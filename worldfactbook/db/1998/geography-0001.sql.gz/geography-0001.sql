SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ecff1a76aba5d64159c66a8537bab5f3fed77f377562c2129dfb16df2f92412',1998,'US','United States','geography',15,'Location: Southern Asia, north and west of
Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area:
total : 647,500 sq km
land: 647,500 sq km
water: 0 sq km
Area— comparative: slightly smaller than Texas
Land boundaries:
total: 5,529 km
border countries: China 76 km, Iran 936 km, Pakistan
2,430 km, Tajikistan 1 ,206 km, Turkmenistan 744 km,
Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot
summers
Terrain: mostly rugged mountains; plains in north
and southwest
Elevation extremes:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal,
copper, talc, barites, sulfur, lead, zinc, iron ore, salt,
precious and semiprecious stones
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 3%
other: 39% (1 993 est.)
Irrigated land: 30,000 sq km (1993 est.)
Natural hazards: damaging earthquakes occur in
Hindu Kush mountains; flooding
Environment— current issues: soil degradation;
overgrazing; deforestation (much of the remaining
forests are being cut down for fuel and building
materials); desertification
Environment— international agreements:
party to: Desertification, Endangered Species,
Environmental Modification, Marine Dumping,
Nuclear Test Ban
signed, but not ratified: Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Marine Life
Conservation
Geography— note: landlocked','4b633717d5b71df62ff5b5263aea57718fbcd3633e421084a81b7b4c1506d680','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3070fa1bd0082f894f31e22af042b10ad88ccc361b8c47026173909a2ca019bb',1998,'DZ','Algeria','geography',23,'Location: Northern Africa, bordering the
Mediterranean Sea, between Morocco and Tunisia
Geographic coordinates: 28 00 N, 3 00 E
Map references: Africa
Area:
total: 2,381 ,740 sq km
land: 2,381 ,740 sq km
water: 0 sq km
Area— comparative: slightly less than 3.5 times the
size of Texas
Land boundaries:
total: 6,343 km
border countries: Libya 982 km, Mali 1,376 km,
Mauritania 463 km, Morocco 1 ,559 km, Niger 956 km,
Tunisia 965 km, Western Sahara 42 km
Coastline: 998 km
Maritime claims:
exclusive fishing zone: 32-52 nm
territorial sea: 12 nm
Climate: arid to semiarid; mild, wet winters with hot,
dry summers along coast; drier with cold winters and
hot summers on high plateau; sirocco is a hot, dust/
sand-laden wind especially common in summer
Terrain: mostly high plateau and desert; some
mountains; narrow, discontinuous coastal plain
Elevation extremes:
lowest point: Chott Melrhir -40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural gas, iron ore,
phosphates, uranium, lead, zinc
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 2%
other: 82% (1993 est.)
Irrigated land: 5,550 sq km (1993 est.)
Natural hazards: mountainous areas subject to
severe earthquakes; mud slides
5
Algeria (continued)
Environment-current issues: soil erosion from
overgrazing and other poor farming practices;
desertification; dumping of raw sewage, petroleum
refining wastes, and other industrial effluents is
leading to the pollution of rivers and coastal waters;
Mediterranean Sea, in particular, becoming polluted
from oil wastes, soil erosion, and fertilizer runoff;
inadequate supplies of potable water
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Nuclear Test Ban
Geography— note: second-largest country in Africa
(after Sudan)
Location: Southwestern Europe, bordering the Bay
of Biscay, Mediterranean Sea, North Atlantic Ocean,
and Pyrenees Mountains, southwest of France
Geographic coordinates: 40 00 N, 4 00 W
Map references: Europe
Area:
fora/; 504,750 sq km
land: 499,400 sq km
water: 5,350 sq km
note: includes Balearic Islands, Canary Islands, and
five places of sovereignty (plazas de soberania) on
and off the coast of Morocco— Ceuta, Mellila, Islas
Chafarinas, Penon de Alhucemas, and Penon de
Velez de la Gomera
Area— comparative: slightly more than twice the
size of Oregon
Land boundaries:
total: 1,919.1 km
border countries: Andorra 65 km, France 623 km,
Gibraltar 1 .2 km, Portugal 1 ,214 km, Morocco (Ceuta)
6.3 km, Morocco (Melilla) 9.6 km
Coastline: 4,964 km
Maritime claims:
exclusive economic zone: 200 nm (applies only to the
Atlantic Ocean)
territorial sea: 12 nm
Climate: temperate; clear, hot summers in interior,
more moderate and cloudy along coast; cloudy, cold
winters in interior, partly cloudy and cool along coast
Terrain: large, flat to dissected plateau surrounded
by rugged hills; Pyrenees in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Teide on Canary Islands 3,71 8 m
Natural resources: coal, lignite, iron ore, uranium,
mercury, pyrites, fluorspar, gypsum, zinc, lead,
tungsten, copper, kaolin, potash, hydropower
Land use:
arable land: 30%
permanent crops: 9%
permanent pastures: 21 %
forests and woodland: 32%
of/?er; 8% (1 993 est.)
Irrigated land: 34,530 sq km (1993 est.)
Natural hazards: periodic droughts
Environment— current issues: pollution of the
Mediterranean Sea from raw sewage and effluents
from the offshore production of oil and gas; water
quality and quantity nationwide; air pollution;
deforestation; desertification
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Desertification
Geography— note: strategic location along
approaches to Strait of Gibraltar','76fe5244f5b7c249d0b834f1e89e0164438851c8cbc5e22cf59b64c3f725f0a3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a97d20a2503da157480b981dc9c4a19490d278a2b4d1c80cf68617155a8c08c',1998,'AS','American Samoa','geography',35,'Location: Southwestern Europe, between France
and Spain
Geographic coordinates: 42 30 N, 1 30 E
Map references: Europe
Area:
total: 450 sq km
land: 450 sq km
water: 0 sq km
Area— comparative: 2.5 times the size of
Washington, DC
Land boundaries:
total: 125 km
border countries: France 60 km, Spain 65 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; snowy, cold winters and warm,
dry summers
Terrain: rugged mountains dissected by narrow
valleys
Elevation extremes:
lowest point: Riu Valira 840 m
highest point: Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral water,
timber, iron ore, lead
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 22%
other: 20% (1993 est.)
Irrigated land: NA sq km
Natural hazards: snowslides, avalanches
Environment— current issues: deforestation;
overgrazing of mountain meadows contributes to soil
erosion
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
9
Andorra (continued)
Geography— note: landlocked
Location: Southern Africa, bordering the South
Atlantic Ocean, between Namibia and Democratic
Republic of the Congo
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area:
total: 1 ,246,700 sq km
land: 1 ,246,700 sq km
water: 0 sq km
Area— comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,198 km
border countries: Democratic Republic of the Congo
2,51 1 km of which 220 km is the boundary of
discontiguous Cabinda Province, Republic of the
Congo 201 km, Namibia 1 ,376 km, Zambia 1 ,1 1 0 km
Coastline: 1,600 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 20 nm
Climate: semiarid in south and along coast to
Luanda; north has cool, dry season (May to October)
and hot, rainy season (November to April)
Terrain: narrow coastal plain rises abruptly to vast
interior plateau
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, diamonds, iron ore,
phosphates, copper, feldspar, gold, bauxite, uranium
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 43%
other: 32% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: locally heavy rainfall causes
periodic flooding on the plateau
Environment— current issues: the overuse of
pastures and subsequent soil erosion attributable to
population pressures; desertification; deforestation of
tropical rain forest, in response to both international
demand for tropical timber and to domestic use as
fuel, resulting in loss of biodiversity; soil erosion
contributing to water pollution and siltation of rivers
and dams; inadequate supplies of potable water
Environment— International agreements:
party to: Biodiversity, Desertification, Law of the Sea
signed, but not ratified: Climate Change
Geography— note: Cabinda is separated from rest
of country by the Democratic Republic of the Congo
Location: Caribbean, island in the Caribbean Sea,
east of Puerto Rico
Geographic coordinates: 18 15 N, 63 10 W
Map references: Centra! America and the
Caribbean
Area:
total: 91 sq km
land: 91 sq km
water: 0 sq km
Area— comparative: about half the size of
Washington, DC
Land boundaries: 0 km
Coastline: 61 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical; moderated by northeast trade
winds
Terrain: flat and low-lying island of coral and
limestone
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crocus Hill 65 m
Natural resources: salt, fish, lobster
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (mostly rock with sparse scrub oak, few
trees, some commercial salt ponds)
Irrigated land: NAsqkm
Natural hazards: frequent hurricanes and other
tropical storms (July to October)
Environment— current issues: supplies of potable
water sometimes cannot meet increasing demand
largely because of poor distribution system
Environment— international agreements:
party to: NA
signed, but not ratified: NA
13
Anguilla (continued)','73aeac39aaec779789d01dedc26b72f8e4bba675581e20c10356d9c6425cfcfb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b449fbb9767b8e85b56c7da971c331dc971660fc5a63bf1ddcd952a3e8f7dd9',1998,'AG','Antigua and Barbuda','geography',45,'Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
east-southeast of Puerto Rico
Geographic coordinates: 17 03 N, 61 48 W
Map references: Central America and the
Caribbean
Area:
total: 440 sq km
land: 440 sq km
water: 0 sq km
note: includes Redonda
Area— comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 153 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical marine; little seasonal temperature
variation
Terrain: mostly low-lying limestone and coral islands
with some higher volcanic areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Boggy Peak 402 m
Natural resources: negligible; pleasant climate
fosters tourism
Land use:
arable land: 18%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 1 1 %
other: 62% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: hurricanes and tropical storms
(July to October); periodic droughts
Environment— current issues: water
management— a major concern because of limited
natural fresh water resources— is further hampered
by the clearing of trees to increase crop production,
causing rainfall to run off quickly
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Location: Southern South America, bordering the
South Atlantic Ocean, between Chile and Uruguay
Geographic coordinates: 34 00 S, 64 00 W
Map references: South America
Area:
total: 2,766,890 sq km
land: 2,736,690 sq km
water: 30,200 sq km
Area— comparative: slightly less than three-tenths
the size of the US
Land boundaries:
total: 9,665 km
border countries: Bolivia 832 km, Brazil 1,224 km,
Chile 5,150 km, Paraguay 1,880 km, Uruguay 579 km
Coastline: 4,989 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly temperate; arid in southeast;
subantarctic in southwest
19
Argentina (continued)
Terrain: rich plains of the Pampas in northern half,
flat to rolling plateau of Patagonia in south, rugged
Andes along western border
Elevation extremes:
lowest point: Salinas Chicas -40 m
highest point: Cerro Aconcagua 6,962 m
Natural resources: fertile plains of the pampas,
lead, zinc, tin, copper, iron ore, manganese,
petroleum, uranium
Land use:
arable land: 9%
permanent crops: 1%
permanent pastures: 52%
forests and woodland: 1 9%
other: 1 9% (1 993 est.)
Irrigated land: 17,000 sq km (1993 est.)
Natural hazards: San Miguel de Tucuman and
Mendoza areas in the Andes subject to earthquakes;
pamperos are violent windstorms that can strike the
Pampas and northeast; heavy flooding
Environment— current issues: erosion results from
inadequate flood controls and improper land use
practices; irrigated soil degradation; desertification; air
pollution in Buenos Aires and other major cities; water
pollution in urban areas; rivers becoming polluted due
to increased pesticide and fertilizer use
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Geography— note: second-largest country in South
America (after Brazil); strategic location relative to sea
lanes between South Atlantic and South Pacific
Oceans (Strait of Magellan, Beagle Channel, Drake
Passage)','c3095a821061529274329b916af755e3b06f7be11b32c5fca759a24722249b0f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd86758c663cf7b80854a9c0ff07bb2b5f10398b882dce01686f4b73a96567a2',1998,'AQ','Antarctica','geography',54,'Location: Southwestern Asia, east of Turkey
Geographic coordinates: 40 00 N, 45 00 E
Map references: Commonwealth of Independent
States
Area:
total: 29,800 sq km
land: 28,400 sq km
water: 1,400 sq km
Area— comparative: slightly smaller than Maryland
Land boundaries:
total: 1,254 km
border countries: Azerbaijan-proper 566 km,
Azerbaijan-Naxcivan exclave 221 km, Georgia 164
km, Iran 35 km, Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: highland continental, hot summers, cold
winters
Terrain: high Armenian Plateau with mountains; little
forest land; fast flowing rivers; good soil in Aras River
valley ./
Elevation extremes:
lowest point: Debed River 400 m
highest point: Aragats Lerr 4,095 m
Natural resources: small deposits of gold, copper,
molybdenum, zinc, alumina
Land use:
arable land: 17%
permanent crops: 3%
permanent pastures: 24%
forests and woodland: 1 5%
other: 41% (1993 est.)
Irrigated land: 2,870 sq km (1993 est.)
Natural hazards: occasionally severe earthquakes;
droughts
Environment— current issues: soil pollution from
toxic chemicals such as DDT; energy blockade, the
result of conflict with Azerbaijan, has led to
deforestation when citizens scavenged for firewood;
pollution of Hrazdan (Razdan) and Aras Rivers; the
draining of Sevana Lich (Lake Sevan), a result of its
use as a source for hydropower, threatens drinking
water supplies; restart of Metsamor nuclear power
plant without adequate (IAEA-recommended) safety
and backup systems
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Nuclear Test Ban, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked
Location: Caribbean, island in the Caribbean Sea,
north of Venezuela
Geographic coordinates: 12 30 N, 69 58 W
Map references: Central America and the
Caribbean
Area:
total: 193 sq km
land: 193 sq km
water: 0 sq km
Area— comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 68.5 km
Maritime claims:
territorial sea: 12 nm
Climate: tropical marine; little seasonal temperature
variation
Terrain: flat with a few hills; scant vegetation
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Jamanota 1 88 m
Natural resources: negligible; white sandy beaches
Land use:
arable land: M%
permanent crops: N A%
permanent pastures: N A%
forests and woodland: NA%
other: 89% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: lies outside the Caribbean
hurricane belt
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Location: Southeastern Asia, islands in the Indian
Ocean, northwest of Australia
Geographic coordinates: 12 14 S, 123 05 E
Map references: Southeast Asia
Area:
total: 5sq km
land: 5sq km
water ; 0 sq km
note: includes Ashmore Reef (West, Middle, and East
Islets) and Cartier Island
Area-Comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: Okm
Coastline: 74.1 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone : 200 nm
territorial sea: 3 nm
Climate: tropical
Terrain: low with sand and coral
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 3 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all grass and sand)
Irrigated land: 0sqkm(1993)
Natural hazards: surrounded by shoals and reefs
that can pose maritime hazards
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed , but not ratified: NA
Geography— note: Ashmore Reef National Nature
Reserve established in August 1983
Location: Central Europe, north of Italy and Slovenia
Geographic coordinates: 47 20 N, 13 20 E
Map references: Europe
Area:
total: 83,858 sq km
land: 82,738 sq km
water: 1,120 sq km
Area— comparative: slightly smaller than Maine
Land boundaries:
total: 2,562 km
border countries: Czech Republic 362 km, Germany
784 km, Hungary 366 km, Italy 430 km, Liechtenstein
35 km, Slovakia 91 km, Slovenia 330 km, Switzerland
164 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; continental, cloudy; cold winters
with frequent rain in lowlands and snow in mountains;
cool summers with occasional showers
Terrain: in the west and south mostly mountains
(Alps); along the eastern and northern margins mostly
flat or gently sloping
Elevation extremes:
lowest point: Neusiedler See 115m
highest point: Grossglockner 3,797 m
Natural resources: iron ore, oil, timber, magnesite,
lead, coal, lignite, copper, hydropower
Land use:
arable land: 17%
permanent crops: 1%
permanent pastures: 23%
forests and woodland : 39%
other: 20% (1 996 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: some forest
degradation caused by air and soil pollution; soil
pollution results from the use of agricultural
chemicals; air pollution results from emissions by
coal- and oil-fired power stations and industrial plants
and from trucks transiting Austria between northern
and southern Europe
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, , but not ratified: Mr Pollution-Sulphur 94,
Antarctic-Environmental Protocol
Geography— note: landlocked; strategic location at
the crossroads of central Europe with many easily
traversable Alpine passes and valleys; major river is
the Danube; population is concentrated on eastern
lowlands because of steep slopes, poor soils, and low
temperatures elsewhere','7ceccfabf3854a4a84f1fe4891d67679a1faee02c485cf9ca059956029152891','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8db044f7a90d209eb55bc6c80ebda9488bae38a29ee15ae786bf2960db9805de',1998,'AZ','Azerbaijan','geography',56,'Location: Southwestern Asia, bordering the Caspian
Sea, between Iran and Russia
Geographic coordinates: 40 30 N, 47 30 E
Map references: Commonwealth of Independent
States
Area:
total: 86,600 sq km
land: 86, 100 sq km
wafer: 500 sq km
note: includes the exclave of Naxcivan Autonomous
Republic and the Nagorno-Karabakh region; the
region''s autonomy was abolished by Azerbaijani
Supreme Soviet on 26 November 1991
Area— comparative: slightly smaller than Maine
Land boundaries:
fofa/:2,013km
border countries: Armenia (with Azerbaijan-proper)
566 km, Armenia (with Azerbaijan-Naxcivan exclave)
221 km, Georgia 322 km, Iran (with
Azerbaijan-proper) 432 km, Iran (with
Azerbaijan-Naxcivan exclave) 179 km, Russia 284
km, Turkey 9 km
Coastline: 0 km (landlocked)
note: Azerbaijan borders the Caspian Sea (800 km,
est.)
Maritime claims: none (landlocked)
Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Lowland (much of it
below sea level) with Great Caucasus Mountains to
the north, Qarabag (Karabakh) Upland in west; Baku
lies on Abseron (Apsheron) Peninsula that juts into
Caspian Sea
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Natural resources: petroleum, natural gas, iron ore,
nonferrous metals, alumina
Land use:
arable land: 18%
permanent crops: 5%
permanent pastures: 25%
forests and woodland: 1 1 %
ofber:41%(1993est.)
Irrigated land: 1 0,000 sq km (1 993 est.)
Natural hazards: droughts; some lowland areas
threatened by rising levels of the Caspian Sea
Environment— current issues: local scientists
consider the Abseron (Apsheron) Peninsula (including
Baku and Sumqayit) and the Caspian Sea to be the
ecologically most devastated area in the world
because of severe air, water, and soil pollution; soil
pollution results from the use of DDT as a pesticide
and also from toxic defoliants used in the production
of cotton
Environment— international agreements:
party to: Climate Change, Ozone Layer Protection
signed, but not ratified: Biodiversity
Geography— note: landlocked','9bd342e1f8d91d02e048f2db7a1e5d930361bdd904752c0e278b41bfc6b41d5c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bb13f58ea2460fcb853a261c926bf84821b27564ae64aa112e84b776c1c3728',1998,'BB','Barbados','geography',82,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, northeast of
Venezuela
Geographic coordinates: 13 10 N, 59 32 W
Map references: Central America and the
Caribbean
Area:
total: 430 sq km
land: 430 sq km
water: 0 sq km
Area— comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 97 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy season (June to October)
Terrain: relatively flat; rises gently to central highland
region
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Hillaby 336 m
Natural resources: petroleum, fish, natural gas
Land use:
arable land: 37%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 12%
other: 46% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: infrequent hurricanes; periodic
landslides
Environment— current issues: pollution of coastal
waters from waste disposal by ships; soil erosion;
illegal solid waste disposal threatens contamination of
aquifers
Environment— international agreements:
party to: Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Whaling
signed, but not ratified: Biodiversity
Geography— note: easternmost Caribbean island','6095cb006e7428515f4dafb6ea889ebc1eb805e77adabaecf2c9a43df4ac1b2d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d79026b08915707e3a0ffb3a37c52d863c5d539efcb9cdb2cef4031a6ef29326',1998,'LC','Saint Lucia','geography',90,'Location: Southern Africa, islands in the southern
Mozambique Channel, about one-half of the way from
Madagascar to Mozambique
Geographic coordinates: 21 30 S, 39 50 E
Map references: Africa
Area:
total: 0.2 sq km
land: 0.2 sq km
water: 0 sq km
Area— comparative: about one-third the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: a volcanic rock 2.4 meters high
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 2.4 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all rock)
irrigated land: 0 sq km (1993)
Natural hazards: maritime hazard since it is usually
under water during high tide and surrounded by reefs;
subject to periodic cyclones
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: N A','ded0cfce07313d4ca28dcde8cccef174e6a2b29b01d4df85f13ae1a8c6cc8ed1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56b64756af0a62b2c69cb2b5e04e00b7b20a60be3e3455113bd25eb1d2beafc6',1998,'FR','France','geography',104,'Location: Middle America, bordering the Caribbean
Sea, between Guatemala and Mexico
Geographic coordinates: 17 15 N, 88 45 W
Map references: Centra! America and the
Caribbean
Area:
total: 22,960 sq km
land: 22,800 sq km
water: 160 sq km
Area— comparative: slightly smaller than
Massachusetts
Land boundaries:
total: 51 6 km
border countries: Guatemala 266 km, Mexico 250 km
Coastline: 386 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm in the north, 3 nm in the south;
note— from the mouth of the Sarstoon River to
Ranguana Cay, Belize''s territorial sea is 3 nm;
according to Belize''s Maritime Areas Act, 1992, the
purpose of this limitation is to provide a framework for
the negotiation of a definitive agreement on territorial
differences with Guatemala
Climate: tropical; very hot and humid; rainy season
(May to February)
Terrain: flat, swampy coastal plain; low mountains in
south
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Victoria Peak 1 ,1 60 m
Natural resources: arable land potential, timber,
fish
Land use:
arable land: 2%
permanent crops: 1%
permanent pastures: 2%
forests and woodland : 92%
other: 3% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: frequent, devastating hurricanes
(September to December) and coastal flooding
(especially in south)
Environment— current issues: deforestation;
water pollution from sewage, industrial effluents,
agricultural runoff
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Marine Dumping, Ship Pollution,
Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: national capital moved 80 km
inland from Belize City to Belmopan because of
hurricanes; only country in Central America without a
coastline on the North Pacific Ocean
Location: Southeastern Asia, group of islands in the
Indian Ocean, south of Indonesia, about one-half of
the way from Australia to Sri Lanka
Geographic coordinates: 12 30 S, 96 50 E
Map references: Southeast Asia
Area:
total: 14 sq km
land: 14 sq km
water: 0 sq km
note: includes the two main islands of West Island and
Home Island
Area— comparative: about 24 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 2.6 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: pleasant, modified by the southeast trade
wind for about nine months of the year; moderate
rainfall
Terrain: flat, low-lying coral atolls
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: NA%
permanent crops: N A%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: cyclones may occur in the early
months of the year
Environment— current issues: fresh water
resources are limited to rainwater accumulations in
natural underground reservoirs
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: two coral atolls thickly covered
with coconut palms and other vegetation
Location: Southeastern Europe, bordering the
Adriatic Sea, between Bosnia and Herzegovina and
Location: Southern South America, islands in the
South Atlantic Ocean, east of southern Argentina
Geographic coordinates: 51 45 S, 59 00 W
Map references: South America
Area:
total: 12,173 sq km
land: 12,173 sq km
water: 0 sq km
note: includes the two main islands of East and West
Falkland and about 200 small islands
Area— comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 1,288 km
Maritime claims:
continental shelf: 200 nm
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: cold marine; strong westerly winds, cloudy,
humid; rain occurs on more than half of days in year;
occasional snow all year, except in January and
February, but does not accumulate
Terrain: rocky, hilly, mountainous with some boggy,
undulating plains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Usborne 705 m
Natural resources: fish, wildlife
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 99%
forests and woodland: 0%
other: 1% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: strong winds persist throughout
the year
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: deeply indented coast provides
good natural harbors; short growing season
Location: south of Africa, islands in the southern
Indian Ocean, about equidistant between Africa,
Antarctica, and Australia; note— French Southern and
Antarctic Lands includes lie Amsterdam, lie
Saint-Paul, lies Crozet, and lies Kerguelen in the
southern Indian Ocean, along with the
French-claimed sector of Antarctica, "Adelie Land";
the US does not recognize the French claim to " Adelie
Land"
Geographic coordinates: 43 00 S, 67 00 E
Map references: Antarctic Region
Area:
total: 7,781 sq km
land: 7,781 sq km
water: 0 sq km
note: includes lie Amsterdam, lie Saint-Paul, lies
Crozet and lies Kerguelen; excludes "Adelie Land"
claim of about 500,000 sq km in Antarctica that is not
recognized by the US
Area— comparative: slightly less than 1 .3 times the
size of Delaware
Land boundaries: 0 km
Coastline: 1,232 km
Maritime claims:
exclusive economic zone: 200 nm from lies
Kerguelen only
territorial sea: 1 2 nm
Climate: antarctic
Terrain: volcanic
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Ross on Kerguelen 1,850 m
Natural resources: fish, crayfish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
168
ships by type: bulk 2, cargo 4, chemical tanker 7,
container 10, liquefied gas tanker 5, oil tanker 19,
refrigerated cargo 2, roll-on/rol!-off cargo 12
note : French Southern and Antarctic Lands owns 3
additional ships (1,000 GRT or over) totaling 78,691
DWT jhat operate under French registry (1997 est.)
Airport^: none
1 Military
Military— note: defense is the responsibility of
Location: Centra! Asia, northwest of China
Geographic coordinates: 48 00 N, 68 00 E
Map references: Commonwealth of Independent
States
Area:
total: 2,71 7,300 sq km
land: 2,669,800 sq km
water: 47,500 sq km
Area— comparative: slightly less than four times the
size of Texas
Land boundaries:
total: 12,012 km
border countries: China 1,533 km, Kyrgyzstan
1,051 km, Russia 6,846 km, Turkmenistan 379 km,
Uzbekistan 2,203 km
Coastline: 0 km (landlocked)
note: Kazakhstan borders the Aral Sea (1 ,015 km)
and the Caspian Sea (1 ,894 km)
Maritime claims: none (landlocked)
Climate: continental, cold winters and hot summers,
arid and semiarid
Terrain: extends from the Volga to the Altai
Mountains and from the plains in western Siberia to
oasis and desert in Centra! Asia
Elevation extremes:
lowest point: Vpadina Kaundy -1 32 m
highest point: Zhengis Shingy (Pik Khan-Tengri)
6,995 m
Natural resources: major deposits of petroleum,
natural gas, coal, iron ore, manganese, chrome ore,
nickel, cobalt, copper, molybdenum, lead, zinc,
bauxite, gold, uranium
Land use:
arable land: 12%
permanent crops: A %
permanent pastures: 57%
forests and woodland: 4%
other: 16% (1996 est.)
Irrigated land: 22,000 sq km (1996 est.)
Natural hazards: earthquakes in the south,
mudslides around Almaty
Environment— current issues: radioactive or toxic
chemical sites associated with its former defense
industries and test ranges are found throughout the
country and pose health risks for humans and
animals; industrial pollution is severe in some cities;
because the two main rivers which flowed into the Aral
Sea have been diverted for irrigation, it is drying up
and leaving behind a harmful layer of chemical
pesticides and natural salts; these substances are
then picked up by the wind and blown into noxious
dust storms; pollution in the Caspian Sea; soil
pollution from overuse of agricultural chemicals and
salinization from faulty irrigation practices
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked
Location: Northern Africa, bordering the North
Atlantic Ocean, between Senegal and Western
Sahara
Geographic coordinates: 20 00 N, 12 00 W
Map references: Africa
Area:
total: 1,030,700 sq km
land: 1,030,- 400 sq km
water: 300 sq km
Area— comparative: slightly larger than three times
the size of New Mexico
Land boundaries:
total: 5,074 km
border countries: Algeria 463 km, Mali 2,237 km,
Senegal 813 km, Western Sahara 1,561 km
Coastline: 754 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the Sahara;
some central hills
Elevation extremes:
lowest point: Sebkha de Ndrhamcha -3 m
highest point: Kediet Ijill 910 m
Natural resources: iron ore, gypsum, fish, copper,
phosphate
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 38%
forests and woodland: 4%
other: 58% (1993 est.)
Irrigated land: 490 sq km (1993 est.)
Natural hazards: hot, dry, dust/sand-laden sirocco
wind blows primarily in March and April; periodic
droughts
304
Environment-current issues: overgrazing,
deforestation, and soil erosion aggravated by drought
are contributing to desertification; very limited natural
fresh water resources away from the Senegal which is
the only perennial river
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: most of the population
concentrated in the cities of Nouakchott and
Nouadhibou and along the Senegal River in the
southern part of the country
Location: Northern Asia, between China and Russia
Geographic coordinates: 46 00 N, 105 00 E
Map references: Asia
Area:
total: 1.565 million sq km
land: 1 .565 million sq km
water: 0 sq km
Area— comparative: slightly smaller than Alaska
Land boundaries:
total: 8,114 km
border countries: China 4,673 km, Russia 3,441 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; continental (large daily and
seasonal temperature ranges)
Terrain: vast semidesert and desert plains;
mountains in west and southwest; Gobi Desert in
southeast
Elevation extremes:
lowest point: Hoh Nuur 518 m
highest point: Tavan Bogd Uul 4,374 m
Natural resources: oil, coal, copper, molybdenum,
tungsten, phosphates, tin, nickel, zinc, wolfram,
fluorspar, gold
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 80%
forests and woodland: 9%
other: 1 0% (1 993 est.)
Irrigated land: 800 sq km (1993 est.)
Natural hazards: dust storms can occur in the
spring; grassland fires
Environment— current issues: limited natural fresh
water resources; policies of the former communist
regime promoting rapid urbanization and industrial
growth have raised concerns about their negative
effects on the environment; the burning of soft coal
and the concentration of factories in Ulaanbaatarhave
severely polluted the air; deforestation, overgrazing,
the converting of virgin land to agricultural production
have increased soil erosion from wind and rain;
desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked; strategic location
between China and Russia
Location: Caribbean, island in the Caribbean Sea,
southeast of Puerto Rico
Geographic coordinates: 16 45 N, 62 12 W
Map references: Central America and the
Caribbean
Area:
total: 100 sq km
land: 100 sq km
water: 0 sq km
Area— comparative: about 0.6 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 40 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical; little daily or seasonal temperature
variation
Terrain: volcanic islands, mostly mountainous, with
small coastal lowland
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Chances Peak 914 m
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 0%
permanent pastures: 1 0%
forests and woodland: 40%
other: 30% (1 993 est.)
Irrigated land: NAsqkm
Natural hazards: severe hurricanes (June to
November); volcanic eruptions (full-scale eruptions of
the Soufriere Hills volcano occurred during 1996)
Environment— current issues: land erosion occurs
on slopes that have been cleared for cultivation
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Location: Southern Africa, bordering the South
Atlantic Ocean, between Angola and South Africa
Geographic coordinates: 22 00 S, 17 00 E
Map references: Africa
Area:
total: 825,41 8 sq km
land: 825,41 8 sq km
water: 0 sq km
Area— comparative: slightly more than half the size
of Alaska
Land boundaries:
total: 3,824 km
border countries: Angola 1,376 km, Botswana 1 ,360
km, South Africa 855 km, Zambia 233 km
Coastline: 1,572 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; hot, dry; rainfall sparse and erratic
Terrain: mostly high plateau; Namib Desert along
coast; Kalahari Desert in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Konigstein 2,606 m
Natural resources: diamonds, copper, uranium,
gold, lead, tin, lithium, cadmium, zinc, salt, vanadium,
natural gas, fish; suspected deposits of oil, natural
gas, coal, iron ore
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 22%
other: 31% (1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: prolonged periods of drought
Environment— current issues: very limited natural
fresh water resources; desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements
Location: Caribbean, islands in the Caribbean Sea,
north of Trinidad and Tobago
Geographic coordinates: 13 15 N, 61 12 W
Map references: Central America and the
Caribbean
Area:
total: 340 sq km
land: 340 sq km
water: 0 sq km
Area— comparative: twice the size of Washington,
DC
Land boundaries: Okm
Coastline: 84 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropica!; little seasonal temperature
variation; rainy season (May to November)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1 ,234 m
Natural resources: NEGL
Land use:
arable land: 10%
permanent crops: 18%
permanent pastures : 5%
forests and woodland: 36%
other: 31% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: hurricanes; Soufriere volcano on
the island of Saint Vincent is a constant threat
Environment— current issues: pollution of coastal
waters and shorelines from discharges by pleasure
yachts and other effluents; in some areas pollution is
severe enough to make swimming prohibitive
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography— note: the administration of the islands
of the Grenadines group is divided between Saint
Vincent and the Grenadines and Grenada
Geographic coordinates: 54 00 N, 2 00 W
Map references: Europe
Area:
total: 244,820 sq km
land: 241 ,590 sq km
water: 3,230 sq km
note: includes Rockall and Shetland islands
Area— comparative: slightly smaller than Oregon
Land boundaries:
total: 360 km
border countries: Ireland 360 km
Coastline: 12,429 km
Maritime claims:
continental shelf: as defined in continental shelf
orders or in accordance with agreed upon boundaries
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: temperate; moderated by prevailing
southwest winds over the North Atlantic Current; more
than one-half of the days are overcast
Terrain: mostly rugged hills and low mountains; level
to rolling plains in east and southeast
Elevation extremes:
lowest point : Fenland -4 m
highest point: Ben Nevis 1 ,343 m
Natural resources: coal, petroleum, natural gas, tin,
limestone, iron ore, salt, clay, chalk, gypsum, lead,
silica
Land use:
arable land: 25%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 1 0%
other: 19% (1993 est.)
Irrigated land: 1 ,080 sq km (1 993 est.)
Natural hazards: NA
Environment— current issues: sulfur dioxide
emissions from power plants contribute to air
pollution; some rivers polluted by agricultural wastes
and coastal waters polluted because of large-scale
disposal of sewage at sea
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: lies near vital North Atlantic sea
lanes; only 35 km from France and now linked by
tunnel under the English Channel; because of heavily
indented coastline, no location is more than 125 km
from tidal waters
Location: North America, bordering both the North
Atlantic Ocean and the North Pacific Ocean, between
Canada and Mexico
Geographic coordinates: 38 00 N, 97 00 W
Map references: North America
Area:
total: 9,629,091 sq km
land: 9,1 58,960 sq km
water: 470, 131 sq km
note: includes only the 50 states and District of
Columbia
Area— comparative: about one-half the size of
Russia; about three-tenths the size of Africa; about
one-half the size of South America (or slightly larger
than Brazil); slightly larger than China; about two and
one-half times the size of Western Europe
Land boundaries:
total: 12,248 km
border countries: Canada 8,893 km (including 2,477
km with Alaska), Cuba 29 km (US Naval Base at
Guantanamo Bay), Mexico 3,326 km
note: Guantanamo Naval Base is leased by the US
and thus remains part of Cuba
Coastline: 19,924 km
Maritime claims:
contiguous zone: 1 2 nm
continental shelf: not specified
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly temperate, but tropical in Hawaii and
Florida and arctic in Alaska, semiarid in the great
plains west of the Mississippi River and arid in the
Great Basin of the southwest; low winter temperatures
in the northwest are ameliorated occasionally in
January and February by warm Chinook winds from
the eastern slopes of the Rocky Mountains
Terrain: vast central plain, mountains in west, hills
and low mountains in east; rugged mountains and
broad river valleys in Alaska; rugged, volcanic
topography in Hawaii
Elevation extremes:
lowest point: Death Valley -86 m
highest point: Mount McKinley 6,194 m
Natural resources: coal, copper, lead,
molybdenum, phosphates, uranium, bauxite, gold,
iron, mercury, nickel, potash, silver, tungsten, zinc,
petroleum, natural gas, timber
Land use:
arable land: 19%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 30%
other: 26% (1993 est.)
Irrigated land: 207,000 sq km (1993 est.)
Natural hazards: tsunamis, volcanoes, and
earthquake activity around Pacific Basin; hurricanes
along the Atlantic coast; tornadoes in the midwest;
mud slides in California; forest fires in the west;
flooding; permafrost in northern Alaska is a major
impediment to development
Environment— current issues: air pollution
resulting in acid rain in both the US and Canada; the
US is the largest single emitter of carbon dioxide from
the burning of fossil fuels; water pollution from runoff
of pesticides and fertilizers; very limited natural fresh
water resources in much of the western part of the
country require careful management; desertification
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Antarctic-Environmental Protocol, Antarctic Treaty,
Climate Change, Endangered Species,
Environmental Modification, Marine Dumping, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed [ but not ratified: Air Pollution-Volatile Organic
Compounds, Biodiversity, Desertification, Hazardous
Wastes
Geography— note: world''s third-largest country
(after Russia and Canada)
Location: Middle East, west of Jordan
Geographic coordinates: 32 00 N, 35 15 E
Map references: Middle East
Area:
total: 5,860 sq km
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun Salient, and the
northwest quarter of the Dead Sea, but excludes Mt.
Scopus; East Jerusalem and Jerusalem No Man''s
Land are also included only as a means of depicting
the entire area occupied by Israel in 1967
Area— comparative: slightly smaller than Delaware
Land boundaries:
total: 404 km
border countries: Israel 307 km, Jordan 97 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, temperature and precipitation
vary with altitude, warm to hot summers, cool to mild
winters
Terrain: mostly rugged dissected upland, some
vegetation in west, but barren in east
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Tall Asur 1,022 m
Natural resources: NEGL
Land use:
arable land: 27%
permanent crops: 0%
permanent pastures: 32%
forests and woodland: 1%
other: 40%
Irrigated land: NA sq km
Natural hazards: NA
Environment— current issues: adequacy of fresh
water supply; sewage treatment
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked; highlands are main
recharge area for Israel''s coastal aquifers; there are
207 Israeli settlements and civilian land use sites in
the West Bank and 29 in East Jerusalem (August
1997 est.)','9ac26c45d1950a0f5a348effdaf584877801e5e09245b91c4b4d4885c7e28458','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cc322cd931d82b1771a49edb835224c4ac36af7c4bba7eccc5a34b87442ebc6',1998,'BM','Bermuda','geography',116,'Location: Southern Asia, between China and India
Geographic coordinates: 27 30 N, 90 30 E
Map references: Asia
Area:
total: 47,000 sq km
land: 47,000 sq km
water: 0 sq km
Area— comparative: about half the size of Indiana
Land boundaries:
total: 1,075 km
border countries: China 470 km, India 605 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies; tropica! in southern plains; cool
winters and hot summers in centra! valleys; severe
winters and cool summers in Himalayas
Terrain: mostly mountainous with some fertile
valleys and savanna
Elevation extremes:
lowest point: Dangme Chu 97 m
highest point: Khula Kangri 1 7,553 m
Natural resources: timber, hydropower, gypsum,
calcium carbide
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 66%
other: 26% (1 993 est.)
Irrigated land: 340 sq km (1993 est.)
Natural hazards: violent storms coming down from
the Himalayas are the source of the country''s name
which translates as Land of the Thunder Dragon;
frequent landslides during the rainy season
Environment— current issues: soil erosion; limited
access to potable water
Environment— international agreements:
party to: Biodiversity, Climate Change, Nuclear Test
Ban
signed, but not ratified: Law of the Sea
Geography— note: landlocked; strategic location
between China and India; controls several key
Himalayan mountain passes
Location: Central South America, southwest of','f68d71ed0376a4066214c0f9d5a58dbec54593a4946697c2dc6a82879961f00d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a63fd8a618f31731b1197e3204afa083bf20d5f88768aeafe8140893395a7b0d',1998,'BR','Brazil','geography',117,'Geographic coordinates: 17 00 S, 65 00 W
Map references: South America
Area:
total: 1,098,580 sq km
land: 1,084,390 sq km
water: 14,190 sq km
Area— comparative: slightly less than three times
the size of Montana
Land boundaries:
total : 6,743 km
border countries: Argentina 832 km, Brazil 3,400 km,
Chile 861 km, Paraguay 750 km, Peru 900 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies with altitude; humid and tropical to
cold and semiarid
Terrain: rugged Andes Mountains with a highland
plateau (Altiplano), hills, lowland plains of the Amazon
Basin
Elevation extremes:
lowest point: Rio Paraguay 90 m
highest point: Cerro Illimani 6,882 m
Natural resources: tin, natural gas, petroleum, zinc,
tungsten, antimony, silver, iron, lead, gold, timber
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 24%
forests and woodland: 53%
other: 21 % (1 993 est.)
Irrigated land: 1,750 sq km (1993 est.)
Natural hazards: cold, thin air of high plateau is
obstacle to efficient fuel combustion, as well as to
physical activity by those unaccustomed to it from
birth; flooding in the northeast (March-April)
Environment— current issues: the clearing of land
for agricultural purposes and the international demand
for tropical timber are contributing to deforestation;
soil erosion from overgrazing and poor cultivation
methods (including slash-and-burn agriculture);
desertification; loss of biodiversity; industrial pollution
of water supplies used for drinking and irrigation
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification,
Marine Dumping, Marine Life Conservation, Ozone
Layer Protection
Geography— note: landlocked; shares control of
Lago Titicaca, world’s highest navigable lake
(elevation 3,805 m), with Peru
Location: Southeastern Europe, bordering the
Adriatic Sea and Croatia
Geographic coordinates: 44 00 N, 18 00 E
Map references: Europe
Area:
total: 51 ,233 sq km
land: 51 ,233 sq km
water: 0 sq km
Area— comparative: slightly smaller than West
Virginia
Land boundaries:
total: 1,459 km
border countries: Croatia 932 km, Serbia and
Montenegro 527 km (31 2 km with Serbia, 21 5 km with
Montenegro)
Coastline: 20 km
Maritime claims: NA
Climate: hot summers and cold winters; areas of
high elevation have short, cool summers and long,
severe winters; mild, rainy winters along coast
Terrain: mountains and valleys
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Natural resources: coal, iron, bauxite, manganese,
forests, copper, chromium, lead, zinc
Land use:
arable land: 14%
permanent crops: 5%
permanent pastures: 20%
forests and woodland: 39%
other: 22% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: frequent and destructive
earthquakes
Environment— current issues: air pollution from
metallurgical plants; sites for disposing of urban waste
are limited; widespread casualties, water shortages,
and destruction of infrastructure because of the
1992-95 civil strife
Environment— international agreements:
party to: Air Pollution, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection
signed, but not ratified : none of the selected
agreements
Geography— note: within Bosnia and Herzegovina''s
recognized borders, the country is divided into a joint
Muslim/Croat Federation (about 51% of the territory)
and a Serb Republic, The Republika Srpska [RS]
(about 49% of the territory); the region called
Herzegovina is contiguous to Croatia and traditionally
has been settled by an ethnic Croat majority
Location: Western South America, bordering the
South Pacific Ocean, between Chile and Ecuador
Geographic coordinates: 10 00 S, 76 00 W
Map references: South America
Area:
total: 1 ,285,220 sq km
land: 1 .28 million sq km
water: 5,220 sq km
Area— comparative: slightly smaller than Alaska
Land boundaries:
total: 6,940 km
border countries: Bolivia 900 km, Brazil 1,560 km,
Chile 1 60 km, Colombia 2,900 km, Ecuador 1 ,420 km
Coastline: 2,414 km
Maritime claims:
continental shelf: 200 nm
territorial sea: 200 nm
Climate: varies from tropical in east to dry desert in
west
Terrain: western coastal plain (costa), high and
rugged Andes in center (sierra), eastern lowland
jungle of Amazon Basin (selva)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado Huascaran 6,768 m
Natural resources: copper, silver, gold, petroleum,
timber, fish, iron ore, coal, phosphate, potash
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 21 %
forests and woodland: 66%
other: 10% (1993 est.)
Irrigated land: 1 2,800 sq km (1 993 est.)
Natural hazards: earthquakes, tsunamis, flooding,
landslides, mild volcanic activity
Environment-current issues: deforestation;
overgrazing of the slopes of the costa and sierra
leading to soil erosion; desertification; air pollution in
Lima; pollution of rivers and coastal waters from
municipal and mining wastes
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: shares control of Lago Titicaca,
world''s highest navigable lake, with Bolivia','3c7bef16898e152eb31034e470652d37d3f945e637cb7d03ae18bce10bc5e4b4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd24ab1de4621dc84e0034fa307a7339d2fd34852751abc7b35fead50f032957',1998,'NO','Norway','geography',128,'Location: Eastern South America, bordering the
Atlantic Ocean
Geographic coordinates: 1 0 00 S, 55 00 W
Map references: South America
Area:
total: 8,51 1 ,965 sq km
land: 8,456,51 Osq km
water: 55,455 sq km
note: includes Arquipelago de Fernando de Noronha,
Atol das Rocas, llha da Trindade, llhas Martin Vaz,
and Penedos de Sao Pedro e Sao Paulo
Area— comparative: slightly smaller than the US
Land boundaries:
total: 14,691 km
border countries: Argentina 1 ,224 km, Bolivia 3,400
km, Colombia 1,643 km, French Guiana 673 km,
Guyana 1 ,1 1 9 km, Paraguay 1 ,290 km, Peru 1 ,560
km, Suriname 597 km, Uruguay 985 km, Venezuela
2,200 km
Coastline: 7,491 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly tropical, but temperate in south
Terrain: mostly flat to rolling lowlands in north; some
plains, hills, mountains, and narrow coastal belt
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico da Neblina 3,014 m
Natural resources: bauxite, gold, iron ore,
manganese, nickel, phosphates, platinum, tin,
uranium, petroleum, hydropower, timber
Land use:
arable land: 5%
permanent crops: 1%
permanent pastures: 22%
forests and woodland: 58%
other: 14% (1993 est.)
63
Brazil (continued)
Irrigated land: 28,000 sq km (1993 est.)
Natural hazards: recurring droughts in northeast;
floods and occasional frost in south
Environment— current Issues: deforestation in
Amazon Basin destroys the habitat and endangers
the existence of a multitude of plant and animal
species indigenous to the area; air and water pollution
in Rio de Janeiro, Sao Paulo, and several other large
cities; land degradation and water pollution caused by
improper mining activities
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropica! Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: largest country in South
America; shares common boundaries with every
South American country except Chile and Ecuador
Location: Southern Asia, archipelago in the Indian
Ocean, about one-half the way from Africa to
Location: Oceania, island in the South Pacific
Ocean, about one-half of the way from Hawaii to the','c0558cb32815c2619388b4c995a269d44919170d7e4f634833d55795b007e9e9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e68da19e2357d7161e83be12ca433986b0d633769689aa5d2af112ab3acdf312',1998,'ID','Indonesia','geography',134,'Geographic coordinates: 6 00 S, 71 30 E
Map references: World
Area:
fofa/:60 sq km
land: 60 sq km
water: 0 sq km
note: includes the entire Chagos Archipelago
Area— comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 698 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical marine; hot, humid, moderated by
trade winds
Terrain: flat and low (up to four meters in elevation)
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Diego Garcia 1 5
m
Natural resources: coconuts, fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: NA%
other: NA%
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Geography— note: archipelago of 2,300 islands;
Diego Garcia, largest and southernmost island,
occupies strategic location in central Indian Ocean;
island is site of joint US-UK military facility
Location: Middle East, bordering the Gulf of Oman,
the Persian Gulf, and the Caspian Sea, between Iraq
and Pakistan
Geographic coordinates: 32 00 N, 53 00 E
Map references: Middle East
Area:
tofa/: 1 .648 million sq km
land: 1.636 million sq km
water: 12,000 sq km
Area— comparative: slightly larger than Alaska
Land boundaries:
total: 5,440 km
border countries: Afghanistan 936 km, Armenia 35
km, Azerbaijan-proper 432 km, Azerbaijan-Naxcivan
exclave 179 km, Iraq 1,458 km, Pakistan 909 km,
Turkey 499 km, Turkmenistan 992 km
Coastline: 2,440 km
note: Iran also borders the Caspian Sea (740 km)
Maritime claims:
contiguous zone: 24 nm
continental shelf: natural prolongation
exclusive economic zone: bilateral agreements, or
median lines in the Persian Gulf
territorial sea: 12 nm
Climate: mostly arid or semiarid, subtropical along
Caspian coast
Terrain: rugged, mountainous rim; high, central
basin with deserts, mountains; small, discontinuous
plains along both coasts
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Qolleh-ye Damavand 5,671 m
Natural resources: petroleum, natural gas, coal,
chromium, copper, iron ore, lead, manganese, zinc,
sulfur
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 27%
forests and woodland: 7%
other: 55% (1993 est.)
Irrigated land: 94,000 sq km (1993 est.)
Natural hazards: periodic droughts, floods; dust
storms, sandstorms; earthquakes along western
border and in the northeast
Environment— current issues: air pollution,
especially in urban areas, from vehicle emissions,
refinery operations, and industrial effluents;
deforestation; overgrazing; desertification; oil pollution in
the Persian Gulf; inadequate supplies of potable water
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection,
Wetlands
signed, but not ratified: Environmental Modification,
Law of the Sea, Marine Life Conservation
Location: Middle East, bordering the Persian Gulf,
between Iran and Kuwait
Geographic coordinates: 33 00 N, 44 00 E
Map references: Middle East
Area:
total: 437,072 sq km
land: 432,162 sq km
water: 4,91 Osq km
Area— comparative: slightly more than twice the
size of Idaho
Land boundaries:
total: 3,631 km
border countries: Iran 1,458 km, Jordan 181 km,
Kuwait 242 km, Saudi Arabia 814 km, Syria 605 km,
Turkey 331 km
Coastline: 58 km
Maritime claims:
continental shelf: not specified
territorial sea: 12 nm
Climate: mostly desert; mild to cool winters with dry,
hot, cloudless summers; northern mountainous
regions along Iranian and Turkish borders experience
cold winters with occasionally heavy snows that melt
in early spring, sometimes causing extensive flooding
in central and southern Iraq
Terrain: mostly broad plains; reedy marshes along
Iranian border in south with large flooded areas;
mountains along borders with Iran and Turkey
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Gundah Zhur 3,608 m
Natural resources: petroleum, natural gas,
phosphates, sulfur
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 0%
other: 79% (1993 est.)
226
Irrigated land: 25,500 sq km (1993 est.)
Natural hazards: dust storms, sandstorms, floods
Environment— current issues: government water
control projects have drained most of the inhabited
marsh areas east of An Nasiriyah by drying up or
diverting the feeder streams and rivers; a once sizable
population of Shi''a Muslims, who have inhabited these
areas for thousands of years, has been displaced;
furthermore, the destruction of the natural habitat
poses serious threats to the area''s wildlife
populations; inadequate supplies of potable water;
development of Tigris-Euphrates Rivers system
contingent upon agreements with upstream riparian
Turkey; air and water pollution; soil degradation
(salinization) and erosion; desertification
Environment— international agreements:
party to: Law of the Sea, Nuclear Test Ban
signed, but not ratified: Environmental Modification
Geographic coordinates: 6 55 N, 158 15 E
Map references: Oceania
Area:
total: 702 sq km
land: 702 sq km
water: 0 sq km
note: includes Pohnpei (Ponape), Truk (Chuuk)
Islands, Yap Islands, and Kosrae
Area-comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 6,112 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; heavy year-round rainfall,
especially in the eastern islands; located on southern
edge of the typhoon belt with occasionally severe
damage
Terrain: islands vary geologically from high
mountainous islands to low, coral atolls; volcanic
outcroppings on Pohnpei, Kosrae, and Truk
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Jo\\o\\om 791 m
Natural resources: forests, marine products,
deep-seabed minerals
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: typhoons (June to December)
Environment— current issues: NA
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography— note: four major island groups totaling
607 islands
Location: Oceania, atoll in the North Pacific Ocean,
about one-third of the way from Honolulu to Tokyo
Geographic coordinates: 28 13 N, 177 22 W
Map references: Oceania
Area:
total: 6.2 sq km
land: 6.2 sq km
water: 0 sq km
note: includes Eastern Island and Sand Island
Area— comparative: about nine times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 15 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but moderated by prevailing
easterly winds
Terrain: low, nearly level
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 4 m
Natural resources: fish, wildlife
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other 100%
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Geography— note: a coral atoll; closed to the public
Location: Eastern Europe, northeast of Romania
Geographic coordinates: 47 00 N, 29 00 E
Map references: Commonwealth of Independent
States
Area:
total: 33,700 sq km
land: 33,700 sq km
water: 0 sq km
Area— comparative: slightly more than twice the
size of Hawaii
Land boundaries:
total: 1 ,389 km
border countries: Romania 450 km, Ukraine 939 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: moderate winters, warm summers
Terrain: rolling steppe, gradual slope south to Black
Sea
Elevation extremes:
lowest point: Nistru River 2 m
highest point: Mount Balaneshty 430 m
Natural resources: lignite, phosphorites, gypsum
Land use:
arable land: 53%
permanent crops: 14%
permanent pastures: 13%
forests and woodland: 13%
other: 7% (1 993 est.)
Irrigated land: 3,1 10 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: heavy use of
agricultural chemicals, including banned pesticides
such as DDT, has contaminated soil and
groundwater; extensive soil erosion from poorfarming
methods
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked','1e519d5a7eb8a6254f768691db6111fb0a591748ad48daf10027eaf9ff50fc6d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fdf3dfa0e707255490a0ef474d0e8efdf50c22e1ada562b2b6b8c45b5101671',1998,'BG','Bulgaria','geography',143,'Location: Southeastern Europe, bordering the Black
Sea, between Romania and Turkey
Geographic coordinates: 43 00 N, 25 00 E
Map references: Europe
Area:
total: 11 0,91 Osq km
land: 110,550 sq km
water: 360 sq km
Area— comparative: slightly larger than Tennessee
Land boundaries:
total: 1 ,808 km
border countries: Greece 494 km, The Former
Yugoslav Republic of Macedonia 148 km, Romania
608 km, Serbia and Montenegro 318 km (all with
Serbia), Turkey 240 km
Coastline: 354 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; cold, damp winters; hot, dry
summers
Terrain: mostly mountains with lowlands in north and
southeast
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Musala 2,925 m
Natural resources: bauxite, copper, lead, zinc, coal,
timber, arable land
Land use:
arable land: 37%
permanent crops: 2%
permanent pastures: 16%
forests and woodland: 35%
other: 10% (1993 est.)
Irrigated land: 12,370 sq km (1993 est.)
Natural hazards: earthquakes, landslides
Environment— current issues: air pollution from
industrial emissions; rivers polluted from raw sewage,
heavy metals, detergents; deforestation; forest
damage from air pollution and resulting acid rain; soil
contamination from heavy metals from metallurgical
plants and industrial wastes
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Sulphur 94,
Antarctic-Environmental Protocol
Geography— note: strategic location near Turkish
Straits; controls key land routes from Europe to Middle
East and Asia
1 People
Population: 8,240,426 (July 1998 est.)
Age structure:
0-14 years: 16% (male 696,131; female 662,335)
15-64 years: 68% (male 2,756,695; female
2,812,192)
65 years and over: 1 6% (male 564,698; female
748,375) (July 1998 est.)
Population growth rate: -0.6% (1998 est.)
Birth rate: 8.08 births/1,000 population (1998 est.)
Death rate: 1 3.24 deaths/1 ,000 population (1 998
est.)
Net migration rate: -0.8 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.75 male(s)/female (1 998 est.)
Infant mortality rate: 12.78 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 71 .96 years
male: 68.39 years
female: 75.74 years (1998 est.)
Total fertility rate: 1.14 children born/woman (1998
est.)
Nationality:
noun: Bulgarian(s)
adjective: Bulgarian
Ethnic groups: Bulgarian 85.3%, Turk 8.5%, Gypsy
2.6%, Macedonian 2.5%, Armenian 0.3%, Russian
0.2%, other 0.6%
Religions: Bulgarian Orthodox 85%, Muslim 13%,
Jewish 0.8%, Roman Catholic 0.5%, Uniate Catholic
0.2%, Protestant, Gregorian-Armenian, and other
0.5%
Languages: Bulgarian, secondary languages
closely correspond to ethnic breakdown
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1992 est.)
Location: Western Africa, north of Ghana
Geographic coordinates: 13 00 N, 2 00 W
Map references: Africa
Area:
total: 274,200 sq km
land: 273,800 sq km
water: 400 sq km
Area— comparative: slightly larger than Colorado
Land boundaries:
total: 3,192 km
border countries: Benin 306 km, Ghana 548 km, Cote
d''Ivoire 584 km, Mali 1 ,000 km, Niger 628 km, Togo
126 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; warm, dry winters; hot, wet
summers
Terrain: mostly flat to dissected, undulating plains;
hills in west and southeast
Elevation extremes:
lowest point: Mouhoun (Black Volta) River 200 m
highest point: Jena Kourou 749 m
Natural resources: manganese, limestone, marble;
small deposits of gold, antimony, copper, nickel,
bauxite, lead, phosphates, zinc, silver
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 22%
forests and woodland: 50%
other: 15% (1993 est.)
Irrigated land: 200 sq km (1993 est.)
Natural hazards: recurring droughts
Environment— current issues: recent droughts
and desertification severely affecting agricultural
activities, population distribution, and the economy;
overgrazing; soil degradation; deforestation
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine Life
Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Nuclear Test
Ban
Geography— note: landlocked
l People
Population: 1 1 ,266,393 (July 1998 est.)
Age structure:
0-14 years: 48% (male 2,721 ,564; female 2,687,770)
15-64 years: 49% (male 2,616,375; female
2,899,923)
65 years and over: 3% (male 146,195; female
194,566) (July 1998 est.)
Population growth rate: 2.72% (1998 est.)
Birth rate: 46.24 births/1,000 population (1998 est.)
Death rate: 1 7.65 deaths/1 ,000 population (1998
est.)
Net migration rate: -1.41 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.75 male(s)/female (1 998 est.)
Infant mortality rate: 109.15 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 46. 1 years
male: 45.38 years
female: 46.85 years (1998 est.)
Total fertility rate: 6.64 children born/woman (1998
est.)
Nationality:
noun: Burkinabe (singular and plural)
adjective: Burkinabe
Ethnic groups: Mossi about 24%, Gurunsi, Senufo,
Lobi, Bobo, Mande, Fulani
Religions: indigenous beliefs 40%, Muslim 50%,
Christian (mainly Roman Catholic) 10%
Languages: French (official), tribal languages
belonging to Sudanic family, spoken by 90% of the
population
Literacy:
definition: age 15 and over can read and write
total population: 19.2%
male: 29.5%
female: 9.2% (1995 est.)
i Government
Country name:
conventional long form: none
conventional short form: Burkina Faso
former: Upper Volta
Data code: UV
Government type: parliamentary
National capital: Ouagadougou
Administrative divisions: 30 provinces; Bam,
Bazega, Bougouriba, Boulgou, Boulkiemde,
Ganzourgou, Gnagna, Gourma, Houe, Kadiogo,
Kenedougou, Komoe, Kossi, Kouritenga, Mouhoun,
73
Burkina Faso (continued)
Namentenga, Naouri, Oubritenga, Oudalan, Passore,
Poni, Sanguie, Sanmatenga, Seno, Sissili, Soum,
Sourou, Tapoa, Yatenga, Zoundweogo
note: there may be a new administrative structure of
45 provinces (Bale, Bam, Banwa, Bazega,
Bougouriba, Boulgou, Boulkiemde, Comoe,
Ganzourgou, Gnagna, Gourma, Houet, loba,
Kadiogo, Kenedougou, Komandjari, Kompienga,
Kossi, Koupelogo, Kouritenga, Kourweogo, Leraba,
Loroum, Mouhoun, Nahouri, Namentenga, Nayala,
Naumbiel, Oubritenga, Oudalan, Passore, Poni,
Samentenga, Sanguie, Seno, Sissili, Soum, Sourou,
Tapoa, Tuy, Yagha, Yatenga, Ziro, Zondomo,
Zoundweogo)
Independence: 5 August 1960 (from France)
National holiday: Anniversary of the Revolution, 4
August (1983)
Constitution: 2 June 1991
Legal system: based on French civil law system and
customary law
Suffrage: universal
Executive branch:
chief of state: President Captain Blaise COMPAORE
(since 15 October 1987)
head of government: Prime Minister Kadre Desire
OUEDRAOGO (since 6 February 1996)
cabinet: Council of Ministers appointed by the
president on the recommendation of the prime
minister
elections: president elected by popular vote for a
seven-year term; the number of terms which a
president may serve is not limited; election last held 1
December 1991 (next to be held NA 1998); prime
minister appointed by the president with the consent
of the legislature
election results: Blaise COMPAORE elected
president with 90.4% percent of the votes of those
who voted (the abstention rate was 74.7%)
Legislative branch: bicameral; consists of a
National Assembly or Assemblee des Deputes
Populaires (ADP) (1 1 1 seats; members are popularly
elected to serve five-year terms) and the purely
consultative Chamber of Representations or Chambre
des Representants (120 seats; members are
appointed to serve three-year terms)
elections: last held 1 1 May 1 997 (next to be held NA
2002)
election results: percent of vote by party— NA; seats
by party— CDP 1 01 , PDP 6, RDA 2, ADF 2
Judicial branch: Supreme Court; Appeals Court
Political parties and leaders: African Democratic
Assembly or RDA [Gerard Kango OUEDRAOGO];
Alliance for Democracy and Federation or ADF
[Herman YAMEOGO]; Burkinabe Bolshevic Party or
PBB; Burkinabe Socialist Party or PSB; Burkinabe
Socialist Bloc or BSB [Earnest Nongma
OUEDRAOGO, president]; Burkinabe
Environmentalist Party or UVDB; Congress for
Democracy and Progress or CDP [Din Salif
SAWADAGO] (the strongest party in the 1997
legislative elections); Front for Social Forces or FFS
[Fide''le KIENTEGA]; Group of Democratic Patriots or
GDP; Movement for Social Tolerance and Progress or
MTP; New Social Democrats or NSD; Open
Revolutionary Party or POR; Organization for
People''s Democracy— Labor Movement or ODP-MT
(ruling party at time of 1 992 elections but was
incorporated, with about a dozen smaller parties, into
the powerful CDP in February 1996); Party for
Democracy and Progress or PDP [Joseph
KI-ZERBO]; Party for Progress and Social
Development or PPDS; Party for African
Independence or PAI
Political pressure groups and leaders: watchdog/
political action groups throughout the country in both
organizations and communities; Burkinabe General
Confederation of Labor or CGTB; National
Confederation of Burkinabe Workers or CNTB;
National Organization of Free Unions or ONSL
International organization participation: ACCT,
ACP, AfDB, CCC, ECA, ECOWAS, Entente, FAO, FZ,
G-77, IBRD, ICAO, ICC, ICFTU, ICRM, IDA, 1DB,
IFAD, IFC, IFRCS, ILO, IMF, Intelsat, Interpol, IOC,
ITU, NAM, OAU, OIC, PCA, UN, UNCTAD, UNESCO,
UNIDO, UPU, WADB, WAEMU, WCL, WFTU, WHO,
WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Bruno Nongoma
ZIDOUEMBA
chancery: 2340 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [1] (202) 332-5577, 6895
Diplomatic representation from the US:
chief of mission: Ambassador Sharon P. WILKINSON
(16 July 1996)
embassy: Avenue Raoul Follerau, Ouagadougou
mailing address: 01 B. P. 35, Ouagadougou
telephone: [226] 306723 through 306726
FAX: [226] 303890
Flag description: two equal horizontal bands of red
(top) and green with a yellow five-pointed star in the
center; uses the popular pan-African colors of','a6582b04d423e40b67bc0d9a36f85626be876449ef60a6ea45ccf53530056de8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c079803c1bc15b6bebd8d29f02a954a9a0814e875f475c3cc7863872610504e5',1998,'ET','Ethiopia','geography',149,'i . Economy
Economy— overview: One of the poorest countries
in the world, landlocked Burkina Faso has a high
population density, few natural resources, and a
fragile soil. Over 80% of the population is engaged in
subsistence agriculture which is highly vulnerable to
variations in rainfall. Industry remains dominated by
unprofitable government-controlled corporations.
Following the African franc currency devaluation in
January 1994 the government updated its
development program in conjunction with international
agencies, and exports and economic growth have
increased.
GDP: purchasing power parity— $10.3 billion (1997
est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity— $950
(1997 est.)
GDP— composition by sector:
agriculture: 32%
industry: 26%
se/v/ces;42%(1995)
Inflation rate— consumer price index: 3% (1996
est.)
Labor force: NA (most adults are employed in
subsistence agriculture)
by occupation: agriculture 80%, industry 15%,
commerce, services, and government 5%
note: 20% of male labor force migrates annually to
neighboring countries for seasonal employment
(1984)
Unemployment rate: NA%
Budget:
revenues: $277 million
expenditures: $ 492 million, including capital
expenditures of $233 million (1995 est.)
Industries: cotton lint, beverages, agricultural
processing, soap, cigarettes, textiles, gold
Industrial production growth rate: 4.2% (1995)
Electricity— capacity: 78,000 kW (1995)
Electricity— production: 220 million kWh (1995)
Electricity— consumption per capita: 21 kWh
(1995)
Agriculture— products: peanuts, shea nuts,
sesame, cotton, sorghum, millet, corn, rice; livestock
Exports:
total value: % 298 million (f.o.b., 1995 est.)
commodities: cotton, animal products, gold
partners: Cote d''Ivoire, France, Italy, Mali
Imports:
total value: $ 500 million (f.o.b., 1995 est.)
commodities: machinery, food products, petroleum
partners: Cote d''Ivoire, France, Togo, Nigeria
Debt— external: $715 million (December 1 996)
Economic aid:
recipient: ODA, $NA
Currency: 1 CommunauteFinanciereAfricaine franc
(CFAF) = 1 00 centimes
Exchange rates: CFA francs (CFAF) per US$1—
608.36 (January 1 998), 583.67 (1 997), 51 1 .55 (1 996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 12 January 1994 the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: calendar year
f Communications
Telephones: 21 ,000 (1 993 est.)
Telephone system: all services only fair
domestic: microwave radio relay, open wire, and
radiotelephone communication stations
international: satellite earth station— 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 32, shortwave
1
Radios: NA
Television broadcast stations: 3 (1997)
Televisions: 49,000(1991 est.)
74','5c1b7fe5d03f73bf4903f9eedb0704cfb61ebd15dfb1633bf1708ead44e49bb1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9e87e065d1503c830b318c98a9802b359eecab65e4398050af761cc21e89f94',1998,'BI','Burundi','geography',161,'Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 3 30 S, 30 00 E
Map references: Africa
Area:
total: 27,830 sq km
land: 25,650 sq km
water: 2,180 sq km
Area— comparative: slightly smaller than Maryland
Land boundaries:
total: 974 km
border countries: Democratic Republic of the Congo
233 km, Rwanda 290 km, Tanzania 451 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: equatorial; high plateau with considerable
altitude variation (772 m to 2,760 m); average annual
temperature varies with altitude from 23 to 17 degrees
centigrade but is generally moderate as the average
altitude is about 1 ,700 m; average annual rainfall is
about 1 50 cm; wet seasons from February to May and
September to November, and dry seasons from June
to August and December to January
Terrain: hilly and mountainous, dropping to a plateau
in east, some plains
77
Burundi (continued)
Elevation extremes:
lowest point: Lake Tanganyika 772 m
highest point: Mount Heha 2,760 m
Natural resources: nickel, uranium, rare earth
oxides, peat, cobalt, copper, platinum (not yet
exploited), vanadium
Land use:
arable land: 44%
permanent crops: 9%
permanent pastures: 36%
forests and woodland: 3%
other: 8% (1993 est.)
Irrigated land: 140 sq km (1993 est.)
Natural hazards: flooding, landslides
Environment— current issues: soil erosion as a
result of overgrazing and the expansion of agriculture
into marginal lands; deforestation (little forested land
remains because of uncontrolled cutting of trees for
fuel); habitat loss threatens wildlife populations
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea, Nuclear Test
Ban
Geography— note: landlocked; straddles crest of
the Nile-Congo watershed','040eb66f6f350dc7be064dbe5c22bf21f6450227e8e54dd600375cdc2d3f9725','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b33459bd42a815f0ca50093fb53cd847827ef390854f3934187842f310e9489b',1998,'CA','Canada','geography',177,'Location: Northern North America, bordering the
North Atlantic Ocean and North Pacific Ocean, north
of the conterminous US
Geographic coordinates: 60 00 N, 95 00 W
Map references: North America
Area:
total: 9,976,140 sq km
land: 9,220,970 sq km
water: 755,1 70 sq km
Area— comparative: slightly larger than US
Land boundaries:
total: 8,893 km
border countries: US 8,893 km (includes 2,477 km
with Alaska)
Coastline: 243,791 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive fishing zone : 200 nm
territorial sea: 12 nm
Climate: varies from temperate in south to subarctic
and arctic in north
Terrain: mostly plains with mountains in west and
lowlands in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Logan 5,950 m
Natural resources: nickel, zinc, copper, gold, lead,
molybdenum, potash, silver, fish, timber, wildlife, coal,
petroleum, natural gas
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 54%
other: 38% (1 993 est.)
Irrigated land: 7,100 sq km (1993 est.)
Natural hazards: continuous permafrost in north is a
serious obstacle to development; cyclonic storms
form east of the Rocky Mountains, a result of the
mixing of air masses from the Arctic, Pacific, and
North American interior, and produce most of the
country''s rain and snow
Environment— current issues: air pollution and
resulting acid rain severely affecting lakes and
damaging forests; metal smelting, coal-burning
utilities, and vehicle emissions impacting on
agricultural and forest productivity; ocean waters
becoming contaminated due to agricultural, industrial,
mining, and forestry activities
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol, Law
of the Sea, Marine Life Conservation
Geography— note: second-largest country in world
(after Russia); strategic location between Russia and
US via north polar route; nearly 90% of the population
is concentrated within 160 km of the US/Canada
border','32a412084196388a31de580f34e9ed44f39cebb026ac078312f3b62c78d77929','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a21de1f76ba115cc3dc002cbfdccbfe3622a71ee2835d074362422c50a5a0afd',1998,'KY','Cayman Islands','geography',191,'Location: Caribbean, island group in Caribbean
Sea, nearly one-half of the way from Cuba to','fc114d802a849a7294887b6edc1f1c5585b1ebfba7a48cc3646af94203925924','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('727613e87b928a3ee00dd018e122422d494e66efe6d37d386b9a2170898c5edd',1998,'HN','Honduras','geography',192,'Geographic coordinates: 1 9 30 N, 80 30 W
Map references: Central America and the
Caribbean
Area:
total: 260 sq km
land: 260 sq km
water: 0 sq km
Area— comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; warm, rainy summers (May
to October) and cool, relatively dry winters (November
to April)
Terrain: low-lying limestone base surrounded by
coral reefs
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: The Bluff 43 m
Natural resources: fish, climate and beaches that
foster tourism
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 23%
other: 69% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: hurricanes (July to November)
Environment— current issues: no natural fresh
water resources, drinking water supplies must be met
by rainwater catchment
88
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: important location between
Cuba and Central America
Location: Central Africa, north of Democratic
Republic of the Congo
Geographic coordinates: 7 00 N, 21 00 E
Map references: Africa
Area:
total: 622,980 sq km
land: 622,980 sq km
water: Osq km
Area— comparative: slightly smaller than Texas
Land boundaries:
total: 5,203 km
border countries: Cameroon 797 km, Chad 1 ,1 97 km,
Democratic Republic of the Congo 1 ,577 km,
Republic of the Congo 467 km, Sudan 1,165 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; hot, dry winters; mild to hot, wet
summers
Terrain: vast, flat to rolling, monotonous plateau;
scattered hills in northeast and southwest
Elevation extremes:
lowest point: Oubangui River 335 m
highest point: Mount Gaou 1 ,420 m
Natural resources: diamonds, uranium, timber,
gold, oil
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 75%
other: 17% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hot, dry, dusty harmattan winds
affect northern areas; floods are common
Environment— current issues: tap water is not
potable; poaching has diminished its reputation as
one of the last great wildlife refuges; desertification;
deforestation
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Nuclear Test
Ban, Ozone Layer Protection, Tropical Timber 94
signed, but not ratified: Law of the Sea
Geography— note: landlocked; almost the precise
center of Africa
Location: Middle America, bordering the Caribbean
Sea, between Guatemala and Nicaragua and
bordering the North Pacific Ocean, between
El Salvador and Nicaragua
Geographic coordinates: 1 5 00 N, 86 30 W
Map references: Central America and the
Caribbean
Area:
total: 11 2,090 sq km
land: 1 1 1 ,890 sq km
water: 200 sq km
Area— comparative: slightly larger than Tennessee
Land boundaries:
total: 1,520 km
border countries: Guatemala 256 km, El Salvador 342
km, Nicaragua 922 km
Coastline: 820 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: natural extension of territory or to
200 nm
exclusive economic zone: 200 nm
territorial sea : 12 nm
Climate: subtropical in lowlands, temperate in
mountains
Terrain: mostly mountains in interior, narrow coastal
plains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro Las Minas 2,870 m
Natural resources: timber, gold, silver, copper,
lead, zinc, iron ore, antimony, coal, fish
Land use:
arable land: 15%
permanent crops: 3%
permanent pastures: 1 4%
forests and woodland: 54%
other: 14% (1993 est.)
Irrigated land: 740 sq km (1993 est.)
Natural hazards: frequent, but generally mild,
earthquakes; damaging hurricanes and floods along
Caribbean coast
Environment— current issues: urban population
expanding; deforestation results from logging and the
clearing of land for agricultural purposes; further land
degradation and soil erosion hastened by
uncontrolled development and improper land use
practices such as farming of marginal lands; mining
activities polluting Lago de Yojoa (the country''s
largest source of fresh water) as well as several rivers
and streams with heavy metals
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Location: Eastern Asia, bordering the South China
Sea and China
Geographic coordinates: 22 15 N, 114 10 E
Map references: Southeast Asia
Area:
total: 1,092 sq km
land: 1,042 sq km
water: 50 sq km
Area— comparative: six times the size of
Washington, DC
Land boundaries:
total: 30 km
border countries: China 30 km
Coastline: 733 km
Maritime claims:
territorial sea: 3nm
Climate: tropical monsoon; cool and humid in winter,
hot and rainy from spring through summer, warm and
sunny in fall
Terrain: hilly to mountainous with steep slopes;
lowlands in north
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Tai Mo Shan 958 m
Natural resources: outstanding deepwater harbor,
feldspar
Land use:
arable land: 6%
permanent crops: 1%
permanent pastures: 1%
forests and woodland: 22%
of/?er; 70% (1 993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: occasional typhoons
Environment— current issues: air and water
pollution from rapid urbanization
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: more than 200 islands
Location: Oceania, island in the North Pacific
Ocean, about one-half of the way from Hawaii to
Location: Western Africa, southeast of Algeria
Geographic coordinates: 16 00 N, 8 00 E
Map references: Africa
Area:
total: 1.267 million sq km
land: 1 ,266,700 sq km
water: 300 sq km
Area-comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,697 km
border countries: Algeria 956 km, Benin 266 km,
Burkina Faso 628 km, Chad 1 ,175 km, Libya 354 km,
Mali 821 km, Nigeria 1,497 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; mostly hot, dry, dusty; tropical in
extreme south
Terrain: predominately desert plains and sand
dunes; flat to rolling plains in south; hills in north
Elevation extremes:
lowest point: Niger River 200 m
highest point: Mont Greboun 1 ,944 m
Natural resources: uranium, coal, iron ore, tin,
phosphates, gold, petroleum
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 7%
forests and woodland: 2%
other: 88% (1993 est.)
Irrigated land: 660 sq km (1993 est.)
Natural hazards: recurring droughts
Environment— current issues: overgrazing; soil
erosion; deforestation; desertification; wildlife
populations (such as elephant, hippopotamus, giraffe,
and lion) threatened because of poaching and habitat
destruction
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Nuclear Test Ban, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography— note: landlocked','3f046aec0707c35c5fb18092f27c8dcacdc354e136125f851db6f195603d78e9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31866e95b35d4cb752d69386b2dd760634e8db75c45efde14ff0bc5e61af0ad7',1998,'TD','Chad','geography',201,'Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N, 19 00 E
Map references: Africa
Area:
total: 1 .284 million sq km
land: 1,259,200 sq km
water; 24,800 sq km
Area— comparative: slightly more than three times
the size of California
Land boundaries:
total: 5,968 km
border countries: Cameroon 1,094 km, Central
African Republic 1,197 km, Libya 1,055 km, Niger
1 ,1 75 km, Nigeria 87 km, Sudan 1 ,360 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center, desert in north,
mountains in northwest, lowlands in south
Elevation extremes:
lowest point: Djourab Depression 175 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum (unexploited but
exploration underway), uranium, natron, kaolin, fish
(Lake Chad)
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 36%
forests and woodland: 26%
other: 35% (1 993 est.)
Irrigated land: 140 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan winds
occur in north; periodic droughts; locust plagues
Environment— current issues: inadequate
supplies of potable water; improper waste disposal in
rural areas contributes to soil and water pollution;
desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Nuclear Test
Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Marine
Dumping
Geography— note: landlocked; Lake Chad is the
most significant water body in the Sahel','daea1dfbb53973cbf04cdf2070d2ce08800ebc4e91921e9c665f1f36f578281a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25066cf93932f46f95a49e414c13b2fddc2aa413fab1d0e92649d17c4486b969',1998,'CN','China','geography',215,'Location: Eastern Asia, bordering the East China
Sea, Korea Bay, Yellow Sea, and South China Sea,
between North Korea and Vietnam
Geographic coordinates: 35 00 N, 105 00 E
Map references: Asia
Area:
total: 9,596,960 sq km
land: 9,326,41 Osq km
water: 270,550 sq km
Area— comparative: slightly smaller than the US
Land boundaries:
total: 22,143.34 km
border countries: Afghanistan 76 km, Bhutan 470 km,
Burma 2,185 km, Hong Kong 30 km, India 3,380 km,
Kazakhstan 1,533 km, North Korea 1,416 km,
Kyrgyzstan 858 km, Laos 423 km, Macau 0.34 km,
Mongolia 4,673 km, Nepal 1,236 km, Pakistan 523
km, Russia (northeast) 3,605 km, Russia (northwest)
40 km, Tajikistan 414 km, Vietnam 1,281 km
Coastline: 14,500 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: claim to shallow areas of East China
Sea and Yellow Sea
territorial sea: 12 nm
Climate: extremely diverse; tropical in south to
subarctic in north
Terrain: mostly mountains, high plateaus, deserts in
west; plains, deltas, and hills in east
Elevation extremes:
lowest point: Turpan Pendi -154 m
highest point: Mount Everest 8,848 m
Natural resources: coal, iron ore, petroleum,
mercury, tin, tungsten, antimony, manganese,
molybdenum, vanadium, magnetite, aluminum, lead,
zinc, uranium, hydropower potential (world''s largest)
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 43%
forests and woodland: 14%
other: 33% (1993 est.)
Irrigated land: 498,720 sq km (1993 est.)
Natural hazards: frequent typhoons (about five per
year along southern and eastern coasts); damaging
floods; tsunamis; earthquakes; droughts
Environment— current issues: air pollution
(greenhouse gases, particulates) from the
overwhelming use of high-sulfur coal as a fuel,
produces acid rain which is damaging forests; water
shortages experienced throughout the country,
particularly in urban areas and in the north; future
growth in water usage threatens to outpace supplies;
water pollution from industrial effluents; much of the
population does not have access to potable water;
less than 10% of sewage receives treatment;
deforestation; estimated loss of one-fifth of
agricultural land since 1949 to soil erosion and
economic development; desertification; trade in
endangered species
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed , but not ratified: none of the selected
agreements
Geography— note: world''s fourth-largest country
(after Russia, Canada, and US)
Location: Southeastern Asia, group of reefs and
islands in the South China Sea, about two-thirds of the
way from southern Vietnam to the southern','de006118509a8de0fae55544166682bc01a939ef38bc26c5198afc5712c5162c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fef2f5e0b144f49dbff7bcc79a1eb0b49205dfe1e0552151bf0c189e31b7e01e',1998,'CX','Christmas Island','geography',223,'Location: Southeastern Asia, island in the Indian
Ocean, south of Indonesia
Geographic coordinates: 10 30 S, 105 40 E
Map references: Southeast Asia
Area:
total: 135 sq km
land: 135 sq km
water: Osq km
Area— comparative: about 0.7 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 138.9 km
Maritime claims:
contiguous zone: 12 nm
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical; heat and humidity moderated by
trade winds
Terrain: steep cliffs along coast rise abruptly to
central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Murray Hill 361 m
Natural resources: phosphate
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified : N A
Geography— note: located along major sea lanes of
Indian Ocean','f27d1a0e47d19dc4a53686fa91149c28e80cc790562b57cd3ad519dd8c197532','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9470d13d13cfc4fc5481e41d77282c9930b6d1362cdb29694bb861b5ba472f6d',1998,'AU','Australia','geography',230,'Location: Middle America, atoll in the North Pacific
Ocean, 1 ,120 km southwest of Mexico
Geographic coordinates: 10 17 N, 109 13 W
Map references: World
Area:
total: 7 sq km
land: 7 sq km
water: 0 sq km
Area— comparative: about 12 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 11.1 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, humid, average temperature 20-32
degrees C, rains May-October
Terrain: coral atoll
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Rocher Clipperton 29 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all coral)
Irrigated land: 0 sq km (1993)
Natural hazards: subject to tornadoes
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Geography— note: reef about 8 km in circumference
Location: Oceania, islands in the Coral Sea,
northeast of Australia
Geographic coordinates: 18 00 S, 152 00 E
Map references: Oceania
Area:
total: less than 3 sq km
land: less than 3 sq km
water: 0 sq km
note: includes numerous small islands and reefs
scattered over a sea area of about 1 million sq km,
with the Willis Islets the most important
Area— comparative: NA
Land boundaries: 0 km
Coastline: 3,095 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical
Terrain: sand and coral reefs and islands (or cays)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Cato Island 6 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures : 0%
forests and woodland: 0%
other: 100% (mostly grass or scrub cover)
Irrigated land: 0 sq km (1993)
Natural hazards: occasional, tropical cyclones
Environment— current issues: no permanent fresh
water resources
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: important nesting area for birds
and turtles
113
Coral Sea Islands (continued)
Geographic coordinates: 0 48 N, 176 38 W
Map references: Oceania
Area:
total: 1 .6 sq km
land: 1 .6 sq km
water: 0 sq km
Area— comparative: about three times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 6.4 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: equatorial; scant rainfall, constant wind,
burning sun
Terrain: low-lying, nearly level, sandy, coral island
surrounded by a narrow fringing reef; depressed
central area
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 3 m
Natural resources: guano (deposits worked until
late 1800s)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 5%
other: 95%
Irrigated land: 0sqkm(1993)
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment— current issues: no natural fresh
water resources
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: almost totally covered with
grasses, prostrate vines, and low-growing shrubs;
small area of trees in the center; primarily a nesting,
roosting, and foraging habitat for seabirds, shorebirds,
and marine wildlife; feral cats
Location: Oceania, islands in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
the Philippines
Geographic coordinates: 15 12 N, 145 45 E
Map references: Oceania
Area:
total: 477 sq km
land: 477 sq km
water: 0 sq km
note: includes 14 islands including Saipan, Rota, and
Tinian
Area— comparative: 2.5 times the size of
Washington, DC
Land boundaries: Okm
Coastline: 1,482 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; moderated by northeast
trade winds, little seasonal temperature variation; dry
season December to June, rainy season July to
October
Terrain: southern islands are limestone with level
terraces and fringing coral reefs; northern islands are
volcanic
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Agrihan 965 m
Natural resources: arable land, fish
Land use:
arable land: 21%
permanent crops: N A%
permanent pastures: 1 9%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: active volcanoes on Pagan and
Agrihan; typhoons (especially August to November)
Environment— current issues: contamination of
groundwater on Saipan may contribute to disease;
clean-up of landfill; protection of endangered species
conflicts with development
Environment— international agreements:
party to: N A
signed, but not ratified: NA
Geography— note: strategic location in the North
Pacific Ocean','51bd6ac0ce4ec45e2a1aac799ffdc0c1eada09aa9c6ff7b1628b339f3295af1a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73c065e2cb28cab9878c5f0480e45cb46dbfa749fe52d774e6105d7e12e10536',1998,'CO','Colombia','geography',236,'Location: Northern South America, bordering the
Caribbean Sea, between Panama and Venezuela,
and bordering the North Pacific Ocean, between
Ecuador and Panama
Geographic coordinates: 4 00 N, 72 00 W
Map references: South America, Central America
and the Caribbean
Area:
total: 1,138,910 sq km
land: 1,038,700 sq km
water: 1 00,21 Osq km
note: includes Isla de Malpelo, Roncador Cay,
Serrana Bank, and Serranilla Bank
Area— comparative: slightly less than three times
the size of Montana
Land boundaries:
total: 7,408 km
border countries: Brazil 1 ,643 km, Ecuador 590 km,
Panama 225 km, Peru 2,900 km, Venezuela 2,050 km
Coastline: 3,208 km (Caribbean Sea 1,760 km,
North Pacific Ocean 1 ,448 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical along coast and eastern plains;
cooler in highlands
Terrain: flat coastal lowlands, central highlands, high
Andes Mountains, eastern lowland plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado del Huila 5,750 m
Natural resources: petroleum, natural gas, coal,
iron ore, nickel, gold, copper, emeralds
Land use:
arable land: 4%
permanent crops: 1 %
permanent pastures: 39%
forests and woodland: 48%
other: 8% (1993 est.)
Irrigated land: 5,300 sq km (1993 est.)
Natural hazards: highlands subject to volcanic
eruptions; occasional earthquakes; periodic droughts
Environment— current issues: deforestation; soil
damage from overuse of pesticides; air pollution,
especially in Bogota, from vehicle emissions
Environment— international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Hazardous Wastes,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: Antarctic-Environmental
Protocol, Desertification, Law of the Sea, Marine
Dumping
Geography— note: only South American country
with coastlines on both North Pacific Ocean and
Caribbean Sea','bcf1d91507c98a96cdfe3307c4c3339f00bacc314fe694bb8563d510da2e878d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bb2dbab05cee25caa30e9280f3b5324b0c3b36d4ff55e4239fa5cb2b641420a',1998,'MZ','Mozambique','geography',246,'Location: Southern Africa, group of islands in the
Mozambique Channel, about two-thirds of the way
between northern Madagascar and northern
Geographic coordinates: 12 10 S, 44 15 E
Map references: Africa
Area:
total: 2,170 sq km
land: 2,170 sq km
water: Osq km
Area— comparative: slightly more than 1 2 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 340 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; rainy season (November to
May)
Terrain: volcanic islands, interiors vary from steep
mountains to low hills
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mount Kartala 2,360 m
Natural resources: NEGL
105
Comoros (continued)
Land use:
arable land: 35%
permanent crops: 10%
permanent pastures: 7%
forests and woodland: 1 8%
other: 30% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: cyclones possible during rainy
season (December to April); Mount Kartala on Grand
Comore is an active volcano
Environment— current issues: soil degradation
and erosion results from crop cultivation on slopes
without proper terracing; deforestation
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography— note: important location at northern
end of Mozambique Channel
Location: Central Africa, northeast of Angola
Geographic coordinates: 0 00 N, 25 00 E
Map references: Africa
Area:
tote/: 2,345,41 0 sq km
land: 2,267,600 sq km
water: 77,81 Osq km
Area— comparative: slightly less than one-fourth
the size of US
Land boundaries:
total: 10,271 km
border countries: Angola 2,51 1 km, Burundi 233 km,
Central African Republic 1 ,577 km, Republic of the
Congo 2,410 km, Rwanda 217 km, Sudan 628 km,
Uganda 765 km, Zambia 1 ,930 km
Coastline: 37 km
Maritime claims:
exclusive economic zone: boundaries with neighbors
territorial sea: 1 2 nm
Climate: tropical; hot and humid in equatorial river
basin; cooler and drier in southern highlands; cooler
and wetter in eastern highlands; north of Equator-
wet season April to October, dry season December to
February; south of Equator— wet season November to
March, dry season April to October
Terrain: vast central basin is a low-lying plateau;
mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Margherita Peak (Mount Stanley) 5,1 1 0 m
Natural resources: cobalt, copper, cadmium,
petroleum, industrial and gem diamonds, gold, silver,
zinc, manganese, tin, germanium, uranium, radium,
bauxite, iron ore, coal, hydropower potential, timber
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 7%
107
Congo, Democratic Republic of the (continued)
forests and woodland: 77%
other: 13% (1993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: periodic droughts in south;
volcanic activity
Environment— current issues: poaching threatens
wildlife populations; water pollution; deforestation;
refugees who arrived in mid-1994 were responsible
for significant deforestation, soil erosion, and wildlife
poaching in the eastern part of the country (most of
those refugees were repatriated in November and
December 1996)
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands
signed [ but not ratified: Environmental Modification
Geography— note: straddles Equator; very narrow
strip of land that controls the lower Congo river and is
only outlet to South Atlantic Ocean; dense tropical rain
forest in central river basin and eastern highlands','a01f81b1d15652e98b00fc0c552468cedea9939b94e00c8efabe6dc4deabc291','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecc1ae41a4ee3bbd7cd52e621b2228e31d37d2c044eabad411f94560b963963d',1998,'CG','Congo','geography',259,'Location: Western Africa, bordering the South
Atlantic Ocean, between Angola and Gabon
Geographic coordinates: 1 00 S, 15 00 E
Map references: Africa
Area:
total: 342,000 sq km
land: 341 ,500 sq km
water: 500 sq km
Area— comparative: slightly smaller than Montana
Land boundaries:
total: 5,504 km
border countries: Angola 201 km, Cameroon 523 km,
Central African Republic 467 km, Democratic
Republic of the Congo 2,41 0 km, Gabon 1 ,903 km
Coastline: 169 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; rainy season (March to June); dry
season (June to October); constantly high
temperatures and humidity; particularly enervating
climate astride the Equator
Terrain: coastal plain, southern basin, central
plateau, northern basin
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Berongou 903 m
Natural resources: petroleum, timber, potash, lead,
zinc, uranium, copper, phosphates, natural gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 29%
forests and woodland: 62%
other: 9% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: seasonal flooding
Environment— current issues: air pollution from
vehicle emissions; water pollution from the dumping of
raw sewage; tap water is not potable; deforestation
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Ozone Layer Protection, T ropical Timber 83,
Tropical Timber 94
signed, but not ratified: Desertification, Law of the
Sea
Geography— note: about 70% of the population
lives in Brazzaville, Pointe Noire, or along the railroad
between them','a7fc2057f211543bb2b4bbca4427a9ce60b837a3d4f11e896ab4eb889391f80a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd79e9a8300e83442bca25b5e464661a27d51b9a8c82dd32b8d8dbad374c20c0',1998,'CK','Cook Islands','geography',262,'Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 21 14 S, 159 46 W
Map references: Oceania
Area:
total : 240 sq km
land: 240 sq km
water: 0 sq km
Area— comparative: 1 .3 times the size of
Washington, DC
Land boundaries: Okm
Coastline: 120 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds
Terrain: low coral atolls in north; volcanic, hilly
islands in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Te Manga 652 m
Natural resources: NEGL
Land use:
arable land: 9%
permanent crops: 13%
permanent pastures: N A%
forests and woodland: NA%
of/?er: 78% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons (November to March)
Environment— current issues: NA
Environment— international agreements:
party to: Biodiversity, Climate Change, Law of the Sea
signed, but not ratified: NA
Geographic coordinates: 0 22 S, 1 60 03 W
Map references: Oceania
Area:
total: 4.5 sq km
land: 4.5 sq km
water: 0 sq km
Area— comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical; scant rainfall, constant wind,
burning sun
Terrain: sandy, coral island surrounded by a narrow
fringing reef
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 23 m
Natural resources: guano (deposits worked until
late 1800s)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 1 00%
Irrigated land: 0sqkm(1993)
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment— current issues: no natural fresh
water resources
Environment— international agreements:
party to: NA
signed, but not ratified: NA
241
Jarvis Island (continued)
Geography— note: sparse bunch grass, prostrate
vines, and low-growing shrubs; primarily a nesting,
roosting, and foraging habitat for seabirds, shorebirds,
and marine wildlife; feral cats','62203a2705171f435f46713d3a0a4bec50185329df71a75d3f3f06b117180e57','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c71ce7afe4016c43e1132729376824c51d4f91dc0e1b33f0e3b5afdfd16cab62',1998,'DE','Germany','geography',279,'Location: Western Africa, bordering the North
Atlantic Ocean, between Ghana and Liberia
Geographic coordinates: 8 00 N, 5 00 W
Map references: Africa
Area:
total: 322,460 sq km
land: 31 8,000 sq km
water: 4,460 sq km
Area— comparative: slightly larger than New
Location: Middle East, bordering the Mediterranean
Sea, between Egypt and Israel
Geographic coordinates: 31 25 N, 34 20 E
Map references: Middle East
Area:
total: 360 sq km
land: 360 sq km
water: Osq km
Area— comparative: slightly more than twice the
size of Washington, DC
Land boundaries:
total: 62 km
border countries: Egypt 1 1 km, Israel 51 km
Coastline: 40 km
Maritime claims: Israeli-occupied with current
status subject to the Israeli-Palestinian Interim
Agreement— permanent status to be determined
through further negotiation
Climate: temperate, mild winters, dry and warm to
hot summers
Terrain: flat to rolling, sand- and dune-covered
coastal plain
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Abu ''Awdah (Joz Abu ''Auda) 105 m
Natural resources: NEGL
Land use:
arable land: 24%
permanent crops: 39%
permanent pastures: 0%
forests and woodland: 1 1 %
other: 26% (1993 est.)
Irrigated land: 120 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: desertification;
salination of fresh water; sewage treatment
Environment— international agreements:
party to: none of the selected agreements
signed [ but not ratified: none of the selected
agreements
Geography— note: there are 24 Israeli settlements
and civilian land use sites in the Gaza Strip (August
1997 est.)
f People
Population: 1,054,173 (July 1998 est.)
note : in addition, there are 6,000 Israeli settlers in the
Gaza Strip (August 1997 est.)
Age structure:
0-14 years: 52% (male 278,551 ; female 265,009)
15-64 years: 46% (male 241 ,420; female 238,857)
65 years and over: 2% (male 1 2,966; female 1 7,370)
(July 1998 est.)
Population growth rate: 6.4% (1998 est.)
Birth rate: 49.07 births/1,000 population (1998 est.)
Death rate: 4 deaths/1 ,000 population (1998 est.)
Net migration rate: 1 8.97 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.75 male(s)/female (1 998 est.)
Infant mortality rate: 24.45 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 72.95 years
male: 71.56 years
female : 74.4 years (1 998 est.)
Total fertility rate: 7.57 children born/woman (1998
est.)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 99.4%,
Jewish 0.6%
Religions: Muslim (predominantly Sunni) 98.7%,
Christian 0.7%, Jewish 0.6%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy: NA
r Government
Country name:
conventional long form: none
conventional short form: Gaza Strip
local long form: none
local short form: Qita Ghazzah
Data code: GZ
c Economy
Economy— overview: Economic progress in the
Gaza Strip has been hampered by tight Israeli security
restrictions. In 1991 roughly 40% of Gaza Strip
workers were employed across the border by Israeli
industrial, construction, and agricultural enterprises,
with worker remittances supplementing GDP by
roughly 50%. Gaza has depended upon Israel for
nearly 90% of its external trade. The Persian Gulf
crisis and its aftershocks have dealt blows to Gaza
since August 1990. Worker remittances from the Gulf
states have dropped, unemployment and popular
unrest have increased, and living standards have
fallen. The redeployment of Israeli forces in the Gaza
Strip in May 1 994 has added to the set of adjustment
problems. This series of disruptions has meant a
sharp decline in employment in Israel since 1991 and
a drop in GDP as a whole. An estimated 378,000
persons were in refugee camps in 1996.
GDP: purchasing power parity— $1 billion (1 996 est.)
GDP— real growth rate: -6.9% (1996 est.)
GDP— per capita: purchasing power parity— $1,100
(1996 est.)
GDP— composition by sector:
agriculture: 33%
industry: 25%
services: 42% (1995 est., includes West Bank)
Inflation rate— consumer price index: 8.4% (1996
est.)
Labor force: NA
by occupation: services 66%, industry 21 %,
agriculture 13% (1996)
note: excluding Israeli settlers
Unemployment rate: 28% (1997 est.)
Budget:
revenues: $684 million
expenditures: $779 million, including capital
expenditures of $NA (1 996)
note: includes West Bank
Industries: generally small family businesses that
produce textiles, soap, olive-wood carvings, and
mother-of-pearl souvenirs; the Israelis have
established some small-scale modern industries in an
industrial center
174
Industrial production growth rate: NA%
Electricity— capacity: NA kW
note: electricity supplied by Israel
Electricity— production: NA kWh
note: electricity supplied by Israel
Electricity— consumption per capita: NA kWh
Agriculture— products: olives, citrus, other fruits,
vegetables; beef, dairy products
Exports:
total value: $630 million (f.o.b., 1997 est.) (includes
West Bank)
commodities: citrus
partners: Israel, Egypt, West Bank
Imports:
total value: $1 .7 billion (c.i.f., 1997 est.) (includes
West Bank)
commodities: food, consumer goods, construction
materials
partners: Israel, Egypt, West Bank
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
Currency: 1 new Israeli shekel (NIS) = 100 new
agorot
Exchange rates: new Israeli shekels (NIS) per
US$1— 3.5340 (December 1997), 3.4494 3.1917
(1996), 3.01 13 (1995), 3.0111 (1994), 2.8301 (1993)
Fiscal year: calendar year (since 1 January 1992)
i Communications
Telephones: NA
note: 3.1% of Palestinian households have
telephones
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM 0,
shortwave 0
Radios: NA; note— 95% of Palestinian households
have radios (1992 est.)
Television broadcast stations: 1 station operated
by the Palestinian Authority
Televisions: NA; note— 59% of Palestinian
households have televisions (1992 est.)
f Transportation
Railways:
total: NA km; note— one line, abandoned and in
disrepair, little trackage remains
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: small, poorly developed road network
Ports and harbors: Gaza
Airports: 2 (1997 est.)
note: includes new international airport that was
scheduled to open in June 1997, but has been
delayed due to political and security disagreements
between Palestinian and Israeli negotiators
Airports— with paved runways:
total: 1
over 3,047 m: 1 (1997 est.)
Airports— with unpaved runways:
total: 1
under 914 m:1 (1997 est.)
K Military
Military branches: NA
Military expenditures— dollar figure: $NA
Military expenditures— percent of GDP: NA%
Location: Central Europe, bordering the Baltic Sea
and the North Sea, between the Netherlands and
Poland, south of Denmark
Geographic coordinates: 51 00 N, 9 00 E
Map references: Europe
Area:
total: 356,91 Osq km
land: 349,520 sq km
water: 7,390 sq km
note: includes the formerly separate Federal Republic
of Germany, the German Democratic Republic, and
Berlin, following formal unification on 3 October 1990
Area— comparative: slightly smaller than Montana
Land boundaries:
total: 3,621 km
border countries: Austria 784 km, Belgium 167 km,
Czech Republic 646 km, Denmark 68 km, France 451
km, Luxembourg 138 km, Netherlands 577 km,
Poland 456 km, Switzerland 334 km
Coastline: 2,389 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate and marine; cool, cloudy, wet
winters and summers; occasional warm, tropical
foehn wind; high relative humidity
Terrain: lowlands in north, uplands in center,
Bavarian Alps in south
Elevation extremes:
lowest point: Freepsum Lake -2 m
highest point: Zugspitze 2,962 m
Natural resources: iron ore, coal, potash, timber,
lignite, uranium, copper, natural gas, salt, nickel
Land use:
arable land: 33%
permanent crops: 1%
permanent pastures: 1 5%
178
forests and woodland: 31 %
of/7er: 20% (1 993 est.)
Irrigated land: 4,750 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: emissions from
coal-burning utilities and industries and lead
emissions from vehicle exhausts (the result of
continued use of leaded fuels) contribute to air
pollution; acid rain, resulting from sulfur dioxide
emissions, is damaging forests; heavy pollution in the
Baltic Sea from raw sewage and industrial effluents
from rivers in eastern Germany; hazardous waste
disposal
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Sulphur 94
Geography— note: strategic location on North
European Plain and along the entrance to the Baltic
Sea
Geographic coordinates: 49 45 N, 6 10 E
Map references: Europe
Area:
total: 2,586 sq km
land: 2,586 sq km
water: 0 sq km
Area— comparative: slightly smaller than Rhode
Island
Land boundaries:
total: 359 km
border countries: Belgium 148 km, France 73 km,
Germany 138 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: modified continental with mild winters, coo!
summers
Terrain: mostly gently rolling uplands with broad,
shallow valleys; uplands to slightly mountainous in the
north; steep slope down to Moselle floodplain in the
southeast
Elevation extremes:
lowest point: Moselle River 133 m
highest point: Burgplatz 559 m
Natural resources: iron ore (no longer exploited)
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 20%
forests and woodland: 21 %
other: 34%
Irrigated land: NA sq km
Natural hazards: NA
Environment— current issues: air and water
pollution in urban areas
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Environmental Modification,
Law of the Sea
Geography— note: landlocked
Location: Western Europe, bordering the
Mediterranean Sea, on the southern coast of France,
near the border with Italy
Geographic coordinates: 43 44 N, 7 24 E
Map references: Europe
Area:
total: 1.95 sq km
land: 1.95 sq km
water: 0 sq km
Area— comparative: about three times the size of
The Mall in Washington, DC
Land boundaries:
total: 4.4 km
border countries: France 4.4 km
Coastline: 4.1 km
Maritime claims:
territorial sea: 12 nm
Climate: Mediterranean with mild, wet winters and
hot, dry summers
Terrain: hilly, rugged, rocky
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Agel 140 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (urban area)
Irrigated land: NAsqkm
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: none of the selected
agreements
317
Monaco (continued)
Geography— note: second smallest independent
state in world (after Holy See); almost entirely urban','a3320e91f7bc740873705656cef2c8fd48c8061ec077aa8e2f67aa12bb9a09c3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1f9056434de9c297eccce4b243c051e14afac9d7ad99cb0429b7791aade0703',1998,'MX','Mexico','geography',280,'Land boundaries:
total: 3,110 km
border countries: Burkina Faso 584 km, Ghana 668
km, Guinea 610 km, Liberia 716 km, Mali 532 km
Coastline: 515 km
Maritime claims:
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical along coast, semiarid in far north;
three seasons— warm and dry (November to March),
hot and dry (March to May), hot and wet (June to
October)
Terrain: mostly fiat to undulating plains; mountains in
northwest
Elevation extremes:
lowest point: Gulf of Guinea 0 m
highest point: Mont Nimba 1 ,752 m
Natural resources: petroleum, diamonds,
manganese, iron ore, cobalt, bauxite, copper
Land use:
arable land: 8%
permanent crops: 4%
permanent pastures: 41 %
forests and woodland: 22%
other: 25% (1993 est.)
Irrigated land: 680 sq km (1993 est.)
Natural hazards: coast has heavy surf and no
natural harbors; during the rainy season torrential
flooding is possible
Environment— current issues: deforestation (most
of the country’s forests— once the largest in West
Africa— have been cleared by the timber industry);
water pollution from sewage and industrial and
agricultural effluents
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified : none of the selected
agreements
Location: Middle America, bordering the Caribbean
Sea and the Gulf of Mexico, between Belize and the
US and bordering the North Pacific Ocean, between
Guatemala and the US
Geographic coordinates: 23 00 N, 102 00 W
Map references: North America
Area:
total: 1,972,550 sq km
land: 1,923,040 sq km
water: 49,51 Osq km
Area— comparative: slightly less than three times
the size of Texas
Land boundaries:
total: 4,538 km
border countries: Belize 250 km, Guatemala 962 km,
US 3,326 km
Coastline: 9,330 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical to desert
Terrain: high, rugged mountains, low coastal plains,
high plateaus, and desert
Elevation extremes:
lowest point: Laguna Salada -10 m
highest point: Volcan Pico de Orizaba 5,700 m
Natural resources: petroleum, silver, copper, gold,
lead, zinc, natural gas, timber
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 39%
forests and woodland: 26%
other: 22% (1993 est.)
Irrigated land: 61 ,000 sq km (1993 est.)
Natural hazards: tsunamis along the Pacific coast,
volcanoes and destructive earthquakes in the center
and south, and hurricanes on the Gulf and Caribbean
coasts
Environment— current issues: natural fresh water
resources scarce and polluted in north, inaccessible
and poor quality in center and extreme southeast; raw
sewage and industrial effluents polluting rivers in
urban areas; deforestation; widespread erosion;
desertification; serious air pollution in the national
capital and urban centers along US-Mexico border
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location on southern
border of US
Location: Oceania, island group in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
Land boundaries:
total: 2,51 5 km
border countries: Finland 729 km, Sweden 1 ,61 9 km,
Russia 167 km
Coastline: 21,925 km (includes mainland 3,419 km,
large islands 2,413 km, long fjords, numerous small
islands, and minor indentations 16,093 km)
Maritime claims:
contiguous zone: 10 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 4 nm
Climate: temperate along coast, modified by North
Atlantic Current; colder interior; rainy year-round on
west coast
Terrain: glaciated; mostly high plateaus and rugged
mountains broken by fertile valleys; small, scattered
plains; coastline deeply indented by fjords; arctic
tundra in north
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Glittertinden 2,472 m
Natural resources: petroleum, copper, natural gas,
pyrites, nickel, iron ore, zinc, lead, fish, timber,
hydropower
Land use:
arable land: 3%
permanent crops: N A%
permanent pastures: 0%
forests and woodland: 27%
other: 70% (1 993 est.)
Irrigated land: 970 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: water pollution;
acid rain damaging forests and adversely affecting
lakes, threatening fish stocks; air pollution from
vehicle emissions
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: about two-thirds mountains;
some 50,000 islands off its much indented coastline;
strategic location adjacent to sea lanes and air routes
in North Atlantic; one of most rugged and longest
coastlines in world; Norway only NATO member
having a land boundary with Russia
Location: Southwestern Europe, bordering the
North Atlantic Ocean, west of Spain
Geographic coordinates: 39 30 N, 8 00 W
Map references: Europe
Area:
total: 92,391 sq km
land: 91 ,951 sq km
water: 440 sq km
note: includes Azores and Madeira Islands
Area— comparative: slightly smaller than Indiana
Land boundaries:
total: 1,214 km
border countries: Spain 1 ,21 4 km
Coastline: 1,793 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: maritime temperate; cool and rainy in north,
warmer and drier in south
Terrain: mountainous north of the Tagus, rolling
plains in south
Portugal (continued)
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Ponta do Pico in Azores 2,351 m
Natural resources: fish, forests (cork), tungsten,
iron ore, uranium ore, marble
Land use:
arable land: 26%
permanent crops: 9%
permanent pastures: 9%
forests and woodland: 36%
other: 20% (1993 est.)
Irrigated land: 6,300 sq km (1 993 est.)
Natural hazards: Azores subject to severe
earthquakes
Environment— current issues: soil erosion; air
pollution caused by industrial and vehicle emissions;
water pollution, especially in coastal areas
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Wetlands
signed, but not ratified: Air Pollution-Volatile Organic
Compounds, Environmental Modification, Nuclear
Test Ban, Tropical Timber 94
Geography— note: Azores and Madeira Islands
occupy strategic locations along western sea
approaches to Strait of Gibraltar
Land boundaries:
total: 4,639 km
border countries: Cambodia 1 ,228 km, China 1,281
km, Laos 2,130 km
Coastline: 3,444 km (excludes islands)
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
502
Climate: tropica! in south; monsoonal in north with
hot, rainy season (mid-May to mid-September) and
warm, dry season (mid-October to mid-March)
Terrain: low, flat delta in south and north; central
highlands; hilly, mountainous in far north and
northwest
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Ngoc Linh 3,143 m
Natural resources: phosphates, coal, manganese,
bauxite, chromate, offshore oil and gas deposits,
forests
Land use:
arable land: 17%
permanent crops: 4%
permanent pastures: 1%
forests and woodland: 30%
other: 48% (1993 est.)
Irrigated land: 1 8,600 sq km (1 993 est.)
Natural hazards: occasional typhoons (May to
January) with extensive flooding
Environment— current issues: logging and
slash-and-burn agricultural practices contribute to
deforestation and soil degradation; water pollution
and overfishing threaten marine life populations;
groundwater contamination limits potable water
supply; growing urban industrialization and population
migration are rapidly degrading environment in Hanoi
and Ho Chi Minh City
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Nuclear Test Ban
Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean, east of','f9dfbcf2eb16da36dac4330a5b7a9f67efa12c7ec64762e294bedfa54cc10eef','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a18fb79ffdb478ea5300557f60ba74be6ea4a210ad9ead6586f55dc4739c66e5',1998,'SI','Slovenia','geography',284,'Geographic coordinates: 45 10 N, 15 30 E
Map references: Europe
Area:
total: 56,538 sq km
/and; 56,41 0 sq km
water: 128 sq km
Area— comparative: slightly smaller than West
Virginia
Land boundaries:
total: 2,197 km
border countries: Bosnia and Herzegovina 932 km,
Hungary 329 km, Serbia and Montenegro 266 km
(241 km with Serbia; 25 km with Montenego),
Slovenia 670 km
Coastline: 5,790 km (mainland 1,778 km, islands
4,012 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 1 2 nm
Climate: Mediterranean and continental; continental
climate predominant with hot summers and cold
winters; mild winters, dry summers along coast
Terrain: geographically diverse; flat plains along
Hungarian border, low mountains and highlands near
Adriatic coast, coastline, and islands
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Dinara 1 ,830 m
Natural resources: oil, some coal, bauxite,
low-grade iron ore, calcium, natural asphalt, silica,
mica, clays, salt
Land use:
arable land: 21%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 38%
o//7er; 19% (1 993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: frequent and destructive
earthquakes
Environment— current issues: air pollution (from
metallurgical plants) and resulting acid rain is
damaging the forests; coastal pollution from industrial
and domestic waste; widespread casualties and
destruction of infrastructure in border areas affected
by civil strife
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Sulphur 94,
Desertification
Geography— note: controls most land routes from
Western Europe to Aegean Sea and Turkish Straits','6c22982dd6e10980b626aaba5c81e911d95bef6db6977c17b07460d3de47f0b4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa82d8e9a83385fbda5a4cf6ba931a9c9933338021ef9df3f21ea0eb710b9ee1',1998,'CU','Cuba','geography',292,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, south of Florida
Geographic coordinates: 21 30 N, 80 00 W
Map references: Central America and the
Caribbean
Area:
total: 11 0,860 sq km
land: 11 0,860 sq km
water : 0 sq km
Area— comparative: slightly smaller than
Pennsylvania
Land boundaries:
total: 29 km
border countries: US Naval Base at Guantanamo Bay
29 km
note: Guantanamo Naval Base is leased by the US
and thus remains part of Cuba
Coastline: 3,735 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds; dry
season (November to April); rainy season (May to
October)
Terrain: mostly flat to rolling plains with rugged hills
and mountains in the southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Turquino 2,005 m
Natural resources: cobalt, nickel, iron ore, copper,
manganese, salt, timber, silica, petroleum
Land use:
arable land: 24%
permanent crops: 7%
permanent pastures: 27%
forests and woodland: 24%
other: 1 8% (1 993 est.)
Irrigated land: 9,100 sq km (1993 est.)
Natural hazards: the east coast is subject to
hurricanes from August to October (in general, the
country averages about one hurricane every other
year); droughts are common
Environment— current issues: pollution of Havana
Bay; overhunting threatens wildlife populations;
deforestation
Environment— international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: Antarctic-Environmental
Protocol, Marine Life Conservation
Geography— note: largest country in Caribbean','1862034dd3d912be4466ca524778e8f1db20abc8aab13b9c58cf58a84966ef47','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15ed845543eeb56497b5d22e489f52420ad080cf02187167cd1d91a162339f83',1998,'CY','Cyprus','geography',300,'Location: Middle East, island in the Mediterranean
Sea, south of Turkey
Geographic coordinates: 35 00 N, 33 00 E
Map references: Middle East
Area:
total: 9,250 sq km (note— 3,355 sq km are in the
Turkish Cypriot area)
land: 9,240 sq km
water: 10 sq km
Area— comparative: about 0.6 times the size of
Connecticut
Land boundaries: 0 km
Coastline: 648 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 nm
Climate: temperate, Mediterranean with hot, dry
summers and cool, wet winters
Terrain: central plain with mountains to north and
south; scattered but significant plains along southern
coast
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Olympus 1 ,952 m
Natural resources: copper, pyrites, asbestos,
gypsum, timber, salt, marble, clay earth pigment
Land use:
arable land: 12%
permanent crops: 5%
permanent pastures: 0%
forests and woodland: 1 3%
other: 70% (1993 est.)
Irrigated land: 390 sq km (1993 est.)
Natural hazards: moderate earthquake activity
Environment— current issues: water resource
problems (no natural reservoir catchments, seasonal
disparity in rainfall; sea water intrusion to island''s
largest aquifier; increased salinization in the north);
water pollution from sewage and industrial wastes;
coastal degradation; loss of wildlife habitats from
urbanization
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Location: Central Europe, southeast of Germany
Geographic coordinates: 49 45 N, 15 30 E
Map references: Europe
Area:
total: 78,703 sq km
land: 78,645 sq km
water: 58 sq km
Area— comparative: slightly smaller than South
Carolina
Land boundaries:
total: 1 ,881 km
border countries: Austria 362 km, Germany 646 km,
Poland 658 km, Slovakia 215 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters
Terrain: Bohemia in the west consists of rolling
plains, hills, and plateaus surrounded by low
mountains; Moravia in the east consists of very hilly
country
Elevation extremes:
lowest point: Elbe River 115m
highest point: Snezka 1 ,602 m
Natural resources: hard coal, soft coal, kaolin, clay,
graphite
Land use:
arable land: 41%
permanent crops: 2%
permanent pastures: 1 1 %
forests and woodland: 34%
other: 12% (1993 est.)
Irrigated land: 240 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: air and water
pollution in areas of northwest Bohemia and in
northern Moravia around Ostrava present health risks;
acid rain damaging forests
Environment— international agreements:
party to: Mr Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol
Geography— note: landlocked; strategically located
astride some of oldest and most significant land routes
in Europe; Moravian Gate is a traditional military
corridor between the North European Plain and the
Danube in central Europe','d22df3250c8954a6e74d3de58167478200235bc80822de00ac8b438e8f814868','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('086800e2f30d6ebd765f51d8fa146b5051de1e21883fd8568d3a955b1f26a399',1998,'DK','Denmark','geography',308,'Location: Northern Europe, bordering the Baltic Sea
and the North Sea, on a peninsula north of Germany
Geographic coordinates: 56 00 N, 10 00 E
Map references: Europe
Area:
total: 43,094 sq km
land: 42,394 sq km
water: 700 sq km
note: includes the island of Bornholm in the Baltic Sea
and the rest of metropolitan Denmark, but excludes
the Faroe Islands and Greenland
Area— comparative: slightly less than twice the size
of Massachusetts
Land boundaries:
total: 68 km
border countries: Germany 68 km
Coastline: 7,314 km
Maritime claims:
contiguous zone: 4 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 3 nm
Climate: temperate; humid and overcast; mild, windy
winters and cool summers
Terrain: low and flat to gently rolling plains
Elevation extremes:
lowest point: Lammefjord -7 m
highest point: Ejer Bavnehoj 173 m
Natural resources: petroleum, natural gas, fish,
salt, limestone, stone, gravel and sand
Land use:
arable land: 60%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 10%
other: 25% (1993 est.)
Irrigated land: 4,350 sq km (1993 est.)
Natural hazards: flooding is a threat in some areas
of the country (e.g., parts of Jutland, along the
southern coast of the island of Lolland) that are
protected from the sea by a system of dikes
Environment— current issues: air pollution,
principally from vehicle and power plant emissions;
nitrogen and phosphorus pollution of the North Sea;
drinking and surface water becoming polluted from
animal wastes and pesticides
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Antarctic-Environmental
Protocol, Law of the Sea
Geography— note: controls Danish Straits
(Skagerrak and Kattegat) linking Baltic and North
Seas; about one-quarter of the population lives in
Copenhagen
Location: Eastern Africa, bordering the Gulf of Aden
and the Red Sea, between Eritrea and Somalia
Geographic coordinates: 11 30 N, 43 00 E
Map references: Africa
Area:
total: 22,000 sq km
land: 21 ,980 sq km
water: 20 sq km
Area— comparative: slightly smaller than
Massachusetts
Land boundaries:
total: 508 km
border countries: Eritrea 1 13 km, Ethiopia 337 km,
Somalia 58 km
Coastline: 314 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; torrid, dry
Terrain: coastal plain and plateau separated by
central mountains
Elevation extremes:
lowest point: Asa\\ -155 m
highest point: Mousa''ali 2,028 m
Natural resources: geothermal areas
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: 9%
forests and woodland: 0%
otav91%(1993 est.)
Irrigated land: NA sq km
Natural hazards: earthquakes; droughts; occasional
cyclonic disturbances from the Indian Ocean bring
heavy rains and flash floods
Environment— current issues: inadequate
supplies of potable water; desertification
131
Djibouti (continued)
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location near world''s
busiest shipping lanes and close to Arabian oilfields;
terminus of rail traffic into Ethiopia; mostly wasteland
Location: Oceania, island group in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','dbea2dbcffe8b757ace2ff9a169b759592635363808b874c6856ba9cdde1f259','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa82a4742e161dcfa844f30374dcabdd4812f076c12c9e763a91cf8a1a42ae9d',1998,'DM','Dominica','geography',322,'Location: Caribbean, eastern two-thirds of the island
of Hispaniola, between the Caribbean Sea and the
North Atlantic Ocean, east of Haiti
Geographic coordinates: 19 00 N, 70 40 W
Map references: Central America and the
Caribbean
Area:
totai : 48,730 sq km
land: 48,380 sq km
water: 350 sq km
Area— comparative: slightly more than twice the
size of New Hampshire
Land boundaries:
total: 275 km
border countries: Haiti 275 km
Coastline: 1,288 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 6 nm
Climate: tropical maritime; little seasonal
temperature variation; seasonal variation in rainfall
Terrain: rugged highlands and mountains with fertile
valleys interspersed
Elevation extremes:
lowest point: Lago Enriquillo -46 m
highest point: Pico Duarte 3,175 m
Natural resources: nickel, bauxite, gold, silver
Land use:
arable land: 21%
permanent crops: 9%
permanent pastures: 43%
forests and woodland: 12%
other: 15% (1993 est.)
Irrigated land: 2,300 sq km (1993 est.)
Natural hazards: occasional hurricanes (July to
October)
Environment— current issues: water shortages;
soil eroding into the sea damages coral reefs;
deforestation
Environment— international agreements:
party to: Biodiversity, Desertification, Endangered
Species, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Climate Change, Law of the
Sea
Geography— note: shares island of Hispaniola with
Haiti (eastern two-thirds is the Dominican Republic,
western one-third is Haiti)
Location: Western South America, bordering the
Pacific Ocean at the Equator, between Colombia and','3602bbcd56594e277ffddda46f7c61cef415580875fb0e20030db97c68ca999c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af7db87c54edc04dea73f468689ce93e84ec371bac456d22574488462dd69100',1998,'PE','Peru','geography',324,'Geographic coordinates: 2 00 S, 77 30 W
Map references: South America
Area:
total: 283,560 sq km
land: 276,840 sq km
water: 6,720 sq km
note: includes Galapagos Islands
Area— comparative: slightly smaller than Nevada
Land boundaries:
total: 2,010 km
border countries: Colombia 590 km, Peru 1 ,420 km
Coastline: 2,237 km
Maritime claims:
continental shelf: claims continental shelf between
mainland and Galapagos Islands
territorial sea: 200 nm
Climate: tropical along coast becoming cooler inland
Terrain: coastal plain (costa), inter-Andean central
highlands (sierra), and flat to rolling eastern jungle
(oriente)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Chimborazo 6,267 m
Natural resources: petroleum, fish, timber
Land use:
arable land: 6%
permanent crops: 5%
permanent pastures: 1 8%
forests and woodland: 56%
other: 15% (1993 est.)
Irrigated land: 5,560 sq km (1 993 est.)
Natural hazards: frequent earthquakes, landslides,
volcanic activity; periodic droughts
Environment— current issues: deforestation; soil
erosion; desertification; water pollution; pollution from
oil production wastes
137
Ecuador (continued)
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: Cotopaxi in Andes is highest
active volcano in world','97ad94654110315d7d44df4c3c5faf6c2c38542879a5811369649b14cd6ab51f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('056cc9578d3c52c82850ad9e688fdb4d4bc1ba842fbaa667872f873dfe593a78',1998,'SD','Sudan','geography',333,'Location: Northern Africa, bordering the
Mediterranean Sea, between Libya and the Gaza
Strip
Geographic coordinates: 27 00 N, 30 00 E
Map references: Africa
Area:
total: 1,001 ,450 sq km
land: 995,450 sq km
wafer: 6,000 sq km
Area— comparative: slightly more than three times
the size of New Mexico
Land boundaries:
total: 2,689 km
border countries: Gaza Strip 1 1 km, Israel 255 km,
Libya 1,150 km, Sudan 1,273 km
Coastline: 2,450 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; hot, dry summers with moderate
winters
Terrain: vast desert plateau interrupted by Nile
valley and delta
Elevation extremes:
lowest point: Qattara Depression -133 m
highest point: Mount Catherine 2,629 m
Natural resources: petroleum, natural gas, iron ore,
phosphates, manganese, limestone, gypsum, talc,
asbestos, lead, zinc
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 98% (1 993 est.)
Irrigated land: 32,460 sq km (1993 est.)
Natural hazards: periodic droughts; frequent
earthquakes, flash floods, landslides, volcanic activity;
hot, driving windstorm called khamsin occurs in
spring; dust storms, sandstorms
Environment— current issues: agricultural land
being lost to urbanization and windblown sands;
increasing soil salinization below Aswan High Dam;
desertification; oil pollution threatening coral reefs,
beaches, and marine habitats; other water pollution
from agricultural pesticides, raw sewage, and
industrial effluents; very limited natural fresh water
resources away from the Nile which is the only
perennial water source; rapid growth in population
overstraining natural resources
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: controls Sinai Peninsula, only
land bridge between Africa and remainder of Eastern
Hemisphere; controls Suez Canal, shortest sea link
between Indian Ocean and Mediterranean Sea; size,
and juxtaposition to Israel, establish its major role in
Middle Eastern geopolitics
Location: Northern Africa, bordering the Red Sea,
between Egypt and Eritrea
Geographic coordinates: 15 00 N, 30 00 E
Map references: Africa
Area:
total: 2,505,810 sq km
land: 2.376 million sq km
water: 1 29,81 Osq km
Area— comparative: slightly more than one-quarter
the size of the US
Land boundaries:
total: 7,687 km
border countries: Central African Republic 1,165 km,
Chad 1 ,360 km, Democratic Republic of the Congo
628 km, Egypt 1,273 km, Eritrea 605 km, Ethiopia
1,606 km, Kenya 232 km, Libya 383 km, Uganda
435 km
Coastline: 853 km
Maritime claims:
contiguous zone: 1 8 nm
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 nm
Climate: tropical in south; arid desert in north; rainy
season (April to October)
Terrain: generally flat, featureless plain; mountains
in east and west
Elevation extremes:
lowest point: Red Sea 0 m
highest point: Kinyeti 3,187 m
Natural resources: petroleum; small reserves of
iron ore, copper, chromium ore, zinc, tungsten, mica,
silver, gold
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 19%
other: 30% (1993 est.)
Irrigated land: 19,460 sq km (1993 est.)
Natural hazards: dust storms
Environment— current issues: inadequate
supplies of potable water; wildlife populations
threatened by excessive hunting; soil erosion;
desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: largest country in Africa;
dominated by the Nile and its tributaries','01f50d7ee9966b48a841100222d5fad754381f86511b307d5f1e91ee576fade1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('faddb6bf847465801d523b5d1c1a072f5829212634de6f39710b968ca155fad2',1998,'SV','El Salvador','geography',341,'Location: Middle America, bordering the North
Pacific Ocean, between Guatemala and Honduras
Geographic coordinates: 1 3 50 N, 88 55 W
Map references: Central America and the
Caribbean
Area:
total: 21,040 sq km
land: 20,720 sq km
water: 320 sq km
Area— comparative: slightly smaller than
Massachusetts
Land boundaries:
total: 545 km
border countries: Guatemala 203 km, Honduras 342
km
Coastline: 307 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; rainy season (May to October); dry
season (November to April)
Terrain: mostly mountains with narrow coastal belt
and central plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro El Pital 2,730 m
Natural resources: hydropower, geothermal power,
petroleum
Land use:
arable land: 27%
permanent crops: 8%
permanent pastures: 29%
forests and woodland: 5%
other: 31% (1993 est.)
Irrigated land: 1 ,200 sq km (1 993 est.)
Natural hazards: known as the Land of Volcanoes;
frequent and sometimes very destructive earthquakes
and volcanic activity
Environment— current issues: deforestation; soil
erosion; water pollution; contamination of soils from
disposal of toxic wastes
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography— note: smallest Central American
country and only one without a coastline on Caribbean
Sea','6a08895e2df17b0184b34a979e30b17bb96d33ef3ee26b7a2354a79fe8798ff5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd858a9feaa10139734010d025c9ba8160004a3c9ee6e8b9fc548bd9b45fdad9',1998,'GQ','Equatorial Guinea','geography',345,'Location: Western Africa, bordering the Bight of
Biafra, between Cameroon and Gabon
Geographic coordinates: 2 00 N, 10 00 E
Map references: Africa
Area:
total: 28,050 sq km
land: 28,050 sq km
water: 0 sq km
Area— comparative: slightly smaller than Maryland
Land boundaries:
total: 539 km
border countries: Cameroon 189 km, Gabon 350 km
Coastline: 296 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills; islands
are volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Malabo 3,008 m
Natural resources: timber, petroleum, small
unexploited deposits of gold, manganese, uranium
Land use:
arable land: 5%
permanent crops: 4%
permanent pastures: 4%
forests and woodland: 46%
other: 41% (1993 est.)
irrigated land: NAsqkm
Natural hazards: violent windstorms
Environment— current issues: tap water is not
potable; desertification
Environment— international agreements:
party to: Biodiversity, Desertification, Endangered
Species, Law of the Sea, Nuclear Test Ban, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography— note: insular and continental regions
rather widely separated','1a88141f1eb17f624fd05a68720a3a06e2e8d654ae5190bf62e387445000f729','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff17e8273eb1bb41bf2341a0611c0857b62d676d50d9b65ff2b3baf072088876',1998,'GN','Guinea','geography',353,'Location: Eastern Africa, bordering the Red Sea,
between Djibouti and Sudan
Geographic coordinates: 1 5 00 N, 39 00 E
Map references: Africa
Area:
total: 121 ,320 sq km
land: 121,320 sq km
water: 0 sq km
Area— comparative: slightly larger than
Pennsylvania
Land boundaries:
total: 1 ,630 km
border countries: Djibouti 1 13 km, Ethiopia 912 km,
Sudan 605 km
Coastline: 2,234 km total; mainland on Red Sea
1,151 km, islands in Red Sea 1,083 km
Maritime claims: NA
Climate: hot, dry desert strip along Red Sea coast;
cooler and wetter in the central highlands (up to 61 cm
of rainfall annually); semiarid in western hills and
lowlands; rainfall heaviest during June-September
except on coastal desert
Terrain: dominated by extension of Ethiopian
north-south trending highlands, descending on the
east to a coastal desert plain, on the northwest to hilly
terrain and on the southwest to flat-to-rolling plains
Elevation extremes:
lowest point: Kobar Sink -75 m
highest point: Soira 3,013 m
Natural resources: gold, potash, zinc, copper, salt,
probably oil and natural gas (petroleum geologists are
prospecting for it), fish
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 48%
forests and woodland: 20%
other: 19% (1993 est.)
Irrigated land: 280 sq km (1993 est.)
Natural hazards: frequent droughts
Environment— current issues: deforestation;
desertification; soil erosion; overgrazing; loss of
infrastructure from civil warfare
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species
signed, but not ratified: none of the selected
agreements
Geography— note: strategic geopolitical position
along world''s busiest shipping lanes; Eritrea retained
the entire coastline of Ethiopia along the Red Sea
upon de jure independence from Ethiopia on 27 April
1993','b70731b8b72d99203ebc97cb74acb5f99008bf793c838e8cdd2650f6c9079ea0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fef4faa08516fe43a4d12d4c3a5077861cf233edc4a0a9ceb6563fe43b8c96ab',1998,'EE','Estonia','geography',355,'Location: Eastern Europe, bordering the Baltic Sea
and Gulf of Finland, between Latvia and Russia
Geographic coordinates: 59 00 N, 26 00 E
Map references: Europe
Area:
total: 45,226 sq km
land: 43,21 1 sq km
water: 2,01 5 sq km
note: includes 1 ,520 islands in the Baltic Sea
Area— comparative: slightly smaller than New
Hampshire and Vermont combined
Land boundaries:
total: 633 km
border countries: Latvia 339 km, Russia 294 km
Coastline: 3,794 km
Maritime claims:
exclusive economic zone: limits to be fixed in
coordination with neighboring states
territorial sea: 12 nm
Climate: maritime, wet, moderate winters, cool
summers
Terrain: marshy, lowlands
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Suur Munamagi 318 m
Natural resources: shale oil (kukersite), peat,
phosphorite, amber, Cambrian blue clay
Land use:
arable land: 22%
permanent crops: 0%
permanent pastures: 1 1 %
forests and woodland: 31 %
other: 36% (1993 est.)
Irrigated land: 1 1 0 sq km (1 993 est.)
Natural hazards: flooding occurs frequently in the
spring
Environment— current issues: air heavily polluted
with sulfur dioxide from oil-shale burning power plants
in northeast; contamination of soil and groundwater
149
Estonia (continued)
with petroleum products, chemicals at former Soviet
military bases; Estonia has more than 1,400 natural
and manmade lakes, the smaller of which In
agricultural areas are heavily affected by organic
waste; coastal sea water is polluted in many locations
Environment-international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Ship Pollution, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Location: Eastern Africa, west of Somalia
Geographic coordinates: 8 00 N, 38 00 E
Map references: Africa
Area:
total: 1,127,127 sq km
land: 1,1 19,683 sq km
water: 7,444 sq km
Area— comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,311 km
border countries: Djibouti 337 km, Eritrea 912 km,
Kenya 830 km, Somalia 1 ,626 km, Sudan 1 ,606 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon with wide
topographic-induced variation
Terrain: high plateau with central mountain range
divided by Great Rift Valley
Elevation extremes:
lowest point: Denakil -125 m
highest point: Ras Dashen Terara 4,620 m
Natural resources: small reserves of gold, platinum,
copper, potash, natural gas
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 40%
forests and woodland: 25%
other: 22% (1993 est.)
Irrigated land: 1 ,900 sq km (1993 est.)
Natural hazards: geologically active Great Rift
Valley susceptible to earthquakes, volcanic eruptions;
frequent droughts
Environment— current issues: deforestation;
overgrazing; soil erosion; desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer
Protection
signed, but not ratified: Environmental Modification,
Law of the Sea, Nuclear Test Ban
Geography— note: landlocked— entire coastline
along the Red Sea was lost with the de jure
independence of Eritrea on 27 April 1993
Location: Southern Africa, island in the Mozambique
Channel, about one-half of the way from southern
Madagascar to southern Mozambique
Geographic coordinates: 22 20 S, 40 22 E
Map references: Africa
Area:
total: 28 sq km
land: 28 sq km
water : 0 sq km
Area— comparative: about 0.16 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 22.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 24 m
Natural resources: negligible
Land use:
arable land: NA%
permanent crops : NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Geography— note: wildlife sanctuary','2bf62369e35cbc24577038442423cc72855d6243d3f6c1024eb1cb3d616f2ac7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a4cb5a79274fd094ffa473c05b69a6a94b138deb3f3dcb7009c5a934b09af2b',1998,'FO','Faroe Islands','geography',364,'Location: Northern Europe, island group between
the Norwegian Sea and the north Atlantic Ocean,
about one-half of the way from Iceland to Norway
Geographic coordinates: 62 00 N, 7 00 W
Map references: Europe
Area:
total: 1 ,399 sq km
land: 1,399 sq km
water: 0 sq km (some lakes and streams)
Area— comparative: eight times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,117 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: mild winters, cool summers; usually
overcast; foggy, windy
Terrain: rugged, rocky, some low peaks; cliffs along
most of coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Slaettaratindur 882 m
Natural resources: fish, whales
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 94% (1 996)
Irrigated land: 0 sq km
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: archipelago of 17 inhabited
islands and one uninhabited island, and a few
uninhabited islets; strategically located along
156
important sea lanes in northeastern Atlantic;
precipitous terrain limits habitation to small coastal
lowlands','b10f6ac4f910c38b178b4f90d432e6ce8858bc3c5e55bc1e8567f26cd1f4a484','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd8f928eac8546414e3ffc3275ee1727647ea1c49b607884a9820e92a44eb912',1998,'NZ','New Zealand','geography',370,'Geographic coordinates: 18 00 S, 175 00 E
Map references: Oceania
Area:
total: 18, 270 sq km
land: 1 8,270 sq km
water: 0 sq km
Area— comparative: slightly smaller than New
Location: Oceania, islands in the South Pacific
Ocean, southeast of Australia
Geographic coordinates: 41 00 S, 174 00 E
Map references: Oceania
Area:
total: 268,680 sq km
land: 268,670 sq km
water: 10 sq km
note: includes Antipodes Islands, Auckland Islands,
Bounty Islands, Campbell Island, Chatham Islands,
and Kermadec Islands
Area— comparative: about the size of Colorado
Land boundaries: 0 km
Coastline: 15,134 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate with sharp regional contrasts
Terrain: predominately mountainous with some
large coastal plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Cook 3,764 m
Natural resources: natural gas, iron ore, sand, coal,
timber, hydropower, gold, limestone
Land use:
arable land: 9%
permanent crops: 5%
permanent pastures: 50%
forests and woodland: 28%
other: 8% (1993 est.)
Irrigated land: 2,850 sq km (1993 est.)
Natural hazards: earthquakes are common, though
usually not severe; volcanic activity
Environment— current issues: deforestation; soil
erosion; native flora and fauna hard-hit by species
introduced from outside
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands, Whaling
signed , but not ratified: Marine Life Conservation
Geography— note: about 80% of the population
lives in cities
Geographic coordinates: 20 00 S, 175 00 W
Map references: Oceania
Area:
total: 748 sq km
land: 71 8 sq km
water: 30 sq km
Area— comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 419 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; modified by trade winds; warm
season (December to May), cool season (May to
December)
Terrain: most islands have limestone base formed
from uplifted coral formation; others have limestone
overlying volcanic base
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Kao Island
1,033 m
Natural resources: fish, fertile soil
Land use:
arable land: 24%
permanent crops: 43%
permanent pastures: 6%
forests and woodland: 1 1 %
other: 16% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: cyclones (October to April);
earthquakes and volcanic activity on Fonuafo’ou
Environment— current issues: deforestation
results as more and more land is being cleared for
agriculture and settlement; some damage to coral
reefs from starfish and indiscriminate coral and shell
collectors; overhunting threatens native sea turtle
populations
Environment— international agreements:
party to: Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: archipelago of 170 islands (36
inhabited)
Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
northeast of Venezuela
Geographic coordinates: 1 1 00 N, 61 00 W
Map references: Central America and the
Caribbean
Area:
total: 5,130 sq km
land: 5,1 30 sq km
water: 0 sq km
Area— comparative: slightly smaller than Delaware
Land boundaries: 0 km
Coastline: 362 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the outer edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy season (June to December)
Terrain: mostly plains with some hills and low
mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: El Cerro del Aripo 940 m
Natural resources: petroleum, natural gas, asphalt
Land use:
arable land: 15%
permanent crops: 9%
permanent pastures: 2%
forests and woodland: 46%
other: 28% (1993 est.)
Irrigated land: 220 sq km (1993 est.)
Natural hazards: outside usual path of hurricanes
and other tropical storms
Environment— current issues: water pollution from
agricultural chemicals, industrial wastes, and raw
sewage; oil pollution of beaches; deforestation; soil
erosion
Trinidad and Tobago (continued)
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Life Conservation, Nuclear Test Ban, Ozone Layer
Protection, Tropical Timber 83, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 15 52 S, 54 25 E
Map references: Africa
Area:
total: 1 sq km
land: 1 sq km
water: 0 sq km
Area— comparative: about 1 .7 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 3.7 km
Maritime claims:
contiguous zone: 1 2 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical
Terrain: sandy
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 7 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (scattered bushes)
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: climatologically important
location for forecasting cyclones; wildlife sanctuary
469
Tromelin Island (continued)
Geographic coordinates: 13 18 S, 176 12 W
Map references: Oceania
Area:
tofa/:274 sq km
land: 274 sq km
water: 0 sq km
note: includes He Uvea (Wallis Island), He Futuna
(Futuna Island), lie Alofi, and 20 islets
Area— comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 129 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical; hot, rainy season (November to
April); cool, dry season (May to October); rains
2,500-3,000 mm per year (80% humidity); average
temperature 26.6 degrees C
Terrain: volcanic origin; low hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Singavi 765 m
Natural resources: NEGL
Land use:
arable land: 5%
permanent crops: 20%
permanent pastures: NA%
forests and woodland: NA%
other: 75% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment— current issues: deforestation (only
small portions of the original forests remain) largely as
a result of the continued use of wood as the main fuel
source; as a consequence of cutting down the forests,
the mountainous terrain of Futuna is particularly prone
to erosion; there are no permanent settlements on
Alofi because of the lack of natural fresh water
resources
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: both island groups have fringing
reefs','7082c5bde0451fce770a8db795892ff06f1696e8dde429f8a86053d61780babc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7de576123246e7a940185ccc15f506484d2acaad178424026a11cf079c1023f',1998,'JE','Jersey','geography',371,'Land boundaries: 0 km
Coastline: 1,129 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200-m depth or to the depth of
exploitation; rectilinear shelf claim added
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; only slight seasonal
temperature variation
Terrain: mostly mountains of volcanic origin
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Tomanivi 1 ,324 m
Natural resources: timber, fish, gold, copper,
offshore oil potential
Land use:
arable land: 10%
permanent crops: 4%
permanent pastures: 10%
forests and woodland: 65%
other: 1 1 % (1 993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: cyclonic storms can occur from
November to January
Environment— current issues: deforestation; soil
erosion
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: includes 332 islands of which
approximately 1 10 are inhabited
Location: Southern Europe, a peninsula extending
into the central Mediterranean Sea, northeast of
Location: Western Europe, island in the English
Channel, northwest of France
Geographic coordinates: 49 15 N, 2 10 W
Map references: Europe
Area:
fofa/;116sq km
/and:116sq km
water: Osq km
Area— comparative: about 0.7 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 70 km
Maritime claims:
exclusive fishing zone: 1 2 nm
territorial sea: 3 nm
Climate: temperate; mild winters and cool summers
Terrain: gently rolling plain with low, rugged hills
along north coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 143 m
Natural resources: agricultural land
Land use:
arable land: 66%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 34%
Irrigated land: NAsqkm
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: largest and southernmost of
Channel Islands; about 30% of population
concentrated in Saint Helier
Location: Oceania, atoll in the North Pacific Ocean,
about one-third of the way from Hawaii to the Marshall
Islands
Geographic coordinates: 1 6 45 N, 1 69 30 W
Map references: Oceania
Area:
total: 2.8 sq km
land: 2.8 sq km
water: 0 sq km
Area— comparative: about 4.7 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 10 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but generally dry; consistent
northeast trade winds with little seasonal temperature
variation
Terrain: mostly flat
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Summit Peak 5 m
Natural resources: NA; guano deposits worked until
depletion about 1890
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment— current issues: no natural fresh
water resources
Environment— international agreements:
party to: NA
signed, but not ratified: NA
243
Johnston Atoll (continued)
Geography— note: strategic location in the North
Pacific Ocean; Johnston Island and Sand Island are
natural islands, which have been expanded by coral
dredging; North Island (Akau) and East Island (Hikina)
are manmade islands formed from coral dredging;
closed to the public; former US nuclear weapons test
site; site of Johnston Atoll Chemical Agent Disposal
System (JACADS); some low-growing vegetation
Land boundaries:
total: 464 km
border countries: Iraq 242 km, Saudi Arabia 222 km
Coastline: 499 km
Maritime claims:
territorial sea: 12 nm
Climate: dry desert; intensely hot summers; short,
cool winters
Terrain: flat to slightly undulating desert plain
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: unnamed location 306 m
Natural resources: petroleum, fish, shrimp, natural
gas
Land use:
arable land : 0%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 0%
other: 92% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: sudden cloudbursts are common
from October to April, they bring inordinate amounts of
rain which can damage roads and houses;
sandstorms and dust storms occur throughout the
year, but are most common between March and
August
Environment— current issues: limited natural fresh
water resources; some of world''s largest and most
259
Kuwait (continued)
sophisticated desalination facilities provide much of
the water; air and water pollution; desertification
Environment— international agreements:
party to: Climate Change, Desertification,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Biodiversity, Endangered
Species, Marine Dumping
Geography— note: strategic location at head of
Persian Gulf
Land boundaries:
total: 535 km
border countries: Mozambique 105 km, South Africa
430 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from tropical to near temperate
Terrain: mostly mountains and hills; some
moderately sloping plains
Elevation extremes:
lowest point: Great Usutu River 21 m
highest point: Emlembe 1,862 m
Natural resources: asbestos, coal, clay, cassiterite,
hydropower, forests, small gold and diamond
deposits, quarry stone, and talc
Land use:
arable land: 11%
permanent crops: 0%
permanent pastures: 62%
forests and woodland: 7%
other: 20% (1993 est.)
Irrigated land: 670 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: limited supplies of
potable water; wildlife populations being depleted
because of excessive hunting; overgrazing; soil
degradation; soil erosion
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Desertification, Law of the
Sea
Geography— note: landlocked; almost completely
surrounded by South Africa','6963aca883a7e3ffbe1b998d70cf1260f0d61c5fb1bc4d48b27e3e77fd03b385','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('985b834ff8412afdb08013adab1da67238fa2c1715e216f8c884fc0e41176699',1998,'GF','French Guiana','geography',393,'Location: Northern South America, bordering the
North Atlantic Ocean, between Brazil and Suriname
Geographic coordinates: 4 00 N, 53 00 W
Map references: South America
Area:
total: 91 ,000 sq km
land: 89,150 sq km
water: 1 ,850 sq km
Area— comparative: slightly smaller than Indiana
Land boundaries:
total: 1,183 km
border countries: Brazil 673 km, Suriname 510 km
Coastline: 378 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; little seasonal
temperature variation
Terrain: low-lying coastal plains rising to hills and
small mountains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Bellevue de I''lnini 851 m
Natural resources: bauxite, timber, gold (widely
scattered), cinnabar, kaolin, fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 83%
other: 17% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: high frequency of heavy showers
and severe thunderstorms; flooding
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: mostly an unsettled wilderness','aced92b970d7b397aa01c49d1543a094da3439bf344d58ade846d69fe31833f5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce31c9bb6179dbb3ed951de386a7c8a4781ba7bd76bb22e9165eff58cda5650b',1998,'PF','French Polynesia','geography',397,'Location: Oceania, archipelago in the South Pacific
Ocean, about one-half of the way from South America
to Australia
Geographic coordinates: 15 00 S, 140 00 W
Map references: Oceania
Area:
total: 4,167 sq km (118 islands and atolls)
land: 3,660 sq km
water: 507 sq km
Area— comparative: slightly less than one-third the
size of Connecticut
Land boundaries: 0 km
Coastline: 2,525 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but moderate
Terrain: mixture of rugged high islands and low
islands with reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Orohena 2,241 m
Natural resources: timber, fish, cobalt
Land use:
arable land: 1%
permanent crops: 6%
permanent pastures: 5%
forests and woodland: 31 %
other: 57% (1 993 est.)
Irrigated land: NAsqkm
Natural hazards: occasional cyclonic storms in
January
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: includes five archipelagoes;
Makatea in French Polynesia is one of the three great
phosphate rock islands in the Pacific Ocean— the
others are Banaba (Ocean Island) in Kiribati and Nauru
l People
Population: 237,844 (July 1998 est.)
Age structure:
0-14 years: 33% (male 40,264; female 38,770)
15-64 years: 62% (male 77,01 1 ; female 71 ,1 00)
65 years and over: 5% (male 5,347; female 5,352)
(July 1998 est.)
Population growth rate: 1 .81% (1998 est.)
Birth rate: 22.67 births/1 ,000 population (1 998 est.)
Death rate: 5 deaths/1,000 population (1998 est.)
Net migration rate: 0.39 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 1 male(s)/female (1 998 est.)
Infant mortality rate: 1 3.67 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 72.25 years
male: 69.87 years
female: 74.75 years (1998 est.)
Total fertility rate: 2.71 children born/woman (1998
est.)
Nationality:
noun: French Polynesian(s)
adjective : French Polynesian
Ethnic groups: Polynesian 78%, Chinese 12%,
local French 6%, metropolitan French 4%
Religions: Protestant 54%, Roman Catholic 30%,
other 16%
Languages: French (official), Tahitian (official)
Literacy:
definition: age 14 and over can read and write, but
definition of literacy not available
total population: 98%
male: 98%
female: 98% (1977 est.)
f- Government
Country name:
conventional long form: Territory of French Polynesia
conventional short form: French Polynesia
local long form/Territoire de la Polynesie Francaise
local short form: Polynesie Francaise
Data code: FP
Dependency status: overseas territory of France
since 1946
Government type: NA
National capital: Papeete
Administrative divisions: none (overseas territory
of France); there are no first-order administrative
divisions as defined by the US Government, but there
are 5 archipelagic divisions named Archipel des
Marquises, Archipel des Tuamotu, Archipel des
Tubuai, lies du Vent, and lies Sous-le-Vent
note: Clipperton Island is administered by France
from French Polynesia
Independence: none (overseas territory of France)
National holiday: National Day, Taking of the
Bastille, 14 July (1789)
Constitution: 28 September 1958 (French
Constitution)
Legal system: based on French system
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President of France Jacques CHIRAC
(since 17 May 1995), represented by High
Commissioner of the Republic Paul RONCIERE
(since NA 1994)
head of government: President of the Territorial
Government of French Polynesia Gaston FLOSSE
(since 4 April 1 991 ); President of the Territorial
Assembly Justin ARAPARI (since 13 May 1996)
cabinet: Council of Ministers; president submits a list
of members of the Territorial Assembly for approval by
them to serve as ministers
elections: high commissioner appointed by the
president of France on the advice of the French
Ministry of Interior; president of the Territorial
Government and the president of the Territorial
Assembly are elected by the members of the
assembly
Legislative branch: unicameral Territorial
Assembly or Assemblee Territoriale (41 seats;
members are elected by popular vote to serve
five-year terms)
elections: last held 12 May 1 996 (next to be held NA
March 2001)
election results : percent of vote by party— NA; seats
by party— People''s Rally for the Republic (Gaullist)
22, Polynesian Liberation Front 10, New Fatherland
Party 5, other 4
note: one seat was elected to the French Senate on
24 September 1989 (next to be held NA September
1998); results— percent of vote by party— NA; seats
by party— UC 1 ; two seats were elected to the French
National Assembly on 25 May— 1 June 1997 (next to
be held NA 2002); results— percent of vote by party—
NA; seats by party— People''s Rally for the Republic
(Gaullist) 2
Judicial branch: Court of Appeal or Cour d'' Appel;
Court of the First Instance or Tribunal de Premiere
Instance; Court of Administrative Law or Tribunal
Administratif
Political parties and leaders: People''s Rally for the
Republic (Tahoeraa Huiraatira) [Gaston FLOSSE];
Polynesian Union Party (includes Te Tiarama and
Pupu Here Ai''a Party) [Jean JUVENTIN]; Independent
Front for the Liberation of Polynesia (Tavini
Huiraatira) [Oscar TEMARU]; New Fatherland Party
(Ai''a Api) [Emile VERNAUDON]; Independent Party
(la Mana Te Nunaa) [Jacques DROLLET]; Te Aratia
Ote Nunaa (Tinomana Ebb); Haere i Mua [Alexandre
LEONTIEFF]; Te e''a No Maohi Nui [Jean-Marius
RAAPOTO]; Pupu Taina [Michel LAW]; Entente
Polynesian [Arthur CHUNG]; Centrist Union or UC
International organization participation: ESCAP
(associate), FZ, ICFTU, SPC, WMO
Diplomatic representation in the US: none
(overseas territory of France)
Diplomatic representation from the US: none
167
French Polynesia (continued)
(overseas territory of France)
Flag description: two narrow red horizontal bands
encase a wide white band; centered on the white band
is a disk with blue and white wave pattern on the lower
half and gold and white ray pattern on the upper half;
a stylized red, blue and white ship rides on the wave
pattern; the French flag is used for official occasions','76b9a7cd160a6c9b99142634a74cd6c38b3b364ac196004564d112eaf26bc7d6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92b1c7ac6b000e6b73a5b7a3ff4e27ee91f448d1daa4e6e7c1453bd132b999dd',1998,'GA','Gabon','geography',407,'Location: Western Africa, bordering the Atlantic
Ocean at the Equator, between Republic of the Congo
and Equatorial Guinea
Geographic coordinates: 1 00 S, 11 45 E
Map references: Africa
Area:
total: 267,670 sq km
land: 257,670 sq km
water: 10,000 sq km
Area— comparative: slightly smaller than Colorado
Land boundaries:
total: 2,551 km
border countries: Cameroon 298 km, Republic of the
Congo 1,903 km, Equatorial Guinea 350 km
Coastline: 885 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly interior; savanna
in east and south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Iboundji 1,575 m
Natural resources: petroleum, manganese,
uranium, gold, timber, iron ore
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 1 8%
forests and woodland : 77%
other: 3% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: deforestation;
poaching
Environment— international agreements:
party to: Biodiversity, Climate Change,
169
Gabon (continued)
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Location: Western Africa, bordering the North
Atlantic Ocean and Senegal
Geographic coordinates: 13 28 N, 16 34 W
Map references: Africa
Area:
total: 11,300 sq km
land: 10,000 sq km
water: 1 ,300 sq km
Area— comparative: slightly less than twice the size
of Delaware
Land boundaries:
total: 740 km
border countries: Senegal 740 km
Coastline: 80 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: not specified
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, rainy season (June to
November); cooler, dry season (November to May)
Terrain: flood plain of the Gambia River flanked by
some low hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 53 m
Natural resources: fish
Land use:
arable land: 18%
permanent crops: 0%
permanent pastures: 9%
forests and woodland : 28%
other: 45% (1993 est.)
Irrigated land: 150 sq km (1993 est.)
Natural hazards: rainfall has dropped by 30% in the
last 30 years
Environment— current issues: deforestation;
desertification; water-borne diseases prevalent
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: almost an enclave of Senegal;
smallest country on the continent of Africa','958a480da2e80130e9aec9474d19d49b47c806b0dd5e67ce143a21283bbf2fd4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4b44877f96f8bd3babbf5e30ee05863eea1520aec467406c76dfcccbf83aa22',1998,'GE','Georgia','geography',411,'Location: Southwestern Asia, bordering the Black
Sea, between Turkey and Russia
Geographic coordinates: 42 00 N, 43 30 E
Map references: Commonwealth of Independent
States
Area:
total: 69,700 sq km
land: 69,700 sq km
water: Osq km
Area— comparative: slightly smaller than South
Carolina
Land boundaries:
total: 1,461 km
border countries: Armenia 164 km, Azerbaijan 322
km, Russia 723 km, Turkey 252 km
Coastline: 310 km
Maritime claims: NA
Climate: warm and pleasant; Mediterranean-like on
Black Sea coast
Terrain: largely mountainous with Great Caucasus
Mountains in the north and Lesser Caucasus
Mountains in the south; Kolkhida Lowland opens to
the Black Sea in the west; Mtkvari River Basin in the
east; good soils in river valley flood plains, foothills of
Kolkhida Lowland
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Mt''a Mqinvartsveri (Gora Kazbek)
5,048 m
Natural resources: forests, hydropower,
manganese deposits, iron ore, copper, minor coal and
oil deposits; coastal climate and soils allow for
important tea and citrus growth
Land use:
arable land: 9%
permanent crops: 4%
permanent pastures: 25%
forests and woodland: 34%
other: 28% (1993 est.)
Irrigated land: 4,000 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: air pollution,
particularly in Rusfavi; heavy pollution of Mtkvari
River and the Black Sea; inadequate supplies of
potable water; soil pollution from toxic chemicals
Environment— international agreements:
party to: Biodiversity, Climate Change, Law of the
Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified : Desertification','2d12f4a6e4e1ddafcde6e03c3392f7a6df649922cfa88a8bd6eade38119c43ce','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afaa03bee2905ac5be0684cfda605a1492705217fb4c188503a729dfb2c6818e',1998,'GH','Ghana','geography',421,'Location: Western Africa, bordering the Gulf of
Guinea, between Cote d''Ivoire and Togo
Geographic coordinates: 8 00 N, 2 00 W
Map references: Africa
Area:
total: 238,540 sq km
land: 230,020 sq km
water: 8,520 sq km
Area— comparative: slightly smaller than Oregon
Land boundaries:
total: 2,093 km
border countries: Burkina Faso 548 km, Cote d''Ivoire
668 km, Togo 877 km
Coastline: 539 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; warm and comparatively dry along
southeast coast; hot and humid in southwest; hot and
dry in north
Terrain: mostly low plains with dissected plateau in
south-central area
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Afadjato 880 m
Natural resources: gold, timber, industrial
diamonds, bauxite, manganese, fish, rubber
Land use:
arable land: 12%
permanent crops: 7%
permanent pastures: 22%
forests and woodland: 35%
other: 24% (1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: dry, dusty, harmattan winds occur
from January to March; droughts
Environment— current issues: recent drought in
north severely affecting agricultural activities;
deforestation; overgrazing; soil erosion; poaching and
habitat destruction threatens wildlife populations;
water pollution; inadequate supplies of potable water
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
Geography— note: Lake Volta is the world''s largest
artificial lake; northeasterly harmattan wind (January
to March)','fe97273bc38b062e7fa4226af2739231f8523fee7fbae5e778565d43cafdbee2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9cde532aa942dcf691ac590d6970642e7e022e051bede0640f85fe334f0a072',1998,'ES','Spain','geography',436,'Location: Southern Africa, group of islands in the
Indian Ocean, northwest of Madagascar
Geographic coordinates: 11 30 S, 47 20 E
Map references: Africa
Area:
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes He Glorieuse, lie du Lys, Verte Rocks,
Wreck Rock, and South Rock
Area— comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 12 m
Natural resources: guano, coconuts
Land use:
arable land : NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (all lush vegetation and coconut palms)
Irrigated land: 0 sq km (1993)
Natural hazards: periodic cyclones
Environment— current issues: NA','a22adbcbaf47964fcbaba748bb8713a1264a8eb6af8802d2bf8b0cf1ba18334e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3a3a0d9f527119e21d51cba4ed222f56c93e3eb1644f72335571049dfab5ed0',1998,'GD','Grenada','geography',438,'Location: Caribbean, island between the Caribbean
Sea and Atlantic Ocean, north of Trinidad and Tobago
Geographic coordinates: 12 07 N, 61 40 W
Map references: Central America and the
Caribbean
Area:
total: 340 sq km
land: 340 sq km
water: 0 sq km
Area-comparative: twice the size of Washington,
DC
Land boundaries: 0 km
Coastline: 121 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; tempered by northeast trade winds
Terrain: volcanic in origin with central mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Saint Catherine 840 m
Natural resources: timber, tropical fruit, deepwater
harbors
Land use:
arable land: 15%
permanent crops: 18%
permanent pastures: 3%
forests and woodland: 9%
other: 55% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: lies on edge of hurricane belt;
hurricane season lasts from June to November
Environment— current issues: NA
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Ozone Layer
Protection, Whaling
signed , but not ratified: none of the selected
agreements
Geography— note: the administration of the islands
of the Grenadines group is divided between Saint
Vincent and the Grenadines and Grenada
Location: Caribbean, islands in the eastern
Caribbean Sea, southeast of Puerto Rico
Geographic coordinates: 16 15 N, 61 35 W
Map references: Central America and the
Caribbean
Area:
total: 1,780 sq km
land: 1,706 sq km
water: 74 sq km
note: Guadeloupe is an archipelago of nine inhabited
islands, including Basse-Terre, Grande-Terre,
Marie-Galante, La Desirade, lies des Saintes, Saint
Barthelemy, and part of Saint Martin
Area— comparative: 10 times the size of
Washington, DC
Land boundaries:
total: 1 0.2 km
border countries: Netherlands Antilles (Sint Maarten)
10.2 km
Coastline: 306 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: subtropical tempered by trade winds;
moderately high humidity
Terrain: Basse-Terre is volcanic in origin with interior
mountains; Grande-Terre is low limestone formation;
most of the seven other islands are volcanic in origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1 ,467 m
Natural resources: cultivable land, beaches and
climate that foster tourism
Land use:
arable land: 14%
permanent crops: 4%
permanent pastures: 1 4%
forests and woodland: 39%
other: 29% (1993 est.)
191
Guadeloupe (continued)
irrigated land: 30 sq km (1993 est.)
Natural hazards: hurricanes (June to October);
Soufriere is an active volcano
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA','bfe583b16bf5bc798152a2d4ac7dfb42f24c563fe3cdb6bfa29322785d36861d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb6423326fd26b9ff9065e9adc48369b6c16937162421ffc044c14842ab76c73',1998,'GU','Guam','geography',447,'Location: Oceania, island in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
the Philippines
Geographic coordinates: 13 28 N, 144 47 E
Map references: Oceania
Area:
total: 541 .3 sq km
land: 541 .3 sq km
water: 0 sq km
Area— comparative: three times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 125.5 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; generally warm and humid,
moderated by northeast trade winds; dry season from
January to June, rainy season from July to December;
little seasonal temperature variation
Terrain: volcanic origin, surrounded by coral reefs;
relatively flat coralline limestone plateau (source of
most fresh water) with steep coastal cliffs and narrow
coastal plains in north, low-rising hills in center,
mountains in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Lamlam 406 m
Natural resources: fishing (largely undeveloped),
tourism (especially from Japan)
Land use:
arable land: 11%
permanent crops: 11%
permanent pastures: 15%
forests and woodland: 1 8%
other: 45% (1 993 est.)
Irrigated land: NAsqkm
Natural hazards: frequent squalls during rainy
season; relatively rare, but potentially very destructive
193
Guam (continued)
typhoons (especially in August)
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed \\ but not ratified: NA
Geography— note: largest and southernmost island
in the Mariana Islands archipelago; strategic location
in western North Pacific Ocean','a86aa2c0652a6880435e2343657a95f30adf74e82aa66e4d4fa8b389d411dbf2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9486458779347208ea5857bf5fa30b9837691cd3de3b733e6b3b60dc53dc2075',1998,'GG','Guernsey','geography',460,'Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and Sierra
Leone
Geographic coordinates: 1 1 00 N, 1 0 00 W
Map references: Africa
Area:
total: 245,860 sq km
land: 245,860 sq km
wafer 0 sq km
Area— comparative: slightly smaller than Oregon
Land boundaries:
total: 3,399 km
border countries: Guinea-Bissau 386 km, Cote
d''Ivoire 610 km, Liberia 563 km, Mali 858 km, Senegal
330 km, Sierra Leone 652 km
Coastline: 320 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: generally hot and humid; monsoonal-type
rainy season (June to November) with southwesterly
winds; dry season (December to May) with
northeasterly harmattan winds
Terrain: generally flat coastal plain, hilly to
mountainous interior
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Nimba 1 ,752 m
Natural resources: bauxite, iron ore, diamonds,
gold, uranium, hydropower, fish
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 22%
forests and woodland: 59%
other: 17% (1993 est.)
Irrigated land: 930 sq km (1 993 est.)
Natural hazards: hot, dry, dusty harmattan haze
may reduce visibility during dry season
Environment— current issues: deforestation;
inadequate supplies of potable water; desertification;
soil contamination and erosion; overfishing,
overpopulation in forest region
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements','53e12b5f4ea76462c29bb95f7b278b2068fd0b281ea7e74bfa71be58219a5ba2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d21a9db257292d3b33564ce9aa4ae83b91978e41580f3a16c4d2f936dad88f58',1998,'GW','Guinea-Bissau','geography',462,'Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Senegal
Geographic coordinates: 12 00 N, 15 00 W
Map references: Africa
Area:
total: 36, 120 sq km
land: 28,000 sq km
water: 8,120 sq km
Area— comparative: slightly less than three times
the size of Connecticut
Land boundaries:
total: 724 km
border countries: Guinea 386 km, Senegal 338 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; generally hot and humid;
monsoonal-type rainy season (June to November)
with southwesterly winds; dry season (December to
May) with northeasterly harmattan winds
Terrain: mostly low coastal plain rising to savanna in
east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location in the northeast
corner of the country 300 m
Natural resources: fish, timber, phosphates,
bauxite, unexploited deposits of petroleum
Land use:
arable land: 11%
permanent crops: 1%
permanent pastures: 38%
forests and woodland: 38%
other: 12% (1993 est.)
Irrigated land: 17 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan haze
may reduce visibility during dry season; brush fires
Environment— current issues: deforestation; soil
erosion; overgrazing; overfishing
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Nuclear Test Ban, Wetlands
signed, but not ratified: none of the selected
agreements','cb6f5e21ca328b628fb74c7654cc99a3d9c48aa28e6a4fa519202e02f8919077','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc6bfbba310b34a434ceffad85bf1881aa42320ec1dda52c8f482c7ae50a5d84',1998,'GY','Guyana','geography',467,'Location: Northern South America, bordering the
North Atlantic Ocean, between Suriname and
Venezuela
Geographic coordinates: 5 00 N, 59 00 W
Map references: South America
Area:
total: 21 4,970 sq km
land: 196,850 sq km
water: 18,120 sq km
Area-comparative: slightly smaller than Idaho
Land boundaries:
total: 2,462 km
border countries: Brazil 1 ,1 1 9 km, Suriname 600 km,
Venezuela 743 km
Coastline: 459 km
Maritime claims:
continental shelf: 200 nm or to the outer edge of the
continental margin
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid, moderated by
northeast trade winds; two rainy seasons (May to
mid-August, mid-November to mid-January)
Terrain: mostly rolling highlands; low coastal plain;
savanna in south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Roraima 2,835 m
Natural resources: bauxite, gold, diamonds,
hardwood timber, shrimp, fish
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 84%
other: 8% (1993 est.)
Irrigated land: 1,300 sq km (1993 est.)
Natural hazards: flash floods are a constant threat
during rainy seasons
Environment— current issues: water pollution from
sewage and agricultural and industrial chemicals;
deforestation
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection, Tropical Timber 83, Tropical
Timber 94, Whaling
signed, but not ratified: none of the selected
agreements
Location: Caribbean, western one-third of the island
of Hispaniola, between the Caribbean Sea and the
North Atlantic Ocean, west of the Dominican Republic
Geographic coordinates: 1 9 00 N, 72 25 W
Map references: Central America and the
Caribbean
Area:
total: 27,750 sq km
land: 27,560 sq km
water: 190 sq km
Area— comparative: slightly smaller than Maryland
Land boundaries:
total: 275 km
border countries: Dominican Republic 275 km
Coastline: 1,771 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: to depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; semiarid where mountains in east
cut off trade winds
Terrain: mostly rough and mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Chaine de la Selle 2,680 m
Natural resources: none
Land use:
arable land: 20%
permanent crops: 1 3%
permanent pastures: 18%
forests and woodland: 5%
other: 44% (1 993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: lies in the middle of the hurricane
belt and subject to severe storms from June to
October; occasional flooding and earthquakes;
periodic droughts
Environment— current issues: extensive
deforestation (much of the remaining forested land is
being cleared for agriculture and used as fuel); soil
erosion; inadequate supplies of potable water
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping,
Marine Life Conservation
signed, but not ratified: Hazardous Wastes, Nuclear
Test Ban
Geography— note: shares island of Hispaniola with
Dominican Republic (western one-third is Haiti,
eastern two-thirds is the Dominican Republic)
Location: Southern Africa, islands in the Indian
Ocean, about two-thirds of the way from Madagascar
to Antarctica
Geographic coordinates: 53 06 S, 72 31 E
Map references: Antarctic Region
Area:
total: 41 2 sq km
land: 41 2 sq km
water: 0 sq km
Area— comparative: slightly more than 2 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 101.9km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: antarctic
Terrain: Heard Island— bleak and mountainous, with
a quiescent volcano; McDonald Islands— small and
rocky
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Big Ben 2,745 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: m%
Irrigated land: 0 sq km (1993)
Natural hazards: Heard Island is dominated by a
dormant volcano called Big Ben
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: primarily used for research
stations
Economy— overview: no economic activity
Geographic coordinates: 4 00 N, 56 00 W
Map references: South America
Area:
total: 163,270 sq km
land: 161,470 sq km
water: 1,800 sq km
Area— comparative: slightly larger than Georgia
Land boundaries:
total: 1,707 km
border countries: Brazil 597 km, French Guiana 510
km, Guyana 600 km
Coastline: 386 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds
Terrain: mostly rolling hills; narrow coastal plain with
swamps
Elevation extremes:
lowest point: unnamed location in the coastal plain
-2 m
highest point: Wilhelmina Gebergte 1 ,286 m
Natural resources: timber, hydropower potential,
fish, kaolin, shrimp, bauxite, gold, and small amounts
of nickel, copper, platinum, iron ore
Land use:
arable land: NA
permanent crops: NA
permanent pastures: 0%
forests and woodland: 96%
other: 4% (1993 est.)
Irrigated land: 600 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: deforestation as
timber is cut for export; pollution of inland waterways
by small-scale mining activities
Suriname (continued)
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Law of the Sea
Geography— note: mostly tropical rain forest; great
diversity of flora and fauna which for the most part is
increasingly threatened by new development;
relatively small population most of which lives along
the coast
Location: Northern Europe, islands between the
Arctic Ocean, Barents Sea, Greenland Sea, and
Norwegian Sea, north of Norway
Geographic coordinates: 78 00 N, 20 00 E
Map references: Arctic Region
Area:
total : 62,049 sq km
land: 62,049 sq km
water: 0 sq km
note: includes Spitsbergen and Bjornoya (Bear
Island)
Area— comparative: slightly smaller than West
Virginia
Land boundaries: 0 km
Coastline: 3,587 km
Maritime claims:
exclusive fishing zone: 200 nm unilaterally claimed by
Norway but not recognized by Russia
territorial sea: 4 nm
Climate: arctic, tempered by warm North Atlantic
Current; cool summers, cold winters; North Atlantic
Current flows along west and north coasts of
Spitsbergen, keeping water open and navigable most
of the year
Terrain: wild, rugged mountains; much of high land
ice covered; west coast clear of ice about one-half of
the year; fjords along west and north coasts
Elevation extremes:
lowest point : Arctic Ocean 0 m
highest point: Newtontoppen 1,717 m
Natural resources: coal, copper, iron ore,
phosphate, zinc, wildlife, fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (no trees and the only bushes are
crowberry and cloudberry)
Irrigated land: NAsqkm
Natural hazards: ice floes often block up the
entrance to Bellsund (a transit point for coal export) on
the west coast and occasionally make parts of the
northeastern coast inaccessible to maritime traffic
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed , but not ratified: NA
Geography— note: northernmost part of the
Kingdom of Norway; consists of nine main islands;
glaciers and snowfields cover 60% of the total area
Location: Southern Africa, between Mozambique
and South Africa
Geographic coordinates: 26 30 S, 31 30 E
Map references: Africa
Area:
total: 17,360 sq km
land: 17,200 sq km
water: 160 sq km
Area— comparative: slightly smaller than New','432b460a8c1a5f87e931ea8825662c464133a297efeb7fa05bb10ddf810f06d1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7a569d36b76f1dd43697136f6520310a91909e1ae2a1ecd5969323449ef4459',1998,'HU','Hungary','geography',476,'Location: Central Europe, northwest of Romania
Geographic coordinates: 47 00 N, 20 00 E
Map references: Europe
Area:
total: 93,030 sq km
land: 92,340 sq km
water: 690 sq km
Area— comparative: slightly smaller than Indiana
Land boundaries:
total: 2,009 km
border countries: Austria 366 km, Croatia 329 km,
Romania 443 km, Serbia and Montenegro 151 km (all
with Serbia), Slovakia 515 km, Slovenia 102 km,
Ukraine 103 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cold, cloudy, humid winters;
warm summers
Terrain: mostly flat to rolling plains; hills and low
mountains on the Slovakian border
Elevation extremes:
lowest point : Tisza River 78 m
highest point: Kekes 1 ,014 m
Natural resources: bauxite, coal, natural gas, fertile
soils
Land use:
arable land: 51%
permanent crops: 2%
permanent pastures: 1 3%
forests and woodland: 1 9%
other: 15% (1993 est.)
Irrigated land: 2,060 sq km (1993 est.)
Environment— current issues: the approximation
of Hungary''s standards in waste management, energy
efficiency, and air, soil, and water pollution with
environmental requirements for EU accession will
require large investments, estimated by the
Government of Hungary at $4 billion over six years;
the 1997 budget allocated $9.7 million for this
purpose; the 1 998 budget allocated $11.3 million; the
Central Environmental Fund, which collects monies
from product charges, environmental fines, and
mining taxes, provided approximately $76.2 million in
1 997 and is expected to provide $1 09.5 million in 1 998
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Sulphur 94,
Antarctic-Environmental Protocol, Law of the Sea
Geography— note: landlocked; strategic location
astride main land routes between Western Europe
and Balkan Peninsula as well as between Ukraine and
Mediterranean basin','17d8d0cb72467fd2603ed502b2836044db3e216d8ceea0bec48a1cd5a4f86b74','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f335d755deb3e01035ef34c37767dc84795e4454b66f4ad8efdd148018a0d090',1998,'IS','Iceland','geography',484,'Location: Northern Europe, island between the
Greenland Sea and the North Atlantic Ocean,
northwest of the UK
Geographic coordinates: 65 00 N, 18 00 W
Map references: Arctic Region
Area:
total: 103,000 sq km
land: 100,250 sq km
water: 2,750 sq km
Area— comparative: slightly smaller than Kentucky
Land boundaries: 0 km
Coastline: 4,988 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; moderated by North Atlantic
Current; mild, windy winters; damp, cool summers
Terrain: mostly plateau interspersed with mountain
peaks, icefields; coast deeply indented by bays and
fiords
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Hvannadalshnukur 2,1 1 9 m
Natural resources: fish, hydropower, geothermal
power, diatomite
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 1 %
other: 76% (1993 est.)
Irrigated land: NA sq km
Natural hazards: earthquakes and volcanic activity
Environment— current issues: water pollution from
fertilizer runoff; inadequate wastewater treatment
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification,
Marine Life Conservation
Geography— note: strategic location between
Greenland and Europe; westernmost European
country; more land covered by glaciers than in all of
continental Europe
Geographic coordinates: 71 00 N, 8 00 W
Map references: Arctic Region
Area:
total: 373 sq km
land: 373 sq km
water: Osq km
Area-comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 124.1 km
Maritime claims:
contiguous zone: 1 0 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 4 nm
Climate: arctic maritime with frequent storms and
persistent fog
Terrain: volcanic island, partly covered by glaciers
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Haakon VII Toppen/Beerenberg 2,277
m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: Osq km (1993)
Natural hazards: dominated by the volcano
Beerenberg; volcanic activity resumed in 1970
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Geography— note: barren volcanic island with some
moss and grass','01fa5c75b54b930450e84da017b1875c129fd62b69fbc8b3f47e1058f9473f7d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9e015aff40c1f6e01c475eff3311a57b27470f38359ac64fc37122923dcf0b4',1998,'IN','India','geography',493,'Location: Southern Asia, bordering the Arabian Sea
and the Bay of Bengal, between Burma and Pakistan
Geographic coordinates: 20 00 N, 77 00 E
Map references: Asia
Area:
total: 3,287,590 sq km
land: 2,973, 190 sq km
water: 31 4,400 sq km
Area— comparative: slightly more than one-third the
size of the US
Land boundaries:
total: 14,103 km
border countries: Bangladesh 4,053 km, Bhutan
605 km, Burma 1,463 km, China 3,380 km, Nepal
1,690 km, Pakistan 2,912 km
Coastline: 7,000 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical monsoon in south to
temperate in north
Terrain: upland plain (Deccan Plateau) in south, flat
to rolling plain along the Ganges, deserts in west,
Himalayas in north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kanchenjunga 8,598 m
Natural resources: coal (fourth-largest reserves in
the world), iron ore, manganese, mica, bauxite,
titanium ore, chromite, natural gas, diamonds,
petroleum, limestone
Land use:
arable land: 56%
permanent crops: 1%
permanent pastures: 4%
forests and woodland: 23%
of/?er:16% (1993 est.)
Irrigated land: 480,000 sq km (1993 est.)
Natural hazards: droughts, flash floods, severe
thunderstorms common; earthquakes
Environment— current issues: deforestation; soil
erosion; overgrazing; desertification; air pollution from
industrial effluents and vehicle emissions; water
pollution from raw sewage and runoff of agricultural
pesticides; tap water is not potable throughout the
country; huge and rapidly growing population is
overstraining natural resources
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: dominates South Asian
subcontinent; near important Indian Ocean trade
routes
Location: body of water between Africa, Antarctica,
Asia, and Australia
Geographic coordinates: 30 00 S, 80 00 E
Map references: World
Area:
total: 73.6 million sq km
note: includes Andaman Sea, Arabian Sea, Bay of
Bengal, Great Australian Bight, Gulf of Aden, Gulf of
Oman, Mozambique Channel, Persian Gulf, Red Sea,
Strait of Malacca, and other tributary water bodies
Area— comparative: slightly less than eight times
the size of the US; third-largest ocean (after the
Pacific Ocean and Atlantic Ocean, but larger than the
Arctic Ocean)
Coastline: 66,526 km
Climate: northeast monsoon (December to April),
southwest monsoon (June to October); tropical
cyclones occur during May/June and October/
November in the northern Indian Ocean and January/
February in the southern Indian Ocean
Terrain: surface dominated by counterclockwise
gyre (broad, circular system of currents) in the
southern Indian Ocean; unique reversal of surface
currents in the northern Indian Ocean; low
atmospheric pressure over southwest Asia from hot,
rising, summer air results in the southwest monsoon
and southwest-to-northeast winds and currents, while
high pressure over northern Asia from cold, falling,
winter air results in the northeast monsoon and
northeast-to-southwest winds and currents; ocean
floor is dominated by the Mid-Indian Ocean Ridge and
subdivided by the Southeast Indian Ocean Ridge,
Southwest Indian Ocean Ridge, and Ninety East
Ridge
Elevation extremes:
lowest point: Java Trench -7,258 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, shrimp,
sand and gravel aggregates, placer deposits,
polymetallic nodules
Natural hazards: ships subject to superstructure
icing in extreme south near Antarctica from May to
October
Environment— current issues: endangered marine
species include the dugong, seals, turtles, and
whales; oil pollution in the Arabian Sea, Persian Gulf,
and Red Sea
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography— note: major chokepoints include Bab
el Mandeb, Strait of Hormuz, Strait of Malacca,
southern access to the Suez Canal, and the Lombok
Strait','82af12b8e16472206b0a74d254afb6847341372053a56841aae5ed53e951ac29','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b548ee65d8a821c6717f68dced5243f9fedaee44a253db8ce6039e43d099ace',1998,'IE','Ireland','geography',500,'Location: Western Europe, occupying five-sixths of
the island of Ireland in the North Atlantic Ocean, west
of Great Britain
Geographic coordinates: 53 00 N, 8 00 W
Map references: Europe
Area:
total: 70,280 sq km
land: 68,890 sq km
water: 1 ,390 sq km
Area— comparative: slightly larger than West
Virginia
Land boundaries:
total: 360 km
border countries: UK 360 km
Coastline: 1,448 km
Maritime claims:
continental shelf: not specified
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: temperate maritime; modified by North
Atlantic Current; mild winters, cool summers;
consistently humid; overcast about half the time
Terrain: mostly level to rolling interior plain
surrounded by rugged hills and low mountains; sea
cliffs on west coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Carrauntoohill 1,041 m
Natural resources: zinc, lead, natural gas, barite,
copper, gypsum, limestone, dolomite, peat, silver
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 68%
forests and woodland: 5%
other: 14% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment— current issues: water pollution,
especially of lakes, from agricultural runoff
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Biodiversity, Climate Change, Desertification,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Wetlands, Whaling
signed, but not ratified: Air Pollution-Sulphur 94,
Endangered Species, Marine Life Conservation,
Tropical Timber 94
Geography— note: strategic location on major air
and sea routes between North America and northern
Europe; over 40% of the population resides within
60 miles of Dublin
Land boundaries:
total: 1 ,006 km
border countries: Egypt 255 km, Gaza Strip 51 km,
Jordan 238 km, Lebanon 79 km, Syria 76 km, West
Bank 307 km
Coastline: 273 km
Maritime claims:
continental shelf : to depth of exploitation
territorial sea: 1 2 nm
Climate: temperate; hot and dry in southern and
eastern desert areas
Terrain: Negev desert in the south; low coastal plain;
central mountains; Jordan Rift Valley
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Har Meron 1 ,208 m
Natural resources: copper, phosphates, bromide,
potash, clay, sand, sulfur, asphalt, manganese, small
amounts of natural gas and crude oil
Land use:
arable land: 17%
permanent crops: 4%
permanent pastures: 7%
forests and woodland: 6%
of/?er; 66% (1993 est.)
Irrigated land: 1 ,800 sq km (1993 est.)
Natural hazards: sandstorms may occur during
spring and summer
Environment— current issues: limited arable land
and natural fresh water resources pose serious
constraints; desertification; air pollution from industrial
and vehicle emissions; groundwater pollution from
industrial and domestic waste, chemical fertilizers,
and pesticides
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography— note: there are 207 Israeli settlements
and civilian land use sites in the West Bank, 42 in the
Israeli-occupied Golan Heights, 24 in the Gaza Strip,
and 29 in East Jerusalem (August 1997 est.)','7acad256b4dfc48a9ab9c763447790910ef598f7d7e21df7a3b123aaacc7342c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd9dce3337f41afdb2fa84f3255e6ffe9397249c685ae431314b480b6e3f8af1',1998,'TN','Tunisia','geography',509,'Geographic coordinates: 42 50 N, 12 50 E
Map references: Europe
Area:
total: 301 ,230 sq km
land: 294,020 sq km
water: 7,21 0 sq km
note: includes Sardinia and Sicily
Area— comparative: slightly larger than Arizona
Land boundaries:
total: 1,932.2 km
border countries: Austria 430 km, France 488 km,
Holy See (Vatican City) 3.2 km, San Marino 39 km,
Slovenia 232 km, Switzerland 740 km
Coastline: 7,600 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 1 2 nm
Climate: predominantly Mediterranean; Alpine in far
north; hot, dry in south
Terrain: mostly rugged and mountainous; some
plains, coastal lowlands
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Blanc 4,807 m
Natural resources: mercury, potash, marble, sulfur,
dwindling natural gas and crude oil reserves, fish, coal
Land use:
arable land: 31%
permanent crops: 1 0%
permanent pastures: 1 5%
forests and woodland: 23%
other: 21% (1993 est.)
Irrigated land: 27,100 sq km (1993 est.)
Natural hazards: regional risks include landslides,
mudflows, avalanches, earthquakes, volcanic
eruptions, flooding; land subsidence in Venice
233
Italy (continued)
Environment— current issues: air pollution from
industrial emissions such as sulfur dioxide; coastal and
inland rivers polluted from industrial and agricultural
effluents; acid rain damaging lakes; inadequate
industrial waste treatment and disposal facilities
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Sulphur 94,
Tropical Timber 94
Geography— note: strategic location dominating
central Mediterranean as well as southern sea and air
approaches to Western Europe
Location: Northern Africa, bordering the
Mediterranean Sea, between Algeria and Libya
Geographic coordinates: 34 00 N, 9 00 E
Map references: Africa
Area:
total: 163,610 sq km
land: 155, 360 sq km
water: 8,250 sq km
Area— comparative: slightly larger than Georgia
Land boundaries:
total: 1,424 km
border countries: Algeria 965 km, Libya 459 km
Coastline: 1,148 km
Maritime claims:
contiguous zone: 24 nm
territorial sea: 12 nm
Climate: temperate in north with mild, rainy winters
and hot, dry summers; desert in south
Terrain: mountains in north; hot, dry central plain;
semiarid south merges into the Sahara
Elevation extremes:
lowest point: Shaft a! Gharsah -17 m
highest point: Jabal ash Shanabi 1 ,544 m
Natural resources: petroleum, phosphates, iron
ore, lead, zinc, salt
Land use:
arable land: 19%
permanent crops: 1 3%
permanent pastures: 20%
forests and woodland: 4%
other: 44% (1993 est.)
Irrigated land: 3,850 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: toxic and
hazardous waste disposal is ineffective and presents
human health risks; water pollution from raw sewage;
limited natural fresh water resources; deforestation;
overgrazing; soil erosion; desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography— note: strategic location in central
Mediterranean
Location: southwestern Asia (that part west of the
Bosporus is sometimes included with Europe),
bordering the Black Sea, between Bulgaria and
Georgia, and bordering the Aegean Sea and the
Mediterranean Sea, between Greece and Syria
Geographic coordinates: 39 00 N, 35 00 E
Map references: Middle East
Area:
total: 780,580 sq km
land: 770,760 sq km
water: 9,820 sq km
Area— comparative: slightly larger than Texas
Land boundaries:
total: 2,627 km
border countries: Armenia 268 km, Azerbaijan 9 km,
Bulgaria 240 km, Georgia 252 km, Greece 206 km,
Iran 499 km, Iraq 331 km, Syria 822 km
Coastline: 7,200 km
Maritime claims:
exclusive economic zone: in Black Sea only— to the
maritime boundary agreed upon with the former
USSR
territorial sea: 6 nm in the Aegean Sea,; 12 nm in the
Black Sea and in the Mediterranean Sea
Climate: temperate; hot, dry summers with mild, wet
winters; harsher in interior
Terrain: mostly mountains; narrow coastal plain;
high central plateau (Anatolia)
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Ararat 5,166 m
Natural resources: antimony, coal, chromium,
mercury, copper, borate, sulfur, iron ore
Land use:
arable land: 32%
permanent crops: 4%
permanent pastures: 1 6%
forests and woodland: 26%
other: 22% (1993 est.)
Irrigated land: 36,740 sq km (1993 est.)
Natural hazards: very severe earthquakes,
especially in northern Turkey, along an arc extending
from the Sea of Marmara to Lake Van
Environment— current issues: water pollution from
dumping of chemicals and detergents; air pollution,
particularly in urban areas; deforestation; concern for
oil spills from increasing Bosporus ship traffic
Environment— international agreements:
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Desertification, Hazardous Wastes, NuclearTest Ban,
Ozone Layer Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: Antarctic-Environmental
Protocol, Environmental Modification
Geography— note: strategic location controlling the
Turkish Straits (Bosporus, Sea of Marmara,
Dardanelles) that link Black and Aegean Seas','d33cc66bf901c269654f7f6984b6c07f3bd0751fa7a75821ce413ef31619357e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('311258f702cb1d0025314089dfd49aa4d1141bbd33fc808ce6f433a6bca0aef9',1998,'JM','Jamaica','geography',518,'Location: Caribbean, island in the Caribbean Sea,
south of Cuba
Geographic coordinates: 18 15 N, 77 30 W
Map references: Central America and the
Caribbean
Area:
total: 10,990 sq km
land: 10,830 sq km
water: 160 sq km
Area— comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 1,022 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; temperate interior
Terrain: mostly mountains with narrow,
discontinuous coastal plain
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Blue Mountain Peak 2,256 m
Natural resources: bauxite, gypsum, limestone
Land use:
arable land: 14%
permanent crops: 6%
permanent pastures: 24%
forests and woodland: 17%
of/7er; 39% (1993 est.)
note: irrigated land— 3% (350 sq km)(1 993 est.)
Irrigated land: 350 sq km (1993 est.)
Natural hazards: hurricanes (especially July to
November)
Environment— current issues: deforestation;
coastal waters polluted by industrial waste, sewage,
and oil spills; damage to coral reefs; air pollution in
Kingston results from vehicle emissions
Environment— international agreements:
party fo; Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Whaling
signed , but not ratified: none of the selected
agreements
Geography— note: strategic location between
Cayman Trench and Jamaica Channel, the main sea
lanes for Panama Canal
Location: Northern Europe, island between the
Greenland Sea and the Norwegian Sea, northeast of','942a97c105eef5eb5b8af6fd0d5640200e1a6507e40b7c58b6eb97100be9a243','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bc9aea84512349ef0c0cea2e5a43dcf75556ee2d1c5eb994364ac72698e3dc6',1998,'KE','Kenya','geography',533,'Location: Eastern Africa, bordering the Indian
Ocean, between Somalia and Tanzania
Geographic coordinates: 1 00 N, 38 00 E
Map references: Africa
Area:
total: 582,650 sq km
land: 569,250 sq km
water: 13,400 sq km
Area— comparative: slightly more than twice the
size of Nevada
Land boundaries:
total: 3,446 km
border countries: Ethiopia 830 km, Somalia 682 km,
Sudan 232 km, Tanzania 769 km, Uganda 933 km
Coastline: 536 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical along coast to arid in
interior
Terrain: low plains rise to central highlands bisected
by Great Rift Valley; fertile plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mount Kenya 5, 1 99 m
Natural resources: gold, limestone, soda ash, salt
barytes, rubies, fluorspar, garnets, wildlife
Land use:
arable land: 7%
permanent crops: 1%
permanent pastures: 37%
forests and woodland: 30%
other: 25% (1993 est.)
Irrigated land: 660 sq km (1993 est.)
Natural hazards: recurring drought in northern and
eastern regions
Environment— current issues: water pollution from
urban and industrial wastes; degradation of water
quality from increased use of pesticides and fertilizers;
deforestation; soil erosion; desertification; poaching
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: the Kenyan Highlands comprise
one of the most successful agricultural production
regions in Africa; glaciers on Mt. Kenya; unique
physiography supports abundant and varied wildlife of
scientific and economic value
Location: Oceania, reef in the North Pacific Ocean,
about one-half of the way from Hawaii to American','12a54e936ed01f74a4823e770374646b478d1012ee83930c852b38fae4b71bae','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24630b605c3b27a7529dba188cc94ae442da1cdba984a350cf20db933c48d222',1998,'WS','Samoa','geography',541,'Geographic coordinates: 6 24 N, 162 24 W
Map references: Oceania
Area:
total: 1 sq km
land: 1 sq km
water: 0 sq km
Area— comparative: about 1 .7 times the size of The
Mall in Washington, DC
Land boundaries: Okm
Coastline: 3 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but moderated by prevailing winds
Terrain: low and nearly level
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 1 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1996)
Natural hazards: wet or awash most of the time,
maximum elevation of about 1 meter makes Kingman
Reef a maritime hazard
Environment— current issues: none
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Geography— note: barren coral atoll with deep
interior lagoon; closed to the public
Geographic coordinates: 5 52 N, 162 06 W
Map references: Oceania
Area:
total: 11.9 sq km
land: 11.9 sq km
water: 0 sq km
Area— comparative: about 20 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 14.5 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: equatorial, hot, and very rainy
Terrain: very low
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 2 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 1 00%
other: 0%
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: about 50 islets covered with
dense vegetation, coconut trees, and balsa-like trees
up to 30 meters tall
Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Colombia and Costa Rica
Geographic coordinates: 9 00 N, 80 00 W
Map references: Central America and the
Caribbean
Area:
total: 78,200 sq km
land: 75,990 sq km
water: 2,21 Osq km
Area— comparative: slightly smaller than South
Carolina
Land boundaries:
total: 555 km
border countries: Colombia 225 km, Costa Rica 330
km
Coastline: 2,490 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid, cloudy; prolonged rainy
season (May to January), short dry season (January
to May)
Terrain: interior mostly steep, rugged mountains and
dissected, upland plains; coastal areas largely plains
and rolling hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Volcan de Chiriqui 3,475 m
Natural resources: copper, mahogany forests,
shrimp
Land use:
arable land: 7%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 44%
other: 27% (1993 est.)
Irrigated land: 320 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: water pollution from
agricultural runoff threatens fishery resources;
deforestation of tropical rain forest; land degradation
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed , but not ratified: Marine Life Conservation
Geography— note: strategic location on eastern end
of isthmus forming land bridge connecting North and
South America; controls Panama Canal that links
North Atlantic Ocean via Caribbean Sea with North
Pacific Ocean
Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 13 35 S, 172 20 W
Map references: Oceania
Area:
total: 2,860 sq km
land: 2,850 sq km
water: 10 sq km
Area-comparative: slightly smaller than Rhode
island
Land boundaries: 0 km
Coastline: 403 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy season (October to March),
dry season (May to October)
Terrain: narrow coastal plain with volcanic, rocky,
rugged mountains in interior
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mauga Silisili 1,857 m
Natural resources: hardwood forests, fish
Land use:
arable land: 19%
permanent crops: 24%
permanent pastures: 0%
forests and woodland: 47%
other: 10%
Irrigated land: NA sq km
Natural hazards: occasional typhoons; active
volcanism
Environment— current issues: soil erosion
Environment— international agreements:
party to: Biodiversity, Climate Change, Law of the
Sea, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Climate Change-Kyoto
Protocol
South Pacific Ocean
Population: 224,713 (July 1998 est.)
note: other estimates range as low as 162,000
Age structure:
0-14 years: 39% (male 44,991 ; female 43,537)
15-64 years: 57% (male 66,201 ; female 60,764)
65 years and over: 4% (male 4,352; female 4,868)
(July 1998 est.)
Population growth rate: 2.33% (1998 est.)
Birth rate: 29.62 births/1 ,000 population (1 998 est.)
Death rate: 5.51 deaths/1 ,000 population (1 998 est.)
Net migration rate: -0.8 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/fema!e
15-64 years: 1 .09 male(s)/female
65 years and over: 0.89 ma!e(s)/female (1998 est.)
Infant mortality rate: 31 .76 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 69.45 years
male: 67.07 years
female : 71 .96 years (1 998 est.)
Total fertility rate: 3.72 children born/woman (1998
est.)
Nationality:
noun: Samoan(s)
adjective: Samoan
Ethnic groups: Samoan 92.6%, Euronesians 7%
(persons of European and Polynesian blood),
Europeans 0.4%
Religions: Christian 99.7% (about one-half of
population associated with the London Missionary
Society; includes Congregational, Roman Catholic,
Methodist, Latter-Day Saints, Seventh-Day Adventist)
Languages: Samoan (Polynesian), English
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 97%
female: 97% (1971 est.)
Location: Southern Europe, an enclave in central','2f0235466fd5c7007052cfd6882305347da845056fdb35945dfbb66f0d7467e1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bed039b361d8307794003f1cb2aca41929eb9d266161b16b5d57990389ef02cb',1998,'KI','Kiribati','geography',549,'Location: Oceania, group of islands in the Pacific
Ocean, straddling the equator, about one-half of the
way from Hawaii to Australia; note— on 1 January
1995, Kiribati unilaterally moved the International
Date Line from the middle of the country to include its
easternmost islands and make it the same day
throughout the country
Geographic coordinates: 1 25 N, 173 00 E
Map references: Oceania
Area:
total: 71 7 sq km
land: 71 7 sq km
water: 0 sq km
note: includes three island groups— Gilbert Islands,
Line Islands, Phoenix Islands
Area-comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,143 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine, hot and humid, moderated
by trade winds
Terrain: mostly low-lying coral atolls surrounded by
extensive reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Banaba 81 m
Natural resources: phosphate (production
discontinued in 1979)
Land use:
arable land: NA%
permanent crops: 51%
permanent pastures: NA%
forests and woodland: 3%
other: 46% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: typhoons can occur any time, but
usually November to March; occasional tornadoes
Environment— current issues: heavy pollution in
lagoon of south Tarawa atoll due to heavy migration
mixed with traditional practices such as lagoon
latrines and open-pit dumping; ground water at risk
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Marine Dumping, Ozone Layer Protection,
Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: 20 of the 33 islands are
inhabited; Banaba (Ocean Island) in Kiribati is one of
the three great phosphate rock islands in the Pacific
Ocean— the others are Makatea in French Polynesia
and Nauru
Location: Eastern Asia, northern half of the Korean
Peninsula bordering the Korea Bay and the Sea of
Japan, between China and South Korea
Geographic coordinates: 40 00 N, 127 00 E
Map references: Asia
Area:
total: 120,540 sq km
land: 120,410 sq km
water: 130 sq km
Area— comparative: slightly smaller than
Mississippi
Land boundaries:
total: 1 ,673 km
border countries: China 1,416 km, South Korea
238 km, Russia 19 km
Coastline: 2,495 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
military boundary line: 50 nm in the Sea of Japan and
the exclusive economic zone limit in the Yellow Sea
where all foreign vessels and aircraft without
permission are banned
Climate: temperate with rainfall concentrated in
summer
Terrain: mostly hills and mountains separated by
deep, narrow valleys; coastal plains wide in west,
discontinuous in east
Elevation extremes:
lowest point: Sea of Japan 0 m
highest point: Paektu-san 2,744 m
Natural resources: coal, lead, tungsten, zinc,
graphite, magnesite, iron ore, copper, gold, pyrites,
salt, fluorspar, hydropower
Irrigated land: 14,600 sq km (1993 est.)
Natural hazards: late spring droughts often followed
by severe flooding; occasional typhoons during the
early fall
Environment— current issues: localized air
pollution attributable to inadequate industrial controls;
water pollution; inadequate supplies of potable water
Environment— international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Environmental Modification, Ozone Layer
Protection, Ship Pollution
signed, but not ratified : Antarctic-Environmental
Protocol, Law of the Sea
Geography— note: strategic location bordering
China, South Korea, and Russia; mountainous interior
is isolated, nearly inaccessible, and sparsely
populated
Location: Eastern Asia, southern half of the Korean
Peninsula bordering the Sea of Japan and the Yellow
Sea
Geographic coordinates: 37 00 N, 127 30 E
Map references: Asia
Area:
total: 98,480 sq km
land: 98,190 sq km
water: 290 sq km
Area— comparative: slightly larger than Indiana
Land boundaries:
total: 238 km
border countries: North Korea 238 km
Coastline: 2,413 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: not specified
exclusive economic zone: 200 nm
territorial sea: 12 nm; 3 nm in the Korea Strait
Climate: temperate, with rainfall heavier in summer
than winter
Terrain: mostly hills and mountains; wide coastal
plains in west and south
Elevation extremes:
lowest point: Sea of Japan 0 m
highest point: Halla-san 1 ,950 m
Natural resources: coal, tungsten, graphite,
molybdenum, lead, hydropower
Land use:
arable land: 19%
permanent crops: 2%
permanent pastures: 1%
forests and woodland: 65%
other: 13% (1993 est.)
Irrigated land: 13,350 sq km (1993 est.)
Natural hazards: occasional typhoons bring high
winds and floods; low-level seismic activity common in
southwest
Environment— current issues: air pollution in large
cities; water pollution from the discharge of sewage
and industrial effluents; drift net fishing
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: Desertification','251801a46e3c0049792697470e43e41dcce6487d0886d5bcc033ca0f495a3d13','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9e1d9757512ba38d40ae51e509af4b1217128069bf71af6356e6e1808aec2d9',1998,'KW','Kuwait','geography',556,'Location: Middle East, bordering the Persian Gulf,
between Iraq and Saudi Arabia
Geographic coordinates: 29 30 N, 45 45 E
Map references: Middle East
Area:
total: 17,820 sq km
land: 17, 820 sq km
water: 0 sq km
Area— comparative: slightly smaller than New','8c17c0f2281fabd1ddb8eb160b027d81eba59ac641234d9b02cd73389fb3a936','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b05eaced30cf28abf568ac75ebf8bdb9f20f11501038478c7ba0f5e99580d17',1998,'KG','Kyrgyzstan','geography',557,'Location: Centra! Asia, west of China
Geographic coordinates: 41 00 N, 75 00 E
Map references: Commonwealth of Independent
States
Area:
total: 198,500 sq km
land: 191 ,300 sq km
water: 7,200 sq km
Area— comparative: slightly smaller than South
Dakota
Land boundaries:
total: 3,878 km
border countries: China 858 km, Kazakhstan 1,051
km, Tajikistan 870 km, Uzbekistan 1 ,099 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: dry continental to polar in high Tien Shan;
subtropical in southwest (Fergana Valley); temperate
in northern foothill zone
Terrain: peaks of Tien Shan and associated valleys
and basins encompass entire nation
Elevation extremes:
lowest point: Kara-Darya 132 m
highest point: Jengish Chokusu (Pik Pobedy) 7,439 m
Natural resources: abundant hydroelectric potential;
significant deposits of gold and rare earth metals;
locally exploitable coal, oil, and natural gas; other
deposits of nepheline, mercury, bismuth, lead, and zinc
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 44%
forests and woodland: 4%
other: 45% (1993 est.)
note: Kyrgyzstan has the world''s largest natural
growth walnut forest
Irrigated land: 9,000 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: water pollution;
many people get their water directly from
contaminated streams and wells; as a result,
water-borne diseases are prevalent; increasing soil
salinity from faulty irrigation practices
Environment— international agreements:
party to: Biodiversity, Desertification, Hazardous
Wastes
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked','7c12c02013e6e27f2344ae024a6e01e8364072563b85a780c58eee3de8bdb516','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc8df94bac6afca7e951ec82a5cd8026867b85706953ef66687d3bcf536a1058',1998,'LV','Latvia','geography',565,'Location: Eastern Europe, bordering the Baltic Sea,
between Estonia and Lithuania
Geographic coordinates: 57 00 N, 25 00 E
Map references: Europe
Area:
total: 64,1 00 sq km
land: 64,1 00 sq km
water: 0 sq km
Area— comparative: slightly larger than West
Virginia
Land boundaries:
total: 1,150 km
border countries: Belarus 141 km, Estonia 339 km,
Lithuania 453 km, Russia 217 km
Coastline: 531 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: maritime; wet, moderate winters
Terrain: low plain
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Gaizinkalns 312 m
Natural resources: minimal; amber, peat,
limestone, dolomite
Land use:
arable land: 27%
permanent crops: 0%
permanent pastures: 1 3%
forests and woodland: 46%
other: 14% (1993 est.)
Irrigated land: 160 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: air and water
pollution because of a lack of waste conversion
equipment; Gulf of Riga and Daugava River heavily
polluted; contamination of soil and groundwater with
chemicals and petroleum products at military bases
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Hazardous Wastes, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements','5d96630feff78b8ad214cbf5b5cc8f36e23c7109f6c32f96ff66a8d6bdcdae35','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd00bf4feaf087cbcfb12ff403238f8011f70edc5864ff158fc70446c56776a7',1998,'FI','Finland','geography',570,'Location: Middle East, bordering the Mediterranean
Sea, between Israel and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references: Middle East
Area:
total: 10,400 sq km
land: 10,230 sq km
water: 170 sq km
Area— comparative: about 0.7 times the size of
Connecticut
Land boundaries:
total: 454 km
border countries: Israel 79 km, Syria 375 km
Coastline: 225 km
Maritime claims:
territorial sea: 12 nm
Climate: Mediterranean; mild to cool, wet winters
with hot, dry summers; Lebanon mountains
experience heavy winter snows
Terrain: narrow coastal plain; Al Biqa'' (Bekaa Valley)
separates Lebanon and Anti-Lebanon Mountains
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point : Jabal al Makmal 3,087 m
Natural resources: limestone, iron ore, salt,
water-surplus state in a water-deficit region
Land use:
arable land: 21%
permanent crops: 9%
permanent pastures: 1 %
forests and woodland: 8%
of/?er; 61% (1993 est.)
Irrigated land: 860 sq km (1993 est.)
Natural hazards: dust storms, sandstorms
Environment— current issues: deforestation; soil
erosion; desertification; air pollution in Beirut from
vehicular traffic and the burning of industrial wastes;
pollution of coastal waters from raw sewage and oil
spills
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Environmental Modification,
Marine Dumping, Marine Life Conservation
Geography— note: Nahr al Litani only major river in
Near East not crossing an international boundary;
rugged terrain historically helped isolate, protect, and
develop numerous factional groups based on religion,
clan, and ethnicity','8308f9e4168082d7d68bc386bf0da6849f5f35e3e8d115e930ecda8711ace9cf','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62e4f94097a082cd64ae930fddb20b07f73cd482c39e83e7db6fce336b2ffe61',1998,'ZA','South Africa','geography',573,'Location: Southern Africa, an enclave of South
Africa
Geographic coordinates: 29 30 S, 28 30 E
Map references: Africa
Area:
total: 30,350 sq km
land: 30,350 sq km
water: 0 sq km
Area— comparative: slightly smaller than Maryland
Land boundaries:
total: 909 km
border countries: South Africa 909 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool to cold, dry winters; hot,
wet summers
Terrain: mostly highland with plateaus, hills, and
mountains
Elevation extremes:
lowest point: junction of the Orange and Makhaleng
Rivers 1,400 m
highest point: Mount Thabana Ntlenyana 3,482 m
Natural resources: water, agricultural and grazing
land, some diamonds and other minerals
Land use:
arable land: 11%
permanent crops: NA%
permanent pastures: 66%
forests and woodland: NA%
other: 23% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: periodic droughts
Environment— current issues: population
pressure forcing settlement in marginal areas results
in overgrazing, severe soil erosion, and soil
exhaustion; desertification; Highlands Water Project
controls, stores, and redirects water to South Africa
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Marine Life Conservation, Ozone
Layer Protection, Wetlands
signed, but not ratified: Endangered Species, Law of
the Sea, Marine Dumping
Geography— note: landlocked; surrounded by
f People
Population: 2,089,829 (July 1998 est.)
Age structure:
0-14 years: 40% (male 420,526; female 419,059)
15-64 years: 55% (male 558,068; female 596,598)
65 years and over: 5% (male 39,782; female 55,796)
(July 1998 est.)
Population growth rate: 1 .91 % (1 998 est.)
Birth rate: 31.84 births/1,000 population (1998 est.)
Death rate: 12.76 deaths/1 ,000 population
(1998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.71 male(s)/fema!e (1 998 est.)
Infant mortality rate: 78.3 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 53.97 years
male: 52.18 years
female: 55.81 years (1998 est.)
Total fertility rate: 4.13 children born/woman
(1998 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic groups: Sotho 99.7%, Europeans 1,600,
Asians 800
Religions: Christian 80%, rest indigenous beliefs
Languages: Sesotho (southern Sotho), English
(official), Zulu, Xhosa
Literacy:
definition: age 15 and over can read and write
total population: 71. 3%
ma/e: 81.1%
female: 62.3% (1995 est.)
Location: Western Africa, bordering the North
Atlantic Ocean, between Cote d''Ivoire and Sierra
Leone
Geographic coordinates: 6 30 N, 9 30 W
Map references: Africa
Area:
total: 1 1 1 ,370 sq km
land: 96,320 sq km
water: 15, 050 sq km
Area— comparative: slightly larger than Tennessee
Land boundaries:
total: 1,585 km
border countries: Guinea 563 km, Cote d''Ivoire 716
km, Sierra Leone 306 km
Coastline: 579 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters with hot
days and cool to cold nights; wet, cloudy summers
with frequent heavy showers
Terrain: mostly flat to rolling coastal plains rising to
rolling plateau and low mountains in northeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Wuteve 1 ,380 m
Natural resources: iron ore, timber, diamonds, gold
Land use:
arable land: 1%
permanent crops: 3%
permanent pastures: 59%
forests and woodland: 1 8%
other: 19% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: dust-laden harmattan winds blow
from the Sahara (December to March)
Environment— current issues: tropical rain forest
subject to deforestation; soil erosion; loss of
biodiversity; pollution of rivers from the dumping of
iron ore tailings and of coastal waters from oil residue
and raw sewage
Environment— international agreements:
party to: Desertification, Endangered Species,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Biodiversity, Climate Change,
Environmental Modification, Law of the Sea, Marine
Dumping, Marine Life Conservation','0455b75c5066c7b904f398128828fa778c29836e09e2e15ee842f29829c71703','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46c67e1b0e1f4faeb3cb525219ed093af147fef5a0970a237b9ce0180197c51e',1998,'LY','Libya','geography',580,'Location: Northern Africa, bordering the
Mediterranean Sea, between Egypt and Tunisia
Geographic coordinates: 25 00 N, 17 00 E
Map references: Africa
Area:
total: 1,759,540 sq km
land: 1,759,540 sq km
water: 0 sq km
Area— comparative: slightly larger than Alaska
Land boundaries:
total: 4,383 km
border countries: Algeria 982 km, Chad 1 ,055 km,
Egypt 1,150 km, Niger 354 km, Sudan 383 km,
Tunisia 459 km
Coastline: 1,770 km
Maritime claims:
territorial sea: 1 2 nm
note: Gulf of Sidra closing line— 32 degrees 30
minutes north
Climate: Mediterranean along coast; dry, extreme
desert interior
Terrain: mostly barren, flat to undulating plains,
plateaus, depressions
Elevation extremes:
lowest point: Sabkhat Ghuzayyil -47 m
highest point: Bikku Bitti 2,267 m
Natural resources: petroleum, natural gas, gypsum
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 0%
other: 91% (1993 est.)
Irrigated land: 4,700 sq km (1993 est.)
Natural hazards: hot, dry, dust-laden ghibli is a
southern wind lasting one to four days in spring and
fall; dust storms, sandstorms
Environment— current issues: desertification; very
limited natural fresh water resources; the Great
Manmade River Project, the largest water
development scheme in the world, is being built to
bring water from large aquifers under the Sahara to
coastal cities
Environment— international agreements:
party to: Desertification, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection
signed, but not ratified: Biodiversity, Climate Change,
Law of the Sea','52b94cbc3ed39ecf47f26e4d914d066be12bdadebeb6c312ba473669a716b259','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce7862d5550a7b2b3a21a0f872486ef3e42b664efde42a4919471db562868008',1998,'CH','Switzerland','geography',588,'Geographic coordinates: 47 10 N, 9 32 E
Map references: Europe
Area:
total: 160 sq km
land: 160 sq km
water: Osq km
Area— comparative: about 0.9 times the size of
Washington, DC
Land boundaries:
total: 76 km
border countries: Austria 35 km, Switzerland 41 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: continental; cold, cloudy winters with
frequent snow or rain; cool to moderately warm,
cloudy, humid summers
Terrain: mostly mountainous (Alps) with Rhine
Valley in western third
Elevation extremes:
lowest point: Ruggeller Riet 430 m
highest point: Grauspitz 2,599 m
Natural resources: hydroelectric potential
Land use:
arable land: 24%
permanent crops: 0%
permanent pastures: 1 6%
forests and woodland: 35%
other: 25% (1993 est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change, Endangered Species, Hazardous
Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography— note: along with Uzbekistan, one of
the only two doubly landlocked countries in the world;
variety of microclimatic variations based on elevation
Location: Eastern Europe, bordering the Baltic Sea,
between Latvia and Russia
Geographic coordinates: 56 00 N, 24 00 E
Map references: Europe
Area:
total: 65,200 sq km
land: 65,200 sq km
water: 0 sq km
Area— comparative: slightly larger than West Virginia
Land boundaries:
total: 1,273 km
border countries: Belarus 502 km, Latvia 453 km,
Poland 91 km, Russia (Kaliningrad) 227 km
Coastline: 99 km
Maritime claims:
territorial sea: 12 nm
Climate: transitional, between maritime and
continental; wet, moderate winters and summers
Terrain: lowland, many scattered small lakes, fertile
soil
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Juozapines/Kalnas 292 m
Natural resources: peat
Land use:
arable land: 35%
permanent crops: 12%
permanent pastures: 7%
forests and woodland: 31 %
other: 15% (1993 est.)
Irrigated land: 430 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: contamination of
soil and groundwater with petroleum products and
chemicals at military bases
Environment— international agreements:
party to: Biodiversity, Climate Change, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Location: Western Europe, between France and
Location: Central Europe, east of France, north of','04b46d14b49060450ba2f103dd9bb40d4e06fcdef508bfde8843cf9dc764be23','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1072d3c3923ba55e1eed57c6a42ff93b7e1505e4d15338035a2f4e85e6f77b10',1998,'PT','Portugal','geography',596,'Location: Southeastern Europe, north of Greece
Geographic coordinates: 41 50 N, 22 00 E
Map references: Europe
Area:
total: 25,333 sq km
land: 24,856 sq km
water: 477 sq km
Area— comparative: slightly larger than Vermont
Land boundaries:
total: 748 km
border countries: Albania 151 km, Bulgaria 148 km,
Greece 228 km, Serbia and Montenegro 221 km (all
with Serbia)
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: hot, dry summers and autumns and
relatively cold winters with heavy snowfall
Terrain: mountainous territory covered with deep
basins and valleys; there are three large lakes, each
divided by a frontier line; country bisected by the
Vardar River
Elevation extremes:
lowest point: Vardar River 50 m
highest point: Korab 2,753 m
Natural resources: chromium, lead, zinc,
manganese, tungsten, nickel, low-grade iron ore,
asbestos, sulfur, timber
Land use:
arable land: 24%
permanent crops: 2%
permanent pastures: 25%
forests and woodland: 39%
other: 10% (1993 est.)
Irrigated land: 830 sq km (1 993 est.)
Natural hazards: high seismic risks
Environment— current issues: air pollution from
metallurgical plants
284
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked; major transportation
corridor from Western and Central Europe to Aegean
Sea and Southern Europe to Western Europe','8ab47f4321fb30913aa772602a4657814f6ea3e85c7c7cd4304e31da5a51503f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df800e5f69d9573510c7c13e5c2e63e5e3c9306e4b710e4c58c43bbabf86a520',1998,'MW','Malawi','geography',598,'Location: Southern Africa, east of Zambia
Geographic coordinates: 13 30 S, 34 00 E
Map references: Africa
Area:
total: 11 8,480 sq km
land: 94,080 sq km
water: 24,400 sq km
Area— comparative: slightly smaller than
Pennsylvania
Land boundaries:
total: 2,881 km
border countries: Mozambique 1,569 km, Tanzania
475 km, Zambia 837 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; rainy season (November to May);
dry season (May to November)
Terrain: narrow elongated plateau with rolling plains,
rounded hills, some mountains
Elevation extremes:
lowest point: junction of the Shire River and
international boundary with Mozambique 37 m
highest point: Mount Mlanje Sapitwa 3,002 m
Natural resources: limestone, unexploited deposits
of uranium, coal, and bauxite
Land use:
arable land: 18%
permanent crops: 0%
permanent pastures: 20%
forests and woodland: 39%
other: 23% (1993 est.)
Irrigated land: 280 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: deforestation; land
degradation; water pollution from agricultural runoff,
sewage, industrial wastes; siltation of spawning
grounds endangers fish populations
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography— note: landlocked','311fe45fa921247361bb08340d8aac02cc57fab25fb6918d4df0d635ce46d313','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87bf46c7169af3d3b4c2ddb8158fdb9a189c4f3b66f9626899084632949b9b1c',1998,'MV','Maldives','geography',608,'Location: Southern Asia, group of atolls in the Indian
Ocean, south-southwest of India
Geographic coordinates: 3 15 N, 73 00 E
Map references: Asia
Area:
total: 300 sq km
land: 300 sq km
water: 0 sq km
Area— comparative: about 1 .7 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 644 km
Maritime claims:
exclusive economic zone: 35-31 0 nm as defined by
geographic coordinates; segment of zone coincides
with maritime boundary with India
territorial sea: 12 nm
Climate: tropical; hot, humid; dry, northeast
monsoon (November to March); rainy, southwest
monsoon (June to August)
Terrain: flat, with white sandy beaches
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Wilingili 24 m
Natural resources: fish
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 3%
forests and woodland : 3%
other: 84% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: low level of islands makes them
very sensitive to sea level rise
Environment— current issues: depletion of
freshwater aquifers threatens water supplies
Environment— international agreements:
party to: Biodiversity, Climate Change, Hazardous
Wastes, Ozone Layer Protection
293
Maldives (continued)
signed, but not ratified: Climate Change-Kyoto
Protocol, Law of the Sea
Geography— note: 1 ,1 90 coral islands grouped into
26 atolls; archipelago of strategic location astride and
along major sea lanes in Indian Ocean
Location: Southern Europe, islands in the
Mediterranean Sea, south of Sicily (Italy)
Geographic coordinates: 35 50 N, 14 35 E
Map references: Europe
Area:
total: 320 sq km
land: 320 sq km
water: 0 sq km
Area— comparative: slightly less than twice the size
of Washington, DC
Land boundaries: 0 km
Coastline: 140 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 25 nm
territorial sea: 12 nm
Climate: Mediterranean with mild, rainy winters and
hot, dry summers
Terrain: mostly low, rocky, flat to dissected plains;
many coastal cliffs
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Dingli Cliffs 245 m
Natural resources: limestone, salt
Land use:
arable land: 38%
permanent crops: 3%
permanent pastures: N A%
forests and woodland: NA%
other: 59% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: very limited natural
fresh water resources; increasing reliance on
desalination
Environment— international agreements:
party to: Air Pollution, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection/Ship Pollution, Wetlands, Whaling
signed, but not ratified: Biodiversity, Climate
Change-Kyoto Protocol
Geography— note: the country comprises an
archipelago, with only the three largest islands (Malta,
Gozo, and Comino) being inhabited; numerous bays
provide good harbors
Location: Western Europe, island in the Irish Sea,
between Great Britain and Ireland
Geographic coordinates: 54 15 N, 4 30 W
Map references: Europe
Area:
total: 588 sq km
land: 588 sq km
water: 0 sq km
Area— comparative: slightly more than three times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 113 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 12 nm
Climate: cool summers and mild winters; humid;
overcast about half the time
Terrain: hills in north and south bisected by central
valley
Elevation extremes:
lowest point: Irish Sea 0 m
highest point: Snaefell 620 m
Natural resources: lead, iron ore
Land use:
arable land: NA%
permanent crops: N A%
permanent pastures: NA%
forests and woodland: NA%
other: NA% (extensive arable land and forests)
Irrigated land: NAsqkm
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: one small islet, the Calf of Man,
lies to the southwest, and is a bird sanctuary','45a3d570109004c40685c0d85071b13a2fe62ded0cdbe29a18ab3c5382f376e2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f011f251e6a27d0842f747bbf8e0fea1986bfc433cc67d0c9f5fd0b0feaabce6',1998,'MH','Marshall Islands','geography',614,'Location: Oceania, group of atolls and reefs in the
North Pacific Ocean, about one-half of the way from
Hawaii to Papua New Guinea
Geographic coordinates: 9 00 N, 168 00 E
Map references: Oceania
Area:
total: 181.3 sq km
land: 181 .3 sq km
water: 0 sq km
note: includes the atolls of Bikini, Enewetak, and
Kwajalein
Area— comparative: about the size of Washington,
DC
Land boundaries: Okm
Coastline: 370.4 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: wet season from May to November; hot and
humid; islands border typhoon belt
Terrain: low coral limestone and sand islands
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Likiep 10 m
Natural resources: phosphate deposits, marine
products, deep seabed minerals
Land use:
arable land: NA%
permanent crops: 60%
permanent pastures: N A%
forests and woodland: NA%
other: 40%
Irrigated land: NAsqkm
Natural hazards: occasional typhoons
Environment— current issues: inadequate
supplies of potable water
Environment— international agreements:
party to: Biodiversity, Climate Change, Law of the
Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography— note: two archipelagic island chains of
30 atolls and 1,152 islands; Bikini and Enewetak are
former US nuclear test sites; Kwajalein, the famous
World War II battleground, is now used as a US
missile test range
Location: Caribbean, island in the Caribbean Sea,
north of Trinidad and Tobago
Geographic coordinates: 14 40 N, 61 00 W
Map references: Central America and the
Caribbean
Area:
total: 1,100 sq km
land: 1 ,060 sq km
water: 40 sq km
Area— comparative: slightly more than six times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical; moderated by trade winds; rainy
season (June to October); vulnerable to devastating
cyclones (hurricanes) every eight years on average;
average temperature 17.3 degrees C; humid
Terrain: mountainous with indented coastline;
dormant volcano
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Montagne Pelee 1,397 m
Natural resources: coastal scenery and beaches,
cultivable land
Land use:
arable land: 8%
permanent crops: 8%
permanent pastures: 17%
forests and woodland: 44%
other: 23% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: hurricanes, flooding, and volcanic
activity (an average of one major natural disaster
every five years)
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA','ab04dc5c6a0d8ce58051401393583e99138b548e570246ad2216dcff8b3a0306','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ed7d0574d9412ffec2e1f184883b7feb14aa371fad7ae2f1e758f836825f741',1998,'MU','Mauritius','geography',626,'Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 20 17 S, 57 33 E
Map references: World
Area:
total: 1,860 sq km
land: 1,850 sq km
water: 10 sq km
note: includes Agalega Islands, Cargados Carajos
Shoals (Saint Brandon), and Rodrigues
Area— comparative: almost 1 1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 177 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, modified by southeast trade winds;
warm, dry winter (May to November); hot, wet, humid
summer (November to May)
Terrain: small coastal plain rising to discontinuous
mountains encircling central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Piton de la Petite Riviere Noire 828 m
Natural resources: arable land, fish
Land use:
arable land: 49%
permanent crops: 3%
permanent pastures: 3%
forests and woodland: 22%
other: 23% (1993 est.)
Irrigated land: 170 sq km (1993 est.)
Natural hazards: cyclones (November to April);
almost completely surrounded by reefs that may pose
maritime hazards
Environment— current issues: water pollution
306
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements','af80d05656552c5012af845e39ed898452f7d0b42f430c3a1a4f393201d08d8b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50baf35ed50a1194b458c5ce4d5ca1205c87b3c121b97844cc1d8ce5f2b9179f',1998,'YT','Mayotte','geography',635,'Location: Southern Africa, island in the Mozambique
Channel, about one-half of the way from northern
Madagascar to northern Mozambique
Geographic coordinates: 12 50 S, 45 10 E
Map references: Africa
Area:
total: 375 sq km
land: 375 sq km
water: 0 sq km
Area— comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 185.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical; marine; hot, humid, rainy season
during northeastern monsoon (November to May); dry
season is cooler (May to November)
Terrain: generally undulating, with deep ravines and
ancient volcanic peaks
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Benara 660 m
Natural resources: NEGL
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: cyclones during rainy season
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: part of Comoro Archipelago
308','60284838c5924ba8b80383709e54a2afafda9b6b0133b1b4fc7b96e4601b94db','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94f82d074052c9783e6a1fc7730bee8cd28db8cdc8601503528278791111c9e4',1998,'MA','Morocco','geography',650,'Location: Northern Africa, bordering the North
Atlantic Ocean and the Mediterranean Sea, between
Algeria and Western Sahara
Geographic coordinates: 32 00 N, 5 00 W
Map references: Africa
Area:
total: 446,550 sq km
land: 446,300 sq km
water: 250 sq km
Area— comparative: slightly larger than California
Land boundaries:
total: 2,01 7.9 km
border countries: Algeria 1 ,559 km, Western Sahara
443 km, Spain (Ceuta) 6.3 km, Spain (Melilla) 9.6 km
Coastline: 1,835 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: Mediterranean, becoming more extreme in
the interior
Terrain: northern coast and interior are mountainous
with large areas of bordering plateaus, intermontane
valleys, and rich coastal plains
Elevation extremes:
lowest point: Sebkha Tah -55 m
highest point: Jebel Toubkal 4,165 m
Natural resources: phosphates, iron ore,
manganese, lead, zinc, fish, salt
Land use:
arable land: 21%
permanent crops: 1%
permanent pastures: 47%
forests and woodland: 20%
other: 1 1 % (1 993 est.)
Irrigated land: 12,580 sq km (1993 est.)
Natural hazards: northern mountains geologically
unstable and subject to earthquakes; periodic
droughts
Environment— current issues: land degradation/
desertification (soil erosion resulting from farming of
marginal areas, overgrazing, destruction of
vegetation); water supplies contaminated by raw
sewage; siltation of reservoirs; oil pollution of coastal
waters
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification,
Law of the Sea
Geography— note: strategic location along Strait of','0b2210c4885a75e6a2fcd81e3ca860b5989d170dac6833522db8c686b2017aa3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cd9fefe8e4a813936a13d947e53f84b4467726c595da4c2dcca8f2fd5aeb2b3',1998,'NR','Nauru','geography',664,'Location: Southern Asia, between China and India
Geographic coordinates: 28 00 N, 84 00 E
Map references: Asia
Area:
total: 140,800 sq km
land: 136,800 sq km
water: 4,000 sq km
Area— comparative: slightly larger than Arkansas
Land boundaries:
total: 2,926 km
border countries: China 1,236 km, India 1,690 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from cool summers and severe
winters in north to subtropical summers and mild
winters in south
Terrain: Terai or flat river plain of the Ganges in
south, central hill region, rugged Himalayas in north
Elevation extremes:
lowest point: Kanchan Kalan 70 m
highest point: Mount Everest 8,848 m
Natural resources: quartz, water, timber,
hydropower potential, scenic beauty, small deposits of
lignite, copper, cobalt, iron ore
Land use:
arable land: 17%
permanent crops: 0%
permanent pastures: 15%
forests and woodland: 42%
other: 26% (1 993 est.)
Irrigated land: 8,500 sq km (1993 est.)
Natural hazards: severe thunderstorms, flooding,
landslides, drought, and famine depending on the
timing, intensity, and duration of the summer
monsoons
Environment— current issues: the almost total
dependence on wood for fuel and cutting down trees
to expand agricultural land without replanting has
resulted in widespread deforestation; soil erosion;
water pollution (use of contaminated water presents
human health risks)
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea, Marine
Dumping, Marine Life Conservation
Geography— note: landlocked; strategic location
between China and India; contains eight of world''s 10
highest peaks','572c47dd2005ee1c3321ad9eb4b3e97cf87a7be999a225e760382f8d00bc4676','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27a2019bedf0be1270f7731509570ebe43a693f4fd30653ec799249332735dc3',1998,'NL','Netherlands','geography',665,'Location: Western Europe, bordering the North Sea,
between Belgium and Germany
Geographic coordinates: 52 30 N, 5 45 E
Map references: Europe
Area:
total: 41 ,526 sq km
land: 33,889 sq km
water: 7,637 sq km
Area— comparative: slightly less than twice the size
of New Jersey
Land boundaries:
total: 1 ,027 km
border countries: Belgium 450 km, Germany 577 km
Coastline: 451 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 1 2 nm
Climate: temperate; marine; cool summers and mild
winters
Terrain: mostly coastal lowland and reclaimed land
(polders); some hills in southeast
Elevation extremes:
lowest point: Prins Alexanderpolder -7 m
highest point: V aalserberg 321 m
Natural resources: natural gas, petroleum, fertile
soil
Land use:
arable land: 27%
permanent crops: 1%
permanent pastures: 31%
forests and woodland: 1 0%
other: 31% (1993 est.)
Irrigated land: 5,600 sq km (1993 est.)
Natural hazards: the extensive system of dikes and
dams, protects nearly one-half of the total area from
being flooded
Environment— current issues: water pollution in
the form of heavy metals, organic compounds, and
nutrients such as nitrates and phosphates; air
pollution from vehicles and refining activities; acid rain
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Biodiversity
Geography— note: located at mouths of three major
European rivers (Rhine, Maas or Meuse, and
Schelde)
Location: Caribbean, two island groups in the
Caribbean Sea— one includes Curacao and Bonaire
north of Venezuela and the other is east of the Virgin
Islands
Geographic coordinates: 12 15 N, 68 45 W
Map references: Central America and the
Caribbean
Area:
total: 960 sq km
land: 960 sq km
water: 0 sq km
note: includes Bonaire, Curacao, Saba, Sint
Eustatius, and Sint Maarten (Dutch part of the island
of Saint Martin)
Area— comparative: more than five times the size of
Washington, DC
Land boundaries:
total: 10.2 km
border countries: Guadeloupe (Saint Martin) 10.2 km
Coastline: 364 km
Maritime claims:
exclusive fishing zone: 1 2 nm
territorial sea: 12 m
Climate: tropical; ameliorated by northeast trade
winds
Terrain: generally hilly, volcanic interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Scenery 862 m
Natural resources: phosphates (Curacao only), salt
(Bonaire only)
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 90% (1 993 est.)
Irrigated land: NA sq km
336
Natural hazards: Curacao and Bonaire are south of
Caribbean hurricane belt, so are rarely threatened;
Sint Maarten, Saba, and Sint Eustatius are subject to
hurricanes from July to October
Environment— current issues: NA
Environment— international agreements:
party to: Whaling (extended from Netherlands)
signed , but not ratified : NA','dba647834f0c6cbec3f2a077108990ebca4ac7f19c3a6c7d955567a89ace7d34','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d2e3c18e12c5b1319f7f3fbf94743d333b6f077c4a4658944e6e5af8e206543',1998,'NG','Nigeria','geography',688,'Location: Western Africa, bordering the Gulf of
Guinea, between Benin and Cameroon
Geographic coordinates: 10 00 N, 8 00 E
Map references: Africa
Area:
total: 923,770 sq km
land: 910,770 sq km
water: 13, 000 sq km
Area— comparative: '' slightly more than twice the
size of California
Land boundaries:
total: 4,047 km
border countries: Benin 773 km, Cameroon 1 ,690 km,
Chad 87 km, Niger 1 ,497 km
Coastline: 853 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 30 nm
Climate: varies; equatorial in south, tropical in
center, arid in north
Terrain: southern lowlands merge into central hills
and plateaus; mountains in southeast, plains in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Chappal Waddi 2,41 9 m
Natural resources: petroleum, tin, columbite, iron
ore, coal, limestone, lead, zinc, natural gas
Land use:
arable land: 33%
permanent crops: 3%
permanent pastures: 44%
forests and woodland: 1 2%
other: 8% (1993 est.)
Irrigated land: 9,570 sq km (1993 est.)
Natural hazards: periodic droughts
Environment— current issues: soil degradation;
rapid deforestation; desertification; recent droughts in
north severely affecting marginal agricultural activities
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Whaling
signed, but not ratified: none of the selected
agreements','fecce76bd98ad5b157baabbc46d5f0e6c8025aab773a6cab13179e8fa4785f55','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05ebf1a839249f5bf3cecf3bd73e238aa877438cd8a8607b1ff5f7df780d1656',1998,'NU','Niue','geography',692,'Location: Oceania, island in the South Pacific
Ocean, east of Tonga
Geographic coordinates: 1 9 02 S, 1 69 52 W
Map references: Oceania
Area:
total: 260 sq km
land: 260 sq km
water: 0 sq km
Area-comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 64 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; modified by southeast trade winds
Terrain: steep limestone cliffs along coast, central
plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location near Mutalau
settlement 68 m
Natural resources: fish, arable land
Land use:
arable land: 19%
permanent crops: 8%
permanent pastures: 4%
forests and woodland: 1 9%
other: 50% (1 993 est.)
Irrigated land: NAsqkm
Natural hazards: typhoons
Environment— current issues: traditional methods
of burning brush and trees to clear land for agriculture
have threatened soil supplies which are not naturally
very abundant
Environment— international agreements:
party to: Biodiversity, Climate Change
signed, but not ratified : Law of the Sea
Geography— note: one of world''s largest coral
islands','28777f2a725d9521a23d9eb6439c2e2d31c94c7f124be664e1b3c57a4077581e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3564556c2114ca497553395c234060257d74e49dd4b17dcf007e01095dbb59aa',1998,'NF','Norfolk Island','geography',699,'Location: Oceania, island in the South Pacific
Ocean, east of Australia
Geographic coordinates: 29 02 S, 167 57 E
Map references: Oceania
Area:
total: 34.6 sq km
land: 34.6 sq km
water: 0 sq km
Area— comparative: about 0.2 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 32 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: subtropical, mild, little seasonal
temperature variation
Terrain: volcanic formation with mostly rolling plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Bates 319 m
Natural resources: fish
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: 25%
forests and woodland: NA%
other: 75% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: typhoons (especially May to July)
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA','4aebe9cb74f1279a35143ac740aaed7da54af7584b9a59b2d499e5d3bf89cd43','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3f0728876f5745830dcac98266442b763932366f17ec35471fad6c6b9f4483a',1998,'MP','Northern Mariana Islands','geography',711,'Location: Northern Europe, bordering the North Sea
and the North Atlantic Ocean, west of Sweden
Geographic coordinates: 62 00 N, 10 00 E
Map references: Europe
Area:
total: 324,220 sq km
land: 307,860 sq km
water: 16,360 sq km
Area— comparative: slightly larger than New','c97506411342d698429ba6d34ae462280f22e177417ebce790a8c2038fed2185','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('305976cbe18afc7264c471e78179c83535208e546fc7945fa26a6a1098f36686',1998,'OM','Oman','geography',712,'Location: Middle East, bordering the Arabian Sea,
Gulf of Oman, and Persian Gulf, between Yemen and
UAE
Geographic coordinates: 21 00 N, 57 00 E
Map references: Middle East
Area:
total: 21 2,460 sq km
land: 212,460 sq km
water: 0 sq km
Area— comparative: slightly smaller than Kansas
Land boundaries:
total: 1 ,374 km
border countries: Saudi Arabia 676 km, UAE 41 0 km,
Yemen 288 km
Coastline: 2,092 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: dry desert; hot, humid along coast; hot, dry
interior; strong southwest summer monsoon (May to
September) in far south
Terrain: vast central desert plain, rugged mountains
in north and south
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jaba\\ ash Sham 2,980 m
Natural resources: petroleum, copper, asbestos,
some marble, limestone, chromium, gypsum, natural
gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: NA%
other: 95% (1 993 est.)
Irrigated land: 580 sq km (1993 est.)
Natural hazards: summer winds often raise large
sandstorms and dust storms in interior; periodic
droughts
Environment— current issues: rising soil salinity;
beach pollution from oil spills; very limited natural
fresh water resources
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location with small
foothold on Musandam Peninsula adjacent to Strait of
Hormuz, a vital transit point for world crude oil
Location: body of water between Antarctica, Asia,
Australia, and the Western Hemisphere
Geographic coordinates: 0 00 N, 160 00 W
Map references: World
Area:
total: 165.384 million sq km
note: includes Bali Sea, Bellingshausen Sea, Bering
Sea, Bering Strait, Coral Sea, East China Sea, Flores
Sea, Gulf of Alaska, Gulf of Tonkin, Java Sea,
Philippine Sea, Ross Sea, Savu Sea, Sea of Japan,
Sea of Okhotsk, South China Sea, Tasman Sea,
Timor Sea, and other tributary water bodies
Area— comparative: about 1 8 times the size of the
US; the largest ocean (followed by the Atlantic Ocean,
the Indian Ocean, and the Arctic Ocean); covers about
one-third of the global surface; larger than the total
land area of the world
Coastline: 135,663 km
Climate: planetary air pressure systems and
resultant wind patterns exhibit remarkable uniformity
in the south and east; trade winds and westerly winds
are well-developed patterns, modified by seasonal
fluctuations; tropical cyclones (hurricanes) may form
south of Mexico from June to October and affect
Mexico and Central America; continental influences
cause climatic uniformity to be much less pronounced
in the eastern and western regions at the same
latitude in the North Pacific Ocean; the western Pacific
is monsoonal— a rainy season occurs during the
summer months, when moisture-laden winds blow
from the ocean over the land, and a dry season during
the winter months, when dry winds blow from the
Asian land mass back to the ocean; tropical cyclones
(typhoons) may strike southeast and East Asia from
May to December
Terrain: surface currents in the northern Pacific are
dominated by a clockwise, warm-water gyre (broad
circular system of currents) and in the southern Pacific
by a counterclockwise, cool-water gyre; in the
northern Pacific, sea ice forms in the Bering Sea and
Sea of Okhotsk in winter; in the southern Pacific, sea
ice from Antarctica reaches its northernmost extent in
October; the ocean floor in the eastern Pacific is
dominated by the East Pacific Rise, while the western
Pacific is dissected by deep trenches, including the
Mariana Trench, which is the world''s deepest
Elevation extremes:
lowest point: Mariana T rench -1 0,924 m
highest point: sea level 0 m
Natural resources: oil and gas fields, polymetallic
nodules, sand and gravel aggregates, placer
deposits, fish
Natural hazards: surrounded by a zone of violent
volcanic and earthquake activity sometimes referred
to as the "Pacific Ring of Fire"; subject to tropical
cyclones (typhoons) in southeast and east Asia from
May to December (most frequent from July to
October); tropical cyclones (hurricanes) may form
south of Mexico and strike Central America and
Mexico from June to October (most common in
August and September); southern shipping lanes
subject to icebergs from Antarctica; cyclical El Nino
phenomenon occurs off the coast of Peru, when the
trade winds slacken and the warm Equatorial
Countercurrent moves south, killing the plankton that
is the primary food source for anchovies;
consequently, the anchovies move to better feeding
grounds, causing resident marine birds to starve by
the thousands because of the loss of their food
source; ships subject to superstructure icing in
extreme north from October to May and in extreme
south from May to October; persistent fog in the
northern Pacific can be a maritime hazard from June
to December
Environment— current issues: endangered marine
species include the dugong, sea lion, sea otter, seals,
turtles, and whales; oil pollution in Philippine Sea and
South China Sea
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography— note: the major choke points are the
Bering Strait, Panama Canal, Luzon Strait, and the
Singapore Strait; the Equator divides the Pacific
Ocean into the North Pacific Ocean and the South
Pacific Ocean; dotted with low coral islands and
rugged volcanic islands in the southwestern Pacific
Ocean','a5c12bf50ef8f81676eb18626c74b7c173d5f6b15e329e938b4814c768429df5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae874cf7972da7119e4aaa00a793127f3c1ab75b4016d0ae31b37400c26004c1',1998,'PK','Pakistan','geography',720,'Location: Southern Asia, bordering the Arabian Sea,
between India on the east and Iran and Afghanistan
on the west and China in the north
Geographic coordinates: 30 00 N, 70 00 E
Map references: Asia
Area:
total: 803,940 sq km
land: 778,720 sq km
water: 25,220 sq km
Area— comparative: slightly less than twice the size
of California
Land boundaries:
total: 6,774 km
border countries: Afghanistan 2,430 km, China 523
km, India 2,912 km, Iran 909 km
Coastline: 1,046 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly hot, dry desert; temperate in
northwest; arctic in north
Terrain: flat Indus plain in east; mountains in north
and northwest; Balochistan plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: K2 (Mt. Godwin-Austen) 8,611 m
Natural resources: land, extensive natural gas
reserves, limited petroleum, poor quality coal, iron
ore, copper, salt, limestone
Land use:
arable land: 27%
permanent crops: 1%
permanent pastures: 6%
forests and woodland: 5%
other: 61% (1993 est.)
Irrigated land: 171,100 sq km (1993 est.)
Natural hazards: frequent earthquakes,
occasionally severe especially in north and west;
flooding along the Indus after heavy rains (July and
August)
Environment— current issues: water pollution from
raw sewage, industrial wastes, and agricultural runoff;
limited natural fresh water resources; a majority of the
population does not have access to potable water;
deforestation; soil erosion; desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography— note: controls Khyber Pass and Bolan
Pass, traditional invasion routes between Central Asia
and the Indian Subcontinent
Location: Oceania, group of islands in the North
Pacific Ocean, southeast of the Philippines
Geographic coordinates: 7 30 N, 134 30 E
Map references: Oceania
Area:
total: 458 sq km
land: 458 sq km
water: 0 sq km
Area— comparative: slightly more than 2.5 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 1,519 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 12 nm
extended fishing zone: 200 nm
territorial sea: 3 nm
Climate: wet season May to November; hot and
humid
Terrain: varying geologically from the high,
mountainous main island of Babelthuap to low, coral
islands usually fringed by large barrier reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Ngerchelchauus 242 m
Natural resources: forests, minerals (especially
gold), marine products, deep-seabed minerals
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: typhoons (June to December)
Environment— current issues: inadequate
facilities for disposal of solid waste; threats to the
marine ecosystem from sand and coral dredging,
illegal fishing practices, and overfishing
361
Palau (continued)
Environment— international agreements:
party to: Law of the Sea
signed, but not ratified: none of the selected
agreements
Geography— note: includes World War i!
battleground of Beliliou (Peleliu) and world-famous
rock islands; archipelago of six island groups totaling
over 200 islands in the Caroline chain
Location: Oceania, atoll in the North Pacific Ocean,
about one-half of the way from Hawaii to American','39876164d0fa9582f26ecab9f0bf90ba7a5ffca33e0be7c44c8bcb94f13a72ec','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbf13b698ef0d35c95f253748d6a8330c0fbec7a817f82187c7aa7bd5c45a0b1',1998,'PG','Papua New Guinea','geography',729,'Location: Southeastern Asia, group of islands
including the eastern half of the island of New Guinea
between the Coral Sea and the South Pacific Ocean,
east of Indonesia
Geographic coordinates: 6 00 S, 147 00 E
Map references: Oceania
Area:
total: 462,840 sq km
land: 452,860 sq km
water: 9,980 sq km
Area— comparative: slightly larger than California
Land boundaries:
total: 820 km
border countries: Indonesia 820 km
Coastline: 5,152 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; northwest monsoon (December to
March), southeast monsoon (May to October); slight
seasonal temperature variation
Terrain: mostly mountains with coastal lowlands and
rolling foothills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Wilhelm 4,509 m
Natural resources: gold, copper, silver, natural gas,
timber, oil, fisheries
Land use:
arable land: 0.1%
permanent crops: 1%
permanent pastures: 0%
forests and woodland: 92.9%
other: 6% (1993 est.)
Irrigated land: NA sq km
Natural hazards: active volcanism; situated along the
Pacific "Rim of Fire"; the country is subject to frequent
and sometimes severe earthquakes; mud slides
Environment— current issues: rain forest subject
to deforestation as a result of growing commercial
demand for tropical timber; pollution from mining
projects; severe drought
Environment— international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol
Geography— note: shares island of New Guinea
with Indonesia; one of world''s largest swamps along
southwest coast
Location: Southeastern Asia, group of small islands
and reefs in the South China Sea, about one-third of
the way from central Vietnam to the northern','88811eb81ef852915c2ffbc5f882850d9a0f6fc29db3667d1c14f467a5acedbb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('459355e6e75b0209bfa0987a319702c38fe6ff106fb019df564de424556c4257',1998,'PH','Philippines','geography',737,'Geographic coordinates: 16 30 N, 112 00 E
Map references: Southeast Asia
Area:
total: NA sq km
land: NA sq km
water: 0 sq km
Area— comparative: NA
Land boundaries: 0 km
Coastline: 518 km
Maritime claims: NA
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on Rocky Island 14
m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: typhoons
Environment— current issues: NA
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Location: Southeastern Asia, archipelago between
the Philippine Sea and the South China Sea, east of
Vietnam
Geographic coordinates: 13 00 N, 122 00 E
Map references: Southeast Asia
Area:
total: 300,000 sq km
land: 298,170 sq km
water: 1 ,830 sq km
Area— comparative: slightly larger than Arizona
Land boundaries: 0 km
Coastline: 36,289 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: to depth of exploitation
exclusive economic zone: 200 nm
territorial sea: irregular polygon extending up to 100
nm from coastline as defined by 1 898 treaty; since late
1970s has also claimed polygonal-shaped area in
South China Sea up to 285 nm in breadth
Climate: tropical marine; northeast monsoon
(November to April); southwest monsoon (May to
October)
Terrain: mostly mountains with narrow to extensive
coastal lowlands
Elevation extremes:
lowest point: Philippine Sea 0 m
highest point: Mount Apo 2,954 m
Natural resources: timber, petroleum, nickel,
cobalt, silver, gold, salt, copper
Land use:
arable land: 19%
permanent crops: 12%
permanent pastures: 4%
forests and woodland: 46%
other: 19% (1993 est.)
Irrigated land: 15,800 sq km (1993 est.)
Natural hazards: astride typhoon belt, usually
affected by 1 5 and struck by five to six cyclonic storms
per year; landslides; active volcanoes; destructive
earthquakes; tsunamis
Environment— current issues: uncontrolled
deforestation in watershed areas; soil erosion; air and
water pollution in Manila; increasing pollution of
coastal mangrove swamps which are important fish
breeding grounds
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Desertification
Location: Oceania, islands in the South Pacific
Ocean, about one-half of the way from Peru to New
Zealand
Geographic coordinates: 25 04 S, 130 06 W
Map references: Oceania
Area:
total: 47 sq km
land: 47 sq km
water: 0 sq km
Area— comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 51 km
Maritime claims:
exclusive fishing zone: 200 nm
exclusive economic zone: 200 nm
territorial sea: 3 nm
Climate: tropical, hot, humid, modified by southeast
trade winds; rainy season (November to March)
Terrain: rugged volcanic formation; rocky coastline
with cliffs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Pawala Valley Ridge 347 m
Natural resources: miro trees (used for
handicrafts), fish
note: manganese, iron, copper, gold, silver, and zinc
have been discovered offshore
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: typhoons (especially November to
March)
Environment— current issues: deforestation (only
a small portion of the original forest remains because
of burning and clearing for settlement)
375
Pitcairn Islands (continued)
Environment— international agreements:
party to: NA
signed [ but not ratified: NA
Geographic coordinates: 8 38 N, 11 1 55 E
Map references: Southeast Asia
Area:
total: less than 5 sq km
land: less than 5 sq km
water: 0 sq km
note: includes 100 or so islets, coral reefs, and sea
mounts scattered over a large area of the central
South China Sea
Area— comparative: NA
Land boundaries: Okm
Coastline: 926 km
Maritime claims: NA
Climate: tropical
Terrain: flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on Southwest Cay
4 m
Natural resources: fish, guano, undetermined oil
and natural gas potential
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland : 0%
other: 1 00%
Irrigated land: 0 sq km (1993)
Natural hazards: typhoons; serious maritime hazard
because of numerous reefs and shoals
Environment— current issues: NA
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography— note: strategically located near
several primary shipping lanes in the central South
China Sea; includes numerous small islands, atolls,
shoals, and coral reefs','dd00e14c5abdcc79fc3eb886e0f1f90d34733cbee5649e1d6c029da92cc67856','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aeb15509d94385621bd09ce36d94e5f79410cdb7473e663934dab274cb926aab',1998,'AR','Argentina','geography',744,'Geographic coordinates: 23 00 S, 58 00 W
Map references: South America
Area:
total: 406,750 $q km
land: 397,300 sq km
water: 9,450 sq km
Area— comparative: slightly smaller than California
Land boundaries:
total: 3,920 km
border countries: Argentina 1 ,880 km, Bolivia 750 km,
Brazil 1,290 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical; substantial rainfall in the
eastern portions, becoming semiarid in the far west
Terrain: grassy plains and wooded hills east of Rio
Paraguay; Gran Chaco region west of Rio Paraguay
mostly low, marshy plain near the river, and dry forest
and thorny scrub elsewhere
Elevation extremes:
lowest point: junction of Rio Paraguay and Rio Parana
46 m
highest point: Cerro San Rafael 850 m
Natural resources: hydropower, timber, iron ore,
manganese, limestone
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 55%
forests and woodland: 32%
other: 7% (1 993 est.)
Irrigated land: 670 sq km (1993 est.)
Natural hazards: local flooding in southeast (early
September to June); poorly drained plains may
become boggy (early October to June)
Environment— current issues: deforestation (an
estimated 2 million hectares of forest land have been
lost from 1 958-85); water pollution; inadequate means
for waste disposal present health risks for many urban
residents
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: Nuclear Test Ban
Geography— note: landlocked; lies between
Argentina, Bolivia, and Brazil','6531cd895b500213d2b777ba9e353f5224c12566545d2e59c641b6f5476426c0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ece5b5562f4ad87fa4244fa2c8464bf4329682c425686b44f2e98e85fde9d1d',1998,'PR','Puerto Rico','geography',751,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, east of the
Geographic coordinates: 1 8 20 N, 64 50 W
Map references: Central America and the
Caribbean
Area:
total: 352 sq km
land: 349 sq km
water: 3 sq km
Area— comparative: twice the size of Washington,
DC
Land boundaries: 0 km
Coastline: 188 km
Maritime claims:
exclusive economic zone : 200 nm
territorial sea: 12 nm
Climate: subtropical, tempered by easterly trade
winds, relatively low humidity, little seasonal
temperature variation; rainy season May to November
Terrain: mostly hilly to rugged and mountainous with
little level land
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crown Mountain 474 m
Natural resources: sun, sand, sea, surf
Land use:
arable land: 15%
permanent crops: 6%
permanent pastures: 26%
forests and woodland: 6%
other: 47% (1 993 est.)
Irrigated land: NAsqkm
Natural hazards: several hurricanes in recent years;
frequent and severe droughts, floods, and
earthquakes
Environment— current issues: lack of natural
freshwater resources
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: important location along the
Anegada Passage— a key shipping lane for the
Panama Canal; Saint Thomas has one of the best
natural, deepwater harbors in the Caribbean','c9c9947fca891a4942c4c293efb33a21f16bf6e58782198536d7942dd11bf22a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('210195bcd3ce285132106c21db348c5952b3c10400ff3a5b6dff7e19ecb989ea',1998,'DO','Dominican Republic','geography',752,'Geographic coordinates: 18 15 N, 66 30 W
Map references: Central America and the
Caribbean
Area:
total: 9,104 sq km
land: 8,959 sq km
water: 145 sq km
Area— comparative: slightly less than three times
the size of Rhode Island
Land boundaries: 0 km
Coastline: 501 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical marine, mild; little seasonal
temperature variation
Terrain: mostly mountains with coastal plain belt in
north; mountains precipitous to sea on west coast;
sandy beaches along most coastal areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro de Punta 1 ,338 m
Natural resources: some copper and nickel;
potential for onshore and offshore oil
Land use:
arable land: 4%
permanent crops: 5%
permanent pastures: 26%
forests and woodland: 1 6%
other: 49% (1993 est.)
Irrigated land: 390 sq km (1993 est.)
Natural hazards: periodic droughts
Environment— current issues: the recent drought
has caused water levels in reservoirs to drop and
prompted water rationing for more than one-half of the
population
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: important location along the
Mona Passage— a key shipping lane to the Panama
Canal; San Juan is one of the biggest and best natural
harbors in the Caribbean; many small rivers and high
central mountains ensure land is well watered; south
coast relatively dry; fertile coastal plain belt in north','7997562016fc9719508c938d53e3b94badfc61c6595b28341acda3c98d7ec45c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('daebea2fb09acdd54aa21b7ee28acd6055a96e7ff9776b4ef7362fdcaa1d7cc6',1998,'QA','Qatar','geography',759,'Location: Middle East, peninsula bordering the
Persian Gulf and Saudi Arabia
Geographic coordinates: 25 30 N, 51 15 E
Map references: Middle East
Area:
total: 11,437 sq km
land: 1 1 ,437 sq km
water: 0 sq km
Area— comparative: slightly smaller than
Connecticut
Land boundaries:
total: 60 km
border countries: Saudi Arabia 60 km
Coastline: 563 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: desert; hot, dry; humid and sultry in summer
Terrain: mostly flat and barren desert covered with
loose sand and gravel
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Qurayn Aba al Bawl 103 m
Natural resources: petroleum, natural gas, fish
Land use:
arable land: 1%
permanent crops: NA%
permanent pastures: 5%
forests and woodland: NA%
other: 94% (1993 est.)
Irrigated land: 80 sq km (1993 est.)
Natural hazards: haze, dust storms, sandstorms
common
Environment— current issues: limited natural fresh
water resources are increasing dependence on
large-scale desalination facilities
Environment— international agreements:
party to: Biodiversity, Climate Change, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography— note: strategic location in centra!
Persian Gulf near major petroleum deposits
Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 21 06 S, 55 36 E
Map references: World
Area:
total: 2,510 sq km
land: 2,500 sq km
water: 10 sq km
Area— comparative: slightly smaller than Rhode
Island
Land boundaries: 0 km
Coastline: 201 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, but temperature moderates with
elevation; cool and dry from May to November, hot
and rainy from November to April
Terrain: mostly rugged and mountainous; fertile
lowlands along coast
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Piton des Neiges 3,069 m
Natural resources: fish, arable land
Land use:
arable land: 17%
permanent crops: 2%
permanent pastures: 5%
forests and woodland: 35%
other: 41 % (1 993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: periodic, devastating cyclones
(December to April); Piton de la Fournaise on the
southeastern coast is an active volcano
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: N A','73a46c7d0b54ae81537f4e682e04b55e6b9ce5f37960d95cffb5de4c36434057','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fb96b7b291e136cc7ffb5539e4b6587847a5876d34661f9d5fabbb4b718ce8d',1998,'RO','Romania','geography',768,'Location: Southeastern Europe, bordering the Black
Sea, between Bulgaria and Ukraine
Geographic coordinates: 46 00 N, 25 00 E
Map references: Europe
Area:
total: 237,500 sq km
land: 230,340 sq km
wafer 7,160 sq km
Area— comparative: slightly smaller than Oregon
Land boundaries:
total: 2,508 km
border countries: Bulgaria 608 km, Hungary 443 km,
Moldova 450 km, Serbia and Montenegro 476 km (all
with Serbia), Ukraine (north) 362 km, Ukraine (east)
169 km
Coastline: 225 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: temperate; cold, cloudy winters with
frequent snow and fog; sunny summers with frequent
showers and thunderstorms
Terrain: central Transylvanian Basin is separated
from the Plain of Moldavia on the east by the
Carpathian Mountains and separated from the
Walachian Plain on the south by the T ransylvanian Alps
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Moldoveanu 2,544 m
Natural resources: petroleum (reserves declining),
timber, natural gas, coal, iron ore, salt
Land use:
arable land: 41%
permanent crops: 3%
permanent pastures: 21 %
forests and woodland: 29%
other: 6% (1993 est.)
387
Romania (continued)
Irrigated land: 31 ,020 sq km (1 993 est.)
Natural hazards: earthquakes most severe in south
and southwest; geologic structure and climate
promote landslides
Environment— current issues: soil erosion and
degradation; water pollution; air pollution in south from
industrial effluents; contamination of Danube delta
wetlands
Environment— international agreements:
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol
Geography— note: controls most easily traversable
land route between the Balkans, Moldova, and','9e98de8dac4e2082ddc7eb5b80764192dcfff43fda887b52fed238e094671a9b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c1f36782e8c832beb3081e76026a7c3f0c30a9e35400bb61d2e4516b8009995',1998,'UG','Uganda','geography',779,'Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area:
total: 26,340 sq km
land: 24,950 sq km
water: 1,390 sq km
Area— comparative: slightly smaller than Maryland
Land boundaries:
total: 893 km
border countries: Burundi 290 km, Democratic
Republic of the Congo 217 km, Tanzania 217 km,
Uganda 169 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; two rainy seasons (February to
April, November to January); mild in mountains with
frost and snow possible
Terrain: mostly grassy uplands and hills; relief is
mountainous with altitude declining from west to east
Elevation extremes:
lowest point: Rusizi River 950 m
highest point: Volcan Karisimbi 4,519 m
Natural resources: gold, cassiterite (tin ore),
wolframite (tungsten ore), natural gas, hydropower
393
Rwanda (continued)
Land use:
arable land: 35%
permanent crops: 1 3%
permanent pastures: 1 8%
forests and woodland: 22%
oftov 12% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: periodic droughts; the volcanic
Virunga mountains are in the northwest along the
border with Democratic Republic of the Congo
Environment— current issues: deforestation
results from uncontrolled cutting of trees for fuel;
overgrazing; soil exhaustion; soil erosion
Environment— international agreements:
party to: Biodiversity, Endangered Species, Nuclear
Test Ban
signed, but not ratified : Climate Change,
Desertification, Law of the Sea
Geography— note: landlocked; predominantly rural
population
Location: islands in the South Atlantic Ocean, about
mid-way between South America and Africa
Geographic coordinates: 15 56 S, 5 42 W
Map references: Africa
Area:
total: 410 sq km
land: 410 sq km
water: 0 sq km
note: includes Ascension, Gough Island, Inaccessible
island, Nightingale Island, and Tristan da Cunha
Island
Area— comparative: slightly more than two times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 60 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: Saint Helena— tropical; marine; mild,
tempered by trade winds; Tristan da Cunha—
temperate; marine, mild, tempered by trade winds
(tends to be cooler than Saint Helena)
Terrain: Saint Helena— rugged, volcanic; small
scattered plateaus and plains
note: the other islands of the group have a volcanic
origin
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Queen Mary''s Peak 2,060 m
Natural resources: fish
Land use:
arable land: 6%
permanent crops: N A%
permanent pastures: 6%
forests and woodland: 6%
other: 82% (1993 est.)
Irrigated land: NA sq km
Natural hazards: active volcanism on Tristan da
Cunha
395
Saint Helena (continued)
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: Napoleon Bonaparte''s place of
exile and burial (his remains were taken to Paris in
1840); harbors at least 40 species of plants unknown
anywhere else in the world; Ascension is a breeding
ground for sea turtles and sooty terns
Location: Caribbean, islands in the Caribbean Sea,
about one-third of the way from Puerto Rico to','42413879fcf4842705059157eeb3b955e2752a1726db6fd6807fab7367322242','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c2c47a6f3e7ce7565a97f725b9bfcee219109ef8ea146c3bf990b3f8f86edec',1998,'TT','Trinidad and Tobago','geography',787,'Geographic coordinates: 17 20 N, 62 45 W
Map references: Central America and the
Caribbean
Area:
total: 269 sq km
land: 269 sq km
water: 0 sq km
Area— comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 135 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm or to the edge of
the continental margin
Climate: subtropical tempered by constant sea
breezes; little seasonal temperature variation; rainy
season (May to November)
Terrain: volcanic with mountainous interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Liamuiga 1,156 m
Natural resources: NEGL
Land use:
arable land: 22%
permanent crops: 1 7%
permanent pastures: 3%
forests and woodland: 17%
other: 41% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: hurricanes (July to October)
Environment— current issues: NA
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Whaling
signed, but not ratified: none of the selected
agreements
Location: Caribbean, island between the Caribbean
Sea and North Atlantic Ocean, north of Trinidad and
Tobago
Geographic coordinates: 1 3 53 N, 60 68 W
Map references: Central America and the
Caribbean
Area:
total: 620 sq km
/and: 61 0 sq km
water: 1 0 sq km
Area— comparative: 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 158 km
Maritime claims: 200 nm or to the edge of the
continental margin
contiguous zone: 24 nm
exclusive economic zone: 200 nm or to the edge of
the continental margin
territorial sea: 12 nm
Climate: tropical, moderated by northeast trade
winds; dry season from January to April, rainy season
from May to August
Terrain: volcanic and mountainous with some broad,
fertile valleys
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Gimie 950 m
Natural resources: forests, sandy beaches,
minerals (pumice), mineral springs, geothermal
potential
Land use:
arable land: 8%
permanent crops: 21%
permanent pastures: 5%
forests and woodland: 13%
other: 53% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: hurricanes and volcanic activity
Environment— current issues: deforestation; soil
erosion, particularly in the northern region
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Whaling
signed , but not ratified: Climate Change-Kyoto
Protocol','f88a8d3616073c4cf83d113707799f850266ef647ef0af00ddc06fd95f623528','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85ffae934dbb5dc3fffbfce19a7e18581f2a50640d60d130e3a9b7edb9138fb1',1998,'MQ','Martinique','geography',799,'Location: Northern North America, islands in the
North Atlantic Ocean, south of Newfoundland
(Canada)
Geographic coordinates: 46 50 N, 56 20 E
Map references: North America
Area:
total: 242 sq km
land: 242 sq km
water: 0 sq km
note: includes eight small islands in the Saint Pierre
and the Miquelon groups
Area— comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: cold and wet, with much mist and fog;
spring and autumn are windy
Terrain: mostly barren rock
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morne de la Grande Montagne 240 m
Natural resources: fish, deepwater ports
Land use:
arable land: 13%
permanent crops: NA%
permanent pastures: N A%
forests and woodland: 4%
other: 83% (1993 est.)
Irrigated land: NA sq km
Natural hazards: persistent fog throughout the year
can be a maritime hazard
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: vegetation scanty
400','48218f7f527eb9c93cdb6782f183266ed6ff0c87be5df0ad2a8336019b5b43ba','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1454a3650affab2a4f137ff652277189f5984ed41b35c9ee968623093f6c33e',1998,'IT','Italy','geography',803,'Geographic coordinates: 43 46 N, 12 25 E
Map references: Europe
Area:
total : 60 sq km
land: 60 sq km
water: 0 sq km
Area— comparative: about 0.3 times the size of
Washington, DC
Land boundaries:
total: 39 km
border countries: Italy 39 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: Mediterranean; mild to cool winters; warm,
sunny summers
Terrain: rugged mountains
Elevation extremes:
lowest point: Fiume Ausa 55 m
highest point: Monte Titano 749 m
Natural resources: building stone
Land use:
arable land: 17%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
of/?er; 83% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: Biodiversity, Climate Change, Nuclear Test
Ban
signed, but not ratified: Air Pollution
Geography— note: landlocked; smallest
independent state in Europe after the Holy See and
Monaco; dominated by the Apennines
405
San Marino (continued)
Geographic coordinates: 47 00 N, 8 00 E
Map references: Europe
Area:
total: 41 ,290 sq km
land : 39,770 sq km
water: 1 ,520 sq km
Area— comparative: slightly less than twice the size
of New Jersey
Land boundaries:
total: 1 ,852 km
border countries: Austria 164 km, France 573 km,
Italy 740 km, Liechtenstein 41 km, Germany 334 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, but varies with altitude; cold,
cloudy, rainy/snowy winters; cool to warm, cloudy,
humid summers with occasional showers
Terrain: mostly mountains (Alps in south, Jura in
northwest) with a central plateau of rolling hills, plains,
and large lakes
Elevation extremes:
lowest point: Lake Maggiore 195 m
highest point: Dufourspitze 4,634 m
Natural resources: hydropower potential, timber,
salt
Land use:
arable land: 10%
permanent crops: 2%
permanent pastures: 28%
forests and woodland: 32%
other: 28% (1993 est.)
Irrigated land: 250 sq km (1993 est.)
Natural hazards: avalanches, landslides, flash
floods
Environment— current issues: air pollution from
vehicle emissions and open-air burning; acid rain;
water pollution from increased use of agricultural
fertilizers; loss of biodiversity
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Antarctic-Environmental
Protocol, Climate Change-Kyoto Protocol, Law of the
Sea
Geography— note: landlocked; crossroads of
northern and southern Europe; along with
southeastern France and northern Italy, contains the
highest elevations in Europe
Location: Middle East, bordering the Mediterranean
Sea, between Lebanon and Turkey
Geographic coordinates: 35 00 N, 38 00 E
Map references: Middle East
Area:
total: 185,180 sq km
land: 184,050 sq km
wafer 1,130 sq km
note: includes 1 ,295 sq km of Israeli-occupied territory
Area— comparative: slightly larger than North
Dakota
Land boundaries:
total: 2,253 km
border countries: Iraq 605 km, Israel 76 km, Jordan
375 km, Lebanon 375 km, Turkey 822 km
Coastline: 193 km
Maritime claims:
contiguous zone: 41 nm
territorial sea: 35 nm
Climate: mostly desert; hot, dry, sunny summers
(June to August) and mild, rainy winters (December to
February) along coast; cold weather with snow or
sleet periodically hitting Damascus
Terrain: primarily semiarid and desert plateau;
narrow coastal plain; mountains in west
Elevation extremes:
lowest point: unnamed location near Lake Tiberias
-200 m
highest point: Mount Hermon 2,814 m
Natural resources: petroleum, phosphates, chrome
and manganese ores, asphalt, iron ore, rock salt,
marble, gypsum
Land use:
arable land: 28%
permanent crops: 4%
permanent pastures: 43%
forests and woodland: 3%
other: 22% (1993 est.)
Irrigated land: 9,060 sq km (1993 est.)
452
Natural hazards: dust storms, sandstorms
Environment— current issues: deforestation;
overgrazing; soil erosion; desertification; water
pollution from dumping of raw sewage and wastes
from petroleum refining; inadequate supplies of
potable water
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, NuclearTest Ban,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: Environmental Modification
Geography— note: there are 42 Israeli settlements
and civilian land use sites in the Israeli-occupied
Golan Heights (August 1997 est.)','e8d23924b9b2382a484f0d4ac397164caa197c8b2b1d3ed83fe24553bf119681','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b589acce043202232d9e4df3396c3bd06384ac7236a0cc2d40b2c30ca8b18077',1998,'SA','Saudi Arabia','geography',811,'Location: Middle East, bordering the Persian Gulf
and the Red Sea, north of Yemen
Geographic coordinates: 25 00 N, 45 00 E
Map references: Middle East
Area:
total: 1 ,960,582 sq km
land: 1,960,582 sq km
water: 0 sq km
Area— comparative: slightly more than one-fifth the
size of the US
Land boundaries:
total: 4,41 5 km
border countries: Iraq 814 km, Jordan 728 km, Kuwait
222 km, Oman 676 km, Qatar 60 km, UAE 457 km,
Yemen 1 ,458 km
Coastline: 2,640 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: not specified
territorial sea: 12 nm
Climate: harsh, dry desert with great extremes of
temperature
Terrain: mostly uninhabited, sandy desert
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal Sawda'' 3,1 33 m
Natural resources: petroleum, natural gas, iron ore,
gold, copper
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 1 %
other: 41% (1993 est.)
Irrigated land: 4,350 sq km (1993 est.)
Natural hazards: frequent sand and dust storms
Environment— current issues: desertification;
depletion of underground water resources; the lack of
perennial rivers or permanent water bodies has
prompted the development of extensive seawater
desalination facilities; coastal pollution from oil spills
Environment— international agreements:
party to: Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection
signed, but not ratified : none of the selected
agreements
Geography— note: extensive coastlines on Persian
Gulf and Red Sea provide great leverage on shipping
(especially crude oil) through Persian Gulf and Suez
Canal
Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and','ff0f433ee79d06f5180910734c0fe29fe3f70779cefedfcba89a392942fde399','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7b9b8faa262dc79402f8c522a61722f5dac05ef14bd532c07a73be6e1b8e9d4',1998,'MR','Mauritania','geography',819,'Geographic coordinates: 14 00 N, 14 00 W
Map references: Africa
Area:
total: 196,1 90 sq km
land: 192,000 sq km
water: 4,1 90 sq km
Area-comparative: slightly smaller than South
Dakota
Land boundaries:
total: 2,640 km
border countries: The Gambia 740 km, Guinea 330
km, Guinea-Bissau 338 km, Mali 419 km, Mauritania
813 km
Coastline: 531 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; rainy season (May to
November) has strong southeast winds; dry season
(December to April) dominated by hot, dry, harmattan
wind
Terrain: generally low, rolling, plains rising to
foothills in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location in the Futa Jaldon
foothills 581 m
Natural resources: fish, phosphates, iron ore
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 1 6%
forests and woodland: 54%
other: 18% (1993 est.)
Irrigated land: 710 sq km (1993 est.)
Natural hazards: lowlands seasonally flooded;
periodic droughts
Environment— current issues: wildlife populations
threatened by poaching; deforestation; overgrazing;
soil erosion; desertification; overfishing
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Marine Dumping
Geography— note: The Gambia is almost an
enclave of Senegal','e14ecf0f6fd76ec6e89cccfcf23d73125fb8313cbb077235082e8aa8776072b0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7f2bb3eb8dc3b72c79e6092adb615e65c0c1b5a4459b1007e45140262d08b78',1998,'ME','Montenegro','geography',827,'Location: Southeastern Europe, bordering the
Adriatic Sea, between Albania and Bosnia and
Herzegovina
Geographic coordinates: 44 00 N, 21 00 E
Map references: Europe
Area:
total: 102,350 sq km (Serbia 88,412 sq km;
Montenegro 13,938 sq km)
land: 102,136 sq km (Serbia 88,412 sq km;
Montenegro 13,724 sq km)
water: 214 sq km (Serbia 0 sq km; Montenegro
214 sq km)
Area— comparative: slightly smaller than Kentucky
(Serbia is slightly larger than Maine; Montenegro is
slightly smaller than Connecticut)
Land boundaries:
total: 2,246 km
border countries: Albania 287 km (1 1 4 km with
Serbia, 173 km with Montenegro), Bosnia and
Herzegovina 527 km (31 2 km with Serbia, 21 5 km with
Montenegro), Bulgaria 318 km (with Serbia), Croatia
(north) 241 km (with Serbia), Croatia (south) 25 km
(with Montenegro), Hungary 151 km (with Serbia),
The Former Yugoslav Republic of Macedonia 221 km
(with Serbia), Romania 476 km (with Serbia)
note: the internal boundary between Montenegro and
Serbia is 211 km
Coastline: 199 km (Montenegro 199 km, Serbia
0 km)
Maritime claims: NA
Climate: in the north, continental climate (cold winter
and hot, humid summers with well distributed rainfall);
central portion, continental and Mediterranean
climate; to the south, Adriatic climate along the coast,
hot, dry summers and autumns and relatively cold
winters with heavy snowfall inland
Terrain: extremely varied; to the north, rich fertile
plains; to the east, limestone ranges and basins; to the
southeast, ancient mountains and hills; to the
southwest, extremely high shoreline with no islands
off the coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Daravica 2,656 m
Natural resources: oil, gas, coal, antimony, copper,
lead, zinc, nickel, gold, pyrite, chrome
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: N A%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: destructive earthquakes
Environment— current issues: pollution of coastal
waters from sewage outlets, especially in
tourist-related areas such as Kotor; air pollution
around Belgrade and other industrial cities; water
pollution from industrial wastes dumped into the Sava
which flows into the Danube
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography— note: controls one of the major land
routes from Western Europe to Turkey and the Near
East; strategic location along the Adriatic coast','a3111b60a24a33b41cbc44979c2d13d60bca720e107b0637ff68c253d7137c7f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c885d19a1ae86a93c4230f985fa60501a522aceae6d736d2af45b62e7ad62da',1998,'SL','Sierra Leone','geography',841,'Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Liberia
Geographic coordinates: 8 30 N, 1 1 30 W
Map references: Africa
Area:
total: 71,740 sq km
land: 71 ,620 sq km
water: 120 sq km
Area— comparative: slightly smaller than South
Carolina
Land boundaries:
total: 958 km
border countries: Guinea 652 km, Liberia 306 km
Coastline: 402 km
Maritime claims:
territorial sea: 200 nm
417
Sierra Leone (continued)
continental shelf: 200-m depth or to the depth of
exploitation
Climate: tropical; hot, humid; summer rainy season
(May to December); winter dry season (December to
April)
Terrain: coastal belt of mangrove swamps, wooded
hill country, upland plateau, mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Loma Mansa (Bintimani) 1 ,948 m
Natural resources: diamonds, titanium ore, bauxite,
iron ore, gold, chromite
Land use:
arable land: 7%
permanent crops: 1%
permanent pastures: 31 %
forests and woodland: 28%
other: 33% (1993 est.)
Irrigated land: 290 sq km (1993 est.)
Natural hazards: dry, sand-laden harmattan winds
blow from the Sahara (November to May);
sandstorms, dust storms
Environment— current issues: rapid population
growth pressuring the environment; overharvesting of
timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in
deforestation and soil exhaustion; civil war depleting
natural resources; overfishing
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Life Conservation, Nuclear Test Ban, Whaling
signed , but not ratified: Environmental Modification','b3c6ad43b2aeea13e5e4619bd3f75b7c630cc48c09429d2049f0c8c3b62d0b7d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2b6647fc1e03a875755a0661be44e76f977d8f3b64018f48f4b17d1b7fb2c9d',1998,'MY','Malaysia','geography',845,'Location: Central Europe, south of Poland
Geographic coordinates: 48 40 N, 19 30 E
Map references: Europe
Area:
total: 48,845 sq km
land: 48,800 sq km
water: 45 sq km
Area— comparative: about twice the size of New
Hampshire
Land boundaries:
total: 1,355 km
border countries: Austria 91 km, Czech Republic 21 5
km, Hungary 515 km, Poland 444 km, Ukraine 90 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters
Terrain: rugged mountains in the central and
northern part and lowlands in the south
Elevation extremes:
lowest point: Bodrok River 94 m
highest point: Gerlachovka 2,655 m
Natural resources: brown coal and lignite; small
amounts of iron ore, copper and manganese ore; salt
Land use:
arable land: 31%
permanent crops: 3%
permanent pastures: 17%
forests and woodland: 41 %
other: 8% (1993 est.)
Irrigated land: 800 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: air pollution from
metallurgical plants presents human health risks; acid
rain damaging forests
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94,
Antarctic Treaty, Biodiversity, Climate Change,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: Antarctic-Environmental
Protocol
Geography— note: landlocked
f People
Population: 5,392,982 (July 1998 est.)
Age structure:
0-14years: 21% (male 570,515; female 546,088)
15-64 years: 68% (male 1 ,81 9,831 ; female
1,845,800)
65 years and over: 1 1 % (male 235,926; female
374,822) (July 1998 est.)
Population growth rate: 0.08% (1998 est.)
Birth rate: 9.96 births/1,000 population (1998 est.)
Death rate: 9.48 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0.33 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.62 male(s)/female (1998 est.)
Infant mortality rate: 9.73 deaths/1,000 live births
(1998 est.)
Life expectancy at birth:
total population: 73.1 9 years
male: 69.41 years
female: 77 A 5 years (1998 est.)
Total fertility rate: 1 .27 children born/woman (1 998
est.)
Nationality:
noun: Slovak(s)
adjective: Slovak
Ethnic groups: Slovak 85.7%, Hungarian 10.7%,
Gypsy 1 .5% (the 1 992 census figures underreport the
Gypsy/Romany community, which could reach 500,000
or more), Czech 1%, Ruthenian 0.3%, Ukrainian 0.3%,
German 0.1%, Polish 0.1%, other 0.3%
Religions: Roman Catholic 60.3%, atheist 9.7%,
Protestant 8.4%, Orthodox 4.1%, other 17.5%
Languages: Slovak (official), Hungarian
Literacy: NA','dba0dad3cc5c454383e65e07a3dae5c3c75abd49aa8e24a8a9696a45aefadfda','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f43102ca0a33bb867bed6a31a566f1c265c7e9450b294e8a7facf63f3a051da',1998,'SB','Solomon Islands','geography',848,'Location: Oceania, group of islands in the South
Pacific Ocean, east of Papua New Guinea
Geographic coordinates: 8 00 S, 159 00 E
Map references: Oceania
Area:
total: 28,450 sq km
land: 27,540 sq km
water: 91 Osq km
Area— comparative: slightly smaller than Maryland
Land boundaries: 0 km
Coastline: 5,313 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical monsoon; few extremes of
temperature and weather
Terrain: mostly rugged mountains with some low
coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Makarakomburu 2,447 m
Natural resources: fish, forests, gold, bauxite,
phosphates, lead, zinc, nickel
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 1 %
forests and woodland: 88%
other: 9% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons, but they are rarely
destructive; geologically active region with frequent
earth tremors; volcanic activity
Environment— current issues: deforestation; soil
erosion; much of the surrounding coral reefs are dead
or dying
426
Environment— international agreements:
party to: Biodiversity, Climate Change, Environmental
Modification, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer Protection,
Whaling
signed, but not ratified: none of the selected
agreements
Location: Eastern Africa, bordering the Gulf of Aden
and the Indian Ocean, east of Ethiopia
Geographic coordinates: 10 00 N, 49 00 E
Map references: Africa
Area:
total: 637,660 sq km
land: 627,340 sq km
water: 10,320 sq km
Area— comparative: slightly smaller than Texas
Land boundaries:
total: 2,366 km
border countries: Djibouti 58 km, Ethiopia 1,626 km,
Kenya 682 km
Coastline: 3,025 km
Maritime claims:
territorial sea: 200 nm
Climate: principally desert; December to February-
northeast monsoon, moderate temperatures in north
and very hot in south; May to October— southwest
monsoon, torrid in the north and hot in the south,
irregular rainfall, hot and humid periods (tangambili)
between monsoons
Terrain: mostly flat to undulating plateau rising to
hills in north
Elevation extremes:
lowest point : Indian Ocean 0 m
highest point: Shimbiris 2,450 m
Natural resources: uranium and largely unexploited
reserves of iron ore, tin, gypsum, bauxite, copper, salt
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 69%
forests and woodland: 26%
other: 3% (1993 est.)
Irrigated land: 1,800 sq km (1993 est.)
Natural hazards: recurring droughts; frequent dust
storms over eastern plains in summer
Environment— current issues: famine; use of
contaminated water contributes to human health
problems; deforestation; overgrazing; soil erosion;
desertification
Environment— international agreements:
party to: Endangered Species, Law of the Sea
signed, but not ratified: Marine Dumping, Nuclear
Test Ban
Geography— note: strategic location on Horn of
Africa along southern approaches to Bab el Mandeb
and route through Red Sea and Suez Canal
Location: Southern Africa, at the southern tip of the
continent of Africa
Geographic coordinates: 29 00 S, 24 00 E
Map references: Africa
Area:
total: 1,219,912 sq km
land: 1,219,912 sq km
water: 0 sq km
note: includes Prince Edward Islands (Marion Island
and Prince Edward Island)
Area— comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 4,750 km
border countries: Botswana 1,840 km, Lesotho 909
km, Mozambique 491 km, Namibia 855 km,
Swaziland 430 km, Zimbabwe 225 km
Coastline: 2,798 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly semiarid; subtropical along east
coast; sunny days, cool nights
Terrain: vast interior plateau rimmed by rugged hills
and narrow coastal plain
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Njesuthi 3,408 m
Natural resources: gold, chromium, antimony, coal,
iron ore, manganese, nickel, phosphates, tin,
uranium, gem diamonds, platinum, copper, vanadium,
salt, natural gas
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 67%
forests and woodland: 7%
other: 15% (1993 est.)
Irrigated land: 12,700 sq km (1993 est.)
Natural hazards: prolonged droughts
Environment— current issues: lack of important
arterial rivers or lakes requires extensive water
conservation and control measures; growth in water
usage threatens to outpace supply; pollution of rivers
from agricultural runoff and urban discharge; air
pollution resulting in acid rain; soil erosion;
desertification
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: South Africa completely
surrounds Lesotho and almost completely surrounds
Swaziland
Location: Southern South America, islands in the
South Atlantic Ocean, east of the tip of South America
Geographic coordinates: 54 30 S, 37 00 W
Map references: Antarctic Region
Area:
total: 4,066 sq km
land: 4,066 sq km
water: 0 sq km
note: includes Shag Rocks, Clerke Rocks, Bird Island
Area-comparative: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline: NAkm
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 1 2 nm
Climate: variable, with mostly westerly winds
throughout the year, interspersed with periods of
calm; nearly all precipitation falls as snow
Terrain: most of the islands, rising steeply from the
sea, are rugged and mountainous; South Georgia is
largely barren and has steep, glacier-covered
mountains; the South Sandwich Islands are of
volcanic origin with some active volcanoes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Paget 2,91 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (largely covered by permanent ice and
snow with some sparse vegetation consisting of
grass, moss, and lichen)
Irrigated land: 0 sq km (1993)
Natural hazards: the South Sandwich Islands have
prevailing weather conditions that generally make
them difficult to approach by ship; they are also
subject to active volcanism
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Geography— note: the north coast of South Georgia
has several large bays, which provide good
anchorage; reindeer, introduced early in this century,
live on South Georgia','77f710772056bb4847d28109a0df9f8a10f835e1fd1e280171e46bee43c1b897','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcf7ddb3b5b29fa5bdeb4caff7fc2c84393d61f80688980b3c327e5676ac671c',1998,'LK','Sri Lanka','geography',856,'Location: Southern Asia, island in the Indian Ocean,
south of India
Geographic coordinates: 7 00 N, 81 00 E
Map references: Asia
Area:
total: 65,61 Osq km
land: 64,740 sq km
water: 870 sq km
Area— comparative: slightly larger than West
Virginia
Land boundaries: 0 km
Coastline: 1,340 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical monsoon; northeast monsoon
(December to March); southwest monsoon (June to
October)
Terrain: mostly low, flat to rolling plain; mountains in
south-central interior
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Pidurutalagala 2,524 m
Natural resources: limestone, graphite, mineral
sands, gems, phosphates, clay
Land use:
arable land: 14%
permanent crops: 1 5%
permanent pastures: 7%
forests and woodland: 32%
other: 32% (1993 est.)
Irrigated land: 5,500 sq km (1993 est.)
Natural hazards: occasional cyclones and
tornadoes
Environment— current issues: deforestation; soil
erosion; wildlife populations threatened by poaching;
coastal degradation from mining activities and
increased pollution; freshwater resources being
polluted by industrial wastes and sewage runoff
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
Geography— note: strategic location near major
Indian Ocean sea lanes','4b14a7bcfab427c69d4223e686d5eb97daf7fbc640e4be2af419e70fb2add6a7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b6d675995275dee781d1e02a26a82ef41e9a438cd40417703f4d6455b99027f',1998,'SR','Suriname','geography',868,'Location: Northern South America, bordering the
North Atlantic Ocean, between French Guiana and','c0a0885b01b1a745b37f8ab18e10fdb72d8d2d07eb19f2951d3d194c03e6aa71','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7feed768e8382c8542bf5d452f5e475eb88fb8f030bd1463e727567c0d8d5591',1998,'ZW','Zimbabwe','geography',870,'Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 00 E
Map references: Commonwealth of Independent
States
Area:
total: 143, 100 sq km
land: 142, 700 sq km
water: 400 sq km
Area-comparative: slightly smaller than Wisconsin
Land boundaries:
total: 3,651 km
border countries: Afghanistan 1,206 km, China 414
km, Kyrgyzstan 870 km, Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: midlatitude continental, hot summers, mild
winters; semiarid to polar in Pamir Mountains
Terrain: Pamirs and Alay Mountains dominate
landscape; western Fergana Valley in north,
Kofarnihon and Vakhsh Valleys in southwest
Elevation extremes:
lowest point: Syrdariya 300 m
highest point: Qullai Kommunizm 7,495 m
Natural resources: significant hydropower
potential, some petroleum, uranium, mercury, brown
coal, lead, zinc, antimony, tungsten
arable land: 6%
permanent crops: 0%
permanent pastures : 25%
forests and woodland: 4%
other: 65% (1993 est.)
Irrigated land: 6,390 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: inadequate
sanitation facilities; increasing levels of soil salinity;
industrial pollution; excessive pesticides; part of the
basin of the shrinking Aral Sea suffers from severe
overutilization of available water for irrigation and
associated pollution
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Ozone Layer Protection
signed \\ but not ratified: none of the selected
agreements
Geography— note: landlocked
:~;7.
Population: 6,020,095 (July 1998 est.)
Age structure:
0-14 years: 41 % (male 1 ,258,424; female 1 ,230,891 )
15-64 years: 54% (male 1 ,61 6,257; female
1,636,732)
65 years and over: 5% (male 1 1 8,485; female
.159,306) (July 1998 est.)
Population growth rate: 1.3% (1998 est.)
Birth rate: 27.67 births/1,000 population (1998 est.)
Death rate: 7.77 deaths/1 ,000 population (1 998 est.)
Net migration rate: -6.87 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.74 male(s)/female (1998 est.)
455
Tajikistan (continued)
Infant mortality rate: 112.14 deaths/1,000 live
births (1998 est.)
Life expectancy at birth:
total population: 64.48 years
male: 61 .35 years
female: 67.77 years (1 998 est.)
Total fertility rate: 3.53 children born/woman (1998
est.)
Nationality:
noun: Tajikistani(s)
adjective: Tajikistan!
Ethnic groups: Tajik 64.9%, Uzbek 25%, Russian
3.5% (declining because of emigration), other 6.6%
Religions: Sunni Muslim 80%, Shi''a Muslim 5%
Languages: Tajik (official), Russian widely used in
government and business
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
Location: Eastern Africa, bordering the Indian
Ocean, between Kenya and Mozambique
Geographic coordinates: 6 00 S, 35 00 E
Map references: Africa
Area:
total: 945,090 sq km
land: 886,040 sq km
water: 59,050 sq km
note: includes the islands of Mafia, Pemba, and
Zanzibar
Area— comparative: slightly larger than twice the
size of California
Land boundaries:
total: 3,402 km
border countries: Burundi 451 km, Kenya 769 km,
Malawi 475 km, Mozambique 756 km, Rwanda 217
km, Uganda 396 km, Zambia 338 km
Coastline: 1,424 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical along coast to
temperate in highlands
Terrain: plains along coast; central plateau;
highlands in north, south
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kilimanjaro 5,895 m
Natural resources: hydropower potential, tin,
phosphates, iron ore, coal, diamonds, gemstones,
gold, natural gas, nickel
Land use:
arable land: 3%
permanent crops: 1%
permanent pastures: 40%
forests and woodland: 38%
other: 18% (1993 est.)
Irrigated land: 1 ,500 sq km (1 993 est.)
Natural hazards: the tsetse fly; flooding on the
central plateau during the rainy season
457
Tanzania (continued)
Environment— current issues: soil degradation;
deforestation; desertification; destruction of coral
reefs threatens marine habitats; recent droughts
affected marginal agriculture
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: Kilimanjaro is highest point in
Africa
i '' . People
Population: 30,608,769 (July 1998 est.)
Age structure:
0-14 years : 45% (male 6,804,194; female 6,844,81 5)
15-64 years: 53% (male 7,835,705; female
8,236,949)
65 years and over: 2% (male 408,827; female
478,279) (July 1998 est.)
Population growth rate: 2.14% (1998 est.)
Birth rate: 40.75 births/1 ,000 population (1 998 est.)
Death rate: 16.71 deaths/1,000 population (1998
est.)
Net migration rate: -2.61 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.95 ma!e(s)/female
65 years and over: 0.85 male(s)/female (1998 est.)
Infant mortality rate: 96.94 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 46.37 years
male: 44.22 years
female: 48.59 years (1998 est.)
Total fertility rate: 5.49 children born/woman (1998
est.)
Nationality:
noun: Tanzanian(s)
adjective: Janzman
Ethnic groups: mainland— native African 99% (of
which 95% are Bantu consisting of more than 130
tribes), other 1% (consisting of Asian, European, and
Arab)
note: Zanzibar— Arab, native African, mixed Arab and
native African
Religions: mainland— Christian 45%, Muslim 35%,
indigenous beliefs 20%
note: Zanzibar— more than 99% Muslim
Languages: Kiswahili or Swahili (official), Kiunguju
(name for Swahili in Zanzibar), English (official,
primary language of commerce, administration, and
higher education), Arabic (widely spoken in Zanzibar),
many local languages
note: Kiswahili (Swahili) is the mother tongue of Bantu
people living in Zanzibar and nearby coastal
Tanzania; although Kiswahili is Bantu in structure and
origin, its vocabulary draws on a variety of sources,
including Arabic and English, and it has become the
lingua franca of central and eastern Africa; the first
language of most people is one of the local languages
Literacy:
definition: age 15 and over can read and write
Kiswahili (Swahili), English, or Arabic
total population: 67.8%
male: 79 .4%
female: 56.8% (1995 est.)
Country name:
conventional long form: United Republic of Tanzania
conventional short form: Tanzania
former: United Republic of Tanganyika and Zanzibar
Data code: TZ
Government type: republic
National capital: Dar es Salaam
note: some government offices have been transferred
to Dodoma, which is planned as the new national
capital by the end of the 1990s; the National Assembly
now meets there on regular basis
Administrative divisions: 25 regions; Arusha, Dar
es Salaam, Dodoma, Iringa, Kigoma, Kilimanjaro,
Lindi, Mara, Mbeya, Morogoro, Mtwara, Mwanza,
Pemba North, Pemba South, Pwani, Rukwa, Ruvuma,
Shinyanga, Singida, Tabora, Tanga, Zanzibar
Central/South, Zanzibar North, Zanzibar Urban/West,
Ziwa Magharibi
note: although some recent maps have referred to
Ziwa Magharibi as Kagera, the US Board on
Geographic Names has not approved the change
Independence: 26 April 1964; Tanganyika became
independent 9 December 1961 (from UK-administered
UN trusteeship); Zanzibar became independent 19
December 1963 (from UK); Tanganyika united with
Zanzibar 26 April 1 964 to form the United Republic of
Tanganyika and Zanzibar; renamed United Republic of
Tanzania 29 October 1 964
National holiday: Union Day, 26 April (1964)
Constitution: 25 April 1 977; major revisions October
1984
Legal system: based on English common law;
judicial review of legislative acts limited to matters of
interpretation; has not accepted compulsory ICJ
jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Benjamin William MKAPA
(since 23 November 1 995); Vice President Omar Ali
JUMA (since 23 November 1995); note the president
is both chief of state and head of government
head of government: President Benjamin William
MKAPA (since 23 November 1995); Vice President
Omar Ali JUMA (since 23 November 1 995); note— the
president is both chief of state and head of','28bf8a7b65eae0b02fb48826f39cf9a08ea3e208bd7b8a7767d43f6ffa4702e7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd1ff259d664f31537f636f35d537782616fbe97026d1d59caed98e4542c637a',1998,'TH','Thailand','geography',878,'Location: Southeastern Asia, bordering the
Andaman Sea and the Gulf of Thailand, southeast of
Burma
Geographic coordinates: 15 00 N, 100 00 E
Map references: Southeast Asia
Area:
total: 514,000 sq km
land: 51 1,770 sq km
water: 2,230 sq km
Area— comparative: slightly more than twice the
size of Wyoming
Land boundaries:
total: 4,863 km
border countries: Burma 1 ,800 km, Cambodia 803
km, Laos 1 ,754 km, Malaysia 506 km
Coastline: 3,219 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy, warm, cloudy southwest
monsoon (mid-May to September); dry, cool northeast
monsoon (November to mid-March); southern
isthmus always hot and humid
Terrain: central plain; Khorat Plateau in the east;
mountains elsewhere
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Doi Inthanon 2,576 m
Natural resources: tin, rubber, natural gas,
tungsten, tantalum, timber, lead, fish, gypsum, lignite,
fluorite
Land use:
arable land: 34%
permanent crops: 6%
permanent pastures: 2%
forests and woodland: 26%
other: 32% (1993 est.)
Irrigated land: 44,000 sq km (1993 est.)
Natural hazards: land subsidence in Bangkok area
resulting from the depletion of the water table;
droughts
Environment— current issues: air pollution from
vehicle emissions; water pollution from organic and
factory wastes; deforestation; soil erosion; wildlife
populations threatened by illegal hunting
Environment— international agreements:
party to: Climate Change, Endangered Species,
Hazardous Wastes, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Tropica!
Timber 83, Tropical Timber 94
signed, but not ratified: Biodiversity, Law of the Sea
Geography— note: controls only land route from
Asia to Malaysia and Singapore
Location: Southeastern Asia, bordering the Gulf of
Thailand, Gulf of Tonkin, and South China Sea,
alongside China, Laos, and Cambodia
Geographic coordinates: 16 00 N, 106 00 E
Map references: Southeast Asia
Area:
total: 329,560 sq km
land: 325,360 sq km
water: 4,200 sq km
Area— comparative: slightly larger than New','8b70f4081a5d40e38d66ab1805c8eb7907ef8e16d711c31379261d646db77cc2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d62b82388aabebac419361e12279cef35036d44c7e505e29b981e936a39ec4',1998,'TK','Tokelau','geography',886,'Location: Oceania, group of three islands in the
South Pacific Ocean, about one-half of the way from
Hawaii to New Zealand
Geographic coordinates: 9 00 S, 172 00 W
Map references: Oceania
Area:
total: 10 sq km
land: 10 sq km
water: 0 sq km
Area— comparative: about 17 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 101 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical; moderated by trade winds (April to
November)
Terrain: low-lying coral atolls enclosing large
lagoons
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: NEGL
Land use:
arable land: 0% (soil is thin and infertile)
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: lies in Pacific typhoon belt
Environment— current issues: very limited natural
resources and overcrowding are contributing to
emigration to New Zealand
Environment— international agreements:
party to: NA
signed, but not ratified: NA','31190dfee1a701177059716551a37514f2776ab637ba8ac2567aa5bffe253c2e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('387f5f435874c91bdde7053fe42ac60431f3cd5c899fed7892510f3925b6fac7',1998,'TO','Tonga','geography',893,'Location: Oceania, archipelago in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','dba2c3f5cc9763816183b4cbb380a2ba67479dfface76994e5a899d532e5e760','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b61f1444ca5249c3bbb842bcadaab702c7f40df71007b6c854580ffaa6b2c33',1998,'AF','Afghanistan','geography',895,'Location: Caribbean, two island groups in the North
Atlantic Ocean, southeast of The Bahamas
Geographic coordinates: 21 45 N, 71 35 W
Map references: Central America and the
Caribbean
Area:
total: 430 sq km
land: 430 sq km
water: 0 sq km
Area— comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 389 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical; marine; moderated by trade winds;
sunny and relatively dry
Terrain: low, flat limestone; extensive marshes and
mangrove swamps
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Blue Hills 49 m
Natural resources: spiny lobster, conch
Land use:
arable land: 2%
permanent crops: N A%
permanent pastures: NA%
forests and woodland: NA%
other: 98% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: frequent hurricanes
Environment— current issues: limited natural fresh
water resources, private cisterns collect rainwater
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Geography-note: 30 islands (eight inhabited)
Location: Oceania, group of islands in the South
Pacific Ocean, about three-quarters of the way from
Hawaii to Australia
Geographic coordinates: 16 00 S, 167 00 E
Map references: Oceania
Area:
total: 14,760 sq km
land: 14,760 sq km
water: 0 sq km
note: includes more than 80 islands
Area— comparative: slightly larger than Connecticut
Land boundaries: 0 km
Coastline: 2,528 km
Maritime claims: measured from claimed
archipelagic baselines
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by southeast trade
winds
Terrain: mostly mountains of volcanic origin; narrow
coastal plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Tabwemasana 1 ,877 m
Natural resources: manganese, hardwood forests,
fish
Land use:
arable land: 2%
permanent crops: 10%
permanent pastures: 2%
forests and woodland: 75%
other: 11% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: tropical cyclones or typhoons
(January to April); volcanism causes minor
earthquakes
Environment— current issues: a majority of the
population does not have access to a potable and
reliable supply of water; deforestation
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: Desertification, Law of the
Sea','e146547d41fa233512d4f482c4d90256f563205213ba7612169062b64aac9b15','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4bb7b092dfae43ac2fcc43142275a4f3bd19d69efd7e5d68111604d90b6457b',1998,'BS','Bahamas','geography',898,'Location: Oceania, island group consisting of nine
coral atolls in the South Pacific Ocean, about one-half
of the way from Hawaii to Australia
Geographic coordinates: 8 00 S, 178 00 E
Map references: Oceania
Area:
total: 26 sq km
land: 26 sq km
water: 0 sq km
Area— comparative: 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 24 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by easterly trade winds
(March to November); westerly gales and heavy rain
(November to March)
Terrain: very low-lying and narrow coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (1993 est.)
note: Tuvalu''s nine coral atolls have enough soil to
grow coconuts and support subsistence agriculture
Irrigated land: NAsqkm
Natural hazards: severe tropical storms are usually
rare, but, in 1997, there were three cyclones
Environment— current issues: since there are no
streams or rivers and groundwater is not potable, all
water needs must be met by catchment systems with
storage facilities; beachhead erosion because of the
use of sand for building materials; excessive
clearance of forest undergrowth for use as fuel;
damage to coral reefs from the spread of the Crown of
Thorns starfish; T uvalu is very concerned about global
increases in greenhouse gas emissions and their
effect on rising sea levels, which threaten the
country''s underground water table
Environment— international agreements:
party to: Climate Change, Endangered Species,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: Biodiversity, Law of the Sea
l People
Population: 10,444 (July 1998 est.)
Age structure:
0-14 years: 35% (male 1 ,875; female 1 ,804)
15-64 years: 60% (male 2,980; female 3,290)
65 years and over: 5% (male 226; female 269) (July
1998 est.)
Population growth rate: 1 .4% (1998 est.)
Birth rate: 22.6 births/1,000 population (1998 est.)
Death rate: 8.62 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.84 ma!e(s)/female (1 998 est.)
Infant mortality rate: 26.23 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 63.88 years
male: 62.72 years
female: 65.09 years (1998 est.)
Total fertility rate: 3.1 1 children born/woman (1998
est.)
Nationality:
noun: Tuvaluan(s)
adjective: Tuvaluan
Ethnic groups: Polynesian 96%
Religions: Church of Tuvalu (Congregationalist)
97%, Seventh-Day Adventist 1.4%, Baha''i 1%, other
0.6%
Languages: Tuvaluan, English
Literacy: NA; note— education is free and
compulsory from ages 6 through 13
i Government
Country name:
conventional long form: none
conventional short form: Tuvalu
former: Ellice Islands
Data code: TV
Government type: constitutional monarchy with a
parliamentary democracy; began debating republic
status in 1992
National capital: Funafuti
Administrative divisions: none
Independence: 1 October 1978 (from UK)
National holiday: Independence Day, 1 October
(1978)
Constitution: 1 October 1978
Legal system: NA
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II of the UK (since
6 February 1952), represented by Governor General
Manuella TULAGA (since NA June 1994)
head of government: Prime Minister Bikenibeu
PAENIU (since 23 December 1 996) and Deputy
Prime Minister Kokeiya MALUA (since 8 April 1998);
cabinet: Cabinet appointed by the governor general
on the recommendation of the prime minister
elections: the queen is a hereditary monarch;
governor general appointed by the queen on the
recommendation of the prime minister; prime minister
and deputy prime minister elected by and from the
members of Parliament; election last held 8 April 1998
(next to be held NA 2002)
election results: Bikenibeu PAENIU reelected prime
minister by a vote in Parliament of 10 to 2; Kokeiya
MALUA elected deputy prime minister; percent of
Parliament vote— NA
Legislative branch: unicameral Parliament or Fale I
Fono, also called House of Assembly (12 seats— two
from each island with more than 1,000 inhabitants,
one from all the other inhabited islands; members
elected by popular vote to serve four-year terms)
elections: last held 26-27 March 1 998 (next to be held
by NA 2002)
election results: percent of vote— NA; seats—
independents 12
Judicial branch: eight Island Courts; High Court;
note— a chief justice visits twice a year to preside over
sessions of the High Court
Political parties and leaders: there are no political
parties but members of Parliament usually align
themselves in informal groupings
International organization participation: AsDB, C
(special), ESCAP, Intelsat (nonsignatory user), ITU,
Sparteca, SPC, SPF, UNESCO, UPU, WHO, WTrO
(applicant)
Diplomatic representation in the US: Tuvalu does
not have an embassy in the US
Diplomatic representation from the US: the US
does not have an embassy in Tuvalu; the US
ambassador to Fiji is accredited to Tuvalu
Flag description: light blue with the flag of the UK in
the upper hoist-side quadrant; the outer half of the flag
represents a map of the country with nine yellow
five-pointed stars symbolizing the nine islands
Location: Eastern Africa, west of Kenya
Geographic coordinates: 1 00 N, 32 00 E
Map references: Africa
Area:
total: 236,040 sq km
land:! 99,71 Osq km
water: 36,330 sq km
Area— comparative: slightly smaller than Oregon
Land boundaries:
total: 2,698 km
border countries: Democratic Republic of the Congo
765 km, Kenya 933 km, Rwanda 169 km, Sudan 435
km, Tanzania 396 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; generally rainy with two dry
seasons (December to February, June to August);
semiarid in northeast
Terrain: mostly plateau with rim of mountains
Elevation extremes:
lowest point: Lake Albert 621 m
highest point : Margherita (Mount Stanley) 5,1 1 0 m
Natural resources: copper, cobalt, limestone, salt
Land use:
arable land: 25%
permanent crops: 9%
permanent pastures: 9%
forests and woodland: 28%
other: 29% (1993 est.)
Irrigated land: 90 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: draining of
wetlands for agricultural use; deforestation;
overgrazing; soil erosion; poaching is widespread
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
480
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Wetlands
signed, but not ratified: Environmental Modification
Geography— note: landlocked','e444bd6b36b90717d1cb9fa52066713527469682f03e3ee743cde6056daf451f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38b36129d9b382eabdcbb698ab998f7061a8fa0b80f685280a9a397c5472e435',1998,'AE','United Arab Emirates','geography',902,'Location: Middle East, bordering the Gulf of Oman
and the Persian Gulf, between Oman and Saudi
Arabia
Geographic coordinates: 24 00 N, 54 00 E
Map references: Middle East
Area:
total: 82,880 sq km
land: 82,880 sq km
water: 0 sq km
Area— comparative: slightly smaller than Maine
Land boundaries:
total: 867 km
border countries: Oman 41 0 km, Saudi Arabia 457 km
Coastline: 1,318 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; cooler in eastern mountains
Terrain: flat, barren coastal plain merging into rolling
sand dunes of vast desert wasteland; mountains in
east
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal Yibir 1 ,527 m
Natural resources: petroleum, natural gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 2%
forests and woodland: 0%
other: 98% (1 993 est.)
Irrigated land: 50 sq km (1993 est.)
Natural hazards: frequent sand and dust storms
Environment— current issues: lack of natural
freshwater resources being overcome by desalination
plants; desertification; beach pollution from oil spills
Environment— international agreements:
party to: Climate Change, Endangered Species,
Hazardous Wastes, Marine Dumping, Ozone Layer
Protection
signed, but not ratified: Biodiversity, Law of the Sea
Geography— note: strategic location along southern
approaches to Strait of Hormuz, a vital transit point for
world crude oil','9f0aeaf62d882a7f08299e9fed26adec6eb0213be27835f3260fa83488706860','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b1ae351106fafe450a5006c765c885336e374e4d3b3d93e9f262787e09f13b2',1998,'GB','United Kingdom','geography',909,'Location: Western Europe, islands including the
northern one-sixth of the island of Ireland between the
North Atlantic Ocean and the North Sea, northwest of','c787d283c2e22a1f57631ee037062bbb59858683c4c126a28ad13dd81380700a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0daa1c1a071054341c5dec81aafccf924a54ecd135710631b432c684bb59a0a1',1998,'UY','Uruguay','geography',910,'Location: Southern South America, bordering the
South Atlantic Ocean, between Argentina and Brazil
Geographic coordinates: 33 00 S, 56 00 W
Map references: South America
Area:
total: 176,220 sq km
land: 173,620 sq km
water: 2,600 sq km
Area— comparative: slightly smaller than
Washington State
Land boundaries:
total: 1,564 km
border countries : Argentina 579 km, Brazil 985 km
Coastline: 660 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 200 nm; overflight and navigation
guaranteed beyond 12 nm
Climate: warm temperate; freezing temperatures
almost unknown
Terrain: mostly rolling plains and low hills; fertile
coastal lowland
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Cerro Catedral 514 m
Natural resources: fertile soil, hydropower, minor
minerals, fisheries
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 77%
forests and woodland: 6%
other: 10% (1997 est.)
Irrigated land: 7,700 sq km (1997 est.)
Natural hazards: seasonally high winds (the
pampero is a chilly and occasional violent wind which
blows north from the Argentine pampas), droughts,
floods; because of the absence of mountains, which
act as weather barriers, all locations are particularly
493
Uruguay (continued)
vulnerable to rapid changes in weather fronts
Environment— current issues: substantial
pollution from Brazilian industry along border; one-fifth
of country affected by acid rain generated by Brazil;
water pollution from meat packing/tannery industry;
inadequate solid/hazardous waste disposal
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed , but not ratified: Marine Dumping, Marine Life
Conservation','b1f116fef59d54bcbfa6234b67d648c2304bccf87b86454096674711aab839d1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9d99a38677a1516954b2e562e1b486f83e31984542c8d05345952f75d1be3a0',1998,'UZ','Uzbekistan','geography',919,'Location: Central Asia, north of Afghanistan
Geographic coordinates: 41 00 N, 64 00 E
Map references: Commonwealth of Independent
States
Area:
total: 447,400 sq km
land: 425,400 sq km
water : 22,000 sq km
Area— comparative: slightly larger than California
Land boundaries:
total: 6,221 km
border countries: Afghanistan 137 km, Kazakhstan
2,203 km, Kyrgyzstan 1,099 km, Tajikistan 1,161 km,
Turkmenistan 1,621 km
Coastline: 0 km
note : Uzbekistan borders the Aral Sea (420 km)
Maritime claims: none (doubly landlocked)
Climate: mostly midlatitude desert, long, hot
summers, mild winters; semiarid grassland in east
Terrain: mostly flat-to-rolling sandy desert with
dunes; broad, flat intensely irrigated river valleys
along course of Amu Darya, Sirdaryo, and Zarafshon;
Fergana Valley in east surrounded by mountainous
Tajikistan and Kyrgyzstan; shrinking Aral Sea in west
Elevation extremes:
lowest point: Sariqarnish Kuli -12 m
highest point: Adelunga Toghi 4,301 m
Natural resources: natural gas, petroleum, coal,
gold, uranium, silver, copper, lead and zinc, tungsten,
molybdenum
Land use:
arable land: 9%
permanent crops: 1%
permanent pastures: 46%
forests and woodland: 3%
other: 41% (1993 est.)
Irrigated land: 40,000 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: drying up of the Aral
Sea is resulting in growing concentrations of chemical
pesticides and natural salts; these substances are
then blown from the increasingly exposed lake bed
and contribute to desertification; water pollution from
industrial wastes and the heavy use of fertilizers and
pesticides is the cause of many human health
disorders; increasing soil salinization; soil
contamination from agricultural chemicals, including
DDT
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification,
Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography— note: along with Liechtenstein, one of
the only two doubly landlocked countries in the world','017334c978b20bc0842ff9858a2af7cc1362150e0dbe0a475bff3ede68ef918c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d9e99a335c95d5d2aece3da2954cc88ca57ad9487bb04ed47baa03fe65b93a9',1998,'VU','Vanuatu','geography',932,'Location: Northern South America, bordering the
Caribbean Sea and the North Atlantic Ocean,
between Colombia and Guyana
Geographic coordinates: 8 00 N, 66 00 W
Map references: South America, Central America
and the Caribbean
Area:
total: 912,050 sq km
land: 882,050 sq km
water : 30,000 sq km
Area— comparative: slightly more than twice the
size of California
Land boundaries:
total: 4,993 km
border countries: Brazil 2,200 km, Colombia 2,050
km, Guyana 743 km
Coastline: 2,800 km
Maritime claims:
contiguous zone: 15 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; more moderate in
highlands
Terrain: Andes Mountains and Maracaibo Lowlands
in northwest; central plains (llanos); Guiana Highlands
in southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Bolivar (La Columna) 5,007 m
Natural resources: petroleum, natural gas, iron ore,
gold, bauxite, other minerals, hydropower, diamonds
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 20%
forests and woodland: 34%
other: 41% (1993 est.)
Irrigated land: 1 ,900 sq km (1 993 est.)
Natural hazards: subject to floods, rockslides, mud
slides; periodic droughts
Environment— current issues: sewage pollution of
Lago de Valencia; oil and urban pollution of Lago de
Maracaibo; deforestation; soil degradation; urban and
industrial pollution, especially along the Caribbean
coast
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping
Geography— note: on major sea and air routes
linking North and South America','46839b574fe0f95c119a38ee1de8508480a45dcb685a0464d869ec4596a1f783','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('600cd1c1ae44ea4ad543f0a2968c48697a654fbc15b891a715f131419748b230',1998,'WF','Wallis and Futuna','geography',940,'Location: Oceania, islands in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','e0b14fbea7a6600686b865ca0f5eac39b8c110a5a9fda69667701ce167afead3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db4a5546f5f7b54d610a3eabe0c604f48d7a1aa0e620b31c8e262cb7e340bdf5',1998,'EH','Western Sahara','geography',941,'Location: Northern Africa, bordering the North
Atlantic Ocean, between Mauritania and Morocco
Geographic coordinates: 24 30 N, 13 00 W
Map references: Africa
Area:
total: 266,000 sq km
land: 266,000 sq km
water: 0 sq km
Area— comparative: about the size of Colorado
Land boundaries:
total: 2,046 km
border countries: Algeria 42 km, Mauritania 1 ,561 km,
Morocco 443 km
Coastline: 1,110 km
Maritime claims: contingent upon resolution of
sovereignty issue
Climate: hot, dry desert; rain is rare; cold offshore air
currents produce fog and heavy dew
Terrain: mostly low, flat desert with large areas of
rocky or sandy surfaces rising to small mountains in
south and northeast
Elevation extremes:
lowest point: Sebjet Tah -55 m
highest point: unnamed location 463 m
Natural resources: phosphates, iron ore
Land use:
arable land: 19%
permanent crops: 24%
permanent pastures: 0%
forests and woodland: 47%
other: 10% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: hot, dry, dust/sand-laden sirocco
wind can occur during winter and spring; widespread
harmattan haze exists 60% of time, often severely
restricting visibility
Environment— current issues: sparse water and
arable land
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Map references: World, Time Zones
Area:
total: 510.072 million sq km
/and; 148.94 million sq km
water: 361. 132 million sq km
note: 70.8% of the world''s surface is water, 29.2% is
land
Area— comparative: land area about 15 times the
size of the US
Land boundaries: the land boundaries in the world
total 251 ,480.24 km (not counting shared boundaries
twice)
Coastline: 356,000 km
Maritime claims:
contiguous zone: 24 nm claimed by most but can vary
continental shelf: 200-m depth claimed by most or to
depth of exploitation, others claim 200 nm or to the
edge of the continental margin
exclusive fishing zone: 200 nm claimed by most but
can vary
exclusive economic zone: 200 nm claimed by most
but can vary
territorial sea: 12 nm claimed by most but can vary
note: boundary situations with neighboring states
prevent many countries from extending their fishing or
economic zones to a full 200 nm; 43 nations and other
areas that are landlocked include Afghanistan,
Andorra, Armenia, Austria, Azerbaijan, Belarus,
Bhutan, Bolivia, Botswana, Burkina Faso, Burundi,
Central African Republic, Chad, Czech Republic,
Ethiopia, Holy See (Vatican City), Hungary,
Kazakhstan, Kyrgyzstan, Laos, Lesotho,
Liechtenstein, Luxembourg, Malawi, Mali, Moldova,
Mongolia, Nepal, Niger, Paraguay, Rwanda, San
Marino, Slovakia, Swaziland, Switzerland, Tajikistan,
The Former Yugoslav Republic of Macedonia,
Turkmenistan, Uganda, Uzbekistan, West Bank,
Zambia, Zimbabwe
Climate: two large areas of polar climates separated
by two rather narrow temperate zones from a wide
equatorial band of tropical to subtropical climates
Terrain: the greatest ocean depth is the Mariana
Trench at 10,924 m in the Pacific Ocean
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Mount Everest 8,848 m
Natural resources: the rapid using up of
nonrenewable mineral resources, the depletion of
forest areas and wetlands, the extinction of animal
and plant species, and the deterioration in air and
water quality (especially in Eastern Europe and the
former USSR) pose serious long-term problems that
governments and peoples are only beginning to
address
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 26%
forests and woodland: 32%
other: 31% (1993 est.)
Irrigated land: 2,481,250 sq km (1993 est.)
Natural hazards: large areas subject to severe
weather (tropical cyclones), natural disasters
(earthquakes, landslides, tsunamis, volcanic
eruptions)
Environment— current issues: large areas subject
to overpopulation, industrial disasters, pollution (air,
water, acid rain, toxic substances), loss of vegetation
(overgrazing, deforestation, desertification), loss of
wildlife, soil degradation, soil depletion, erosion
Environment— international agreements:
selected international environmental agreements are
included under the Environment— international
agreements entry for each country and in the Selected
International Environmental Agreements appendix','8685442d71d286b8f07e5e518c0d1d30f836dfce3c71c22ae1585341351c37ec','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec8859700dd530406500bb3a82af80948af649ca38348b53d06ec149021c2751',1998,'YE','Yemen','geography',949,'Location: Middle East, bordering the Arabian Sea,
Gulf of Aden, and Red Sea, between Oman and Saudi
Arabia
Geographic coordinates: 15 00 N, 48 00 E
Map references: Middle East
Area:
total: 527,970 sq km
land: 527,970 sq km
water: 0 sq km
note : includes Perim, Socotra, the former Yemen
Arab Republic (YAR or North Yemen), and the former
People''s Democratic Republic of Yemen (PDRY or
South Yemen)
Area— comparative: slightly larger than twice the
size of Wyoming
Land boundaries:
total: 1,746 km
border countries: Oman 288 km, Saudi Arabia 1,458
km
Coastline: 1,906 km
Maritime claims:
contiguous zone: 1 8 nm in the North; 24 nm in the
South
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly desert; hot and humid along west
coast; temperate in western mountains affected by
seasonal monsoon; extraordinarily hot, dry, harsh
desert in east
Terrain: narrow coastal plain backed by flat-topped
hills and rugged mountains; dissected upland desert
plains in center slope into the desert interior of the
Arabian Peninsula
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal an Nabi Shu''ayb 3,760 m
Natural resources: petroleum, fish, rock salt,
marble, small deposits of coal, gold, lead, nickel, and
copper, fertile soil in west
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 30%
forests and woodland: 4%
other: 63% (1993 est.)
Irrigated land: 3,600 sq km (1993 est.)
Natural hazards: sandstorms and dust storms in
summer
Environment— current issues: very limited natural
fresh water resources; inadequate supplies of potable
water; overgrazing; soil erosion; desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location on Bab el
Mandeb, the strait linking the Red Sea and the Gulf of
Aden, one of world''s most active shipping lanes','7f21343a9a2d0a5c6d11462bce6fb8e8d19c4809f4907148d4ec3780b73b05cd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31e653b5ac754340d0e34010e3b40c00f03c3dd5f769ea16811602a0d2f19e82',1998,'ZM','Zambia','geography',957,'Location: Southern Africa, east of Angola
Geographic coordinates: 1 5 00 S, 30 00 E
Map references: Africa
Area:
total: 752,61 Osq km
land: 740,720 sq km
water: 1 1 ,890 sq km
Area— comparative: slightly larger than Texas
Land boundaries:
total: 5,664 km
border countries: Angola 1 ,1 1 0 km, Democratic
Republic of the Congo 1 ,930 km, Malawi 837 km,
Mozambique 41 9 km, Namibia 233 km, Tanzania 338
km, Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; modified by altitude; rainy season
(October to April)
Terrain: mostly high plateau with some hills and
mountains
Elevation extremes:
lowest point: Zambezi river 329 m
highest point: in Mafinga Hills 2,301 m
Natural resources: copper, cobalt, zinc, lead, coal,
emeralds, gold, silver, uranium, hydropower potential
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 40%
forests and woodland: 39%
other: 14% (1993 est.)
Irrigated land: 460 sq km (1993 est.)
Natural hazards: tropical storms (November to
April)
Environment— current issues: air pollution and
resulting acid rain in the mineral extraction and
refining region; poaching seriously threatens
rhinoceros and elephant populations; deforestation;
soil erosion; desertification; lack of adequate water
treatment presents human health risks
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked','1a5efe8309978668ffac09384ce316fbd27cd8b2fbe4a513e2369c0aaa4db3ae','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

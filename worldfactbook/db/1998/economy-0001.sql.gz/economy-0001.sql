SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4e8f70fba13dcf0faaccfead9ffc201bc4d5a0badf6b6a2c5aabe968239a97b',1998,'SL','Sierra Leone','economy',233,'@Sierra Leone:Geography
Location: Western Africa, bordering the North Atlantic Ocean, between
Guinea and Liberia
Geographic coordinates: 8 30 N, 11 30 W
Map references: Africa
Area: total: 71,740 sq km land: 71,620 sq km water: 120 sq km
Area-comparative: slightly smaller than South Carolina
Land boundaries: total: 958 km border countries: Guinea 652 km, Liberia
306 km
Coastline: 402 km
Maritime claims: territorial sea: 200 nm continental shelf: 200-m depth or
to the depth of exploitation
Climate: tropical; hot, humid; summer rainy season (May to December);
winter dry season (December to April)
Terrain: coastal belt of mangrove swamps, wooded hill country, upland
plateau, mountains in east
Elevation extremes: lowest point: Atlantic Ocean 0 m highest point: Loma
Mansa (Bintimani) 1,948 m
Natural resources: diamonds, titanium ore, bauxite, iron ore, gold, chromite
Land use: arable land: 7% permanent crops: 1% permanent pastures: 31%
forests and woodland: 28% other: 33% (1993 est.)
Irrigated land: 290 sq km (1993 est.)
Natural hazards: dry, sand-laden harmattan winds blow from the Sahara
(November to May); sandstorms, dust storms
Environment-current issues: rapid population growth pressuring the
environment; overharvesting of timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in deforestation and soil
exhaustion; civil war depleting natural resources; overfishing
Environment-international agreements: party to: Biodiversity, Climate
Change, Desertification, Endangered Species, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Whaling signed, but not ratified:
Environmental Modification
@Sierra Leone:People
Population: 5,080,004 (July 1998 est.)
Age structure: 0-14 years: 45% (male 1,130,728; female 1,167,084) 15-64
years: 52% (male 1,257,901; female 1,367,902) 65 years and over: 3%
(male 79,113; female 77,276) (July 1998 est.)
Population growth rate: 4.01% (1998 est.)
Birth rate: 46.16 births/1,000 population (1998 est.)
Death rate: 17.25 deaths/1,000 population (1998 est.)
Net migration rate: 11.18 migrant(s)/1,000 population (1998 est.)
Sex ratio: at birth: 1.03 male(s)/female under 15 years: 0.96 male(s)/female
15-64 years: 0.91 male(s)/female 65 years and over: 1.02 male(s)/female
(1998 est.)
Infant mortality rate: 129.38 deaths/1,000 live births (1998 est.)
Life expectancy at birth: total population: 48.57 years male: 45.56 years
female: 51.66 years (1998 est.)
Total fertility rate: 6.23 children born/woman (1998 est.)
Nationality: noun: Sierra Leonean(s) adjective: Sierra Leonean
Ethnic groups: 20 native African tribes 90% (Temne 30%, Mende 30%,
other 30%), Creole 10% (descendents of freed Jamaican slaves who were
settled in the Freetown area in the late-eighteenth century), refugees from
Liberia''s recent civil war, small numbers of Europeans, Lebanese,
Pakistanis and Indians
Religions: Muslim 60%, indigenous beliefs 30%, Christian 10%
Languages: English (official, regular use limited to literate minority),
Mende (principal vernacular in the south), Temne (principal vernacular in
the north), Krio (English-based Creole, spoken by the descendents of freed
Jamaican slaves who were settled in the Freetown area, a lingua franca and
a first language for 10% of the population but understood by 95%)
Literacy: definition: age 15 and over can read and write in English, Mende,
Temne, or Arabic total population: 31.4% male: 45.4% female: 18.2%
(1995 est.)
@Sierra Leone:Government
Country name: conventional long form: Republic of Sierra Leone
conventional short form: Sierra Leone
Data code: SL
Government type: constitutional democracy
National capital: Freetown
Administrative divisions: 3 provinces and 1 area*; Eastern, Northern,
Southern, Western*
Independence: 27 April 1961 (from UK)
National holiday: Republic Day, 27 April (1961)
Constitution: 1 October 1991; subsequently amended several times
Legal system: based on English law and customary laws indigenous to local
tribes; has not accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch: chief of state: President Ahmad Tejan KABBAH
(inaugurated 29 March 1996); note-the president is both the chief of state
and head of government head of government: President Ahmad Tejan
KABBAH (inaugurated 29 March 1996); note-the president is both the
chief of state and head of government cabinet: Ministers of State appointed
by the president with the approval of the House of Representatives; the
cabinet is responsible to the president elections: president elected by
popular vote for a five-year term; election held 26-27 February 1996 (next
to be held NA 2001); note-president''s tenure of office is limited to 2 five-
year terms election results: Ahmad Tejan KABBAH elected president;
percent of popular vote-first round KABBAH 36.0%, second round
KABBAH 59.5%
Legislative branch: unicameral House of Representatives (80 seats, 68
elected, 12 filled by paramount chiefs elected in separate elections;
members serve five-year terms) elections: last held 26-27 February 1996
(next to be held 2001) election results: percent of vote by party-NA; seats
by party-SLPP 27, UNPP 17, PDP 12, APC 5, NUP 4, DCP 3; note-first
elections since the former House of Representatives was shut down by the
military coup of 29 April 1992
Judicial branch: Supreme Court
Political parties and leaders: 15 parties registered for the February 1996
elections; National Peoples Party or NPP [Andrew TURAY |; Democratic
Center Party or DCP [Abu KOROMA]; Peoples Progressive Party or PPP
[Edward KAMARA, chairman]; Coalition for Progress Party or CPP
[Geredine WILLIAMS-SARHO)}]; National Unity Movement or NUM [John
Desmond Fashole LUKE]; United National Peoples Party or UNPP [John
KARIFA-SMART]; Peoples Democratic Party or PDP [Thaimu
BANGURA, chairman]; All Peoples Congress or APC [Edward
Mohammed TURAY, chairman]; National Republican Party or NRP [Sahr
Stephen MAMBU]; Social Democratic Party or SDP [Andrew Victor
LUNGAY]; Peoples National Convention or PNC [Edward John
KARGBO, chairman]; National Unity Party or NUP [Dr. John KARIMU,
chairman]; Sierra Leone Peoples Party or SLPP [President Tejan KABBAH,
chairman]; National Democratic Alliance or NDA [Amadu M. B.
JALLOH]; National Alliance for Democracy Party or NADP [Mohamed
Yahya SILLAH]
International organization participation: ACP, AfDB, C, CCC, ECA,
ECOWAS, FAO, G-77, IAEA, IBRD, ICAO, ICFTU, ICRM, IDA, IDB,
IFAD, IFC,
IFRCS, ILO, IMF, IMO, Intelsat (nonsignatory user), Interpol, IOC,
ITU, NAM, OAU, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL,
WEFTU, WHO,
WIPO, WMO, WToO, WTrO
Diplomatic representation in the US: chief of mission: Ambassador John
Ernest LEIGH chancery: 1701 19th Street NW, Washington, DC 20009
telephone: [1] (202) 939-9261 through 9263 FAX: [1] (202) 483-1793
Diplomatic representation from the US: chief of mission: Ambassador John
L. HIRSCH embassy: Corner of Walpole and Siaka Stevens Streets,
Freetown mailing address: use embassy street address telephone: [232] (22)
226481 through 226485 FAX: [232] (22) 225471
Flag description: three equal horizontal bands of light green (top), white,
and light blue
@Sierra Leone:Economy
Economy-overview: Sierra Leone has substantial mineral, agricultural, and
fishery resources. However, the economic and social infrastructure is not
well developed, and serious social disorders continue to hamper economic
development. The seizure of power by the new Armed Forces
Revolutionary Council (AFRC) in May 1997 led to UN sanctions and a
sharp drop in GDP. About two-thirds of the working-age population
engages in subsistence agriculture. Manufacturing consists mainly of the
processing of raw materials and of light manufacturing for the domestic
market. Bauxite and rutile mines have been shut down by civil strife. The
major source of hard currency is found in the mining of diamonds, the large
majority of which are smuggled out of the country.
GDP: purchasing power parity-$2.65 billion (1997 est.)
GDP-real growth rate: -27% (1997 est.)
GDP-per capita: purchasing power parity-$540 (1997 est.)
GDP-composition by sector: agriculture: 39% industry: 27% services: 34%
(1995)
Inflation rate-consumer price index: 40% (1997 est.)
Labor force: total: 1.369 million (1981 est.) by occupation: agriculture 65%,
industry 19%, services 16% (1981 est.) note: only about 65,000 wage
earners (1985)
Unemployment rate: NA%
Budget: revenues: $96 million expenditures: $150 million, including capital
expenditures of $NA (1996 est.)
Industries: mining (diamonds); small-scale manufacturing (beverages,
textiles, cigarettes, footwear); petroleum refining
Industrial production growth rate: NA%
Electricity-capacity: 126,000 kW (1995)
Electricity-production: 230 million kWh (1995)
Electricity-consumption per capita: 48 kWh (1995)
Agriculture-products: rice, coffee, cocoa, palm kernels, palm oil, peanuts;
poultry, cattle, sheep, pigs; fish
Exports: total value: $47 million (f.0.b., 1996); note-much reduced in 1997
by civil warfare commodities: diamonds, rutile, cocoa, coffee, fish partners:
US 20%, Belgium 20%, Spain 13%, UK 6%, other Western Europe
Imports: total value: $211 million (c.i.f., 1996) commodities: foodstuffs,
machinery and equipment, fuels and lubricants partners: Cote d''Ivoire, EU
countries, India
Debt-external: $1.1 billion (1996)
Economic aid: recipient: ODA, $NA
Currency: 1 leone (Le) = 100 cents
Exchange rates: leones (Le) per US$1-1,312.37 (December 1997), 967.72
(1997), 920.73 (1996), 755.22 (1995), 586.74 (1994), 567.46 (1993)
Fiscal year: 1 July-30 June','85ead6dbd0cf19327d2d87c8313daaa4fe10e9fa7b6f3bd3a54be2a210f2174a','internet-archive','1998-cia-world-factbook-united-states-central-intelligence-agency','txt','ed8d799a5289d0958a7a95ba11403072d40c0ab0f88fcf382252becb0759ed16','https://archive.org/download/1998-cia-world-factbook-united-states-central-intelligence-agency/1998-cia-world-factbook-united-states-central-intelligence-agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1ad52c28a593bac875196627178cd6c5bba8a391c82306e775639cbc5d0b35b',1998,'US','United States','economy',10,'Economy— overview
GDP
GDP— real growth rate
GDP— per capita
GDP— composition by sector
agriculture
industry
services
Inflation rate— consumer price index
Labor force
total
by occupation
Unemployment rate
Budget
revenues
expenditures
Industries
Industrial production growth rate
Electricity— capacity
Electricity— production
Electricity— consumption per capita
Agriculture— products
Exports
total value
commodities
partners
Imports
total value
commodities
partners
Debt— external
Economic aid
donor
recipient
Currency
Exchange rates
Fiscal year
Economy— overview: Afghanistan is an extremely
poor, landlocked country, highly dependent on
farming and livestock raising (sheep and goats).
Economic considerations have played second fiddle
to political and military upheavals during more than 18
years of war, including the nearly 10-year Soviet
military occupation (which ended 15 February 1989).
During the war one-third of the population fled the
country, with Pakistan and Iran sheltering a combined
peak of more than 6 million refugees. Now, only
750,000 registered Afghan refugees remain in
Pakistan and about 1.2 million in Iran. Another 1
million have probably moved into and around urban
areas within Afghanistan. Gross domestic product has
fallen substantially over the past 18 years because of
the loss of labor and capital and the disruption of trade
and transport. Much of the population continues to
suffer from insufficient food, clothing, housing, and
medical care. Inflation remains a serious problem
throughout the country, with one estimate putting the
rate at 240% in Kabul in 1996. Numerical data are
likely to be either unavailable or unreliable.
GDP: purchasing power parity— $19.3 billion (1997
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $800
(1997 est.)
GDP— composition by sector:
agriculture: 53%
industry: 28.5%
services: ^.5% (1990)
Inflation rate— consumer price index: 240%
(1996 est.)
Labor force:
total: 7.1 million
by occupation: agriculture and animal husbandry
67.8%, industry 10.2%, construction 6.3%, commerce
5.0%, services and other 10.7% (1980 est.)
Unemployment rate: 8% (1995 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: small-scale production of textiles, soap,
furniture, shoes, fertilizer, and cement; handwoven
carpets; natural gas, oil, coal, copper
Electricity— capacity: 494,000 kW (1995)
Electricity— production: 655 million kWh (1995)
Electricity-consumption per capita: 37 kWh
(1995)
Agriculture— products: wheat, fruits, nuts, karakul
pelts; wool, mutton
Exports:
total value: $80 million (1 996 est.)
commodities: fruits and nuts, handwoven carpets,
wool, cotton, hides and pelts, precious and
semi-precious gems
partners: FSU, Pakistan, Iran, Germany, India, UK,
Belgium, Luxembourg, Czechoslovakia
Imports:
total value: $ 150 million (1996 est.)
commodities: food and petroleum products; most
consumer goods
partners: FSU, Pakistan, Iran, Japan, Singapore,
India, South Korea, Germany
Debt— external: $2.3 billion (March 1991 est.)
Economic aid:
recipient: ODA; about $45 million in UN aid plus
additional bilateral aid and aid in kind (1997)
note: US provided $450 million in bilateral assistance
(1985-93); US continues to contribute to multilateral
assistance through the UN programs of food aid,
immunization, land mine removal, and a wide range of
aid to refugees and displaced persons
Currency: 1 afghani (AF) = 100 puls
Exchange rates: afghanis (Af) per US$1— 17,000
(December 1996), 7,000 (January 1995), 1,900
(January 1994), 1,019 (March 1993), 850 (1991);
note— these rates reflect the free market exchange
rates rather than the official exchange rate, which was
fixed at 50.600 afghanis to the dollar until 1 996, when
it rose to 2,262.65 per dollar, and finally became fixed
again at 3,000.00 per dollar on April 1996
Fiscal year: 21 March— 20 March','680053dbcedc43bfe526dec83130ce1e92ad9b57765fd071910941902a303ba0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b327d1e6f0a3e5995a7ca4a72bad3c194a1bdb8ca12af6f35539dcb23472de0',1998,'AL','Albania','economy',19,'Economy— overview: An extremely poor country by
European standards, Albania is making the difficult
transition to a more open-market economy. The
economy rebounded in 1993-95 after a severe
depression accompanying the collapse of the previous
centrally planned system in 1 990 and 1 991 . However, a
weakening of government resolve to maintain
stabilization policies in the election year of 1 996
contributed to renewal of inflationary pressures,
spurred by the budget deficit which exceeded 12%. The
collapse of financial pyramid schemes in early 1997 —
which had attracted deposits from a substantial portion
of Albania''s adult population— triggered severe social
unrest which led to more than 1 ,500 deaths,
widespread destruction of property, and an 8% drop in
GDP. The new government installed in July 1997 has
taken strong measures to restore public order and to
revive economic activity and trade. The economy
continues to be bolstered by remittances of some 20%
of the labor force which works abroad, mostly in Greece
and Italy. These remittances supplement GDP and help
offset the large foreign trade deficit. Most agricultural
land was privatized in 1992, substantially improving
peasant incomes.
GDP: purchasing power parity— $4.5 billion (1 997 est.)
GDP— real growth rate: -8% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,370
(1997 est.)
GDP— composition by sector:
agriculture: 56%
industry: 21%
services: 23% (1995)
Inflation rate— consumer price index: 40% (1997
est.)
Labor force:
total: 1.692 million (1994 est.) (including 352,000
emigrant workers and 261 ,000 domestically
unemployed)
by occupation: agriculture (nearly all private) 49.5%,
private sector 22.2%, state (nonfarm) sector 28.3%
(including state-owned industry 7.8%); note— includes
only those domestically employed
Unemployment rate: 14% (October 1997) officially,
but likely to be as high as 28%
Budget:
revenues; $624 million
expenditures: $996 million, including capital
expenditures of $NA
Industries: food processing, textiles and clothing;
lumber, oil, cement, chemicals, mining, basic metals,
hydropower
Industrial production growth rate: 6% (1995 est.)
Electricity— capacity: 1.892 million kW (1995)
Electricity— production: 4.435 billion kWh (1995)
Electricity— consumption per capita: 1 ,31 4 kWh
(1995)
Agriculture— products: wide range of
temperate-zone crops and livestock
Exports:
total value: $228 million (f.o.b., 1996 est.)
commodities: asphalt, metals and metallic ores,
electricity, crude oil, vegetables, fruits, tobacco
partners: Italy, Greece, Germany, Belgium, US
Imports:
total value: $879 million (f.o.b., 1996 est.)
commodities: machinery, consumer goods, grains
partners: Italy, Greece, Bulgaria, Turkey, The Former
Yugoslav Republic of Macedonia
Debt— external: $645 million (1996)
Economic aid:
recipient: $630 million pledged 1997
Currency: 1 lek (L) = 100 qintars
Exchange rates: leke (L) per US$1— 152.28
(January 1998), 148.93 (1997), 104.50 (1996), 92.70
(1995), 94.62 (1994), 102.06 (1993)
Fiscal year: calendar year
4','f482a5c061ec83f6a566510c0913dac2d705e1aa06f3e291d5078c147ff5a6d7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02dedf1cf9fc323c50e3f0cfb46753e36b80fc849945098e1cf9122ec5fe1a24',1998,'DZ','Algeria','economy',26,'Economy— overview: The hydrocarbons sector is
the backbone of the economy, accounting for roughly
57% of government revenues, 25% of GDP, and
almost all export earnings. Algeria has the fifth-largest
reserves of natural gas in the world and is the second
largest gas exporter; it ranks fourteenth for oil
reserves. Algiers'' efforts to reform one of the most
centrally planned economies in the Arab world began
after the 1 986 collapse of world oil prices plunged the
country into a severe recession. In 1989, the
government launched a comprehensive,
IMF-supported program to achieve economic
stabilization and to introduce market mechanisms into
the economy. Despite substantial progress toward
economic adjustment, in 1992 the reform drive stalled
as Algiers became embroiled in political turmoil. In
September 1 993, a new government was formed, and
one priority was the resumption and acceleration of
the structural adjustment process. Burdened with a
heavy foreign debt, Algiers concluded a one-year
standby arrangement with the IMF in April 1994 and
the following year signed onto a three-year extended
fund facility. Progress on economic reform, a Paris
Club debt rescheduling in 1 995, and oil and gas sector
expansion have contributed to a recovery since 1995.
Investments in developing hydrocarbon resources are
likely to maintain growth and export earnings.
Continuing but gradual government efforts to attract
foreign and domestic investment outside that sector
seek to diversify the economy and tackle problems of
high unemployment and falling living standards,
problems as yet untouched by the macroeconomic
turnaround.
GDP: purchasing power parity— $1 20.4 billion (1 997
est.)
GDP— real growth rate: 2.5% (1997 est.)
GDP— per capita: purchasing power parity— $4,000
(1997 est.)
GDP— composition by sector:
agriculture: 12%
industry: 50%
sen/ices: 38% (1 995 est.)
Inflation rate— consumer price index: 7% (1997
est.)
Labor force:
total: 7.8 million (1996 est.)
by occupation: government 29.5%, agriculture 22%,
| construction and public works 1 6.2%, industry 1 3.6%,
commerce and services 1 3.5%, transportation and
communication 5.2% (1 989)
Unemployment rate: 28% (1997 est.)
Budget:
revenues: $13.7 billion
expenditures: billion, including capital
expenditures of $5.1 million (1996 est.)
Industries: petroleum, natural gas, light industries,
mining, electrical, petrochemical, food processing
Industrial production growth rate: NA%
Electricity— capacity: 6.007 million kW (1995)
Electricity— production: 19.1 billion kWh (1995)
Electricity— consumption per capita: 630 kWh
(1995)
Agriculture— products: wheat, barley, oats,
grapes, olives, citrus, fruits; sheep, cattle
Exports:
total value: $ 13.1 billion (f.o.b., 1997 est.)
commodities: petroleum and natural gas 97%
partners: Italy 18.8%, US 14.8%, France 11.8%,
Spain 8%, Germany 7.9% (1995 est.)
Imports:
total value : $1 0 billion (f.o.b., 1 997 est.)
commodities: capital goods, food and beverages,
consumer goods
partners: France 29%, Spain 10.5%, Italy 8.2%, US
8%, Germany 5.6% (1995 est.)
Debt— external: $33 billion (1997 est.)
Economic aid:
recipient : ODA, $420 million (1996)
Currency: 1 Algerian dinar (DA) = 100 centimes
Exchange rates: Algerian dinars (DA) per US$1 —
58.969 (January 1 998), 57.707 (1 997), 54.749 (1 996),
47.663 (1995), 35.059 (1994), 23.345 (1993)
Fiscal year: calendar year
Economy— overview: Spain''s mixed capitalist
economy supports a GDP that on a per capita basis is
three-fourths that of the four leading West European
economies. Its center-right government has staked
much on gaining admission to the first group of countries
to implement the European single currency and, based
on economic indicators, Madrid appears poised to be in
EMU from the outset. The deficit-to-GDP ratio is 2.3%,
the debt-to-GDP ratio is expected to be around 68%,
and inflation is approximately 2%. Moreover, the AZNAR
administration has continued to advocate liberalization,
privatization, and deregulation of the economy, and has
introduced some tax reforms to that end.
Unemployment, nonetheless, remains the highest in the
EU at 21%. The government, for political reasons, has
made only limited progress in changing labor laws or
reforming pension schemes, which are key to the
sustainability of both Spain’s internal economic
advances and its competitiveness in a single currency
area.
GDP: purchasing power parity— $642.4 billion (1 997
est.)
GDP— real growth rate: 3.3% (1997 est.)
GDP— per capita: purchasing power parity —
$16,400 (1997 est.)
GDP— composition by sector:
agriculture: 3.6%
industry: 33.6%
services: 62.8% (1995 est.)
Inflation rate— consumer price index: 2.1% (1997
est.)
Labor force:
fo/a/; 16.2 million
by occupation: services 64%, manufacturing, mining,
and construction 28%, agriculture 8% (1997 est.)
Unemployment rate: 21% (1997 est.)
Budget:
revenues; $11 3 billion
expenditures: $139 billion, including capital
expenditures of $15 billion (1995)
Industries: textiles and apparel (including footwear),
food and beverages, metals and metal manufactures,
chemicals, shipbuilding, automobiles, machine tools,
tourism
Industrial production growth rate: -0.8% (1996)
Electricity— capacity: 39.583 million kW (1995)
Electricity— production: 154.144 billion kWh
(1995)
Electricity— consumption per capita: 4,026 kWh
(1995)
Agriculture— products: grain, vegetables, olives,
wine grapes, sugar beets, citrus; beef, pork, poultry,
dairy products; fish catch of 867,000 metric tons in
1993
Exports:
total value: $ 94.5 billion (f.o.b., 1995)
commodities : cars and trucks, semifinished
manufactured goods, foodstuffs, machinery (1994)
partners: EU 72.1%, US 4.2%, other developed
countries 7.9% (1996)
Imports:
total value: $ 118.3 billion (c.i.f., 1995)
commodities : machinery, transport equipment, fuels,
semifinished goods, foodstuffs, consumer goods,
chemicals (1994)
partners: EU 65.6%, US 6.6%, other developed
countries 11.5%, Middle East 6.2% (1996)
Debt— external: $90 billion (1993 est.)
Economic aid:
donor: ODA, $1 .213 billion (1993)
Currency: 1 peseta (Pta) = 100 centimos
Exchange rates: pesetas (Ptas) per US$1— 153.94
(January 1998), 146.41 (1997), 126.66(1996), 124.69
(1995), 133.96 (1994), 127.26 (1993)
Fiscal year: calendar year','8c760a5573ab94ab7a18db92f85c205baa1a69bf95e5f627bb2962f99b0c5dcf','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a7f1b00728b763260a88df285d2f33913fefe5f3e1a1d149a32aa423ec8cab9',1998,'AS','American Samoa','economy',31,'Economy— overview: This is a traditional
Polynesian economy in which more than 90% of the
land is communally owned. Economic activity is
strongly linked to the US, with which American Samoa
conducts the great bulk of its foreign trade. Tuna
fishing and tuna processing plants are the backbone
of the private sector, with canned tuna the primary
export. Transfers from the US Government add
substantially to American Samoa''s economic
well-being. According to one observer, attempts by
the government to develop a larger and broader
economy are restrained by Samoa''s remote location,
its limited transportation, and its devastating
hurricanes. Tourism, a developing sector, may be
held back in 1998 by the financial difficulties in East
Asia.
GDP: purchasing power parity— $150 million (1995
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $2,600
(1995 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA %
Labor force:
total: 14,400 (1990)
by occupation: government 33%, tuna canneries
34%, other 33% (1990)
Unemployment rate: 12% (1991)
Budget:
revenues; $97 million ($43 million in local revenue
and $54 million in grant revenue)
expenditures: $NA, including capital expenditures of
$NA (FY90/91)
Industries: tuna canneries (largely dependent on
foreign fishing vessels), handicrafts
Industrial production growth rate: NA%
Electricity— capacity: 33,000 kW (1995)
Electricity— production: 105 million kWh (1995)
Electricity— consumption per capita: 1 ,830 kWh
(1995)
Agriculture— products: bananas, coconuts,
vegetables, taro, breadfruit, yams, copra, pineapples,
papayas; dairy farming
Exports:
total value: $ 318 million (f.o.b., 1992)
commodities: canned tuna 93%
partners: US 99.6%
Imports:
total value: $41 8 million (c.i.f., 1992)
commodities: materials for canneries 56%, food 8%,
petroleum products 7%, machinery and parts 6%
partners: US 62%, Japan 9%, NZ 7%, Australia 11%,
Fiji 4%, other 7%
Debt— external: $NA
Economic aid:
recipient ; ODA, $NA
note: important financial support from the US
Currency: 1 US dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October— 30 September
Economy— overview: Tourism, the mainstay of
Andorra''s tiny, well-to-do economy, accounts for
roughly 80% of GDP. An estimated 10 million tourists
visit annually, attracted by Andorra''s duty-free status
and by its summer and winter resorts. Andorra''s
comparative advantage has recently eroded as the
economies of neighboring France and Spain have
been opened up, providing broader availability of
goods and lower tariffs. The banking sector, with its
"tax haven" status, also contributes substantially to
the economy. Agricultural production is limited by a
scarcity of arable land, and most food has to be
imported. The principal livestock activity is sheep
raising. Manufacturing consists mainly of cigarettes,
cigars, and furniture. Andorra is a member of the EU
Customs Union and is treated as an EU member for
trade in manufactured goods (no tariffs) and as a
non-EU member for agricultural products.
GDP: purchasing power parity— $1.2 billion (1995
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity —
$18,000 (1995 est.)
GDP— composition by sector:
agriculture : NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force: NA
Unemployment rate: 0%
Budget:
revenues: $138 million
expenditures: $177 million, including capital
expenditures of $NA (1993)
Industries: tourism (particularly skiing), sheep,
timber, tobacco, banking
Industrial production growth rate: NA%
Electricity— capacity: 35,000 kW (1992)
Electricity— production: 140 million kWh (1992)
Electricity— consumption per capita: NA kWh;
note— Andorra exports most of its electricity to France
and Spain
Agriculture— products: small quantities of tobacco,
rye, wheat, barley, oats, vegetables; sheep raising
Exports:
total value: $47 million (f.o.b., 1995)
commodities: electricity, tobacco products, furniture
partners: France 49%, Spain 47%
Imports:
total value: $1 billion (1995)
10
commodities: consumer goods, food
partners: France, Spain, US 4.2%
Debt— external: $NA
Economic aid: none
Currency: 1 French franc (F) = 100 centimes; 1
peseta (Pta) = 100 centimos; the French and Spanish
currencies are used
Exchange rates: French francs (F) per US$1 —
6.0836 (January 1 998), 5.8367 (1 997) , 5. 1 1 55 (1 996),
4.9915 (1995), 5.5520 (1994), 5.6632 (1993); Spanish
pesetas (Ptas) per US$1 — 153.94 (January 1998),
146.41 (1997), 126.66 (1996), 124.69 (1995), 133.96
(1994), 127.26 (1993)
Fiscal year: calendar year
Economy— overview: Angola is an economy in
disarray because of more than 20 years of nearly
continuous warfare. Despite its abundant natural
resources, output per capita is among the world''s
lowest. Subsistence agriculture provides the main
livelihood for 85% of the population. Oil production
and the supporting activities are vital to the economy,
contributing about 50% to GDP. Notwithstanding the
signing of a peace accord in November 1994,
sporadic violence continues, millions of land mines
remain, and many farmers are reluctant to return to
their fields. As a result, much of the country''s food
must still be imported. To take advantage of its rich
resources— gold, diamonds, extensive forests,
Atlantic fisheries, arable land, and large oil deposits —
Angola will need to implement the peace agreement
and reform government policies. Despite the high
inflation and political difficulties, total output grew an
estimated 9% in 1996, largely due to increased oil
production and higher oil prices.
GDP: purchasing power parity— $8.2 billion (1996
est.)
GDP— real growth rate: 9% (1996 est.)
GDP— per capita: purchasing power parity— $800
(1996 est.)
GDP— composition by sector:
agriculture: 12%
industry: 56%
services: 32% (1994 est.)
Inflation rate— consumer price index: 92%
(mid-1997 est.)
Labor force:
total: 2.783 million economically active
by occupation: agriculture 85%, industry and services
15% (1997 est.)
Unemployment rate: extensive unemployment and
underemployment affecting more than half the
population (1997 est.)
Budget:
revenues: $928 million
expenditures: $2.5 billion, including capital
expenditures of $963 million (1992 est.)
Industries: petroleum; diamonds, iron ore,
phosphates, feldspar, bauxite, uranium, and gold;
cement; basic metal products; fish processing; food
processing; brewing; tobacco products; sugar;
textiles
Industrial production growth rate: NA%
Electricity— capacity: 617,000 kW (1995)
Electricity— production: 18.62 billion kWh (1995)
Electricity— consumption per capita: 185 kWh
(1995)
Agriculture— products: bananas, sugarcane,
coffee, sisal, corn, cotton, manioc (tapioca), tobacco,
vegetables, plantains; livestock; forest products; fish
Exports:
total value: $ 4 billion (f.o.b., 1996 est.)
commodities: crude oil 90%, diamonds, refined
12
petroleum products, gas, coffee, sisal, fish and fish
products, timber, cotton
partners: US 70%, EU
Imports:
total value: billion (f.o.b., 1995 est.)
commodities: capita! equipment (machinery and
electrical equipment), vehicles and spare parts;
medicines, food, textiles and clothing; substantial
military supplies
partners: Portugal, Brazil, US, France, Spain
Debt— external: $12.5 billion (1996 est.)
Economic aid:
recipient: ODA, $451 million (1994)
Currency: 1 kwanza (NKz) = 100 Iwei
Exchange rates: kwanza (NKz) per US$1— 265,000
(August 1997), 201,994 (November 1996)
note: the exchange rate is set by the National Bank of
Angola (BNA); adjusted by BNA on 19 July 1997 at
265,000 kwanzas per US$1; black market rate was
then 360,000 kwanzas per US$1
Fiscal year: calendar year
Economy— overview: Anguilla has few natural
resources, and the economy depends heavily on
high-class tourism, offshore banking, lobster fishing,
and remittances from emigrants. The economy, and
especially the tourism sector, suffered a setback in
late 1995 due to the effects of Hurricane Luis in
September but recovered in 1996. Anguillan officials
have put substantial effort into developing the offshore
financing sector. A comprehensive package of
financial services legislation was enacted in late 1 994.
In the medium term, prospects for the economy will
depend on the tourism sector and, therefore, on
continuing income growth in the industrialized nations.
GDP: purchasing power parity— $75 million (1996
est.)
GDP— real growth rate: 3.4% (1996 est.)
GDP— per capita: purchasing power parity— $7,200
(1996 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 3.6% (1996
est.)
Labor force:
total: 4,400 (1992)
by occupation: commerce 36%, services 29%,
construction 18%, transportation and utilities 10%,
manufacturing 3%, agriculture/fishing/forestry/mining
4%
Unemployment rate: 7% (1992 est.)
Budget:
revenues: $13.5 million (1993)
expenditures: $17.6 million, including capital
expenditures of $740,000 (1995 est.)
industries: tourism, boat building, offshore financial
services
Industrial production growth rate: NA%
Electricity— capacity: NA kW
Electricity— production: NAkWh
Electricity— consumption per capita: NA kWh
Agriculture— products: pigeon peas, corn, sweet
potatoes; sheep, goats, pigs, cattle, poultry; fishing
(including lobster)
Exports:
total value: $ 1.8 million (f.o.b., 1996)
commodities: lobster, fish, livestock, salt
partners: NA
Imports:
total value: $ 52.7 million (f.o.b., 1996)
commodities: NA
partners: NA
Debt— external: $8.5 million (1996 est.)
Economic aid: $NA
Currency: 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars (EC$) per
US$1 -2.7000 (fixed rate since 1976)
Fiscal year: 1 April— 31 March','c5c443bf9765c03d2df0220ee41b2d0ad02dc28c555fd236b3496f3805276f58','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18fe184b15cf01edb27f344efc29969d4b45b9951d0926e28839ae71e1bba310',1998,'AQ','Antarctica','economy',41,'Economy— overview: No economic activity at
present except for fishing off the coast and small-scale
tourism, both based abroad.
Economy— overview: Argentina benefits from rich
natural resources, a highly literate population, an
export-oriented agricultural sector, and a diversified
industrial base. Nevertheless, following decades of
mismanagement and statist policies, the economy in
the late 1980s was plagued with huge external debts
and recurring bouts of hyperinflation. Elected in 1989,
in the depths of recession, President MENEM has
implemented a comprehensive economic
restructuring program that has put Argentina on a path
of stable, sustainable growth. Argentina''s currency
has traded at par with the US dollar since April 1991,
and inflation has fallen to its lowest level in 50 years.
Argentines have responded to price stability by
repatriating capital and investing in domestic industry.
Growth averaged more than 8% between 1991 and
1994, then fell 4.6% in 1995, largely in reaction to the
Mexican peso crisis. The economy has since
recovered strongly. However, unemployment remains
nearly 1 4%, and Buenos Aires still depends on foreign
capital to meet the bulk of its financing needs. The IMF
has urged additional economic reforms to ensure
equitable long-term growth.
GDP: purchasing power parity — $348.2 billion (1 997
est.)
GDP— real growth rate: 8.4% (1997 est.)
GDP— per capita: purchasing power parity— $9,700
(1997 est.)
GDP— composition by sector:
agriculture: 7%
industry: 36%
services: 57% (1995 est.)
Inflation rate— consumer price index: 0.3%
(1997)
Labor force:
total: 14.5 million (1995 est.)
by occupation: agriculture 12%, industry 31%,
services 57% (1985 est.)
Unemployment rate: 13.7% (October 1997)
Budget:
revenues; $55 billion
expenditures: $59 billion, including capital
expenditures of $NA (1997 est.)
Industries: food processing, motor vehicles,
consumer durables, textiles, chemicals and
petrochemicals, printing, metallurgy, steel
Industrial production growth rate: 8.7% (1997
est.)
Electricity— capacity: 19.61 million kW (1995)
Electricity— production: 65.72 billion kWh (1995)
Electricity— consumption per capita: 1,960 kWh
(1995)
Agriculture— products: wheat, corn, sorghum,
soybeans, sugar beets; livestock
Exports:
total value: $25 A billion (f.o.b., 1997)
commodities : meat, wheat, corn, oilseed,
manufactures, fuels
partners: Brazil 26.1%, US 8.5%, Chile 7.0%,
Netherlands 5.7%, Italy 3.5% (1995)
Imports:
total value: $30.3 billion (c.i.f., 1997)
commodities: machinery and equipment, chemicals,
metals, transport equipment, agricultural products
partners: Brazil 20.8%, US 20.7%, Italy 6.3%,
Germany 6.2%, France 5.2% (1995)
Debt— external: $115 billion (1997 est.)
Economic aid: $NA
Currency: 1 nuevo peso argentino = 100 centavos
Exchange rates: pesos per US$1— 0.99950
(January 1998), 0.99950 (1997), 0.99966 (1996),
0.99975 (1995), 0.99901 (1994), 0.99895 (1993)
Fiscal year: calendar year
Economy— overview: Under the old Soviet central
planning system, Armenia had developed a modern
industrial sector, supplying machine tools, textiles,
and other manufactured goods to sister republics in
exchange for raw materials and energy. Since the
implosion of the USSR in December 1 991 , Armenia
has switched to small-scale agriculture away from the
large agroindustrial complexes of the Soviet area. The
agricultural sector has long-term needs for more
investment and updated technology. The privatization
of industry has been at a slower pace, but ahead of
most of the rest of the CIS. Armenia is a food importer
and its mineral deposits (gold, bauxite) are small. The
ongoing conflict with Azerbaijan over the ethnic
Armenian-dominated region of Nagorno-Karabakh
and the embargoes imposed by Azerbaijan and
Turkey contributed to a severe economic decline in
the early 1990s. By 1994, however, the Armenian
Government had launched an ambitious
IMF-sponsored economic program that has resulted
in positive growth rates in 1995-97. Armenia also
managed to slash inflation and to privatize most small
and medium-sized enterprises. The chronic energy
shortages Armenia suffered in recent years has been
partially offset by the energy supplied by one of its
nuclear power plants at Metsamor, which in 1996
supplied about 40% of the country’s energy needs,
according to the Armenian Government. Moreover,
Armenia is expanding its energy imports from Iran.
GDP: purchasing power parity— $9.5 billion (1997
est.)
GDP— real growth rate: 2.7% (1997 est.)
GDP— per capita: purchasing power parity— $2,750
(1997 est.)
GDP— composition by sector:
agriculture: 38%
industry: 32%
services: 30% (1996 est.)
Inflation rate— consumer price index: 13.2%
(1997 est.)
Labor force:
total: 1 .6 million (1997)
by occupation: manufacturing, mining, and
construction 25%, agriculture 38%, services 37%
Unemployment rate: 10.6% officially registered
unemployed, but large numbers of underemployed
(June 1997)
Budget:
revenues: $322 million
expenditures: $424 million, including capital
expenditures of $80 million (1998 est.)
Industries: much of industry is shut down;
metal-cutting machine tools, forging-pressing
machines, electric motors, tires, knitted wear, hosiery,
shoes, silk fabric, washing machines, chemicals,
trucks, watches, instruments, microelectronics
Industrial production growth rate: 0.7% (1997
est.)
Electricity— capacity: 2.768 million kW (1995)
Electricity— production: 6.3 billion kWh (1996)
Electricity— consumption per capita: 1 ,570 kWh
(1995)
Agriculture— products: fruit (especially grapes),
vegetables; vineyards near Yerevan are famous for
brandy and other liqueurs; minor livestock sector
Exports:
total value: $290 million (f.o.b., 1996)
commodities : gold and jewelry, aluminum, transport
equipment, electrical equipment, scrap metal
partners: Iran, Russia, Turkmenistan, Georgia
Imports:
total value: $727 million (c.i.f., 1996)
commodities: grain, other foods, fuel, other energy
partners: Iran, Russia, Turkmenistan, Georgia, US,
EU
Debt— external: $820 million (of which $75 million to
Russia) (1997 est.)
Economic aid:
recipient: ODA, $NA
note: commitments (excluding Russia), $1 ,385 million
($675 million in disbursements) (1992-95)
Currency: 1 dram = 100 luma (introduced new
currency in November 1993)
Exchange rates: dram per US$1— 499.89
(November 1997), 414.04 (1996), 405.91 (1995),
288.65 (1994), 9.11 (1993)
Fiscal year: calendar year
Economy— overview: Tourism is the mainstay of
the Aruban economy, although offshore banking and
oil refining and storage are also important. The rapid
growth of the tourism sector over the last decade has
resulted in a substantia! expansion of other activities.
Construction has boomed, with hotel capacity five
times the 1985 level. In addition, the reopening of the
country''s oil refinery in 1993, a major source of
employment and foreign exchange earnings, has
further spurred growth. Aruba''s small labor force and
less than 1% unemployment rate have led to a large
number of unfilled job vacancies despite sharp rises in
wage rates in recent years.
GDP: purchasing power parity— $1.4 billion (1996
est.)
GDP— real growth rate: 4% (1996 est.)
GDP— per capita: purchasing power parity —
$21,000 (1996 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services : NA%
Inflation rate— consumer price index: 3.2%
(1996)
Labor force: NA
by occupation : most employment is in the tourist
industry (1996)
Unemployment rate: 0.6% (1996 est.)
Budget:
revenues; $376 million
expenditures: $ 409 million, including capital
expenditures of $107 million (1997 est.)
Industries: tourism, transshipment facilities, oil
refining
Industrial production growth rate: NA%
Electricity— capacity: 90,000 kW (1995)
Electricity— production: 340 million kWh (1995)
Electricity— consumption per capita: 5,154 kWh
(1995)
Agriculture— products: aloes; livestock; fishing
Exports:
total value: $ 1 .7 billion (including oil re-exports)
(f.o.b., 1996)
commodities: mostly refined petroleum products
partners: US 64%, EU
Imports:
total value: $ 2 billion (f.o.b., 1996)
commodities: food, consumer goods, manufactures,
petroleum products, crude oil for refining and reexport
partners: US 8%, EU
Debt— external: $669 million (December 1995)
Economic aid: the Netherlands provided a 1 996 aid
package of $224 million to Aruba, the Netherlands
Antilles, and Suriname
Currency: 1 Aruban florin (Af.) = 100 cents
Exchange rates: Aruban florins (Af.) per US$1 —
1 .7900 (fixed rate since 1 986)
Fiscal year: calendar year
Economy— overview: no economic activity
Economy— overview: Australia has a prosperous
Western-style capitalist economy, with a per capita
GDP at the level of the highly industrialized West
European countries. Rich in natural resources,
Australia is a major exporter of agricultural products,
minerals, metals, and fossil fuels. Commodities
28
account for 57% of the value of total exports, so that a
downturn in world commodity prices can have a big
impact on the economy. The government is pushing
for increased exports of manufactured goods, but
competition in international markets continues to be
severe. Australia has suffered from the low growth
and high unemployment characterizing the OECD
countries in the early 1990s, but the economy has
expanded at reasonably steady rates in recent years.
In addition to high unemployment, short-term
economic problems include a balancing of output
growth and inflationary pressures and the stimulation
of exports to offset rising imports, especially given the
economic crisis in Asia.
GDP: purchasing power parity— $394 billion (1 997
est.)
GDP— real growth rate: 3.3% (1997 est.)
GDP— per capita: purchasing power parity—
$21,400 (1997 est.)
GDP— composition by sector:
agriculture: 4%
industry: 31%
services: 65% (1997 est.)
Inflation rate— consumer price index: 1% (1997
est.)
Labor force:
total: 9.2 million (December 1997)
by occupation: services 73%, industry 22%,
agriculture 5% (1997 est.)
Unemployment rate: 8.4% (1997)
Budget:
revenues: $89.35 billion
expenditures: $91 .92 billion, including capital
expenditures of $NA (FY97/98 est.)
Industries: mining, industrial and transportation
equipment, food processing, chemicals, steel
Industrial production growth rate: 1 .2% (1995)
Electricity— capacity: 38.83 million kW (1995)
Electricity— production: 163.082 billion kWh
(1995)
Electricity— consumption per capita: 8,901 kWh
(1995)
Agriculture— products: wheat, barley, sugarcane,
fruits; cattle, sheep, poultry
Exports:
total value: $ 68 billion (f.o.b., 1997 est.)
commodities: coal, gold, meat, wool, alumina, iron
ore, wheat, machinery and transport equipment
partners: Japan 20%, ASEAN 1 6%, South Korea 9%,
US 9%, NZ 8%, UK, Taiwan, Hong Kong, China
(1997)
Imports:
total value: $ 67 billion (f.o.b., 1997 est.)
commodities: machinery and transport equipment,
computers and office machines, telecommunication
equipment and parts; crude oil and petroleum
products
partners: US 22%, Japan 17%, UK 6%, China 5%, NZ
5% (1994/95)
Debt— external: $150 billion (December 1996)
Economic aid:
donor: ODA, $1.43 billion (FY97/98)
Currency: 1 Australian dollar ($A) = 1 00 cents
Exchange rates: Australian dollars ($A) per US$1 —
1 .4865 (February 1998), (1.3439 (1997), 1.2773
(1996), 1.3486 (1995), 1.3668 (1994), 1.4704 (1993)
Fiscal year: 1 July— 30 June
Economy-overview: Austria, a member of the
European Union since 1 January 1995, has a
well-developed market economy with a high standard
of living. With exports of goods and services reaching
over 40% of GDP, Austria''s economy is closely
integrated with other EU member countries, especially
with Germany. Austria''s entry into the EU has drawn
an influx of foreign investors attracted by Austria''s
access to the single European market. Austria is well
on its way to meeting all Maastricht convergence
criteria for monetary union, through privatization
efforts, the 1996-98 budget consolidation programs,
and austerity measures, which were expected to bring
total public sector deficit down to 3% of GDP in 1997
and public debt in line with the 60% of GDP required
by the EU. Cuts mainly affect the civil service and
Austria''s generous social system, the two major
causes of the government deficit. To meet increased
competition from both the EU and Central European
countries, Austria will need to emphasize
knowledge-based sectors of the economy and
deregulate the service sector, particularly
telecommunications and the energy sector. Economic
prospects are expected to brighten in 1998 with GDP
growth projected to be 2.5%.
GDP: purchasing power parity— $174.1 billion (1997
est.)
GDP— real growth rate: 2.1% (1997 est.)
GDP— per capita: purchasing power parity —
$21,400 (1997 est.)
GDP— composition by sector:
agriculture: 1.5%
industry: 31.6%
services: 66.9% (1996)
Inflation rate— consumer price index: 1 .3%
(1997)
Labor force:
total: 3.646 million (1996)
by occupation: services 66.1%, industry and crafts
29.6%, agriculture and forestry 1.3% (salaried
employees, 1996)
note: an estimated 1 50,000 Austrians are employed
abroad; foreign laborers in Austria number 298,000
(1996)
Unemployment rate: 7.1% (January 1998)
Budget:
revenues: $53.6 billion
expenditures: $61 .6 billion, including capital
expenditures of $NA (1996 est.)
Industries: food, iron and steel, machines, textiles,
chemicals, electrical, paper and pulp, tourism, mining,
motor vehicles
Industrial production growth rate: 1% (1996)
Electricity— capacity: 15.65 million kW (1996)
Electricity— production: 54.8 billion kWh (1996)
Electricity— consumption per capita: 6,900 kWh
(1996)
Agriculture— products: grains, potatoes, sugar
beets, wine, fruit, dairy products; cattle, pigs, poultry;
sawn wood
Exports:
total value: $ 57.8 billion (1996)
commodities: machinery and equipment, iron and
steel, lumber, textiles, paper products, chemicals
partners: EU 64.7% (Germany 37.7%, Italy 8.5%),
Eastern Europe 14.9%, Japan 1.5%, US 3.1% (1996)
Imports:
total value: $67. 3 billion (1996)
commodities: petroleum, foodstuffs, machinery and
equipment, vehicles, chemicals, textiles and clothing,
pharmaceuticals
partners: EU 70.7% (Germany 42.8%, Italy 8.7%),
Eastern Europe 10%, Japan 2.4%, US 4.5% (1996)
Debt— external: $29.4 billion (1996 est.)
Economic aid:
donor: ODA, $480 million; assistance to central and
eastern Europe $400 million (1996)
Currency: 1 Austrian schilling (AS) = 100 groschen
Exchange rates: Austrian schillings (AS) per
US$1— 12.776 (January 1998), 12.204 (1997),
10.587(1996), 10.081 (1995), 11.422 (1994), 11.632
(1993)
Fiscal year: calendar year','bbd480bf35b061891e5eadffa4308f5368d09e1c938ff08a7cd5095f766e8b15','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5f42fe9a63fab939fd8ecc473bc666286213ddf3da696116078e1b634f53916',1998,'AG','Antigua and Barbuda','economy',48,'Economy— overview: Tourism continues to be by
far the dominant activity in the economy accounting
directly or indirectly to more than half of GDP.
Increased tourist arrivals have helped spur growth in
the construction and transport sectors. The dual
island nation''s agricultural production is mainly
directed to the domestic market; the sector is
constrained by the limited water supply and labor
shortages that reflect the pull of higher wages in
tourism and construction. Manufacturing comprises
enclave-type assembly for export with major products
being bedding, handicrafts, and electronic
components. Prospects for economic growth in the
medium term will continue to depend on income
growth in the industrialized world, especially in the US,
which accounts for about half of all tourist arrivals.
GDP: purchasing power parity— $470 million (1997
est.)
GDP— real growth rate: 3.3% (1997 est.)
GDP— per capita: purchasing power parity— $7,400
(1997 est.)
GDP— composition by sector:
agriculture: 3.8%
industry: 18.9%
services: 77.3% (1995)
Inflation rate— consumer price index: 2.5%
(1996)
Labor force:
total: 30,000
by occupation: commerce and services 82%,
agriculture 11%, industry 7% (1983)
Unemployment rate: 5%-10%(1995 est.)
Budget:
revenues; $107 million
expenditures: $132 million, including capital
expenditures of $18 million (1995)
Industries: tourism, construction, light
manufacturing (clothing, alcohol, household
appliances)
Industrial production growth rate: NA%
Electricity— capacity: 26,000 kW (1995)
Electricity— production: 95 million kWh (1995)
Electricity— consumption per capita: 1,458 kWh
(1995)
Agriculture— products: cotton, fruits, vegetables,
bananas, coconuts, cucumbers, mangoes,
sugarcane; livestock
Exports:
total value: $45 million (f.o.b., 1996 est.)
commodities: petroleum products 48%, manufactures
23%, food and live animals 4%, machinery and
transport equipment 17%
partners: OECS 26%, Barbados 15%, Guyana 4%,
Trinidad and Tobago 2%, US 0.3%
Imports:
total value: $350.8 million (f.o.b., 1996 est.)
commodities: food and live animals, machinery and
transport equipment, manufactures, chemicals, oil
partners: US 27%, UK 16%, Canada 4%, OECS 3%,
other 50%
Debt— external: $225 million (1996 est.)
Economic aid: $NA
Currency: 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars (EC$) per
US$1— 2.7000 (fixed rate since 1976)
Fiscal year: 1 April— 31 March
Economy— overview: Economic activity is limited to
the exploitation of natural resources, including
petroleum, natural gas, fish, and seals.','6ba2366b09c3309ddd26187b3200046a1a7d1b3e9239ed0697e5e8d6e968a190','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9785221c31e97a8265d8884c58ba1901c93cd43bbe745cc2bb8986451a418895',1998,'AZ','Azerbaijan','economy',59,'Economy— overview: Azerbaijan is less developed
industrially than either Armenia or Georgia, the other
Transcaucasian states. It resembles the Central Asian
states in its majority nominally Muslim population,
high structural unemployment, and low standard of
living. The economy''s most prominent products are
oil, cotton, and gas. Production from the Caspian oil
and gas field has been in decline for several years, but
the negotiation of more than a dozen
production-sharing arrangements (PSAs) with foreign
firms, which have thus far committed $30 billion to oil
field development, should generate the funds needed
to spur future industrial development. Oil production
under the first of these PSAs, with the Azerbaijan
International Operating Company, began in
November 1 997. Azerbaijan shares all the formidable
problems of the ex-Soviet republics in making the
transition from a command to a market economy, but
its considerable energy resources brighten its
long-term prospects. Baku has only recently begun
making progress on economic reform, and old
economic ties and structures are slowly being
replaced. A major short-term obstacle to economic
progress, including stepped up foreign investment, is
the continuing conflict with Armenia over the ethnic
Armenian-dominated region of Nagorno-Karabakh.
Trade with Russia and the other former Soviet
republics is declining in importance while trade is
building up with the nations of Europe, Turkey, Iran,
and the UAE. A serious long-term challenge is the
maintenance of the competitiveness of non-oil exports
in world markets.
GDP: purchasing power parity— $1 1 .9 billion (1 997
est.)
GDP— real growth rate: 5.8% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,460
(1997 est.)
GDP— composition by sector:
agriculture: 30%
industry: 23%
services: 47% (1996 est.)
Inflation rate— consumer price index: 3.7% (1997
est.)
Labor force:
total: 2.789 million
by occupation: agriculture and forestry 32%, industry
and construction 26%, other 42% (1990)
Unemployment rate: 20% (1996 est.)
Budget:
revenues; $565 million
expenditures: $ 682 million, including capital
expenditures of $NA (1996 est.)
Industries: petroleum and natural gas, petroleum
products, oilfield equipment; steel, iron ore, cement;
chemicals and petrochemicals; textiles
Industrial production growth rate: 0.3% (1997
est.)
33
Azerbaijan (continued)
Electricity— capacity: 5.239 million kW (1995)
Electricity— production: 16.051 billion kWh (1995)
Electricity— consumption per capita: 2,200 kWh
(1996 est.)
Agriculture— products: cotton, grain, rice, grapes,
fruit, vegetables, tea, tobacco; cattle, pigs, sheep,
goats
Exports:
tota! value: $789 million (f.o.b., 1996 est.)
commodities: oil and gas, chemicals, oilfield
equipment, textiles, cotton
partners: CIS, European countries, Turkey
Imports:
total value: $1 .3 billion (c.i.f., 1 996 est.)
commodities : machinery and parts, consumer
durables, foodstuffs, textiles
partners: CIS, European countries, Turkey
Debt-external: $100 million (of which $75 million to
Russia)
Economic aid:
recipient: ODA, $14 million (1993)
note: commitments, 1992-95, $1,000 million ($185
million in disbursements); wheat from Turkey
Currency: 1 manat = 100 gopik
Exchange rates: manats per US$1— 3,936.00
(September 1997), 4,301.26 (1996), 4,413.54 (1995),
1,570.23 (1994), 99.98 (1993)
Fiscal year: calendar year','835f6cc3d41a9724c72df3d07d01154957c63017e0f4453a902c79abf3715b3f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b18cc9930ac25f089be872d4e3363af41590d94e5c027a04e77bf1d0dec897f',1998,'BS','Bahamas','economy',64,'Economy— overview: The Bahamas is a stable,
developing nation with an economy heavily
dependent on tourism and offshore banking. Tourism
alone accounts for more than 50% of GDP and directly
or indirectly employs 40% of the archipelago''s labor
force. Moderate growth in tourism receipts and a
boom in construction of new hotels, resorts, and
residences led to an increase of the country''s GDP by
an estimated 3.5% in 1997. Manufacturing and
agriculture together contribute less than 10% of GDP
and show little growth despite government incentives
aimed at those sectors. Overall growth prospects in
the short run will depend heavily on the fortunes of the
tourism sector and continued income growth in the
US, which accounts for the majority of tourist visitors.
GDP: purchasing power parity— $5.36 billion (1997
est.)
GDP— real growth rate: 3.5% (1997 est.)
GDP— per capita: purchasing power parity —
$19,400 (1997 est.)
GDP— composition by sector:
agriculture: 3%
industry: 5%
services: 92% (1997 est.)
Inflation rate— consumer price index: 0.4%
(1997)
Labor force:
total: 146, 600 (1996)
by occupation: government 30%, tourism 40%,
business services 10%, agriculture 5% (1995 est.)
Unemployment rate: 10% (1997 est.)
Budget:
revenues; $687.5 million
expenditures: $827 million, including capital
expenditures of $1 12 million (FY96/97 est.)
Industries: tourism, banking, cement, oil refining
and transshipment, salt production, rum, aragonite,
pharmaceuticals, spiral-welded steel pipe
Industrial production growth rate: NA%
Electricity— capacity: 401,000 kW (1995)
Electricity— production: 1.29 billion kWh (1996)
Electricity— consumption per capita: 4,100 kWh
(1996)
Agriculture— products: citrus, vegetables; poultry
Exports:
total value: $ 201 .7 million (f.o.b., 1996)
commodities: pharmaceuticals, cement, rum,
crawfish, refined petroleum products
partners: US 24%, Spain 14%, UK 7%, Norway 7%,
France 6%, Italy 5% (1995 est.)
Imports:
total value: $1.26 billion (c.i.f., 1996)
35
The Bahamas (continued)
commodities: foodstuffs, manufactured goods, crude
oil, vehicles, electronics
partners: US 29%, Finland 10%, Iran 10%, Denmark
8%
Debt— external: $381.7 million (1997)
Economic aid: $NA
Currency: 1 Bahamian dollar (B$) = 100 cents
Exchange rates: Bahamian dollar (B$) per US$1 —
1.000 (fixed rate pegged to the dollar)
Fiscal year: 1 July— 30 June
Economy— overview: The Turks and Caicos
economy is based on tourism, fishing, and offshore
financial services. Most capital goods and food for
domestic consumption are imported. The US was the
leading source of tourists in 1 996, accounting for more
than half of the 87,000 visitors. Major sources of
government revenue include fees from offshore
financial activities and customs receipts.
GDP: purchasing power parity— $1 1 0 million (1 996
est.)
GDP— real growth rate: 3.5% (1996 est.)
GDP— per capita: purchasing power parity— $7,700
(1996 est.)
GDP— composition by sector:
agriculture: NA%
industry : NA%
services: NA%
Inflation rate— consumer price index: 8% (1994
est.)
Labor force:
total: 4, 848 (1990 est.)
by occupation: about 33% in government and 20% in
agriculture and fishing; large numbers in tourism and
financial and other services (1997 est.)
Unemployment rate: 15% (1996 est.)
Budget:
revenues; $31. 9 million
expenditures: $30.4 million, including capital
expenditures of $NA (1995)
Industries: tourism, offshore financial services
Industrial production growth rate: NA%
Electricity— capacity: 4,000 kW (1995)
Electricity— production: 5 million kWh (1995)
Electricity — consumption per capita: 359 kWh
(1995)
Agriculture— products: corn, beans, cassava,
citrus fruits; fish
Exports:
total value: $ 6.8 million (f.o.b., 1993)
commodities: lobster, dried and fresh conch, conch
shells
partners: US, UK
Imports:
total value: $42.8 million (1993)
commodities: food and beverages, tobacco, clothing,
manufactures, construction materials
partners: US, UK
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: calendar year
Economy— overview: Tuvalu consists of a densely
populated, scattered group of nine coral atolls with
poor soil. The country has no known mineral
resources and few exports. Subsistence farming and
fishing are the primary economic activities. The
islands are too small and too remote for development
of a large-scale tourist industry. Government
Tuvalu (continued)
revenues largely come from the sale of stamps and
coins and worker remittances. About 1 ,000 Tuvaluans
work in Nauru in the phosphate mining industry. Nauru
has begun repatriating Tuvaluans, however, as
phosphate resources decline, which will present
additional problems for Tuvalu''s already stretched
economy. Substantial income is received annually
from an international trust fund established in 1987 by
Australia, NZ, and the UK and supported also by
Japan and South Korea. In an effort to reduce its
dependence on foreign aid, the government is
pursuing public sector reforms, including privatization
of some government functions and personnel cuts of
up to 7%. Low-lying T uvalu is particularly vulnerable to
any future global warming.
GDP: purchasing power parity— $7.8 million (1995
est.)
GDP— real growth rate: 8.7% (1995)
GDP— per capita: purchasing power parity— $800
(1995 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 3.9%
(average 1985-93)
Labor force: NA
by occupation: NA
note: people make a living mainly through exploitation
of the sea, reefs, and atolls and from wages sent
home by those working abroad (mostly workers in the
phosphate industry and sailors)
Unemployment rate: NA%
Budget:
revenues: $4.3 million
expenditures: $4.3 million, including capital
expenditures of $NA (1989 est.)
Industries: fishing, tourism, copra
Industrial production growth rate: NA%
Electricity— capacity: 2,600 kW (1995)
Electricity— production: 3 million kWh (1995)
Electricity— consumption per capita: NA kWh
Agriculture— products: coconuts; fish
Exports:
total value: $165,000 (f.o.b., 1989)
commodities: copra
partners: Fiji, Australia, NZ
Imports:
total value: $4.4 million (c.i.f., 1989)
commodities : food, animals, mineral fuels, machinery,
manufactured goods
partners: Fiji, Australia, NZ
Debt— external: $NA
Economic aid:
recipient: ODA, $1,725 million from Australia (FY96/
97 est.); $1.7 million from NZ (FY95/96); note:
substantial annual support from an international trust
fund
Currency: 1 Tuvaluan dollar ($T) or 1 Australian
dollar ($A) = 100 cents
Exchange rates: Tuvaluan dollars ($T) or Australian
dollars ($A) per US$1— 1.5281 (January 1998),
1.3439(1997), 1.2773 (1996), 1.3486 (1995), 1.3667
(1994), 1.4704(1993)
Fiscal year: calendar year
Economy— overview: Uganda has substantial
natural resources, including fertile soils, regular
rainfall, and sizable mineral deposits of copper and
cobalt. Agriculture is the most important sector of the
economy, employing over 80% of the work force.
Coffee is the major export crop and accounts for the
bulk of export revenues. Since 1986 the
government— with the support of foreign countries
and international agencies— has acted to rehabilitate
and stabilize the economy by undertaking currency
reform, raising producer prices on export crops,
increasing prices of petroleum products, and
improving civil service wages. The policy changes are
especially aimed at dampening inflation and boosting
481
Uganda (continued)
production and export earnings, in 1990-97, the
economy turned in a solid performance based on:
continued investment in the rehabilitation of
infrastructure, improved incentives for production and
exports, reduced inflation, gradually improved
domestic security, and the return of exiled
Indian-Ugandan entrepreneurs.
GDP: purchasing power parity— $34.6 billion (1997
est.)
GDP— real growth rate: 5% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,700
(1997 est.)
GDP— composition by sector:
agriculture: 49%
industry: 13%
services: 38% (1995 est.)
Inflation rate— consumer price index: 6% (1997)
Labor force:
total: 8.361 million (1993 est.)
by occupation: agriculture 86%, industry 4%, services
10% (1980 est.)
Unemployment rate: NA%
Budget:
revenues: $869 million
expenditures: $985 million, including capital
expenditures of $69 million (FY95/96)
Industries: sugar, brewing, tobacco, cotton textiles,
cement
Industrial production growth rate: 19.7% (FY95/
96)
Electricity— capacity: 162,000 kW (1995)
Electricity— production: 807 million kWh (1995)
Electricity— consumption per capita: 35 kWh
(1995)
Agriculture— products: coffee, tea, cotton,
tobacco, cassava (tapioca), potatoes, corn, millet,
pulses; beef, goat meat, milk, poultry
Exports:
total value: $604 million (f.o.b., 1996)
commodities: coffee, gold, cotton, tea, corn, fish
partners: Spain 23%, France 14%, Germany 14%,
Italy 10%, Netherlands 8% (1995)
Imports:
total value: $1 .2 billion (c.i.f., 1 996)
commodities: machinery, chemicals, fuel, cotton
piece goods, transportation equipment, food
partners: Kenya 26%, UK 12%, Japan 8%, Germany
8%, India 5.5% (1995)
Debt— external: $3.5 billion (1996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Ugandan shilling (USh) = 100 cents
Exchange rates: Ugandan shillings (USh) per
US$1 — 1,148.1 (January 1998), 1,083.0 (1997),
1,046.1 (1996), 968.9 (1995), 979.4 (1994), 1,195.0
(1993)
Fiscal year: 1 July— 30 June
Economy-overview: After Russia, the Ukrainian
republic was far and away the most important
economic component of the former Soviet Union,
producing about four times the output of the
next-ranking republic. Its fertile black soil generated
more than one-fourth of Soviet agricultural output, and
its farms provided substantial quantities of meat, milk,
grain, and vegetables to other republics. Likewise, its
diversified heavy industry supplied equipment and
raw materials to industrial and mining sites in other
regions of the former USSR. Ukraine depends on
imports of energy, especially natural gas. Shortly after
the implosion of the USSR in December 1991, the
Ukrainian Government liberalized most prices and
erected a legal framework for privatization, but
widespread resistance to reform within the
government and the legislature soon stalled reform
efforts and led to some backtracking. Output in
1992-97 fell to less than half the 1991 level. Loose
monetary policies pushed inflation to hyperinflationary
levels in late 1993. Since his election in July 1994,
President KUCHMA has pushed economic reforms,
maintained financial discipline, and tried to remove
almost all remaining controls over prices and foreign
trade. Implementation of KUCHMA''s economic
agenda is encountering considerable resistance from
parliament, entrenched bureaucrats, and industrial
interests; and an environment of corruption continues
to discourage foreign investors. One signal
achievement has been the reduction of the inflation
rate to 10% by yearend 1997. If KUCHMA succeeds
in implementing aggressive market reforms during
1998, the economy should reverse its downward
trend, with real growth occurring by late 1998 and into
1999.
GDP: purchasing power parity— $124.9 billion (1997
est.)
GDP— real growth rate: -3.2% (1997 est.)
GDP— per capita: purchasing power parity— $2,500
(1997 est.)
GDP— composition by sector:
agriculture : 14%
industry: 30%
services: 56% (1997 est.)
Inflation rate— consumer price index: 10%
(yearend 1997 est.)
Labor force:
total: 22.8 million (yearend 1997)
by occupation: industry and construction 32%,
agriculture and forestry 24%, health, education, and
culture 17%, trade and distribution 8%, transport and
communication 7%, other 12% (1996)
Unemployment rate: 2.6% officially registered;
large number of unregistered or underemployed
workers (December 1997)
484
Budget:
revenues: $18 billion
expenditures: $21 billion, including capital
expenditures of $NA (1997 est.)
Industries: coal, electric power, ferrous and
nonferrous metals, machinery and transport
equipment, chemicals, food-processing (especially
sugar)
Industrial production growth rate: -1 .8% (1997
est.)
Electricity— capacity: 52 million kW (1997)
Electricity— production: 177 billion kWh (1997)
Electricity— consumption per capita: 3,431 kWh
(1997)
Agriculture— products: grain, sugar beets,
sunflower seeds, vegetables; meat, milk
Exports:
total value: $1 5.2 billion (1 997 est.)
commodities: ferrous and nonferrous metals,
chemicals, machinery and transport equipment, food
products
partners: Russia, China, Belarus, Turkey, Germany
(1997)
Imports:
total value: $ 20.2 billion (1997 est.)
commodities: energy, machinery and parts,
transportation equipment, chemicals, plastics and
rubber
partners: Russia, Turkmenistan, Belarus, Germany,','3a4a69da97df9fedffede3b8427452d52da264e9b5570782127bc72350071260','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cfef8b3f4be3a913bba0dc52c7c0c49be9532f9afa588a3fb703ff100c07e0c',1998,'BH','Bahrain','economy',72,'Economy— overview: In Bahrain, petroleum
production and processing account for about 60% of
export receipts, 60% of government revenues, and
30% of GDP. Economic conditions have fluctuated
with the changing fortunes of oil since 1985, for
example, during and following the Gulf crisis of
1990-91. With its highly developed communication
and transport facilities, Bahrain is home to numerous
multinational firms with business in the Gulf. A large
share of exports consists of petroleum products made
from imported crude. Construction proceeds on
several major industrial projects. Unemployment,
especially among the young, and the depletion of both
oil and underground water resources are major
long-term economic problems.
GDP: purchasing power parity— $8.2 billion (1997
est.)
GDP— real growth rate: 2.7% (1997 est.)
GDP— per capita: purchasing power parity —
$13,700 (1997 est.)
GDP— composition by sector:
agriculture: 1%
industry: 38%
services: 61% (1995)
Inflation rate— consumer price index: -0.2%
(1996 est.)
Labor force:
total: 140,000
by occupation: industry, commerce, and service 78%,
government 21%, agriculture 1% (1994)
note: 44% of the population in the 1 5-64 age group is
non-national (July 1998 est.)
Unemployment rate: 15% (1996 est.)
Budget:
revenues; $1.7 billion
expenditures: $1.9 billion, including capital
expenditures of $400 million (1998 est.)
Industries: petroleum processing and refining,
aluminum smelting, offshore banking, ship repairing;
tourism
Industrial production growth rate: 3.4% (1995)
Electricity— capacity: 1.05 million kW (1995)
Electricity— production: 4.4 billion kWh (1995)
Electricity— consumption per capita: 7,640 kWh
(1995)
Agriculture— products: fruit, vegetables; poultry,
dairy products; shrimp, fish
Exports:
total value: $4.6 billion (f.o.b., 1996)
commodities: petroleum and petroleum products
61%, aluminum 7%
partners: India 22%, Japan 12%, Saudi Arabia 6%,
US 6%, UAE 5% (1995)
Imports:
total value: $3.7 billion (f.o.b., 1996)
commodities: nonoil 63%, crude oil 37%
37
Bahrain (continued)
partners: Saudi Arabia 40%, US 13%, UK 7%, Japan
5%, Switzerland 5% (1995)
Debt— external: $3.2 billion (1995)
Economic aid: $NA
Currency: 1 Bahraini dinar (BD) = 1 ,000 fils
Exchange rates: Bahraini dinars (BD) per US$1 —
0.3760 (fixed rate)
Fiscal year: calendar year
Economy— overview: no economic activity','40ce4ea9e3f31c9ca03964e75bcf35101b59d42a1925bd4e3236ac7e7067dae7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c8e5a4fc6c897f93fb6d4fc226081922578cea0d05784fda88dd40b53c07203',1998,'BD','Bangladesh','economy',77,'Economy— overview: Despite sustained domestic
and international efforts to improve economic and
demographic prospects, Bangladesh remains one of
the world''s poorest, most densely populated, and
least developed nations. Annual GDP growth has
averaged over 4% in recent years from a low base. Its
economy is largely agricultural, with the cultivation of
rice the single most important activity in the economy.
Major impediments to growth include frequent
cyclones and floods, the inefficiency of state-owned
enterprises, a rapidly growing labor force that cannot
be absorbed by agriculture, delays in exploiting
energy resources (natural gas), inadequate power
supplies, and slow implementation of economic
reforms. Frequent strikes that crippled the economy in
1995 and early 1996 subsided after Prime Minister
Sheikh HASINA Wajed''s Awami League government
assumed power in mid-1996, allowing a return to
normal economic activity. The current government
has made some headway improving the climate for
foreign investors and liberalizing the capital markets;
for example, it has negotiated with foreign firms for oil
and gas exploration, better countrywide distribution of
cooking gas, and the construction of natural gas
pipelines and power plants. Progress on other
economic reforms has been halting because of
opposition from the bureaucracy, public sector unions,
and other vested interest groups.
GDP: purchasing power parity— $167 billion (1997
est.)
GDP— real growth rate: 5.5% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,330
(1997 est.)
GDP— composition by sector:
agriculture: 30%
industry: 18%
services: 52% (1996)
Inflation rate— consumer price index: 2.5%
(1996)
Labor force:
total: 56 million
by occupation: agriculture 63%, services 25%,
industry and mining 10% (1996)
note: extensive export of labor to Saudi Arabia,
Kuwait, UAE, and Oman (1996)
Unemployment rate: 35.2% (1996)
Budget:
revenues: $3.6 billion
expenditures: $5.3 billion, including capital
expenditures of $3 billion (FY96/97)
Industries: jute manufacturing, cotton textiles, food
processing, steel, fertilizer
Industrial production growth rate: 5.3% (1996)
Electricity— capacity: 2.978 million kW (1995)
Electricity— production: 1 1.5 billion kWh (1997)
Electricity— consumption per capita: 71 kWh
(1997 est.)
Agriculture— products: rice, jute, tea, wheat,
sugarcane, potatoes; beef, milk, poultry
Exports:
total value: $3.9 billion (1 996)
commodities: garments, jute and jute goods, leather,
frozen fish and seafood
partners: Western Europe 42%, US 30%, Hong Kong
4%, Japan 3% (FY95/96 est.)
Imports:
total value: $6.9 billion (1996)
commodities: capital goods, textiles, food, petroleum
products
partners: India 21%, China 10%, Western Europe 8%,
Hong Kong 7%, Singapore 6% (FY95/96 est.)
Debt— external: $17.1 billion (1996)
Economic aid:
recipient: $1 .475 billion (FY96/97)
Currency: 1 taka (Tk) = 100 poisha
Exchange rates: taka (Tk) per US$1— 45.450
(January 1 998), 43.892 (1 997), 41 .794 (1 996), 40.278
(1995), 40.212 (1994), 39.567 (1993)
Fiscal year: 1 July— 30 June','7ed22860869cb33c3e6422297d4434a52804dea5a60594552ccd5f16d2598879','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5726d662d8bea11b781df466bdf5391fa6281e2416520245ea1c6a728789e61',1998,'BB','Barbados','economy',85,'Economy— overview: Historically, the Barbadian
economy had been dependent on sugarcane
cultivation and related activities, but production in
recent years has diversified into manufacturing and
tourism. The start of the Port Charles Marina project in
Speightstown helped the tourism industry continue to
expand in 1996-97. The government continues its
efforts to reduce the unacceptably high
unemployment rate, encourage direct foreign
investment, and privatize remaining state-owned
enterprises.
GDP: purchasing power parity— $2.8 billion (1997
est.)
GDP— real growth rate: 3% (1997 est.)
GDP— per capita: purchasing power parity —
$10,900 (1997 est.)
GDP— composition by sector:
agriculture: 7%
industry: 17%
sen/ices: 76% (1996 est.)
Inflation rate— consumer price index: 2.4%
(1996)
Labor force:
total: 68,900 (1996)
by occupation: services 75%, industry 15%,
agriculture 10% (1996 est.)
Unemployment rate: 1 6.2% (1 996)
Budget:
revenues: $600 million
expenditures: $645 million, including capital
expenditures of $80 million (FY96/97 est.)
Industries: tourism, sugar, light manufacturing,
component assembly for export
Industrial production growth rate: 0.8% (1996)
Electricity— capacity: 140,000 kW (1995)
Electricity— production: 591.5 million kWh (1996)
Electricity— consumption per capita: 2,145 kWh
(1995)
Agriculture— products: sugarcane, vegetables,
cotton
Exports:
total value: $ 235 million (f.o.b., 1995)
commodities: sugar and molasses, rum, other foods
and beverages, chemicals, electrical components,
clothing
partners: US 1 5%, UK 1 5%, T rinidad and Tobago 9%,
Windward Islands 8%
Imports:
total value: $763 million (c.i.f., 1995)
commodities : consumer goods, machinery,
foodstuffs, construction materials, chemicals, fuel,
electrical components
partners: US 37%, Trinidad and Tobago 11%, UK
10%, Japan 7%
Debt— external: $359 million (December 1996)
Economic aid: $NA
Currency: 1 Barbadian dollar (Bds$) = 100 cents
Exchange rates: Barbadian dollars (Bds$) per
US$1— 2.0000 (fixed rate pegged to the dollar)
Fiscal year: 1 April— 31 March','803beee76ad27c2c4d2a50afc9ed213b7801ccd16ec182e73e4c0bab0452309f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b722746a04bd4d9988325314e503c0e390f88aabffa13be11bd61a8934834182',1998,'FR','France','economy',98,'Economy— overview: The Belarusian government
has revived economic output since mid-1996 by
pursuing a policy of rapid credit expansion, ending
years of cumulative decline. Real GDP increased by
2.6% in 1 996 and the growth rate tripled in 1 997. Lack
of profitability and resurgent inflation— which
increased from an average monthly rate of 2.8% in
1996 to 4.4% in 1997— however, have kept
enterprises from making much needed capital
investments. As a result, infrastructure and equipment
stocks have continued to deteriorate. Belarus has
seen little structural reform since 1995, when
LUKASHENKO launched the country on the path of
"market socialism". Privatization of enterprises
controlled by the central government virtually ceased
in 1996. As of May 1997, only about 10% of all
enterprises under central government control had
been privatized. In addition, LUKASHENKO has
re-imposed administrative control over prices and the
national currency''s exchange rate, and expanded the
state''s right to intervene arbitrarily in the management
of private enterprise. Lack of structural reform, and a
climate hostile to business, have inhibited foreign
investment in Belarus in 1995-97. In 1995 Belarus
ranked second to last among the 15 former Soviet
republics in terms of the average amount of foreign
investment it attracted per capita. Although it moved
up to 1 1th place in 1996, this was largely due to
inflows from Russia related to the construction of the
Yamal natural gas pipeline. Belarus''s trade deficit has
grown steadily over the past three years— from 8% of
total trade turnover in 1995 to 14% in the first quarter
of 1997— despite the government''s efforts to promote
exports and limit imports. Given Belarus''s limited
fiscal reserve, a continued growth in the trade deficit
will increase vulnerability to a balance of payments
crisis.
GDP: purchasing power parity— $50.4 billion (1997
est.)
GDP— real growth rate: 8.5% (1997 est.)
GDP— per capita: purchasing power parity— $4,800
(1997 est.)
GDP— composition by sector:
agriculture: 20%
industry: 43%
services: 37% (1997 est.)
Inflation rate— consumer price index: 65% (1997
est.)
Labor force:
total: 4.3 million
by occupation: industry and construction 40%,
agriculture and forestry 19%, services 41% (1997
est.)
Unemployment rate: 3.3% officially registered
unemployed (July 1997); large numbers of
underemployed workers
Budget:
revenues: $4 billion
expenditures: $4.1 billion, including capital
expenditures of $180 million (1997 est.)
Industries: tractors, metal-cutting machine tools,
off-highway dump trucks up to 1 10-metric-ton load
capacity, wheel-type earth movers for construction
and mining, eight-wheel-drive, high-flotation trucks
with cargo capacity of 25 metric tons for use in tundra
and roadless areas, equipment for animal husbandry
and livestock feeding, motorcycles, television sets,
chemical fibers, fertilizer, linen fabric, wool fabric,
radios, refrigerators, other consumer goods
Industrial production growth rate: 17% (1997
est.)
Electricity— capacity: 7.21 million kW (1997)
Electricity— production: 23.7 billion kWh (1996)
Electricity— consumption per capita: 3,144 kWh
(1996)
Agriculture— products: grain, potatoes,
vegetables; meat, milk
Exports:
total value: $5. 4 billion (f.o.b., 1996)
commodities: machinery and transport equipment,
chemicals, foodstuffs
partners: Russia, Ukraine, Poland, Germany
Imports:
total value: $ 6.7 billion (c.i.f., 1996)
commodities: fuel, natural gas, industrial raw
materials, textiles, sugar
partners: Russia, Ukraine, Poland, Germany
Debt— external: $970 million (December 1997 est.)
Economic aid:
recipient: ODA, $186 million (1993)
note: commitments, $3,930 million ($1 ,845 million
disbursements), 1992-95
Currency: Belarusian rubel (BR)
Exchange rates: Belarusian rubels per US$1 —
31 ,030 (1 9 January 1 998 official Belarusian exchange
rate), 28,800 (October 1997 end of period), 15,500
(yearend 1996), 11,500 (yearend 1995), 10,600
(yearend 1994), 699 (yearend 1993)
Fiscal year: calendar year
Economy— overview: This highly developed private
enterprise economy has capitalized on its centra!
geographic location, highly developed transport
network, and diversified industrial and commercial
base. Industry is concentrated mainly in the populous
Flemish area in the north, although the government is
encouraging reinvestment in the southern region of
Walloon. With few natural resources, Belgium must
import substantial quantities of raw materials and
export a large volume of manufactures, making its
economy unusually dependent on the state of world
markets. Two-thirds of its trade is with other EU
countries. The economy grew at a strong 4% annual
pace during the period 1988-90, slowed to 1% in
1991-92, dropped by 1.5% in 1993, recovered with
moderate 2.3% growth in 1994 and 1995, and fell off
again to 1.4% in 1996, with continued substantial
unemployment. Belgium''s public debt fell from 127%
of GDP in 1 996 to 1 24% in 1 997, and the government
is trying to control its expenditures to bring the figure
more into line with other industrialized countries. GDP
growth of 2.5% is forecast for 1998.
GDP: purchasing power parity— $236.3 billion (1 997
est.)
GDP— real growth rate: 2.3% (1997 est.)
GDP— per capita: purchasing power parity —
$23,200 (1997 est.)
GDP— composition by sector:
agriculture: 2%
industry: 28%
services: 70% (1994)
Inflation rate— consumer price index: 1 .7% (1997
est.)
Labor force:
total: 4.283 million (1997)
by occupation: services 69.7%, industry 27.7%,
agriculture 2.6% (1992)
Unemployment rate: 12.75% (1997)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: engineering and metal products, motor
vehicle assembly, processed food and beverages,
chemicals, basic metals, textiles, glass, petroleum,
coal
Industrial production growth rate: 9.7% (1995)
Electricity— capacity: 13.592 million kW (1995)
Electricity— production: 69.56 billion kWh (1995)
Electricity— consumption per capita: 7,306 kWh
(1995 est.)
Agriculture— products: sugar beets, fresh
vegetables, fruits, grain, tobacco; beef, veal, pork,
milk
Exports:
total value: $W2 billion (f.o.b., 1997)
Belgium-Luxembourg Economic Union (BLEU)
commodities: iron and steel, transportation
equipment, tractors, diamonds, petroleum products
partners: EU 67.2% (Germany 19%), US 5.8%,
former Communist countries 1 .4% (1 994)
Imports:
total value: $158.5 billion (c.i.f., 1997)
Belgium-Luxembourg Economic Union
commodities: fuels, grains, chemicals, foodstuffs
partners: EU 75% (Germany 22.1%), US 5%, former
Communist countries 0.8% (1997)
Debt— external: $31.3 billion (1992 est.)
Economic aid:
donor: ODA, $808 million (1993)
Currency: 1 Belgian franc (BF) = 100 centimes
Exchange rates: Belgian francs (BF) per US$1 —
37.459 (January 1 998), 35.774 (1 997), 30.962 (1996),
29.480 (1995), 33.456 (1994), 34.597 (1993)
Fiscal year: calendar year
Economy— overview: The small, essentially private
enterprise economy is based primarily on agriculture,
agro-based industry, and merchandising, with tourism
and construction assuming greater importance.
Sugar, the chief crop, accounts for more than
one-third of exports, while the banana industry is the
country''s largest employer. The government''s tough
austerity program in 1997 resulted in an economic
slowdown that is likely to continue in 1998. Political
tension in the run-up to the elections will tend to
discourage investment, already suffering as a result of
tight monetary and fiscal policies. The trade deficit has
been growing, mostly as a result of low export prices
for sugar and bananas and could increase further if a
pre-election boost in government spending leads to a
rise in imports, The ruling in 1 997 by the World T rade
Organization against the European Union''s banana
import regime— which had granted Belize preferential
treatment— is also hurting the prospects for growth,
and could contribute to an increase in already high
unemployment.
GDP: purchasing power parity— $680 million (1997
est.)
GDP— real growth rate: 2.9% (1997 est.)
GDP— per capita: purchasing power parity— $3,000
(1997 est.)
GDP— composition by sector:
agriculture: 20%
industry: 27%
services: 53% (1996 est.)
Inflation rate— consumer price index: 1% (1997
est.)
Labor force:
total: 71 ,000
by occupation: agriculture 30%, services 16%,
government 15.4%, commerce 1 1 .2%, manufacturing
10.3%
note: shortage of skilled labor and all types of
technical personnel (1997 est.)
Unemployment rate: 13% (1997 est.)
Budget:
revenues: $140 million
expenditures: $142 million, including capital
expenditures of $NA (FY97/98 est.)
Industries: garment production, food processing,
tourism, construction
Industrial production growth rate: 0.2% (1996
est.)
Electricity— capacity: 23,000 kW (1995)
Electricity— production: 105 million kWh (1995)
Electricity— consumption per capita: 491 kWh
(1995)
Agriculture— products: bananas, coca, citrus,
sugarcane; lumber; fish, cultured shrimp
Exports:
total value: $166 million (f.o.b., 1996)
commodities : sugar, citrus fruits, bananas, clothing,
fish products, molasses, wood
partners : US 44%, UK 42%, other EU 5%, Canada 3%
(1996)
Imports:
total value: $262 million (c.i.f., 1996)
commodities: machinery and transportation
equipment, food, manufactured goods, fuels,
chemicals, pharmaceuticals
partners: US 55%, Mexico 12%, UK 5% (1997)
Debt— external: $217 million (1996)
Economic aid:
recipient: ODA, $NA
Currency: 1 Belizean dollar (Bz$) = 100 cents
Exchange rates: Belizean dollars (Bz$) per US$1 —
2.0000 (fixed rate)
Fiscal year: 1 April— 31 March
Imports:
total value: $693 million (c.i.f., 1995)
commodities: foodstuffs, beverages, tobacco,
petroleum products, intermediate goods, capital
goods, light consumer goods
partners: France 27%, Thailand 9%, China, Hong Kong
Debt— external: $1.7 billion (1995 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Communaute Financier Africaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1—
608.36 (January 1 998), 583.67 (1 997), 51 1 .55 (1 996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 1 2 January 1 994 the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: calendar year
Economy— overview: Grown throughout the
islands, coconuts are the sole cash crop. Copra and
fresh coconuts are the major export earners. Small
local gardens and fishing contribute to the food
supply, but additional food and most other necessities
must be imported from Australia.
GDP: purchasing power parity — $NA
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity — $NA
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force: NA
note: the Cocos Islands Cooperative Society Ltd.
employs construction workers, stevedores, and
lighterage worker operations; tourism employs others
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: copra products and tourism
Industrial production growth rate: NA%
Electricity— capacity: NA kW
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Agriculture— products: vegetables, bananas,
pawpaws, coconuts
Exports: $NA
commodities: copra
partners: Australia
Imports: $NA
commodities: foodstuffs
partners: Australia
Debt— external: $NA
Economic aid: none
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 —
1 .5281 (January 1 998), 1 .3439 (1 997), 1 .2773 (1 996),
1 .3486 (1 995), 1 .3667 (1 994), 1 .4704 (1 993)
Fiscal year: 1 July— 30 June
Economy— overview: Cote d''Ivoire is among the
world''s largest producers and exporters of coffee,
cocoa beans, and palm oil. Consequently, the
economy is highly sensitive to fluctuations in
international prices for these products and to weather
conditions. Despite attempts by the government to
diversify the economy, it is still largely dependent on
agriculture and related activities, which engage
roughly 85% of the population. After several years of
lagging performance, the Ivorian economy began a
comeback in 1994, due to improved prices for cocoa
and coffee, growth in nontraditional primary exports
such as pineapples and rubber, limited trade and
banking liberalization, offshore oil and gas
discoveries, and generous external financing and debt
rescheduling by multilateral lenders and France.
The 50% devaluation of Franc Zone currencies on
1 2 January 1 994 caused a one-time jump in the
117
Cote d''Ivoire (continued)
inflation rate to 26% in 1994, but the rate fell to 7% in
1996 and an estimated 3.4% in 1997. Moreover,
government adherence to donor-mandated reforms
led to a jump in growth rates— 6.5% in GDP in 1996
and again in 1997
GDP: purchasing power parity— $25.8 billion (1997
est.)
GDP— real growth rate: 6.5% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,700
(1997 est.)
GDP— composition by sector:
agriculture: 31%
industry: 20%
se/v/ces:49%(1995)
Inflation rate— consumer price index: 3.4% (1997
est.)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $2.4 billion
expenditures: $2.7 billion, including capital
expenditures of $600 million (1996 est.)
Industries: foodstuffs, beverages: wood products,
oil refining, automobile assembly, textiles, fertilizer,
construction materials, electricity
Industrial production growth rate: 9% (first half of
1996)
Electricity— capacity: 1.173 million kW (1995)
Electricity— production: 1.875 billion kWh (1995)
Electricity— consumption per capita: 127 kWh
(1995)
Agriculture— products: coffee, cocoa beans,
bananas, palm kernels, corn, rice, manioc (tapioca),
sweet potatoes, sugar; cotton, rubber; timber
Exports:
total value: $4.2 billion (f.o.b., 1996)
commodities: cocoa 36%, coffee 22%; tropical woods
4%, petroleum, cotton, bananas, pineapples, palm oil,
cotton, fish
partners : France 18%, Germany 8%, Italy 8%,
Netherlands 8%, Burkina Faso, Mali, US, UK
Imports:
total value: $3.2 billion (f.o.b., 1996)
commodities: food, consumer goods; capital goods,
fuel, transport equipment
partners: France 32%, Nigeria 20%, US 6%, Ghana,
Germany, Italy
Debt— external: $16.1 billion (1996 est.)
Economic aid:
recipient: ODA, $552 million (1993)
Currency: 1 Communaute Financier Africaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1 —
608.36 (January 1 998), 583.67 (1 997), 51 1 .55 (1 996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 12 January 1994, the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: calendar year
Economy— overview: The economy was formerly
based on agriculture, mainly sheep farming, which
directly or indirectly employs most of the work force.
Dairy farming supports domestic consumption; crops
furnish winter fodder. Exports feature shipments of
high-grade wool to the UK and the sale of postage
stamps and coins. Rich stocks of fish in the
surrounding waters are not presently exploited by the
islanders. So far, efforts to establish a domestic fishing
industry have been unsuccessful. The economy has
diversified since 1987, when the government began
selling fishing licenses to foreign trawlers operating
within the Falklands exclusive fishing zone; overfishing
is a growing problem. These license fees total more
than $40 million per year and support the island''s
health, education, and welfare system. To encourage
tourism, the Falkland Islands Development
Corporation has built three lodges for visitors attracted
by the abundant wildlife and trout fishing. The islands
are now self-financing except for defense. The British
Geological Survey announced a 200-mile oil
exploration zone around the islands in 1 993, and early
seismic surveys suggest substantial reserves capable
of producing 500,000 barrels per day. An agreement
between Argentina and the UK in 1 995 seeks to defuse
licensing and sovereignty conflicts that would dampen
foreign interest in exploiting potential oil reserves.
GDP: purchasing power parity — $NA
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity — $NA
GDP— composition by sector:
agriculture: NA%
industry : NA%
services : NA%
Inflation rate— consumer price index: NA%
155
Falkland Islands (Islas Malvinas) (continued)
Labor force:
total: 1,100 (est.)
by occupation: agriculture 95% (mostly
sheepherding)
Unemployment rate: full employment; labor
shortage
Budget:
revenues: $53.4 million
expenditures: $53.1 million, including capital
expenditures of $NA (1994-95 est.)
Industries: wool and fish processing; sale of stamps
and coins
Industrial production growth rate: NA%
Electricity — capacity: 9,000 kW (1995)
Electricity-production: 10 million kWh (1995)
Electricity— consumption per capita: 4,316 kWh
(1995)
Agriculture— products: fodder and vegetable
crops; sheep farming, small dairy herds
Exports:
total value: $7.6 million (1995)
commodities: wool, hides, meat
partners: UK, Netherlands, Japan (1992)
Imports:
total value: $24.7 million (1995)
commodities: fuel, food and drink, building materials,
clothing
partners: UK, Netherlands Antilles, Japan (1992)
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
note: UK, ODA and OOF bilateral commitments
totaled $18 million (1993-94)
Currency: 1 Falkland pound (£F) = 100 pence
Exchange rates: Falkland pound (£F) per US$1 —
0.61 1 5 (January 1 998), 0.61 06 (1 997), 0.6403 (1 996),
0.6335 (1995), 0.6529 (1994), 0.6658 (1993); note—
the Falkland pound is at par with the British pound
Fiscal year: 1 April— 31 March
Economy— overview: The economy is tied closely
to that of France through subsidies and imports.
Besides the French space center at Kourou, fishing
and forestry are the most important economic
activities, with exports offish and fish products (mostly
shrimp) accounting for more than 60% of total revenue
in 1 992. The large reserves of tropical hardwoods, not
fully exploited, support an expanding sawmill industry
that provides sawn logs for export. Cultivation of crops
is limited to the coastal area, where the population is
largely concentrated. French Guiana is heavily
dependent on imports of food and energy.
Unemployment is a serious problem, particularly
among younger workers.
GDP: purchasing power parity— $800 million (1993
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $6,000
(1993 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 2.5%
(1992)
Labor force:
total: 46,300 (1993)
by occupation: services, government, and commerce
60.6%, industry 21.2%, agriculture 18.2% (1980)
Unemployment rate: 24.1% (1993 est.)
Budget:
revenues: $176 million
expenditures: $350 million, including capital
expenditures of $92 million (1994)
Industries: construction, shrimp processing, forestry
products, rum, gold mining
Industrial production growth rate: NA%
Electricity— capacity: 165,000 kW (1995)
Electricity— production: 420 million kWh (1995)
Electricity— consumption per capita: 2,890 kWh
(1995)
Agriculture— products: rice, corn, manioc, cocoa,
vegetables, bananas, sugar; cattle, pigs, poultry
Exports:
total value: $81 million (f.o.b., 1994)
commodities: shrimp, timber, gold, rum, rosewood
essence, clothing
partners: France 60%, EU 7%
Imports:
total value: $ 605 million (c.i.f., 1994)
commodities: food (grains, processed meat),
machinery and transport equipment, fuels and
chemicals
partners: France 62%, Germany 4%,
Belgium-Luxembourg 4%, US 2%
Debt— external: $1.2 billion (1988)
Economic aid:
recipient: ODA, $NA
Currency: 1 French franc (F) = 100 centimes
Exchange rates: French francs (F) per US$1 —
6.0836 (January 1 998), 5.8367 (1 997), 5.1 1 55 (1 996),
4.9915 (1995), 5.5520 (1994), 5.6632 (1993)
Fiscal year: calendar year
Economy— overview: Greece has a mixed capitalist
economy with the public sector accounting for roughly
half of GDP. Tourism provides a major portion of
foreign exchange. Greece is among the poorest EU
countries in terms of per capita income; Athens
continues to rely heavily on EU aid, which currently
amounts to about 4.5% of GDP. Macroeconomic
problems include the huge public sector, substantial
budget and balance of payments deficits, and 10%
unemployment. Economic growth is strengthening,
and the government''s strict fiscal and monetary
policies are responsible for the decline in inflation and
the budget deficit. Despite widespread protests from
labor unions and farmers over austerity, the
government is taking further steps to enhance
revenue collection and reduce expenditures to
prepare Greece for participation in the EU''s single
currency by 2001. Greece entered the exchange
rate mechanism— a requirement for European
186
Monetary Union (EMU) membership— in March 1998.
GDP growth is projected at 3.5% for 1998, inflation at
4%, and unemployment at 8.5%
GDP: purchasing power parity— $1 37.4 billion (1 997
est.)
GDP— real growth rate: 3.7% (1997 est.)
GDP— per capita: purchasing power parity —
$13,000 (1997 est.)
GDP— composition by sector:
agriculture: 11%
industry: 25%
serv/ces:64%(1994)
Inflation rate— consumer price index: 6% (1997
est.)
Labor force:
total: 4.21 million
by occupation: services 52%, agriculture 23%,
industry 25% (1995)
Unemployment rate: 1 0% (1 997 est.)
Budget:
revenues: $37 billion (excluding privatization receipts)
expenditures: $45 billion, including capital
expenditures of $NA (1998 est.)
Industries: tourism; food and tobacco processing,
textiles; chemicals, metal products; mining, petroleum
Industrial production growth rate: 0.5% (1997
est.)
Electricity— capacity: 8.606 million kW (1995)
Electricity— production: 38.814 billion kWh (1995)
Electricity— consumption per capita: 3,720 kWh
(1995)
Agriculture— products: wheat, corn, barley, sugar
beets, olives, tomatoes, wine, tobacco, potatoes;
meat, dairy products
Exports:
total value: $ 9.8 billion (f.o.b., 1997 est.)
commodities: manufactured goods 53%, foodstuffs
34%, fuels 5% (1994)
partners: EU 60% (Germany 22%, Italy 14%, France
6%, UK 6%), US 3% (1995)
Imports:
total value: $27 billion (elf., 1 997 est.)
commodities: manufactured goods 72%, foodstuffs
15%, fuels 10% (1994)
partners: EU 70% (Italy 18%, Germany 16%, France
8%, UK 6%) US 4% (1995)
Debt— external: $33 billion (1997 est.)
Economic aid:
recipient: EU, $5.4 billion (1997 est.)
Currency: 1 drachma (Dr) = 100 lepta
Exchange rates: drachmae (Dr) per US$1— 286.99
(January 1998), 273.06 (1997), 240.71 (1996), 231.66
(1995), 242.60 (1994), 229.26 (1993)
Fiscal year: calendar year
Economy— overview: Greenland suffered negative
economic growth in the early 1990s, but since 1993
the economy has improved. The Greenland Home
Rule Government (GHRG) has pursued a light fiscal
policy since the late 1980s which has helped create
surpluses in the public budget and low inflation. Since
1990, Greenland has registered a foreign trade deficit
following the closure of the last remaining lead and
zinc mine in 1989. Greenland today is critically
dependent on fishing and fish exports; the shrimp
fishery is by far the largest income earner. Despite
resumption of several interesting hydrocarbon and
minerals exploration activities, it will take several
years before production can materialize. Tourism is
the only sector offering any near-term potential and
even this is limited due to a short season and high
costs. The public sector, including publicly owned
enterprises and the municipalities, plays the dominant
role in Greenland''s economy. About half the
government revenues come from grants from the
Danish Government, an important supplement of
GDP.
GDP: purchasing power parity— $945 million (1997
est.)
GDP— real growth rate: 0.6% (1997 est.)
GDP— per capita: purchasing power parity —
$16,100 (1997 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 0.6% (1997
est.)
Labor force:
total: 24, 500 (1995 es','34fe9391676b95486456aa5a47fd29c3a82e7b02b51c5f6a382b5ceb2d316579','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fb2c67e4a0a20de3f47bbb0e909ecbeb4ef7a8154ba2836f86289add6d9ea67',1998,'FR','France','economy',99,'t.)
Unemployment rate: 1 0.5% (1 995 est.)
Budget:
revenues; $706 million
expenditures: $697 million, including capital
expenditures of $NA (1995)
Industries: fish processing (mainly shrimp),
handicrafts, furs, small shipyards
Industrial production growth rate: NA%
Electricity— capacity: 106,000 kW (1995)
Electricity— production: 245 million kWh (1995)
Electricity— consumption per capita: 4,253 kWh
(1995)
Agriculture— products: forage crops, small garden
vegetables; sheep, fish
Exports:
total value: $363.4 million (f.o.b., 1995)
commodities: fish and fish products 95%
partners: Denmark 89%, Japan 5%, UK 5%
Imports:
total value: $421 million (c.i.f., 1995)
commodities : machinery and transport equipment
25%, manufactured goods 1 8%, food and live animals
11%, petroleum products 6%
partners: Denmark 7.5%, Iceland 3.8%, Japan 3.3%,
Norway 3.1%, US 2.4%, Germany 2.4%, Sweden
1.8%
Debt— external: $243 million (1995)
Economic aid: substantial annual subsidy from
Denmark— $427 million (1995)
Currency: 1 Danish krone (DKr) = 100 oere
Exchange rates: Danish kroner (DKr) per US$1 —
6.916 (January 1998), 6.604 (1997), 5.799 (1996),
5.602 (1995), 6.361 (1994), 6.484 (1993)
Fiscal year: calendar year
Economy— overview: The economy depends on
agriculture, tourism, light industry, and services. It is
also dependent upon France for large subsidies and
imports. Tourism is a key industry, with most tourists
from the US; an increasingly large number of cruise
ships visit the islands. The traditional sugarcane crop
is slowly being replaced by other crops, such as
bananas (which now supply about 50% of export
earnings), eggplant, and flowers. Other vegetables
and root crops are cultivated for local consumption,
although Guadeloupe is still dependent on imported
food, mainly from France. Light industry features
sugar and rum production. Most manufactured goods
and fuel are imported. Unemployment is especially
high among the young.
GDP: purchasing power parity— $3.7 billion (1995
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $9,200
(1995 est.)
GDP— composition by sector:
agriculture: 6%
industry: 9%
services: 85% (1993 est.)
Inflation rate— consumer price index: 3.7%
(1990)
Labor force:
total: 128,000
by occupation: agriculture 15%, industry 20%,
services 65% (1993)
Unemployment rate: 31 .3% (1 995)
Budget:
revenues: $300 million
expenditures: $460 million, including capital
expenditures of $90 million (1995)
Industries: construction, cement, rum, sugar,
tourism
Industrial production growth rate: NA%
Electricity— capacity: 388,000 kW (1995)
192
Electricity— production: 1 billion kWh (1995)
Electricity— consumption per capita: 2,483 kWh
(1995)
Agriculture— products: bananas, sugarcane,
tropical fruits and vegetables; cattle, pigs, goats
Exports:
total value:$ 145 million (f.o.b., 1994)
commodities: bananas, sugar, rum
partners: France 75%, Martinique 13% (1994)
Imports:
total value : $1 .6 billion (c.i.f., 1 994)
commodities: foodstuffs, fuels, vehicles, clothing and
other consumer goods, construction materials
partners: France 64%, EU 13%, Martinique 4%, US,
Japan (1994)
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
note: substantial annual French subsidies
Currency: 1 French franc (F) = 100 centimes
Exchange rates: French francs (F) per US$1 —
6.0836 (January 1998), 5.8367 (1997), 5.1155(1996),
4.9915 (1995), 5.5520 (1994), 5.6632 (1993)
Fiscal year: calendar year
Economy— overview: Kazakhstan, the second
largest of the former Soviet republics in territory,
possesses enormous untapped fossil fuel reserves as
well as plentiful supplies of other minerals and metals.
It also has considerable agricultural potential with its
vast steppe lands accommodating both livestock and
grain production. Kazakhstan''s industrial sector rests
on the extraction and processing of these natural
resources and also on a relatively large machine
248
building sector specializing in construction equipment,
tractors, agricultural machinery, and some defense
items. The breakup of the USSR and the collapse of
demand for Kazakhstan''s traditional heavy industry
products have resulted in a sharp contraction of the
economy since 1 991 , with the steepest annual decline
occurring in 1994. In 1995-97 the pace of the
government program of economic reform and
privatization quickened, resulting in a substantial
shifting of assets into the private sector. The
December 1996 signing of the Caspian Pipeline
Consortium agreement to build a new pipeline from
western Kazakhstan''s Tengiz oil field to the Black Sea
increases prospects for substantially larger oil exports
in several years. The emigration of large numbers of
skilled Slavic managers and technicians from the
northern industrial areas will hold back future growth.
GDP: purchasing power parity— $50 billion
(1997 est.)
GDP— real growth rate: 2.1% (1997 est.)
GDP— per capita: purchasing power parity— $3,000
(1997 est.)
GDP— composition by sector:
agriculture: 12%
industry: 25%
services: 63% (1 996 est.)
Inflation rate— consumer price index: 12%
(1997 est.)
Labor force:
total: 6.9 million
by occupation : industry 27%, agriculture and forestry
23%, other 50% (1996)
Unemployment rate: 2.6% includes only officially
registered unemployed; also large additional numbers
of unemployed and underemployed workers
(December 1996 est.)
Budget:
revenues: $3 billion
expenditures: $4.6 billion, including capital
expenditures of $40 million (1996 est.)
Industries: oil, coal, iron ore, manganese, chromite,
lead, zinc, copper, titanium, bauxite, gold, silver,
phosphates, sulfur, iron and steel, nonferrous metal,
tractors and other agricultural machinery, electric
motors, construction materials; much of industrial
capacity is shut down and/or is in need of repair
Industrial production growth rate: 3% (1997 est.)
Electricity— capacity: 18.9 million kW (1995)
Electricity— production: 61.7 billion kWh (1995)
Electricity— consumption per capita: 3,800 kWh
(1996 est.)
Agriculture— products: grain, mostly spring wheat,
cotton; wool, meat
Exports:
total value: $5.6 billion (1996)
commodities: oil, ferrous and nonferrous metals,
chemicals, grain, wool, meat, coal
partners: Russia, Ukraine, Uzbekistan, Netherlands,
Economy— overview: The economy is based on
sugarcane, bananas, tourism, and light industry.
Agriculture accounts for about 6% of GDP and the
small industrial sector for 1 1 %. Sugar production has
declined, with most of the sugarcane now used for the
production of rum. Banana exports are increasing,
going mostly to France. The bulk of meat, vegetable,
and grain requirements must be imported,
contributing to a chronic trade deficit that requires
large annual transfers of aid from France. Tourism has
become more important than agricultural exports as a
source of foreign exchange. The majority of the work
force is employed in the service sector and in
administration.
GDP: purchasing power parity— $3.95 billion (1995
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity —
$10,000 (1995 est.)
GDP— composition by sector:
agriculture: 6%
industry: 11%
services: 83% (1 992 est.)
Inflation rate— consumer price index: 3.9%
(1990)
Labor force:
total: 160,000
by occupation: agriculture 10%, industry 17%,
services 73% (1992)
Unemployment rate: 23.5% (1994)
Budget:
revenues : $658 million
expenditures: $2.2 billion, including capital
expenditures of $1 64 million (1 994)
Industries: construction, rum, cement, oil refining,
sugar, tourism
Industrial production growth rate: NA%
Electricity— capacity: 1 1 5,000 kW (1 995)
Electricity— production: 900 million kWh (1995)
Electricity— consumption per capita: 2,280 kWh
(1995)
Agriculture— products: pineapples, avocados,
bananas, flowers, vegetables, sugarcane for rum
Exports:
total value: $220 million (f.o.b., 1994)
commodities : refined petroleum products, bananas,
rum, pineapples
partners: France 57%, Guadeloupe 31%, French
Guiana (1991)
Imports:
total value: $1 .6 billion (c.i.f., 1 994)
commodities: petroleum products, crude oil,
foodstuffs, construction materials, vehicles, clothing
and other consumer goods
partners: France 62%, UK, Italy, Germany, Japan, US
(1991)
Debt— external: $180 million (1994)
Economic aid:
recipient: ODA, $NA
note: substantial annual French aid
Currency: 1 French franc (F) = 100 centimes
Exchange rates: French francs (F) per US$1 —
6.0836 (January 1 998), 5.8367 (1 997), 5. 1 1 55 (1 996),
4.9915 (1995), 5.5520 (1994), 5.6632 (1993)
Fiscal year: calendar year
Economy— overview: The government has
embraced free-market economics, freezing spending,
easing price controls, liberalizing domestic and
international trade. Mongolia''s severe climate,
scattered population, and wide expanses of
unproductive land, however, have constrained
economic development. Economic activity
traditionally has been based on agriculture and the
breeding of livestock. In past years extensive mineral
resources had been developed with Soviet support;
total Soviet assistance at its height amounted to 30%
of GDP, but disappeared almost overnight in 1 990-91 .
The mining and processing of coal, copper,
molybdenum, tin, tungsten, and gold account for a
large part of industrial production. The Mongolian
leadership has been soliciting support from foreign
donors, who pledged some $250 million in aid in
October 1997. Economic growth picked up in 1997
after stalling in 1996 due to a series of natural
disasters and declines in world prices of copper and
cashmere.
GDP: purchasing power parity— $5.6 billion (1997
est.)
GDP— real growth rate: 3.3% (1997 est.)
GDP— per capita: purchasing power parity— $2,200
(1997 est.)
GDP— composition by sector:
agriculture: 34%
industry: 32%
services: 34% (1995 est.)
Inflation rate— consumer price index: 17.5%
(1997 est.)
Labor force:
total: 1.115 million (mid-1 993 est.)
by occupation: primarily herding/agricultural
Unemployment rate: 15% (1997 est.)
Budget:
revenues: $N A
expenditures: $NA
Industries: copper, construction materials, mining
(particularly coal); food and beverage, processing of
animal products
Industrial production growth rate: 4.5% (1997
est.)
Electricity— capacity: 901 ,000 kW (1995)
Electricity— production: 3.15 billion kWh (1995)
Electricity— consumption per capita: 1 ,303 kWh
(1995)
Agriculture— products: wheat, barley, potatoes,
forage crops; sheep, goats, cattle, camels, horses
Exports:
total value: $418 million (f.o.b., 1997 est.)
commodities: copper, livestock, animal products,
cashmere, wool, hides, fluorspar, other nonferrous
metals
partners: Russia 21%, China 18% (1996)
Imports:
total value: $443.4 million (f.o.b., 1997 est.)
commodities: machinery and equipment, fuels, food
products, industrial consumer goods, chemicals,
building materials, sugar, tea
partners: Russia 34%, China 15% (1996)
Debt— external: $500 million (1996 est.)
Economic aid:
recipient: ODA $250 million (1998 est.)
Currency: 1 tughrik (Tug) = 100 mongos
Exchange rates: tughriks (Tug) per US$1— 812.09
(December 1997), 789.99 (1997), 548.40 (1996),
448.61 (1995), 412.72 (1994)
Fiscal year: calendar year
Debt— external: $5.7 billion (December 1997)
Economic aid:
recipient: ODA, $NA
Currency: 1 metical (Mt) = 100 centavos
Exchange rates: meticais (Mt) per US$1— 1 1 ,635.0
(January 1998), 11.543.6 (1997), 11,293.8 (1996),
9,024.3 (1995), 6,038.6 (1994), 3,874.2 (1993)
Fiscal year: calendar year
Economy— overview: The economy is heavily
dependent on the extraction and processing of
minerals for export. Mining accounts for 20% of GDP.
Namibia is the fourth-largest exporter of nonfuel
minerals in Africa and the world''s fifth-largest
producer of uranium. Rich alluvial diamond deposits
make Namibia a primary source for gem-quality
diamonds. Namibia also produces large quantities of
lead, zinc, tin, silver, and tungsten. Half of the
population depends on agriculture (largely
subsistence agriculture) for its livelihood. Namibia
must import some of its food. Although per capita GDP
is three to six times the per capita GDP of Africa''s
poorest countries, the majority of Namibia''s people
live in pronounced poverty because of the great
inequality of income distribution and the large
amounts going to foreigners. The Namibian economy
has close links to South Africa.
GDP: purchasing power parity— $6.2 billion (1996
est.)
GDP— real growth rate: 3% (1996 est.)
GDP— per capita: purchasing power parity— $3,700
(1996 est.)
GDP— composition by sector:
agriculture: 15%
industry: 20%
services : 65% (1 995 est.)
Inflation rate— consumer price index: 8% (1996
est.)
Labor force:
total: 500,000
by occupation: agriculture 49%, industry and
commerce 25%, services 5%, government 18%,
mining 3% (1994 est.)
Unemployment rate: 30% to 40%, including
underemployment (1997 est.)
Budget:
revenues: $"1 A billion
expenditures: $1 .2 billion, including capital
expenditures of $193 million (FY96/97 est.)
Industries: meat packing, fish processing, dairy
products; mining (diamond, lead, zinc, tin, silver,
tungsten, uranium, copper)
Industrial production growth rate: 10% (1994)
Electricity— capacity: 0 kW (1 995)
Electricity— production: 0 kWh (1995)
note: imports electricity from South Africa
Electricity— consumption per capita: 584 kWh
(1995)
Agriculture— products: millet, sorghum, peanuts;
livestock; fish
Exports:
total value: $1 .45 billion (f.o.b., 1996 est.)
commodities: diamonds, copper, gold, zinc, lead,
uranium, cattle, processed fish, karakul skins
partners: UK, South Africa, Spain, Japan (1994)
Imports:
total value: $1 .55 billion (f.o.b., 1 996 est.)
commodities : foodstuffs, petroleum products and fuel,
machinery and equipment, chemicals
partners: South Africa 85%, Germany, US, Japan
(1994 est.)
Debt— external: $315 million (1996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Namibian dollar (N$) = 100 cents
Exchange rates: Nambian dollars (N$) per US$1 —
4.94193 (January 1998), 4.60796 (1997), 4.29935
(1996), 3.62709 (1995), 3.55080 (1994), 3.26774
(1993)
Fiscal year: 1 April— 31 March
Economy— overview: The economy has
traditionally been based on agriculture. Sugarcane
has been the primary crop for more than a century,
386
and in some years it accounts for 85% of exports. The
government has been pushing the development of a
tourist industry to relieve high unemployment, which
recently amounted to one-third of the labor force. The
gap in Reunion between the well-off and the poor is
extraordinary and accounts for the persistent social
tensions. The white and Indian communities are
substantially better off than other segments of the
population, often approaching European standards,
whereas indigenous groups suffer the poverty and
unemployment typical of the poorer nations of the
African continent. The outbreak of severe rioting in
February 1991 illustrates the seriousness of
socioeconomic tensions. The economic well-being of
Reunion depends heavily on continued financial
assistance from France.
GDP: purchasing power parity— $3 billion (1 996 est.)
GDP— real growth rate: 4% (1996 est.)
GDP— per capita: purchasing power parity— $4,300
(1996 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force:
total: 242,1 69 (1993)
by occupation : agriculture 8%, industry 1 9%, services
73% (1990)
Unemployment rate: 35% (1994)
Budget:
revenues: $856.7 million
expenditures: $2.2437 billion, including capital
expenditures of NA (1993)
Industries: sugar, rum, cigarettes, handicraft items,
flower oil extraction
Industrial production growth rate: NA%
Electricity— capacity: 299,000 kW (1995)
Electricity— production: 1.105 billion kWh (1995)
Electricity— consumption per capita: 1 ,659 kWh
(1995)
Agriculture— products: sugarcane, vanilla,
tobacco, tropical fruits, vegetables, corn
Exports:
total value: $171. 776 million (f.o.b., 1994)
commodities: sugar 63%, rum and molasses 4%,
perfume essences 2%, lobster 3%, (1993)
partners: France, Mauritius, Bahrain, South Africa,
Italy, Madagascar
Imports:
total value: $2,354 billion (c.i.f., 1994)
commodities: manufactured goods, food, beverages,
tobacco, machinery and transportation equipment,
raw materials, and petroleum products
partners: France, Mauritius, Bahrain, South Africa,
Italy, Madagascar
Debt— external: $NA
Economic aid:
recipient: substantial annual subsidies from France
Currency: 1 French franc (F) = 100 centimes
Exchange rates: French francs (F) per US$1 —
6.0836 (January 1 998), 5.8367 (1 997), 5.1 1 55 (1 996),
4.9915 (1995), 5.5520 (1994), 5.6632 (1993)
Fiscal year: calendar year
Economy— overview: Agriculture, dominated by
banana production, is the most important sector of this
lower middle income economy. The services sector,
based mostly on a growing tourist industry, is also
important. The government has been relatively
unsuccessful at introducing new industries, and high
unemployment rates of 35%-40% continue. The
continuing dependence on a single crop represents
the biggest obstacle to the islands'' development;
tropical storms wiped out substantial portions of crops
in both 1994 and 1995. The tourism sector has
considerable potential for development over the next
decade.
GDP: purchasing power parity— $259 million (1996
est.)
GDP— real growth rate: 1 % (1 996 est.)
GDP— per capita: purchasing power parity— $2,200
(1996 est.)
GDP— composition by sector:
agriculture: 10.6%
industry: 17.5%
services: 71 .9% (1 996 est.)
Inflation rate— consumer price index: 3.6%
(1996)
Labor force:
total: 67,000 (1984 est.)
by occupation: agriculture 26%, industry 17%,
services 57% (1980 est.)
Unemployment rate: 35%-40% (1994 est.)
Budget:
revenues: $80 million
expenditures: $118 million, including capital
expenditures of $39 million (1996 est.)
Industries: food processing, cement, furniture,
clothing, starch
industrial production growth rate: 0.3% (1995
est.)
Electricity— capacity: 14,000 kW (1995)
Electricity— production: 64 million kWh (1995)
Electricity— consumption per capita: 545 kWh
(1995)
Agriculture— products: bananas, coconuts, sweet
potatoes, spices; small numbers of cattle, sheep, pigs,
goats; small fish catch used locally
Exports:
total value: $ 46 million (f.o.b., 1996)
commodities : bananas 39%, eddoes and dasheen
(taro), arrowroot starch, tennis racquets
partners: Caricom countries 49%, UK 16%, US 10%
(1995)
Imports:
total value: $127 million (f.o.b., 1996)
commodities: foodstuffs, machinery and equipment,
chemicals and fertilizers, minerals and fuels
partners: US 36%, Caricom countries 28%, UK 13%
(1995)
Debt— external: NA
Economic aid:
recipient: ODA, $NA
Currency: 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars (EC$) per
US$1— 2.7000 (fixed rate since 1976)
Fiscal year: calendar year
Economy— overview: The UK is one of the world''s
great trading powers and financial centers, and its
essentially capitalistic economy ranks among the four
largest in Western Europe. Over the past two decades
the government has greatly reduced public ownership
and contained the growth of social welfare programs.
Agriculture is intensive, highly mechanized, and
efficient by European standards, producing about
60% of food needs with only about 1 % of the labor
force. The UK has large coal, natural gas, and oil
reserves; primary energy production accounts for
12% of GDP, one of the highest shares of any
industrial nation. Services, particularly banking,
489
United Kingdom (continued)
insurance, and business services, account by far for
the largest proportion of GDP while industry continues
to decline in importance, now employing only 18% of
the work force. Exports and manufacturing output
have been the primary engines of growth.
Unemployment is gradually falling. Inflation is a
moderate 3.1%. A major economic policy question for
the UK in the late 1990s is the terms on which it
participates in the financial and economic integration
of Europe.
GDP: purchasing power parity— $1 .242 trillion (1 997
est.)
GDP— real growth rate: 3.5% (1997 est.)
GDP— per capita: purchasing power parity —
$21,200 (1997 est.)
GDP— composition by sector:
agriculture : 1 .8%
industry: 31 .4%
services: 66.8% (1996 est.)
Inflation rate— consumer price index: 3.1%
(1997)
Labor force:
total: 28.2 million (1997)
by occupation: services 68.9%, manufacturing and
construction 17.5%, government 1 1 .3%, energy 1 .2%,
agriculture 1.1% (1996)
Unemployment rate: 5.5% (1997 est.)
Budget:
revenues; $416.1 billion
expenditures: $470 billion, including capital
expenditures of $NA (1 996 est.)
Industries: production machinery including machine
tools, electric power equipment, automation
equipment, railroad equipment, shipbuilding, aircraft,
motor vehicles and parts, electronics and
communications equipment, metals, chemicals, coal,
petroleum, paper and paper products, food
processing, textiles, clothing, and other consumer
goods
Industrial production growth rate: 2% (1997 est.)
Electricity— capacity: 66.149 million kW (1995)
Electricity— production: 306.62 billion kWh (1995)
Electricity— consumption per capita: 5,546 kWh
(1995)
Agriculture— products: cereals, oilseed, potatoes,
vegetables; cattle, sheep, poultry; fish
Exports:
total value: $268 billion (f.o.b., 1997)
commodities: manufactured goods, machinery, fuels,
chemicals, semifinished goods, transport equipment
partners: EU countries 53.2% (Germany 12.4%,
France 9.9%, Netherlands 7.8%), US 11.4% (1996)
Imports:
total value: $283.5 billion (f.o.b., 1997)
commodities: manufactured goods, machinery,
semifinished goods, foodstuffs, consumer goods
partners: EU countries 50.2% (Germany 14.2%,
France 9.0%, Netherlands 6.5%), US 13.9% (1996)
Debt— external: $16.2 billion (June 1992)
Economic aid:
donor: ODA, $2,908 billion (1993)
Currency: 1 British pound (£) = 100 pence
Exchange rates: British pounds (£) per US$1 —
0.61 1 5 (January 1 998), 0.61 06 (1 997), 0.6403 (1 996),
0.6335 (1995), 0.6529 (1994), 0.6658 (1993)
Fiscal year: 1 April— 31 March
Economy— overview: The US has the most
powerful, diverse, and technologically advanced
economy in the world, with a per capita GDP of
$30,200, the largest among major industrial nations. In
this market-oriented economy, private individuals and
business firms make most of the decisions, and
government buys needed goods and services
predominantly in the private marketplace. US business
firms enjoy considerably greater flexibility than their
counterparts in Western Europe and Japan in
decisions to expand capital plant, lay off surplus
workers, and develop new products. At the same time,
they face higher barriers to entry in their rivals'' home
markets than the barriers to entry of foreign firms in US
markets. In all economic sectors, US firms are at or
near the forefront in technological advances, especially
in computers and in medical, aerospace, and military
equipment, although their advantage has narrowed
since the end of World War II. The onrush of
technology largely explains the gradual development
of a "two-tier labor market" in which those at the bottom
lack the education and the professional/technical skills
of those at the top and, more and more, fail to get pay
raises, health insurance coverage, and other benefits.
The years 1994-97 witnessed moderate gains in real
output, low inflation rates, and a drop in unemployment
below 6%. Long-term problems include inadequate
investment in economic infrastructure, rapidly rising
medical costs of an aging population, sizable trade
deficits, and stagnation of family income in the lower
economic groups. The outlook for 1 998 is for continued
moderate growth, low inflation, and about the same
level of unemployment. Two shadows for 1 998 are the
severe financial crises in East Asia and the exuberant
level of stock prices in relation to corporate earnings.
GDP: purchasing power parity— $8,083 trillion (1 997
est.)
GDP— real growth rate: 3.8% (1997)
GDP— per capita: purchasing power parity —
$30,200 (1997 est.)
GDP— composition by sector:
agriculture: 2%
industry: 23%
services: 75% (1997','2747ee89a994a32a092a9d6074ce2c8539148e2c90aa0487f41c11a72040b8f1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecb153af3fc8890315605fef26b57052d99c26f0e4d5d49a6e7550dc4de997b3',1998,'FR','France','economy',100,'est.)
Inflation rate— consumer price index: 2% (1997)
Labor force:
total: 136.3 million (includes unemployed) (1997)
by occupation: managerial and professional 29.1%,
technical, sales and administrative support 29.6%,
services 13.5%, manufacturing, mining,
transportation, and crafts 25.1%, farming, forestry,
and fishing 2.7%
Unemployment rate: 4.9% (1997)
Budget:
revenues; $1 .579 trillion
expenditures: $1 .601 trillion, including capital
expenditures of $NA (1997)
Industries: leading industrial power in the world,
highly diversified and technologically advanced;
petroleum, steel, motor vehicles, aerospace,
telecommunications, chemicals, electronics, food
processing, consumer goods, lumber, mining
Industrial production growth rate: 3.9% (1997)
Electricity— capacity: 741.589 million kW (1995)
Electricity— production: 3.585 trillion kWh (1995)
Electricity— consumption per capita: 13,732 kWh
(1995)
Agriculture— products: wheat, other grains, corn,
fruits, vegetables, cotton; beef, pork, poultry, dairy
products; forest products; fish
Exports:
total value: $625.1 billion (f.o.b., 1996)
commodities: capital goods, automobiles, industrial
supplies and raw materials, consumer goods,
agricultural products
partners: Canada 22%, Western Europe 21%, Japan
11%, Mexico 8% (1995)
Imports:
total value: $ 822 billion (c.i.f., 1996)
commodities: crude oil and refined petroleum
products, machinery, automobiles, consumer goods,
industrial raw materials, food and beverages
partners: Canada, 20%, Western Europe 18%, Japan
16.5%, Mexico 8% (1995)
Debt— external: $862 billion (1995 est.)
Economic aid:
donor: ODA, $9,721 billion (1993)
492
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: British pounds (£) per US$—
0.61 1 5 (January 1 998), 0.61 06 (1 997), 0.6403 (1 996),
0.6335 (1995), 0.6529 (1994), 0.6658 (1993);
Canadian dollars (Can$) per US$— 1 .4408 (January
1998), 1.3846 (1997), 1.3635 (1996), 1.3724 (1995),
1.3656 (1994), 1.2901 (1993); French francs (F) per
US$ — 6.0836 (January 1998), 5.8367 (1997), 5.1155
(1996), 4.9915 (1995), 5.5520 (1994), 5.6632 (1993);
Italian lire (Lit) per US$— 1,787.7 (January 1997),
1,703.1 (1997), 1,542.9(1996), 1,628.9 (1995),
1,612.4 (1994), 1,573.7 (1993); Japanese yen (•) per
US$— 129.45 (January 1998), 120.99 (1997), 108.78
(1996), 94.06 (1995), 102.21 (1994), 111.20 (1993);
German deutsche marks (DM) per US$ — 1 .8167
(January 1998), 1.7341 (1997), 1.5048(1996), 1.4331
(1995), 1.6228(1994), 1.6533 (1993)
Fiscal year: 1 October— 30 September
Economy— overview: Economic progress in the
West Bank has been hampered by tight Israeli
security restrictions. Industries using advanced
technology or requiring sizable investment have been
discouraged by a lack of local capital and Israeli
policies that block the movement of goods and people.
Capital investment consists largely of residential
housing, not productive assets that would enable local
Palestinian firms to compete with Israeli industry.
GDP has been substantially supplemented by
workers who commute to jobs in Israel. Worker
remittances from the Persian Gulf states dropped
after Iraq invaded Kuwait in August 1990. In the wake
of the Persian Gulf crisis, many Palestinians have
returned to the West Bank, increasing unemployment,
and export revenues have dropped because of the
decline of markets in Jordan and the Gulf states. An
estimated 147,000 people were in refugee camps in
1996.
GDP: purchasing power parity— $2.8 billion (1996
est.)
GDP— real growth rate: -6.9% (1996 est.)
GDP— per capita: purchasing power parity— $1 ,600
(1996 est.)
GDP— composition by sector:
agriculture: 33%
industry: 25%
services: 42% (1995 est., includes Gaza Strip)
Inflation rate— consumer price index: 8.4% (1996
est.)
Labor force: NA
by occupation: agriculture 13%, industry 13%,
commerce, restaurants, and hotels 12%, construction
8%, other services 54% (1996)
note: excluding Israeli settlers
Unemployment rate: 28% (1997 est.)
Budget:
revenues: $684 million
expenditures: $779 million, including capital
expenditures of $NA (1996)
note: includes Gaza Strip
Industries: generally small family businesses that
produce cement, textiles, soap, olive-wood carvings,
and mother-of-pearl souvenirs; the Israelis have
established some small-scale, modern industries in
the settlements and industrial centers
Industrial production growth rate: NA%
Electricity— capacity: NA kW
note: most electricity imported from Israel; East
Jerusalem Electric Company buys and distributes
electricity to Palestinians in East Jerusalem and its
concession in the West Bank; the Israel Electric
Company directly supplies electricity to most Jewish
residents and military facilities; at the same time,
some Palestinian municipalities, such as Nabulus and
Janin, generate their own electricity from small power
plants
Electricity— production: NA kWh
note: most electricity imported from Israel; East
Jerusalem Electric Company buys and distributes
electricity to Palestinians in East Jerusalem and its
concession in the West Bank; the Israel Electric
Company directly supplies electricity to most Jewish
residents and military facilities; at the same time,
some Palestinian municipalities, such as Nabulus and
Janin, generate their own electricity from small power
plants
Electricity— consumption per capita: NA kWh
Agriculture— products: olives, citrus and other
fruits, vegetables; beef, dairy products
Exports:
total value: $630 million (f.o.b., 1997 est.) (includes
Gaza Strip)
commodities: olives, fruit, vegetables, limestone
partners: Jordan, Israel
Imports:
total value: $1 .7 billion (c.i.f., 1997 est.) (includes
Gaza Strip)
commodities: food, consumer goods, construction
materials
partners: Jordan, Israel
Debt— external: $51 million (1995)
Economic aid:
recipient: ODA, $NA
Currency: 1 new Israeli shekel (NIS) = 100 new
agorot; 1 Jordanian dinar (JD) = 1 ,000 fils
510
Exchange rates: new Israeli shekels (NIS) per
US$1— 3.5340 (December 1997), 3.4494 (1997),
3.1 91 7 (1 996), 3.01 1 3 (1 995), 3.01 1 1 (1994), 2.8301
(1993); Jordanian dinars (JD) per US$1 — 0.7090
(January 1 998), 0.7090 (1 997), 0.7090 (1 996), 0.7005
(1995), 0.6987 (1994), 0.6928 (1993)
Fiscal year: calendar year (since 1 January 1992)','ba4a0e11528e597e30909f5262d79cf52e906c813b83b819024a237cd8449725','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9482d9f966e9dc414f7a8dcf97a320f41bbf216e97139f3ee6bad89aa286fc82',1998,'BJ','Benin','economy',108,'Economy— overview: The economy of Benin
remains underdeveloped and dependent on
subsistence agriculture, cotton production, and
regional trade. Growth in real output, which had
averaged a sound 4% during 1 990-95, rose to 5.5% in
1 996 and was targeted at 4.8% for 1 997. Rapid
population growth offset much of this growth in output.
Inflation jumped to 55% in 1994 (compared to 3% in
1993) following the 50% currency devaluation in
January 1994, but has subsided over the past three
years, with a target of 3.5% inflation in 1997.
Commercial and transport activities, which make up a
large part of GDP, are extremely vulnerable to
developments in Nigeria, particularly fuel shortages.
Support by the Paris Club and official bilateral
creditors has eased the external debt situation in
recent years. The government, still burdened with
money-losing state enterprises and a bloated civil
service, has been gradually implementing a World
Bank supported structural adjustment program since
1991.
GDP: purchasing power parity— $1 1 .3 billion (1997
est.)
GDP— real growth rate: 5.8% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,900
(1997 est.)
GDP— composition by sector:
agriculture: 34%
industry: 14%
services: 52% (1995)
Inflation rate— consumer price index: 3.5% (1997
est.)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues; $299 million
expenditures: $ 445 million, including capital
expenditures of $14 million (1995 est.)
Industries: textiles, cigarettes; beverages, food;
construction materials, petroleum
Industrial production growth rate: NA%
Electricity— capacity: 15,000 kW (1995)
Electricity— production: 6 million kWh (1995)
Electricity— consumption per capita: 45 kWh
(1995)
Agriculture— products: corn, sorghum, cassava
(tapioca), yams, beans, rice, cotton, palm oil, peanuts;
poultry, livestock
Exports:
total value: $ 192 million (f.o.b., 1995)
commodities: cotton, crude oil, palm products, cocoa
partners: Brazil 18%, Portugal 14%, Morocco, Libya,','1cb541a4baa78ed6b315d6e360bf7e5cd82ac0daf039470e860d0c18b9faf06b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0eb35b2d9a1cb925f90c63be9e6711f54a25578025593c23d8e6eb5c3325973e',1998,'BM','Bermuda','economy',112,'Economy— overview: Bermuda enjoys one of the
highest per capita incomes in the world, having
successfully exploited its location by providing
financial services for international firms and luxury
tourist facilities for 360,000 visitors annually. The
tourist industry, which accounts for an estimated 28%
of GDP, attracts 84% of its business from North
America. The industrial sector is small, and agriculture
is severely limited by a lack of suitable land. About
80% of food needs are imported. International
business contributes over 60% of Bermuda''s
economic output; a failed independence vote in late
1995 can be partially attributed to Bermudian fears of
scaring away foreign firms.
GDP: purchasing power parity— $1 .8 billion (1 996
est.)
GDP— real growth rate: 2.4% (1996 est.)
GDP— per capita: purchasing power parity —
$29,000 (1996 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 1.8%
(November 1997)
Labor force:
total: 34,633
by occupation: clerical 23%, services 22%, laborers
17%, professional and technical 17%, administrative
and managerial 12%, sales 7%, agriculture and
fishing 2% (1996)
Unemployment rate: NEGL% (1995)
Budget:
revenues: $430.9 million
expenditures: $452.9 million, including capital
expenditures of $50 million (FY95/96 est.)
Industries: tourism, finance, insurance, structural
concrete products, paints, perfumes,
pharmaceuticals, ship repairing
Industrial production growth rate: NA%
Electricity— capacity: 145,000 kW (1996)
Electricity— production: 527,526,728 kWh (1996)
Electricity— consumption per capita: 7,856 kWh
(1996)
Agriculture— products: bananas, vegetables,
citrus, flowers; dairy products
Exports:
total value: $67.7 million (f.o.b., 1996 est.)
commodities : reexports of pharmaceuticals
partners: Netherlands 50%, Brazil 13%, Canada 6%
(1996)
Imports:
total value: $569 million (f.o.b., 1996 est.)
commodities: miscellaneous manufactured articles,
machinery and transport equipment, food and live
animals, chemicals
partners: US 73%, UK 5%, Canada 4% (1996 est.)
Debt— external: $NA
Economic aid: $NA
Currency: 1 Bermudian dollar (Bd$) = 100 cents
Exchange rates: Bermudian dollar (Bd$) per
US$1— 1.0000 (fixed rate)
Fiscal year: 1 April— 31 March
Economy— overview: The economy, one of the
world''s smallest and least developed, is based on
agriculture and forestry, which provide the main
livelihood for 90% of the population and account for
about 40% of GDP. Agriculture consists largely of
subsistence farming and animal husbandry. Rugged
mountains dominate the terrain and make the building
of roads and other infrastructure difficult and
expensive. The economy is closely aligned with
India''s through strong trade and monetary links. The
industrial sector is technologically backward, with
most production of the cottage industry type. Most
development projects, such as road construction, rely
on Indian migrant labor. Bhutan''s hydropower
potential and its attraction for tourists are key
resources. The Bhutanese Government has made
some progress in expanding the nation''s productive
base and improving social welfare. Model education,
social, and environment programs in Bhutan are
underway with support from multilateral development
organizations. Each economic program takes into
account the government''s desire to protect the
country''s environment and cultural traditions. GDP
growth averaged 5% per year in 1991-95, with
information not yet available for 1996-97. Detailed
controls and uncertain policies in areas like industrial
licensing, trade, labor, and finance continue to
hamper foreign investment.
GDP: purchasing power parity— $1 .3 billion (1 995
est.)
GDP— real growth rate: 6.9% (1995 est.)
GDP— per capita: purchasing power parity— $730
(1995 est.)
GDP— composition by sector:
agriculture: 42%
industry: 32%
services: 26% (1 995 est.)
Inflation rate— consumer price index: 7% (FY96/
97 est.)
Labor force: NA
by occupation: agriculture 93%, services 5%, industry
and commerce 2%
note: massive lack of skilled labor
Unemployment rate: NA%
Budget:
revenues: $146 million
expenditures: $152 million, including capital
expenditures of $94 million (FY95/96 est.)
note: the government of India finances nearly
three-fifths of Bhutan''s budget expenditures
Industries: cement, wood products, processed
fruits, alcoholic beverages, calcium carbide
Industrial production growth rate: 7.6% (1992
est.)
Electricity— capacity: 361,000 kW (1995)
Electricity— production: 1.707 billion kWh (1995)
note: exports electricity to India
Electricity— consumption per capita: 143 kWh
(1995)
Agriculture— products: rice, corn, root crops,
citrus, foodgrains; dairy products, eggs
Exports:
total value: $77.4 million (f.o.b., 1996 est.)
commodities: cardamom, gypsum, timber,
handicrafts, cement, fruit, electricity (to India),
precious stones, spices
partners: India 94%, Bangladesh
Imports:
total value: $104.1 million (c.i.f., 1996 est.)
commodities: fuel and lubricants, grain, machinery
and parts, vehicles, fabrics, rice
partners: India 77%, Japan, UK, Germany, US
Debt— external: $129 million (FY94/95)
Economic aid:
recipient: $NA
Currency: 1 ngultrum (Nu) - 100 chetrum; note—
Indian currency is also legal tender
Exchange rates: ngultrum (Nu) per US$1 — 39.358
(January 1998), 36.313 (1 997), 35.433 (1 996), 32.427
(1995), 31.374 (1994), 30.493 (1993); note-the
Bhutanese ngultrum is at par with the Indian rupee
Fiscal year: 1 July— 30 June
F. Communications
Telephones: 4,620(1991 est.)
Telephone system:
domestic: domestic telephone service is very poor
with very few telephones in use
international: international telephone and telegraph
service is by landline through India; a satellite earth
station was planned (1990)
Radio broadcast stations: AM 1, FM 1,
shortwave 0(1 990)
Radios: 23,000 (1989 est.)
Television broadcast stations: 0 (1990 est.)
Televisions: 200 (1985 est.)','b9a896a5639e72f6b74d1921ade517ddda12a0021685979dfabcdc3739012110','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee46adc4c1d1d8dfa5fdf99d7d13bb3ecacd66ea7651bd9515e67fdd2492c8db',1998,'BR','Brazil','economy',120,'Economy— overview: With its long history of
semifeudal social controls, dependence on volatile
prices for its mineral exports, and bouts of
hyperinflation, Bolivia has remained one of the
poorest and least developed Latin American
countries. However, Bolivia has experienced
generally improving economic conditions since the
PAZ Estenssoro administration (1985-89) introduced
market-oriented policies which reduced inflation from
1 1 ,700% in 1985 to about 20% in 1988. PAZ
Estenssoro was followed as president by Jaime PAZ
Zamora (1989-93) who continued the free-market
policies of his predecessor, despite opposition from
his own party and from Bolivia''s once powerful labor
movement. By maintaining fiscal discipline, PAZ
Zamora helped reduce inflation to 9.3% in 1993, while
GDP grew by an annual average of 3.25% during his
tenure. President SANCHEZ DE LOZADA
(1993-1997) vowed to advance the market-oriented
economic reforms he helped launch as PAZ
Estenssoro''s planning minister. His successes
included the signing of a free trade agreement with
Mexico and the Southern Cone Common Market
(Mercosur) as well as the privatization of the state
airline, phone company, railroad, electric power
company, and oil company. Furthermore, SANCHEZ
DE LOZADA sponsored legislation creating private
social security accounts for all adult Bolivians and
capitalized these new accounts with the state''s
remaining 50% share in the privatized companies.
Hugo BANZER Suarez took office in August 1997 and
has proclaimed his commitment to the economic
reforms of the previous administration.
GDP: purchasing power parity— $23.1 billion (1997
est.)
GDP— real growth rate: 4.4% (1997 est.)
GDP— per capita: purchasing power parity— $3,000
(1997 est.)
GDP— composition by sector:
agriculture: 17%
industry: 26%
services: 57% (1995 est.)
Inflation rate— consumer price index: 7% (1997)
Labor force:
total: 2.5 million
by occupation: agriculture NA%, services and utilities
NA%, manufacturing, mining and construction NA%
Unemployment rate: 10%
Budget:
revenues: $3.75 billion
expenditures: $ 3.75 billion, including capital
expenditures of $556.2 million (1995 est.)
Industries: mining, smelting, petroleum, food and
beverages, tobacco, handicrafts, clothing
Industrial production growth rate: 4% (1995 est.)
Electricity— capacity: 786,000 kW (1995)
Electricity— production: 2.9 billion kWh (1995)
Electricity— consumption per capita: 370 kWh
(1995)
Agriculture— products: coffee, coca, cotton, corn,
sugarcane, rice, potatoes; timber
Exports:
total value: $1 .4 billion (f.o.b., 1 997)
commodities: metals 34%, natural gas 9.4%,
soybeans 8.4%, jewelry 11%, wood 6.9%
partners: US 22%, UK 9.3%, Colombia 8.7%, Peru
7.4%, Argentina 7.2%
Imports:
total value: $ 1 .7 billion (c.i.f. 1997)
commodities: capital goods 48%, chemicals 11%,
petroleum 5%, food 5% (1993 est.)
partners: US 20%, Japan 13%, Brazil 12, Chile 7.5%
(1996)
Debt— external: $4.2 billion (1997)
Economic aid:
recipient: ODA, $588 million (1997)
Currency: 1 boliviano ($B) = 100 centavos
Exchange rates: bolivianos ($B) per US$1— 5.3724
(January 1998), 5.2543 (1997), 5.0746 (1996), 4.8003
(1995), 4.6205 (1994), 4.2651 (1993)
Fiscal year: calendar year
f Comm u n i cat! o ns
Telephones: 144,300 (1987 est.)
Telephone system: new subscribers face
bureaucratic difficulties; most telephones are
concentrated in La Paz and other cities
domestic: microwave radio relay system being
expanded
international: satellite earth station— 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 129, FM 0,
shortwave 68
Radios: NA
Television broadcast stations: 43
Televisions: 500,000 (1993 est.)
T r a n s port a t To n
Railways:
total: 3,691 km (single track)
narrow gauge: 3,652 km 1 .000-m gauge; 39 km
0.760-m gauge (13 km electrified) (1995)
Highways:
total: 52,21 6 km
paved: 2,872 km (including 27 km of expressways)
unpaved: 49,344 km (1995 est.)
Waterways: 1 0,000 km of commercially navigable
waterways
Pipelines: crude oil 1,800 km; petroleum products
580 km; natural gas 1,495 km
Ports and harbors: none; however, Bolivia has free
port privileges in the maritime ports of Argentina,
Brazil, Chile, and Paraguay
Merchant marine:
total: 1 cargo ship (1 ,000 GRT or over) totaling 4,21 4
GRT/6,390 DWT (1997 est.)
57
Bolivia (continued)
Airports: 1,153 (1997 est.)
Airports— with paved runways:
total: 1 1
over 3,047 m: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4 (1 997 est.)
Airports— with unpaved runways:
total: 1,142
2,438 to 3,047 m: 3
1,524 to 2,437 m: 73
914 to 1,523 m: 229
under 91 4 m: 837 (1997 est.)
Economy— overview: Bosnia and Herzegovina
ranked next to The Former Yugoslav Republic of
Macedonia as the poorest republic in the old Yugoslav
federation. Although agriculture has been almost all in
private hands, farms have been small and inefficient,
and the republic traditionally has been a net importer
of food. Industry has been greatly overstaffed, one
reflection of the rigidities of communist central
planning and management. TITO had pushed the
development of military industries in the republic with
the result that Bosnia hosted a large share of
Yugoslavia''s defense plants. The bitter interethnic
warfare in Bosnia caused production to plummet by
80% from 1990 to 1995, unemployment to soar, and
human misery to multiply. With an uneasy peace in
place, output has recovered in 1996-97 at high
percentage rates on a low base, but remains less than
half the 1990 level. The country, especially in the
Muslim-Croat area, receives substantial amounts of
humanitarian aid from the international community.
Wide regional differences in war damage and access
to the outside world have resulted in substantial
variations in living conditions among local areas and
individual families.
GDP: purchasing power parity— $4.41 billion (1997
est.)
GDP— real growth rate: 35% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,690
(1997 est.)
GDP— composition by sector:
agriculture: 19%
industry: 23%
se/v/ces:58%(1996 est.)
Inflation rate— consumer price index: NA%
Labor force:
total: 1,026,254
by occupation: N A%
Unemployment rate: 40%-50% (1996 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: steel, coal, iron ore, lead, zinc,
manganese, bauxite, vehicle assembly, textiles,
tobacco products, wooden furniture, tank and aircraft
assembly, domestic appliances, oil refining; much of
capacity damaged or shut down (1 995)
Industrial production growth rate: NA%
Electricity— capacity: 2.339 million kW (1995)
Electricity— production: 1.4 billion kWh (1995)
Electricity— consumption per capita: 506 kWh
(1995)
Agriculture— products: wheat, corn, fruits,
vegetables; livestock
Exports:
total value: $ 152 million (1995 est.)
commodities: NA
partners: NA
Imports:
total value: $1 .1 billion (1 995 est.)
commodities: NA
partners: NA
Debt— external: $3.5 billion (yearend 1995 est.)
Economic aid:
recipient: .2 billion (1997 pledged)
Currency: 1 convertible marka = 100 convertible
pfenniga; former currencies still used
Exchange rates: NA
Fiscal year: calendar year
Economy— overview: Agriculture still provides a
livelihood for more than 80% of the population but
supplies only about 50% of food needs and accounts
for only 4% of GDP. Subsistence farming and cattle
raising predominate. Diamond mining and tourism
also are important to the economy. The sector is
plagued by erratic rainfall and poor soils. Substantial
mineral deposits were found in the 1970s and the
mining sector grew from 25% of GDP in 1 980 to 35%
in 1997. Unemployment officially is 21% but unofficial
estimates place it closer to 40%. On the plus side is
the substantia! positive trade balance.
GDP: purchasing power parity— $5 billion (1 997 est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity— $3,300
(1997 est.)
GDP— composition by sector:
agriculture: 4%
industry: 45% (including 35% mining)
services: 51% (1997 est.)
Inflation rate— consumer price index: 10% (1996
est.)
Labor force:
total: 235,000 formal sector employees (1995)
by occupation : 1 00,000 public sector; 1 35,000 private
sector, including 14,300 who are employed in various
mines in South Africa; most others engaged in cattle
raising and subsistence agriculture (1995 est.)
Unemployment rate: 20-40% (1997 est.)
Budget:
revenues; $1.6 billion
expenditures: $1.8 billion, including capital
expenditures of $560 million (FY96/97)
Industries: diamonds, copper, nickel, coal, salt,
soda ash, potash; livestock processing
Industrial production growth rate: 4.6% (FY92/
93)
Electricity— capacity: 217,000 kW (1995)
Electricity— production: 1 billion kWh (1995)
Electricity— consumption per capita: 962 kWh
(1995)
Agriculture— products: sorghum, maize, millet,
pulses, groundnuts (peanuts), beans, cowpeas,
sunflower seed; livestock
Exports:
total value: $ 2.31 billion (f.o.b. 1996 est.)
commodities: diamonds 71%, copper and nickel 5%,
meat 3%
partners: Europe 74%, Southern African Customs
Union (SACU) 22%, Zimbabwe 3%
Imports:
total value: $1.6 billion (c.i.f., 1996 est.)
commodities: foodstuffs, vehicles and transport
equipment, textiles, petroleum products
partners : Southern African Customs Union (SACU)
74%, Europe 8%, Zimbabwe 6%
Debt— external: $619 million (1996)
Economic aid:
recipient: ODA, $189 million (1993)
Currency: 1 pula (P) = 100 thebe
Exchange rates: pula (P) per US$1— 3.8547
(January 1 998), 3.6508 (1 997), 3.3242 (1 996), 2.771 6
(1995), 2.6831 (1994), 2.4190 (1993)
Fiscal year: 1 April— 31 March
Electricity— consumption per capita: 577 kWh
(1995)
Agriculture— products: cotton, sugarcane,
soybeans, corn, wheat, tobacco, cassava (tapioca),
fruits, vegetables; beef, pork, eggs, milk; timber
Exports:
total value: $1 A billion (f.o.b., 1997 est.)
commodities: cotton, soybeans, timber, vegetable
oils, meat products, coffee, tung oil
partners: Brazil 48%, Netherlands 22%, Argentina
9%, US 4%, Uruguay 3%, Chile 2% (1997)
Imports:
total value: $2.5 billion (c.i.f., 1996 est.)
commodities: capital goods, consumer goods,
foodstuffs, raw materials, fuels
partners: Brazil 29%, US 22%, Argentina 14%, Hong
Kong 9% (1995)
Debt— external: $1.3 billion (1996)
Economic aid:
recipient: ODA, $38 million (1993)
Currency: 1 guarani (G) = 100 centimos
Exchange rates: guaranies (G) per US$ — 2,528.8
(January 1998), 2,191.0 (1997), 2,062.8 (1996),
1 ,970.4 (1 995), 1 ,91 1 .5 (1 994), 1 ,744.3 (1 993)
Fiscal year: calendar year
Economy— overview: The Peruvian economy has
become increasingly market-oriented, with major
privatizations completed since 1990 in the mining,
electricity, and telecommunications industries. In the
1980s, the economy suffered from hyperinflation,
declining per capita output, and mounting external
debt. Peru was shut off from IMF and World Bank
support in the mid-1980s because of its huge debt
arrears. An austerity program implemented shortly
after the FUJIMORI government took office in July
1990 contributed to a third consecutive yearly
contraction of economic activity, but the slide came to
a halt late that year, and in 1991 output rose 2.4%.
After a burst of inflation as the austerity program
eliminated government price subsidies, monthly price
increases eased to the single-digit level and by
December 1 991 dropped to the lowest increase since
mid-1987. Lima obtained a financial rescue package
from multilateral lenders in September 1991 , although
it faced $14 billion in arrears on its external debt. By
working with the IMF and World Bank on new financial
conditions and arrangements, the government
succeeded in ending its arrears by March 1993. In
1992, GDP fell by 2.8%, in part because a
warmer-than-usual El Nino current resulted in a 30%
drop in the fish catch, but the economy rebounded as
strong foreign investment helped push growth to 7% in
1993, about 13% in 1994, and 6.8% in 1995. Growth
slowed to about 2.8% in 1996 as the government
adopted tight fiscal and monetary policy to reduce the
current account deficit and meet its IMF targets.
Growth then rebounded to 7.3% in 1997 even as
inflation fell to its lowest level in 23 years. Capital
inflows surged to record levels in early 1997 and have
remained strong despite economic shocks stemming
from the Asian financial crisis and the El Nino weather
events.
GDP: purchasing power parity— $1 1 0.2 billion (1 997
est.)
GDP— real growth rate: 7.3% (1997 est.)
GDP— per capita: purchasing power parity— $4,420
(1997 est.)
GDP— composition by sector:
agriculture: 14%
industry: 41%
services: 45% (1996)
Inflation rate— consumer price index: 6.7% (1 997
est.)
Labor force:
total: 7. 6 million (1996 est.)
by occupation: agriculture, mining and quarrying,
manufacturing, construction, transport, services
Unemployment rate: 8.2%; extensive
underemployment (1996)
Budget:
revenues: $8.5 billion
expenditures: $9.3 billion, including capital
expenditures of $2 billion (1996 est.)
Industries: mining of metals, petroleum, fishing,
textiles, clothing, food processing, cement, auto
assembly, steel, shipbuilding, metal fabrication
Industrial production growth rate: 1.2% (1996)
Electricity— capacity: 4.187 million kW (1995)
Electricity— production: 15.6 billion kWh (1995)
Electricity— consumption per capita: 648 kWh
(1995)
Agriculture— products: coffee, cotton, sugarcane,
rice, wheat, potatoes, plantains, coca; poultry, red
meats, dairy products, wool; fish catch of 6.9 million
metric tons (1990)
Exports:
total value: $5.9 billion (f.o.b., 1996)
commodities: copper, zinc, fishmeal, crude petroleum
and byproducts, lead, refined silver, coffee, cotton
partners: US 20%, Japan 7%, UK 7%, China 7%,
Germany 5% (1996)
Imports:
total value: $9.2 billion (f.o.b., 1996)
commodities : machinery, transport equipment,
foodstuffs, petroleum, iron and steel, chemicals,
pharmaceuticals
partners: US 31%, Colombia 7%, Chile 6%,
Venezuela 6%, UK 6% (1996)
Debt— external: $25.7 billion (1996 est.)
Economic aid:
recipient: ODA, $363 million (1993)
Currency: 1 nuevo sol (SI.) = 100 centimos
Exchange rates: nuevo sol (SI.) per US$1— 2.750
(January 1998), 2.664 (1997), 2.453 (1996), 2.253
(1995), 2.195 (1994), 1.988 (1993)
Fiscal year: calendar year','3ca9c851bf7db5277441c4875e18e5ad9780a545c8fbe58b9b1b36807d013558','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a40724bdbed263a08a15b9238ac190ffff1d464ba566d6f70eb8ab07e337340e',1998,'ID','Indonesia','economy',138,'Economy— overview: All economic activity is
concentrated on the largest island of Diego Garcia,
where joint UK-US defense facilities are located.
Construction projects and various services needed to
support the military installations are done by military
and contract employees from the UK, Mauritius, the
Philippines, and the US. There are no industrial or
agricultural activities on the islands.
Electricity— capacity: NA kW
note: electricity supplied by the US military
Electricity— production: NA kWh
note: electricity supplied by the US military
Electricity— consumption per capita: NA kWh
Economy— overview: The economy, one of the
most prosperous in the Caribbean, is highly
dependent on tourism, which generates an estimated
45% of the national income. In 1985, the government
began offering offshore registration to companies
wishing to incorporate in the islands, and
incorporation fees now generate substantial
revenues. An estimated 210,000 companies were on
the offshore registry by yearend 1 996. The adoption of
a comprehensive insurance law in late 1994, which
provides a blanket of confidentiality with regulated
statutory gateways for investigation of criminal
offenses, is expected to make the British Virgin
Islands even more attractive to international business.
Livestock raising is the most important agricultural
activity; poor soils limit the islands'' ability to meet
domestic food requirements. Because of traditional
close links with the US Virgin Islands, the British Virgin
Islands has used the dollar as their currency since
1959.
GDP: purchasing power parity— $144 million (1996
est.)
GDP— real growth rate: 4.5% (1996 est.)
GDP— per capita: purchasing power parity —
$1 1 ,000 (1996 est.)
GDP— composition by sector:
agriculture: 3%
industry: U%
services: 83% (1989)
Inflation rate— consumer price index: 2.5% (1990
est.)
Labor force:
total: 4,911 (1980)
by occupation: tourism NA%
Unemployment rate: 3% (1995)
Budget:
revenues: $77.1 million
expenditures: $76.4 million, including capita!
expenditures of $NA (FY93/94)
Industries: tourism, light industry, construction, rum,
concrete block, offshore financial center
Industrial production growth rate: 4% (1985)
Electricity— capacity: 13,000 kW (1995)
Electricity— production: 42 million kWh (1995)
Electricity— consumption per capita: 3,224 kWh
(1995)
Agriculture— products: fruits, vegetables;
livestock, poultry; fish
Exports:
total value: $3.4 million (f.o.b., 1990)
commodities : rum, fresh fish, fruits, animals; gravel,
sand
partners: Virgin Islands (US), Puerto Rico, US
Imports:
total value: $ 11.5 million (c.i.f., 1988)
commodities: building materials, automobiles,
foodstuffs, machinery
partners: Virgin Islands (US), Puerto Rico, US
Debt— external: $4.5 million (1985)
Economic aid: $NA
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 April— 31 March
Economy— overview: This small, wealthy economy
is a mixture of foreign and domestic entrepreneurship,
government regulation and welfare measures, and
village tradition. It is almost totally supported by
exports of crude oil and natural gas, with revenues
from the petroleum sector accounting for perhaps half
of GDP. Per capita GDP is far above most other Third
World countries, and substantial income from
overseas investment supplements income from
domestic production. The government provides for all
medical services and subsidizes food and housing.
The government is beginning to show progress on its
basic policy of diversifying the economy away from oil
and gas. Brunei''s leaders are concerned that steadily
increased integration in the world economy will
undermine internal social cohesion.
GDP: purchasing power parity— $5.4 billion (1997
est.)
GDP— real growth rate: 3.5% (1997 est.)
GDP— per capita: purchasing power parity —
$18,000 (1997 est.)
GDP— composition by sector:
agriculture : 5%
industry: 46%
services: 49% (1996 est.)
Inflation rate— consumer price index: 2% (1997
est.)
Labor force:
total: 144,000 (1995 est.); note— includes foreign
workers and military personnel
by occupation: government 48%, production of oil,
natural gas, services, and construction 42%,
agriculture, forestry, and fishing 4%, other 6% (1986
est.)
note : temporary residents make up 41 % of labor force
(1991)
Unemployment rate: 4.8% (1994 est.)
Budget:
revenues: $2.5 billion
expenditures: $2.6 billion, including capital
expenditures of $768 million (1995 est.)
Industries: petroleum, petroleum refining, liquefied
natural gas, construction
Industrial production growth rate: 4% (1997 est.)
Electricity— capacity: 646,000 kW (1997 est.)
Electricity— production: 1 .26 billion kWh (1995)
Electricity— consumption per capita: 4,31 1 kWh
(1995)
Agriculture— products: rice, cassava (tapioca),
bananas; water buffalo
Exports:
total value: $2.62 billion (f.o.b., 1996 est.)
commodities: crude oil, liquefied natural gas,
petroleum products
partners: ASEAN 31%, Japan 27%, South Korea
26%, UK, Taiwan (1996 est.)
Imports:
total value: $ 2.65 billion (c.i.f., 1996 est.)
commodities: machinery and transport equipment,
manufactured goods, food, chemicals
partners: Singapore 29%, UK 19%, US 13%,
Malaysia 9%, Japan 5% (1994 est.)
Debt— external: $0
Economic aid: $NA
Currency: 1 Bruneian dollar (B$) = 100 cents
Exchange rates: Bruneian dollars (B$) per US$1 —
1 .7533 (January 1 998), 1 .4848 (1997), 1 .41 00 (1 996),
1.4174 (1995), 1.5274 (1994), 1.6158 (1993); note-
the Bruneian dollar is at par with the Singapore dollar
Fiscal year: calendar year
Economy— overview: While Indonesia was long
touted for its sound macroeconomic management and
spectacular growth, the Asian financial crisis in 1997/
98 revealed the weak underpinnings of the economy:
an unhealthy banking sector, untenable levels of
private foreign debt, and uncompetitive practices that
favored the financial interests of former President
SOEHARTO''s family and friends. Indonesia sought
IMF assistance early in the crisis and eventually
brokered a $42 billion bailout package; but Jakarta
jeopardized the program by resisting strict IMF
reforms, partly in response to the rupiah''s collapse,
which lost as much as 80% of its value at one point.
Economic prospects look bleak for 1 998: the economy
probably will shrink between 4% to 10%,
unemployment top historic highs— in excess of 1 5%—
and inflation move toward hyper levels.
GDP: purchasing power parity— $960 billion
(1997 est.)
GDP— real growth rate: 4% (1997 est.)
GDP— per capita: purchasing power parity— $4,600
(1997 est.)
GDP— composition by sector:
agriculture: 16%
industry: 43%
services: 41% (1996)
Inflation rate— consumer price index: 50%
(1998 est.)
Labor force:
total: 67 million
by occupation: agriculture 44%, manufacturing 13%,
construction 5%, transport and communications 4%,
other 34% (1995 est.)
Unemployment rate: 15%; underemployment 50%
(1998 est.)
Budget:
revenues: $42.8 billion
expenditures: $42.8 billion, including capital
expenditures of $14.4 billion (FY97/98 est.)
Industries: petroleum and natural gas, textiles,
mining, cement, chemical fertilizers, plywood, food,
rubber; tourism
Industrial production growth rate: 10.5% (1996
est.)
Electricity— capacity: 16.265 million kW (1995)
Electricity— production: 60.4 billion kWh (1995)
Electricity— consumption per capita: 297 kWh
(1995)
Agriculture— products: rice, cassava (tapioca),
peanuts, rubber, cocoa, coffee, palm oil, copra, other
tropical products; poultry, beef, pork, eggs
Exports:
total value: $53.4 billion (f.o.b., 1997)
commodities: textiles/garments 20.6%, wood
products 15.7%, electronics 9.9%, footwear 6.1%
partners: Japan 27.1%, US 13.9%, Singapore 8.3%,
South Korea 6.4%, Taiwan 3.9%, China 3.8%, Hong
Kong 3.6% (1995)
Imports:
total value: $41 .6 billion (f.o.b., 1997)
commodities : manufactures 75.3%, raw materials
9.0%, foodstuffs 7.8%, fuels 7.7%
partners: Japan 22.7%, US 11.7%, Germany 6.9%,
South Korea 6.0%, Singapore 5.8%, Australia 5.0%,
Taiwan 4.5% (1995)
Debt— external: $136 billion (yearend 1997 est.)
Economic aid:
recipient: IMF program, $42 billion (1998 est.)
Currency: Indonesian rupiah (Rp)
Exchange rates: Indonesian rupiahs (Rp) per
US$1— 8,000 (April 1998), 2,909.4 (1997), 2,342.3
(1996), 2,248.6 (1995), 2,160.8 (1994), 2,087.1 (1993)
Fiscal year: 1 April— 31 March
Economy-overview: Iran''s economy is a mixture
of central planning, state ownership of oil and other
large enterprises, village agriculture, and small-scale
private trading and service ventures. Newly elected
President KHATAMI has continued to follow the
market reform plans of former President
RAFSANJANI and has indicated that he will pursue
diversification of Iran''s oil-reliant economy. In the early
1990s, Iran experienced a financial crisis and was
forced to reschedule $15 billion in debt. The strong oil
market in 1996 helped ease financial pressures on
Iran and allowed for Tehran''s timely debt service
payments. Iran''s financial situation tightened in 1997
and early 1998 because of lower oil prices. Iran may
be forced to decrease imports and slow debt
repayments if the oil market worsens further.
GDP: purchasing power parity— $371 .2 billion
(1997 est.)
GDP— real growth rate: 3.2% (1997 est.)
GDP— per capita: purchasing power parity— $5,500
(1997 est.)
GDP— composition by sector:
agriculture: 21%
industry: 37%
services: 42% (1994 est.)
Inflation rate— consumer price index: 23% (1996)
Labor force:
total: 15.4 million
by occupation: agriculture 33%, manufacturing 21%
(1988 est.)
note: shortage of skilled labor
Unemployment rate: more than 30%
(January 1998 est.)
Budget:
revenues: $34.6 billion
expenditures: $34.9 billion, including capital
expenditures of $1 1 .8 billion (FY96/97)
Industries: petroleum, petrochemicals, textiles,
cement and other construction materials, food
processing (particularly sugar refining and vegetable
oil production), metal fabricating, armaments
Industrial production growth rate: 5.7%
(FY95/96 est.)
Electricity— capacity: 25.1 17 million kW (1995)
Electricity— production: 79 billion kWh (1995)
Electricity— consumption per capita: 1 ,222 kWh
(1995)
Agriculture— products: wheat, rice, other grains,
sugar beets, fruits, nuts, cotton; dairy products, wool;
caviar
Exports:
total value: $ 19 billion (f.o.b., 1997 est.)
commodities: petroleum 80%, carpets, fruits, nuts,
hides, iron, steel
partners: Japan, US, UK, Germany, South Korea,
UAE
Imports:
total value: $ 15.6 billion (f.o.b., 1997 est.)
commodities: machinery, military supplies, metal
works, foodstuffs, pharmaceuticals, technical
services, refined oil products
partners: Germany, Italy, Japan, UAE, UK, Belgium
Debt— external: $21 .9 billion (1 996 est.)
Economic aid:
recipient: ODA, $40 million (1993)
Currency: 10 Iranian rials (IR) = 1 toman; note-
domestic figures are generally referred to in terms of
the toman
Exchange rates: Iranian rials (IR) per US$1 —
1,752.14 (January 1998), 1,750.76 (1996), 1,752.92
(1997), 1,747.93 (1995), 1,748.75 (1994), 1,267.77
(1993); black market rate: 4,600 rials per US$1
(March 1 997); note— as of May 1 995, the "official rate"
of 1 ,750 rials per US$1 is used for imports of essential
goods and services and for oil exports, whereas the
"official export rate" of 3,000 rials per US$1 is used for
non-oil exports and imports not covered by the official
rate
Fiscal year: 21 March— 20 March
Economy— overview: The Ba''thist regime engages
in extensive central planning and management of
industrial production and foreign trade while leaving
some small-scale industry and services and most
agriculture to private enterprise. The economy has
been dominated by the oil sector, which has
traditionally provided about 95% of foreign exchange
earnings. In the 1980s, financial problems caused by
massive expenditures in the eight-year war with Iran
and damage to oil export facilities by Iran led the
government to implement austerity measures and to
borrow heavily and later reschedule foreign debt
payments; Iraq suffered economic losses of at least
$100 billion from the war. After the end of hostilities in
1988, oil exports gradually increased with the
construction of new pipelines and restoration of
damaged facilities. Agricultural development
remained hampered by labor shortages, salinization,
227
Iraq (continued)
and dislocations caused by previous land reform and
collectivization programs. The industrial sector,
although accorded high priority by the government,
also was under financial constraints. Iraq''s seizure of
Kuwait in August 1990, subsequent international
economic embargoes, and military action by an
international coalition beginning in January 1991
drastically changed the economic picture. The
UN-sponsored economic embargo has reduced
exports and imports and has contributed to the sharp
rise in prices. The Iraqi Government has been
unwilling to abide by UN resolutions so that the
economic embargo could be removed. The
government''s policies of supporting large military and
internal security forces and of allocating resources to
key supporters of the regime have exacerbated
shortages. Industrial and transportation facilities,
which suffered severe damage, have been partially
restored. At current prices, oil exports are about
one-third of their prewar level because of the
implementation of UN Security Council Resolution
986— the UN''s oil-for-goods program— in December
1996. Shortages of spare parts continue. In accord
with the oil-for-goods deal, Iraq is allowed to export $2
billion worth of oil in exchange for badly needed food
and medicine, The first oil was pumped in December
1996, and the first supplies of food and medicine
arrived in April 1997. Per capita output for 1995-97
and living standards are well below the 1989-90 level,
but any estimates have a wide range of error.
GDP: purchasing power parity— $42.8 billion
(1997 est.)
GDP— real growth rate: 0% (1997 est.)
GDP— per capita: purchasing power parity— $2,000
(1997 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force:
total: 4 A million (1989)
by occupation: services 48%, agriculture 30%,
industry 22%
note: severe labor shortage; expatriate labor force
was about 1,600,000 (July 1990); since then, it has
declined substantially
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capita! expenditures of
$NA
Industries: petroleum, chemicals, textiles,
construction materials, food processing
Industrial production growth rate: NA%
Electricity— capacity: 6.83 million kW (1996)
Electricity— production: 31 .8 billion kWh (1996)
Electricity— consumption per capita: 1,362 kWh
(1996 est.)
Agriculture— products: wheat, barley, rice,
vegetables, dates, other fruit, cotton; cattle, sheep
Exports: $NA
commodities: crude oil
partners: Jordan, Turkey (1996)
Imports: $NA
commodities: manufactures, food
partners: France, Turkey, Jordan, Vietnam, Australia
(1996)
Debt— external: very heavy relative to GDP but
amount unknown (1996)
Economic aid:
recipient: ODA, $NA
Currency: 1 Iraqi dinar (ID) = 1,000 fils
Exchange rates: Iraqi dinars (ID) per US$1— 0.3109
(fixed official rate since 1982); black market rate —
Iraqi dinars (ID) per US$1 — 1 ,530 (December 1997),
3,000 (December 1995); subject to wide fluctuations
Fiscal year: calendar year
Economy— overview: Economic activity consists
primarily of subsistence farming and fishing. The
islands have few mineral deposits worth exploiting,
except for high-grade phosphate. The potential for a
tourist industry exists, but the remoteness of the
location and a lack of adequate facilities hinder
development. Financial assistance from the US is the
primary source of revenue, with the US pledged to
spend $1 billion in the islands in the 1990s.
Geographical isolation and a poorly developed
infrastructure are major impediments to long-term
growth.
GDP: purchasing power parity— $220 million (1996
est.)
note: GDP is supplemented by grant aid, averaging
perhaps $100 million annually
GDP— real growth rate: 1% (1996 est.)
GDP— per capita: purchasing power parity— $1 ,760
(1996 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 4% (1996
est.)
Labor force: NA
by occupation: two-thirds are government employees
Unemployment rate: 27% (1989)
Budget:
revenues: $58 million
expenditures: $52 million, including capital
expenditures of $4.7 million (FY95/96 est.)
Industries: tourism, construction, fish processing,
craft items from shell, wood, and pearls
Industrial production growth rate: NA%
Electricity— capacity: 38,500 kW (1995)
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Agriculture— products: black pepper, tropical fruits
and vegetables, coconuts, cassava (tapioca), sweet
potatoes; pigs, chickens
Exports:
total value: $73 million (f.o.b., 1996 est.)
commodities: fish, garments, bananas, black pepper
partners: Japan, US, Guam
Imports:
total value: $ 168 million (c.i.f., 1996 est.)
commodities: food, manufactured goods, machinery
and equipment, beverages
partners: US, Japan, Australia
Debt— external: $129 million
Economic aid:
recipient: under terms of the Compact of Free
Association, the US will provide $1 .3 billion in grant
aid during the period 1986-2001
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October— 30 September
Economy— overview: The economy is based on
providing support services for any remaining activities
located on the islands. All food and manufactured
goods must be imported.
Electricity— capacity: NA kW
Electricity— production: NA kWh
Economy— overview: Moldova enjoys a favorable
climate and good farmland but has no major mineral
deposits. As a result, the economy depends heavily
on agriculture, featuring fruits, vegetables, wine, and
tobacco. Moldova must import all of its supplies of oil,
coal, and natural gas, largely from Russia. Energy
shortages contributed to sharp production declines
after the breakup of the Soviet Union in 1991. The
Moldovan Government has recently been making
progress on an ambitious economic reform agenda.
As part of its reform efforts, Moldova introduced a
stable convertible currency, freed all prices, stopped
issuing preferential credits to state enterprises and
backed steady land privatization, removed export
controls, and freed interest rates. The IMF has
suspended payment on Moldova''s Extended Fund
Facility since November 1 997, due to concerns about
the budget deficit and money supply growth. In late
December Parliament agreed to a lower 1998 budget
deficit to address IMF and World Bank concerns.
GDP: purchasing power parity— $10.8 billion (1997
est.)
GDP— real growth rate: -2% (1997 est.)
GDP— per capita: purchasing power parity— $2,400
(1997 est.)
GDP— composition by sector:
agriculture : 42%
industry: 36%
services: 22% (1995)
Inflation rate— consumer price index: 1 1 .2%
(1997 est.)
Labor force:
total: 2.42 million (1995)
by occupation: agriculture 46.1%, industry 13.9%,
other 40.0% (1996)
Unemployment rate: 1 .4% (includes only officially
registered unemployed; large numbers of
underemployed workers) (March 1997)
Budget:
revenues: $570 million
expenditures: $ 641 million, including capital
expenditures of $28 million (1997 est.)
Industries: food processing, agricultural machinery,
foundry equipment, refrigerators and freezers,
washing machines, hosiery, sugar, vegetable oil,
shoes, textiles
316
Industrial production growth rate: -2% (1997 est.)
Electricity— capacity: 2.906 million kW (1997)
Electricity— production: 1.5 billion kWh (1997)
Electricity— consumption per capita: 324 kWh
(1996 est.)
Agriculture— products: vegetables, fruits, wine,
grain, sugar beets, sunflower seed, tobacco; meat,
milk
Exports:
total value: $ 816 million (1997)
commodities: foodstuffs, wine, tobacco, textiles and
footwear, machinery
partners: Russia, Kazakhstan, Ukraine, Romania,
Economy— overview: Singapore has an open
economy with strong service and manufacturing
sectors and excellent international trading links
derived from its entrepot history. Extraordinarily
strong fundamentals allowed Singapore to weather
the effects of the Asian financial crisis better than its
neighbors, but the crisis did pull GDP growth down to
approximately 6% in 1997. Projections for 1998 GDP
growth are in the 4.5% to 6.5% range. Rising labor
costs and appreciation of the Singapore dollar against
its neighbors'' currencies continue to be a threat to
Singapore''s competitiveness. The government''s
strategy to address this problem includes increasing
productivity, improving infrastructure, and
encouraging higher value-added industries. In applied
technology, per capita output, investment, and labor
discipline, Singapore has key attributes of a
developed country.
GDP: purchasing power parity— $84.6 billion (1997
est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity —
$24,600 (1997 est.)
GDP— composition by sector:
agriculture: NEGL%
industry: 28%
services: 72%
Inflation rate— consumer price index: 1 .8% (1 997
est.)
Labor force:
total: 1.856 million (1997 est.)
by occupation: financial, business, and other services
33.5%, manufacturing 25.6%, commerce 22.9%,
construction 6.6%, other 11.4% (1994)
Unemployment rate: 3% (1997 est.)
Budget:
revenues: $16.3 billion
expenditures: $13.6 billion, including capital
expenditures of $NA (FY97/98 est.)
Industries: electronics, financial services, oil drilling
equipment, petroleum refining, rubber processing and
rubber products, processed food and beverages, ship
repair, entrepot trade, biotechnology
Industrial production growth rate: 7% (1996 est.)
Electricity— capacity: 4.513 million kW (1995)
Electricity— production: 21 billion kWh (1995)
Electricity— consumption per capita: 7,234 kWh
(1995)
Agriculture— products: rubber, copra, fruit,
vegetables; poultry
420
Exports:
total value: % 125.6 billion (1997 est.)
commodities: computer equipment, rubber and rubber
products, petroleum products, telecommunications
equipment
partners: Malaysia 19%, US 18%, Hong Kong 9%,
Japan 8%, Thailand 6% (1995)
Imports:
total value: $133.9 billion (1997 est.)
commodities: aircraft, petroieum, chemicals,
foodstuffs
partners: Japan 21%, Malaysia 15%, US 15%,
Thailand 5%, Taiwan 4%, South Korea 4% (1995)
Debt— external: $NA
Economic aid: $NA
Currency: 1 Singapore dollar (S$) = 1 00 cents
Exchange rates: Singapore dollars (S$) per US$1 —
1 .7533 (January 1 998), 1 .4848 (1 997), 1 .41 00 (1 996),
1.4174 (1995), 1.5274 (1994), 1.6158 (1993)
Fiscal year: 1 April — 31 March','c3014f7db4ae07c093919dc54ceff71678306e197f3e7f469dbba1093e27d0d2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a7fbf5f45ae352fd47e3f980017e9e71c8bb98698a69f3fc4458c111dd83d9c',1998,'BG','Bulgaria','economy',145,'Economy— overview: One of the poorest countries
of central Europe, Bulgaria has slowly been moving
from its old command economy towards a
market-oriented economy. The economy faced a
major crisis in 1996, marked by a banking system in
turmoil, a depreciating currency, inflation of 311%,
and contracting production and foreign trade. Foreign
exchange reserves dwindled to $518 million, while
dramatically hiked interest rates added to the
domestic debt burden and stifled growth. GDP fell by
11% in 1996, after experiencing 2.0% growth in 1995.
Privatization of state-owned industries stagnated,
although the first auction of a mass privatization
program was undertaken in late 1996. Lagging
progress on structural reforms led to postponement of
IMF disbursements under a $580 million standby loan
agreed to in July 1996. In November 1996, the IMF
proposed a currency board as Bulgaria''s best chance
to restore confidence in the lev, eliminate
unnecessary spending, and avoid hyperinflation. The
board was set up on 1 July 1997. Its establishment
was followed by a reduction in inflation and interest
rates and by a rise in foreign investment.
Simultaneously the government pledged to sell off
some of the most attractive state assets. GDP in 1 997
dropped 7.4%, but is expected to rebound to an
estimated 2% in 1998. Other government objectives
include: the completion of land reform, the
privatization and strengthening of the banking system,
and the modernization of the legal environment of
business.
GDP: purchasing power parity— $35.6 billion (1997
est.)
GDP— real growth rate: -7.4% (1997 est.)
GDP— per capita: purchasing power parity— $4,100
(1997 est.)
GDP— composition by sector:
agriculture: 12%
industry: 31%
services: 57% (1 997 est.)
Inflation rate— consumer price index: 579%
(1997 est.)
Labor force:
total: 3.57 million (1996 est.)
by occupation: industry 41%, agriculture 18%, other
41% (1992)
Unemployment rate: 14% (1997 est.)
Budget:
revenues: $2.7 billion
expenditures: $3.2 billion, including capital
expenditures of $NA (1997 est.)
Industries: machine building and metal working,
food processing, chemicals, textiles, construction
materials, ferrous and nonferrous metals
Industrial production growth rate: -7.4% (1997
est.)
Electricity— capacity: 12.087 million kW (1995)
Electricity— production: 41.449 billion kWh (1995)
Electricity— consumption per capita: 4,821 kWh
(1995)
Agriculture— products: grain, oilseed, vegetables,
fruits, tobacco; livestock
Exports:
total value: $4.9 billion (f.o.b., 1997)
commodities : machinery and equipment 15.2%;
agriculture and food 18.9%; textiles and apparel
14.8%; metals, minerals, and fuels 26.5%; chemicals
and plastics 20%; other 4.6% (1996)
partners: OECD 50.0% (EU 37.2%); CIS and Central
and Eastern Europe 32.4%; Arab countries 5.8%;
other 11.8% (1995)
Imports:
total value: $4.5 billion (f.o.b., 1997 est.)
commodities: fuels, minerals, and raw materials
40.7%; machinery and equipment 1 8.4%; textiles and
apparel 1 1 .6%; agricultural products 7.5%; metals
and ores 5.2%; chemicals and plastics 12.2%; other
4.4% (1996)
partners: OECD 45.5% (EU 38.1%); CIS and Central
and Eastern European countries 41.1%; Arab
countries 1 .8%; other 1 1 .6% (1 995)
Debt— external: $10 billion (1997 est.)
Economic aid: NA
Currency: 1 lev (Lv) = 100 stotinki
Exchange rates: leva (Lv) per US$1— 1,740 (1997),
483.4 (1996), 70.7 (1995), 54.2 (1994), 27.1 (1993)
Fiscal year: calendar year','9eb41ae4d98e995d91657eb5a4aadc6ede4d121dc6ca1d8e5344a71349f50a59','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd69edd4a0f43bac4612c764fea6db7cc0976bb303934bc419fb04f7dc26fc0d',1998,'ET','Ethiopia','economy',153,'Economy— overview: Burma has a mixed economy
with private activity dominant in agriculture, light
industry, and transport, and with substantial
state-controlled activity, mainly in energy, heavy
industry, and the rice trade. Government policy in the
last nine years, 1989-97, has aimed at revitalizing the
economy after three decades of tight central planning.
Thus, private activity has markedly increased; foreign
investment has been encouraged, so far with
moderate success; and efforts continue to increase
the efficiency of state enterprises. Published
estimates of Burma''s foreign trade are greatly
understated because of the volume of black-market
trade. A major ongoing problem is the failure to
achieve monetary and fiscal stability. Although Burma
remains a poor Asian country, its rich resources
furnish the potential for substantial long-term
increases in income, exports, and living standards.
GDP: purchasing power parity— $55.7 billion (1997
est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity— $1,190
(1997 est.)
GDP— composition by sector:
agriculture: 61%
industry: 10%
services: 29% (1996 est.)
Inflation rate— consumer price index: 30%-40%
(1997 est.)
Labor force:
total: 18.8 million (FY95/96 est.)
by occupation: agriculture 65.2%, industry 14.3%,
trade 10.1%, government 6.3%, other 4.1% (FY88/89
est.)
Unemployment rate: NA%
Budget:
revenues: $7 .9 billion
expenditures: $12.2 billion, including capital
expenditures of $5.7 billion (FY96/97)
Industries: agricultural processing; textiles and
footwear; wood and wood products; copper, tin,
tungsten, iron; construction materials;
pharmaceuticals; fertilizer
Industrial production growth rate: 9.2% (FY95/96
est.)
Electricity— capacity: 1.212 million kW (1995)
Electricity— production: 4.1 billion kWh (FY95/96
est.)
Electricity— consumption per capita: 79 kWh
(1995)
Agriculture— products: paddy rice, corn, oilseed,
sugarcane, pulses; hardwood
Exports:
total value: $693 million (1 996)
commodities: pulses and beans, teak, rice, rubber,
hardwood
partners: Singapore, China, Indonesia, India,
Economy— overview: One of the 20 poorest
countries in the world, Guinea-Bissau depends mainly
on farming and fishing. Cashew crops have increased
remarkably in recent years, and the country now ranks
sixth in cashew production. Guinea-Bissau exports
fish and seafood along with small amounts of peanuts,
palm kernels, and timber. Rice is the major crop and
staple food. Trade reform and price liberalization are
the most successful part of the country''s structural
adjustment program under IMF sponsorship. The
tightening of monetary policy and the development of
the private sector have begun to reinvigorate the
economy. Inflation dropped sharply in the first quarter
of 1997. Membership in the WAMU (West African
Monetary Union) beginning in May 1997, should help
support 5% annual growth and contribute to fiscal
discipline. Because of high costs the development of
petroleum, phosphate, and other mineral resources is
not a near term prospect.
GDP: purchasing power parity— $1.15 billion (1997
est.)
GDP— real growth rate: 5% (1997 est.)
GDP— per capita: purchasing power parity— $975
(1997 est.)
GDP— composition by sector:
agriculture: 45%
industry: 18%
services: 37% (1997 est.)
Inflation rate— consumer price index: 65% (1996)
Labor force: 480,000
Unemployment rate: NA%
Budget: $NA
Industries: agricultural products processing, beer,
soft drinks
Industrial production growth rate: 2.6% (1997
est.)
Electricity— capacity: 1 1 ,000 kW (1 995)
Electricity— production: 45 million kWh (1995)
Electricity— consumption per capita: 40 kWh
(1995)
Agriculture— products: rice, corn, beans, cassava
(tapioca), cashew nuts, peanuts, palm kernels, cotton;
fishing and forest potential not fully exploited
Exports:
total value: $ 25.8 million (f.o.b., 1996 est.)
commodities: cashews 95%, fish, peanuts, palm
kernels, sawn lumber (1994)
partners: Spain 35%, India 30%, Thailand 10%, Italy
10% (1995)
Imports:
total value: $63 million (f.o.b., 1996 est.)
commodities: foodstuffs, transport equipment,
petroleum products, machinery and equipment (1 994)
partners: Thailand 27%, Portugal 23%, Japan 6%,
Cote d''Ivoire 7% (1995)
Debt— external: $953 million (1996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Communaute Financiere Africaine franc
(CFAF) = 100 centimes; note— on 1 May 1997,
Guinea-Bissau adopted as its currency the CFA franc
following its membership into the BCEAO
Exchange rates: CFA francs (CFAF) per US$1 —
608.36 (January 1 998), 583.67 (1 997);
Guinea-Bissauan pesos (PG) per US$1— 26,373
(1996), 18,073 (1995), 12,892 (1994), 10,082 (1993)
note: as of 2 May 1997, Guinea-Bissau has adopted
the CFA franc as the national currency following its
membership in BCEAO
Fiscal year: calendar year
Economy— overview: This small poor island
economy has become increasingly dependent on
cocoa since independence over 20 years ago.
However, cocoa production has substantially declined
because of drought and mismanagement. The
resulting shortage of cocoa for export has created a
persistent balance-of-payments problem. Sao Tome
has to import all fuels, most manufactured goods,
consumer goods, and a significant amount of food.
Over the years, it has been unable to service its
external debt and has had to depend on concessional
aid and debt rescheduling. Considerable potential
exists for development of a tourist industry, and the
government has taken steps to expand facilities in
recent years. The government also has attempted to
reduce price controls and subsidies, but economic
growth has remained sluggish. Sao Tome is also
optimistic that significant petroleum discoveries are
forthcoming in its territorial waters in the oil-rich waters
of the Gulf of Guinea.
GDP: purchasing power parity— $154 million (1996
est.)
GDP— real growth rate: 1 .5% (1 996 est.)
GDP— per capita: purchasing power parity— $1 ,000
(1996 est.)
GDP— composition by sector:
agriculture: 21%
industry: 26%
services: 53% (1 995 est.)
Inflation rate— consumer price index: 60% (1996
est.)
Labor force: most of population mainly engaged in
subsistence agriculture and fishing; there are
shortages of skilled workers
Unemployment rate: 28% (1996 est.)
Budget:
revenues: $58 million
expenditures: ''ll million, including capital
expenditures of $54 million (1993 est.)
Industries: light construction, textiles, soap, beer;
fish processing; timber
Industrial production growth rate: NA%
Electricity— capacity: 6,000 kW (1995)
Electricity— production: 16 million kWh (1995)
Electricity— consumption per capita: 1 1 4 kWh
(1995)
Agriculture— products: cocoa, coconuts, palm
kernels, copra, cinnamon, pepper, coffee, bananas,
papaya, beans; poultry; fish
Exports:
total value: $4.9 million (f.o.b., 1996 est.)
commodities : cocoa 95%, copra, coffee, palm oil
partners: Netherlands 75.7%, Germany 1.2%,
Portugal 1.1%
Imports:
total value: $ 19.6 million (c.i.f., 1996 est.)
commodities: machinery and electrical equipment,
food products, petroleum products
partners: Portugal 32.2%, France 16.8%, Belgium
6.6%, Japan, Angola
Debt— external: $266 million (1996)
Economic aid:
recipient: ODA, $NA
Currency: 1 dobra (Db) = 100 centimos
Exchange rates: dobras (Db) per US$1— 7,003.9
(December 1997), 4,552.5 (1997), 2,203.2 (1996),
1,420.3 (1995), 732.6 (1994), 429.9 (1993)
Fiscal year: calendar year','9924b2c75c9222cdd3d84ea3dd80f45dd97907087031365272f1363ae81b8f36','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cdf5d7c69ed55fc29c21c636240bc525e29f4e9ab398a732772fe8456f372cd',1998,'TH','Thailand','economy',154,'Imports:
total value: $1 .4 billion (1 996)
commodities: machinery, transport equipment,
construction materials, food products, consumer
goods
partners: Japan, Singapore, China, Thailand,
Economy— overview: In 1997/98, the Thai
economy is in a deep recession as a result of the
severe financial problems facing many Thai firms,
particularly banks and finance companies. In the early
1990s, Thailand liberalized financial inflows; banks
and other firms borrowed in dollars and did not hedge
their positions because there was no perceived
exchange rate risk. These funds financed a property
boom that began to taper off in the mid-1990s. In
addition, export growth— previously a key driver of the
Thai economy— collapsed in 1996, resulting in
growing doubts that the Bank of Thailand could
maintain the baht''s peg to the dollar. The Bank
mounted an expensive defense of the exchange rate
that nearly depleted foreign exchange reserves, then
decided to float the exchange rate, triggering a sharp
increase in foreign liabilities that cash-strapped Thai
firms were already having trouble repaying. In August
1997, the government headed by Prime Minister
CHAWALIT signed an agreement with the IMF for
access to a $14 billion facility to supplement foreign
exchange reserves and restore financial market
stability. CHAWALIT resigned in November 1997,
however, under pressure for lacking a coherent
approach to managing the IMF program and the
financial crisis. Democratic Party leader CHUAN
Likphai formed a seven-party coalition government
and closely adhered to the IMF program, tentatively
reestablishing financial stability by February 1 998. An
economic turnaround requires rescheduling the large
short-term foreign liabilities of Thai firms, restoring
high rates of export growth to finance foreign liabilities,
and extensively recapitalizing the banking system.
GDP: purchasing power parity— $525 billion (1997
est.)
GDP— real growth rate: -0.4% (1997 est.)
GDP— per capita: purchasing power parity— $8,800
(1997 est.)
GDP— composition by sector:
agriculture: 10%
industry: 28.7%
serv/''ces: 61. 3% (1997)
Inflation rate— consumer price index: 5.6% (1997
est.)
Labor force:
total: 32.6 million (1997 est.)
by occupation: agriculture 54%, industry 15%,
services (including government) 31% (1996 est.)
Unemployment rate: 3.5%
Budget:
revenues: $24 billion
expenditures: $ 25 billion, including capital
expenditures of $8 billion (FY96/97)
Industries: tourism; textiles and garments,
agricultural processing, beverages, tobacco, cement,
light manufacturing, such as jewelry; electric
appliances and components, computers and parts,
integrated circuits, furniture, plastics; world''s
second-largest tungsten producer and third-largest tin
producer
Industrial production growth rate: -15% (1997
est.)
Electricity— capacity: 15.838 million kW (1995)
Electricity— production: 77.5 billion kWh (1995)
Electricity— consumption per capita: 1 ,295 kWh
(1995)
Agriculture— products: rice, cassava (tapioca),
rubber, corn, sugarcane, coconuts, soybeans
Exports:
total value: $ 51.6 billion (f.o.b., 1997)
commodities: manufactures 82%, agricultural
products and fisheries 14% (1997)
partners: US 19.6%, Japan 14.9%, Singapore 11%,
Hong Kong 5.7%, Malaysia 4.3%, UK 3.7% (1997)
Imports:
total value: $73.5 billion (c.i.f., 1996)
commodities: capital goods 50%, consumer goods
10.2%, fuels 8.7% (1997)
partners: Japan 25.6%, US 13.9%, Singapore 5%,
Taiwan 4.6%, Germany 4.5%, Malaysia 4.1% (1997)
Debt— external: $90 billion (1997)
Economic aid:
recipient: ODA, $624 million (1993)
Currency: 1 baht (B) = 100 satang
Exchange rates: baht (B) per US$1— 53.812
(January 1998), 31.364 (1997), 25.343 (1996), 24.915
(1995), 25.150 (1994), 25.319 (1993)
Fiscal year: 1 October— 30 September
Economy— overview: This small sub-Saharan
economy is heavily dependent on both commercial
and subsistence agriculture, which provides
employment for more than 60% of the labor force.
Cocoa, coffee, and cotton together generate about
30% of export earnings. Togo is self-sufficient in basic
foodstuffs when harvests are normal, with occasional
regional supply difficulties. In the industrial sector,
phosphate mining is by far the most important activity,
although it has suffered from the collapse of world
phosphate prices and increased foreign competition.
Togo serves as a regional commercial and trade
center. The government''s decade-long effort,
supported by the World Bank and the IMF, to
implement economic reform measures, encourage
foreign investment, and bring revenues in line with
expenditures has stalled. Political unrest, including
private and public sector strikes throughout 1 992 and
1993, has jeopardized the reform program, shrunk the
tax base, and disrupted vital economic activity. The 1 2
January 1994 devaluation of the currency by 50%
provided an important impetus to renewed structural
adjustment; these efforts were facilitated by the end of
strife in 1994 and a return to overt political calm. The
1998 presidential elections provide an important
opportunity for Togo''s evolving political system to
demonstrate that the country can participate in a
peaceful and effective manner with World Bank and
IMF programs. Progress depends on continuing
privatization, increased transparency in government
accounting to accommodate increased social service
outlays, and possible downsizing of the military, on
which the regime has depended to stay in place.
GDP: purchasing power parity— $6.2 billion (1997
est.)
GDP— real growth rate: 4.8% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,300
(1997 est.)
GDP— composition by sector:
agriculture: 32%
industry : 23%
services: 45% (1995)
Inflation rate— consumer price index: 15.7%
(1995)
Labor force:
total: 1 .538 million (1993 est.)
by occupation: agriculture 65%, industry 5%, services
30% (1997 est.)
Unemployment rate: NA%
Budget:
revenues: $232 million
expenditures: $252 million, including capital
expenditures of $NA (1997 est.)
Industries: phosphate mining, agricultural
processing, cement; handicrafts, textiles, beverages
Industrial production growth rate: 13.6% (1995)
Electricity— capacity: 34,000 kW (1995)
Electricity— production: 90 million kWh (1995)
note: imports electricity from Ghana
Electricity— consumption per capita: 92 kWh
(1995)
463
Togo (continued)
Agriculture— products: coffee, cocoa, cotton,
yams, cassava (tapioca), corn, beans, rice, millet,
sorghum; meat; annual fish catch of 10,000-14,000
tons
Exports:
total value: $ 196 million (f.o.b., 1996)
commodities: cotton, phosphates, coffee, cocoa
partners: Canada 9.2%, US 8.1%, Taiwan 7.5%,
Nigeria 6.7% (1995 est.)
Imports:
total value: $404 million (c.i.f., 1996)
commodities: machinery and equipment, consumer
goods, petroleum products
partners: Ghana 17.1%, China 13.3%, France 12.5%,
Cameroon 6.0% (1995 est.)
Debt— external: $1.4 billion (1995)
Economic aid:
recipient: ODA, $NA
Currency: 1 Communaute Financier Africaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1 —
608.36 (January 1 998), 583.67 (1 997), 51 1 .55 (1 996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 12 January 1994, the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1 948
Fiscal year: calendar year','78bff57cee0df5ddd9a21886cc951c6e346e62eae742975cf9cc45a5826b00c4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd998a677530315176d39ac1a5a2c523bca134620c9d48c10a5e3b63e7f2e1b2',1998,'MY','Malaysia','economy',155,'Debt— external: $5.3 billion (FY94/95 est.)
76
Economic aid:
recipient: ODA, $61 million (1993)
Currency: 1 kyat (K) = 100 pyas
Exchange rates: kyats (K) per US$1— 6.3941
(January 1998) 6.2418 (1997), 5.9176 (1996), 5.6670
(1995), 5.9749 (1994), 6.1570 (1993); unofficial-
310-350 (1998)
Fiscal year: 1 April— 31 March','0d65547ba6c2980b49cf5d57675130b71dc5be9289615583125d9f77570ace4c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b133e8e4e5c354466e8df394c84278cd7b3f80cc229283c67eb64fe7219ca36',1998,'BI','Burundi','economy',164,'Economy— overview: Burundi is a landlocked,
resource-poor country in an early stage of economic
development. The economy is predominately
agricultural with roughly 90% of the population
dependent on subsistence agriculture. Its economic
health depends on the coffee crop, which accounts for
80% of foreign exchange earnings. The ability to pay
for imports therefore rests largely on the vagaries of
the climate and the international coffee market. As
part of its economic reform agenda, launched in
February 1991 with IMF and World Bank support,
Burundi is trying to diversify its agricultural exports,
attract foreign investment in industry, and modernize
government budgetary practices. Since October 1993
the nation has suffered from massive ethnic-based
violence which has resulted in the death of perhaps
100,000 persons and the displacement of a million
others. Foods, medicines, and electricity remain in
short supply. An impoverished and disorganized
government can hardly implement the needed reform
programs.
GDP: purchasing power parity— $4 billion (1 997 est.)
GDP— real growth rate: 4.4% (1997 est.)
GDP— per capita: purchasing power parity— $660
(1997 est.)
GDP— composition by sector:
agriculture: 56%
industry: 18%
services: 26% (1995 est.)
78
Inflation rate-consumer price index: 26% (1996
est.)
Labor force:
total: 1 .9 million
by occupation: agriculture 93.0%, government 4.0%,
industry and commerce 1 .5%, services 1 .5% (1 983
est.)
Unemployment rate: NA%
Budget:
revenues: $222 million
expenditures: % 258 million, including capital
expenditures of $92 million (1995 est.)
Industries: light consumer goods such as blankets,
shoes, soap; assembly of imported components;
public works construction; food processing
Industrial production growth rate: NA%
Electricity— capacity: 43,000 kW (1995)
Electricity— production: 158 million kWh (1995)
note : imports some electricity from Democratic
Republic of the Congo
Electricity— consumption per capita: 32 kWh
(1995)
Agriculture— products: coffee, cotton, tea, corn,
sorghum, sweet potatoes, bananas, manioc (tapioca);
meat, milk, hides
Exports:
total value: $40 million (f.o.b., 1996)
commodities: coffee 81%, tea, cotton, hides
partners: EU 60%, US 7%, Asia 1%
Imports:
total value: $127 million (c.i.f., 1996)
commodities: capital goods 26%, petroleum products,
foodstuffs, consumer goods
partners: EU 47%, Asia 25%, US 6%
Debt— external: $1.1 billion (1995 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Burundi franc (FBu) = 100 centimes
Exchange rates: Burundi francs (FBu) per US$1 —
41 2.59 (January 1 998), 352.35 (1 997), 302.75 (1 996),
249.76 (1995), 252.66 (1994), 242.78 (1993)
Fiscal year: calendar year
Economy — overview: After four years of solid
macroeconomic performance, Cambodia''s economy
slowed dramatically in 1 997 due to the twin shocks of
the regional economic crisis and the July violence and
political infighting. Economic growth fell from 6.5% in
1 996 to 1 .5% in 1 997, foreign investment slowed, and
tourism declined 16% from 1996 levels. Despite these
difficulties, inflation accelerated only slightly to 9.5%;
the government managed to keep the national budget
in balance even with increased expenditures on the
military and police; and the economy ran a small
balance of payments surplus. The future payments
could be adversely affected by the currency crises in
Thailand, Malaysia, and Indonesia, which tends to
make Cambodia''s exports more expensive at the
same time imports from these countries become
cheaper. The long-term development of the economy
after decades of war remains a daunting challenge.
Human resource levels in the population are low,
particularly in the poverty-ridden countryside. The
almost total lack of basic infrastructure in the
countryside will continue to hinder development.
Recurring political instability hinders foreign
investment. Corruption and inexperience among
Cambodia''s government officials will serve as a
further drag on the economy.
GDP: purchasing power parity— $7.7 billion (1997
est.)
GDP— real growth rate: 1.5% (1997 est.)
GDP— per capita: purchasing power parity— $71 5
(1997 est.)
GDP— composition by sector:
agriculture: 47.3%
industry: 15.4%
services: 37.3% (1996 est.)
Inflation rate— consumer price index: 9.5% (1997
est.)
80
Labor force: 2.5 million to 3 million
by occupation : agriculture 80% (1 997 est.)
Unemployment rate: NA%
Budget:
revenues: $261 million
expenditures: $496 million, including capital
expenditures of $NA (1995 est.)
Industries: rice milling, fishing, wood and wood
products, rubber, cement, gem mining, textiles
Industrial production growth rate: 7% (1995 est.)
Electricity— capacity: 35,000 kW (1995)
Electricity— production: 190 million kWh (1995)
Electricity— consumption per capita: 18 kWh
(1995)
Agriculture— products: rice, rubber, corn,
vegetables
Exports:
total value: $615 million (1996 est.)
commodities: timber, garments, rubber, soybeans,
sesame
partners: Singapore, Japan, Thailand, Hong Kong,
Indonesia, Malaysia, US
Imports:
total value: $1 billion (1996 est.)
commodities: cigarettes, construction materials,
petroleum products, machinery, motor vehicles
partners: Singapore, Vietnam, Japan, Australia, Hong
Kong, Indonesia
Debt— external: $2.2 billion (1996 est.)
Economic aid:
recipient: ODA, $NA
note: international donors pledged a total of $1 .8
billion in 1995 and 1996
Currency: 1 new riel (CR) = 100 sen
Exchange rates: riels (CR) per US$1— 3,537.0
(January 1998), 2,946.3 (1997), 2,624.1 (1996),
2,450.8 (1995), 2,545.3 (1994), 2,689.0 (1993)
Fiscal year: calendar year','062ccb55a9d5337888bb418bbd3f65700edd15463857c135d400d2c60f85cc51','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbb589caa742fc85c23e2a6f9b6615f29530ec62ba3c22725f0afe8e08c2cdf9',1998,'CM','Cameroon','economy',171,'Economy— overview: Because of its oil resources
and favorable agricultural conditions, Cameroon has
one of the best-endowed primary commodity
economies in sub-Saharan Africa. Still, it faces many
of the serious problems facing other underdeveloped
countries, such as a top-heavy civil service and a
generally unfavorable climate for business enterprise.
The development of the oil sector led to rapid
economic growth between 1970 and 1985. Growth
came to an abrupt halt in 1986, precipitated by steep
declines in the prices of major exports: petroleum,
coffee, and cocoa. Export earnings were cut by almost
one-third, and inefficiencies in fiscal management
were exposed. Since 1990, the government has
embarked on various IMF and World Bank programs
designed to spur business investment, increase
efficiency in agriculture, improve trade, and
recapitalize the nation''s banks. The government,
however, failed to press forward vigorously with these
programs. The latest enhanced structural adjustment
agreement was signed in October 1997; the parties
hope this will prove more successful, yet government
mismanagement remains a problem. Inflation, which
rose to 48% after the devaluation of 1994, has been
brought back under control. Progress toward
privatization of remaining state industry remains slow.
President BIYA''s new government of December 1 997
has replaced old hands in the government economic
control structure with promising technocrats.
GDP: purchasing power parity— $30.9 billion (1997
est.)
GDP— real growth rate: 5% (1997 est.)
82
GDP— per capita: purchasing power parity— $2,1 00
(1997 est.)
GDP— composition by sector:
agriculture: 32%
industry: 27%
services: 41% (1995 est.)
Inflation rate— consumer price index: 3% (1997
est.)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $2.23 billion
expenditures: $2.23 billion, including capital
expenditures of $NA (FY96/97 est.)
Industries: petroleum production and refining, food
processing, light consumer goods, textiles, lumber
Industrial production growth rate: NA%
Electricity— capacity: 627,000 kW (1995)
Electricity— production: 2.715 billion kWh (1995)
Electricity— consumption per capita: 201 kWh
(1995)
Agriculture— products: coffee, cocoa, cotton,
rubber, bananas, oilseed, grains, root starches;
livestock; timber
Exports:
total value: $ 1.9 billion (f.o.b., 1996)
commodities: crude oil and petroleum products,
lumber, cocoa beans, aluminum, coffee, cotton
partners: EU (particularly France, Italy, and Spain)
about 60%, African countries, Korea, Taiwan, and','690ad8ab312cb1bfccfa7fd993eea16efbf9fb6b0a0c70e134136d34bcc85433','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10f498aefb3af86a93691baa02a8b78b948bee60318e850d3911a287e5de69f4',1998,'CN','China','economy',172,'Imports:
total value: $1 .5 billion (f.o.b., 1 996)
commodities : machines and electrical equipment,
food, consumer goods, transport equipment,
petroleum products
partners: EU (France 40%), African countries, US 7%
Debt— external: $10 billion (1996 est.)
Economic aid: France signed two loan agreements
totaling $55 million in September 1997 and the Paris
Club agreed in October 1997 to reduce the official
debt by 50% and to reschedule it on favorable terms
with a consolidation of payments due through 2000
Currency: 1 CommunauteFinanciereAfricaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1—
608.36 (January 1 998), 583.67 (1997), 51 1 .55 (1996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 12 January 1994, the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: 1 July— 30 June
| Co rri m u n i c at to ns
Telephones: 36,737(1991 est.)
Telephone system: available only to business and
Imports:
total value : $6 billion (1996)
commodities : machinery and parts, industrial
materials, oil and gas
partners: Russia, Ukraine, Uzbekistan, Turkey,
Debt— external: $9.6 billion (including $2.1 billion to
Russia) (yearend 1997 est.)
Economic aid:
recipient: ODA, $220 million (1993)
note: commitments, 1992-95, $4.5 billion ($4.1 billion
drawn)
Currency: on 2 September 1 996, Ukraine introduced
the long-awaited hryvnia as its national currency,
replacing the karbovanets (in circulation since 12
November 1 992) at a rate of 1 00,000 karbovantsi to 1
hryvnia
Exchange rates: hryvnia per US$1 — 1 .9359
(February 1998), 1.8617 (1997), 1.8295 (1996),
1.4731 (1995), 0.3275 (1994), 0.0453 (1993)
Fiscal year: calendar year','d970fd887b4522866bc60fa856540ab78cdf98473a2b93554861d265a8814b46','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('533869b8546c1f9e701c75be912d19512b552cc052cf8f4270703bbf3b7df5de',1998,'CA','Canada','economy',180,'Economy— overview: As an affluent, high-tech
industrial society, Canada today closely resembles
the US in its market-oriented economic system,
pattern of production, and high living standards. Since
World War II, the impressive growth of the
manufacturing, mining, and service sectors has
transformed the nation from a largely rural economy
into one primarily industrial and urban. Canada
started the 1990s in recession, and real rates of
growth have averaged only 1 .1% so far this decade.
Because of slower growth, Canada still faces high
unemployment— especially in Quebec and the
Maritime Provinces— and a large public sector debt.
With its great natural resources, skilled labor force,
and modern capital plant, however, Canada will enjoy
better economic prospects in the future. The
continuing constitutional impasse between English-
and French-speaking areas is raising the possibility of
a split in the federation, making foreign investors
somewhat edgy.
GDP: purchasing power parity— $658 billion (1997
est.)
GDP— real growth rate: 3.5% (1997 est.)
GDP— per capita: purchasing power parity —
$21,700 (1997 est.)
GDP— composition by sector:
agriculture: 3%
industry: 31%
services: 66% (1997)
Inflation rate— consumer price index: 1 .8%
(1997)
Labor force:
total: 15.3 million (1997)
by occupation: services 75%, manufacturing 16%,
agriculture 3%, construction 5%, other 1% (1997)
Unemployment rate: 8.6% (December 1997)
Budget:
revenues: $106.5 billion
expenditures : $1 17.2 billion, including capital
expenditures of $1 .7 billion (1 996)
Industries: processed and unprocessed minerals,
food products, wood and paper products,
transportation equipment, chemicals, fish products,
petroleum and natural gas
Industrial production growth rate: 1.7% (1997
est.)
Electricity— capacity: 1 1 3.645 million kW (1 995)
Electricity— production: 532.64 billion kWh (1995)
Electricity— consumption per capita: 17,448 kWh
(1995)
Agriculture— products: wheat, barley, oilseed,
tobacco, fruits, vegetables; dairy products; forest
products; commercial fisheries provide annua! catch
of 1 .5 million metric tons, of which 75% is exported
Exports:
total value: $208.6 billion (f.o.b., 1997)
commodities: newsprint, wood pulp, timber, crude
petroleum, machinery, natural gas, aluminum, motor
vehicles and parts; telecommunications equipment
partners: US, Japan, UK, Germany, South Korea,
Netherlands, China
Imports:
total value: $194.4 billion (c.i.f., 1997)
commodities: crude oil, chemicals, motor vehicles and
parts, durable consumer goods, computers;
telecommunications equipment and parts
partners: US, Japan, UK, Germany, France, Mexico,
Taiwan, South Korea
Debt— external: $253 billion (1996)
Economic aid:
donor: ODA, $1 .6 billion (1995)
note: ODA and OOF commitments, $10.1 billion
(1986-91)
Currency: 1 Canadian dollar (Can$) = 100 cents
Exchange rates: Canadian dollars (Can$) per
US$1— 1.4408 (January 1998), 1.3846 (1997),
1 .3635 (1 996), 1 .37241 (1 995), 1 .3656 (1 994), 1 .2901
(1993)
Fiscal year: 1 April— 31 March
Debt— external: $26.5 billion (1996)
Economic aid:
recipient: ODA, $46 million (1993)
Currency: 1 bolivar (Bs) = 100 centimos
Exchange rates: bolivares (Bs) per US$1— 507.447
(January 1998), 488.635 (1997), 417.333 (1996),
176.843 (1995), 148.503 (1994), 90.826 (1993)
Fiscal year: calendar year','d07e62e97b71d0929dfcc862add97d5888363eaf1f02db3f348656ebf8037d52','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8689b768d8aa4346d06115ae1270c544f0819f70d7088e149d07cc126705dbcc',1998,'PT','Portugal','economy',185,'Economy— overview: Cape Verde''s low per capita
GDP reflects a poor natural resource base, serious
water shortages exacerbated by cycles of long-term
drought, and a high birthrate. The economy is service
oriented, with commerce, transport, and public
services accounting for almost 70% of GDP. Although
nearly 70% of the population lives in rural areas, the
share of agriculture in GDP in 1995 was only 8%, of
which fishing accounts for 1 .5%. About 90% of food
must be imported. The fishing potential, mostly lobster
and tuna, is not fully exploited. Cape Verde annually
runs a high trade deficit, financed by foreign aid and
remittances from emigrants; remittances constitute a
supplement to GDP of more than 20%. Economic
reforms, launched by the new democratic government
in 1991, are aimed at developing the private sector
and attracting foreign investment to diversify the
economy. Prospects for 1998 depend heavily on the
maintenance of aid flows, remittances, and the
momentum of the government''s development
program.
GDP: purchasing power parity— $538 million (1997
est.)
GDP— real growth rate: 4.5% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,370
(1997 est.)
GDP— composition by sector:
agriculture: 8%
industry: 18%
se/v/ces:74%(1996 est.)
Inflation rate— consumer price index: 6.2%
(1996)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $188 million
expenditures: $ 228 million, including capital
expenditures of $1 1 6 million (1 996)
Industries: food and beverages, fish processing,
shoes and garments, salt mining, ship repair,
Industrial production growth rate: NA%
Electricity— capacity: 7,000 kW (1995)
87
Cape Verde (continued)
Electricity— production: 40 million kWh (1995)
Electricity— consumption per capita: 92 kWh
(1995)
Agriculture— products: bananas, corn, beans,
sweet potatoes, sugarcane, coffee, peanuts; fish
Exports:
total value : $12.8 million (f.o.b., 1996 est.)
commodities: shoes, garments, fish, bananas, hides,
partners: Portugal, Spain, France, UK
Imports:
total value: $237 million (f.o.b., 1996 est.)
commodities: foodstuffs, consumer goods, industrial
products, transport equipment, fuels
partners: Portugal 41%, Netherlands, France, Spain,
US
Debt— external: $202 million (1996)
Economic aid:
recipient: ODA, $70 million (1995)
Currency: 1 Cape Verdean escudo (CVEsc) = 100
centavos
Exchange rates: Cape Verdean escudos (CVEsc)
per US$1— 95.400 (December 1997), 93.177 (1997),
82.591 (1996), 76.853 (1995), 81.891 (1994), 80.427
(1993)
Fiscal year: calendar year
Economy— overview: The Former Yugoslav
Republic of Macedonia, although the poorest republic
in the former Yugoslav federation, can meet basic
food and energy needs through its own agricultural
and coal resources. The economy slowly rebounded
in 1 996-97 after years of recession. Continued
recovery depends on Macedonia''s ability to attract
investment, to redevelop trade ties with Greece and
Serbia and Montenegro, and to maintain its
commitment to economic liberalization. The economy
depends on outside sources for all of its oil and gas
and most of its modern machinery and parts. An
important supplement of GDP is the remittances from
thousands of Macedonians working in Germany and
other West European nations.
GDP: purchasing power parity— $2 billion (1 997 est.)
GDP— real growth rate: 1 .5% (1997 est.)
GDP— per capita: purchasing power parity— $960
(1997 est.)
GDP— composition by sector:
agriculture: 20.4%
industry: 38.6%
services: 41% (1995 est.)
Inflation rate— consumer price index: 3.5% (1997
est.)
Labor force:
fofa/; 591 ,773 (June 1994)
by occupation: manufacturing and mining 40% (1 992)
285
Macedonia, The Former Yugoslav Republic of (continued)
Unemployment rate: 30% (1997 est.); note— many
employed workers are, in fact, furloughees
Budget:
revenues: $1 .06 billion
expenditures: $1 billion, including capital
expenditures of $107 million (1996 est.)
Industries: coal, metallic chromium, lead, zinc,
ferronickel, textiles, wood products, tobacco
Industrial production growth rate: 3.4% (1997
est.)
Electricity— capacity: 1.366 million kW (1995)
Electricity— production: 5.4 billion kWh (1995)
Electricity— consumption per capita: 2,584 kWh
(1995)
Agriculture— products: rice, tobacco, wheat, corn,
millet, cotton, sesame, mulberry leaves, citrus,
vegetables; beef, pork, poultry, mutton
Exports:
total value: $1 .2 billion (f.o.b., 1996)
commodities: food, beverage, tobacco 17.0%,
machinery and transport equipment 13.3%, other
manufactured goods 58%
partners: Bulgaria, other former Yugoslav republics,
Germany, Italy
Imports:
total value: $1 .6 billion (c.i.f., 1 996)
commodities: machinery and equipment 19%,
chemicals 14%, fuels 12%
partners: other former Yugoslav republics, Germany,
Bulgaria, Italy, Austria
Debt— external: $1.06 billion (June 1997)
Economic aid:
recipient: ODA, $NA
note: US, $10 million (for humanitarian and technical
assistance); in December 1995, the EU agreed to
provide a credit line of ECU 21 .7 million for investment
projects
Currency: 1 Macedonian denar (MKD) = 100 deni
Exchange rates: denar per US$1— 31 (July 1997),
40.5 (September 1996), 38.8 (December 1995), 39
(November 1994), 865 (October 1992)
Fiscal year: calendar year
Economy— overview: Madagascar suffers from
chronic malnutrition, underfunded health and
education facilities, a roughly 3% annual population
growth rate, and severe loss of forest cover,
accompanied by erosion. Agriculture, including fishing
and forestry, is the mainstay of the economy,
accounting for 33% of GDP and contributing more
287
Madagascar (continued)
than 70% to export earnings. Industry features textile
manufacturing and the processing of agricultural
products. Growth in output in 1992-97 averaged less
than the growth rate of the population. Growth has
been held back by antigovernment strikes and
demonstrations, a decline in world coffee demand,
and the erratic commitment of the government to
economic reform. Formidable obstacles stand in the
way of Madagascar''s realizing its considerable growth
potential; the extent of government reforms, outside
financial aid, and foreign investment will be key
determinants.
GDP: purchasing power parity— $10.3 billion (1997
est.)
GDP— real growth rate: 3% (1997 est.)
GDP— per capita: purchasing power parity— $730
(1997 est.)
GDP— composition by sector:
agriculture: 33%
industry: 15%
services: 52% (1996 est.)
Inflation rate— consumer price index: 19.8%
(1996)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $477 million
expenditures: $706 million, including capital
expenditures of $264 million (1996 est.)
Industries: meat processing, soap, breweries,
tanneries, sugar, textiles, glassware, cement,
automobile assembly plant, paper, petroleum, tourism
Industrial production growth rate: 3.8% (1993
est.)
Electricity— capacity: 220,000 kW (1995)
Electricity— production: 595 million kWh (1995)
Electricity— consumption per capita: 43 kWh
(1995)
Agriculture— products: coffee, vanilla, sugarcane,
cloves, cocoa, rice, cassava (tapioca), beans,
bananas, peanuts; livestock products
Exports:
total value: $493 million (f.o.b., 1996 est.)
commodities: coffee 45%, vanilla 20%, cloves,
shellfish, sugar, petroleum products (1995 est.)
partners: France 41%, US, Japan, Italy (1995)
Imports:
total value: $612 million (f.o.b., 1996 est.)
commodities: intermediate manufactures 30%, capital
goods 28%, petroleum 15%, consumer goods 14%,
food 13% (1995 est.)
partners: France 40%, Japan, Hong Kong, Singapore,
US (1995)
Debt— external: $4.4 billion (1996 est.)
Economic aid:
recipient: ODA, $454 million (1992-96)
Currency: 1 Malagasy franc (FMG) = 100 centimes
Exchange rates: Malagasy francs (FMG) per
US$1 — 5,302.9 (December 1997), 5,090.9 (1997),
4,061 .3 (1 996), 4,265.6 (1 995), 3,067.3 (1 994),
1,913.8 (1993)
Fiscal year: calendar year','9c1b43b08c6b5e64de8954d241b290358b230fd6a1c449cea072aea96f418a1c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98bcb235dbab0e4273625e41d1c7b64470066ab7bdd9c9d1886e03d1d4c90ddf',1998,'HN','Honduras','economy',195,'Economy— overview: With no direct taxation, the
Islands are a thriving offshore financial center; 28,000
foreign companies do business with the 600
registered banks and trust companies; banking assets
exceed $500 billion. Tourism is also a mainstay,
accounting for about 70% of GDP and 75% of foreign
currency earnings. The tourist industry is aimed at the
luxury market and caters mainly to visitors from North
America. Total tourist arrivals exceeded 1 million
visitors in 1995 and again in 1996. About 90% of the
islands1 food and consumer goods must be imported.
The Caymanians enjoy one of the highest outputs per
capita and one of the highest standards of living in the
world.
GDP: purchasing power parity— $860 million (1996
est.)
GDP— real growth rate: 4.5% (1996 est.)
GDP— per capita: purchasing power parity —
$23,800 (1996 est.)
GDP— composition by sector:
agriculture: 1 .4%
industry: 3.2%
services: 95.4% (1 994 est.)
Inflation rate— consumer price index: 2.1% (1996
est.)
Labor force:
total: 8,061
by occupation: service workers 18.7%, clerical 18.6%,
construction 12.5%, finance and investment 6.7%,
directors and business managers 5.9% (1979)
Unemployment rate: 7% (1992)
Budget:
revenues: $141 .5 million
expenditures: $160.7 million, including capital
expenditures of $NA (1991)
Industries: tourism, banking, insurance and finance,
construction, construction materials, furniture
Industrial production growth rate: NA%
Electricity— capacity: 75,000 kW (1995)
Electricity— production: 230 million kWh (1995)
Electricity— consumption per capita: 6,929 kWh
(1995)
Agriculture— products: vegetables, fruit; livestock;
turtle farming
Exports:
total value: $3 A million (f.o.b., 1995 est.)
commodities: turtle products, manufactured
consumer goods
partners: mostly US
Imports:
total value: $333 million (c.i.f., 1995 est.)
commodities: foodstuffs, manufactured goods
partners: US, Trinidad and Tobago, UK, Netherlands
Antilles, Japan
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
Currency: 1 Caymanian dollar (Cl$) = 100 cents
Exchange rates: Caymanian dollars (Cl$) per
US$1— 0.83 (3 November 1995), 0.85 (22 November
1993)
Fiscal year: 1 April— 31 March
Economy— overview: Subsistence agriculture,
together with forestry, remains the backbone of the
economy of the Central African Republic (CAR), with
more than 70% of the population living in outlying
areas. The agricultural sector generates half of GDP.
Timber has accounted for about 16% of export
earnings and the diamond industry for nearly 54%.
Important constraints to economic development
include the CAR''s landlocked position, a poor
transportation system, a largely unskilled work force,
and a legacy of misdirected macroeconomic policies.
The 50% devaluation of the currencies of 14
Francophone African nations on 1 2 January 1 994 had
mixed effects on the CAR''s economy. Diamond,
timber, coffee, and cotton exports increased, leading
an estimated rise of GDP of 7% in 1 994 and nearly 5%
in 1995. Military rebellions and social unrest in 1996
were accompanied by widespread destruction of
property and a drop in GDP of 1%. Ongoing violence
between the government and rebel military groups
over pay issues, living conditions, and political
representation has destroyed many businesses in the
capital, reduced tax revenues for the government, and
delayed negotiations for an IMF financial aid
agreement.
GDP: purchasing power parity— $3.3 billion
(1997 est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $1 ,000
(1997 est.)
GDP— composition by sector:
agriculture: 50%
industry: 14%
services: 36% (1 994 est.)
Inflation rate— consumer price index: 4%
(1996 est.)
Labor force: NA
Unemployment rate: 6% (1993)
Budget:
revenues: $638 million
expenditures: $1.9 billion, including capital
expenditures of $888 million (1994 est.)
Industries: diamond mining, sawmills, breweries,
textiles, footwear, assembly of bicycles and
motorcycles
Industrial production growth rate: NA%
Electricity— capacity: 43,000 kW (1995)
Electricity— production: 100 million kWh (1995)
Electricity— consumption per capita: 31 kWh
(1995)
Agriculture— products: cotton, coffee, tobacco,
manioc (tapioca), yams, millet, corn, bananas; timber
Exports:
total value: $ 171 million (f.o.b., 1995)
commodities: diamonds, timber, cotton, coffee,
tobacco
partners: France 16%, Belgium-Luxembourg 40.1%,
Italy, Japan, US, Spain, Iran, Democratic Republic of
the Congo, Republic of the Congo
Imports:
total value: $174 million (f.o.b., 1995)
commodities: food, textiles, petroleum products,
machinery, electrical equipment, motor vehicles,
chemicals, pharmaceuticals, consumer goods,
industrial products
partners: France 37%, other EU countries, Japan
24%, Algeria, Cameroon, Namibia
Debt— external: $890 million (1994 est.)
Economic aid:
recipient: ODA, $NA; traditional budget subsidies
from France
Currency: 1 CommunauteFinanciereAfricaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1 —
608.36 (January 1998), 583.67 (1997), 51 1 .55 (1996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note : beginning 12 January 1994, the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: calendar year
Imports:
total value: $3.5 billion (c.i.f., 1997 est.)
commodities: raw materials, consumer goods, capital
goods, fuels
partners: US, Guatemala, Mexico, Panama,
Venezuela, Japan
Debt— external: $2.6 billion (yearend 1997)
Economic aid:
recipient: ODA, $763 million (1996)
note : US has committed $280 million in economic
assistance to El Salvador for 1995-97 (excludes
military aid)
Currency: 1 Salvadoran colon (C) = 100 centavos
Exchange rates: Salvadoran colones (C) per US$1
(end of period)— 8.755 (January 1998-1995), 8.750
(1994), 8.670(1993)
note: as of 1 June 1990, the rate is based on the
average of the buying and selling rates, set on a
weekly basis, for official receipts and payments,
imports of petroleum, and coffee exports; prior to that
date, a system of floating was in effect
Fiscal year: calendar year
Economy— overview: In 1994 the REINA
administration inherited an economy in the grips of
stagflation due to an unprecedented energy crisis,
declining agricultural output, and extravagant public
expenditures. In response the REINA administration
cut the fiscal deficit and enacted a number of
structural reforms including passage of a modern
financial sector reform law in 1995 and a centra! bank
reform law in 1996. As a result, Honduras finished
1997 with improved GDP growth and a decreasing
rate of inflation. The newly elected FLORES
administration faces pressure from the international
financial community and the IMF to further decrease
the fiscal deficit and implement key reforms, including
the privatization of state enterprises such as
Hondutel. Tegucigalpa will probably implement tighter
fiscal and monetary policies to keep inflation low and
meet commitments to the IMF. This may slow GDP
growth to 3.5% in 1 998. Moreover, wage increases for
public-sector employees, agreed to in 1 997, will make
it difficult for FLORES to make headway on the fiscal
deficit and inflation.
GDP: purchasing power parity— $12.7 billion
(1997 est.)
GDP— real growth rate: 4.5% (1997 est.)
GDP— per capita: purchasing power parity— $2,200
(1997 est.)
GDP— composition by sector:
agriculture: 20%
industry: 19%
services: 61% (1997)
Inflation rate— consumer price index: 15%
(1997 est.)
Labor force:
total: 1 .3 million (1997 est.)
by occupation: agriculture 62%, services 20%,
manufacturing 9%, construction 3%, other 6% (1985)
Unemployment rate: 6.3% (1997); underemployed
30% (1997 est.)
Budget:
revenues: $655 million
expenditures: $850 million, including capital
expenditures of $150 million (1997 est.)
Industries: sugar, coffee, textiles, clothing, wood
products
Industrial production growth rate: 10%
(1992 est.)
Electricity— capacity: 305,000 kW (1995)
Electricity— production: 2.8 billion kWh (1995)
Electricity— consumption per capita: 516 kWh
(1995)
Agriculture— products: bananas, coffee, citrus;
beef; timber; shrimp;
Exports:
total value: $1 .3 billion (f.o.b., 1996)
commodities: bananas, coffee, shrimp, lobster,
minerals, meat, lumber
partners : US 54%, Germany 7%, Belgium 5%, Japan
4%, Spain 3% (1995)
Imports:
total value: $1 .8 billion (c.i.f. 1996)
commodities : machinery and transport equipment,
industrial raw materials, chemical products,
manufactured goods, fuel and oil, foodstuffs
partners: US 43%, Guatemala 5%, Japan 5%,
Germany 4%, Mexico 3%, El Salvador 3% (1995)
Debt— external: $4.1 billion (1995)
Economic aid:
recipient: ODA, $NA
Currency: 1 lempira (L) = 100 centavos
Exchange rates: lempiras (L) per US$1 (end of
period) — 13.1332 (January 1998), 13.0942 (1997),
12.8694 (1996), 10.3432 (1995), 9.4001 (1994),
7.2600 (1993)
Fiscal year: calendar year
Economy— overview: Hong Kong has a bustling
free market economy highly dependent on
international trade. Natural resources are limited, and
food and raw materials must be imported. Indeed,
imports and exports, including reexports, each exceed
GDP in dollar value. Real GDP growth averaged a
remarkable 8% in 1987-88, slowed to 3.0% in
1989-90, and picked up to 4.2% in 1991, 5.0% in
1 992, 5.2% in 1 993, 5.5% in 1 994, 4.8% in 1 995, 4.7%
in 1 996, and an estimated 5.5% in 1 997. A shortage of
labor continues to put upward pressure on prices and
the cost of living. Even before Hong Kong reverted to
Chinese administration on 1 July 1997 it had
extensive trade and investment ties with China.
GDP: purchasing power parity— $175.2 billion
(1997 est.)
GDP— real growth rate: 5.5% (1997 est.)
GDP— per capita: purchasing power parity —
$26,800 (1997 est.)
GDP— composition by sector:
agriculture: 0.1%
industry: 16.1%
services: 83.8% (1996 est.)
Inflation rate— consumer price index: 5.1%
(1997 est.)
Labor force:
total: 3.1 83 million (1997)
by occupation: wholesale and retail trade,
restaurants, and hotels 32.4%, social services 9.9%,
manufacturing 9.9%, financing, insurance, and real
estate 13.0%, transport and communications 5.7%,
construction 2.6%, other 26.5% (June 1997)
Unemployment rate: 3.1% (1996 est.)
Budget:
revenues; $19 billion
expenditures: $14 A billion, including capital
expenditures of $289 million (FY95/96 est.)
Industries: textiles, clothing, tourism, electronics,
plastics, toys, watches, clocks
Industrial production growth rate: -3.2% (1997
est.)
Electricity— capacity: 1 1 .3 million kW (1 996)
Electricity— production: 28 billion kWh (1996)
Electricity— consumption per capita: 3,968 kWh
(1995)
Agriculture— products: fresh vegetables; poultry
Exports:
total value: $180.7 billion (including reexports; f.o.b.,
1996)
commodities: clothing, textiles, yarn and fabric,
footwear, electrical appliances, watches and clocks,
toys
partners: China 34%, US 21%, Japan 7%, Germany
4%, UK 3% (1996)
Imports:
total value: $198.6 billion (c.i.f., 1996)
commodities: foodstuffs, transport equipment, raw
materials, semimanufactures, petroleum; a large
share is reexported
partners: China 37%, Japan 14%, Taiwan 8%,
US 8%, Singapore 5% (1996)
Debt— external: none (1996)
Economic aid: $NA
Currency: 1 Hong Kong dollar (HK$) = 100 cents
Exchange rates: Hong Kong dollars (HK$) per
US$— 7.74 (1997), 7.730 (1996), 7.800 (1995), 7.800
(1994), 7.800 (1993), 7.741 (1992); note— linked to
the US dollar at the rate of about 7.8 HK$ per 1 US$
Fiscal year: 1 April— 31 March
Economy— overview: Niger is a poor, landlocked
Sub-Saharan nation, whose economy centers on
subsistence agriculture, animal husbandry, reexport
trade, and increasingly less on uranium, its major
export since the 1970s. Terms of trade with Nigeria,
Niger''s largest regional trade partner, have improved
dramatically since the 50% devaluation of the West
African franc in January 1994; this devaluation
boosted exports of livestock, cowpeas, onions, and
the products of Niger''s small cotton industry. The
government relies on bilateral and multilateral aid for
operating expenses and public investment and is
strongly induced to adhere to structural adjustment
programs designed by the IMF and the World Bank.
The US terminated bilateral assistance to Niger after
the coup of 1996. Other donors have reduced their
aid.
GDP: purchasing power parity— $6.3 billion (1997
est.)
GDP— real growth rate: 4.5% (1997 est.)
GDP— per capita: purchasing power parity— $670
(1997 est.)
GDP— composition by sector:
agriculture: 41%
industry: 18%
sen/ices: 41% (1996)
Inflation rate— consumer price index: 5.3%
(1996)
Labor force:
total: 70,000 receive regular wages or salaries
by occupation: agriculture 90%, industry and
commerce 6%, government 4%
Unemployment rate: NA%
Budget:
revenues: $370 million (including $160 million from
foreign sources)
expenditures: $370 million, including capital
expenditures of $186 million (1998 est.)
Industries: cement, brick, textiles, food processing,
chemicals, slaughterhouses, and a few other small
light industries; uranium mining
Industrial production growth rate: 0.5% (1994
est.)
Electricity— capacity: 63,000 kW (1995)
Electricity— production: 170 million kWh (1995)
note: imports about 200 million kWh of electricity from','3b387d81e9148503435730c3af0f002061dd57eeaced189efda6af239f7ae550','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc703064e66e26990f5ac481fc69ba30f36b7ae8fe9a4508f0e384681eb45929',1998,'TD','Chad','economy',204,'Economy— overview: Landlocked Chad''s
economic development suffers from it''s geographic
remoteness, drought, lack of infrastructure, and
political turmoil. About 85% of the population depends
on agriculture, including the herding of livestock. Of
Africa''s Francophone countries, Chad benefited least
from the 50% devaluation of their currencies in
January 1994. Financial aid from the World Bank, the
African Development Fund, and other sources is
directed largely at the improvement of agriculture,
especially livestock production. Lack of financing,
however, is stalling the development of a southern oil
field and the construction of a proposed oil pipeline
through Cameroon.
GDP: purchasing power parity— $4.3 billion
(1997 est.)
GDP— real growth rate: 5.5% (1997 est.)
GDP— per capita: purchasing power parity— $600
(1997 est.)
GDP— composition by sector:
agriculture: 48%
industry: 18%
services: 34% (1995)
Inflation rate— consumer price index: 15%
(1997 est.)
Labor force: NA
by occupation : agriculture 85% (subsistence farming,
herding, and fishing)
Unemployment rate: NA%
Budget:
revenues; $198 million
expenditures: $21 8 million, including capital
expenditures of $146 million (1998 est.)
Industries: cotton textiles, meat packing, beer
brewing, natron (sodium carbonate), soap, cigarettes,
construction materials
Industrial production growth rate: 5% (1995)
Electricity— capacity: 29,000 kW (1995)
Electricity— production: 80 million kWh (1995)
Electricity— consumption per capita: 14 kWh
(1995)
Agriculture— products: cotton, sorghum, millet,
peanuts, rice, potatoes, manioc (tapioca); cattle,
sheep, goats, camels
Exports:
total value: $259 million (f.o.b., 1996 est.)
commodities: cotton, cattle, textiles
partners : Portugal 30%, Germany 18%, South Africa
16%, France 7%
Imports:
total value: $301 million (f.o.b., 1996 est.)
commodities: machinery and transportation
equipment 39%, industrial goods 20%, petroleum
products 1 3%, foodstuffs 9%; textiles; note— excludes
military equipment
93
Chad (continued)
partners: France 34%, Cameroon 24%, Nigeria 7%,
US 6%
Debt— external: $875 million (1995 est.)
Economic aid:
recipient: $125 million committed by Taiwan (August
1997); $30 million committed by African Development
Bank
Currency: 1 CommunauteFinanciereAfricaine franc
(CFAF) = 100 centimes
Exchange rates: CFA Francs (CFAF) per US$1 —
608.36 (January 1 998), 583.67 (1997), 51 1 .55 (1 996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 12 January 1994 the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: calendar year','35518e71e789cb7631026ea39da9f3114d6dda89ba4a1a1670c50bdbef3138cd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd0e24cea308df2e7252ce2c6ed8dc010cbb38ae2af8f5f25050e1335189c65e',1998,'CL','Chile','economy',211,'Economy— overview: Chile has a prosperous,
essentially free market economy. Civilian
governments— which took over from the military in
March 1990— have continued to reduce the
government''s role in the economy while shifting the
emphasis of public spending toward social programs.
Growth in real GDP averaged more than 7.0% in
1991-1997, and inflation is nearing a 40-year low.
Chile''s currency and foreign reserves also are strong,
as sustained foreign capital inflows— including
significant direct investment— have more than offset
current account deficits and public debt buybacks.
President FREI, who took office in March 1994, has
placed improving Chile''s education system and
developing foreign export markets at the top of his
economic agenda. Despite this progress, the Chilean
economy remains largely dependent on a few
sectors— particularly copper mining, fishing, and
forestry. Success in meeting the government''s goal of
sustained annual economic growth of 5% depends
largely on world prices for these commodities,
continued foreign investor confidence, and the
government''s ability to maintain a conservative fiscal
stance. In 1996, Chile became an associate member
of Mercosur and concluded a Free Trade Agreement
with Canada.
GDP: purchasing power parity— $168.5 billion
(1997 est.)
GDP— real growth rate: 7.1% (1997 est.)
GDP— per capita: purchasing power parity —
$11,600 (1997 est.)
GDP— composition by sector:
agriculture: 8%
industry: 33%
services: 59% (1995 est.)
Inflation rate— consumer price index: 6% (1997)
Labor force:
total: 5.7 million (1997 est.)
by occupation: services 38.3% (includes government
12%), industry and commerce 33.8%, agriculture,
forestry, and fishing 1 9.2%, mining 2.3%, construction
6.4% (1990)
Unemployment rate: 6.1% (1997)
Budget:
revenues: $17 billion
expenditures: billion, including capital
expenditures of $NA (1 996 est.)
Industries: copper, other minerals, foodstuffs, fish
processing, iron and steel, wood and wood products,
transport equipment, cement, textiles
Industrial production growth rate: 4.2% (1997)
Electricity— capacity: 5.504 million kW (1995)
Electricity— production: 24.5 billion kWh (1995)
Electricity— consumption per capita: 1 ,730 kWh
(1995)
Agriculture— products: wheat, corn, grapes,
beans, sugar beets, potatoes, fruit; beef, poultry,
wool; timber; 1991 fish catch of 6.6 million metric tons
Exports:
total value: $16.9 billion (f.o.b., 1997)
commodities: copper 37%, other metals and minerals
8.2%, wood products 7.1%, fish and fishmeal 9.8%,
fruits 8.4% (1994)
partners: EU 25%, US 15%, Asia 34%, Latin America
20% (1995 est.)
Imports:
total value: $18.2 billion (f.o.b., 1997)
commodities: capital goods 25.2%, spare parts
24.8%, raw materials 15.4%, petroleum 10%,
foodstuffs 5.7% (1994)
partners: EU 18%, US 25%, Asia 16%, Latin America
26% (1995 est.)
Debt— external: $26.7 billion (1997 est.)
Economic aid:
recipient: ODA, $50.3 million (1996 est.)
Currency: 1 Chilean peso (Ch$) = 100 centavos
Exchange rates: Chilean pesos (Ch$) per US$1 —
452.60 (January 1 998), 41 9.30 (1 997), 41 2.27 (1 996),
396.78 (1995), 420.08 (1994), 404.35 (1993)
Fiscal year: calendar year','f3480b9302ad862a5388cea1ff37959afe326d599d4eb20212373ecd8606130c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9c4f55520941b645654e09e3d799ac7a3f96cdc48636ffd2bd32b4b56aa0b43',1998,'HK','Hong Kong','economy',218,'Economy— overview: Beginning in late 1978 the
Chinese leadership has been trying to move the
economy from a sluggish Soviet-style centrally
planned economy to a more market-oriented
economy but still within a rigid political framework of
Communist Party control. To this end the authorities
switched to a system of household responsibility in
agriculture in place of the old collectivization,
increased the authority of local officials and plant
managers in industry, permitted a wide variety of
small-scale enterprise in services and light
manufacturing, and opened the economy to increased
foreign trade and investment. The result has been a
quadrupling of GDP since 1978. Agricultural output
doubled in the 1980s, and industry also posted major
gains, especially in coastal areas near Hong Kong and
opposite Taiwan, where foreign investment helped
spur output of both domestic and export goods. On the
darker side, the leadership has often experienced in
its hybrid system the worst results of socialism
(bureaucracy, lassitude, corruption) and of capitalism
(windfall gains and stepped-up inflation). Beijing thus
has periodically backtracked, retightening central
controls at intervals. In 1 992-97 annual growth of GDP
accelerated, particularly in the coastal areas—
averaging about 10% annually according to official
figures. In late 1993 China''s leadership approved
additional long-term reforms aimed at giving still more
play to market-oriented institutions and at
strengthening the center''s control over the financial
system; state enterprises would continue to dominate
many key industries in what was now termed "a
socialist market economy." In 1995-97 inflation
dropped sharply, reflecting tighter monetary policies
and stronger measures to control food prices. At the
same time, the government struggled to (a) collect
revenues due from provinces, businesses, and
individuals; (b) reduce corruption and other economic
crimes; and (c) keep afloat the large state-owned
enterprises, most of which had not participated in the
vigorous expansion of the economy and many of
which have been losing the ability to pay full wages
and pensions. From 60 to 100 million surplus rural
workers are adrift between the villages and the cities,
many subsisting through part-time low-paying jobs.
Popular resistance, changes in central policy, and
loss of authority by rural cadres have weakened
China''s population control program, which is essential
to maintaining growth in living standards. Another
long-term threat to continued rapid economic growth
is the deterioration in the environment, notably air
pollution, soil erosion, and the steady fall of the water
table especially in the north. China continues to lose
arable land because of erosion and economic
development; furthermore, the regime gives
insufficient priority to agricultural research. The next
few years may witness increasing tensions between a
highly centralized political system and an increasingly
decentralized economic system. Rapid economic
growth likely will continue but at a declining rate. Hong
Kong''s reversion on 1 July 1997 to Chinese
administration will strengthen the already close ties
between the two economies.
GDP: purchasing power parity— $4.25 trillion (1997
estimate as extrapolated from World Bank estimate
for 1 995 with use of official Chinese growth figures for
1996-97; the result may overstate China''s GDP by as
much as 25%)
GDP— real growth rate: 8.8% (1997 est.)
GDP— per capita: purchasing power parity— $3,460
(1997 est.)
GDP— composition by sector:
agriculture: 20%
industry: 49%
services: 31 % (1 996 est.)
Inflation rate— consumer price index: 2.8%
(1997 est.)
Labor force:
total: 623.9 million (1995)
by occupation: agriculture and forestry 53%, industry
and commerce 26%, construction and mining 7%,
social services 4%, other 10% (1995)
Unemployment rate: officially 4% in urban areas;
probably 8%-10%; substantial unemployment and
underemployment in rural areas (1997 est.)
Budget:
revenues : $NA
expenditures : $NA, including capital expenditures of
$NA
Industries: iron and steel, coal, machine building,
armaments, textiles and apparel, petroleum, cement,
chemical fertilizers, footwear, toys, food processing,
autos, consumer electronics, telecommunications
Industrial production growth rate: 13%
(1996 est.)
Electricity— capacity: 250 million kW (1997 est.)
Electricity— production: 1.135 trillion kWh (1997
est.)
Electricity— consumption per capita: 1 ,1 00 kWh
(1997 est.)
98
Agriculture— products: rice, wheat, potatoes,
sorghum, peanuts, tea, millet, barley, cotton, other
fibers, oilseed; pork and other livestock products; fish
Exports:
total value: $182.7 billion (f.o.b., 1997)
commodities: electrical machinery, clothing, footwear,
toys, mineral fuels, leather, plastics, fabrics (1997)
partners: Hong Kong, US, Japan, South Korea,
Germany, Netherlands (1997)
Imports:
total value: $142.4 billion (c.i.f., 1997)
commodities: mechanical appliances, electrical
machinery, mineral fuels, plastics, iron and steel,
fabrics, cotton and yarn (1997)
partners: Japan, Taiwan, US, South Korea, Hong
Kong, Germany, Singapore (1997)
Debt— external: $131 billion (1997 est.)
Economic aid:
recipient: ODA, $1 .977 billion (1 993)
Currency: 1 yuan (¥) = 10 jiao
Exchange rates: yuan (¥) per US$1— 8.2796
(December 1997), 8.2898 (1997), 8.3142 (1996),
8.3514 (1995), 8.6187 (1994), 5.7620 (1993)
note: beginning 1 January 1994, the People''s Bank of
China quotes the midpoint rate against the US dollar
based on the previous day''s prevailing rate in the
interbank foreign exchange market
Fiscal year: calendar year','25dcfd8dea74c8f3ac2a3c74ec4ed11bd91601b7c619c28805732c5769e27913','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21aa27a96f32f28a05019ab0afb7f44f4f49b6e2657fc8b0217717729ac9283d',1998,'CX','Christmas Island','economy',226,'Economy— overview: Phosphate mining had been
the only significant economic activity, but in December
1987 the Australian Government closed the mine. In
1990, the mine was reopened by private operators.
Australian-based Casinos Austria International Ltd.
built a $45 million casino on Christmas Island.
GDP: purchasing power parity — $NA
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity — $NA
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force:
total: NA
by occupation: tourism 400 people, mining 100','b13f9e5ced995a213cd0ff454535066d1dda614943ac732dc3d7ba1a533c8c00','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e1663d7afd4b9c1080bb7509d277798b294f7b2bb05ac562c51301a1d7e047a',1998,'AU','Australia','economy',233,'Economy— overview: Although 1 1 5 species of fish
have been identified in the territorial waters of
Clipperton Island, the only economic activity is a tuna
fishing station.
Economy— overview: no economic activity
Economy— overview: This unique, noncommercial
economy is supported financially by contributions
(known as Peter''s Pence) from Roman Catholics
throughout the world, the sale of postage stamps and
tourist mementos, fees for admission to museums,
and the sale of publications. The incomes and living
standards of lay workers are comparable to, or
somewhat better than, those of counterparts who
work in the city of Rome.
Labor force: NA
by occupation: dignitaries, priests, nuns, guards, and
3,000 lay workers who live outside the Vatican
Budget:
revenues: $175.5 million
expenditures: $175 million, including capital
expenditures of $NA (1994)
Industries: printing and production of a small
amount of mosaics and staff uniforms; worldwide
banking and financial activities
Electricity-capacity: 5,000 kW standby
note: electricity supplied by Italy
Electricity— production: NA kWh
note: electricity supplied by Italy
Electricity— consumption per capita: NA kWh
Currency: 1 Vatican lira (VLit) = 100 centesimi
Exchange rates: Vatican lire (VLit) per US$1 —
1,787.7 (January 1998), 1,703.1 (1997), 1,542.9
(1996), 1,628.9 (1995), 1,612.4(1994), 1,573.7
(1 993); note— the Vatican lira is at par with the Italian
lira which circulates freely
Fiscal year: calendar year
Economy— overview: no economic activity','8fb188bb4a46660ab4d88697f751fbb80aa00267852c63c672aa72457d398124','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86a4efd523aefb0c82e2e58420dee6979bfd26ace7e32514974eb5f37d3d18b5',1998,'CO','Colombia','economy',239,'Economy— overview: Columbia is recovering from
a short recession that began in late 1996— resulting
from tight monetary policy to drive down inflation,
declining business confidence related to President
SAMPER''s political difficulties, and a slowdown in
exports stemming from an appreciation of the peso
and a recession in neighboring Venezuela. Although
1 997''s 3.1% GDP growth rate represented an
improvement over 1 996, it ranked among the lowest in
Latin America and was substantially lower than the
average annual growth rate exceeding 4% that
Colombia posted for several decades prior to
SAMPER’s election. Colombia''s next president will
inherit a variety of economic problems. Most notably,
the unemployment rate is at its highest level this
decade, risks for the export sector and foreign
investors are rising as a result of increasing guerrilla
violence and a volatile exchange rate, and the fiscal
deficit has more than tripled since 1994.
GDP: purchasing power parity— $231 .1 billion (1997
est.)
GDP— real growth rate: 3.1% (1997 est.)
GDP— per capita: purchasing power parity— $6,200
(1997 est.)
GDP— composition by sector:
agriculture: 19%
industry: 26%
services: 55% (1996)
Inflation rate— consumer price index: 17.7%
(1997 est.)
Labor force:
total: 16.8 million (1997 est.)
by occupation: services 46%, agriculture 30%,
industry 24% (1990)
Unemployment rate: 12.2% (1997 est.)
Budget:
revenues: $26 billion (1996 est.)
expenditures: $30 billion including capital
expenditures of $NA (1996 est.)
Industries: textiles, food processing, oil, clothing
and footwear, beverages, chemicals, cement; gold,
coal, emeralds
Industrial production growth rate: -1 .2% (1996)
Electricity— capacity: 10.781 million kW (1995)
Electricity— production: 47 billion kWh (1995)
Electricity— consumption per capita: 1 ,307 kWh
(1995)
Agriculture— products: coffee, cut flowers,
bananas, rice, tobacco, corn, sugarcane, cocoa
beans, oilseed, vegetables; forest products; shrimp
farming
Exports:
total value: $1 1 .4 billion (f.o.b., 1 997 est.)
commodities : petroleum, coffee, coal, bananas, fresh
cut flowers
partners: US 39%, EC 25.7%, Japan 2.9%,
Venezuela 8.5% (1992)
104
Imports:
total value: $ 13.5 billion (c.i.f., 1997 est.)
commodities: industrial equipment, transportation
equipment, consumer goods, chemicals, paper
products
partners: US 36%, EC 18%, Brazil 4%, Venezuela
6.5%, Japan 8.7% (1992)
Debt— external: $17.1 billion (1997 est.)
Economic aid:
recipient: ODA, $30 million (1993)
Currency: 1 Colombian peso (Col$) = 100 centavos
Exchange rates: Colombian pesos (Co!$) per
US$1— 1345.0 (February 1998), 1,140.96 (1997),
1,036.69 (1996), 912.83 (1995), 844.84 (1994),
863.06 (1993)
Fiscal year: calendar year','8ec7df7a233132119444b94c23814cc87922491ed1859ba3f3fa2c975f0d971c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96e25262bbb4aee4d06b5730d9cfa65b2363194aebe5bd161a8d5e575b9116c0',1998,'MZ','Mozambique','economy',248,'Economy— overview: One of the world''s poorest
countries, Comoros is made up of three islands that
have inadequate transportation links, a young and
rapidly increasing population, and few natural
resources. The low educational level of the labor force
contributes to a subsistence level of economic activity,
high unemployment, and a heavy dependence on
foreign grants and technical assistance. Agriculture,
including fishing, hunting, and forestry, is the leading
sector of the economy. It contributes 40% to GDP,
employs 80% of the labor force, and provides most of
the exports. The country is not self-sufficient in food
production; rice, the main staple, accounts for the bulk
of imports. The government is struggling to upgrade
education and technical training, to privatize
commercial and industrial enterprises, to improve
health services, to diversify exports, to promote
tourism, and to reduce the high population growth
rate. Continued foreign support is essential if the goal
of 4% annual GDP growth is to be maintained in the
late 1990s.
GDP: purchasing power parity— $400 million
(1997 est.)
GDP— real growth rate: 3.5% (1997 est.)
GDP— per capita: purchasing power parity— $685
(1997 est.)
106
GDP— composition by sector:
agriculture: 40%
industry: 14%
services: 46% (1 996 est.)
Inflation rate— consumer price index: 3.5%
(1996 est.)
Labor force:
total: 144,500 (1996 est.)
by occupation: agriculture 80%, government 3%
Unemployment rate: 20% (1996 est.)
Budget:
revenues: $55 million
expenditures: $71 million, including capital
expenditures of $15 million (1995 est.)
Industries: tourism, perfume distillation, textiles,
furniture, jewelry, construction materials, soft drinks
Industrial production growth rate: -6.5%
(1989 est.)
Electricity— capacity: 9,750 kW (1996)
Electricity— production: 31 million kWh (1996)
Electricity— consumption per capita: 38 kWh
(1996)
Agriculture— products: vanilla, cloves, perfume
essences, copra, coconuts, bananas, cassava
(tapioca)
Exports:
total value : $1 1 .4 million (f.o.b., 1996 est.)
commodities: vanilla, ylang-ylang, cloves, perfume oil,
copra
partners: France 54%, Germany 18%, US 18%
Imports:
total value: $70 million (f.o.b., 1996 est.)
commodities: rice and other foodstuffs, consumer
goods; petroleum products, cement, transport
equipment
partners: France 60%, South Africa 10%, Kenya 5%,
Singapore 4%
Debt— external: $219 million (1996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Comoran franc (CF) = 100 centimes
Exchange rates: Comoran francs (CF) per US$1—
456.27 (January 1 998), 437.75 (1 997), 383.66 (1996),
374.36 (1995), 416.40 (1994), 283.16 (1993)
note: beginning 1 2 January 1 994, the Comoran franc
was devalued to 75 per French franc from 50 per
French franc at which it had been fixed since 1948
Fiscal year: calendar year
Economy— overview: Before the peace accord of
October 1992, Mozambique had been devastated by
civil war and was one of the poorest countries on the
globe. Prospects subsequently improved, and with its
solid economic performance in 1996-97, Mozambique
has begun to exploit its sizable agricultural,
hydropower, and transportation resources. Foreign
assistance programs help supply the foreign exchange
required to support the budget and pay for imports of
goods and services. The restoration of electrical
transmission lines to South Africa and the completion
of a new transmission line to Zimbabwe (permitting the
giant Cahora Bassa hydropower plant to export large
amounts of electricity), proposed construction of a
natural gas pipeline to South Africa, and reform of
transportation services will greatly improve foreign
exchange receipts. The Mozambique and South
African governments are developing the Maputo
corridor, linking the port of Maputo with Witbank, South
Africa. In the past few years, more than 700 state
enterprises have been privatized, including the
country''s largest commercial bank and a number of
sizable manufacturing firms. Other pending reform
measures are the reform of tax collection and the
facilitation of private enterprise in the transportation,
energy, and telecommunications sectors.
GDP: purchasing power parity— $14.6 billion (1997
est.)
GDP— real growth rate: 8% (1997 est.)
GDP— per capita: purchasing power parity— $800
(1997 est.)
GDP— composition by sector:
agriculture: 35%
industry: 13%
services: 52% (1996 est.)
Inflation rate— consumer price index: 5.8%
(1997)
Labor force: NA
by occupation : 80% engaged in agriculture
note: in 1993, 47% of the wage earners were
employed in industry, 28% in transportation and
communication; traditionally, a large number of
Mozambicans work abroad
Unemployment rate: NA
Budget:
revenues: $324 million
expenditures: $600 million, including capital
expenditures of $310 million (1996 est.)
Industries: food, beverages, chemicals (fertilizer,
soap, paints), petroleum products, textiles, cement,
glass, asbestos, tobacco
Industrial production growth rate: NA
Electricity— capacity: 2.358 million kW (1995)
Electricity— production: 465 million kWh (1995)
Electricity— consumption per capita: 73 kWh
(1995)
Agriculture— products: cotton, cashew nuts,
sugarcane, tea, cassava (tapioca), corn, rice, tropical
fruits; beef, poultry
Exports:
total value: $ 226 million (f.o.b., 1996 est.)
commodities : shrimp 40%, cashews, cotton, sugar,
copra, citrus
partners: Spain, South Africa, Japan, Portugal, US
Imports:
total value: $802 million (c.i.f., 1996 est.)
commodities: food, clothing, farm equipment,
petroleum
partners: South Africa 38%, US, Japan, Portugal,
Economy— overview: Taiwan has a dynamic
capitalist economy with gradually decreasing
guidance of investment and foreign trade by
government authorities and partial government
ownership of some large banks and industrial firms.
Spillover from the Asian financial crisis hit Taiwan in
the fourth quarter of 1997, wreaking havoc on the
stock and currency markets. While the economy
remains sound, (the government forecasts 6% GDP
growth for 1998) the New Taiwan Dollar depreciated
20% in 1997. Real growth in GDP has averaged about
8.5% a year during the past three decades. Export
growth has been even faster and has provided the
impetus for industrialization. Inflation and
unemployment are low. Agriculture contributes only
3% to GDP, down from 35% in 1952. Traditional
labor-intensive industries are steadily being moved
off-shore and replaced with more capital- and
technology-intensive industries. Taiwan has become
a major investor in China, Thailand, Indonesia, the
Philippines, Malaysia, and Vietnam. The tightening of
labor markets has led to an influx of foreign workers,
both legal and illegal.
GDP: purchasing power parity— $308 billion (1997
est.)
GDP— real growth rate: 6.8% (1997 est.)
GDP— per capita: purchasing power parity —
$14,200 (1997 est.)
GDP— composition by sector:
agriculture: 3.3%
industry: 35.7%
services: 61% (1996)
Inflation rate— consumer price index: 0.9%
(1997)
Labor force:
total: 9.4 million (1997)
by occupation: services 52%, industry 38%,
agriculture 10% (1996 est.)
Unemployment rate: 2.7% (1997)
Budget:
revenues: $40 billion
expenditures: $55 billion, including capital
expenditures of $NA (1 998 est.)
Industries: electronics, textiles, chemicals, clothing,
food processing, plywood, sugar milling, cement,
shipbuilding, petroleum refining
Industrial production growth rate: 7% (1997)
Electricity— capacity: 23.763 million kW (1996)
Electricity— production: 124.973 billion kWh
(1996)
522
Electricity — consumption per capita: 5,500 kWh
(1995)
Agriculture— products: rice, wheat, corn,
soybeans, vegetables, fruit, tea; pigs, poultry, beef,
milk; fish
Exports:
total value: $122.1 billion (f.o.b., 1997)
commodities: machinery and electrical equipment
21.7%, electronic products 14.8%, information/
communications 1 1 .8%, textile products 1 1 .6% (1 997)
partners: US 24.2%, Hong Kong 23.5%, Europe
15.1%, Japan 9.6% (1997)
Imports:
total value: $1 14.4 billion (c.i.f., 1997)
commodities: machinery and electrical equipment
16.5%, electronic products 16.3%, chemicals 10.0%,
precision instrument 5.6% (1997)
partners: Japan 25.4%, US 20.3%, Europe 18.9%,
Hong Kong 1.7% (1997)
Debt— external: $80 million (1997 est.)
Economic aid: $NA
Currency: 1 New Taiwan dollar (NT$) = 100 cents
Exchange rates: New Taiwan dollars per US$1 —
32.45 (yearend 1997), 27.5 (1996), 27.4 (1995), 26.2
(1994), 26.6 (1993), 25.4(1992)
Fiscal year: 1 July— 30 June','aa08f4a4238e04229470578cb1d126ca54840a308d6ace8982f9860e76399484','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e4d238213af892e42f661453dbea116379ba5a8c3214d89bfb6567f4218b3cf',1998,'CG','Congo','economy',254,'Economy— overview: The economy of Democratic
Republic of the Congo— a nation endowed with vast
potential wealth— has declined significantly since the
mid-1 980s. The new government has instituted a tight
fiscal policy that has curbed inflation and currency
depreciation. Plans are underway to introduce a new
national currency. Most formal transactions are
conducted in hard currency but a barter economy
flourishes in all but the largest cities. Most individuals
and families survive through subsistence farming or
petty trade. International investors show renewed
interest, especially in the mining and
telecommunications sectors. However, poor
infrastructure, an uncertain legal framework,
corruption and lack of transparency in government
economic policy remain a brake on investment and
growth. A number of IMF and World Bank missions
have met with the new government to help it develop
a coherent economic plan.
GDP: purchasing power parity— $18 billion
(1996 est.)
GDP— real growth rate: 1 .5% (1996 est.)
GDP— per capita: purchasing power parity— $400
(1996 est.)
GDP— composition by sector:
agriculture: 59%
industry: 1 5%
services: 26% (1 995 est.)
Inflation rate— consumer price index: NA%
Labor force:
total: 14.51 million (1993 est.)
by occupation: agriculture 65%, industry 16%,
services 19% (1991 est.)
Unemployment rate: NA%
Budget:
revenues: $269 million
expenditures: $244 million, including capital
expenditures of $24 million (1996 est.)
Industries: mining, mineral processing, consumer
products (including textiles, footwear, cigarettes,
processed foods and beverages), cement, diamonds
Industrial production growth rate: NA%
Electricity— capacity: 2.831 million kW (1995)
Electricity— production: 5.22 billion kWh (1995)
Electricity— consumption per capita: 95 kWh
(1995)
Agriculture— products: coffee, sugar, palm oil,
rubber, tea, quinine, cassava (tapioca), palm oil,
bananas, root crops, corn, fruits; wood products
Exports:
total value: $1 .9 billion (f.o.b., 1996 est.)
commodities: diamonds, copper, coffee, cobalt,
crude oil
partners: Belgium, US, France, Germany, Italy, UK,
Japan, South Africa
Imports:
total value: $1 .1 billion (c.i.f,, 1996 est.)
commodities: consumer goods, foodstuffs, mining
and other machinery, transport equipment, fuels
partners: Belgium, South Africa, US, France,
Germany, Italy, Japan, UK
Debt— external: $13.8 billion (1995 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 zaire (Z) = 100 makuta
Exchange rates: new zaires (Z) per US$1— 115,000
(January 1 998), 83,764 (October 1 996), 7,024 (1 995),
1,194 (1994), 3 (1993)
note: on 22 October 1993 the new zaire, equal to
3,000,000 old zaires, was introduced
Fiscal year: calendar year
Economy— overview: The economy is a mixture of
village agriculture and handicrafts, an industrial sector
based largely on oil, support services, and a
government characterized by budget problems and
overstaffing. Oil has supplanted forestry as the
mainstay of the economy, providing about 90% of
government revenues and exports. In the early 1 980s,
rapidly rising oil revenues enabled the government to
finance large-scale development projects with GDP
growth averaging 5% annually, one of the highest
rates in Africa. Subsequently, falling oil prices cut
GDP growth by half. Moreover, the government has
mortgaged a substantial portion of its oil earnings,
contributing to the government''s shortage of
revenues. The 12 January 1994 devaluation of Franc
Zone currencies by 50% resulted in inflation of 61 % in
1994 but inflation has subsided since. Economic
reform efforts continue with the support of
international organizations, notably the World Bank
and the IMF.
GDP: purchasing power parity— $5.25 billion (1996
est.)
GDP— real growth rate: 4% (1996 est.)
GDP— per capita: purchasing power parity— $2,000
(1996 est.)
GDP— composition by sector:
agriculture: 1 1 .4%
industry: 35.2%
services: 53.4% (1993)
Inflation rate— consumer price index: 3% (1996
est.)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $870 million
expenditures: $970 million, including capital
expenditures of $NA (1997 est.)
Industries: petroleum extraction, cement kilning,
lumbering, brewing, sugar milling, palm oil, soap,
cigarette making
Industrial production growth rate: NA%
Electricity— capacity: 1 1 8,000 kW (1 995)
Electricity— production: 438 million kWh (1995)
Electricity— consumption per capita: 220 kWh
(1995)
Agriculture— products: cassava (tapioca) accounts
for 90% of food output, sugar, rice, corn, peanuts,
vegetables, coffee, cocoa; forest products
Exports:
total value: $ 1 .2 billion (f.o.b., 1995)
commodities: crude oil 90%, lumber, plywood, sugar,
cocoa, coffee, diamonds
partners: Belgium-Luxembourg 24.3%, Taiwan
20.2%, US 14.9%, Italy 14.8% (1995 est.)
Imports:
total value: W0 million (f.o.b. 1995)
commodities: intermediate manufactures, capital
equipment, construction materials, foodstuffs,
petroleum products
partners: France 31.2%, Netherlands 24.6%, Italy
11.4%, US 6.9% (1995 est.)
Debt— external: $5.3 billion (1996)
Economic aid:
recipient: ODA, $N A
Currency: 1 Communaute Financier Africaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1 —
608.36 (January 1 998), 583.67 (1 997), 51 1 .55 (1 996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 1 2 January 1 994, the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: calendar year','6ebc7678b04b04df60f00166f5b4cf97dcd0c0b25742162ebd481d4260d98d52','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b1a3b0d267a94fc81425461d35bbc1ee353b5200e3078ac619878a352c8d0ba',1998,'CK','Cook Islands','economy',265,'Economy— overview: Like many other South
Pacific island nations, the Cook Islands'' economic
development is hindered by the isolation of the
country from foreign markets, lack of natural
resources, periodic devastation from natural
disasters, and inadequate infrastructure. Agriculture
provides the economic base with major exports made
up of copra and citrus fruit. Manufacturing activities
are limited to fruit-processing, clothing, and
handicrafts. Trade deficits are made up for by
remittances from emigrants and by foreign aid,
overwhelmingly from New Zealand. In 1996, the
government declared bankruptcy, citing a $1 20 million
public debt. Efforts to exploit tourism potential and
expanding the mining and fishing industries have not
been enough to adequately deal with the financial
crisis. In an effort to stem further erosion of the
economy, the government slashed public service
salaries by 50%, condensed the number of
government ministries from 52 to 22, reduced the
number of civil servants by more than half, began
selling government assets, and closed all overseas
diplomatic posts except for the one in New Zealand.
GDP: purchasing power parity— $79 million
(1994 est.)
112
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity — $4,000
(1994 est.)
GDP— composition by sector:
agriculture: 17%
industry: 6%
services: 77% (FY90/91)
Inflation rate— consumer price index: 2.6% (1994
est.)
Labor force:
total: 6,601 (1993)
by occupation: agriculture 29%, government 27%,
services 25%, industry 15%, other 4% (1981)
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capita! expenditures of
$NA
Industries: fruit processing, tourism
Industrial production growth rate: NA%
Electricity— capacity: 6,000 kW (1995)
Electricity— production: 15 million kWh (1995)
Electricity— consumption per capita: 775 kWh
(1995)
Agriculture— products: copra, citrus, pineapples,
tomatoes, beans, pawpaws, bananas, yams, taro,
coffee
Exports:
total value: $42 million (f.o.b., 1994 est.)
commodities: copra, fresh and canned citrus fruit,
coffee; fish; pearls and pearl shells; clothing
partners: NZ 80%, Japan, Hong Kong (1993)
Imports:
total value: $ 85 million (c.i.f., 1994)
commodities: foodstuffs, textiles, fuels, timber, capital
goods
partners: NZ 49%, Italy, Australia (1993)
Debt— external: $160 million (1994)
Economic aid:
recipient: roughly $16 million annually, 1985-95, with
New Zealand furnishing 88% of the total
Currency: 1 New Zealand dollar (NZ$) = 100 cents
Exchange rates: New Zealand dollars (NZ$) per
US$1— 1.7283 (January 1998), 1.5083 (1997),
1.4543 (1996), 1.5235 (1995), 1.6844 (1994), 1.8495
(1993)
Fiscal year: 1 April— 31 March
Economy— overview: no economic activity','06bfc805ccd4923347776071dc0d48b3e3ef9e121ab707019170277fc61c599e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04635b8bb83589e66344629011e591f284d4300e774735450d64aa449290d2e5',1998,'CR','Costa Rica','economy',273,'Economy— overview: Costa Rica''s basically stable
and progressive economy depends especially on
tourism and the export of bananas, coffee, and other
agricultural products. Poverty has been substantially
reduced over the past 1 5 years, and a strong social
safety net has been put in place. Recent trends,
however, have been disappointing. Economic growth
slipped from 4.3% in 1994 to 2.5% in 1995, and to
0.9% in 1996, and then rebounded in 1997 to 3%.
Inflation rose to 22.5% in 1995 from 13.5% in 1994,
receded to 1 7.5% in 1 996, then dropped to 1 1 .2% in
1997. Unemployment appears moderate at 5.7%, but
substantial underemployment continues.
Furthermore, substantial government deficits have
undermined efforts to maintain the quality of social
services. The government thus faces a formidable set
of problems: to curb inflation, reduce the deficit,
encourage domestic savings, and improve public
sector efficiency while increasing the role of the
private sector, all this in harmony with IMF
agreements. One important positive development—
the infusion of more than $200 million in 1997 by
microchip giant Intel and the anticipated attraction of
other high-tech firms to Costa Rica will help stimulate
growth and employment over the next several years.
GDP: purchasing power parity— $19.6 billion (1997
est.)
GDP— real growth rate: 3% (1997 est.)
GDP— per capita: purchasing power parity— $5,500
(1997 est.)
GDP— composition by sector:
agriculture: 18%
industry: 24%
services: 58% (1995)
Inflation rate— consumer price index: 1 1 .2%
(1997 est.)
Labor force:
total: 868,300
by occupation: industry and commerce 35.1 %,
government and services 33%, agriculture 27%, other
4.9% (1985 est.)
Unemployment rate: 5.7% (1997 est.); much
underemployment
Budget:
revenues; $1.1 billion
expenditures: $1. 34 billion, including capital
expenditures of $110 million (1991 est.)
Industries: food processing, textiles and clothing,
construction materials, fertilizer, plastic products
Industrial production growth rate: 10.5% (1992)
Electricity— capacity: 1.094 million kW (1995)
Electricity— production: 4.53 billion kWh (1995)
Electricity— consumption per capita: 1 ,323 kWh
(1995)
Agriculture— products: coffee, bananas, sugar,
corn, rice, beans, potatoes; beef; timber (depletion of
forest resources has resulted in declining timber
output)
Exports:
total value: $2.9 billion (f.o.b., 1996)
commodities: coffee, bananas, textiles, sugar
partners: US, Germany, Italy, Guatemala, El
Salvador, Netherlands, UK, France
Imports:
total value: $3 A billion (c.i.f., 1996)
commodities: raw materials, consumer goods, capital
equipment, petroleum
partners : US, Japan, Mexico, Guatemala, Venezuela,','3c3e71574b6bd3406f6164365f4b1070a5d486f9d51a5fa23473541cbf91e11c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2a82a1fedbc938351b2a768c50800e6b4a3d531d7931dab31b113676c3f3ad0',1998,'DE','Germany','economy',274,'Debt— external: $3.2 billion (October 1996 est.)
Economic aid:
recipient: OD A, $NA
Currency: 1 Costa Rican colon (C) = 100 centimos
Exchange rates: Costa Rican colones (C) per
US$1— 243.55 (December 1997), 232.60 (1997),
207.69 (1996), 179.73 (1995), 157.07 (1994), 142.17
(1993)
Fiscal year: calendar year
115
Costa Rica (continued)
Debt— external: $426 million (1995 est.)
Economic aid:
recipient: bilateral $36.1 million; multilateral $34.7
million (1994)
Currency: 1 dalasi (D) = 100 butut
Exchange rates: dalasi (D) per US$1— 10.513
(December 1 997), 1 0.200 (1 997), 9.789 (1 996), 9.546
(1995), 9.576 (1994), 9.129 (1993)
Fiscal year: 1 July— 30 June
Economy— overview: In 1 997 the German economy,
the world''s third most powerful, benefited from robust
exports, particularly to other members of the EU and the
US, as well as strengthening equipment investment. But
anemic private consumption and a contraction in the
construction industry limited the expansion.
Unemployment continued to set post-war monthly
records through the end of 1997 and averaged 4.3
million for the year. In preparation for the 1 January 1999
start of the European Monetary Union, the government
has made major efforts in 1 996-97 to reduce the fiscal
deficit. This effort has been complicated by growing
unemployment, an erosion of the tax base, and the
continuing transfer of roughly $100 billion a year to
eastern Germany to refurbish this ex-communist area. In
recent years business and political leaders have
become increasingly concerned about Germany''s
decline in attractiveness as an investment target. They
cite increasing preference by German companies to
locate new manufacturing facilities in foreign countries,
including the US, rather than in Germany, to be closerto
the markets and to avoid Germany''s high tax rates, high
wage costs, rigid labor structures, and extensive
regulations. For similar reasons foreign investment in
Germany has been lagging in recent years.
GDP: purchasing power parity— $1 .74 trillion
(western: purchasing power parity— $1.60 trillion;
eastern: purchasing power parity— $144 billion) (1997
est.)
GDP— real growth rate: 2.4% (western 2.5%,
eastern 1.7%) (1997 est.)
GDP— per capita: purchasing power parity —
$20,800 (western: purchasing power parity— $23,600;
eastern: purchasing power parity— $9,100) (1997
est.)
GDP— composition by sector:
agriculture: 1.1%
industry: 34.5%
services: 64.4% (1995)
Inflation rate— consumer price index: 1.8%
(1997)
Labor force:
total: 38.7 million
by occupation: industry 41%, agriculture 3%, services
56% (1995)
Unemployment rate: 1 2% (1 997 est.)
Budget:
revenues: $755 billion
expenditures: $832.1 billion, including capital
expenditures of $NA (1995)
Industries: western: among world''s largest and
technologically advanced producers of iron, steel,
coal, cement, chemicals, machinery, vehicles,
machine tools, electronics, food and beverages;
eastern: metal fabrication, chemicals, brown coal,
shipbuilding, machine building, food and beverages,
textiles, petroleum refining
Industrial production growth rate: 3% (1997)
Electricity— capacity: 109.727 million kW (1995)
Electricity— production: 495.875 billion kWh
(1995)
Electricity— consumption per capita: 6,154 kWh
(1995 est.)
Agriculture— products: western: potatoes, wheat,
barley, sugar beets, fruit, cabbage; cattle, pigs,
poultry; eastern: wheat, rye, barley, potatoes, sugar
beets, fruit; pork, beef, chicken, milk, hides
Exports:
total value: $521.1 billion (f.o.b., 1996)
commodities: manufactures 88.2% (including
machines and machine tools, chemicals, motor
vehicles, iron and steel products), agricultural
products 5.0%, raw materials 2.3%, fuels 1.0%, other
3.5% (1995)
partners: EU 57.7% (France 1 1 .7%, UK 8.1 %, Italy
7.6%, Netherlands 7.5%, Belgium-Luxembourg 6.5%,
Austria 5.5%), Eastern Europe 8.0%, other West
European countries 7.5%, US 7.3%, NICs 5.6%,
Japan 2.5%, OPEC 2.2%, China 1 .4% (1996 est.)
Imports:
total value: $ 455.7 billion (f.o.b., 1996)
commodities: manufactures 74.2%, agricultural
products 9.9%, fuels 6.4%, raw materials 5.9%, other
3.6% (1995)
partners: EU 55.5% (France 10.8%, Netherlands
8.6%, Italy 8.4%, Belgium-Luxembourg 6.6%, UK
6.4%, Austria 3.9%), Eastern Europe 8.7%, other
West European countries 7.2%, US 6.8%, Japan
5.3%, NICs 5.3%, China 2.4%, OPEC 1.7%, other
7.1% (1995)
Debt— external: $NA
Economic aid:
donor: ODA, $9 billion (1996 est.)
Currency: 1 deutsche mark (DM) = 100 pfennige
Exchange rates: deutsche marks (DM) per US$1 —
1.8167 (January 1 998), 1 .7341 (1 997), 1 .5048 (1 996),
1.4331 (1995), 1.6228 (1994), 1.6533 (1993)
Fiscal year: calendar year
Debt— external: $3.3 billion (1996)
Economic aid:
recipient: ODA, $10 million (1993)
note: commitments, 1992-95, $4,780 million ($1,795
million disbursements)
Currency: 1 Kazakhstani tenge = 100 tiyn
Exchange rates: tenges per US$1— 76.4 (February
1998), 75.55 (January 1998), 75.44 (1997), 67.30
(1996), 60.95 (1995), 35.54 (1994)
Fiscal year: calendar year
Economy— overview: The stable, prosperous
economy features moderate growth, low inflation, and
low unemployment. Agriculture is based on small
family-owned farms. The industrial sector, until
recently dominated by steel, has become increasingly
more diversified. During the past decades, growth in
the financial sector has more than compensated for
the decline in steel. Services, especially banking,
account for a growing proportion of the economy.
Luxembourg participates in an economic union with
Belgium on trade and most financial matters, is also
closely connected economically to the Netherlands,
and, as a member of the EU, enjoys the advantages
of the open European market.
GDP: purchasing power parity— $13.48 billion (1997
est.)
GDP— real growth rate: 3.6% (1997 est.)
GDP— per capita: purchasing power parity —
$33,700 (1997 est.)
GDP— composition by sector:
agriculture: 5%
industry: 21%
services: 74% (1995)
Inflation rate— consumer price index: 2.3%
(1995)
Labor force:
total: 213,1 00 (one-third of labor force is foreign
workers, mostly from Portugal, Italy, France, Belgium,
and Germany)
by occupation: trade, restaurants, hotels 20%, mining,
quarrying, manufacturing 16%, other market services
18%, community, social, personal services 14%,
construction 11%, finance, insurance, real estate,
business services 9%, transport, storage,
communications 8%, agriculture, hunting, forestry,
fishing 1%, electricity, gas, water 1% (1995 est.)
Unemployment rate: 3.5% (1997)
Budget:
revenues: $5.46 billion
expenditures: $5.44 billion, including capital
expenditures of $NA (1997 est.)
Industries: banking, iron and steel, food processing,
chemicals, metal products, engineering, tires, glass,
aluminum
Industrial production growth rate: 3.3% (1 995
est.)
Electricity— capacity: 138,000 kW (1995)
Electricity— production: 470 million kWh (1995)
Electricity— consumption per capita: 13,518 kWh
(1995)
Agriculture— products: barley, oats, potatoes,
wheat, fruits, wine grapes; livestock products
Exports:
total value: $7. 1 billion (f.o.b., 1996)
commodities: finished steel products, chemicals,
rubber products, glass, aluminum, other industrial
products
partners: Germany 28%, France 18%, Belgium 15%,
UK 7%, Netherlands 5%
imports:
total value: $9.4 billion (c.i.f., 1996)
commodities: minerals, metals, foodstuffs, quality
consumer goods
partners: Belgium 38%, Germany 25%, France 11%,
Netherlands 4%
Debt— external: $NA
Economic aid:
donor: ODA, $50 million (1993)
Currency: 1 Luxembourg franc (LuxF) = 100
centimes; note— centimes no longer in use
Exchange rates: Luxembourg francs (LuxF) per
US$1— 37.459 (January 1998), 35.774 (1997),
30.962 (1996), 29.480 (1995), 33.456 (1994), 34.597
(1993); note— the Luxembourg franc is at par with the
Belgian franc, which circulates freely in Luxembourg
Fiscal year: calendar year
Economy— overview: The economy is based
largely on tourism (including gambling) and textile and
fireworks manufacturing. Efforts to diversify have
spawned other small industries— toys, artificial
flowers, and electronics. The tourist sector has
accounted for roughly 25% of GDP, and the clothing
industry has provided about two-thirds of export
earnings; the gambling industry probably represents
over 40% of GDP. Macau depends on China for most
of its food, fresh water, and energy imports. Japan and
Hong Kong are the main suppliers of raw materials
and capital goods.
GDP: purchasing power parity— $7.8 billion (1997
est.)
GDP— real growth rate: -0.3% (1997 est.)
GDP— per capita: purchasing power parity —
$15,600 (1997 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 3.9% (1997
est.)
Labor force:
total: 271, 228 (1995)
by occupation: industry 28%, restaurants and hotels
28%, other services 44%
Unemployment rate: 3.6% (1995)
Budget:
revenues: $1.3 billion
expenditures: $1 .07 billion, including capital
expenditures of $NA (1995 est.)
Industries: clothing, textiles, toys, electronics,
footwear, tourism
Industrial production growth rate: NA%
Electricity— capacity: 260,000 kW (1995)
Electricity— production: 1.3 billion kWh (1995)
Electricity— consumption per capita: 3,250 kWh
(1996 est.)
Agriculture— products: rice, vegetables
Exports:
total value: $1 .99 billion (f.o.bM 1996 est.)
commodities: textiles, clothing, toys, electronics,
cement
partners: US 42%, EU 31 .7%, Hong Kong 1 0%, China
9.8% (1996)
Imports:
tota! value: $1 .99 billion (c.i.f., 1 996 est.)
commodities: raw materials, foodstuffs, capital goods,
fuels, lubricants
partners: Hong Kong 28.9%, China 21 .8%, EU 14.7%,
Japan 10.5% (1996)
Debt— external: $0(1996)
Economic aid:
recipient: ODA, $NA
Currency: 1 pataca (P) = 100 avos
Exchange rates: patacas (P) per US$1— 7.99
(1997), 7.962 (1996), 8.034 (1993-95), 7.973 (1992);
note— linked to the Hong Kong dollar at the rate of
1 .03 patacas per Hong Kong dollar
Fiscal year: calendar year
Debt— external: $2.3 billion (1996 est.)
Economic aid:
recipient: donor pledges, $332 million (1996)
Currency: 1 Malawian kwacha (MK) = 100 tambala
Exchange rates: Malawian kwacha (MK) per
US$1— 17.5300 (October 1997), 15.3085 (1996),
15.2837 (1995), 8.7364 (1994), 4.4028 (1993)
Fiscal year: 1 April— 31 March
Imports:
total value: $1 AS billion (1997)
commodities: oil, gas, coal, steel, machinery,
foodstuffs, automobiles, and other consumer durables
partners: Russia, Ukraine, Uzbekistan, Romania,
Debt— external: more than $1 billion (1997)
Economic aid:
recipient: IMF and World Bank, $512 million (1 992-97)
Currency: the Moldovan leu (MLD) (plural !ei) was
introduced in late 1993
Exchange rates: lei (MLD) per US$1 (end of
period) — 4.6870 (January 1997), 4.6628 (1997),
4.6743 (1996), 4.4990 (1995), 4.2700 (1994), 3.6400
(1993), 0.4145 (1992); period average^4.6758
(January 1998), 81.6637 (1997), 4.6045 (1996),
4.4958 (1995)
Fiscal year: calendar year
Economy— overview: Monaco, situated on the
French Mediterranean coast, is a popular resort,
attracting tourists to its casino and pleasant climate.
The Principality has successfully sought to diversify
into services and small, high-value-added,
nonpolluting industries. The state has no income tax
and low business taxes and thrives as a tax haven
both for individuals who have established residence
and for foreign companies that have set up
businesses and offices. About 55% of Monaco''s
annual revenue comes from value-added taxes on
hotels, banks, and the industrial sector. Living
standards are high, roughly comparable to those in
prosperous French metropolitan areas.
GDP: purchasing power parity— $800 million (1996
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity —
$25,000 (1996 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force:
total: 30,540 (1 January 1994)
Unemployment rate: 3.1% (1994)
Budget:
revenues : $623.3 million
expenditures: $638.7 million, including capital
expenditures of $NA (1995 est.)
Industrial production growth rate: NA%
Electricity— capacity: 1 0,000 kW standby
note: electricity imported from France
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Agriculture— products: none
Exports: $NA; full customs integration with France,
which collects and rebates Monegasque trade duties;
also participates in EU market system through
customs union with France
Imports: $NA; full customs integration with France,
which collects and rebates Monegasque trade duties;
also participates in EU market system through
customs union with France
Debt— external: $NA
Economic aid: $NA
Currency: 1 French franc (F) = 100 centimes
Exchange rates: French francs (F) per US$1—
6.0836 (January 1 998), 5.8367 (1 997), 5.1 1 55 (1 996),
4.9915 (1995), 5.5520 (1994), 5.6632 (1993)
Fiscal year: calendar year','6bdbde5f6533ae7235e4d4d86fde6e0283fb358e1eecdca69a29b1b9d1a30a33','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35529844aa55fdeb6c74a8a71113c9dfd2644bcef9034542afbf52d5a1b591db',1998,'SI','Slovenia','economy',287,'Economy— overview: Before the dissolution of
Yugoslavia, the Republic of Croatia, after Slovenia,
was the most prosperous and industrialized area, with
a per capita output perhaps one-third above the
Yugoslav average. Croatia faces considerable
economic problems stemming from: the legacy of
longtime communist mismanagement of the
economy; damage during the internecine fighting to
bridges, factories, power lines, buildings, and houses;
the large refugee and displaced population, both
Croatian and Bosnian; and the disruption of economic
ties. Western aid and investment, especially in the
tourist and oil industries, would help restore the
economy. The government has been successful in
some reform efforts— partially macroeconomic
stabilization policies— and it has normalized relations
with its creditors. Yet it still is struggling with
privatization of large state enterprises and with bank
reform.
GDP: purchasing power parity— $22.7 billion (1 997
est.)
GDP— real growth rate: 4.4% (1997 est.)
GDP— per capita: purchasing power parity— $4,500
(1997 est.)
GDP— composition by sector:
agriculture: "12%
industry: 24%
services: 64% (1 995 est.)
Inflation rate— consumer price index: 3.7% (1997
est.)
Labor force:
total: 1.444 million (1995)
by occupation: industry and mining 31 .1%, agriculture
4.3%, government 19.1% (including education and
health), other 45.5% (1993)
Unemployment rate: 15.9% (yearend 1997 est.)
Budget:
revenues: $5.3 billion
expenditures: $6.3 billion, including capital
expenditures of $78.5 million (1997 est.)
Industries: chemicals and plastics, machine tools,
fabricated metal, electronics, pig iron and rolled steel
products, aluminum, paper, wood products,
construction materials, textiles, shipbuilding,
petroleum and petroleum refining, food and
beverages; tourism
Industrial production growth rate: 0% (1995)
Electricity— capacity: 3.593 million kW (1995)
Electricity— production: 7.15 billion kWh (1995)
Electricity— consumption per capita: 2,315 kWh
(1995)
Agriculture— products: wheat, corn, sugar beets,
sunflower seed, alfalfa, clover, olives, citrus, grapes,
vegetables; livestock breeding, dairy farming
Exports:
total value: $ 4.3 billion (f.o.b., 1997)
commodities : machinery and transport equipment
13.6%, miscellaneous manufactures 27.6%,
chemicals 14.2%, food and live animals 12.2%, raw
materials 6.1%, fuels and lubricants 9.4%, beverages
and tobacco 2.7% (1993)
partners: Germany 22%, Italy 21%, Slovenia 18%
(1994)
Imports:
total value: $ 9.1 billion (c.i.f., 1997)
commodities: machinery and transport equipment
23.1%, fuels and lubricants 8.8%, food and live
animals 9.0%, chemicals 14.2%, miscellaneous
manufactured articles 16.0%, raw materials 3.5%,
beverages and tobacco 1 .4% (1 993)
partners: Germany 21%, Italy 19%, Slovenia 10%
(1994)
Debt— external: $5,904 billion (October 1997)
Economic aid:
recipient: ODA, $NA
note: IMF has given Croatia $192 million; World Bank
has given Croatia $100 million
Currency: 1 Croatian kuna (HRK) = 100 lipas
Exchange rates: Croatian kuna per US$1— 6.369
(January 1998), 6.101 (1997), 5.434 (1996), 5.230
(1995), 5.996 (1994), 3.577(1993)
Fiscal year: calendar year','242fa5e5d62222ebe50a7910c5643bb4850c425b6742ba5415bc1b51f7e94125','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b63d6c72057343641264eb2aeb797c777d2e3e989f0ed1554f142af61e37521',1998,'CU','Cuba','economy',295,'Economy— overview: The state plays the primary
role in the economy and controls practically all foreign
trade. The government has undertaken several
reforms in recent years to stem excess liquidity,
increase labor incentives, and alleviate serious
shortages of food, consumer goods, and services.
The liberalized agricultural markets introduced in
October 1994, at which state and private farmers sell
above-quota production at unrestricted prices, have
broadened legal consumption alternatives and
reduced black market prices. Government efforts to
lower subsidies to unprofitable enterprises and to
shrink the money supply caused the semi-official
exchange rate for the Cuban peso to move from a
peak of 120 to the dollar in the summer of 1994 to 23
to the dollar by yearend 1997. New taxes introduced
in 1996 helped drive down the number of
self-employed workers from 208,000 in January 1 996
to 1 76,000 by September 1 997. Havana announced in
1995 that GDP declined by 35% during 1989-93, the
result of lost Soviet aid and domestic inefficiencies.
The drop in GDP apparently halted in 1994, when
Cuba reported 0.7% growth, followed by increases of
2.5% in 1995 and 7.8% in 1996. Growth slowed again
in 1 997, to 2.5%, in part due to a poor sugar harvest.
Export earnings declined 3% in 1997, to $1.9 billion,
the result of lower sugar export volume and lower
world prices for nickel and sugar. Imports remained
unchanged in 1 997 at $3.2 billion. Tourism plays a key
role in foreign currency earnings. The disparity
between those at the top of the ladder and those at the
bottom has increased markedly in the past 10 years.
Living standards for the average Cuban remain at a
depressed level compared with 1990.
GDP: purchasing power parity— $16.9 billion (1997
est.)
GDP— real growth rate: 2.5% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,540
(1997 est.)
GDP— composition by sector:
agriculture: 7.6%
industry: 34.8%
services: 57.6% (1996 est.)
Inflation rate— consumer price index: NA%
Labor force:
total: 4.5 million economically active population (1 996
est.)
by occupation: services and government 30%,
industry 22%, agriculture 20%, commerce 11%,
construction 1 0%, transportation and communications
7% (June 1990)
note: state sector 76%, non-state sector 24% (1 996
est.)
Unemployment rate: 8% (1996 est.)
Budget:
revenues: $NA
expenditures: $N A, including capital expenditures of
$NA
Industries: sugar, petroleum, food, tobacco, textiles,
chemicals, paper and wood products, metals
(particularly nickel), cement, fertilizers, consumer
goods, agricultural machinery
Industrial production growth rate: 6% (1995 est.)
Electricity— capacity: 3.988 million kW (1995)
Electricity— production: 10.105 billion kWh (1995)
Electricity— consumption per capita: 924 kWh
(1995)
Agriculture— products: sugarcane, tobacco, citrus,
coffee, rice, potatoes and other tubers, beans;
livestock
122
Exports:
total value: $1 .9 billion (f.o.b., 1997 est.)
commodities: sugar, nickel, tobacco, shellfish,
medical products, citrus, coffee
partners: Russia 1 8%, Netherlands 1 4% Canada 1 3%
(1997 est.)
Imports:
total value: $3.2 billion (c.i.f., 1997 est.)
commodities: petroleum, food, machinery, chemicals
partners : Spain 14%, Russia 12%, Mexico 9% (1997
est.)
Debt— external: $10.5 billion (convertible currency,
1996); another $20 billion owed to Russia (1996)
Economic aid:
recipient: ODA, $46 million (1997 est.)
Currency: 1 Cuban peso (Cu$) = 100 centavos
Exchange rates: Cuban pesos (Cu$) per US$1—
1.0000 (non-convertible, official rate, linked to the US
dollar)
Fiscal year: calendar year','0316a35fab1d0acd9484fa6097f3d4e7fd58a62993d84e49e4e07e526b12be71','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f1502918a53b562b278f4094c531a9b998e41ca64f59c8bf8ef7735f4361004',1998,'CY','Cyprus','economy',303,'Economy— overview: The Greek Cypriot economy
is small and prosperous, but highly susceptible to
external shocks. Industry contributes 22% to GDP and
employs 25% of the labor force, while the service
sector contributes 73% to GDP and employs 62% of
the labor force. Erratic growth rates in the 1990s
reflect the economy''s vulnerability to swings in tourist
arrivals, caused by political instability on the island
and fluctuations in economic conditions in Western
Europe. The Turkish Cypriot economy has about
one-third the per capita GDP of the south. Because it
is recognized only by Turkey, it has had much difficulty
arranging foreign financing, and foreign firms have
hesitated to invest there. The economy remains
heavily dependent on agriculture and government
service, which together employ about half of the work
force. Moreover, the small, vulnerable economy has
suffered because the Turkish lira is legal tender. To
compensate for the economy''s weakness, Turkey
provides direct and indirect aid to nearly every sector.
In January 1997, Turkey signed a $250 million
economic cooperation accord with the Turkish Cypriot
area to support tourism, education, and industry.
GDP: purchasing power parity— $11.19 billion
(Greek Cypriot area: purchasing power parity— $9.75
billion; Turkish Cypriot area: purchasing power
parity— $1.44 billion) (1997 est.)
GDP— real growth rate: 2.4% (Greek Cypriot area:
2.5%; Turkish Cypriot area: 1.7%) (1997 est.)
GDP— per capita: purchasing power parity —
$13,500 (Greek Cypriot area: purchasing power
parity— $15,000; Turkish Cypriot area: purchasing
power parity— $8,000) (1997 est.)
GDP— composition by sector: Greek Cypriot area:
agriculture 4.4%; industry 22.4%; services 73.2%
(1996); Turkish Cypriot area: agriculture 10%;
industry 24.6%; services 65.4% (1995)
Inflation rate— consumer price index: Greek
Cypriot area: 3.5% (1997 est.); Turkish Cypriot area:
87.5% (1997 est.)
Labor force:
total: Greek Cypriot area: 299,700
by occupation: services 62%, industry 25%,
agriculture 13% (1995)
total: Turkish Cypriot area: 76,500 (1996)
by occupation: services 66%, industry 11%,
agriculture 23% (1995)
Unemployment rate: Greek Cypriot area: 3.3%
(1997 est.); Turkish Cypriot area: 6.4% (1996)
Budget:
revenues: Greek Cypriot area— $2.9 billion, Turkish
Cypriot area— $171 million
expenditures: Greek Cypriot area— $3.4 billion,
including capital expenditures of $345 million, Turkish
Cypriot area— $306 million, including capital
expenditures of $56.8 million (1997 est.)
Industries: food, beverages, textiles, chemicals,
metal products, tourism, wood products
Industrial production growth rate: Greek Cypriot
area: -4% (1996); Turkish Cypriot area: 5.1% (1995)
Electricity— capacity: 666,000 kW (1995)
Electricity— production: 2.6 billion kWh (1995)
Electricity— consumption per capita: 3,530 kWh
(1995)
Agriculture— products: potatoes, citrus,
vegetables, barley, grapes, olives, vegetables
125
Cyprus (continued)
Exports:
total value: Greek Cypriot area: $1 .3 billion (f.o.b.,
1996)
commodities: citrus, potatoes, grapes, wine, cement,
clothing and shoes
partners: Russia 19.1%, Bulgaria 16.4%, UK 11.3%,
Greece 6.3%, Germany 4.8%
total value: Turkish Cypriot area: $70.5 million (f.o.b.,
1996)
commodities: citrus, potatoes, textiles
partners: Turkey 48.2%, UK 21.3%, other EU 13.7%
Imports:
total value: Greek Cypriot area: $3.6 billion (f.o.b.,
1996)
commodities: consumer goods, petroleum and
lubricants, food and feed grains, machinery
partners: US 17.8%, UK 11.9%, Italy 9.7%, Germany
7.5%, Greece 7.6%
total value: Turkish Cypriot area: $318.4 million
(f.o.b., 1996)
commodities: food, minerals, chemicals, machinery
partners: Turkey 55.3%, UK 13.8%, other EU 11.6%
Debt-external: Greek Cypriot area: $1 .56 billion
(1997)
Economic aid: Greek Cypriot area: recipient— $1 87
million (1990-94) in grants; Turkish Cypriot area:
recipient— $700 million (1990-97) from Turkey in
grants and loans that are usually forgiven
Currency: 1 Cypriot pound (£C) = 100 cents; 1
Turkish lira (TL) = 100 kurus
Exchange rates: Cypriot pounds (£C) per US1$ —
0.5326 (January 1 998), 0.51 35 (1 997), 0.4663 (1 996),
0.4522 (1995), 0.4915 (1994), 0.4970 (1993); Turkish
liras (TL) per US$1 -187,477 (November 1997),
81,405 (1996), 45,845.1 (1995), 29,608.7 (1994),
10,984.6(1993)
Fiscal year: calendar year
Economy— overview: Political and financial crises
in 1 997 shattered the Czech Republic’s image as one
of the most stable and prosperous of post-Communist
states. Delays in enterprise restructuring and failure to
develop a well-functioning capital market played
major roles in Czech economic troubles, which
culminated in a currency crisis in May. The currency
was forced out of its fluctuation band as investors
worried that the current account deficit, which reached
about 8% of GDP in 1996, would become
unsustainable. After expending $3 billion in vain to
support the currency, the central bank let it float. The
growing current account imbalance reflected a surge
in domestic demand and poor export performance, as
wage increases outpaced productivity. The
government was forced to introduce two austerity
packages later in the spring which cut government
spending by 2.5% of GDP. A tough 1998 budget
continues the painful medicine. These problems were
compounded in the summer of 1997 by
unprecedented flooding which inundated much of the
eastern part of the country. Czech difficulties in 1997
contrast with earlier achievements of strong GDP
growth, a balanced budget, and inflation and
unemployment that were among the lowest in the
region. The Czech economy''s transition problems
continue to be too much direct and indirect
government influence on the privatized economy, the
sometimes ineffective management of privatized
firms, and a shortage of experienced financial
analysts for the banking system. Prague forecasts a
balanced budget, 2.2% GDP growth, 5.2%
unemployment, and 10% inflation for 1998.
GDP: purchasing power parity— $1 1 1 .9 billion (1 997
est.)
GDP— real growth rate: 0.7% (1997 est.)
GDP— per capita: purchasing power parity —
$10,800 (1997 est.)
GDP— composition by sector:
agriculture: 5%
industry: 40.6%
services: 54.4% (1996)
Inflation rate— consumer price index: 10% (1997)
Labor force:
total: 5.1 24 million (1997)
by occupation: industry 33.1%, agriculture 6.9%,
construction 9.1%, transport and communications
7.2%, services 43.7% (1994)
Unemployment rate: 5% (1997 est.)
Budget:
revenues; $14.2 billion
expenditures: $14.6 billion, including capital
expenditures of $NA (1997)
Industries: fuels, ferrous metallurgy, machinery and
equipment, coal, motor vehicles, glass, armaments
Industrial production growth rate: 6.9% (1996)
Electricity— capacity: 13.85 million kW (1994)
Electricity— production: 53.285 billion kWh (1995)
Electricity— consumption per capita: 5,069 kWh
(1995)
Agriculture— products: grains, potatoes, sugar
beets, hops, fruit; pigs, cattle, poultry; forest products
Exports:
total value: $21 .7 billion (f.o.b., 1 996)
commodities: machinery and equipment 32.7%,
manufactured goods 28.8%, raw materials and fuel
9.2%, food 4.1% (1996)
partners: EU 60.9%, CEFTA 21 .4%, Slovakia 13.9%,
EFTA 1.7% (1996)
Imports:
total value: $27.7 billion (f.o.b., 1996)
commodities: machinery and equipment 38.2%,
manufactured goods 19.3%, raw materials and fuels
12.4%, and food 5.6% (1996)
partners: EU 61 .1%, CEFTA 16.3%, Slovakia 1 1 .8%,
EFTA 2.2% (1996)
Debt— external: $20.7 billion (1996)
Economic aid: $NA
Currency: 1 koruna (Kc) = 100 haleru
Exchange rates: koruny (Kcs) per US$1— 35.357
(January 1 998), 31 .698 (1 997), 27.1 45 (1 996), 26.541
(1995), 28.785 (1994), 29.153 (1993)
note: values before 1 993 reflect Czechoslovak
exchange rates
Fiscal year: calendar year','5ba41f973fac336d68388fbae7692c12c7467f07021935c04e3d5ccc0600af9f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c1c77e26410db62382385545e79b67e9cffbe745e4a08e07d4977244f7d525f',1998,'DK','Denmark','economy',311,'Economy— overview: This thoroughly modern
market economy features high-tech agriculture,
up-to-date small-scale and corporate industry,
extensive government welfare measures, comfortable
living standards, and high dependence on foreign
trade. Denmark is a net exporter of food. The
center-left coalition government will concentrate on
reducing the persistently high unemployment rate and
the budget deficit as well as following the previous
government''s policies of maintaining low inflation and
a current account surplus. The coalition also vows to
maintain a stable currency. The coalition has lowered
marginal income taxes while maintaining overall tax
revenues; boosted industrial competitiveness through
labor market and tax reforms and increased research
and development funds; and improved welfare
services for the neediest while cutting paperwork and
delays. Prime Minister RASMUSSEN''S reforms focus
on adapting Denmark to the criteria for European
integration by 1999; Copenhagen has won from the
European Union (EU) the right to opt out of the
European Monetary Union (EMU). Denmark is, in fact,
one of the few EU countries likely to fit into the EMU
on time. Growth may fall off slightly to 2.8% in 1998,
and inflation may rise to 2.5%.
GDP: purchasing power parity— $122.5 billion (1997
est.)
GDP— real growth rate: 3% (1997 est.)
GDP— per capita: purchasing power parity —
$23,200 (1997 est.)
GDP— composition by sector:
agriculture: 4%
industry: 27%
services: 69% (1995)
Inflation rate— consumer price index: 2.2% (1997
est.)
Labor force:
total: 2,895,950
by occupation: private services 40%, government
services 30%, manufacturing and mining 19%,
construction 6%, agriculture, forestry, and fishing 5%
(1995)
Unemployment rate: 7.9% (1997 est.)
Budget:
revenues: $62.1 billion
expenditures: $66.4 billion, including capital
expenditures of $NA (1996 est.)
Industries: food processing, machinery and
equipment, textiles and clothing, chemical products,
electronics, construction, furniture, and other wood
products, shipbuilding
Industrial production growth rate: 1 .3% (1 996)
Electricity— capacity: 10.604 million kW (1995)
Electricity— production: 34.244 billion kWh (1995)
Electricity— consumption per capita: 6,432 kWh
(1995)
Agriculture— products: grain, potatoes, rape, sugar
beets; meat, dairy products; fish
Exports:
total value: $48.8 billion (f.o.b., 1996)
commodities: machinery and instruments 25%, meat
and meat products, fuels, dairy products, ships, fish,
chemicals
partners: Germany 22.5%, Sweden 9.7%, UK 7.9%,
Norway 5.9%, France 5.4%, Netherlands 4.4%, US
4.0% (1995)
Imports:
total value: $43.2 billion (c.i.f., 1996)
commodities: machinery and equipment, petroleum
25%, chemicals, grain and foodstuffs, textiles, paper
partners: Germany 21 .7%, Sweden 1 1 .7%,
Netherlands 7.0%, UK 6.6%, France 5.2%, Norway
4.9%, US 4.7%, Japan 3.5%, FSU 1.7% (1995)
Debt— external: $44 billion (1996 est.)
Economic aid:
donor: ODA, $1.34 billion (1993)
Currency: 1 Danish krone (DKr) = 100 oere
130
Exchange rates: Danish kroner (DKr) per US$1 —
6.916 (January 1998), 6.604 (1997), 5.799 (1996),
5.602 (1995), 6.361 (1994), 6.484 (1993)
Fiscal year: calendar year
Economy— overview: The economy is based on
service activities connected with the country''s
strategic location and status as a free trade zone in
northeast Africa. Two-thirds of the inhabitants live in
the capital city, the remainder being mostly nomadic
herders. Scanty rainfall limits crop production to fruits
and vegetables, and most food must be imported.
Djibouti provides services as both a transit port for the
region and an international transshipment and
refueling center. It has few natural resources and little
industry. The nation is, therefore, heavily dependent
on foreign assistance to help support its balance of
payments and to finance development projects. An
unemployment rate of 40% to 50% continues to be a
major problem. Per capita consumption dropped an
estimated 35% over the last seven years because of
recession, civil war, and a high population growth rate
(including immigrants and refugees). Faced with a
multitude of economic difficulties, the government has
fallen in arrears on long term external debt and has
been struggling to meet the stipulations of foreign aid
donors.
GDP: purchasing power parity— $520 million (1997
est.)
GDP— real growth rate: 0.5% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,200
(1997 est.)
GDP— composition by sector:
agriculture: 3%
industry: 20%
services: 77% (1996 est.)
Inflation rate— consumer price index: 3% (1997
est.)
Labor force:
total: 282,000
by occupation : agriculture 75%, industry 1 1 %,
services 14% (1991 est.)
Unemployment rate: 40%-50% (1 996 est.)
Budget:
revenues: $156 million
expenditures: $175 million, including capital
expenditures of $NA (1997 est.)
Industries: limited to a few small-scale enterprises,
such as dairy products and mineral-water bottling
Industrial production growth rate: 3% (1996 est.)
Electricity— capacity: 85,000 kW (1995)
Electricity— production: 180 million kWh (1995)
Electricity— consumption per capita: 427 kWh
(1995)
Agriculture— products: fruits, vegetables; goats,
sheep, camels
Exports:
total value: $ 39.6 million (f.o.b., 1996 est.)
commodities: hides and skins, coffee (in transit)
(1995)
partners: Ethiopia 45%, Somalia, Yemen, Saudi
Arabia (1996)
132
Imports:
total value: $ 200.5 million (f.o.b., 1996 est.)
commodities: foods, beverages, transport equipment,
chemicals, petroleum products (1995)
partners: France, Ethiopia, Italy, Saudi Arabia,
Thailand (1996)
Debt— external: $276 million (1996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Djiboutian franc (DF) = 100 centimes
Exchange rates: Djiboutian francs (DF) per US$1 —
177.721 (fixed rate since 1973)
Fiscal year: calendar year','91989762074030f31f6d917a67b8f7dd547c06aa466b8a55723a309aa90826f9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('987392ca72aed02cf052636f2bdd908b227a93ea7b0f483aa7c7f9cb3ff1b00b',1998,'DM','Dominica','economy',319,'Economy— overview: The economy is dependent
on agriculture and thus is highly vulnerable to climatic
conditions, notably tropical storms. Agriculture,
primarily bananas, accounts for 26% of GDP and
employs 40% of the labor force. Development of the
tourist industry remains difficult because of the rugged
coastline, lack of beaches, and the lack of an
international airport. Hurricane Luis devastated the
country''s banana crop in September 1995; tropical
storms had wiped out one-quarter of the crop in 1 994
as well. The government is attempting to develop an
offshore financial industry in order to diversify the
island''s production base.
GDP: purchasing power parity— $208 million (1996
est.)
GDP— real growth rate: 3.7% (1996 est.)
GDP— per capita: purchasing power parity— $2,500
(1996 est.)
GDP— composition by sector:
agriculture: 26%
industry: NA%
services: NA% (1995)
Inflation rate— consumer price index: 1 .7%
(1996)
Labor force:
total: 25,000
by occupation: agriculture 40%, industry and
commerce 32%, services 28% (1984)
Unemployment rate: 15% (1992 est.)
Budget:
revenues: $77 million
expenditures: $78 million, including capital
expenditures of $22 million (FY95/96)
Industries: soap, coconut oil, tourism, copra,
furniture, cement blocks, shoes
Industrial production growth rate: -0.4% (1996
est.)
Electricity— capacity: 8,000 kW (1995)
Electricity— production: 37 million kWh (1995)
Electricity— consumption per capita: 448 kWh
(1995)
Agriculture— products: bananas, citrus, mangoes,
root crops, coconuts; forestry and fisheries potential
not exploited
Exports:
total value: $51. 8 million (f.o.b., 1996)
commodities: bananas 50%, soap, bay oil,
vegetables, grapefruit, oranges
partners: Caricom countries 47%, UK 36%, US 7%
(1996 est.)
Imports:
total value: $98.1 million (f.o.b., 1996)
commodities: manufactured goods, machinery and
equipment, food, chemicals
partners: US 41%, Caricom 25%, UK 13%,
Netherlands, Canada
Debt— external: $110 million (1996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars (EC$) per
US$1— 2.7000 (fixed rate since 1976)
Fiscal year: 1 July— 30 June
134
Economy— overview: Economic reforms launched
in late 1994 contributed to exchange rate stabilization,
reduced inflation, and strong GDP growth in 1995-96.
In 1996, there was increased mineral and petroleum
exploration, and a new investment law that allows for
repatriation of capital dividends has drawn more
investment to the island. Upon coming to power in
August 1996, President FERNANDEZ nevertheless
inherited a trouble-ridden economy hampered by a
pressured peso, a large external debt, nearly bankrupt
state-owned enterprises, and a manufacturing sector
hindered by daily power outages. In December,
FERNANDEZ presented a bold economic reform
package— including such reforms as the devaluation
of the peso, income tax cuts, a 50% increase in sales
taxes, reduced import tariffs, and increased gasoline
prices— in an attempt to create a market-oriented
economy that can compete internationally. Even
though reforms are moving ahead at a slow pace, the
economy grew vigorously in 1997, with tourism and
telecommunications leading the advance. The
government is working to increase electric generating
capacity, a key to continued economic growth.
GDP: purchasing power parity— $38.3 billion (1997
est.)
GDP— real growth rate: 7% (1997 est.)
GDP— per capita: purchasing power parity— $4,700
(1997 est.)
GDP— composition by sector:
agriculture: 15%
industry: 22%
services: 63% (1995)
Inflation rate— consumer price index: 10.9%
(1997 est.)
Labor force: 2.3 million to 2.6 million
by occupation: agriculture 50%, services and
government 32%, industry 18% (1991 est.)
Unemployment rate: 30% (1996 est.)
Budget:
revenues: $2 billion
expenditures: $2 billion, including capital
expenditures of $994 million (1996 est.)
Industries: tourism, sugar processing, ferronickel
and gold mining, textiles, cement, tobacco
Industrial production growth rate: 6.3% (1995
est.)
Electricity— capacity: 1 .447 million kW (1995)
Electricity— production: 6.5 billion kWh (1995)
Electricity— consumption per capita: 865 kWh
(1995)
Agriculture— products: sugarcane, coffee, cotton,
cocoa, tobacco, rice, beans, potatoes, corn, bananas;
cattle, pigs, dairy products, meat, eggs
Exports:
total value: W5 million (f.o.b., 1996)
commodities: ferronickel, sugar, gold, coffee, cocoa
partners: US 45%, EU 34%, Canada, Japan, Puerto
Rico (1995)
imports:
total value: $ 3.7 billion (f.o.b., 1996)
commodities: foodstuffs, petroleum, cotton and
fabrics, chemicals and pharmaceuticals
partners: US 44%, EU 16%, Venezuela 11%,
Netherlands Antilles, Mexico, Japan (1995)
Debt— external: $3.6 billion (1997)
Economic aid:
recipient: ODA, $21 million (1993)
Currency: 1 Dominican peso (RD$) = 100 centavos
Exchange rates: Dominican pesos (RD$) per
US$1— 14.332 (December 1997), 14.265 (1997),
13.775 (1996), 13.597 (1995), 13.160 (1994), 12.676
(1993)
Fiscal year: calendar year
136','f08a3a6201b227b8ccdc6ed0c2607f73b0f72787ccd7204bca99aa1b9bda4539','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d3ac4e21026483280006d2d1df4a361415ad360eb71be616abb8aa49eff57bd',1998,'PE','Peru','economy',327,'Economy— overview: Ecuador has substantial oil
resources and rich agricultural areas. As an exporter
of primary products such as oil, bananas, and shrimp,
fluctuations in world market prices can have a
substantial domestic impact. Growth has been
uneven in recent years as the government has
repeatedly initiated ill-conceived fiscal stabilization
measures. The populist government of Abdala
BUCARAM Ortiz proposed a major currency reform in
1996, but popular discontent with new austerity
measures and rampant official corruption undermined
his government''s position. Congress replaced
BUCARAM with Fabian ALARCON in February 1997.
ALARCON has adopted a minimalist economic
138
program that puts off major decisions until the next
elected government takes office in August 1998.
Ecuador joined the World T rade Organization in 1 996,
but has failed to comply with many of its accession
commitments. Growth slowed to 2.0% in 1 996, due to
a lack of investment caused by political uncertainty
and high domestic interest rates, but economic activity
picked up in 1997. Exports and economic growth in
1998 may be adversely affected by lower world oil
prices and, to a smaller extent, by El Nino.
GDP: purchasing power parity— $53.4 billion (1997
est.)
GDP— real growth rate: 3.4% (1997 est.)
GDP— per capita: purchasing power parity— $4,400
(1997 est.)
GDP— composition by sector:
agriculture: 12%
industry: 37%
services: 51% (1996 est.)
Inflation rate— consumer price index: 31% (1997
est.)
Labor force:
total: 4.2 million
by occupation: agriculture 29%, manufacturing 18%,
commerce 15%, services and other activities 38%
(1990)
Unemployment rate: 6.9% with widespread
underemployment (August 1997 est.)
Budget:
revenues: $3.6 billion (1997)
expenditures : $3.6 billion, including capital
expenditures of $NA (1996 est.)
Industries: petroleum, food processing, textiles,
metal work, paper products, wood products,
chemicals, plastics, fishing, lumber
Industrial production growth rate: 2.4% (1997
est.)
Electricity— capacity: 2.754 million kW (1996)
Electricity— production: 9.27 billion kWh (1996)
Electricity— consumption per capita: 600 kWh
(1996)
Agriculture— products: bananas, coffee, cocoa,
rice, potatoes, manioc, plantains, sugarcane; cattle,
sheep, pigs, beef, pork, dairy products; balsa wood;
fish, shrimp
Exports:
total value: $3.4 billion (f.o.b., 1997)
commodities: petroleum 30%, bananas 26%, shrimp
16%, cut flowers 2%, fish 1 .9%
partners: US 39%, Latin America 25%, EU countries
22%, Asia 12%
Imports:
total value: $2.9 billion (c.i.f., 1997)
commodities: transport equipment, consumer goods,
vehicles, machinery, chemicals
partners: US 32%, EU 19%, Latin America 35%, Asia
11%
Debt— external: $12.5 billion (1997)
Economic aid:
recipient: ODA, $153 million (1993)
note: received $12.7 million from the US and $160
million from other countries in 1995
Currency: 1 sucre {SI) = 100 centavos
Exchange rates: sucres (SI) per US$1 — 4,498.0
(January 1998), 3,988.3 (1997), 3,189.5 (1996),
2,564.5 (1995), 2,196.7 (1994), 1,919.1 (1993)
Fiscal year: calendar year','ee3e4ed2379d42acbcc899bb03d24dbc0b524888f5d5c811d7882d534c24efc3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d5f1c32e3415496f351d53179fe1971ab7014865bcbf179fe861fc22a7cacc8',1998,'SD','Sudan','economy',336,'Economy— overview: At the end of the 1 980s,
Egypt faced problems of low productivity and poor
economic management, compounded by the adverse
social effects of excessive population growth, high
inflation, and massive urban overcrowding. In the face
of these pressures, in 1991 Egypt undertook
wide-ranging macroeconomic stabilization and
structural reform measures. This reform effort has
been supported by three successive IMF
arrangements, the last of which was concluded in
October 1996. Egypt''s reform efforts— and its
participation in the Gulf war coalition— also led to
massive debt relief under the Paris Club
arrangements. Although the pace of reform has been
uneven and slower than envisaged under the IMF
programs, substantial progress has been made in
improving macroeconomic performance. Budget
deficits have been slashed while foreign reserves in
1997 were at an all-time high. And Egypt has been
moving toward a more decentralized, market-oriented
economy. These economic reforms and growing
investment opportunities have prompted increasing
foreign investment, but incoming capital has largely
been concentrated in stock market portfolio flows.
Egypt''s economy also has been hit by a sharp
downturn in tourism— a key foreign exchange and job
producing sector— following the 17 November 1997
massacre of foreign tourists at Luxor. Although Egypt
will probably regain these revenues over time, the
slump in tourism is likely to slow the GDP growth rate
in 1998.
GDP: purchasing power parity— $267.1 billion (1997
est.)
GDP— real growth rate: 5.2% (1997 est.)
GDP— per capita: purchasing power parity— $4,400
(1997 est.)
GDP— composition by sector:
agriculture: 17%
industry: 32%
sernces; 51% (1996)
Inflation rate— consumer price index: 4.9%
(1997)
Labor force:
total: 17.4 million (1996 est.)
by occupation: agriculture 40%, services, including
government 38%, industry 22% (1990 est.)
Unemployment rate: 9.4% (1997 est.)
Budget:
revenues: $19.2 billion
expenditures: $19.8 billion, including capital
expenditures of $4 billion (FY96/97 est.)
Industries: textiles, food processing, tourism,
chemicals, petroleum, construction, cement, metals
Industrial production growth rate: 8.5% (1996
est.)
Electricity— capacity: 13.04 million kW (1995)
Electricity— production: 48.5 billion kWh (1995)
Electricity— consumption per capita: 778 kWh
(1995)
Agriculture— products: cotton, rice, corn, wheat,
beans, fruits, vegetables; cattle, water buffalo, sheep,
goats; annual fish catch about 140,000 metric tons
Exports:
total value: $5A billion (f.o.b., FY96/97 est.)
commodities: crude oil and petroleum products,
cotton yarn, raw cotton, textiles, metal products,
chemicals
partners: EU, US, Japan
Imports:
total value: $15.5 billion (c.i.f., FY96/97 est.)
commodities : machinery and equipment, foods,
fertilizers, wood products, durable consumer goods,
capital goods
partners: US, EU, Japan
Debt— external: $30.5 billion (1996/97 est.)
Economic aid:
recipient: OD A, $1,713 billion (1993)
Currency: 1 Egyptian pound (£E) = 100 piasters
Exchange rates: Egyptian pounds (£E) per US$1—
3.4 (November 1994), 3.369 (November 1993), 3.345
(November 1992); market rate— 3.3880 (January
1998), 3.3880 (1997), 3.3880 (1996), 3.3900 (1995),
3.3910(1994), 3.3718(1993)
Fiscal year: 1 July— 30 June
Economy— overview: Sudan is buffeted by civil war,
chronic political instability, adverse weather, high
inflation, a drop in remittances from abroad, and
counterproductive economic policies. The private
sector''s main areas of activity are agriculture and
trading, with most private industrial investment predating
1980. Agriculture employs 80% of the workforce.
Industry mainly processes agricultural items. Sluggish
economic performance over the past decade,
attributable largely to declining annual rainfall, has kept
per capita income at low levels. A large foreign debt and
huge arrearages continue to cause difficulties. In 1990
the International Monetary Fund took the unusual step of
declaring Sudan noncooperative because of its
nonpayment of arrearages to the Fund. After Sudan
backtracked on promised reforms in 1992-93, the IMF
threatened to expel Sudan from the Fund. To avoid
expulsion, Khartoum agreed to make payments on its
arrears to the Fund, liberalize exchange rates, and
reduce subsidies, measures it has partially
implemented. The government''s continued prosecution
of the civil war and its growing international isolation
continued to inhibit growth in the nonagricultural sectors
of the economy during 1997. Hyperinflation has raised
consumer prices above the reach of most. In 1 997, a top
priority was to develop potentially lucrative oilfields in
south-central Sudan; the government was seeking
foreign partners to exploit the oil sector.
GDP: purchasing power parity— $26.6 billion (1997
est.)
GDP— real growth rate: 5% (1997 est.)
GDP— per capita: purchasing power parity— $875
(1997 est.)
GDP— composition by sector:
agriculture: 33%
industry: 17%
services: 50% (1992 est.)
Inflation rate— consumer price index: 27%
(mid-1997 est.)
Labor force:
total: 1 1 million (1996 est.)
by occupation: agriculture 80%, industry and
commerce 10%, government 6%
note: labor shortages for almost all categories of
skilled employment (1983 est.)
440
Television broadcast stations: 3
Televisions: 2.06 million (1992 est.)','a2dae0ea03c7ee85b27186d1b485ede740c810a18688e2aaa5f24c8c7887e42c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df4d355829e5ee996ece9faec8557630b52a1d74c9e793a4b799ab0c583812b8',1998,'SV','El Salvador','economy',344,'Economy— overview: In 1997 the government
emphasized a fixed exchange rate, along with
conservative monetary and fiscal policies to promote
foreign investment. Inflation fell to an unprecedented
low of 2%. Exports reached a record level and were
the main engine of growth. Productivity in other
sectors remained weaker, however. For the last few
years, El Salvador has experienced sizable deficits in
both its trade and its fiscal accounts. The trade deficit
has been offset by remittances from the large number
of Salvadorans living abroad and from external aid.
The deficit is expected to increase in 1 998 as imports
continue to rise. San Salvador is stepping up its
privatization efforts in 1 998 to increase revenues. Late
in 1997 the legislative assembly approved a
privatization law that will facilitate the sale of the
state-owned telephone company sometime in 1998.
The government also plans to privatize pension funds
later in the year.
GDP: purchasing power parity— $17.8 billion (1997
est.)
GDP— real growth rate: 4% (1997 est.)
GDP— per capita: purchasing power parity— $3,000
(1997 est.)
GDP— composition by sector:
agriculture: 15%
industry: 24%
services: 61 % (1 997 est.)
Inflation rate— consumer price index: 2% (1997)
Labor force:
total: 2.26 million (1997 est.)
by occupation: agriculture 40%, commerce 16%,
manufacturing 15%, government 13%, financial
services 9%, transportation 6%, other 1%
Unemployment rate: 7.7% (1997 est.)
Budget:
revenues: $1 .75 billion
expenditures: $1 .82 billion, including capital
expenditures of $317 million (1997 est.)
Industries: food processing, beverages, petroleum,
chemicals, fertilizer, textiles, furniture, light metals
Industrial production growth rate: 7% (1997 est.)
Electricity— capacity: 900,000 kW (1996)
Electricity— production: 3.5 billion kWh (1997)
Electricity— consumption per capita: 603 kWh
(1997 est.)
Agriculture— products: coffee, sugarcane, corn,
rice, beans, oilseed, cotton, sorghum; beef, dairy
products; shrimp
Exports:
total value: $1 .96 billion (f.o.b., 1997 est.)
commodities: coffee, sugar; shrimp; textiles
partners: US, Guatemala, Germany, Costa Rica,','064108c11aaf0e968e096e84423fae84e0da436a08a824aa383ea90a39bcae77','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88f9c11e29d66b7e556c30f7b37f64b510176a5f286c4e86e6e02cfceffee2ce',1998,'GN','Guinea','economy',348,'Economy— overview: The discovery and
exploitation of large oil reserves have contributed to
dramatic economic growth in recent years. Farming,
forestry, and fishing are also major components of
GDP. Subsistence farming predominates. Although
pre-independence Equatorial Guinea counted on
cocoa production for hard currency earnings, the
deterioration of the rural economy under successive
brutal regimes has diminished potential for
agriculture-led growth. A number of aid programs
sponsored by the World Bank and the IMF have been
cut off since 1 993 because of the government''s gross
corruption and mismanagement. Businesses, for the
most part, are owned by government officials and their
family members. Undeveloped natural resources
include titanium, iron ore, manganese, uranium, and
alluvial gold. The country responded favorably to the
devaluation of the CFA franc in January 1994.
GDP: purchasing power parity— $660 million (1997
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $1 ,500
(1997 est.)
GDP— composition by sector:
agriculture: 46%
industry: 33%
services: 2)% (1995 est.)
Inflation rate— consumer price index: 6% (1996
est.)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $47 million
expenditures: $43 million, including capital
expenditures of $7 million (1996 est.)
Industries: fishing, sawmilling
Industrial production growth rate: 7.4% (1994
est.)
Electricity— capacity: 5,000 kW (1995)
Electricity— production: 20 million kWh (1995)
Electricity-consumption per capita: 48 kWh
(1995)
Agriculture— products: coffee, cocoa, rice, yams,
cassava (tapioca), bananas, palm oil nuts, manioc;
livestock; timber
Exports:
total value: $ 197 million (f.o.b., 1996 est.)
commodities : petroleum, timber, cocoa
partners: US 34%, Japan 17%, Spain 13%, China
13%, Nigeria
Imports:
total value: $248 million (c.i.f., 1996 est.)
commodities: petroleum, food, beverages, clothing,
machinery
partners: Cameroon 40%, Spain 18%, France 14%,
US 8%
Debt— external: $254 million (1996 est.)
Economic aid:
recipient : ODA, $NA
Currency: 1 Communaute Financier Africaine franc
(CFAF) = 1 00 centimes
Exchange rates: CFA francs (CFAF) per US$1 —
608.36 (January 1 998), 583.67 (1997), 51 1 .55 (1 996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 12 January 1994, the CFA franc was
devalued to CFAF 100 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: 1 April— 31 March
Economy— overview: With independence from
Ethiopia on 27 April 1993, Eritrea faced the bitter
economic problems of a small, desperately poor
African country. The economy is largely based on
subsistence agriculture, with over 70% of the
population involved in farming and herding. The small
industrial sector consists mainly of light industries with
outmoded technologies. Domestic output (GDP) is
substantially augmented by worker remittances from
abroad. Government revenues come from custom
duties and taxes on income and sales. Road
construction is a top domestic priority. Eritrea has
inherited the entire coastline of Ethiopia and has
long-term prospects for revenues from the
development of offshore oil, offshore fishing, and
tourism. Eritrea''s economic future depends on its
ability to master fundamental social and economic
problems, e.g., overcoming illiteracy, promoting job
creation, expanding technical training, attracting
foreign investment, and streamlining the bureaucracy.
GDP: purchasing power parity— $2.2 billion (1996
est.)
GDP— real growth rate: 6.8% (1996 est.)
GDP— per capita: purchasing power parity— $600
(1996 est.)
GDP— composition by sector:
agriculture: 18%
industry: 20%
services: 62% (1 995 est.)
Inflation rate— consumer price index: 4% (1997
est.)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $226 million
expenditures: $453 million, including capital
expenditures of $88 million (1996 est.)
Industries: food processing, beverages, clothing
and textiles
Industrial production growth rate: NA%
Electricity— capacity: 73,000 kW (1995)
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Agriculture— products: sorghum, lentils,
vegetables, maize, cotton, tobacco, coffee, sisal (for
making rope); livestock (including goats); fish
Exports:
total value: $71 million (1996 est.)
commodities: livestock, sorghum, textiles, food, small
manufactures
partners: Ethiopia 67%, Sudan 10%, Saudi Arabia
4%, US 3%, Italy, Yemen (1996)
Imports:
total value: $499 million (1 996 est.)
commodities: processed goods, machinery,
petroleum products
partners: Ethiopia, Saudi Arabia, Italy, United Arab
Emirates
Debt— external: $162 million (1995 est.)
148
Economic aid:
recipient: ODA, $N A
Currency: 1 nafka = 100 cents
Exchange rates: nakfa per US$1 = 7.2 (March 1 998
est.)
note: following independence from Ethiopia, Eritrea
continued to use Ethiopian currency until late in 1997
when Eritrea issued its own currency, the nakfa, at
approximately the same rate as the birr, i.e., 7.2 nakfa
per US$1
Fiscai year: calendar year','f8cbadadd9924103b7adc08bfc1ab7295a8c66b1621ba68001f8d2d9e047e5da','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3903d0d8b34adc9e53b98053302d6f5c0c56c0c1608cb7a1ba1615e2f9b61332',1998,'EE','Estonia','economy',358,'Economy— overview: In 1997 Estonia''s continued
implementation of market economic reforms,
disciplined fiscal and monetary policies, and a liberal
free trade regime resulted in GDP growth of 10% and
a drop in inflation to 1 1 .2%. Estonia can point to its
inclusion among the first group of Central and East
150
European countries to begin EU accession talks in
1998 as its most significant economic achievement in
1997. Other economic strengths include solid
investment grade rating from both Standard and
Poors and Moody''s, government revenue collection in
excess of projections by more than 6%, growth in
exports at a faster rate than imports, and record levels
of foreign direct investment, among the highest per
capita in Central and East Europe. Estonia privatized
its shipping company in 1997, but failed to make as
much progress privatizing other large infrastructure/
utility companies, such as Eesti Energia and the Oil
Shale company, which it plans to privatize in the next
two years. The growing current account deficit, which
stood at nearly 1 0% of GDP at yearend 1 997, remains
a serious concern. In 1998, GDP is expected to grow
by 5.5% and inflation to fall 10%.
GDP: purchasing power parity— $9.34 billion (1997
est.)
GDP— real growth rate: 10% (1997 est.)
GDP— per capita: purchasing power parity— $6,450
(1997 est.)
GDP— composition by sector:
agriculture: 7.1%
industry: 24.9%
services: 68% (1 995 est.)
Inflation rate— consumer price index: 1 1 .2%
(1997 est.)
Labor force:
total: 785,000 (1996 est.)
by occupation: industry and construction 42%,
agriculture and forestry 20%, other 38% (1990)
Unemployment rate: 3.6% (1997 est.)
Budget:
revenues: $1.7 billion
expenditures: $1 .8 billion, including capital
expenditures of $214 million (1996 est.)
Industries: oil shale, shipbuilding, phosphates,
electric motors, excavators, cement, furniture,
clothing, textiles, paper, shoes, apparel
Industrial production growth rate: 3% (1996 est.)
Electricity— capacity: 3.287 million kW (1995)
Electricity— production: 8.083 billion kWh (1995)
Electricity— consumption per capita: 4,355 kWh
(1995)
Agriculture— products: potatoes, fruits,
vegetables; livestock and dairy products; fish
Exports:
total value: $ 2 billion (f.o.b., 1996)
commodities: textiles 16%, food products 16%,
machinery and equipment 16%, metals 9% (1995)
partners: Finland, Russia, Sweden, Germany, Latvia
(1995)
Imports:
total value: $3.2 billion (c.i.f., 1996)
commodities: machinery and equipment 29%,
foodstuffs 14%, minerals 13%, textiles 13%, metals
12% (1995)
partners: Finland, Russia, Sweden, Germany (1995)
Debt— external: $270 million (January 1996)
Economic aid:
recipient: ODA, $147 million (1993)
note: Western commitments $285 million (including
international financial institutions)
Currency: 1 Estonian kroon (EEK) = 100 cents
(introduced in August 1992)
Exchange rates: krooni (EEK) per US$1— 14.527
(January 1 998), 1 3.882 (1 997), 1 2.034 (1 996), 1 1 .465
(1995), 12.991 (1994), 13.223 (1993); note-krooni
are tied to the German deutsche mark at a fixed rate
of 8 to 1
Fiscal year: calendar year
Economy— overview: Ethiopia remains one of the
poorest and least developed countries in the world. Its
economy is based on agriculture, which accounts for
more than half of GDP, 90% of exports, and 80% of total
employment; coffee generates 60% of export earnings.
The agricultural sector suffers from frequent periods of
drought, poor cultivation practices, and deterioration of
internal security conditions. The manufacturing sector
is heavily dependent on inputs from the agricultural
sector. Over 90% of large-scale industry, but less than
10% of agriculture, is state-run. The government is
considering selling off a portion of state-owned plants
and is implementing reform measures that are
gradually liberalizing the economy. A major
medium-term problem is the improvement of roads,
water supply, and other parts of an infrastructure badly
neglected during years of civil strife.
GDP: purchasing power parity— $29 billion (1997
est.)
GDP— real growth rate: 5% (1997 est.)
GDP— per capita: purchasing power parity— $530
(1997 est.)
GDP— composition by sector:
agriculture: 55%
industry: 12%
services: 33% (1995 est.)
Inflation rate— consumer price index: 0% (1996
est.)
Labor force:
total : NA
by occupation : agriculture and animal husbandry
80%, government and services 12%, industry and
construction 8% (1985)
Unemployment rate: NA%
Budget:
revenues: $1 billion
expenditures: $1 .48 billion, including capital
expenditures of $415 million (FY96/97)
Industries: food processing, beverages, textiles,
chemicals, metals processing, cement
industrial production growth rate; NA%
Electricity— capacity: 464,000 kW (1995)
Electricity— production: 1.143 billion kWh (1995)
Electricity— consumption per capita: 20 kWh
(1995)
Agriculture— products: cereals, pulses, coffee,
oilseed, sugarcane, potatoes, other vegetables;
hides, cattle, sheep, goats
Exports:
total value: $41 8 million (f.o.b., 1996)
commodities: coffee, leather products, gold (1995)
partners: Germany 32%, Japan 14%, Djibouti 7%,
Saudi Arabia 8%, Italy 8% (1994)
Imports:
total value: $1 .23 billion (f.o.b., 1996 est.)
commodities: food and live animals, petroleum and
petroleum products, chemicals, machinery, motor
vehicles and aircraft (1994)
partners: Saudi Arabia 15%, Italy 11%, US 12.3%,
Germany 8% (1994)
Debt— external: $5.2 billion (1995)
Economic aid:
recipient: ODA, $367 million (FY95/96)
Currency: 1 birr (Br) = 100 cents
Exchange rates: birr (Br) per US$1 (end of
period)— 6.9530 (February 1998), 6.8080 (September
1997), 6.4260 (1996), 6.3200 (1995), 5.9500 (1994),
5.0000 (fixed rate 1992-93)
note; since May 1993, the birr market rate has been
determined in an interbank market supported by
weekly wholesale auction; prior to that date, the
official rate was pegged to US$1 = 5.000 birr
Fiscal year: 8 July— 7 July
Economy— overview: no economic activity','402b6f030e75653adb328315d4c7dfb8362896502fdd980072ad4addae7dba91','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('509dbeec885a74597421604a487a9ac037d1c5f16baf2d6a6e80b9373864f3ef',1998,'FO','Faroe Islands','economy',367,'Economy— overview: The Faroese economy in
1995 and 1996 saw a noticeable upturn after several
years of decline brought on by a drop in fish catches
and declining prices and by over-spending by the
Faroese Home Rule Government (FHRG). In the early
1990s, property values plummeted, and the FHRG
had to bail out and merge the two largest Faroese
banks. Fishing is now improving; wage costs are
increasing; the FHRG''s budget is almost in balance;
and the large foreign debt has come down
significantly. Nevertheless, the total dependence on
fishing makes the Faroese economy extremely
vulnerable, and the reduction in the foreign debt is at
the cost of low investment. Oil finds close to the
Faroese area give hope for deposits in the immediate
Faroese area, which may lay the basis for an eventual
economic rebound. The Faroese are supported by a
substantial annual subsidy from Denmark.
GDP: purchasing power parity— $800 million (1996
est.)
GDP— real growth rate: 6% (1996 est.)
GDP— per capita: purchasing power parity —
$16,300 (1996 est.)
GDP— composition by sector:
agriculture: 20%
industry: 16%
services: 64% (1996 est.)
Inflation rate— consumer price index: 2.8% (1996
est.)
Labor force:
total: 20,345 (1 995 est.)
by occupation: largely engaged in fishing,
manufacturing, transportation, and commerce
Unemployment rate: 1 1 % (1 996 est.)
Budget:
revenues: $467 million
expenditures: $468 million, including capital
expenditures of $1 1 million (1996 est.)
Industries: fishing, shipbuilding, construction,
handicrafts
Industrial production growth rate: NA%
Electricity— capacity: 91,000 kW (1995)
Electricity— production: 200 million kWh (1995)
Electricity— consumption per capita: 4,092 kWh
(1995)
Agriculture— products: milk, potatoes, vegetables;
sheep; salmon farming; fish
Exports:
total value: $362 million (f.o.b., 1995)
commodities: fish and fish products 92%, animal
feedstuffs, transport equipment (ships)
partners: Denmark 22.2%, UK 25.8%, Germany
9.7%, France 8.3%, Norway 6.2%, US 2.0%
Imports:
total value: $ 315.6 (c.i.f., 1995)
commodities : machinery and transport equipment
17.0%, consumer goods 33%, raw materials and
semi-manufactures 26.9%, fuels 1 1 .4%, fish and salt
6.7%
partners : Denmark 34.5%, Norway 15.9%, UK 8.4%
Germany 7.8%, Sweden 5.8%, US 1.5%
Debt— external: $767 million (1995 est.)
Economic aid: receives an annual subsidy from
Denmark of about $150 million (1995)
Currency: 1 Danish krone (DKr) = 100 oere
Exchange rates: Danish kroner (DKr) per US$1 —
6.916 (January 1998), 6.604 (1997), 5.799 (1966),
5.602 (1995), 6.361 (1994), 6.484 (1993)
157
Faroe Islands (continued)
Fiscal year: calendar year','2cadc90a0299b4249400b68772080d8d2e93f08b3747cbf39ad4ba39386bff0c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3326a931567b84f699607c00c1af9bdc6f0b4f884f188e01507c39b64146d6ea',1998,'JE','Jersey','economy',375,'Economy— overview: Fiji, endowed with forest,
mineral, and fish resources, is one of the most
developed of the Pacific island economies, though still
with a large subsistence sector. Sugar exports and a
growing tourist industry are the major sources of
foreign exchange. Sugar processing makes up
one-third of industrial activity. Roughly 250,000
tourists visit each year. Political uncertainty and
drought, however, contribute to substantial
fluctuations in earnings from tourism and sugar and to
the emigration of skilled workers. Fiji''s growth slowed
in 1997 because the sugar industry suffered from low
world prices and rent disputes between farmers and
landowners.
GDP: purchasing power parity— $5.1 billion (1996
est.)
GDP— real growth rate: 3% (1996)
GDP— per capita: purchasing power parity— $6,500
(1996 est.)
GDP— composition by sector:
agriculture: 21%
industry: 18%
services: 61% (1995 est.)
Inflation rate— consumer price index: 3% (1997
est.)
Labor force:
total: 235,000
by occupation: subsistence agriculture 67%, wage
earners 18%, salary earners 15% (1987)
Unemployment rate: 6% (1997 est.)
Budget:
revenues: $540.65 million
expenditures: $742.65 million, including capital
expenditures of $NA (1997 est.)
Industries: sugar, tourism, copra, gold, silver,
clothing, lumber, small cottage industries
Industrial production growth rate: 2.9% (1995)
Electricity— capacity: 200,000 kW (1995)
Electricity— production: 545 million kWh (1995)
Electricity— consumption per capita: 705 kWh
(1995)
Agriculture— products: sugarcane, coconuts,
cassava (tapioca), rice, sweet potatoes, bananas;
cattle, pigs, horses, goats; fish catch 13,796 tons
(1991)
Exports:
total value: $6 39 million (f.o.b., 1996)
commodities: sugar 32%, clothing, gold, processed
fish, lumber
partners: EU 26%, Australia 15%, other Pacific island
countries 11%, Japan 6%
Imports:
total value: $947 million (c.i.f., 1996)
commodities: machinery and transport equipment,
petroleum products, food, consumer goods,
chemicals
partners: Australia 30%, NZ 17%, Japan 13%, EU
6%, US 6%
Debt— external: $333.8 million (1996 est.)
Economic aid:
recipient: ODA, $14.35 million from Australia (FY96/
97 est.); $3.5 million from New Zealand (FY95/96)
Currency: 1 Fijian dollar (F$) = 100 cents
Exchange rates: Fijian dollars (F$) per US$1 —
1 .9064 (January 1 998), 1 .4437 (1 997), 1 .4033 (1 996),
1.4063 (1995), 1.4641 (1994), 1.5418(1993)
Fiscal year: calendar year
Economy— overview: Israel has a technologically
advanced market economy with substantial
government participation. It depends on imports of
crude oil, grains, raw materials, and military
equipment. Despite limited natural resources, Israel
has intensively developed its agricultural and
industrial sectors over the past 20 years.
Manufacturing and construction employ about 28% of
Israeli workers; agriculture, forestry, and fishing only
2.6%; and services the rest. Israel is largely
self-sufficient in food production except for grains.
Diamonds, high-technology equipment, and
agricultural products (fruits and vegetables) are
leading exports. Israel usually posts sizable current
account deficits, which are covered by large transfer
payments from abroad and by foreign loans. Roughly
half of the government''s external debt is owed to the
US, which is its major source of economic and military
aid. To earn needed foreign exchange, Israel has
been targeting high-technology niches in international
markets, such as medical scanning equipment. The
influx of Jewish immigrants from the former USSR
topped 750,000 during the period 1989-97, bringing
the population of Israel from the former Soviet Union
to one million, or one-sixth of the total population.
Initially this great influx increased unemployment,
intensified housing problems, and strained the
government budget. At the same time, the immigrants
bring to the economy scientific and professional
expertise of substantial value for the future.
GDP: purchasing power parity— $96.7 billion
(1997 est.)
GDP— real growth rate: 1.9% (1997 est.)
GDP— per capita: purchasing power parity —
$17,500 (1997 est.)
GDP— composition by sector:
agriculture: 2%
industry: 17%
services: 81 % (1997 est.)
Inflation rate— consumer price index: 9% (1997)
Labor force:
total: 2.3 million (1997)
by occupation: public services 31 .3%, manufacturing
20.2%, finance and business 13.1%, commerce
12.8%, construction 7.5%, personal and other
services 6.4%, transport, storage, and
communications 6.2%, agriculture, forestry, and
fishing 2.6% (1996)
Unemployment rate: 7.7% (1997)
Budget:
revenues: $55 billion
expenditures: $ 58 billion, including capital
expenditures of $NA (1998 est.)
Industries: food processing, diamond cutting and
polishing, textiles and apparel, chemicals, metal
products, military equipment, transport equipment,
electrical equipment, potash mining, high-technology
electronics, tourism
Industrial production growth rate: 5.4% (1996)
Electricity— capacity: 7.736 million kW (1996)
Electricity— production: 32.5 billion kWh (1996)
Electricity— consumption per capita: 5,387 kWh
(1995)
Agriculture— products: citrus and other fruits,
vegetables, cotton; beef, poultry, dairy products
Exports:
total value: $ 20.7 billion (f.o.b., 1997)
commodities: machinery and equipment, cut
diamonds, chemicals, textiles and apparel,
agricultural products, metals
partners : EU 32%, US 31%, Japan 7% (1996)
Imports:
total value: $28 .6 billion (c.i.f., 1997)
commodities: military equipment, investment goods,
rough diamonds, oil, consumer goods
partners: EU 52%, US 20%, Japan (1996)
Debt— external: $18.7 billion (1997)
Economic aid:
recipient: $1.2 billion (1997) from the US
Currency: 1 new Israeli shekel (NIS) = 100 new
agorot
Exchange rates: new Israeli shekels (NIS) per
US$1 -3.5340 (December 1997), 3.4494 (1997),
3.1917(1 996), 3.01 13(1 995), 3.01 1 1 (1 994), 2.8301
(1993)
Fiscal year: calendar year (since 1 January 1992)
Economy— overview: The economy is based
largely on financial services, agriculture, and tourism.
Potatoes, cauliflower, tomatoes, and especially
flowers are important export crops, shipped mostly to
the UK. The Jersey breed of dairy cattle is known
worldwide and represents an important export earner.
Milk products go to the UK and other EU countries. In
1986 the finance sector overtook tourism as the main
contributor to GDP, accounting for 40% of the island''s
output. In recent years, the government has
encouraged light industry to locate in Jersey, with the
result that an electronics industry has developed
alongside the traditional manufacturing of knitwear. All
raw material and energy requirements are imported,
as well as a large share of Jersey''s food needs. Light
tax and death duties make the island a popular tax
haven.
GDP: purchasing power parity— $NA
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity — $NA
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $643.7 million
expenditures: $597.2 million, including capital
expenditures of $NA (1995 est.)
Industries: tourism, banking and finance, dairy
Industrial production growth rate: NA%
Electricity— capacity: 50,000 kW standby
note: electricity supplied by France
Electricity— production: NA kWh
note: electricity supplied by France
Electricity— consumption per capita: NA kWh
(1992)
Agriculture— products: potatoes, cauliflowers,
tomatoes; meat, dairy products
Exports: $NA
commodities: light industrial and electrical goods,
foodstuffs, textiles
partners: UK
Imports: $NA
commodities: machinery and transport equipment,
manufactured goods, foodstuffs, mineral fuels,
chemicals
partners: UK
Debt— external: $NA
Economic aid: none
Currency: 1 Jersey pound (£J) = 100 pence
Exchange rates: Jersey pounds (£J) per US$1 —
0.6115 (January 1 998), 0.61 06 (1 997), 0.6403 (1 996),
0.6335 (1995), 0.6529 (1994), 0.6658 (1993); the
Jersey pound is at par with the British pound
Fiscal year: 1 April— 31 March
Economy— overview: Economic activity is limited to
providing services to US military personnel and
contractors located on the island. All food and
manufactured goods must be imported.
Electricity— capacity: NA kW
note; electricity supplied by the base operating
support contractor
Electricity— production: six 25,000 kWh
generators
note: electricity supplied by the base operating
support contractor
Economy— overview: Kuwait is a small and
relatively open economy with proved crude oil
reserves of about 94 billion barrels— 10% of world
reserves. Kuwait has rebuilt its war-ravaged
petroleum sector; its crude oil production averaged 2
million barrels per day in 1996. Petroleum accounts
for nearly half of GDP, 90% of export revenues, and
75% of government income. Kuwait lacks water and
has practically no arable land, thus preventing
development of agriculture. With the exception of fish,
it depends almost wholly on food imports. About 75%
of potable water must be distilled or imported.
Because of its high per capita income, Kuwait
provides its citizens with extensive health,
educational, and retirement benefits. The bulk of the
work force is non-Kuwaiti, living at a considerably
lower level. Per capita military expenditures are
among the highest in the world. The economy
improved moderately in 1994-97, with the growth in
industry and finance. The World Bank has urged
Kuwait to push ahead with privatization, including in
the oil industry, but the government will move slowly
on opening the petroleum sector.
GDP: purchasing power parity— $46.3 billion (1997
est.)
GDP— real growth rate: 1% (1997 est.)
GDP— per capita: purchasing power parity —
$22,300 (1997 est.)
GDP— composition by sector:
agriculture: 0%
industry: 53%
services: 47% (1996)
Inflation rate— consumer price index: 3.2%
(1996)
Labor force:
total: 1.1 million (1996 est.)
by occupation: government and social services 50%,
services 40%, industry and agriculture 10% (1996
est.)
note: 68% of the population in the 15-64 age group is
non-national (July 1998 est.)
Unemployment rate: 1 .8% (official 1996 est.)
Budget:
revenues: $10.3 billion
expenditures: $14.5 billion, including capital
expenditures of $NA (FY97/98 est.)
Industries: petroleum, petrochemicals, desalination,
food processing, construction materials, salt,
construction
260
Industrial production growth rate: 1% (1997 est.)
Electricity— capacity: 6.988 million kW (1995)
Electricity— production: 25 billion kWh (1995)
Electricity— consumption per capita: 13,756 kWh
(1995)
Agriculture— products: practically no crops;
extensive fishing in territorial waters
Exports:
total value: $ 14.7 billion (f.o.b., 1996)
commodities: oil and refined products, fertilizers
partners: Japan 29%, US 16%, Netherlands 13%,
Singapore 12% (1996 est.)
Imports:
total value: $7.7 billion (f.o.b., 1996)
commodities: food, construction materials, vehicles
and parts, clothing
partners : US 31%, UK 14%, Japan 13%, Germany
8%, Italy 7% (1996 est.)
Debt— external: $8 billion (1995 est.)
Economic aid: $NA
Currency: 1 Kuwaiti dinar (KD) = 1 ,000 fils
Exchange rates: Kuwaiti dinars (KD) per US$1 —
0.3055 (January 1998), 0.3033 (1997), 0.2994 (1996),
0.2984 (1995), 0.2976 (1994), 0.3017 (1993)
Fiscal year: 1 July— 30 June
Economy— overview: New Caledonia has more
than 20% of the world''s known nickel resources. In
recent years, the economy has suffered because of
depressed international demand for nickel, the
principal source of export earnings. Only a negligible
amount of the land is suitable for cultivation, and food
accounts for about 25% of imports. In addition to
nickel, financial support from France and tourism are
key to the health of the economy. The outlook for 1 998
is clouded by the spillover of financial problems in
East Asia and by lower expected prices for nickel.
GDP: purchasing power parity— $1 .5 billion (1 995
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $8,000
(1995 est.)
GDP— composition by sector:
agriculture: 5%
industry: 35%
services: 60% (1992 est.)
Inflation rate— consumer price index: 1 .7% (1 996
est.)
Labor force:
total: 70,044 (1988)
by occupation: agriculture 32%, industry 20%,
services 40%, mining 8% (1992)
Unemployment rate: 15% (1994)
Budget:
revenues: $755.6 million
expenditures: $ 755.6 million, including capital
expenditures of $NA (1995 est.)
Industries: nickel mining and smelting
Industrial production growth rate: NA%
Electricity— capacity: 253,000 kW (1995)
Electricity— production: 1.145 billion kWh (1995)
Electricity— consumption per capita: 6,204 kWh
(1995)
Agriculture— products: vegetables; beef, other
livestock products
Exports:
total value: $500 million (f.o.b., 1996)
commodities: ferronickels, nickel ore
partners: Japan 31%, France 29%, US 1 2%, Australia
7%, Taiwan 6% (1996 est.)
Imports:
total value: $930 million (c.i.f., 1996)
339
New Caledonia (continued)
commodities: foods, transport equipment, machinery
and electrical equipment, fuels, minerals
partners: France 45%, Australia 18%, Singapore 7%,
New Zealand 6%, Japan 4% (1 996 est.)
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
note: important support from France
Currency: 1 CFP franc (CFPF) = 100 centimes
Exchange rates: Comptoirs Francais du Pacifique
francs (CFPF) per US$1— 110.60 (January 1998),
106.11 (1997), 93.00 (1996), 90.75 (1995), 100.93
(1994), 102.96 (1993); note— linked at the rate of
18.18 to the French franc
Fiscal year: calendar year
Economy— overview: Today, Slovenia exhibits the
highest per capita GDP of all the transition economies
of the region, fairly moderate inflation, and a
comfortable level of international reserves. However,
GDP has posted slower growth since reaching a
zenith of 5.5% in 1994. Growth declined to 3.5% in
1995 and 3.2% in 1996 and in 1997. Exports in 1997
benefited from economic recovery abroad— especially
of Slovenia''s main trading partners of the EU, which
take 70% of Slovene exports. This export-led trend is
predicted to continue, with an expected GDP growth
rate of 3.8% for 1998. Slovenia received an invitation
in 1997 to begin accession negotiations with the EU—
a further reflection of Slovenia''s sound economic
footing. Slovenia must press on with privatization,
enterprise restructuring, institution reform, and
liberalization of financial markets, thereby creating
conditions conducive to foreign investment, and
maintaining a stable tolar.
GDP: purchasing power parity— $19.5 billion (1997
est.)
GDP— real growth rate: 3.25% (1997 est.)
GDP— per capita: purchasing power parity —
$10,000 (1997 est.)
GDP— composition by sector:
agriculture: 5%
industry: 33%
services: 62% (1996)
Inflation rate— consumer price index: 9.7%
(1996)
425
Slovenia (continued)
Labor force:
total: 857,400
by occupation: services 62%, industry 36%,
agriculture 2% (1995)
Unemployment rate: 7.1% (1997 est.)
Budget:
revenues: $8.48 billion
expenditures: $8.53 billion, including capital
expenditures of $455 million (1 996 est.)
Industries: ferrous metallurgy and rolling mill
products, aluminum reduction and rolled products,
lead and zinc smelting, electronics (including military
electronics), trucks, electric power equipment, wood
products, textiles, chemicals, machine tools
Industrial production growth rate: 0.8% (1996)
Electricity— capacity: 2.524 million kW (1995)
Electricity— production: 11.615 billion kWh (1995)
Electricity— consumption per capita: 5,759 kWh
(1995)
Agriculture— products: potatoes, hops, wheat,
sugar beets, corn, grapes; cattle, sheep, poultry
Exports:
total value: $ 8.3 billion (f.o.b., 1996)
commodities: manufactured goods 50.7%, machinery
and transport equipment 31.4%, chemicals 10.5%,
food 3.8% (1995)
partners: Germany 31%, former Yugoslavia 16.5%,
Italy 13%, Croatia 10%, France 7%, Austria 7%, US
5% (1996)
Imports:
total value: $ 9.5 billion (f.o.b., 1996)
commodities: machinery and transport equipment
33.8%, manufactured goods 30.4%, chemicals
12.1%, fuels and lubricants 6.6%, food 8.4% (1995)
partners: Germany 22%, Italy 17%, France 10%,
Austria 10%, Croatia 6%, US 3% (1996)
Debt— external: $4.5 billion (1996 est.)
Economic aid:
recipient: ODA, $5 million (1993)
Currency: 1 tolar (SIT) = 100 stotins
Exchange rates: tolars (SIT) per US$1— 171 .30
(January 1 998), 1 59.69 (1 997), 1 35.36 (1 996), 1 1 8.52
(1995), 128.81 (1994), 113.24(1993)
Fiscal year: calendar year
Economy— overview: In this small landlocked
economy subsistence agriculture occupies more than
60% of the population. Manufacturing features a
number of agroprocessing factories. Mining has
declined in importance in recent years; high-grade
iron ore deposits were depleted by 1978, and health
concerns have cut world demand for asbestos.
Exports of soft drink concentrate, sugar and wood
pulp are the main earners of hard currency.
Surrounded by South Africa, except for a short border
with Mozambique, Swaziland is heavily dependent on
South Africa from which it receives nearly 90% of its
imports and to which it sends more than half of its
exports. Remittances from Swazi workers in South
African mines supplement domestically earned
income by as much as 20%. The government is trying
to improve the atmosphere for foreign investment.
Overgrazing, soil depletion, and drought persist as
problems for the future.
GDP: purchasing power parity— $3.9 billion (1997
est.)
GDP— real growth rate: 3% (19976 est.)
GDP— per capita: purchasing power parity— $3,800
(1997 est.)
GDP— composition by sector:
agriculture: 10%
industry: 42%
services: 48% (1997 est.)
Inflation rate— consumer price index: 9.5%
(1997)
Labor force:
total: 135,000 (1996)
by occupation: private sector about 70%, public
sector about 30%
Unemployment rate: 22% (1995 est.)
Budget:
revenues: $400 million
expenditures: $450 million, including capital
expenditures of $1 15 million (FY96/97)
Industries: mining (coal and asbestos), wood pulp,
sugar, soft drink concentrates
Industrial production growth rate: 3.7% (FY95/
96)
Electricity— capacity: 130,000 kW (1995)
Electricity— production: 407 million kWh (1995)
note: imports 60% of its electricity from South Africa
Electricity— consumption per capita: 1 ,062 kWh
(1995)
Agriculture— products: sugarcane, cotton, maize,
tobacco, rice, citrus, pineapples, corn, sorghum,
peanuts; cattle, goats, sheep
Exports:
total value: $893 million (f.o.b., 1996)
commodities: soft drink concentrates, sugar, wood
pulp, cotton yarn (1995)
partners: South Africa 58%, EU 20%, Mozambique
6% (1994)
imports:
total value: $1 A billion (f.o.b., 1996)
commodities : motor vehicles, machinery, transport
equipment, foodstuffs, petroleum products, chemicals
(1995)
partners: South Africa 88%, Japan, UK, US (FY94/95)
Debt— external: $194 million (1995)
Economic aid:
recipient: ODA, $NA
Currency: 1 lilangeni (E) = 100 cents
Exchange rates: emalangeni (E) per US$1— 4.9417
(January 1998), 4.5998 (1997), 4.2706 (1996), 3.6266
(1995), 3.5490 (1994), 3.2636 (1993); note— the
Swazi emalangeni are at par with the South African
rand
Fiscal year: 1 April— 31 March
Economy-overview: Aided by peace and
neutrality for the whole twentieth century, Sweden has
achieved an enviable standard of living under a mixed
system of high-tech capitalism and extensive welfare
benefits. It has a modern distribution system,
excellent internal and external communications, and a
skilled labor force. Timber, hydropower, and iron ore
constitute the resource base of an economy heavily
oriented toward foreign trade. Privately owned firms
account for about 90% of industrial output, of which
the engineering sector accounts for 50% of output and
exports. Agriculture accounts for only 2% of GDP and
2% of the jobs. In recent years, however, this
extraordinarily favorable picture has been clouded by
budgetary difficulties, inflation, high unemployment,
and a gradual loss of competitiveness in international
markets. To curb the budget deficit and bolster
confidence in the economy, the government adopted
an adjustment program in November 1994 that aims
to eliminate the government budget deficit and to
stabilize the debt to GDP ratio. Sweden has
harmonized its economic policies with those of the
EU, which it joined at the start of 1995. Sweden has
decided not to join the EMU (European Monetary
Union). Annual GDP growth should edge up to 2.5%
in 1998-99.
GDP: purchasing power parity— $1 76.2 billion (1 997
est.)
GDP— real growth rate: 2.1% (1997 est.)
GDP— per capita: purchasing power parity —
$19,700 (1997 est.)
GDP— composition by sector:
agriculture: 2%
industry: 27%
services: 71% (1993)
Inflation rate— consumer price index: 2% (1997
est.)
Labor force:
total: 4.552 million (84% unionized, 1992)
by occupation: community, social and personal
services 38.3%, mining and manufacturing 21.2%,
commerce, hotels, and restaurants 14.1%, banking,
insurance 9.0%, communications 7.2%, construction
7.0%, agriculture, fishing, and forestry 3.2% (1991)
Unemployment rate: 6.6% plus about 5% in training
programs (1997 est.)
Budget:
revenues; $109.4 billion
expenditures: $146.1 billion, including capital
expenditures of $NA (FY95/96)
Industries: iron and steel, precision equipment
(bearings, radio and telephone parts, armaments),
wood pulp and paper products, processed foods,
motor vehicles
Industrial production growth rate: 2.6% (1996)
Electricity— capacity: 35.462 million kW (1995)
Electricity— production: 142.913 billion kWh
(1995)
Electricity— consumption per capita: 15,996 kWh
(1995)
Agriculture— products: grains, sugar beets,
potatoes; meat, milk
Exports:
total value: $84.5 billion (f.o.b., 1996)
commodities: machinery, motor vehicles, paper
448
products, pulp and wood, iron and steel products,
chemicals, petroleum and petroleum products
partners: EU 59.1% (Germany 13.2%, UK 10.2%,
Denmark 6.9%, France 5.1%), Norway 8.1%, Finland
4.8%, US 8.0% (1994)
Imports:
total value: $66. 6 billion (c.i.f., 1996)
commodities: machinery, petroleum and petroleum
products, chemicals, motor vehicles, foodstuffs, iron
and steel, clothing
partners : EU 62.6% (Germany 18.4%, UK 9.5%,
Denmark 6.6%, France 5.5%), Finland 6.3%, Norway
6.1%, US 8.5% (1994)
Debt— external: $66.5 billion (1994)
Economic aid:
donor: ODA, $1 .769 billion (1 993)
Currency: 1 Swedish krona (SKr) = 100 oere
Exchange rates: Swedish kronor (SKr) per US$1 —
8.0085 (January 1 998), 7.6349 (1 997), 6.7060 (1 996),
7.1333 (1995), 7.7160 (1994), 7.7834 (1993)
Fiscal year: 1 January— 31 December (Sweden
changed its fiscal year from 1 July— 30 June in 1 995)','26f65eb21feeb5da6710b564cbb659da7ed84b7241a3bb3d3032b70187bdb2a9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('448a37e8aac3e46a80770ccd7fb47a8a6d8d238c9ddc2e8a957f054217a3dc1e',1998,'FI','Finland','economy',383,'Economy— overview: Finland has a highly
industrialized, largely free-market economy, with per
capita output roughly that of the UK, France,
Germany, and Italy. Its key economic sector is
manufacturing— principally the wood, metals, and
engineering industries. Trade is important, with the
export of goods representing about 30% of GDP.
Except for timber and several minerals, Finland
depends on imports of raw materials, energy, and
some components for manufactured goods. Because
of the climate, agricultural development is limited to
maintaining self-sufficiency in basic products.
Forestry, an important export earner, provides a
secondary occupation for the rural population. The
economy has come back from the recession of
1990-92, which had been caused by economic
overheating, depressed foreign markets, and the
dismantling of the barter system between Finland and
the former Soviet Union under which Soviet oil and
gas had been exchanged for Finnish manufactured
goods. The Finns voted in an October 1994
referendum to enter the EU, and Finland officially
joined the Union on 1 January 1995. Attempts to cut
the unacceptably high rate of unemployment and
increasing integration with Western Europe will
dominate the economic picture over the next few
years. Despite high unemployment and moderate
GDP growth of 3.9% anticipated for 1998, inflation is
forecast to rise to 2.5%
GDP: purchasing power parity— $102.1 billion (1997
est.)
GDP— real growth rate: 4.6% (1997 est.)
GDP— per capita: purchasing power parity —
$20,000 (1997 est.)
GDP— composition by sector:
agriculture: 7%
industry: 37%
services: 5Q% (19%)
Inflation rate— consumer price index: 1 .2% (1 997
est.)
Labor force:
total: 2.533 million
by occupation: public services 30.4%, industry 20.9%,
commerce 15.0%, finance, insurance, and business
services 10.2%, agriculture and forestry 8.6%,
transport and communications 7.7%, construction
7.2%
Unemployment rate: 14.6% (1997 est.)
Budget:
revenues; $33 billion
expenditures: $40 billion, including capital
expenditures of $NA (1996 est.)
Industries: metal products, shipbuilding, pulp and
paper, copper refining, foodstuffs, chemicals, textiles,
clothing
Industrial production growth rate: 7.4% (1995)
161
Finland (continued)
Electricity— capacity: 14.143 million kW (1995)
Electricity-production: 58.626 billion kWh (1995)
Electricity— consumption per capita: 13,181 kWh
(1995)
Agriculture— products: cereals, sugar beets,
potatoes; dairy cattle; annual fish catch about 1 60,000
metric tons
Exports:
total value: $38.4 billion (f.o.b., 1996)
commodities: paper and pulp, machinery, chemicals,
metals, timber
partners: EU 46.5% (Germany 13.4%, UK 10.4%),
Sweden 10.1%, US 6.7%, Japan 2.6%, Russia 4.8%
(1995)
Imports:
total value: $ 29.3 billion (c.i.f., 1996)
commodities: foodstuffs, petroleum and petroleum
products, chemicals, transport equipment, iron and
steel, machinery, textile yarn and fabrics, fodder
grains
partners: EU 44% (Germany 16.6%, UK 8.0%),
Sweden 1 1.7%, US 7.1%, Russia 7.1%, Japan 6.3%
(1995)
Debt— external: $30 billion (December 1993)
Economic aid:
donor: ODA, $355 million (1993)
Currency: 1 markka (FMk) or Finmark = 100 pennia
Exchange rates: markkaa (FMk) per US$1— 5.4948
(January 19987), 5.1914 (1997), 4.5936 (1996),
4.3667 (1995), 5.2235 (1994), 5.7123 (1993)
Fiscal year: calendar year
Debt-external: $NA
Economic aid:
recipient: ODA, $122 million (1993)
note: commitments from the West and international
institutions, $525 million (1992-95)
Currency: 1 Latvian lat (LVL) = 100 santims;
introduced NA March 1993
Exchange rates: lats (LVL) per US$1— 0.595
(January 1998), 0.581 (1997), 0.551 (1996), 0.528
(1995), 0.560 (1994), 0.675 (1993)
Fiscal year: calendar year
Economy-overview: The 1975-91 civil war
seriously damaged Lebanon''s economic
infrastructure, cut national output by half, and all but
ended Lebanon’s position as a Middle Eastern
entrepot and banking hub. Peace has enabled the
central government to restore control in Beirut, begin
collecting taxes, and regain access to key port and
government facilities. Economic recovery has been
helped by a financially sound banking system and
resilient small- and medium-scale manufacturers, with
family remittances, banking services, manufactured
and farm exports, and international aid as the main
sources of foreign exchange. Lebanon''s economy has
made impressive gains since Prime Minister HARIRI
launched his $1 8 billion "Horizon 2000" reconstruction
program in 1 993. Real GDP grew 8% in 1 994 and 7%
in 1995 before Israel''s Operation Grapes of Wrath in
April 1 996 stunted economic activity. During 1 992-97,
annual inflation fell from more than 170% to 9%, and
foreign exchange reserves jumped to more than $4
billion from $1 .4 billion. Burgeoning capital inflows
have generated foreign payments surpluses, and the
Lebanese pound has remained relatively stable.
Progress also has been made in rebuilding Lebanon''s
war-torn physical and financial infrastructure.
Solidere, a $2-biliion firm, is managing the
reconstruction of Beirut''s central business district; the
stock market reopened in January 1996; and
international banks and insurance companies are
returning. The government nonetheless faces serious
challenges in the economic arena. It has had to fund
reconstruction by tapping foreign exchange reserves
and boosting borrowing. The stalled peace process
and ongoing violence In southern Lebanon could lead
to wider hostilities that would disrupt vital capital
inflows. Furthermore, the gap between rich and poor
has widened since HARIRI took office, resulting in
grassroots dissatisfaction over the skewed distribution
of the reconstruction''s benefits and leading the
government to shift its focus from rebuilding
infrastructure to improving living conditions.
GDP: purchasing power parity— $15.2 billion
(1997 est.)
GDP— real growth rate: 4% (1997 est.)
GDP— per capita: purchasing power parity— $4,400
(1997 est.)
GDP— composition by sector:
agriculture: 4%
industry: 23%
services: 73% (1997 est.)
Inflation rate— consumer price index: 9%
(1997 est.)
Labor force:
total: 1 million plus as many as 1 million foreign
workers (1996 est.)
by occupation: services 62%, industry 31%,
agriculture 7% (1997 est.)
Unemployment rate: 18% (1997 est.)
Budget:
revenues: $2.4 billion
expenditures: $5.9 billion, including capital
expenditures of $NA (1997 est.)
Industries: banking; food processing; jewelry;
cement; textiles; mineral and chemical products;
wood and furniture products; oil refining; metal
fabricating
Industrial production growth rate: 25%
(1993 est.)
Electricity— capacity: 1.35 million kW (1997)
Electricity— production: 5 billion kWh (1995)
Electricity— consumption per capita: 1 ,380 kWh
(1995)
Agriculture— products: citrus, vegetables,
potatoes, olives, tobacco, hemp (hashish); sheep,
goats
Exports:
total value: $1.01 8 billion (f.o.b., 1996)
commodities: paper and paper products 26%, food
stuffs 16%, textiles and textile products 10%, jewelry
8%, metals and metal products 8%, electrical
equipment and products 8%, chemical products 6%,
transport vehicles 4% (1995)
partners: UAE 23%, Saudi Arabia 14%, Kuwait 8%,
Syria 7%, Jordan 5%, France 5%, Italy 4%, US 3%
(1996)
Imports:
total value : $7,559 billion (c.i.f., 1996)
commodities : machinery and transport equipment
28%, foodstuffs 20%, consumer goods 19%,
chemicals 9%, textiles 5%, metals 5%, fuels 3%
(1995)
partners: Italy 12%, US 11%, Germany 9%, France
8%, Syria 4%, UK 4%, Japan 4% (1996)
Debt— external: $2.3 billion (1997 est.)
Economic aid:
recipient: aid pledges of $3.5 billion for 1997-2001
Currency: 1 Lebanese pound (£L) = 100 piasters
Exchange rates: Lebanese pounds (£L) per US$1 —
1,526.1 (January 1998), 1,539.5 (1997), 1,571.4
(1996), 1,621 .4 (1995), 1,680.1 (1994), 1,741.4
(1993)
Fiscal year: calendar year','fda02ef657500f8edb6c8dbfacb7c16a1fbf501706903e2df83e43d209dc0e1d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72ad4232aa47277f5ef2d279393914dc1d1adf9ffcef8945af114dd4434fb141',1998,'WF','Wallis and Futuna','economy',387,'Economy— overview: One of the four West
European trillion-dollar economies, France matches a
growing services sector with a diversified industrial
base and substantial agricultural resources. Services
now account for more than 70% of GDP, while
industry generates about one-quarter of GDP and
more than 80% of export earnings. The government
retains considerable influence over key segments of
each sector, with majority ownership of railway,
electricity, aircraft, and telecommunication firms. It
nevertheless has been slowly relaxing its control over
these sectors since the early 1990s, most recently
selling 23% of France Telecom. The government also
plans to sell its stakes in Air France and in the
insurance, banking, and defense industries.
Meanwhile, large tracts of fertile land, the application
of modern technology, and subsidies have combined
to make France the leading agricultural producer in
Western Europe. A major exporter of wheat and dairy
products, France is virtually self-sufficient in
agriculture. The economy expanded by 2.3% last
year, following a 1 .3% gain in 1996. Persistently high
unemployment still poses a major problem for the
government, however, as does the need to control
government spending to keep the economy
internationally competitive and meet membership
qualifications for the European Economic and
Monetary Union (EMU) which is slated to introduce a
common European currency in January 1999.
Succeeding governments have shied away from
cutting exceptionally generous social welfare benefits
or the enormous state bureaucracy, preferring to pare
defense spending and raise taxes to keep the deficit
down. The JOSPIN administration has pledged both
to lower unemployment and bring France into EMU,
pinning its hopes for new jobs on economic growth
and on legislation to gradually reduce the workweek
from 39 to 35 hours by 2002.
GDP: purchasing power parity— $1 .32 trillion (1 997
est.)
GDP— real growth rate: 2.3% (1997 est.)
GDP— per capita: purchasing power parity —
$22,700 (1997 est.)
GDP— composition by sector:
agriculture: 2.4%
industry: 26.5%
se/v/ces:71.1% (1994)
Inflation rate— consumer price index: 2% (1996)
Labor force:
total: 25.5 million
by occupation: services 69%, industry 26%,
agriculture 5% (1995)
Unemployment rate: 12.4% (1997)
Budget:
revenues: $222 billion
expenditures: $265 billion, including capital
expenditures of $NA (1998 est.)
Industries: steel, machinery, chemicals,
automobiles, metallurgy, aircraft, electronics, mining,
textiles, food processing, tourism
Industrial production growth rate: 4% (1997 est.)
Electricity— capacity: 102.94 million kW (1995)
Electricity— production: 467.541 billion kWh
(1995)
Electricity— consumption per capita: 6,841 kWh
(1995)
Agriculture— products: wheat, cereals, sugar
beets, potatoes, wine grapes; beef, dairy products;
fish catch of 850,000 metric tons ranks among world''s
top 20 countries and is all used domestically
Exports:
total value: $275 billion (f.o.b., 1997 est.)
commodities: machinery and transportation
equipment, chemicals, foodstuffs, agricultural
products, iron and steel products, textiles and clothing
partners: Germany 17%, Italy 9%, UK 9%, Spain 8%,
Belgium-Luxembourg 8%, US 6%, Netherlands 4.5%,
Japan 2%, Russia 0.7% (1996)
Imports:
total value: $256 billion (f.o.b., 1997 est.)
commodities: crude oil, machinery and equipment,
agricultural products, chemicals, iron and steel
products
partners: Germany 17%, Italy 10%, US 9%,
Belgium-Luxembourg 8%, UK 8%, Spain 7%,
Netherlands 5%, Japan 3%, China 2% (1997 est.)
Debt— external: $117.6 billion (1996 est.)
Economic aid:
donor: ODA, $7,915 billion (1993)
Currency: 1 French franc (F) = 100 centimes
Exchange rates: French francs (F) per US$1 —
6.0836 (January 1998), 5.8367 (1 997), 5.1 155 (1 996),
4.9915 (1995), 5.5520 (1994), 5.6632 (1993)
Fiscal year: calendar year','de4acdd430ed0f82daf7cc804bb192833e03d969892bf0e1ea4d1ca1605a5dac','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('063d6b7679f6afff910797fc1c504faf63b961cb0f9520ec6d586b17768f5f4f',1998,'PF','French Polynesia','economy',398,'Economy— overview: Since 1962, when France
stationed military personnel in the region, French
Polynesia has changed from a subsistence economy
to one in which a high proportion of the work force is
either employed by the military or supports the tourist
industry. Tourism accounts for about 20% of GDP and
is a primary source of hard currency earnings. The
small manufacturing sector primarily processes
agricultural products. The territory will continue to
benefit from a five-year (1994-98) development
agreement with France aimed principally at creating
new jobs.
GDP: purchasing power parity— $1 .76 billion (1995
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $8,000
(1995 est.)
GDP— composition by sector:
agriculture: 4%
industry: 18%
services: 78% (1992 est.)
Inflation rate— consumer price index: 1.5%
(1994)
Labor force:
total: 1 1 8,744 (of which 70,044 are employed) (1 988)
by occupation: agriculture 13%, industry 19%,
services 68% (1992 est.)
Unemployment rate: 15% (1992 est.)
Budget:
revenues: $636 million
expenditures: $643 million, including capital
expenditures of $NA (1994)
Industries: tourism, pearls, agricultural processing,
handicrafts
Industrial production growth rate: NA%
Electricity— capacity: 79,000 kW (1995)
Electricity— production: 330 million kWh (1995)
Electricity— consumption per capita: 1,500 kWh
(1995)
Agriculture— products: coconuts, vanilla,
vegetables, fruits; poultry, beef, dairy products
Exports:
total value: $245 million (f.o.b., 1994)
commodities: cultured pearls 53.8%, coconut
products, mother-of-pearl, vanilla, shark meat (1992)
partners: France 33%, US 8.5% (1994)
Imports:
total value: $ 967 million (c.i.f., 1994)
commodities: fuels, foodstuffs, equipment
partners: France 44.7%, US 13.9% (1994)
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
Currency: 1 CFP franc (CFPF) = 100 centimes
Exchange rates: Comptoirs Francais du Pacifique
francs (CFPF) per US$1 -11 0.60 (January 1998),
106.11 (1997), 93.00 (1996), 90.75 (1995), 100.94
(1994), 102.96 (1993); note— linked at the rate of
18.18 to the French franc
Fiscal year: calendar year','5845ee046afe1acccba90cd60228f8999a2df46540dce5a0f84bf4a07466f49e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('209650146fec07c5d11f7daa2011b70acab6ec8baff0a261410f719220c440e2',1998,'GA','Gabon','economy',405,'Economy— overview: Economic activity is limited to
servicing meteorological and geophysical research
stations and French and other fishing fleets. The fish
catches landed on lies Kerguelen by foreign ships are
exported to France and Reunion.
Budget:
revenues: $14.2 million
expenditures: $NA, including capital expenditures of
$NA (1997)
Economy— overview: Gabon enjoys a per capita
income four times that of most nations of sub-Saharan
Africa. This has supported a sharp decline in extreme
poverty but because of high income inequality a large
proportion of the population remains poor. Gabon
depended on timber and manganese until oil was
discovered offshore in the early 1970s. The oil sector
now accounts for 50% of GDP. Gabon continues to
face fluctuating prices for its oil, timber, manganese,
and uranium exports. Despite the abundance of
natural wealth and a manageable rate of population
growth, the economy is hobbled by poor fiscal
management. In 1992, the fiscal deficit widened to
2.4% of GDP, and Gabon failed to settle arrears on its
bilateral debt, leading to a cancellation of
rescheduling agreements with official and private
creditors. Devaluation of its Francophone currency by
50% on 12 January 1994 sparked a one-time
inflationary surge, to 35%; the rate dropped to 6% in
1996. The IMF provided a one-year standby
arrangement in 1994-95 and a three-year Enhanced
Financing Facility (EFF) at near commercial rates
beginning in late 1995. Those agreements mandate
progress in privatization and fiscal discipline. France
provided additional financial support in January 1997
after Gabon had met IMF targets for mid-1996. In
1997, an IMF mission to Gabon chastened the
government for overspending on off-budget items,
overborrowing from the central bank, and slipping on
its schedule for privatization and administrative reform
(such as reduced public sector employment and
salary growth).
GDP: purchasing power parity— $6 billion (1 996 est.)
GDP— real growth rate: 3% (1996 est.)
GDP— per capita: purchasing power parity— $5,000
(1996 est.)
170
GDP— composition by sector:
agriculture: 7.1%
industry: 54.6%
services: 38.3% (1996)
Inflation rate— consumer price index: 6.2% (1996
est.)
Labor force: NA
by occupation: agriculture 65%, industry and
commerce, services
Unemployment rate: 1 0%-1 4% (1 993 est.)
Budget:
revenues: $1.5 billion
expenditures: $1 .3 billion, including capital
expenditures of $302 million (1996 est.)
Industries: food and beverage; textile; lumbering
and plywood; cement; petroleum extraction and
refining; manganese, uranium, and gold mining;
chemicals; ship repair
Industrial production growth rate: 2.3% (1995)
Electricity— capacity: 310,000 kW (1995)
Electricity— production: 925 million kWh (1995)
Electricity— consumption per capita: 800 kWh
(1995)
Agriculture— products: cocoa, coffee, sugar, palm
oil; rubber; okoume (a tropical softwood); cattle; small
fishing operations (provide a catch of about 30,000
metric tons)
Exports:
total value: $3.1 billion (f.o.b., 1996 est.)
commodities: crude oil 81%, timber 12%, manganese
5%, uranium (1996)
partners: US 50%, France 16%, Japan 8%, China,
Spain, Germany (1994)
Imports:
total value: $969 million (f.o.b., 1 996 est.)
commodities: machinery and equipment, foodstuffs,
chemicals, petroleum products, construction materials
partners: France 39%, Cote d''Ivoire 13%, US 6%,
Netherlands 5%, Japan
Debt— external: $3.9 billion (1996 )
Economic aid: $NA
Currency: 1 Communaute Financiere Africaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1 —
608.36 (January 1 998), 583.67 (1 997), 51 1 .55 (1 996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 1 2 January 1 994, the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: calendar year
Economy— overview: The Gambia has no
important mineral or other natural resources and has
a limited agricultural base. About 75% of the
population depends on crops and livestock for its
livelihood. Small-scale manufacturing activity features
the processing of peanuts, fish, and hides. Reexport
trade normally constitutes a major segment of
economic activity, but the 50% devaluation of the CFA
franc in January 1994 made Senegalese goods more
competitive and hurt the reexport trade. The Gambia
has benefited from a rebound in tourism after its
decline in response to the military''s takeover in July
1994. Short-run economic progress remains highly
dependent on sustained bilateral and multilateral aid
and on responsible government economic
management.
GDP: purchasing power parity— $1 .23 billion (1 997
est.)
GDP— real growth rate: 2.1% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,000
(1997 est.)
GDP— composition by sector:
agriculture: 27%
industry: 15%
services: 58% (1993 est.)
Inflation rate— consumer price index: 2.2%
(1997)
Labor force:
total: NA
by occupation: agriculture 75.0%, industry,
commerce, and services 18.9%, government 6.1%
Unemployment rate: NA%
Budget:
revenues; $88.6 million
expenditures: $98.2 million, including capital
expenditures of $NA (FY96/97 est.)
Industries: processing peanuts, fish, and hides;
tourism; beverages; agricultural machinery assembly,
woodworking, metalworking; clothing
Industrial production growth rate: NA%
Electricity— capacity: 29,000 kW (1995)
Electricity— production: 73 million kWh (1995)
Electricity— consumption per capita: 74 kWh
(1995)
Agriculture— products: peanuts, millet, sorghum,
rice, corn, cassava (tapioca), palm kernels; cattle,
sheep, goats; forest and fishing resources not fully
exploited
Exports:
total value: $ 160 million (f.o.b., 1995)
commodities: peanuts and peanut products 70%, fish,
cotton lint, palm kernels
partners: Japan, Senegal, Hong Kong, France,
Switzerland, UK, Indonesia
Imports:
total value: $140 million (c.i.f., 1995)
commodities: foodstuffs, manufactures, raw
materials, fuel, machinery and transport equipment
partners: China, Cote d''Ivoire, Hong Kong, UK,','8bef245849c4047166469e5456cf3976fa42c7ac85755097e7cbaed522b2d215','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac1d805988527038c6f5a9cda40d45974d1575691365cbe51ec25df551e9ceb7',1998,'GE','Georgia','economy',414,'Economy— overview: Georgia''s economy has
traditionally revolved around Black Sea tourism;
cultivation of citrus fruits, tea, and grapes; mining of
manganese and copper; and output of a small
industrial sector producing wine, metals, machinery,
chemicals, and textiles. The country imports the bulk
of its energy needs, including natural gas and oil
products. Its only sizable internal energy resource is
hydropower. Despite the severe damage the
economy has suffered due to civil strife, Georgia, with
the help of the IMF and World Bank, has made
substantial economic gains in 1995-97, increasing
GDP growth and slashing inflation. Georgia still
suffers from energy shortages, although energy
deliveries are steadily improving. Georgia is pinning
its hopes for long-term recovery on the development
of an international transportation corridor through the
key Black Sea ports of P''ot''i and Bat''umi. The
construction of a Caspian oil pipeline through
Georgia— scheduled to open in early 1999— should
spur greater western investment in the economy. A
growing trade deficit, continuing problems with
corruption, and political uncertainties cloud the
short-term economic picture.
GDP: purchasing power parity— $8.1 billion (1997
est.)
GDP— real growth rate: 1 1 .8% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,570
(1997 est.)
GDP— composition by sector:
agriculture: 29%
industry: 16%
services: 55% (1 997 est.)
Inflation rate— consumer price index: 7.1% (1997
est.)
Labor force:
fofa/; 2.2 million (1996)
by occupation: industry and construction 31 %,
agriculture and forestry 25%, other 44% (1990)
Unemployment rate: 16% (1996 est.)
Budget:
revenues : $441 million
expenditures: $606 million, including capital
expenditures of $54 million (1996 est.)
Industries: steel, aircraft, machine tools, foundry
equipment, electric locomotives, tower cranes,
electric welding equipment, machinery for food
preparation and meat packing, electric motors,
process control equipment, trucks, tractors, textiles,
shoes, chemicals, wood products, wine
Industrial production growth rate: 8.1% (1997
est.)
Electricity— capacity: 4.558 million kW (1995)
Electricity— production: 7.1 billion kWh (1996)
Electricity— consumption per capita: 1 ,1 75 kWh
(1995)
Agriculture— products: citrus, grapes, tea,
vegetables, potatoes; small livestock sector
Exports:
total value: $400 million (f.o.b., 1996 est.)
commodities: citrus fruits, tea, wine, other agricultural
products; diverse types of machinery; ferrous and
nonferrous metals; textiles; chemicals; fuel re-exports
partners: Russia, Turkey, Armenia, Azerbaijan,
Bulgaria (1996)
Imports:
total value: $733 million (c.i.f., 1996 est.)
commodities: fuel, grain and other foods, machinery
and parts, transport equipment
partners: Russia, Turkey, Azerbaijan (1996); note—
EU and US send humanitarian food shipments
Debt— external: $1.3 billion (1996 est.)
Economic aid:
recipient: ODA, $28 million (1993)
note: commitments, 1992-95, $1,200 million ($675
million disbursements)
Currency: lari introduced September 1 995 replacing
the coupon
Exchange rates: lari per US$1 (end of period)— 1 .32
(December 1997), 1.28 (December 1996), 1.24
(December 1995)
Fiscal year: calendar year
177
Georgia (continued)','e7824a9f0c036147d6c093a35c29cc606828c0ec71d92c65ab4c62a5dfa10a63','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcda095e23c5b0d51869c851a2b2d68f9ec46d535537e6e476d8e6453ce70077',1998,'GH','Ghana','economy',424,'Economy— overview: Well endowed with natural
resources, Ghana has twice the per capita output of
the poorer countries in West Africa. Even so, Ghana
remains heavily dependent on international financial
and technical assistance. Gold, timber, and cocoa
production are major sources of foreign exchange.
The domestic economy continues to revolve around
subsistence agriculture, which accounts for 41% of
GDP and employs 60% of the work force, mainly small
landholders. In 1995-97, Ghana made mixed progress
under a three-year structural adjustment program in
cooperation with the IMF. On the minus side, public
sector wage increases and regional peacekeeping
commitments have led to continued inflationary deficit
financing, depreciation of the cedi, and rising public
discontent with Ghana''s austerity measures.
GDP: purchasing power parity— $36.2 billion (1997
est.)
GDP— real growth rate: 3% (1997 est.)
GDP— per capita: purchasing power parity— $2,000
(1997 est.)
GDP— composition by sector:
agriculture: 41%
industry: 14%
services: 45% (1996 est.)
inflation rate— consumer price index: 27.7%
(1997 est.)
Labor force:
total: NA
by occupation: agriculture and fishing 61%, industry
10%, services 29% (1996 est.)
Unemployment rate: 20% (1997 est.)
Budget:
revenues: $1.39 billion
expenditures: $1 .47 billion, including capital
expenditures of $370 million (1996 est.)
Industries: mining, lumbering, light manufacturing,
aluminum smelting, food processing
Industrial production growth rate: 4.2% (1996
est.)
Electricity— capacity: 1 .3 million kW (1 997)
Electricity— production: 600 million kWh (1996)
Electricity— consumption per capita: 373 kWh
(1996)
Agriculture— products: cocoa, rice, coffee,
cassava (tapioca), peanuts, corn, shea nuts,
bananas; timber
Exports:
total value: $1 .57 billion (f.o.b., 1996 est.)
commodities: gold 39%, cocoa 35%, timber 9.4%,
tuna, bauxite, aluminum, manganese ore, and
diamonds (1996 est.)
partners: UK, Germany, US, Netherlands, Japan,','6cf312ac3c986eb74c9e3a13cfbb61b8c28f975aa976114e1351f926b1192641','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b346ef5ee6f70cd124340bf14b6b14210b10071d2deb235267e708aeab9a6606',1998,'NG','Nigeria','economy',425,'Imports:
total value: $1 .84 billion (c.i.f., 1995)
commodities: capital equipment, petroleum,
consumer goods, foods, intermediate goods
partners: UK, Nigeria, US, Germany, Japan,
Electricity— consumption per capita: 40 kWh
(1995)
Agriculture— products: cowpeas, cotton, peanuts,
millet, sorghum, cassava (tapioca), rice; cattle, sheep,
goats, camels, donkeys, horses, poultry
Exports:
total value: $ 188 million (f.o.b., 1996)
commodities: uranium ore 67%, livestock products
20%, cowpeas, onions
partners: France 41%, Nigeria 22%, Burkina Faso,
Cote d''Ivoire, Japan 18%
Imports:
total value: $ 374 million (c.i.f., 1996)
commodities: consumer goods, primary materials,
machinery, vehicles and parts, petroleum, cereals
partners: France 24%, Nigeria 19%, Cote d''Ivoire,
China, Belgium-Luxembourg
Debt— external: $1 .3 billion (1996 est.)
Economic aid:
recipient: ODA; bilateral donors: France, Germany,
EU, Japan
Currency: 1 Communaute Financiere Africaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1 —
608.36 (January 1 998), 583.67 (1 997), 51 1 .55 (1 996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 12 January 1994, the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: calendar year
Economy— overview: The oil-rich Nigerian economy
continues to be hobbled by political instability,
corruption, and poor macroeconomic management.
Nigeria''s unpopular military rulers have failed to make
significant progress in diversifying the economy away
from overdependence on the capital intensive oil sector
which provides 30% of GDP, 95% of foreign exchange
earnings, and about 80% of budgetary revenues. The
government''s resistance to initiating greater
transparency and accountability in managing the
country''s multibillion dollar oil earnings continues to limit
economic growth and prevent an agreement with the
IMF and bilateral creditors on debt relief. The largely
subsistence agricultural sector has failed to keep up with
rapid population growth, and Nigeria, once a large net
exporter of food, now must import food. Agricultural
production in 1996 suffered from severe shortages of
fertilizer, and production of fertilizer fell even further in
1997.
GDP: purchasing power parity— $1 32.7 billion (1 996
est.)
GDP— real growth rate: 3.3% (1996 est.)
GDP— per capita: purchasing power parity— $1 ,300
(1996 est.)
GDP— composition by sector:
agriculture: 39%
industry: 31%
services: 30% (1 996 est.)
Inflation rate— consumer price index: 12% (1997
est.)
Labor force:
total: 42.844 million
by occupation: agriculture 54%, industry, commerce,
and services 19%, government 15%
Unemployment rate: 28% (1992 est.)
Budget:
revenues; $13.9 billion (1998 est.)
expenditures: $^.9 billion, including capital
expenditures of $NA billion (1998 est.)
Industries: crude oil, coal, tin, columbite, palm oil,
peanuts, cotton, rubber, wood, hides and skins, textiles,
cement and other construction materials, food products,
footwear, chemicals, fertilizer, printing, ceramics, steel
Industrial production growth rate: 4.1% (1996)
Electricity— capacity: 5.881 million kW (1995)
Electricity— production: 16.21 billion kWh (1996)
Electricity— consumption per capita: 152 kWh
(1995)
Agriculture— products: cocoa, peanuts, palm oil,
corn, rice, sorghum, millet, cassava (tapioca), yams,
rubber; cattle, sheep, goats, pigs; fishing and forest
resources extensively exploited
Exports:
total value: $15 billion (f.o.b., 1996)
commodities: petroleum and petroleum products
95%, cocoa, rubber
partners: US 40%, EU 21% (1995)
Imports:
total value: $ 8 billion (c.i.f., 1996)
commodities: machinery, chemicals, transportation
equipment, manufactured goods, food and animals
partners: EU 50%, US 12%, Japan 7%
Debt— external: $34 billion (1997 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 naira (N) = 100 kobo
Exchange rates: naira (N) per US$1— 21.886
(December 1 997), 21 .886 (1 997), 21 .895 (1 995),
21.996(1994), 22.065 (1993)
Fiscal year: calendar year','d8260668680702923750ee81bc8607ce6df0514493ce10d702b8766dbb86a96c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9d9fad837f22a78151d41678896374b00ba4d1bbd24e1e5f932eff68f40283e',1998,'NL','Netherlands','economy',426,'Debt— external: $5.2 billion (1996 est.)
Economic aid:
recipient: ODA, $472 million (1993)
Currency: 1 new cedi (C) = 100 pesewas
Exchange rates: new cedis per US$1— 2,271 .70
(January 1998), 2,050.17 (1997), 1,637.23 (1996),
1,200.43 (1995), 956.71 (1994), 649.06 (1993)
Fiscal year: calendar year
j: Communications
Telephones: 100,000 (1997 est.)
Telephone system: poor to fair system
domestic: primarily microwave radio relay
international: satellite earth station— 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 4, FM 23, shortwave
0(1997)
Radios: 12.5 million (1997 est.)
Television broadcast stations: broadcast stations
3 (8 repeaters); pay per view (cable/satellite) 1 (1997)
Televisions: 1.9 million (1997 est.)
Economy— overview: This highly developed and
affluent economy is based on private enterprise. The
government makes its presence felt, however,
through many regulations, permit requirements, and
welfare programs affecting most aspects of economic
activity. Industrial activity features food-processing,
oil-refining, and metalworking. The highly mechanized
agricultural sector employs only 2% of the labor force
but provides large surpluses for export and the
domestic food-processing industry. Indeed, the
Netherlands ranks third worldwide in value of
agricultural exports, behind the US and France. Sharp
cuts in subsidy and social security spending have
been accompanied by sustained growth in output and
employment. Growth in 1998 should be a brisk 3.5%.
The Dutch will almost certainly qualify for the first
wave of countries entering the European Monetary
Union (EMU) in 1999.
GDP: purchasing power parity— $343.9 billion (1 997
est.)
GDP— real growth rate: 3.25% (1997)
GDP— per capita: purchasing power parity —
$22,000 (1997 est.)
GDP— composition by sector:
agriculture: 4%
industry: 18%
sendees: 78% (1996)
Inflation rate— consumer price index: 2% (1997)
Labor force:
total: 6.6 million (1997)
by occupation: services 75%, manufacturing and
construction 23%, agriculture 2% (1996)
Unemployment rate: 6.9% (1997)
Budget:
revenues; $103.4 billion
expenditures: $ 112.5 billion, including capita!
expenditures of $NA (1998 draft)
Industries: agroindustries, metal and engineering
products, electrical machinery and equipment,
chemicals, petroleum, fishing, construction,
microelectronics
Industrial production growth rate: 3.75% (1997)
Electricity— capacity: 20.09 million kW (1996 est.)
Electricity— production: 82 billion kWh (1996 est.)
Electricity— consumption per capita: 4,968 kWh
(1996 est.)
Agriculture— products: grains, potatoes, sugar
beets, fruits, vegetables; livestock
Exports:
total value: $203.1 billion (f.o.b., 1997)
commodities: manufactures and machinery,
chemicals; processed food and tobacco, agricultural
products
partners: EU 80% (Germany 29%,
Belgium-Luxembourg 13%, UK 10%), Centra! and
Eastern Europe 4%, US 3% (1996)
Imports:
total value: $1,791 trillion (c.i.f., 1997)
commodities: raw materials and semifinished
products, consumer goods, transportation equipment,
crude oil, food products
partners: EU 64% (Germany 22%,
Belgium-Luxembourg 11%, UK 10%), Central and
Eastern Europe 4%, US 8% (1996)
Debt— external: $0
Economic aid:
donor: ODA, $2.9 billion (1997)
Currency: 1 Netherlands guilder, gulden, or florin (f.)
= 100 cents
Exchange rates: Netherlands guilders, gulden, or
florins (f.) per US$1-2.0462 (January 1998), 1.9513
(1 997), 1 .6859 (1 996), 1 .6057 (1 995), 1 .8200 (1 994),
1.8573(1993)
Fiscal year: calendar year
Economy— overview: Tourism, petroleum
transshipment, and offshore finance are the
mainstays of this small economy, which is closely tied
to the outside world. The islands enjoy a high per
capita income and a well-developed infrastructure as
compared with other countries in the region. Almost all
consumer and capital goods are imported, with
Venezuela and the US being the major suppliers. Poor
soils and inadequate water supplies hamper the
development of agriculture.
GDP: purchasing power parity— $2.4 billion (1997
est.)
GDP— real growth rate: -1.3% (1997 est.)
GDP— per capita: purchasing power parity —
$11,500 (1997 est.)
GDP— composition by sector:
agriculture: 1%
industry: 15%
services: 84% (1 996 est.)
Inflation rate— consumer price index: 3.6%
(1997)
Labor force:
tote/; 89,000
by occupation: government 65%, industry and
commerce 28% (1983)
Unemployment rate: 12.8% (1993)
Budget:
revenues; $277 million
expenditures: $322 million, including capital
expenditures of $14 million (1996 est.)
Industries: tourism (Curacao, Sint Maarten, and
Bonaire), petroleum refining (Curacao), petroleum
transshipment facilities (Curacao and Bonaire), light
manufacturing (Curacao)
337
Netherlands Antilles (continued)
Industrial production growth rate: NA%
Electricity— capacity: 200,000 kW (1995)
Electricity— production: 840 million kWh (1995)
Electricity— consumption per capita: 4,128 kWh
(1995)
Agriculture— products: aloes, sorghum, peanuts,
vegetables, tropical fruit
Exports:
total value: $NA
commodities: petroleum products 98% (1993)
partners: US 39%, Brazil 9%, Colombia 6% (1993)
Imports:
total value: $1 .4 billion (f.o.b., 1 996 est.)
commodities: crude petroleum 64%, food,
manufactures (1993)
partners: Venezuela 26%, US 18%, Colombia 6%,
Netherlands 6%, Japan 5% (1993)
Debt— external: $1.95 billion (December 1995)
Economic aid:
recipient: ODA, $NA; the Netherlands Antilles
received a $97 million Dutch aid package in 1996,
making it the Netherlands'' second largest aid recipient
behind India
Currency: 1 Netherlands Antillean guilder, gulden,
or florin (NAf.) = 100 cents
Exchange rates: Netherlands Antillean guilders,
gulden, or florins (NAf.) per US$1— 1 .790 (fixed rate
since 1989)
Fiscal year: calendar year','b6786c8f23b763fc7e18b75f185268ad7f64fa0e9cc40411c0c016f3079ac4f8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad65a3de9687f0bc6c553b4258f0441941fda7c502e9b71bcb1774abead3d344',1998,'ES','Spain','economy',432,'Economy— overview: Gibraltar benefits from an
extensive shipping trade, offshore banking, and its
position as an international conference center. The
British military presence has been sharply reduced
and now contributes about 1 1 % to the local economy.
The financial sector accounts for 1 5% of GDP; tourism
(more than 5 million visitors in 1995), shipping
services fees, and duties on consumer goods also
generate revenue. Because more than 70% of the
economy is in the public sector, changes in
government spending have a major impact on the
level of employment.
GDP: purchasing power parity— $500 million (1997
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity —
$17,500 (1997 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 2.1%
(1996)
Labor force:
total: 14,800 (including non-Gibraltar laborers)
by occupation: services 60%, industry 40%,
agriculture NEGL
Unemployment rate: 1 3.5% (1 996)
Budget:
revenues: $111.6 million
expenditures: $11 5.6 million, including capital
expenditures of $NA (1 995/96)
Industries: tourism, banking and finance,
ship-building and repairing; support to large UK naval
and air bases; tobacco, mineral waters, beer, canned
fish
Industrial production growth rate: NA%
Electricity— capacity: 30,000 kW (1995)
Electricity— production: 85 million kWh (1995)
Electricity— consumption per capita: 2,667 kWh
(1995)
Agriculture— products: none
Exports:
total value: $ 83.7 million (f.o.b., 1995)
commodities: (principally reexports) petroleum 51%,
manufactured goods 41 %, other 8%
partners: UK, Morocco, Portugal, Netherlands, Spain,
US, FRG
Imports:
total value: $778 million (c.i.f., 1995)
commodities: fuels, manufactured goods, and
foodstuffs
partners: UK, Spain, Japan, Netherlands
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
Currency: 1 Gibraltar pound (£G) = 100 pence
Exchange rates: Gibraltar pounds (£G) per US$1 —
0.61 1 5 (January 1 998), 0.61 06 (1 997), 0.6403 (1 996),
0.6335 (1995), 0.6529 (1994), 0.6658 (1993); note-
the Gibraltar pound is at par with the British pound
Fiscal year: 1 July— 30 June
Economy— overview: no economic activity','0043009b278f9b141f97974ced7c984956ee1a2262ffea83627fccc034cc2fc3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c448fd63fd7bfeeb65bcad0eb39d752c41f7e82081bf420b23aafc75f9b97d64',1998,'GD','Grenada','economy',441,'Economy— overview: The agriculturally based
economy was hurt in 1996 by the emergence of the
pink mealy bug, which destroyed much of the cocoa
harvest. Bananas, a major foreign exchange earner,
also suffered due to falling prices, low production, and
poor quality. Tourism, the leading foreign exchange
earner, continued to do well, as did manufacturing.
Construction boomed in 1996 due to concessions for
low and middle income mortgages. The government
introduced a 5% tax on electricity and telephones and
doubled the general consumption tax, which caused a
small rise in the inflation rate. The tourist industry
faces stiff competition over the next few years.
GDP: purchasing power parity— $300 million (1996
est.)
GDP— real growth rate: 3.1% (1996 est.)
GDP— per capita: purchasing power parity— $3,200
(1996 est.)
GDP— composition by sector:
agriculture: 10.2%
industry: 40.3%
services: 49.5% (1994 est.)
Inflation rate— consumer price index: 3.2% (1996
est.)
Labor force:
total: 36,000
by occupation: services 31%, agriculture 24%,
construction 8%, manufacturing 5%, other 32%
(1985)
Unemployment rate: 20% (1 October 1996)
Budget:
revenues: $75.7 million (1996 est.)
expenditures: $ 126.7 million, including capita!
expenditures of $51 million (1996 est.)
Industries: food and beverages, textiles, light
assembly operations, tourism, construction
Industrial production growth rate: 1 .8% (1992
est.)
Electricity— capacity: 9,000 kW (1995)
Electricity— production: 70 million kWh (1995)
Electricity— consumption per capita: 741 kWh
(1995)
Agriculture— products: bananas, cocoa, nutmeg,
mace, citrus, avocados, root crops, sugarcane, corn,
vegetables
Exports:
total value: $24 million (f.o.b., 1996 est.)
commodities: bananas, cocoa, nutmeg, fruit and
vegetables, clothing, mace
partners: Caricom 32.3%, UK 20%, US 13%,
Netherlands 8.8% (1991)
Imports:
total value: $ 128 million (f.o.b., 1996 est.)
commodities: food 25%, manufactured goods 22%,
machinery 20%, chemicals 10%, fuel 6% (1989)
partners: US 31.2%, Caricom 23.6%, UK 13.8%,
Japan 7.1% (1991)
Debt— external: $97 million (1996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars (EC$) per
US$1— 2.7000 (fixed rate since 1976)
Fiscal year: calendar year','0cef5970f258ead77c53d539cbfed9f3e85d285d8b72b64371a62eb00dd1b2a7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89414d70c784c80bb504fb6cdb72ef004b5896a06b085adb23d7e412ffe44087',1998,'GU','Guam','economy',450,'Economy— overview: The economy depends
mainly on US military spending and on revenue
generated by the tourism industry. Over the past 20
years, the tourist industry has grown rapidly, creating
a construction boom for new hotels and the expansion
of older ones. More than one million tourists visit
Guam each year. Most food and industrial goods are
imported, with about 75% from the US. Guam faces
the problem of building up the civilian economic sector
to offset the impact of military downsizing.
GDP: purchasing power parity— $3 billion (1 996 est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity —
$19,000 (1996 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 4% (1992
est.)
Labor force:
total: 65,660 (1995)
by occupation: federal and territorial government
31%, private 69% (trade 21%, services 33%,
construction 12%, other 3%) (1995)
Unemployment rate: 2% (1992 est.)
Budget:
revenues: $524.3 million
expenditures: $361 .4 million, including capital
expenditures of $NA (1995)
Industries: US military, tourism, construction,
transshipment services, concrete products, printing
and publishing, food processing, textiles
Industrial production growth rate: NA%
Electricity— capacity: 302,000 kW (1995)
Electricity— production: 755 million kWh (1995)
Electricity— consumption per capita: 4,925 kWh
(1995)
Agriculture— products: fruits, copra, vegetables;
eggs, pork, poultry, beef
Exports:
total value: $ 86.1 million (f.o.b., 1992)
commodities: mostly transshipments of refined
petroleum products, construction materials, fish, food
and beverage products
partners: US 25%, former T rust T erritory of the Pacific
Islands 63%, other 12%
Imports:
total value: $202.4 million (c.i.f., 1992)
commodities: petroleum and petroleum products,
food, manufactured goods
partners: US 23%, Japan 19%, other 58%
Debt— external: $NA
Economic aid:
recipient: although Guam receives no foreign aid, it
does receive large transfer payments from the general
revenues of the US Federal Treasury into which
Guamanians pay no income or excise taxes; under
the provisions of a special law of Congress, the
Guamanian Treasury, rather than the US Treasury,
receives federal income taxes paid by military and
civilian Federal employees stationed in Guam
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October— 30 September
194
C o m m u n i c a t i o n s
Telephones: 74,317 (March 1997)
Telephone system:
domestic: NA
international: satellite earth stations— 2 Intelsat
(Pacific Ocean); submarine cables to US and Japan
Radio broadcast stations: AM 3, FM 3,
shortwave 0
Radios: 206,000(1994)
Television broadcast stations: 3
Televisions: 97,000 (1994 est.)
Economy— overview: The agricultural sector
accounts for one-fourth of GDP and two-thirds of
exports and employs more than half of the labor force.
Coffee, sugar, and bananas are the main products.
Manufacturing and construction account for one-fifth
of GDP. Since assuming office in January 1996,
President ARZU has worked to implement a program
of economic liberalization and political modernization.
The signing of the Peace Accords in December 1 996,
which ended 36 years of civil war, removed a major
obstacle to foreign investment. In 1997, Guatemala
met its economic targets when GDP growth
accelerated to 4.1% and inflation fell to 9%. The
government also increased tax revenues— historically
the lowest in Latin America— to 9% of GDP and
created a new tax administration. It also successfully
placed $1 50 million in dollar-denominated notes in the
international markets. Debt service costs should
decline in 1998. Remaining challenges for the
administration in 1998 include completing a deal with
the IMF and stabilizing monetary policy. Throughout
1997, the Central Bank maintained a tight money
supply, helping to control inflation, but it also caused
high interest rates and led to operating losses for the
bank. Early in 1 998, it relaxed its monetary policy in an
effort to correct these problems, but increased
pressure on the quetzal has prompted the bank to
intervene to prop up its value.
GDP: purchasing power parity— $45.8 billion (1997
est.)
GDP— real growth rate: 4.1% (1997 est.)
GDP— per capita: purchasing power parity— $4,000
(1997 est.)
GDP— composition by sector:
agriculture: 24%
industry: 21%
services: 55% (1997 est.)
Inflation rate— consumer price index: 9% (1997
est.)
Labor force:
total: 3.32 million (1997 est.)
by occupation: agriculture 58%, services 14%,
manufacturing 14%, commerce 7%, construction 4%,
transport 2.6%, utilities 0.3%, mining 0.1% (1995)
Unemployment rate: 5.2% (1997 est.)
Budget:
revenues: $NA
expenditures: $NA
Industries: sugar, textiles and clothing, furniture,
chemicals, petroleum, metals, rubber, tourism
Industrial production growth rate: 1.9% (1996)
Electricity— capacity: 766,000 kW (1995)
Electricity— production: 3.1 billion kWh (1995)
Electricity— consumption per capita: 282 kWh
(1995)
Agriculture— products: sugarcane, corn, bananas,
196
coffee, beans, cardamom; cattle, sheep, pigs,
chickens
Exports:
total value: $2.9 billion (f.o.b., 1997 est.)
commodities: coffee, sugar, bananas, cardamom,
petroleum
partners: US 37%, El Salvador 13%, Honduras 7%,
Costa Rica 5%, Germany 5%
Imports:
total value: $ 3.3 billion (c.i.f., 1997 est.)
commodities: fuel and petroleum products,
machinery, grain, fertilizers, motor vehicles
partners: US 44%, Mexico 10%, Venezuela 4.6%,
Japan, Germany
Debt-external: $3.38 billion (1996 est.)
Economic aid:
recipient: ODA, $274 million (1994)
Currency: 1 quetzal (Q) = 100 centavos
Exchange rates: free market quetzales (Q) per
US$1 -6.2580 (January 1998), 6.0653 (1997),
6.0495 (1996), 5.8103 (1995), 5.7512 (1994), 5.6354
(1993)
Fiscal year: calendar year','e4218094ab4b96288b90f32fc6e6ec710e726e1768259abbcfc760eef65761ae','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35235a7f4e624086cb91608b81bc2c212b627f46a6839aa8bec04b338a7d4c8c',1998,'GG','Guernsey','economy',458,'Economy— overview: Financial services account
for about 55% of total income. Tourism,
manufacturing, and horticulture, mainly tomatoes and
cut flowers, have been declining. Bank profits (1992)
registered a record 26% growth. Fund management
and insurance are the two other major income
generators. Light tax and death duties make the island
a popular tax-haven.
GDP: $NA
GDP— real growth rate: NA%
GDP— per capita: $NA
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 7% (1988)
Labor force: NA
Unemployment rate: 3%-4% (1994 est.)
Budget:
revenues: $277.9 million
expenditures: $248.8 million, including capital
expenditures of $NA (1995 est.)
Industries: tourism, banking
Industrial production growth rate: NA%
Electricity— capacity: NA kW
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Agriculture— products: tomatoes, greenhouse
flowers, sweet peppers, eggplant, other vegetables,
fruit; Guernsey cattle
Exports: $NA
commodities: tomatoes, flowers and ferns, sweet
peppers, eggplant, other vegetables
partners : UK (regarded as internal trade)
Imports: $NA
commodities: coal, gasoline, oil, machinery and
equipment
partners: UK (regarded as internal trade)
Debt— external: $NA
Economic aid: none
Currency: 1 Guernsey (£G) pound = 100 pence
Exchange rates: Guernsey pounds (£G) per
US$1 -0.61 15 (January 1998), 0.6106 (1997),
0.6403 (1996), 0.6335 (1995), 0.6529 (1994), 0.6658
(1993); note— the Guernsey pound is at par with the
British pound
Fiscal year: calendar year
Economy— overview: Although possessing major
mineral, hydropower, and agricultural resources,
Guinea remains one of the poorest countries in the
world. The agricultural sector employs 80% of the
workforce. Guinea possesses over 25% of the world''s
bauxite reserves and is the second largest bauxite
producer. The mining sector accounted for about 75%
of exports in 1995. Long-run improvements in
government fiscal arrangements, literacy, and the
legal framework are needed if the country is to move
out of poverty. The government made encouraging
progress in budget management in 1997. Except in
the mining industry, foreign investment remains
minimal.
GDP: purchasing power parity— $8.3 billion (1997
est.)
GDP— real growth rate: 4.8% (1997 est.)
GDP— per capita: purchasing power parity— $1 , 1 00
(1997 est.)
GDP— composition by sector:
agriculture: 24%
industry: 31%
services: 45% (1 995 est.)
Inflation rate— consumer price index: 3.5% (1996
est.)
Labor force:
total: 2.4 million (1983)
by occupation : agriculture 80.0%, industry and
commerce 1 1 .0%, services 5.4%, civil service 3.6%
Unemployment rate: NA%
Budget:
revenues : $553 million
expenditures: $652 million, including capital
expenditures of $317 million (1995 est.)
Industries: bauxite, gold, diamonds; alumina
refining; light manufacturing and agricultural
processing industries
Industrial production growth rate: 3.2% (1994)
Electricity— capacity: 176,000 kW (1995)
Electricity— production: 500 million kWh (1995)
Electricity— consumption per capita: 76 kWh
(1995)
Agriculture— products: rice, coffee, pineapples,
palm kernels, cassava (tapioca), bananas, sweet
potatoes; cattle, sheep, goats; timber
Exports:
total value: $ 748 million (1995 est.)
commodities: bauxite, alumina, diamonds, gold,
coffee, fish, agricultural products
partners: US 21%, Belgium-Luxembourg21%, Ireland
15%, Spain 15% (1995)
Imports:
total value: $809 million (1 995 est.)
commodities: petroleum products, metals, machinery,
transport equipment, textiles, grain and other
foodstuffs
partners: France 35%, Cote d''Ivoire 31%, US 14%,
Belgium-Luxembourg 10%, Hong Kong 10% (1995)
Debt— external: $3 billion (1997 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Guinean franc (FG) = 100 centimes
Exchange rates: Guinean francs (FG) per US$1—
1 ,004.0 (January 1 997), 1 ,004.0 (1 997), 991 .4 (1 995),
976.6 (1994), 955.5 (1993), 902.0 (1992)
note : the official exchange rate of the Guinean franc
was set and quoted weekly against the US dollar until
the end of October 1 993; since 1 November 1 994, the
exchange rate is determined in the interbank market
for foreign exchange
Fiscal year: calendar year','59ed176f25f79e3594d6ca0c3cd9b136ba1c3f383154989486c9eaf825ac19c2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c734e059f2e589e9f36d2da0d745604ad945aa3b1b48835237dc66bf99b6a04',1998,'GY','Guyana','economy',470,'Economy— overview: In 1997, Guyana, one of the
poorest countries in the Western Hemisphere, posted
its sixth straight year of economic growth of 5% or
better, with the advance led by gold and bauxite
mining and by sugar growing. Favorable growth
factors have included expansion in the key agricultural
and mining sectors, a more favorable atmosphere for
business initiative, a more realistic exchange rate, a
moderate inflation rate, and the continued support of
international organizations. Serious underlying
economic problems will continue. Electric power has
been in short supply and constitutes a major barrier to
future gains in national output. The government must
persist in efforts to manage its sizable external debt
and extend its privatization program.
GDP: purchasing power parity— $1.8 billion (1997
est.)
GDP— real growth rate: 5% (1997 est.)
GDP— per capita: purchasing power parity— $2,500
(1997 est.)
GDP— composition by sector:
agriculture: 39%
industry: 28%
services: 33% (1995 est.)
Inflation rate— consumer price index: 4.5% (1997
est.)
Labor force: NA
Unemployment rate: 1 2% (1 992 est.)
Budget:
revenues: $278 million
expenditures: $299 million, including capital
expenditures of $133 million (1996 est.)
Industries: bauxite, sugar, rice milling, timber,
fishing (shrimp), textiles, gold mining
Industrial production growth rate: 5.6% (1994
est.)
Electricity— capacity: 114,000 kW (1995)
Electricity— production: 230 million kWh (1995)
Electricity— consumption per capita: 339 kWh
(1995)
Agriculture— products: sugar, rice, wheat,
vegetable oils; beef, pork, poultry, dairy products;
development potential exists for fishing and forestry
Exports:
total value: $546 million (f.o.b., 1996)
commodities: sugar, gold, bauxite/alumina, rice,
shrimp, molasses
partners: Canada 33%, US 24%, UK 22% (1994 est.)
Imports:
total value: $589 million (c.i.f., 1996 est.)
commodities: manufactures, machinery, petroleum,
food
partners: US 29%, Trinidad and Tobago 17%,
Netherlands Antilles 17%, UK 11%, (1994 est.)
Debt— external: $1 .5 billion (1996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Guyanese dollar (G$) = 100 cents
Exchange rates: Guyanese dollars (G$) per
US$1 — 144.2 (January 1998), 142.4 (1997), 140.4
(1996), 142.0 (1995), 138.3 (1994), 126.7 (1993)
Fiscal year: calendar year
Economy— overview: About 75% of the population
lives in abject poverty. Nearly 70% of all Haitians
depend on the agriculture sector, which consists
mainly of small-scale subsistence farming and
employs about two-thirds of the economically active
workforce. The country has experienced little or no
job creation since President PREVAL took office in
February 1996, although the informal economy is
growing. Failure to reach agreements with
international sponsors have denied Haiti badly
needed budget and development assistance. Meeting
aid conditions in 1 998 will be especially challenging in
the face of mounting popular criticism of reforms.
GDP: purchasing power parity— $7.1 billion (1997
est.)
GDP— real growth rate: 1.1% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,070
(1997 est.)
GDP— composition by sector:
agriculture: 44%
industry: 13%
services: 43% (1995)
Inflation rate— consumer price index: 17% (1997
est.)
Labor force:
total: 3.6 million (1995)
by occupation : agriculture 66%, services 25%,
industry 9%
note: shortage of skilled labor, unskilled labor
abundant (1982)
Unemployment rate: 60% (1996 est.)
Budget:
revenues: $ 284 million
expenditures: $308 million, including capital
expenditures of $NA (FY96/97 est.)
Industries: sugar refining, flour milling, textiles,
cement, tourism, light assembly industries based on
imported parts
Industrial production growth rate: 2.5% (1995
est.)
Electricity— capacity: 153,000 kW (1995)
Electricity— production: 315 million kWh (1995)
Electricity— consumption per capita: 48 kWh
(1995)
Agriculture— products: coffee, mangoes,
sugarcane, rice, corn, sorghum; wood
Exports:
total value: $ 90 million (f.o.b., 1996)
commodities: light manufactures 53%, coffee 17%,
other agriculture 17%
partners: US 76.3%, EU 19.8% (1996)
Imports:
total value: $665 million (f.o.b., 1996)
commodities: machines and manufactures 34%, food
and beverages 22%, petroleum products 14%,
chemicals 10%, fats and oils 9%
partners: US 65.0%, EU 13.9% (1995)
Debt— external: $781 million (1995 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 gourde (G) = 100 centimes
Exchange rates: gourdes (G) per US$1 (end of
period)— 17.311 (December 1997), 17.311 (1997),
15.093 (1996), 16.160 (1995), 12.947 (1994), 12.805
(1993)
Fiscal year: 1 October— 30 September
Economy— overview: The economy is dominated
by the bauxite industry, which accounts for more than
1 5% of GDP and 70% of export earnings. Following a
dismal year in 1 994— which saw the value of the
Surinamese guilder plummet by about 70%, inflation
rise to more than 600%, and national output fall for the
fifth consecutive year— nearly all economic indicators
improved in 1995-97. The VENETIAAN government
unified the exchange rate as part of its structural
adjustment program (SAP). After assuming power in
the fall of 1996, the WIJDENBOSCH government
ended the SAP claiming it was unfair to the poorer
elements of society. Tax revenues fell as old taxes
lapsed and the government failed to implement new
tax alternatives. By the end of 1997, the allocation of
new Dutch development funds was frozen as
Surinamese government relations with Holland
deteriorated. Suriname''s economic prospects for the
medium term will depend on renewed commitment to
financially responsible monetary and fiscal policies.
GDP: purchasing power parity— $1 .44 billion (1 997
est.)
GDP— real growth rate: 4% (1997 est.)
GDP— per capita: purchasing power parity— $3,400
(1997 est.)
GDP— composition by sector:
agriculture: 14%
industry: 33%
se/v/ces:53%(1994)
Inflation rate— consumer price index: 8% (1997
est.)
Labor force: NA
by occupation: agriculture, industry, services
Unemployment rate: 20% (1997)
Budget:
revenues: $31 7 million
expenditures: $333 million, including capital
expenditures of $52 million (1997 est.)
Industries: bauxite and gold mining, alumina and
aluminum production, lumbering, food processing,
fishing
Industrial production growth rate: 6.5% (1994
est.)
Electricity— capacity: 425,000 kW (1995)
Electricity— production: 1.601 billion kWh (1995)
Electricity— consumption per capita: 3,727 kWh
(1995)
Agriculture— products: paddy rice, bananas, palm
kernels, coconuts, plantains, peanuts; beef, chicken;
forest products and shrimp of increasing importance
Exports:
total value: $434.3 million (f.o.b., 1996 est.)
commodities: alumina, aluminum, shrimp and fish,
rice, bananas
partners: Norway 33%, Netherlands 26%, US 13%,
Japan 6%, Brazil 6%, UK 3% (1994)
Imports:
total value: $490 million (f.o.b., 1997 est.)
commodities: capital equipment, petroleum,
foodstuffs, cotton, consumer goods
partners: US 40%, Netherlands 24%, Trinidad and
Tobago 11%, Japan 3% (1994)
Debt— external: $216 million (1996 est.)
Economic aid:
recipient: the Netherlands provided a 1996 aid
package of $224 million to Suriname, Aruba, and the
Netherlands Antilles
Currency: 1 Surinamese guilder, gulden, or florin
(Sf.) = 1 00 cents
Exchange rates: Surinamese guilders, gulden, or
florins (Sf.) per US$1— central bank midpoint rate:
401 .00 (January 1 998), 401 .00 (1 997), 401 .26 (1 996),
442.23 (1995), 134.12 (1994); parallel rate: 412
(December 1995), 510 (December 1994), 109
(January 1994)
note: beginning July 1994, the central bank midpoint
exchange rate was unified and became market
determined
Fiscal year: calendar year
Economy— overview: Coal mining is the major
economic activity on Svalbard. By treaty (9 February
1920), the nationals of the treaty powers have equal
rights to exploit mineral deposits, subject to
Norwegian regulation. Although US, UK, Dutch, and
Swedish coal companies have mined in the past, the
only companies still mining are Norwegian and
Russian. The settlements on Svalbard are essentially
company towns. The Norwegian state-owned coal
company employs nearly 60% of the Norwegian
population on the island, runs many of the local
services, and provides most of the local infrastructure.
There is also some trapping of seal, polar bear, fox,
and walrus.
Labor force: NA
Budget:
revenues: $11. 7 million
expenditures: $1 1 .7 million, including capital
expenditures of $NA (1997 est.)
Electricity— capacity: NA kW
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Economic aid:
recipient: Norway, $8.7 million (1997)
Currency: 1 Norwegian krone (NKr) = 100 oere
Exchange rates: Norwegian kroner (NKr) per
US$1 -7.4875 (January 1998), 7.0734 (1997),
6.4498 (1996), 6.3352 (1995), 7.0576 (1994), 7.0941
(1993)','e4678bc789baed40aaab7325d57114ce901b975712153c3e6e89e0584f61642b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e823b54be4a9a609993c99def6042cf0cf8ec2909f23c0585c5901f461389d0c',1998,'HU','Hungary','economy',479,'Economy— overview: Hungary has consolidated its
March 1995 stabilization program and undergone
enough restructuring to become an established
market economy. The country appears to have
entered a period of sustainable growth, gradually
falling inflation, and stable external balances. The
government''s main economic priorities are to
complete structural reforms, particularly the
implementation of the 1997 pension reform act (the
first in the region), taxation reform, and planning for
comprehensive health care, local government finance
reform, and the reform of education at all levels.
Foreign investment has totaled more than $17 billion
through 1997. In recognition of Hungary''s improved
macro-economic situation, all major credit-rating
agencies listed the country''s foreign currency debt
issuances as investment grade in 1996. The current
IMF stand-by arrangement expired in February 1998,
and Budapest and the IMF agree that there is no need
to renew it. The OECD welcomed Hungary as a
member in May 1996, and in December 1997 the EU
invited Hungary to begin the accession process.
Forecasters expect 4%-5% growth in 1998.
GDP: purchasing power parity— $73.2 billion
(1997 est.)
GDP— real growth rate: 4.4% (1997 est.)
GDP— per capita: purchasing power parity— $7,400
(1997 est.)
GDP— composition by sector:
agriculture: 7.2%
industry: 31 .8%
services: 61% (1995)
Inflation rate— consumer price index: 18%
(1997 est.)
Labor force:
total: 4.5 million (1996)
by occupation: services 65.0%, industry 26.7%,
agriculture 8.3 (1996)
Unemployment rate: 9% (1997 est.)
Budget:
revenues; $12.1 billion
expenditures: $13.8 billion, including capital
expenditures of $NA (1997 est.)
Industries: mining, metallurgy, construction
materials, processed foods, textiles, chemicals
(especially pharmaceuticals), motor vehicles
Industrial production growth rate: 7% (1997 est.)
Electricity— capacity: 6.979 million kW (1995)
Electricity— production: 32.92 billion kWh (1995)
Electricity— consumption per capita: 3,423 kWh
(1995)
Agriculture— products: wheat, corn, sunflower
seed, potatoes, sugar beets; pigs, cattle, poultry, dairy
products
Exports:
total value: $16 billion (f.o.b., 1996)
commodities: machinery and equipment 36.6%, other
manufactures 40.6%, agriculture and food products
15.1%, raw materials 4.4%, fuels and electricity 3.3%
(1996)
partners: EU 62.8% (Germany 29%, Austria 10.6%,
Italy 8.0%), FSU 8.6% (1996)
Imports:
total value:$ 18.6 billion (f.o.b., 1996)
commodities: machinery and equipment 36.5%, other
manufactures 43.7%, fuels and electricity 1 1 .8%,
agricultural and food products 4.4%, raw materials
3.6% (1996)
partners: EU 59.8% (Germany 23.6%, Austria 9.5%,
Italy 8.1%), FSU 14.9% (1996)
Debt— external: $27.6 billion (1996 est.)
Economic aid: $NA
Currency: 1 forint (Ft) = 100 filler
Exchange rates: forints per US$1— 206.260
(January 1998), 186.789 (1997), 152.647 (1996),
125.681 (1995), 105.160 (1994), 91.933 (1993)
Fiscal year: calendar year','0f8c3278a5937bb8f35367b7c83dd86c756a429b808e9dd3673356043206b343','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8fc24f6aba29f4a2b28839112f4bfacc69342a2d3af8233239c5ce722d2d4de',1998,'IS','Iceland','economy',487,'Economy— overview: Iceland''s Scandinavian-type
economy is basically capitalistic, yet with an extensive
welfare system, low unemployment, and remarkably
even distribution of income. The economy depends
heavily on the fishing industry, which provides 75% of
export earnings and employs 12% of the work force.
In the absence of other natural resources— except
energy— Iceland''s economy is vulnerable to changing
world fish prices. The economy remains sensitive to
declining fish stocks as well as to drops in world prices
for its main exports: fish and fish products, aluminum,
and ferrosilicon. The center-right government plans to
continue its policies of reducing the budget and
current account deficits, limiting foreign borrowing,
containing inflation, revising agricultural and fishing
policies, diversifying the economy, and privatizing
state-owned industries. The government remains
opposed to EU membership, primarily because of
Icelanders'' concern about losing control over their
fishing resources. Growth is likely to slow in 1998, to
a still respectable 3.9%.
GDP: purchasing power parity— $5.71 billion
(1997 est.)
GDP— real growth rate: 4.9% (1997 est.)
GDP— per capita: purchasing power parity —
$21,000 (1997 est.)
GDP— composition by sector:
agriculture: 9.6%
industry: 22.1%
services: 68.3% (1991)
Inflation rate— consumer price index: 2.3%
(1996)
Labor force:
total: 131,000 (1996 est.)
by occupation: manufacturing 12.9%, fishing and fish
processing 1 1 .8%, construction 1 0.7%, other services
59.5%, agriculture 5.1% (1996 est.)
Unemployment rate: 3.8% (1997 est.)
Budget:
revenues: $1.9 billion
expenditures: $ 2.1 billion, including capital
expenditures of $146 million (1996 est.)
Industries: fish processing; aluminum smelting,
ferrosilicon production, geothermal power; tourism
Industrial production growth rate: NA%
Electricity— capacity: 1.083 million kW (1995)
Electricity— production: 4.916 billion kWh (1995)
Electricity— consumption per capita: 18,481 kWh
(1995)
Agriculture— products: potatoes, turnips; cattle,
sheep; fish catch of about 1 .1 million metric tons in
1992
Exports:
total value: $1 .8 billion (f.o.b., 1 996)
commodities: fish and fish products 75%, animal
products, aluminum, ferrosilicon, diatomite
partners: UK 19%, Germany 14%, US 12%, Japan
11%, Denmark 8%, France 7% (1995)
Imports:
total value: $2 billion (f.o.b., 1996)
commodities: machinery and transportation
equipment, petroleum products, foodstuffs, textiles
partners: Germany 11%, Norway 10%, UK 10%,
Denmark 9%, US 8%, Sweden 7% (1995)
Debt— external: $2.2 billion (1996 est.)
Economic aid: $NA
Currency: 1 Icelandic krona (IKr) = 100 aurar
Exchange rates: Icelandic kronur (IKr) per US$1 —
72.707 (January 1 998), 70.904 (1 997), 66.500 (1 996),
64.692 (1995), 69.944 (1994), 67.603 (1993)
Fiscal year: calendar year
Economy— overview: Jan Mayen is a volcanic
island with no exploitable natural resources.
Economic activity is limited to providing services for
employees of Norway''s radio and meteorological
stations located on the island.','a929e394f59beb640f2925092d432b8bc5905b56c0210af6657ed98b0f819691','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0955d66c05b2ca33276be527603d5057e8f190f635585b9bd4486704a4396402',1998,'IN','India','economy',496,'Economy— overview: India''s economy
encompasses traditional village farming, modern
agriculture, handicrafts, a wide range of modern
industries, and a multitude of support services. 67% of
India''s labor force of nearly 400 million work in
agriculture, which contributes 30% of the country''s
GDP. Production, trade, and investment reforms since
1991 have provided new opportunities for Indian
businesspersons and an estimated 300 million middle
class consumers. New Delhi has avoided debt
rescheduling, attracted foreign investment, and
revived confidence in India''s economic prospects
since 1 991 . Many of the country''s fundamentals—
including savings rates (26% of GDP) and reserves
(now about $24 billion)— are healthy. Inflation eased
to 7% in 1 997, and interest rates dropped to between
1 0% and 1 3%. Even so, the Indian Government needs
to restore the early momentum of reform, especially
by continuing reductions in the extensive remaining
government regulations. Moreover, economic policy
changes have not yet significantly increased jobs or
reduced the risk that international financial strains will
reemerge within the next few years. Nearly 40% of the
Indian population remains too poor to afford an
adequate diet. India''s exports, currency, and foreign
institutional investment were affected by the East
Asian crisis in late 1997 and early 1998, but capital
account controls, a low ratio of short-term debt to
reserves, and enhanced supervision of the financial
sector helped insulate it from near term
balance-of-payments problems. Export growth, has
219
India (continued)
been slipping in 1996-97, averaging only about 4% to
5%— a large drop from the more than 20% increases
it was experiencing over the prior three years— mainly
because of the fall in Asian currencies relative to the
rupee. Energy, telecommunications, and
transportation shortages and the legacy of inefficient
factories constrain industrial growth which expanded
only 6.7% in 1997— down from more than 11% in
1996. Growth of the agricultural sector is still fairly
slow rebounding to only 5.7% in 1997 from a fall of
0.1% in 1996. Agricultural investment has slowed,
while costly subsidies on fertilizer, food distribution,
and rural electricity remain. Nevertheless, even if a
series of weak coalition governments continue to rule
in New Delhi over the next few years and are unable
to push reforms aggressively, parts of the economy
that have already benefited from deregulation will
continue to grow. Indian think tanks project GDP
growth of at least 5.5% in 1998.
GDP: purchasing power parity— $1 .534 trillion
(1997 est.)
GDP— real growth rate: 5% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,600
(1997 est.)
GDP— composition by sector:
agriculture: 30%
industry: 28%
services: 42% (1996 est.)
Inflation rate— consumer price index: 7%
(1997 est.)
Labor force:
total: 390 million (1997 est.)
by occupation: agriculture 67%, services 18%,
industry 15% (1995 est.)
Unemployment rate: NA%
Budget:
revenues: $39 billion
expenditures: $ 61 billion, including capital
expenditures of $10 billion (FY97/98 est.)
Industries: textiles, chemicals, food processing,
steel, transportation equipment, cement, mining,
petroleum, machinery
Industrial production growth rate: 6.7%
(1997 est.)
Electricity— capacity: 83.288 million kW (1996)
Electricity— production: 398.28 billion kWh (1995)
Electricity— consumption per capita: 427 kWh
(1995)
Agriculture— products: rice, wheat, oilseed, cotton,
jute, tea, sugarcane, potatoes; cattle, water buffalo,
sheep, goats, poultry; fish catch of about 3 million
metric tons ranks India among the world''s top 10
fishing nations
Exports:
total value: $33.9 billion (f.o.b, 1997)
commodities: gems and jewelry, clothing, engineering
goods, chemicals, leather manufactures, cotton yarn,
and fabric
partners: US, Hong Kong, UK, Germany
Imports:
total value: $39.7 billion (c.i.f., 1997)
commodities: crude oil and petroleum products,
machinery, gems, fertilizer, chemicals
partners : US, Belgium, Germany, Kuwait, Saudi
Arabia, UK, Japan
Debt— external: $90.7 billion (1997)
Economic aid:
recipient: ODA, $1,237 billion (1993); US ODA
bilateral commitments $171 million; US Ex-lm bilateral
commitments $680 million; Western (non-US)
countries, ODA bilateral commitments $2.48 billion;
OPEC bilateral aid $200 million; World Bank (IBRD)
multilateral commitments $2.8 billion; Asian
Development Bank (AsDB) multilateral commitments
$760 million; International Finance Corporation (IFC)
multilateral commitments $200 million; other
multilateral commitments $554 million (1995-96)
Currency: 1 Indian rupee (Re) = 100 paise
Exchange rates: Indian rupees (Rs) per US$1 —
39.358 (January 1 998), 36.313 (1 997), 35.433 (1 996),
32.427 (1995), 31.374 (1994), 30.493 (1993)
Fiscal year: 1 April— 31 March
Economy— overview: The Indian Ocean provides
major sea routes connecting the Middle East, Africa,
and East Asia with Europe and the Americas, it carries
a particularly heavy traffic of petroleum and petroleum
products from the oilfields of the Persian Gulf and
Indonesia. Its fish are of great and growing importance
to the bordering countries for domestic consumption
and export. Fishing fleets from Russia, Japan, Korea,
and Taiwan also exploit the Indian Ocean, mainly for
shrimp and tuna. Large reserves of hydrocarbons are
being tapped in the offshore areas of Saudi Arabia,
Iran, India, and western Australia. An estimated 40%
of the world''s offshore oil production comes from the
Indian Ocean. Beach sands rich in heavy minerals
and offshore placer deposits are actively exploited by
bordering countries, particularly India, South Africa,
Indonesia, Sri Lanka, and Thailand.','58983a7ab7d7771ad505719383244919411544a8f1d4f84a4a8a961bdb7d83a1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f45033ac9cf60e0d93a2ec36357855d68024a3c874bf1eaa4e3524e7adc46040',1998,'IE','Ireland','economy',503,'Economy— overview: The economy is small and
trade dependent. Agriculture, once the most important
sector, is now dwarfed by industry, which accounts for
38% of GDP, about 80% of exports, and employs 27%
of the labor force. Although exports remain the
primary engine for Ireland''s robust growth, the
economy is also benefiting from a rise in consumer
spending and recovery in both construction and
business investment. Since the 1980s, inflation has
fallen sharply and chronic trade deficits have been
transformed into annual surpluses. Unemployment
remains a serious problem, however, and job creation
is the main focus of government policy. To ease
unemployment, Dublin aggressively courts foreign
investors and recently created a new industrial
development agency to aid small indigenous firms.
GDP: purchasing power parity— $59.9 billion
(1997 est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity —
$18,600 (1997 est.)
GDP— composition by sector:
agriculture: 8.5%
industry: 38.3%
services: 53.2% (1 995)
Inflation rate— consumer price index: 1 .6%
(1997)
Labor force:
total: 1 .52 million (1997 est.)
by occupation : services 62.1%, manufacturing and
construction 27.0%, agriculture, forestry, and fishing
10.0%, utilities 0.9% (1996 est.)
Unemployment rate: 1 1 .8% (1 997)
Budget:
revenues; $20.6 billion
expenditures: $20.3 billion, including capital
expenditures of $5.2 billion (1997)
Industries: food products, brewing, textiles, clothing,
chemicals, pharmaceuticals, machinery,
transportation equipment, glass and crystal
Industrial production growth rate: 10.1%
(1997 est.)
Electricity— capacity: 3.62 million kW (1995)
Electricity— production: 16.586 billion kWh (1995)
Electricity— consumption per capita: 4,672 kWh
(1995)
Agriculture— products: turnips, barley, potatoes,
sugar beets, wheat; meat and dairy products
Exports:
total value: $54.8 billion (f.o.b., 1997)
commodities: chemicals, data processing equipment,
industrial machinery, live animals, animal products
partners: EU 66% (UK 22%, Germany 13%, France
8%), US 6%
Imports:
total value: $ 44.9 billion (c.i.f., 1997)
commodities: food, animal feed, data processing
equipment, petroleum and petroleum products,
machinery, textiles, clothing
partners: EU 52% (UK 29%, Germany 10.2%, France
4%), US 12%
Debt— external: $14 billion (1996)
Economic aid:
donor: ODA, $81 million (1993)
Currency: 1 Irish pound (£lr) = 100 pence
Exchange rates: Irish pounds (£lr) per US$1 —
0.7233 (January 1997), 0.6588 (1997), 0.6248 (1996),
0.6235 (1995), 0.6676 (1994), 0.6816 (1993)
Fiscal year: calendar year','bd27ebf0f1b0a534cd37d5b5ab83418ee196cf625e62b020f7762baa3ec28692','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b2765701141b12fb4daf47ba1fb35095106826485e196c7d87d73be4e2997c3',1998,'TN','Tunisia','economy',512,'Economy-overview: Since World War II, the Italian
economy has changed from one based on agriculture
into a ranking industrial economy, with approximately
the same total and per capita output as France and the
UK. This basically capitalistic economy is still divided
into a developed industrial north, dominated by private
companies, and a less developed agricultural south,
with large public enterprises and more than 20%
unemployment. Most raw materials needed by industry
and over 75% of energy requirements must be
imported. In the second half of 1992, Rome became
unsettled by the prospect of not qualifying to participate
in EU plans for economic and monetary union later in
the decade; thus, it finally began to address its huge
fiscal imbalances. Subsequently, the government has
adopted fairly stringent budgets, abandoned its
inflationary wage indexation system, and started to
scale back its generous social welfare programs,
including pension and health care benefits. In
November 1996 the lire rejoined the European
monetary system, which it had left in September 1992
when under extreme pressure in currency markets. Italy
faces the problem of restructuring its economy to meet
Maastricht criteria for inclusion in the EMU, together
with other problems of refurbishing a tottering
communications system, curbing industrial pollution,
and adjusting to new EU and global competitive forces.
GDP: purchasing power parity— $1 .24 trillion
(1997 est.)
GDP— real growth rate: 1 .5% (1997 est.)
GDP— per capita: purchasing power parity —
$21,500 (1997 est.)
GDP— composition by sector:
agriculture: 3.3%
industry: 33%
services: 63.7% (1994)
Inflation rate— consumer price index: 1 .9%
(1997 est.)
Labor force:
total: 22.851 million
by occupation: services 61%, industry 32%,
agriculture 7% (1996)
Unemployment rate: 12.2% (December 1997 est.)
Budget:
revenues: $41 6 billion
expenditures: $506 billion, including capital
expenditures of $47 billion (1 996 est.)
Industries: tourism, machinery, iron and steel,
chemicals, food processing, textiles, motor vehicles,
clothing, footwear, ceramics
Industrial production growth rate: 0.5%
(1996 est.)
Electricity— capacity: 57.186 million kW (1995)
Electricity— production: 225.179 billion kWh
(1995)
Electricity— consumption per capita: 4,509 kWh
(1995)
Agriculture— products: fruits, vegetables, grapes,
potatoes, sugar beets, soybeans, grain, olives; meat
and dairy products; fish catch of 525,000 metric tons
in 1990
Exports:
total value: $ 250.8 billion (f.o.b., 1996)
commodities: metals, textiles and clothing, production
machinery, motor vehicles, transportation equipment,
chemicals
partners: EU 53.4%, US 7.8%, OPEC 3.8%
Imports:
total value: billion (c.i.f., 1996)
commodities: industrial machinery, chemicals,
transport equipment, petroleum, metals, food,
agricultural products
partners: EU 45.5%, OPEC 4.8%, US 4.3%
Debt— external: $45 billion (1996 est.)
Economic aid:
donor: ODA, $3,043 billion (1993)
Currency: 1 Italian lira (Lit) = 100 centesimi
Exchange rates: Italian lire (Lit) per US$1 — 1 ,787.7
(January 1998), 1,703.1 (1997), 1,542.9 (1996),
1 ,628.9 (1 995), 1 ,61 2.4 (1 994), 1 ,573.7 (1 993)
Fiscal year: calendar year
Economy— overview: Tunisia has a diverse
economy, with important agricultural, mining, energy,
tourism, and manufacturing sectors. Governmental
control of economic affairs has gradually lessened
over the past decade with increasing privatization of
trade and commerce, simplification of the tax
structure, and a prudent approach to debt. Rea!
growth averaged 4.6% in 1992-96 and reached 5.6%
in 1997, down from 6.9% in 1996, which benefited
from a record cereal crop. Inflation has been
moderate. Growth in tourism and increased trade
have been key elements in this solid record. Tunisia''s
association agreement with the European Union
entered into force on 1 March 1998, the first such
accord between the EU and Mediterranean countries
to be activated. Under the agreement Tunisia will
gradually remove barriers to trade with the EU over
the next decade. Further privatization, the attraction of
increased foreign investment, and improvements in
government efficiency are among the challenges for
the future.
GDP: purchasing power parity— $56.5 billion (1997
est.)
GDP— real growth rate: 5.6% (1997 est.)
GDP— per capita: purchasing power parity— $6,100
(1997 est.)
GDP— composition by sector:
agriculture: 14%
industry: 28%
se/v/ces;58%(1996 est.)
Inflation rate— consumer price index: 4.6% (1997
est.)
Labor force:
total: 2.917 million (1993 est.)
by occupation: services 55%, industry 23%,
agriculture 22% (1995 est.)
note: shortage of skilled labor
Unemployment rate: 15% (1997 est.)
Budget:
revenues: $6.3 billion
expenditures: $6.8 billion, including capital
expenditures to $1 .5 billion (1997 est.)
Industries: petroleum, mining (particularly
phosphate and iron ore), tourism, textiles, footwear,
food, beverages
Industrial production growth rate: 3.5% (1995)
Electricity— capacity: 1.414 million kW (1995)
Electricity— production: 6.165 billion kWh (1995)
Electricity— consumption per capita: 696 kWh
(1995)
Agriculture— products: olives, dates, oranges,
almonds, grain, sugar beets, grapes; poultry, beef,
dairy products
Exports:
total value: $5.6 billion (f.o.b., 1997 est.)
commodities: hydrocarbons, textiles, agricultural
products, phosphates and chemicals
partners: EU 80%, North African countries 6%, Asia
4%, US 1% (1996)
Imports:
total value: $7 A billion (c.i.f., 1997 est.)
commodities: industrial goods and equipment 57%,
hydrocarbons 13%, food 12%, consumer goods
partners: EU countries 80%, North African countries
5.5%, Asia 5.5%, US 5% (1996)
Debt— external: $10.6 billion (1997 est.)
Economic aid:
recipient: ODA, $221 million (1993)
Currency: 1 Tunisian dinar (TD) = 1,000 millimes
Exchange rates: Tunisian dinars (TD) per US$1—
1.1612 (January 1 998), 1 .1 059 (1 997), 0.9734 (1 996),
0.9458 (1995), 1.0116 (1994), 1.0037 (1993)
Fiscal year: calendar year
Economy— overview: Turkmenistan is largely
desert country with nomadic cattle raising, intensive
agriculture in irrigated oases, and huge gas and oil
resources. One-half of its irrigated land is planted in
cotton, making it the world''s tenth largest producer. It
also possesses the world''s fifth largest reserves of
natural gas and substantial oil resources. Until the end
of 1993, Turkmenistan had experienced less
economic disruption than other former Soviet states
because its economy received a boost from higher
prices for oil and gas and a sharp increase in hard
currency earnings. In 1994, Russia''s refusal to export
Turkmen gas to hard currency markets and mounting
debts of its major customers in the former USSR for
gas deliveries contributed to a sharp fall in industrial
production and caused the budget to shift from a
surplus to a slight deficit. The economy bottomed out
in 1996, but high inflation continued. Furthermore,
with an authoritarian ex-communist regime in power
and a tribally based social structure, Turkmenistan
has taken a cautious approach to economic reform,
hoping to use gas and cotton sales to sustain its
inefficient economy. In 1996, the government set in
place a stabilization program aimed at a unified and
market-based exchange rate, allocation of
government credits by auction, and strict limits on
budget deficits. Privatization goals remain limited.
Turkmenistan is working hard to open new gas export
channels through Iran and Turkey to Europe, but
these will take many years to realize.
GDP: purchasing power parity— $12.5 billion (1996
est.)
GDP— real growth rate: -0.3% (1996)
GDP— per capita: purchasing power parity— $3,000
(1996 est.)
GDP— composition by sector:
agriculture: 18%
industry: 50%
services: 32% (1996 est.)
Inflation rate— consumer price index: 992%
(1996 est.)
Labor force:
total: 2.34 million (1996)
by occupation: agriculture and forestry 44%, industry
and construction 19%, other 37% (1996)
Unemployment rate: NA%
Budget:
revenues: $ 521 million
expenditures: $548 million, including capita!
expenditures of $83 million (1996 est.)
Industries: natural gas, oil, petroleum products,
textiles, food processing
Industrial production growth rate: NA%
Electricity— capacity: 3.95 million kW (1995)
Electricity— production: 9.204 billion kWh (1995)
Electricity— consumption per capita: 2,013 kWh
(1995)
Agriculture— products: cotton, grain; livestock
Exports:
total value: $1 .7 billion to states outside the FSU
(1996)
commodities: natural gas, cotton, petroleum products,
textiles, electricity, carpets
partners: FSU, Hong Kong, Switzerland, US,
Germany, Turkey (1996)
Imports:
total value: $1 .5 billion from states outside the FSU
(1996)
commodities: machinery and parts, grain and food,
plastics and rubber, consumer durables, textiles
partners: FSU, US, Turkey, Germany, Cyprus (1996)
Debt— external: $400 million (of which $275 million
to Russia) (1995 est.)
Economic aid:
recipient: ODA, $10 million (1993)
note: commitments, $1,830 million ($375 million
drawn), 1992-95
Currency: 1 Tukmen manat (TMM) = 100 tenesi;
Turkmenistan introduced its national currency on 1
November 1993
Exchange rates: manats per US$1— 4,070
(January 1997), 2,400 (January 1996)
note: government established a unified rate in
mid-January 1996
Fiscal year: calendar year','ec62a7463953796384016cf2d560bd3eded359db150b21043e0e1cd9d368c910','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2a10c24d776e5d6ee0ac773937533d3839bf5e3779c339c05ec5c1a349040be',1998,'JM','Jamaica','economy',521,'Economy— overview: Key sectors in this island
economy are bauxite (alumina and bauxite account
for more than half of exports) and tourism. Since
assuming office in 1992, Prime Minister PATTERSON
has eliminated most price controls, streamlined tax
schedules, and privatized government enterprises.
Continued tight monetary and fiscal policies have
helped slow inflation and stabilize the exchange rate,
but have resulted in the slow-down of economic
growth (moving from 1 .5% in 1 992 to 0.5% in 1 995. In
1996, GDP was in negative growth (-1 .4%) and
remained so in 1997. Serious problems include: high
interest rates; increased foreign competition; the weak
financial condition of business in general resulting in
receiverships or closures and downsizings of
companies; the shift in investment portfolios to
non-productive, short-term high yield instruments; a
pressured, sometimes sliding, exchange rate; a
widening merchandise trade deficit; and a growing
internal debt for government bailouts to various ailing
sectors of the economy. Jamaica''s medium-term
prospects will depend upon encouraging investment
in the productive sectors, maintaining a competitive
exchange rate, stabilizing the labor environment, and
implementing proper fiscal and monetary policies.
GDP: purchasing power parity— $9.5 billion
(1996 est.)
GDP— real growth rate: -1 .4% (1996 est.)
GDP— per capita: purchasing power parity— $3,660
(1996 est.)
GDP— composition by sector:
agriculture: 8%
industry: 37%
se/v/ces:55%(1996 est.)
Inflation rate— consumer price index: 17%
(1996 est.)
Labor force:
total: 1.14 million (1996)
by occupation: services 41%, agriculture 22.5%,
industry 19%, unemployed 17.5% (1989)
Unemployment rate: 1 6% (1996 est.)
Budget:
revenues: $3 billion
expenditures: $ 3 billion, including capital
expenditures of $1,163 billion (FY97/98 est.)
Industries: tourism, bauxite, textiles, food
processing, light manufactures
Industrial production growth rate: NA%
Electricity— capacity: 1 .182 million kW (1995)
Electricity— production: 3.87 billion kWh (1995)
Electricity— consumption per capita: 1 ,503 kWh
(1995)
Agriculture— products: sugarcane, bananas,
coffee, citrus, potatoes, vegetables; poultry, goats,
milk
Exports:
total value: A billion (f.o.b., 1996)
commodities: alumina, bauxite, sugar, bananas, rum
partners: US 37%, UK 13%, Canada 12%,
Netherlands 9%, Norway 7%
Imports:
total value: $2.9 billion (f.o.b., 1996 est.)
commodities: machinery and transport equipment,
construction materials, fuel, food, chemicals
partners: US 52%, Trinidad and Tobago 8%, Japan
6%, UK 4%, Canada 3%
Debt— external: $3.2 billion (1997 est.)
Economic aid:
recipient: ODA, $306 million (1996)
Currency: 1 Jamaican dollar (J$) = 100 cents
Exchange rates: Jamaican dollars (J$) per US$1 —
36.051 (November 1997), 37.120 (1996), 35.142
(1995), 33.086 (1994), 24.949 (1993)
Fiscal year: 1 April— 31 March','610b2fb335180489806ca7b635b26305c53aa7af86609663058fbd1106d99b57','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e60778091fc6f60b6b47e6f519d576497ec03a09a040c8db8fe33f481f15c63',1998,'NO','Norway','economy',526,'Economy— overview: Government-industry
cooperation, a strong work ethic, mastery of high
technology, and a comparatively small defense
allocation (roughly 1% of GDP) have helped Japan
advance with extraordinary rapidity to the rank of
second most powerful economy in the world. One
notable characteristic of the economy is the working
together of manufacturers, suppliers, and distributors
in closely knit groups called keiretsu. A second basic
feature has been the guarantee of lifetime
employment for a substantial portion of the urban
labor force; this guarantee is eroding. Industry, the
most important sector of the economy, is heavily
dependent on imported raw materials and fuels. The
much smaller agricultural sector is highly subsidized
and protected, with crop yields among the highest in
the world. Usually self-sufficient in rice, Japan must
import about 50% of its requirements of other grain
and fodder crops. Japan maintains one of the world''s
largest fishing fleets and accounts for nearly 15% of
the global catch. For three decades overall real
economic growth had been spectacular: a 10%
average in the 1 960s, a 5% average in the 1 970s, and
a 4% average in the 1980s. Growth slowed markedly
in 1992-95 largely because of the aftereffects of
overinvestment during the late 1980s and
contractionary domestic policies intended to wring
speculative excesses from the stock and real estate
markets. Growth picked up to 3.9% in 1996, largely a
reflection of stimulative fiscal and monetary policies
as well as low rates of inflation. But in 1997 growth fell
back to 1%. As a result of the expansionary fiscal
policies and declining tax revenues due to the
recession, Japan has one of the largest budget
deficits as a percent of GDP among the industrialized
countries. The crowding of habitable land area and the
aging of the population are two other major long-run
problems.
GDP: purchasing power parity— $3.08 trillion
(1997 est.)
GDP— real growth rate: 0.9% (1997 est.)
GDP— per capita: purchasing power parity —
$24,500 (1997 est.)
GDP— composition by sector:
agriculture: 2%
industry: 41 .5%
services: 56.5% (1995)
Inflation rate— consumer price index: 1 .7%
(1997)
Labor force:
total: 67 .23 million (March 1997)
by occupation: trade and services 50%,
manufacturing, mining, and construction 33%, utilities
and communication 7%, agriculture, forestry, and
fishing 6%, government 3% (1994)
Unemployment rate: 3.4% (1997)
Budget:
revenues; $497 billion
expenditures: $621 billion, including capital
expenditures (public works only) of about $72 billion
(FY98/99 est.)
Industries: among world''s largest and
technologically advanced producers of steel and
nonferrous metallurgy, heavy electrical equipment,
construction and mining equipment, motor vehicles
and parts, electronic and telecommunication
equipment, machine tools, automated production
systems, locomotives and railroad rolling stock, ships,
chemicals; textiles, processed foods
Industrial production growth rate: 4.3% (1997)
Electricity— capacity: 199.878 million kW (1995)
Electricity— production: 930.55 billion kWh (1995)
Electricity— consumption per capita: 7,414 kWh
(1995)
Agriculture— products: rice, sugar beets,
vegetables, fruit; pork, poultry, dairy products, eggs;
world''s largest fish catch of 1 0 million metric tons in
1991
Exports:
total value: $421 billion (f.o.b., 1997)
commodities: manufactures 96% (including
machinery 50%, motor vehicles 19%, consumer
electronics 3%)
partners: US 27%, Southeast Asia 17%, EU 15%,
China 5%
Imports:
total value: $ 339 billion (c.i.f., 1997)
commodities: manufactures 54%, foodstuffs and raw
materials 28%, fossil fuels 16%
partners: US 22%, Southeast Asia 15%, EU 14%,
China 12%
Debt— external: $NA
Economic aid:
donor: ODA, $8.3 billion (1998 est.)
note: ODA and OOF commitments (1970-94), $174
billion
Currency: yen(¥)
Exchange rates: yen (¥) per US$1— 129.45
(January 1998), 120.99 (1997), 108.78 (1996), 94.06
(1995), 102.21 (1994), 111.20(1993)
Fiscal year: 1 April— 31 March','084ecc670ed9bea52cf163a33acd4d5b7287a4eb135f8589f3854f66c6bd6f67','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e91de58a2148c9ffefea9bb4a411614ef53c5f3d8421a65b0fabad779e4f72a',1998,'JO','Jordan','economy',529,'Economy— overview: Jordan is a small Arab
country with inadequate supplies of water and other
natural resources such as oil and coal. Jordan
benefited from increased Arab aid during the oil boom
of the late 1 970s and early 1 980s, when its annual real
GNP growth averaged more than 10%. In the
remainder of the 1980s, however, reductions in both
Arab aid and worker remittances slowed real
economic growth to an average of roughly 2% per
year. Imports— mainly oil, capital goods, consumer
durables, and food— outstripped exports, with the
difference covered by aid, remittances, and
borrowing. In mid-1989, the Jordanian Government
began debt-rescheduling negotiations and agreed to
implement an IMF-supported program designed to
gradually reduce the budget deficit and implement
badly needed structural reforms. The Persian Gulf
crisis that began in August 1990, however,
aggravated Jordan’s already serious economic
problems, forcing the government to shelve the IMF
program, stop most debt payments, and suspend
rescheduling negotiations. Aid from Gulf Arab states,
worker remittances, and trade contracted; and
refugees flooded the country, producing serious
balance-of-payments problems, stunting GDP growth,
and straining government resources. The economy
rebounded in 1992, largely due to the influx of capital
repatriated by workers returning from the Gulf, but
recovery was uneven in 1994-97. The government is
implementing the reform program adopted in 1992
and continues to secure rescheduling and write-offs of
its heavy foreign debt. Debt, poverty, and
245
Jordan (continued)
unemployment remain Jordan''s biggest on-going
problems.
GDP: purchasing power parity— $20.7 billion
(1997 est.)
GDP— real growth rate: 5.3% (1997 est.)
GDP— per capita: purchasing power parity— $4,800
(1997 est.)
GDP— composition by sector:
agriculture: 6%
industry: 30%
services: 64% (1995 est.)
Inflation rate— consumer price index: 3%
(1997 est.)
Labor force:
total : 1 .15 million plus 300,000 foreign workers (1997
est.)
by occupation: industry 1 1 .4%, commerce,
restaurants, and hotels 10.5%, construction 10.0%,
transport and communications 8.7%, agriculture
7.4%, other services 52.0% (1992)
Unemployment rate: 1 5% official rate; note— actual
rate is 20%-25% (1997 est.)
Budget:
revenues: $2.7 billion
expenditures: $2.8 billion, including capital
expenditures of $630 million (1997 est.)
Industries: phosphate mining, petroleum refining,
cement, potash, light manufacturing
Industrial production growth rate: -3.4% (1996)
Electricity— capacity: 1 .066 million kW (1995)
Electricity— production: 5.02 billion kWh (1995)
Electricity— consumption per capita: 1 ,259 kWh
(1995)
Agriculture— products: wheat, barley, citrus,
tomatoes, melons, olives; sheep, goats, poultry
Exports:
total value: $1 .53 billion (f.o.b., 1997)
commodities: phosphates, fertilizers, potash,
agricultural products, manufactures
partners: Iraq, India, Saudi Arabia, EU, Indonesia,
UAE
Imports:
total value: $ 3.7 billion (c.i.f., 1997)
commodifies: crude oil, machinery, transport
equipment, food, live animals, manufactured goods
partners: EU, Iraq, US, Japan, Turkey
Debt— external: $7.3 billion (1997 est.)
Economic aid:
recipient: ODA, $424 million (1996)
Currency: 1 Jordanian dinar (JD) = 1 ,000 fils
Exchange rates: Jordanian dinars (JD) per US$1 —
0.7090 (January 1998-1996), 0.7005 (1995), 0.6987
(1994), 0.6928 (1993)
note: since May 1 989, the dinar has been pegged to a
basket of currencies
Fiscal year: calendar year
Economy— overview: no economic activity','fa725519cd6013fe2f85df45d64356b2d6e9e57b4ee7907510f0600edb57381c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff263c69e9f469f7e8b8949d27bc076cd2e48d0a423bc0630114e7bd6b20b8a9',1998,'KE','Kenya','economy',536,'Economy— overview: Since 1993, the government
of Kenya has implemented a program of economic
liberalization and reform. Steps have included the
removal of import licensing and price controls, removal
of foreign exchange controls, fiscal and monetary
restraint, and reduction of the public sector through
privatizing publicly owned companies and downsizing
the civil service. With the support of the World Bank,
IMF, and other donors, these reforms have led to a
turnaround in economic performance following a
period of negative growth in the early 1990s. Kenya''s
real GDP grew at 5% in 1995 and 4% in 1 996, and
inflation remained under control. Growth slowed in
1997. Political violence damaged the tourist industry,
and the IMF allowed Kenya''s Enhanced Structural
Adjustment Program to lapse due to the government''s
failure to enact reform conditions and to adequately
address public sector corruption. Moreover, El Nino
rains destroyed crops and damaged an already
crumbling infrastructure in 1997 and on into 1998.
Long-term barriers to development include electricity
shortages, the government''s continued and inefficient
dominance of key sectors, endemic corruption, and the
country''s high population growth rate.
GDP: purchasing power parity— $45.3 billion
(1997 est.)
GDP— real growth rate: 2.9% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,600
(1997 est.)
GDP— composition by sector:
agriculture: 27%
industry: 20%
services: 53% (1995)
Inflation rate— consumer price index: 8.8%
(1996)
Labor force:
total: 8.78 million (1993 est.)
by occupation: agriculture 75%-80%, non-agriculture
20%-25%
Unemployment rate: 35% urban (1994 est.)
Budget:
revenues: $3 billion
expenditures: $3 billion, including capital
expenditures of $638 million (FY96/97 est.)
Industries: small-scale consumer goods (plastic,
furniture, batteries, textiles, soap, cigarettes, flour),
processing agricultural products; oil refining, cement;
tourism
Industrial production growth rate: 3.8% (1995)
Electricity— capacity: 808,000 kW (1995)
Electricity— production: 3.59 billion kWh (1995)
Electricity— consumption per capita: 134 kWh
(1995)
Agriculture— products: coffee, tea, corn, wheat,
sugarcane, fruit, vegetables; dairy products, beef,
pork, poultry, eggs
Exports:
total value: $2.1 billion (f.o.b., 1996)
commodities: tea 18%, coffee 15%, petroleum
products (1995)
partners: Uganda 22.8%, UK 20.1%, Tanzania
19.1%, Germany 14.0%, Netherlands 7.6%, US 6.1%
Imports:
total value: $2.9 billion (f.o.b., 1996)
commodities : machinery and transportation
equipment 31%, consumer goods 13%, petroleum
products 12% (1995)
partners: UK 21 .3%, U AE 1 8%, Japan 1 4%,
Germany, US
Debt— external: $7 billion (1994 est.)
Economic aid: NA
Currency: 1 Kenyan shilling (KSh) = 100 cents
Exchange rates: Kenyan shillings (KSh) per
US$1— 61.164 (January 1998), 58.732 (1997),
57.115 (1996), 51.430 (1995), 56.051 (1994), 58.001
(1993)
Fiscal year: 1 July— 30 June','cf6cce30e095838d52e7d3abc86de2b29b52ba76fca30b74d2b0d091fb948d5e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b70d073f68630cef67b17eb2faf1e84f312dbca16e55db489f691cb41bf4ae7',1998,'WS','Samoa','economy',544,'Economy— overview: no economic activity
Economy— overview: no economic activity
Economy— overview: Because of its key
geographic location, Panama''s economy is
service-based, heavily weighted toward banking,
commerce, and tourism. Since taking office in 1994,
President PEREZ BALLADARES has advanced an
economic reform program designed to liberalize the
trade regime, attract foreign investment, privatize
state-owned enterprises, institute fiscal reform, and
encourage job creation through labor code reform.
The government privatized its two remaining ports
along the Panama Canal in 1997 and approved the
sale of the railroad in early 1 998. It also plans to sell
other assets, including the electric company. Panama
joined the World Trade Organization (WTrO) and
approved a tariff reduction that will give the country
the lowest average tariff rates in Latin America. A
banking reform law was approved by the legislature in
early 1 998 and will take effect in June. After two years
of near stagnation, the reforms are beginning to take
root; GDP grew by 3.6% in 1997 and is expected to
grow by more than 5% in 1998. The most important
sectors driving growth have been the Panama Canal
and the shipping and port activities. The Colon Free
Zone also rebounded from a slow year in 1996.
GDP: purchasing power parity— $18 billion (1997
est.)
GDP— real growth rate: 3.6% (1997 est.)
GDP— per capita: purchasing power parity— $6,700
(1997 est.)
GDP— composition by sector:
agriculture: 8%
industry: 18%
services: 74% (1997 est.)
Inflation rate— consumer price index: 1 .2%
(1997)
Labor force:
total: 1.044 million (1997 est.)
by occupation: government and community services
31 .8%, agriculture, hunting, and fishing 26.8%,
commerce, restaurants, and hotels 16.4%,
manufacturing and mining 9.4%, construction 3.2%,
transportation and communications 6.2%, finance,
insurance, and real estate 4.3%
note: shortage of skilled labor, but an oversupply of
unskilled labor
Unemployment rate: 13.1% (1997 est.)
Budget:
revenues: $2.4 billion
expenditures: $2.4 billion, including capital
expenditures of $341 million (1997 est.)
Industries: construction, petroleum refining,
brewing, cement and other construction materials,
sugar milling
Industrial production growth rate: 0.4% (1995
est.)
Electricity— capacity: 957 million kW (1995)
Electricity— production: 3.6 billion kWh (1995)
Electricity— consumption per capita: 1 ,355 kWh
(1995)
Agriculture— products: bananas, rice, corn, coffee,
sugarcane, vegetables; livestock; fishing (shrimp)
Exports:
total value: $592 million (f.o.b., 1997 est.)
commodities: bananas 43%, shrimp 1 1 %, sugar 4%,
clothing 5%, coffee 2%
partners: US 37%, EU, Central America and
Caribbean
Imports:
total value: $2.95 billion (c.i.f., 1997 est.)
commodities: capital goods 21%, crude oil 11%,
foodstuffs 9%, consumer goods, chemicals
partners: US 48%, EU, Central America and
Caribbean, Japan
Debt— external: $7.26 billion (1996 est.)
Economic aid:
recipient: NA
Currency: 1 balboa (B) = 100 centesimos
Exchange rates: balboas (B) per US$1— 1.000
(fixed rate)
Fiscal year: calendar year
Economy— overview: The economy of Samoa has
traditionally been dependent on development aid,
private family remittances from overseas, and
agricultural exports. The country is vulnerable to
devastating storms. Agriculture employs two-thirds of
the labor force, and furnishes 90% of exports,
featuring coconut cream, coconut oil, and copra.
Outside of a large automotive wire harness factory,
the manufacturing sector mainly processes
agricultural products. Tourism is an expanding sector;
more than 70,0000 tourists visited the islands in 1996.
The 1 998 Samoan budget calls for deregulation of the
financial sector, development of more financial
investments, and forecasts 3% to 4% growth.
GDP: purchasing power parity— $450 million (1996
est.)
GDP— real growth rate: 5.9% (1996 est.)
GDP— per capita: purchasing power parity— $2, 1 00
(1996 est.)
GDP— composition by sector:
agriculture: 40%
industry: 25%
services: 35% (1996 est.)
Inflation rate— consumer price index: 7.5%
(1996)
Labor force:
total: 82,500 (1991 est.)
by occupation: agriculture 65%, services 30%,
industry 5% (1995 est.)
Unemployment rate: NA%
Budget:
revenues: $52 million
expenditures: $99 million, including capital
expenditures of $37 million (FY96/97 est.)
Industries: timber, tourism, food processing, fishing
Industrial production growth rate: 14% (1996 est.)
Electricity— capacity: 21,700 kW (1996 est.)
Electricity— production: 56.3 million kWh (1 996 est.)
Electricity— consumption per capita: 310 kWh
(1995)
Agriculture— products: coconuts, bananas, taro,
yams
Exports:
total value: $ 10 million (f.o.b., 1996)
commodities: coconut oil and cream, copra, fish, beer
(1996)
partners: New Zealand 48%, American Samoa 11%,
Australia 10%, Germany 7%, US 3% (1996)
Imports:
total value: $100 million (c.i.f., 1996)
commodities: intermediate goods 50%, food 26%,
capital goods 12% (1996)
partners: New Zealand 37%, Australia 22%, Fiji 1 5%,
US 13%
Debt— external: $169.4 million (1996 est.)
Economic aid:
recipient: ODA; $8.7 million bilateral aid from Australia
(FY96/97 est.); $5 million bilateral aid from NZ (FY95/96)
Currency: 1 tala (WS$) = 100 sene
Exchange rates: tala (WS$) per US$1— 2.7556
(January 1998), 2.5562 (1997), 2.4618 (1996), 2.4722
(1995), 2.5349 (1994), 2.5681 (1993)
Fiscal year: calendar year','c048e9d3f0a1b463f49fbbb1525583b900dae9d9803f96db5609285b37c500fc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42551b75ff53de50cb03d4d686bb8180d55698d83defd38c4fd70d5a12d0d37b',1998,'KI','Kiribati','economy',552,'Economy— overview: A remote country of 33
scattered coral atolls, Kiribati has few national
resources. Commercially viable phosphate deposits
were exhausted at the time of independence from the
UK in 1 979. Copra and fish now represent the bulk of
production and exports. The economy has fluctuated
widely in recent years. Real GDP growth has declined
from about 10% in 1988 to about 2.6% in 1995 and
1 .9% in 1 996. Growth in 1 997 was expected to parallel
the 1996 performance. Economic development is
constrained by a shortage of skilled workers, weak
infrastructure, and remoteness from international
markets. The financial sector is at an early stage of
development as is the expansion of private sector
initiatives. Foreign financial aid, largely from the UK
and Japan, is a critical supplement to GDP, equal in
amount to 25%-50% of GDP in recent years.
Remittances from workers abroad account for more
than $5 million each year.
GDP: purchasing power parity— $62 million
(1996 est.)
GDP— real growth rate: 1 .9% (1 996 est.)
GDP— per capita: purchasing power parity— $800
(1996 est.)
GDP— composition by sector:
agriculture: 14%
industry: 7%
services: 79% (1996 est.)
Inflation rate— consumer price index: -0.6%
(1996 est.)
Labor force:
total: 7,870 economically active, not including
subsistence farmers (1985 est.)
Unemployment rate: 2%; underemployment 70%
(1992 est.)
Budget:
revenues: $33.3 million
expenditures: $47.7 million, including capital
expenditures of $NA million (1996 est.)
Industries: fishing, handicrafts
Industrial production growth rate: 0.7%
(1992 est.)
Electricity— capacity: 2,000 kW (1995)
Electricity— production: 7 million kWh (1995)
Electricity— consumption per capita: 88 kWh
(1995)
Agriculture— products: copra, taro, breadfruit,
sweet potatoes, vegetables; fish
Exports:
total value: $6.7 million (f.o.b., 1 996 est.)
commodities: copra 62%, seaweed, fish
partners: US, Australia, NZ (1996)
Imports:
total value: $37.4 million (c.i.f., 1996 est.)
commodities: foodstuffs, machinery and equipment,
miscellaneous manufactured goods, fuel
partners: Australia 46%, Fiji, Japan, NZ, US (1996)
Debt— external: $7.2 million (1996 est.)
Economic aid:
recipient: ODA, $4,725 million from Australia
(FY96/97 est.); $2,175 million from NZ (FY95/96)
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 —
1 .5281 (January 1 998), 1 .3439 (1 997), 1 .2773 (1 996),
1.3486 (1995), 1.3667 (1994), 1.4704 (1993)
Fiscal year: NA
Economy— overview: More than 90% of this
command economy is socialized; agricultural land is
collectivized; and state-owned industry produces 95%
of manufactured goods. State control of economic
affairs is unusually tight even for a communist country
because of the small size and homogeneity of the
society and the strict rule of KIM ll-song in the past
and now his son, KIM Chong-il. Economic growth
during the period 1984-88 averaged 2%-3%, but
output declined by an average of 4%-5% or more
annually during 1989-97 because of systemic
problems and disruptions in economic and
technological links with the former USSR and China.
The leadership has insisted on maintaining its high
level of military outlays from a shrinking economic pie.
Moreover, a serious drawdown in inventories and
critical shortages in the energy sector have led to
increasing interruptions in industrial production.
Abundant mineral resources and hydropower have
formed the basis of industrial development since
World War II. Manufacturing is centered on heavy
industry, including military industry, with light industry
lagging far behind. Despite the use of improved seed
varieties, expansion of irrigation, and the heavy use of
fertilizers, North Korea is not yet self-sufficient in food
production. Indeed, a shortage of arable lands,
several years of poor harvests, systemic
inefficiencies, a cumbersome distribution system, and
extensive floods in 1995-96 followed by a severe
drought in 1997 have resulted in increasingly serious
food shortages. Substantial grain shipments from
Japan and South Korea are offsetting a portion of the
losses. North Korea remains far behind South Korea
in economic development and living standards.
GDP: purchasing power parity— $21 .8 billion (1 997
est.)
GDP— real growth rate: -3.7% (1997 est.)
GDP— per capita: purchasing power parity— $900
(1997 est.)
GDP— composition by sector:
agriculture: 25%
industry: 60%
services: 15% (1995 est.)
Inflation rate— consumer price index: NA%
Labor force:
total: 9.61 5 million
by occupation: agricultural 36%, nonagricultural 64%
Unemployment rate: NA%
Budget:
revenues: $19.3 billion
expenditures: $19.3 billion, including capital
expenditures of $NA (1992 est.)
Industries: military products; machine building,
electric power, chemicals; mining (coal, iron ore,
magnesite, graphite, copper, zinc, lead, and precious
metals), metallurgy; textiles, food processing
Industrial production growth rate: -7% to -9%
(1992 est.)
Electricity— capacity: 9.5 million kW (1995)
Electricity— production: 35.2 billion kWh (1995)
Electricity— consumption per capita: 1 ,499 kWh
(1995)
Agriculture— products: rice, corn, potatoes,
soybeans, pulses; cattle, pigs, pork, eggs
Exports:
total value: $ 912 million (f.o.b., 1996 est.)
commodities: minerals, metallurgical products,
agricultural and fishery products, manufactures
(including armaments)
partners: China, Japan, South Korea, Germany, Hong
Kong, Russia
Imports:
total value: $ 1.95 billion (c.i.f., 1996 est.)
commodities: petroleum, grain, coking coal,
machinery and equipment, consumer goods
partners: China, Japan, Hong Kong, Germany,
Russia, Singapore
Debt— external: $12 billion (1996 est.)
Economic aid:
recipient: an estimated $200 million to $300 million in
aid from US, South Korea, Japan, and EU in 1997
Currency: 1 North Korean won (Wn) = 100 chon
Exchange rates: North Korean won (Wn) per
US$1— 2.15 (May 1994), 2.13 (May 1992), 2.14
(September 1991), 2.1 (January 1990), 2.3
(December 1989)
Fiscal year: calendar year
Economy— overview: As one of the Four Dragons
of East Asia, South Korea has achieved an incredible
record of growth. Three decades ago its GDP per
capita was comparable with levels in the poorer
countries of Africa and Asia. Today its GDP per capita
is eight times India''s, 15 times North Korea''s, and
already up with the lesser economies of the European
Union. This success through the late 1980s was
achieved by a system of close government business
ties, including directed credit, import restrictions,
sponsorship of specific industries, and a strong labor
effort. The government promoted the import of raw
materials and technology at the expense of consumer
goods and encouraged savings and investment over
consumption. The Asian financial crisis of 1997/98
exposed certain longstanding weaknesses in South
Korea''s development model, including high debt/
equity ratios, massive foreign borrowing, and an
undisciplined financial sector. Also, a number of
private sector conglomerates are near bankruptcy. At
yearend 1997, an international effort, spearheaded by
the IMF, was underway to shore up reserves and
stabilize the economy. Growth in 1998 will be sharply
cut. Long-term growth will depend on how
successfully South Korea implements planned
economic reforms that would bolster the financial
sector, improve corporate management, and open the
economy further to foreign participation.
GDP: purchasing power parity— $631 .2 billion
(1997 est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity —
$13,700 (1997 est.)
GDP— composition by sector:
agriculture: 8%
industry: 45%
serv/ces; 47% (1991 est.)
Inflation rate— consumer price index: 5% (1996)
Labor force:
tofa/; 20 million
by occupation: services and other 52%, mining and
manufacturing 27%, agriculture, fishing, forestry 21%
(1991)
Unemployment rate: 2% (1996)
Budget:
revenues: $101 billion
expenditures: $101 billion, including capital
expenditures of $20 billion (1996 est.)
Industries: electronics, automobile production,
chemicals, shipbuilding, steel, textiles, clothing,
footwear, food processing
Industrial production growth rate: 8.2% (1996)
Electricity— capacity: 31.665 million kW (1995)
Electricity— production: 174.52 billion kWh (1995)
Electricity— consumption per capita: 3,831 kWh
(1995)
Agriculture— products: rice, root crops, barley,
vegetables, fruit; cattle, pigs, chickens, milk, eggs; fish
catch of 2.9 million metric tons, seventh largest in
world
Exports:
total value: $129.8 billion (f.o.b., 1996)
commodities : electronic and electrical equipment,
machinery, steel, automobiles, ships; textiles,
clothing, footwear; fish
partners: US 17%, EU 13%, Japan 12% (1995)
Imports:
total value: $150.2 billion (cJ.f., 1996)
commodities: machinery, electronics and electronic
equipment, oil, steel, transport equipment, textiles,
organic chemicals, grains
partners: US 22%, Japan 21%, EU 13% (1995)
Debt— external: $154 billion (1998 est.)
Economic aid: $NA
Currency: 1 South Korean won (W) = 100 chun
(theoretical)
Exchange rates: South Korean won (W) per
US$1— 1,706.80 (January 1998), 951.29 (1997),
804.45 (1996), 771.27 (1995), 803.45 (1994), 802.67
(1993)
Fiscal year: calendar year','331a1d856191d1e7b6cbd7bab235fc2724791a3eb2654796484fdf707114826a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fcd18c90a75bf6f05f49caa539e8ee2066d270aacb8a690cdb5c56492bdccab',1998,'KG','Kyrgyzstan','economy',560,'Economy— overview: Kyrgyzstan is a small, poor,
mountainous country with a predominantly agricultural
economy. Cotton, wool, and meat are the main
agricultural products and exports. Industrial exports
include gold, mercury, uranium, and hydropower.
Kyrgyzstan has been one of the most progressive
countries of the former Soviet Union in carrying out
market reforms. Following a successful stabilization
program, which lowered inflation from 88% in 1 994 to
15% for 1997, attention is turning toward stimulating
growth. Much of the government''s stock in enterprises
has been sold. Drops in production have been severe
since the breakup of the Soviet Union in December
1991, but by mid-1995 production began to recover
and exports began to increase. Pensioners,
unemployed workers, and government workers with
salary arrears continue to suffer. Foreign assistance
played a substantial role in the country''s economic
turnaround in 1996-97.
GDP: purchasing power parity— $9.7 billion
(1997 est.)
GDP— real growth rate: 10% (1997 est.)
GDP— per capita: purchasing power parity— $2,1 00
(1997 est.)
GDP— composition by sector:
agriculture: 47%
industry: 12%
services: 41% (1996 est.)
Inflation rate— consumer price index: 15%
(1997 est.)
Labor force:
total: 1 .7 million
by occupation: agriculture and forestry 40%, industry
and construction 19%, other 41% (1995 est.)
Unemployment rate: 8% (December 1996 est.)
Budget:
revenues: $225 million
expenditures: $308 million, including capital
expenditures of $1 1 million (1996 est.)
Industries: small machinery, textiles, food
processing, cement, shoes, sawn logs, refrigerators,
furniture, electric motors, gold, rare earth metals
Industrial production growth rate: 10.8% (1996
est.)
Electricity— capacity: 3.632 million kW (1995)
Electricity— production: 13.7 billion kWh
(1996 est.)
Electricity— consumption per capita: 2,090 kWh
(1995)
Agriculture— products: wool, tobacco, cotton,
potatoes, vegetables, grapes, fruits and berries;
sheep, goats, cattle
Exports:
total value: $506 million (1996)
commodities: cotton, wool, meat, tobacco; gold,
mercury, uranium, hydropower; machinery; shoes
partners: China, UK, FSU
Imports:
total value: $890 million (1 996)
commodities: grain, lumber, industrial products,
ferrous metals, fuel, machinery, textiles, footwear
partners: Turkey, Cuba, US, Germany
Debt— external: $746 million (1996)
Economic aid:
recipient: ODA, $56 million (1993)
note: commitments, 1992-95, $1,695 million ($390
million disbursements)
Currency: 1 Kyrgyzstani som (KGS) = 100 tyiyn
Exchange rates: soms (KGS) per US$1— 14.6
(January 1997), 11.2 (yearend 1995), 10.6 (yearend
1994)
Fiscal year: calendar year
Economy— overview: The government of Laos-
one of the few remaining official communist states—
has been decentralizing control and encouraging
private enterprise since 1986. The results, starting
from an extremely low base, have been striking-
growth averaged 7% in 1988-96. Because Laos
depends heavily on its trade with Thailand, it fell victim
to the financial crisis in the region in 1997, when
growth was a mere 1 .5%. Laos is a landlocked country
with a primitive infrastructure. It has no railroads, a
rudimentary road system, and limited external and
internal telecommunications. Electricity is available in
only a few urban areas. Subsistence agriculture
accounts for half of GDP and provides 80% of total
employment. The predominant crop is glutinous rice.
In non-drought years, Laos is self-sufficient overall in
food, but each year flood, pests, and localized drought
cause shortages in various parts of the country. For
the foreseeable future the economy will continue to
depend on aid from the IMF and other international
sources; Japan is currently the largest bilateral aid
donor; aid from the former USSR/Eastern Europe has
been cut sharply. As in many developing countries,
deforestation and soil erosion will hamper efforts to
regain a high rate of GDP growth.
GDP: purchasing power parity— $5.9 billion
(1997 est.)
GDP— real growth rate: 1 .5% (1 997 est.)
GDP— per capita: purchasing power parity— $1,150
(1997 est.)
GDP— composition by sector:
agriculture: 56%
industry: 1 9%
services: 25% (1997 est.)
Inflation rate— consumer price index: 16%
(1997 est.)
Labor force: 1 million-1.5 million
by occupation: agriculture 80% (1997 est.)
Unemployment rate: 1 .7% overall; 4.5% in urban
areas (1995 est.)
Budget:
revenues; $230.2 million
expenditures: $365.9 million, including capital
expenditures of $317 million (1996)
Industries: tin and gypsum mining, timber, electric
power, agricultural processing, construction,
garments
Industrial production growth rate: NA%
Electricity— capacity: 217,000 kW (1997)
Electricity— production: 1.2 billion kWh (1996)
Electricity— consumption per capita: 60 kWh
(1995)
Agriculture— products: sweet potatoes,
vegetables, corn, coffee, sugarcane, cotton; water
buffalo, pigs, cattle, poultry; tobacco
Exports:
total va/ue: $313.1 million (f.o.b., 1996)
commodities: wood products, garments, electricity,
coffee, tin
partners: Vietnam, Thailand, Germany, France
Imports:
total value: $ 678 million (c.i.f., 1996)
commodities: machinery and equipment, vehicles,
fuel
partners: Thailand, Japan, Vietnam, China, Singapore
Debt— external: $1.2 billion (1996)
Economic aid:
recipient: ODA, $212.2 million
Currency: 1 new kip (NK) = 100 at
Exchange rates: new kips (NK) per US$1— 2,500
(January 1998), 1,256.73 (1997), 921.14 (1996),
804.69 (1995), 717.67 (1994), 716.25 (1993)
note: as of September 1 995, a floating exchange rate
policy was adopted
Fiscal year: 1 October— 30 September','5a255c7751c830736c7a3a43aa295afcd35b00f4fc3853e7de168e9909f8175e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('878c1b4176d64636ef6c439b2c85a1aa6c5170a8751ebbe14ff12f277a66cdbd',1998,'LV','Latvia','economy',568,'Economy— overview: In 1 997 Latvia scored the
most impressive economic achievements since
independence in 1 991 , with GDP growing by 6% and
inflation at 7.4%. GDP is expected to grow 5% in 1 998
and inflation to range between 6% and 7%. In 1997
Latvia continued its strict fiscal policy and apparently
ended the year with a small fiscal surplus, reflecting
higher-than-expected income from customs
revenues, excise and business taxes, and restraints
on government spending. Foreign direct investment
(FDI) in 1997 was a record $880 million by yearend.
Prospects for increasing FDI in 1 998 are good if Latvia
privatizes at least some of its large companies,
including Venspils Nafta (the state oil company).
Although Latvia was disappointed that it was not
included among the five Central and East European
states invited to start EU accession talks in spring
1998, it is likely to join the WTrO in 1998. Latvia''s
growing current account and trade deficits remain a
cause for concern, reaching nearly 10% by yearend.
Latvia''s trade deficit may even reach 22% of GDP in
1998.
GDP: purchasing power parity— $1 0.4 billion
(1997 est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity— $4,260
(1997 est.)
GDP— composition by sector:
agriculture: 9%
industry: 34%
services: 57% (1995)
Inflation rate— consumer price index: 7.4%
(1997 est.)
Labor force:
fofa/; 1 .4 million (1997)
by occupation: industry 41 %, agriculture and forestry
16%, services 43% (1990)
Unemployment rate: 7% (1996)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: buses, vans, street and railroad cars,
synthetic fibers, agricultural machinery, fertilizers,
washing machines, radios, electronics,
pharmaceuticals, processed foods, textiles;
dependent on imports for energy, raw materials, and
intermediate products
Industrial production growth rate: 2% (1996 est.)
Electricity— capacity: 2.035 million kW (1995)
Electricity— production: 4.095 billion kWh (1995)
Electricity— consumption per capita: 2,300 kWh
(1995)
Agriculture— products: grain, sugar beets,
potatoes, vegetables; meat, milk, eggs; fish
Exports:
total value: $1.4 billion (f.o.b., 1996)
commodities: wood and wood products, textiles,
foodstuffs
partners: Russia, other CIS, Germany, Sweden, UK
267
Latvia (continued)
Imports:
total value: $2,3 billion (c.i.f., 1996)
commodities: fuels, machinery and equipment,
chemicals
partners: Russia, other CIS, Germany, Sweden, UK,','8b1db4aec0f15929ded7f9fa0987c63e8ac0069ef5acd5d9f7c2094dacfea451','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('599e0c11357656bf16c8bd13bec29670a3bb2bf7e22e0dc5455ee60c0d1f65b7',1998,'ZA','South Africa','economy',575,'Economy— overview: Small, landlocked, and
mountainous, Lesotho has no important natural
resources other than water. Its economy is based on
agriculture, light manufacturing, and remittances from
miners employed in South Africa. The number of such
mine workers has declined steadily over the past five
years; in 1996 their remittances added about 33% to
GDP compared with the addition of roughly 67% in
1990. Manufacturing depends largely on farm
products which support the milling, canning, leather,
and jute industries. Recent foreign investments will
enable Lesotho to export garments made from
imported textiles. Although drought has decreased
agricultural activity over the past few years,
completion of a major hydropower facility in January
1998 now permits the sale of water to South Africa
and will support the economy''s continued expansion.
The pace of the privatization of state-owned firms
increased toward the end of 1 994.
GDP: purchasing power parity— $5.1 billion
(1997 est.)
GDP— real growth rate: 9% (1997 est.)
GDP— per capita: purchasing power parity— $2,500
(1997 est.)
GDP— composition by sector:
agriculture: 10%
industry: 53%
services: 37% (1997)
Inflation rate— consumer price index: 8,7% (1996
est.)
Labor force:
total: 689,000 economically active
by occupation: 86% of resident population engaged in
subsistence agriculture; roughly 35% of the active
male wage earners work in South Africa
Unemployment rate: substantial unemployment
and underemployment effecting more than half of the
labor force (1996 est.)
Budget:
revenues; $507 million
expenditures: $487 million, including capital
expenditures of $170 million (FY96/97 est.)
Industries: food, beverages, textiles, handicrafts;
construction; tourism
Industrial production growth rate: 19.7% (1995)
Electricity— capacity: 0kW(1995)
note: electricity supplied by South Africa
Electricity— production: 0 kWh (1995)
note: electricity supplied by South Africa
Electricity— consumption per capita: 163 kWh
(1995)
Agriculture— products: corn, wheat, pulses,
sorghum, barley; livestock
Exports:
total value: $21 8 million (f.o.b., 1996 est.)
commodities: clothing, wool, footwear, road vehicles,
mohair (1995)
partners: South African Customs Union 52%, North
America 38%, EU 9% (1995)
Imports:
total value: $ 1.1 billion (c.i.f., 1996 est.)
commodities: corn, clothing, building materials,
vehicles, machinery, medicines, petroleum products
(1993)
partners: South African Customs Union 90%, Asia
6%, EU 2% (1995)
Debt— external: $517 million (FY95/96 est.)
Economic aid:
recipient : ODA, $NA
Currency: 1 loti (L) = 100 lisente
note : maloti (M) is the plural form of loti
Exchange rates: maloti (M) per US$1— 4.94193
(January 1998), 4.60796 (1997), 4.29935 (1996),
3.62709 (1995), 3.55080 (1994), 3.26774 (1993);
note— the Basotho loti is at par with the South
African rand
Fiscal year: 1 April— 31 March
Economy— overview: Civil war since 1990 has
destroyed much of Liberia''s economy, especially the
infrastructure in and around Monrovia. Many
businessmen have fled the country, taking capital and
expertise with them. Some returned during 1997.
Many will not return. Richly endowed with water,
mineral resources, forests, and a climate favorable to
agriculture, Liberia had been a producer and exporter
of basic products, while local manufacturing, mainly
foreign owned, had been small in scope. The
democratically elected government, installed in
August 1997, inherited massive international debts
and currently relies on revenues from its maritime
registry to provide the bulk of its foreign exchange
earnings. The restoration of the infrastructure and the
raising of incomes in this ravaged economy depends
on continued disarmament of factions and the
implementation of sound macro- and micro-economic
policies of the new government.
GDP: purchasing power parity— $2.6 billion (1997
est.)
GDP— real growth rate: NA% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,000
(1997 est.)
GDP— composition by sector:
agriculture: 30%
industry: 36%
services: 34%
inflation rate— consumer price index: NA%
Labor force:
by occupation: agriculture 70%
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures : $NA
Industries: rubber processing, food processing,
construction materials, furniture, palm oil processing,
iron ore, diamonds
Industrial production growth rate: NA%
Electricity— capacity: 332,000 kW (1995)
Electricity— production: 472 million kWh (1995)
Electricity— consumption per capita: 154 kWh
(1995)
Agriculture— products: rubber, coffee, cocoa, rice,
cassava (tapioca), palm oil, sugarcane, bananas;
sheep, goats; timber
Exports:
total value: $667 million (f.o.b., 1995 est.)
commodities: diamonds, iron ore, rubber, timber,
coffee
partners: US, EU, Netherlands, Singapore
Imports:
total value: $5.8 billion (f.o.b., 1995 est.)
commodities: mineral fuels, chemicals, machinery,
transportation equipment, manufactured goods; rice
and other foodstuffs
partners: US, EU, Japan, China, Netherlands,
ECOWAS, South Korea
Debt— external: $2 billion (1997 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Liberian dollar (L$) = 100 cents
Exchange rates: Liberian dollars (L$) per US$1 —
1 .0000 (officially fixed rate since 1940); market
exchange rate: Liberian dollars (L$) per US$1— 50
(October 1995), 7 (January 1992); market rate floats
against the US dollar
Fiscal year: calendar year','cf641c2b5be19f0d198d0fa21cbc623f0c210e694b6d887c13a1ba94fdace880','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15d2ab9c1a5cdfdb196add18cc8d01634745741045fb023a4398a0caad2457e2',1998,'LY','Libya','economy',583,'Economy— overview: The socialist-oriented
economy depends primarily upon revenues from the
oil sector, which contributes practically all export
earnings and about one-third of GDP. Per capita GDP
is the highest in Africa at $6,700, but
disproportionately little of national income flows down
to the lower orders of society. GDP growth fluctuates
sharply in response to changes in the world oil market;
GDP has either contracted or grown very sluggishly
since 1 992. Import restrictions and inefficient resource
allocations have led to periodic shortages of basic
goods and foodstuffs. The nonoil manufacturing and
construction sectors, which account for about 20% of
GDP, have expanded from processing mostly
agricultural products to include the production of
petrochemicals, iron, steel, and aluminum. Although
agriculture accounts for only 5% of GDP, it employs
18% of the labor force. Climatic conditions and poor
soils severely limit farm output, and Libya imports
about 75% of its food requirements. The UN sanctions
imposed in April 1992 do not have a major impact on
the economy although they have increased
transaction and transportation costs.
GDP: purchasing power parity— $38 billion (1997
est.)
GDP— real growth rate: 0.5% (1997 est.)
GDP— per capita: purchasing power parity— $6,700
(1997 est.)
GDP— composition by sector:
agriculture: 5%
industry: 55%
services: 40% (1996 est.)
Inflation rate— consumer price index: 30% (1997
est.)
Labor force:
total: 1 million
by occupation: industry 31%, services 27%,
government 24%, agriculture 18%
note: 3% of the population in the 15-64 age group is
non-national (July 1998 est.)
Unemployment rate: 25% (1997 est.)
Budget:
revenues: $10.4 billion
expenditures: $10.3 billion, including capital
expenditures of $2.5 billion (1995 est.)
Industries: petroleum, food processing, textiles,
handicrafts, cement
Industrial production growth rate: NA%
Electricity— capacity: 4.6 million kW (1995)
Electricity— production: 17 billion kWh (1995)
Electricity— consumption per capita: 3,239 kWh
(1995)
Agriculture— products: wheat, barley, olives,
dates, citrus, vegetables, peanuts; meat, eggs
Exports:
total value: $9 billion (f.o.b., 1995)
commodities: crude oil, refined petroleum products,
natural gas
partners: Italy, Germany, Spain, France, Turkey,
Greece, Egypt
Imports:
total value: $6.2 billion (f.o.b., 1995)
commodities: machinery, transport equipment, food,
manufactured goods
partners: Italy, Germany, UK, France, Spain, Turkey,
Tunisia, Eastern Europe
Debt— external: $2.6 billion excluding military debt
(1995 est.)
Economic aid: $NA
Currency: 1 Libyan dinar (LD) = 1 ,000 dirhams
Exchange rates: Libyan dinars (LD) per US$1 —
0.3902 (January 1998), 0.3891 (1997), 0.3651 (1996),
0.3532 (1995), 0.3596 (1994), 0.3250 (1993)
Fiscal year: calendar year','21d8321b8a72fb23131f09c9b20d0a1b38386499e517b657b0bd1be2a84f8505','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc97ce4b58fa85f323a53e191e20d77d9615ac4955117880e9752ff70efdcd7a',1998,'CH','Switzerland','economy',591,'Economy— overview: Despite its small size and
limited natural resources, Liechtenstein has
developed into a prosperous, highly industrialized,
free-enterprise economy with a vital financial service
sector and living standards on a par with the urban
areas of its large European neighbors. Low business
taxes— the maximum tax rate is 18%— and easy
incorporation rules have induced about 73,700
holding or so-called letter box companies to establish
nominal offices in Liechtenstein, providing 30% of
state revenues. The country participates in a customs
union with Switzerland and uses the Swiss franc as its
national currency. It imports more than 90% of its
energy requirements. Liechtenstein is a member of
the European Economic Area (an organization
serving as a bridge between EFTA and EU) since May
1995. The government is working to harmonize its
economic policies with those of an integrated Europe.
GDP: purchasing power parity— $713 million (1996
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity —
$23,000 (1996 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 0.5% (1997
est.)
Labor force:
total: 22,891 of which 13,847 are foreigners; 8,231
commute from Austria and Switzerland to work each
day
by occupation: industry, trade, and building 46%,
services 52%, agriculture, fishing, forestry, and
horticulture 2% (1996 est.)
Unemployment rate: 1 .6% (1 997)
Budget:
revenues; $455 million
expenditures: $435 million, including capital
expenditures of $NA (1996 est.)
Industries: electronics, metal manufacturing,
textiles, ceramics, pharmaceuticals, food products,
precision instruments, tourism
Industrial production growth rate: NA%
Electricity— capacity: 23,000 kW (1995)
Electricity— production: 150 million kWh (1995)
Electricity— consumption per capita: 8,000 kWh
(1995 est.)
Agriculture— products: wheat, barley, maize,
potatoes; livestock, dairy products
Exports:
total value: $2.47 billion (1 996)
commodities: small specialty machinery, dental
products, stamps, hardware, pottery
partners: EU and EFTA countries 60.57%
(Switzerland 15.7%) (1995)
Imports:
total value: $91 7.3 million (1996)
commodities: machinery, metal goods, textiles,
foodstuffs, motor vehicles
partners: EU countries, Switzerland (1996)
Debt— external: $0(1996)
Economic aid: none
Currency: 1 Swiss franc, franken, or franco (SwF) =
100 centimes, rappen, or centesimi
Exchange rates: Swiss francs, franken, or franchi
(SwF) per US$1— 1.4757 (January 1998), 1.4513
(1997), 1.2360(1996), 1.1825(1995), 1.3677(1994),
1.4776 (1993)
Fiscal year: calendar year
Economy— overview: Lithuania has benefited from
its disciplined approach to market reform and its
adherence to strict fiscal and monetary policies
imposed by the IMF, measures that have helped
constrain the growth of the money supply, reduce
inflation to 8.6%, and support GDP growth of 6% in
1997. Inflation is expected to fall in 1998 to 6% and
GDP to grow at close to 7%. Foreign direct investment
in 1 997 of some $430 million pushed the country over
the $1 billion mark, the first Baltic state to reach this
milestone. However, the current account deficit has
hovered around 8% to 10% of GDP annually since
1995— the result of greater demand for consumer
goods and falling growth in exports.
GDP: purchasing power parity— $15.4 billion (1997
est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity— $4,230
(1997 est.)
GDP— composition by sector:
agriculture: 9%
industry: 28%
sen/ices: 63% (1995 est.)
Inflation rate— consumer price index: 8.6% (1997
est.)
Labor force:
total: 1.8 million
by occupation: industry and construction 42%,
agriculture and forestry 20%, other 38% (1997)
Unemployment rate: 6.7% (January 1998)
Budget:
revenues: $1.5 billion
expenditures: $1.7 billion, including capital
expenditures of $NA (1997 est.)
Industries: metal-cutting machine tools, electric
motors, television sets, refrigerators and freezers,
petroleum refining, shipbuilding (small ships),
furniture making, textiles, food processing, fertilizers,
agricultural machinery, optical equipment, electronic
components, computers, amber
Industrial production growth rate: 3.7% (1996)
Electricity— capacity: 5.463 million kW (1995)
Electricity— production: 14.33 billion kWh (1997
est.)
Electricity— consumption per capita: 2,398 kWh
(1995)
Agriculture— products: grain, potatoes, sugar
beets, vegetables; meat, milk, eggs; fish; flax fiber
Exports:
total value: $3.3 billion (1996)
commodities: agricultural products 16.9%, mineral
products 15.7%, textiles 15.2%, machinery 1 1 .4%,
live animals 7.7% (1996)
partners: Russia, Germany, Belarus, Latvia, Ukraine
(1996)
Imports:
total value: $4.4 billion (1 996)
commodities: mineral production 20%, machinery
16%, transport equipment 10%, chemicals 10%,
textiles 8%, foodstuff 6% (1 996)
partners: Russia, Germany, Poland, Italy, Denmark
(1996)
Debt— external: $895 million
Economic aid:
recipient: ODA, $144 million (1993)
note: commitments from the West and international
financial institutions, $765 million (1992-95)
Currency: 1 Lithuanian litas = 100 centas
Exchange rates: litai per US$1— 4.000 (fixed rate
since 1 May 1994), 3.978 (1994), 4.344 (1993), 1.773
(1992)
Fiscal year: calendar year','3436234134eaf04f56bb04f81159aae2dc4da59a672123c09063bbe0bf2c4249','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43b45b9fd746c4197dd492fd9b3e038e7e29bab12fb5ddee9d876473c255bea2',1998,'MW','Malawi','economy',601,'Economy— overview: Landlocked Malawi ranks
among the world''s least developed countries. The
economy is predominately agricultural, with about
90% of the population living in rural areas. Agriculture
accounts for 45% of GDP and 90% of export
revenues. The economy depends on substantial
inflows of economic assistance from the IMF, the
World Bank, and individual donor nations. The new
government faces strong challenges, e.g., to spur
exports, to improve educational and health facilities,
and to deal with environmental problems of
deforestation and erosion.
GDP: purchasing power parity— $8.6 billion (1997
est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity— $900
(1997 est.)
GDP— composition by sector:
agriculture: 45%
industry: 30%
services: 25% (1 995 est.)
Inflation rate— consumer price index: 83.4%
(1995)
Labor force:
total: 3.5 million
by occupation: agriculture 86%, wage earners 14%
(1990 est.)
Unemployment rate: NA%
Budget:
revenues: $530 million
expenditures: $674 million, including capital
expenditures of $129 million (1993)
Industries: tea, tobacco, sugar, sawmill products,
cement, consumer goods
Industrial production growth rate: 0.9% (1995.)
Electricity— capacity: 185,000 kW (1995)
Electricity— production: 800 million kWh (1995)
Electricity— consumption per capita: 82 kWh
(1995)
Agriculture— products: tobacco, sugarcane,
cotton, tea, corn, potatoes, cassava (tapioca),
sorghum, pulses; cattle, goats
Exports:
total value: $ 405 million (f.o.b., 1995)
commodities: tobacco, tea, sugar, coffee, peanuts,
wood products
partners: US, South Africa, Germany, Japan
Imports:
total value: $ 475 million (f.o.b., 1995)
commodities: food, petroleum products,
semimanufactures, consumer goods, transportation
equipment
partners: South Africa, Zimbabwe, Japan, US, UK,','93a6e28af1509bca8d9ea6c403c0c7845c33df8af9c045e59fdb65d49072371b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('154a1d18d3ea6ab489aaea481356d297b139f13a14cae5d4e0002db6a959acd4',1998,'MX','Mexico','economy',603,'Economy— overview: After decades of high GDP
growth, Malaysia''s economy— shaken by the ongoing
regional financial crisis in 1997/98— is forecast by the
government to grow only 4%-5% in 1 998; private
forecasts project the growth rate could be as low as
2%. The sharp decline in local currency and stock
markets forced Kuala Lumpur to announce tough
cost-cutting measures— on top of a contractionary
budget— to further reduce the current account deficit
to 3% of GDP in 1998 from 5.5% in 1997. To achieve
this goal, Kuala Lumpur will cut government spending
by 20% and continue to slash big-ticket imports and
defer large-scale infrastructure projects. Government
austerity and slower growth mean increased
unemployment and higher interest rates that will bite
into corporate earnings.
GDP: purchasing power parity— $227 billion (1997
est.)
GDP— real growth rate: 7.4% (1997 est.)
GDP— per capita: purchasing power parity —
$11,100 (1997 est.)
GDP— composition by sector:
agriculture: 14%
industry: 45%
services: 41% (1995 est.)
Inflation rate— consumer price index: 36% (1996)
Labor force:
total: 8.398 million (1996 est.)
by occupation: manufacturing 25%, agriculture,
forestry, and fisheries 21%, local trade and tourism
17%, services 12%, government 11%, construction
8% (1996)
Unemployment rate: 2.6% (1996 est.)
Budget:
revenues: $22.6 billion
expenditures: $22 billion, including capital
expenditures of $5.3 billion (1996 est.)
Industries: Peninsular Malaysia— rubber and oil
palm processing and manufacturing, light
manufacturing industry, electronics, tin mining and
smelting, logging and processing timber; Sabah—
logging, petroleum production; Sarawak— agriculture
processing, petroleum production and refining,
logging
Industrial production growth rate: 14.4% (1995)
Electricity— capacity: 7.83 million kW (1995)
Electricity— production: 42 billion kWh (1995)
Electricity— consumption per capita: 2,132 kWh
(1995)
Agriculture — products: Peninsular Malaysia-
natural rubber, palm oil, rice; Sabah— subsistence
crops, rubber, timber, coconut, rice; Sarawak—
rubber, pepper; timber
Exports:
total value: $78.2 billion (1996)
commodities : electronic equipment, petroleum and
petroleum products, palm oil, wood and wood
products, rubber, textiles
partners: US 21 %, Singapore 20%, Japan 1 2%, Hong
Kong 5%, UK 4%, Thailand 4%, Germany 3% (1995)
Imports:
total value: $78.4 billion (1996)
commodities: machinery and equipment, chemicals,
food
partners: Japan 27%, US 16%, Singapore 12%,
Taiwan 5%, Germany 4%, South Korea 4% (1995)
Debt— external: $27.5 billion (1995 est.)
Economic aid:
recipient: ODA, $45 million (1993)
Currency: 1 ringgit (M$) = 100 sen
Exchange rates: ringgits (M$) per US$1— 4.3985
(January 1 998), 2.81 33 (1 997), 2.51 59 (1 996), 2.5044
(1995), 2.6243 (1994), 2.5741 (1993)
Fiscal year: calendar year
Economy— overview: Mexico has a free market
economy with a mixture of modern and outmoded
industry and agriculture, increasingly dominated by the
private sector. The number of state-owned enterprises
in Mexico has fallen from more than 1 ,000 in 1982 to
fewer than 200 in 1 998. The ZEDILLO administration is
privatizing and expanding competition in sea ports,
railroads, telecommunications, electricity, natural gas
distribution, and airports. The Mexican economy is in
its third year of recovery from the recession of 1 995,
which was touched off by a financial crisis. After
declining 6.2% in 1995, real GDP grew 5.1% in 1996
and 7.3% in 1997 and is expected to rise by 5% in
1998. A strong export sector helped to cushion the
311
Mexico (continued)
economy''s decline in 1995 and led the recovery in
1 996 and 1 997. Private consumption spending in 1 998
probably will rise by at least 4% on the strength of
increased employment and rising real wages, and the
troubled banking sector is likely to increase lending for
the first time in three years. Despite the spillover from
the Asian crisis, the medium-term outlook for Mexico
remains positive, with government and private sector
economists projecting average annual growth of 4% to
5% through the year 2000. Mexico still needs to
overcome many structural problems as it strives to
modernize its economy and raise living standards.
Income distribution is very unequal with the top 20% of
income earners accounting for 55% of income. The
inefficient agricultural sector employs 20% to 25% of
the labor force but produces only 8% of GDP. Trade
with the United States and Canada has nearly doubled
since NAFTA was implemented in 1994. Mexico is
pursuing additional trade agreements with most
countries in Latin America and with the European
Union to lessen its dependence on the United States,
which accounts for 80% of Mexico''s total trade.
GDP: purchasing power parity— $694.3 billion (1 997
est.)
GDP— real growth rate: 7.3% (1997 est.)
GDP— per capita: purchasing power parity— $7,700
(1997 est.)
GDP— composition by sector:
agriculture: 8%
industry: 33%
services: 59% (1997 est.)
Inflation rate— consumer price index: 15.7%
(1997 est.)
Labor force:
total: 36.6 million (1996)
by occupation: services 28.8%, agriculture, forestry,
hunting, and fishing 21 .8%, commerce 17.1%,
manufacturing 16.1%, construction 5.2%, public
administration and national defense 4.4%,
transportation and communications 4.1%
Unemployment rate: 3.7% (1997 est.) urban; plus
considerable underemployment
Budget:
revenues: $92 billion
expenditures: $94 billion, including capital
expenditures of $NA (1997 est.)
Industries: food and beverages, tobacco,
chemicals, iron and steel, petroleum, mining, textiles,
clothing, motor vehicles, consumer durables, tourism
Industrial production growth rate: 9.3% (1997
est.)
Electricity— capacity: 35.466 million kW (1995)
Electricity— production: 145.199 billion kWh
(1995)
Electricity— consumption per capita: 1 ,533 kWh
(1995)
Agriculture— products: corn, wheat, soybeans,
rice, beans, cotton, coffee, fruit, tomatoes; beef,
poultry, dairy products; wood products
Exports:
total value: $11 0.4 billion (f.o.b., 1997 est.), includes
in-bond industries
commodities: crude oil, oil products, coffee, silver,
engines, motor vehicles, cotton, consumer electronics
partners: US 85%, Canada 2.1%, Japan 1%, Spain
1%, Chile 1%, Brazil 1% (1997 est.)
Imports:
total value: $109.8 billion (f.o.b., 1997 est.), includes
in-bond industries
commodities: metal-working machines, steel mill
products, agricultural machinery, electrical
equipment, car parts for assembly, repair parts for
motor vehicles, aircraft, and aircraft parts
partners: US 74.8%, Japan 4.1%, Germany 3.5%,
Canada 1.8%, South Korea 1.4%, Italy 1.2%, France
1.1% (1997 est.)
Debt— external: $162 billion (1997 est.)
Economic aid:
recipient: O DA, $85 million (1993)
Currency: 1 New Mexican peso (Mex$) = 100
centavos
Exchange rates: market rate of Mexican pesos
(Mex$) per US$1 — 8.1798 (January 1998), 7.9141
(1997), 7.5994(1996), 6.4194 (1995), 3.3751 (1994),
3.1156 (1993)
Fiscal year: calendar year
Economy— overview: Norway is a prosperous
bastion of welfare capitalism. The economy consists
of a combination of free market activity and
government intervention. The government controls
key areas, such as the vital petroleum sector (through
large-scale state enterprises), and extensively
subsidizes agriculture, fishing, and areas with sparse
resources. Norway maintains an extensive welfare
system that helps propel public sector expenditures to
more than 50% of GDP and results in one of the
highest average tax levels in the world. A small
country with a high dependence on international
trade, Norway is basically an exporter of raw materials
and semiprocessed goods, with an abundance of
small- and medium-sized firms, and is ranked among
the major shipping nations. The country is richly
endowed with natural resources— petroleum,
hydropower, fish, forests, and minerals— and is highly
dependent on its oil sector. Only Saudi Arabia exports
more oil than Norway. Norway imports more than half
its food needs. Oslo opted to stay out of the EU during
a referendum in November 1994. Economic growth in
1998 should be about the same as in 1997. Inflation
probably will move up toward 3% because of tightness
in labor markets. Despite their high per capita
income— outstripped among major nations only by the
US— and their generous welfare benefits, the
Norwegians worry about that time in the 21st century
when the oil and gas run out.
GDP: purchasing power parity— $1 20.5 billion (1 997
est.)
GDP-real growth rate: 3.5% (1997 est.)
GDP— per capita: purchasing power parity —
$27,400 (1997 est.)
GDP— composition by sector:
agriculture: 2.9%
industry: 34.7%
services: 62.4% (1991)
Inflation rate— consumer price index: 2% (1997
est.)
Labor force:
total: 2.1 3 million
by occupation: services 71%, industry 23%,
agriculture, forestry, and fishing 6% (1993)
Unemployment rate: 2.6% (yearend 1997)
Budget:
revenues: $48.6 billion
expenditures: $53 billion, including capital
expenditures of $NA (1994 est.)
Industries: petroleum and gas, food processing,
shipbuilding, pulp and paper products, metals,
chemicals, timber, mining, textiles, fishing
Industrial production growth rate: 3% (1996 est.)
Electricity— capacity: 26.431 million kW (1995)
Electricity— production: 121.375 billion kWh
(1995)
Electricity— consumption per capita: 26,547 kWh
(1995)
Agriculture— products: oats, other grains; beef,
milk; livestock output exceeds value of crops; among
world''s top 1 0 fishing nations; fish catch of 2.33 million
metric tons in 1994
Exports:
total value: $49.3 billion (f.o.b., 1996)
commodities: petroleum and petroleum products
43%, metals and products 11%, foodstuffs (mostly
fish) 9%, chemicals and raw materials 25%, natural
gas 6.0%, ships 5.4%
partners: EU 77.2% (UK 19.8%, Germany 12.7%,
Netherlands 9.1%, France 7.8%, Sweden 9.8%), US
6.0% (1995)
Imports:
total value: $ 35.1 billion (c.i.f., 1996)
commodities: machinery and equipment and
manufactured consumer goods 54%, chemicals and
other industrial inputs 39%, foodstuffs 6%
partners: EU 71.0% (Sweden 15.4%, Germany
1 3.8%, UK 9.7%, Denmark 7.5%, Netherlands 4.4%),
US 6.6% (1995)
Debt— external: $NA
Economic aid:
donor: ODA, $1 .014 billion (1993)
Currency: 1 Norwegian krone (NKr) = 100 oere
Exchange rates: Norwegian kroner (NKr) per
US$1 -7.4875 (January 1998), 7.0734 (1997),
6.4498 (1996), 6.3352 (1995), 7.0576 (1994), 7.0941
(1993)
Fiscal year: calendar year
Economy— overview: Poland today stands out as
one of the most successful and open transition
economies. The privatization of small and medium
state-owned companies and a liberal law on establishing
new firms marked the rapid development of a private
sector now responsible for at least two-thirds of
economic activity. In contrast to the vibrant expansion of
private non-farm activity, the large agriculture
component remains handicapped by structural
problems, surplus labor, inefficient small farms, and lack
of investment. The government''s determination to enter
the EU as soon as possible affects all aspects of its
economic policies. Improving Poland''s worsening
current account deficit also is a priority. To date, the
government has resisted pressure for protectionist
solutions and continues to support regional free trade
initiatives. The government export strategy emphasizes
a more aggressive export assistance program. Warsaw
continues to hold the budget deficit to less than 2% of
GDP. Further progress on public finance depends
mainly on comprehensive reform of the social welfare
system and privatization of Poland''s remaining state
sector. Restructuring and privatization of "sensitive
sectors" (e.g., coal, steel) has been delayed.
Long-awaited privatizations in aviation, energy, and
telecommunications are scheduled for 1998.
GDP: purchasing power parity— $280.7 billion (1 997
est.)
GDP— real growth rate: 6.9% (1997 est.)
GDP— per capita: purchasing power parity— $7,250
(1997 est.)
GDP— composition by sector:
agriculture: 6.6%
industry: 34.9%
services: 58.5% (1996 est.)
Inflation rate— consumer price index: 15% (1997
est.)
Labor force:
total: 17.7 million (1997 est.)
by occupation: industry and construction 29.9%,
agriculture 26%, services 44.1% (1996)
Unemployment rate: 1 2% (1 997)
Budget:
revenues: $33.8 billion
expenditures: $35.5 billion, including capital
expenditures of $NA (1997 est.)
Industries: machine building, iron and steel, coal
mining, chemicals, shipbuilding, food processing,
glass, beverages, textiles
Industrial production growth rate: 1 1 .2% (1 997
est.)
Electricity— capacity: 33.5 million kW (1997 est.)
Electricity— production: 1 42 billion kWh (1 997 est.)
Electricity— consumption per capita: 3,360 kWh
(1995)
Agriculture— products: potatoes, milk, cheese,
fruits, vegetables, wheat; poultry and eggs; pork, beef
Exports:
total value: $26.4 billion (f.o.b., 1997 est.)
commodities : intermediate goods 38%, machinery
and transport equipment 23%, consumer goods 21 %,
foodstuffs 10%, fuels 7% (1996 est.)
partners: Germany 34.5%, Russia 6.8%, France
5.9%, Italy 5.6%, US 4.8%, Netherlands 4.1% (1996)
Imports:
total value: $44.5 billion (f.o.b., 1997 est.)
commodities : machinery and transport equipment
32%, intermediate goods 20%, chemicals 15%,
consumer goods 9%, food 9%, fuels 8% (1996 est.)
partners: Germany 26.5%, Italy 10.4%, Russia 7.3%,
UK 6.3%, Netherlands 4.8%, France 4.4% (1996)
Debt— external: $43 billion (1997 est.)
Economic aid:
recipient: US, $210 million (1995-97)
Currency: 1 zloty (Zl) = 100 groszy
Exchange rates: zlotych (Zl) per US$1— 3.54
(January 1 998), 3.2793 (1 997), 2.6961 (1 996), 2.4250
(1995); note— a currency reform on 1 January 1995
replaced 10,000 old zlotys with 1 new zloty; 22,723
(1994), 18,115 (1993), 13,626 (1992)
Fiscal year: calendar year
Economy— overview: Portugal''s short-term
economic fundamentals remain strong: 1997 was
marked by a reduction in inflation, a rise in the GDP
growth rate, a reduction in the fiscal deficit, and a
lowering of interest rates. The Socialist government''s
primary economic goal is to place Portugal in the initial
group of countries adopting the single European
currency; Lisbon looks well positioned to be in the first
tranche of EMU countries. As for the long run, Portugal
380
is increasing its infrastructure spending, in anticipation
of hosting the world''s International Exposition, which
began in May 1998. Lisbon also is working to
modernize its capital plant and increase
competitiveness in hope of moving up closer to the EU
average.
GDP: purchasing power parity— $149.5 billion (1997
est.)
GDP— real growth rate: 3.3% (1997 est.)
GDP— per capita: purchasing power parity —
$15,200 (1997 est.)
GDP— composition by sector:
agriculture: 6%
industry: 36%
services: 58% (1995 est.)
Inflation rate— consumer price index: 2.3% (1997
est.)
Labor force:
total: 4.53 million (1996 est.)
by occupation: services 56%, manufacturing 23%,
agriculture, forestry, fisheries 11%, construction 8%,
utilities 1%, mining 1% (1995)
Unemployment rate: 7% (January 1998)
Budget:
revenues: $48 billion
expenditures: $52 billion, including capital
expenditures of $7.4 billion (1996 est.)
Industries: textiles and footwear; wood pulp, paper,
and cork; metalworking; oil refining; chemicals; fish
canning; wine; tourism
Industrial production growth rate: 2.2% (1996
est.)
Electricity— capacity: 8.831 million kW (1995)
Electricity— production: 31.446 billion kWh (1995)
Electricity— consumption per capita: 3,072 kWh
(1995)
Agriculture— products: grain, potatoes, olives,
grapes; sheep, cattle, goats, poultry, meat, dairy
products
Exports:
total value: $23.8 billion (f.o.b., 1996)
commodities: clothing and footwear, machinery, cork
and paper products, hides
partners: EU 76%, other developed countries 9% (US
5%)
Imports:
total value: $33.9 billion (c.i.f., 1996)
commodities: machinery and transport equipment,
agricultural products, chemicals, petroleum, textiles
partners: EU 72%, other developed countries 8% (US
3%), less developed countries 17% (1995)
Debt— external: $13.1 billion (1997 est.)
Economic aid:
donor: ODA, $220 million (1996)
recipient: ODA, $70 million (1993)
Currency: 1 Portuguese escudo (Esc) = 100
centavos
Exchange rates: Portuguese escudos (Esc) per
US$1— 185.81 (January 1998), 175.31 (1997),
154.24 (1996), 151.11 (1995), 165.99 (1994), 160.80
(1993)
Fiscal year: calendar year
Economy— overview: Vietnam is a poor, densely
populated country that has had to recover from the
ravages of war, the loss of financial support from the
old Soviet Bloc, and the rigidities of a centrally
planned economy. Substantial progress has been
achieved over the past 10 years in moving forward
from an extremely low starting point. Economic growth
continued at a strong pace during 1 997 with industrial
output rising by 12% and real GDP expanding by
8.5%. These positive numbers, however, masked
some major difficulties that are emerging in economic
performance. Many domestic industries, including
coal, cement, steel, and paper, reported large
stockpiles of inventory and tough competition from
more efficient foreign producers, giving Vietnam a
trade deficit of $3.3 billion in 1997. While
disbursements of aid and foreign direct investment
have risen, they are not large enough to finance the
rapid increase in imports; and it is widely believed that
Vietnam may be using short-term trade credits to
bridge the gap— a risky strategy that could result in a
foreign exchange crunch. Meanwhile, Vietnamese
authorities continue to move slowly toward
implementing the structural reforms needed to
revitalize the economy and produce more competitive,
export-driven industries. Privatization of state
enterprises remains bogged down in political
controversy, while the country''s dynamic private
sector is denied both financing and access to markets.
Reform of the banking sector is proceeding slowly,
raising concerns that the country will be unable to tap
sufficient domestic savings to maintain current high
levels of growth. Administrative and legal barriers are
also causing costly delays for foreign investors and
are raising similar doubts about Vietnam''s ability to
maintain the inflow of foreign capital. Ideological bias
in favor of state intervention and control of the
economy is slowing progress toward a more
liberalized investment environment.
GDP: purchasing power parity— $128 billion (1997
est.)
GDP— real growth rate: 8.5% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,700
(1997 est.)
GDP— composition by sector:
agriculture: 28%
industry: 30%
services: 42% (1 996 est.)
Inflation rate— consumer price index: 5% (1997)
Labor force:
total: 32.7 million
by occupation: agriculture 65%, industry and services
35% (1990 est.)
Unemployment rate: 25% (1 995 est.)
Budget:
revenues: $5.6 billion
expenditures: $6 billion, including capital
expenditures of $1.7 billion (1996 est.)
Industries: food processing, garments, shoes,
machine building, mining, cement, chemical fertilizer,
glass, tires, oil
Industrial production growth rate: 12% (1997
est.)
Electricity— capacity: 5.32 million kW (1995)
Electricity— production: 12.3 billion kWh (1995)
Electricity— consumption per capita: 165 kWh
(1995)
Agriculture— products: paddy rice, corn, potatoes,
rubber, soybeans, coffee, tea, bananas; poultry, pigs;
fish
Exports:
total value: $ 7.1 billion (f.o.b., 1996 est.)
commodities: crude oil, marine products, rice, coffee,
rubber, tea, garments, shoes
partners: Japan, Germany, Singapore, Taiwan, Hong
Kong, France, South Korea
Imports:
total value: $11.1 billion (f.o.b., 1 996 est.)
commodities: machinery and equipment, petroleum
products, fertilizer, steel products, raw cotton, grain,
cement, motorcycles
partners: Singapore, South Korea, Japan, France,
Hong Kong, Taiwan
Debt— external: $7.3 billion Western countries; $4.5
billion CEMA debts primarily to Russia; $9 billion to
$18 billion nonconvertible debt (former CEMA, Iraq,
Iran)
Economic aid:
recipient: ODA, $NA
note: $2.4 billion in credits and grants pledged by
international donors for 1997
Currency: 1 new dong (D) = 100 xu
Exchange rates: new dong (D) per US$1— 12,300
(January 1998), 11,100 (December 1996), 11,193
(1 995 average), 1 1 ,000 (October 1 994), 1 0,800
(November 1993), 8,100 (July 1991)
Fiscal year: calendar year','98427f4d2147bb3ca8af93bbeeac6b0dd17caded599681d6c36b0de2c164ca62','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ce4f35252e1a12859287d7a5899ae91aa2d5624847d94a91a704ab9edf86700',1998,'MV','Maldives','economy',611,'Economy— overview: Tourism, Maldives largest
industry, accounts for about 18% of GDP and more
than 60% of the Maldives'' foreign exchange receipts.
Over 90% of government tax revenue comes from
import duties and tourism-related taxes. About
350,000 tourists visited the islands in 1997. Fishing is
a second leading growth sector. The Maldivian
Government began an economic reform program in
1989 initially by lifting import quotas and opening
some exports to the private sector. Subsequently, it
has liberalized regulations to allow more foreign
investment. Agriculture and manufacturing continue to
play a minor role in the economy, constrained by the
limited availability of cultivable land and the shortage
of domestic labor. Most staple foods must be
imported. Industry, which consists mainly of garment
production, boat building, and handicrafts, accounts
for about 15% of GDP. Maldivian authorities worry
about the impact of erosion and possible global
warming on their low-lying country; 80% of the area is
three feet or less above sea level.
GDP: purchasing power parity— $500 million (1997
est.)
GDP— real growth rate: 6.2% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,800
(1997 est.)
GDP— composition by sector:
agriculture: 22%
industry: 15%
services: 63% (1994 est.)
Inflation rate— consumer price index: 6.3%
(1996)
Labor force:
total: 56,435 (1990 est.)
by occupation: fishing industry and agriculture 25%,
services 21%, manufacturing and construction 21%,
trade, restaurants, and hotels 1 6%, transportation and
communication 10%, other 7%
Unemployment rate: NEGL%
Budget:
revenues: $88 million (excluding foreign grants)
expenditures: $141 million, including capital
expenditures of $NA (1995 est.)
Industries: fish processing, tourism, shipping, boat
building, coconut processing, garments, woven mats,
rope, handicrafts, coral and sand mining
Industrial production growth rate: 6.3% (1994
est.)
Electricity— capacity: 14,000 kW (1995)
Electricity— production: 50 million kWh (1995)
Electricity— consumption per capita: 191 kWh
(1995)
Agriculture— products: coconuts, corn, sweet
potatoes; fishing
Exports:
total value: $ 59 million (f.o.b., 1996)
commodities: fish, clothing
partners: Sri Lanka, US, Germany, Singapore, UK
Imports:
total value: $302 million (f.o.b., 1996)
commodifies: consumer goods, intermediate and
capital goods, petroleum products
partners: Singapore, India, Sri Lanka, Hong Kong,
Japan, Thailand
Debt— external: $179 million (1996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 rufiyaa (Rf) = 100 laari
Exchange rates: rufiyaa (Rf) per US$1— 1 1 .770
(1995-January 1998), 11.586 (1994), 10.957 (1993)
Fiscal year: calendar year
294
Economy— overview: Mali is among the poorest
countries in the world, with 65% of its land area desert
or semidesert. Economic activity is largely confined to
the riverine area irrigated by the Niger. About 10% of
the population is nomadic and some 80% of the labor
force is engaged in farming and fishing. Industrial
activity is concentrated on processing farm
commodities. Mali is heavily dependent on foreign aid
and vulnerable to fluctuations in world prices for
cotton, its main export. The government in 1997
continued its successful implementation of an
IMF-recommended structural adjustment program
that is helping the economy grow, diversify, and attract
foreign investment. Mali''s adherence to economic
reform, and the 50% devaluation of the African franc
in January 1994, has pushed up economic growth.
Several multinational corporations increased gold
mining operations in 1996 and the government
projects that Mali will become a major Sub-Saharan
gold exporter in the next few years.
GDP: purchasing power parity— $6 billion (1 997 est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity— $600
(1997 est.)
GDP— composition by sector:
agriculture: 49%
industry: 17%
services: 34% (1995)
Inflation rate— consumer price index: 3% (1997
est.)
Labor force:
total: NA
by occupation: agriculture 80%, services 19%,
industry and commerce 1% (1981)
Unemployment rate: NA%
Budget:
revenues: $730 million
expenditures: $770 million, including capital
expenditures of $320 million (1997 est.)
industries: minor local consumer goods production
and food processing; construction; phosphate and
gold mining
Industrial production growth rate: 0.6% (1995
est.)
Electricity— capacity: 87,000 kW (1995)
Electricity— production: 290 million kWh (1995)
Electricity— consumption per capita: 31 kWh
(1995)
Agriculture— products: cotton, millet, rice, corn,
vegetables, peanuts; cattle, sheep, goats
Exports:
total value: $473 million (f.o.b., 1996 est.)
commodities: cotton, livestock, gold
partners: mostly franc zone and Western Europe
Imports:
total value: $797 million (f.o.b., 1996 est.)
commodities: machinery and equipment, foodstuffs,
construction materials, petroleum, textiles
partners: mostly franc zone and Western Europe
Debt— external: $2.8 billion (1995)
Economic aid:
recipient: ODA, $NA
Currency: 1 Communaute Financiere Africaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1 —
608.36 (January 1 998), 583.67 (1 997), 51 1 .55 (1 996),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 12 January 1994, the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: calendar year
Economy— overview: Significant resources are
limestone, a favorable geographic location, and a
productive labor force. Malta produces only about
20% of its food needs, has limited freshwater supplies,
and has no domestic energy sources. The economy is
dependent on foreign trade, manufacturing (especially
electronics and textiles), and tourism; the state-owned
Malta drydocks employs about 3,800 people. In 1996,
approximately 1 million tourists visited the island. Per
capita GDP of $12,900 places Malta in the range of
the less affluent EU countries. The island is divided
politically over the question of joining the EU.
GDP: purchasing power parity— $4.9 billion (1997
est.)
GDP— real growth rate: 2.8% (1997 est.)
GDP— per capita: purchasing power parity —
$12,900 (1997 est.)
GDP— composition by sector:
agriculture: 5%
industry: 34%
services: 61% (1995 est.)
Inflation rate— consumer price index: 2.3%
(1996)
Labor force:
total: 148,085 (September 1996)
by occupation: public services 34%, other services
32%, manufacturing and construction 22%,
agriculture 2% (1996)
Unemployment rate: 3.7% (September 1996)
Budget:
revenues: $ 1.3 billion
expenditures: $1.5 billion, including capital
expenditures of $219 million (1997 est.)
Industries: tourism; electronics, ship building and
repair, construction; food and beverages, textiles,
footwear, clothing, tobacco
Industrial production growth rate: NA%
Electricity— capacity: 250,000 kW (1994)
Electricity— production: 1 .45 billion kWh (1995)
Electricity— consumption per capita: 3,923 kWh
(1995)
Agriculture— products: potatoes, cauliflower,
grapes, wheat, barley, tomatoes, citrus, cut flowers,
green peppers; pork, milk, poultry, eggs
Exports:
total value: $ 1.7 billion (f.o.b., 1996)
commodities : machinery and transport equipment,
clothing and footware, printed matter
partners: Italy 32%, Germany 16%, UK 8%
Imports:
total value: $2.8 billion (c.i.f., 1996)
commodities: food, petroleum, machinery and
semimanufactured goods
partners: Italy 27%, Germany 14%, UK 13%, US 9%
Debt— external: $134 million (1996)
Economic aid:
recipient: ODA, $NA
Currency: 1 Maltese lira (LM) = 100 cents
Exchange rates: Maltese liri (LM) per US$1 —
0.3960 (January 1 998), 0.3857 (1 997), 0.3604 (1 996),
0.3529 (1995), 0.3776 (1994), 0.3821 (1993)
Fiscal year: 1 April— 31 March
Economy— overview: Offshore banking,
manufacturing, and tourism are key sectors of the
economy. The government''s policy of offering
incentives to high-technology companies and financial
institutions to locate on the island has paid off in
expanding employment opportunities in high-income
industries. As a result, agriculture and fishing, once
the mainstays of the economy, have declined in their
shares of GDP. Banking and other services now
contribute more than half to GDP. T rade is mostly with
the UK. The Isle of Man enjoys free access to EU
markets.
GDP: purchasing power parity— $780 million (1994
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity —
$10,800 (1994 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 2% (1996
est.)
Labor force:
total: 33,577 (1996)
by occupation : manufacturing 11%, construction
10%, transport and communication 8%, retail
distribution 9%, professional and scientific services
18%, public administration 6%, banking and finance
18%
Unemployment rate: 2% (1996 est.)
Budget:
revenues; $333.7 million
expenditures: $333.5 million, including capital
expenditures of $NA (FY94/95 est.)
Industries: financial services, light manufacturing,
tourism
Industrial production growth rate: NA%
Electricity— capacity: NA kW
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Agriculture— products: cereals, vegetables; cattle,
sheep, pigs, poultry
Exports: $NA
commodities: tweeds, herring, processed shellfish,
beef, lamb
partners: UK
Imports: $NA
commodities: timber, fertilizers, fish
partners: UK
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
Currency: 1 Manx pound (£M) = 100 pence
Exchange rates: Manx pounds (£M) per US$1 —
0.6115 (January 1 998), 0.61 06 (1 997), 0.6403 (1 996),
0.6335 (1995), 0.6529 (1994), 0.6658 (1993); the
Manx pound is at par with the British pound
Fiscal year: 1 April— 31 March','ddcf685e5ce1605b1b40b09c62f772dd30627ef98de56e502a66c99ce4367c91','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2f89ca62a89178d6b941a1559d228050437699eeb86256b8b6600b2fc558756',1998,'MH','Marshall Islands','economy',617,'Economy— overview: US Government assistance
is the mainstay of the economy, constituting an
important supplement to GDP. Agricultural production
is concentrated on small farms, and the most
important commercial crops are coconuts, tomatoes,
melons, and breadfruit. Small-scale industry is limited
to handicrafts, fish processing, and copra. The tourist
industry, now a small source of foreign exchange
employing less than 10% of the labor force, remains
the best hope for future added income. The islands
have few natural resources, and imports far exceed
exports. The government is drafting economic reforms
designed to increase revenue and compensate for
reductions in US Government grants— in FY95/96, the
US Government provided grants of $68 million, equal
to roughly 70% of the country''s GDP. More than 25%
of the government''s FY95/96 budget was devoted to
debt repayment. In 1996, efforts to stabilize the
economy included a 27% reduction in the
government''s work force and a 1 0% cut in the budget.
GDP: purchasing power parity— $98 million (1996
est.)
GDP— real growth rate: 2% (1996 est.)
GDP— per capita: purchasing power parity— $1 ,680
(1996 est.)
GDP— composition by sector:
agriculture: 15%
industry: 13%
services: 72% (1995)
Inflation rate— consumer price index: 4% (FY95/
96)
Labor force:
total: 4,800 (1986)
by occupation: NA
Unemployment rate: 16% (1991 est.)
Budget:
revenues: $80.1 million
expenditures: $77.4 million, including capital
expenditures of $19.5 million (FY95/96 est.)
Industries: copra, fish, tourism, craft items from
shell, wood, and pearls, offshore banking (embryonic)
Industrial production growth rate: NA%
Electricity— capacity: 16,000 kW (1994)
Electricity— production: 57 million kWh (1994)
Electricity— consumption per capita: NA kWh
Agriculture— products: coconuts, cacao, taro,
breadfruit, fruits; pigs, chickens
Exports:
total value: $ 17.5 million (f.o.b., 1996 est.)
commodities: fish, coconut oil, fish, trochus shells
partners: US, Japan, Australia
Imports:
total value: $ 71.8 million (c.i.f., 1996 est.)
commodities: foodstuffs, machinery and equipment,
fuels, beverages and tobacco
partners: US, Japan, Australia, NZ
Debt— external: $128 million (FY95/96)
Economic aid:
recipient: under the terms of the Compact of Free
Association, the US is to provide approximately $68
million in aid annually
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October— 30 September','34eab5e349bef0d51baa43721ae537ab7c4fd9fd343dd90b69aa7e333fc0bfea','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('560389e94b81840fad9faa57252bf6938e83c14a9bc97d6b915f1ed952d9ff00',1998,'MR','Mauritania','economy',622,'Economy— overview: A majority of the population
still depends on agriculture and livestock for a
livelihood, even though most of the nomads and many
subsistence farmers were forced into the cities by
recurrent droughts in the 1 970s and 1 980s.
Mauritania has extensive deposits of iron ore, which
account for almost 50% of total exports. The decline in
world demand for this ore, however, has led to
cutbacks in production. The nation’s coastal waters
are among the richest fishing areas in the world, but
overexploitation by foreigners threatens this key
source of revenue. The country''s first deepwater port
opened near Nouakchott in 1986. In recent years,
drought and economic mismanagement have resulted
in a substantial buildup of foreign debt. The
government has begun the second stage of an
economic reform program in consultation with the
World Bank, the IMF, and major donor countries.
Short-term growth prospects are poor because of the
heavy debt service burden, rapid population growth,
and vulnerability to climatic conditions.
GDP: purchasing power parity— $4.1 billion (1996
est.)
GDP— real growth rate: 6% (1996 est.)
GDP— per capita: purchasing power parity— $1 ,750
(1996 est.)
GDP— composition by sector:
agriculture: 26%
industry: 31%
services: 43% (1 996)
Inflation rate— consumer price index: 4.7%
(1996)
305
Mauritania (continued)
Labor force:
total: 465,000 (1981 est.); 45,000 wage earners
(1980)
by occupation: agriculture 47%, services 29%,
industry and commerce 14%, government 10%
Unemployment rate: 23% (1995 est.)
Budget:
revenues: $329 million
expenditures: $265 million, including capital
expenditures of $75 million (1996 est.)
Industries: fish processing, mining of iron ore and
gypsum
Industrial production growth rate: 7.2% (1994)
Electricity— capacity: 105,000 kW (1995)
Electricity— production: 143 million kWh (1995)
Electricity— consumption per capita: 63 kWh
(1995)
Agriculture— products: dates, millet, sorghum, root
crops; cattle, sheep; fish products
Exports:
total value : $494 million (f.o.b., 1996)
commodities: fish and fish products, iron ore, gold
partners: Japan 22%, Italy 16%, France 14%
Imports:
total value: $457 million (c.i.f., 1 996)
commodities: foodstuffs, consumer goods, petroleum
products, capital goods
partners: France 30%, Algeria 10%, Spain 7%, China
6%, US 3%
Debt— external: $2.5 billion (1995)
Economic aid:
recipient: ODA, $NA
Currency: 1 ouguiya (UM) = 5 khoums
Exchange rates: ouguiyas (UM) per US$1 —
169.880 (January 1998), 148.916 (1997), 137.222
(1996), 129.768 (1995), 123.575 (1994), 120.806
(1993)
Fiscal year: calendar year
Economy— overview: In January 1994, Senegal
undertook a bold and ambitious economic reform
program with the support of the international donor
community. This reform began with a 50%
devaluation of Senegal''s currency, the CFA franc,
which is linked at a fixed rate to the French franc. *
Government price controls and subsidies have been
steadily dismantled. After seeing its economy contract
by 2.1% in 1993, Senegal made an important
turnaround, thanks to the reform program, with real
growth in GDP of 5.6% in 1996 and 4.7% in 1997.
Annual inflation has been pushed below 3% and the
fiscal deficit has been cut to less than 1 .5% of GDP.
Investment has been steadily rising from 13.8% of
GDP in 1993 to 16.5% in 1997. As a member of the
West African Economic and Monetary Union
(UEMOA), Senegal is working toward greater regional
integration with a unified external tariff. Senegal also
realized full Internet connectivity in 1996, creating a
miniboom in information technology-based services.
Private activity now accounts for 82% of GDP. On the
negative side, Senegal faces deep-seated urban
problems of chronic unemployment, juvenile
delinquency, and drug addiction.
GDP: purchasing power parity— $15.6 billion (1997
est.)
GDP— real growth rate: 4.7% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,850
(1997 est.)
GDP— composition by sector:
agriculture: 19%
industry: 17%
services: 64% (1996 est.)
Inflation rate— consumer price index: 2.5% (1997
est.)
Labor force: NA
by occupation: agriculture 60%
Unemployment rate: NA%; urban youth 40%
Budget:
revenues: $885 million
expenditures: $885 million, including capital
expenditures of $125 million (1996 est.)
Industries: agricultural and fish processing,
phosphate mining, fertilizer production, petroleum
refining, construction materials
Industrial production growth rate: 7.4% (1996
est.)
Electricity— capacity: 303,440 kW (1997)
Electricity— production: 1 .027 billion kWh (1 997
est.)
Electricity— consumption per capita: 109 kWh
(1997 est.)
Agriculture— products: peanuts, millet, corn,
sorghum, rice, cotton, tomatoes, green vegetables;
cattle, poultry, pigs; fish
Exports:
total value: $ 986 million (f.o.b., 1996)
commodities: fish, ground nuts (peanuts), petroleum
products, phosphates, cotton
partners: France, other EU countries, Cote d''Ivoire,','575911fda8872d077466df20cdb027da3efab1a5b7d540175ff533f42e72d7fb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6656b81fd216b4c1a2dce71a669d2658ac30aa7ed5a7867052c7fa26e4e6dc6',1998,'MU','Mauritius','economy',629,'Economy— overview: Since independence in 1 968,
Mauritius has developed from a low income,
agriculturally based economy to a middle income
diversified economy with growing industrial, financial
services, and tourist sectors. For most of the period,
annual growth has been of the order of 5% to 6%. This
remarkable achievement has been reflected in
increased life expectancy, lowered infant mortality,
and a much improved infrastructure. Sugarcane is
grown on about 90% of the cultivated land area and
accounts for 25% of export earnings. The
government''s development strategy centers on
industrialization (with a view to modernization and to
exports), agricultural diversification, and tourism.
Economic performance in 1991-97 continued strong
with solid growth and low unemployment.
GDP: purchasing power parity— $1 1 .7 billion (1 996
est.)
GDP— real growth rate: 5.4% (1996 est.)
GDP— per capita: purchasing power parity —
$10,300 (1996 est.)
GDP— composition by sector:
agriculture: 8%
industry: 29%
se/v/ces;63%(1996)
Inflation rate— consumer price index: 6.5%
(1996)
Labor force:
total: 51 4, 000 (1995)
by occupation: construction and industry 36%,
services 24%, agriculture and fishing 14%, trade,
restaurants, hotels 16%, transportation and
communication 7%, finance 3% (1995)
Unemployment rate: 1 .8% (1 995)
Budget:
revenues: $822 million (FY 94/95)
expenditures: $ 1 billion, including capital
expenditures of $198 million (FY95/96 est.)
307
Mauritius (continued)
Industries: food processing (largely sugar milling),
textiles, wearing apparel; chemicals, metal products,
transport equipment, nonelectrical machinery; tourism
Industrial production growth rate: 5.8% (1992)
Electricity— capacity: 361 ,000 kW (1995)
Electricity— production: 960 million kWh (1995)
Electricity— consumption per capita: 852 kWh
(1995)
Agriculture— products: sugarcane, tea, corn,
potatoes, bananas, pulses; cattle, goats; fish
Exports:
total value: $1 .6 billion (f.o.b., 1 996 est.)
commodities: clothing and textiles 55%, sugar 24%
(1995)
partners: UK 34%, France 21%, US 15%, Germany
6%, Italy 4% (1995)
Imports:
total value: $22 billion (c.i.f., 1996 est.)
commodities: manufactured goods 37%, capital
equipment 19%, foodstuffs 13%, petroleum products
8%, chemicals 7% (1995)
partners: France 20%, India 8%, Hong Kong 7%, UK
6%, Germany 5% (1995)
Debt— external: $1 .2 billion (1 996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Mauritian rupee (MauR) = 100 cents
Exchange rates: Mauritian rupees (MauRs) per
US$1 — 22.220 (January 1998), 20.561 (1997),
17.948 (1996), 17.386 (1995), 17.960 (1994), 17.648
(1993)
Fiscal year: 1 July— 30 June','a3c74aab0e111ead0756b887e4efac90da4423886f61e0ec83dcb4b56d5bb501','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6e32cc0c801fcc8f96bfd4ba6c67069786e0328ba813b1d4570af78d2583265',1998,'YT','Mayotte','economy',638,'Economy— overview: Economic activity is based
primarily on the agricultural sector, including fishing
and livestock raising. Mayotte is not self-sufficient and
must import a large portion of its food requirements,
mainly from France. The economy and future
development of the island are heavily dependent on
French financial assistance, an important supplement
to GDP. Mayotte''s remote location is an obstacle to
the development of tourism.
GDP: purchasing power parity— $63 million (1997
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $600
(1997 est.)
GDP— composition by sector:
agriculture : NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force: NA
Unemployment rate: 38% (1991 est.)
Budget:
revenues: $NA
expenditures: $73 million, including capital
expenditures of $NA (1991 est.)
Industries: newly created lobster and shrimp
industry
Industrial production growth rate: NA%
Electricity— capacity: NA kW
Electricity— production: NAkWh
Electricity— consumption per capita: NA kWh
Agriculture— products: vanilla, ylang-ylang, coffee,
copra
Exports:
total value: $3.64 million (f.o.b., 1996)
commodities : ylang-ylang (perfume essence), vanilla,
copra
partners : France 80%, Comoros 15%, Reunion
Imports:
total value: $1 31 .5 million (f.o.b., 1 996)
commodities : building materials, machinery and
transportation equipment, metals, chemicals, rice,
clothing, flour
partners: France 66%, Africa 14%, Southeast Asia
20%
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
note: extensive French financial assistance
Currency: 1 French franc (F) = 100 centimes
Exchange rates: French francs (F) per US$1 —
6.0836 (January 1 998), 5.8367 (1 997), 5.1 1 55 (1 996),
4.9915 (1995), 5.5520 (1994), 5.6632 (1993)
Fiscal year: calendar year','35d7db06a002e8c2d1a3f336a8c72b13a039967fde66c0b0ad7930e27e80f3ed','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f38034952812b769a0eaf12e347249755a0f6dcfe6b34838d695d25657996a5',1998,'MS','Montserrat','economy',646,'Economy — overview: The economy of this volcanic
island is small and open, with economic activity
centered on tourism and related services. Tourism
accounts for roughly one-quarter of Montserrat''s
national income. The island''s main export is electronic
components, which are mainly shipped to the US. The
agriculture sector is small; cabbages, carrots,
cucumbers, and onions are grown for the domestic
market; additionally, some hot peppers and live plants
are exported to the US and Europe. Volcanic activity
in mid-1997 led to a substantial evacuation of the
southern half of the island, including the capital,
Plymouth. Volcanic activity since July 1995 has
resulted in the departure of an estimated 8,000
people, mainly to Antigua and Guadeloupe.
GDP: purchasing power parity— $43 million (1996
est.)
GDP— real growth rate: -20.2% (1996 est.)
GDP— per capita: purchasing power parity— $5,000
(1996 est.)
GDP— composition by sector:
agriculture: 4.8%
industry: 1 8.4%
services: 76.8% (1990 est.)
Inflation rate— consumer price index: 6.2% (1996
est.)
Labor force:
total: 4,521 (1992); note— later substantially lowered
by flight of people from volcanic activity
by occupation: community, social, and personal
services 40.5%, construction 13.5%, trade,
restaurants, and hotels 12.3%, manufacturing 10.5%,
agriculture, forestry, and fishing 8.8%, other 14.4%
(1983 est.)
Unemployment rate: 6% (1995)
Budget:
revenues: $NA
expenditures: $NA
Industries: tourism, rum, textiles, electronic
appliances
Industrial production growth rate: NA%
Electricity— capacity: 4,000 kW (1995)
Electricity— production: 15 million kWh (1995)
Electricity— consumption per capita: 1 ,1 78 kWh
(1995)
Agriculture— products: cabbages, carrots,
cucumbers, tomatoes, onions, peppers; livestock
products
Exports:
total value: $12.1 million (f.o.b., 1995 est.)
commodities: electronic components, plastic bags,
apparel, hot peppers, live plants, cattle
partners: US, Ireland
Imports:
total value: $ 29.9 million (f.o.b., 1994 est.)
commodities: machinery and transportation
equipment, foodstuffs, manufactured goods, fuels,
lubricants, and related materials
partners : NA
Debt— external: $10.2 million (December 1994)
Economic aid: $NA
Currency: 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars (EC$) per
US$1— 2.7000 (fixed rate since 1976)
Fiscal year: 1 April— 31 March','5c8df41ac97b50cf0d2231bfb83e9935ab557a9b816b5d52667f8ccb66df064f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f870ba1b2def17c62a4354daa236fdc4715e5bc38229b6eb53bfb56dd52ad64a',1998,'GI','Gibraltar','economy',653,'Economy— overview: Morocco faces the problems
typical of developing countries— restraining
government spending, reducing constraints on private
activity and foreign trade, and keeping inflation within
manageable bounds. Since the early 1980s the
government has pursued an economic program
toward these objectives with the support of the IMF,
the World Bank, and the Paris Club of creditors. The
dirham is now fully convertible for current account
transactions; reforms of the financial sector have been
implemented; and state enterprises are slowly being
privatized. Drought conditions in 1997 depressed
activity in the key agricultural sector, holding down
exports and contributing to a 2.2% contraction in real
GDP. Favorable rainfalls in the fall of 1 997 have led to
forecasts of robust, 8%-9% real GDP growth in 1998.
Servicing the external debt, preparing the economy
for freer trade with the European Union, improving
education and living standards, and finding jobs for
Morocco''s youthful population remain long-term
challenges.
GDP: purchasing power parity— $107 billion (1997
est.)
GDP— real growth rate: -2.2% (1997 est.)
GDP— per capita: purchasing power parity— $3,500
(1997 est.)
GDP— composition by sector:
agriculture: 14%
industry: 33%
services: 53% (1997)
Inflation rate— consumer price index: 3% (1997
est.)
Labor force:
tofa/: 7.4 million
by occupation: agriculture 50%, services 26%,
industry 15%, other 9% (1985)
Unemployment rate: 1 6% (1 997 est.)
Budget:
revenues; $10.4 billion
expenditures: $10.75 billion, including capital
expenditures of $1.9 billion (1996 est.)
Industries: phosphate rock mining and processing,
food processing, leather goods, textiles, construction,
tourism
Industrial production growth rate: 4.5% (1996
est.)
Electricity— capacity: 3.788 million kW (1995)
Electricity— production: 10.8 billion kWh (1995)
Electricity— consumption per capita: 411 kWh
(1995)
Agriculture— products: barley, wheat, citrus, wine,
vegetables, olives; livestock
Exports:
total value: $6.9 billion (f.o.b., 1996)
commodities: food and beverages 30%,
semiprocessed goods 23%, consumer goods 21%,
phosphates 17% (1995 est.)
partners: EU 63%, Japan 7.7%, India 6.6%, US 3.4%,
Libya 3.4% (1996 est.)
Imports:
total value: $9.7 billion (c.i.f., 1996)
commodities : semiprocessed goods 26%, capital
goods 25%, food and beverages 18%, fuel and
lubricants 15%, consumer goods 12%, raw materials
4% (1995 est.)
partners: EU 57%, US 6.6%, Saudi Arabia 5.3%,
Brazil 2.8% (1996 est.)
Debt— external: $23.4 billion (1996 est.)
Economic aid:
recipient: ODA, $297 million (1993)
note: $2.8 billion debt canceled by Saudi Arabia
(1991)
Currency: 1 Moroccan dirham (DH) = 100 centimes
Exchange rates: Moroccan dirhams (DH) per
US$1— 9.822 (January 1998), 9.527 (1997), 8.716
(1996), 8.540 (1995), 9.203 (1994), 9.299 (1993)
Fiscal year: July 1 -June 30','2932acd6f2823bc6e2476ddda5c224cde357942359e7e8fdf2e2105216e40794','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8378a8e71225cd4bad95e5ccecb55f268bc5ff6d037a7b49a8e542bb333bab1',1998,'NR','Nauru','economy',660,'Economy— overview: Revenues come from the
export of phosphates, the reserves of which are
expected to be exhausted by the year 2000.
Phosphates have given Nauruans one of the highest
per capita incomes in the Third World, but incomes
probably will drop sharply in the future. Few other
resources exist, so most necessities must be
imported, including fresh water from Australia. The
rehabilitation of mined land and the replacement of
income from phosphates are serious long-term
problems. Substantial amounts of phosphate income
are invested in trust funds to help cushion the
transition. However, dividends from the trusts have
declined sharply since 1990 and the government has
been borrowing heavily from the trusts to finance fiscal
deficits. In an effort to stem further escalation of fiscal
problems, the government has called for a freeze on
wages for two years, a reduction of over-staffed public
service departments, drastic cutbacks in hiring new
government staff, privatization of numerous
government agencies, and closure of some overseas
consulates.
GDP: purchasing power parity— $100 million (1993
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity —
$10,000 (1993 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: -3.6%
(1993)
Labor force:
by occupation: employed in mining phosphates,
public administration, education, and transportation
Unemployment rate: 0%
Budget:
revenues: $23.4 million
expenditures: $64.8 million, including capital
expenditures of $NA (FY95/96)
Industries: phosphate mining, financial services,
coconut products
Industrial production growth rate: NA%
Electricity— capacity: 10,000 kW (1995)
Electricity— production: 30 million kWh (1995)
Electricity— consumption per capita: 2,956 kWh
(1995)
Agriculture— products: coconuts predominate
Exports:
total value: $25.3 million (f.o.b., 1991)
commodities: phosphates
partners : Australia, NZ
Imports:
total value: $ 21.1 million (c.i.f., 1991)
commodities: food, fuel, manufactures, building
materials, machinery
partners: Australia, UK, NZ, Japan
Debt— external: $33.3 million
Economic aid:
recipient: ODA, $2.25 million from Australia (FY96/97
est.)
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 —
1 .5281 (January 1 998), 1 .3439 (1 997), 1 .2773 (1 996),
1.3486 (1995), 1.3667 (1994), 1.4704 (1993)
Fiscal year: 1 July— 30 June
Economy— overview: no economic activity
Economy-overview: Nepal is among the poorest
and least developed countries in the world with more
than half of its population living below the poverty line.
Agriculture is the mainstay of the economy, providing
a livelihood for over 80% of the population and
accounting for 40% of GDP. Industrial activity mainly
involves the processing of agricultural produce
including jute, sugarcane, tobacco, and grain.
Production of textiles and carpets has expanded
recently and accounted for about 80% of foreign
exchange earnings in the past two years. Apart from
agricultural land and forests, exploitable natural
resources are mica, hydropower, and tourism.
Agricultural production is growing by about 5% on
average as compared with annual population growth
of 2.5%. Since May 1991, the government has been
moving forward with economic reforms particularly
those that encourage trade and foreign investment,
e.g., by eliminating business licenses and registration
requirements in order to simplify investment
procedures. The government has also been cutting
expenditures by reducing subsidies, privatizing state
industries, and laying off civil servants. More recently,
however, political instability— five different
governments over the past few years— has hampered
Kathmandu''s ability to forge consensus to implement
key economic reforms. Nepal has considerable scope
for accelerating economic growth by exploiting its
potential in hydropower and tourism, areas where
there has recently been foreign investment interest.
Prospects for foreign trade or investment in other
areas will remain poor, however, because of the small
size of the economy, its technological backwardness,
its remoteness, its landlocked geographic location,
and its susceptibility to natural disaster. The
international community''s role of funding more than
60% of Nepal''s development budget and more than
28% of total budgetary expenditures will likely
continue as a major ingredient of growth.
GDP: purchasing power parity— $31.1 billion (1997
est.)
GDP— real growth rate: 4.2% (1997 est.)
GDP— per capita: purchasing power parity— $1 ,370
(1997 est.)
GDP— composition by sector:
agriculture: 40%
industry: 21%
services: 39% (1 997 est.)
inflation rate— consumer price index: 7.5% (1997
est.)
Labor force:
total: 10 million (1996 est.)
by occupation: agriculture 81%, services 16%,
industry 3%
note; severe lack of skilled labor
Unemployment rate: NA%; substantial
underemployment (1996)
Budget:
revenues: $536 million
expenditures: $81 8 million, including capital
expenditures of $NA (FY96/97 est.)
Industries: tourism, carpet, textile; small rice, jute,
sugar, and oilseed mills; cigarette; cement and brick
production
Industrial production growth rate: 14.7% (FY94/
95 est.)
Electricity— capacity: 292,000 kW (1995)
Electricity— production: 980 million kWh (1996)
Electricity— consumption per capita: 48 kWh
(1996 est.)
Agriculture— products: rice, corn, wheat,
sugarcane, root crops; milk, water buffalo meat
Exports:
total value: $41 9 million (f.o.b., 1997 est.) but does
not include unrecorded border trade with India
commodities: carpets, clothing, leather goods, jute
goods, grain
partners: India, US, Germany, UK
Imports:
total value: $1.6 billion (c.i.f., 1997 est.)
commodities : petroleum products 20%, fertilizer 11%,
machinery 10%
partners: India, Singapore, Japan, Germany
Debt— external: $2.6 billion (1997 est.)
Economic aid:
recipient: ODA, $411 million (FY97/98)
Currency: 1 Nepalese rupee (NR) = 100 paisa
Exchange rates: Nepalese rupees (NRs) per
US$1 -63.265 (January 1998), 58.010 (1997),
56.692 (1996), 51.890 (1995), 49.398 (1994), 48.607
(1993)
Fiscal year: 16 July— 15 July','a4378645679cdc7252c329d8473c20c0c27b44b8c7c439677a5519900a6bfed7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfd188190c2459eb2344d26dce530abe63cfcfc74990742886ffcad6952f9fa5',1998,'NZ','New Zealand','economy',672,'Economy— overview: Since 1984 the government
has accomplished major economic restructuring,
moving an agrarian economy dependent on a
concessionary British market access toward a more
industrialized, free market economy that can compete
globally. This dynamic growth has boosted real
incomes, broadened and deepened the technological
capabilities of the industrial sector, and contained
inflationary pressures. Business confidence
strengthened in 1994, and export demand picked up
in the Asia-Pacific region, resulting in 6.2% growth.
Growth continued strong in 1995, but tailed off in
1996-97. Inflation remains among the lowest in the
industrial world. Per capita GDP has been moving up
to the levels of the big West European economies.
However, the Asian economic crisis may slow GDP
growth in 1998.
GDP: purchasing power parity— $63.4 billion (1997
est.)
GDP— real growth rate: 2.5% (1997 est.)
GDP— per capita: purchasing power parity —
$17,700 (1997 est.)
GDP— composition by sector:
agriculture: 7. 3%
industry: 25.9%
services: 66.8% (1990)
Inflation rate— consumer price index: 2% (1997
est.)
341
New Zealand (continued)
Labor force:
total: 1,634,500 (September 1 995)
by occupation: services 64.6%, industry 25.0%,
agriculture 10.4% (1994)
Unemployment rate: 5.9% (December 1996)
Budget:
revenues: $24.1 billion
expenditures: $21 .8 billion, including capital
expenditures of $NA (FY95/96 est.)
Industries: food processing, wood and paper
products, textiles, machinery, transportation
equipment, banking and insurance, tourism, mining
Industrial production growth rate: NA%
Electricity— capacity: 7.747 million kW (1995)
Electricity— production: 33.696 billion kWh (1995)
Electricity— consumption per capita: 9,889 kWh
(1995)
Agriculture— products: wheat, barley, potatoes,
pulses, fruits, vegetables; wool, meat, dairy products;
fish catch reached a record 503,000 metric tons in
1988
Exports:
total value: $ 18.5 billion (1997 est.)
commodities: mo\\, lamb, mutton, beef, fish, cheese,
chemicals, forestry products, fruits and vegetables,
manufactures, dairy products, wood
partners: Australia 19%, Japan 15%, UK 15%, US
12%
Imports:
total value: $19.2 billion (1997 est.)
commodities: machinery and equipment, vehicles and
aircraft, petroleum, consumer goods, plastics
partners: Australia 21 %, US 1 8%, Japan 1 6%, UK 6%
Debt— external: $28.5 billion (FY95/96 est.)
Economic aid:
donor: ODA, $98 million (1993)
Currency: 1 New Zealand dollar (NZ$) = 1 00 cents
Exchange rates: New Zealand dollars (NZ$) per
US$1— 1.7283 (January 1998), 1.5083 (1997),
1.4543 (1996), 1.5235 (1995), 1.6844 (1994), 1.8495
(1993)
Fiscal year: 1 July— 30 June
Economy— overview: The economy''s base is
agriculture, which contributes 32% to GDP. Squash,
coconuts, bananas, and vanilla beans are the main
crops, and agricultural exports make up two-thirds of
total exports. The country must import a high
proportion of its food, mainly from New Zealand. The
industrial sector accounts for only 10% of GDP.
Tourism is the primary source of hard currency
earnings; the country also remains dependent on
sizable external aid and remittances to offset its trade
deficit. The economy grew at a declining rate in
1993-96. The government has been turning its
attention to further development of the private sector
and the reduction of the budget deficit.
GDP: purchasing power parity— $239 million (1996
est.)
466
GDP— real growth rate: 1% (1996 est.)
GDP— per capita: purchasing power parity— $2,250
(1996 est.)
GDP— composition by sector:
agriculture: 32%
industry: 10%
services: 58% (1996)
Inflation rate— consumer price index: 2% (1997
est.)
Labor force:
total: 36,665 (1994)
by occupation: agriculture 65% (1997 est.)
Unemployment rate: 1 1 .8% (FY93/94)
Budget:
revenues: $49 million
expenditures: $120 million, including capital
expenditures of $75 million (FY96/97 est.)
Industries: tourism, fishing
Industrial production growth rate: 1 .9% (FY95/
96)
Electricity— capacity: 7,000 kW (1995)
Electricity— production: 30 million kWh (1995)
Electricity— consumption per capita: 284 kWh
(1995)
Agriculture— products: coconuts, copra, bananas,
vanilla beans, cocoa, coffee, ginger, black pepper;
fish
Exports:
total value: $ 15.3 million (f.o.b., 1996)
commodities: squash, fish, vanilla, root crops,
coconut oil
partners: Japan 43%, US 19%, Canada 14%, NZ 5%,
Australia 5% (1996 est.)
Imports:
total value: $ 82.9 million (f.o.b., 1996)
commodities: food products, live animals, machinery
and transport equipment, manufactures, fuels,
chemicals
partners: NZ 34%, Australia 16%, US 10%, UK 8%,
Japan 6% (1996 est.)
Debt— external: $70 million (1995)
Economic aid:
recipient: ODA, $37 million (1994)
Currency: 1 pa''anga (T$) = 100 seniti
Exchange rates: pa''anga (T$) per US$1 —1 .31 1 2
(November 1997), 1.2323 (1996), 1.2709 (1995),
1.3202 (1994), 1.3841 (1993)
Fiscal year: 1 July— 30 June
Economy— overview: Trinidad and Tobago has
earned a reputation as an excellent investment site for
international businesses. Successful economic
reforms were implemented in 1995, and foreign
investment and trade are flourishing.
Unemployment— a main cause of the country''s
socio-economic problems— is high, but has
decreased to its lowest point in five years. The country
enjoys a healthy trade surplus, yet its heavy
dependence on oil and petrochemical prices makes
its trade balance vulnerable to sudden shifts. Tourism
is a major foreign exchange earner, with 260,000
arrivals in 1995, 80% from Europe.
GDP: purchasing power parity— $13.2 billion (1996
est.)
GDP— real growth rate: 3.1% (1996 est.)
GDP— per capita: purchasing power parity —
$10,400 (1996 est.)
GDP— composition by sector:
agriculture: 2%
industry: 45%
services: 53% (1995 est.)
Inflation rate— consumer price index: 3.4%
(1996)
Labor force:
total: 404,500
by occupation: construction and utilities 13%,
manufacturing, mining, and quarrying 14%,
agriculture 11%, services 62% (1993 est.)
Unemployment rate: 16.1% (December 1996)
Budget:
revenues; $1.7 billion
expend/fores: $1.6 billion, including capital
expenditures of $243 million (1997 est.)
Industries: petroleum, chemicals, tourism, food
processing, cement, beverage, cotton textiles
Industrial production growth rate: 7.5% (1995)
Electricity— capacity: 1.15 million kW (1995)
Electricity— production: 3.9 billion kWh (1995)
Electricity— consumption per capita: 3,068 kWh
(1995)
468
Agriculture— products: cocoa, sugarcane, rice,
citrus, coffee, vegetables; poultry
Exports:
total value: $2.5 billion (f.o.b., 1996)
commodities: petroleum and petroleum products,
chemicals, steel products, fertilizer, sugar, cocoa,
coffee, citrus, flowers
partners: US 48%, Caricom countries 15%, Latin
America 9%, EU 5% (1994)
Imports:
total value: $2 A billion (c.i.f., 1996)
commodities : machinery, transportation equipment,
manufactured goods, food, live animals
partners : US 48%, Venezuela 10%, UK 8%,
Germany, Canada (1995)
Debt— external: $1.9 billion (1996 est.)
Economic aid:
recipient: ODA, $10 million (1993)
Currency: 1 Trinidad and Tobago dollar (TT$) = 100
cents
Exchange rates: Trinidad and Tobago dollars (TT$)
per US$1— 6.2840 (January 1998), 6.2503 (1997),
6.0051 (1996), 5.9478 (1995), 5.9249 (1994), 5.3511
(1993)
Fiscal year: calendar year
Economy— overview: no economic activity
Economy— overview: The economy is limited to
traditional subsistence agriculture, with about 80% of
the labor force earning its livelihood from agriculture
(coconuts and vegetables), livestock (mostly pigs),
and fishing. About 4% of the population is employed in
government. Revenues come from French
Government subsidies, licensing of fishing rights to
Japan and South Korea, import taxes, and
remittances from expatriate workers in New
Caledonia. Wallis and Futuna imports food —
particularly flour, sugar, rice, and beef— fuel, clothing,
machinery, and transport equipment, but its exports
are negligible, consisting mostly of breadfruit, yams,
and taro root.
GDP: purchasing power parity — $28.7 million (1995
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $2,000
(1995 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services : NA%
Inflation rate— consumer price index: NA%
Labor force: NA
by occupation: agriculture, livestock, and fishing 80%,
government 4% (est.)
Unemployment rate: NA%
Budget:
revenues: $22 million
expenditures: $22 million, including capital
expenditures of $NA (1997 est.)
Industries: copra, handicrafts, fishing, lumber
Industrial production growth rate: NA%
Electricity— capacity: NA kW
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Agriculture— products: breadfruit, yams, taro,
bananas; pigs, goats
Exports:
total value: $370,000 (f.o.b., 1995 est.)
commodities: copra, handicrafts
partners: NA
Imports:
total value: $13.5 million (c.i.f., 1995 est.)
commodities: foodstuffs, manufactured goods,
transportation equipment, fuel, clothing
partners: France, Australia, New Zealand
Debt— external: $NA
Economic aid:
recipient: ODA, $N A
Currency: 1 CFP franc (CFPF) = 100 centimes
Exchange rates: Comptoirs Francais du Pacifique
francs (CFPF) per US$1— 1 10.60 (January 1998),
106.11 (1997), 93.00 (1996), 90.75 (1995), 100.94
(1994), 102.96 (1993); note— linked at the rate of
18.18 to the French franc
Fiscal year: calendar year','44e494f1bf440e08f25510eadd3111e10f308bb1c4d0054289454a5b5ad1dc6a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28df698e933846bf2d05697dd99a6f54e84f24d04258da8d43df3b0d4a5ed753',1998,'NI','Nicaragua','economy',680,'Economy— overview: The Nicaraguan economy,
devastated during the 1980s by economic
mismanagement and civil war, is beginning to
rebound. In 1991 President CHAMORRO launched
an ambitious economic stabilization program that
reduced inflation and obtained substantial economic
aid from abroad. Economic growth rose sharply in
1995-97, due to surges in exports and efforts to
enhance trade liberalization. The program, however,
hit some snags, and a 1994-97 IMF Enhanced
Structural Adjustment Facility (ESAF) signed by the
CHAMORRO administration with the Fund lapsed in
September 1996 due to non-compliance. In 1997,
however, the IMF resumed negotiations for an ESAF
with the ALEMAN administration, and agreed to an
ESAF in 1998. IMF approval of the ESAF cleared the
way for debt relief by the Paris Club later that year and
has opened the way for debt relief under the Highly
Indebted Poor Countries Initiative. Implementation of
a 1997 property accord— designed to resolve conflict
over properties confiscated by the Sandinistas in the
1980s— should also help inspire international investor
confidence. Strong growth is forecast for 1998, with
implementation of a 1997 free trade agreement with
Mexico expected to boost agricultural exports,
although the industrial sector may come under
pressure from increased Mexican competition.
GDP: purchasing power parity— $9.3 billion (1997
est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity— $2,1 00
(1997 est.)
GDP— composition by sector:
agriculture: 34%
industry: 21%
services: 45% (1995)
Inflation rate— consumer price index: 1 1 .6%
(1996)
Labor force:
total: 1.5 million
by occupation: services 54%, agriculture 31 %,
industry 15% (1995 est.)
Unemployment rate: 16%; underemployment 36%
(1996 est.)
Budget:
revenues: $389 million
expenditures: $551 million, including capita!
expenditures of $NA (1996 est.)
Industries: food processing, chemicals, metal
products, textiles, clothing, petroleum refining and
distribution, beverages, footwear
Industrial production growth rate: 1.4% (1994
est.)
Electricity— capacity: 457,000 kW (1995)
Electricity— production: 1 .76 billion kWh (1995)
Electricity— consumption per capita: 416 kWh
(1995)
Agriculture— products: coffee, bananas,
sugarcane, cotton, rice, corn, cassava (tapioca),
citrus, beans; beef, veal, pork, poultry, dairy products
Exports:
total value: $635 million (f.o.b., 1996)
commodities: coffee, seafood, meat, sugar, gold,
bananas
partners: US, Central America, Germany, Canada
Imports:
total value: $ 1.1 billion (c.i.f., 1996)
commodities: consumer goods, machinery and
equipment, petroleum products
partners: Central America, US, Venezuela, Japan
Debt— external: $6 billion (1996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 gold cordoba (C$) = 100 centavos
Exchange rates: gold cordobas (C$) per US$1 —
9.76 (October 1997), 8.44 (1996), 7.55 (1995), 6.72
(1994), 5.62 (1993)
Fiscal year: calendar year','2ae2f670cb0cd59523fbeabc4c2d73df735c772edfe3b014631d56040349e0ef','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3ccb8b005a07568507b5f3a57f5205263d65cdfd3c898144ef7744c9fcc720d',1998,'NU','Niue','economy',695,'Economy— overview: The economy is heavily
dependent on aid from New Zealand and remittances
as Niue has no indigenous export product.
Government expenditures regularly exceed revenues,
with the shortfall made up by grants from New
Zealand; the grants are used to pay wages to public
employees. Niue cut government expenditures in
1994-96 by reducing the public service by almost half.
The agricultural sector consists mainly of subsistence
gardening, although some cash crops are grown for
export. Industry consists primarily of small factories to
process passion fruit, lime oil, honey, and coconut
cream. The sale of postage stamps to foreign
collectors is an important source of revenue. The
island in recent years has suffered a serious loss of
population because of migration of Niueans to New
Zealand. A small tourist industry is developing.
GDP: purchasing power parity— $2.4 million (1993
est.)
GDP-real growth rate: NA%
GDP— per capita: purchasing power parity— $1 ,200
(1993 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
sen/ices: NA%
Inflation rate— consumer price index: 5% (1992)
Labor force:
total: 450 (1992 est.)
by occupation : most work on family plantations; paid
work exists only in government service, small industry,
and the Niue Development Board
Unemployment rate: NA%
Budget:
revenues: $5.5 million
expenditures: $ 6.3 million, including capital
expenditures of $NA (1985 est.)
Industries: tourism, handicrafts, food processing
Industrial production growth rate: NA%
Electricity— capacity: 1 ,000 kW (1 995)
Electricity— production: 3 million kWh (1995)
Electricity— consumption per capita: 1 ,633 kWh
(1995)
Agriculture— products: coconuts, passion fruit,
honey, limes, taro, yams, cassava (tapioca), sweet
potatoes; pigs, poultry, beef cattle
Exports:
total value: $11 7,500 (f.o.b., 1989)
commodities: canned coconut cream, copra, honey,
passion fruit products, pawpaw, root crops, limes,
footballs, stamps, handicrafts
partners: NZ 89%, Fiji, Cook Islands, Australia
Imports:
total value: $4.1 million (c.i.f., 1989)
commodities: food, live animals, manufactured goods,
machinery, fuels, lubricants, chemicals, drugs
partners: NZ 59%, Fiji 20%, Japan 13%, Samoa,
Australia, US
Debt— external: $NA
Economic aid:
recipient: ODA, $5.9 million from NZ (FY95/96)
Currency: 1 New Zealand dollar (NZ$) = 100 cents
Exchange rates: New Zealand dollars (NZ$) per
US$1— 1 .7283 (January 1998), 1 .5082 (1 997), 1 .4543
(1996), 1.5235 (1995), 1.6844 (1994), 1.8495 (1993)
Fiscal year: 1 April— 31 March','1624809a0721ef9d1a677f0ca526c2c9a33dcc59ab71b2887702686786f82812','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d894c9896e862922ac72772346920f3f82dd703f682f9a21f6a3381544af7662',1998,'NF','Norfolk Island','economy',702,'Economy— overview: The primary economic
activity is tourism, which has brought a level of
prosperity unusual among inhabitants of the Pacific
islands. The number of visitors has increased steadily
over the years and reached 28,000 in FY92/93.
Revenues from tourism have helped the agricultural
sector to become self-sufficient in the production of
beef, poultry, and eggs.
GDP: purchasing power parity— $NA
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $NA
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force:
total: 1,395 (1991 est.)
by occupation: tourism NA%, subsistence agriculture
NA%
Unemployment rate: NA%
Budget:
revenues: $4.6 million
expenditures: $4.8 million, including capital
expenditures of $NA (FY92/93)
Industries: tourism
Industrial production growth rate: NA%
Electricity— capacity: NA kW
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Agriculture— products: Norfolk Island pine seed,
Kentia palm seed, cereals, vegetables, fruit; cattle,
poultry
351
Norfolk Island (continued)
Exports:
total value: $1 .5 million (f.o.b., FY91/92)
commodities: postage stamps, seeds of the Norfolk
Island pine and Kentia palm, small quantities of
avocados
partners: Australia, other Pacific island countries, NZ,
Asia, Europe
Imports:
total value: $ 17.9 million (c.i.f., FY91/92)
commodities: NA
partners: Australia, other Pacific island countries, NZ,
Asia, Europe
Debt— external: $NA
Economic aid: none
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 —
1 .5281 (January 1998), 1 .3439 (1 997), 1 .2773 (1 996),
1 .3486 (1 995), 1 .3667 (1 994), 1 .4704 (1 993)
Fiscal year: 1 July— 30 June','ee6a5ba2d9725792097cec10ae86162dd4d0ba5b4c4a6f414cdfc741d6c8a684','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fdf8aeefc1cd032e5912cc1bab4437a74ff154a0cdb8317112f2bc86df83dc0',1998,'MP','Northern Mariana Islands','economy',706,'Economy— overview: The economy benefits
substantially from financial assistance from the US.
The rate of funding has declined as locally generated
government revenues have grown. An agreement for
the years 1986 to 1992 entitled the islands to $228
million for capital development, government
operations, and special programs. Since 1992,
funding has been extended one year at a time. The
commonwealth received $27.7 million from FY93/94
through FY95/96. For FY96/97 through FY02/03,
funding of $1 1 million will be provided for
infrastructure, with an equal local match. A rapidly
growing chief source of income is the tourist industry,
which now employs about 50% of the work force.
Japanese tourists predominate. The agricultural
sector is of minor importance and is made up of cattle
ranches and small farms producing coconuts,
breadfruit, tomatoes, and melons. Garment
production is the fastest growing industry with
employment of 12,000 mostly Chinese workers and
shipments of $800 million to the US in 1997 under
duty and quota exemptions.
GDP: purchasing power parity— $524 million (1994
est.)
note: GDP numbers reflect US spending
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity —
$10,500 (1994 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
sen/ices: NA%
Inflation rate— consumer price index: 6.5% (1994
est.)
Labor force:
total: 7,476 total indigenous labor force; 2,699
unemployed; 22,560 foreign workers (1995)
by occupation: NA
Unemployment rate: 14% (residents)
Budget:
revenues: $190.4 million
expenditures: $190.4 million, including capital
expenditures of $19.1 million (FY94/95)
Industries: tourism, construction, garments,
handicrafts
Industrial production growth rate: NA%
Electricity— capacity: NA kW
Electricity— production: NAkWh
Electricity— consumption per capita: NA kWh
Agriculture— products: coconuts, fruits,
vegetables; cattle
Exports: NA
commodities: garments
partners: NA
Imports: NA
commodities: food, construction equipment and
materials, petroleum products
partners: US, Japan
Debt— external: $NA
Economic aid: none
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October— 30 September
Economy— overview: Economic activity is limited to
providing services to contractors located on the
island. All food and manufactured goods must be
imported.
Electricity— capacity: NA kW
rrofe; electricity supplied by the US military
Electricity— production: NA kWh
note: electricity supplied by the US military','797d8fc1e55bba8cb9e96354ecaed95993da260b254bd523ca7ff012f560b3f7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58f015f6db11f01f5ee8d2a1676218ed8569e970cf67b6e1c4cf67afa8dc6fb6',1998,'OM','Oman','economy',715,'Economy— overview: Economic performance is
closely tied to the fortunes of the oil industry.
Petroleum accounts for 75% of export earnings and
government revenues and for roughly 40% of GDP.
Oman has proved oil reserves of 4 billion barrels,
equivalent to about 20 years'' production at the current
rate of extraction. Agriculture is carried on at a
subsistence level and the general population depends
on imported food. The year 1996 was marked by
higher oil production and prices. The government is
encouraging private investment, both domestic and
foreign, as a prime force for further economic
development.
GDP: purchasing power parity— $17.2 billion (1997
est.)
GDP— real growth rate: 3.5% (1997 est.)
GDP— per capita: purchasing power parity— $8,000
(1997 est.)
GDP— composition by sector:
agriculture: 3%
industry : 43%
services: 54% (1995)
Inflation rate— consumer price index: 1% (1996
est.)
Labor force:
total: 780,500 (1997 est.)
by occupation: agriculture 37% (1993 est.)
Unemployment rate: NA%
Budget:
revenues: $5.2 billion
expenditures: $6 billion, including capital
expenditures of $1.3 billion (1998 est.)
Industries: crude oil production and refining, natural
gas production, construction, cement, copper
Industrial production growth rate: 3% (1994 est.)
Electricity— capacity: 1 .744 million kW (1 995)
Electricity— production: 7.8 billion kWh (1995)
Electricity— consumption per capita: 3,670 kWh
(1995)
Agriculture— products: dates, limes, bananas,
alfalfa, vegetables; camels, cattle; annual fish catch
averages 100,000 metric tons
Exports:
total value: $7. 6 billion (f.o.b., 1997 est.)
commodities: petroleum 75%, reexports, fish,
processed copper, textiles
partners: Japan 29%, South Korea 17%, China 12%,
Thailand 11%, US 7% (1996)
Imports:
total value: % 4.8 billion (f.o.b., 1997 est.)
commodities: machinery, transportation equipment,
manufactured goods, food, livestock, lubricants
partners: UAE 22% (largely reexports), Japan 15%,
UK 15%, France 6%, US 5% (1996)
Debt— external: $3 billion (1997 est.)
Economic aid:
recipient: ODA, $82 million (1993)
Currency: 1 Omani rial (RO) = 1,000 baiza
Exchange rates: Omani rials (RO) per US$1 —
0.3845 (fixed rate since 1986)
Fiscal year: calendar year
Economy— overview: The Pacific Ocean is a major
contributor to the world economy and particularly to
those nations its waters directly touch. It provides
low-cost sea transportation between East and West,
extensive fishing grounds, offshore oil and gas fields,
minerals, and sand and gravel for the construction
industry. In 1985 over half (54%) of the world''s fish
catch came from the Pacific Ocean, which is the only
ocean where the fish catch has increased every year
since 1978. Exploitation of offshore oil and gas
reserves is playing an ever-increasing role in the
energy supplies of Australia, NZ, China, US, and
Peru. The high cost of recovering offshore oil and gas,
combined with the wide swings in world prices for oil
since 1 985, has slowed but not stopped new drillings.','e5055d75bfeaa2bfdacd1eb98696d52962ebce06ee9485ec16df480ac9b68767','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2228d2e1844e069395fabda79ead01ab2d506eae13afcde22fd34b942ae565f',1998,'PK','Pakistan','economy',723,'Economy— overview: Pakistan continues to suffer
through a damaging foreign exchange crisis. The
crisis stems from years of loose fiscal policies that
exacerbated inflation and allowed the public debt,
money supply, and current account deficit to explode.
In April 1997, Prime Minister SHARIF introduced a
stimulus package of tax cuts intended to boost failing
industrial output and spur export growth. At that time,
the IMF endorsed the program, paving the way for a
$1.5 billion Enhanced Structural Adjustment Facility.
Although the economy showed signs of improvement
following the measures, SHARIF has refused to
implement the tough structural reforms necessary for
sustained, longer-term growth. As a consequence, at
yearend 1997, industrial production continued to flag,
foreign exchange reserves continued to teeter around
$1 billion— only four weeks of imports— and borrowing
to support the budget deficit already exceeded the
amount allocated for the entire fiscal year. At the same
time, the government must cope with long-standing
economic vulnerabilities— inadequate infrastructure,
low levels of literacy, and increasing sectarian, ethnic,
and tribal violence.
GDP: purchasing power parity— $344 billion (1997
est.)
GDP— real growth rate: 3.1% (1997 est.)
GDP— per capita: purchasing power parity— $2,600
(1997 est.)
GDP— composition by sector:
agriculture: 24.2%
industry: 26.4%
services: 49.4% (1 997)
Inflation rate— consumer price index: 1 1 .8%
(FY96/97)
Labor force:
total: 37.8 million (1998)
by occupation: agriculture 47%, mining and
manufacturing 17%, services 17%, other 19%
note: extensive export of labor, mostly to the Middle
East, and use of child labor
360
Unemployment rate: NA%
Budget:
revenues: $9.6 billion
expenditures: $13.6 billion, including capital
expenditures of $NA (FY96/97)
Industries: textiles, food processing, beverages,
construction materials, clothing, paper products,
shrimp
Industrial production growth rate: 3.3% (FY96/97
est.)
Electricity— capacity: 13.169 million kW (1995)
Electricity— production: 58.1 billion kWh (1997)
Electricity— consumption per capita: 436 kWh
(1997)
Agriculture— products: cotton, wheat, rice,
sugarcane, fruits, vegetables; milk, beef, mutton, eggs
Exports:
total value: $ 8.2 billion (FY96/97)
commodities: cotton, textiles, clothing, rice, leather,
carpets
partners : EU, US, Hong Kong, Japan
Imports:
total value: $1 1 .4 billion (FY96/97)
commodities: petroleum, petroleum products,
machinery, transportation equipment, vegetable oils,
animal fats, chemicals
partners: EU, Japan, US, China
Debt— external: $33 billion (1997 est.)
Economic aid:
recipient: $2.2 billion from all bilateral and multilateral
sources (FY96/97)
Currency: 1 Pakistani rupee (PRe) = 100 paisa
Exchange rates: Pakistani rupees (PRs) per
US$1 -44.050 (January 1998), 41.112 (1997),
36.079 (1996), 31.643 (1995), 30.567 (1994), 28.1
(1993); note— annual average of official rate; parallel
market rate is higher
Fiscal year: 1 July— 30 June
Economy— overview: The economy consists
primarily of subsistence agriculture and fishing. The
government is the major employer of the work force,
relying heavily on financial assistance from the US.
The population enjoys a per capita income of more
than twice that of the Philippines and much of
Micronesia. Long-run prospects for the tourist sector
have been greatly bolstered by the expansion of air
travel in the Pacific and the rising prosperity of leading
East Asian countries.
GDP: purchasing power parity— $1 60 million (1 997
est.)
note: GDP numbers reflect US spending
GDP— real growth rate: 10% (1997 est.)
GDP— per capita: purchasing power parity— $8,800
(1997 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force: NA
by occupation: NA
Unemployment rate: 7%
Budget:
revenues: $52.9 million
expenditures: $59.9 million, including capital
expenditures of $NA (1997 est.)
Industries: tourism, craft items (from shell, wood,
pearls), some commercial fishing and agriculture
Industrial production growth rate: NA%
Electricity— capacity: 62,000 kW (1995)
Electricity— production: 195 million kWh (1995)
Electricity— consumption per capita: 1 1 ,704 kWh
(1995)
Agriculture— products: coconuts, copra, cassava
(tapioca), sweet potatoes
Exports:
total value: $ 14.3 million (f.o.b., 1996)
commodities: troch us (type of shellfish), tuna, copra,
362
handicrafts
partners: US, Japan
Imports:
total value: $72 .4 million (f.o.b., 1996)
commodities: NA
partners: US
Debt— external: about $100 million (1989)
Economic aid:
recipient: ODA, $NA
note: the Compact of Free Association with the US,
entered into after the end of the UN trusteeship on 1
October 1994, will provide Palau with up to $700
million in US aid over 1 5 years in return for furnishing
military facilities
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October— 30 September','2b6c39baf80441797cb29d1e23ed80da010086a4c87cfd2135da6875d474e32a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61b7862832244ec83f92fdd174ea4389d69f99c1fe930bee314223fab00192d3',1998,'PG','Papua New Guinea','economy',732,'Economy— overview: Papua New Guinea is richly
endowed with natural resources, but exploitation has
been hampered by the rugged terrain and the high
cost of developing an infrastructure. Agriculture
provides a subsistence livelihood for the bulk of the
population. Mineral deposits, including oil, copper,
and gold, account for 72% of export earnings.
Budgetary support from Australia and development
aid under World Bank auspices have helped sustain
the economy. In 1995, Port Moresby reached
agreement with the IMF and World Bank on a
structural adjustment program, of which the first
phase was successfully completed in 1996. Droughts
caused by the El Nino weather pattern wreaked havoc
on Papua New Guinea''s coffee, cocoa, and coconut
production, the mainstays of the agricultural-based
economy and major sources of export earnings. The
coffee crop was slashed by up to 50% in 1997.
Moreover, droughts could bite into growth in 1998.
GDP: purchasing power parity— $1 1 .6 billion (1 996
est.)
GDP— real growth rate: 2.3% (1996 est.)
GDP— per capita: purchasing power parity— $2,650
(1996 est.)
GDP— composition by sector:
agriculture: 26 .4%
industry: 41%
services: 32.6% (1996 est.)
Inflation rate— consumer price index: 1 1 .6%
(1996)
Labor force:
total: 1.941 million
by occupation: agriculture 64% (1993 est.)
Unemployment rate: NA%
Budget:
revenues: $ 1.5 billion
expenditures : $1 .35 billion, including capital
expenditures of $NA (1997 est.)
Industries: copra crushing, palm oil processing,
plywood production, wood chip production; mining of
gold, silver, and copper; crude oil production;
construction, tourism
Industrial production growth rate: NA%
Electricity— capacity: 490,000 kW (1995)
Electricity— production: 1 .76 billion kWh (1995)
Electricity— consumption per capita: 410 kWh
(1995)
Agriculture— products: coffee, cocoa, coconuts,
palm kernels, tea, rubber, sweet potatoes, fruit,
vegetables; poultry, pork
Exports:
total value: $2.5 billion (f.o.b., 1996)
commodities : gold, copper ore, oil, logs, coffee, palm
oil, cocoa, lobster
partners: Australia, Japan, Germany, UK, South
Korea
Imports:
total value: $1.7 billion (c.i.f., 1996)
commodities: machinery and transport equipment,
manufactured goods, food, fuels, chemicals
partners: Australia, US, Singapore, Japan, UK
Debt— external: $3.2 billion (1995)
Economic aid:
recipient: ODA, $291 million (1993); $240 million
bilateral aid from Australia (FY96/97 est.); $4.1 million
ODA from NZ (FY95/96)
Currency: 1 kina (K) = 100 toea
Exchange rates: kina (K) per US$1— 0.6299
(November 1997), 0.7588 (1996), 0.7835 (1995),
0.9950 (1994), 1.0221 (1993); note— the government
floated the kina on 10 October 1994
Fiscal year: calendar year
367
Papua New Guinea (continued)','77f5f0330533a23e6c9a926fcae2ca7ce5e2ecc5043a014074e6dfd437c4e1b2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f27123c614319bc987d70697572f16f13306d906b8e2803ac5d6bce0f854f8db',1998,'PH','Philippines','economy',739,'Economy— overview: no economic activity
Economy— overview: In 1997 the Philippine
economy, primarily a mixture of agriculture and light
industry, continued its fifth year of positive economic
growth, led by expansion of exports and investment.
The government expects growth to slow to about 3%
in 1 998 due to spillover effects of the financial crisis in
East Asia. The government has promised to continue
its economic reforms to help the Philippines match the
pace of development in the newly industrialized
countries of East Asia. The strategy includes
improving infrastructure, overhauling the tax system
to bolster government revenues, and moving toward
further deregulation and privatization of the economy.
GDP: purchasing power parity— $244 billion (1997
est.)
GDP— real growth rate: 5.1% (1997 est.)
GDP— per capita: purchasing power parity— $3,200
(1997 est.)
GDP— composition by sector:
agriculture: 22%
industry: 32%
services : 46% (1996 est.)
Inflation rate— consumer price index: 5.1%
(1997)
Labor force:
total: 29.1 3 million (1996 est.)
by occupation: agriculture 43.4%, services 22.6%,
government services 17.9%, industry and commerce
16.1% (1995)
Unemployment rate: 8.7% (1997)
Budget:
revenues: $16.3 billion
expenditures: $16.6 billion, including capital
expenditures of $2.7 billion (1 996 est.)
374
Industries: textiles, pharmaceuticals, chemicals,
wood products, food processing, electronics
assembly, petroleum refining, fishing
Industrial production growth rate: 6.3% (1996)
Electricity— capacity: 7.64 million kW (1995)
Electricity— production: 25.65 billion kWh (1995)
Electricity— consumption per capita: 350 kWh
(1995)
Agriculture— products: rice, coconuts, corn,
sugarcane, bananas, pineapples, mangoes; pork,
eggs, beef; fish catch of 2 million metric tons annually
Exports:
total value: $ 25 billion (f.o.b., 1997 est.)
commodities: electronics and telecommunications
51%, machinery and transport 10%, garments 9%,
other 30%
partners: US 34%, Japan 17%, EU 17%, ASEAN
14%, Hong Kong 4%, Taiwan 4% (1997 est.)
Imports:
total value: $34 billion (f.o.b., 1997 est.)
commodities : raw materials and intermediate goods
43%, capital goods 36%, consumer goods 9%, fuels 9%
partners: Japan 21%, US 20%, ASEAN 12%, EU
10%, Taiwan 5%, Hong Kong 4%, Saudi Arabia 4%
(1997 est.)
Debt— external: $45.4 billion (December 1997)
Economic aid:
recipient: ODA, $3 billion pledged at December 1997
for 1998
Currency: 1 Philippine peso (P) = 100 centavos
Exchange rates: Philippine pesos (P) per US$1 —
40.2 (April 1998), 26.36 (May 1997), 29.471 (1997),
26.216 (1996), 25.714 (1995), 26.417 (1994), 27.120
(1993)
Fiscal year: calendar year
Economy— overview: The inhabitants exist on
fishing and subsistence farming. The fertile soil of the
valleys produces a wide variety of fruits and
vegetables, including citrus, sugarcane, watermelons,
bananas, yams, and beans. Bartering is an important
part of the economy. The major sources of revenue
are the sale of postage stamps to collectors and the
sale of handicrafts to passing ships.
GDP: purchasing power parity — $NA
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $NA
GDP— composition by sector:
agriculture: NA%
industry: NA%
services : NA%
Inflation rate— consumer price index: NA%
Labor force:
total: 14 able-bodied men (1993)
by occupation: no business community in the usual
sense; some public works; subsistence farming and
fishing
Unemployment rate: NA%
Budget:
revenues: $729,884
expenditures: $878,1 1 9, including capital
expenditures of $NA (FY94/95 est.)
Industries: postage stamps, handicrafts
Industrial production growth rate: NA%
Electricity— capacity: NA kW
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Agriculture— products: wide variety of fruits and
vegetables
Exports: $NA
commodities: fruits, vegetables, curios
partners : NA
Imports: $NA
commodities: fuel oil, machinery, building materials,
flour, sugar, other foodstuffs
partners : NA
Debt— external: $NA
Economic aid:
recipient: ODA bilateral commitments (1992-93),
$84,000
Currency: 1 New Zealand dollar (NZ$) = 100 cents
Exchange rates: New Zealand dollars (NZ$) per
US$1 -1.7283 (January 1998), 1.5083 (1997),
1.4543 (1996), 1.5235 (1995), 1.6844 (1994), 1.8495
(1993)
Fiscal year: 1 April— 31 March
Economy— overview: Economic activity is limited to
commercial fishing. The proximity to nearby oil- and
gas-producing sedimentary basins suggests the
potential for oil and gas deposits, but the region is
largely unexplored, and there are no reliable
estimates of potential reserves; commercial
exploitation has yet to be developed.','f6546c410e009d65b2a3296bb0aeeed626f83d5b66ce52f9711c8d0f49d9d336','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd89c0d96ee1f64ffb4a2d8d7b612be2ba2497cf3098630ddc1877e97b791002',1998,'AR','Argentina','economy',747,'Economy— overview: Paraguay has a market
economy marked by a large informal sector. The
informal sector features both reexport of imported
consumer goods (electronics, whiskeys, perfumes,
cigarettes, and office equipment) to neighboring
countries as well as the activities of thousands of
microenterprises and urban street vendors. The formal
sector is largely oriented toward services. A large
percentage of the population derive their living from
agricultural activity, often on a subsistence basis. The
formal economy has grown an average of about 3%
over the past five years. However, population has
increased at about the same rate over the same period,
leaving per capita income nearly stagnant. The
WASMOSY government has continued to pursue its
economic reform agenda, albeit with limited success
because of in-fighting in the ruling party and resistance
from the opposition. Paraguay''s ongoing integration
into Mercosur (the Southern Cone Common Market)
offers potential for investment and growth.
GDP: purchasing power parity— $21 .9 billion (1 997
est.)
GDP— real growth rate: 2.6% (1997 est.)
GDP— per capita: purchasing power parity— $3,900
(1997 est.)
GDP— composition by sector:
agriculture: 26.4%
industry: 24.9%
services: 48.7% (1995)
Inflation rate— consumer price index: 6.2%
(1997)
Labor force:
total: 1.8 million (1995 est.)
by occupation: agriculture 45%
Unemployment rate: 8.2% (urban) (1996 est.)
Budget:
revenues: $1.25 billion
expenditures: $1.63 billion, including capital
expenditures of $357 million (1995 est.)
Industries: meat packing, oilseed crushing, milling,
brewing, textiles, other light consumer goods, cement,
construction
Industrial production growth rate: 5.1% (1995)
Electricity— capacity: 6.533 million kW (1995)
Electricity— production: 40.05 billion kWh (1995)
note : exported about 36.96 billion kWh of electricity to','c8719893f23def21c174431c3a207bc60e93d589da277217f398ec353ef5b67b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58e0fa97a91d7874998416b6975a363f3b2dfb5a7ead87be52d4b05a55aa91be',1998,'DO','Dominican Republic','economy',755,'Economy— overview: Puerto Rico has one of the
most dynamic economies in the Caribbean region. A
diverse industrial sector has surpassed agriculture as
the primary locus of economic activity and income.
Encouraged by duty-free access to the US and by tax
incentives, US firms have invested heavily in Puerto
Rico since the 1950s. US minimum wage laws apply.
Sugar production has lost out to dairy production and
other livestock products as the main source of income
in the agricultural sector. Tourism has traditionally
been an important source of income for the island,
with estimated arrivals of nearly 4 million tourists in
1 993. The construction sector has been a key factor in
recent economic growth.
GDP: purchasing power parity— $32.9 billion (1997
est.)
GDP— real growth rate: 3% (1997 est.)
GDP— per capita: purchasing power parity— $8,600
(1997 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 5.5% (1997
est.)
Labor force:
total: 1 .3 million (1996)
by occupation : government 1 9%, manufacturing 1 3%,
trade 17%, construction 5%, other 32%, unemployed
14% (1996)
Unemployment rate: 13% (FY96/97 est.)
Budget:
revenues: $5.1 billion
expenditures: $ 5.1 billion, including capital
expenditures of $NA (FY94/95)
Industries: pharmaceuticals, electronics, apparel,
food products; tourism
Industrial production growth rate: 5% (1994 est.)
Electricity— capacity: 4.465 million kW (1995)
Electricity— production: 17.34 billion kWh (1995)
Electricity— consumption per capita: 4,548 kWh
(1995)
Agriculture— products: livestock products,
chickens; sugarcane, coffee, pineapples, plantains,
bananas
Exports:
total value: $22.9 billion (f.o.b. 1996)
commodities: pharmaceuticals, electronics, apparel,
canned tuna, rum, beverage concentrates, medical
equipment
partners: US 88% (1995 est.)
Imports:
total value: $19.1 billion (c.i.f. 1996)
commodities: chemicals, clothing, food, fish,
petroleum products
partners: US 62% (1995 est.)
Debt— external: $NA
Economic aid: none
Currency: 1 US dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 July— 30 June','3dc931a1bbfb139e2b230c315ee22979dedc6df45985077084e9f3b2e3e37f0e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae497e88a6eb56d52a3473c9e0d5782602613625d47f89312679532312f0844c',1998,'QA','Qatar','economy',762,'Economy— overview: Oil is the backbone of the
economy and accounts for more than 30% of GDP,
roughly 70% of export earnings, and 66% of
government revenues. Proved oil reserves of 3.7
billion barrels should ensure continued output at
current levels for 23 years. Oil has given Qatar a per
capita GDP comparable to the leading West
European industrial countries. Qatar''s proved
reserves of natural gas exceed 7 trillion cubic meters,
more than 5% of the world total, third largest in the
world. Production and export of natural gas are
becoming increasingly important. Long-term goals
feature the development of off-shore petroleum and
the diversification of the economy.
GDP: purchasing power parity— $1 1 .2 billion (1 997
est.)
GDP— real growth rate: 10% (1997 est.)
GDP— per capita: purchasing power parity —
$16,700 (1997 est.)
GDP— composition by sector:
agriculture: 1%
industry: 49%
serw''ces: 50% (1996 est.)
Inflation rate— consumer price index: 2.5%
(1996)
Labor force:
total: 233, 000 (1993 est.)
note: 83% of the population in the 15-64 age group is
non-national (July 1997 est.)
Unemployment rate: NA%
Budget:
revenues: $3.7 billion
expenditures: $4.5 billion, including capital
expenditures of $700 million (FY97/98 est.)
Industries: crude oil production and refining,
fertilizers, petrochemicals, steel reinforcing bars,
cement
Industrial production growth rate: -4% (1995)
Electricity— capacity: 1.303 million kW (1995)
Electricity— production: 5.8 billion kWh (1995)
Electricity— consumption per capita: 10,863 kWh
(1995)
Agriculture— products: fruits, vegetables; poultry,
dairy products, beef; fish (al! on small scale)
Exports:
total value: $ 5.8 billion (f.o.b., 1997 est.)
commodities : petroleum products 80%, fertilizers,
steel
partners: Japan 55%, Singapore 11%, South Korea
6%, Australia 3%, UAE 3% (1996)
Imports:
total value: $5 billion (f.o.b., 1997 est.)
commodities: machinery and equipment, consumer
goods, food, chemicals
partners: Italy 14%, UK 12%, France 11%, Japan
10%, Germany 9% (1996)
Debt— external: $11 billion (1997 est.)
Economic aid: $NA
Currency: 1 Qatari riyal (QR) = 100 dirhams
Exchange rates: Qatari riyals (QR) per US$1 —
3.6400 riyals (fixed rate)
Fiscal year: 1 April— 31 March','b02672d17dda29598b5d42a5f70ce4bca45366e3078f938d02fea12cf34965c3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61f46b8d713be270f3dc3ca0591b84ab317ad0e2954cbbc2cf8fea9578cf8a8f',1998,'UA','Ukraine','economy',771,'Economy-overview: Romania, one of the poorer
countries in the region, is continuing its difficult
transition to a market-based economy. After the
collapse of the Soviet Bloc in 1 989-91 , Romania was
left with an obsolete industrial base and a pattern of
industrial capacity wholly unsuited to its needs. For
the next few years the country lagged behind most of
its neighbors in the pace of restructuring. Then in
February 1997, Romania embarked on a
comprehensive macroeconomic stabilization and
structural reform program. The domestic foreign
exchange market was freed, and controls on
current-account convertibility were removed in
October. Restructuring programs include liquidating
large energy-intensive industries, and agricultural and
financial sector reform. The private sector share of
GDP rose to an estimated 58% in 1997, however, this
total includes firms with government-held minority
stakes. Although progress has been made in
privatizing small- and medium-sized firms, delays in
structural reforms— including the postponement of
sales of large state-owned enterprises— threaten
plans to revive GDP growth. In 1998, GDP will likely
be unchanged; and inflation is projected to fall to 45%
from 151% in 1997.
GDP: purchasing power parity— $1 1 4.2 billion (1 997
est.)
GDP— real growth rate: -6.6% (1997 est.)
GDP— per capita: purchasing power parity— $5,300
(1997 est.)
GDP— composition by sector:
agriculture: 19%
industry: 36%
se/v/ces:45% (1996)
Inflation rate— consumer price index: 151%
(1997 est.)
Labor force:
total: 10.1 million (1996 est.)
by occupation: industry 28.6%, agriculture 34.4%,
trade 10.4%, construction 5.1%, other 21.5% (1995)
Unemployment rate: 8.8% (1997 est.)
Budget:
revenues; $10 billion
expenditures: $1 1 .7 billion, including capital
expenditures of $1.3 billion (1997 est.)
Industries: mining, timber, construction materials,
metallurgy, chemicals, machine building, food
processing, petroleum production and refining
Industrial production growth rate: -5.9% (1997
est.)
Electricity— capacity: 22.06 million kW (1995)
Electricity— production: 55.19 billion kWh (1995)
Electricity— consumption per capita: 2,412 kWh
(1995)
Agriculture— products: wheat, corn, sugar beets,
sunflower seed, potatoes, grapes; milk, eggs, meat
Exports:
total value: $8.4 billion (f.o.b., 1997 est.)
commodities: textiles and footwear 27.5%, metals and
metal products 16.2%, mineral products 9.0%,
chemicals 11.2%, other 36.1% (1996)
partners: Germany 18.1%, Italy 16.7%, France 5.6%,
Turkey 5%, Netherlands 4.2%, China 3.0% (1996)
Imports:
total value: $10 A billion (f.o.b., 1997 est.)
commodities: fuels and minerals 24%, machinery and
transport equipment 25%, food and agricultural goods
7.6%, chemicals 12.5%, other 30.9% (1996)
partners: Germany 17.1%, Italy 15.6%, Russia
12.6%, France 5.0%, US 3.8%, Egypt 3.8% (1996)
Debt— external: $10 billion (1997 est.)
Economic aid:
recipient: $NA
Currency: 1 leu (L) = 100 bani
Exchange rates: lei (L) per US$1— 8,293.40
(January 1998), 7,167.94 (1997), 3,084.22 (1996),
2,033.28 (1995), 1,655.09 (1994), 760.05 (1993)
Fiscal year: calendar year
Economy— overview: Russia, a vast country with a
wealth of natural resources, a well-educated
population, and a diverse, but declining, industrial
base, continues to experience formidable difficulties in
moving from its old centrally planned economy to a
modern market economy. After seven consecutive
years of contraction 1990-96 in which GDP fell by
one-third, GDP grew by 0.4% in 1997, according to
official statistics. Moscow continued to make strides in
its battle against inflation, which fell to 11%, half the
1996 rate. The central government made good on
most back wages owed public-sector employees—
including the military— although the stock of wage
arrears to employees of private enterprises remained
large. Privatization revenues increased significantly,
largely on the strength of a few high-profile tenders,
such as that of telecommunications giant Svyazinvest.
On the downside, Moscow continued to struggle with
a severe fiscal imbalance. Lagging tax collections led
the government to adopt a revised budget in spring
1 997 that cut spending by about 20% despite protests
from the legislature. Russia''s traditional trade surplus
continued to contract— largely because of soft
international commodity prices— and Moscow''s WT rO
accession made only halting progress. Although
President YELTSIN brought in a new economic team
early in 1 997, key structural reform initiatives continue
to move slowly. A revised tax code remains stuck in
the Duma, while little progress is being made on
agricultural land reform. Small business development
has lagged. Prospects for a return to robust growth
have been set back by the spillover from Asia''s
financial turmoil, which hit Russia hard during the last
quarter of 1 997. Moscow at first tried to both support
the ruble and keep interest rates down, but this policy
proved unsustainable, and in early December 1997
the Central Bank let interest rates rise sharply. As the
year ended, Russian authorities were attempting to
put the best face on the financial situation, while at the
same time scaling back their previous optimistic
growth projections for 1998 to 1%-2%. Because of
Russia''s severe macroeconomic constraints,
resources allocated to the military sector have
declined sharply since the implosion of the USSR in
December 1991.
GDP: purchasing power parity— $692 billion (1997
est.)
GDP— real growth rate: 0.4% (1997 est.)
GDP— per capita: purchasing power parity— $4,700
(1997 est.)
GDP— composition by sector:
agriculture; 7%
industry: 39%
services: 54% (1996)
Inflation rate— consumer price index: 1 1 % (1 997
est.)
Labor force:
fofa/: 66 million (1997)
by occupation: NA
Unemployment rate: 9% (1997 est.) with
considerable additional underemployment
Budget:
revenues: $59 billion
expenditures: $70 billion, including capital
expenditures of $NA (1997 est.)
Industries: complete range of mining and extractive
industries producing coal, oil, gas, chemicals, and
metals; all forms of machine building from rolling mills
to high-performance aircraft and space vehicles;
shipbuilding; road and rail transportation equipment;
communications equipment; agricultural machinery,
tractors, and construction equipment; electric power
generating and transmitting equipment; medical and
scientific instruments; consumer durables, textiles,
foodstuffs, handicrafts
Industrial production growth rate: 1 .9% (1997
est.)
Electricity— capacity: 214.687 million kW (1995)
Electricity— production: 834 billion kWh (1997)
Electricity— consumption per capita: 5,508 kWh
(1995)
Agriculture— products: grain, sugar beets,
sunflower seed, vegetables, fruits (because of its
northern location does not grow citrus, cotton, tea, and
other warm climate products); meat, milk
Exports:
total value: $86.7 billion (1997)
commodities: petroleum and petroleum products,
natural gas, wood and wood products, metals,
chemicals, and a wide variety of civilian and military
manufactures
partners: Europe, North America, Japan, Third World
countries
Imports:
total value: $66.9 billion (1 997)
commodities : machinery and equipment, consumer
goods, medicines, meat, grain, sugar, semifinished
metal products
partners: Europe, North America, Japan, Third World
countries
Debt— external: $135 billion (yearend 1996)
Economic aid:
recipient: ODA, $15 billion drawn (1990-97)
note: US commitments, including Ex-lm, $15 billion
(1990-96); other countries, ODA and OOF bilateral
commitments (1990-96), $125 billion
Currency: 1 ruble (R) = 100 kopeks
Exchange rates: rubles per US$1— 5,941
(December 1997), 5,785 (1997), 5,121 (1996), 4,559
(1995), 2,191 (1994), 992 (1993)
Fiscal year: calendar year','7bc3246f6a755a85c2db4b42a261b9c674ecf7dddfcb8c50987ba7830e80f943','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e937d22a403083e027319738db7e4b03cbf33650d0a2a74d19a737930c361d4',1998,'UG','Uganda','economy',782,'Economy— overview: Rwanda is a poor African
nation which has suffered bitterly from ethnic-based civil
war. The agricultural sector dominates the economy;
coffee and tea normally make up 80%-90% of exports.
The amount of fertile land is limited, however, and
deforestation and soil erosion continue to reduce the
production potential. Manufacturing focuses mainly on
the processing of agricultural products. A structural
adjustment program with the World Bank began in
October 1990. Civil war in 1990 devastated wide areas,
especially in the north, and displaced hundreds of
thousands of people. A peace accord in mid-1993
temporarily ended most of the fighting, but resumption of
large-scale violence and genocide in April 1994 in the
394
capital city Kigali and elsewhere took 500,000 lives in
that year alone and severely damaged already poor
economic prospects. In 1994-96, peace was restored
throughout much of the country. In 1 996-97 most of the
refugees who fled the war returned to Rwanda. Sketchy
data suggest that GDP dropped 50% in 1 994 and came
back partially, by 25%, in 1995. Plentiful rains helped
agriculture in 1 996, and outside aid continued to support
this desperately poor economy. The economy continues
to face significant challenges in rehabilitating
infrastructure, agriculture, health care facilities, and
capital plant. Recovery of domestic production will
proceed slowly.
GDP: purchasing power parity— $3 billion (1 996 est.)
GDP-real growth rate: 13.3% (1996)
GDP— per capita: purchasing power parity— $440
(1996 est.)
GDP— composition by sector:
agriculture: 37%
industry: 17%
services: 46% (1995 est.)
Inflation rate— consumer price index: 7.4%
(1996)
Labor force:
total: 3.6 million
by occupation: agriculture 93%, government and
services 5%, industry and commerce 2%
Unemployment rate: NA%
Budget:
revenues; $231 million
expenditures: $31 9 million, including capital
expenditures of $13 million (1996 est.)
Industries: mining of cassiterite (tin ore) and
wolframite (tungsten ore), tin, cement, processing of
agricultural products, small-scale beverage
production, soap, furniture, shoes, plastic goods,
textiles, cigarettes
Industrial production growth rate: 4.9% (1995
est.)
Electricity— capacity: 34,000 kW (1995)
Electricity— production: 169 million kWh (1995)
Electricity— consumption per capita: 21 kWh
(1995)
Agriculture— products: coffee, tea, pyrethrum
(insecticide made from chrysanthemums), bananas,
beans, sorghum, potatoes; livestock
Exports:
total value: $ 62.3 million (f.o.b., 1996 est.)
commodities: coffee 74%, tea, cassiterite, wolframite,
pyrethrum (1995)
partners: Brazil, EU
Imports:
total value: $202.4 million (f.o.b., 1996 est.)
commodities: foodstuffs 35%, machines and
equipment, capital goods, steel, petroleum products,
cement and construction material (1995)
partners : US, EU, Kenya, Tanzania
Debt— external: $1 billion (December 1995)
Economic aid:
recipient: ODA, $NA
note: in October 1990 Rwanda launched a Structural
Adjustment Program with the IMF; since September
1991 , the EU has given $46 million and the US $25
million in support of this program (1993)
Currency: 1 Rwandan franc (RF) = 100 centimes
Exchange rates: Rwandan francs (RF) per US$1 —
302.28 (January 1 998), 301 .53 (1 997), 306.82 (1 996),
262.20 (1995), 144.31 (1993)
Fiscal year: calendar year
Economy— overview: The economy depends
primarily on financial assistance from the UK. The
local population earns some income from fishing, the
raising of livestock, and sales of handicrafts. Because
there are few jobs, a large proportion of the work force
has left to seek employment overseas.
GDP: purchasing power parity — $NA
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity — $NA
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force:
total: 2,41 6 (1991 est.)
by occupation: professional, technical, and related
workers 8.7%, managerial, administrative, and clerical
12.8%, sales people 8.1%, farmer, fishermen, etc.
5.4%, craftspersons, production process workers
14.7%, others 50.3% (1987)
note: a large proportion of the work force has left to
seek employment overseas
Unemployment rate: NA%
Budget:
revenues: 2 million
expenditures: million, including capital
expenditures of $NA (FY92/93)
Industries: crafts (furniture, lacework, fancy
woodwork), fishing
Industrial production growth rate: NA%
Electricity— capacity: 4,000 kW (1995)
Electricity— production: 6 million kWh (1995)
Electricity— consumption per capita: 887 kWh
(1995)
Agriculture— products: maize, potatoes,
vegetables; timber production being developed;
fishing, including crawfishing on Tristan da Cunha
Exports:
total value: $ 704,000 (f.o.b., 1995)
commodities: fish (frozen, canned, and salt-dried
skipjack, tuna), handicrafts
partners: South Africa, UK
Imports:
total value: $14,434 million (c.i.f., 1995)
commodities: food, beverages, tobacco, fuel oils,
animal feed, building materials, motor vehicles and
parts, machinery and parts
partners: UK, South Africa
Debt— external: $NA
Economic aid:
recipient: $5.3 million from UK (1997)
Currency: 1 Saint Helenian pound (£S) = 1 00 pence
Exchange rates: Saint Helenian pounds (£S) per
US$1— 0.6115 (January 1998), 0.6047 (1997),
0.6403 (1996), 0.6335 (1995), 0.6529 (1994), 0.6658
(1 993); note— the Saint Helenian pound is at par with
the British pound
Fiscal year: 1 April— 31 March','da99bc010044bb752ecfb8202fa8e00950a4a432aae149ba22325c83ae46f910','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aefb3e6ef6627b184be8ca65a21bfb963d72237b4c0f4410f5a4a151afa7eee',1998,'TT','Trinidad and Tobago','economy',790,'Economy— overview: The economy has
traditionally depended on the growing and processing
of sugarcane; decreasing world prices have hurt the
industry in recent years. Tourism, export-oriented
manufacturing, and offshore banking activity have
assumed larger roles. Most food is imported. The
government has undertaken a program designed to
revitalize the faltering sugar sector. It is also working
to improve revenue collection in order to better fund
social programs. In 1997 some leaders in Nevis were
urging separation from Saint Kitts on the basis that
Nevis was paying far more in taxes than it was
receiving in government services.
GDP: purchasing power parity— $235 million (1996
est.)
GDP— real growth rate: 5.8% (1996 est.)
GDP— per capita: purchasing power parity— $5,700
(1996 est.)
GDP— composition by sector:
agriculture: 6%
industry: 22%
services: 72% (1996 est.)
Inflation rate— consumer price index: 3.1%
(1996)
Labor force:
total: 18,172 (June 1995)
by occupation: services 69%, manufacturing 31%
Unemployment rate: 4.3% (May 1995)
Budget:
revenues: $100.2 million
expenditures: $100.1 million, including capital
expenditures of $41 .4 million (1 996 est.)
Industries: sugar processing, tourism, cotton, salt,
copra, clothing, footwear, beverages
Industrial production growth rate: NA%
Electricity— capacity: 16,000 kW (1995)
Electricity— production: 81 million kWh (1995)
Electricity— consumption per capita: 1 ,976 kWh
(1995)
Agriculture— products: sugarcane, rice, yams,
vegetables, bananas; fishing potential not fully
exploited
Exports:
total value: $ 39.1 million (f.o.b., 1996 est.)
commodities: machinery, food, electronics,
beverages and tobacco
partners: US 46.6%, UK 26.4%, Caricom nations
9.8% (1994)
Imports:
total value : $131 .5 million (f.o.b., 1996 est.)
commodities: machinery, manufactures, food, fuels
partners : US 45%, Caricom nations 18.8%, UK
12.5%, Canada 4.2%, Japan 4.2%, (1994)
Debt— external: $56 million (1995 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars (EC$) per
US$1— 2.7000 (fixed rate since 1976)
Fiscal year: calendar year
Economy— overview: Though foreign investment in
manufacturing and information processing in recent
years has increased Saint Lucia''s industrial base, the
economy remains vulnerable due to its heavy
dependence on banana production, which is subject
to periodic droughts and tropical storms. Indeed, the
destructive effect of Tropical Storm Iris in mid-1995
caused the loss of 20% of the year''s banana crop.
Increased competition from Latin American bananas
will probably further reduce market prices,
exacerbating Saint Lucia''s need to diversify its
economy in coming years, e.g., by further expanding
tourism, manufacturing, and construction.
GDP: purchasing power parity— $600 million (1996
est.)
GDP— real growth rate: 0.8% (1996 est.)
GDP— per capita: purchasing power parity— $3,800
(1996 est.)
GDP— composition by sector:
agriculture: 10.7%
industry : 32.3%
services: 57% (1 996 est.)
Inflation rate— consumer price index: -2.3%
(1996 est.)
Labor force:
total: 43,800
by occupation : agriculture 43.4%, services 38.9%,
industry and commerce 17.7% (1983 est.)
Unemployment rate: 15% (1996 est.)
Budget:
revenues: $155 million
expenditures: $169 million, including capital
expenditures of $48 million (FY96/97 est.)
Industries: clothing, assembly of electronic
components, beverages, corrugated cardboard
boxes, tourism, lime processing, coconut processing
Industrial production growth rate: 2.8% (1996
est.)
Electricity— capacity: 22,000 kW (1995)
Electricity— production: 110 million kWh (1995)
Electricity— consumption per capita: 705 kWh
(1995)
Agriculture— products: bananas, coconuts,
vegetables, citrus, root crops, cocoa
Exports:
total value: $79.5 million (f.o.b., 1996 est.)
commodities: bananas 41%, clothing, cocoa,
vegetables, fruits, coconut oil
partners: UK 50%, US 24%, Caricom countries 16%
(1995)
Imports:
total value: $270.6 million (f.o.b., 1996 est.)
commodities: food 23%, manufactured goods 21%,
machinery and transportation equipment 19%,
chemicals, fuels
partners: US 36%, Caricom countries 22%, UK 11%,
Japan 5%, Canada 4% (1995)
Debt— external: $131 million (1996)
Economic aid:
recipient: ODA, $NA
Currency: 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars (EC$) per
US$1— 2.7000 (fixed rate since 1976)
Fiscal year: 1 April— 31 March','b553049d221856241c052a86d81055eaa688316066f058f4df7ebbbb6b71c6db','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5122d77791fd5a7e6725242370cbe5d9a10674687640d338ebe0114c829e9ff',1998,'MQ','Martinique','economy',802,'Economy— overview: The inhabitants have
traditionally earned their livelihood by fishing and by
servicing fishing fleets operating off the coast of
Newfoundland. The economy has been declining,
however, because the number of ships stopping at
Saint Pierre has dropped steadily over the years. In
1992, an arbitration panel awarded the islands an
exclusive economic zone of 12,348 sq km to settle a
longstanding territorial dispute with Canada, although
it represents only 25% of what France had sought.
The islands are heavily subsidized by France. Imports
come primarily from Canada and France.
GDP: purchasing power parity— $74 million (1996
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity —
$11,000 (1996 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force:
total: 2,971 (1995)
by occupation: NA
Unemployment rate: 11% (1996)
Budget:
revenues: $28 million
expenditures: $28 million, including capital
expenditures of $7.8 million (1992 est.)
Industries: fish processing and supply base for
fishing fleets; tourism
Industrial production growth rate: NA%
Electricity— capacity: 27,000 kW (1995)
Electricity— production: 42 million kWh (1995)
Electricity— consumption per capita: 6,216 kWh
(1995)
Agriculture— products: vegetables; cattle, sheep,
pigs; fish catch of 14,800 metric tons (1994)
Exports:
total value: $5 million (f.o.b., 1995)
commodities: fish and fish products, fox and mink
pelts
partners: US 58%, France 17%, UK 11%, Canada,
Portugal (1990)
Imports:
total value: $70.2 million (c.i.f., 1995)
commodities: meat, clothing, fuel, electrical
equipment, machinery, building materials
partners: Canada, France, US, Netherlands, UK
Debt— external: $NA
Economic aid:
recipient: ODA, $N A
Currency: 1 French franc (F) = 100 centimes
Exchange rates: French francs (F) per US$1 —
6.0836 (January 1998), 5.8367 (1997), 5.1 155 (1996),
4.9915 (1995), 5.5520 (1994), 5.6632 (1993)
Fiscal year: calendar year','bd038639324667ec4bf345209de65c79af9db8ed60f6438d691b113e4bc0e04d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1be986a7e7eeb2c5c3021d2d6944f929ed59651a29eee6cee3f68f636959325b',1998,'IT','Italy','economy',806,'Economy— overview: The tourist sector contributes
over 50% of GDP. In 1995 more than 3.3 million
tourists visited San Marino. The key industries are
banking, wearing apparel, electronics, and ceramics.
Main agricultural products are wine and cheeses. The
per capita level of output and standard of living are
comparable to those of Italy, which supplies much of
its food.
GDP: purchasing power parity— $500 million (1997
est.)
GDP— real growth rate: 4.8% (1994 est.)
GDP— per capita: purchasing power parity —
$20,000 (1997 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 5.3%
(1995)
Labor force:
total: 15,600 (1995)
by occupation: services 55%, industry 43%,
agriculture 2% (1995)
Unemployment rate: 3.6% (April 1996)
Budget:
revenues: $320 million
expenditures: $320 million, including capital
expenditures of $26 million (1995 est.)
Industries: tourism, textiles, electronics, ceramics,
cement, wine
Industrial production growth rate: NA%
Electricity— capacity: NA kW
note: electricity supplied by Italy
Electricity— production: NA kWh
note: electricity supplied by Italy
Electricity— consumption per capita: NA kWh
Agriculture— products: wheat, grapes, maize,
olives; cattle, pigs, horses, meat, cheese, hides
Exports: trade data are included with the statistics
for Italy; commodities: building stone, lime, wood,
chestnuts, wheat, wine, baked goods, hides, and
ceramics
Imports: trade data are included with the statistics
for Italy; commodities: wide variety of consumer
manufactures, food
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
Currency: 1 Italian lire (Lit) = 100 centesimi; note—
also mints its own coins
406
Exchange rates: Italian lire (Lit) per US$1 — 1 ,787.7
(January 1998), 1,703.1 (1997), 1,542.9 (1996),
1,628.9(1995), 1,612.4 (1994), 1,573.7(1993)
Fiscal year: calendar year
Economy— overview: Switzerland, a fundamentally
prosperous and stable modern economy with a per
capita GDP roughly 10% above that of the big West
European economies, is experiencing continued
economic difficulties. GDP growth was a minus 0.2%
in 1996 and a weak plus 0.4% in 1997. Weak
domestic consumer demand is partly at fault;
stagnating real disposable income combines with a
reluctance to reduce saving rates in the face of an
uncertain employment outlook. Switzerland''s leading
sectors, including financial services, biotechnology,
pharmaceuticals, and special-purpose machines,
therefore are more reliant on export markets. Exports
should lead an upturn in Swiss economic performance
in 1998-99, provided the franc does not appreciate
substantially as a result of Swiss monetary policy or
instability in the run up to EMU.
GDP: purchasing power parity— $1 72.4 billion (1 997
est.)
GDP— real growth rate: 0.4% (1997 est.)
GDP— per capita: purchasing power parity —
$23,800 (1997 est.)
GDP— composition by sector:
agriculture: 2.8%
industry: 31 A%
services: 66.1% (1995)
Inflation rate— consumer price index: -0.1%
(1997)
Labor force:
total: 3.8 million (850,000 foreign workers, mostly
Italian)
by occupation: services 67%, manufacturing and
construction 29%, agriculture and forestry 4% (1995)
Unemployment rate: 5% (1997 est.)
Budget:
revenues: $25.8 billion
expenditures: $30.8 billion, including capital
expenditures of $2.3 billion (1997)
Industries: machinery, chemicals, watches, textiles,
precision instruments
Industrial production growth rate: 0% (1996)
Electricity— capacity: 14.27 million kW (1995)
Electricity— production: 55 billion kWh (1996)
Electricity— consumption per capita: 6,850 kWh
(1996 est.)
Agriculture— products: grains, fruits, vegetables;
meat, eggs
Exports:
total value: $99.2 billion (f.o.b., 1997)
commodities: machinery 29%, chemicals 26%, metals
8%, agricultural products 4% (1996)
partners: EU countries 61%, US 9%, Japan 4%
(1996)
Imports:
total value: $ 86.6 billion (c.i.f., 1997)
commodities: machinery 22%, chemicals 20%, metals
8%, agricultural products 9% (1996)
partners: EU 79%, US 7%, Japan 3% (1996)
Debt— external: $NA
Economic aid:
donor: ODA, $1,034 billion (1995)
Currency: 1 Swiss franc, franken, or franco (SFR) =
100 centimes, rappen, or centesimi
Exchange rates: Swiss francs, franken, or franchi
(SFR) per US$1— 1.4757 (January 1998), 1.4513
(1997), 1 .2360 (1 996), 1 .1 825 (1 995), 1 .3677 (1994),
1.4776 (1993)
Fiscal year: calendar year
Economy— overview: Syria''s predominantly statist
economy is on a shaky footing because of
Damascus''s failure to implement extensive economic
reform. The dominant agricultural sector remains
underdeveloped, with roughly 80% of agricultural land
still dependent on rain-fed sources. Although Syria
has sufficient water supplies in the aggregate at
normal levels of precipitation, the great distance
between major water supplies and population centers
poses serious distribution problems. The water
problem is exacerbated by rapid population growth,
industrial expansion, and increased water pollution.
Private investment is critical to the modernization of
the agricultural, energy, and export sectors. Oil
production is leveling off, and the efforts of the nonoil
sector to penetrate international markets have fallen
short. Syria''s inadequate infrastructure, outmoded
453
Syria (continued)
technological base, and weak educational system
make it vulnerable to future shocks and hamper
competition with neighbors such as Jordan and Israel.
GDP: purchasing power parity— $106.1 billion (1997
est.)
GDP— real growth rate: 4.6% (1997 est.)
GDP— per capita: purchasing power parity— $6,600
(1997 est.)
GDP— composition by sector:
agriculture: 28%
industry: 14%
services: 58% (1995)
Inflation rate— consumer price index: 1 5%-20%
(1997 est.)
Labor force:
total: 4.7 million (1995 est.)
by occupation: services 40%, agriculture 40%,
industry 20% (1996 est.)
Unemployment rate: 12% (1997 est.)
Budget:
revenues: $3.9 billion
expenditures: $4.3 billion, including capital
expenditures of $1.9 billion (1996 est.)
Industries: petroleum, textiles, food processing,
beverages, tobacco, phosphate rock mining
Industrial production growth rate: 0.2% (1996
est.)
Electricity— capacity: 4.157 million kW (1995)
Electricity— production: 14.9 billion kWh (1995)
Electricity— consumption per capita: 970 kWh
(1995)
Agriculture— products: wheat, barley, cotton,
lentils, chickpeas; beef, lamb, eggs, poultry, milk
Exports:
total value: $4.2 billion (f.o.b., 1997)
commodities: petroleum 70%, textiles 12%, food and
live animals 10%, manufactures 5% (1997 est.)
partners: EU 57% (Germany 17%, Italy 16%, France
11%), Lebanon 14%, Saudi Arabia 7% (1995 est.)
Imports:
total value: $5.7 billion (c.i.f., 1997)
commodities: machinery and equipment 40%,
foodstuffs/animals 15%, metal and metal products
15%, textiles 10%, chemicals 10%, consumer goods
5% (1997 est.)
partners: EU 33% (Italy 9%, Germany 8%, France
4%), South Korea 5%, US 4%, Japan 4% (1995 est.)
Debt— external: $20 billion (1997 est.)
Economic aid:
recipient: $4.2 billion (1990-92)
Currency: 1 Syrian pound (£S) = 100 piastres
Exchange rates: Syrian pounds (£S) per US$1 —
41 .9 (January 1997); official fixed rate 11.225
Fiscal year: calendar year','79260bbe9d2e219a81bee9958081a1ca6ea8cffc052713f512ff79994adfe3a3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cd9c723edddee782072cac2ccdd8e1f455aeed03c3c0503ca90cfa886484bd5',1998,'SA','Saudi Arabia','economy',814,'Economy— overview: This is a well-to-do oil-based
economy with strong government controls over major
economic activities. About 35% of GDP comes from
the private sector. Economic (as well as political) ties
with the US are especially strong. The petroleum
sector accounts for roughly 75% of budget revenues,
35% of GDP, and 90% of export earnings. Saudi
Arabia has the largest reserves of petroleum in the
world (26% of the proved total), ranks as the largest
exporter of petroleum, and plays a leading role in
OPEC. For the 1 990s the government intends to bring
its budget, which has been in deficit since 1983, back
into balance, and to encourage private economic
activity. Roughly 4 million foreign workers play an
important role in the Saudi economy, for example, in
the oil and service sectors. Helped by production
above its OPEC quota, Saudi Arabia continued to
bring its finances closer into balance in 1997,
recording a $1 .6 billion budget deficit and a $200
million current account surplus. For 1998, the country
looks to its policies of maintaining moderate fiscal
reforms, restraining public spending, and encouraging
nonoil exports. Shortages of water and rapid
population growth will constrain government efforts to
increase self-sufficiency in agricultural products.
GDP: purchasing power parity— $206.5 billion (1 997
est.)
GDP— real growth rate: 4% (1997 est.)
GDP— per capita: purchasing power parity —
$10,300 (1997 est.)
GDP— composition by sector:
agriculture: 6%
industry: 46%
services: 48% (1996)
Inflation rate— consumer price index: 0% (1997
est.)
Labor force: 7 million
by occupation: government 40%, industry,
construction, and oil 25%, services 30%, agriculture
5%
note: 35% of the population in the 1 5-64 age group is
non-national (July 1998 est.)
Unemployment rate: NA%
Budget:
revenues: $47.5 billion
expenditures: $52.3 billion, including capital
expenditures of $NA (1998 est.)
Industries: crude oil production, petroleum refining,
basic petrochemicals, cement, two small steel-rolling
mills, construction, fertilizer, plastics
Industrial production growth rate: 16% (1996
est.)
Electricity— capacity: 20.9 million kW (1995)
Electricity— production: 65 billion kWh (1995)
Electricity— consumption per capita: 3,470 kWh
(1995)
Agriculture— products: wheat, barley, tomatoes,
melons, dates, citrus; mutton, chickens, eggs, milk
Exports:
total value: $56.7 billion (f.o.b., 1996)
commodities: petroleum and petroleum products 90%
partners: Japan 17%, US 15%, South Korea 10%,
Singapore 8%, France 5% (1996 est.)
Imports:
total value: $25.4 billion (f.o.b., 1996)
commodities: machinery and equipment, foodstuffs,
chemicals, motor vehicles, textiles
partners: US 22%, UK 1 2%, Japan 9%, Germany 8%,
Italy 5%, France 4% (1996 est.)
Debt— external: $NA
Economic aid:
donor: pledged $100 million in 1993 to fund
reconstruction of Lebanon
Currency: 1 Saudi riyal (SR) = 100 halalah
Exchange rates: Saudi riyals (SR) per US$1 —
3.7450 (fixed rate since June 1986)
Fiscal year: calendar year','72fe707548a4b3626b47a18dfc2bdae5eeacfed580a48b3ff9b6e71a216cd4e5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df71e986612e790a379b8fe928f49f27a8fd6fc1dd93431903ddacb283e40695',1998,'ML','Mali','economy',821,'Imports:
total value: $1.4 billion (f.o.b., 1996)
commodities: foods and beverages, consumer goods,
capital goods, petroleum products
partners: France 30%, other EU countries, Nigeria,
Cameroon, Cote d''Ivoire, Algeria, China, Japan
Debt— external: $3.7 billion (1996)
Economic aid:
recipient: ODA, $439 million (1993)
Currency: 1 Communaute Financiere Africaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1 —
608.36 (January 1 998), 583.67 (1 997), 51 1 .55 (1 966),
499.15 (1995), 555.20 (1994), 283.16 (1993)
note: beginning 12 January 1994, the CFA franc was
devalued to CFAF 1 00 per French franc from CFAF 50
at which it had been fixed since 1948
Fiscal year: calendar year','661ba71445699a235e91732c683815a42d7c8ebbc4a4aff975ae3dc9add779ff','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8b224d5bae9814c8b4d7751aecd834f9ef56e80108f79fe2351cd4ac22ec46d',1998,'ME','Montenegro','economy',830,'Economy— overview: The swift collapse of the
Yugoslav federation in 1991 has been followed by
highly destructive warfare, the destabilization of
republic boundaries, and the breakup of important
interrepublic trade flows. Output in Serbia and
Montenegro dropped by half in 1 992-93. Like the other
former Yugoslav republics, it had depended on its
sister republics for large amounts of energy and
manufactures. Wide differences in climate, mineral
resources, and levels of technology among the
republics accentuated this interdependence, as did
the communist practice of concentrating much
industrial output in a small number of giant plants. The
breakup of many of the trade links, the sharp drop in
output as industrial plants lost suppliers and markets,
and the destruction of physical assets in the fighting all
have contributed to the economic difficulties of the
republics. One singular factor in the economic
situation of Serbia is the continuation in office of a
communist government that is primarily interested in
political and military mastery, not economic reform.
Hyperinflation ended with the establishment of a new
currency unit in June 1 993; prices have been relatively
stable since 1 995. Reliable statistics are hard to come
by; the GDP estimate is extremely rough. The
economic boom anticipated by the government after
the suspension of UN sanctions in December 1995
has failed to materialize. Until the government
cooperates on such matters as human rights and war
criminals, it will lack full support from international
financial institutions.
GDP: purchasing power parity— $24.3 billion (1997
est.)
GDP— real growth rate: 7% (1997 est.)
GDP— per capita: purchasing power parity— $2,280
(1997 est.)
GDP— composition by sector:
agriculture: 25%
industry: 50%
services: 25% (1994 est.)
Inflation rate— consumer price index: 7% (1997)
Labor force:
total: 2.178 million
by occupation: industry 41 %, services 35%, trade and
tourism 12%, transportation and communication 7%,
agriculture 5% (1994)
Unemployment rate: more than 35% (1995 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: machine building (aircraft, trucks, and
automobiles; tanks and weapons; electrical
equipment; agricultural machinery); metallurgy (steel,
aluminum, copper, lead, zinc, chromium, antimony,
bismuth, cadmium); mining (coal, bauxite, nonferrous
ore, iron ore, limestone); consumer goods (textiles,
footwear, foodstuffs, appliances); electronics,
petroleum products, chemicals, and pharmaceuticals
Industrial production growth rate: 8% (1997 est.)
Electricity— capacity: 1 1 .779 million kW (1 995)
Electricity— production: 33.4 billion kWh (1995)
Electricity— consumption per capita: 3,009 kWh
(1995)
Agriculture— products: cereals, fruits, vegetables,
tobacco, olives; cattle, sheep, goats
Exports:
total value: $2.8 billion (1996 est.)
commodities : manufactured goods, food and live
animals, raw materials
partners: Russia, Italy, Germany
Imports:
total value: $6.2 billion (1 996 est.)
commodities : machinery and transport equipment,
fuels and lubricants, manufactured goods, chemicals,
food and live animals, raw materials
partners: Germany, Italy, Russia
Debt— external: $1 1 .2 billion (1 995 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Yugoslav New Dinar (YD) = 100 paras
Exchange rates: Yugoslav New Dinars (YD) per US
$1— official rate: 5.85 (December 1997), 5.02
(September 1996), 1 .5 (early 1995); black market
rate: 8.9 (December 1997), 2 to 3 (early 1995)
Fiscal year: calendar year
414
f Communications
Telephones: 700,000
Telephone system:
domestic: NA
international: satellite earth station— 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: 27 (public or
state-owned 1, private 26)
Radios: 2.015 million
Television broadcast stations: 8 (state owned 1 ,
privately owned 7) plus 1 Satellite TV down link and 48
cable distribution systems
Televisions: 1 million
l Transportation
Railways:
total: 3,987 km
standard gauge: 3,987 km 1 .435-m gauge (1 ,341 km
partially electrified) (1997)
Highways:
total: 49,525 km
paved: 28,873 km
unpaved: 20,652 km (1996 est.)
Waterways: NAkm
Pipelines: crude oil 41 5 km; petroleum products 1 30
km; natural gas 2,1 10 km
Ports and harbors: Bar, Belgrade, Kotor, Novi Sad,
Pancevo, Tivat, Zelenika
Merchant marine:
total: 20 ships (1 ,000 GRT or over) totaling 322,391
GRT/533,935 DWT (owned by Montenegro)
ships by type: bulk 6, cargo 1 1 , container 3
note: Montenegrin ships operate under the flag of
Malta (1997 est.)
Airports: 48 (Serbia 43, Montenegro 5) (1997 est.)
Airports— with paved runways:
total: 18
over 3,047 m: 2 (Serbia 2, Montenegro 0)
2,438 to 3,047 m: 5 (Serbia 3, Montenegro 2)
1,524 to 2,437 m: 5 (Serbia 4, Montenegro 1)
914 to 1,523 m: 2 (Serbia 2, Montenegro 0)
under 914 m: 4 (Serbia 4, Montenegro 0) (1 997 est.)
Airports— with unpaved runways:
total: 30
1,524 to 2,437 m: 2 (Serbia 2, Montenegro 0)
914 to 1,523 m: 14 (Serbia 13, Montenegro 1)
under 914 m: 1 4 (Serbia 1 3, Montenego 1 ) (1 997 est.)
i Military
Military branches: People''s Army (includes Ground
Forces with internal and border troops, Naval Forces,
and Air and Air Defense Forces), Civil Defense
Military manpower— military age: Montenegro-
19; Serbia— NA
Military manpower— availability:
males age 75-49; Montenegro — 187,131 ; Serbia —
2,731,102 (1998 est.)
Military manpower— fit for military service:
males: Montenegro— 150,666 (1998 est.); Serbia—
2,187,111 (1998 est.)
Military manpower— reaching military age
annually:
males: Montenegro— 5,591 ; Serbia— N A (1998 est.)
Military expenditures— dollar figure: 6.55 billion
dinars (1998 est.); note— conversion of defense
expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures— percent of GDP: 6% (1998
est.)','b8ef1cb36bf7a955908e0d418ee302f1ec3ee4e7ac04e1dea0d67817d0bb0554','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49c91758925a2c9c763ce8947494f059dc7e5b61a47fd23c218d0a9cd1fec1f3',1998,'SC','Seychelles','economy',835,'Economy— overview: Since independence in 1 976,
per capita output in this Indian Ocean archipelago has
expanded to roughly seven times the old
near-subsistence level. Growth has been led by the
tourist sector, which employs about 30% of the labor
force and provides more than 70% of hard currency
earnings, and by tuna fishing, which accounted for
70% of GDP in 1996-97. In recent years the
government has encouraged foreign investment in
order to upgrade hotels and other services. At the
same time, the government has moved to reduce the
dependence on tourism by promoting the
development of farming, fishing, and small-scale
manufacturing. The vulnerability of the tourist sector
was illustrated by the sharp drop in 1991-92 due
largely to the Gulf war. Although the industry has
rebounded, the government recognizes the continuing
need for upgrading the sector in the face of stiff
international competition.
GDP: purchasing power parity— $550 million (1997
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $7,000
(1997 est.)
GDP— composition by sector:
agriculture: 4%
industry: 15%
services: 81% (1994)
Inflation rate— consumer price index: -0.3%
(1995 est.)
Labor force:
total: 26,000 (1996)
by occupation: industry 19%, services 57%,
government 14%, fishing, agriculture, and forestry
10% (1989)
Unemployment rate: NA%
Budget:
revenues: $220 million
expenditures: $241 million, including capital
expenditures of $36 million (1994 est.)
Industries: fishing; tourism; processing of coconuts
and vanilla, coir (coconut fiber) rope, boat building,
printing, furniture; beverages
Industrial production growth rate: 4% (1992)
Electricity— capacity: 28,000 kW (1995)
Electricity— production: 125 million kWh (1995)
416','9286ac1de147a6d3e3ef1a387fb26e36e18a1f392eaed2ee8626808c68a865d7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('261c74f45cb0bbb4e8be6bd300947a3f54b0237068cb2cddf6079a41796937ae',1998,'SL','Sierra Leone','economy',844,'Economy— overview: Sierra Leone has substantial
mineral, agricultural, and fishery resources. However,
the economic and social infrastructure is not well
developed, and serious social disorders continue to
hamper economic development. The seizure of power
by the new Armed Forces Revolutionary Council
418
(AFRC) in May 1997 led to UN sanctions and a sharp
drop in GDP. About two-thirds of the working-age
population engages in subsistence agriculture.
Manufacturing consists mainly of the processing of
raw materials and of light manufacturing for the
domestic market. Bauxite and rutile mines have been
shut down by civil strife. The major source of hard
currency is found in the mining of diamonds, the large
majority of which are smuggled out of the country.
GDP: purchasing power parity— $2.65 billion (1997
est.)
GDP— real growth rate: -27% (1997 est.)
GDP— per capita: purchasing power parity— $540
(1997 est.)
GDP— composition by sector:
agriculture: 39%
industry: 27%
services: 34% (1995)
Inflation rate— consumer price index: 40% (1997
est.)
Labor force:
tote/: 1 .369 million (1981 est.)
by occupation: agriculture 65%, industry 19%,
services 16% (1981 est.)
note: only about 65,000 wage earners (1 985)
Unemployment rate: NA%
Budget:
revenues; $96 million
expenditures: $150 million, including capital
expenditures of $NA (1996 est.)
Industries: mining (diamonds); small-scale
manufacturing (beverages, textiles, cigarettes,
footwear); petroleum refining
Industrial production growth rate: NA%
Electricity— capacity: 126,000 kW (1995)
Electricity— production: 230 million kWh (1995)
Electricity— consumption per capita: 48 kWh
(1995)
Agriculture— products: rice, coffee, cocoa, palm
kernels, palm oil, peanuts; poultry, cattle, sheep, pigs;
fish
Exports:
total value: $ 47 million (f.o.b., 1996); note— much
reduced in 1997 by civil warfare
commodities: diamonds, rutile, cocoa, coffee, fish
partners: US 20%, Belgium 20%, Spain 13%, UK 6%,
other Western Europe
Imports:
total value: $2U million (c.i.f., 1996)
commodities: foodstuffs, machinery and equipment,
fuels and lubricants
partners: Cote d''Ivoire, EU countries, India
Debt— external: $1.1 billion (1996)
Economic aid:
recipient: ODA, $NA
Currency: 1 leone (Le) = 100 cents
Exchange rates: leones (Le) per US$1— 1 ,312.37
(December 1997), 967.72 (1997), 920.73 (1996),
755.22 (1995), 586.74 (1994), 567.46 (1993)
Fiscal year: 1 July— 30 June','06e22ae52dbcd7f2a58d46b41f4dd7e4ee1a67797045f32c54e4d162eefd6f47','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97651b6a645115209dedbce650f61cbbc80f9fba1d13decf65ada6eab167fd29',1998,'SB','Solomon Islands','economy',851,'Economy— overview: The bulk of the population
depend on subsistence agriculture, fishing, and
forestry for at least part of their livelihood. Most
manufactured goods and petroleum products must be
imported. The islands are rich in undeveloped mineral
resources such as lead, zinc, nickel, and gold. In
recent years the government has poorly managed the
country''s finances. The new prime minister has vowed
to cut expenditures and to promote the private sector
to boost economic growth.
GDP: purchasing power parity— $1 .27 billion (1997
est.)
GDP— real growth rate: 3.5% (1997 est.)
GDP— per capita: purchasing power parity— $3,000
(1997 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: 1 1 .8%
(1996)
Labor force:
total: 26,842
by occupation: services 41 .5%, agriculture, forestry,
and fishing 23.7%, commerce, transport, and finance
21.7%, construction, manufacturing, and mining
13.1% (1992 est.)
Unemployment rate: NA%
Budget:
revenues: $147 million
expenditures: $168 million, including capital
expenditures of $NA (1997 est.)
Industries: copra, fish (tuna)
Industrial production growth rate: NA%
Electricity— capacity: 12,000 kW (1995)
Electricity— production: 30 million kWh (1995)
Electricity— consumption per capita: 75 kWh
(1995)
Agriculture— products: cocoa, beans, coconuts,
palm kernels, rice, potatoes, vegetables, fruit; cattle,
pigs; timber; fish
Exports:
total value: $ 168 million (f.o.b., 1995)
commodities: timber, fish, palm oil, cocoa, copra
partners: Japan 39%, UK 23%, Thailand 9%,
Australia 5%, US 2% (1991)
Imports:
total value: $152 million (c.i.f., 1995 est.)
commodities : plant and machinery, manufactured
427
Solomon Islands (continued)
goods, food and live animals, fuel
partners: Australia 34%, Japan 16%, Singapore 14%,
NZ 9%
Debt— external: $100 million (1995 est.)
Economic aid:
recipient: ODA, $8,625 million from Australia (FY96/
97 est.); $3.3 million from NZ (FY95/96)
Currency: 1 Solomon Islands dollar (Sl$) = 100
cents
Exchange rates: Solomon Islands dollars (Sl$) per
US$1 — 3.7580 (November 1997), 3.5664 (1997),
3.4059 (1995), 3.2914 (1994), 3.1877 (1993)
Fiscal year: calendar year
Economy— overview: One of the world''s poorest
and least developed countries, Somalia has few
resources. Moreover, much of the economy has been
devastated by the civil war. Agriculture is the most
important sector, with livestock accounting for about
40% of GDP and about 65% of export earnings.
Nomads and semi-nomads, who are dependent upon
livestock for their livelihood, make up a large portion of
the population. Crop production generates only 10%
of GDP and employs about 20% of the work force.
After livestock, bananas are the principal export;
sugar, sorghum, corn, and fish are products for the
domestic market. The small industrial sector, based
on the processing of agricultural products, accounts
for less than 10% of GDP; most facilities have been
shut down because of the civil strife. Moreover,
ongoing civil disturbances in Mogadishu and outlying
areas are interfering with any substantial economic
advance.
GDP: purchasing power parity— $8 billion (1 996 est.)
GDP— real growth rate: 4% (1996 est.)
GDP— per capita: purchasing power parity— $600
(1996 est.)
GDP— composition by sector:
agriculture: 59%
industry: 10%
services: 31% (1995 est.)
Inflation rate— consumer price index: NA%
Labor force:
total : 3.7 million (very few are skilled laborers)(1993
est.)
by occupation: agriculture (mostly pastoral
nomadism) 71%, industry and services 29%
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: a few small industries, including sugar
refining, textiles, petroleum refining (mostly shut
down)
Industrial production growth rate: NA%
Electricity— capacity: 144,000 kW prior to the civil
war, but now largely shut down due to war damage;
some localities operate their own generating plants,
providing limited municipal power; note— UN and
relief organizations use their own portable power
systems
Electricity— production: 245 million kWh (1995
est.)
Electricity— consumption per capita: 33 kWh
(1995 est.)
Agriculture— products: bananas, sorghum, corn,
sugarcane, mangoes, sesame seeds, beans; cattle,
sheep, goats; fishing potential largely unexploited
Exports:
total value: $130 million (1 994 est.)
commodities : bananas, live animals, fish, hides
(1997)
partners: Saudi Arabia 57%, Yemen 14%, Italy 13%,
UAE 10%, US (bananas) (1995 est.)
Imports:
total value: $ 269 million (1994 est.)
commodities: manufactures, petroleum products,
foodstuffs, construction materials (1995)
partners: Kenya 24%, Djibouti 18%, Pakistan 6%
(1995 est.)
Debt— external: $2.6 billion (1994 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Somali shilling (So. Sh.) = 100 cents
Exchange rates: Somali shillings (So. Sh.) per
US$1— 7,500 (November 1997 est.), 7,000 (January
1996 est.), 5,000 (1 January 1995), 2,616 (1 July
1993), 4,200 (December 1992)
note: the Republic of Somaliland, a self-declared
independent country not recognized by any
government, issues its own currency, the Somaliland
shilling (Sol. Sh.); estimated exchange rate, Sol. Sh.
per US$1— 4,000 (November 1997)
Fiscal year: NA
Economy— overview: South Africa is a
middle-income, developing country with an abundant
supply of resources, well developed financial, legal,
communications, energy, and transport sectors, a
stock exchange which ranks among the ten largest in
the world, and a modern infrastructure supporting an
efficient distribution of goods to major urban centers
throughout the region. Growth has been positive since
the historic election of President Nelson MANDELA in
the country''s first multi-racial elections in 1 994, but not
strong enough to cut into the substantial
unemployment. Daunting economic problems remain
from the apartheid era, especially the problems of
poverty and economic empowerment among the
blacks. Other problems are crime and corruption. The
new South African government demonstrated its
commitment to open markets, privatization, and a
favorable investment climate with the release of its
macroeconomic strategy in June 1996. Called
"Growth, Employment and Redistribution," this policy
framework includes the introduction of tax incentives
to stimulate new investment in labor-intensive
projects, expansion of basic infrastructure services,
the restructuring and partial privatization of state
431
South Africa (continued)
assets, continued reduction of tariffs and subsidies to
promote economic efficiency, improved services to
the disadvantaged, and integration into the global
GDP: purchasing power parity— $270 billion (1997
est.)
GDP— real growth rate: 3% (1997 est.)
GDP— per capita: purchasing power parity— $6,200
(1997 est.)
GDP— composition by sector:
agriculture: 5%
industry : 37%
services: 58% (1995 est.)
Inflation rate— consumer price index: 9.7% (1997
est.)
Labor force:
total: 14.2 million economically active (1996)
by occupation: services 35%, agriculture 30%,
industry 20%, mining 9%, other 6%
Unemployment rate: 30% (1 997 est.); note— an
additional 11% of the workforce is underemployed
Budget:
revenues; $30.5 billion
expenditures: $38 billion, including capital
expenditures of $2.6 billion (FY94/95 est.)
Industries: mining (world''s largest producer of
platinum, gold, chromium), automobile assembly,
metalworking, machinery, textile, iron and steel,
chemical, fertilizer, foodstuffs
Industrial production growth rate: 1 .2% (1996
est.)
Electricity— capacity: 34.566 million kW (1995)
Electricity— production: 163.56 billion kWh (1995)
Electricity— consumption per capita: 3,559 kWh
(1995)
Agriculture— products: corn, wheat, sugarcane,
fruits, vegetables; beef, poultry, mutton, wool, dairy
products
Exports:
total value: $31 .3 billion (f.o.b., 1997)
commodities: gold 20%, other minerals and metals
20%-25%, food 5%, chemicals 3% (1997)
partners: Italy, Japan, US, Germany, UK, other EU
countries, Hong Kong
Imports:
total value: $28 billion (f.o.b., 1997)
commodities: machinery 32%, transport equipment
15%, chemicals 11%, petroleum products, textiles,
scientific instruments (1994)
partners: Germany, US, Japan, UK, Italy
Debt— external: $23.5 billion (1997 est.)
Economic aid:
recipient: ODA, $NA
note: current aid pledges include US $600 million over
three years, 1994-96; UK $150 million over three
years; Australia $21 million over three years; Japan
$1 .3 billion over two years ending in 1 996; EU $833
million over five years
Currency: 1 rand (R) = 100 cents
Exchange rates: rand (R) per US$1 — 4.941 93
(January 1998), 4.60796 (1997), 4.29935 (1996),
3.62709 (1995), 3.55080 (1994), 3.26774 (1993)
Fiscal year: 1 April— 31 March
Economy— overview: Some fishing takes place in
adjacent waters. There is a potential source of income
from harvesting fin fish and krill. The islands receive
income from postage stamps produced in the UK.
Budget:
revenues: $291 ,777
expenditures: $451 ,000, including capital
expenditures of $NA (1988 est.)','80226ed1d61e79bb4abf4f3edbec36cea5f6850a6ab6f04d0931466bf3bb6e53','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('667326c3c3e9080658276adecd631c20a11daa0b621f1b4ccd31c0f699bbf338',1998,'LK','Sri Lanka','economy',859,'Economy— overview: At independence in 1948,
plantations growing tea, rubber, or coconuts and
paddies growing rice for subsistence dominated Sri
Lanka''s economy, and, as late as 1 970, plantation crops
accounted for 93% of exports. In 1977, Colombo
abandoned statist economic policies and its import
substitution trade policy for market-oriented policies and
export-oriented trade. Sri Lanka''s most dynamic
industries now are food processing, textiles and apparel,
food and beverages, telecommunications, and
insurance and banking. By 1996 plantation crops made
up only 20% of exports, while textiles and garments
accounted for 63%. GDP grew at an annual average
rate of 5.5% throughout the 1 990s until a drought and a
deteriorating security situation lowered growth to 3.8% in
1996. The economy rebounded in second half 1996,
however, and continued to perform well in 1997 with
growth of 6%. Sustained economic growth, coupled with
population growth of only 1 .1%, has pushed Sri Lanka
from the ranks of the poorest countries in the world up to
the threshold of the middle income countries. For the
next round of reforms, the central bank of Sri Lanka
recommends that Colombo expand market
mechanisms in nonplantation agriculture, dismantle the
government''s monopoly on wheat imports, and promote
more competition in the financial sector. A continuing
cloud over the economy is the fighting between the
Sinhalese and the minority Tamils, which has cost
50,000 lives in the past 14 years.
GDP: purchasing power parity— $72.1 billion (1997
est.)
GDP— real growth rate: 6% (1997 est.)
GDP— per capita: purchasing power parity— $3,800
(1997 est.)
GDP— composition by sector:
agriculture: 18.4%
industry: 18%
services: 63.6% (1996)
Inflation rate— consumer price index: 9.6%
(1997)
Labor force:
total: 6.2 million (1997)
by occupation: services 46%, agriculture 37%,
industry 17% (1997 est.)
Unemployment rate: 11% (1997 est.)
Budget:
revenues; $3 billion
expenditures: $4.2 billion, including capital
expenditures of $1 billion (1997 est.)
Industries: processing of rubber, tea, coconuts, and
other agricultural commodities; clothing, cement,
petroleum refining, textiles, tobacco
Industrial production growth rate: 6.5% (1996
est.)
Electricity— capacity: 1.557 million kW (1997 est.)
Electricity— production: 4.86 billion kWh (1997
est.)
Electricity— consumption per capita: 220 kWh
(1997 est.)
Agriculture— products: rice, sugarcane, grains,
pulses, oilseed, roots, spices, tea, rubber, coconuts;
milk, eggs, hides, meat
Exports:
total value: $4.1 billion (f.o.b., 1996)
commodities: textiles and apparel, tea, diamonds and
other gems, rubber products, petroleum products
(1995)
partners: US 34%, UK 9.5%, Japan 6.2%, Germany
5.8%, Belgium-Luxembourg 5.3% (1996)
Imports:
total value : $5.4 billion (c.i.f., 1996)
commodities: machinery and equipment, textiles,
transport equipment, petroleum, building materials,
sugar, wheat (1996)
partners: India 10.4%, Japan 9.1%, South Korea
6.5%, Hong Kong 6.5%, Taiwan 5.3% (1996)
Debt— external: $9.4 billion (1996)
Economic aid:
recipient: ODA, $620 million (1996 est.)
Currency: 1 Sri Lankan rupee (SLRe) = 100 cents
Exchange rates: Sri Lankan rupees (SLRes) per
US$1— 61.479 (January 1998), 58.995 (1997),
55.271 (1996), 51.252 (1995), 49.415 (1994), 48.322
(1993)
Fiscal year: calendar year','2e5a4f7eeb41135fbab0a6f0e5557dc761f5027301064d7363127e5c9eb28b7e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6987a4eb4cc00db22f3bff83fa49d4eab364fa03794cb1856c2accd5c94b01e4',1998,'SR','Suriname','economy',863,'Unemployment rate: 30% (FY92/93 est.)
Budget:
revenues: $482 million
expenditures: $1 .5 billion, including capital
expenditures of $30 million (1996)
Industries: cotton ginning, textiles, cement, edible
oils, sugar, soap distilling, shoes, petroleum refining
Industrial production growth rate: 5% (1996 est.)
Electricity-capacity: 500,000 kW (1995)
Electricity— production: 1.305 billion kWh (1995)
Electricity— consumption per capita: 43 kWh
(1995)
Agriculture— products: cotton, groundnuts,
sorghum, millet, wheat, gum arabic, sesame; sheep
Exports:
total value: $620 million (f.o.b., 1996)
commodities: cotton 23%, sesame 22%, livestock/
meat 13%, gum arabic 5% (1996)
partners: Saudi Arabia 20%, UK 14%, China 11%,
Italy 8% (1996)
Imports:
total value: $1 .5 billion (1 996)
commodities: foodstuffs, petroleum products,
manufactured goods, machinery and equipment,
medicines and chemicals, textiles (1996)
partners: Saudi Arabia 10%, South Korea 7%,
Germany 6%, Egypt 6% (1996)
Debt— external: $20.3 billion (1996 est.)
Economic aid:
recipient: ODA, $387 million (1993)
Currency: 1 Sudanese pound (£Sd) = 100 piastres
Exchange rates: Sudanese pounds (£Sd) per
US$1 — official rate: 1,602.70 (July 1997), 1,250.79
(1996), 580.87 (1995), 289.61 (1994), 159.31 (1993);
market rate: 1,612.90 (July 1997), 1,250.79 (1996),
571.02 (August 1995), 289.61 (1994), 159.31 (1993),
97.43 (1992)
note; the market rate is a unified exchange rate
determined by a committee of local bankers, without
official intervention, and is quoted uniformly by all
commercial banks
Fiscal year: calendar year
note: prior to July 1 995, Sudan had a fiscal year that
began on 1 July and ended on 30 June; as a transition
to their new fiscal year, a six-month budget was
implemented for 1 July-31 December 1995; the new
calendar year (1 January-31 December) fiscal year
became effective 1 January 1996','add0e7fcb452cd8341b00c0d664d286b2e3bfa3f04426339cbb04c5713d5058f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4dddad00b290dafb2f45d36829a85792e13d68c213ca341f2a7d3ce7d74d7a6',1998,'ZW','Zimbabwe','economy',872,'Economy— overview: Tajikistan has the lowest per
capita GDP among the former Soviet republics.
Agriculture dominates the economy, with cotton the
most important crop. Mineral resources, varied but
limited in amount, include silver, gold, uranium, and
tungsten. Industry is limited to a large aluminum plant,
hydropower facilities, and small obsolete factories
mostly in light industry and food processing. The Tajik
economy has been gravely weakened by four years of
civil conflict and by the loss of subsidies from Moscow
and of markets for its products. Tajikistan thus
depends on aid from Russia and Uzbekistan and on
international humanitarian assistance for much of its
basic subsistence needs. Even if the peace
agreement of June 1 997 is honored, the country faces
major problems in integrating refugees and former
combatants into the economy. Moreover, constant
political turmoil and the continued dominance by
former communist officials have impeded the
introduction of meaningful economic reforms.
GDP: purchasing power parity— $4.1 billion (1997
est.)
GDP— real growth rate: -10% (1997 est.)
GDP— per capita: purchasing power parity— $700
(1997 est.)
GDP— composition by sector:
agriculture : 25%
industry : 35%
services: 40% (1997)
Inflation rate— consumer price index: 40% (1996
est.)
Labor force:
total: 1 .9 million (1996)
by occupation : agriculture and forestry 52%,
manufacturing, mining, and construction 17%,
services 31% (1995)
Unemployment rate: 2.4% includes only officially
registered unemployed; also large numbers of
underemployed workers and unregistered
unemployed people (December 1996)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: aluminum, zinc, lead, chemicals and
fertilizers, cement, vegetable oil, metal-cutting
machine tools, refrigerators and freezers
Industrial production growth rate: -20% (1996
est.)
Electricity— capacity: 4.443 million kW (1995)
Electricity— production: 14.66 billion kWh (1995)
Electricity— consumption per capita: 2,302 kWh
(1995)
Agriculture— products: cotton, grain, fruits, grapes,
vegetables; cattle, sheep, goats
Exports:
total value : $768 million (1996 est.)
commodities: cotton, aluminum, fruits, vegetable oil,
textiles
partners: FSU 78%, Netherlands (1994)
Imports:
total value: $657 million (1996 est.)
commodities: fuel, chemicals, machinery and
transport equipment, textiles, foodstuffs
partners: FSU 55%, Switzerland, UK (1994)
456
Debt— external: $635 million (of which $250 million
to Russia) (1995 est.)
Economic aid:
recipient: ODA, $22 million (1993)
note; commitments, $885 million (disbursements
$115 million) (1992-95)
Currency: the Tajikistani ruble (TJR) = 100 tanga;
Tajikistan introduced its own currency in May 1995
Exchange rates: Tajikistani rubies (TJR) per
US$1— 350 (January 1997), 284 (January 1996)
Fiscal year: calendar year
Economy— overview: Tanzania is one of the
poorest countries in the world. The economy is heavily
dependent on agriculture, which accounts for 57% of
GDP, provides 85% of exports, and employs 90% of
the work force. Topography and climatic conditions,
however, limit cultivated crops to only 4% of the land
area. Industry accounts for 17% of GDP and is mainly
limited to processing agricultural products and light
consumer goods. The economic recovery program
announced in mid-1986 has generated notable
increases in agricultural production and financial
support for the program by bilateral donors. The World
Bank, the International Monetary Fund, and bilateral
donors have provided funds to rehabilitate Tanzania’s
deteriorated economic infrastructure. Growth in
1 991 -97 has featured a pickup in industrial production
and a substantial increase in output of minerals, led by
gold. Natural gas exploration in the Rufiji Delta looks
promising and production could start by 2002. Recent
banking reforms have helped increase private sector
growth and investment.
GDP: purchasing power parity— $21.1 billion (1997
est.)
GDP— real growth rate: 4.3% (1997 est.)
GDP— per capita: purchasing power parity— $700
(1997 est.)
GDP— composition by sector:
agriculture: 57%
industry: 17%
services: 26% (1995 est.)
Inflation rate— consumer price index: 15% (1997
est.)
Labor force:
total: 13.495 million
by occupation: agriculture 90%, industry and
commerce 10% (1995 est.)
Unemployment rate: NA%
Budget:
revenues: $959 million
expenditures:^ A billion, including capital
expenditures of $214 million (FY96/97 est.)
Industries: primarily agricultural processing (sugar,
beer, cigarettes, sisal twine), diamond and gold
mining, oil refining, shoes, cement, textiles, wood
products, fertilizer, salt
Industrial production growth rate: 0.4% (1995
est.)
Electricity— capacity: 439,000 kW (1995)
Electricity— production: 895 million kWh (1995)
Electricity— consumption per capita: 31 kWh
(1995)
Agriculture— products: coffee, sisal, tea, cotton,
pyrethrum (insecticide made from chrysanthemums),
cashews, tobacco, cloves (Zanzibar), corn, wheat,
cassava (tapioca), bananas, fruits, vegetables; cattle,
sheep, goats
Exports:
total value: $ 760 million (f.o.b., 1996)
commodities: coffee, manufactured goods, cotton,
cashew nuts, minerals, tobacco, sisal (1995)
partners: EU, Japan, India, US (1995)
Imports:
total value: $1 .4 billion (c.i.f., 1 996)
commodities: consumer goods, machinery and
transportation equipment, crude oil
partners: EU, Kenya, Japan, China, India (1995)
Debt— external: $7.9 billion (1997 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Tanzanian shilling (TSh) = 100 cents
Exchange rates: Tanzanian shillings (TSh) per
US$1— 631.61 (January 1998), 612.12 (1997),
579.98 (1996), 574.76 (1995), 509.63 (1994), 405.27
(1993)
Fiscal year: 1 July— 30 June
Telephones: 137,000 (1989 est.)
Telephone system: fair system operating below
capacity
domestic: open wire, microwave radio relay,
tropospheric scatter
international: satellite earth stations— 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations: AM 12, FM 4,
shortwave 0
Radios: 720,000 (1993 est.)
Television broadcast stations: 3 (1995 est.);
note— all on Zanzibar
Televisions: 55,000 (1993 est.)','0fc4ae10868f5e44892ab830db819b51c5c83fd70b9bb4539c6cc68e5bbffb8b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a22166a1d60effd631ca247cd6847b20b312224e1404e0a4853b63c8b78028ba',1998,'TK','Tokelau','economy',889,'Economy— overview: Tokelau''s small size,
isolation, and lack of resources greatly restrain
economic development and confine agriculture to the
subsistence level. The people must rely on aid from
New Zealand to maintain public services, annual aid
being substantially greater than GDP. The principal
sources of revenue come from sales of copra, postage
stamps, souvenir coins, and handicrafts. Money is
also remitted to families from relatives in New
Zealand.
GDP: purchasing power parity— $1 .5 million (1 993
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity— $1 ,000
(1993 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force: NA
Unemployment rate: NA%
Budget:
revenues; $430,830
expenditures: $2.8 million, including capital
expenditures of $37,300 (1987 est.)
Industries: small-scale enterprises for copra
production, wood work, plaited craft goods; stamps,
coins; fishing
Industrial production growth rate: NA%
Electricity— capacity: NA kW
Electricity— production: NA kWh
Electricity— consumption per capita: NA kWh
Agriculture— products: coconuts, copra, breadfruit,
papaya, bananas; pigs, poultry, goats
Exports:
total value: $98,000 (f.o.b., 1983)
commodities: stamps, copra, handicrafts
partners: HZ
Imports:
total value: $ 323,400 (c.i.f., 1983)
commodities: foodstuffs, building materials, fuel
partners : NZ
Debt— external: $0
Economic aid:
recipient: ODA, $3.7 million from NZ (FY95/96)
Currency: 1 New Zealand dollar (NZ$) = 100 cents
Exchange rates: New Zealand dollars (NZ$) per
US$1 -1.7283 (January 1998), 1.5083 (1997),
1.4543 (1996), 1.5235 (1995), 1.6844 (1994), 1.8495
(1993)
Fiscal year: 1 April— 31 March','04fa01e503eb1f8678a89020cf7a70e4c64f389967740c1784bc5f7b7f0c1b44','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d41357a555a5e29d106bb17894ed7b447ebca2c32e41708249e4d46b9ad369a1',1998,'AE','United Arab Emirates','economy',905,'Economy— overview: The UAE has an open
economy with one of the world''s highest per capita
incomes and with a sizable annual trade surplus. Its
wealth is based on oil and gas output (about 33% of
GDP), and the fortunes of the economy fluctuate with
the prices of those commodities. Since 1 973, the UAE
has undergone a profound transformation from an
impoverished region of small desert principalities to a
modern state with a high standard of living. At present
levels of production, oil and gas reserves should last
for over 1 00 years. The UAE Government is
encouraging increased privatization within the
economy, and industrial development is expected to
pick up in 1997-98.
GDP: purchasing power parity— $54.2 billion (1997
est.)
GDP— real growth rate: 5% (1997 est.)
GDP— per capita: purchasing power parity —
$24,000 (1997 est.)
GDP— composition by sector:
agriculture: 3%
industry: 55%
services: 42% (1996 est.)
Inflation rate— consumer price index: 3.6% (1997
est.)
Labor force:
total: 1.05 million (1996 est.)
by occupation: services 65%, industry and commerce
30%, agriculture 5% (1996 est.)
note: 75% of the population in the 15-64 age group is
non-national (July 1998 est.)
Unemployment rate: NA%
Budget:
revenues: $5.1 billion
expenditures: $5.4 billion, including capital
expenditures of $294 million (1997 est.)
Industries: petroleum, fishing, petrochemicals,
construction materials, some boat building,
handicrafts, pearling
Industrial production growth rate: 6.1% (1995
est.)
Electricity— capacity: 5.29 million kW (1995)
Electricity— production: 1 8 billion kWh (1 995)
Electricity— consumption per capita: 6,155 kWh
(1995)
Agriculture— products: dates, vegetables,
watermelons; poultry, eggs, dairy products; fish
Exports:
total value: $ 33.2 billion (f.o.b., 1996 est.)
commodities: crude oil 66%, natural gas, reexports,
dried fish, dates
partners: Japan 38%, South Korea 7%, Singapore
7%, India 6%, Oman 4%, Iran 3% (1996)
Imports:
total value: $23.5 billion (f.o.b., 1996 est.)
commodities: manufactured goods, machinery and
transport equipment, chemicals, food
partners: US 1 0%, Japan 9%, UK 8%, Italy 6%, South
Korea 6%, India 6% (1996)
Debt— external: $14 billion (1996 est.)
Economic aid: $NA
Currency: 1 Emirian dirham (Dh) = 100 fils
Exchange rates: Emirian dirhams (Dh) per US$1 —
3.671 0 (fixed rate)
Fiscal year: calendar year','bd07ed2fc44cc1172e9e7100fbe4c6da50cf15f4d679d556031d11a5f556e8ac','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a96fa6d63c3141241501f94245d77ac199bb3146446c970a32af5ef4786ebae',1998,'UY','Uruguay','economy',913,'Economy— overview: Uruguay''s small economy
benefits from a favorable climate for agriculture and
substantial hydropower potential. Economic
development has been restrained in recent years by
high— though declining— inflation and extensive
government regulation. The SANGUINETTI
494
government''s conservative monetary and fiscal policies
are aimed at continuing to reduce inflation; other
priorities include extensive reform of the social security
system and increased investment in education.
Economic performance remains sensitive to conditions
in Argentina and Brazil, largely because more than half
of Uruguay''s trade is conducted with its partners in
Mercosur (the Southern Cone Common Market).
GDP: purchasing power parity— $29.1 billion (1 997 est.)
GDP— real growth rate: 5.1% (1997)
GDP— per capita: purchasing power parity— $8,900
(1997 est.)
GDP— composition by sector:
agriculture: 10.8%
industry: 27 .4%
services: 61 .8% (1995)
Inflation rate— consumer price index: 1 5.2% (1 997)
Labor force:
total: 1.38 million (1997 est.)
by occupation: government 25%, manufacturing 19%,
agriculture 11%, commerce 12%, utilities,
construction, transport, and communications 12%,
other services 21% (1988 est.)
Unemployment rate: 10.3% (December 1997)
Budget:
revenues: $4 billion
expenditures: $4.3 billion, with capital expenditures of
$385 million (1997 est.)
Industries: meat processing, wool and hides, sugar,
textiles, footwear, leather apparel, tires, cement,
petroleum refining, wine
Industrial production growth rate: 5.6% (1997)
Electricity— capacity: 2.055 million kW (1995)
Electricity— production: 7.6 billion kWh (1995)
Electricity— consumption per capita: 1 ,852 kWh
(1995)
Agriculture— products: wheat, rice, corn, sorghum;
livestock; fishing
Exports:
total value: $2.7 billion (f.o.b., 1997)
commodities: wool and textile manufactures, beef and
other animal products, rice, fish and shellfish,
chemicals
partners: Brazil, Argentina, US, Germany, Italy
Imports:
total value: $3.7 billion (c.i.f., 1997)
commodities : machinery and equipment, vehicles,
chemicals, minerals, plastics, oil
partners: Brazil, Argentina, US, Italy, Germany
Debt— external: $4.6 billion (1996 est.)
Economic aid:
recipient: ODA, $63 million (1994)
Currency: 1 Uruguayan peso ($Ur) = 100
centesimos
Exchange rates: Uruguayan pesos ($Ur) per
US$1 -9.98 (January 1998), 9.4448 (1997), 7.9718
(1996), 6.3491 (1995), 5.0529 (1994), 3.9484 (1993)
Fiscal year: calendar year','80db836f1222c91c75e6eb3d39a64281b76b73bfa771762f25564744e396a6e9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('939fb4b3ea424f493683e32b9f1e5e8d2f72ae954a48e0db15f9c02706db1820',1998,'UZ','Uzbekistan','economy',922,'Economy— overview: Uzbekistan is a dry,
landlocked country of which 1 0% consists of intensely
cultivated, irrigated river valleys. It was one of the
poorest areas of the former Soviet Union with more
than 60% of its population living in densely populated
rural communities. Uzbekistan is now the world''s third
largest cotton exporter, a major producer of gold and
natural gas, and a regionally significant producer of
chemicals and machinery. Following independence in
December 1 991 , the government sought to prop up its
Soviet-style command economy with subsidies and
tight controls on production and prices. Faced with
high rates of inflation, however, the government
began to reform in mid-1994, by introducing tighter
monetary policies, expanding privatization, slightly
reducing the role of the state in the economy, and
improving the environment for foreign investors.
Nevertheless, the state continues to be a dominating
influence in the economy, and reforms have so far
failed to bring about much-needed structural changes.
The IMF suspended Uzbekistan''s $185 million
standby arrangement in late 1996 because of
governmental steps that made impossible fulfillment
of Fund conditions.
GDP: purchasing power parity— $60.7 billion (1997
est.)
GDP— real growth rate: 2.4% (1997 est.)
GDP— per capita: purchasing power parity— $2,500
(1997 est.)
GDP— composition by sector:
agriculture: 26%
industry: 27%
services: 47% (1996 est.)
Inflation rate— consumer price index: 55% (1996
est.)
Labor force:
fote/;8.6 million (1996 est.)
by occupation: agriculture and forestry 44%, industry
and construction 20%, other 36% (1995)
Unemployment rate: 5% plus another 10%
underemployed (December 1996 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: textiles, food processing, machine
building, metallurgy, natural gas
Industrial production growth rate: 6% (1996)
Electricity— capacity: 11.822 million kW (1995)
Electricity— production: 45.42 billion kWh (1996
est.)
Electricity— consumption per capita: 1 ,91 6 kWh
(1996 est)
Agriculture— products: cotton, vegetables, fruits,
grain; livestock
Exports:
total value: $ 3.8 billion (1996)
commodities: cotton, gold, natural gas, mineral
fertilizers, ferrous metals, textiles, food products,
autos
partners: Russia, Ukraine, Eastern Europe, Western
Europe
Imports:
total value: $4.7 billion (1996)
commodities: grain, machinery and parts, consumer
durables, other foods
partners: principally other FSU, Czech Republic,
Western Europe
Debt— external: $2.3 billion (of which $51 0 million to
Russia) (1996 est.)
Economic aid:
recipient: ODA, $71 million (1993)
note: commitments, $2,915 million ($135 million in
disbursements) (1992-95)
Currency: introduced provisional som-coupons 10
November 1993 which circulated parallel to the
Russian rubles; became the sole legal currency 31
January 1994; was replaced in July 1994 by the som
currency
Exchange rates: Uzbekistani soms (UKS) per
US$1 -75.8 (September 1997), 41.1 (1996), 30.2
(1995), 11.4(1994), 1.0 (1993)
Fiscal year: calendar year','de68342833bbc221e472cb180507bf37c693e7cd21af834c4e30fcbbb07de5d5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b28e5bc0500cc2d8d9c67ac39627070e25cbd9d5843b8c3ab7048352d46b83f3',1998,'VU','Vanuatu','economy',928,'Economy— overview: The economy is based
primarily on subsistence or small-scale agriculture
which provides a living for 65% of the population.
Fishing, offshore financial services, and tourism, with
46,000 visitors in 1 996, are other mainstays of the
economy. Mineral deposits are negligible; the country
has no known petroleum deposits. A small light
industry sector caters to the local market. Tax
revenues come mainly from import duties. Economic
development is hindered by dependence on relatively
few commodity exports, vulnerability to natural
disasters, and long distances from main markets and
between constituent islands.
GDP: purchasing power parity— $231 million (1996
est.)
GDP— real growth rate: 3% (1996 est.)
GDP— per capita: purchasing power parity— $1 ,300
(1996 est.)
GDP— composition by sector:
agriculture: 23%
industry: ]3%
services: 64% (1996)
Inflation rate— consumer price index: 2.2% (1997
est.)
Labor force:
total: NA
by occupation: agriculture 65%, services 32%,
industry 3% (1995 est.)
Unemployment rate: NA%
Budget:
revenues: $94.4 million
expenditures: $99.8 million, including capita!
expenditures of $30.4 million (1996 est.)
Industries: food and fish freezing, wood processing,
meat canning
Industrial production growth rate: 6.4% (1996
est.)
Electricity— capacity: 1 1 ,000 kW (1 995)
Electricity— production: 30 million kWh (1995)
Electricity— consumption per capita: 173 kWh
(1995)
Agriculture— products: copra, coconuts, cocoa,
coffee, taro, yams, coconuts, fruits, vegetables; fish,
beef
Exports:
total value: $ 30 million (f.o.b., 1996)
commodities : copra, beef, cocoa, timber, coffee
partners: Japan 28%, Spain 21%, Germany 14%, UK
7%, Cote d''Ivoire 7%, Australia, New Caledonia (1996
est.)
Imports:
total value: $ 97 million (f.o.b., 1996)
commodities : machines and vehicles, food and
beverages, basic manufactures, raw materials and
fuels, chemicals
partners: Japan 47%, Australia 23%, Singapore 8%,
New Zealand 6%, France 3%, Fiji (1996 est.)
Debt— external: $63 million (1996 est.)
Economic aid:
recipient: ODA, $9.6 million from Australia (FY96/97
est.); $3.1 million from NZ (FY95/96)
Currency: 1 vatu (VT) = 100 centimes
Exchange rates: vatu (VT) per US$1— 124.56
(January 1 998), 1 1 5.87 (1 997), 1 1 1 .72 (1 996), 112.11
(1995), 116.41 (1994), 121 .58 (1993)
Fiscal year: calendar year
Economy— overview: The petroleum sector
dominates the economy, accounting for 27% of GDP,
78% of export earnings, and more than half of
government operating revenues. It is likely to become
even more important as the state petroleum company
plans to double its production over the next 10 years.
Realizing the failure of interventionist policies, the
CALDERA administration embarked on a
comprehensive economic reform program, which
included negotiation of a stand-by agreement with the
IMF in 1996, elimination of price and exchange
controls, and revitalization of Venezuela''s stalled
privatization program. The influx of foreign capital,
and the currency depreciation that followed exchange
liberalization, led to 1 03% inflation in 1 996, the highest
in Venezuelan history. The government stepped in
toward the end of 1996, propping up the Bolivar by
using a stable nominal exchange rate as a restraint on
inflation— which fell in 1997 to 38%. The
macroeconomic adjustments, bolstered by strong oil
prices, resulted in strong growth in 1997. However,
the East Asian financial crisis and the decline of
international oil prices toward the end of 1 997 brought
pressure on the currency, which Caracas was able to
stave off. Caracas readjusted its exchange rate bands
and began to allow quicker depreciation of the Bolivar;
the government also tightened monetary policy.
Concerned over potential revenue shortfalls from soft
oil prices for the 1998 budget, Caracas has
implemented budget cuts to compensate for
previously optimistic oil revenue estimates. The
government also has pushed ahead with sale of the
state-owned steel company and the strategic
aluminum sector, thereby reassuring domestic and
international investors of Venezuela''s commitment to
reform. The monetary and fiscal measures have been
well received by the international financial community.
As a result, financial analysts believe the economy will
still grow at a healthy pace in 1 998, though they have
lowered their initial projections for GDP growth due to
the soft oil market.
GDP: purchasing power parity— $185 billion (1997
est.)
GDP— real growth rate: 5% (1997)
GDP— per capita: purchasing power parity— $8,300
(1997 est.)
GDP— composition by sector:
agriculture: 4%
industry: 63%
services: 33% (1997 est.)
Inflation rate— consumer price index: 38% (1997)
Labor force:
total: 9.2 million
by occupation: services 64%, industry 23%,
agriculture 13% (1997 est.)
Unemployment rate: 1 1 .5% (1 997 est.)
Budget:
revenues: $11.99 billion
expenditures: $1 1 .48 billion, including capital
expenditures of $3 billion (1996 est.)
501
Venezuela (continued)
Industries: petroleum, iron ore mining, construction
materials, food processing, textiles, steel, aluminum,
motor vehicle assembly
Industrial production growth rate: 0.5% (1995
est.)
Electricity — capacity: 18.975 million kW (1995)
Electricity— production: 74 billion kWh (1995)
Electricity— consumption per capita: 3,508 kWh
(1995)
Agriculture— products: corn, sorghum, sugarcane,
rice, bananas, vegetables, coffee; beef, pork, milk,
eggs; fish
Exports:
total value: $ 20.8 billion (f.o.b., 1996)
commodities: petroleum 78%, bauxite and aluminum,
steel, chemicals, agricultural products, basic
manufactures
partners : US and Puerto Rico 55%, Japan,
Netherlands, Italy
Imports:
total value: $10.5 billion (f.o.b., 1996)
commodities: raw materials, machinery and
equipment, transport equipment, construction
materials
partners: US 40%, Germany, Japan, Netherlands,','e6b5b550f08a0cc0632b8cb3e40531b5191de18d808c5e10860ff25f4f63669e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d00db9aec80ff9c2509519cd8a25cd16331d53ceb0a8db7123f259746b15611',1998,'PR','Puerto Rico','economy',936,'Economy— overview: Tourism is the primary
economic activity, accounting for more than 70% of
GDP and 70% of employment. The islands normally
host 2 million visitors a year. The number of US
tourists in the first five months of 1996 was down by
55% from the same period in 1 995, the lingering result
of the fierce hurricanes of 1995. Unemployment rose
sharply in 1996. The manufacturing sector consists of
textile, electronics, pharmaceutical, and watch
assembly plants. The agricultural sector is small, most
food being imported. International business and
financial services are a small but growing component
of the economy. One of the world''s largest petroleum
refineries is at Saint Croix. A major economic problem
at the beginning of 1 997 was the more than $1 billion
in governmental arrears, in income tax refunds,
payments to vendors, and overdue wages.
GDP: purchasing power parity— $1 .2 billion (1 987
est.)
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity —
$12,500 (1987 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: NA%
Labor force:
total: 47,443 (1990 est.)
by occupation: agriculture 1 %, industry 20%, services
62%, other 17% (1990)
Unemployment rate: 6.2% (March 1994)
Budget:
revenues: $364.4 million
expenditures: $364.4 million, including capital
expenditures of $NA (1 990 est.)
Industries: tourism, petroleum refining, watch
assembly, rum distilling, construction,
pharmaceuticals, textiles, electronics
Industrial production growth rate: NA%
Electricity— capacity: 316 million kW (1995)
Electricity— production: 1 billion kWh (1995)
Electricity— consumption per capita: 10,285 kWh
(1995)
Agriculture— products: truck garden products, fruit,
vegetables, sorghum; Senepol cattle
Exports:
total value: $1 .8 billion (f.o.b., 1992)
commodities: refined petroleum products
partners : US, Puerto Rico
Imports:
total value: $2.2 billion (c.i.f., 1992)
commodities: crude oil, foodstuffs, consumer goods,
building materials
partners: US, Puerto Rico
Debt— external: $NA
Economic aid: $NA
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October— 30 September','889e33eb102001030bc570a9f1f594d22cb338223071d9c4dff131a27718c9be','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e04f6a559bd7de39413d65bb0e6adab081f9a3f680b40ef05e29aebe89ede366',1998,'EH','Western Sahara','economy',944,'Economy— overview: Western Sahara, a territory
poor in natural resources and lacking sufficient
rainfall, depends on pastoral nomadism, fishing, and
phosphate mining as the principal sources of income
for the population. Most of the food for the urban
population must be imported. All trade and other
economic activities are controlled by the Moroccan
Government. Incomes and standards of living are
substantially below the Moroccan level.
GDP: purchasing power parity — $NA
GDP— real growth rate: NA%
GDP— per capita: purchasing power parity — $NA
GDP— composition by sector:
agriculture: NA%
industry : NA%
services: 40%-45% (1996 est.)
Inflation rate— consumer price index: NA%
Labor force:
total: 12,000
by occupation: animal husbandry and subsistence
farming 50%
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: phosphate mining, handicrafts
Industrial production growth rate: NA%
Electricity— capacity: 56,000 kW (1995)
Electricity— production: 85 million kWh (1995)
Electricity— consumption per capita: 391 kWh
(1995)
Agriculture— products: fruits and vegetables
(grown in the few oases); camels, sheep, goats (kept
by the nomads)
Exports: $NA
commodities: phosphates 62%
partners: Morocco claims and administers Western
Sahara, so trade partners are included in overall
Moroccan accounts
Imports: $NA
commodities: fuel for fishing fleet, foodstuffs
partners: Morocco claims and administers Western
Sahara, so trade partners are included in overall
Moroccan accounts
Debt— external: $NA
Economic aid:
recipient: ODA, $NA
Currency: 1 Moroccan dirham (DH) = 100 centimes
Exchange rates: Moroccan dirhams (DH) per
US$1— 9.822 (January 1998), 9.527 (1997), 8.716
(1996), 8.540 (1995), 9.203 (1994), 9.299 (1993)
Fiscal year: calendar year
Economy— overview: Real global output— gross
world product (GWP) — rose an estimated 4.0% in
1997. And, once more, results varied widely among
regions and countries. With its solid 3.8% growth, the
US again accounted for 21% of GWP in 1997.
Western Europe grew at 2.5%, not enough to cut into
its high unemployment, and accounted for another
21 % of GWP. Japan''s faltering economy grew at only
0.9% with its share of GWP at 8%. The advanced
countries as a whole accounted for an estimated 53%
of GWP, with overall growth at 3.0%. The 15 former
Soviet republics and the countries of Eastern Europe
posted growth of 1.8%, reversing the long downturn
that followed the collapse of communism. Growth
varied widely among these countries, e.g., Ukraine at
a negative 3.2%, Russia at a positive 0.4%, and the
Baltic countries at a strong 7%. The area as a whole
accounted for 5% of global output. China and India,
with a combined population of 2.2 billion or 37% of the
world total, grew at 8.8% and 5%, respectively.
(China''s official GDP statistics probably are
overstated.) The developing countries as a whole
contributed 42% to GWP with an overall growth rate of
5.7%. Externally, the nation-state, as a bedrock
economic-political institution, is steadily losing control
over international flows of people, goods, funds, and
technology. Internally, the central government in a
number of cases is losing control over resources as
separatist regional movements— typically based on
ethnicity— gain momentum, e.g., in the successor
states of the former Soviet Union, in the former
Yugoslavia, in India, and in Canada. In Western
513
World (continued)
Europe, governments face the difficult political
problem of channeling resources away from welfare
programs in order to increase investment and
strengthen incentives to seek employment. The
addition of more than 80 million people each year to
an already overcrowded globe is exacerbating the
problems of pollution, desertification,
underemployment, epidemics, and famine. Because
of their own internal problems, the industrialized
countries have inadequate resources to deal
effectively with the poorer areas of the world, which, at
least from the economic point of view, are becoming
further marginalized. Toward the end of 1997 and on
into 1998, serious financial difficulties in several
high-growth East Asia countries cast a shadow over
short-term global economic prospects. The
introduction of the euro as the common currency of
much of Western Europe in January 1999 will pose
serious economic risks because of varying levels of
income and cultural and political differences among
the participating nations. (For specific economic
developments in each country of the world in 1997,
see the individual country entries.)
GDP: GWP (gross world product)— purchasing
power parity— $38 trillion (1997 est.)
GDP— real growth rate: 4% (1997 est.)
GDP— per capita: purchasing power parity— $6,500
(1997 est.)
GDP— composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Inflation rate— consumer price index: all countries
25%; developed countries 2% to 4% typically;
developing countries 1 0% to 60% typically (1 997 est.)
note: national inflation rates vary widely in individual
cases, from stable prices in Japan to hyperinflation in
a number of Third World countries
Labor force:
total: 2.24 billion (1992)
by occupation: NA
Unemployment rate: 30% combined
unemployment and underemployment in many
non-industrialized countries; developed countries
typically 5%-12% unemployment (1997 est.)
Industries: dominated by the onrush of technology,
especially in computers, robotics,
telecommunications, and medicines and medical
equipment; most of these advances take place in
OECD nations; only a small portion of non-OECD
countries have succeeded in rapidly adjusting to these
technological forces; the accelerated development of
new industrial (and agricultural) technology is
complicating already grim environmental problems
Industrial production growth rate: 5% (1997 est.)
Electricity— capacity: 4 billion kW (1994)
Electricity— production: 12.34268 trillion kWh
(1994)
Electricity— consumption per capita: 1 ,996 kWh
(1995 est.)
Agriculture— products: the whole gamut of crops,
livestock, forest products, and fish
Exports:
total value: $5 trillion (f.o.b., 1997 est.)
commodities: the whole range of industrial and
agricultural goods and services
partners: in value, about 75% of exports from the
developed countries
Imports:
total value: $5.1 trillion (c.i.f., 1997 est.)
commodities : the whole range of industrial and
agricultural goods and services
partners: in value, about 75% of imports by the
developed countries
Debt— external: $2 trillion for less developed
countries (1997 est.)
Economic aid: worldwide traditional foreign aid $50
billion (1995 est.)','ee7b9c2a9dbe8483a9b4545e0368b108df091f005d164415427c316e03e9d770','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1dc46c9b4d9e8efe1e58076726e39444dbdb7c1b2074a5d4537140c818f5756',1998,'YE','Yemen','economy',952,'Economy — overview: The northern city Sanaa is
the political capital of a united Yemen, and the
southern city Aden, with its refinery and port facilities,
is the economic and commercial capital. Future
economic development depends heavily on the
attraction of foreign investment to diversify the
economy. Former South Yemen''s willingness to
merge stemmed partly from the sharp decline in
Soviet economic support. The low level of domestic
industry and agriculture has made northern Yemen
dependent on imports for practically all of its essential
needs. Once self-sufficient in food production,
northern Yemen has become a major importer. Land
once used for export crops— cotton, fruit, and
vegetables— has been turned over to growing a shrub
called qat, whose leaves are chewed for their
stimulant effect by Yemenis and which has no
significant export market. Economic growth in former
South Yemen has been constrained by a lack of
incentives, partly stemming from centralized control
over production decisions, investment allocation, and
import choices. Yemen''s GDP has been
supplemented by remittances from Yemenis working
abroad and by foreign aid. Since the Gulf crisis,
however, remittances have dropped substantially.
Floods in June 1 996 caused the loss of much valuable
topsoil in the agricultural sector, increasing the need
for imports of foodstuffs. Oil production and GDP as a
whole are expected to increase moderately in 1998.
GDP: purchasing power parity— $31.8 billion (1997
est.)
GDP— real growth rate: 5% (1997 est.)
GDP— per capita: purchasing power parity— $2,300
(1997 est.)
GDP— composition by sector:
agriculture: 1 5%
industry: 39%
services: 46% (1995)
Inflation rate— consumer price index: 5% (1997
est.)
Labor force: no reliable estimates exist, most
people are employed in agriculture and herding or as
expatriate laborers; services, construction, industry,
and commerce account for less than one-half of the
labor force
Unemployment rate: 30% (1995 est.)
Budget:
revenues; $2.6 billion
expenditures: $2.7 billion, including capital
expenditures of $1 .1 billion (1 998 est.)
Industries: crude oil production and petroleum
refining; small-scale production of cotton textiles and
leather goods; food processing; handicrafts; small
aluminum products factory; cement
Industrial production growth rate: NA%
Electricity— capacity: 810,000 kW (1995)
Electricity— production: 1.85 billion kWh (1995)
Electricity— consumption per capita: 126 kWh
(1995)
Agriculture— products: grain, fruits, vegetables,
qat (mildly narcotic shrub), coffee, cotton; dairy
products, poultry, meat; fish
Exports:
total value : $2.3 billion (f.o.b., 1997 est.)
commodities: crude oil, cotton, coffee, dried and
salted fish
partners: China 23%, South Korea 19%, Thailand
14%, Brazil 13%, Japan 12%, Thailand 7% (1995)
Imports:
total value: $2.3 billion (f.o.b., 1997 est.)
commodities: textiles and other manufactured
consumer goods, petroleum products, foodstuffs,
cement, machinery, chemicals
partners: US 12%, France 11%, UAE 10%, Saudi
Arabia 7%, UK 5% (1995)
Debt— external: $8 billion (1996)
Economic aid:
recipient: ODA, $148 million (1993)
Currency: Yemeni rial (YRI) (new currency)
Exchange rates: Yemeni rials (YRI) per US$1 —
129.158 (1 997), 94.1 57 (1 996), 40.839 (1 995), 1 2.01 0
(official fixed rate 1991-94)
Fiscal year: calendar year','cb4c7f7ef013bf319cc84ae569494b89010e9a4262a5f8d0cfed1d535c4e724b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71b97bd4bf691ecad7c7a9a49ac4756408c6577ab67e36616ae59fa5ea09be57',1998,'ZM','Zambia','economy',960,'Economy— overview: Despite progress in
privatization and budgetary reform, Zambia''s
economy has a long way to go. Inflation, while slowing
somewhat, continues to be a major concern to the
CHILUBA government. Zambia''s copper mining
sector, which accounts for over 80% of the nation''s
foreign currency intake, is struggling. Production rates
are down as are world copper prices. Aid cuts by
Zambia''s donors, arising out of concern for the
November 1 996 flawed election, will severely damage
Zambia''s economic prospects. Urged by the World
Bank, Zambia has embarked on a privatization
program which is to include the all-important copper
industry.
GDP: purchasing power parity— $8.8 billion (1997
est.)
GDP— real growth rate: 3.5% (1997 est.)
GDP— per capita: purchasing power parity— $950
(1997 est.)
GDP— composition by sector:
agriculture: 23%
industry: 40%
services: 37% (1997 est.)
Inflation rate— consumer price index: 43.9%
(1996)
Labor force:
total: 3.4 million
by occupation: agriculture 85%, mining,
manufacturing, and construction 6%, transport and
services 9%
Unemployment rate: 22% (1991)
Budget:
revenues: $888 million
expenditures: $835 million, including capital
expenditures of $1 10 million (1995 est.)
Industries: copper mining and processing,
construction, foodstuffs, beverages, chemicals,
textiles, fertilizer
Industrial production growth rate: 3.5% (1996)
Electricity— capacity: 2.436 million kW (1995)
Electricity— production: 7.79 billion kWh (1995)
Electricity— consumption per capita: 668 kWh
(1995)
Agriculture— products: corn, sorghum, rice,
peanuts, sunflower seed, tobacco, cotton, sugarcane,
cassava (tapioca); cattle, goats, pigs, poultry, beef,
pork, poultry meat, milk, eggs, hides
Exports:
total value: $975 million (f.o.b., 1996 est.)
commodities: copper, zinc, cobalt, lead, tobacco
partners : EU countries, Japan, South Africa, US,
Saudi Arabia, India, Thailand, Malaysia
Imports:
total value: $990 million (f.o.b., 1996 est.)
commodities: machinery, transportation equipment,
foodstuffs, fuels, petroleum products, electricity,
miscellaneous manufactured goods
partners: South Africa, EU countries, Japan, Saudi
Arabia, US
Debt— external: $7.2 billion (1996 est.)
Economic aid:
recipient: ODA, $2 billion (1995 est.)
Currency: 1 Zambian kwacha (ZK) = 100 ngwee
Exchange rates: Zambian kwacha (ZK) per US$1—
1,351. ,35 (October 1997), 1,203.71 (1996), 857.23
(1995), 669.37 (1994), 452.76 (1993)
Fiscal year: calendar year
Economy— overview: Agriculture employs 27% of
the labor force of this landlocked nation and supplies
almost 25% of exports. Mining accounts for only 5% of
both GDP and employment, but minerals and metals
account for about 20% of exports. The government is
working to consolidate earlier progress in developing
a market-oriented economy. Although the IMF
suspended support for Zimbabwe''s economic
structural adjustment program (ESAP) in 1 995, due to
government failure to meet key targets, recent talks
between the government and the Fund have held
promise for possible renewed support if Zimbabwe
remains committed to budgetary targets. A key
element of the budget is the Zimbabwe Program for
Socio-Economic Transformation (ZIMPREST), the
second phase of ESAP, whose goals include
increased commercialization and privatization of
government-owned enterprises and more
"outward-looking" trade and investment policies. The
World Bank resumed balance of payments support to
Zimbabwe in early 1998. Government officials face
the difficult task of restraining expenditures in their
effort to keep inflation within bounds.
GDP: purchasing power parity— $24.9 billion (1996
est.)
GDP— real growth rate: 8.1% (1996 est.)
GDP— per capita: purchasing power parity— $2,200
(1996 est.)
GDP— composition by sector:
agriculture: 18.3%
industry: 35.3%
services: 46.4% (1993 est.)
Inflation rate— consumer price index: 21 .4%
(1996)
Labor force:
total: 4.228 million (1993 est.)
by occupation: agriculture 27%, transport and
services 46%, industry 27%
Unemployment rate: at least 45% (1 994 est.)
Budget:
revenues: $2.5 billion
expenditures: $2.9 billion, including capital
expenditures of $279 million (FY96/97 est.)
Industries: mining (coal, clay, numerous metallic
and nonmetallic ores), copper, steel, nickel, tin, wood
products, cement, chemicals, fertilizer, clothing and
footwear, foodstuffs, beverages
Industrial production growth rate: 10% (1994)
Electricity— capacity: 2.148 million kW (1995)
Electricity— production: 7.1 billion kWh (1995)
Electricity— consumption per capita: 792 kWh
(1995)
Agriculture— products: corn, cotton, tobacco,
wheat, coffee, sugarcane, peanuts; cattle, sheep,
goats, pigs
Exports:
total value: $ 2.5 billion (f.o.b., 1996 est.)
commodities: agricultural 38% (tobacco 28%),
manufactures 34%, gold 12%, textiles 4%,
ferrochrome 7% (1996 est.)
partners: South Africa 12%, UK 12%, Germany 6%,
Japan 6% (1996 est.)
Imports:
total value: $22 billion (f.o.b., 1996 est.)
commodities: machinery and transportation
equipment 41%, other manufactures 24%, chemicals
13%, fuels 10% (1996 est.)
partners: South Africa 38%, UK 9%, US 5%, Japan
5% (1996 est.)
Debt— external: $4.8 billion (1996)
Economic aid:
recipient: ODA, $362 million (1993)
Currency: 1 Zimbabwean dollar (Z$) = 100 cents
Exchange rates: Zimbabwean dollars (Z$) per
US$1 -18.7970 (January 1998), 11.8906 (1997),
9.9206 (1996), 8.6580 (1995), 8.1500 (1994), 6.4725
(1993)
Fiscal year: 1 July— 30 June','56fa723d4e024c63f3b8dfab255041373b4bd5814b5e6639b9e9152c31e22f3a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

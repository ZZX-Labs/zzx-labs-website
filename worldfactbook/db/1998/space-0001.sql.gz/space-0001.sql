SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93ee85f548dab633b0ce35c8b2838eeff116f022afa0816afde147ef2173402e',1998,'ZW','Zimbabwe','space',974,'100
tons, gross register
cubic meters of permanently
enclosed space
2.831 684 7
tons, long (deadweight)
avoirdupois ounces
35,840
tons, long (deadweight)
avoirdupois pounds
2,240
tons, long (deadweight)
kilograms
1,016.046 909 8
tons, long (deadweight)
long hundredweights
20
tons, long (deadweight)
metric tons
1.016 046 908 8
tons, long (deadweight)
short hundredweights
22.4
tons, long (deadweight)
short tons
1.12
tons, metric
avoirdupois pounds
2,204.623
tons, metric
kilograms
1,000
tons, metric
long hundredweights
19.684 130 3
tons, metric
long tons
0.984 206 5
tons, metric
quintals
10
tons, metric
short hundredweights
22.046 23
tons, metric
short tons
1.102 311 3
tons, metric
troy ounces
32,150.75
tons, net register
cubic feet of permanently enclosed
space for cargo and passengers
100
tons, net register
cubic meters of permanently enclosed
space for cargo and passengers
2.831 684 7
tons, shipping
cubic feet of permanently enclosed
cargo space
42
599
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply by
tons, shipping
cubic meters of permanently
enclosed cargo space
1.189 307 574
tons, short
avoirdupois pounds
2,000
tons, short
kilograms
907.184 74
tons, short
long hundredweights
17.85714
tons, short
long tons
0.892 857 1
tons, short
metric tons
0.907 184 74
tons, short
short hundredweights
20
townships (US)
sections
36
townships (US)
square kilometers
93.239 572
townships (US)
square statute miles
36
miles, square statute
acres
640
miles, square statute
hectares
258.998 811 033 6
miles, square statute
square feet
27,878,400
miles, square statute
square meters
2,589,988.110 336
miles, square statute
square yards
3,097,600
yards
centimeters
91.44
yards
feet
3
yards
inches
36
yards
meters
0.914 4
yards
miles
0.000 568 18
yards, cubic
bushels
21.696 227
yards, cubic
cubic feet
27
yards, cubic
cubic inches
46,656
yards, cubic
cubic meters
0.764 554 857 984
yards, cubic
gallons
201.974 0
yards, cubic
liters
764.554 857 984
yards, cubic
pecks
86.784 91
yards, square
acres
0.000 206 611 6
yards, square
hectares
0.000 083 612 736
yards, square
square centimeters
8,361.273 6
yards, square
square feet
9
yards, square
square inches
1,296
yards, square
square meters
0.836127 36
yards, square
square miles
0.000 000 322 830 6
Note: At this time, only three countries— Burma, Liberia, and the US— have not adopted the International System of Units
(SI, or metric system) as their official system of weights and measures. Although use of the metric system has been
sanctioned by law in the US since 1866, it has been slow in displacing the American adaptation of the British Imperial
System known as the US Customary System. The US is the only industrialized nation that does not mainly use the metric
system in its commercial and standards activities, but there is increasing acceptance in science, medicine, government, and
many sectors of industry.
600
Appendix F:
Cross-Reference List of Country Data Codes
FIPS 1 0-4- Countries, Dependencies, Areas of Special Sovereignty, and Their Principal Administrative Divisions (FIPS PUB 10-4) is
maintained by the Office of the Geographer and Global Issues (Department of State) and published by the National Institute
of Standards and Technology (Department of Commerce). These two-character alphabetic codes are included in the text of
the Factbook in the Data code entry under the Government category. FIPS 1 0-4 codes are intended for general use
throughout the US Government, especially in activities associated with the mission of the Department of State and national
defense programs.
ISO 3166: Codes for the Representation of Names of Countries (ISO 3166) is prepared by the International Organization for
Standardization. ISO 3166 includes two- and three-character alphabetic codes and three-digit numeric codes that may be
needed for activities involving exchange of data with international organizations that have adopted that standard. Except for
the numeric codes, ISO 31 66 codes have been adopted in the US as FIPS 104-1: American National Standard Codes for the
Representation of Names of Countries, Dependencies, and Areas of Special Sovereignty for Information Interchange.
Internet: This is a provisional compilation that generally agrees with the ISO 3166 two-character alphabetic codes.
Entity
FIPS 10-4
ISO 3166
Internet
Comment
Zl
ZW
ZWE
716
ZW
_ : _ _ — .1-1. U, , lU. 1 1 0 . tUn 1 IQ i limn Ia thot
•Serbia and Montenegro have asserted the formation of a joint independent state, but this entity has not been formally recognized as a state by the US; the US view is that
the Socialist Federal Republic of Yugoslavia (SFRY) has dissolved and that none of the successor republics represents its continuation.
608
Appendix G:
Cross-Reference List of Hydrographic Codes
1HO 23-4th:
Limits of Oceans and Seas , Special Publication 23, Draft 4th Edition 1 986, published by the International Hydrographic Bureau
of the International Hydrographic Organization
IHO 23-3rd:
Limits of Oceans and Seas, Special Publication 23, 3rd Edition 1953, published by the international Hydrographic Organization
ACIC M 49-1:
Chart of Limits of Seas and Oceans, revised January 1958, published by the Aeronautical Chart and Information Center
(ACIC), United States Air Force; note— ACIC is now part of the National Imagery and Mapping Agency (NIMA)
DIAM 65-18:
Geopolitical Data Elements and Related Features, Data Standard No. 4, Defense Intelligence Agency Manual 65-18,
December 1 994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes similar to the Federal information Processing
Standards (FIPS) 10-4 country codes. The names and limits of the following oceans and seas are not always directly
comparable because of differences in the customers, needs, and requirements of the individual organizations. Even the
number of principal water bodies varies from organization to organization. Factbook users, for example, find the Atlantic Ocean
and Pacific Ocean entries useful, but none of the following standards include those oceans in their entirety. Nor is there any
provision for combining codes or overcodes to aggregate water bodies.
Principal Oceans and Seas of the World With
Hydrographic Codes by Institution
IHO
IHO
ACIC
DIAM
23-4th
23-3rd*
M 49-1
65-18
Arctic Ocean
9
17
A
5A
Atlantic Ocean
—
—
—
—
North Atlantic Ocean
1
23
B
1A
South Atlantic Ocean
4
32
C
2A
Baltic Sea
2
1
B26
7B
Indian Ocean
5
45
F
6A
Mediterranean Sea
3.1
28
B11
—
Eastern Mediterranean
3.1.2
28 B
—
8E
Western Mediterranean
3.1.1
28 A
—
8W
Pacific Ocean
—
—
—
—
North Pacific Ocean
7
57
D
3A
South Pacific Ocean
8
61
E
4A
South China and Eastern Archipelagic Seas
6
49, 48
D18 plus others
3U plus others
Oceans and Seas of the World With
Hydrographic Codes by Institution
IHO
IHO
ACIC
DIAM
23-4th
23-3rd*
M 49-1
65-18
ARCTIC OCEAN
9
17
A
5A
East Siberian Sea
9.1
11
A6
5S
Laptev Sea
9.2
10
A5
5P
Kara Sea
9.3
9
A4
5K
Barents Sea
9.4
7
A2
5B
White Sea
9.5
8
A3
5W
609
Appendix G: Cross-Reference List of Hydrographic Codes (continued)
IHO
23-4th
IHO
23-23rd*
ACIC
M 49-1
DIAM
65-18
North Greenland Sea
9.6
—
—
—
Norwegian Sea
97
6
B30
5N
Iceland Sea
9.8
—
—
—
Davis Strait
9.9
15
B2
IV
Hudson Strait
9.10
16 A
A15
1U
Hudson Bay
9.11
16
A10
1H
Baffin Bay
9.12
14 A
A12
IP
Lincoln Sea
9.13
17 A
A13
5L
Northwest Passages (Northwest Passage,
Northwestern Passages)
9.14
14
A9
5T
Beaufort Sea
9.15
13
A8
5U
Chukchi Sea
9.16
12
A7
5C
James Bay
—
—
All
—
Kane Basin
—
—
A14
—
ATLANTIC OCEAN (see North Atlantic Ocean and
South Atlantic Ocean)
—
—
—
BALTIC SEA
2
1
B26
7B
Gulf of Bothnia
2.1
1(a)
B29
7T
Gulf of Finland
2.2
1(b)
B28
7F
Gulf of Riga
2.3
1(c)
B27
7H
The Sound
2.4
2
—
—
The Great Belt
2.5
2
-
—
The Little Belt
2.6
2
—
—
Kattegat
2.7
2
B25
7K
INDIAN OCEAN
5
45
F
6A
Mozambique Channel
5.1
45 A
FI
6Z
Gulf of Suez
5.2
35
F5
6W
Gulf of Aqaba
5.3
36
—
6Q
Red Sea
5.4
37
F4
6E
Gulf of Aden
5.5
38
F3
6D
Persian Gulf (Gulf of Iran)
5.6
41
F7
6P
Gulf of Oman
5.7
40
F6
6M
Arabian Sea
5.8
39
F2
6R
Laccadive Sea (Lakshadweep Sea)
5.9
42
F9
6L
Gulf of Mannar
5.10
—
F8
—
Palk Strait and Palk Bay
5.11
—
—
—
Bay of Bengal
5.12
43
F10
6B
Andaman Sea (Burma Sea)
5.13
44
F11
6N
Strait of Malacca (Malacca Strait)
5.14
46(a)
FI 2
6C
Great Australian Bight
5.15
62
F21
6G
Suez Canal
—
—
—
6U
MEDITERRANEAN REGION
3
—
—
—
Mediterranean Sea
3.1
28
B11
—
Mediterranean Sea, Western Basin
3.1.1
28 A
—
8W
Strait of Gibraltar
3.1. 1.1
28(a)
B7
8S
610
IHO
IHO
ACIC
DIAM
23-4th
23-23rd*
M 49-1
65-18
Alboran Sea
3.1.1 .2
28(b)
—
8Y
Balearic Sea (Balear Sea, Iberian Sea)
3.1 .1.3
28(C)
B9
8J
Ligurian Sea (Ligure Sea)
3.1. 1.4
28(d)
BIO
8L
Tyrrhenian Sea (Tirreno Sea)
3.1. 1.5
28(e)
B12
8T
Mediterranean Sea, Eastern Basin
3.1.2
28 B
—
8E
Adriatic Sea
3.1.2. 1
28(g)
B14
8D
Strait of Sicily (Strait of Sicilia)
3.1. 2.2
—
—
Ionian Sea
3.1. 2.3
28(f)
B13
8N
Aegean Sea
3.1. 2.4
28 (h)
B15
8G
Sea of Marmara
3.2
29
B16
8M
Black Sea
3.3
30
B17
8B
Sea of Azov
3.4
31
B18
8Z
Gulf of Lion (Gulf of Lions)
—
—
B8
8X
Aral Sea
—
—
—
8R
Bosporus
—
—
—
8P
Caspian Sea
—
—
—
8C
Dardanelles
—
—
—
8U
NORTH ATLANTIC OCEAN
1
23
B
1A
Skagerrak
1.1
3
B24
IS
North Sea
1.2
4
B23
IN
Inner Seas off the West Coast of Scotland
1.3
18
—
IK
Irish Sea and Saint Georges Channel
1.4
19
B22
1 R, IQ
Bristol Channel
1.5
20
B21
1C
Celtic Sea
1.6
21 A
—
—
English Channel
1.7
21
B20
IE
Bay of Biscay
1.8
22
B19
IB
Canarias Sea
1.9
—
—
—
Gulf of Guinea
1.10
34
C4
1G
Caribbean Sea
1.11
27
B6
IX
Gulf of Mexico
1.12
26
B5
1M
Bay of Fundy
1.13
25
B4
IF
Gulf of Saint Lawrence
1.14
24
B3
IT
Labrador Sea
1.15
15 A
—
1L
Greenland Sea
1.16
5
A1
5G
Denmark Strait
—
—
B1
ID
Lake Erie
—
—
—
9E
Lake Huron
—
—
—
9H
Lake Michigan
—
—
—
9M
Lake Ontario
—
—
—
9N
Lake Superior
—
—
—
9S
Panama Canal
—
—
—
1J
Saint Lawrence Seaway
—
—
—
9L
NORTH PACIFIC OCEAN
7
57
D
3A
Philippine Sea
7.1
56
D26
3P
Taiwan Strait (Formosa Strait)
7.2
—
D17
3F
East China Sea (Tung Hai)
7.3
50
D13
3E
611
Appendix G: Cross-Reference List of Hydrographic Codes (continued)
IHO
23-4th
IHO
23-23rd*
ACIC
M 49-1
DIAM
65-18
Yellow Sea (Huang Hai, Hwang Hai)
7.4
51
D14
3Y
Bo Hai (Bo Sea, Gulf of Chihli)
7.5
—
D16
3X
Liaodong Wan (Liaodong Gulf)
7.6
—
_
—
Inland Sea of Japan (Seto Naikai)
7.7
53
—
3N
Sea of Japan (Japan Sea)
7.8
52
Dll
3J
Gulf of Tartary
7.9
—
DIO
—
Sea of Okhotsk
7.10
54
D8
3Q
Bering Sea
7.11
55
D6
5D
Anadyrskiy Zaliv (Anadyrskiy Gulf)
7.12
—
—
5Y
Gulf of Alaska
7.13
58
D4
5F
Coastal Waters of Southeast Alaska
7.14
59
D3
5E
and British Columbia
Gulf of California
7.15
60
D2
3L
Gulf of Panama
7.16
—
D1
—
Amurskiy Liman
—
—
D27
—
Bering Strait
—
—
D7
5R
Bristol Bay
—
—
D5
—
Korea Bay
—
—
D15
3R
Korea Strait
—
—
D12
—
Sakhalinskiy Zaliv
—
-
D28
3B
Zaliv Shelikhova (Zaliv Shelekhova)
—
—
D9
3K
Luzon Strait
—
—
—
31
Tatar Strait
—
—
—
3D
PACIFIC OCEAN (see North Pacific Ocean
—
—
—
—
and South Pacific Ocean)
SOUTH ATLANTIC OCEAN
4
32
C
2A
Rio de la Plata
4.1
33
Cl
2R
Drake Passage
—
—
C5
2D
Golfo San Matias
—
—
C2
2M
Golfo San Jorge
—
—
C3
2J
Scotia Sea
—
—
C6
2S
Weddell Sea
—
—
C7
2W
SOUTH CHINA AND EASTERN
6
49 and 48
D18 plus others
3U plus others
ARCHIPELAGIC SEAS
South China Sea (Nan Hai)
6.1
49
D18
3U
Gulf of Tonkin
6.2
—
D19
3G
Gulf of Thailand (Gulf of Siam)
6.3
47
D20
3T
Natuna Sea
6.4
—
—
—
Singapore Strait
6.5
46(b)
—
3Z
Sunda Strait
6.6
—
—
—
Java Sea (Jawa Sea)
6.7
48 (n)
FI 3
4J
Makassar Strait (Makasar Strait)
6.8
48 (m)
El
4M
Bali Sea
6.9
48(1)
FI 4
4L
Flores Sea
6.10
48 0)
F16
4F
Sumba Strait
6.11
—
—
—
612
IHO
IHO
ACIC
DIAM
23-4th
23-23rd*
M 49-1
65-18
Savu Sea (Sawu Sea)
6.12
48 (o)
FI 5
6S
Timor Sea
6.13
48 (i)
FI 9
6T
Joseph Bonaparte Gulf
6.14
—
F20
—
Gulf of Carpentaria
6.15
—
E4
4P
Arafura Sea
6.16
48 (h)
E3
4U
Aru Sea
6.17
—
—
—
Banda Sea
6.18
48(g)
E2
4B
Teluk Bone (Gulf of Bone, Gulf of Boni)
6.19
48 (k)
F17
4E
Ceram Sea (Seram Sea)
6.20
48(f)
D25
4Q
Gulf of Berau
6.21
—
—
—
Halmahera Sea
6.22
48(e)
D24
3H
Molucca Sea (Molukka Sea, Maluku Sea)
6.23
48(c)
D23
3M
Teluk Tomini (Gulf of Tomini)
6.24
48(d)
F18
3V
Sulawesi Sea
6.25
—
—
—
Mindanao Sea
6.26
—
—
Sulu Sea
6.27
48(a)
D21
3S
Celebes Sea
—
48 (b)
D22
3C
SOUTH PACIFIC OCEAN
8
61
E
4A
Bismarck Sea
8.1
66
E6
4K
Solomon Sea
8.2
65
E7
4S
Torres Strait
8.3
—
E5
—
Coastal Waters of Great Barrier Reefs
8.4
—
—
—
Coral Sea
8.5
64
E9
4C
Tasman Sea
8.6
63
E10
4T
Bass Strait
8.7
62 A
F22
6F
Amundsen Sea
—
—
E12
4D
Bellingshausen Sea
—
—
E13
4G
Cook Strait
—
—
E8
—
Ross Sea
—
—
Ell
4R
* The letters after the numbers are subdivisions, not footnotes.
613
Appendix H:
Cross-Reference List of Geographic Names
This list indicates where various geographic names—
including the location of all United States Foreign
Service Posts, alternate names of countries, former
names, and political or geographical portions of
larger entities— can be found in The World Factbook.
Spellings are normally, but not always, those
approved by the US Board on Geographic Names
(BGN). Additional information is included in
brackets.
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
A
Abidjan [US Embassy]
Cote d’Ivoire
5 19 N
4 02 W
Abkhazia [region]
1750 S
31 03 E
Hatay [province]
Turkey
36 30N
36 15 E
Havana [US post not maintained; representation by
US Interests Section (USiNT) of the Swiss Embassy]
20 00 S
30 00 E
Riga [US Embassy]
17 50 S
105 00 W
Salvador de Bahia [US Consular Agency]
20 00 S
30 00 E
Soviet Union
Armenia, Azerbaijan, Belarus, Estonia, Georgia,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
Spanish Guinea','688454e7c2d25fbb90af6214472142a738703f20a45f415eb9f42373739e8bf8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7893d364191b60c04e9ced6e60f52dc2acf9cef8513bfd2e01c017a5795a5e0d',1998,'AF','Afghanistan','space',975,'AF
AF
AFG
004
AF
34 31 N
69 12 E
Kaduna
37 00 N
73 00 E
Valletta [US Embassy]
37 00 N
73 00 E
Wales [region] _ United Kingdom _ 52 30N _ 3 30W
638
Name
Entry in The World Factbook
Latitude
(deg min)
jafissiB **] iI«IKK«E
iniTn
Wallis Islands','8eb2098e444dc3e560dd794ce1927d6fe9077d858ef16631e3cac0fc0c395541','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d31ef4dcc4f8d27f1a706b8dea5e9794101947e199c43bcf506f9ea3c9cabc25',1998,'AL','Albania','space',976,'AL
AL
ALB
008
AL
41 20 N
19 50 E
Tirane (see Tirana)
41 20 N
19 50 E
Tirol [region]
Austria, Italy
47 00 N
11 00 E
Tobago [island]','03b5c024b5f5c2aeaa06234a1a0ccecacb7098d112fecd321a7d9303ba56662c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a67ad231e88d29bf5f1c7db8f59acd7349d3791f2bfe3fdf53f6c6bb480465d',1998,'DZ','Algeria','space',977,'AG
DZ
DZA
012
DZ
3647 N
2 03 E
Alhucemas, Penon de
35 43 N
0 43 W
Oranjestad
Scale 1: 19,500,000
802586 (R01083) 6-98
Central Balkan Region
CROATIA!
j rj '' Hodmezovasarhely
HUN G A R Y
,pecs J1/}
. l\\''t
Subotica I )
Vojvodina','bf0cf6c49c6ae738bc6f5bdb39de85d4d9396d5698fca5b027c929926356d71b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4680885940ab1c2f0db6b0980535351edbb1c8e6654a262f4e618409edb979b5',1998,'AS','American Samoa','space',978,'AQ
AS
ASM
016
AS
14 20 S
170 00 W
Edinburgh [US Consulate General]
14 13 S
169 35 W
Maputo [US Embassy]
1416 S
170 42 W
Palawan [island]
1 1 3 S
171 15 W
Swan Islands
14 18 S
170 42 W
Tyrol, South [region]','f14610e0bcea02b6403cc96ae8655c4daaa36b4d99e124237d6a3e3fb1937188','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a51c0fa9c71358bab9c38e63985ff0ac506703250e4d4bf5d783e994ba954cf0',1998,'AO','Angola','space',979,'AO
AO
AGO
024
AO
5 33 S
12 12 E
Cabot Strait
Atlantic Ocean
47 20 N
59 30 W
Caicos Islands
8 48 S
13 14 E
Lubumbashi
Democratic Republic of the Congo
11 40 S
27 28 E
Lusaka [US Embassy]','5952dd59720eeb6df3da43d2c4487863c19ad8013ad01316ef68a3e2b43f7f26','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee608477f85f8d9b7efec76487507061973e5f787c3846c3f00d300a9564e28a',1998,'AQ','Antarctica','space',980,'AY
AQ
ATA
010
AQ
ISO defines as the territory south of 60
degrees south latitude
66 30 S
139 00 E
Aden
71 00 S
70 00 W
Alexandria
67 00 S
163 00 E
Balochistan [region]
79 30 S
49 30 W
Berlin [US Branch Office]
62 56 S
60 34W
Denmark Strait
Atlantic Ocean
67 00 N
24 00 W
D’Entrecasteaux Islands
90 35 W
Philip Island
7330S
12 00 E
Quemoy [island]
Taiwan
24 27 N
1 1 8 23 E
Quito [US Embassy]
79 30 S
162 00 W
Roseau
80 00 S
180 00 E
Ross Island
81 30 S
175 00 W
Ross Sea
76 00 S
175 00 W
Rota [island]
67 24 S
179 55 W
Senyavin Islands
Federated States of Micronesia
6 55 N
158 00 E
Seoul [US Embassy]
South Korea
37 34 N
127 00 E
61 00 S
45 00 W
South Ossetia [region]
62 00 S
59 00 W
South Tyrol [region]
66 30 S
139 00 E
Thailand, Gulf of
Pacific Ocean
10 00 N
101 00 E
Thessaloniki [US Consulate General]
72 20 S
99 00 W
Tiberias, Lake','8243427c3b32934ca17dbdbece91274d2738fb0b61738d3fe468ee7602e95de8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e901aeda908693cf33b2476261e9e3e5104b13df15ea4ba52886b92223f0646',1998,'AG','Antigua and Barbuda','space',981,'AC
AG
ATG
028
AG
14 34 N
90 44 W
Antipodes Islands
17 38 N
61 48 W
Barcelona [US Consulate General]
16 55 N
62 19 W
Red Sea
Indian Ocean
20 00 N
38 00 E
Revillagigedo Island
17 06 N
61 51 W
Saint Lawrence, Gulf of
Atlantic Ocean
48 00 N
62 00 W
Saint Lawrence Island
Caribbean Sea
lals A vos
(VENEZUELA).','8868cd8e1eae3c86e77c2263d3e12a19ab8ba54c99bf3cdd6d6f37263bf6fc45','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a6c160cc88bd4e1e9bb1e6bf6314a5df9ab65e474c6c26fd32e564168497ae7',1998,'AR','Argentina','space',982,'AR
AR
ARG
032
AR
34 36 S
58 27 W
Bujumbura [US Embassy]
35 00 N
63 00 W
Panama [US Embassy]','30c5c733945922b4c0acef9652c9baf8947f8c317fc0c2c17c2e7b92b7052f84','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74654f098a00549abae4754c2859538d8fc2f04a8f9cde72bb8de4155fd35454',1998,'AW','Aruba','space',983,'AA
AW
ABW
533
AW
Ashmore and Cartier Islands
AT
—
—
—
—
ISO includes with Australia
12 33 N
70 06 W
Oresund (The Sound)
Atlantic Ocean
55 50 N
12 40 E
Orkney Islands','6ea0231359c862b233dfa5750d1da26c53fa379abfdb46c6ea11bbba845023c0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f8a0c5aa7f6758d816ffc2cc7cacc70ee935022f9c53227678de9a8474a3362',1998,'AU','Australia','space',984,'AS
AU
AUS
036
AU
ISO includes Ashmore and Cartier
Islands, Coral Sea Islands
10 12 S
142 16 E
Banks Island
27 28 S
153 02 E
Britain (see Great Britain)
35 17 S
149 08 E
Canton (Guangzhou)
23 15 S
155 32 E
Caucasus [region]
Russia
42 00 N
45 00 E
Cayenne
10 25 S
105 39 E
Christmas Island (Kiritimati) [Pacific Ocean]
31 30 S
159 00 E
Louisiade Archipelago
30 07 S
147 24 E
Maddalena, Isola
37 49 S
144 58 E
Mellila
31 56 S
115 50 E
Pescadores [islands]
Taiwan
23 30 N
119 30 E
Peshawar [US Consulate]
33 52 S
151 13 E
T Tahiti [island]
43 00 S
147 00 E
Tasman Sea
Pacific Ocean
4 30 S
168 00 E
Taymyr Peninsula (Poluostrov Taymyr)
Russia
76 00 N
104 00 E
Tbilisi [US Embassy]
Boundary representation is not necessarily authoritative.
Names in Vietnam are shown without diacritical marks.
100
Oceania
CHINA fiataJ
/i. Taipei
*■"*/ ■/*?
___Sh*ntDUw/ :/
Okinawa y A
Naha*sv
- vV*
* BONIN
^ ,1, tfMAfOS
I* ;i (JAPAN)
!?''
1 £ VOL CAM)
O’ ISLANDS
: (JAPAN)
Marcos /s/and
(JAPAN)
\\ / Taiwan
*Hong Kong SA.R. Vao-hsiung
mu , i o/o/;
shima
(JAPAN) f
Philippine
Sea
P H I
Palawan f Becolodf/fc"*J.
Negros^f* .Jjpgayanc
. Zamboanga
, Northern
'' Mariana
Islands
< ( (U.S.)
+ Saipan
Guam if Hagfitfia (Agana)
(U.S.)
Wake Island
(U.S.)
BandarS
Begawi
BRUNEI
FEDERATED STATES OF MICRONESIA
Pohnpai
★
Palikir i
CAROLINE ISLANDS
Celebes Sea ''
WmM mm -- A
^^^^^ngpanda^B Ambon
Java Sea Banda Sea t
.IN DO N E S I A ■ t
^jons ~ • /
MARSHALL
ISLANDS
Tarawa^ KIRIBATI
(GILBERT ISLANDS)
Yaren District * • flenabe •
NAURU * *•
Mackay* ''
Vh
RockhamptonJ
- ~
Gladstone'' ''
Brisbane j(
Gold Coast *j
Broken 0^''
Hill X','08bac23e2e8ce05a86219f51a1ff0f5f214815ab84fed5e2a67353ca199df0f8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c5409b9eb45ae5fad41888c22647be937a5828e0819b96d4cbe3ce156ecc63d',1998,'AT','Austria','space',985,'AU
AT
AUT
040
AT
47 48 N
1 3 02 E
Samar [island]
48 12 N
1622 E
Vientiane [US Embassy]
Laos
17 58 N
102 36 E
Vilnius [US Embassy]','eacf7a68d1f1c2ec895e9c9fa248c1947f3145b5ce5971d603abb40990fb0331','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70856fc4a8d244feb935fe02fc0c3c8dfb8356277dfec92c05ce0a4690fb1901',1998,'AZ','Azerbaijan','space',986,'AJ
AZ
AZE
031
AZ
The Bahamas
BF
BS
BHS
044
BS
40 23 N
49 51 E
Baku [US Embassy]
40 23 N
49 51 E
Baky (see Baku)
40 23 N
49 51 E
Balabac Strait
Pacific Ocean
735 N
117 00 E
Balearic Islands
40 00 N
46 40 E
Nagoya [US Consulate]
39 20 N
45 20 E
N’Djamena [US Embassy]','a3490b0db670fe8e2f130f162e66b6c898ad4cfbb5723d481b03deb8eebd1384','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ee26a9e0f274d6dc817889582532404d238244b850f6f85e759b9d84b867948',1998,'BH','Bahrain','space',987,'BA
BH
BHR
048
BH
Baker Island
FQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
26 13 N
50 35 E
Manaus [US Consular Agency]','6f2b9b17008cb70d0ed0b2862e9dfa3cd99a8c4ff6ce3435464c150749277d7d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af2f70fb48eaf5c8cdc2412a808b9f53155e8ccd7b5390b384b14d1384e86c50',1998,'BD','Bangladesh','space',988,'BG
BD
BGD
050
BD
23 43 N
90 25 E
Dhofar [region]
24 00 N
90 00 E
East Siberian Sea
Arctic Ocean
74 00 N
166 00 E
East Timor (Portuguese Timor)','7cf05f92b79c7e794260db903314afb75a981543b557d081a95244a9b3d6bccf','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('966b101b4e656ddd54e3f65d207ea22d8551db73a3e72443b5c94e331d95673b',1998,'BB','Barbados','space',989,'BB
BB
BRB
052
BB
Bassas da India
BS
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
13 06 N
59 37 W
Brisbane','24f672934fc2922266385e3c83b5464cf15c963c0079616bdd179b16b174c0ac','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0972afce5e746ce750c3b8f75000aa66688c4cd4b82221f70e5ef36e7b11568',1998,'BY','Belarus','space',990,'BO
BY
BLR
112
BY
53 00 N
28 00 E
Bengal, Bay of
Indian Ocean
15 00 N
90 00 E
Bering Sea
Pacific Ocean
60 00 N
175 00 W
Bering Island
Russia
55 00 N
166 30 E
Bering Strait
Pacific Ocean
65 30 N
169 00 W
Berkner Island
53 00 N
28 00 E
C Cabinda [province]
53 54 N
27 34 E
Minorca Island (Isla de Menorca)','0696bfeb0fb833a126d2574684a29a688790955085a71dca0573e2582bfb18d3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96769e33cf9e16f8e55e60707aee9aa187db262e1eba7fa6d560fd4a363210e9',1998,'BE','Belgium','space',991,'BE
BE
BEL
056
BE
601
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
51 13 N
425 E
Aozou Strip
50 50 N
4 20 E
Union (USEU), US Mission to the North Atlantic
Treaty Organization (USNATO)]
Bubiyan [island]','ef118050fb89d2ae086471a303217111b660f9d5cb8e8943025aebdf6681c44a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f30e984ec35e68488b663b724d25f27ae70b4b4c176c215c15f936db35d0c6b',1998,'BZ','Belize','space',992,'BH
BZ
BLZ
084
BZ
17 30 N
88 12 W
Belle Isle, Strait of
Atlantic Ocean
51 35 N
56 30 W
Bellingshausen Sea
Pacific Ocean
71 00 S
85 00 W
Belmopan
17 15 N
88 46 W
Belorussia
17 15 N
88 45 W
British Solomon Islands','c5a30d477aa8ca0edccd5431b9153516e978f068d902874a0faff7215871bbf4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a114f66ed9e873dbfe48d28562376ce688143220d5a4a2cfa07e02a0a4df106',1998,'BJ','Benin','space',993,'BN
BJ
BEN
204
BJ
6 21 N
2 26 E
Courantyne River
Guyana, Suriname
5 57 N
57 06 W
Crete [island]
9 30 N
2 15 E
Daito Islands
6 29 N
2 37 E
Portuguese East Africa','706dde92672a8d2a85ece063b1207caef026ce1a788ca052aad22803aae721a4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4513fef2de03922ecf623a5651e3df396440b43db9041d6b6669c7ee0b734991',1998,'BM','Bermuda','space',994,'BD
BM
BMU
060
BM
32 17 N
64 46 W
Hanoi [US Embassy]
Vietnam
21 02 N
105 51 E
Harare [US Embassy]','e6b3dcb794373700240a86b4f009f4ca75b0bc1453bd5354bcd8869a2c024899','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b541c095d829aaf5fa79f06a9dbd6ccd2a333c6876963b5cb52c95c49bf9870',1998,'BA','Bosnia and Herzegovina','space',995,'BK
BA
BIH
070
BA
44 00 N
18 00 E
Bosporus [strait]
Atlantic Ocean
41 00 N
29 00 E
Bothnia, Gulf of
Atlantic Ocean
63 00 N
20 00 E
Bougainville [island]
44 00 N
18 00 E
Hispaniola [island]
Dominican Republic, Haiti
18 45 N
71 00 W
Ho Chi Minh City
Vietnam
10 45 N
106 40 E
Hokkaido [island]
43 52 N
18 25 E
Sarawak [state]','66c15ef0b9ceca1e20038a2cb15d87c09043a3afa1608fb516deeb2d6398d848','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('135d501672cc7ef5a01a3211630dbbc9bd12153c623590dbf01911c7e416dbe2',1998,'BW','Botswana','space',996,'BC
BW
BWA
072
BW
22 00 S
24 00 E
Beijing [US Embassy]
25 55 E
Galapagos Islands (Archipielago de Colon)','ab802320a8f8e9dcd86d66d7c675ece3ebce3fbf7a41cc7d049ef36ce39a3353','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0de676937aedd55c07a628fbb11b8594bcb2ff6c5803e7f74b2d723a24bd3b37',1998,'BV','Bouvet Island','space',997,'BV
BV
BVT
074
BV
° (NORWAY)
NORWEGIAN CLAIM
undefined limit
PRINCE EDWARD ISLANDS
(SOUTH AFRICA)\\
Novolazarevskayac2^
i^RUSSIA)/ \\
French Sputhern .
and Antarctic iafids
\\sourir i
t sReu/nd
Ustnftia ISLANDS^
Dralp ^
Passage
1 area of
lerilargement^
flNeumayer ‘ Maitri
(GERMANY) (INDIA)
Queen Maud Land
y(U.K.)
rano II /
IntinaV— ^ /
AntarcticJ-t
(FRANCE)
CHILEAN .
CLAIM
Bellingshausen
I Sea I
■^Belg^no ill \\
^ARGENT»NA^
Amundsen-Scott
=S=S“*““''W m.S.) -
South Pole v 7
2800 m. \\.
Mark Byrd
yS o u t h Pacific \\ An)undsJ
\\ O c e a n\\ Sea
Argentina, Brazil, Chite; China>^oland,
Russia, South Korea/Uruguay eafch have
a station on King George Island,
AruWPrat
(CHILE)^
Juan Carious
tSPAINf
Syo^UAPAN)
H Nlawson \\
\\ (AUSTRALIA) \\
f Amery Ice Shelf \\
Zhong Shan g^vis ''
(CHINA) \\ (AUSTRALIA)
1 Mirnyy
. vostok Tmssw
''(RUSSIA) /*& J /
/ C: A r Shackieton i
/ * I K Ice Shelf
ILES \\
Kerguelen/
Heard Island and \\
McDonald Islands \\
(AUSTRALIA)
Indian
Ocean
ROSS ; ; \\ \\
Ice Shelf '' ; \\
''-■ ^:Sc)tt '' \\
(N. Z.)**hmuT6\\
. /#
ij Casey / ^
AUSTRALIA) /$
lyictoria''Landx
Of fjEsperahza
^ffiRG^NTIN^
m /m Maramfaio
"naria "(ARGENTINA,
, (CHILE), I /
Scott
nt*!cUc ,stanK
-L. Circle
CLAIM
" Dunlont d''Urville
\\ (FRANCE) /
BALLENY''^
- -tSCANDS
FRENCH
CLAIM
-m
/vN (traham
Palmer..n^anci;:^
J x® ^Farada1
/ Antarctic ■ ''
‘ Pertinsulet "
4U.K/(tetAlNE)
? / \\ Sani^8n-< f
/(OvkjwO^V
South Pacific
. Ocean
CHATHAM ISLANDS
(NEW ZEALAND)
Macquarie Island
'' ( AUSTRALIA) X
Campbell
Island ^
(NEW ZEALAND) A (JCKLAND ISLANDS
/ (NEW ZEALAND)
- SNARES ISLANDS
g (NEW ZEALAND)
NEW
ZEALAND
J /North Island
Christchurch
802596 (R02207) 6-98
ie number to local time to obtain UTC.
i zone number from UTC to obtain local time.
WEST
EAST
Subtract time zone number from local time to obtain UTC.
Add time zone number to UTC to obtain local time.','46a4b432fd1f4a4b43249c29f1ab97c0d32aa8a22c97e8d2761237b7382274fc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53a44716e96cd086ada4de116552ef93dbfcee5f5c8c76bfbc4db7dd9d2a7d9e',1998,'BR','Brazil','space',998,'BR
BR
BRA
076
BR
1 27 S
48 29 W
Belep Islands (lies Belep)
15 47 S
47 55 W
Bratislava [US Embassy]
3 51 S
32 25 W
Fernando Po [island] (see Bioko)
3 43 S
38 30 W
Fort-de-France
3 08 S
60 01 W
Manchukuo
20 30 S
2851 W
Mas a Tierra (Robinson Crusoe Island)
30 04 S
51 11 W
Port-of-Spain [US Embassy]
8 03 S
34 54 W
Redonda [island]
22 54 S
wci r tvi
Rio de Oro
3 51 S
33 49 W
Rockall [island]
023 N
29 23 W
Saint Peter Port
1259S
38 31 W
Salzburg
2332S
46 37 W
Sao Pedro e Sao Paulo, Penedos de [rocks]
0 23 N
29 23 W
Sao Tiago [island]
Cape Verde
15 05 N
23 40 W
Sao Tome [island]
20 31 S
29 20 W
Tripoli
802584 (R02068) 6-98
South America','faf3f9e52e06e4f88abce1a9db7cf874e672019501861fae7d10ebd1bde2c240','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08f873d693891e250a1ef19ef2b301530ca9aca1f645afe35c85dd4670c7ec42',1998,'IO','British Indian Ocean Territory','space',999,'10
10
IOT
086
IO
British Virgin Islands
VI
VG
VGB
092
VG
Brunei
BX
BN
BRN
096
BN
6 00 S
71 30 E
Channel Islands
Guernsey, Jersey
49 20 N
2 20 W
Charlotte Amalie
Virgin Islands
1821 N
64 56 W
Chatham Islands
7 20 S
72 25 E
Diego Ramirez [islands]
6 00 S
71 30 E
Okhotsk, Sea of
Pacific Ocean
53 00 N
150 00 E
Okinawa [island group]','5c02c9294684ddc97a2ee30c76e19f188ec26ef6129113e5bf8e1726c88b8f5a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bae5c62191333f5f9fca919b36ab82f0bf657e8fb8d5cfa09c905d2dba541d03',1998,'BF','Burkina Faso','space',1000,'UV
BF
BFA
854
BF
Burma
BM
MM
MMR
104
MM
ISO uses the name Myanmar
12 22 N
1 31 W
Outer Mongolia
13 00 N
2 00 W
Ural Mountains
Kazakhstan, Russia
6000 N
60 00 E
Ussuri River
China, Russia
48 28 N
1 35 02 E
V Vaduz','e4d5cd6c0b87fd93a38364315445e77b138b81761e97fea1e77f23dc7866f1a6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79a0df9c445c24399eebca8d320f9753d6d776149889613c17153c4e7088e6df',1998,'KH','Cambodia','space',1001,'CB
KH
KHM
116
KH
1326 N
103 50 E
Anglo-Egyptian Sudan
13 00 N
105 00 E
Kanton Island
13 00 N
105 00 E
Khuriya Muriya Islands (Kuria Muria Islands)
11 33 N
104 55 E
Phoenix Islands','32c550a6ab2a03360dde03332adb51d3a2b4dd167a8b0e37b8de2700835e923f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2e5f84281f0b6ca7820613b46489eecffffa658175b0b34afc081f472e923a2',1998,'CM','Cameroon','space',1002,'CM
CM
CMR
120
CM
4 03 N
9 42 E
Douglas
Man, Isle of
54 09 N
4 28 W
Dover, Strait of
Atlantic Ocean
51 00 N
1 30 E
Drake Passage
Atlantic Ocean
60 00 S
60 00 W
Dubai [US Consulate General]
6 00 N
12 00 E
French Guinea
3 52 N
11 31 E
Yap Islands
Federated States of Micronesia
9 30 N
138 00 E
Yaren','b291b29198522070b9444f219fcf6b2eec10ddb01c29821b9e352287a17891ed','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b509b1289543073fb3fa38ea7976b99098571206890dd7076bdc61a9a5023908',1998,'CA','Canada','space',1003,'CA
CA
CAN
124
CA
Cape Verde
CV
CV
CPV
132
CV
79 30 N
90 00 W
Azad Kashmir
68 00 N
70 00 W
Baghdad [US Embassy temporarily suspended; US Iraq
Interests Section located in Poland’s embassy in Baghdad]
33 21 N
44 25 E
Baki (see Baku)
75 15 N
121 30 W
Banks Islands (lies Banks)
51 03 N
114 05 W
California, Gulf of
Pacific Ocean
28 00 N
112 00 W
618
Name
Entry In The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Campbell Island
76 00 N
87 00 W
Dhahran [US Consulate General]
78 00 N
103 00 W
Ellesmere Island
81 00 N
80 00 W
Ellice Islands
44 39 N
63 36 W
Halmahera [island]
54 00N
62 00 W
Laccadive Islands
45 31 N
73 34 W
Moravia [region]
Czech Republic
49 30 N
17 00 E
Moravian Gate
Czech Republic
49 35 N
17 50 E
Moroni
52 00 N
56 00 W
Niamey [US Embassy]
45 20 N
73 58 W
Ouagadougou [US Embassy]
46 20 N
63 20 W
Prince Edward Islands
76 30 N
1 1 9 00 W
Principe [island]
52 00 N
72 00 W
Queen Charlotte Islands
53 00 N
132 00 W
Queen Elizabeth Islands
78 00 N
95 00 W
Queen Maud Land [claimed by Norway]
43 55 N
59 50 W
Safety Islands (lies du Salut)
47 12 N
60 09 W
Saint Paul Island
43 39 N
79 23 W
Torres Strait
Pacific Ocean
10 25S
142 10 E
Torshavn
49 16 N
123 07 W
Vancouver Island
49 45 N
126 00 W
Van Diemen Strait (Osumi Strait)
Pacific Ocean
31 00 N
131 00 E
Vatican City [US Embassy]
Holy See
41 54 N
1227E
Velez de la Gomera, Penon de
Whitehorse
r~~~-
Bering
See
--A/t
Anchora^^^^ \\
7/1 \\ lapt
VfT Gulf of Alesl.n \\ ^ „ r ''
V" 1 \\ 5^:.
\\ Scale 1:37,000,000 <f \\
1 0 400 Kilometers \\. ^
l | - 1 - - - \\
^ 7 j
^.fUrlAN /StAfX
180''* ***** - \\1b
s c^T ^
Scale 1:360,000
5 Kilometers
Is
v''x
v u m
/for J
\\
NjA''X,/
J
ig
/
to
-<
^J/y%
K
130 0^
A''-^N/
a. • 4;r .
% v j
^Vancouver ''•
^Seattle/
^Dlympia j
Wasl/ing U
*Salem /
/
Oregob
/
Mon/tana
s UX''''
^Sacramento icareon Citrj-- - Lsalt.Late cJ~
San FraneiscoX
? / X
\\ California
North Qakota
9''
South Pakota
Pierre
j Minnesota]
X Saint Paul 7
Denver
Colorado
Iowa X -Chicago,
tcjtnsinf
Madison ! \\ Lansing
^L- — i ) Detroit^
/Montpelier /N.H\\ 7\\
r yt! ©Concord
Nebraska \\ •
I Lincoln. \\ Des Moines
7 \\Hartford R-1- ''
- -
Pennsylvania 5 _£Ntw York,.-,-
1 PhiladelphiaVT?nton
\\Harrisbum^CS?Vk''rSey
Topeka ^
! Kansas
M°ine5_) I . tndianal
7 _ Illinois,.!- — t Columbus /Wep J T^Annapolis
\\ JlndianapolW A Virginia/ ^Ma^ington, D.C.
VqnntfeM / 9 Richmond V/J *
St. Louisj; ) /X Charleston! ... . .
• 7 / * f 9 ,, j \\ Virginia XX
Jefferson Cityvl Frankfort \\ _
Missouri f\\ / Kentucky / - 1 - " Xh
X V Los Angeles
/• oN
Arizona /
phoenix j New Mexico
9 State capital " . Herfnosillo
/ <» > V''X
I Scale 1:27,000,000 \\
/ Albers Equal- Area Projection V /
standard parallels 28° 30''N and 45° 30‘ N
1 0 500 Kilometers (f j A
/ I '' ‘1 1 ''"H - 1 - 1 1 / X
/ 0 500 Miles N,
/ \\Aid l.
Oklahoma
0
Oklahoma City
Chihuahua','b628d9c10af3ac964dc43dee9d36c7c09529188cf2ecb275407c27d57b72ab95','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cef053573c93d78d49908c4cf36d5a224573d9ccfaa72794d6bac200fc441d9a',1998,'KY','Cayman Islands','space',1004,'CJ
KY
CYM
136
KY
19 20 N
81 23 W
Georgetown
The Gambia
13 30 N
14 47 W
Georgetown [US Embassy]
19 20 N
81 20 W
Grand Turk','730c627531d388b1da63af2c95343c9310790bccc8c799c6890e725c96d5ca3e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53744326b7c1b94bfcf37a1d40c9f2e97b31834715d74b1df03a27d806d292cd',1998,'CF','Central African Republic','space',1005,'CT
CF
CAF
140
CF
4 22 N
18 35 E
Banjul [US Embassy]
The Gambia
13 28 N
16 39 W
Banks Island
7 00 N
21 00 E
Ceuta','a555df8604207bb5f6bb71b7d99af419194571e8bf4b50a6754e1639a9bfe1c6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1239d65f31b34e88f087a513f419cdc8d58fdbbcd93328c4a3133f086d0b319',1998,'TD','Chad','space',1006,'CD
TD
TCD
148
TD
22 00 N
18 00 E
Apia [US Embassy]
12 07 N
15 03 E
Negev [region]','04dce23c70c6c138a95ed65697ce0b9403be6dcd7aeff30513f2b120baa32494','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e28e95a6835b644fbbc453c293797b390372daa937593a2f91f48b0e95f1069f',1998,'CL','Chile','space',1007,'Cl
CL
CHL
152
CL
2430 S
69 15 W
Athens [US Embassy]
56 30 S
68 43 W
Diomede Islands
Russia [Big Diomede], United States [Little
Diomede]
65 47 N
169 00 W
Diu
27 07 S
109 22 W
Eastern Channel (East Korea Strait or Tsushima Strait)
Pacific Ocean
34 00 N
129 00 E
Eastern Samoa
55 59 S
67 16 W
Horne, lies de
33 00 S
80 00 W
Jubal, Strait of
Indian Ocean
27 40 N
33 55 E
Judaea [region]
Israel, West Bank
31 35 N
35 00 E
Jutland [region]
33 38 S
78 52 W
Mascarene Islands
Mauritius, Reunion
21 00 S
57 00 E
Maseru [US Embassy]
27 07 S
109 22 W
Passion, lie de la
Clipperton Island
10 17 N
109 13 W
Pashtunistan [region]
Afghanistan, Pakistan
32 00 N
69 00 E
Peking (see Beijing)
33 38 S
78 52 W
Rocas, Atol das
26 28 S
105 00 W
Salisbury (see Harare)
26 21 S
79 52 W
San Andres y Providencia, Archipielago
26 17 S
80 05 W
San Jose [US Embassy]
3327 S
70 40 W
Santo Antao [island]
Cape Verde
17 05 N
25 10W
Santo Domingo [US Embassy]','d74ebce6a5baf47f8bd378cb05f11cacee050b6980520f8654f102c99723a126','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('801f2357b93d5095262523c3f2def3c90be41d78420ac6a29a185e1f5ffeed45',1998,'CN','China','space',1008,'CH
CN
CHN
156
CN
see also Taiwan
39 56 N
116 24 E
Beirut [US Embassy]
23 06 N
113 16 E
Canton Island (Kanton Island)
39 39 N
104 04 E
Chennai (Madras) [US Consulate General]
35 00 N
105 00 E
China, Republic of
Taiwan
23 30 N
105 00 E
Chisinau [US Embassy]
Moldova
47 00 N
28 50 E
Choiseul [island]
23 06 N
113 16 E
Guantanamo Bay [US Naval Base]
19 00 N
109 30 E
Halifax [US Consulate General]
42 00 N
113 00 E
Ionian Islands
36 00 N
84 00 E
Kuril Islands
Russia [de facto]
46 10N
152 00 E
Kuwait [US Embassy]
44 00 N
124 00 E
Manchuria
44 00 N
124 00 E
Manila [US Embassy]
39 56 N
1 1 6 24 E
Pelagian Islands (Isole Pelagie)
31 14 N
121 28 E
Shenyang [US Consulate General]
41 48 N
123 27 E
Shetland Islands
42 00 N
8600 E
Sint Eustatius [island]
Netherlands Antilles
17 29 N
62 58 W
Sint Maarten [island]
Netherlands Antilles
18 04 N
63 04 W
Skagerrak [strait]
Atlantic Ocean
57 45 N
9 00 E
Skopje [US Embassy]
The Former Yugoslav Republic of Macedonia
41 59 N
21 26 E
Society Islands (lies de la Societe)
32 00 N
90 00 E
Tbilisi (see Tbilisi)','1ecabdafd5a4c613843d033b6cfb46e2240b2db44d481909a46b4082e6ef418f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef723e8aadc22c6a4a80f2939617f145379bd7a6dce513fae4f9ae9855347c0d',1998,'CX','Christmas Island','space',1009,'KT
CX
CXR
162
CX
Clipperton Island
IP
—
—
—
—
ISO includes with French Polynesia
18 44 N
64 19 W
Severnaya Zemlya (Northland) [island group]
Russia
79 30 N
98 00 E
Shaba [region]
Democratic Republic of the Congo
8 00S
27 00 E
Shag Island
(AUSTRALIA) *
Denpasar +
! Lombok —
Cocos
(Keeling) ,,
Islands
(AUSTRALIA)
Indian Ocean
Ashmore and
Cartier Islands
(AUSTRALIA)
rr I
TCt Gulf of
> Carpentaria
Scale 1:32,000,000 at 5*N
Mercator Projection','0121e7cce05895d573f9801ebe7ff520680ee53eecb0b69a29418bc6d5ae52c5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10489d7ce52ff8da8c69fdd3cdac8707b03f1b309c899fb1f94a1ab196ad81e7',1998,'CC','Cocos (Keeling) Islands','space',1010,'CK
cc
CCK
166
cc
12 30 S
96 50 E
Colombo [US Embassy]
12 30 S
96 50 E
Kerguelen, lies
French Southern and Antarctic Lands
49 30 S
69 30 E
Kermadec Islands
12 10 S
96 55 E
West Korea Strait (Western Channel)
Pacific Ocean
34 40 N
129 00 E
West Pakistan','3a32697266d0ca314926145bb483702902b66d2c3dfe587813a9b3d6793b25c2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52bd051b7d271a4203b88c6eb532aa497c19f1a485523c6a2dbf1b729122fee4',1998,'CO','Colombia','space',1011,'CO
CO
COL
170
CO
10 59 N
74 48 W
Bashi Channel
Pacific Ocean
22 00 N
121 00 E
Basilan Strait
Pacific Ocean
6 49 N
122 05 E
Basque Provinces
4 36 N
74 05 W
Bohemia [region]
Czech Republic
14 30 E
Bombay (see Mumbai)
4 00 N
90 30 W
Malta Channel
Atlantic Ocean
56 44 N
26 53 E
Malvinas, Islas
Falkland Islands (Islas Malvinas)
51 45 S
59 00 W
Mamoutzou
13 32 N
80 03 W
Roosevelt Island
13 00 N
81 30 W
San Bernardino Strait
Pacific Ocean
12 32 N
124 10 E
San Felix, Isla
14 25 N
80 16 W
Serranilla Bank
1551 N
79 46 W
Settlement, The','9e0473e0d29489fc8f2bc79b5edb37c9863747eb9141a43840c00fa5428d61cf','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ee57d116088a06d82e414d283b1a83b230a1bd205ac0568569d18c55c21743b',1998,'KM','Comoros','space',1012,'CN
KM
COM
174
KM
Congo, Democratic Republic of the
CG
ZR
ZAR
180
ZR
formerly Zaire
Congo, Republic of the
CF
CG
COG
178
CG
12 15 S
44 25 E
Ankara [US Embassy]
Turkey
39 56 N
3252 E
Annobon [island]
11 41 S
43 16 E
Mortlock Islands (Nomoi Islands)
Federated States of Micronesia
5 30 N
153 40 E
Moscow [US Embassy]
Russia
55 45 N
37 35 E
Mount Pinatubo','d6849eb9305ed95b16c63a7046a1fe223323f4f7fb4a992759532a75f1da80e7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc86da6679433313d033b88dd43ec64a8c70c483d8a2cb5b3bffc8bd838e1b1e',1998,'CK','Cook Islands','space',1013,'CW
CK
COK
184
CK
Coral Sea Islands
CR
—
—
—
—
ISO includes with Australia
21 12 S
159 46 W
Axel Heiberg Island
10 53 S
165 49 W
Danish Straits
Atlantic Ocean
58 00 N
11 00 E
Danish West Indies
Virgin Islands
18 20 N
64 50 W
Danzig (Gdansk)
10 53 S
165 49 W
Pusan [US Consulate]
South Korea
35 06 N
129 03 E
Pyongyang
North Korea
39 01 N
125 45 E
Q
Quebec [US Consulate General]','875c5a78ac7e593082eecf1a5c0917d465a5ade54a46d1a6dd9320ceea544bee','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e30bd0c00bba2edadb83937ae646cda79f8c2dd7dc8c5f95fe3ef6c302ff38d8',1998,'CR','Costa Rica','space',1014,'cs
CR
CRI
188
CR
Cote d''Ivoire
IV
Cl
CIV
384
Cl
5 32 N
87 04 W
Cocos Islands
956 N
84 05 W
San Juan','419b5b2ba8fb173da3b036b474c0974616fef1b6239a75335ae1900afc87f5bb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d43dd49877c7138176fb670f5ce236f35586a7a130caf3df099a27ef5e67d18',1998,'HR','Croatia','space',1015,'HR
HR
HRV
191
HR
43 00 N
17 00 E
Daman (Damao)
42 24 N
18 31 E
Pribilof Islands
45 48 N
1558 E
Zaire
Democratic Republic of the Congo
15 00 S
30 00 E
Zanzibar [island]
Tanzania
6 10 S
3911 E
Zion, Mount
Israel, Jordan
31 46 N
35 14 E
Zurich
•Wn Pod8oricv
Kotor
/ ^ Kosovs ka ^
V Mitrovica
JC ^Pristina
Kosovo’ ?”“•)
Dakovica Gnjilane. _/>_/
(Djakovica) Urosevac /'' ''
|B»
Pemlk*
Tetovo Skopje
>4 o'' r / a £ /
Shengjin f
Hy
THE FORMER YUGOSLAV
REPUBLIC OF MACEDONIA
Priion Stnfmica
Scale 1:3,550,000
Lambert Conformal Conic Projection,
standard parallels 40 N and 56 N
Serbia and Montenegro have asserted the formation of a ji
: independent state, but this entity has not been formally
I recognized as a state by the United States.
K. ALBANIA A
f Lushnje t U
t ; 88rat#.i
Bitoia
Lake
\\Ere^
LEdbessa • \\
7SI
Tvior^
\\ Strait of
Otranto \\ r\\± ~ ±
*i Otranto
''^fewrn ;
Kosrfm. i /Kstertnl ■ 7
x R t E C E _ ■
..KozifiL
Therm aikos
K6lpos
802587 (R02592) 6-98
ROM. Bucharest UKR.
_ - / | SevastopolV ''\\
W^hl —
* Krasnodar
RUSSIA
r 1 ''
jS.'' KAZAKHSTAN','b39cb049db7c498d7721e64ff9e2a8f1d346ab394aa861a3c6ef004330cc0ad6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8d5de98f71260b1c54c34f7408c0d6731f5cd670d9c1d97e2d7496612e89b82',1998,'CU','Cuba','space',1016,'CU
CU
CUB
192
CU
20 00 N
75 08 W
Guatemala [US Embassy]
23 08 N
82 22 W
Hawaii
21 40 N
82 50 W
K
Kabul [US Embassy now closed]
21 40 N
82 50 W
Pleasant Island
21 40 N
82 50 W
Yucatan Peninsula','c51f8754b566d5a30d4f721a8dfc096d9136504d2664c2df7b158ec36732e3f9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('276be92c9f2982aa14fe6310e19480ea60073fe552c5eed4559cac3fce42e06b',1998,'CY','Cyprus','space',1017,'CY
CY
CYP
196
CY
Czech Republic
EZ
CZ
CZE
203
CZ
35 ION
33 22 E
Leipzig [US Consulate General]
35 10N
33 22 E
Nightingale Island
Saint Helena
37 25 S
12 30 W
Nomoi Islands (Mortlock Islands)
Federated States of Micronesia
5 30 N
153 40 E
North Atlantic Ocean
Atlantic Ocean
30 00 N
45 00 W
North Channel
Atlantic Ocean
55 10N
5 40 W
North Frisian Islands
Denmark, Germany
54 50 N
8 12 E
North Island','1232d504a7e1084a3c21aef6bb4b38a9dccc196c19f351e9315b2ee058ef85d8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88e61297d8574b547b0a6c94852895ea7c7d611432ff67b5554df84c52b5b6db',1998,'DK','Denmark','space',1018,'DA
DK
DNK
208
DK
55 10N
15 00 E
Bosnia
55 40 N
12 35 E
Coral Sea
Pacific Ocean
15 00 S
150 00 E
Corfu [island]
56 00 N
9 15 E
Juventud, Isla de la (Isle of Youth)','fec7aebe0ed12240bbc242699b8bc5281ef7b05380731b25df450de45ab2e2f9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('187e5d9f4bf96202ac609f3b69ea60df797abd19fed8d248b9df1ae60bc2ae0e',1998,'DJ','Djibouti','space',1019,'DJ
DJ
DJI
262
DJ
602
Entity
FIPS 10-4
ISO 3166
Internet
Comment
11 30 N
43 00 E
Agalega Islands
11 30 N
43 15 E
Dnieper [river] (Dnyapro, Dnepr, Dnipro)
Belarus, Russia, Ukraine
46 30 N
32 18 E
Dniester [river] (Nistru, Dnister)
Moldova, Ukraine
46 18 N
30 17 E
Dodecanese [islands]
11 30 N
43 00 W
French Sudan
11 30 N
43 00 E
French Togo','17326cf0c00a0a52a5a567a3ac76bac5d8ee8ce5bf45ed5840c10c555a3d1a1d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3263005532c29267310b0ee92f4d8d941f020b66aee09b52b9bbff0e7d4907f',1998,'DO','Dominican Republic','space',1020,'DR
DO
DOM
214 .
DO
East Timor
—
TP
TMP
626
TP
FIPS includes with Indonesia
18 28 N
69 54 W
Sao Paulo [US Consulate General]','f2a2c350a321389eae2a8f906a746aa6e367feb167774f47ceb45d1bc317a43f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a18f0e109240370474f0421af64b91c3467cdfe04e04c973cbd131c8cf46eca4',1998,'EC','Ecuador','space',1021,'EC
EC
ECU
218
EC
0 00 N
90 30 W
Commander Islands (Komandorskiye Ostrova)
Russia
55 00 N
167 00 E
Conakry [US Embassy]
0 00 N
90 30 W
Galilee [region]
2 13 S
79 54 W
H Ha’apai Group
0 13 S
78 30 W
R
Rabat [US Embassy]','31cf43bfbb4249dd06c10a381a6daae883700c4726613357ba3e07687a522ae6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20983ad12c2ee0d5c1bbc557400d60c50908cdfdb24df1f696ccc95cf9cfbb72',1998,'EG','Egypt','space',1022,'EG
EG
EGY
818
EG
31 12 N
29 54 E
Algiers [US Embassy]
30 03 N
31 15 E
Calcutta [US Consulate General]
30 13 N
33 09 E
Gilbert Islands
30 20 N
32 23 E
Great Britain [island]
30 02 N
32 54 E
Mogadishu
29 30 N
34 00 E
Singapore [US Embassy]
29 55 N
32 33 E
Suez, Gulf of
Indian Ocean
28 10N
33 27 E
Sulu Archipelago
x ■ \\ / ^Ahvaz ;
An NajinyS*'' - '' S Abadar.
Al Basrah -v;^ ^
VS^ ~7JSL | \\B0shehr
^ KUWAIT j ^
*yafar \\ i S
al Batin \\ i ”‘V
S> | Psrs*m
Al JubayTVJ Gulf
Buraydah Ad Dammam''. Manama
• Dhahranlf ★
BAHRAIN* /QATAR
in* IRAN
Yanbu’ |
^alBahr .Medina
. t" .
- - "V L/UDai \\/
U ^ Doha /aw,
SAUDI H^->ha
\\jr\\\\J Ly I \\ UNfTED ARAB
X/''V'' Administrative r-/
n- Boundary /
ARABIA
-''^^Dhabi "X''v. Muscat
V UNfTED ARAB / “‘“W*
v - - - - •. boundary
A EMIRATES
De Facto Boundary\\','7a619c9bb137d08cc0d4399794c6bf3257e5371a4a6cc485764846d3c069cb0f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edd46dd9c12529a1a330147cf91f996799a7b4696401233695f0d560c7e25de7',1998,'SV','El Salvador','space',1023,'ES
SV
SLV
222
SV
13 42 N
89 12 W
Santa Cruz
Bolivia
17 48 S
63 10W
Santa Cruz Islands
Caribbean
\\Sea
802582 (R02067) 6-98','b221140f468cf87a36dea208dcb6a3f29caa97d3d50838f831c9ddb0af284877','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59a8850d22e2ea464e3a4f6e6a1cade1a6be7c916c5aa300be4974c2bf5a708c',1998,'GQ','Equatorial Guinea','space',1024,'EK
GQ
GNQ
226
GQ
1 25 S
5 36 E
Antananarivo [US Embassy]
3 30 N
842 E
Biscay, Bay of
Atlantic Ocean
44 00 N
4 00 W
Bishkek [US Embassy]
055 N
9 19 E
Cosmoledo Group (Atoll de Cosmoledo)
0 59 N
9 33 E
Enderbury Island
3 30 N
8 42 E
Finland, Gulf of
Atlantic Ocean
60 00 N
27 00 E
Florence [US Consulate General]
345 N
847E
Malacca, Strait of
Indian Ocean
2 30 N
101 20 E
Malagasy Republic
1 30 N
10 00 E
Riyadh [US Embassy]
2 00 N
10 00 E
Spanish Morocco','ae00148379d3afb534d1800814bfd1b25701aab69fdac3e7b1652541502d6881','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f00793f2d085613c20129c9f4a061d89128088729fbc4ef298c21e240abd4285',1998,'ER','Eritrea','space',1025,'ER
ER
ERI
232
ER
15 20 N
38 53 E
Asmera (see Asmara)
15 20 N
38 53 E
Assumption Island','5fd1bb3489780284f4d9b83d07930a0cc99b55c0e6157de07b92a56e78436bac','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb543efc65b78105f4ab88ec68abcd1f90a360b5518db7f04bf83072e3e1027b',1998,'ET','Ethiopia','space',1026,'ET
ET
ETH
231
ET
Europa Island
EU
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
Falkland Islands (Islas Malvinas)
FA
FK
FLK
238
FK
800 N
38 00 E
Acapulco
902 N
38 42 E
Adelie Land (Terre Adelie) [claimed by France]
*Hargeysa SOMALIA
Provisional /
Administrative Line
f
I * Israeli-occupied with current status subject to the Israeli-
Palestinian Interim Agreement - permanent status to be
determined through further negotiations.
802588 (R02107) 6-98
Africa
802589 (R02109) 6-98
Central Africa
Asia
802591 (R02105) 6-98
Commonwealth of Independent States
802592 (R02110) 6-98
Chengdu^
Chongqing
Zigong*
Shanghai Easf
CHINA ,
Hangzho^^/w*
Wen2hbu aA
Kunming^ j
FuzhouJ^j
V Akyeb BURMA
\\jSittwe) \\
-20-^r—~\\ - — it
^ Ja ipei
Xiamen^ ^ / (.
L*yW Shantou^r .>/ / /
^-^^X^:~Quangzhou--jr— — — / -
annina Kao-hsiungL / Taiwan
ianmng J^BTHong Kong SAR. V-
^Ztanjan^^ teau
<0
Okinawa * ^
Naha* ^ ^ ,
^ 0 o/i/ro-
. i SHOTO
j L ^ V) . (JAPAN)
^ Tropic of Cancer
: 5; BONIN ,
O ISLANDS ,
Pratas . ,
''Island \\Luzon ,
flanpoon;, I ^
Basse^Wo^eiiV Ihailand
TaV%\\ '' Ban9kok
Nakhon ,
• Ratchasima
f Hainan
J Dao
Hue '' ^ PARACEL
\\Da Nang J *SLANDS
> VIETNAM
» * BABUYAN ISLANDS
AMBOQIA / Nha 1
South
PHIL I jP
SOd **: '' , ’ * i I o
Philippine
Sob
S Gulf of '' LohgS
-J Thailand
ISLANDS phuket
(g (INDIA)
George Tow ti jb&fS^v
* tern
Pulau Simeulue
|||||||UVYSIA
5, I KUaiai-umpur
''HvqV- x
A. KEPULAUAN
V NATUNA
ngapore
as y} Wjj ^SINGAPORE
* ^ Pu/au „
S iberut% %r
'' ''
Bandar Seri /Kota Kinabalu
Begawan . ■.
[NAYSIA. J X
UiV^fneo
&
W Halmahera
kXtt&A .■■■ Samarinda.i Jfali
M.AU1 ‘J / ^
^ \\palembang *
Bil/ito
Tahiqhgkararig- (
Teluktoturig ;
* Jakarta
eu
Java Sea Ujungpandang M
I N D 0 N&fc S I A
SSNOSSS/V _ Madura Floral Ron
North
Pacific
Ocean
New Guinea
Java *iSufafeaya ^ Lombok
| J PAPUA
j \\ NEW
•F-x''Souinea','101988bce64921042b8e467542a62faec228cae885ee70ab64003acedbb34e74','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ec47f0fad00bbcd7abb647859ff57956fc6bffe0ce93669adda87fb1d6f96dd',1998,'FJ','Fiji','space',1027,'FJ
FJ
FJI
242
FJ
18 20 S
178 30 E
626
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Lefkosa (see Nicosia)
12 30 S
177 30 E
Ryukyu Islands
18 08 S
178 25 E
Sverdlovsk (see Yekaterinburg)
Russia
56 50 N
60 39 E
Swains Island
18 00 S
178 00 E
Vladivostok [US Consulate General]
Russia
43 10N
131 56 E
Volcano Islands','c12d00ef109c2212a45f0d2e472eea5d07953b367bcbe4c69de0bc9a15d6cdc7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75a3682d9a1a6cede721bacd6e0e2358b03a1605bee9eb9a56cd2d9a6efc646b',1998,'FI','Finland','space',1028,'FI
FI
FIN
246
FI
60 15 N
20 00 E
Alaska
60 10N
24 58 E
Hermosilio [US Consulate]
Lake
\\ Onega
0 c e a n','cf9e8e2719e7c67cb8be2e8151d7e904f2d0a2047fdac6defe2ad99b1b06900d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59fe1f17d96c0ff95b1f88cd69de1a615ffd7557bd557d0d9e464bbe0f813251',1998,'FR','France','space',1029,'FR
FR
FRA
250
FR
France, Metropolitan
FX
FXX
249
FX
ISO limits to the European part of
France, excluding French Guiana,
French Polynesia, French Southern
and Antarctic Lands, Guadeloupe,
Martinique, Mayotte, New Caledonia,
Reunion, Saint Pierre and Miquelon,
44 50 N
0 34 W
Borneo [island]
Brunei, Indonesia, Malaysia
030 N
114 00 E
Bornholm [island]
42 00 N
900 E
Corsico [island]
43 18 N
5 24 E
Martin Vaz, llhas
48 52 N
2 20 E
Pascua, Isla de (Easter Island)
48 35 N
745 E
Stuttgart','9fde920c8c46fd0636ced98f70a0aca24b08d707c8f6625c434dcd30b7339135','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('566997198e4031a6c86f8a10a861b406c21676e2bc4fa66ccbadd3c8df046ead',1998,'GF','French Guiana','space',1030,'FG
GF
GUF
254
GF
4 56 N
52 20 W
Cebu [US Consular Agency]
5 17 N
52 35 W
Devon Island
5 20 N
52 37 W
Sahel
Burkina Faso, Cape Verde, Chad, The Gambia,
Guinea-Bissau, Mali, Mauritania, Niger, Senegal
15 00 N
8 00 W
Saigon (see Ho Chi Minh City)
Vietnam
10 45 N
106 40 E
Saint Brandon (Cargados Carajos Shoals)','ba86e880d5b2db3915ad4f0c1eaf31a31bd0caa2def275403bf5bc71e5e63108','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d8eefe71f339ceeacb34a98bf5c8adb1e9bcc19eef0220e41fea241999bea2a',1998,'PF','French Polynesia','space',1031,'FP
PF
PYF
258
PF
ISO includes Clipperton Island
French Southern and Antarctic
Lands
FS
TF
ATF
260
FIPS 10-4 does not include the French-
claimed portion of Antarctica (Terre
Adelie)
23 20 S
151 00 W
615
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Avarua
16 30 S
151 45 W
Bordeaux
23 09 S
134 58 W
Gaspar Strait
Pacific Ocean
3 00 S
107 00 E
622
Latitude
Longitude
Name
Entry in The World Factbook
(deg min)
(deg min)
Geneva [US Consular Agency, US Mission
9 00 S
139 30 W
Marseille [US Consulate General]
17 32 S
149 34 W
Paramaribo [US Embassy]
17 00 S
150 00 W
Socotra [island]
17 37 S
149 27 W
Taipei
Taiwan
25 03 N
121 30 E
Taiwan Strait
Pacific Ocean
24 00 N
119 00 E
Tallinn [US Embassy]
19 00 S
142 00 W
637
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry In The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Tubuai Islands (lies Tubuai)
2300S
150 00 W
Tunb al Kubra [island]
Iran
26 14 N
55 19 E
Tunb as Sughra [island]
Iran
26 14 N
55 09 E
Tunis [US Embassy]
(FRANCE)
Rapa
Pitcairn Islands
(U.K.)
i Atorf/?
fcJC*Ja\\]’1 Island
Hamilt
South Pacific
Ocean
> Wellington
•;,v/
p*£hrfstchurch
South Island
\\ CHATHAM
■ /SM/VDS
(N.Z.)
Scale: 1:36,000,000 at 30*S
Mercator Projection
0 500 KHometer*
Mi1 V-W — i - 1
0 500 Mties
802594 (R02111) 6-98
Nor t fry Pacific
/ Ocean \\
/ J''y*
Bering Sea
Whitehorse*.
4Vj -Anchorage J
3 ^UNITED SJATES "
v Fairbanks . „ay ^ . r/,.
/O5 1 Provideniya rfAnadyr1
cCL»r-wf*
Petropavlovsk- ,
Kamchatskiv/
\\i jVda|
.occupied by th/Soviet Union in 1945, V > \\
-r0^ administered b/Russia, claimed by Japan. '' A u •
f V''''^> Chukchi
J Sea
% .
Pevekf\\Cherski*.
Cp Wra/rc/e/
1 /s/antf
?£&
(C\\ .
/■./&**» :fis
> / Jt~pa- Echo Ba^} '' v/ X
\\^Ye,,°wknife f S
* ''■ y f : :■ •: • w<Sreaf S/ave J?" A /S— /
,44 , *
/tCbe^SAca . J- f ■ f/J ■
I 7!%t£ji
® Tiksi} i
K^igiqclini4
''Mfankin inlet)
2% cic
Isa
Arctic
0 c e a n
\\ i /
Hudson ^
Bay ^
CP35K
5 10\\C (50\\F) isotherm
\\ My
R| U S'' S I A
i
#Noril’sk \\*£nisey/^
^Y3w
5s vn \\ .
\\. , ;V 5/ iqaMt
Baffin %
Bay
r( Mm*
<f^x
df (Frob£fl*Ba^ \\
vtJ ^
» * %
Daws Strait^ J>\\
i, ~ — - — v Svalbard
Long rearby«| % (NORWAY)','cb45026cd8254342599f9350112dee1409db93f8fc211c884b2931a7deadf8e1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0db4c3a203ff158071bfc2e45ccb37c0bc05beb1db708824252ac1e9346dc54',1998,'GA','Gabon','space',1032,'GB
GA
GAB
266
GA
The Gambia
GA
GM
GMB
270
GM
Gaza Strip
GZ
—
—
—
—
0 23 N
9 27 E
Ligurian Sea
Atlantic Ocean
43 30 N
900 E
Lilongwe [US Embassy]','f4f276c0fecace737da2520398fd2148a9d0f0f8e0df501684581de3982fd361','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2adcc8c92f03917e7b8b757f5849ba7810e094b477bb645ec64ba38663d5f820',1998,'GE','Georgia','space',1033,'GG
GE
GEO
268
GE
43 00 N
41 00 E
Abu Dhabi [US Embassy]
42 20 N
44 00 E
South Pacific Ocean
Pacific Ocean
30 00 S
130 00 W
South Sandwich Islands
41 43 N
44 49 E
Tegucigalpa [US Embassy]
41 43 N
44 49 E
Tien Shan [mountains]
China, Kyrgyzstan
42 00 N
80 00 E
Tierra del Fuego
Argentina, Chile
54 00 S
69 00 W
Tijuana [US Consulate General]
Caspian
Sea
Ml
_
TURKEY
Vv * \\ I
LEBANON^Damascus
Haifa JlT, OolM .
ISRAELff^g^
\\ V^Baahdad^
Kermanshah
Arak* :
- - i^S{em^W}ORD^\\
Al Jizah*y . TffSfiar- .
f i \\\\ jt’Aqabaiy"
i raV
//SftSf .TabQk
A','8e431c2f5fecccfc6c01ab1c21eefee4c84c24f94ea3afe6b06cf9ad72bfb048','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77e0135cd6207b3919013a64ad2b52627b7964903d85ff95ed27f63dae009564',1998,'DE','Germany','space',1034,'GM
DE
DEU
276
DE
48 30 N
11 30 E
Beagle Channel
Atlantic Ocean
5453 S
68 10W
Bear Island (see Bjornoya)
Svalbard
74 26 N
19 5 E
Beaufort Sea
Arctic Ocean
73 00 N
140 00 W
Bechuanaland
52 31 N
13 24 E
Berlin, East
52 30 N
1 3 33 E
Berlin, West
52 30 N
1 2 20 E
Bern [US Embassy]
48 00 N
8 15 E
Black Rock
50 44 N
7 05 E
Bophuthatswana
53 44 N
7 25 E
East Germany (German Democratic Republic)
52 00 N
1 3 00 E
East Korea Strait (Eastern Channel or Tsushima Strait)
Pacific Ocean
34 00 N
129 00 E
East Pakistan
50 07 N
8 40 E
Franz Josef Land [islands]
Russia
81 00 N
55 00 E
Freetown [US Embassy]
52 00 N
13 00 E
German Southwest Africa
51 00 N
900 E
53 33 N
9 59 E
Hamilton [US Consulate General]
51 19 N
12 20 E
Lemnos [island]
48 09 N
11 35 E
Musandam Peninsula
Oman, United Arab Emirates
26 18 N
56 24 E
Muscat [US Embassy]
51 00 N
13 00 E
Schleswig-Holstein [region]
54 31 N
9 33 E
Scopus, Mount
Israel, West Bank
31 48 N
35 14 E
Scotia Sea
Atlantic Ocean
56 00 S
40 00 W
Scotland [region]
48 46 N
911 E
Sucre
Bolivia
19 02 S
65 17 W
Suez Canal
51 00 N
11 00 E
Thurston Island
53 22 N
520E
West Island','26affef5feaa587dd69fafe7877aced5a1d89234740a18e2aae42787c7ba3439','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7028ca2b4cc7cea4e7ecf5db74fa35e8a28c6e42e9fe5667b59836b86ff457f4',1998,'GH','Ghana','space',1035,'GH
GH
GHA
288
GH
533 N
0 13 W
Adamstown
Pitcairn Islands
25 04 S
130 05 W
Adana [US Consulate]
Turkey
37 01 N
35 18 E
Addis Ababa [US Embassy]
8 00 N
2 00 W
Golan Heights [region]
Syria
33 00 N
35 45 E
Good Hope, Cape of','8e65596600ba716c1f54abbd86fb9eadd5f07e36a8abb5be3371d13621c84fa8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1c2d283dc65c1c792ba28dba8b96a54def2249527668869618ebff8cb3739f9',1998,'GI','Gibraltar','space',1036,'Gl
Gl
GIB
292
Gl
Glorioso Islands
GO
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
3611 N
5 22 W
Gibraltar, Strait of
Atlantic Ocean
35 57 N
5 36 W
Gidi Pass','cf7f495454b4bbfc1e9b834c471747909ea4e9ad0d5e70c3b8407e3b6653d525','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5145ccd217dbd5a9fa81bda8490be6b72dc360230f3be3ece269b862ba6dbdf',1998,'GR','Greece','space',1037,'GR
GR
GRC
300
GR
38 00 N
25 00 E
Aegean Sea
Atlantic Ocean
38 30 N
25 00 E
Afars and Issas, French Territory of the (F.T.A.I.)
37 45 N
24 42 E
Andros Island
The Bahamas
24 26 N
77 57 W
Anegada Passage
Atlantic Ocean
18 30 N
63 40 W
Angkor Wat [ruins]
37 59 N
2344 E
Attu Island
39 40 N
19 45 E
Corinth
37 56 N
22 56 E
Com Islands (Islas del Maiz)
35 15 N
24 45 E
Crimea [region]
37 00 N
25 10 E
Czechoslovakia
Czech Republic, Slovakia
49 00 N
18 00 E
D Dahomey
36 00 N
27 05 E
Dodoma
Tanzania
611 S
35 45 E
Doha [US Embassy]
38 30 N
20 30 E
Ionian Sea
Atlantic Ocean
38 30 N
18 00 E
Irian Jaya [province]
39 54 N
25 21 E
Leningrad (see Saint Petersburg)
Russia
59 55 N
30 15 E
Lesser Sunda Islands
39 15 N
26 15 E
Leyte [island]
36 10N
28 00 E
632
Name
Latitude
(deg min)
Longitude
(deg min)
Entry in The World Factbook
Rhodesia Zimbabwe 20 00 S 30 00 E
Rhodesia, Northern
37 48 N
26 44 E
Sanaa [US Embassy]
40 38 N
22 56 E
Thimphu','e4f03626561651fd317f922a5d42c93cf154bd126bc2f7cdc473531d9197a186','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec888407acb9300ae01e621c1ef11feb9751118e755a114e0480ba9e492965db',1998,'GL','Greenland','space',1038,'GL
GL
GRL
304
GL
6411 N
51 44 W
Gold Coast
6411 N
51 44 W
Nyasaland
(DENMARK)
Dennis rh
Strait "■
Jan Mayen
(NORWAY)
Serbia and Montenegro have asserted the formation
of a joint independent state, but this entity has
not been formally recognized as a state by the
United States.
F.Y.R.O.M. * The Former Yugoslav Republic of Macedonia
Barents
Cpp\\
aC
Nerwaoic,
Torshavr>- ; Faroe |Slands
(DENMARK) /
^ \\ /
Kangerlu$$ua<|\\ /
\\ (Sgndre Stnamfjord)''. /( vf,$.
\\ Nuuk \\ jv / \\., w
\\Paamiut / (Godthab) '' \\ ‘SSSfeiS 5
(Frederikshab)£ T ... " .. (ScoreSby^upd) >
\\ \\ f (AmnS^IH^^^^
ILabrador \\ x /
Denmark Strait
vU £>J‘ 1 Bj0rn0ya ,
vW) Greenland (Norway)
o/A/
^ Jan Mayan
(Norway}
Z/ L Arkhangelsk
Reykjavik
- C/rc/e
Norwegian. /
|5ea,X
X/Vorf/? Atlantic Ocean''
\\ /
Scale 1:39,000,000 /
Azimuthal Equal-Area Projection
0 500 Kilometers
I i , « ■■ ir- 1--H - , - ,
0 N 500 Miles
The Arctic region is often defined as that area where the
average temperature for the warmest month is below 10*C.
Faroe
Torshavn. Islands
W (DENMARK)
Lake
ir
Kazan’
Onega
d)
^ A
%
~Y ;
Nizhniy
A Ladoga
%
Novgorod
I ? ^A-rX .
pf / v ia*e / Nizhniy \\
^ xS^p Ladoga Novgorod 1
. SWEDEN Petersburg^ ^Moscow $aratov<i
North CoPffl
^tockhg^
x '' $ ®
Ct ''V Ba,tic jBi
''fiasenl ^ 5ea 1^
^,p- Berlin
GERMANY ★
Warsaw*
%/A Jpolgoi
,A Kharkiv S J
iiS''.jNOL // (//Rostov
OniprOji 7i
/^KRAINE
_ . 30 -v/ ^%r fifecA- 5e
Antarctic Region
I Year-round research station
Scale 1:68,000,000
Azimuthal Equal-Area Projection
0 500 1000 Kilometers
Nineteen of 26 Antarctic consultative nations have made
no claims to Antarctic territory (although Russia and the
United States have reserved the right to do so) and do not
recognize the claims of the other nations.
South Georgia and the
''''South SandwichJslands
(administered by U.K.,
claimed by ARGENTINA) -
\\
South | Atlantic
Ocean
ARGENTINE
BRITISH
CLAIM
r Falkland Islands
ttetas Malvinas) /
(administered by U.K./
claimed by ARGENTINA)','5b3dee9bb8b4e20b081cec61dc1cd513293619f1a50118988da64f8c6a4ecf7b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97dfd02ae6bcc4d9930d00968d8082c9a78cb6a99c1a26660c236367d52e3b54',1998,'GD','Grenada','space',1039,'GJ
GD
GRD
308
GD
12 07 N
61 40 W
Grytviken
12 03 N
61 45 W
Saint George’s Channel
Atlantic Ocean
52 00 N
6 00W
Saint Helier
12 20 N
61 30 W
Southern Rhodesia','d22396280fb4096d9311a29b7e8cf0b8279b96376f60505168ab70bee923aec2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('086a8a1844b4addde2b8d86d66bc2e27b0608eb5cab6df0c2f2071f628374ff1',1998,'GP','Guadeloupe','space',1040,'GP
GP
GLP
312
GP
16 00 N
61 44 W
616
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Basseterre
18 04 N
63 04 W
Saint Martin (Sint Maarten)
Netherlands Antilles
18 04 N
63 04 W
Saint Paul Island
(FRANCE)
DOMINICA a
Roseau^','c83c46318a2cbd01ea624973c78dc1366ba4bbf6bd66aee0d58fb89122157f9e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47ebf28cb50aea4d4fe53ae1e3b9ed302df1db7d2624a0f6e0a05bd5d8c9b7e5',1998,'GU','Guam','space',1041,'GQ
GU
GUM
316
GU
13 28 N
144 45 E
Ajaccio
France (Corsica)
41 55 N
8 44 E
Akmola (see Astana)
13 28 N
144 45 E
Hague, The [US Embassy]','91fe0965d9d79a6599beeedcc29d16b0577cce7f3f0046524863fdd3bf9ad5da','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44e6e50404305b069f14128841fa7efcb86069911eb2802c8770508d450c5354',1998,'GT','Guatemala','space',1042,'GT
GT
GTM
320
GT
14 38 N
90 31 W
Guinea, Gulf of
Atlantic Ocean
3 00 N
2 30 E
Guayaquil [US Consulate General]
San Salvador','ae569fe6c310b7c3212ffd492b10cb65de6797a21faece61e43dc8b68cacd2fe','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1d7c5946dddb20bf6a192358cb1bfc997474f6b66b299d9b54739a5a5bbae60',1998,'GG','Guernsey','space',1043,'GK
—
—
—
ISO includes with the United Kingdom
49 43 N
2 12 W
Aleutian Islands
United States (Alaska)
52 00 N
176 00 W
Alexander Archipelago
United States (Alaska)
57 00 N
134 00 W
Alexander Island
49 27 N
2 32 W
Saint Petersburg [US Consulate General]
Russia
59 55 N
30 15 E
Saint-Pierre
49 26 N
2 21 W
Saxony [region]','9405d19b00f8d5d3c162ba0e4e7c80114440eaeda2976b0e5a85c9179ef77fd5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d355ebdc423d1c283a3fcb94455a7e10944d891f32ef245d824426849dc6adec',1998,'GN','Guinea','space',1044,'GV
GN
GIN
324
GN
9 31 N
13 43 W
Congo (Leopoldville)
Democratic Republic of the Congo
15 00 S
30 00 E
Con Son [Islands]
Vietnam
8 43 N
106 36 E
Cook Strait
Pacific Ocean
41 15 S
174 30 E
Copenhagen [US Embassy]
11 00 N
10 00W
French Indochina
Cambodia, Laos, Vietnam
15 00 N
107 00 E
French Morocco','879d4c660750d989b620a53aa9c97787e55f34999b84d4cf4b45426113846aee','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b49ba267974073d1eaea14d0efe1fac06aaca877740d43c2a9fc99859901ad42',1998,'GW','Guinea-Bissau','space',1045,'PU
GW
GNB
624
GW
603
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
11 25 N
16 20 W
Bikini Atoll
11 51 N
15 35 W
Bjornoya (Bear Island)
Svalbard
74 26 N
195 E
Black Forest
12 00 N
15 00 W
Portuguese Timor (East Timor)','24e89c3932de3f901e61bf68e43d6e11c940ebeac391c7279416d0d321dcca79','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7f0848bf05cba53960f8a958d78d57065a13cf9c827d819e100a45e0cfe691c',1998,'GY','Guyana','space',1046,'GY
GY
GUY
328
GY
5 00 N
59 00 W
British Honduras
6 59 N
58 23 W
Etorofu (Iturup) [island]
Russia [de facto]
44 55 N
147 40 E
F
Farquhar Group (Atoll de Farquhar)
6 48 N
58 10W
German Democratic Republic (East Germany)','e11fe9ffc6f2860b3ab0ef26ee03dc51ca856bb57bc07b51fd006a27a38835b7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccb56d8a5bbb6b45e960be939fe2d32b3252eea38c208a8133401c657fd1ad28',1998,'HM','Heard Island and McDonald Islands','space',1047,'HM
HM
HMD
334
HM
Holy See (Vatican City)
VT
VA
VAT
336
VA
5306S
73 30 E
Hejaz [region]
53 06 S
73 30 E
Mecca
5300 S
72 30 E
Shag Rocks','20f0ef435e4c0f98b1cf63ee221e6226bd86142d63fa18a0ba06b9fd1f65508a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be1b873e8254307f2ebd7b64963337040a187a502cd8c0af829b8af99d2a19b9',1998,'HN','Honduras','space',1048,'HO
HN
HND
340
HN
17 25 S
83 56 W
Sydney [US Consulate General]
14 06 N
87 13 W
Tehran [US post not maintained; representation by
Swiss Embassy]
Iran
35 40 N
51 26 E
Tel Aviv [US Embassy]','6c8cc98a7cdcf66abecdcfbf89064eafc1c5995376f0ec58ccbfde171835b6d0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67ec66e7c7736d546964b0b18a38d2761db7f666e8b3989076578567f9866f8a',1998,'HK','Hong Kong','space',1049,'HK
HK
HKG
344
HK
Howland Island
HQ
—
—
—
ISO includes with the US Minor
Outlying Islands
22 15 N
114 10 E
Honiara
22 18 N
114 10 E
Kra, Isthmus of
Burma, Thailand
10 20 N
99 00 E
Krakatoa [volcano]
22 24 N
114 10 E
New York, New York [US Mission to the United
22 17 N
1 1 4 09 E
Victoria','747c3b3a2029c793fec305bfad56eb0ccd1912cb08fc51ae50947f1b5ef7c17c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efb24aafe1477507f41aa09454548fca567843fccb440b0441b5ead792555bf3',1998,'IS','Iceland','space',1050,'1C
IS
ISL
352
IS
19 00 N
111 30 W
Rhodes [island]
SHETLAND
ISLANDS j
. ^ORKNEY :
0J / 5> ISLANDS !
HEBRIDES f
0.~ . !
/Aberdeen /
J I
/
/%( l I
Dublin^
A hirv ; C''-''—ii, •Mancfi^fter
AND/ > Liverpool
^^^^gSWEDEN,/ Gtt/f V ..
\\ Helsinkk./^ " ^
fi’u!
RUSSIA J
a jl LATVIA
Riga *
’ DENMARK \\ r~^
Sj Copenhagen
C '' /’ Bornholm
fidtondiC ^ VVmolensk
^ MinskJ
MaWljr6wV§
Minsk *|
* . ★•■■■■■ <■■ Va
BEIARUSM
KINGDOM,^- x • kv-w J Warsaw / Brest
''"4- ;.r-rfflE )“ Vr-rot«(b\\ ‘f’
^Londonji^ Leipzig/^C . ''.Wro^ \\ N
£wte/c;.»p ..J#! / *L
L) , v-~, TiPw 1 . Frankfurt ■; Y ■■ Vje^r l^rakow (
hW^ : %WLUxemb/rgamMa''n \\ CZECH REPUaiCi(iMw|®|^ C
wi : i V^Par*. uS\\T V .^J Bmo«
-'' ■ ••.••'' " ''•■/•’ /''//*'''''' . // SWttbouitflfv Munich / C
V''^ f * C Vienna TVs-^Budapest j N3
V / \\ /*0^^^AUST^ HUNGARY J j
London ★ <
Rotterdara^p ''
English Channel J UJte<
Guernsey (U.K.) v - ''
Jersey (u.k.) « .• /
^ , ,, 1 •
T .-«L','e0a8b5e185342ab46682c2ca891d4bd92e56e7509835b95beef5a121aa54ae85','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef696e06160eba068eb0e520203344026621ee45541ff18cd901acc3735c5093',1998,'IN','India','space',1051,'IN
IN
IND
356
IN
11 30 N
72 30 E
Amirante Isles (Les Amirantes)
12 00 N
92 45 E
Andaman Sea
Indian Ocean
10 00 N
95 00 E
Andorra la Vella
23 16 N
77 24 E
Biafra [region]
18 58 N
72 50 E
Bonaire [island]
Netherlands Antilles
12 10 N
68 15 W
Bonifacio, Strait of
Atlantic Ocean
41 01 N
14 00 E
Bonin Islands
22 32 N
88 22 E
Calgary [US Consulate General]
13 04 N
80 16 E
Chesterfield Islands (lies Chesterfield)
20 10N
73 00 E
Damascus [US Embassy]
Syria
33 30 N
36 18 E
Danger Islands (see Pukapuka Atoll)
20 42 N
70 59 E
Djibouti [US Embassy]
14 20 N
74 00 E
Godthab (Nuuk)
32 42 N
74 52 E
Jammu and Kashmir [region]
India, Pakistan
34 00 N
76 00 E
Japan, Sea of
Pacific Ocean
40 00 N
135 00 E
Jars, Plain of
Laos
19 27 N
103 10 E
Java [island]
10 00 N
7300 E
Laccadive Sea
Indian Ocean
7 00 N
7600 E
Lagos [US Embassy]
10 00 N
7300 E
La Paz [US Embassy]
Bolivia
16 30S
68 09 W
La Perouse Strait
Pacific Ocean
45 45 N
142 00 E
Laptev Sea
Arctic Ocean
76 00 N
126 00 E
Las Palmas
13 04 N
80 16 E
Madrid [US Embassy]
8 17 N
73 02 E
Minsk [US Embassy]
18 58 N
72 50 E
Munich [US Consulate General]
28 36 N
77 12 E
New Guinea
Indonesia, Papua New Guinea
5 00 S
140 00 E
New Hebrides
8 00 N
93 30 E
Nicosia [US Embassy]
27 50 N
88 30 E
Sinai Peninsula','12b20e3387df23b4557c00093e39dfcad9c06c3410f7e330dae279b6d77f1b39','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc731b9844ba4bfe0059b6776374c28a85bd386cd24259b4d124cb7eeabe0dfd',1998,'ID','Indonesia','space',1052,'ID
ID
IDN
360
ID
Iran
IR
IR
IRN
364
IR
8 20 S
1 1 5 00 E
Bali Sea
Indian Ocean
7 45 S
1 1 5 30 E
Balintang Channel
Pacific Ocean
19 49 N
121 40 E
Balintang Islands
2 00 S
121 00 E
Celebes Sea
Pacific Ocean
3 00 N
122 00 E
Celtic Sea
Atlantic Ocean
51 00 N
6 30 W
Central African Empire
500 S
120 00 E
Dutch Guiana
9 00 S
126 00 E
Easter Island (Isla de Pascua)
1 00 N
128 00 E
Hamburg [US Consulate General]
5 00 S
138 00 E
Irish Sea
Atlantic Ocean
53 30 N
5 20 W
Iron Gate
Romania, Serbia and Montenegro
44 41 N
22 31 E
Islamabad [US Embassy]
6 10 S
106 48 E
Jamestown
Saint Helena
15 56 S
5 44 W
Jammu
7 30 S
1 1 0 00 E
Java Sea
Pacific Ocean
5 00 S
1 1 0 00 E
Jeddah (see Jiddah)
000 N
1 1 5 00 E
Kamaran [island]
607S
105 24 E
Krakow [US Consulate General]
9 00S
120 00 E
Lesvos [island]
3 35 N
98 40 E
Mediterranean Sea
Atlantic Ocean
36 00 N
15 00 E
Melbourne [US Consulate General]
2 00 S
28 00 E
Mombasa
3 30 N
102 30 E
Naxcivan [region]
500S
120 00 E
Netherlands Guiana
9 00 S
126 00 E
Port-Vila
2 00 S
28 00 E
Spitsbergen [island]
Svalbard
78 00 N
20 00 E
Stanley
Falkland Islands (Islas Malvinas)
51 42 S
57 41 W
Stockholm [US Embassy]
0 00 N
102 00 E
Sumba [island]
10 00S
120 00 E
Sunda Islands (Soenda Isles)
Indonesia, Malaysia
2 00 S
110 00 E
Sunda Strait
Indian Ocean
6 00 S
105 45 E
Surabaya [US Consulate General]
7 15 S
112 45 E
Surigao Strait
Pacific Ocean
10 15 N
125 23 E
Surinam
9 00 S
125 00 E
Timor Sea
Pacific Ocean
11 00 S
128 00 E
Tinian [island]','206d6e24886766f9e5de52ec0a9171bdbc091addb7849a288c1ab62ddb697e85','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('272d7dfc04f085d09a98070907a9829ae030cf282836d0aa7f9216a1308688fe',1998,'IQ','Iraq','space',1053,'IZ
IQ
IRQ
368
IQ
33 00 N
44 00 E
Messina, Strait of
Atlantic Ocean
38 15 N
15 35 E
Mexico [US Embassy]','1dc7e0a2acbffe3c1b1887871722eaf69987ff5c75131a7b2bc7bac2705c07a8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c74d70c35ffc321451d0ca5bf6e26348924e3fcc820dca2349905ebc969c425',1998,'IE','Ireland','space',1054,'El
IE
IRL
372
IE
53 20 N
6 15 W
Durban [US Consulate General]
53 00 N
8 00 W
Elba [island]','2d0871285fd2fb2a9eddf2939c1558550e9daad83e10a43255f3dcb224f9e410','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fa0af96e30c912710648b57bb0c08e1a2e9d429c9daac891a73a14411a7c018',1998,'IL','Israel','space',1055,'IS
IL
ISR
376
IL
32 54 N
35 20 E
Galleons Passage
Atlantic Ocean
11 00 N
60 55 W
Gambier Islands (lies Gambier)
32 50 N
35 00 E
Haiphong
Vietnam
20 52 N
106 41 E
Hainan Dao [island]
30 30 N
34 55 E
Negros [island]
32 05 N
34 48 E
Terre Adelie (Adelie Land) [claimed by France]
32 48 N
35 35 E
Tibet (Xizang)','c1c0b27d6df8cca7fd3b155040f98aeb42abb0968c43dc50a3175a23a4ab8057','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a284f9ef17361951495e98f2f369bcc89d675c7c665caad9be290f6e7007900',1998,'IT','Italy','space',1056,'IT
IT
ITA
380
IT
42 46 N
10 17 E
Ellef Ringnes Island
38 30 N
15 00 E
Epirus, Northern
Albania, Greece
40 00 N
20 30 E
Espana
43 46 N
11 15 E
Florida, Straits of
Atlantic Ocean
25 00 N
79 45 W
former Soviet Union (FSU)
Armenia, Azerbaijan, Belarus, Estonia, Georgia,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
Formosa [island]
Taiwan
23 30 N
121 00 E
Formosa Strait (see Taiwan Strait)
Pacific Ocean
24 00 N
119 00 E
Fortaleza [US Consular Agency]
44 25 N
857 E
George Town
41 13 N
09 24 E
Madeira Islands
45 28 N
9 12 E
Minami-tori-shima (Marcus Island)
40 50 N
14 15 E
Nassau [US Embassy]
The Bahamas
25 05 N
77 21 W
Natuna Besar Islands
38 07 N
13 21 E
Palestine
Israel, West Bank
32 00 N
35 15 E
Palikir
Federated States of Micronesia
6 55 N
158 08 E
Palk Strait
Indian Ocean
10 00 N
79 45 E
Pamirs [mountains]
China, Tajikistan
38 00 N
73 00 E
Pampas [region]
36 47 N
12 00 E
Papeete
35 40 N
12 40 E
Peleliu (Beliliou) [island]
41 54 N
12 29 E
Roncador Cay
40 00 N
9 00 E
Sargasso Sea
Atlantic Ocean
30 00 N
55 00 W
Sark [island]
37 30 N
14 00 E
Sicily, Strait of
Atlantic Ocean
37 20 N
11 20 E
Sidra, Gulf of
Atlantic Ocean
31 30 N
18 00 E
Sikkim [state]
46 30 N
10 30 E
South Vietnam
Vietnam
12 00 N
108 00 E
South Yemen (People’s Democratic Republic of Yemen)
4504 N
7 40 E
Turkish Straits
Atlantic Ocean
40 40 N
28 00 E
Turkmeniya
43 25 N
11 00 E
Tutuila [island]
46 30 N
10 30 E
Tyrrhenian Sea
Atlantic Ocean
40 00N
12 00E
U Udorn (Udon Thani) [US Consulate]','075c67dc16ab91715eb291bb4b92b00f160e3131208cd86267727f50d63e491a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5810c940224f126789b2cfecf413acf9c1ddb0183305b31f36e03a26fc400a00',1998,'JM','Jamaica','space',1057,'JM
JM
JAM
388
JM
Jan Mayen
JN
—
—
—
* —
ISO includes with Svalbard
18 00 N
76 48 W
Kingston','f5e5548a02323ba43529efb9e4a79d100d6382697a9e604e7e222bfdfae6630a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cc79d6d7ca1ee5a10e49e9959941303dbba9e6e843ad037b6cfb035303ed6e2',1998,'JP','Japan','space',1058,'JA
JP
JPN
392
JP
Jarvis Island
DQ
—
—
—
ISO includes with the US Minor
Outlying Islands
27 00 N
140 10 E
Bonn [US Embassy]
43 00 N
17 00 E
Dakar [US Embassy]
33 35 N
130 24 E
Funafuti
44 00 N
143 00 E
Holland
36 00 N
138 00 E
Hormuz, Strait of
Indian Ocean
26 34 N
56 15 E
Horn, Cape (Cabo de Hornos)
34 20 N
133 30 E
Inner Mongolia (Nei Mongol)
24 47 N
141 20 E
J
Jakarta [US Embassy]
34 41 N
135 10 E
Kodiak Island
33 00 N
131 00 E
Kyyiv (see Kiev)
24 16 N
154 00 E
Mariana Islands
Guam, Northern Mariana Islands
16 00 N
145 30 E
Marion Island
24 16 N
154 00 E
Mindanao [island]
35 10N
136 55 E
Naha [US Consulate General]
26 13 N
127 40 E
Nairobi [US Embassy]
30 00 N
140 00 E
Naples [US Consulate General]
26 30 N
128 00 E
Oman, Gulf of
Indian Ocean
24 30 N
58 30 E
Ombai Strait
Pacific Ocean
8 30 S
125 00 E
Oran
34 40 N
135 30 E
630
Name
Entry in The World Factbook
Latitude
(deg min)
Oslo [US Embassy]
26 30 N
128 00 E
Saba [island]
Netherlands Antilles
17 38 N
63 10W
Sabah [state]
24 30 N
124 00 E
Sakhalin Island (Ostrov Sakhalin)
Russia
51 00 N
143 00 E
Sala y Gomez, Isla
43 03 N
141 21 E
Sapudi Strait
Pacific Ocean
705 S
114 10 E
Sarajevo [US Embassy]
33 45 N
133 30 E
Shikotan [island]
Russia [de facto]
43 47 N
146 45 E
Siam
35 42 N
139 46 E
Tonkin, Gulf of
Pacific Ocean
20 00 N
108 00 E
Toronto [US Consulate General]
25 00 N
141 00 E
Vostok Island','6a34e06a6b9026d90971fb8e5dd94114d9b435e7c7295453e51a0a559dbd7b65','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5eccacb891ab1784612b1e27094066d7af0e1d1cf0d6f654b80c2938b95a0b7c',1998,'JE','Jersey','space',1059,'JE
—
—
—
—
ISO includes with the United Kingdom
Johnston Atoll
JQ
—
—
—
ISO includes with the US Minor
Outlying Islands
49 12 N
2 37 W
Saint John’s','bcf2310b838904175dd3b5837eb2c7abdf040781c4bd396b87e43b0adbeebb47','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a457a11d39e59153f135b06bee1839b7a297caf74819b2d09914bca26a7f34b5',1998,'JO','Jordan','space',1060,'JO
JO
JOR
400
JO
Juan de Nova Island
JU
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
31 57 N
35 56E
Amsterdam [US Consulate General]
31 00 N
36 00 E
Transkei','416f2156f088c69b7f8c31bd6b35b616e7f737685c1a2949be90006e65fe8173','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a633acc7103a6eb57b35f085b39bd5eab343d6586af2295f9fa5f0a14bdc1cf',1998,'KZ','Kazakhstan','space',1061,'KZ
KZ
KAZ
398
KZ
51 10N
71 30 E
Aland Islands
43 15 N
76 57 E
Almaty [US Embassy]
Kazakhstan •
43 15 N
76 57 E
Alofi
51 10N
71 30 E
Arab, Shatt al [river]
Iran, Iraq
29 57 N
48 34 E
Arabian Sea
Indian Ocean
15 00 N
65 00 E
Arafura Sea
Pacific Ocean
900S
133 00 E
Aral Sea
Kazakhstan, Uzbekistan
45 00 N
6000 E
Argun River
China, Russia
53 20 N
121 28 E
Ascension Island
Saint Helena
757 S
14 22 W
Ashgabat [US Embassy]
Kozakhstan
51 00 N
71 30 E
Ashkhabad (see Ashgabat)
51 10N
71 30 E
Asuncion [US Embassy]','5de64c3ba412cf86b1e270a5e59a8bd33f7972747b1229565ae8b188027cd307','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4845373807f274030e7638aeb4865421239666f74888ef07b3eed6b1b882192b',1998,'KE','Kenya','space',1062,'KE
KE
KEN
404
KE
Kingman Reef
KQ
—
—
—
ISO includes with the US Minor
Outlying Islands
4 03 S
39 40 E
Mona Passage
Atlantic Ocean
18 30 N
67 45 W
1 17 S
36 49 E
Nampo-shoto [islands]','e366c258d14c1d5a65b13112bdf181ce122a7a5fbec66dd699a471f2d9fa93dc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f0b0313ab246823b54669edb17864e73a3437c1399435a41eb9a99bf6bee1ac',1998,'KI','Kiribati','space',1063,'KR
Kl
KIR
296
Kl
Korea, North
KN
KP
PRK
408
KP
Korea, South
KS
KR
KOR
410
KR
0 52 S
169 35 E
Bandar Seri Begawan [US Embassy]
Brunei
4 52 S
1 1 4 55 E
Banda Sea
Pacific Ocean
5 00 S
128 00 E
Bangkok [US Embassy]
2 49S
171 40 W
Cape Town [US Consulate General]
1 52 N
157 20 W
Chukchi Sea
Arctic Ocean
69 00 N
171 00 W
Ciskei
3 08 S
171 5 W
621
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Enewetak Atoll (Eniwetok Atoll)
1 25 N
173 00 E
Goa [state]
2 49 S
171 40 W
Karachi [US Consulate General]
1 52 N
157 20 W
Kishinev (see Chisinau)
Moldova
47 00 N
28 50 E
Kithira Strait
Atlantic Ocean
36 00 N
23 00 E
Kobe
0 52 S
169 35 E
Ocean Island (Kure Island)
3 30 S
172 00 W
Pines, Isle of (Isla de la Juventud)
1 25 N
173 00 E
Tatar Strait
Pacific Ocean
50 00 N
141 00 E
Tashkent [US Embassy]
10 06 S
152 23 W
Vrangelya, Ostrov (Wrangel Island)
Russia
71 14 N
179 36 W
W Wakhan Corridor (see Vakhan)
Kupang Timor
Arafura Sea
PAPOA ^EW GUIJ^ .fioopaMwV/a
M^lang-^ SOLOMON
Ue*-! New Britain V OULUmun
Solomon Sea
ISLANDS
In cf i a n
Ocean
-20 -
Ashmore and ■
Cartier Islands
(AUSTRALIA)
tot Had land
A.^,n ^
! ,w- ^ •''Port''*"
i smv ''p " x Moresby
Guadalcanal
TCl Gull of
■f Vl
CV»rp<’nr,L''f.''. \\
I
c I
Cairns*
Coral Sea
(AUSTRALIA)
Cora! Sea
• • $4/vn4 c#uz
1. VANUATU
• New * Port-vila
• Caledonia c>
. (FRANCE) ft
otuma ’* Mata-Utu^
• Wallis d
Vanua ;
Law/ A ,
fui.
wr/ **f* *
Law > “i. f-
(GILBERT ISLANDS)
iba •
North Pacific
Ocean
Kingman Reef
(U.S.)
Palmyra Atoll
(U.S.)
•
Howland Island
• (U.S.)
““Baker island (u''.s.)”
Jarvis Island
(U.S.)
''t''
ILES
MARQUISES
Lavu f:i
FUI.
•^aitoand Apiaw ★
Paflo
• Pago
Cook
Islands
(NX)
m Q Suv»*
Law > j. *
A
• •.TONGA
Alofi
*Niue(N.Z.)
i **’
i j*
^ Nukualofa
Cava-hRa !
a
! i
T f : j ;■
ot Capricorn
SOCIETY
ISLANDS
^Papeete
Tahiti
ARCHiPEL DES TUAMOTU
r
Avarua
e
sland
AIM)
ffLZ.)','11849079e354ad21e59e797f775146f71fb87294b3836079ca48d3abba18a218','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ba56e00f270f67545fc37631a105707e8a1b98d6ff7a21e09b88e28af788256',1998,'KW','Kuwait','space',1064,'KU
KW
KWT
414
KW
Bucharest [US Embassy]
29 20 N
47 59 E
Kuznetsk Basin
Russia
54 00 N
86 00 E
Kwajaiein Atoll','d19b14c45b5d65c7297363d3bf797aab5a1be278bba7b1790e99bf39c29364bf','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95869b3308277212dd09fe0a9a6a416b5964deb614de6ed1091306cd20bc6b22',1998,'KG','Kyrgyzstan','space',1065,'KG
KG
KGZ
417
KG
Laos
LA
LA
LAO
418
LA
42 54 N
74 36 E
Bishop Rock
42 54 N
74 36 E
Fukuoka [US Consulate]
41 00 N
75 00 E
Kiritimati (Christmas Island)','98659654ab8a93eddff834a10c61a2e3dbe12a84b3e43af8511b2450ac45e7e8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd5d3687100f3196365e11e8f3a96198d51c8910e613286510b6b6c56c921900',1998,'LB','Lebanon','space',1066,'LE
LB
LBN
422
LB
33 53 N
35 30 E
Belau (Palau Islands)
34 26 N
35 51 E
Tripoli [US post not maintained; representation by
Belgian Embassy]','dba528d6b87f00a3f91c21495679cf0ba044bd51953b785acda85cfa0d82b736','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6379bfc6a622b550c4959292d233ca4265a1a08658d8cdd248a017205f12c05',1998,'LS','Lesotho','space',1067,'LT
LS
LSO
426
LS
29 30S
28 30 E
Batan Islands
29 28 S
27 30 E
Matamoros [US Consulate]','c193dba18b6f0e6944d7afb16ffef44d6435e3b11db7d0073c5bc4d20dd7e5d1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db69527ad0d1dfd46af4d1f8a17757b16bc2fef70cf1048850bdc94f233c1a11',1998,'LY','Libya','space',1068,'LY
LY
LBY
434
LY
604
Entity
FIPS 10-4
ISO 3166
Internet
Comment
32 54 N
1311 E
Tristan da Cunha Group
Saint Helena
37 04 S
12 19 W
Trobriand Islands','808308b0155fe3ae5caaee375bd46424972f6ebbd9910e0e37b39968b7add175','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da1067f26482504772c44373b6479c1e97b7ba056b681b10660c2d4c49b592fc',1998,'LU','Luxembourg','space',1069,'LU
LU
LUX
442
LU
Macau
MC
MO
MAC
446
MO
Macedonia, The Former Yugoslav
Republic of
MK
MK
MKD
807
MK
49 45 N
610E
Luzon [island]','7f311dbf5645a6d4f40a8c5a38988e0c38f341ce1f380fc1dbef73d4be21348c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1cec57b7f7841b630aba28b10560264575ddf4f49df27d55369c413adf8c512',1998,'MG','Madagascar','space',1070,'MA
MG
MDG
450
MG
18 52 S
4730E
Antigua [island]
20 00 S
47 00 E
627
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Male','6158e6da89bb239aa0371a4f25e1d82e0cac19a3b4915673485bb89437980e43','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7854dbe5a29a79768780a467512c750db0ed37fcb58026de9bd765fa94e1f05',1998,'MY','Malaysia','space',1071,'MY
MY
MYS
458
MY
5 26 N
100 16 E
George Town
The Bahamas
23 30 N
75 46 W
George Town
3 10 N
101 42 E
Kunashiri (Kunashir) [island]
Russia [de facto]
44 20 N
146 00 E
Kunlun Mountains
5 23 N
100 15 E
Pentland Firth
Atlantic Ocean
58 44 N
3 13 W
Perim [island]
5 20 N
117 10 E
Sable Island
2 30 N
113 30 E
Sardinia [island]','a8855e6600c52ac967926cad59402095838231dfe81d95450b0a705cf78646a4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bddeb5dc1ac7e011d1d460088d0024e05f7088e9793b048bb3a01fe7d3d47be',1998,'ML','Mali','space',1072,'ML
ML
MU
466
ML
12 39 N
8 00 W
Banaba (Ocean Island)
17 00 N
4 00 W
French Territory of the Afars and Issas (F.T.A.I.)','16ae82abd3c91b83ce19fb2f80d360cc25a126e22e9863d625f0d227592ffa0a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('707d24767b4b5766fb232794609b3c7675d1de3461fa298d2697f23df8532d31',1998,'MT','Malta','space',1073,'MT
MT
MLT
470
MT
Man, Isle of
IM
—
—
—
—
ISO includes with the United Kingdom
35 54 N
14 31 E
Valley, The','4e75116513bae960ab0ade85746a825e8de958eaa95fedbffddad1911bba8845','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73bd727e4bb13ef0a9eb5ad144c2c01ced60c58160be2cf67aefaa40c9906d05',1998,'MH','Marshall Islands','space',1074,'RM
MH
MHL
584
MH
11 35 N
165 23 E
Bilbao
11 30 N
162 15 E
England [region]
11 30 N
162 15 E
Eolie, Isole
9 05 N
167 20 E
Kyushu [island]
7 05 N
171 08 E
Makassar Strait
Pacific Ocean
2 00 S
1 1 7 30 E
Malabo
8 00 N
167 00 E
Rangoon [US Embassy]
Burma
16 47 N
96 10 E
Ratak Chain
9 00 N
171 00 E
Recife [US Consulate]','1efe01ce168a60da5a749fe2ce701c1a980b70c4e3e8d9d6b8e94978119ab386','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99e65023af21d99940a3b5d8712f68cf00c1aa08fcf5987c331d6a561679f89c',1998,'MQ','Martinique','space',1075,'MB
MQ
MTQ
474
MQ
14 36 N
61 05 W
Frankfurt am Main [US Consulate General]
m (FRANCE)
ce ^
• x ; j ■/„. .4 v*> •*/ ^
jJSK Netherlands Antilles
(NtTrl.) (NETH.)
tranjestad^ Curacao
^Bonaire
/*T \\ Willemstad
Mala Margarita
Tortuga ^
ST. VINCENT AND
THE GRENADINES
Port-of-Spain
TRINIDAD AND
TOBAGO
OM Bl A
tfe. .''iasasss
mam','f80efb9dc539f29b385f4935d7fabdb90b9c35cf0a87727fc1fe2cc254aa9c0d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1004639a6d0c0515ce11dcd8e483c2414a9ba5a52a30cedfd3f9873140a24801',1998,'MU','Mauritius','space',1076,'MP
MU
MUS
480
MU
1025 S
56 40 E
Agana (see Hagatna)
16 25 S
59 38 E
Caroline Islands
Federated States of Micronesia, Palau
7 30 N
148 00 E
Caribbean Sea
Atlantic Ocean
15 00 N
73 00 W
Carpentaria, Gulf of
Pacific Ocean
14 00 S
139 00 E
Casablanca [US Consulate General]
20 10 S
57 30 E
Port Moresby [US Embassy]
19 42 S
63 25 E
Rome [US Embassy, US Mission to the UN
Agencies for Food and Agriculture (FODAG)]
16 25 S
59 38 E
Saint Christopher [island]','80d3deff86c50a0d78b4e948eada78d6fc8df844c2be269601abfb9df47eb575','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d13901b4693e8c17833e037c6b7b20263d9976b252b5e23889fa18b03b9a0617',1998,'MX','Mexico','space',1077,'MX
MX
MEX
484
MX
Micronesia, Federated
States of
FM
FM
FSM
583
FM
Midway Islands
MQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
Miscellaneous (French)
ISO includes Bassas Indian Ocean da
India, Europa Islands Island, Glorioso
Islands, Juan de Nova Island, Tromelin
Island
Moldova
MD
MD
MDA
498
MD
1651 N
99 55W
Accra [US Embassy]
31 44 N
106 29 W
Cluj-Napoca [US Branch Office]
20 40 N
103 20 W
Guadalcanal [island]
2911 N
118 17W
Guangzhou [US Consulate General]
29 04 N
1 1 0 58 W
Herzegovina
25 53 N
97 30 W
Mata-Utu
23 13 N
106 25 W
Mbabane [US Embassy]
Swaziland
26 18 S
31 06 E
McDonald Islands
20 58 N
89 37 W
Mesopotamia
19 24 N
99 09 W
Mexico, Gulf of
Atlantic Ocean
25 00 N
90 00 W
Milan [US Consulate General]
25 40 N
1 00 1 9 W
Montevideo [US Embassy]
27 30 N
99 31 W
Nuuk (Godthab)
19 00 N
112 45 W
Reykjavik [US Embassy]
32 32 N
11701 W
Timor [island]
19 30 N
89 00 W
Yucatan Channel
Atlantic Ocean
21 45 N
85 45 W
Yugoslavia
Bosnia and Herzegovina, Croatia,
The Former Yugoslav Republic of
Macedonia, Serbia and Montenegro, Slovenia
Z
Zagreb [US Embassy]
Arkansas
0
Little Rock /
f Tennessee
Memphis — —
^Mississippi A,abama \\ Georgia
North
Atlantic
Ocean
^Kew Orleans
Gulf of Mexico
THE ^ BAHAMAS
yvTAr ^ \\
4j> Nassau * 5
<& - \\
Hawaii
Midway J.
Islands
North Pacific ! Ocean
Scale 1:34,000,000
0 400 Kilometers
| - - ,
0 400 Miles
u A
Maui
Hawaii
I (R02419)|
802583 6-98
Central America and the Caribbean
Grest
Abaco
THE BAHAMAS
\\^Catiatand
fr San Salvador
Groat V_
Exuma
■ Cay Lotos \\ ^uSS
(TX \\ HAHGf
i (THE tAHAMAS)
Rum Cay
Long Island ~
m x
f" Hotife*
S “ ^Mayapuan#
’AdH/o* Turks and
i**9"* Caicos Islands
r (U.K.)
o 1;
Groat Jnagus A
oy
North
Atlantic
Ocean
U.S. Naval Bate
Guantanamo Bay
H/a
Port-aSNlna
Santiago ^
DOMINICAN:^ British Atwoic
REPUBLIC '' '' , _ Tyt
^■v_/*S«mo^ ^ Virgin u. N«n *S!sfi£nhtl
Domingo ^ ^Sl *"“»•. S *
/ won# Puerto Rico Sf. Cro/x B ^
r. «i e \\ Basseterre * ^
yv ’ ST. KITTS AND NEVIS * ®
Plymouth''#
Montserrat (U.K.)
Anguilla (U.K.)
St. Martin (Quad, and Nath. AntWaa)
- St. Barthalemy (Guard.)','07a6d0fb2e3be4a02891a3b19be481a5b9ff9a3482664820475ab6d98052a1ef','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3430a5220fdc54ed7120be114d7831949057a83b5b6c1f6be3e7813f0219953a',1998,'MN','Mongolia','space',1078,'MG
MN
MNG
496
MN
Montenegro*
MW
—
—
—
—
see footnote at end of table
46 00 N
105 00 E
Pacific Islands, Trust Territory of the
Marshall Islands, Federated States of Micronesia,
Northern Mariana Islands, Palau
10 00 N
155 00 E
Pagan [island]
47 55 N
106 53 E
Ullung-do [island]
South Korea
37 29 N
130 52 E
Unimak Pass [strait]
Pacific Ocean
54 20 N
164 SOW
Union of Soviet Socialist Republics (USSR)
Armenia, Azerbaijan, Belarus, Estonia, Georgia,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
United Arab Republic (UAR)
Egypt, Syria
Upper Volta','6faed7abc357987e52a6a21d8bc886f8780a4e9cc95045698a1ff5415d7bb8a9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e2f7123b78ee2f7f26186bfaefa5d324e0a81698ff7dc91678d1563193a586c',1998,'MS','Montserrat','space',1079,'MH
MS
MSR
500
MS
16 44 N
62 14 W
Ponape (Pohnpei) [island]
Federated States of Micronesia
6 55 N
158 15 E
Ponta Delgada [US Consulate]','6f7d75abddf196526242740c14599736e28f9c62981b4ede01f9ea6867d1f2bb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d42a5d9b43512e58e0a567ea6d74686b8d936c5d98b1ee6acd8370ba578144f',1998,'MA','Morocco','space',1080,'MO
MA
MAR
504
MA
33 39 N
7 35 W
Castries
32 00 N
5 00 W
French Somaliland
34 02 N
6 51 W
Ralik Chain
32 00 N
7 00 W
Spanish North Africa
Spain (Ceuta, Islas Chafarinas, Melilla, Penon de
Alhucemas, Penon de Velez de la Gomera)
35 15 N
4 00 W
Spanish Sahara
35 48 N
5 45 W
Tarawa [island]','b620ede0c6010d4431fdad3ba13356dbcf2bfa17bab67f11a1dc5ea07b294bc2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01a7cfa50965ad66da4500fb8446f746b1193e67151531b2f700dae77f83a6d2',1998,'MZ','Mozambique','space',1081,'MZ
MZ
MOZ
508
MZ
25 58 S
32 35 E
Marcus Island (Minami-tori-shima)
18 15 S
35 00 E
Portuguese Guinea','dcab03cd2b261b88822b3321482fbf251ce770b4d369cc49355ae31da2c12c6f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd437b1f2ba1fe209fcbbd7024f10ac53a68308d4bef99550feeac5eadfdf3b0',1998,'NA','Namibia','space',1082,'WA
NA
NAM
516
NA
22 00 S
17 00 E
Germany, Federal Republic of
22 00 S
17 00 E
Southern Grenadines
22 59 S
1431 E
Warsaw [US Embassy]
2234S
17 06 E
Windward Passage
Atlantic Ocean
20 00 N
73 50W
Wrangel Island (Ostrov Vrangelya)
Russia
71 14 N
179 36 W
Y
Yalu River
China, North Korea
39 55 N
124 20 E
Yamoussoukro
Cote d’Ivoire
649 N
5 17 W
Yangon (see Rangoon)
Burma
1647 N
96 10 E
Yaounde [US Embassy]','2b95c0bb3b7651670548bab3ec6a8f68738d185e18466a1eb85599717398ca0e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab5f29cb32ad13cb668a3ac09d47bc47ca0e0195b724a71efd6ea6750d550b91',1998,'NR','Nauru','space',1083,'NR
NR
NRU
520
NR
Navassa Island
BQ
—
—
—
—
0 32 S
166 55 E
Plymouth
0 32 S
166 55 E
Yekaterinburg (Sverdlovsk) [US Consulate General]
Russia
5650 N
60 39 E
Yellow Sea
Pacific Ocean
36 00 N
123 00 E
Yemen (Aden) [People’s Democratic Republic of Yemen]','6ea0e075f513153e2d72024ca8b72747d8a3c3fc8897a9cb240d7dc67f065d86','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85188cf4222c1f399ffbd22284a2d34d210b9d6c59049e25272e0473cb458cdb',1998,'NP','Nepal','space',1084,'NP
NP
NPL
524
NP
27 43 N
85 19 E
Kattegat [strait]
Atlantic Ocean
57 00 N
11 00 E
Kauai Channel
Pacific Ocean
21 45 N
158 50 W
Keeling Islands','e44cb3f3df31962a479f822cbc2a4713b9cc0299ef34a41603acaab24a246ed1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a990ceb08db4864f3785ea9b2a1f1b998f6bc847c1ee9b56204cb0e9b1e314a',1998,'NL','Netherlands','space',1085,'NL
NL
NLD
528
NL
Netherlands Antilles
NT
AN
ANT
530
AN
52 22 N
4 54 E
Amsterdam Island (He Amsterdam)
French Southern and Antarctic Lands
37 52 S
77 32 E
Amundsen Sea
Pacific Ocean
7230 S
11200 W
Amur River
China, Russia
52 56 N
141 10 E
Anatolia [region]
Turkey
39 00 N
35 00 E
Andaman Islands
52 05 N
4 18 E
Haifa
52 30 N
5 45 E
Hong Kong [US Consulate General]
5326 N
5 30 E
West Germany (Federal Republic of Germany)','5f0aa3728ed527f59e8e08161f0fb45d4f567947bacfe1c65b04f671ed397e55','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ef47435c865e1d756031fceb30d8b1e95f6995e71d137391461a4eab4a8e7e1',1998,'NC','New Caledonia','space',1086,'NC
NC
NCL
540
NC
1945 S
16340 E
Belfast [US Consulate General]
19 52 S
158 15 E
Chiang Mai [US Consulate General]
21 00 S
167 00 E
Luanda [US Embassy]
22 16 S
166 27 E
Novaya Zemlya [islands]
Russia
74 00 N
57 00 E
Nubia','5f09d5bf786524ceeec4b1105b24164ab4a5ef2672f6bcd96fa6b9204ff95219','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51baf1c51f68dea8c68bd3e31989d888732810f892095b9192f95c0ed5bdc41c',1998,'NZ','New Zealand','space',1087,'NZ
NZ
NZL
554
NZ
4941 S
178 43 E
Antwerp [European Logistical Support Office]
36 52 S
174 46 E
Auckland Islands
51 00 S
166 30 E
Australes, lies (lies Tubuai)
47 43 S
174 00 E
Brasilia [US Embassy]
52 33 S
169 09 E
Canal Zone
44 00 S
176 30 W
Chechnya (Chechnia)
Russia
43 15 N
45 40 E
Cheju-do [island]
Korea, South
33 20 N
126 30 E
Cheju Strait
Pacific Ocean
34 00 N
126 30 E
Chengdu [US Consulate General]
29 SOS
178 15 W
Kerulen River
China, Mongolia
48 48 N
1 1 7 00 E
Khabarovsk
Russia
48 27 N
135 06 E
Khanka, Lake
China, Russia
45 00 N
132 24 E
Khartoum [US Embassy] •
39 00 S
176 00 E
North Korea
North Korea
40 00 N
127 00 E
North Pacific Ocean
Pacific Ocean
30 00 N
165 00 W
North Sea
Atlantic Ocean
56 00 N
4 00 E
North Vietnam
Vietnam
23 00 N
106 00 E
North Yemen (Yemen Arab Republic)
43 00 S
171 00 E
South Korea
South Korea
37 00 N
127 30 E
South Orkney Islands
41 28 S
174 51 E
West Frisian Islands','f8ac147c1c437c3dfc21e2979f2be68c841c1616b4501f5fa94508c03e17e3dc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aa939c9bdba3abf4261698a194623779339717f61ded1021d70e29da7611ec7',1998,'NI','Nicaragua','space',1088,'NU
Nl
NIC
558
Nl
12 15 N
83 00 W
Corocoro Island
Guyana, Venezuela
338 N
66 50 W
Corsica (Corse) [island]
12 15 N
83 00 W
Majorca Island (Isla de Mallorca)
12 09 N
86 17 W
Manama [US Embassy]','5085951d079256911ca8d15f5c09c59517e14f83cf3a2438c31c5b50d9893a48','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13618e3665c19bdf509e3fddcf2fd67d5e70f730b9db7ad82cee57e2e8c8fd91',1998,'NG','Nigeria','space',1089,'Nl
NG
NGA
566
NG
605
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
9 12 N
711 E
Abyssinia
530 N
730 E
Big Diomede Island
Russia
65 46 N
169 06 W
Bijagos, Arquipelago dos
10 33 N
7 27 E
Kailas Range
China, India
30 00 N
82 00 E
Kalimantan [region]
6 27 N
324 E
Lahore [US Consulate General]','5e97f5c1146b8e152db02cf3d852378c1d83535137c5a1f41d7e791e983956ca','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cc52e41f06b2b0a95ed171eda42e6a52420e47af64d95ba9fe33419406f6779',1998,'NU','Niue','space',1090,'NE
NU
NIU
570
NU
19 01 S
16955 E
614
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Alphonse Island','a838f644a1fc4e25b1335f2193afc8ae6f5896de163299c3ebef9b47ebddb76f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6de8b2e08ecd9236ce32fa5935178f8cac903c7238b538e126ccc9922feacfc9',1998,'NF','Norfolk Island','space',1091,'NF
NF
NFK
574
NF
29 02 S
167 56 E
Byelorussia
29 03 S
167 58 E
Kingstown
2908 S
167 57 E
Philippine Sea
Pacific Ocean
20 00 N
134 00 E
631
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Phnom Penh [US Embassy]
(AUSTRALIA)
Grear Australian
Bight
J_f\\ Adelaide
Bendigo,
Newcastle^/
Sydney^
/
118 ^Wollongong
liorrfMxva Island
(AUSTRALIA)
„ Melbourne
Geelong -4 —
Tasman
Sea
ZEALAND
Indian
Ocean
t North
& /s/ar?c/
I''Hobart ^ _
Tasmania
€c. r
) Wellington
Christchurch
South Island
120
Stewart Island
180
, Midway Islands
(U.S.)
Kau*!c Oahu
a, 4 Honolulu
- . i 2^—
''0
^ Hawaii
• Johnston Atoll
(U.S.)
MARSHALL
ISLANDS
Majuro','ff0f2d216040c503cdbad43c42ce20ef3a131f7d72667c4fe4a125243fd7736e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26e876d309ca38fcfd48aa55fb7b629fd1578628fa43edd132e816aa1877e895',1998,'MP','Northern Mariana Islands','space',1092,'CQ
MP
MNP
580
MP
19 40 N
145 24 E
Atacama [region]
18 8 N
145 47 E
Pago Pago
14 10N
145 12 E
Rotuma [island]
15 12 N
145 45 E
Sakishima Islands
15 00 N
145 38 E
Tiran, Strait of
Indian Ocean
28 00 N
34 27 E
Tirana [US Embassy]','94074b0585f6e941471fb0e169fa475a6339d12d2618fbd59211f26105894e5c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('259ecb39b71eaa01baed058c822490dce296fab60e299df71630ece1494599d6',1998,'NO','Norway','space',1093,'NO
NO
NOR
578
NO
59 55 N
10 45 E
Osumi Strait (Van Diemen Strait)
Pacific Ocean
31 00 N
131 00 E
Otranto, Strait of
Atlantic Ocean
40 00 N
19 00 E
Ottawa [US Embassy]','90696d3bfc33ed6682d4db1c23688f23a77733fd95a6d738bc50e59576a4a1ed','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06f80f467af3be981ac914b0bb2a18986c5c112d4c48d70ccfc4f7b2c66716ef',1998,'OM','Oman','space',1094,'MU
OM
OMN
512
OM
17 00 N
54 10 E
Diego Garcia [island]
17 30 N
5600 E
Khyber Pass
Afghanistan, Pakistan
34 05 N
71 10 E
Kiel Canal (Nord-Ostsee Kanal)
Atlantic Ocean
53 53 N
9 08 E
Kiev [US Embassy]
23 37 N
58 35 E
Muscat and Oman
21 00 N
57 00 E
Myanma, Myanmar
Burma
22 00 N
98 00 E
N Nagorno-Karabakh [region]
& x','b61b64685a9879a2cb70c2e3d98b9ace999158963634d20c9663083d15369cd4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f5ae5f7aefc141fe627c9995633e12ec6e956dd2d1ec312e46f26f550136c5b',1998,'PK','Pakistan','space',1095,'PK
PK
PAK
586
PK
34 30 N
74 00 E
Azores [islands]
28 00 N
63 00 E
Baltic Sea
Atlantic Ocean
57 00 N
19 00 E
Bamako [US Embassy]
3342 N
73 10 E
Islas Malvinas
Falkland Islands (Islas Malvinas)
51 45 S
59 00 W
Istanbul [US Consulate General]
Turkey
41 01 N
28 58 E
Istrian Peninsula
Croatia, Slovenia
45 00 N
14 00 E
Italian East Africa
Eritrea, Ethiopia, Somalia
8 00 N
38 00 E
624
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Italian Somaliland
24 52 N
67 03 E
Kara Sea
Arctic Ocean
76 00 N
80 00 E
Karakoram Pass
China, India
35 30 N
77 50 E
Karelian Isthmus
Russia
60 25 N
30 00 E
Karimata Strait
Pacific Ocean
2 05 S
108 40 E
Kashmir [region]
India, Pakistan
34 00 N
76 00 E
Katanga [region]
Democratic Republic of the Congo
10 00S
26 00 E
Kathmandu [US Embassy]
31 35 N
74 18 E
Lakshadweep (Laccadive Islands)
34 01 N
71 33 E
Peter 1 Island
30 00 N
70 00 E
West Siberian Plain
Russia
60 00 N
75 00 E
Western Channel (West Korea Strait)
Pacific Ocean
34 40 N
129 00 E
Western Samoa','1fa60e1f218780b5058a27fded58a02e2e6238c02db42ce5546f0e6a1071dec0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7f11657ca9c24eaaec63178b0ecfe99b92d1288d2591cb528cfe49483ab5716',1998,'PW','Palau','space',1096,'PS
PW
PLW
585
PW
Palmyra Atoll
LQ
—
—
—
ISO includes with the US Minor
Outlying Islands
7 30 N
1 34 30 E
Belem [US Consular Agency]
720 N
134 29 E
Kosovo [region]
Serbia and Montenegro
42 30 N
21 00 E
Kowloon
7 01 N
134 15 E
Pemba Island
Tanzania
7 31 S
39 25 E
Penang Island','20d6c81f8969fe410cbeb62a8d2460172e1d741c5952ae3648756520a45b5024','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b729b1d76d24605056a8279f6ccc6873146060538365aea0717728185c6ebf3',1998,'PA','Panama','space',1097,'PM
PA
PAN
591
PA
9 00 N
79 45 W
Canary Islands
8 58 N
79 32 W
Panama Canal
9 00 N
79 45 W
Panama, Gulf of
Pacific Ocean
800 N
79 30 W
Panay [island]','fb8031e7e1919f29da0629330af0be2a1c18a8aa9054ce3d50a038428b4cf1e6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1581f2805d6b22e00c61b2c50462db93d250f24343cb3678e0cf875f13ff9855',1998,'PG','Papua New Guinea','space',1098,'PP
PG
PNG
598
PG
Paracel Islands
PF
—
—
—
—
2 10 S
147 00 E
Adriatic Sea
Atlantic Ocean
42 30 N
16 00 E
Aegean Islands
5 00 S
150 00 E
Bismarck Sea
Pacific Ocean
400 S
148 00 E
Bissau [US Embassy]
6 00 S
155 00 E
Bougainville Strait
Pacific Ocean
6 40 S
156 10 E
Bounty Islands
930S
150 40 E
Desolation Islands (Isles Kerguelen)
French Southern and Antarctic Lands
49 30 S
69 30 E
620
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Devils Island (lie du Diable)
4 30 S
154 10 E
Greenland Sea
Arctic Ocean
79 00 N
5 00 W
Grenadines, Northern
11 00 S
153 00 E
Loyalty Islands (lies Loyaute)
6 00 S
150 00 E
New Delhi [US Embassy]
9 30 S
147 10 E
Porto Alegre [US Consulate]
6 00 S
155 00 E
Solomon Islands, southern
8 38 S
151 04 E
Trucial Coast','beb8b2d30f767456a172b9fb933c29bd98d3c4abcc4e71335c7c72176ee1bfe6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31feded0d12d278ec6ad18292b5399e734be9934a703806e9f2cfb0fc7c5ba81',1998,'PE','Peru','space',1099,'PE
PE
PER
604
PE
12 03 S
77 03 W
Lincoln Sea
Arctic Ocean
83 00 N
56 00W
Line Islands
Jarvis Island, Kingman Reef, Kiribati, Palmyra Atoll
0 05 N
157 00 W
Lisbon [US Embassy]','cd05752b72b2ab9275bd8fa5fda2bc70f6d88cb21a54fcc67393f3b608b42830','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7eeaa9137b1a0079c479f9f690e602575f3047c839c9e6aa94179e4398046bf',1998,'PH','Philippines','space',1100,'RP
PH
PHL
608
PH
Pitcairn Islands
PC
PN
PCN
612
PN
19 10N
121 40 E
Baffin Bay
Arctic Ocean
73 00 N
66 00 W
Baffin Island
19 55 N
122 10 E
Balkan Peninsula
Albania, Bosnia and Herzegovina, Bulgaria,
Croatia, Greece, Romania, Serbia and
Montenegro, Slovenia, The Former Yugoslav
Republic of Macedonia, Turkey (European part)
42 00 N
23 00 E
Balleny Islands •
2030 N
121 50 E
Bavaria (Bayern)
10 18 N
123 54 E
Celebes [island]
10 50 N
124 50 E
Liancourt Rocks [claimed by Japan]
South Korea
37 15 N
131 50 E
Libreville [US Embassy]
16 00 N
121 00 E
Luzon Strait
Pacific Ocean
20 30 N
121 00 E
Lyakhov Islands
Russia
73 45 N
138 00 E
M Macao
Macau
22 10N
1 1 3 33 E
Macedonia
The Former Yugoslav Republic of Macedonia
41 50 N
22 00 E
Macquarie Island
14 35 N
121 00 E
Manipa Strait
Pacific Ocean
3 20 S
127 23 E
Mannar, Gulf of
Indian Ocean
8 30 N
79 00 E
Manua Islands
8 00 N
125 00 E
Mindoro [island]
12 50 N
121 05 E
Mindoro Strait
Pacific Ocean
12 20 N
120 40 E
628
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Minicoy Island
15 08 N
120 21 E
Mozambique Channel
Indian Ocean
19 00 S
41 00 E
Mumbai [US Consulate General]
10 00 N
123 00 E
Netherlands East Indies
930 N
1 1 8 30 E
Palermo
11 15 N
122 30 E
Pantelleria, Isola di
12 00 N
12500 E
Samaria [region]
West Bank
32 15 N
35 10 E
Samoa Islands
American Samoa, Samoa
MOOS
171 00 W
Samos [island]
6 00 N
121 00 E
Sulu Sea
Pacific Ocean
8 00 N
120 00 E
Sumatra [island]','4e8fa5fee15090beed6b220cecbccf36999f67d92517a219f59e771f1b1d2ec2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47ad5a1b1a08142cc22deef6ba596d3bbc1ad0aaace3a05ef69df042f805173d',1998,'PL','Poland','space',1101,'PL
PL
POL
616
PL
54 23 N
18 40 E
Dao Bach Long Vi [island]
Vietnam
20 08 N
107 44 E
Dardanelles [strait]
Atlantic Ocean
40 15 N
26 25 E
Dar es Salaam [US Embassy]
Tanzania
648S
39 17 E
Davis Strait
Atlantic Ocean
67 00 N
57 00 W
Dead Sea
Israel, Jordan, West Bank
32 30 N
35 30 E
Deception Island
50 03 N
19 58 E
Kuala Lumpur [US Embassy]
52 25 N
16 55 E
Prague [US Embassy]
Czech Republic
40 55 N
21 00 E
Praia [US Embassy]
Cape Verde
14 55 N
23 31 W
Pretoria [US Embassy]
52 15 N
21 00 E
Washington, DC [US Mission to the Organization of
American States (OAS)]','1d8c8f48b74a89f8c8aedd72e88aee2d7c7decb4a3ca2f817c75300f0a6dd449','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdb9e5eee28ae714cd58127ec6c0583aa45b09bd158a650c0a8742ca9b7312a2',1998,'PT','Portugal','space',1102,'PO
PT
PRT
620
PT
38 30 N
28 00 W
Azov, Sea of
Atlantic Ocean
49 00 N
36 00 E
B
Bab el Mandeb [strait]
Indian Ocean
12 40 N
43 20 E
Babuyan Channel
Pacific Ocean
18 44 N
121 40 E
Babuyan Islands
38 43 N
9 08 W
Ljubljana [US Embassy]
32 40 N
16 45 W
Madras [see Chennai]
37 44 N
25 40 W
Port-au-Prince [US Embassy]
15^|_isbon j
SPAIN Valencia^,.
■0/0 3Bursa^40''
^Gibraltar Malaga
V {U.KY-* ^
c* • ''r;. •• © .
BALEARIC
ISLANDS','6a8d43ac82e163529e1a746b41ccf5eed898cd51f6a05ab965ff6c83fd69b16c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a333e182db39d68ebd09101574f188bd4466ca25b5d035d142d41898e67468b8',1998,'QA','Qatar','space',1103,'QA
QA
QAT
634
QA
Reunion
RE
RE
REU
638
RE
25 17 N
51 32 E
Donets Basin
Russia, Ukraine
48 15 N
38 30 E
Douala','4955d49740bfc692d2bb1d8372bc75d9ae3989eeaaeed9ecb9176da6caac4a84','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5680e7329924a14f917bdaecc87be8ea3b73e7e887ce1ad5950329adc56ebbc',1998,'RO','Romania','space',1104,'RO
RO
ROM
642
RO
Russia
RS
RU
RUS
643
RU
Budapest [US Embassy]
46 47 N
23 36 E
619
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Cochin China [region]
Vietnam
11 00 N
107 00 E
Coco, Isla del
46 30 N
24 00 E
Trindade, llha de
''Milan Venice slovM®4* Zagreb
f Marseille1--^./
^ ^ V $ L BOSNIA AND / Belgrade
. - CAW \\ CROATIA \\heR2EGOVINAS \\ TBsevaKwmmB&aBSKm
^<4 ^K/Say»*
Ji . ITALY Aa^,c
{( \\^r ^
A V''MT* //^ iTjP^ ‘^URKEY
..-j. . . - k-^-/;s- . ■''w'' ''
.. J^r Ionian \\ ^
C// UK '' <
r X; V.J - Crete . *
Tunis*/ Scale 1: 19,500,000 ^^0^
mai TA^Valletta Lambert Conformal Conic Projection,
standard parallels 40’N and 56°N
TUNISIA |> 0 300 Kilometers
Slavonski Brod Federation of Bosnia
A ^and Herzegovina i
.m Prijedor
. Republika Srpska
rvV." .Ban''a Lulffl Dodo)
1. Inter-Entity
; j-r^Bputori&ty Line (IE8L) f j \\
Kljuc { (Dayton agreement fine) \\ i (,
? i \\ / >
Bijeljina* / Sabac^^^^^flr8tl<
wDrobeta-Tumu Severin
| ^n*n* Glarnoc,
^BOSNIA’ yt
X D ( L
) Zenlca*] J \\
tHE R Z E (3 0 V MSI A Srebrer
I Sarajevo 7^
Federation of Bosnia *Pa,e ^
and Herzegovina ^ -
| Republika
I Srpska 7
°* Serblia
Calafat','07f82abc1620bbf823a1dc6c5dfb0a01c99a79c3c425f5677bd3aaac84faba8d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bebd66e904625753d8b776a26fcdbc40cf50a86639b11010cd9d87ab75efeaca',1998,'RW','Rwanda','space',1105,'RW
RW
RWA
646
RW
Saint Helena
SH
SH
SHN
654
SH
1 57 S
30 04 E
Kingston [US Embassy]','15aeda0fcbfc245e7803100c62240540cef31adcb16175812f50d8ebf9895005','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19cec8e7c3d924ddc0843fb04805537f94f26b60ecda42e3074a92d23d453522',1998,'KN','Saint Kitts and Nevis','space',1106,'SC
KN
KNA
659
KN
17 18 N
62 43 W
Bastia
France (Corsica)
42 42 N
9 27 E
Basutoland
17 09 N
62 35 W
New Britain [island]
17 20 N
62 45 W
Saint Christopher and Nevis
17 20 N
62 45 W
Saint-Denis
Reunion
20 52 S
55 28 E
Saint George’s [US Embassy]','b12d7f3c36141b59fcfbc17ece2626242b14e44e3f7e2d9bbacbbc21b64439a5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc71aa9c4386b37f67029b96c04680555885dccfa23b68748ca3857d45246c0a',1998,'PM','Saint Pierre and Miquelon','space',1107,'SB
PM
SPM
666
PM
46 46 N
5611 W
Saint Thomas [island]
Virgin Islands
1821 N
64 55 W
Saint Vincent Passage
Atlantic Ocean
13 30 N
61 00 W
Saipan [island]','5f3b4523eada49054e3a893343bbc355ce55e7b25899c0db5ab52f4c6a8b4294','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb17cb938f3fa8eebaff52a583a2a645102dc1f3b495f985809bb3ef5ee0f293',1998,'VC','Saint Vincent and the Grenadines','space',1108,'VC
VC
VCT
670
VC
13 15 N
61 12 W
Grenadines, Southern
13 09N
61 14 W
Kinshasa [US Embassy]
Democratic Republic of the Congo
4 18 S
15 18 E
Kirghiziya
12 45 N
61 15 W
Northern Ireland','f7fd45ba0273617ac7bfedb7a091d01065f6f537682a52e4846729c1c7df353e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48cd9735470e53d6818d070406930e40a4e0b0618c82dd1c852412977a1a1589',1998,'WS','Samoa','space',1109,'ws .
WS
WSM
882
WS
13 50 S
171 44 N
Aqaba, Gulf of
Indian Ocean
29 00 N
34 30 E
Aqmola (see Astana)
1335S
172 20 W
Wetar Strait
Pacific Ocean
8 20 S
126 30 E
White Sea
Arctic Ocean
65 30 N
38 00 E
Willemstad
Netherlands Antilles
12 06 N
68 56 W
Windhoek [US Embassy]','3a94a70e309018a46028bfd8d984e48ce3c8045b677fa2040fc95afae5fc53c0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9bd3862d596ecaea78683f919153a90888fcb01fbd716e29d90c4e2f021d172',1998,'ST','Sao Tome and Principe','space',1110,'TP
ST
STP
678
ST
1 38 N
725 E
Prussia [region]
Germany, Poland, Russia
53 00 N
14 00 E
Pukapuka Atoll
0 12 N
6 39 E
Sapporo [US Consulate General]','7711440721705313c1166fd7d3bd53a3f264e8dcd074cddd9610bb463a003032','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c474b50e6622eb503b459732cb950d5c7b11ad1f993b19b03fb2f38f0573dee9',1998,'SA','Saudi Arabia','space',1111,'SA
SA
SAU
682
SA
26 18 N
50 08 E
Dhaka [US Embassy]
24 30 N
38 30 E
Helsinki [US Embassy]
21 30 N
39 12 E
Jerusalem [US Consulate General]
Israel, West Bank
31 47 N
35 14 E
Jiddah [US Consulate General]
21 30 N
39 12 E
Johannesburg [US Consulate General]
21 27 N
39 49 E
Medan [US Consulate General]
24 38 N
46 43 E
Road Town
British Virgin Islands
18 27 N
64 37 W
Robinson Crusoe Island (Mas a Tierra)','fd5f922035b0b0782b1a0923877173f9bca7addcc36b4e596f52a7569e33ada5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34ac144e6c23c05dc950abfdec85bee9ce99958a20a132c15d75050ad9b122e4',1998,'SN','Senegal','space',1112,'SG
SN
SEN
686
SN
Serbia*
SR
—
—
—
_
see footnote at end of table
Serbia and Montenegro*
—
—
—
—
see footnote at end of table
14 40 N
17 26 W
Dalmatia [region]','3f0009dacaaf566ca9e1ef9ff4828a1e40e589a52e8b54d266f56615a8144ca2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51d95518616fae42c2eb0c531267a07deb6e7e827233a58c20c2b010afeec610',1998,'SC','Seychelles','space',1113,'SE
SC
SYC
690
SC
925S
46 22 E
Alderney [island]
7 01 S
52 45 E
Amami Strait
Pacific Ocean
28 40 N
129 30 E
Amindivi Islands
600 S
5310E
Amman [US Embassy]
946 S
46 34 E
Astana (Akmola)
9 43 S
47 35 E
Cotonou [US Embassy]
10 10 s
51 10 E
Fernando de Noronha
441 S
55 30 E
Maiz, Islas del (Corn Islands)
4 38S
55 27 E
Vienna [US Embassy, US Mission to International
Organizations in Vienna (UNVIE)]','63ceacf2f188849bcf9683939f3cf4de8b1c88a49c780d34f0750972e832a413','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f482d670024501aa01d7d379c223db8eba11d36907e81a77609d8d0a232bf36',1998,'SG','Singapore','space',1114,'SN
SG
SGP
702
SG
1 17 N
103 51 E
Singapore Strait
Pacific Ocean
1 15 N
104 00 E
Sinkiang (Xinjiang)','212acdff304c35be97b2d280576b71626bd1847905255310043ae7cc4d054500','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edac372f481875a9e7b57f8dda9625f4cc972d395d99620a0e708468e683a5b7',1998,'SK','Slovakia','space',1115,'LO
SK
SVK
703
SK
48 09 N
17 07 E
Brazzaville [US Embassy]
Republic of the Congo
4 16 S
15 17 E
Bridgetown [US Embassy]','2ec9f28bb10754e9705975236d39a9ea9e33413b682bb15f47909bd9e42120fd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09e75b100663ab46215d172efed81e3ddb4f83268171c1ee2edd18b944828788',1998,'SI','Slovenia','space',1116,'SI
SI
SVN
705
SI
606
Entity
FIPS 10-4
ISO 3166
Internet
Comment
46 03 N
14 31 E
Lobamba
Swaziland
2627 S
31 12 E
Lombok Strait
Indian Ocean
8 30 S
1 1 5 50 E
Lome [US Embassy]','d4a845327ec7f8a84d6ef828ad7e3f9f62e0200c8b15fb33a934ca5c031c29e8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68b1b2a07a458cd61bb9d845c161d631cea13dfec007cc2f721dbc4339c4d30f',1998,'SB','Solomon Islands','space',1117,'BP
SB
SLB
090
SB
8 00 S
159 00 E
British Somaliland
7 05 S
121 00 E
Christmas Island [Indian Ocean]
9 32 S
160 12 E
Guadalupe, Isla de
9 26 S
159 57 E
Honshu [island]
11 00 S
166 15 E
Santiago [US Embassy]
800 S
159 00 E
Solomon Sea
Pacific Ocean
8 00 S
153 00 E
Songkhla','7203695c057724fe43328b7da4aed01d62fef38780dca66af85e8a6f83beb839','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3228154628cb261e18bdac66144c84bc13bdcd736416543dc4a4d9c2289da45',1998,'SO','Somalia','space',1118,'so
SO
SOM
706
SO
10 00 N
49 00 E
Brussels [US Embassy, US Mission to European
10 00 N
49 00 E
Iturup (see Etorofu)
Russia [de facto]
44 55 N
147 40 E
Ivory Coast
Cote d’Ivoire
8 00 N
5 00 W
Iwo Jima [island]
2 04 N
45 22 E
Moldavia [region]
Moldova, Romania
47 00 N
29 00 E
Moluccas (Spice Islands)','bfdfab31c5fd94aa0a912ef782c99c9cebe7460683700c9ffcf714b0687bf2d6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6676083f120f49b3fe531a5b236bc911308e28e320b1d8b6f0fcf0be139997b',1998,'ZA','South Africa','space',1119,'SF
ZA
ZAF
710
ZA
South Georgia and the South
Sandwich Islands
SX
GS
SGS
239
GS
WEKMSli
Boa Vista [island]
Cape Verde
16 05 N
22 50 W
Bogota [US Embassy]
26 30 S
25 30 E
Bora-Bora [island]
33 55 S
18 22 E
Caracas [US Embassy]
Venezuela
10 30 N
66 56 W
Cargados Carajos Shoals
33 00 S
27 00 E
Ciudad Juarez [US Consulate General]
29 55 S
30 56 E
Dushanbe [US Embassy]
34 24 S
18 30 E
Goteborg
26 15 S
28 00 E
Juan de Fuca, Strait of
Pacific Ocean
48 18 N
124 00 W
Juan Fernandez, Isla de
46 51 S
37 52 E
Marmara, Sea of
Atlantic Ocean
40 40 N
28 15 E
Marquesas Islands (lies Marquises)
25 45 S
28 10 E
Prevlaka peninsula
46 35 S
38 00 E
Prince Patrick Island
32 15 S
28 15 E
Transylvania [region]
2300S
31 00 E
Verde Island Passage
Pacific Ocean
1334N
120 51 E
Victoria','5622a3838a6563468ed97b33b5b01fba7987b1338a242aa39f4f8485aa968e05','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c338ef76b621c9ca4599071d9745c0a78e83cf0a20c4320949649e6ae3aea8d7',1998,'ES','Spain','space',1120,'SP
ES
ESP
724
ES
Spratly Islands
PG
—
—
—
—
35 13 N
353 W
Alma-Ata (see Almaty)
39 30 N
300 E
Balearic Sea (Iberian Sea)
Atlantic Ocean
40 30 N
2 00 E
Bali [island]
41 23 N
211 E
Barents Sea
Arctic Ocean
74 00 N
36 00 E
Barranquilla
43 00 N
2 30 W
Bass Strait
Pacific Ocean
39 20 S
145 30 E
Basse-Terre
43 15 N
2 58 W
Bioko [island]
28 00 N
15 30 W
Canberra [US Embassy]
42 00 N
2 00 E
Cato island
35 53 N
5 19 W
Ceylon
35 12 N
2 26 W
Chagos Archipelago (Oil Islands)
40 00 N
4 00 W
Essequibo [region] [claimed by Venezuela]
28 06 N
15 24 W
Lau Group
40 24 N
341 W
Magellan, Strait of
Atlantic Ocean
54 00 S
71 00 W
Maghreb
Algeria, Libya, Mauritania, Morocco, Tunisia
30 00 N
5 00 E
Mahe Island
39 30 N
3 00 E
Majuro [US Embassy]
39 30 N
3 00 E
Malpelo, Isla de
35 19 N
2 58 W
Merida [US Consulate]
40 00 N
4 00 E
Mitla Pass
3511 N
4 18 W
Venda','8fe8b1177bcb516475865156177ad90e0923aa2acc1b688339be43cc1fed0105','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f917fd1f09dd628f68723b906df25e58ff1e6b3827557ba51704d5612bdbefe8',1998,'LK','Sri Lanka','space',1121,'CE
LK
LKA
144
LK
7 00 N
81 00 E
Chafarinas, Islas
6 56 N
79 51 E
Colon, Archipielago de (Galapagos Islands)','54584b7239d2f8f4f2512c4ed0a1f110d5c350aa1f9546f4bbbcaa56464fc4d3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ab7cd81ee25f1df1dfa3dc77cef965fb38672e5c944d99cf752642269ae1a9b',1998,'SD','Sudan','space',1122,'su
SD
SDN
736
SD
15 00 N
30 00 E
Anjouan [island]
15 36 N
32 32 E
625
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Khmer Republic
20 30 N
33 00 E
Nukualofa
Omdurman^
Khartoum
J \\ «/aH
Port Sudan \\ Sc
r~T
Scale 1:21,000,000
Lambert Conformal Conic Projection,
standard parallels 12°N and 38‘N
0 300 Kilometers
! Boundary representation i^>
.jlj not necessarily authoritative.
A! Ghaydah .
V Al
\\ - 1 Aden >
; ''"tejShfiL W ■• >4*
II^SDjibouti
;^EMEN
Gulf of Ad 3i
^ Addis Ababa','8a7e176fb0990f899f6bfdeec61ad18ba2bdfd33020d53f8511d9c64832bd95e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3e29b2408674645d4025dfb8146b3bc0c6abc8f1bc5ff5fb38b04d2db36e85b',1998,'SR','Suriname','space',1123,'NS
SR
SUR
740
SR
Svalbard
SV
SJ
SJM
744
SJ
ISO includes Jan Mayen
Swaziland
wz
SZ
SWZ
748
SZ
4 00 N
56 00 W
Dutch West Indies
Netherlands Antilles
52 05 N
4 18 E
Dzungarian Gate
China, Kazakhstan
45 25 N
82 25 E
E East China Sea
Pacific Ocean
30 00 N
126 00 E
East Frisian Islands
4 00 N
56 00 W
Nevis [island]
550 N
55 10W
Parece Vela [island]
20 20 N
136 00 E
Paris [US Embassy, US Mission to the Organization
for Economic Cooperation and Development (OECD),
US Observer Mission to the UN Educational, Scientific,
and Cultural Organization (UNESCO)]
400 N
56 00 W
Suva [US Embassy]','3376a47619fec57d28338461973019a362dbb90b8109bb133809f2feff19d628','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b504bd353850a4dac06446dc3957f42a0b75574f825581a58562b1e44587e4bb',1998,'SE','Sweden','space',1124,'sw
SE
SWE
752
SE
57 43 N
11 58 E
Gotland [island]
57 30 N
18 33 E
Gough Island
Saint Helena
40 10 S
9 45 W
Grand Banks
Atlantic Ocean
47 06 N
55 48 W
Grand Cayman [island]
59 20 N
18 03 E
Strasbourg [US Consulate General]','7c81922f9667bff150d6049609570edb6fb9378fd7d42741dfc7b743c5ca0044','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('621b2ac860a0666e069ac22d1b5b110f904165e5714b5174457e5b7b23a2753b',1998,'CH','Switzerland','space',1125,'sz
CH
CHE
756
CH
Syria
SY
SY
SYR
760
SY
Taiwan
TW
TW
TWN
158
TW
46 57 N
7 26 E
Bessarabia [region]
Romania, Moldova, Ukraine
47 00 N
28 30 E
Bhopal
46 12 N
6 10 E
to European Office of the UN and Other
International Organizations]
Genoa
47 23 N
8 32 E
639
180 160 140 120 100 80 60 40
Greenland Sea
''±60\\CheW> S}Eberjan
\\ >)
RUSSIA C^fek
< R"v
Arctic, Ocean
Provider!
\\ \\ ^sx-
\\ \\ sr
1 I \\ .
U> Atari ^ /
/ X Af\\ /''
Ctute)\\
^uT
1« y, fe/^.A©Ss(U-^
ttse^Oitoocmi it^yj
(ScoresbysufKj/ ^
/ i %SS» / z1***''
^ ~ YV ''Tasiilaq /i Denmark
/ %i5H A fefl ppffin Rav\\ \\$P''^ (Ammassalil^ sfra/#
>* / Sec? U \\ ’Q\\ KangerlussuaqX
/ \\prudhoe Beaufort BaffinBay
Te7< V /Sea
NITED^STATES
- CZ Victo ria
0$ry (Spndre Stremfjordl
WY3''Vn?‘ T
,,,..1. vX L> A*, BJ&
\\ T \\ Xr-. n»s w
R \\$WBamn%^^ V/ C^1Godthlb)
S KuJsfana Hgfc \\ . Sw&j#
<X Fairbanks* i''/v, X- ^cjff ^ XX^T^ J?W P^asT
^2^ >X^Anchora8e )\\9^fQ^ strait™"**™
160 - ■v*1*5® Kodiak
i ™ P^Z W*£Hc-
fv, :.//r Acho Bay"
^hitehorse
j-O ""M- Watson x
M t .Uke ''i
RYeilowkQife
kangiqclir^q
{Rankin InlelTx
Has =ver* . \\ C A N A D . A j
l vYr;''— - i - ~T''- Hudson Bay\\
^/: ^ j JHhter^^^
!&r * _ j Athabasca *, Cf
OJfince Rupert* / ^ J/
C'' D . . / I
Prince /
Zj George / Edmonton z/’x r l
& r ■ /x-r XxXX
\\ X Chisasibi
\\ (Fort George)
/ North
Pacific
Ocean
''-''Saskatoon i \\ \\ Winnipeg
Vi i W caigarv ".Saskatoon
Mvancou/er ^ \\ •calgary
(4 .Reg^a j
| ^Seaf :
/Portland ,r l
^Sacr^mento"
.Winnipeg Thunder
j Lake Superior^,-
Bayex-\\ \\ Montreal/'' / /
*>v X Lake \\ Ottawa x
l Huron \\ I
\\ '' 1 ^Boston
V‘r‘/S\\ VrXftntrt--^ ia/re *V>
Labrador Sea
Happy ValleW/f^^-
Goose Bav jl X /s/and of
/file. y f v . /fyiewfpundland
y V Saint Jo4^\\
■ ''X''* Gulf of h y\\p
5f, Lawrence f St. Pierre
i f \\ and Miquelon
// /. 1 f\\X (FRANCE)
^r#“\\
I C is*e R-
1^- Minneapolis*x. Michigan i ( V NJ/ J/lLake Erie N^^Jew York
''N. Milwaukee! /Detroit JLQ& P''
M Milwaukee!
U N I T E D,S«J
x r-
^Philadelphia
\\Bittsburgh— T r
/ LasVegasvX«fi/
•i\\ Los Angeles,
Spn Difego^ /
/ Tijuana t Tjt
I Mexicali <>
STATE S
Chicago Cleveland ^Z^sfoAnom
/ Columbus ,. r \\ ★yVashington, D.C.
Indianapolis
- "* oj-Szci \\ North
\\St. Louis y \\ N°rf<4 Ben
lr \\ ^
X \\ / Atlantic
^Phoenix ^Albuquerque
^ \\ El Paso
* * .^Memphis \\ /
Oklahonja City # ^ / .Atlanta ^Charleston
e j V/ f \\ Ocean
\\ \\ oiuuau v : _ 4 ,
\\ft \\ Juarez \\<Z , S*an. Houston vPv
X \\ V ; [Antonio • t»-?'' *>.^-) v>
) •Hermosillo X/ \\ j *
^ *Chihuahua \\| p’"
Gulf of Mexico
\\ THE BAHAMAS
i\\ ^ Nassau ( ^
J''; \\ ^ ^ f; - x-
Scale: 1:38,700,000
Lambert Conformal Conic Projection,
standard parallels 37°N and 65 °N
0 300 600 Kilometers
300 600 Miles
Boundary representation is
not necessarily authoritative.
R MEXiqO irampi,
** ] Leon v)
Bahia de
_ Campeche
Veracruz
REV/LLAGIGEDO
(MEXICO)
★Welmopan ,
^ Xsu^temala^ / Tegucigalf','ee912caeb311aa82ec375be249a3f2d77bd803cbd72e413d550d63995b675cd5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('900f3a426beaadba273c6cf9ae84dac8bb42dc111e816bbf10ee4fede0d16469',1998,'TJ','Tajikistan','space',1126,'Tl
TJ
TJK
762
TJ
Tanzania
TZ
TZ
TZA
834
TZ
38 35 N
68 48 E
Dutch Antilles
Netherlands Antilles
52 05 N
4 18 E
Dutch East Indies','dfb90af5277af3b8972e30358046a830c58b1a2f748d6eecfdd2cc4dc08e7c5d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edcf1520882ad73ca73b96a5b6082e0a914d7252676a61aef53bc72728e2c88c',1998,'TH','Thailand','space',1127,'TH
TH
THA
764
TH
13 45 N
100 31 E
Bangui [US Embassy]
18 47 N
98 59 E
Chihli, Gulf of (see Bo Hai)
Pacific Ocean
38 30 N
120 00 E
China, People’s Republic of
15 00 N
100 00 E
Siberia [region]
Russia
60 00 N
100 00 E
Sibutu Passage
Pacific Ocean
4 50 N
119 35 E
Sicily [island]
7 12 N
100 36 E
Sound, The (Oresund)
Atlantic Ocean
55 50 N
12 40 E
South Atlantic Ocean
Atlantic Ocean
30 00 S
15 00 W
South China Sea
Pacific Ocean
10 00 N
113 00 E
South Georgia [island]
17 26 N
102 46 E
Ulaanbaatar [US Embassy]','40291ab4fd765a573e0cbc92dad6299a173528ba6fea508777988eefd754a415','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29f052b68feccfc65eef174b7c09f476d6a72f977434ad175d692c0e11d01133',1998,'TG','Togo','space',1128,'TO
TG
TGO
768
TG
8 00 N
1 10 E
French West Indies
Guadeloupe, Martinique
16 30 N
62 00 W
Friendly Islands
6 08 N
1 13 E
London [US Embassy]','4653141cca4a2d48a975b2950e8c8ed07780751e7deead40f7a890ab2ee7136c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f26bc34daece7a569e7c88a8750ad006076046ffeee46dcb0bbc2fe1076aa390',1998,'TO','Tonga','space',1129,'TN
TO
TON
776
TO
20 00 S
175 00 W
Frisian Islands
Denmark, Germany, Netherlands
53 35 N
6 40 E
Frunze (see Bishkek)
19 42S
174 29 W
Habomai Islands
Russia [de facto]
43 30 N
146 10 E
Hadhramaut [region]
21 08 S
175 12 W
Nuevo Laredo [US Consulate]','b33517c8a80a3567f136cc41708d25aae771873569e0e69fdc0616f91219e3e1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9b6d8bf592a06d92fe6d1f579ecb278fda77c19e6d8138d78f410d29ba0f21f',1998,'TT','Trinidad and Tobago','space',1130,'TD
TT
no
780
TT
Tromelin Island
TE
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
10 39 N
61 31 W
Porto-Novo
11 15 N
60 40 W
Tokyo [US Embassy]','546b63be9e8c1a5395a52cc6d0b30b01938d8d2ada1fd927c1ecdfc7dc27358d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f797b0644d9100c4980adfde685a709a3013a0e0fdaf02bb916f55f9f01bdac4',1998,'TM','Turkmenistan','space',1131,'TX
TM
TKM
795
TM
37 57 N
58 23 E
Asmara [US Embassy]
40 00 N
60 00 E
Turks Island Passage
Atlantic Ocean
21 40 N
71 00 W
Tuscany [region]','962162a0d062919e7d2322130e191b5eaadd6ae0bacc64a0afb9d55b57136979','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3783f055541eebe1b87bc7383a084814d22c698b45e93bed24c3e7b0f6dd841',1998,'TC','Turks and Caicos Islands','space',1132,'TK
TC
TCA
796
TC
21 56 N
71 58 W
Cairo [US Embassy]
21 28 N
71 08 W
Great Australian Bight
Indian Ocean
35 00 S
130 00 E
Great Belt (Store Baelt)
Atlantic Ocean
55 30 N
11 00 E
Great Bitter Lake','8ced59caf940a82f349ee93e9312e44e71d632e936cd8b78eb507f6b0c19d510','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e75ad5b709425b02e0c054354ba30d536d6033d9888acba04ad7ba5a20d0e3c8',1998,'TV','Tuvalu','space',1133,'TV
TV
TUV
798
TV
8 00 S
178 00 E
Elobey, Islas de
8 30 S
179-12 E
Fundy, Bay of
Atlantic Ocean
45 00 N
66 00 W
Futuna Islands (Hoorn Islands/lles de Horne)
u Funafuti
MatJ-Utu
• RAWAKI
• • (PHOENIX
• • ISLANDS)
6 Tokelau
%<NX)
American
SAMOA Samoa
★ ^ (U.6.)
KJrftimatl
, (Christmas Island)
(KIRIBATI)
• ^
U*','7d4a3848e92d5ec7c481087fa73626d4690dd2d1e183318ae36504a9ba869ed0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d07382d0940d5de73840454b4bf865fcf16bcd2c98223802cdb0e26bbc5aff91',1998,'UA','Ukraine','space',1134,'UP
UA
UKR
804
UA
45 00 N
34 00 E
Crimean Peninsula
45 00 N
3400 E
Crooked Island Passage
Atlantic Ocean
22 55 N
74 35 W
Crozet Islands (lies Crozet)
French Southern and Antarctic Lands
4630S
51 00 E
Curacao [US Consulate General]
Netherlands Antilles
1211 N
69 00 W
Cyclades [islands]
50 26 N
30 31 E
Kigali [US Embassy]
50 26 N
30 31 E
L Labrador
SLOVAKIA- '' T','3bc70a7022f52207c8c6c967f0cb8762d099be590559843ca129fc7a44fc0019','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d81687aca7f19d1390215267769ecd043d3700e2c69942e7ccd9f39bcbc8435',1998,'AE','United Arab Emirates','space',1135,'TC
AE
ARE
784
AE
24 28 N
54 22 E
Abu Musa [island]
Iran
25 52 N
55 03 E
Abuja [US Embassy Branch Office]
25 18 N
55 18 E
Dubayy (see Dubai)
25 18 N
55 18 E
Dublin [US Embassy]
24 00 N
54 00 E
Trucial Oman
24 00 N
54 00 E
Trucial States
24 00 N
54 00 E
Truk Islands
Federated States of Micronesia
7 25 N
151 47 E
Tsugaru Strait
Pacific Ocean
41 35 N
141 00 E
Tuamotu Islands (lies Tuamotu)','311f3cb011dd7cf47901716ff5e7261b046655e9d402f446b56417b3a6fe204a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2252ef3d2c7ad9bfab927c444590885a6400521cfe6b7c48b9ddabbd37fdf19',1998,'GB','United Kingdom','space',1136,'UK
GB
GBR
826
UK/GB
ISO includes Guernsey, Isle of Man,
5435 N
5 55 W
Belgian Congo
Democratic Republic of the Congo
000 N
2500 E
Belgrade
Serbia and Montenegro
44 50 N
20 30 E
Belize City [US Embassy]
49 52 N
627 W
Bismarck Archipelago
54 00 N
2 00 W
British East Africa
Kenya, Tanzania, Uganda
1 00 N
38 00 E
British Guiana
55 57 N
3 13 W
Eire
52 30 N
1 30 W
English Channel
Atlantic Ocean
50 20 N
1 00 W
Eniwetok Atoll (see Enewetak Atoll)
54 00 N
2 00 W
Great Channel
Indian Ocean
6 25 N
94 20 E
Greater Sunda Islands
Brunei, Indonesia, Malaysia
2 00S
1 1 0 00 E
Green Islands
51 30 N
010W
Longyearbyen
Svalbard
78 13 N
1 5 33 E
Lord Howe Island
54 40 N
6 45 W
Northern Rhodesia
59 00 N
3 00 W
Osaka-Kobe [US Consulate General]
57 35 N
13 48 W
Rodrigues [island]
57 00 N
4 00 W
634
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Scott Island
60 30 N
1 30 W
Shikoku [island]','3d40f3595a994640f4d6987341daa38c37e079c3da5855220ef2290b6e51a4da','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('837319b0ce1c41af8b1bd90b92af56d531ab4b85a33ea723a03184d7f24392a3',1998,'US','United States','space',1137,'US
US
USA
840
US
United States Minor Outlying
Islands
UM
UMI
581
UM
ISO includes Baker Island, Howland
Island, Jarvis Island, Johnston Atoll,
Kingman Reef, Midway Islands,
Palmyra Atoll, Wake Island
65 00 N
153 00 W
Alaska, Gulf of
Pacific Ocean
58 00 N
145 00 W
Aldabra Islands (Groupe d’Aldabra)
52 55 N
172 57 E
Auckland [US Consulate General]
20 00 N
157 45 W
Heard Island
57 49 N
152 23 W
Kola Peninsula (Kol’skiy Poluostrov)
Russia
67 20 N
37 00 E
Kolonia [US Embassy]
Federated States of Micronesia
658 N
158 13 E
Korea Bay
Pacific Ocean
3900 N
124 00 E
Korea, Democratic People’s Republic of
North Korea
4000 N
127 00 E
40 43 N
74 01 W
Nations (USUN)]
Newfoundland [island]
21 30 N
158 00 W
Ocean Island (Banaba)
28 25 N
178 20 W
Ogaden [region]
Ethiopia, Somalia
7 00 N
46 00 E
Oil Islands (Chagos Archipelago)
57 00 N
170 00 VV
Prince Edward Island
55 35 N
131 06 W
Revillagigedo Islands
49 30 N
67 00 W
Saint Lawrence Seaway
Atlantic Ocean
49 15 N
67 00 W
Saint Martin [island]
5711 N
170 16 W
Saint Paul Island (lie Saint-Paul)
French Southern and Antarctic Lands
38 43 S
77 29 E
633
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Saint Peter and Saint Paul Rocks (Penedos de
Sao Pedro e Sao Paulo)
38 53 N
77 02 W
Weddell Sea
Atlantic Ocean
72 00 S
45 00 W
Wellington [US Embassy]
Alaska
/ X Chukchi jf...r - - rPradhoetV'' . Xuvik ''
RUSSIA / \\ / C \\ \\
>/ - -fX
i . . XWJ‘ Bering^ Nome
^Provrdemya s trait VV
Arctic
Alaska','e71884be2614fcab85b5b0d1ef65bfbb465e1b57da25e53a5063bb478dde84de','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d41d0f80592221f60486b6e186862120d8c7b37c42a1441a0fc27702ca1ab02',1998,'UY','Uruguay','space',1138,'UY
UY
URY
858
UY
34 53 S
5611 W
Montreal [US Consulate General, US Mission to
the International Civil Aviation Organization (ICAO)]','ffdd35eb89a442ef6a0e40f824b286902b0a1ed83a0b2f551d38ae3d72c73fe4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bf4e811fdec2a5c1b4a3a9744f714cc4e7c8e3ca7dae5bb469b30b8a9b11680',1998,'UZ','Uzbekistan','space',1139,'UZ
UZ
UZB
860
UZ
41 20 N
69 18 E
636
Name
Latitude
(deg min)
Longitude
(deg min)
Entry in The World Factbook
Tasmania [island]
41 20 N
69 18 E
Transjordan
..Nukus
Ankara nSS^''" ARMENIA lSH^ilkte;Qayi, IS
fi^2T4? ; - — Jfl
«&**&■• I turkey^ ^ wSPfj f
T Denizli. | Konya# vd^" -C^A '' j
^ ^ i * ? jDjyarbaktr i®*tf 7 9) »Ta nz j
* * " (Mersin)^ , Adana Qgl^tep ^ l A :''"l. ''• , Ras^«";\\
" j '' i/''j :/^> IrbltVfc Zanjan itezvin
• ''crelf I Nicosja^ / ’ T 1
i r'' *3 / \\ KarkukC
CYPRUS W* SYRIA® ;x;.M S-v * ? • .Qom
Beirut dK^'' l % / .Kermanshah j
Mediterranean ! Sea LEBANON \\ C^dad\\ Arak# !
J- Bosporus
Sam sun j Batumi ,
*-"V . i V*','b93441a6280cf468cccfb178cf040000624868b326bfcc313e2ee117b166811c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e8818cd553e89960ae7bd66e34fb9e89c844e9e87e71e1c88189289cd72f270',1998,'VU','Vanuatu','space',1140,'NH
vu
VUT
548
vu
Venezuela
VE
VE
VEN
862
UE
Vietnam
VM
VN
VNM
704
VN
Virgin Islands
VQ
VI
VIR
850
VI
607
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
Virgin Islands (UK)
~~ —
—
—
—
—
see British Virgin Islands
Virgin Islands (US)
—
—
—
__
—
see Virgin Islands
Wake Island
WQ
—
—
—
ISO includes with the US Minor
Outlying Islands
14 00 S
167 30 E
Barbuda [island]
16 00 S
167 00 E
629
Appendix H: Cross-Reference List of Geographic Names (continued)
Latitude
Longitude
Name
Entry in The World Factbook
(deg min)
(deg min)
New Siberian Islands
Russia
75 00 N
142 00 E
New Territories
17 44 S
168 19 E
Poznan','6c4f6735680147c9fbb443d4f2367877df72ebcdbd2d4f71bf2843e94409d6c7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f724d49938072be1c0fadcad707b41db50f2d659283c35c3ef30154b15a9b2bb',1998,'WF','Wallis and Futuna','space',1141,'WF
WF
WLF
876
WF
West Bank
WE
—
—
__
—
14 19 S
178 05 W
G
Gaborone [US Embassy]
14 19 S
178 05 W
Horn of Africa
Djibouti, Eritrea, Ethiopia, Somalia
8 00 N
48 00 E
Hudson Bay
Arctic Ocean
60 00 N
86 00 W
Hudson Strait
Arctic Ocean
62 00 N
71 00 W
Hunter Island
New Caledonia, Vanuatu
22 24 S
172 06 E
1 Iberian Peninsula
Portugal, Spain
40 00 N
5 00 W
Inaccessible Island
Saint Helena
37 17 S
12 40 W
Indochina
Cambodia, Laos, Vietnam
15 00 N
107 00 E
Inland Sea
13 57 S
171 56 W
Matsu [island]
Taiwan
26 13 N
119 56 E
Matthew Island
New Caledonia, Vanuatu
22 20 S
171 20 E
Mazatlan
13 17 S
176 10 W
Walvis Bay','8bf74b428c3e5293f7adc1c0c6aa37af67a19443b22c5fe4966e9bc0804b43d7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2131b74d04f1f99ca43113bf9578937e7222b62f1f639793131f5bc7053922b9',1998,'EH','Western Sahara','space',1142,'Wl
EH
ESH
732
EH
Western Samoa
—
—
—
—
—
see Samoa
World
the Factbook uses the W data code
from DIAM 65-18 Geopolitical Data
Elements and Related Features, Data
Standard No. 3, December 1994,
published by the Defense Intelligence
Agency
23 45 N
Rio Muni
24 30 N
13 00 W
Spice Islands (Moluccas)','a8d538e800515f4aacdc3a61d196939f95ac91ddb084cbf98a29c5ee8ae72b7c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1b3d9b147fb4dca3139996c1765d9c9bb7e4b535c28ac84ac65c95c0591f4ac',1998,'YE','Yemen','space',1143,'YM
YE
YEM
887
YE
Yugoslavia*
—
YU
YUG
891
YU
see footnote at end of table
Zaire
—
—
—
—
see Democratic Republic of the Congo
12 46 N
45 01 E
Aden, Gulf of
Indian Ocean
12 30 N
48 00 E
Admiralty Island
United States (Alaska)
57 44 N
134 20 W
Admiralty Islands
15 00 N
50 00 E
623
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Hagatna (Agana)
1521 N
42 34 E
Kamchatka Peninsula (Poluostrov Kamchatka) ''
Russia
56 00 N
160 00 E
Kampala [US Embassy]
15 00 N
44 00 E
Northeast Providence Channel
Atlantic Ocean
25 40 N
77 09 W
Northern Epirus
Albania, Greece
40 00 N
20 30 E
Northern Grenadines
12 39 N
43 25 E
Perouse Strait, La
Pacific Ocean
44 45 N
142 00 E
Persia
Iran
32 00 N
53 00 E
Persian Gulf
Indian Ocean
27 00 N
51 00 E
Perth [US Consulate General]
15 21 N
44 12 E
San Ambrosio, Isla
12 30 N
54 00 E
Sofia [US Embassy]
14 00 N
48 00 E
South-West Africa
14 00 N
46 00 E
Yemen Arab Republic
15 00 N
44 00 E
Yemen, North [Yemen Arab Republic]
15 00 N
44 00 E
Yemen (Sanaa) [Yemen Arab Republic]
15 00 N
44 00 E
Yemen, People’s Democratic Republic of
MOON
46 00 E
Yemen, South [People’s Democratic Republic of Yemen]
MOON
46 00 E
Yerevan [US Embassy]','1ff308ec5e5110c8c3a1d91cc015cec879c04173bd1478d4611fea4909875ab8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6558ae9494d29030dc4de9088c3ca24fde4011422ce55e7ad13c980c8f49acdc',1998,'ZM','Zambia','space',1144,'ZA
ZM
ZWB
894
ZM
15 25 S
28 17 E
Luxembourg [US Embassy]
15 00 S
30 00 E
Northwest Passages
Arctic Ocean
74 40 N
100 00 W
Norwegian Sea
Atlantic Ocean
66 00 N
6 00 E
Nouakchott [US Embassy]
15 00 S
Rhodesia, Southern','558b929f2f5be9350ac7008dfc1226f3ac7d1d8b28870316dfce7ce20345b936','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce6e298471b67c11c7ac450a22be6848af807ee21ca9de2d59b5fbe44b050b45',1998,'GS','South Georgia and the South Sandwich Islands','space',1145,'53 39 S
41 48 W
617
Appendix H: Cross-Reference List of Geographic Names (continued)
Latitude
Longitude
Name
Entry in The World Factbook
(deg min)
(deg min)
Black Sea
Atlantic Ocean
Bloemfontein
54 15 S
36 45 W
Guadalajara [US Consulate General]
53 33 S
42 02 W
Shanghai [US Consulate General]
54 15 S
36 45 W
South Island
57 45 S
26 30 W
635
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
South Shetland Islands','c38af50dbc7630ef7cdd009b346a02fd37a89ad179ba0597b638613f9b5a7bb1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24d3f8c98a8bee5d1444f1e8010f65d74dd3b5da0da28112e13f47fdea18164f',1998,'KR','Korea, Republic of','space',1146,'South Korea
37 00 N
127 30 E
Korea Strait
Pacific Ocean
34 00 N
129 00 E
Koror [US Embassy]','bcce72c631020af96e9d7d5c0fd09bc4590b9cca9735727605d00d98ff161ec7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

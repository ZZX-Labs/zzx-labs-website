SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87b1c01f79e89665094c06b0798068c210132d773a4c555205755dbd17b3153d',1998,'US','United States','transnational-issues',14,'Disputes— international
Illicit drugs
xxv
Disputes— international: support to Islamic
militants worldwide by some factions; question over
which group should hold Afghanistan''s seat at the UN
Illicit drugs: world''s second-largest illicit opium
producer after Burma (cultivation in 1997—39,150
hectares, a 3% increase over 1996; potential
production in 1 997—1 ,265 metric tons, a 3% increase
over 1996) and a major source of hashish
USSR
Union of Soviet Socialist Republics (Soviet Union); used for information dated
before 25 December 1991
USSR/EE
Union of Soviet Socialist Republics/Eastern Europe
V
VHF
very-high-frequency
w
WADB
West African Development Bank
WAEMU
West African Economic and Monetary Union
WCL
World Confederation of Labor
WCO
World Customs Organization; see Customs Cooperation Council
Wetlands
Convention on Wetlands of International Importance Especially as Waterfowl
Habitat
WEU
Western European Union
WFC
World Food Council
WFP
World Food Program
WFTU
World Federation of Trade Unions
Whaling
International Convention for the Regulation of Whaling
WHO
World Health Organization
WIPO
World Intellectual Property Organization
WMO
World Meteorological Organization
WP
Warsaw Pact
WTO
see WToO for World Tourism Organization or WTrO for World Trade Organization
WToO
World Tourism Organization
WTrO
World T rade Organization
Y
YAR
Yemen Arab Republic [Yemen (Sanaa) or North Yemen]; used for information
dated before 22 May 1 990 or CY91
Z
ZC
Zangger Committee
531
Appendix B:
United Nations System
Main committee
Standing and
procedural committee
Other subsidiary
organs
UNSCOM
UN Compensation
Commission
Iraq/Kuwait Border •-
Demarcation
Commission
Trusteeship Council
Security Council
MINUGUA
MINURSO
MIPONUH
MONUA
UNDOF
UNFICYP
UNIFIL
UN1KOM
UNMIBH
UNMOGIP
UNMOP
UNMOT
UNOMIG
UNOMIL
UNPREDEP
UNTSO
General Assembly
Military Staff Committee
-□ IAEA
International Court
Secretariat
of Justice
UNRWA
UN Special Fund
UNCTAD
UNDP
UNEP
UNFPA
UNHCR
UNICEF
UNITAR
UNRISD
UNU
□
Economic and _ _
Social Council
— • Regional Commissions
— • Functional Commissions
— • Standing Committee
— • Expert Bodies
Principal organs of the United Nations
• Other United Nations organs
□ Specialized agencies and other
autonomous organizations
within the system
- □ FAO
— □ IBRD
- □ IDA
— □ IFC
- □ ICAO
- □ IFAD
- □ ILO
- □ IMF
- □ IMO
- □ ITU
- □ UNESCO
- □ UNIDO
- □ UPU
- □ WHO
- □ WIPO
- □ WMO
- □ WTrO
Based on chart from the UN Chronicle
532
Appendix C:
International Organizations
and Groups
advanced developing countries
another term for those less developed countries (LDCs) with particularly rapid industrial development; see newly
industrializing economies (NIEs)
advanced economies
a new term used by the International Monetary FUND (IMF) for the top group in its hierarchy of advanced
economies, countries in transition, and developing countries; recently published IMF statistics include the following
28 advanced economies: Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Greece, Hong
Kong, Iceland, Ireland, Israel, Italy, Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Portugal,
Singapore, Spain, Sweden, Switzerland, Taiwan, UK, US; note— this group would presumably also cover the
following seven smaller countries of Andorra, Bermuda, Faroe Islands, Holy See, Liechtenstein, Monaco, and San
Marino which are included in the more comprehensive group of "developed countries"
African, Caribbean, and Pacific Countries
(ACP)
address— Avenue Georges Henri 451, B-1200
Brussels, Belgium
telephone— [32] (2) 743 06 00
FAX— [32] (2) 735 55 73
established— 1 April 1976
aim— to manage their preferential economic and
aid relationship with the EU
members— (70) Angola, Antigua and Barbuda, The Bahamas, Barbados, Belize, Benin, Botswana, Burkina Faso,
Burundi, Cameroon, Cape Verde, Central African Republic, Chad, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cote d''Ivoire, Djibouti, Dominica, Dominican Republic, Equatorial Guinea, Eritrea, Ethiopia,
Fiji, Gabon, The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana, Haiti, Jamaica, Kenya, Kiribati,
Lesotho, Liberia, Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria, Papua
«New Guinea, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, Sudan, Suriname, Swaziland, Tanzania,
Togo, Tonga, Trinidad and Tobago, Tuvalu, Uganda, Vanuatu, Zambia, Zimbabwe
African Development Bank (AfDB)
note— also known as Banque Africaine de
Developpement (BAD)
address— 01 BP 1387, Abidjan 01, Cote d''Ivoire
telephone-[225] 20 41 18
FAX— [225] 20 40 06
established— 4 August 1963
aim— to promote economic and social
development
regional members— (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde,
Central African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya,
Lesotho, Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia, Niger,
Nigeria, Rwanda, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan,
Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
nonpermanent members— ( 25) Argentina, Austria, Belgium, Brazil, Canada, China, Denmark, Finland, France,
Germany, India, Italy, Japan, South Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain, Sweden,
Switzerland, UAE, UK, US
Agence de Cooperation Culturelle et
Technique (ACCT)
see Agency for Cultural and Technical Cooperation (ACCT)
Agence de la francophonie (ACCT)
see Agency for the French-speaking Community (ACCT)
Agency for Cultural and Technical
Cooperation (ACCT)
see Agency for the French-speaking Community (ACCT); acronym from Agence de Cooperation Culturelle et
Technique
Note: The Socialist Federal Republic of Yugoslavia (SFRY) ceases to exist. None of the successor states of the former Yugoslavia, including Serbia and Montenegro,
have been permitted to participate solely on the basis of the membership of the former Yugoslavia in the United Nations General Assembly and Economic and Social
Council and their subsidiary bodies and in various United Nations specialized agencies. The United Nations, however, permits the seat and nameplate of the SFRY to
remain, permits the SFRY mission to continue to function, and continues to fly the flag of the former Yugoslavia. For a variety of reasons, a number of other organizations
have not yet taken action with regard to the membership of the former Yugoslavia. The World Factbook therefore continues to list Yugoslavia under international
organizations where the SFRY seat remains or where no action has yet been taken.
533
Appendix C: International Organizations and Groups (continued)
Agency for the French-speaking Community
(ACCT)
note— formerly Agency for Cultural and
Technical Cooperation
address— 13 quai Andre-Citroen, F-75015
Paris, France
telephone— {33] (1)44 37 33 00
FAX-{33] (1)45 79 14 98
established—. 21 March 1970
name changed— 1996
aim— to promote cultural and technical
cooperation among French-speaking countries
Agency for the Prohibition of Nuclear
Weapons in Latin America and the Caribbean
(OPANAL)
note-acronym from Organismo para la
Proscripcion de las Armas Nucleares en la
America Latina y el Caribe (OPANAL)
address— Temistocles 78, Col Polanco, CP
01 1 560, Mexico City 5 DF, Mexico
telephone— {52] (5) 280 4923, 280 5064, 280
2715
FAX— [52] (5) 280 2965
established— 14 February 1967
aim— to encourage the peaceful uses of atomic
energy and prohibit nuclear weapons
Andean Group (AG)
note— known also as the Andean Parliament
address— Carrera 7a, No. 13-58, Oficina 401,
Apartado Aereo 039165, Santafe de Bogota,
Columbia
telephone— {57] (1) 284 41 91, 284 40 28, 284
33 74
FAX— [57] (1) 184 32 70
established— 26 May 1969
effective — 1 6 October 1 969
aim— to promote harmonious development
through economic integration
Arab Bank for Economic Development in
Africa (ABEDA)
note— also known as Banque Arabe de
Developpement Economique en Afrique
(BADEA)
address— Abdel Rahman El Mahdi Avenue,
P.O. Box 2640, Khartoum, Sudan
telephone— {249] (11) 770498, 773646, 773709
FAX— [249] (11)770600
established— 18 February 1974
effective—'' 16 September 1974
a/m— to promote economic development
members— (40) Belgium, Benin, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Comoros, Democratic Republic of the Congo (may have dropped out), Republic of
the Congo, Cote d''Ivoire, Djibouti, Dominica, Equatorial Guinea, France, Gabon, Guinea, Haiti, Laos, Lebanon,
Luxembourg, Madagascar, Mali, Mauritius, Moldova, Monaco, Niger, Romania, Rwanda, Senegal, Seychelles,
Switzerland, Togo, Tunisia, Vanuatu, Vietnam
associate members— { 5) Egypt, Guinea-Bissau, Mauritania, Morocco, Saint Lucia
participating governments— (2) New Brunswick (Canada), Quebec (Canada)
members— (30) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia,
Costa Rica, Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Haiti, Honduras, Jamaica,
Mexico, Nicaragua, Panama, Paraguay, Peru, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad
and Tobago, Uruguay, Venezuela
members— (5) Bolivia, Colombia, Ecuador, Peru, Venezuela
associate members— (1 ) Panama
observers— (26) Argentina, Australia, Austria, Belgium, Brazil, Canada, Costa Rica, Denmark, Egypt, Finland,
France, Germany, India, Israel, Italy, Japan, Mexico, Netherlands, Paraguay, Spain, Sweden, Switzerland, UK, US,
Uruguay, Yugoslavia
members— (17 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE, Palestine Liberation
Organization; note— these are all the members of the Arab League excluding Comoros, Djibouti, Somalia, Yemen
534
Arab Cooperation Council (ACC)
members— (4) Egypt, Iraq, Jordan, Yemen
established— 16 February 1989
aim— to promote economic cooperation and
integration, possibly leading to an Arab
Common Market
Arab Fund for Economic and Social
Development (AFESD)
address— P.O. Box 21923, Safat 13080, Kuwait
telephone— [965] 4844500
FAX— (965] 4815750, 4815760, 4815770
established— 16 May 1968
aim— to promote economic and social
development
members— (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt (suspended
from 1979 to 1988), Iraq (suspended 1993), Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar,
Saudi Arabia, Somalia (suspended 1993), Sudan (suspended 1993), Syria, Tunisia, UAE, Yemen, Palestine
Liberation Organization
Arab League (AL)
note— also known as League of Arab States
(LAS)
address— Midan Attahrir, Tahrir Square,
P.O. Box 11642, Cairo, Egypt
telephone— [20] (2) 750 511
FAX-[20] (2) 740 331
established— 22 March 1945
aim— to promote economic, social, political, and
military cooperation
members— (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan,
Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE,
Yemen, Palestine Liberation Organization
Arab Maghreb Union (AMU)
address— 27 avenue Okba Agdal, Rabat,','57c56c537b7048eb94186722a631ce60d8afb641a41b13ba079914e2a484cc84','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d176b3d2bd489cbcfedfad5e97c9b9005362d3a66395985050e8ff0c87c0de2',1998,'AL','Albania','transnational-issues',16,'Location: Southeastern Europe, bordering the
Adriatic Sea and Ionian Sea, between Greece and
Serbia and Montenegro
Geographic coordinates: 41 00 N, 20 00 E
Map references: Europe
Area:
total: 28,750 sq km
land: 27,400 sq km
water: 1 ,350 sq km
Area— comparative: slightly smaller than Maryland
Land boundaries:
total: 720 km
border countries: Greece 282 km, The Former
Yugoslav Republic of Macedonia 151 km, Serbia and
Montenegro 287 km (1 1 4 km with Serbia, 1 73 km with
Montenegro)
Coastline: 362 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 nm
Climate: mild temperate; cool, cloudy, wet winters;
hot, clear, dry summers; interior is cooler and wetter
Terrain: mostly mountains and hills; small plains
along coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit 2,753 m
Natural resources: petroleum, natural gas, coal,
chromium, copper, timber, nickel
Land use:
arable land: 21%
permanent crops: 5%
permanent pastures: 15%
forests and woodland: 38%
other: 21% (1993 est.)
Irrigated land: 3,410 sq km (1993 est.)
Natural hazards: destructive earthquakes; tsunamis
occur along southwestern coast
Environment— current issues: deforestation; soil
erosion; water pollution from industrial and domestic
effluents
Environment— international agreements:
party to: Biodiversity, Climate Change, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location along Strait of
Otranto (links Adriatic Sea to Ionian Sea and
Mediterranean Sea)
Disputes— international: the Albanian Government
supports protection of the rights of ethnic Albanians
outside of its borders but has downplayed them to
further its primary foreign policy goal of regional
cooperation; Albanian majority in Kosovo seeks
independence from Serbian Republic; Albanians in
The Former Yugoslav Republic of Macedonia claim
discrimination in education, access to public-sector
jobs and representation in government
Illicit drugs: increasingly active transshipment point
for Southwest Asian opiates, hashish, and cannabis
transiting the Balkan route and cocaine from South
America destined for Western Europe; limited opium
and cannabis production; ethnic Albanian
narcotrafficking organizations active in Central and
Eastern Europe','527d554fadfb0ad37d1a22af0edf98ba0082f076ba3f40da966860a2589d81e8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c12ec1802ff7eaa8f8edbf04d40fc3fd81c570906cde3026d5e0ac761837795f',1998,'DZ','Algeria','transnational-issues',27,'Disputes— international: part of southeastern
region claimed by Libya
7
Canary Islands are not shown.
Disputes— international: Gibraltar question with
UK; Spain controls five places of sovereignty (plazas
de soberania) on and off the coast of Morocco— the
coastal enclaves of Ceuta and Melilla, which Morocco
contests, as well as the islands of Penon de
Alhucemas, Penon de Velez de la Gomera, and Islas
Chafarinas
Illicit drugs: key European gateway country for Latin
American cocaine and North African hashish entering
the European market; transshipment point for and
consumer of Southwest Asian heroin
Spratly Islands
South','4745d02e64578e85914cee449e22217ce20d718b4a0e9806a02daba328f56b8b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08fe9b46ef64225f8a6db1a14f91f0560e64df30f79faaa5979f35515a30b1f5',1998,'AS','American Samoa','transnational-issues',28,'(territory of the US)
Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 14 20 S, 170 00 W
Map references: Oceania
Area:
total: 199 sq km
land: 199 sq km
water: 0 sq km
note: includes Rose Island and Swains Island
Area— comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 116 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical marine, moderated by southeast
trade winds; annual rainfall averages 124 inches;
rainy season from November to April, dry season from
May to October; little seasonal temperature variation
Terrain: five volcanic islands with rugged peaks and
limited coastal plains, two coral atolls (Rose Island,
Swains Island)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Lata 966 m
Natural resources: pumice, pumicite
Land use:
arable land: 5%
permanent crops: 10%
permanent pastures: 0%
forests and woodland: 70%
other: 15% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons common from December
to March
Environment— current issues: limited natural fresh
water resources; the water division of the government
has spent substantial funds in the past few years to
improve water catchments and pipelines
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Geography— note: Pago Pago has one of the best
natural deepwater harbors in the South Pacific Ocean,
sheltered by shape from rough seas and protected by
peripheral mountains from high winds; strategic
location in the South Pacific Ocean
Disputes— international: none
Disputes— international: none
Disputes— international: none
Illicit drugs: increasingly used as a transshipment
point for cocaine and heroin destined for Western
Europe and other African states','c912e054faac24350cd88e00a49a6321fc1f1ea9a921e4d99c31585313ef2ea8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55b8a6034fdad5c797d81da7de4d1f56321f26b7ff0e5c2bc401c14c4748befd',1998,'AQ','Antarctica','transnational-issues',44,'Disputes— international: Antarctic Treaty defers
claims (see Antarctic Treaty Summary above);
sections (some overlapping) claimed by Argentina,
Australia, Chile, France (Adelie Land), New Zealand
(Ross Dependency), Norway (Queen Maud Land),
and UK; the US and most other nations do not
recognize the territorial claims of other nations and
have made no claims themselves (the US reserves
the right to do so); no formal claims have been made
in the sector between 90 degrees west and 150
degrees west
16
Disputes— international: short section of the
southwestern boundary with Chile is indefinite; claims
UK-administered Falkland Islands (Islas Malvinas);
claims UK-administered South Georgia and the South
Sandwich Islands; territorial claim in Antarctica
Illicit drugs: increasing use as a transshipment
country for cocaine headed for Europe and the US
21
Disputes— international: Armenia supports ethnic
Armenians in the Nagorno-Karabakh region of
Azerbaijan in the longstanding, separatist conflict
against the Azerbaijani Government; traditional
demands on former Armenian lands in Turkey have
subsided
Illicit drugs: illicit cultivator of cannabis mostly for
domestic consumption; used as a transshipment point
for illicit drugs to Western Europe and the US
Disputes— international: none
Illicit drugs: drug money-laundering center and
transit point for narcotics bound for the US and
Europe; added to the US list of major drug producing
or drug transit countries in December 1 996
25
Ashmore and
Cartier Islands
(territory of Australia)
my
INDONESIA v-
O''
G:?c-
Map Area — ~^r
/
y AUSTRALIA
400 SWkm
400 800 mi
Hibernia
^''""2; Reef
(AUSTRALIA)
O Ashmore Reef
wdst t
Islet
0 Middle
Islet
East Islet
Indian Oce: n
0 10 20 km
0 10 20 mi
^ .. reef
Cartier {-c"
Island
Disputes— international: none
Atlantic Ocean
f Geography
Location: body of water between Africa, Europe,
Antarctica, and the Western Hemisphere
Geographic coordinates: 0 00 N, 25 00 W
Map references: World
Area:
total: 82.21 7 million sq km
note: includes Baltic Sea, Black Sea, Caribbean Sea,
Davis Strait, Denmark Strait, Drake Passage, Gulf of
Mexico, Mediterranean Sea, North Sea, Norwegian
Sea, Scotia Sea, Weddell Sea, and other tributary
water bodies
Area— comparative: slightly less than nine times the
size of the US; second-largest of the world''s four
oceans (after the Pacific Ocean, but larger than Indian
Ocean or Arctic Ocean)
Coastline: 111,866 km
Climate: tropical cyclones (hurricanes) develop off
the coast of Africa near Cape Verde and move
westward into the Caribbean Sea; hurricanes can
occur from May to December, but are most frequent
from August to November
Terrain: surface usually covered with sea ice in
Labrador Sea, Denmark Strait, and Baltic Sea from
October to June; clockwise warm water gyre (broad,
circular system of currents) in the northern Atlantic,
counterclockwise warm water gyre in the southern
Atlantic; the ocean floor is dominated by the
Mid-Atlantic Ridge, a rugged north-south centerline
for the entire Atlantic basin
Elevation extremes:
lowest point: Puerto Rico Trench -8,605 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, marine
mammals (seals and whales), sand and gravel
aggregates, placer deposits, polymetallic nodules,
precious stones
Natural hazards: icebergs common in Davis Strait,
Denmark Strait, and the northwestern Atlantic Ocean
from February to August and have been spotted as far
26
south as Bermuda and the Madeira Islands; icebergs
from Antarctica occur in the extreme southern Atlantic
Ocean; ships subject to superstructure icing in
extreme northern Atlantic from October to May and
extreme southern Atlantic from May to October;
persistent fog can be a maritime hazard from May to
September
Environment— current issues: endangered marine
species include the manatee, seals, sea lions, turtles,
and whales; drift net fishing is hastening the decline of
fish stocks and contributing to international disputes;
municipal sludge pollution off eastern US, southern
Brazil, and eastern Argentina; oil pollution in
Caribbean Sea, Gulf of Mexico, Lake Maracaibo,
Mediterranean Sea, and North Sea; industrial waste
and municipal sewage pollution in Baltic Sea, North
Sea, and Mediterranean Sea
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography— note: major chokepoints include the
Dardanelles, Strait of Gibraltar, access to the Panama
and Suez Canals; strategic straits include the Strait of
Dover, Straits of Florida, Mona Passage, The Sound
(Oresund), and Windward Passage; the Equator
divides the Atlantic Ocean into the North Atlantic
Ocean and South Atlantic Ocean
Disputes— international: some maritime disputes
(see littoral states)
Location: Oceania, continent between the Indian
Ocean and the South Pacific Ocean
Geographic coordinates: 27 00 S, 133 00 E
Map references: Oceania
Area:
total: 7,686,850 sq km
land: 7,617,930 sq km
water: 68,920 sq km
note: includes Lord Howe Island and Macquarie
Island
Area— comparative: slightly smaller than the US
Land boundaries: 0 km
Coastline: 25,760 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: generally arid to semiarid; temperate in
south and east; tropical in north
Terrain: mostly low plateau with deserts; fertile plain
in southeast
Elevation extremes:
lowest point: Lake Eyre -15 m
highest point: Mount Kosciusko 2,229 m
Natural resources: bauxite, coal, iron ore, copper,
tin, silver, uranium, nickel, tungsten, mineral sands,
lead, zinc, diamonds, natural gas, petroleum
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 54%
forests and woodland: 1 9%
other: 21 % (1 993 est.)
Irrigated land: 21,070 sq km (1993 est.)
Natural hazards: cyclones along the coast; severe
droughts
27
Australia (continued)
Environment— current issues: soil erosion from
overgrazing, industrial development, urbanization,
and poor farming practices; soil salinity rising due to
the use of poor quality water; desertification; clearing
for agricultural purposes threatens the natural habitat
of many unique animal and plant species; the Great
Barrier Reef off the northeast coast, the largest coral
reef in the world, is threatened by increased shipping
and its popularity as a tourist site; limited natural fresh
water resources
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed , but not ratified: Desertification
Geography— note: world''s smallest continent but
sixth-largest country; population concentrated along
the eastern and southeastern coasts; regular, tropical,
invigorating, sea breeze known as "the Doctor" occurs
along the west coast in the summer
Disputes— international: territorial claim in
Antarctica (Australian Antarctic Territory)
Illicit drugs: Tasmania is one of the world’s major
suppliers of licit opiate products; government
maintains strict controls over areas of opium poppy
cultivation and output of poppy straw concentrate
29
Disputes— international: none
Illicit drugs: transshipment point for Southwest
Asian heroin and South American cocaine destined
for Western Europe','da506ca0a6f4dbf5c2f2747f7c265998282030297d7be51fb9d76f1f5f796df3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9851b8af9364d5681a0788eb0922daf7924f2dbdf64141a4835a42fe58727c4b',1998,'AG','Antigua and Barbuda','transnational-issues',52,'Disputes— international: none
Illicit drugs: considered a long-time but relatively
minor transshipment point for narcotics bound for the
US and Europe and recent transshipment point for
heroin from Europe to the US; potentially more
significant as a drug money-laundering center
18
Arctic Ocean
f Geog r a p h y
Location: body of water mostly north of the Arctic
Circle
Geographic coordinates: 90 00 N, 0 00 E
Map references: Arctic Region
Area:
total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea, Beaufort Sea,
Chukchi Sea, East Siberian Sea, Greenland Sea,
Hudson Bay, Hudson Strait, Kara Sea, Laptev Sea,
Northwest Passage, and other tributary water bodies
Area— comparative: slightly less than 1 .5 times the
size of the US; smallest of the world''s four oceans
(after Pacific Ocean, Atlantic Ocean, and Indian
Ocean)
Coastline: 45,389 km
Climate: polar climate characterized by persistent
cold and relatively narrow annual temperature ranges;
winters characterized by continuous darkness, cold
and stable weather conditions, and clear skies;
summers characterized by continuous daylight, damp
and foggy weather, and weak cyclones with rain or
snow
Terrain: central surface covered by a perennial
drifting polar icepack that averages about 3 meters in
thickness, although pressure ridges may be three
times that size; clockwise drift pattern in the Beaufort
Gyral Stream, but nearly straight line movement from
the New Siberian Islands (Russia) to Denmark Strait
(between Greenland and Iceland); the icepack is
surrounded by open seas during the summer, but
more than doubles in size during the winter and
extends to the encircling land masses; the ocean floor
is about 50% continental shelf (highest percentage of
any ocean) with the remainder a central basin
interrupted by three submarine ridges (Alpha
Cordillera, Nansen Cordillera, and Lomonsov Ridge)
Elevation extremes:
lowest point: Fram Basin -4,665 m
highest point: sea level 0 m
Natural resources: sand and gravel aggregates,
placer deposits, polymetallic nodules, oil and gas
fields, fish, marine mammals (seals and whales)
Natural hazards: ice islands occasionally break
away from northern Ellesmere Island; icebergs calved
from glaciers in western Greenland and extreme
northeastern Canada; permafrost in islands; virtually
icelocked from October to June; ships subject to
superstructure icing from October to May
Environment— current issues: endangered marine
species include walruses and whales; fragile
ecosystem slow to change and slow to recover from
disruptions or damage
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography— note: major chokepoint is the southern
Chukchi Sea (northern access to the Pacific Ocean
via the Bering Strait); strategic location between North
America and Russia; shortest marine link between the
extremes of eastern and western Russia, floating
research stations operated by the US and Russia;
maximum snow cover in March or April about 20 to 50
centimeters over the frozen ocean; snow cover lasts
about 10 months
Disputes— international: some maritime disputes
(see littoral states); Svalbard is the focus of a maritime
boundary dispute between Norway and Russia','6ea651f945caac57e19efc5e2fecbaaf2618c3e3f2581e0ae36d76d34ad8ccfa','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e96ee303388c9cd7fc7ff4516aee8688000fa3ae4116de423d9aa8b51ac79325',1998,'AZ','Azerbaijan','transnational-issues',55,'Current issues: Azerbaijan continues to be plagued
by an unresolved ten-year-old conflict with Armenian
separatists over its Nagorno-Karabakh region. The
Karabakh Armenians have declared independence
and seized almost 20% of the country''s territory,
creating almost 1 million Azerbaijani refugees in the
process. Both sides have generally observed a
Russian-mediated cease-fire in place since May
1994.
Disputes— international: Armenia supports ethnic
Armenians in the Nagorno-Karabakh region of
Azerbaijan in the longstanding, separatist conflict
against the Azerbaijani Government; Caspian Sea
boundaries are not yet determined among Azerbaijan,
Iran, Kazakhstan, Russia, and Turkmenistan
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for CIS consumption; limited
government eradication program; transshipment point
for opiates to Western Europe
Location: Caribbean, chain of islands in the North
Atlantic Ocean, southeast of Florida
Geographic coordinates: 24 15 N, 76 00 W
Map references: Central America and the
Caribbean
Area:
total: 13,940 sq km
land: 10,070 sq km
water: 3,870 sq km
Area— comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 3,542 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation (measured from the archipelagic straight
baselines)
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical marine; moderated by warm waters
of Gulf Stream
Terrain: long, flat coral formations with some low
rounded hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Alvernia, on Cat Island 63 m
Natural resources: salt, aragonite, timber
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 32%
other: 67% (1 993 est.)
Irrigated land: NA sq km
Natural hazards: hurricanes and other tropica!
storms that cause extensive flood and wind damage
Environment— current issues: coral reef decay;
solid waste disposal
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location adjacent to US
and Cuba; extensive island chain','826e23e0d4c36d158de2764d67caccb1cf1c07393a156e08c9d695e40f90832a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6efa45f77a0589fdb6746728599e08be424a5214e27fd15cb9cab1eac368928f',1998,'BS','Bahamas','transnational-issues',68,'Disputes— international: none
Illicit drugs: transshipment point for cocaine and
marijuana bound for US and Europe; banking industry
vulnerable to money-laundering
Disputes— international: none
Disputes— international: none
482
f Geography
Location: Eastern Europe, bordering the Black Sea,
between Poland and Russia
Geographic coordinates: 49 00 N, 32 00 E
Map references: Commonwealth of Independent
States
Area:
total: 603,700 sq km
land: 603,700 sq km
water: 0 sq km
Area— comparative: slightly smaller than Texas
Land boundaries:
total: 4,558 km
border countries: Belarus 891 km, Hungary 103 km,
Moldova 939 km, Poland 428 km, Romania (south)
169 km, Romania (west) 362 km, Russia 1,576 km,
Slovakia 90 km
Coastline: 2,782 km
Maritime claims:
continental shelf: 200-m or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate continental; Mediterranean only
on the southern Crimean coast; precipitation
disproportionately distributed, highest in west and
north, lesser in east and southeast; winters vary from
cool along the Black Sea to cold farther inland;
summers are warm across the greater part of the
country, hot in the south
Terrain: most of Ukraine consists of fertile plains
(steppes) and plateaus, mountains being found only in
the west (the Carpathians), and in the Crimean
Peninsula in the extreme south
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Hora Hoverla 2,061 m
Natural resources: iron ore, coal, manganese,
natural gas, oil, salt, sulfur, graphite, titanium,
magnesium, kaolin, nickel, mercury, timber
Land use:
arable land: 58%
permanent crops: 2%
permanent pastures: 13%
forests and woodland: 18%
other: 9% (1993 est.)
Irrigated land: 26,050 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: inadequate
supplies of potable water; air and water pollution;
deforestation; radiation contamination in the northeast
from 1 986 accident at Chornobyl1 Nuclear Power Plant
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Antarctic Treaty,
Biodiversity, Climate Change, Environmental
Modification, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Law of the Sea
Geography— note: strategic position at the
crossroads between Europe and Asia; second-largest
country in Europe
l People
Population: 50,125,108 (July 1998 est.)
Age structure:
0-74 years: 19% (male 4,852,461 ; female 4,656,688)
15-64 years: 67% (male 1 6,096,737; female
17,481,600)
65 years and over: 14% (male 2,284,960; female
4,752,662) (July 1998 est.)
Population growth rate: -0.64% (1998 est.)
Birth rate: 9.53 births/1 ,000 population (1998 est.)
Death rate: 16.31 deaths/1,000 population (1998
est.)
Net migration rate: 0.43 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.48 male(s)/female (1 998 est.)
Infant mortality rate: 21 .8 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 65.84 years
male: 60.08 years
female: 71 .89 years (1 998 est.)
Total fertility rate: 1 .35 children born/woman (1 998
est.)
Nationality:
noun: Ukrainian(s)
adjective: Ukrainian
Ethnic groups: Ukrainian 73%, Russian 22%,
Jewish 1%, other 4%
Religions: Ukrainian Orthodox— Moscow
Patriarchate, Ukrainian Orthodox— Kiev Patriarchate,
Ukrainian Autocephalous Orthodox, Ukrainian
Catholic (Uniate), Protestant, Jewish
Languages: Ukrainian, Russian, Romanian, Polish,
Hungarian
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 100%
female: 97% (1989 est.)','edbc543515fac15afcf7dc939ed1a0dfc156386ce3ad5cb1693bc00decf3ae62','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23487e2500f1c20d2c9f4fb96ceafdafd5c9851c185955a067a1a3902feead1c',1998,'BH','Bahrain','transnational-issues',69,'Location: Middle East, archipelago in the Persian
Gulf, east of Saudi Arabia
Geographic coordinates: 26 00 N, 50 33 E
Map references: Middle East
Area:
total: 620 sq km
land: 620 sq km
water: Osq km
Area— comparative: 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 161 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: extending to boundaries to be
determined
territorial sea: 12 nm
Climate: arid; mild, pleasant winters; very hot, humid
summers
Terrain: mostly low desert plain rising gently to low
central escarpment
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jaba! ad Dukhan 122 m
Natural resources: oil, associated and
nonassociated natural gas, fish
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 6%
forests and woodland: 0%
other: 92% (1 993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: periodic droughts; dust storms
Environment— current issues: desertification
resulting from the degradation of limited arable land,
periods of drought, and dust storms; coastal
degradation (damage to coastlines, coral reefs, and
sea vegetation) resulting from oil spills and other
36
discharges from large tankers, oil refineries, and
distribution stations; no natural fresh water resources
so that groundwater and sea water are the only
sources for all water needs
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection
signed , but not ratified: none of the selected
agreements
Geography— note: close to primary Middle Eastern
petroleum sources; strategic location in Persian Gulf
which much of Western world’s petroleum must transit
to reach open ocean
Disputes— international: territorial dispute with
Qatar over the Hawar Islands and maritime boundary
dispute with Qatar currently before the International
Court of Justice (ICJ)
38
vegetation consisting of grasses, prostrate vines, and
low growing shrubs; primarily a nesting, roosting, and
foraging habitat for seabirds, shorebirds, and marine
wildlife
l, People
Population: uninhabited
note: American civilians evacuated in 1 942 after
Japanese air and naval attacks during World War II;
occupied by US military during World War II, but
abandoned after the war; public entry is by
special-use permit only and generally restricted to
scientists and educators; a cemetery and cemetery
ruins are located near the middle of the west coast','099ef4ce013e7652241c432c6b6cceb632d44edd0f1ca30b091aae498ef045c7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edb225d744ba5db08ee9863316ffb937ec5e786f068e7cbc0677a4bed5af818d',1998,'BD','Bangladesh','transnational-issues',81,'Disputes— international: a portion of the boundary
with India is indefinite
Illicit drugs: transit country for illegal drugs
produced in neighboring countries','5204dec1147550e57bee1cbaba42a565b2f3c90032a8c8aac34bec2a0dca1e3a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c2d41cb5013a1f2d525df71fb4fdcb051b92400f719c11533c1b9cd44af6662',1998,'FR','France','transnational-issues',92,'Disputes— international: claimed by Madagascar
G e o g r a p h y
Location: Eastern Europe, east of Poland
Geographic coordinates: 53 00 N, 28 00 E
Map references: Commonwealth of Independent
States
Area:
total: 207,600 sq km
land: 207,600 sq km
water: 0 sq km
Area— comparative: slightly smaller than Kansas
Land boundaries:
total: 3,098 km
border countries: Latvia 141 km, Lithuania 502 km,
Poland 605 km, Russia 959 km, Ukraine 891 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: cold winters, cool and moist summers;
transitional between continental and maritime
Terrain: generally flat and contains much marshland
Elevation extremes:
lowest point: Nyoman River 90 m
highest point: Dzyarzhynskaya Hara 346 m
Natural resources: forests, peat deposits, small
quantities of oil and natural gas
Land use:
arable land: 29%
permanent crops: 1%
permanent pastures: 15%
forests and woodland: 34%
other: 21% (1993 est.)
Irrigated land: 1 ,000 sq km (1 993 est.)
Natural hazards: NA
Environment— current issues: soil pollution from
pesticide use; southern part of the country
contaminated with fallout from 1986 nuclear reactor
accident at Chornobyl1 in northern Ukraine
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Biodiversity, Environmental
Modification, Marine Dumping, Nuclear Test Ban,
43
Belarus (continued)
Ozone Layer Protection
signed '' but not ratified: Climate Change, Law of the
Sea
Geography— note: landlocked
Disputes— international: demarcation has begun
on border with Lithuania
Illicit drugs: limited cultivation of opium poppy and
cannabis, mostly for the domestic market;
transshipment point for illicit drugs to Russia and
Western Europe
45
Location: Western Europe, bordering the North Sea,
between France and the Netherlands
Geographic coordinates: 50 50 N, 4 00 E
Map references: Europe
Area:
total: 30,51 Osq km
land: 30,230 sq km
water: 280 sq km
Area— comparative: about the size of Maryland
Land boundaries:
total: 1 ,385 km
border countries: France 620 km, Germany 167 km,
Luxembourg 148 km, Netherlands 450 km
Coastline: 64 km
Maritime claims:
continental shelf: median line with neighbors
exclusive fishing zone: median line with neighbors
(extends about 68 km from coast)
territorial sea: 12 nm
Climate: temperate; mild winters, cool summers;
rainy, humid, cloudy
Terrain: flat coastal plains in northwest, central
rolling hills, rugged mountains of Ardennes Forest in
southeast
Elevation extremes:
lowest point: North Sea 0 m
highest point: Signal de Botrange 694 m
Natural resources: coal, natural gas
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 20%
forests and woodland: 21 %
other: 34%
Irrigated land: 10 sq km including Luxembourg
(1993 est.)
Natural hazards: flooding is a threat in areas of
reclaimed coastal land, protected from the sea by
concrete dikes
Environment— current issues: Meuse River, a
major source of drinking water, polluted from steel
production wastes; other rivers polluted by animal
wastes and fertilizers; industrial air pollution
contributes to acid rain in neighboring countries
Environment— international agreements:
party to: Air Pollution, Air Pollution-Sulphur 85,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Law of the Sea
Geography— note: crossroads of Western Europe;
majority of West European capitals within 1 ,000 km of
Brussels which is the seat of both the EU and NATO
Disputes— international: none
Illicit drugs: source of precursor chemicals for
South American cocaine processors; transshipment
point for cocaine, heroin, hashish, and marijuana
entering Western Europe
Disputes— international: border with Guatemala in
dispute; talks to resolve the dispute are ongoing
Illicit drugs: transshipment point for cocaine;
small-scale illicit producer of cannabis for the
international drug trade; minor money-laundering
center
Disputes— international: none
Illicit drugs: transshipment point for narcotics
associated with Nigerian trafficking organizations and
most commonly destined for Western Europe and the
US
Disputes— international: none
101
Cocos (Keeling)
Islands
Disputes— international: none
Illicit drugs: illicit producer of cannabis, mostly for
local consumption; minor transshipment point for
Southwest and Southeast Asian heroin to Europe and
occasionally to the US, and for Latin American
cocaine destined for Europe
118
Cr03tia
Disputes— international: claimed by Madagascar
154
Falkland Islands
(Islas Malvinas)
t (dependent territory
I of the UK)
Disputes— international: claimed by Argentina
Disputes— international: none
Illicit drugs: minor transshipment point for Latin
American cocaine for the West European market
162
Land use:
arable land: 33%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 27%
ote18%(1993 est.)
Irrigated land: 16,300 sq km (1995 est.)
Natural hazards: flooding
Environment— current issues: some forest
damage from acid rain; air pollution from industrial and
vehicle emissions; water pollution from urban wastes,
agricultural runoff
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed , but not ratified: none of the selected
agreements
Geography— note: largest West European nation;
occasional strong, cold, dry, north-to-northwesterly
wind known as mistral
Disputes— international: Suriname claims area
between Riviere Litani and Riviere Marouini (both
headwaters of the Lawa)
Illicit drugs: small amount of marijuana grown for
local consumption; minor transshipment point to
Europe
166
Disputes— international: none
French Southern
and Antarctic Lands
(overseas territory of France)
Indian Ocaar,
fie Amsterdam 0
0
lie Saint-Paul
% lies Crozet
o o
„Cj
lies Kerguelen
0 400 800 km
6 400 800 mi
Disputes— international: ''''Adelie Land''1 claim in
Antarctica is not recognized by the US
Disputes— international: claimed by Madagascar
Location: Southern Europe, bordering the Aegean
Sea, Ionian Sea, and the Mediterranean Sea,
between Albania and Turkey
Geographic coordinates: 39 00 N, 22 00 E
Map references: Europe
Area:
total: 131,940 sq km
land: 130,800 sq km
water: 1,1 40 sq km
Area— comparative: slightly smaller than Alabama
Land boundaries:
total: 1,210 km
border countries: Albania 282 km, Bulgaria 494 km,
Turkey 206 km, The Former Yugoslav Republic of
Macedonia 228 km
Coastline: 13,676 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 6 nm
Climate: temperate; mild, wet winters; hot, dry
summers
Terrain: mostly mountains with ranges extending
into sea as peninsulas or chains of islands
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Olympus 2,917 m
Natural resources: bauxite, lignite, magnesite,
petroleum, marble
Land use:
arable land: 19%
permanent crops: 8%
permanent pastures: 41 %
forests and woodland: 20%
other: 12% (1993 est.)
Irrigated land: 13,140 sq km (1993 est.)
Natural hazards: severe earthquakes
Environment— current issues: air pollution; water
pollution
185
Greece (continued)
Environment— international agreements:
party to: Air Pollution, Air Pollution-Sulphur 94,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides,
Air Pollution-Volatile Organic Compounds
Geography— note: strategic location dominating the
Aegean Sea and southern approach to Turkish
Straits; a peninsular country, possessing an
archipelago of about 2,000 islands
f People
Population: 10,662,138 (July 1998 est.)
Age structure:
0-14 years: 1 6% (male 890,673; female 830,945)
15-64 years: 67% (male 3,602,473; female
3,577,961)
65 years and over: 17% (male 780,029; female
980,057) (July 1998 est.)
Population growth rate: 0.43% (1998 est.)
Birth rate: 9.65 births/1 ,000 population (1998 est.)
Death rate: 9.37 deaths/1 ,000 population (1 998 est.)
Net migration rate: 4 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
af birth: 1 .07 male(s)/fema!e
under 15 years: 1 .07 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.79 male(s)/female (1998 est.)
Infant mortality rate: 7.26 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.31 years
male: 75.76 years
female: 81 .04 years (1998 est.)
Total fertility rate: 1 .31 children born/woman (1998
est.)
Nationality:
noun: Greek(s)
adjective: Greek
Ethnic groups: Greek 98%, other 2%
note: the Greek Government states there are no
ethnic divisions in Greece
Religions: Greek Orthodox 98%, Muslim 1 .3%,
other 0.7%
Languages: Greek (official), English, French
Literacy:
definition: age 15 and over can read and write
total population: 95%
male: 98%
female: 93% (1991 est.)
T Government
Country name:
conventional long form: Hellenic Republic
conventional short form: Greece
local long form: Elliniki Dhimokratia
local short form: Ellas
former: Kingdom of Greece
Data code: GR
Government type: parliamentary republic;
monarchy rejected by referendum 8 December 1974
National capital: Athens
Administrative divisions: 51 prefectures (nomoi,
singular— nomosjand 1 autonomous region*; Ayion
Oros* (Mt. Athos), Aitolia kai Akarnania, Akhaia,
Argolis, Arkadhia, Arta, Attiki, Dhodhekanisos,
Drama, Evritania, Evros, Ewoia, Fiorina, Fokis,
Fthiotis, Grevena, Ilia, Imathia, loannina, Irakleion,
Kardhitsa, Kastoria, Kavala, Kefallinia, Kerkyra,
Khalkidhiki, Khania, Khios, Kikladhes, Kilkis,
Korinthia, Kozani, Lakonia, Larisa, Lasithi, Lesvos,
Levkas, Magnisia, Messinia, Pella, Pieria, Preveza,
Rethimni, Rodhopi, Samos, Serrai, Thesprotia,
Thessaloniki, Trikala, Voiotia, Xanthi, Zakinthos
Independence: 1829 (from the Ottoman Empire)
National holiday: Independence Day, 25 March
(1 821 ) (proclamation of the war of independence)
Constitution: 11 June 1975
Legal system: based on codified Roman law;
judiciary divided into civil, criminal, and administrative
courts
Suffrage: 1 8 years of age; universal and compulsory
Executive branch:
chief of state: President Konstandinos (Kostis)
STEPHANOPOULOS (since 10 March 1995)
head of government: Prime Minister Konstandinos
SIMITIS (since 19 January 1996)
cabinet: Cabinet appointed by the president on the
recommendation of the prime minister
elections: president elected by Chamber of Deputies
for a five-year term; election last held 10 March 1995
(next to be held by NA March 2000); prime minister
appointed by the president
election results: Konstandinos STEPHANOPOULOS
elected president; percent of Chamber of Deputies
vote— NA
Legislative branch: unicameral Parliament or Vouli
ton Ellinon (300 seats; members are elected by direct
popular vote to serve four-year terms)
elections: elections last held 22 September 1996
(next to be held by NA September 2000)
election results: percent of vote by party— PASOK
41 .5%, ND 38. 1 %, KKE 5.6%, Coalition of the Left and
Progress 5.1%, DIKKI 4.4%, Political Spring 2.9%;
seats by party-PASOK 1 62, ND 1 08, KKE 1 1 ,
Coalition of the Left and Progress 10, DIKKI 9; note-
seating has subsequently changed as a result of
disciplinary actions by PASOK, ND, and DIKKI; as of
3 February 1 998 seating is PASOK 1 59, ND 1 02, KKE
11, Coalition of the Left and Progress 10, DIKKI 8,
independents 10
Judicial branch: Supreme Judicial Court, judges
appointed for life by the president after consultation
with a judicial council; Special Supreme Tribunal,
judges appointed for life by the president after
consultation with a judicial council
Political parties and leaders: New Democracy or
ND (conservative) [Konstandinos KARAMANLIS];
Panhellenic Socialist Movement or PASOK
[Konstandinos SIMITIS]; Communist Party or KKE
[Aleka PAPARIGA]; Political Spring [Andonios
SAMARAS]; Coalition of the Left and Progress
(Synaspismos) [Nikolaos KONSTANDOPOULOS];
Democratic Social Movement or DIKKI [Dhimitrios
TSOVOLAS]; Rainbow Coalition [Pavios
VOSKOPOULOS]
International organization participation: Australia
Group, BIS, BSEC, CCC, CE, CERN, EAPC, EBRD,
ECE, EIB, EU, FAO, G- 6, IAEA, IBRD, ICAO, ICC,
ICFTU, ICRM, IDA, IEA, IFAD, IFC, IFRCS, IHO, ILO,
IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, IOM, ISO,
ITU, MINURSO, MTCR, NAM (guest), NATO, NEA,
NSG, OAS (observer), OECD, OSCE, PCA, UN,
UNCTAD, UNESCO, UNHCR, UNIDO, UNIKOM,
UNMIBH, UNOMIG, UPU, WEU, WFTU, WHO,
WIPO, WMO, WToO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Loukas TSILAS
chancery: 2221 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [1] (202) 939-5800
FAX; [1] (202) 939-5824
consulate(s) general: Boston, Chicago, Los Angeles,
New York, and San Francisco
consulate(s): Atlanta, Houston, and New Orleans
Diplomatic representation from the US:
chief of mission: Ambassador R. Nicholas BURNS
embassy: 91 Vasilissis Sophias Boulevard, 10160
Athens
mailing address: PSC 108, APO AE 09842-0108
telephone: [30] (1)721-2951
FAX; [30] (1)645-6282
consulate(s) general: Thessaloniki
Flag description: nine equal horizontal stripes of
blue alternating with white; there is a blue square in
the upper hoist-side corner bearing a white cross; the
cross symbolizes Greek Orthodoxy, the established
religion of the country
Disputes— international: complex maritime, air,
and territorial disputes with Turkey in Aegean Sea;
Cyprus question with Turkey; dispute with The Former
Yugoslav Republic of Macedonia over name; in
September 1995, Skopje and Athens signed an
interim accord resolving their dispute over symbols
and certain constitutional provisions; Athens also
lifted its economic embargo on the Former Yugoslav
Republic of Macedonia
Illicit drugs: a gateway to Europe for traffickers
smuggling cannabis and heroin from the Middle East
and Southwest Asia to the West and precursor
chemicals to the East; some South American cocaine
transits or is consumed in Greece
187
Location: Northern North America, island between
the Arctic Ocean and the North Atlantic Ocean,
northeast of Canada
Geographic coordinates: 72 00 N, 40 00 W
Map references: Arctic Region
Area:
tofa/; 2,175,600 sq km
tend: 2,175,600 sq km (341 ,600 sq km ice-free,
1,834,000 sq km ice-covered) (est.)
Area-comparative: slightly more than three times
the size of Texas
Land boundaries: 0 km
Coastline: 44,087 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: arctic to subarctic; cool summers, cold
winters
Terrain: flat to gradually sloping icecap covers all but
a narrow, mountainous, barren, rocky coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Gunnbjorn 3,700 m
Natural resources: zinc, lead, iron ore, coal,
molybdenum, gold, platinum, uranium, fish, seals,
whales
Land use:
arable tend: 0%
permanent crops: 0%
permanent pastures: 1%
forests and woodland: 0%
other: 99% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: continuous permafrost over
northern two-thirds of the island
Environment— current issues: protection of the
arctic environment; preservation of their traditional
way of life, including whaling; note— Greenland
participates actively in Inuit Circumpolar Conference
(ICC)
Environment— international agreements:
party to: Whaling (extended through Denmark)
signed, but not ratified: N A
Geography— note: dominates North Atlantic Ocean
between North America and Europe; sparse
population confined to small settlements along coast
Disputes— international: none
Disputes— international: claimed by Madagascar
Disputes— international: none
Illicit drugs: transshipment point for cocaine and
marijuana bound for the US and Europe
Disputes— international: none
318
Disputes— international: none
Disputes— international: quadripoint with
Botswana, Zambia, and Zimbabwe is in
disagreement; dispute with Botswana over
uninhabited Kasikili (Sidudu) Island in Linyanti
(Chobe) River is presently at the ICJ; at least one
other island in Linyanti River is contested
Disputes— international: Matthew and Hunter
Islands claimed by France and Vanuatu
Disputes— international: none
Disputes— international: none
Illicit drugs: transshipment points for South
American drugs destined for the US and Europe
403
^^viles^ijon Santander,
<r''r~*La Coruna
Bilbao j ^^ANDORRA /
•Le6n Pasajesp^^^
.Valladolid .Zaragoza ^
.Salamanca Tarragona* ^ Barcelona
Castellon de r &
la Plana,.
Valencia1
MADRID®
<0
I Huelva
O Balearic
*'' Islands
r Cordoba /Alicante
* Cartagena./, cpA
•Sevilla /''
Malaga / r5,ditsffc‘
Cadiz >
Disputes— international: claimed by Madagascar
and Mauritius
Disputes— international: Northern Ireland question
with Ireland (historic peace agreement approved 10
April 1998); Gibraltar question with Spain; Argentina
claims Falkland Islands (Islas Malvinas); Argentina
claims South Georgia and the South Sandwich
Islands; Mauritius claims island of Diego Garcia in
British Indian Ocean Territory; Rockall continental
shelf dispute involving Denmark, Iceland, and Ireland
(Ireland and the UK have signed a boundary
agreement in the Rockall area); territorial claim in
Antarctica (British Antarctic Territory); Seychelles
claims Chagos Archipelago in British Indian Ocean
Territory
Illicit drugs: gateway country for Latin American
cocaine entering the European market; producer of
synthetic drugs, precursor chemicals; transshipment
point for Southwest Asian heroin; money-laundering
center
490
United States jj |
Disputes— international: maritime boundary
disputes with Canada (Dixon Entrance, Beaufort Sea,
Strait of Juan de Fuca, Machias Seal Island); US
Naval Base at Guantanamo Bay is leased from Cuba
and only mutual agreement or US abandonment of the
area can terminate the lease; Haiti claims Navassa
Island; US has made no territorial claim in Antarctica
(but has reserved the right to do so) and does not
recognize the claims of any other nation; Marshall
Islands claims Wake Island
Illicit drugs: consumer of cocaine shipped from
Colombia through Mexico and the Caribbean;
consumer of heroin, marijuana, and increasingly
methamphetamines from Mexico; consumer of
high-quality Southeast Asian heroin; illicit producer of
cannabis, marijuana, depressants, stimulants,
hallucinogens, and methamphetamines; drug
money-laundering center
Disputes— international: none
West Bank
Current issues: The Israel-PLO Declaration of
Principles on Interim Self-Government Arrangements
("the DOP"), signed in Washington on 13 September
1 993, provides for a transitional period not exceeding
five years of Palestinian interim self-government in the
Gaza Strip and the West Bank. Permanent status
negotiations began on 5 May 1996, but have not
resumed since the initial meeting. Under the DOP,
Israel agreed to transfer certain powers and
responsibilities to the Palestinian Authority, which
includes a Palestinian Legislative Council elected in
January 1996, as part of interim self-governing
arrangements in the West Bank and Gaza Strip. A
transfer of powers and responsibilities for the Gaza
Strip and Jericho took place pursuant to the
Israel-PLO 4 May 1 994 Cairo Agreement on the Gaza
Strip and the Jericho Area and in additional areas of
the West Bank pursuant to the Israel-PLO 28
September 1995 Interim Agreement and the
Israel-PLO 15 January 1997 Protocol Concerning
Redeployment in Hebron. The DOP provides that
Israel will retain responsibility during the transitional
period for external security and for internal security
509
West Bank (continued)
and public order of settlements and Israelis.
Permanent status is to be determined through direct
negotiations.
Disputes— international: West Bank and Gaza
Strip are Israeli-occupied with current status subject to
the Israeli-Palestinian Interim Agreement-
permanent status to be determined through further
negotiation
telephone— [33] (1)49 53 28 28
FAX-{ 33] (1)49 53 29 42
established— NA 1919
aim— to promote free trade and private
enterprise and to represent business interests at
national and international levels
International Civil Aviation Organization
(ICAO)
address— ICAO, 999 University Street, Montreal
H3C 5H7, Canada
telephone— [1] (514) 954 8219
FAX— [1] (514) 954 6077
established— 7 December 1944
effective —4 April 1947
aim— to promote international cooperation in
civil aviation; a UN specialized agency
International Committee of the Red Cross
(ICRC)
address— 1C RC, 19 av de la Paix, CH-1202
Geneva, Switzerland
telephone— [41] (22) 734 60 01
FAX— [41] (22) 733 20 57
established— HA 1863
aim— to provide humanitarian aid in wartime
members— {131) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
members— (62 national councils) Argentina, Australia, Austria, Bangladesh, Belgium, Brazil, Burkina Faso,
Cameroon, Canada, Chile, China, Colombia, Cote d''Ivoire, Cyprus, Denmark, Ecuador, Egypt, Finland, France,
Germany, Greece, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, South Korea, Kuwait,
Lebanon, Lithuania, Luxembourg, Madagascar, Mexico, Morocco, Netherlands, Nigeria, Norway, Pakistan, Peru,
Portugal, Saudi Arabia, Senegal, Singapore, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Taiwan,
Togo, Tunisia, Turkey, UK, US, Uruguay, Venezuela, Yugoslavia
members— (185) Afghanistan, Albania, Algeri','5a0e62f17bc248be4f89bf87e55dfc033f268bad1e5d516cf43100da84701bf7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5d9552917e37cc4a831fd213fb3168ca454bc517eab5aedd36e2df448d3b825',1998,'FR','France','transnational-issues',93,'a, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Palau, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, T rinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe _
members— (25 individuals) all Swiss nationals
554
International Confederation of Free Trade members— (19,487 affiliated organizations in the following 136 countries) Algeria, Antigua and Barbuda, Argentina,
Unions (ICFTU) Australia, Austria, The Bahamas, Bangladesh, Barbados, Basque Country, Belgium, Belize, Benin, Bermuda,
Botswana, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
address — International Trade Union House, Bd China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
Emile Jacqmain 155, B-1210 Brussels, Belgium d''Ivoire, Curacao, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, El
telephone— [32] (2) 224 02 1 1 Salvador, Eritrea, Estonia, Falkland Islands, Fiji, Finland, France, French Polynesia, Gabon, The Gambia, Germany,
FAX— [32] (2) 201 58 15, 203 07 56 Ghana, Greece, Grenada, Guatemala, Guinea, Guyana, Holy See, Honduras, Hong Kong, Hungary, Iceland, India,
established— HA December 1949 Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Lebanon, Liberia, Lithuania,
aim— to promote the trade union movement Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritius, Mexico, Mongolia, Montserrat, Morocco,
Mozambique, Nepal, Netherlands, New Caledonia, NZ, Nicaragua, Niger, Norway, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Romania, Rwanda, Saint Helena, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, UK, US, Vanuatu, Venezuela, Zambia,
telephone— [33] (4) 72 44 70 00
FAX-133] (4) 72 44 71 63
established— 13 June 1956
aim— to promote international cooperation
among police authorities in fighting crime
members— (15 judges) elected by the UN General Assembly and Security Council to represent all principal legal
systems
555
Appendix C: International Organizations and Groups (continued)
International Development Association (IDA) members— (159)
Part / — (26 developed countries) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany,
Iceland, Ireland, Italy, Japan, Kuwait, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South Africa, Spain,
Sweden, Switzerland, UAE, UK, US
Part 1/ — (133 less developed countries) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Azerbaijan,
Bangladesh, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech
Republic, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Ethiopia, Fiji, Gabon, The Gambia, Georgia, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel, Jordan, Kazakhstan, Kenya, Kiribati, South
Korea, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Sierra Leone, Slovakia,
Slovenia, Solomon Islands, Somalia, Sri Lanka, Sudan, Swaziland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Uzbekistan, Vanuatu, Vietnam, Yemen, Zambia, Zimbabwe
Internationa! Energy Agency (IEA) members— (23) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Greece, Ireland, Italy,
Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
address— 2 rue Andre Pascal, F-75775 Paris
CEDEX16, France
telephone— [33] (1)45 24 82 00
FAX~{ 33] (1)45 24 99 88
established —15 November 1974
aim— to promote cooperation on energy
matters, especially emergency oil sharing and
relations between oil consumers and oil
producers; established by the OECD
Internationa! Federation of Red Cross and
Red Crescent Societies (IFRCS)
note— formerly known as League of Red Cross
and Red Crescent Societies (LORCS)
address— Chemin des Crets 17, CP 372,
Petit-Saconnex, CH-1211 Geneva 19,
telephone— {33] (1)45 2410 10
FAX— {33] (1 ) 45 24 1 1 10
established— HA 1958
aim— to promote the peaceful uses of nuclear
energy; associated with OECD
Nuclear Suppliers Group (NSG)
note— also known as the London Suppliers
Group or the London Group
address— do Permanent Mission of Japan in
Vienna, Prinz-Eugen Strasse 8-10, A-1040
Vienna, Austria
telephone— {A3] (1) 505 5467
FAX— {43] (1) 505 6167
established— HA 1974
effective— HA 1975
aim— to establish guidelines for exports of
nuclear materials, processing equipment for
uranium enrichment, and technical information
to countries of proliferation concern and regions
of conflict and instability
Organismo para la Proscripcion de las
Armas Nucleares en la America Latina y el
Caribe (OPANAL) _
Organization for Economic Cooperation and
Development (OECD)
address— 2 rue Andre Pascal, F-75775 Paris
CEDEX 16, France
telephone— {33] (1)45 24 82 00
FAX— {33] (1 ) 45 24 85 00, 45 24 81 76
established— 14 December 1960
effective— 30 September 1961
aim— to promote economic cooperation and
development
Organization for Security and Cooperation in
Europe (OSCE)
note— formerly the Conference on Security and
Cooperation in Europe (CSCE)
address— Karntner Ring 5-7, A-1 010 Vienna,','cecd28cdf9d84aa28eab8de693fa8ba9d493796477b1413b1d468cbe64feee34','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebdb8f8a2f73d9b9223d34f031d70b74e571abb11d4594b1a635c43e49b0c735',1998,'BJ','Benin','transnational-issues',105,'Location: Western Africa, bordering the North
Atlantic Ocean, between Nigeria and Togo
Geographic coordinates: 9 30 N, 2 15 E
Map references: Africa
Area:
total: 11 2,620 sq km
land: 110,620 sq km
water: 2,000 sq km
Area— comparative: slightly smaller than
Pennsylvania
Land boundaries:
total: 1 ,989 km
border countries: Burkina Faso 306 km, Niger 266
km, Nigeria 773 km, Togo 644 km
Coastline: 121 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid in south; semiarid in
north
Terrain: mostly flat to undulating plain; some hills
and low mountains
Elevation extremes:
lowest point : Atlantic Ocean 0 m
highest point : Mount Tanekas 641 m
Natural resources: small offshore oil deposits,
limestone, marble, timber
Land use:
arable land: 13%
permanent crops : 4%
permanent pastures: 4%
forests and woodland: 31 %
other: 48% (1 993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan wind
may affect north in winter
Environment— current issues: recent droughts
have severely affected marginal agriculture in north;
inadequate supplies of potable water; poaching
threatens wildlife populations; deforestation;
desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography— note: no natural harbors','5594f5605abd935daccdb1cc4c9ae41b9f8b6b9134c72eb2db4370aafcd363fc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8861f54c6e8cb6e4dc306cedbd71192b649866726cea7818e6ca516116d731b',1998,'BM','Bermuda','transnational-issues',109,'(dependent territory
of the UK)
Location: North America, group of islands in the
North Atlantic Ocean, east of North Carolina (US)
Geographic coordinates: 32 20 N, 64 45 W
Map references: North America
Area:
total: 50 sq km
land: 50 sq km
water: 0 sq km
Area— comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 103 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: subtropical; mild, humid; gales, strong
winds common in winter
Terrain: low hills separated by fertile depressions
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Tom Flill 76 m
Natural resources: limestone, pleasant climate
fostering tourism
Land use:
arable land: 6%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA (1 997 est.)
note: developed (55%), and rural and open space
(39%) comprise 94% of Bermudian land area
Irrigated land: NA sq km
Natural hazards: hurricanes (June to November)
Environment— current issues: asbestos disposal;
water pollution; preservation of open space
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: consists of about 360 small coral
islands with ample rainfall, but no rivers or freshwater
lakes; some land, reclaimed and otherwise, was
leased by US Government from 1941 to 1995
Disputes— international: none
53','e442088a54023c0405accd4dff7e4e74dc098915c54e2e70cbabdda42c9dcaff','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46e8a192752d0753a1d5fc459eb7c67b741aed02caacc10d0f8f59b70612cecd',1998,'BR','Brazil','transnational-issues',122,'Disputes— international: has wanted a sovereign
corridor to the South Pacific Ocean since the Atacama
area was lost to Chile in 1 884; dispute with Chile over
Rio Lauca water rights
Illicit drugs: world''s third-largest cultivator of coca
(after Peru and Colombia) with an estimated 46,900
hectares under cultivation in 1 997, a 2.5% decrease in
overall cultivation of coca from 1996 levels; Bolivia,
however, is the second-largest producer of coca leaf;
even so, farmer abandonment and voluntary and
forced eradication programs resulted in leaf
production dropping from 75,100 metric tons in 1996
to 73,000 tons in 1997, a 3% decrease from 1996;
government considers all but 12,000 hectares illicit;
intermediate coca products and cocaine exported to
or through Colombia, Brazil, Argentina, and Chile to
the US and other international drug markets;
alternative crop program aims to reduce illicit coca
cultivation
Current issues: On 21 November 1995, in Dayton,
Ohio, the former Yugoslavia''s three warring parties
signed a peace agreement that brought to a halt over
three years of interethnic civil strife in Bosnia and
Flerzegovina (the final agreement was signed in Paris
on 14 December 1995). The Dayton Agreement,
signed then by Bosnian President IZETBEGOVIC,
Croatian President TUDJMAN, and Serbian President
MILOSEVIC, divides Bosnia and Herzegovina roughly
equally between the Muslim/Croat Federation and the
Bosnian Serbs while maintaining Bosnia''s currently
recognized borders. In 1995-96, a NATO-led
international peacekeeping force (IFOR) of 60,000
troops served in Bosnia to implement and monitor the
military aspects of the agreement. IFOR was
succeeded by a smaller, NATO-led Stabilization
Force (SFOR) whose mission is to deter renewed
hostilities. SFOR will remain in place until June 1998.
A High Representative appointed by the UN Security
Council is responsible for civilian implementation of
the accord, including monitoring implementation,
facilitating any difficulties arising in connection with
civilian implementation, and coordinating activities of
the civilian organizations and agencies in Bosnia and
Herzegovina. The Bosnian conflict began in the spring
of 1992 when the Government of Bosnia and
Herzegovina held a referendum on independence and
the Bosnian Serbs— supported by neighboring
Serbia— responded with armed resistance aimed at
partitioning the republic along ethnic lines and joining
Serb-held areas to form a "greater Serbia.” In March
1994, Bosnia''s Muslims and Croats reduced the
number of warring factions from three to two by
signing an agreement in Washington creating their
joint Muslim/Croat Federation of Bosnia and
Herzegovina. The Federation, formed by the Muslims
and Croats in March 1994, is one of two entities (the
other being the Bosnian Serb-led Republika Srpska)
that comprise Bosnia and Herzegovina.
Disputes— international: disputes with Serbia over
Serbian populated areas
Illicit drugs: transit point for minor regional
marijuana and opiate trafficking routes
60
PSI 18557
Location: Southern Africa, north of South Africa
Geographic coordinates: 22 00 S, 24 00 E
Map references: Africa
Area:
total: 600,370 sq km
land: 585,370 sq km
wafer 15,000 sq km
Area— comparative: slightly smaller than Texas
Land boundaries:
total: 4,01 3 km
border countries: Namibia 1 ,360 km, South Africa
1,840 km, Zimbabwe 813 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: semiarid; warm winters and hot summers
Terrain: predominately flat to gently rolling tableland;
Kalahari Desert in southwest
Elevation extremes:
lowest point: junction of the Limpopo and Shashe
Rivers 513 m
highest point:lso6\\\\o Hill 1,489 m
Natural resources: diamonds, copper, nickel, salt,
soda ash, potash, coal, iron ore, silver
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 47%
other: 6% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: periodic droughts; seasonal
August winds blow from the west, carrying sand and
dust across the country, which can obscure visibility
Environment— current issues: overgrazing;
desertification; limited fresh water resources
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked; population
concentrated in eastern part of the country
Disputes— international: quadripoint with Namibia,
Zambia, and Zimbabwe is in disagreement; dispute
with Namibia over uninhabited Kasikili (Sidudu) Island
in Linyanti (Chobe) River is presently at the ICJ; at
least one other island in Linyanti River is contested
62
Disputes— international: short section of the
boundary with Brazil, just west of Salto del Guaira
(Guaira Falls) on the Rio Parana, has not been
precisely delimited
Illicit drugs: illicit producer of cannabis for the
international drug trade; transshipment country for
Bolivian cocaine headed for Europe and the US
370
Disputes— international: three sections of the
boundary with Ecuador are in dispute
Illicit drugs: until recently the world’s largest coca
leaf producer, Peru has reduced the area of coca
under cultivation by 40%, from 115,300 hectares in
1 995 to 68,800 hectares at the end of 1 997; source of
supply for most of the world’s cocaine base; most of
cocaine base is shipped to Colombian drug dealers for
processing into cocaine for the international drug
market, but exports of finished cocaine are increasing','c808df406e9d5449d733e721407817b214c86932bf77a18a1f3d287e70f3b4ec','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f74cf8273572c9efc2d7a8a8a980ed69d1942eaff6e0bb96bf1713d4c3913c98',1998,'BV','Bouvet Island','transnational-issues',125,'I (territory of Norway)
G e o g r a p h y
Location: Southern Africa, island in the South
Atlantic Ocean, south-southwest of the Cape of Good
Hope (South Africa)
Geographic coordinates: 54 26 S, 3 24 E
Map references: Antarctic Region
Area:
total: 58 sq km
land: 58 sq km
water: Osq km
Area— comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 29.6 km
Maritime claims:
territorial sea: 4 nm
Climate: antarctic
Terrain: volcanic; maximum elevation about 800
meters; coast is mostly inaccessible
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 780 m
Natural resources: none
Land use:
arable land ;0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all ice)
Irrigated land: Osq km (1993)
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: covered by glacial ice','cc60e8ca16dd02e94f65187f10f8b54fabb51d83951b275e3b5ef0e9c824bfb8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('617f780113f2f1fed8546b4e51337eb4d04416798b79d2bb5663319af97f5d79',1998,'NO','Norway','transnational-issues',127,'Disputes— international: none
Disputes— international: short section of the
boundary with Paraguay, just west of Salto das Sete
Quedas (Guaira Falls) on the Rio Parana, has not
been precisely delimited; two short sections of
boundary with Uruguay are in dispute— Arroio
Invernada (Arroyo de la Invernada) area of the Rio
Quarai (Rio Cuareim) and the islands at the
confluence of the Rio Quarai and the Uruguay River
Illicit drugs: limited illicit producer of cannabis,
minor coca cultivation in the Amazon region, mostly
used for domestic consumption; government has a
large-scale eradication program to control cannabis;
important transshipment country for Bolivian and
Colombian cocaine headed for the US and Europe;
increasingly used by Andean traffickers as a way
station between Peru and Colombia
British Indian
Ocean Territory
(dependent territory
of the UK)
Peros ( ''
Banhos \\ . .
Salomon Islands
Chagos
Archipelago
. Jhree Brothers
, Nelsons
Island
Danger 1
Island
'' Eagle Islands
Indian
Egmont Islands
Ocean
O 25 50 km
. ''v Diego
y Garcia
6 25
50 mi
Disputes— international: none
238
Location: Eastern Asia, island chain between the
North Pacific Ocean and the Sea of Japan, east of the
Korean Peninsula
Geographic coordinates: 36 00 N, 138 00 E
Map references: Asia
Area:
total: 377,835 sq km
land: 374,744 sq km
water: 3,091 sq km
note: includes Bonin Islands (Ogasawara-gunto),
Daito-shoto, Minami-jima, Okino-tori-shima, Ryukyu
Islands (Nansei-shoto), and Volcano Islands
(Kazan-retto)
Area— comparative: slightly smaller than California
Land boundaries: 0 km
Coastline: 29,751 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm; 3 nm in the international
straits— La Perouse or Soya, Tsugaru, Osumi, and
Eastern and Western Channels of the Korea or
Tsushima Strait
Climate: varies from tropical in south to cool
temperate in north
Terrain: mostly rugged and mountainous
Elevation extremes:
lowest point: Hachiro-gata -4 m
highest point: Fujiyama 3,776 m
Natural resources: negligible mineral resources,
fish
Land use:
arable land: 11%
permanent crops: 1%
permanent pastures: 2%
forests and woodland: 67%
other: 19% (1993 est.)
Irrigated land: 27,820 sq km (1993 est.)
Natural hazards: many dormant and some active
volcanoes; about 1 ,500 seismic occurrences (mostly
tremors) every year; tsunamis
Environment— current issues: air pollution from
power plant emissions results in acid rain; acidification
of lakes and reservoirs degrading water quality and
threatening aquatic life; Japan''s appetite for fish and
tropical timber is contributing to the depletion of these
resources in Asia and elsewhere
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Desertification
Geography— note: strategic location in northeast
Asia
Disputes— international: islands of Etorofu,
Kunashiri, Shikotan, and the Habomai group occupied
by the Soviet Union in 1945, now administered by
Russia, claimed by Japan; Liancourt Rocks
(Takeshima/Tokdo) disputed with South Korea;
Senkaku-shoto (Senkaku Islands) claimed by China
and Taiwan
Jarvis Island
f (territory of the US)
0 0.5 1 km
0 0.5 1 mi
South Pacific Ocean','806164b8a877399e4dd00b0611cd2b740c41fd53b70d0f8875b073910052748e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ff065eb270eccb7a9986b33ff1686f9c193d8dd42ba98f1c9b5333d9145c9c8',1998,'ID','Indonesia','transnational-issues',141,'Disputes— international: the island of Diego Garcia
is claimed by Mauritius; the Chagos Archipelago is
claimed by Seychelles
[British Virgin
Islands
(dependent territory
of the UK)
Location: Caribbean, between the Caribbean Sea
and the North Atlantic Ocean, east of Puerto Rico
Geographic coordinates: 1 8 30 N, 64 30 W
Map references: Central America and the
Caribbean
Area:
total: 150 sq km
land: 150 sq km
water: 0 sq km
note: includes the island of Anegada
Area— comparative: about 0.9 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 80 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: subtropical; humid; temperatures
moderated by trade winds
Terrain: coral islands relatively flat; volcanic islands
steep, hilly
Elevation extremes:
lowest point: Caribbean Sea 0 m
/7/g/?es^ po/''nf; Mount Sage 521 m
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 7%
permanent pastures: 33%
forests and woodland: 7%
other: 33% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: hurricanes and tropical storms
(July to October)
Environment— current issues: limited natural fresh
water resources (except for a few seasonal streams
and springs on Tortola, most of the islands'' water
supply comes from wells and rainwater catchment)
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: strong ties to nearby US Virgin
Islands and Puerto Rico
ty
Disputes— international: none
68
PSI 18557
f Geography
Location: Southeastern Asia, bordering the South
China Sea and Malaysia
Geographic coordinates: 4 30 N, 1 14 40 E
Map references: Southeast Asia
Area:
total: 5,770 sq km
land: 5,270 sq km
wafer; 500 sq km
Area— comparative: slightly smaller than Delaware
Land boundaries:
total: 381 km
border countries: Malaysia 381 km
Coastline: 161 km
Maritime claims:
exclusive economic zone: 200 nm or to median line
territorial sea: 12 nm
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to mountains in east;
hilly lowland in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Bukit Pagon 1,850 m
Natural resources: petroleum, natural gas, timber
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 1 %
forests and woodland: 85%
other: 12% (1993 est.)
Irrigated land: 1 0 sq km (1 993 est.)
Natural hazards: typhoons, earthquakes, and
severe flooding are very rare
Environment— current issues: seasonal smoke/
haze resulting from forest fires in Indonesia
Environment— international agreements:
party to: Endangered Species, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: close to vital sea lanes through
South China Sea linking Indian and Pacific Oceans;
two parts physically separated by Malaysia; almost an
enclave of Malaysia
i People
Population: 315,292 (July 1998 est.)
Age structure:
0-14 years: 33% (male 53,219; female 50,906)
15-64 years: 63% (male 103,949; female 93,370)
65 years and over: 4% (male 7,569; female 6,279)
(July 1998 est.)
Population growth rate: 2.44% (1998 est.)
Birth rate: 24.92 births/1 ,000 population (1998 est.)
Death rate: 5. 17 deaths/1 ,000 population (1998 est.)
Net migration rate: 4.61 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.11 ma!e(s)/female
65 years and over: 1 .21 ma!e(s)/female (1 998 est.)
Infant mortality rate: 23.3 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 71 .69 years
male: 70.1 7 years
female: 73.29 years (1998 est.)
Total fertility rate: 3.35 children born/woman (1998
est.)
Nationality:
noun: Bruneian(s)
adjective : Bruneian
Ethnic groups: Malay 64%, Chinese 20%, other
16%
Religions: Muslim (official) 63%, Buddhism 14%,
Christian 8%, indigenous beliefs and other 15%
(1981)
Languages: Malay (official), English, Chinese
Literacy:
definition: age 1 5 and over can read and write
total population: 88.2%
male: 92.6%
female: 83.4% (1995 est.)
Disputes— international: may wish to purchase the
Malaysian salient that divides the country; possibly
involved in a complex dispute over the Spratly Islands
with China, Malaysia, Philippines, Taiwan, and
Vietnam; in 1984, Brunei established an exclusive
fishing zone that encompasses Louisa Reef in the
southern Spratly Islands, but has not publicly claimed
the island
70
Location: Southeastern Asia, archipelago between
the Indian Ocean and the Pacific Ocean
Geographic coordinates: 5 00 S, 120 00 E
Map references: Southeast Asia
Area:
total: 1,919,440 sq km
land: 1,826,440 sq km
water: 93,000 sq km
Area— comparative: slightly less than three times
the size of Texas
Land boundaries:
total: 2,602 km
border countries: Malaysia 1 ,782 km, Papua New
Guinea 820 km
Coastline: 54,716 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; more moderate in
highlands
Terrain: mostly coastal lowlands; larger islands have
interior mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Puncak Jaya 5,030 m
Natural resources: petroleum, tin, natural gas, nickel,
timber, bauxite, copper, fertile soils, coal, gold, silver
Land use:
arable land: 10%
permanent crops: 7%
permanent pastures: 7%
forests and woodland: 62%
other: 14% (1993 est.)
Irrigated land: 45,970 sq km (1993 est.)
Natural hazards: occasional floods, severe
droughts, tsunamis, earthquakes
Environment— current issues: deforestation;
water pollution from industrial wastes, sewage; air
pollution in urban areas
Environment— international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Desertification, Marine Life
Conservation
Geography— note: archipelago of 17,000 islands
(6,000 inhabited); straddles Equator; strategic
location astride or along major sea lanes from Indian
Ocean to Pacific Ocean
Disputes— international: sovereignty over Timor
Timur (East Timor Province) disputed with Portugal
and not recognized by the UN; two islands in dispute
with Malaysia
Illicit drugs: illicit producer of cannabis largely for
domestic use; possible growing role as transshipment
point for Golden Triangle heroin
Iran
Disputes— international: Iran and Iraq restored
diplomatic relations in 1990 but are still trying to work
out written agreements settling outstanding disputes
from their eight-year war concerning border
demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shaft al Arab
waterway; Iran occupies two islands in the Persian
Gulf claimed by the UAE: Lesser Tunb (called Tunb as
Sughra in Arabic by UAE and Jazireh-ye Tonb-e
Kuchek in Persian by Iran) and Greater Tunb (called
Tunb al Kubra in Arabic by UAE and Jazireh-ye
Tonb-e Bozorg in Persian by Iran); it jointly
administers with the UAE an island in the Persian Gulf
claimed by the UAE (called Abu Musa in Arabic by
UAE and Jazireh-ye Abu Musa in Persian by Iran) —
over which Iran has taken steps to exert unilateral
control since 1 992, including access restrictions and a
military build-up on the island; the UAE has garnered
significant diplomatic support in the region in
protesting these Iranian actions; Caspian Sea
boundaries are not yet determined among Azerbaijan,
iran, Kazakhstan, Russia, and Turkmenistan
Illicit drugs: illicit producer of opium poppy for the
domestic and international drug trade; net opiate
importer but also a key transshipment point for
Southwest Asian heroin to Europe
Disputes— international: Iran and Iraq restored
diplomatic relations in 1990 but are still trying to work
out written agreements settling outstanding disputes
from their eight-year war concerning border
demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shatt al Arab
waterway; in November 1994, Iraq formally accepted
the UN-demarcated border with Kuwait which had
been spelled out in Security Council Resolutions 687
(1991), 773 (1993), and 883 (1 993); this formally ends
earlier claims to Kuwait and to Bubiyan and Warbah
islands; dispute over water development plans by
Turkey for the Tigris and Euphrates Rivers
228
Disputes— international: none
Midway islands fM ■
(territory of the US) Z
O 1 2 km
O 1 2 mi
reef ^
■ '' Q Sand Islet
''v|
North Pacific
Ocean
Disputes— international: none
Moldova
Disputes— international: two islands in dispute with
telephone— {62] (21) 7262410, 7262991,
7262272,7251988
FAX- [62] (21) 7398234, 7243348
established— 9 August 1 967
aim— to encourage regional economic, social,
and cultural cooperation among the
non-Communist countries of Southeast Asia
members— (9) Brunei, Burma, Indonesia, Laos, Malaysia, Philippines, Singapore, Thailand, Vietnam
obsen/ers— (2) Cambodia, Papua New Guinea
consultative partners— ( 2) China, Russia
Australia Group
established— 1984
aim— to consult on and coordinate export
controls related to chemical and biological
weapons
members— (28) Argentina, Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France,
Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Poland,
Portugal, Slovakia, Spain, Sweden, Switzerland, UK, US; note-may now include only 23 countries
observer— ( 1) Singapore
Australia-New Zealand-United States
Security Treaty (ANZUS)
members— (3) Australia, NZ, US
address— do Department of Foreign Affairs and
Trade, Bag 8, Queen Victoria Terrace, Canberra
ACT 2600, Australia
telephone— [61] (62) 61 91 11
FAX-{ 61] (62) 61 21 51
established— 1 September 1951
effective— 29 April 1952
aim— to implement a trilateral mutual security
agreement, although the US suspended security
obligations to NZ on 1 1 August 1986; Australia
and the US continue to hold annual meetings
Banco Centroamericano de Integracion
Economico (BCIE)
see Central American Bank for Economic Integration (BCIE)
Banco Interamericano de Desarrollo (BID)
see Inter-American Development Bank (IADB)
536
Bank for International Settlements (BIS)
address— Centralbahnplatz 2, CH-4002 Basel,','85788bd09a79e566451dac60068f578b1fc680a20303cfe0dc16db1d3382dc39','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02f8126d775c4914347feb5cc58b1aa1a35b5be46c9f788d89c3674675e96f2b',1998,'ET','Ethiopia','transnational-issues',151,'Disputes— international: none
Location: Southeastern Asia, bordering the
Andaman Sea and the Bay of Bengal, between
Bangladesh and Thailand
Geographic coordinates: 22 00 N, 98 00 E
Map references: Southeast Asia
Area:
total: 678,500 sq km
land: 657,740 sq km
water: 20,760 sq km
Area— comparative: slightly smaller than Texas
Land boundaries:
total: 5,876 km
border countries: Bangladesh 193 km, China 2,185
km, India 1 ,463 km, Laos 235 km, Thailand 1 ,800 km
Coastline: 1,930 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical monsoon; cloudy, rainy, hot, humid
summers (southwest monsoon, June to September);
less cloudy, scant rainfall, mild temperatures, lower
humidity during winter (northeast monsoon,
December to April)
Terrain: central lowlands ringed by steep, rugged
highlands
Elevation extremes:
lowest point: Andaman Sea 0 m
highest point: Hkakabo Razi 5,881 m
Natural resources: petroleum, timber, tin, antimony,
zinc, copper, tungsten, lead, coal, some marble,
limestone, precious stones, natural gas
Land use:
arable land: 15%
permanent crops: 1%
permanent pastures : 1 %
forests and woodland: 49%
other: 34% (1993 est.)
Irrigated land: 10,680 sq km (1993 est.)
Natural hazards: destructive earthquakes and
cyclones; flooding and landslides common during
rainy season (June to September); periodic droughts
Environment— current issues: deforestation;
industrial pollution of air, soil, and water; inadequate
sanitation and water treatment contribute to disease
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location near major
Indian Ocean shipping lanes
f''"''~ . . People .
Population: 47,305,319 (July 1998 est.)
Age structure:
0-14 years: 36% (male 8,798,474; female 8,461,791)
15-64 years: 59% (male 14,052,386; female
14,019,244)
65 years and over: 5% (male 888,773; female
1,084,651) (July 1998 est.)
Population growth rate: 1 .65% (1998 est.)
Birth rate: 28.96 births/1,000 population (1998 est.)
Death rate: 12.51 deaths/1,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.82 male(s)/female (1998 est.)
Infant mortality rate: 78.35 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 54.51 years
male: 53.03 years
female: 56.08 years (1998 est.)
Total fertility rate: 3.7 children born/woman (1998
est.)
75
Burma (continued)
Nationality:
noun: Burmese (singular and plural)
adjective: Burmese
Ethnic groups: Burman 68%, Shan 9%, Karen 7%,
Rakhine 4%, Chinese 3%, Mon 2%, Indian 2%, other
5%
Religions: Buddhist 89%, Christian 4% (Baptist 3%,
Roman Catholic 1%), Muslim 4%, animist beliefs 1%,
other 2%
Languages: Burmese, minority ethnic groups have
their own languages
Literacy:
definition: age 15 and over can read and write
total population: 83.1%
male: 88.7%
female: 77.7% (1995 est.)
Disputes— international: none
202
Disputes— international: none
408
telephone— {25^] (1) 51 72 00
FAX— [251] (1) 51 4416
established— 29 April 1958
aim— to promote economic development as a
regional commission of the UN''s Economic and
Social Council
Economic Commission for Asia and the Far see Economic and Social Commission for Asia and the Pacific (ESCAP)
East (ECAFE)
members— ( 53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African
Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Djibouti, Egypt,
Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia,
Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia, Niger, Nigeria, Rwanda,
Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan, Swaziland, Tanzania,
Togo, Tunisia, Uganda, Zambia, Zimbabwe
associate members— (2) France, UK
members— (51) Afghanistan, Armenia, Australia, Azerbaijan, Bangladesh, Bhutan, Brunei, Burma, Cambodia,
China, Fiji, France, India, Indonesia, Iran, Japan, Kazakhstan, Kiribati, North Korea, South Korea, Kyrgyzstan, Laos,
Malaysia, Maldives, Marshall Islands, Federated States of Micronesia, Mongolia, Nauru, Nepal, Netherlands, NZ,
Pakistan, Palau, Papua New Guinea, Philippines, Russia, Samoa, Singapore, Solomon Islands, Sri Lanka,
Tajikistan, Thailand, Tonga, Turkey, Turkmenistan, Tuvalu, UK, US, Uzbekistan, Vanuatu, Vietnam
associate members— (9) American Samoa, Cook Islands, French Polynesia, Guam, Hong Kong, Macau, New
Caledonia, Niue, Northern Mariana Islands
545
Appendix C: International Organizations and Groups (continued)
Economic Commission for Europe (ECE)
address— Palais des Nations, CH-121 1 Geneva
10, Switzerland
telephone— [41] (22) 917 1234, 907 2893
FAX— [41] (22) 917 0036
established— 28 March 1947
aim— to promote economic development as a
regional commission of the UN''s Economic and
Social Council
members— ( 55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany,
Greece, Hungary, Iceland, Ireland, Israel, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova, Monaco, Netherlands, Norway,
Poland, Portugal, Romania, Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan,
Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan, Yugoslavia
Economic Commission for Latin America
(ECLA)
see Economic Commission for Latin America and the Caribbean (ECLAC)
Economic Commission for Latin America
and the Caribbean (ECLAC)
address— Edificio Naciones Unidas, Avenida
Dag Hammarskjold, Casilla 179 D, Santiago,
telephoned 251] (1) 517700
FAX— [251] (1)512622
established— 25 May 1963
aim— to promote unity and cooperation among
African states
members^ 53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African
Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Djibouti, Egypt,
Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia,
Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sahrawi
Arab Democratic Republic, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa,
Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
Organization of American States (OAS)
address— corner of 17th Street and Constitution
Avenue NW, Washington, DC 20006, US
telephone— [\\] (202) 458 3000
FAX-1 ](202)458 3967
established— 30 April 1948
effective— 13 December 1951
aim— to promote regional peace and security as
well as economic and social development
members— (35) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Cuba (excluded from formal participation since 1962), Dominica, Dominican Republic,
Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama,
Paraguay, Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and
Tobago, US, Uruguay, Venezuela
observers— (31) Algeria, Angola, Austria, Belgium, Central American Parliament, Commission of the European
Communities, Cyprus, Egypt, Equatorial Guinea, Finland, France, Germany, Greece, Holy See, Hungary, India,
Israel, Italy, Japan, South Korea, Morocco, Netherlands, Pakistan, Poland, Portugal, Romania, Russia, Saudi
Arabia, Spain, Switzerland, Tunisia
Organization of Arab Petroleum Exporting
Countries (OAPEC)
members— (10) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar, Saudi Arabia, Syria, UAE
address— P.O. Box 20501, Safat 13066, Kuwait
telephone— [%5] 4844500
FAX— [965] 4815747
established— 9 January 1968
aim— to promote cooperation in the petroleum
industry
Organization of Eastern Caribbean States
(OECS)
address— OECS, P.O. Box 179, The Morne,
Castries, St. Lucia
telephone— (809) 45 22537, 45 22538, 45
36401
FAX— [1] (809) 45 31628
established— 18 June 1981
effective— 4 July 1 981
aim— to promote political, economic, and
defense cooperation
members— (7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines
associate members— (2) Anguilla, British Virgin Islands
Organization of Petroleum Exporting
Countries (OPEC)
members— (11) Algeria, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia, UAE, Venezuela
address— Obere Donaustrasse 93, A-1020
Vienna, Austria
telephone— { 43] (1) 21 11 20
FAX— [43] (1)216 43 20
established— 14 September 1960
aim—l o coordinate petroleum policies
Organization of the Islamic Conference (OIC)
address— 6 km Makkah Al-Mukarramah Road,
P.O. Box 1 78, Jeddah 21411, Saudi Arabia
telephone— [%6] (2) 680-0800
FAX— [966] (2) 687-6568
established— 22-25 September 1969
aim— to promote Islamic solidarity in economic,
social, cultural, and political affairs
members— (53 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain,
Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The Gambia,
Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia,
Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman, Pakistan, Qatar, Saudi Arabia, Senegal,
Sierra Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Tunisia, Turkey, Turkmenistan, Uganda, UAE,
Uzbekistan, Yemen, Palestine Liberation Organization
observers— (6) Bosnia and Herzegovina, Central African Republic, Guyana, Moro National Liberation Front
(Philippines), Togo, "Turkish Republic of Northern Cyprus"
565
Appendix C: International Organizations and Groups (continued)
Paris Club
see Group of 10
Partnership for Peace (PFP)
address— NATO Office of Information and
Press, B-1 1 10 Brussels, Belgium
telephone— [32] (2) 728 44 15
FAX-t 32] (2) 728 45 79
established— 10^ ^ January 1994
aim— to expand and intensify political and
military cooperation throughout Europe,
increase stability, diminish threats to peace, and
build relationships by promoting the spirit of
practical cooperation and commitment to
democratic principles that underpin NATO;
program under the auspices of NATO
members— ( 27) Albania, Armenia, Austria, Azerbaijan, Belarus, Bulgaria, Czech Republic, Estonia, Finland,
Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic of Macedonia,
Moldova, Poland, Romania, Russia, Slovakia, Slovenia, Sweden, Switzerland, Turkmenistan, Ukraine, Uzbekistan
Permanent Court of Arbitration (PCA)
address— Peace Palace, Carnegieplein 2,
NL-2517 KJ The Hague, Netherlands
telephone— [31] (70) 302 42 42
FAX— [31] (70) 302 41 67
established— 29 July 1899
aim— to facilitate the settlement of international
disputes
members— (33) Argentina, Australia, Austria, Belarus, Belgium, Bolivia, Brazil, Bulgaria, Burkina Faso, Cambodia,
Cameroon, Canada, Chile, China, Colombia, Democratic Republic of the Congo, Cuba, Cyprus, Czech Republic,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Fiji, Finland, France, Germany, Greece, Guatemala,
Haiti, Honduras, Hungary, Iceland, India, Iran, Iraq, Israel, Italy, Japan, Jordan, Kyrgyzstan, Laos, Lebanon, Libya,
Liechtenstein, Luxembourg, Malta, Mauritius, Mexico, Netherlands, NZ, Nicaragua, Nigeria, Norway, Pakistan,
Panama, Paraguay, Peru, Poland, Portugal, Romania, Russia, Senegal, Singapore, Slovakia, Slovenia, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Thailand, Turkey, Uganda, Ukraine, UK, US, Uruguay,
Venezuela, Zimbabwe
Population Commission
see Commission on Population and Development
Rio Group (RG)
note— formerly known as Grupo de los Ocho,
established in December 1986
established— NA 1988
aim— to consult on regional Latin American
issues
members— (12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Mexico, Panama, Paraguay, Peru, Uruguay,
Venezuela
Second World
another term for the traditionally Marxist-Leninist states of the USSR and Eastern Europe, with authoritarian
governments and command economies based on the Soviet model; the term is fading from use; see centrally
planned economies
Sistema Economico Latinoamericana(SELA)
note— see Latin American Economic System (LAES)
Social Commission
see Commission for Social Development
socialist countries
in general, countries in which the government owns and plans the use of the major factors of production;
note— the term is sometimes used incorrectly as a synonym for communist countries
South
a popular term for the poorer, less industrialized countries generally located south of the developed countries; the
counterpart of the North; see less developed countries (LDCs)
South Asian Association for Regional
Cooperation (SAARC)
members— (7) Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka
address— P. O. Box 4222, Kathmandu, Nepal
te/ephone— [977] (1) 221785, 226350, 221792,
228029
FAX— [977] (1) 227033, 223991
established— 8 December 1985
aim— to promote economic, social, and cultural
cooperation
566
South Pacific Commission (SPC) members— (26) American Samoa, Australia, Cook Islands, Fiji, France, French Polynesia, Guam, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, New Caledonia, NZ, Niue, Northern Mariana Islands, Palau, Papua
address— Anse Vata, BP D5, 98848 Noumea New Guinea, Pitcairn Islands, Samoa, Solomon Islands, Tokelau, Tonga, Tuvalu, US, Vanuatu, Wallis and Futuna
CEDEX, New Caledonia
telephone— [687] 26 20 00
FAX— [687] 26 38 18
established— 6 February 1947
effective— 29 July 1948
aim— to promote regional cooperation in
economic and social matters
South Pacific Forum (SPF)
address— do Forum Secretariat, Ratu Sukuna
Road, Private Mail Bag, Suva, Fiji
te/ephone— [679] 312 600, 303 106
FAX— [679] 301 102, 305 573
established— 5 August 1971
aim— to promote regional cooperation in political
matters
South Pacific Regional Trade and Economic members— (15) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ,
Cooperation Agreement (Sparteca) Niue, Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
address— do forum Secretariat, Ratu Sukuna
Road GPO Box 856, Suva, Fiji
telephone— [679] 312 600, 303 106
FAX— [679] 302 204
established— NA 1981
aim— to redress unequal trade relationships of
Australia and New Zealand with small island
economies in the Pacific region
Southern African Customs Union (SACU) members— (5) Botswana, Lesotho, Namibia, South Africa, Swaziland
address— Director, State Revenue, Private Bag
1 31 85, Windhoek, Namibia, or Director General,
Trade and Industry, Private Bag X84, Pretoria
0001 , South Africa, or Director of Customs and
Excise, Private Bag 0041 , Gaborone, Botswana,
or Director of Customs and Excise, P. O. Box
891 , Maseru 1 00, Lesotho, or Chief Customs
Officer, P.O. Box 489, Manzini, Swaziland
established— 1 1 December 1 969
aim— to promote free trade and cooperation in
customs matters
Southern African Development Community members— (12) Angola, Botswana, Lesotho, Malawi, Mauritius, Mozambique, Namibia, South Africa, Swaziland,
(SADC) Tanzania, Zambia, Zimbabwe
note— evolved from the Southern African
Development Coordination Conference
(SADCC)
address— Private Bag 0095, Gaborone,','2ed70b23607a91afb30dd7261299c4046e6ca5d113d522be6b33c99949ef03b1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2f2f7c9aeebfbbb4d58e7fbb4fed1609712a12fad5ac301a6f5e9b1de46759b',1998,'MY','Malaysia','transnational-issues',159,'Disputes— international: none
Illicit drugs: world''s largest illicit producer of opium
(cultivation in 1997—155,150 hectares, a 5% decline
from 1996; potential production— 2,365 metric tons,
an 8% drop from 1 996) and a minor producer of
cannabis for the international drug trade; surrender of
drug warlord KHUN SA''s Mong Tai Army in January
1996 was hailed by Rangoon as a major
counternarcotics success, but lack of serious
government commitment and resources continue to
hinder the overall antidrug effort; growing role in the
production of methamphetamines for regional
consumption
f Geography
Location: Southeastern Asia, peninsula and
northern one-third of the island of Borneo, bordering
Indonesia and the South China Sea, south of Vietnam
Geographic coordinates: 2 30 N, 1 12 30 E
Map references: Southeast Asia
Area:
total: 329,750 sq km
land: 328,550 sq km
water: 1 ,200 sq km
Area-comparative: slightly larger than New
Illicit drugs: transit point for Golden T riangle heroin
going to the US, Western Europe, and the Third
World; also a money-laundering center
Disputes— international: Gabcikovo Dam dispute
with Hungary (to be resolved March 1998);
unresolved property issues with Czech Republic over
redistribution of former Czechoslovak federal property
Illicit drugs: minor, but increasing, transshipment
point for Southwest Asian heroin and hashish bound
for Western Europe','663218c2eecf7c3b10a412970e4b6f212a21ad9e83a4794c2364be159852ef47','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43529492aa3b420de871ea718b76371a9ef9ec4899084a96676eb7ccbb77c957',1998,'BI','Burundi','transnational-issues',168,'Disputes— international: offshore islands and
sections of the boundary with Vietnam are in dispute;
maritime boundary with Vietnam not defined; parts of
border with Thailand are indefinite; maritime boundary
with Thailand not clearly defined
Illicit drugs: transshipment site for Golden Triangle
heroin en route to West; possible money-laundering;
high-level narcotics-related corruption reportedly
involving government, military, and police; possible
small-scale opium, heroin, and amphetamine
production; large producer of cannabis for the
international market','7d709ec2c7a301c4dd7b1ca64ee0ee971a56b78299257e4aef700aaa6508ce1d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cf340866ab113f0111b8a6328eb398c7c43bbdb7f538e6838a8fea505c48ee4',1998,'CM','Cameroon','transnational-issues',169,'Location: Western Africa, bordering the Bight of
Biafra, between Equatorial Guinea and Nigeria
Geographic coordinates: 6 00 N, 12 00 E
Map references: Africa
Area:
total: 475,440 sq km
land: 469,440 sq km
water: 6,000 sq km
Area— comparative: slightly larger than California
Land boundaries:
total: 4,591 km
border countries: Central African Republic 797 km,
Chad 1,094 km, Republic of the Congo 523 km,
Equatorial Guinea 189 km, Gabon 298 km, Nigeria
1,690 km
Coastline: 402 km
Maritime claims:
territorial sea: 50 nm
Climate: varies with terrain, from tropical along coast
to semiarid and hot in north
Terrain: diverse, with coastal plain in southwest,
dissected plateau in center, mountains in west, plains
in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Fako 4,095 m
Natural resources: petroleum, bauxite, iron ore,
timber, hydropower potential
Land use:
arable land: 13%
permanent crops: 2%
permanent pastures: 4%
forests and woodland: 78%
other: 3% (1993 est.)
Irrigated land: 210 sq km (1993 est.)
Natural hazards: recent volcanic activity with
release of poisonous gases
Environment— current issues: water-borne
diseases are prevalent; deforestation; overgrazing;
81
Cameroon (continued)
desertification; poaching; overfishing
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection, Tropical Timber 83, Tropical
Timber 94
signed, but not ratified: Nuclear Test Ban
Geography— note: sometimes referred to as the
hinge of Africa
f People
Population: 1 5,029,433 (July 1 998 est.)
Age structure:
0-14 years: 46% (male 3,468,861 ; female 3,436,814)
15-64 years: 51% (male 3,795,748; female
3,829,824)
65 years and over: 3% (male 224,881 ; female
273,305) (July 1998 est.)
Population growth rate: 2.81% (1998 est.)
Birth rate: 42.06 births/1 ,000 population (1998 est.)
Death rate: 13.96 deaths/1 ,000 population (1998
est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.03 ma!e(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.82 male(s)/female (1998 est.)
Infant mortality rate: 76.88 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 51 .44 years
male: 49.9 years
female: 53.03 years (1 998 est.)
Total fertility rate: 5.86 children born/woman (1998
est.)
Nationality:
noun: Cameroonian(s)
adjective: Cameroonian
Ethnic groups: Cameroon Highlanders 31%,
Equatorial Bantu 19%, Kirdi 11%, Fulani 10%,
Northwestern Bantu 8%, Eastern Nigritic 7%, other
African 13%, non-African less than 1%
Religions: indigenous beliefs 51%, Christian 33%,
Muslim 16%
Languages: 24 major African language groups,
English (official), French (official)
Literacy:
definition: age 15 and over can read and write
total population: 63.4%
male: 75%
female: 52.1% (1995 est.)','e532c2985e5d9d2189988b97c20527124705be579a30412d7e7260aae51b68a8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1909f2c6e9b9fc8f28c72bc6886e2816d47d7b6adc7cedea9a300a481eda7154',1998,'CN','China','transnational-issues',175,'Disputes— international: demarcation of
international boundaries in the vicinity of Lake Chad,
the lack of which led to border incidents in the past, is
completed and awaits ratification by Cameroon,
Chad, Niger, and Nigeria; dispute with Nigeria over
land and maritime boundaries in the vicinity of the
Bakasi Peninsula has been referred to the ICJ with a
ruling expected in 1998
83
(also see separate Hong Kong and Taiwan entries)
Sea
Fiery Cross
Reef r-
Northeast Cay
Southwest CayS.-
West York
. Jsland
. Thitu Island Flat
, uk, * Jsland
Loaita Nan^if ^ ^Lankiam Cay *
Sand Cay^Loaita Island /A
Itu Aba Island ’ e''Eldad Reef ''fjanshan
’ . ^Namyit Island
l '' . Island
* '' ''-iy*9
Sin Cowe-^S''’ ’ Mischief °
Island 1 Reef V
Alison ^
Reef
^Pigeon Reef
° Moon
Shoal
Amboyna''''
Cay p o so loo km
0 50 100 mi
Disputes— international: dispute with Romania
over continental shelf of the Black Sea under which
significant gas and oil deposits may exist; agreed in
1997 to two-year negotiating period, after which either
party can refer dispute to the International Court of
Justice; has made no territorial claim in Antarctica (but
has reserved the right to do so) and does not
recognize the claims of any other nation; certain
territory of Moldova and Ukraine— including
Bessarabia and Northern Bukovina— are considered
by Bucharest as historically a part of Romania; this
territory was incorporated into the former Soviet Union
following the Molotov-Ribbentrop Pact in 1940
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for CIS consumption; limited
government eradication program; used as
transshipment point for opiates and other illicit drugs
to Western Europe and Russia
485','f2d4115c22422b178f8e5dc6774dbcc34f0229e7721778ea007d30242a79dc2a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('510223abd580fff90b2691b23cd3939e9fa155c293461d125cf6cf667ced2dfe',1998,'CA','Canada','transnational-issues',176,'m
Disputes— international: claims all of Guyana west
of the Essequibo River; maritime boundary dispute
with Colombia in the Gulf of Venezuela
Illicit drugs: illicit producer of cannabis, opium, and
coca leaf for the international drug trade on a small
scale; however, large quantities of cocaine and heroin
transit the country from Colombia; important
money-laundering hub; active eradication program
primarily targeting opium','ab5bb8d93580b6886dbbb5980493505cbf3063e2ea353ba2db7a03377a863c5e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4930f291af1827b218f4b07a25a0341749ec52e01aa89ad0bf5c313c05b7d96e',1998,'PT','Portugal','transnational-issues',189,'Disputes— international: none
Illicit drugs: increasingly used as a transshipment
point for illicit drugs moving from Latin America and
Africa destined for Western Europe
Disputes— international: none
Macedonia, The
Former Yugoslav
Republic of
Disputes— international: dispute with Greece over
name; in September 1 995, Skopje and Athens signed
an interim accord resolving their dispute over symbols
and certain constitutional provisions; Athens also
lifted its economic embargo on The Former Yugoslav
Republic of Macedonia; twenty bilateral agreements
remain unsigned in a dispute over Bulgarian
nonrecognition of Macedonian as a language distinct
from Bulgarian; the border commission formed by The
Former Yugoslav Republic of Macedonia and Serbia
and Montenegro in April 1 996 to resolve differences in
delineation of their mutual border has made no
progress so far; Albanians in Macedonia claim
discrimination in education, access to public-sector
jobs and representation in government; Party for
Democratic Action (DPA) calls for a rewrite of the
constitution to declare ethnic Albanians a national
group and allow for regional autonomy
Illicit drugs: transshipment point for Southwest
Asian heroin and hashish; minor transit point for South
American cocaine
Location: Southern Africa, island in the Indian
Ocean, east of Mozambique
Geographic coordinates: 20 00 S, 47 00 E
Map references: Africa
Area:
total: 587,040 sq km
land: 581 ,540 sq km
water: 5,500 sq km
Area— comparative: slightly less than twice the size
of Arizona
Land boundaries: 0 km
Coastline: 4,828 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or 1 00 nm from the 2,500-m
isobath
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical along coast, temperate inland, arid
in south
Terrain: narrow coastal plain, high plateau and
mountains in center
286
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Maromokotro 2,876 m
Natural resources: graphite, chromite, coal,
bauxite, salt, quartz, tar sands, semiprecious stones,
mica, fish
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 41 %
forests and woodland: 40%
other: 14% (1993 est.)
Irrigated land: 1 0,870 sq km (1 993 est.)
Natural hazards: periodic cyclones
Environment— current issues: soil erosion results
from deforestation and overgrazing; desertification;
surface water contaminated with raw sewage and
other organic wastes; several species of flora and
fauna unique to the island are endangered
Environment— international agreements:
party to: Biodiversity, Desertification, Endangered
Species, Marine Life Conservation, Nuclear Test Ban,
Ozone Layer Protection
signed, but not ratified: Climate Change, Law of the
Sea
Geography— note: world''s fourth-largest island;
strategic location along Mozambique Channel
Disputes— international: claims Bassas da India,
Europa Island, Glorioso Islands, Juan de Nova Island,
and Tromelin Island (all administered by France)
Illicit drugs: illicit producer of cannabis (cultivated
and wild varieties) used mostly for domestic
consumption; transshipment point for heroin
288','e0a3e77450773bac14da596c44134817b2cb2822dff329a08ed5798e56dff11e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bda518bfda04cf2e262fad18a78427d7b224e78d18481e4485eafac7cb0e6f1',1998,'KY','Cayman Islands','transnational-issues',190,'(dependent territory
of the UK)
Caribbean
Sea
Cayman
Brae
Little ^ ^
Cayman
Grand
Cayman
GEORGE TOWN
O 20 40 Km
O 20 40 mi','372bc38fcc07ce02ef3b0079eb002d49ef47979ef8e325e1b9b0e9936622314d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c727dddf5cd0c6608b299631004f64c8d6f2d838d69919761dc2956be870dfec',1998,'HN','Honduras','transnational-issues',199,'Disputes— international: none
Illicit drugs: vulnerable to drug money-laundering
and drug transshipment
Central African
I Republic
Current issues: In 1 996 the Central African
Republic experienced three mutinies by dissident
elements of the armed forces which demanded back
pay as well as political and military reforms.
Continuing violence in 1 997 between the government
and rebel military groups over pay issues, living
conditions, and lack of opposition party representation
in the government has destroyed many businesses in
the capital, reducing tax revenues and exacerbating
the government''s problems in meeting expenses.
Disputes— international: none
Disputes— international: land boundary dispute
with Honduras mostly resolved by 1 1 September 1992
International Court of Justice (ICJ) decision; the
presidents of Honduras and El Salvador signed in
January 1998 an agreement allowing citizens in the
1992 demarcated areas to choose Honduran or
Salvadoran citizenship; the two countries also agreed
to a final demarcation of the border within one year;
the agreement awaits ratification by the legislative
assemblies of both countries; with respect to the
maritime boundary in the Golfo de Fonseca, ICJ
referred to an earlier agreement in this century and
advised that some tripartite resolution among El
Salvador, Honduras and Nicaragua likely would be
required
illicit drugs: transshipment point for cocaine;
marijuana produced for local consumption
Disputes— international: land boundary dispute
with El Salvador mostly resolved by 1 1 September
1992 International Court of Justice (ICJ) decision; the
presidents of El Salvador and Honduras signed in
January 1998 an agreement allowing citizens in the
1992 demarcated areas to choose Salvadoran or
Honduran citizenship; the two countries aiso agreed
to a final demarcation of the border within one year;
the agreement awaits ratification by the legislative
assemblies of both countries; with respect to the
maritime boundary in the Golfo de Fonseca, ICJ
referred to an earlier agreement in this century and
advised that some tripartite resolution among El
Salvador, Honduras, and Nicaragua likely would be
required; maritime boundary dispute with Nicaragua
Illicit drugs: transshipment point for drugs and
narcotics, mostly along the Caribbean coastline; illicit
producer of cannabis, cultivated on small plots and
used principally for local consumption
Disputes— international: none
Illicit drugs: a hub for Southeast Asian heroin trade;
transshipment and money-laundering center;
increasing indigenous amphetamine abuse
Howland Island
(territory of the US)
Illicit drugs: transshipment point for cocaine
destined for the US
344','74a470b5aec1f26d16757d7da42ba023929f9caaf0808b8a56df134ffab55141','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b333e6bbfca6e4a58fbde1a77a9c5eba0bd0de712195734b08b185493761dfe3',1998,'TD','Chad','transnational-issues',208,'Disputes— international: demarcation of
international boundaries in the vicinity of Lake Chad,
the lack of which led to border incidents in the past, is
completed and awaits ratification by Cameroon,
Chad, Niger, and Nigeria','779e18aa60762fb34498be42563f0db623f0a795099037370dd7ccba4a0bc19e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a3ad519a8f92ee8e8a326941abe4495c1adf9e2216a071e80b272f05c5a477c',1998,'CL','Chile','transnational-issues',209,'Location: Southern South America, bordering the
South Atlantic Ocean and South Pacific Ocean,
between Argentina and Peru
Geographic coordinates: 30 00 S, 71 00 W
Map references: South America
Area:
total: 756,950 sq km
land: 748,800 sq km
water: 8,1 50 sq km
note : includes Easter Island (Isla de Pascua) and Isla
Sala y Gomez
Area— comparative: slightly smaller than twice the
size of Montana
Land boundaries:
total: 6,171 km
border countries: Argentina 5,1 50 km, Bolivia 861 km,
Peru 160 km
Coastline: 6,435 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
94
Climate: temperate; desert in north; cool and damp
in south
Terrain: low coastal mountains; fertile central valley;
rugged Andes in east
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point : Cerro Aconcagua 6,962 m
Natural resources: copper, timber, iron ore,
nitrates, precious metals, molybdenum
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 1 8%
forests and woodland: 22%
other: 55% (1 993 est.)
Irrigated land: 12,650 sq km (1993 est.)
Natural hazards: severe earthquakes; active
volcanism; tsunamis
Environment— current issues: air pollution from
industrial and vehicle emissions; water pollution from
raw sewage; deforestation contributing to loss of
biodiversity; soil erosion; desertification
Environment— international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location relative to sea
lanes between Atlantic and Pacific Oceans (Strait of
Magellan, Beagle Channel, Drake Passage);
Atacama Desert is one of world''s driest regions
i People
Population: 14,787,781 (July 1998 est.)
Age structure:
0-14 years: 28% (male 2,1 34,701 ; female 2,043,1 12)
15-64 years: 65% (male 4,768,366; female
4,811,403)
65 years and over: 7% (male 426,924; female
603,275) (July 1998 est.)
Population growth rate: 1.27% (1998 est.)
Birth rate: 1 8.28 births/1 ,000 population (1 998 est.)
Death rate: 5.55 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(1998 est.)
Sex ratio:
at birth: 1.05 male(s)/fema!e
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/female (1 998 est.)
Infant mortality rate: 10.39 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 75.16 years
male: 72.01 years
female: 78.48 years (1998 est.)
Total fertility rate: 2.3 children born/woman
(1998 est.)
Nationality:
noun: Chilean(s)
adjective: Chilean
Ethnic groups: white and white-Amerindian 95%,
Amerindian 3%, other 2%
Religions: Roman Catholic 89%, Protestant 11%,
Jewish
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 95.2%
male: 95.4%
female: 95% (1995 est.)
Disputes— international: short section of the
southeastern boundary with Argentina is indefinite;
Bolivia has wanted a sovereign corridor to the South
Pacific Ocean since the Atacama area was lost to
Chile in 1884; dispute with Bolivia over Rio Lauca
water rights; territorial claim in Antarctica (Chilean
Antarctic Territory) partially overlaps Argentine and
British claims
Illicit drugs: a minor transshipment country for
cocaine destined for the US and Europe; booming
economy has made it more attractive to traffickers
seeking to launder drug profits
96
telephone— {56] (2) 2102000
FAX- [56] (2) 2080252, 2081946
established— 25 February 1948 as Economic
Commission for Latin America (ECLA)
aim— to promote economic development as a
regional commission of the UN’s Economic and
Social Council
members— (41 ) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Cuba, Dominica, Dominican Republic, Ecuador, El Salvador, France, Grenada, Guatemala,
Guyana, Haiti, Honduras, Italy, Jamaica, Mexico, Netherlands, Nicaragua, Panama, Paraguay, Peru, Portugal,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Spain, Suriname, Trinidad and Tobago, UK,
US, Uruguay, Venezuela
associate members-(7) Anguilla, Aruba, British Virgin Islands, Montserrat, Netherlands Antilles, Puerto Rico,
Virgin Islands
Economic Commission for Western Asia
(ECWA)
see Economic and Social Commission for Western Asia (ESCWA)
Economic Community of Central African
States (CEEAC)
note— acronym from Communaute Economique
des Etats de I''Afrique Centrale
address— CEEAC, BP 2112, Libreville, Gabon
teiephone-{2A\\] 73 35 47, 73 35 48, 73 36 77
established— 1 8 October 1983
aim— to promote regional economic cooperation
and establish a Central African Common Market
members— (10) Burundi, Cameroon, Central African Republic, Chad, Democratic Republic of the Congo, Republic
of the Congo, Equatorial Guinea, Gabon, Rwanda, Sao Tome and Principe
observer— (1) Angola
Economic Community of the Great Lakes
Countries (CEPGL)
members— (3) Burundi, Democratic Republic of the Congo, Rwanda
note— acronym from Communaute Economique
des Pays des Grands Lacs
address— B.O. Box 58, Gisenyi, Rwanda
telephone— [250] 40228
FAX— [250] 40785
established— 26 September 1976
aim— to promote regional economic cooperation
and integration
546
Economic Community of West African
States (ECOWAS)
members— { 16) Benin, Burkina Faso, Cape Verde, Cote d’Ivoire, The Gambia, Ghana, Guinea, Guinea-Bissau,
Liberia, Mali, Mauritania, Niger, Nigeria, Senegal, Sierra Leone, Togo
address— 6 King George V Road, PMB 12745,
Lagos, Nigeria
fe/ep/?one— [234] (1) 636839, 636841, 636064,
630398
FAX''— {234] (1) 636822
established— 28 May 1975
aim— to promote regional economic cooperation
Economic Cooperation Organization (ECO)
address— No. 5 Khayahan-A-Hejab, Bd
Keshavarz, P.O. Box 14155-6176, Teheran, Iran
Islamic Republic
telephone— [96] (21) 653349, 654888, 655100,
658614, 656152, 658045, 659052
FAX-498] (21) 658046
established— HA 1985
aim— to promote regional cooperation in trade,
transportation, communications, tourism,
cultural affairs, and economic development
members— (1 0) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan, Pakistan, Tajikistan, Turkey, Turkmenistan,','1b451977d33c94e58c3e17a74975cd05a2aeb08e4de95a0e8308ca94e00f690f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90b357247f178c1c8445e980034a5c3702167514211bdadebe9414161c0c9303',1998,'HK','Hong Kong','transnational-issues',222,'Disputes— international: boundary with India in
dispute; two disputed sections of the boundary with
Russia remain to be settled; most of the boundary with
Tajikistan in dispute; 33-km section of boundary with
North Korea in the Paektu-san (mountain) area is
indefinite; involved in a complex dispute over the
Spratly Islands with Malaysia, Philippines, Taiwan,
Vietnam, and possibly Brunei; maritime boundary
dispute with Vietnam in the Gulf of Tonkin; Paracel
Islands occupied by China, but claimed by Vietnam
and Taiwan; claims Japanese-administered
Senkaku-shoto (Senkaku Islands/Diaoyu Tai), as
does Taiwan; sections of land border with Vietnam are
indefinite
Illicit drugs: major transshipment point for heroin
produced in the Golden Triangle; growing domestic
drug abuse problem
99','3b1588f1813d06d542320361209c9de0c4c0f3dc60f89eb65e4f4da17e6b5fe9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4786f786073e0526dc68c917f155706702d9f7f31bc341237973703fd13aab1',1998,'AU','Australia','transnational-issues',229,'Disputes— international: none
Clipperton Island ■ ■
(possession of France)
Frederick
l Reef
v * Saumarcz Reef
^ IS
Wreck Reef-y*
Bird Islet
Cato Island -s
Disputes— international: none
Disputes— international: none
Location: Southern Europe, an enclave of Rome
(Italy)
Geographic coordinates: 41 54 N, 12 27 E
Map references: Europe
Area:
total: 0.44 sq km
land: 0.44 sq km
water: 0 sq km
Area— comparative: about 0.7 times the size of The
Mall in Washington, DC
Land boundaries:
total: 3.2 km
border countries: Italy 3.2 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; mild, rainy winters (September
to mid-May) with hot, dry summers (May to
September)
Terrain: low hill
Elevation extremes:
lowest point: unnamed location 19 m
highest point: unnamed location 75 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (urban area)
Irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: Air Pollution, Environmental
Modification
Holy See (Vatican City) (continued)
Geography— note: urban; landlocked; enclave of
Rome, Italy; world''s smallest state; outside the
Vatican City, 13 buildings in Rome and Castel
Gandolfo (the pope''s summer residence) enjoy
extraterritorial rights
Disputes— international: none
208
Disputes— international: none
213
Disputes— international: none
Northern Mariana
Islands
(commonwealth in political
union with the US)
O 100 200 km
O 100 200 mi
Farallon de
Pajaros ,
v , Maug Islands
* Asuncion Island
Philippine ^Agrihan
Sea
Pagan 0 North
Pacific
Guguan Ocean
aSarigan
° Anatahan
'' Farallon de
Medinilla
Sa''panfsA.PAN
• Tinian
°Pota','f07dd04cea4df7b9f12f7f39da8c9de54a25928262aeb016ef87f9ad58c456cd','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f93e68f51bc2c8589c259d7dc18b39d548ef0e4ca1b763c9ca16ad354cf19a5a',1998,'CO','Colombia','transnational-issues',243,'Disputes— international: maritime boundary
dispute with Venezuela in the Gulf of Venezuela;
territorial disputes with Nicaragua over Archipelago de
San Andres y Providencia and Quita Sueno Bank
Illicit drugs: illicit producer of coca, opium poppies,
and cannabis; cultivation of coca in 1997—79,500
hectares, an 18% increase over 1996; potential
production of cocaine in 1997—125 metric tons, a
14% increase over 1996; cultivation of opium in
1997—6,600 hectares, a 5% increase over 1996;
potential production of opium in 1997—66 metric tons,
a 5% increase over 1996; the world''s largest
processor of coca derivatives into cocaine; supplier of
cocaine to the US and other international drug
markets; active aerial eradication program seeks to
virtually eliminate coca and opium crops
aim— to provide a forum for largest debtor
nations in Latin America
members— (11) Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic, Ecuador, Mexico, Peru, Uruguay,
Venezuela
Group of 15 (G-15)
note — by p rod u ct of the Non-Aligned Movement
address— Technical Support Facility, Ch du
Champ d''Ancier 1 7, Case postale 326, CH-121 1
Geneva 19, Switzerland
telephone— {41] (22) 798 42 10
FAX-[ 41] (22) 798 38 49
established— September 1989
aim— to promote economic cooperation among
developing nations; to act as the main political
organ for the Non-Aligned Movement
members— (15) Algeria, Argentina, Brazil, Egypt, India, Indonesia, Jamaica, Malaysia, Mexico, Nigeria, Peru,
Senegal, Venezuela, Yugoslavia, Zimbabwe
Group of 19 (G-19)
established— HA October 1975
aim— to represent the interests of the less
developed countries (LDCs) that participated in
the Conference on International Economic
Cooperation (CIEC) held in several sessions
between NA December 1975 and 3 June 1977
members— ( 19) Algeria, Argentina, Brazil, Cameroon, Democratic Republic of the Congo, Egypt, India, Indonesia,
Iran, Iraq, Jamaica, Mexico, Nigeria, Pakistan, Peru, Saudi Arabia, Venezuela, Yugoslavia, Zambia
551
Appendix C: International Organizations and Groups (continued)
Group of 24 (G-24)
address— do European Commission, DGIA—
G-24 Coordination Unit, Rue de la Loi 200,
B-1049 Brussels, Belgium
telephone— [32] (2) 299 22 44
FAX— [32] (2) 299 06 02
established— HA January 1972
aim— to promote the interests of developing
countries in Africa, Asia, and Latin America
within the IMF
members— (24) Algeria, Argentina, Brazil, Colombia, Democratic Republic of the Congo, Cote d''Ivoire, Egypt,
Ethiopia, Gabon, Ghana, Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru, Philippines, Sri Lanka,
Syria, Trinidad and Tobago, Venezuela, Yugoslavia
Group of 30 (G-30)
address— 1 990 M Street NW, Suite 450,
Washington, DC 20036, US
telephone— [\\] (202) 331 2472
FAX— [1] (202) 785 9423
established— NA 1 979
aim— to discuss and propose solutions to the
world''s economic problems
members— (30) informal group of 30 leading international bankers, economists, financial experts, and business
leaders organized by Johannes Witteveen (former managing director of the IMF)
Group of 33 (G-33)
members— (33) leading economists from 13 countries
established— NA 1987
aim— to promote solutions to international
economic problems
Group of 77 (G-77)
address— Office of the Chairman, United
Nations, Room S-3959, P.O. Box 20, New York,
NY 10017, US
telephone— [\\] (212) 963 3816, 963 0192, 963
Mil
FAX— [1 ] (21 2) 963 3515, 963 1753
established— NA October 1967
aim— to promote economic cooperation among
developing countries; name persists in spite of
increased membership
members— (129 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, Antigua and Barbuda,
Argentina, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Brunei,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba,
Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji,
Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India,
Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia,
Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Federated
States of Micronesia, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Qatar, Romania, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname,
Swaziland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Uganda, UAE, Uruguay,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe, Palestine Liberation Organization
Gulf Cooperation Council (GCC)
members— { 6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
note— also known as the Cooperation Council
for the Arab States of the Gulf
address— P.O. Box 7153, Riyadh 11462, Saudi
Arabia
telephone— {%§] (1) 482 7777
FAX— [966] (1)482 9109
established— 25 May 1981
aim— to promote regional cooperation in
economic, social, political, and military affairs
Hexagonal Group
see Central European Initiative (CEI)
high-income countries
another term for the industrialized countries with high per capita GDPs; see developed countries (DCs)
552
Indian Ocean Commission (InOC)
members— (5) Comoros, France (for Reunion), Madagascar, Mauritius, Seychelles
address— QA avenue Sir Guy Forget, BP7,
Quatre Bornes, Mauritius
telephone^ 230] 425 9564, 425 1652
FAX''— [230] 425 1209
established— July 1982
aim— to organize and promote regional
cooperation in ali sectors, especially economic
industrial countries
another term for the developed countries; see developed countries (DCs)
Inter-American Development Bank (IADB)
note— also known as Banco Interamericano de
Desarrollo (BID)
ac/c/ress — 1 300 New York Avenue NW,
Washington, DC 20577, US
telephone— [\\] (202) 623 1000
FAX— [1 ] (202) 623 3096
established— 8 April 1959
effective— 30 December 1959
aim— to promote economic and social
development in Latin America
members— (46) Argentina, Austria, The Bahamas, Barbados, Belgium, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Croatia, Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France, Germany,
Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica, Japan, Mexico, Netherlands, Nicaragua, Norway,
Panama, Paraguay, Peru, Portugal, Slovenia, Spain, Suriname, Sweden, Switzerland, Trinidad and Tobago, UK,
US, Uruguay, Venezuela
Inter-Governmental Authority on Drought
and Development (IGADD)
see Inter-Governmental Authority on Development (IGAD)
Inter-Governmental Authority on
Development (IGAD)
members— (7) Djibouti, Eritrea, Ethiopia, Kenya, Somalia, Sudan, Uganda
note— formerly known as Inter-Governmental
Authority on Drought and Development (IGADD)
address— P. O. Box 2653, Djibouti, Djibouti
te/ep/7 one — [2 5 3] 354050, 354486
FAX— [253] 356994
established— 1 5-1 6 January 1 986 as the
Inter-Governmental Authority on Drought and
Development
revitalized— 21 March 1996 as the Inter-
Governmental Authority on Development
aim— to promote a social, economic, and
scientific community among its members
International Atomic Energy Agency (IAEA)
address— ] Wagramerstrasse 5, P.O. Box 100,
A- 1400 Vienna, Austria
telephone— [A3] (1) 20600
FAX— [43] (1) 20607
established— 26 October 1956
effective— 29 July 1957
aim— to promote peaceful uses of atomic energy
members— (124) Afghanistan, Albania, Algeria, Argentina, Armenia, Australia, Austria, Bangladesh, Belarus,
Belgium, Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, Burma, Cambodia, Cameroon, Canada, Chile, China,
Colombia, Democratic Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, Finland, France, Gabon, Georgia,
Germany, Ghana, Greece, Guatemala, Haiti, Holy See, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Lebanon, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malaysia, Mali, Marshall
Islands, Mauritius, Mexico, Monaco, Mongolia, Morocco, Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia,
Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland,
Syria, Tanzania, Thailand, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela,
Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
International Bank for Economic
Cooperation (IBEC)
was established on 22 October 1963 to promote economic cooperation and development; members were Bulgaria,
Cuba, Czechoslovakia, East Germany, Hungary, Mongolia, Poland, Romania, USSR, Vietnam; now it is a Russian
bank with a new charter
553
Appendix C: International Organizations and Groups (continued)
International Bank for Reconstruction and
Development (IBRD)
note— also known as the World Bank
address— 1818 H Street NW, Washington, DC
20433, US
telephone— [\\] (202) 477 1234
FAX''— [1] (202) 477 6391
established— 22 July 1944
effective— 27 December 1 945
aim— to provide economic development loans; a
UN specialized agency
International Chamber of Commerce (ICC)
address— 38 Cours Albert 1st, F-75008 Paris,','f4b24b3c4c0d5ed1d46bcd278bf5323bbf3c59c115753bbf170299baee396960','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7050917ad7f20a9413c95322c3b66358b79b2008947043cb546a44af18bb4eb4',1998,'KM','Comoros','transnational-issues',244,'0 30 60 km
0 30 60 mi
n
Indian Ocean
Imoroni
\\ \\ Grande Comore
X~\\) (Njazidja)
MoutsamoudouA^^
KSSmboni','33f805571b94d35f8d63e514ac75ed673647da4273b75eea42d64e7d2e8f4c3b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b544af3d2adb2c9c7b9ad463408879f610d2cfd9a375272e3b5e2320f870092a',1998,'MZ','Mozambique','transnational-issues',245,'MayotteX^ ( (
Channel
Administered by FRANCE,
claimed by COMOROS.
Historical perspective: Comoros has had difficulty
in achieving political stability, having endured 18
coups or attempted coups since receiving
independence from France in 1975. Most recently, in
August 1997, the islands of Anjouan and Moheli
declared their independence from Comoros. An
attempt in September 1997 by the government to
reestablish control over the rebellious islands by force
failed, and presently the Organization of African Unity
is brokering negotiations to effect a reconciliation.
Location: Southern Africa, bordering the
Mozambique Channel, between South Africa and
Tanzania
Geographic coordinates: 18 15 S, 35 00 E
Map references: Africa
Area:
total: 801,590 sq km
land: 784,090 sq km
water: 17,500 sq km
Area— comparative: slightly less than twice the size
of California
Land boundaries:
total: 4,571 km
border countries: Malawi 1,569 km, South Africa 491
km, Swaziland 1 05 km, Tanzania 756 km, Zambia 41 9
km, Zimbabwe 1,231 km
Coastline: 2,470 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands in center,
high plateaus in northwest, mountains in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Monte Binga 2,436 m
Natural resources: coal, titanium, natural gas
Land use:
arable land: 4%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 1 8%
other: 22% (1993 est.)
Irrigated land: 1,180 sq km (1993 est.)
Natural hazards: severe droughts and floods occur
in central and southern provinces; devastating
cyclones
Environment— current issues: a long civil war and
recurrent drought in the hinterlands have resulted in
increased migration of the population to urban and
coastal areas with adverse environmental
consequences; desertification; pollution of surface
and coastal waters
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Disputes— international: quadripoint with
Botswana, Namibia, and Zambia is in disagreement
Illicit drugs: significant transit point for African
cannabis and South Asian heroin, mandrax, and
methamphetamines destined for the South African
and European markets
Taiwan
Location: Eastern Asia, islands bordering the East
China Sea, Philippine Sea, South China Sea, and
Taiwan Strait, north of the Philippines, off the
southeastern coast of China
Geographic coordinates: 23 30 N, 121 00 E
Map references: Southeast Asia
Area:
total: 35,980 sq km
land: 32,260 sq km
water: 3,720 sq km
note: includes the Pescadores, Matsu, and Quemoy
Area— comparative: slightly smaller than Maryland
and Delaware combined
Land boundaries: 0 km
Coastline: 1,448 km
Maritime claims:
exclusive economic zone : 200 nm
territorial sea: 12 nm
Climate: tropical; marine; rainy season during
southwest monsoon (June to August); cloudiness is
persistent and extensive all year
Terrain: eastern two-thirds mostly rugged
mountains; flat to gently rolling plains in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Yu Shan 3,997 m
Natural resources: small deposits of coal, natural
gas, limestone, marble, and asbestos
Land use:
arable land: 24%
permanent crops: 1%
permanent pastures: 5%
forests and woodland: 55%
other: 15%
Irrigated land: NAsqkm
Natural hazards: earthquakes and typhoons
Environment— current issues: air pollution; water
pollution from industrial emissions, raw sewage;
contamination of drinking water supplies; trade in
endangered species; low-level radioactive waste
disposal
Environment— international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Disputes— international: involved in complex
dispute over the Spratly Islands with China, Malaysia,
Philippines, Vietnam, and possibly Brunei; Paracel
Islands occupied by China, but claimed by Vietnam
and Taiwan; claims Japanese-administered
Senkaku-shoto (Senkaku Islands/Diaoyu Tai), as
does China
Illicit drugs: considered an important heroin transit
point; major problem with domestic consumption of
methamphetamines and heroin
Appendix A:
Abbreviations
ABEDA
Arab Bank for Economic Development in Africa
ACC
Arab Cooperation Council
ACCT
Agence de Cooperation Culturelle et Technique; see Agency for
Cultural and Technical Cooperation; changed name in 1996 to Agence
de la francophonie or Agency for the French-speaking Community
ACP
African, Caribbean, and Pacific Countries
AfDB
African Development Bank
AFESD
Arab Fund for Economic and Social Development
AG
Andean Group
Air Pollution
Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen
Protocol to the 1979 Convention on Long-Range Oxides Transboundary
Air Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
Air Pollution-Sulphur 85
Protocol to the 1979 Convention on Long-Range Transboundary
Air Pollution on the Reduction of Sulphur Emissions or Their Transboundary
Fluxes by at Least 30%
Air Pollution-Sulphur 94
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
Further Reduction of Sulphur Emissions
Air Pollution-Volatile
Protocol to the 1979 Convention on Organic Compounds Long-Range
Transboundary Air Pollution Concerning the Control of Emissions of Volatile
Organic Compounds or Their Transboundary Fluxes
AL
Arab League
ALADI
Asociacion Latinoamericana de Integracion; see Latin American Integration
Association (LAIA)
AMF
Arab Monetary Fund
AMU
Arab Maghreb Union
Antarctic-Environmental
Protocol
Protocol on Environmental Protection to the Antarctic Treaty
ANZUS
Australia-New Zealand-United States Security Treaty
APEC
Asia Pacific Economic Cooperation
Arabsat
Arab Satellite Communications Organization
AsDB
Asian Development Bank
ASEAN
Association of Southeast Asian Nations
Autodin
Automatic Digital Network
BAD
Banque Africaine de Developpement; see African Development Bank (AfDB)
BADEA
Banque Arabe de Developpement Economique en Afrique; see Arab Bank for
Economic Development in Africa (ABEDA)
BCIE
Banco Centroamericano de integracion Economico; see Central American Bank
for Economic Integration (BCIE)
BDEAC
Banque de Developpment des Etats de I''Afrique Centraie; see Central African
States Development Bank (BDEAC)
Benelux
Benelux Economic Union
BID
Banco Interamericano de Desarrollo; see Inter-American Development Bank
(IADB)
Biodiversity
Convention on Biological Diversity
524
BIS
Bank for International Settlements
BOAD
Banque Ouest-Africaine de Developpement; see West African Development Bank
(WADB)
BSEC
Black Sea Economic Cooperation Zone
c
C
Commonwealth
CACM
Central American Common Market
CAEU
Council of Arab Economic Unity
Caricom
Caribbean Community and Common Market
CB
Citizen’s band mobile radio communications
CBSS
Council of the Baltic Sea States
ccc
Customs Cooperation Council
CDB
Caribbean Development Bank
CE
Council of Europe
CEAO
Communaute Economique de I''Afrique de I''Ouest; see West African Economic
Community (CEAO)
CEEAC
Communaute Economique des Etats de I''Afrique Centrale; see Economic
Community of Central African States (CEEAC)
CEI
Central European Initiative
CEMA
Council for Mutual Economic Assistance; also known as CMEA or Comecon
CEPGL
Communaute Economique des Pays des Grands Lacs; see Economic Community
of the Great Lakes Countries (CEPGL)
CERN
Conseil Europeen pour la Recherche Nucleaire; see European Organization for
Nuclear Research (CERN)
CG
Contadora Group
c.i.f.
cost, insurance, and freight
CIS
Commonwealth of Independent States
CITES
see Endangered Species
Climate Change
United Nations Framework Convention on Climate Change
Climate Change-
Kyoto Protocol
Kyoto Protocol to the United Nations Framework Convention on Climate Change
CMEA
Council for Mutual Economic Assistance (CEMA); also known as Comecon
COCOM
Coordinating Committee on Export Controls
Comecon
Council for Mutual Economic Assistance (CEMA); also known as CMEA
Comsat
Communications Satellite Corporation
CP
Colombo Plan
CSCE
Conference on Security and Cooperation in Europe; see Organization on Security
and Cooperation in Europe (OSCE)
CY
calendar year
D
DC
developed country
Desertification
United Nations Convention to Combat Desertification in Those Countries
Experiencing Serious Drought and/or Desertification, Particularly in Africa
DSN
Defense Switched Network
DWT
deadweight ton
E
EADB
East African Development Bank
EAPC
Euro-Atlantic Partnership Council
EBRD
European Bank for Reconstruction and Development
525
Appendix A: Abbreviations (continued)
EC
European Community; see European Union (EU)
ECA
Economic Commission for Africa
ECAFE
Economic Commission for Asia and the Far East; see Economic and Social for
Asia and the Pacific (ESCAP)
ECE
Economic Commission for Europe
ECLA
Economic Commission for Latin America; see Economic Commission for Latin
America and the Caribbean (ECLAC)
ECLAC
Economic Commission for Latin America and the Caribbean
ECO
Economic Cooperation Organization
ECOSOC
Economic and Social Council
ECOWAS
Economic Community of West African States
ECSC
European Coal and Steel Community; see European Union (EU)
ECWA
Economic Commission for Western Asia; see Economic and Social Commission
for Western Asia (ESCWA)
EEC
European Economic Community; see European Union (EU)
EFTA
European Free Trade Association
EIB
European Investment Bank
EMU
European Monetary Union
Endangered Species
Convention on the International Trade in Endangered Species of Wild Flora and
Fauna (CITES)
Entente
Council of the Entente
Environmental Modification
Convention on the Prohibition of Military or Any Other Hostile Use of
Environmental Modification Techniques
ESA
European Space Agency
ESCAP
Economic and Social Commission for Asia and the Pacific
ESCWA
Economic and Social Commission for Western Asia
est.
estimate
EU
European Union
Euratom
European Atomic Energy Community; see European Community (EC)
Eutelsat
European Telecommunications Satellite Organization
Ex-lm
Export-Import Bank of the United States
F
FAO
Food and Agriculture Organization
FAX
facsimile
f.o.b.
free on board
FLS
Front Line States
FRG
Federal Republic of Germany (West Germany); used for information dated before
3 October 1990 orCY91
FSU
former Soviet Union
FY
fiscal year (FY93/94, for example, began in calendar year 1993 and ended in
calendar year 1994)
FYROM
The Former Yugoslav Republic of Macedonia
FZ
Franc Zone
G
G-2
Group of 2
v~-
526
G-7
Group of 7
G-8
Group of 8
G-9
Group of 9
G-10
Group of 10
G-11
Group of 1 1
G-15
Group of 15
G-19
Group of 19
G-24
Group of 24
G-30
Group of 30
G-33
Group of 33
G-77
Group of 77
GATT
General Agreement on Tariffs and Trade; subsumed by the World Trade
Organization (WTrO) on 1 January 1995
GCC
Gulf Cooperation Council
GDP
gross domestic product
GDR
German Democratic Republic (East Germany); used for information dated before
3 October 1990 orCY91
GNP
gross national product
GRT
gross register ton
GWP
gross world product
H
Hazardous Wastes
Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal
HF
high-frequency
1
IADB
Inter-American Development Bank
IAEA
International Atomic Energy Agency
IBEC
International Bank for Economic Cooperation
IBRD
International Bank for Reconstruction and Development (World Bank)
ICAO
International Civil Aviation Organization
ICC
International Chamber of Commerce
ICEM
Intergovernmental Committee for European Migration; see International
Organization for Migration (IOM)
ICFTU
International Confederation of Free Trade Unions; see World Confederation of
Labor (WCL)
ICJ
International Court of Justice
(CM
Intergovernmental Committee for Migration; see International Organization for
Migration (IOM)
ICRC
International Committee of the Red Cross
ICRM
International Red Cross and Red Crescent Movement
IDA
International Development Association
IDB
Islamic Development Bank
IEA
International Energy Agency
IFAD
International Fund for Agricultural Development
IFC
International Finance Corporation
IFCTU
International Federation of Christian Trade Unions
IFRCS
International Federation of Red Cross and Red Crescent Societies
IGAD
Inter-Governmental Authority on Development
527
Appendix A: Abbreviations (continued)
IGADD
Inter-Governmental Authority on Drought and Development
IHO
International Hydrographic Organization
MB
International Investment Bank
ILO
International Labor Organization
IMCO
Intergovernmental Maritime Consultative Organization; see International Maritime
Organization (IMO)
IMF
International Monetary Fund
IMO
International Maritime Organization
Inmarsat
International Mobile Satellite Organization
InOC
Indian Ocean Commission
Intelsat
International Telecommunications Satellite Organization
Interpol
International Criminal Police Organization
Intersputnik
International Organization of Space Communications
IOC
International Olympic Committee
IOM
International Organization for Migration
ISO
International Organization for Standardization
ITU
International Telecommunication Union
K
kHz
kilohertz
km
kilometer
kW
kilowatt
kWh
kilowatt hour
L
LAES
Latin American Economic System
LAIA
Latin American Integration Association
LAS
League of Arab States; see Arab League (AL)
Law of the Sea
United Nations Convention on the Law of the Sea (LOS)
LDC
less developed country
LLDC
least developed country
London Convention
see Marine Dumping
LORCS
League of Red Cross and Red Crescent Societies; see International Federation of
Red Cross and Red Crescent Societies (IFRCS)
LOS
see Law of the Sea
M
m
meter
Marecs
Maritime European Communications Satellite
Marine Dumping
Convention on the Prevention of Marine Pollution by Dumping Wastes and Other
Matter
Marine Life Conservation
Convention on Fishing and Conservation of Living Resources of the High Seas
MARPOL
see Ship Pollution
Medarabtel
the Middle East Telecommunications Project of the International
Telecommunications Union
Mercosur
Mercado Comun del Cono Sur; see Southern Cone Common Market
MHz
megahertz
MINURSO
United Nations Mission for the Referendum in Western Sahara
MINUGUA
United Nations Verification Mission in Guatemala
MIPONUH
United Nations Police Mission in Haiti
MONUA
United Nations Observer Mission in Angola
MTCR
Missile Technology Control Regime
528
N
NA
not available
NACC
North Atlantic Cooperation Council; see Euro-Atlantic Partnership Council (EAPC)
NAM
Nonaligned Movement
NATO
North Atlantic Treaty Organization
NC
Nordic Council
NEA
Nuclear Energy Agency
NEGL
negligible
NIB
Nordic Investment Bank
NIC
newly industrializing country; see newly industrializing economy (NIE)
NIE
newly industrializing economy
nm
nautical mile
NMT
Nordic Mobile Telephone
NSG
Nuclear Suppliers Group
Nuclear Test Ban
Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and
Under Water
NZ','c1ca3bebb7cd004b3bc6a57da1d4a8d9907eb440e0becba277f496e7f185235d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f21ce5e75c69ed537af98f2758d8a9756c6b82242e6c3efe2443d0aa0a2bb5d9',1998,'CG','Congo','transnational-issues',258,'Disputes— international: Democratic Republic of
the Congo-Tanzania-Zambia tripoint in Lake
Tanganyika may no longer be indefinite since it has
been informally reported that the indefinite segment of
the Democratic Republic of the Congo-Zambia
boundary has been settled; long segment of the
boundary with Republic of the Congo along the Congo
River is indefinite (no division of the river or its islands
has been made)
Illicit drugs: illicit producer of cannabis, mostly for
domestic consumption
109
Disputes— international: long segment of the
boundary with Democratic Republic of the Congo
along the Congo River is indefinite (no division of the
river or its islands has been made)
111','5d5580a32ae688d6685f9f7c20a2b0238c375dd8119351cabbd2b44bc0f5fdf9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f5d60a67354a5bc41d6df1511eeb6bd7b3fb4582828a2bd77909c4d59895eb0',1998,'CK','Cook Islands','transnational-issues',261,'(self-governing in free
association with
New Zealand)
Rakahanga ,
Pukapuka ^ 1 Manihiki
■ Nassau
Island
° Penrhyn
Suwarrow
South Pacific Ocean
Palmerston >
Aitutaki,
■ Manuae
Takutea ■, .Mitiaro
Atiu ''Mauke
O 150 300 km
0 150 300 mi
Rarotonga
-<— * AVARUA
* Mangaia
Disputes— International: none
Coral Sea Islands
(territory of Australia)
$ Osprey Reef
^Shark Reef
Bougainville
Reef#
Moore
} " Reefs
Holmes Reefs &
'' a*
\\ # Flora Reef
^Herald Cays — $
V'' Flinders
<$> 4 Resf
''
5*2*. Cr*
Willis Islets
Cl yMagdeiaine Cays
%~-Coringa Islets
Tregrosse Islets
f
^***Lihou
0 Tregrosse Reefs
Abington Reefs
Reef
* Marion
f$Reef
Coral
Sea
Disputes— international: none','0f7f3408fc0ea9471ef63e66123201ebd381291e843d22ff2fcddf53c6fcb580','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f767713a688c40d08bfecd6d758253a0e210c90ba0a7e5f0ac17f5e78500b64e',1998,'CR','Costa Rica','transnational-issues',270,'G e o g r a p h y
Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Nicaragua and Panama
Geographic coordinates: 10 00 N, 84 00 W
Map references: Central America and the
Caribbean
Area:
total: 51,100 sq km
land: 50,660 sq km
water: 440 sq km
note: includes Isla del Coco
Area— comparative: slightly smaller than West
Virginia
Land boundaries:
total: 639 km
border countries: Nicaragua 309 km, Panama 330 km
Coastline: 1,290 km
Maritime claims:
exclusive economic zone : 200 nm
territorial sea: 12 nm
Climate: tropical; dry season (December to April);
rainy season (May to November)
Terrain: coastal plains separated by rugged
mountains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro Chirripo 3,810 m
Natural resources: hydropower potential
Land use:
arable land: 6%
permanent crops: 5%
permanent pastures: 46%
forests and woodland: 31 %
other: 12% (1993 est.)
Irrigated land: 1,200 sq km (1993 est.)
Natural hazards: occasional earthquakes,
hurricanes along Atlantic coast; frequent flooding of
lowlands at onset of rainy season; active volcanoes
Environment— current issues: deforestation,
largely a result of the clearing of land for cattle
ranching; soil erosion
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Wetlands
signed, but not ratified: Marine Life Conservation','cca773926bd236caf54e9fa796ddb9cf2b4a7ff99adbaedbcdcbeea8d269b00f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e6ba98020809d10eb9eddfcd52400e0c60fb3d20d1f7d6b5da0db42c232eba9',1998,'DE','Germany','transnational-issues',278,'Disputes— international: none
Illicit drugs: transshipment country for cocaine and
heroin from South America; illicit production of
cannabis on small, scattered plots
Disputes— international: short section of boundary
with Senega! is indefinite
173
[Gaza Strip
In t r o d u c t i o n
Current issues: The lsrae!-PLO Declaration of
Principles on Interim Self-Government Arrangements
("the DOP"), signed in Washington on 13 September
1 993, provides for a transitional period not exceeding
five years of Palestinian interim self-government in the
Gaza Strip and the West Bank. Permanent status
negotiations began on 5 May 1996, but have not
resumed since the initial meeting. Under the DOP,
Israel agreed to transfer certain powers and
responsibilities to the Palestinian Authority, which
includes a Palestinian Legislative Council elected in
January 1996, as part of interim self-governing
arrangements in the West Bank and Gaza Strip. A
transfer of powers and responsibilities for the Gaza
Strip and Jericho took place pursuant to the
Israel-PLO 4 May 1 994 Cairo Agreement on the Gaza
Strip and the Jericho Area and in additional areas of
the West Bank pursuant to the Israel-PLO 28
September 1995 Interim Agreement and the
Israel-PL0 15 January 1997 Protocol Concerning
Redeployment in Hebron. The DOP provides that
Israel will retain responsibility during the transitional
period for external security and for internal security
and public order of settlements and Israelis.
Permanent status is to be determined through direct
negotiations.
Disputes— international: West Bank and Gaza
Strip are Israeli-occupied with current status subject to
the Israeli-Palestinian Interim Agreement-
permanent status to be determined through further
negotiation
Disputes— international: individual Sudeten
German claims for restitution of property confiscated in
connection with their expulsion after World War II
Illicit drugs: source of precursor chemicals for South
American cocaine processors; transshipment point for
and consumer of Southwest Asian heroin and hashish,
Latin American cocaine, and European-produced
synthetic drugs
Disputes— international: Caspian Sea boundaries
are not yet determined among Azerbaijan, Iran,
Kazakhstan, Russia, and Turkmenistan
Illicit drugs: significant illicit cultivation of cannabis
and limited cultivation of opium poppy and ephedra
(for the drug ephedrone); limited government
eradication program; cannabis consumed largely in
the CIS; used as transshipment point for illicit drugs to
Russia, North America, and Western Europe from
Southwest Asia
249
Disputes— international: none
282
Location: Eastern Asia, bordering the South China
Sea and China
Geographic coordinates: 22 10 N, 1 13 33 E
Map references: Southeast Asia
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area— comparative: about 0.1 times the size of
Washington, DC
Land boundaries:
total: 0.34 km
border countries: China 0.34 km
Coastline: 40 km
Maritime claims: not specified
Climate: subtropical; marine with cool winters, warm
summers
Terrain: generally flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Coloane Alto 174 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: Ozone Layer Protection (extended from
Portugal)
signed, but not ratified: N A
Geography— note: essentially urban; one causeway
and two bridges connect the two islands of Coloane
and Taipa to the peninsula on mainland
Disputes— international: dispute with Tanzania
over the boundary in Lake Nyasa (Lake Malawi)
290
Disputes— international: certain territory of
Moldova and Ukraine— including Bessarabia and
Northern Bukovina— are considered by Bucharest as
historically a part of Romania; this territory was
incorporated into the former Soviet Union following
the Molotov-Ribbentrop Pact in 1940
Illicit drugs: limited cultivation of opium poppy and
cannabis, mostly for CIS consumption; transshipment
point for illicit drugs to Western Europe and Russia','1e2219d7b963d9fffaa3522e6ab18c02c01910a7f45e049b6499c0c9a2f0379a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60f6160014caf4968b29433a31e860eeb8d281fcdfabd456df462d8bf452a784',1998,'SI','Slovenia','transnational-issues',291,'Disputes— international: Eastern Slavonia, which
was held by ethnic Serbs during the ethnic conflict,
was returned to Croatian control by the UN
Transitional Administration for Eastern Slavonia on 1 5
January 1998; Croatia and Italy made progress
toward resolving a bilateral issue dating from WWII
over property and ethnic minority rights; significant
progress has been made with Slovenia toward
resolving a maritime border dispute over direct access
to the sea in the Adriatic; Serbia and Montenegro is
disputing Croatia''s claim to the Prevlaka Peninsula in
southern Croatia because it controls the entrance to
Boka Kotorska in Montenegro; Prevlaka is currently
under observation by the UN military observer mission
in Prevlaka (UNMOP)
Illicit drugs: transit point along the Balkan route for
Southwest Asian heroin to Western Europe; a minor
transit point for maritime shipments of South
American cocaine bound for Western Europe
Location: Southeastern Europe, eastern Alps
bordering the Adriatic Sea, between Austria and','adeedf1f98f7fb32a19d98123d2d3250c37fdc7b2873831a1b1a4f3d8dc5f390','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecc1751d9b7f90bc8b03f88222309f287cfb06775dc31f370e1f05cdef2bdf0d',1998,'CU','Cuba','transnational-issues',299,'Disputes— international: US Naval Base at
Guantanamo Bay is leased to US and only mutual
agreement or US abandonment of the area can
terminate the lease
Illicit drugs: territory serves as lesser transshipment
zone for cocaine bound for the US','3c5dea9fa23d7ad3d8252c8b4659b5e9d0f85d1f90aee6ba995e75e66d3cf1b8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('261b856f6ce87a07a4fdac764a73cd52f6b3ee8ee3a4b91dd5e0431ce04ad7d6',1998,'CY','Cyprus','transnational-issues',307,'Disputes— international: 1974 hostilities divided
the island into two de facto autonomous areas, a
Greek Cypriot area controlled by the internationally
recognized Cypriot Government (59% of the island''s
land area) and a Turkish-Cypriot area (37% of the
island), that are separated by a UN buffer zone (4% of
the island); there are two UK sovereign base areas
within the Greek Cypriot portion of the island
Illicit drugs: transit point for heroin and hashish via
air routes and container traffic to Europe, especially
from Lebanon and Turkey; some cocaine transits as
well
126
Disputes— international: Liechtenstein claims
restitution for 1 ,600 sq km of territory in the Czech
Republic confiscated from its royal family in 1918; the
Czech Republic insists that restitution does not go
back before February 1948, when the communists
seized power; individual Sudeten German claims for
restitution of property confiscated in connection with
their expulsion after World War II; unresolved property
issues with Slovakia over redistribution of former
Czechoslovak federal property
Illicit drugs: transshipment point for Southwest
Asian heroin and hashish and Latin American cocaine
to Western Europe; domestic consumption—
especially of locally produced synthetic drugs— on the
rise','8521f5baebab94e54743b7cecb47b1defc1b36893298798b63b1551e1b50e759','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcbbb9fc001b832f322eb5f010e866a86488fe9d8a45a21dd1f9be327c52cce2',1998,'DK','Denmark','transnational-issues',315,'Disputes— international: Rockall continental shelf
dispute involving Iceland, Ireland, and the UK (Ireland
and the UK have signed a boundary agreement in the
Rockall area)
Disputes— international: none
Disputes— international: none
Rotuma
South Pacific Gee an
Vanua Levujb^ basa ''
/ Sav&atfi t''~i>’faveunl
LautoKa.A— v >Lei„ka
VitiLevu C.._J8Suva ’ .
Kadavu
. Ceva-i-Ra
O 100 200 km
O 100 200 mi
Disputes— international: none
189','24a7492bb4140ecc33bc0df6b36a1c81216f02f2688ad65c2182f73d31b6bcec','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42fb41329653e2f9df401a29fca84eff5593d2d0f9235d3d973c5a22be7e346f',1998,'DM','Dominica','transnational-issues',316,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, about one-half of
the way from Puerto Rico to Trinidad and Tobago
Geographic coordinates: 13 30 N, 61 20 W
Map references: Central America and the
Caribbean
Area:
total: 750 sq km
land: 750 sq km
water: 0 sq km
Area— comparative: slightly more than four times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 148 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by northeast trade
winds; heavy rainfall
Terrain: rugged mountains of volcanic origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Morne Diablatins 1,447 m
Natural resources: timber
Land use:
arable land: 9%
permanent crops: 13%
permanent pastures: 3%
forests and woodland: 67%
other: 8% (1993 est.)
Irrigated land: NA sq km
Natural hazards: flash floods are a constant threat;
destructive hurricanes can be expected during the late
summer months
Environment— current issues: NA
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of
133
Dominica (continued)
the Sea, Ozone Layer Protection, Whaling
signed, but not ratified: none of the selected
agreements
Disputes— international: none
Illicit drugs: transshipment pointfor South American
drugs destined for the US through Puerto Rico','50a456571838bf25e118a92e5a59e41b8ad411db4cea036b035a72ad48be749d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15de2b8fe024ea83a7a6a285fd75cfa332cd28341d0e0630fd860cab4d722149',1998,'PE','Peru','transnational-issues',331,'Disputes— international: three sections of the
boundary with Peru are in dispute
Illicit drugs: significant transit country for derivatives
of coca originating in Colombia, Bolivia, and Peru;
minor illicit producer of coca; importer of precursor
chemicals used in production of illicit narcotics;
important money-laundering hub
139','71738c360831bf87c64cfa57630ee8dca2e80f46a6d32aad420d323bac3dbb56','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c690df33d7e6152fd91f27aff1f1120d4986b4588c5c3071b9044660a0610c7',1998,'EG','Egypt','transnational-issues',332,'Siwah
Al MinyaJ
Al 1 ^Sharrft
^ Ghardaqah.'' ash i
AsyutX^, BQri ShaykhXI
Xsafajah
Al Kharijah,
Luxor
JftrTnangtef^','b317dd62227aae6afb5a4c03f259647c5a437c303751dfcc22e791f8dd64adfe','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dceb413603b35314a40ca9d3998163446f441def96b9547f35d941c5f1f2aca0',1998,'SD','Sudan','transnational-issues',340,'Disputes— international: administrative boundary
with Sudan does not coincide with international
boundary creating the "Hala''ib Triangle,11 a barren
area of 20,580 sq km
Illicit drugs: a transit point for Southwest Asian and
Southeast Asian heroin and opium moving to Europe
and the US; popular transit stop for Nigerian couriers;
large domestic consumption of hashish from Lebanon
and Syria
142','6abf7191d4f8fff84d3af3ffc1c43e1dce97c8b53649608c6b9fc0c6b20483f5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46f7aa00d156a9d11802428ec0509404d4e4fd8182986017d64837614d6dbb19',1998,'GN','Guinea','transnational-issues',352,'Disputes— international: maritime boundary
dispute with Gabon because of disputed sovereignty
over islands in Corisco Bay; maritime boundary
dispute with Nigeria because of disputed jurisdiction
over oil-rich areas in the Gulf of Guinea
Historical perspective: on 29 May 1991, ISAIAS
Afworki, secretary general of the People''s Front for
Democracy and Justice (PFDJ), which then served as
the country''s legislative body, announced the
formation of the Provisional Government in Eritrea
(PGE) in preparation for the 23-25 April 1993
referendum on independence for the Autonomous
Region of Eritrea; the referendum resulted in a
landslide vote for independence which was
proclaimed on 27 April 1993
Disputes— international: a dispute with Yemen
over sovereignty of the Hanish Islands in the southern
Red Sea has been submitted to arbitration under the
auspices of the ICJ; a decision on the Islands is
expected in mid-1998','9bed39400ce124c9a9661a98a5e40e72b4039500184620217e466ef05b1cf974','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad1e4842c881f1e00d0874debdcd91028024b51439d1beac7b59db867cc3fdd2',1998,'EE','Estonia','transnational-issues',363,'Disputes— International: most of the southern half
of the boundary with Somalia is a Provisional
Administrative Line; territorial dispute with Somalia
over the Ogaden
Illicit drugs: transit hub for heroin originating in
Southwest and Southeast Asia and destined for
Europe and North America as well as cocaine
destined for markets in southern Africa; cultivates qat
(chat) for local use and regional export
Europa Island ■ ■
(possession of France) |fi| j(|f|','3c1d2d23e5a65ddc8dd097d25ca0418cf61c66c7c1a5d8496babae0923935ca3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f09bbc216c89a3641b0693806ef84ce17b3370732948879a70d8930f3046c06',1998,'JE','Jersey','transnational-issues',379,'Disputes— international: none
Disputes— international: West Bank and Gaza
Strip are Israeli-occupied with current status subject to
the Israeli-Palestinian Interim Agreement-
permanent status to be determined through further
negotiation; Golan Heights is Israeli-occupied; Israeli
troops in southern Lebanon since June 1982
Illicit drugs: increasingly concerned about cocaine
and heroin abuse and trafficking
Telephone system: most highly developed system
in the Middle East although not the largest
domestic: good system of coaxial cable and
microwave radio relay
international: 3 submarine cables; satellite earth
stations— 3 Intelsat (2 Atlantic Ocean and 1 Indian
Ocean)
Radio broadcast stations: AM 9, FM 45,
shortwave 0
Radios: 2.25 million (1993 est.)
Television broadcast stations: 20
Televisions: 1.5 million (1993 est.)
(British crown dependency)
Disputes— international: none
Johnston Atoll
I (territory of the US)
Disputes— international: none
Disputes— international: in November 1994, Iraq
formally accepted the UN-demarcated border with
Kuwait which had been spelled out in Security Council
Resolutions 687 (1991), 773 (1993), and 883 (1993);
this formally ends earlier claims to Kuwait and to
Bubiyan and Warbah islands; ownership of Qaruh and
Umm a! Maradim islands disputed by Saudi Arabia
Land boundaries: 0 km
Coastline: 2,254 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; modified by southeast trade winds;
hot, humid
Terrain: coastal plains with interior mountains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Panie 1 ,628 m
Natural resources: nickel, chrome, iron, cobalt,
manganese, silver, gold, lead, copper
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 1 2%
forests and woodland: 39%
other: 49% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: typhoons most frequent from
November to March
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Disputes— international: significant progress has
been made with Croatia toward resolving a maritime
border dispute over direct access to the sea in the
Adriatic; Italy is negotiating with Slovenia over
property and minority rights issues dating from World
Warll
Illicit drugs: transit point for Southwest Asian heroin
bound for Western Europe and for precursor
chemicals
Disputes— international: Swaziland has asked
South Africa to open negotiations on reincorporating
some nearby South African territories that are
populated by ethnic Swazis or that were long ago part
of the Swazi Kingdom
''Sweden H 1MI
i n mu
Location: Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, Kattegat, and Skagerrak,
between Finland and Norway
Geographic coordinates: 62 00 N, 15 00 E
Map references: Europe
Area:
total: 449,964 sq km
land: 41 0,928 sq km
water: 39,036 sq km
Area— comparative: slightly larger than California
Land boundaries:
total: 2,205 km
border countries: Finland 586 km, Norway 1,619 km
Coastline: 3,218 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: agreed boundaries or
midlines
territorial sea: 12 nm (adjustments made to return a
portion of straits to high seas)
Climate: temperate in south with cold, cloudy winters
and cool, partly cloudy summers; subarctic in north
Terrain: mostly flat or gently rolling lowlands;
mountains in west
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Kebnekaise 2,1 1 1 m
Natural resources: zinc, iron ore, lead, copper,
silver, timber, uranium, hydropower potential
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 1 %
forests and woodland: 68%
other: 24% (1 993 est.)
Irrigated land: 1,150 sq km (1993 est.)
Natural hazards: ice floes in the surrounding waters,
especially in the Gulf of Bothnia, can interfere with
maritime traffic
Environment— current issues: acid rain damaging
soils and lakes; pollution of the North Sea and the
Baltic Sea
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location along Danish
Straits linking Baltic and North Seas
I: People
Population: 8,886,738 (July 1998 est.)
Age structure:
0-14 years: 19% (male 852,520; female 808,600)
15-64 years : 64% (male 2,885,783; female
2,792,964)
65 years and over: 1 7% (male 653,631 ; female
893,240) (July 1998 est.)
Population growth rate: 0.26% (1998 est.)
Birth rate: 1 1 .7 births/1 ,000 population (1 998 est.)
Death rate: 1 0.78 deaths/1 ,000 population (1 998
est.)
Net migration rate: 1 .69 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years : 1 .03 male(s)/female
65 years and over: 0.73 male(s)/female (1 998 est.)
Infant mortality rate: 3.93 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 79.1 9 years
male: 76.52 years
female: 82 years (1 998 est.)
447
Sweden (continued)
Total fertility rate: 1 .76 children born/woman (1 998
est.)
Nationality:
noun: Swede(s)
adjective: Swedish
Ethnic groups: white, Lapp (Sami), foreign-born or
first-generation immigrants 12% (Finns, Yugoslavs,
Danes, Norwegians, Greeks, Turks)
Religions: Evangelical Lutheran 94%, Roman
Catholic 1.5%, Pentecostal 1%, other 3.5% (1987)
Languages: Swedish
note: small Lapp- and Finnish-speaking minorities
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1 979 est.)
male: NA%
female: NA%
Disputes— international: none
Illicit drugs: minor transshipment point for and
consumer of narcotics shipped via the CIS and Baltic
states; increasing consumer of European
amphetamines','3d3ae738bb3f58dee792bcb9fd2bc2c4f637f60cd705f4f7f64bf47edceeaedb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d366e1eba4aa98656c2f621f50b6c95d1f2f4125aa91e097b452c4c0bc734427',1998,'FI','Finland','transnational-issues',380,'Location: Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, and Gulf of Finland, between
Sweden and Russia
Geographic coordinates: 64 00 N, 26 00 E
Map references: Europe
Area:
total: 337,030 sq km
land: 305,470 sq km
water: 31 ,560 sq km
Area— comparative: slightly smaller than Montana
Land boundaries:
total: 2,628 km
border countries: Norway 729 km, Sweden 586 km,
Russia 1,313 km
Coastline: 1 ,1 26 km (excludes islands and coastal
indentations)
Maritime claims:
contiguous zone: 6 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 12 nm
territorial sea: 12 nm (in the Gulf of Finland— 3 nm)
Climate: cold temperate; potentially subarctic, but
comparatively mild because of moderating influence
of the North Atlantic Current, Baltic Sea, and more
than 60,000 lakes
Terrain: mostly low, flat to rolling plains interspersed
with lakes and low hills
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Haltiatunturi 1,328 m
Natural resources: timber, copper, zinc, iron ore,
silver
Land use:
arable land: 8%
permanent crops: NA%
permanent pastures: 0%
forests and woodland: 76%
other: 16% (1993 est.)
Irrigated land: 640 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: air pollution from
manufacturing and power plants contributing to acid
rain; water pollution from industrial wastes,
agricultural chemicals; habitat loss threatens wildlife
populations
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Sulphur 94
Geography— note: long boundary with Russia;
Helsinki is northernmost national capital on European
continent; population concentrated on small
southwestern coastal plain
Disputes— international : based on the 1 920 T reaty
of Riga, Latvia had claimed the Abrene/Pytalovo
section of border ceded by the Latvian Soviet Socialist
Republic to Russia in 1 944; draft treaty delimiting the
boundary with Russia has not been signed; ongoing
talks over boundary dispute with Lithuania (primary
concern is oil exploration rights)
Illicit drugs: transshipment point for opiates and
cannabis from Southwest Asia and cocaine from Latin
America to Western Europe and Scandinavia;
produces illicit amphetamines for export
Current issues: Lebanon has made progress
toward rebuilding its political institutions and regaining
its national sovereignty since the end of the
devastating 16-year civil war, which began in 1975.
Under the Ta''if Accord— the blueprint for national
reconciliation— the Lebanese have established a
more equitable political system, particularly by giving
Muslims a greater say in the political process while
institutionalizing sectarian divisions in the
government. Since the end of the civil war, the
Lebanese have formed five cabinets and conducted
two legislative elections. Most of the militias have
been weakened or disbanded. The Lebanese Armed
Forces (LAF) has seized vast quantities of weapons
used by the militias during the war and extended
central government authority over about one-half of
the country. Hizballah, the radical Shi''a party, retains
most of its weapons. Foreign forces still occupy areas
of Lebanon. Israel maintains troops in southern
Lebanon and continues to support a proxy militia, the
Army of South Lebanon (ASL), along a narrow stretch
of territory contiguous to its border. The ASL''s enclave
encompasses this self-declared security zone and
about 20 kilometers north to the strategic town of
Jazzin. Syria maintains about 25,000 troops in
Lebanon. These troops are based mainly in Beirut,
North Lebanon, and the Bekaa Valley. Syria''s
deployment was legitimized by the Arab League
during Lebanon''s civil war and in the Ta''if accord.
Citing the continued weakness of the LAF, Beirut''s
requests, and failure of the Lebanese Government to
implement all of the constitutional reforms in the Ta''if
accord, Damascus has so far refused to withdraw its
troops from Lebanon.
Disputes— international: Israeli troops in southern
Lebanon since June 1982; Syrian troops in northern,
central, and eastern Lebanon since October 1976
Illicit drugs: small illicit producer of hashish and
heroin; hashish production is shipped to Western
Europe, the Middle East, and North and South
America; some cocaine processing and trafficking; a
Lebanese/Syrian eradication campaign started in the
early 1990s has practically eliminated the opium and
cannabis crops
270','af51da0e02c63fb08dbfb24f5bda7e66783f0cb4f3b718d669ddab50d7007063','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('348fdba5d0051f02225afc1bfe5b346c94f8e7e7104065a077d27a72b4ffd7fe',1998,'WF','Wallis and Futuna','transnational-issues',391,'Disputes— international: Madagascar claims
Bassas da India, Europa Island, Glorioso Islands,
Juan de Nova Island, and Tromelin Island; Comoros
claims Mayotte; Mauritius claims Tromelin Island;
Suriname claims part of French Guiana; territorial
claim in Antarctica (Adelie Land); Matthew and Hunter
Islands east of New Caledonia claimed by France and
(overseas territory of France)
■+
O 25 50 km
O 25 50 mi
lies
Wallis
MATA-UTU*
fie Uvea
■7 '' Ocr.''-r
lies de Home
fie Futuna
.Sigave (Leava)
he Alofi','d13b579031c55c1cb220e87c0959adcf99c5ac7ab497ed2259af4b33058c6c0a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdab5ad8b49f4da7caf1591a77a2f6cb0a1da4cdad6c40ec16903e948f59fe10',1998,'VU','Vanuatu','transnational-issues',392,'Illicit drugs: transshipment point for and consumer
of South American cocaine and Southwest Asian
heroin
Disputes— international: claims Matthew and
Hunter Islands east of New Caledonia
Venezuela','9c921e1296175e83e9100f8e7ef9a3dd23520a29f4001464a1b412d2f47ff3b3','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('341c5afdc0109e53899d628cef9647efad035c7f3c92140e3854814574a1e5de',1998,'PF','French Polynesia','transnational-issues',396,'!; (overseas territory
j of France)
KIRIBATI .
lies
•• Marquises
South Pacific.
Ocean
Makatea .
V
Uturoa* .
Society
Islands
^ PAPEETE
\\ *
Tahiti
o, Archipel des
Tuamotu
■ jles .Mataura
Tubuai''
o c ^ o
Mururua ^ 4 0
Rikitea^
!i ,Rapa
0 250 500 km
0 250 500 mi','79a217382f45cf90e8d54f50a54f7518e676f6e2dd7042e65c6fbac87fc3abf0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cfd1b339675c5b988e277dc7ab27267b6ebb0b80aa9fac92f66cbb1016cbf6d',1998,'GA','Gabon','transnational-issues',402,'other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: lie Amsterdam and He Saint-Paul
are extinct volcanoes
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: remote location in the southern
Indian Ocean
Disputes— international: maritime boundary
dispute with Equatorial Guinea because of disputed
sovereignty over islands in Corisco Bay
The Gambia','af442ce41fe9e753015c668bc2878c6d085bbb2ce928b96acc8ebe64b87fb92b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8286bb149f4fdd485226b136261d6d580c6049d37e727d08d2106ab26642566',1998,'GE','Georgia','transnational-issues',418,'Disputes— international: none
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for domestic consumption; used
as transshipment point for opiates to Western Europe','41ae20188bcb1e039675e1dfebf950d08073ffad2faffa6a5e42f735d1d66394','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a26f7fc3c6f85be12368609074783fb56b3835cd9475484fea1e4717641c7242',1998,'NL','Netherlands','transnational-issues',429,'Disputes— international: none
Illicit drugs: illicit producer of cannabis for the
international drug trade; transit hub for Southwest and
Southeast Asian heroin and South American cocaine
destined for Europe and the US
Disputes— international: none
Illicit drugs: important gateway for cocaine, heroin,
and hashish entering Europe; European producer of
illicit amphetamines and other synthetic drugs
Antilles
(part of the Kingdom of
Disputes— international: none
illicit drugs: money-laundering center;
transshipment point for South American drugs bound
for the US and Europe','50ba55b7b656287882d2a1750038456c0dab9246016e591d962fcfe6d6e144a0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cefeddaa98efd59740539817cf27fe3c609d2cc72a530e3d2b3a1a458e649047',1998,'GI','Gibraltar','transnational-issues',430,'l (dependent territory
of the UK)
Location: Southwestern Europe, bordering the Strait
of Gibraltar, which links the Mediterranean Sea and
the North Atlantic Ocean, on the southern coast of
Disputes— international: claims and administers
Western Sahara, but sovereignty is unresolved and
the UN is attempting to hold a referendum on the
issue; the UN-administered cease-fire has been in
effect since September 1991 ; Spain controls five
places of sovereignty (plazas de soberania) on and off
the coast of Morocco— the coastal enclaves of Ceuta
and Melilla which Morocco contests, as well as the
islands of Penon de Alhucemas, Penon de Velez de la
Gomera, and Islas Chafarinas
Illicit drugs: illicit producer of hashish; trafficking on
the increase for both domestic and international drug
markets; shipments of hashish mostly directed to
Western Europe; transit point for cocaine from South
America destined for Western Europe
(U.K.r^Ceuta Melilla
,Nrr!:- / >SEJ_^A(SP.)
At.-:rt>c
Ocnr.’i','3a09f5373ec95b07965a384c243ab71ea356e7d7a9cd74a4434b4d337e353549','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76e1235bfdcf4e77839f67edc9e6651d8d94906d333bc5a44a25c57f1208e3ea',1998,'ES','Spain','transnational-issues',431,'Geographic coordinates: 36 1 1 N, 5 22 W
Map references: Europe
Area:
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area— comparative: about 1 1 times the size of The
Mall in Washington, DC
Land boundaries:
total: 1 .2 km
border countries: Spain 1 .2 km
Coastline: 12 km
Maritime claims:
territorial sea: 3 nm
Climate: Mediterranean with mild winters and warm
summers
Terrain: a narrow coastal lowland borders the Rock
of Gibraltar
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Rock of Gibraltar 426 m
Natural resources: NEGL
Land use:
arable land: NA%
permanent crops: N A%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment— current issues: limited natural
freshwater resources, so large concrete or natural
rock water catchments collect rain water
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: strategic location on Strait of
Gibraltar that links the North Atlantic Ocean and
Mediterranean Sea
l P e o pie
Population: 29,045 (July 1998 est.)
Age structure:
0-14 years: 20% (male 3,131; female 2,731)
15-64 years: 66% (male 10,835; female 8,262)
65 years and over: 1 4% (male 1 ,684; female 2,402)
(July 1998 est.)
Population growth rate: 0.43% (1998 est.)
Birth rate: 13.01 births/1,000 population (1998 est.)
Death rate: 8.78 deaths/1 ,000 population (1 998 est.)
Net migration rate: 0.1 migrant(s)/1, 000 population
(1998 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.15 male(s)/female
15-64 years: 1 .31 male(s)/female
65 years and over: 0.7 male(s)/female (1 998 est.)
Infant mortality rate: 6.61 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 78.1 9 years
male: 74.9 years
female: 81 .64 years (1 998 est.)
Total fertility rate: 2.1 9 children born/woman (1 998
est.)
Nationality:
noun: Gibraltarian(s)
adjective: Gibraltar
Ethnic groups: Italian, English, Maltese,
Portuguese, Spanish
Religions: Roman Catholic 74%, Protestant 11%
(Church of England 8%, other 3%), Muslim 8%,
Jewish 2%, none or other 5% (1981)
Languages: English (used in schools and for official
purposes), Spanish, Italian, Portuguese, Russian
Literacy:
definition: NA
total population: above 95%
male : NA%
female: NA%
I Government
Country name:
conventional long form: none
conventional short form: Gibraltar
Data code: Gl
Dependency status: dependent territory of the UK
Government type: NA
National capital: Gibraltar
Administrative divisions: none (dependent
territory of the UK)
Independence: none (dependent territory of the UK)
National holiday: Commonwealth Day (second
Monday of March)
Constitution: 30 May 1969
Legal system: English law
183
Gibraltar (continued)
Suffrage: 18 years of age; universal, plus other UK
subjects resident six months or more
Executive branch:
chief of state: Queen ELIZABETH II of the UK (since
6 February 1952), represented by Governor Admiral
Sir Richard LUCE (NA February 1997)
head of government: Chief Minister Peter CARUANA
(since 17 May 1996)
cabinet: Council of Ministers appointed from among
the elected members of the House of Assembly by the
governor in consultation with the chief minister
note: there is also a Gibraltar Council that advises the
governor
elections: none; the queen is a hereditary monarch;
governor appointed by the queen; chief minister
appointed by the governor
Legislative branch: unicameral House of Assembly
(18 seats, 15 elected; members are elected by
popular vote to serve four-year terms)
elections : last held 16 May 1996 (next to be held NA
May 2000)
election results: percent of vote by party— SD 53%,
SL 42%, NP 3%; seats by party— SD 8, SL 7
Judicial branch: Supreme Court; Court of Appeal
Political parties and leaders: Gibraltar Socialist
Labor Party or SL [Joe BOSSANO]; Gibraltar Labor
Party/Association for the Advancement of Civil Rights
or GCL/AACR [Adolfo CANEPA]; Gibraltar Social
Democrats or SD [Peter CARUANA]; Gibraltar
National Party or NP [Joe GARCIA]
Political pressure groups and leaders:
Housewives Association; Chamber of Commerce;
Gibraltar Representatives Organization
International organization participation: Interpol
(subbureau)
Diplomatic representation in the US: none
(dependent territory of the UK)
Diplomatic representation from the US: none
(dependent territory of the UK)
Flag description: two horizontal bands of white (top,
double width) and red with a three-towered red castle
in the center of the white band; hanging from the
castle gate is a gold key centered in the red band
Disputes— international: source of friction between
Spain and the UK
184
Glorioso Islands
(possession of France)
100 200 km','f6d87bf2912d0bee2cf7ce1e10bb4bc44f63a29360efeb3ddbf97b9619d82423','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3952db61ed8640e1aef30e9cfce20cd422dea348a62614f8919842e500664792',1998,'GD','Grenada','transnational-issues',445,'Disputes— international: none
Illicit drugs: small-scale cannabis cultivation; lesser
transshipment point for marijuana and cocaine to US
I Guadeloupe
| (overseas department
; of France)','9b62535db55c105ea89a875d7677193e77b65eed3ce98c9be37722f93de90a8b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4256e3d0193fd1530a929971ff232df44be818691f06da9d981a42b0a391f23e',1998,'GU','Guam','transnational-issues',446,'(territory of the US)
Disputes— international: none
Location: Middle America, bordering the Caribbean
Sea, between Honduras and Belize and bordering the
North Pacific Ocean, between El Salvador and Mexico
Geographic coordinates: 1 5 30 N, 90 1 5 W
Map references: Central America and the
Caribbean
Area:
total: 108,890 sq km
land: 108,430 sq km
water: 460 sq km
Area— comparative: slightly smaller than
Tennessee
Land boundaries:
total: 1 ,687 km
border countries: Belize 266 km, El Salvador 203 km,
Honduras 256 km, Mexico 962 km
Coastline: 400 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid in lowlands; cooler in
highlands
Terrain: mostly mountains with narrow coastal plains
and rolling limestone plateau (Peten)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Volcan Tajumulco 4,21 1 m
Natural resources: petroleum, nickel, rare woods,
fish, chicle
Land use:
arable land: 12%
permanent crops: 5%
permanent pastures: 24%
forests and woodland: 54%
other: 5% (1993 est.)
Irrigated land: 1,250 sq km (1993 est.)
Natural hazards: numerous volcanoes in
mountains, with occasional violent earthquakes;
Caribbean coast subject to hurricanes and other
tropical storms
Environment— current issues: deforestation; soil
erosion; water pollution
Environment— international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol
Geography— note: no natural harbors on west coast','54dc23d76461c27abd485bfddbdfe8b72a3e34ca5ab2473c3959134e8b2417f9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4180942bcd2b15bb1c20cfb7bd72db492b6fa168ac86feb401bd1fb90789a6d',1998,'GG','Guernsey','transnational-issues',455,'Disputes— international: border with Belize in
dispute; talks to resolve the dispute are ongoing
Illicit drugs: transit country for cocaine shipments;
illicit producer of opium poppy and cannabis for the
international drug trade; active eradication program of
cannabis and opium poppy
Location: Western Europe, islands in the English
Channel, northwest of France
Geographic coordinates: 49 28 N, 2 35 W
Map references: Europe
Area:
total: 194 sq km
land: 194 sq km
water: 0 sq km
note: includes Alderney, Guernsey, Herm, Sark, and
some other smaller islands
Area— comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 50 km
Maritime claims:
exclusive fishing zone: 1 2 nm
territorial sea: 3 nm
Climate: temperate with mild winters and cool
summers; about 50% of days are overcast
Terrain: mostly level with low hills in southwest
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location on Sark 114 m
Natural resources: cropland
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: N A%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: large, deepwater harbor at Saint
Peter Port
197
Guernsey (continued)
Disputes— international: none
200','3bca225d9efc430dfe1e9ac845a5181e3c7f3714e1980d00d0a1579d81cdb4bb','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5773053d2aba2a04c946f5f50e80318a60f411b9b71eec6547aea0ace3d81c23',1998,'GY','Guyana','transnational-issues',474,'Disputes— international: all of the area west of the
Essequibo River claimed by Venezuela; Suriname
claims area between New (Upper Courantyne) and
Courantyne/Kutari Rivers (all headwaters of the
Courantyne)
Illicit drugs: transshipment point for narcotics from
South America— primarily Venezuela— to Europe and
the US; producer of cannabis
204
D
Disputes— international: claims US-administered
Navassa Island
Illicit drugs: transshipment point for cocaine and
marijuana en route to the US and Europe
206
Heard Island
and McDonald
Islands
bnrc: * * ■
Disputes— international: claims area in French
Guiana between Litani Rivier and Riviere Marouini
(both headwaters of the Lawa Rivier); claims area in
Guyana between New (Upper Courantyne) and
Courantyne/Koetari Rivers (all headwaters of the
Courantyne)
Illicit drugs: transshipment pointfor South American
drugs destined mostly for Europe
443
Svalbard
(territory of Norway)
Disputes— international: Svalbard is the focus of a
maritime boundary dispute in the Barents Sea
between Norway and Russia
0 20 40 mi','b36c657b74c59950e93b02eaf3d73ecc4a323939b3030b2f9226b9fcc1fa6a6d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c924e535c932c36d1ad8a34d02805bcdf51d51251673bc46db55140c3734f80',1998,'AT','Austria','transnational-issues',483,'Disputes— international: Gabcikovo Dam dispute
with Slovakia (to be resolved March 1998)
Illicit drugs: major transshipment point for
Southwest Asian heroin and cannabis and transit
point for South American cocaine destined for
Western Europe; limited producer of precursor
chemicals, particularly for amphetamines and
methamphetamines
telephone^] (1)213450
FAX— [43] (1) 21345-5885
established— 1 6 February 1 946
aim— Economic and Social Council organization
dealing with illicit drugs programs of UN
members— (53) selected on a rotating basis from all regions with emphasis on producing and processing countries
540
Commission on Population and
Development
address— Division for Policy and Coordination
and ECOSOC Affairs, Department for Policy
Coordination and Sustainable Development,
United Nations, Room 2963, New York, NY
10017, US
telephone— [\\] (212) 963 1234
FAX— 1] (212) 963 5935
established— 3 October 1946
aim— to deal with population matters of
importance to the UN, as part of Economic and
Social Council
members— (47) selected on a rotating basis from all regions
Commission on Science and Technology for
Development
address— United Nations, New York, NY 10017,
US
telephone— m (212) 9631234
F>4X— [1] (212) 758 2718
established— 30 April 1992
aim— to promote international cooperation, as
part of the Economic and Social Council, in the
field of science and technology
members— (53) selected on a rotating basis from all regions
Commission on the Status of Women
adc/ress — Division for Policy and Coordination
and ECOSOC Affairs, Department for Policy
Coordination and Sustainable Development,
United Nations, Room S-2963, New York, NY
10017, US
telephone— (212) 963 1234
FAX— [1] (212) 963 5935
established —21 June 1946
aim— to deal, as part of the Economic and Social
Council, with women''s rights goals of UN
members— (45) selected on a rotating basis from all regions
Commission on Sustainable Development
address — Division for Sustainable
Development, UN DPCSD, Room DC2-2274,
New York, NY 10017, US
telephone-1 1] (212) 963 0902
FAX— [1] (212) 963 4260
established— 12 February 1993
aim— to monitor, as part of the Economic and
Social Council, implementation of agreements
reached at the UN Conference on Environment
and Development
members— (53) selected on a rotating basis from all regions
541
Appendix C: International Organizations and Groups (continued)
Commonwealth (C)
note— also known as Commonwealth of Nations
address— do Commonwealth Secretariat,
Marlborough House, Pall Mall, London SW1Y
5HX, UK
telephone— {44] (171)839 3411
FAX— [44] (171) 930 0827
established— 31 December 1931
aim— to foster multinational cooperation and
assistance, as a voluntary association that
evolved from the British Empire
members— (52) Antigua and Barbuda, Australia, The Bahamas, Bangladesh, Barbados, Belize, Botswana, Brunei,
Cameroon, Canada, Cyprus, Dominica, Fiji, The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya,
Kiribati, Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius, Mozambique, Namibia, NZ, Nigeria (suspended),
Pakistan, Papua New Guinea, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Seychelles, Sierra Leone, Singapore, Solomon Islands, South Africa, Sri Lanka, Swaziland, Tanzania, Tonga,
Trinidad and Tobago, Uganda, UK, Vanuatu, Zambia, Zimbabwe
special members— (2) Nauru (soon to become full member), Tuvalu
Commonwealth of Independent States (CIS)
address— Kirov Street 17, 220000 Minsk,
telephone— [43] (1) 514 36-190
FAX— {43} (1) 514 36-96
established— 1 January 1995
aim— to foster the implementation of human
rights, fundamental freedoms, democracy, and
the rule of law; to act as an instrument of early
warning, conflict prevention and crisis
management; and to serve as a framework for
conventional arms control and confidence
building measures
members— (23) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Greece, Iceland,
Ireland, Italy, Japan, Luxembourg, Netherlands, Norway, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
members— (34) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Czech Republic, Denmark,
Finland, France, Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea, Luxembourg, Netherlands, NZ,
Norway, Poland, Portugal, Romania, Russia, Slovakia, South Africa, Spain, Sweden, Switzerland, Ukraine, UK, US
observer— (1) European Commission (a policy-planning body for the EU)
see Agency for the Prohibition of Nuclear Weapons in Latin America and the Caribbean (OPANAL)
members— (29) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany,
Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, NZ, Norway,
Poland, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
special members— { 1) EU
members — (55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany,
Greece, Holy See, Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova, Monaco, Netherlands, Norway,
Poland, Portugal, Romania, Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan,
Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan, Yugoslavia (suspended)
partners for cooperation-{ 7) Algeria, Egypt, Israel, Japan, South Korea, Morocco, Tunisia
564
Organization of African Unity (OAU)
address— P. 0. Box 3243, Addis Ababa,','6dbbcdd12958152d154723ea5d12d49a43e885260db68d41aad8ceeceeaa7e49','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3fa31e6a33eebefe1ac915c6849c94edced9fdff38aec76ed989c5796a5e4c5',1998,'IS','Iceland','transnational-issues',491,'Disputes— international: Rockall continental shelf
dispute involving Denmark, Ireland, and the UK
(Ireland and the UK have signed a boundary
agreement in the Rockall area)','5f875cabbb7063b5e6bf8ef62ceb9067505e29b0600529848d80d6fec44bc393','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a85b5c432efcb03079826185110c44d5e83aa0ac59d9a226b6341fa623dfa55',1998,'IN','India','transnational-issues',492,'mrits<
......
>SrinM\\rhii
'' Gangt
andla .Bhopal _ .
ST" /Ahmadabad
) ‘Nagpur
Arslan ^Mumbai
Gti'' ((Bombay)
VPanaji
Marmagaox
La
P
Vishakhap^tnam
HyderalD§d
bhennai
.(Madras)
vPondicherry
Madurai
^ i: \\^JTu\\{c6rp
Bangalore.
GajicuV.
CochinV
Andaman tf
Islands $
JPort
Blair
SR!
J LANKA
Nicobar
Islands
Disputes— international: boundary with China in
dispute; status of Kashmir with Pakistan;
water-sharing problems with Pakistan over the Indus
River (Wular Barrage); a portion of the boundary with
Bangladesh is indefinite
220
Illicit drugs: world''s largest licit producer of opium
for the pharmaceutical trade, but an undetermined
quantity of opium is diverted to illicit international drug
markets; major transit country for illicit narcotics
produced in neighboring countries; illicit producer of
hashish and methaqualone; cultivated 2,050 hectares
of opium in 1997, a 34% decrease from 1996, with a
potential production of 30 metric tons, a 36%
decrease from 1996
Indian Ocean
Disputes— international: some maritime disputes
(see littoral states)
221','67fb0e20a953868a3907a52185ac8b5199a146841b760840e90d4ded4d14d5f9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5ff789e1946955ddd8083e9263cc09617f57e41fa946ae3d4b5e8a4803d0e79',1998,'IE','Ireland','transnational-issues',507,'Disputes— international: Northern Ireland question
with the UK (historic peace agreement approved 10
April 1998); Rockall continental shelf dispute involving
Denmark, Iceland, and the UK (Ireland and the UK
have signed a boundary agreement in the Rockall
area)
Illicit drugs: transshipment point for and consumer
of hashish from North Africa to the UK and
Netherlands and of European-produced synthetic
drugs; transshipment point for heroin and cocaine
230','a5c44460733b852dca6ff8d40308d5af8e2c09899f2d058b05653b40c18ed5f6','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75c1512b7a7116d314bf3e0ea5494b4df8f7301a5dea1b42f16aab7b4aa803c4',1998,'TN','Tunisia','transnational-issues',516,'Disputes— international: Italy is negotiating with
Slovenia over property and minority rights issues
dating from World War II; Croatia and Italy made
progress toward resolving a bilateral issue dating from
WWII over property and ethnic minority rights
Illicit drugs: important gateway for and consumer of
Latin American cocaine and Southwest Asian heroin
entering the European market
Disputes— international: maritime boundary
dispute with Libya; Malta and Tunisia are discussing
the commercial exploitation of the continental shelf
between their countries, particularly for oil exploration
Turkey
Disputes— international: complex maritime, air and
territorial disputes with Greece in Aegean Sea;
Cyprus question with Greece; Hatay question with
Syria; dispute with downstream riparian states (Syria
and Iraq) over water development plans for the Tigris
and Euphrates Rivers; traditional demands on former
Armenian lands in Turkey have subsided
Illicit drugs: major transit route for Southwest Asian
heroin and hashish to Western Europe and the US via
air, land, and sea routes; major Turkish, Iranian, and
other international trafficking organizations operate
out of Istanbul; laboratories to convert imported
morphine base into heroin are in remote regions of
Turkey as well as near Istanbul; government
maintains strict controls over areas of legal opium
poppy cultivation and output of poppy straw
concentrate
474
i Geography
Location: Central Asia, bordering the Caspian Sea,
between Iran and Kazakhstan
Geographic coordinates: 40 00 N, 60 00 E
Map references: Commonwealth of Independent
States
Area:
total: 488,100 sq km
land: 488,1 00 sq km
water: 0 sq km
Area— comparative: slightly larger than California
Land boundaries:
tote/: 3,736 km
border countries: Afghanistan 744 km, Iran 992 km,
Kazakhstan 379 km, Uzbekistan 1,621 km
Coastline: 0 km
note: Turkmenistan borders the Caspian Sea
(1,768 km)
Maritime claims: none (landlocked)
Climate: subtropical desert
Terrain: flat-to-rolling sandy desert with dunes rising
to mountains in the south; low mountains along border
with Iran; borders Caspian Sea in west
Elevation extremes:
lowest point: Sarygamysh Koli -1 1 0 m
highest point : Ayrybaba 3,1 39 m
Natural resources: petroleum, natural gas, coal,
sulfur, salt
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 63%
forests and woodland: 8%
other: 26% (1993 est.)
Irrigated land: 1 3,000 sq km (1 993 est.)
Natural hazards: NA
Environment— current issues: contamination of
into irrigation contributes to that river''s inability to
replenish the Aral Sea; desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked
Disputes— international: Caspian Sea boundaries
are not yet determined among Azerbaijan, Iran,
Kazakhstan, Russia, and Turkmenistan
Illicit drugs: limited illicit cultivator of opium poppy,
mostly for domestic consumption; limited government
eradication program; increasingly used as
transshipment point for illicit drugs from Southwest
Asia to Russia and Western Europe; also a
transshipment point for acetic anhydride destined for
557
Appendix C: International Organizations and Groups (continued)
International Investment Bank (IIB)
International Labor Organization (ILO)
address— International Labor Office, 4 route des
Morillons, CH-1211 Geneva 22, Switzerland
telephone— {41] (22) 799 61 1 1
FAX-{ 41] (22) 798 86 85
established— II April 1919 (affiliated with the
UN 14 December 1946)
aim— to deal with world labor issues; a UN
specialized agency
International Maritime Organization (IMO)
note— name changed from Intergovernmental
Maritime Consultative Organization (IMCO) on
22 May 1982
address— 4 Albert Embankment, London SE1
7SR, UK
telephone— {44] (171) 735 7611
FAX— [44] (171) 587 3210
established— 17 March 1958
aim— to deal with international maritime affairs;
a UN specialized agency
International Maritime Satellite Organization
(Inmarsat)
International Mobile Satellite Organization
(Inmarsat)
note— formerly International Maritime Satellite
Organization
address— 99 City Road, London EC1 Y 1AX, UK
telephone— {44] (171) 728 1212
FAX— [44] (171) 728 1602
established— 3 September 1976
effective— 26 July 1979
aim— to provide worldwide communications for
commercial, distress, and safety applications, at
sea, in the air, and on land
established on 7 July 1970; to promote economic development; members were Bulgaria, Cuba, Czechoslovakia,
East Germany, Hungary, Mongolia, Poland, Romania, USSR, Vietnam; now it is a Russian bank with a new charter
members— (174) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen,
Yugoslavia (suspended), Zambia, Zimbabwe
members— ( 155) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Brazil, Brunei,
Bulgaria, Burma, Cambodia, Cameroon, Canada, Cape Verde, Chile, China, Colombia, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Latvia, Lebanon, Liberia, Libya, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Malta,
Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Ukraine, UAE, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia (suspended)
associate members— (2) Hong Kong, Macau _ _
see International Mobile Satellite Organization (Inmarsat)
members— (79) Algeria, Argentina, Australia, The Bahamas, Bahrain, Bangladesh, Belarus, Belgium, Brazil, Brunei,
Bulgaria, Cameroon, Canada, Chile, China, Colombia, Costa Rica, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Egypt, Finland, France, Gabon, Georgia, Germany, Ghana, Greece, Iceland, India, Indonesia, Iran, Iraq,
Israel, Italy, Japan, South Korea, Kuwait, Lebanon, Liberia, Malaysia, Malta, Mauritius, Mexico, Monaco,
Mozambique, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Saudi Arabia, Senegal, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Sweden,
Switzerland, Thailand, Tunisia, Turkey, Ukraine, UAE, UK, US, Yugoslavia
558
International Monetary Fund (IMF)
address— 700 19th Street NW, Washington, DC
20431, US
telephone— [\\] (202) 623 7000
FAX-m (202) 623 4661, 623 7491, 623 4662
established— 22 July 1944
effective— 27 December 1945
aim— to promote world monetary stability and
economic development; a UN specialized
agency
International Olympic Committee (IOC)
note— there are 194 National Olympic
Committees of which 1 85 are recognized by the
International Olympic Committee
address— Chateau de Vidy, CH-1007
Lausanne, Switzerland
telephone— {41] (21) 621 61 11
FAX''— [41] (21) 621 6216
established— 23 June 1894
aim— to promote the Olympic ideals and
administer the Olympic games; 1996 Summer
Olympics in Atlanta, United States (20 July-4
August); 1998 Winter Olympics in Nagano,
Japan (date NA); 2000 Summer Olympics in
Sydney, Australia (date NA); 2002 Winter
Olympics in Salt Lake City, United States (date
NA)
International Organization for Migration
(IOM)
note— established as Provisional
Intergovernmental Committee for the Movement
of Migrants from Europe; renamed
Intergovernmental Committee for European
Migration (ICEM) on 15 November 1952;
renamed Intergovernmental Committee for
Migration (ICM) in November 1980; current
name adopted 14 November 1989
address— 17 route des Morillons, CP 71,
CH-1211 Geneva 19, Switzerland
telephone— {4)] (22) 717 91 11
FAX— [41] (22) 798 61 50
established— 6 December 1951
aim— to facilitate orderly international emigration
and immigration
members— (182) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Palua, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe _ _ _
National Olympic Committees— (196 and the Palestine Liberation Organization) Afghanistan, Albania, Algeria,
American Samoa, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Cayman Islands, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Guinea-Bissau, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Taiwan, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Virgin Islands, Yemen, Yugoslavia (Serbia and Montenegro),
Zambia, Zimbabwe, Palestine Liberation Organization
members— (59) Albania, Angola, Argentina, Armenia, Australia, Austria, Bangladesh, Belgium, Bolivia, Bulgaria,
Canada, Chile, Colombia, Costa Rica, Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador,
Egypt, El Salvador, Finland, France, Germany, Greece, Guatemala, Haiti, Honduras, Hungary, Israel, Italy, Japan,
Kenya, South Korea, Liberia, Luxembourg, Netherlands, Nicaragua, Norway, Pakistan, Panama, Paraguay, Peru,
Philippines, Poland, Portugal, Senegal, Slovakia, Sri Lanka, Sweden, Switzerland, Tajikistan, Thailand, Uganda,
US, Uruguay, Venezuela, Zambia
observers— (48) Afghanistan, Belarus, Belize, Bosnia and Herzegovina, Brazil, Cape Verde, Federation of Ethnic
Communities'' Council of Australia Inc., Georgia, Ghana, Guinea, Guinea-Bissau, Holy See, India, Indonesia, Iran,
Ireland, Japan International Friendship and Welfare Foundation, Jordan, Kyrgyzstan, Latvia, Lithuania, Malta,
Mexico, Moldova, Morocco, Mozambique, Namibia, NZ, Niwano Peace Foundation, Partnership with the Children
of the Third World, Presiding Bishop''s Fund for World Relief/Episcopal Church, Refugee Council of Australia,
Romania, Russia, Rwanda, San Marino, Sao Tome and Principe, Slovenia, Somalia, South Africa, Spain, Sudan,
Turkey, Ukraine, UK, Vietnam, Yugoslavia, Zimbabwe
559
Appendix C: International Organizations and Groups (continued)
International Organization for
Standardization (ISO)
address— CP 56, 1 rue de Varembe, CH-1211
Geneva 20, Switzerland
telephone— [41] (22) 749 01 11
FAX- [41] (22) 733 34 30
established— NA February 1 947
aim— to promote the development of
international standards with a view to facilitating
international exchange of goods and services
and to developing cooperation in the sphere of
intellectual, scientific, technological and
economic activity
International Red Cross and Red Crescent
Movement (ICRM)
ac/dress — C ICR, 1 9 avenue de la Paix, CH-1 202
Geneva, Switzerland
telephone— [41] (22) 734 60 01
FAX— [41] (22) 733 20 57
established— NA 1928
aim— to promote worldwide humanitarian aid
through the International Committee of the Red
Cross (ICRC) in wartime, and International
Federation of Red Cross and Red Crescent
Societies (IFRCS; formerly League of Red
Cross and Red Crescent Societies or LORCS) in
peacetime
International Telecommunication Union (ITU)
address— Place des Nations, CH-121 1 Geneva
20, Switzerland
telephone— [4t] (22) 730 6184
FAX— [41] (22) 733 7256, 730 6614
established— 9 December 1932
effective— 1 January 1934
affiliated with the UN— 15 November 1947
aim— to deal with world telecommunications
issues; a UN specialized agency
members— { 86 national standards organizations) Albania, Algeria, Argentina, Armenia, Australia, Austria,
Bangladesh, Belarus, Belgium, Bosnia and Herzegovina, Brazil, Bulgaria, Canada, Chile, China, Colombia, Costa
Rica, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Egypt, Ethiopia, Finland, France, Germany,
Ghana, Greece, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Kazakhstan, Kenya,
North Korea, South Korea, Libya, The Former Yugoslav Republic of Macedonia, Malaysia, Mauritius, Mexico,
Mongolia, Morocco, Netherlands, NZ, Nigeria, Norway, Pakistan, Panama, Philippines, Poland, Portugal, Romania,
Russia, Saudi Arabia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria,
Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey, Ukraine, UK, US, Uruguay, Uzbekistan, Venezuela,
Vietnam, Yugoslavia, Zimbabwe
correspondent members— ( 24) Bahrain, Barbados, Botswana, Brunei, Estonia, Hong Kong, Jordan, Kuwait,
Kyrgyzstan, Latvia, Lebanon, Lithuania, Malawi, Malta, Mozambique, Nepal, Oman, Papua New Guinea, Paraguay,
Peru, Qatar, Turkmenistan, Uganda, UAE
subscriber members— ( 9) Antigua and Barbuda, Bolivia, Cambodia, Dominican Republic, Fiji, Grenada, Guyana,
Namibia, Saint Lucia
National Societies— (1 63 countries) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Australia, Austria, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia,
Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, The Gambia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, North Korea, South Korea, Kuwait, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia, Mali,
Malta, Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda,
Ukraine, UAE, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
members— (187) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad andTobago, Tunisia,
Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
560
International Telecommunications Satellite
Organization (Intelsat)
ac/d/''ess — Intelsat, 3400 International Drive NW,
Washington, DC 20008-3098, US
telephone— [\\] (202) 944 7500
FAX—[\\ ] (202) 944 7890
established— 20 August 1971
effective— 12 February 1973
aim— to develop and operate a global
commercial telecommunications satellite system
members— (140) Afghanistan, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus,
Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji,
Finland, France, Gabon, Germany, Ghana, Greece, Guatemala, Guinea, Haiti, Holy See, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea,
Kuwait, Kyrgyzstan, Lebanon, Libya, Liechtenstein, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Monaco, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saudi Arabia, Senegal, Singapore, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda','b7aeb4b8cffa182416ec61e03abbbc535fe9c41e61bc177ec0e5641d615fb652','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdbc3e688db188f5d6410f08757a0c614e97a14d7b4b61c49248284a67fd692d',1998,'TN','Tunisia','transnational-issues',517,', UAE, UK, US, Uruguay, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
nonsignatory users— (44) Albania, Antigua and Barbuda, Belarus, Belize, Burma, Burundi, Cambodia, Comoros,
Cook Islands, Cuba, Djibouti, Eritrea, The Gambia, Guinea-Bissau, Guyana, Kiribati, North Korea, Laos, Latvia,
Lesotho, Liberia, Lithuania, The Former Yugoslav Republic of Macedonia, Maldives, Marshall Islands, Moldova,
Mongolia, Nauru, Niue, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Seychelles,
Sierra Leone, Slovakia, Slovenia, Solomon Islands, Suriname, Tonga, Turkmenistan, Tuvalu, Ukraine, Vanuatu
Islamic Development Bank (IDB)
address— P. O. Box 5925, Jeddah 21432, Saudi
Arabia
telephone— [986] (2) 6361400
FAX-{ 966] (2) 6366871
established— 15 December 1973
aim— to promote Islamic economic aid and
social development
members— (48 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain,
Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The Gambia,
Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives,
Mali, Mauritania, Morocco, Mozambique, Niger, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone,
Somalia, Sudan, Syria, Tunisia, Turkey, Turkmenistan, Uganda, UAE, Yemen, Palestine Liberation Organization
Latin American Economic System (LAES)
note— a Iso known as Sistema Economico
Latinoamericana (SELA)
address— SELA, Avda Francisco de Miranda,
Torre Europa, piso 4, Chacaito, Apartado de
Correos 17035, Caracas 1010-A, Venezuela
telephone— [58] (2) 905 5111
FAX— {58] (2) 951 6953, 951 7246
established— 17 October 1975
aim— to promote economic and social
development through regional cooperation
members— (27) Argentina, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba, Dominican
Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua,
Panama, Paraguay, Peru, Suriname, Trinidad and Tobago, Uruguay, Venezuela
Latin American integration Association
(LAIA)
note— also known as Asociacion
Latinoamericana de Integracion (ALADI)
address— Calie Cebollati 1461, Casilla de
Correo 577, 11000 Montevideo, Uruguay
telephone— {598] (2) 40 1 1 21 , 49 59 1 5
FAX— [598] (2) 49 06 49
established— 12 August 1980
effective— 18 March 1981
aim— to promote freer regional trade
members— (11) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Mexico, Paraguay, Peru, Uruguay, Venezuela
observers— (20) China, Commission of the European Communities, Costa Rica, Cuba, Dominican Republic, El
Salvador, Guatemala, Honduras, Inter-American Development Bank, Italy, Nicaragua, Organization of American
States, Panama, Portugal, Romania, Russia, Spain, Switzerland, United Nations Development Program, United
Nations Economic Commission for Latin America and the Caribbean
League of Arab States (LAS)
see Arab League (AL)
League of Red Cross and Red Crescent
Societies (LORCS)
see International Federation of Red Cross and Red Crescent Societies (IFRCS)
561
Appendix C: International Organizations and Groups (continued)
least developed countries (LLDCs)
that subgroup of the less developed countries (LDCs) initially identified by the UN General Assembly in 1971 as
having no significant economic growth, per capita GDPs normally less than $1,000, and low literacy rates; also
known as the undeveloped countries; the 42 LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan, Botswana,
Burkina Faso, Burma, Burundi, Cape Verde, Central African Republic, Chad, Comoros, Djibouti, Equatorial Guinea,
Eritrea, Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti, Kiribati, Laos, Lesotho, Malawi, Maldives, Mali,
Mauritania, Mozambique, Nepal, Niger, Rwanda, Samoa, Sao Tome and Principe, Sierra Leone, Somalia, Sudan,
Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
less developed countries (LDCs)
the bottom group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); mainly countries and dependent areas with low levels of output, living
standards, and technology; per capita GDPs are generally below $5,000 and often less than $1 ,500; however, the
group also includes a number of countries with high per capita incomes, areas of advanced technology, and rapid
rates of growth; includes the advanced developing countries, developing countries, Four Dragons (Four Tigers),
leastdeveloped countries (LLDCs), low-income countries, middle-income countries, newly industrializing
economies (NIEs), the South, Third World, underdeveloped countries, undeveloped countries; the 172 LDCs are:
Afghanistan, Algeria, American Samoa, Angola, Anguilla, Antigua and Barbuda, Argentina, Aruba, The Bahamas,
Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin Islands, Brunei,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Cayman Islands, Central African Republic,
Chad, Chile, China, Christmas Island, Cocos Islands, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Falkland Islands, Fiji, French Guiana,
French Polynesia, Gabon, The Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe, Guam,
Guatemala, Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, India, Indonesia, Iran, Iraq,
Jamaica, Jersey, Jordan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia,
Libya, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Isle of Man, Marshall Islands, Martinique, Mauritania,
Mauritius, Mayotte, Federated States of Micronesia, Mongolia, Montserrat, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue, Norfolk Island, Northern Mariana
Islands, Oman, Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn Islands, Puerto
Rico, Qatar, Reunion, Rwanda, Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint
Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Taiwan, Tanzania, Thailand,
Togo, Tokelau, Tonga, Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu, UAE, Uganda, Uruguay,
Vanuatu, Venezuela, Vietnam, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara, Yemen, Zambia,
Zimbabwe; note-similar to the new International Monetary Fund (IMF) term “developing countries” which adds
Malta, Mexico, South Africa, and Turkey but omits in its recently published statistics American Samoa, Anguilla,
British Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea,
Falkland Islands, French Guiana, French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe,
Guam, Guernsey, Jersey, North Korea, Macau, Isle of Man, Martinique, Mayotte, Montserrat, Nauru, New
Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint
Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and
Futuna, West Bank, Western Sahara
low-income countries
another term for those less developed countries with below-average per capita GDPs; see less developed countries
(LDCs)
London Suppliers Group
see Nuclear Suppliers Group (NSG)
Mercado Comun del Cono Sur (Mercosur)
see Southern Cone Common Market
middle-income countries
another term for those less developed countries with above-average per capita GDPs; see less developed countries
(LDCs)
Missile Technology Control Regime (MTCR)
established— 16 April 1987
aim— to arrest the proliferation of missiles
(unmanned delivery vehicles of mass
destruction) by controlling the export of key
missile technologies and equipment
members— (28) Argentina, Australia, Austria, Belgium, Brazil, Canada, Denmark, Finland, France, Germany,
Greece, Hungary, Iceland, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South
Africa, Spain, Sweden, Switzerland, UK, US
Near Abroad
Russian term for the 14 non-Russian successor states of the USSR, in which 25 million ethnic Russians live and in
which Moscow has expressed a strong national security interest; the 14 countries are Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine,','9a822918167fe63fc14fa45969cfa9b20471dc51e839e1edf7437dbeb0237c88','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5077001d75062adc3d00c7e7d773419a3092ecf93ac3dd086d64e89a994f3230',1998,'JM','Jamaica','transnational-issues',525,'Disputes— international: none
Illicit drugs: transshipment point for cocaine from
Central and South America to North America and
Europe; illicit cultivation of cannabis; government has
an active manual cannabis eradication program
Jan Mayen
(territory of Norway)','addd4cb38bee131834fd365090a8df45b9fc4674c5d20bfe5ee30de69e64ee52','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7e05054000b05b0c1bf221ea1fe9ab95457cf1f08e2fe8fd13564f12d6651b7',1998,'JO','Jordan','transnational-issues',527,'Geograp h y
Location: Middle East, northwest of Saudi Arabia
Geographic coordinates: 31 00 N, 36 00 E
Map references: Middle East
Area:
tete/:89,213sq km
land: 88,884 sq km
water: 329 sq km
Area— comparative: slightly smaller than Indiana
Land boundaries:
total: 1 ,61 9 km
border countries: Iraq 181 km, Israel 238 km, Saudi
Arabia 728 km, Syria 375 km, West Bank 97 km
Coastline: 26 km
Maritime claims:
territorial sea: 3 nm
Climate: mostly arid desert; rainy season in west
(November to April)
Terrain: mostly desert plateau in east, highland area
in west; Great Rift Valley separates East and West
Banks of the Jordan River
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Jabal Ram 1,754 m
Natural resources: phosphates, potash, shale oil
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 9%
forests and woodland: 1 %
other: 85% (1993 est.)
Irrigated land: 630 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: limited natural fresh
water resources; deforestation; overgrazing; soil
erosion; desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Wetlands
244
signed, but not ratified: none of the selected
agreements
I People
Population: 4,434,978 (July 1998 est.)
Age structure:
0-14 years: 43% (male 985,21 1 ; female 935,982)
15-64 years: 54% (male 1 ,224,595; female
1,160,915)
65 years and over: 3% (male 64,406; female 63,869)
(July 1998 est.)
Population growth rate: 2.54% (1998 est.)
Birth rate: 35.18 births/1,000 population (1998 est.)
Death rate: 3.91 deaths/1 ,000 population (1 998 est.)
Net migration rate: -5.92 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 1.01 male(s)/female (1998 est.)
Infant mortality rate: 33.29 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population : 72.84 years
male: 70.96 years
female: 74.84 years (1998 est.)
Total fertility rate: 4.79 children born/woman
(1998 est.)
Nationality:
mm''Jordanian(s)
adjective: Jordanian
Ethnic groups: Arab 98%, Circassian 1%, Armenian
1%
Religions: Sunni Muslim 96%, Christian 4%
(1997 est.)
Languages: Arabic (official), English widely
understood among upper and middle classes
Literacy:
definition: age 1 5 and over can read and write
total population: 86.6%
male: 93.4%
female: 79.4% (1995 est.)
Disputes— international: none
Geo g r a p h y
Location: Southern Africa, island in the Mozambique
Channel, about one-third of the way between
Madagascar and Mozambique
Geographic coordinates: 17 03 S, 42 45 E
Map references: Africa
Area:
total: 4 A sq km
land: 4 .4 sq km
water: 0 sq km
Area— comparative: about seven times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 24.1 km
Maritime claims:
contiguous zone: 1 2 nm
continental shelf: 200-m depth or to depth the of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: NA
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 10 m
Natural resources: guano deposits and other
fertilizers
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 90%
other: 10%
Irrigated land: 0sqkm(1993)
Natural hazards: periodic cyclones
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: N A
Geography— note: wildlife sanctuary
246','c6b414566bd5bef445f4e1520167c2e839bd7c8c99d3b4401a7df74edeef6dba','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a879b5999d02d6ae3e30db89af5b2f5a02d6b329c4b3d1b97e93673c4e7aec1b',1998,'KE','Kenya','transnational-issues',540,'Disputes— international: administrative boundary
with Sudan does not coincide with international
boundary
Illicit drugs: widespread harvesting of small, wild
plots of marijuana and qat (chat); transit country for
South Asian heroin destined for Europe and,
sometimes, North America; Indian methaqualone also
transits on way to South Africa','c991a21069c74eee4e5f72cdba568880a305c1745bb758ff898d5809a9599222','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2df91744611c2751850e59843b8e033b7a80f82fd2698b688cf2cc3d8a8f2478',1998,'WS','Samoa','transnational-issues',547,'Disputes— international: none
252
Disputes— international: none
363
Panama *jlH
Disputes— international: none
illicit drugs: major cocaine transshipment point and
major drug money-laundering center; no recent signs
of coca cultivation; monitoring of financial transactions
is improving
South Pacific Ocean
Disputes— international: none','6c195b48517bc2d0b1dddf261e43360cad3b9182f8d701327eb0bcdf33771a3b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e57588b3b776dd75e0a7278a6481ce26371a2776b111fed2be69d65f17f9af88',1998,'KI','Kiribati','transnational-issues',548,'400 800 km
. MARSHALL
. ISLANDS
Equator "
^TARAWA
UNITED STATES ft
(Hawaii) ^
° Johnston Atoll
(U-S)
North Pacific Ocean
Kingman Reef Palmyra Atoj,
(us/
Howland I. (U.S.)
« Baker I. (U.S.) _
Jarvis !.* JCHnstmas I.)
(U.S.)
o »« Kiribati
Banaba *\\a(Giibert
Islands)
TUVALU \\ °
° a Rawaki
o0 "(Phoenix t
Islands)
Tokelau South Pacific Ocean
SOLOMON
ISLANDS
(N.Z.) •
Cook Is.
o(N.Z.) 8
> VANUATU ''t''cyl ''i
• •**:
FIJI •
Samoa (u.s.)
French „
Polynesia * *
(FR)
Cook Islands ''
(NZ.)„
Disputes— international: none
254
Disputes— international: 33-km section of
boundary with China in the Paektu-san (mountain)
area is indefinite; Demarcation Line with South Korea
Disputes— international: Demarcation Line with
North Korea; Liancourt Rocks (Takeshima/Tokdo)
claimed by Japan','dfc4247bce509c7be0572d879bb6488a94d480502c54c163cd4a75ca38b2c03f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36b26089771e3c5c749434b667bfad6e55e9255b091557895c44b0dda335b53e',1998,'KG','Kyrgyzstan','transnational-issues',564,'Disputes— international: territorial dispute with
Tajikistan on southwestern boundary in Isfara Valley
area
Illicit drugs: limited illicit cultivator of cannabis and
opium poppy, mostly for CIS consumption; limited
government eradication program; increasingly used
as transshipment point for illicit drugs to Russia and
Western Europe from Southwest Asia
Laos
Location: Southeastern Asia, northeast of Thailand,
west of Vietnam
Geographic coordinates: 18 00 N, 105 00 E
Map references: Southeast Asia
Area:
total: 236,800 sq km
land: 230,800 sq km
water: 6,000 sq km
Area— comparative: slightly larger than Utah
Land boundaries:
total: 5,083 km
border countries: Burma 235 km, Cambodia 541 km,
China 423 km, Thailand 1 ,754 km, Vietnam 2, 1 30 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon; rainy season (May to
November); dry season (December to April)
Terrain: mostly rugged mountains; some plains and
plateaus
Elevation extremes:
lowest point: Mekong River 70 m
highest point: Phou Bia 2,817 m
Natural resources: timber, hydropower, gypsum,
tin, gold, gemstones
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 54%
other: 40% (1993 est.)
Irrigated land: 1,250 sq km (1993 est.)
Natural hazards: floods, droughts, and blight
Environment— current issues: unexploded
ordnance; deforestation; soil erosion; a majority of the
population does not have access to potable water
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Nuclear
Test Ban
signed, but not ratified: Law of the Sea
Geography— note: landlocked
Disputes— international: parts of the border with
Thailand are indefinite
Illicit drugs: world''s third largest opium producer
(cultivation in 1997—28,150 hectares, an 11%
increase over 1996; potential production— 210 metric
tons, a 5% increase over 1996); heroin producer;
transshipment point for heroin and amphetamines
produced in Burma; illicit producer of cannabis','d6f47e8d25e5dcc726f485234eedf1db04bff82de75f1816b0febdde6a11d976','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31ee7df97d5315c08c504cf1adfaacf0444d44afb2006d8f586027c3f1181289',1998,'LS','Lesotho','transnational-issues',571,'!"■'' ■
SOUTH AFRICA r
V.
1 .Teyateyaneng
Xmaseru
Mokhotlong. V
Thaba-Tseka* 1
\\ .Mafeteng
Y.“ aacha^Nek^/
''"V. .Quthing }','f361818ce38063fc0a3b68aeb9029b8709e15ac799dbf4e2372ee81743fdd8e2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e87d136e9530263c221ae423bb5821da5be090f93d008ee7c1ded8545c04e998',1998,'ZA','South Africa','transnational-issues',572,'0_
30 60 km
0
30 60 mi
Disputes— international: none
272
; Liberia
Current issues: The Abuja Peace Accords ended
seven years of civil warfare in Liberia. More than
20,000 of the estimated 33,000 factional fighters gave
up their arms to the Cease-Fire Monitoring Group of
the Economic Community of West African States
(ECOMOG). Free and open presidential and
legislative elections were held 19 July 1997; former
faction leader, Charles TAYLOR, and his National
Patriotic Party won overwhelming victories. The years
of civil strife coupled with the flight of most business
people disrupted formal economic activity, but with
peace restored and a popularly-elected government
installed, the difficult task of rebuilding the social and
economic structure of this war-torn country can
proceed.
Disputes— international: none
Illicit drugs: increasingly a transshipment point for
Southeast and Southwest Asian heroin and South
American cocaine for the European and US markets','ac7e3baff1a69f10aaa4c8f57910b4316104e25f430467ec544b0326dceddf94','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea4aca4bdfb1a7ad9bb742fd1240fb7263377abe54000f1dc8b6579b527c2860',1998,'LY','Libya','transnational-issues',587,'Disputes— international: maritime boundary
dispute with Tunisia; Libya claims about 1 9,400 sq km
in northern Niger and part of southeastern Algeria','10d7d62fb8bdbdbf24c4ba1a7c623d2ac96110d1e32e344f766afe77e8f2a321','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8af625e71d07ade96673837d2f8003b1cac3ed98750b41a9d45cfd2b10374cf',1998,'CH','Switzerland','transnational-issues',594,'Disputes— international: claims 1 ,600 sq km of
territory in the Czech Republic confiscated from its
royal family in 1918; the Czech Republic insists that
restitution does not go back before February 1948,
when the communists seized power
278
Disputes— international: ongoing talks over
boundary dispute with Latvia (primary concern oil
exploration rights); demarcation has begun on border
with Belarus; 1 997 border agreement with Russia not
yet ratified
Illicit drugs: transshipment point for opiates and
other illicit drugs from Southwest Asia and Latin
America to Western Europe and Scandinavia
280
telephone— {^] (61) 280 80 80
FAY— [41] (61) 280 91 00
established— 20 January 1930
effective— 17 March 1930
aim— to promote cooperation among central
banks in international financial settlements
members— (33) Australia, Austria, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Estonia, Finland, France,
Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, Latvia, Lithuania, Netherlands, Norway, Poland,
Portugal, Romania, Slovakia, South Africa, Spain, Sweden, Switzerland, Turkey, UK, US, Yugoslavia (suspended)
pending members— (9) Brazil, China, Hong Kong, India, South Korea, Mexico, Russia, Saudi Arabia, Singapore
Banque Africaine de Developpement (BAD)
see African Development Bank (AfDB)
Banque Arabe de Developpement
Economique en Afrique (BADEA)
see Arab Bank for Economic Development in Africa (ABEDA)
Banque de Developpement des Etats de
l"Afrique Centrale (BDEAC)
see Central African States Development Bank (BDEAC)
Banque Ouest-Africaine de Developpement
(BOAD)
see West African Development Bank (WADB)
Benelux Economic Union (Benelux)
members— (3) Belgium, Luxembourg, Netherlands
note— acronym from Belgium, Netherlands, and
telephone-^ 41] (22) 730 4222
FAX— [41] (22) 733 0395
established— 5 May 1919
aim— to organize, coordinate, and direct
international relief actions; to promote
humanitarian activities; to represent and
encourage the development of National
Societies; to bring help to victims of armed
conflicts, refugees, and displaced people; to
reduce the vulnerability of people through
development programs
members — (170) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, The Gambia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, North Korea, South Korea,
Kuwait, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
associate members— (13) Andorra, Antigua and Barbuda, Comoros, Cyprus, Equatorial Guinea, Gabon, Kiribati,
Namibia, Saint Kitts and Nevis, Seychelles, Suriname, Tuvalu, Vanuatu
address— 1818 H Street NW, Washington, DC
20433, US
telephone— [1] (202) 477 1234
FAX— [1] (202) 477 6391
established— 26 January 1960
effective— 24 September 1960
aim— UN specialized agency and IBRD affiliate
that provides economic loans for low income
countries
556
International Finance Corporation (IFC)
address— 1850 1 Street NW, Washington, DC
20433, US
telephone-^] (202) 473 0631
FAX''— [1 ] (202) 676 0631
established— 25 May 1955
effective— 20 July 1956
aim— to support private enterprise in
international economic development; a UN
specialized agency and IBRD affiliate
International Fund for Agricultural
Development (IFAD)
address— V ia del Serafico 107, 1-00142 Rome,
telephone— [M] (31) 350 31 11
FAX— [A]] (31) 350 31 10
established— 9 October 1874, affiliated with the
UN 15 November 1947
effective — 1 July 1948
aim— to promote international postal
cooperation; a UN specialized agency
members— (189) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands
Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Overseas Territories of the UK, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
Warsaw Pact (WP)
established 14 May 1955 to promote mutual defense; members met 1 July 1991 to dissolve the alliance; member
states at the time of dissolution were Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and the USSR; earlier
members included East Germany and Albania
West African Development Bank (WADB)
note— also known as Banque Ouest-Africaine
de Developpement (BOAD); is a financial
institution of WAEMU
address— 68 av de la Liberation, BP 1172,
Lome, Togo
telephone— {228] 21 59 06, 21 42 44, 21 01 13
FAX— [228] 21 52 67, 21 72 69
established— 14 November 1973
a/m — to promote regional economic
development and integration
members— (7) Benin, Burkina Faso, Cote d''Ivoire, Mali, Niger, Senegal, Togo
West African Economic and Monetary Union
(WAEMU)
note— also known as Union economique et
monetaire Ouest africaine (UEMOA)
address— Commission de I''UEMOA, 01 BP 543,
Ouadgadougou, Burkina Faso
telephone— [226] 31 88 73 through 76
FAX— [226] 31 88 72
established — 1 August 1994
aim— to increase competitiveneess of members''
economic markets; to create a common market
members— (7) Benin, Burkino Faso, Cote d''Ivoire, Mali, Niger, Senegal, Togo
West African Economic Community (CEAO)
note— acronym from Communaute Economique
de I''Afrique de I''Ouest
established on 3 June 1972 to promote regional economic development; its members were Benin, Burkina Faso,
Cote d''Ivoire, Mali, Mauritania, Niger, Senegal; it was disbanded in 1994
577
Appendix C: International Organizations and Groups (continued)
Western European Union (WEU)
address— Rue de la Regence 4, B-1000
Brussels, Belgium
telephone— [32] (2) 500 4411
FAX— [32] (2) 511 32 70
established— 23 October 1 954
effective— 6 May 1955
aim— to provide mutual defense and to move
toward political unification
memper$-( io) Belgium, France, Germany, Greece, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
associate members— (3) Iceland, Norway, Turkey
associate partners— (10) Bulgaria, Czech Republic, Estonia, Hungary, Latvia, Lithuania, Poland, Romania,
Slovakia, Slovenia
observers— (5) Austria, Denmark, Finland, Ireland, Sweden
World Bank
see International Bank for Reconstruction and Development (IBRD)
World Bank Group
includes International Bank for Reconstruction and Development (IBRD), International Development Association
(IDA), and International Finance Corporation (IFC)
World Confederation of Labor (WCL)
address— Rue de Treves 33, B-1040 Brussels,
telephone— [4*1] (22) 730 81 11
FAX— [41] (22) 734 23 26
established— 1 October 1947
effective— 4 April 1951
aim— to sponsor meteorological cooperation; a
UN specialized agency
members— (191) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niue, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia,','a80b8d7ab86bce0e91cc17dc27b337d90aaa4b9f77dc306d3f2e06d29ad87225','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c72ccba00134630622b87da53a8b28ab6f01980331032410a2851bd6d28a1238',1998,'MX','Mexico','transnational-issues',602,'Land boundaries:
total: 2,669 km
border countries: Brunei 381 km, Indonesia 1 ,782 km,
Thailand 506 km
Coastline: 4,675 km (Peninsular Malaysia 2,068 km,
East Malaysia 2,607 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation; specified boundary in the South China
Sea
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; annual southwest (April to
October) and northeast (October to February)
monsoons
Terrain: coastal plains rising to hills and mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mount Kinabalu 4,100 m
Natural resources: tin, petroleum, timber, copper,
iron ore, natural gas, bauxite
Land use:
arable land: 3%
permanent crops: 1 2%
permanent pastures: 0%
forests and woodland: 68%
other: 17% (1993 est.)
Irrigated land: 3,400 sq km (1 993 est.)
Natural hazards: flooding, landslides
Environment— current issues: air pollution from
industrial and vehicular emissions; water pollution
from raw sewage; deforestation; smoke/haze from
Indonesian forest fires
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location along Strait of
Malacca and southern South China Sea
Disputes— international: involved in a complex
dispute over the Spratly Islands with China,
Philippines, Taiwan, Vietnam, and possibly Brunei;
Sabah State claimed by the Philippines; Brunei may
wish to purchase the Malaysian salient that divides
Brunei into two parts; two islands in dispute with
Singapore; two islands in dispute with Indonesia
Illicit drugs: transit point for Golden Triangle heroin
going to Western markets despite severe penalties for
drug trafficking
Disputes— international: none
Illicit drugs: illicit cultivation of opium poppy
(cultivation in 1 997—4,000 hectares, a 22% decrease
from 1996; potential production— 46 metric tons,
about a 15% decrease from 1996) and cannabis
continues in spite of increased government
eradication; major supplier of heroin and marijuana to
the US market; continues as the primary
transshipment country for US-bound cocaine from
South America; increasingly involved in the
production and distribution of methamphetamines
312
Micronesia,
Federated
States of
Disputes— international: territorial claim in
Antarctica (Queen Maud Land); Svalbard is the focus
of a maritime boundary dispute in the Barents Sea
between Norway and Russia
Illicit drugs: minor transshipment point for drugs
shipped via the CIS and Baltic states for the European
market; increasing domestic consumption of cannabis
and amphetamines
Land boundaries:
total: 2,888 km
border countries: Belarus 605 km, Czech Republic
658 km, Germany 456 km, Lithuania 91 km, Russia
(Kaliningrad Oblast) 206 km, Slovakia 444 km,
Ukraine 428 km
Coastline: 491 km
Maritime claims:
exclusive economic zone: defined by international
treaties
territorial sea: 12 nm
Climate: temperate with cold, cloudy, moderately
severe winters with frequent precipitation; mild
summers with frequent showers and thundershowers
Terrain: mostly flat plain; mountains along southern
border
Elevation extremes:
lowest point: Raczki Elblaskie -2 m
highest point: Rysy 2,499 m
Natural resources: coal, sulfur, copper, natural gas,
silver, lead, salt
Land use:
arable land: 47%
permanent crops: 1%
permanent pastures: 13%
forests and woodland: 29%
other: 10% (1993 est.)
Irrigated land: 1 ,000 sq km (1 993 est.)
Natural hazards: NA
Environment— current issues: situation has
improved since 1989 due to decline in heavy industry
and increased environmental concern by
postcommunist governments; air pollution
nonetheless remains serious because of sulfur
dioxide emissions from coal-fired power plants, and
the resulting acid rain has caused forest damage;
water pollution from industrial and municipal sources
is also a problem, as is disposal of hazardous wastes
Environment— international agreements:
party to: Air Pollution, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Law of the Sea
Geography— note: historically, an area of conflict
because of flat terrain and the lack of natural barriers
on the North European Plain
T r a n s p o r t a t i o n
Railways:
tote/: 24, 31 3 km
broad gauge: 652 km 1.520-m gauge
standard gauge: 22,243 km 1 .435-m gauge (1 1 ,648
km electrified; 8,978 km double track)
narrow gauge: 1,418 km various gauges including
1.000-m, 0.785-m, 0.750-m, and 0.600-m (1996)
Highways:
total: 374,990 km
paved: 245,243 km (including 258 km of
expressways)
unpaved: 129,747 km (1996 est.)
Waterways: 3,812 km navigable rivers and canals
(1996)
Pipelines: crude oil and petroleum products 2,280
km; natural gas 17,000 km (1996)
Ports and harbors: Gdansk, Gdynia, Gliwice,
Kolobrzeg, Szczecin, Swinoujscie, Ustka, Warsaw,
Wrocaw
Merchant marine:
total: 90 ships (1 ,000 GRT or over) totaling 1 ,574,637
GRT/2,446,849 DWT
ships by type: bulk 67, cargo 1 0, chemical tanker 3,
container 2, passenger 1 , refrigerated cargo 2, roll-on/
roll-off cargo 1 , short-sea passenger 4
note: Poland owns an additional 35 ships (1 ,000 GRT
or over) totaling 459,793 DWT operating under the
registries of The Bahamas, Cyprus, Liberia, Malta,
and Vanuatu (1997 est.)
Airports: 83 (1997 est.)
Airports— with paved runways:
total: 68
over 3,047 m: 2
2,438 to 3,047 m: 23
1,524 to 2,437 m: 34
914 to 1,523 m: 6
under 914 m: 3 (1997 est.)
Airports— with unpaved runways:
total: 1 5
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 5(1997 est.)
Heliports: 3 (1997 est.)
Disputes— international: sovereignty over Timor
Timur (East Timor province) disputed with Indonesia
and not recognized by the UN
Illicit drugs: important gateway country for Latin
American cocaine entering the European market;
transshipment point for hashish from North Africa to
Europe; consumer of Southwest Asian heroin
381
Disputes— international: maritime boundary with
Cambodia not defined; involved in a complex dispute
over the Spratly Islands with China, Malaysia,
Philippines, Taiwan, and possibly Brunei; maritime
boundary with Thailand resolved, August 1997;
maritime boundary dispute with China in the Gulf of
Tonkin; Paracel Islands occupied by China but
claimed by Vietnam and Taiwan; offshore islands and
sections of boundary with Cambodia are in dispute;
sections of land border with China are indefinite
Illicit drugs: key growing areas in Vietnam cultivated
6,150 hectares of poppy in 1997 (an increase of 95%
over 1996), with a potential production of 45 metric
tons (an increase of 80% over 1996) of opium; opium
producer and probably minor transit point for
Southeast Asian heroin destined for the US and
Europe; growing opium addiction; possible
small-scale heroin production
Virgin Islands
(territory of the US)','11480108d12fbad5f39ab741c71808e521a9f04ea816620dae11b69ad2d57824','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a5d73543b69e6c722fc5ecf320c0530180979d60eacff47ae8e4d571bb90fd0',1998,'MV','Maldives','transnational-issues',605,'Arabian
Sea
iY
'' Y
%%
* v. Male Atoll
h ^ MALE
* i. \\ VJ
Xy i * .
<0
5 U
6
vj
Laccadive
Sea
Addu Atoll ,
^ Gan
adequate intercity microwave radio relay network
between Sabah and Sarawak via Brunei; domestic
satellite system with 2 earth stations
international: submarine cables to India, Hong Kong
and Singapore; satellite earth stations— 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 28, FM 3,
shortwave 0
Radios: 8.08 million (1992 est.)
Television broadcast stations: 33
Televisions: 2 million (1993 est.)
Disputes— international: none
G e o g r a p h y
Location: Western Africa, southwest of Algeria
Geographic coordinates: 17 00 N, 4 00 W
Map references: Africa
Area:
total: 1.24 million sq km
land: 1 .22 million sq km
water: 20,000 sq km
Area— comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 7,243 km
border countries: Algeria 1,376 km, Burkina Faso
1,000 km, Guinea 858 km, Cote d''Ivoire 532 km,
Mauritania 2,237 km, Niger 821 km, Senegal 419 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical to arid; hot and dry February to
June; rainy, humid, and mild June to November; cool
and dry November to February
Terrain: mostly flat to rolling northern plains covered
by sand; savanna in south, rugged hills in northeast
Elevation extremes:
iowest point: Senegal River 23 m
highest point: Hombori Tondo 1,155 m
Natural resources: gold, phosphates, kaolin, salt,
limestone, uranium, bauxite, iron ore, manganese, tin,
and copper deposits are known but not exploited
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 6%
other: 67% (1993 est.)
Irrigated land: 780 sq km (1993 est.)
Natural hazards: hot, dust-laden harmattan haze
common during dry seasons; recurring droughts
Environment— current issues: deforestation; soil
erosion; desertification; inadequate supplies of
potable water; poaching
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection, Wetlands
signed, but not ratified: Nuclear Test Ban
Geography— note: landlocked
P e o pie
Population: 10,108,569 (July 1998 est.)
Age structure:
0-14 years: 47% (male 2,405,624; female 2,383,728)
15-64 years: 49% (male 2,367,538; female
2,628,399)
65 years and over: 4% (male 152,999; female
170,281) (July 1998 est.)
Population growth rate: 3.24% (1998 est.)
Birth rate: 49.88 births/1,000 population (1998 est.)
Death rate: 1 9.04 deaths/1 ,000 population (1 998
est.)
Net migration rate: 1 .57 migrant(s)/1 ,000
population (1998 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years : 0.9 male(s)/female
65 years and over: 0.89 male(s)/female (1 998 est.)
Infant mortality rate: 121 .72 deaths/1 ,000 live
births (1998 est.)
Life expectancy at birth:
total population: 47.03 years
male : 45.67 years
female: 48.43 years (1998 est.)
Total fertility rate: 7.02 children born/woman (1998
est.)
Nationality:
noun: Malian(s)
adjective: Malian
Ethnic groups: Mande 50% (Bambara, Malinke,
Sarakole), Peul 17%, Voltaic 12%, Songhai 6%,
Tuareg and Moor 10%, other 5%
Religions: Muslim 90%, indigenous beliefs 9%,
Christian 1%
Languages: French (official), Bambara 80%,
numerous African languages
Literacy:
definition: age 15 and over can read and write
total population: 31%
male: 39.4%
female: 23.1% (1995 est.)
Disputes— international: none
Disputes— international: Malta and Tunisia are
discussing the commercial exploitation of the
continental shelf between their countries, particularly
for oil exploration
Illicit drugs: minor transshipment point for hashish
from North Africa to Western Europe
Man, Isle of
: (British crown dependency)
Disputes— international: none
300','fc10617414e8a2ed15da017e7f708e006f3ba39e7cdc332ea203c08a37abcac4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0a12bf7f97e1402c841ff1e531cb6187b026b0f26030d473fb1ee22fa038cd4',1998,'MH','Marshall Islands','transnational-issues',613,'0 150 300 km
0 150 300 mi
North Pacific Ocean
Bikini
Ct
DTaongi
» Bikar
Ujelang
^Rongerik JJtirik o %:
w Rongelap Takf
$ Wotho *'' M6}it *
''p Uldep <&Wotie
Ujae\\ J^^Xtr''Ebeye Jb _ Ma/oe/ap
Q, * ^Kwajalein Enkub%>
Kwajalein ''
Namu
Ailinglapalap
<?
Majuro ^/Imo
MAJURO® Mili
h ^
V,,!,.* kVirty
Disputes— international: claims US territory of
Wake Island
302','a6b61f6e1aa8b107f909e3250d983d7590d2f1855dead63ecd4ee064fb04bcfc','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3f071d3f588154cd9502d5939eaa41bb4ff49637246a8463e4247af650c42bf',1998,'MU','Mauritius','transnational-issues',633,'Disputes— international: claims the island of Diego
Garcia in UK-administered British Indian Ocean
Territory; claims French-administered T romelin Island
Illicit drugs: illicit producer of cannabis for the
international drug trade; heroin consumption and
transshipment are growing problems','c1ee0b62f1a99bcf4fab8def6e923a75aabc09bab550b63574fa32271235b229','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aff4d8ee20a23ee341107dfb65009c79011f98088874bcb0e3f39796e41867e',1998,'YT','Mayotte','transnational-issues',634,'(territorial collectivity
of France)
Disputes— international: claimed by Comoros','72a1bcb848e761f5603cc6069d6e0f0e65a3a63142ae9873071f1acb8b1be76d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c642e3fac0d1893aa619bf9e659ae68eeee9d790fc08b8cb80967674c47a4592',1998,'NR','Nauru','transnational-issues',657,'Location: Oceania, island in the South Pacific
Ocean, south of the Marshall Islands
Geographic coordinates: 0 32 S, 166 55 E
Map references: Oceania
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area— comparative: about 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 30 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; monsoonal; rainy season
(November to February)
Terrain: sandy beach rises to fertile ring around
raised coral reefs with phosphate plateau in center
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location along plateau rim
61 m
Natural resources: phosphates
Land use:
arable land: NA%
permanent crops: N A%
permanent pastures: NA%
forests and woodland: NA%
other: 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: periodic droughts
Environment— current issues: limited natural fresh
water resources, roof storage tanks collect rainwater;
intensive phosphate mining during the past 90
years— mainly by a UK, Australia, and New Zealand
consortium— has left the central 90% of Nauru a
wasteland and threatens limited remaining land
resources
Environment— international agreements:
party to: Biodiversity, Climate Change, Law of the
Sea, Marine Dumping
signed, but not ratified: none of the selected
agreements
Geography— note: Nauru is one of the three great
phosphate rock islands in the Pacific Ocean— the
others are Banaba (Ocean Island) in Kiribati and
Makatea in French Polynesia; only 53 km south of
Equator
Disputes— international: none
330
Navassa Island
(territory of the US)
Geo g r a p h y
Location: Caribbean, island in the Caribbean Sea,
about one-fourth of the way from Haiti to Jamaica
Geographic coordinates: 18 25 N, 75 02 W
Map references: Central America and the
Caribbean
Area:
total: 5.2 sq km
land: 5.2 sq km
water: 0 sq km
Area— comparative: about nine times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: marine, tropical
Terrain: raised coral and limestone plateau, flat to
undulating; ringed by vertical white cliffs (9 to 15
meters high)
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: unnamed location on southwest side
77 m
Natural resources: guano
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 10%
forests and woodland: 0%
other: 90%
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: strategic location 160 km south
of the US Naval Base at Guantanamo Bay, Cuba;
mostly exposed rock, but enough grassland to support
goat herds; dense stands of fig-like trees, scattered
cactus
Disputes— international: claimed by Haiti
Disputes— international: with Bhutan over 91 ,000
Bhutanese refugees in Nepal
Illicit drugs: illicit producer of cannabis for the
domestic and international drug markets; transit point
for opiates from Southeast Asia to the West','63293d82b883b2cc4aef8ef7a7c725a6af0b6104ee0da352d28f54568ec298a1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60219bad55db354a3a5ee8e1e6c1b6192ff05c12fc90e3781de424afe2262e69',1998,'NC','New Caledonia','transnational-issues',669,'(overseas territory
of France)
Location: Oceania, islands in the South Pacific
Ocean, east of Australia
Geographic coordinates: 21 30 S, 165 30 E
Map references: Oceania
Area:
total: 19,060 sq km
land: 18,575 sq km
water: 485 sq km
Area— comparative: slightly smaller than New','37481cbcc45bd285906cfac6c598c738732d2ba6061930193b76c5573342d5a5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5aded94f2537a05e6131ee24fb3961aa754280e5a4ab5d39750d87299633eab',1998,'NZ','New Zealand','transnational-issues',676,'Disputes— international: territorial claim in
Antarctica (Ross Dependency)
Disputes— international: none
Disputes— international: none
Illicit drugs: transshipment point for South American
drugs destined for the US and Europe and producer of
cannabis
Tromelin Island
(possession of France)
0
OAPEC
Organization of Arab Petroleum Exporting Countries
OAS
Organization of American States
OAU
Organization of African Unity
ODA
official development assistance
OECD
Organization for Economic Cooperation and Development
OECS
Organization of Eastern Caribbean States
OIC
Organization of the Islamic Conference
ONUMOZ
see United Nations Operation in Mozambique (UNOMOZ)
ONUSAL
United Nations Observer Mission in El Salvador
OOF
other official flows
OPANAL
Organismo para la Proscripcion de las Armas Nucleares en la America Latina y el
Caribe; see Agency for the Prohibition of Nuclear Weapons in Latin America and
the Caribbean
OPEC
Organization of Petroleum Exporting Countries
OSCE
Organization on Security and Cooperation in Europe
Ozone Layer Protection
Montreal Protocol on Substances That Deplete the Ozone Layer
P
PCA
Permanent Court of Arbitration
PDRY
People''s Democratic Republic of Yemen [Yemen (Aden) or South Yemen]; used
for information dated before 22 May 1990 or CY91
PFP
Partnership for Peace
R
Ramsar
see Wetlands
RG
Rio Group
S
SAARC
South Asian Association for Regional Cooperation
SACU
Southern African Customs Union
SADC
Southern African Development Community
SADCC
Southern African Development Coordination Conference; see Southern African
Development Community (SADC)
SELA
Sistema Economico Latinoamericana; see Latin American Economic System
(LAES)
SFRY
Socialist Federal Republic of Yugoslavia; dissolved 5 December 1991
529
Appendix A: Abbreviations (continued)
SHF
super-high-frequency
Ship Pollution
Protocol of 1 978 Relating to the International Convention for the Prevention of
Pollution From Ships, 1973 (MARPOL)
Sparteca
South Pacific Regional Trade and Economic Cooperation Agreement
SPC
South Pacific Commission
SPF
South Pacific Forum
sq km
square kilometer
sq mi
square mile
TAT
Trans-Atlantic Telephone
Tropical Timber 83
International Tropical Timber Agreement, 1983
Tropical Timber 94
International Tropical Timber Agreement, 1994
UAE','137f8170baf7b5d5ff6852c66c16bb96b1c0873cdb5467427f9aa1bcad0aa264','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c909521569f5fc28339f8a26034da108e81b2273fb1cb1dfe358319b102ac0e2',1998,'NI','Nicaragua','transnational-issues',677,'del
Maiz
Geo g r a p h y
Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Costa Rica and Honduras
Geographic coordinates: 13 00 N, 85 00 W
Map references: Central America and the
Caribbean
Area:
total: 129,494 sq km
land: 120,254 sq km
water: 9,240 sq km
Area— comparative: slightly smaller than New York
State
Land boundaries:
total: 1,231 km
border countries: Costa Rica 309 km, Honduras
922 km
Coastline: 910 km
Maritime claims:
contiguous zone: 25-nm security zone
continental shelf: natural prolongation
territorial sea: 200 nm
Climate: tropical in lowlands, cooler in highlands
Terrain: extensive Atlantic coastal plains rising to
central interior mountains; narrow Pacific coastal plain
interrupted by volcanoes
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mogoton 2,438 m
Natural resources: gold, silver, copper, tungsten,
lead, zinc, timber, fish
Land use:
arable land: 9%
permanent crops: 1%
permanent pastures: 46%
forests and woodland: 27%
other: 17% (1993 est.)
Irrigated land: 880 sq km (1993 est.)
Natural hazards: destructive earthquakes,
volcanoes, landslides, and occasionally severe
hurricanes
342
Environment— current issues: deforestation; soil
erosion; water pollution
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection,
Whaling
signed, but not ratified: Environmental Modification,
Law of the Sea
Disputes— international: territorial disputes with
Colombia over the Archipelago de San Andres y
Providencia and Quita Sueno Bank; with respect to
the maritime boundary question in the Golfo de
Fonseca, the International Court of Justice (ICJ)
referred the disputants to an earlier agreement in this
century and advised that some tripartite resolution
among El Salvador, Honduras, and Nicaragua likely
would be required; maritime boundary dispute with','6adb1b0c89729febcded2cd57ccb25539bbb48078e2f8a10e6527da8b5c1764b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d988e18201ea223f8e2f6abc909a2b3e9c64425616bec5758e57c5be94ca6d2',1998,'NG','Nigeria','transnational-issues',687,'Disputes— international : Libya claims about 1 9,400
sq km in northern Niger; demarcation of international
boundaries in the vicinity of Lake Chad, the lack of
which led to border incidents in the past, is completed
and awaits ratification by Cameroon, Chad, Niger, and
346
Disputes— international: demarcation of
international boundaries in the vicinity of Lake Chad,
the lack of which led to border incidents in the past, is
348
completed and awaits ratification by Cameroon,
Chad, Niger, and Nigeria; dispute with Cameroon over
land and maritime boundaries in the vicinity of the
Bakasi Peninsula has been referred to the ICJ with a
ruling expected in 1998; maritime boundary dispute
with Equatorial Guinea because of disputed
jurisdiction over oil-rich areas in the Gulf of Guinea
Illicit drugs: facilitates movement of heroin en route
from Southeast and Southwest Asia to Western
Europe and North America; increasingly a transit
route for cocaine from South America intended for
European, East Asian, and North American markets','7ced0b7952a83b7a0a638117a10be34b11c6922f3e03e10c7319977e42e50a1b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5f8d46c80e4cda209024f7b75199000c9aa43a355fd10f3ca0205250c5423fd',1998,'NU','Niue','transnational-issues',691,'(self-governing in free
association with
New Zealand)
Disputes— international: none
350','4490a8150286bddb11d2157cd192cd43f2f29d275188e0fa5d71d0161fa559e8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fa63c81b081341c9c11c5a2b5e159a3652da93f9eb5b5465564e5b725bf1b45',1998,'MP','Northern Mariana Islands','transnational-issues',710,'Disputes— international: none
353
Geographic coordinates: 19 17 N, 166 36 E
Map references: Oceania
Area:
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area— comparative: about 1 1 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 19.3 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: atoll of three coral islands built up on an
underwater volcano; central lagoon is former crater,
islands are part of the rim
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 6 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1993)
Natural hazards: occasional typhoons
Environment— current issues: NA
Environment— international agreements:
party to: NA
signed, but not ratified: NA
Geography— note: strategic location in the North
Pacific Ocean; emergency landing location for
transpacific flights
Disputes— international: claimed by Marshall
Islands
507','e52810a8a85bfd6fb912b1fcecf5898cd14524d40f28e0f517383700f852b76a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86e9bdaa58bc80b20755b43cba0620372ccd745ac77bbaa46dde3518b28eb801',1998,'OM','Oman','transnational-issues',719,'Disputes— international: no defined boundary with
most of UAE, but Administrative Line in far north
Pacific Ocean
Disputes— international: some maritime disputes
(see littoral states)','c0eff8ea4a7607ec85141404e3fe5032ba6037cc084380c258c34082354f9c1b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec5bd892893e301b3441c136a3abd1deae3643d68d4befda62591d0ffbae1511',1998,'PK','Pakistan','transnational-issues',727,'Disputes— international: status of Kashmir with
India; water-sharing problems with India over the
Indus River (Wular Barrage)
Illicit drugs: illicit producer of opium and hashish for
the international drug trade (cultivation in 1997 — 4,100
hectares, a 21% increase over 1996; potential
production— 85 metric tons, a 1 3% increase over 1 996);
center for processing Afghan heroin and key transit area
for Southwest Asian heroin moving to Western markets
Kayangel
Islands'',
% . Palau
Babelthuap. :A Islands
r~ KOROR
• b Beliliou
Philippine
Sea
O 50 100 km
O 50 100 mi
.Sonsorol Islands
. Pulo Anna
North
Pacific
Ocean
* Merir
Tobi\\
r; Helen Reef
Disputes— international: none
Palmyra Atoll
(territory of the US)','7facc3199d9b88d62052aff1ffacac073c03d6b9fb4fdd743bbe4f261ff1878f','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8a78ac7c049d454f3a3b48adc905d802d35d76cffb8f37b7ac8631e87f906c0',1998,'PG','Papua New Guinea','transnational-issues',736,'Disputes— international: none
Paracel Islands
South China Sea
Amphitrite
West Send* «Treelsland Gr0up
e« Rocky Island
Lincoln
Island
Woody
Pattle „ lsland
Island
Robert Island f a ,i— Drummond Island
Money Island* Duncan ^Vu!addore
aeef
Discovery Reef*, **
_ i Bombay
Passu -• •'' Reef
Group Keah
Crescent
Triton
Island','33e0ffb5ced12671888d68f267565c142f0d1ec64bbeb576ae0f0c0cedc9747b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d115c4428f0fee1a02f2d8d87fb8ae8ca77cdbaa9b8b4192d9322066e3516258',1998,'PH','Philippines','transnational-issues',742,'Disputes— international: occupied by China, but
claimed by Taiwan and Vietnam
Disputes— international: involved in a complex
dispute over the Spratly Islands with China, Malaysia,
Taiwan, Vietnam, and possibly Brunei; claims
Malaysian state of Sabah
Illicit drugs: exports locally-produced marijuana and
hashish to East Asia, the US, and other Western
markets; serves as a transit point for heroin and
crystal methamphetamine
Pitcairn Islands
'' (dependent territory
of the UK)
O 50 lOO Km
6 50 100 ml
0 Sandy
Oeno
ADAMSTOWN
★
^^.Bounty
Pitcairn Bay
o Henderson
Dude c
South Pacific Ocean
Disputes— international: none
376
Disputes— international: all of the Spratly Islands
are claimed by China, Taiwan, and Vietnam; parts of
them are claimed by Malaysia and the Philippines; in
1984, Brunei established an exclusive fishing zone,
which encompasses Louisa Reef in the southern
Spratly Islands, but has not publicly claimed the island
436','6b4d12f40f45b2bd39bc883ee26c8bd39d3489bab8af49c862905aa76fdd7c39','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47aa7d6a915ebccab16a584f7ac7029818fe4b78528943cd69f40ee57880e936',1998,'PL','Poland','transnational-issues',749,'G e o g r a p h y
Location: Central Europe, east of Germany
Geographic coordinates: 52 00 N, 20 00 E
Map references: Europe
Area:
total: 31 2,683 sq km
land: 304,51 Osq km
water: 8,173 sq km
Area-comparative: slightly smaller than New
established— 27 July 1991
aim— to form an economic and political
cooperation group for the region between the
Adriatic and the Baltic Seas
members— ( 16) Albania, Austria, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Hungary,
Italy, The Former Yugoslav Republic of Macedonia, Moldova, Poland, Romania, Slovakia, Slovenia, Ukraine
centrally planned economies
a term applied mainly to the traditionally communist states that looked to the former USSR for leadership; most are
now evolving toward more democratic and market-oriented systems; also known formerly as the Second World or
as the communist countries; through the 1980s, this group included Albania, Bulgaria, Cambodia, China, Cuba,
Czechoslovakia, GDR, Hungary, North Korea, Laos, Mongolia, Poland, Romania, USSR, Vietnam, Yugoslavia
Colombo Plan (CP)
members— (24) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Cambodia, Canada, Fiji, India, Indonesia,
Iran, Japan, South Korea, Laos, Malaysia, Maldives, Nepal, NZ, Pakistan, Papua New Guinea, Philippines,
address— Colombo Plan Bureau, P.O. Box 596,
12 Melbourne Avenue, Colombo 4, Sri Lanka
telephone— {94] (1) 581813, 581853, 581754
FAX— [94] (1)581754
established — 1 July 1951
aim— to promote economic and social
development in Asia and the Pacific
Singapore, Sri Lanka, Thailand, UK, US
539
Appendix C: International Organizations and Groups (continued)
Commission for Social Development
nofe — formerly Social Commission
address— Division Policy Coordination
ECOSOC Affairs, Department Policy
Coordination and Sustainable Development,
United Nations, Room S-29631, New York, NY
10017, US
telephone— ft] (212) 963 1234
FAX— [1] (212) 963 5935
established— 21 June 1946 as the Social
Commission, renamed 29 July 1966
aim— to deal, as part of the Economic and Social
Council, with social development programs of UN
members— ( 32) selected on a rotating basis from all regions
Commission on Crime Prevention and
Criminal Justice
address— Crime Prevention and Criminal
Justice Division, Vienna international Center,
P.O. Box 500, A- 1400 Vienna, Austria
telephone— [A3] (1) 21345, extension 4272
FAX-[43] (1)21 345 5898
established— 6 February 1992
aim— to provide guidance, as part of the
Economic and Social Council, on crime
prevention and criminal justice
members— (A0) selected on a rotating basis from all regions
Commission on Human Rights
address— do United Nations Office, Centre for
Human Rights, Palais des Nations, CH-1211
Geneva 10, Switzerland
telephone— [W] (22) 917 12 34, 907 12 34
FAX— [41] (22) 733 32 46
established— 18 February 1946
aim— to assist, as part of the Economic and
Social Council, with human rights programs of UN
members— (53) selected on a rotating basis from all regions
Commission on Narcotic Drugs
address— do United Nations Drug Control
Programme, Treaty Implementation and Legal
Affairs Division, P.O. Box 500, A-1400 Vienna,','df12c2b6e37e8d544bb2e36ea448f4c38d28d0edb7d7d4154d661767c1fbdd00','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec8783ff176ba7bdab8b7ffeaf09abea78466d3e3afb9189e9e6e98847223f5d',1998,'PR','Puerto Rico','transnational-issues',750,'(commonwealth associated with the US)
Disputes— international: none
506
Wake Island
: (territory of the US)
G e o g r a p h y
Location: Oceania, island in the North Pacific
Ocean, about two-thirds of the way from Hawaii to the','8f72a635d557e7730cc063f6c0785bcfd3019a508e06285cdd4c2c4e73f2218e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fedbe2c6ccae0e3a75a6fd71d242d6485bb067d04e355a2d862cdf14aabcbc56',1998,'QA','Qatar','transnational-issues',766,'Disputes— international: territorial dispute with
Bahrain over the Hawar Islands and maritime
boundary dispute with Bahrain currently before the
International Court of Justice (ICJ); in 1996, agreed
with Saudi Arabia to demarcate border per 1992
accord; that process is ongoing
385
Reunion
(overseas department
of France)','ed7ae862177312f8881d4cf895af9bcde686ace2d58ee91204856cfae489aed5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9999cc51bf28961d984cadf1cbbe50c9de14ec41b92a80f32e4e189c27a498bf',1998,'RO','Romania','transnational-issues',767,'200 ml
mum
WS
Bmm
1 V • .Sibiu Brasov
i Timisoara • 1 Galati:
aaifl
\\ ''''S n. ■ Brailar
L > Pioiestt # /
j^Tulcjla
BUCHAREST^
i J
C .. ® Const;
Giurgiu^j-^?^
(ntaf
^jjMangalia
Serbia \\
P
/ BULGARIA ^
Black
Sea
_','edfebedca41d47c97ed77cded33a812bfe05c0880dca5bee6aabf252a072fab7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31de55cfcb87800bf93e7b2c211d252ea62b18deb6901607bb904232444bb113',1998,'UA','Ukraine','transnational-issues',775,'Disputes— international: dispute with Ukraine over
continental shelf of the Black Sea under which
significant gas and oil deposits may exist; agreed in
1 997 to two-year negotiating period, after which either
party can refer dispute to the International Court of
Justice
Illicit drugs: important transshipment point for
Southwest Asian heroin transiting the Balkan route
and small amounts of Latin American cocaine bound
for Western Europe
389
Russia
Geography Natural resources: wide natural resource base
Location: Northern Asia (that part west of the Urals
is sometimes included with Europe), bordering the
Arctic Ocean, between Europe and the North Pacific
Ocean
Geographic coordinates: 60 00 N, 100 00 E
Map references: Asia
Area:
total : 17,075,200 sq km
land: 16,995,800 sq km
water: 79,400 sq km
Area— comparative: slightly less than 1 .8 times the
size of the US
Land boundaries:
total: 19,917 km
border countries: Azerbaijan 284 km, Belarus 959 km,
China (southeast) 3,605 km, China (south) 40 km,
Estonia 294 km, Finland 1 ,313 km, Georgia 723 km,
Kazakhstan 6,846 km, North Korea 19 km, Latvia 217
km, Lithuania (Kaliningrad Oblast) 227 km, Mongolia
3,441 km, Norway 167 km, Poland (Kaliningrad
Oblast) 206 km, Ukraine 1 ,576 km
Coastline: 37,653 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: ranges from steppes in the south through
humid continental in much of European Russia;
subarctic in Siberia to tundra climate in the polar north;
winters vary from cool along Black Sea coast to frigid
in Siberia; summers vary from warm in the steppes to
cool along Arctic coast
Terrain: broad plain with low hills west of Urals; vast
coniferous forest and tundra in Siberia; uplands and
mountains along southern border regions
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Mount Elbrus 5,633 m
including major deposits of oil, natural gas, coal, and
many strategic minerals, timber
note: formidable obstacles of climate, terrain, and
distance hinder exploitation of natural resources
Land use:
arable land: 8%
permanent crops: 0%
permanent pastures: 4%
forests and woodland: 46%
other: 42% (1993 est.)
Irrigated land: 40,000 sq km (1993 est.)
Natural hazards: permafrost over much of Siberia is
a major impediment to development; volcanic activity
in the Kuril Islands; volcanoes and earthquakes on the
Kamchatka Peninsula
Environment— current issues: air pollution from
heavy industry, emissions of coal-fired electric plants,
and transportation in major cities; industrial and
agricultural pollution of inland waterways and sea
coasts; deforestation; soil erosion; soil contamination
from improper application of agricultural chemicals;
scattered areas of sometimes intense radioactive
contamination
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropica! Timber 83,
Wetlands
signed, but not ratified: Air Pollution-Sulphur 94
Geography— note: largest country in the world in
terms of area but unfavorably located in relation to
major sea lanes of the world; despite its size, much of
the country lacks proper soils and climates (either too
cold or too dry) for agriculture
observers— { 7) Austria, Egypt, Israel, Italy, Poland, Slovakia, Tunisia
537
Appendix C: International Organizations and Groups (continued)
Caribbean Community and Common Market
(Caricom)
address— Caricom, P.O. Box 10827, Bank of
Guyana Building, 3rd floor, Avenue of the
Republic, Georgetown, Guyana
telephone— {592] (2) 69281 through 69289
FAX-{ 592] (2) 66091, 67816, 57341
established—* 4 July 1973
effective—'' 1 August 1973
aim— to promote economic integration and
development, especially among the less
developed countries
Caribbean Development Bank (CDB)
address— P.O. Box 408, Wildey, St. Michael,','a09baea8c154fe0dfb128342e63d76da4c5c7e3628c2e1444c846ee1139d4056','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20885ae90b75339b4d03d26ce7f1886156c669031d931911a253c7aaaaca8c15',1998,'RW','Rwanda','transnational-issues',778,'Disputes— international: two disputed sections of
the boundary with China remain to be settled; islands
of Etorofu, Kunashiri, and Shikotan and the Habomai
group occupied by the Soviet Union in 1945, now
administered by Russia, claimed by Japan; Caspian
Sea boundaries are not yet determined among
Azerbaijan, Iran, Kazakhstan, Russia, and
Turkmenistan; Estonian and Russian negotiators
reached a technical border agreement in December
Current issues: following the outbreak of genocidal
strife in Rwanda in April 1994 between Tutsi and Hutu
factions, more than 2 million refugees fled to
neighboring Burundi, Tanzania, Uganda and, Zaire,
now called Democratic Republic of the Congo;
according to the UN High Commission on Refugees,
in 1996 and early 1997 nearly 1 ,300,000 Hutus
returned to Rwanda; of these, 720,000 returned from
Democratic Republic of the Congo, 480,000 from
Tanzania, 88,000 from Burundi, and 10,000 from','5aa14b6844005b60238e6fe52c02b960ac01cc18388c4e410eebac9fb1da12a1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92bd81e8cdc0e2306500dd5430f67af127ff29690bd22b9c8e684ee3a5f2acd4',1998,'UG','Uganda','transnational-issues',786,'Disputes— international: none
Saint Helena
(dependent territory
of the UK)
|
Disputes— international: none
Saint Kitts
and Nevis','feaf35838c3b7fda12f56b3a8814e1280528bcde0b6340f81a75b916e7fe0b84','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21a3668b03b5c851630a5829020b1aa7b755ef4163e4519ca4f2815745de9eae',1998,'TT','Trinidad and Tobago','transnational-issues',794,'Disputes— international: none
Illicit drugs: transshipment points for South
American drugs destined for the US
398','43c49442a749c53a79a98bacadc8349d5e8814466170892ec3acaf4465007f29','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6533f6074ee94c306e1c930953f9bf0adc35035893da0dec7200bc12a1c005de',1998,'MQ','Martinique','transnational-issues',798,'Disputes— international: none
Illicit drugs: transit point for South American drugs
destined for the US and Europe
Saint Pierre
and Miquelon
(territorial collectivity
of France)','2ef0636f651d52461e9164b608fdc9c0ab267b0b0354c185affed1026e6b05ef','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e1704f8f6c42089ae0a4ef6c06e4ada93590c76f4c1e50015078c075187a7bc',1998,'IT','Italy','transnational-issues',810,'Disputes— international: none
Sao Tome
; and Principe
★ ★
\\ G e o graph y
Location: Western Africa, island in the Gulf of
Guinea, straddling the Equator, west of Gabon
Geographic coordinates: 1 00 N, 7 00 E
Map references: Africa
Area:
total: 960 sq km
land: 960 sq km
water: 0 sq km
Area— comparative: more than five times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 209 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; one rainy season
(October to May)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Sao Tome 2,024 m
Natural resources: fish
Land use:
arable land: 2%
permanent crops: 36%
permanent pastures: 1%
forests and woodland: NA%
other: 61% (1993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: NA
Environment— current issues: deforestation; soil
erosion and exhaustion
Environment— international agreements:
party to: Environmental Modification, Law of the Sea
signed, but not ratified: Biodiversity, Climate Change,
Desertification
Disputes— international: none
Illicit drugs: because of more stringent government
regulations, significantly less used as a
money-laundering center; transit country for and
consumer of South American cocaine and Southwest
Asian heroin
Syria
telephone— [39] (6) 54591
FAX— [39] (6) 5043463
established— HA November 1974
aim— to promote agricultural development; a UN
specialized agency
International Hydrographic Organization
(IHO)
note— name changed from International
Hydrographic Bureau on 22 September 1 970
address— BP 445, 7 avenue President J F
Kennedy, Monte Carlo MC 98011 CEDEX,','c3a80e9ab20776abb42024e4634d134a88e33cdf3cb59c52f379a3c937c41d41','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0521e5d4b4e08155b6b314c2897581fa8091b031c7733ba42203ee2a6d2bcf93',1998,'SA','Saudi Arabia','transnational-issues',818,'Disputes— international: large section of boundary
with Yemen not defined; location and status of
boundary with UAE is not final, de facto boundary
reflects 1974 agreement; Kuwaiti ownership of Qaruh
and Umm al Maradim islands is disputed by Saudi
Arabia; in 1996, agreed with Qatar to demarcate
border per 1992 accord; that process is ongoing
Illicit drugs: death penalty for traffickers; increasing
consumption of heroin and cocaine
410','9fdb3c15c22635d80c28bdd2dcf9483a8f3e4796a1c77eb706bf7e81730b6aa0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8da0ad1fca94833e4bf900067c43a32d63231e3b7aea371ec5492d133aab6b2',1998,'ML','Mali','transnational-issues',825,'Disputes— international: short section of boundary
with The Gambia is indefinite
Illicit drugs: transshipment point for Southwest and
Southeast Asian heroin moving to Europe and North
America; illicit cultivator of cannabis
412
Serbia and','aced1ff0a3b0eaad3fe06baee6ab1036bb627fe3843bb526d455a534c14bf2ff','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a5f1042a2ea64398dcdf3b5b1e1d235918a4a0d0c8c7a439d2ba1743b0f10b6',1998,'ME','Montenegro','transnational-issues',831,'Disputes— international: disputes with Bosnia and
Herzegovina over Serbian populated areas; Albanian
majority in Kosovo seeks independence from Serbian
republic; Serbia and Montenegro is disputing Croatia''s
claim to the Prevlaka Peninsula in southern Croatia
because it controls the entrance to Boka Kotorska in
Montenegro; Prevlaka is currently under observation
by the UN military observer mission in Prevlaka
(UNMOP); the border commission formed by The
Former Yugoslav Republic of Macedonia and Serbia
and Montenegro in April 1996 to resolve differences in
delineation of their mutual border has made no
progress so far
Illicit drugs: major transshipment point for
Southwest Asian heroin moving to Western Europe on
the Balkan route','5c512c98405560f8286b829495f8d9ed2579af1a281875aca02de35053061f99','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d16c7c28457a43312a391d8579cb95b1fbfcad17b9c28a0663a4110b525e65af',1998,'SC','Seychelles','transnational-issues',832,'O lOO 200 km
VICTORIA®
Les
Amirantes .
Indian Ocean
Groupe
d’Aldabra
Mahd
Coetivy 0
>S Atoll de
Cosmoledo
^ Atoll de
Farquhar
T Geography
Location: Eastern Africa, group of islands in the
Indian Ocean, northeast of Madagascar
Geographic coordinates: 4 35 S, 55 40 E
Map references: Africa
Area:
total: 455 sq km
land: 455 sq km
water: 0 sq km
Area— comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 491 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; humid; cooler season
during southeast monsoon (late May to September);
warmer season during northwest monsoon (March to
May)
Terrain: Mahe Group is granitic, narrow coastal strip,
rocky, hilly; others are coral, flat, elevated reefs
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Morne Seychellois 905 m
Natural resources: fish, copra, cinnamon trees
Land use:
arable land: 2%
permanent crops: 13%
permanent pastures: NA%
forests and woodland: 11%
other: 74% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: lies outside the cyclone belt, so
severe storms are rare; short droughts possible
Environment— current issues: water supply
depends on catchments to collect rain water
415
Seychelles (continued)
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography— note: 40 granitic and about 50
coralline islands
Disputes— international: claims Chagos
Archipelago in British Indian Ocean Territory','b15090a2c5cdfc7569b7e221a573276bf67cbeb620a32510dba52178523329d2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e3c30484e3a02496ceb42fa8c9db3c4cdeef79f6b5d9df676c9f5555f217219',1998,'SL','Sierra Leone','transnational-issues',837,'Electricity— consumption per capita: 1 ,719 kWh
(1995)
Agriculture— products: coconuts, cinnamon,
vanilla, sweet potatoes, cassava (tapioca), bananas;
broiler chickens; tuna fishing (expansion under way)
Exports:
total value: $56 A million (f.o.b., 1995)
commodities: fish, cinnamon bark, copra, petroleum
products (re-exports)
partners: France, UK, China, Germany, Japan (1993)
Imports:
total value: $238 million (c.i.f., 1995)
commodities: manufactured goods, food, petroleum
products, tobacco, beverages, machinery and
transportation equipment
partners: China, Singapore, South Africa, UK (1993)
Debt— external: $170 million (1994 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Seychelles rupee (SRe) = 100 cents
Exchange rates: Seychelles rupees (SRe) per
US$1— 5.1901 (January 1998), 5.0263 (1997),
4.9700 (1996), 4.7620 (1995), 5.0559 (1994), 5.1815
(1993)
Fiscal year: calendar year','e9f10ae91af3b85a6944031d5890b3f0c74f9f63a6ecad92c93122b56fad9a2e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d41af9e12f26abd3cbf17a28ae2c5fc1e24af17595c6decdbbfc0885f52d10bc',1998,'HR','Croatia','transnational-issues',847,'Geographic coordinates: 46 00 N, 15 00 E
Map references: Europe
Area:
total: 20,256 sq km
/and: 20,256 sq km
water: 0 sq km
Area— comparative: slightly smaller than New
rain
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Sulphur 94','3156c85a5aeaa07bd0567e74299fcc13dc2e20d6d3ce067a1815adf267b592a1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f963cb7d98bbd3ea9cca904738abce320da576c9399c9471209606f620dca5e',1998,'SB','Solomon Islands','transnational-issues',855,'Disputes— international: none
Disputes— international: most of the southern half
of the boundary with Ethiopia is a Provisional
Administrative Line; territorial dispute with Ethiopia
over the Ogaden
Pietersburg
^PRETORIA | x
Johannesburg* SWAZI
.Upington
... . . Ladysmith
.Kimberley •
r\\ irds |
Bloemfontein* >fLES •/ y
.De Aar VT '' an
East London
. Port Elizabeth
Indian
Ocean
Prince Edward Islands
not shown.
O 100 200 km
Disputes— international: Swaziland has asked
South Africa to open negotiations on reincorporating
some nearby South African territories that are
populated by ethnic Swazis or that were long ago part
of the Swazi Kingdom
Illicit drugs: transshipment center for heroin and
cocaine; cocaine consumption on the rise; world''s
largest market for illicit methaqualone, usually
imported illegally from India through various east
African countries; illicit cultivation of marijuana
432
South Georgia
; and the South
Sandwich Islands
I: (dependent territory of the UK,
? also claimed by Argentina)
Shag Rocks
are not shown.
O 100 200 km
6 lOO 200 mi
South Georgia
Island °
South
Atlantic Ocean
Clerke °
Rocks
Traversay 0
Islands °fl
Scotia Sea
South
Sandwich Saunders l.°
lslands Montagu 1.0
Administered by U.K.,
claimed by ARGENTINA.
Bristol l.°
Southern ''
Thule
Disputes— international: claimed by Argentina
433','0510eb2d0333ef91688549385d8d1d3fd08ba13627f389d8bebe13c842fff5f7','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57604578b8469110839243d7414507c50937a650af050cecbac4ae0f059c9c83',1998,'SR','Suriname','transnational-issues',867,'Disputes— international: administrative boundary
with Kenya does not coincide with international
boundary; administrative boundary with Egypt does
not coincide with international boundary creating the
"Hala''ib Triangle," a barren area of 20,580 sq km','2c549ed57f505b821d34f5a124baa23f13fb38748abd3919f7ae08299c129b1e','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2689ad4717de0fa2f13acea8da199ae819d12df90d487f6799a7652af5618942',1998,'ZW','Zimbabwe','transnational-issues',874,'Tanzania
Disputes— international: most of the boundary with
China in dispute; territorial dispute with Kyrgyzstan on
northern boundary in Isfara Valley area
Illicit drugs: limited illicit cultivation of cannabis and
opium poppy, mostly for domestic consumption;
increasingly used as transshipment point for illicit
drugs from Southwest Asia to Russia and Western
Europe
Disputes— international: dispute with Malawi over
the boundary in Lake Nyasa (Lake Malawi);
Democratic Republic of the Congo-Tanzania-Zambia
tripoint in Lake Tanganyika may no longer be
indefinite since it has been informally reported that the
indefinite section of the Democratic Republic of the
Congo-Zambia boundary has been settled
Illicit drugs: growing role in transshipment of
Southwest and Southeast Asian heroin and South
American cocaine destined for European and US
markets and of South Asian methaqualone bound for
Southern Africa
459
International Court of Justice (ICJ)
note— also known as the World Court
address— Peace Palace, NL-2517 KJ The
Hague, Netherlands
telephone— {3}] (70) 302 23 23
FAX— {31] (70) 364 99 28
established— 26 June 1945
effective— 24 October 1945
a/m — primary judicial organ of the UN
subbureaus— (176) Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
subbureaus — (11) American Samoa, Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Gibraltar, Hong
Kong, Macau, Montserrat, Puerto Rico, Turks and Caicos Islands
International Criminal Police Organization
(Interpol)
address— BP 6041 , F-6941 1 Lyon CEDEX 06,
World Court
see International Court of Justice (ICJ)
World Customs Organization (WCO)
see Customs Cooperation Council (CCC)
World Federation of Trade Unions (WFTU)
address— Branicka 112, 14000 Prague 4, Czech
Republic
telephone— [42] (2) 46 21 40, 46 20 85, 46 29 61
FAX— [42] (2) 46 13 78
established— 3 October 1945
aim— to promote the trade union movement
members— {125 and the Palestine Liberation Organization) Afghanistan, Albania, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Benin, Bolivia,
Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon, Canada, Chile, Colombia, Democratic Republic
of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic, Djibouti, Dominican
Republic, Ecuador, Egypt, El Salvador, Eritrea, Ethiopia, Fiji, Finland, France, French Guiana, The Gambia, Ghana,
Greece, Guadeloupe, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India, Indonesia,
Iran, Iraq, Jamaica, Japan, Jordan, Kazakhstan, North Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia,
Libya, Madagascar, Malawi, Malaysia, Mali, Martinique, Mauritius, Mexico, Mozambique, Nepal, New Caledonia,
NZ, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal, Puerto Rico,
Reunion, Romania, Russia, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the Grenadines, Saudi
Arabia, Senegal, Sierra Leone, Slovakia, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Sweden, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zimbabwe, Palestine Liberation Organization
World Food Council (WFC)
established 1 7 December 1 974; to study world food problems and to recommend solutions; ECOSOC organization;
there were 36 members selected on a rotating basis from all regions; subsumed by the World Food Program and
Food and Agriculture Organization
World Food Program (WFP)
members— (36) selected on a rotating basis from all regions
address— \\f ia Cristoforo Colombo 426, 1-00145
Rome, Italy
telephone— [39] (6) 522821
FAX— {39] (6) 5123700, 5133537, 52282840
established— 24 November 1 961
aim— to provide food aid in support of economic
development or disaster relief; an ECOSOC
organization
578
World Health Organization (WHO)
address— CH-1 211 Geneva 27, Switzerland
telephone— [4]] (22) 791 21 11, 791 32 23
FAY— [41] (22) 791 07 46
established— 22 July 1946
effective— 7 April 1948
aim— to deal with health matters worldwide; a
UN specialized agency
World Intellectual Property Organization
(WIPO)
address— 34 chemin des Colombettes, Case
Postale 18, CH-1211 Geneva 20, Switzerland
telephone— [41] (22) 730 9111
FAX— [41] (22) 733 5428
established— 14 July 1967
effective— 26 April 1970
aim— to furnish protection for literary, artistic,
and scientific works; a UN specialized agency
World Meteorological Organization (WMO)
address— Case Postale 2300, 41 Av
Giuseppe-Motta, CH-1211 Geneva 2,
associate members— (2) Puerto Rico, Tokelau
members— (161) Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Centra! African Republic, Chad,
Chile, China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, North Korea, South Korea, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, San Marino, Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Tajikistan, Tanzania, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
members— (184) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, British Caribbean Territories, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, French Polynesia, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau,
The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, Netherlands Antilles, New Caledonia, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Lucia, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia (suspended), Zambia, Zimbabwe
579
Appendix C: International Organizations and Groups (continued)
World Tourism Organization (WToO)
address— Calle Capitan Haya 42, 28020
Madrid, Spain
telephone— { 34] (1) 571 06 28
FAX— [34] (1) 571 37 33
established— 2 January 1975
aim— to promote tourism as a means of
contributing to economic development,
international understanding, and peace
World Trade Organization (WTrO)
note— succeeded General Agreement on Tariff
and Trade (GATT)
address— Centre William Rappard, 154 rue de
Lausanne, CH-1211 Geneva 21, Switzerland
fe/ep/rone— [41](22)739 51 11
FAX— [41] (22) 739 54 58
established— 15 April 1994
effective— I January 1995
aim— to provide a means to resolve trade
conflicts between members and to carry on
negotiations with the goal of further lowering
and/or eliminating tariffs and other trade barriers
Zangger Committee (ZC)
established— early 1 970s
aim— to establish guidelines for the export
control provisions of the Nonproliferation of
Nuclear Weapons T reaty (NPT)
members— (131) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Austria, Bangladesh, Belgium, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Ethiopia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Haiti, Hungary, India, Indonesia, Iran, Iraq, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Lebanon,
Lesotho, Libya, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Nepal, Netherlands, Nicaragua,
Niger, Nigeria, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia, Rwanda, San
Marino, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri
Lanka, Sudan, Switzerland, Syria, Tanzania, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE, US, Uruguay,
Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members— (4) Aruba, Macau, Madeira Islands, Netherlands Antilles
observer— (1) Holy See _ _ i _
members— (139) Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, Bahrain, Bangladesh,
Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cameroon, Canada, Central African Republic, Chad, Chile, Colombia, Democratic Republic of the Congo, Republic
of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong
Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Kenya, South Korea, Kuwait,
Lesotho, Liechtenstein, Libya, Luxembourg, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Mongolia, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Senegal,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Uganda, UAE, UK, US, Uruguay, Venezuela, Zambia, Zimbabwe
observers— ( 5) Azerbaijan, Laos, Somalia, Tajikistan, Turkmenistan
applicants — (31) Albania, Armenia, The Bahamas, Belarus, Cambodia, Cape Verde, China, Comoros, Croatia,
Estonia, Georgia, Jordan, Kazakhstan, Kiribati, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic of
Macedonia, Moldova, Nepal, Oman, Panama, Russia, Saudi Arabia, Tuvalu, Ukraine, Uzbekistan, Vanuatu,
Vietnam, Yemen, Taiwan; note— some of these countries applied to GATT and are still under consideration for
membership in WTrO
note— the following member of GATT had not become a member of WTrO as of 1 January 1998: Yugoslavia
(suspended)
members— (29) Australia, Austria, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Japan, Luxembourg, Netherlands, Norway, Poland, Portugal, Romania,
Russia, Slovakia, South Africa, Spain, Sweden, Switzerland, UK, US
580
Appendix D:
Selected International
Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Nitrogen Oxides or Their Transboundary Fluxes
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the Reduction of Sulphur
Emissions or Their Transboundary Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further Reduction of
Sulphur Emissions
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Volatile Organic Compounds or Their Transboundary Fluxes
Antarctic-Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature— 1 December 1959
entered into force— 23 June 1 961
objective-Ao ensure that Antarctica is used for
peaceful purposes, such as, for international
cooperation in scientific research, and that it does
not become the scene or object of international
discord
parties— (43) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Chile, China, Colombia, Cuba,
Czech Republic, Denmark, Ecuador, Finland, France, Germany, Greece, Guatemala, Hungary, India, Italy,
Japan, North Korea, South Korea, Netherlands, NZ, Norway, Papua New Guinea, Peru, Poland, Romania,
Russia, Slovakia, South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US, Uruguay
Basel Convention on the Control of
Transboundary Movements of Hazardous
Wastes and Their Disposal
note— abbreviated as Hazardous Wastes
opened for signature— 22 March 1 989
entered into force— 5 May 1992
objective— to reduce transboundary movements of
wastes subject to the Convention to a minimum
consistent with the environmentally sound and
efficient management of such wastes; to minimize
the amount and toxicity of wastes generated and
ensure their environmentally sound management as
closely as possible to the source of generation; and
to assist LDCs in environmentally sound
management of the hazardous and other wastes
they generate
parties— (118) Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas, Bahrain, Bangladesh,
Barbados, Belgium, Belize, Benin, Bolivia, Brazil, Bulgaria, Burundi, Canada, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Ecuador, Egypt, El Salvador, Estonia, EU, Finland, France, The Gambia, Germany, Greece, Guatemala,
Guinea, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, South Korea,
Kuwait, Kyrgyzstan, Latvia, Lebanon, Liechtenstein, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malawi, Malaysia, Maldives, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Nigeria, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Senegal,
Seychelles, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria,
Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, UAE, UK, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified— (3) Afghanistan, Haiti, US
Biodiversity
see Convention on Biological Diversity
581
Appendix D: Selected International Environmental Agreements (continued)
Convention on Biological Diversity
note— abbreviated as Biodiversity
opened for signature— 5 June 1992
entered into force— 29 December 1993
objective— to develop national strategies for the
conservation and sustainable use of biological
diversity
parties— (173) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda,
Ukraine, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified-jt 2) Afghanistan, Azerbaijan, Kuwait, Liberia, Libya, Malta, Sao
Tome and Principe, Thailand, Tuvalu, UAE, US, former Yugoslavia
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on Climate Change
Convention on Fishing and Conservation of
Living Resources of the High Seas
note— abbreviated as Marine Life Conservation
opened for signature— 29 April 1 958
entered into force— 20 March 1 966
objective— to solve through international
cooperation the problems involved in the
conservation of living resources of the high seas,
considering that because of the development of
modern technology some of these resources are in
danger of being overexploited
parties— ( 37) Australia, Belgium, Bosnia and Herzegovina, Burkina Faso, Cambodia, Colombia, Denmark,
Dominican Republic, Fiji, Finland, France, Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia,
Mauritius, Mexico, Netherlands, Nigeria, Portugal, Senegal, Sierra Leone, Solomon Islands, South Africa, Spain,
Switzerland, Thailand, Tonga, Trinidad and Tobago, Uganda, UK, US, Venezuela, former Yugoslavia
countries that have signed, but not yet ratified— (21) Afghanistan, Argentina, Bolivia, Canada, Costa Rica, Cuba,
Ghana, Iceland, Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ, Pakistan, Panama, Sri Lanka,
Tunisia, Uruguay
Convention on Long-Range Transboundary Air
Pollution
note— abbreviated as Air Pollution
opened for signature — 1 3 November 1 979
entered into force— 16 March 1983
objective— to protect the human environment
against air pollution and to gradually reduce and
prevent air pollution, including long-range
transboundary air pollution
parties— { 43) Armenia, Austria, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, EU, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova,
Netherlands, Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland,
Turkey, Ukraine, UK, US, former Yugoslavia
countries that have signed, but not yet ratified— (2) Holy See, San Marino
Convention on the International Trade in
Endangered Species of Wild Flora and Fauna
(CITES)
note— abbreviated as Endangered Species
opened for signature— 3 March 1973
entered into force— 1 July 1975
objective— to protect certain endangered species
from overexploitation by means of a system of
import/export permits
parties— (134) Afghanistan, Algeria, Argentina, Australia, Austria, The Bahamas, Bangladesh, Barbados,
Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cameroon, Canada,
Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic
of the Congo, Costa Rica, Cote d’Ivoire, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eri','c4730f2cdbd806b3465291830476d4ce744692fb786022818a34743a9e394e5c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1a74c271d49585a5d4d1273f11fd1c64913f4d26cd926cf7e0379bc792811d3',1998,'ZW','Zimbabwe','transnational-issues',875,'trea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Guyana, Honduras,
Hungary, India, Indonesia, Iran, Israel, Italy, Japan, Jordan, Kenya, Kiribati, South Korea, Liberia, Liechtenstein,
Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritius, Mexico, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Tuvalu, Uganda, UAE, UK, US, Uruguay, Vanuatu,
Venezuela, Vietnam, Zambia, Zimbabwe
countries that have signed, but not yet ratified— {A) Cambodia, Ireland, Kuwait, Lesotho _
582
Convention on the Prevention of Marine
Pollution by Dumping Wastes and Other Matter
(London Convention)
note— abbreviated as Marine Dumping
opened for signature— 29 December 1972
entered into force— 30 August 1975
objective— to control pollution of the sea by dumping
and to encourage regional agreements
supplementary to the Convention
parties— { 77) Afghanistan, Antigua and Barbuda, Argentina, Australia, Barbados, Belarus, Belgium, Belize,
Bosnia and Herzegovina, Brazil, Canada, Cape Verde, Chile, China, Democratic Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Denmark, Dominican Republic, Egypt, EU, Finland, France, Gabon,
Germany, Greece, Guatemala, Haiti, Honduras, Hungary, Iceland, Ireland, Italy, Jamaica, Japan, Jordan,
Kenya, Kiribati, Libya, Luxembourg, Malta, Mexico, Monaco, Morocco, Nauru, Netherlands, NZ, Nigeria,
Norway, Oman, Panama, Papua New Guinea, Philippines, Poland, Portugal, Russia, Saint Lucia, Seychelles,
Slovenia, Solomon Islands, South Africa, Spain, Suriname, Sweden, Switzerland, Tonga, Tunisia, Tuvalu,
Ukraine, UAE, UK, US, Vanuatu, former Yugoslavia
Convention on the Prohibition of Military or Any
Other Hostile Use of Environmental Modification
Techniques
note— abbreviated as Environmental Modification
opened for signature—'' 1 0 December 1 976
entered into force— 6 October 1978
objective— to prohibit the military or other hostile use
of environmental modification techniques in order to
further world peace and trust among nations
parties— { 64) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Bangladesh, Belarus,
Belgium, Benin, Brazil, Bulgaria, Canada, Cape Verde, Chile, Costa Rica, Cuba, Cyprus, Czech Republic,
Denmark, Dominica, Egypt, Finland, Germany, Ghana, Greece, Guatemala, Hungary, India, Ireland, Italy,
Japan, North Korea, South Korea, Kuwait, Laos, Malawi, Mauritius, Mongolia, Netherlands, NZ, Niger, Norway,
Pakistan, Papua New Guinea, Poland, Romania, Russia, Saint Lucia, Sao Tome and Principe, Slovakia,
Solomon Islands, Spain, Sri Lanka, Sweden, Switzerland, Tunisia, Ukraine, UK, US, Uruguay, Uzbekistan,
Vietnam, Yemen
countries that have signed, but not yet ratified— (17) Bolivia, Democratic Republic of the Congo, Ethiopia, Holy
See, Iceland, Iran, Iraq, Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal, Sierra Leone, Syria,
Turkey, Uganda
Convention on Wetlands of International
Importance Especially as Waterfowl Habitat
(Ramsar)
note— abbreviated as Wetlands
opened for signature— 2 February 1971
entered into force— 21 December 1975
objective— to stem the progressive encroachment
on and loss of wetlands now and in the future,
recognizing the fundamental ecological functions of
wetlands and their economic, cultural, scientific, and
recreational value
parties— ( 97) Albania, Algeria, Argentina, Armenia, Australia, Austria, Bangladesh, Belgium, Bolivia, Brazil,
Bulgaria, Burkina Faso, Canada, Chad, Chile, China, Democratic Republic of the Congo, Costa Rica, Cote
d’Ivoire, Croatia, Czech Republic, Denmark, Ecuador, Egypt, Estonia, Finland, France, Gabon, The Gambia,
Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Ireland, Israel, Italy, Japan, Jordan, Kenya, Latvia, Lesotho, Liechtenstein, Lithuania, Malawi, Mali, Malta,
Mauritania, Mexico, Morocco, Namibia, Netherlands, NZ, Niger, Norway, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia, Senegal, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Suriname, Sweden, Switzerland, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda,
UK, US, Uruguay, Venezuela, Vietnam, former Yugoslavia, Zambia
Desertification
see United Nations Convention to Combat Desertification in those Countries Experiencing Serious Drought and /
or Desertification, Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild Flora and Fauna (CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use of Environmental Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of Hazardous Wastes and Their Disposal
International Convention for the Regulation of
Whaling
note— abbreviated as Whaling
opened for signature— 2 December 1946
entered into force— 1 0 November 1 948
objective— to protect all species of whales from
overhunting; to establish a system of international
regulation for the whale fisheries to ensure proper
conservation and development of whale stocks; and
to safeguard for future generations the great natural
resources represented by whale stocks
parties— ( 57) Antigua and Barbuda, Austria, The Bahamas, Barbados, Belize, Brazil, Brunei, Canada, Cyprus,
Denmark (including Greenland), Dominica, Ecuador, Egypt, Fiji, Finland, France, The Gambia, Ghana,
Grenada, Guyana, Ireland, Italy, Jamaica, Kiribati, Latvia, Malaysia, Malta, Mauritius, Mexico, Monaco,
Netherlands (Netherlands also extended the convention to Netherlands Antilles), NZ, Nicaragua, Nigeria,
Norway, Poland, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Seychelles, Sierra Leone,
Slovakia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Switzerland, Tanzania, Tonga,
Trinidad and Tobago, Turkey, Tuvalu, UK, US, former Yugoslavia
International Tropical Timber Agreement, 1983
note— abbreviated as Tropical Timber 83
opened for signature— 18 November 1983
entered into force — 1 April 1 985; this agreement will
expire when the International Tropical Timber
Agreement, 1994, goes into force
objective— to provide an effective framework for
cooperation between tropical timber producers and
consumers and to encourage the development of
national policies aimed at sustainable utilization and
conservation of tropical forests and their genetic
resources
parties— (54) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cameroon, Canada, China, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Denmark, Ecuador, Egypt, EU, Fiji,
Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan,
South Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua New Guinea,
Peru, Philippines, Portugal, Russia, Spain, Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US,
Venezuela
583
Appendix D: Selected International Environmental Agreements (continued)
International Tropical Timber Agreement, 1994
note— abbreviated as Tropical Timber 94
opened for signature— 26 January 1 994, but not yet
in force
objective— to ensure that by the year 2000 exports
of tropical timber originate from sustainably
managed sources; to establish a fund to assist
tropical timber producers in obtaining the resources
necessary to reach this objective
parties— (51) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cambodia, Cameroon, Canada, Central African
Republic, China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Denmark,
Ecuador, Egypt, EU, Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras, India,
Indonesia, Japan, South Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama,
Papua New Guinea, Peru, Philippines, Spain, Sweden, Switzerland, Thailand, Togo, UK, US, Venezuela
countries that have signed, but not yet ratified— (3) Ireland, Italy, Portugal
Kyoto Protocol to the United Nations Framework
Convention on Climate Change
note— abbreviated as Climate Change-Kyoto
Protocol
opened for signature— 1 6 March 1 998, but not yet in
force
objective— to further reduce greenhouse gas
emissions by enhancing the national programs of
developed countries aimed at this goal and by
establishing percentage reduction targets for the
developed countries
parties— { 0)
countries that have signed, but not yet ratified— ( 12) Antigua and Barbuda, Argentina, Maldives, Malta, Marshall
Islands, Federated States of Micronesia, Philippines, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Seychelles, Switzerland
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter (London
Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the High Seas
Montreal Protocol on Substances That Deplete
the Ozone Layer
note— abbreviated as Ozone Layer Protection
opened for signature— 1 6 September 1 987
entered into force— 1 January 1989
objective— to protect the ozone layer by controlling
emissions of substances that deplete it
parties— (165) Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cameroon, Canada, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guyana, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Latvia, Lebanon, Lesotho, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal
(Portugal has also extended the protocol to Macau), Qatar, Romania, Russia, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Saudi Arabia, Senegal, Seychelles, Singapore, Slovakia, Slovenia,
Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, former Yugoslavia,
Zambia, Zimbabwe
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International
Convention for the Prevention of Pollution From
Ships, 1973 (MARPOL)
note— abbreviated as Ship Pollution
opened for signature— 17 February 1978
entered into force— 2 October 1 983
objective— to preserve the marine environment
through the complete elimination of pollution by oil
and other harmful substances and the minimization
of accidental discharge of such substances
parties— ( 96) Algeria, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas, Barbados, Belgium,
Belize, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada, Chile, China, Colombia, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Ecuador, Egypt, Equatorial Guinea, Estonia, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Ireland,
Israel, Italy, Jamaica, Japan, Kazakhstan, Kenya, North Korea, South Korea, Latvia, Lebanon, Liberia,
Lithuania, Luxembourg, Malta, Marshall Islands, Mauritius, Mexico, Monaco, Morocco, Netherlands, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Peru, Poland, Portugal, Romania, Russia, Saint Vincent and the
Grenadines, Seychelles, Singapore, Slovakia, Slovenia, South Africa, Spain, Suriname, Sweden, Switzerland,
Syria, Togo, Tonga, Tunisia, Turkey, Tuvalu, Ukraine, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, former
Yugoslavia
584
Protocol on Environmental Protection to the
Antarctic Treaty
note— abbreviated as Antarctic-Environmental
Protocol
opened for signature— 4 October 1991
entered into force— 1 4 January 1 998
objective— to enhance the protection of the
Antarctic environment and dependent and
associated ecosystems
parties— ( 27) Argentina, Australia, Belgium, Brazil, Chile, China, Ecuador, Finland, France, Germany, Greece,
India, Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa, Spain, Sweden,
UK, US, Uruguay
countries that have signed, but not yet ratified— (16) Austria, Bulgaria, Canada, Colombia, Cuba, Czech
Republic, Denmark, Guatemala, Hungary, North Korea, Papua New Guinea, Romania, Slovakia, Switzerland,
Turkey, Ukraine
Protocol to the 1979 Convention on Long-Range
Transboundary Air Pollution Concerning the
Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
parties— { 25) Austria, Belarus, Bulgaria, Canada, Czech Republic, Denmark, EU, Finland, France, Germany,
Hungary, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia, Spain, Sweden,
Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified— (3) Belgium, Greece, Poland
note— abbreviated as Air Pollution-Nitrogen Oxides
opened for signature— 31 October 1988
entered into force— 14 February 1991
objective— to provide for the control or reduction of
nitrogen oxides and their transboundary fluxes
Protocol to the 1 979 Convention on Long-Range
Transboundary Air Pollution Concerning the
Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
parties— (17) Austria, Bulgaria, Czech Republic, Denmark, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified— (7) Belgium, Canada, EU, Greece, Portugal, Ukraine, US
note— abbreviated as Air Pollution-Volatile Organic
Compounds
opened for signature— 1 8 November 1991, but not
yet in force
objective— to provide for the control and reduction of
emissions of volatile organic compounds in order to
reduce their transboundary fluxes so as to protect
human health and the environment from adverse
effects
Protocol to the 1 979 Convention on Long-Range
Transboundary Air Pollution on Further
Reduction of Sulphur Emissions
note-abbreviated as Air Pollution-Sulphur 94
opened for signature— 14 June 1994, but not yet in
force
objective— to provide for a further reduction in sulfur
emissions or transboundary fluxes
parties— (14) Canada, Czech Republic, Denmark, France, Greece, Liechtenstein, Luxembourg, Netherlands,
Norway, Slovakia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified— (14) Austria, Belgium, Bulgaria, Croatia, EU, Finland, Germany,
Hungary, Ireland, Italy, Poland, Russia, Slovenia, Ukraine
Protocol to the 1979 Convention on Long-Range
Transboundary Air Pollution on the Reduction of
Sulphur Emissions or Their Transboundary
Fluxes by at Least 30%
parties— (21) Austria, Belarus, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Finland, France,
Germany, Hungary, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia, Sweden,
Switzerland, Ukraine
note— abbreviated as Air Pollution-Sulphur 85
opened for signature— 8 July 1 985
entered into force— 2 September 1987
objective— to provide for a 30% reduction in sulfur
emissions or transboundary fluxes by 1 993
Ship Pollution
see Protocol of 1978 Relating to the International Convention for the Prevention of Pollution From Ships, 1973
(MARPOL)
585
Appendix D: Selected International Environmental Agreements (continued)
Treaty Banning Nuclear Weapon Tests in the
Atmosphere, in Outer Space, and Under Water
note— abbreviated as Nuclear Test Ban
opened for signature— 5 August 1 963
entered into force— 1 0 October 1 963
objective- to obtain an agreement on general and
complete disarmament under strict international
control in accordance with the objectives of the
United Nations; to put an end to the armaments race
and eliminate incentives for the production and
testing of all kinds of weapons, including nuclear
weapons
parties— ( 125) Afghanistan, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The Bahamas,
Bangladesh, Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burma, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of
the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece,
Guatemala, Guinea-Bissau, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait, Laos, Lebanon, Liberia, Libya, Luxembourg,
Madagascar, Malawi, Malaysia, Malta, Mauritania, Mauritius, Mexico, Mongolia, Morocco, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland,
Romania, Russia, Rwanda, Samoa, San Marino, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela,
Yemen, former Yugoslavia, Zambia
countries that have signed, but not yet ratified— (11) Algeria, Burkina Faso, Burundi, Cameroon, Ethiopia, Haiti,
Mali, Paraguay, Portugal, Somalia, Vietnam
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law of the
Sea (LOS)
note— abbreviated as Law of the Sea
opened for signature— 10 December 1982
entered into force— 16 November 1994
objective— to set up a comprehensive new legal
regime for the sea and oceans; to include rules
concerning environmental standards as well as
enforcement provisions dealing with pollution of the
marine environment
parties— (125) Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas, Bahrain,
Barbados, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burma,
Cameroon, Cape Verde, Chile, China, Comoros, Democratic Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominica, Egypt, Equatorial Guinea, EU, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Iceland, India, Indonesia, Iraq, Ireland, Italy, Jamaica, Japan, Jordan,
Kenya, South Korea, Kuwait, Lebanon, The Former Yugoslav Republic of Macedonia, Malaysia, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Monaco, Mongolia,
Mozambique, Namibia, Nauru, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Philippines, Portugal, Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Sweden, Tanzania, Togo,
Tonga, Trinidad and Tobago, Tunisia, Uganda, UK, Uruguay, Vietnam, Yemen, former Yugoslavia, Zambia,
countries that have signed, but not yet ratified— (46) Afghanistan, Bangladesh, Belarus, Belgium, Bhutan,
Burkina Faso, Burundi, Cambodia, Canada, Central African Republic, Chad, Colombia, Republic of the Congo,
Denmark, Dominican Republic, El Salvador, Ethiopia, Hungary, Iran, North Korea, Laos, Lesotho, Liberia, Libya,
Liechtenstein, Luxembourg, Madagascar, Malawi, Maldives, Morocco, Nepal, Nicaragua, Niger, Niue, Poland,
Qatar, Rwanda, Suriname, Swaziland, Switzerland, Thailand, Tuvalu, Ukraine, UAE, Vanuatu
United Nations Convention to Combat
Desertification in Those Countries Experiencing
Serious Drought and/or Desertification,
Particularly in Africa
note— abbreviated as Desertification
opened for signature — 1 4 October 1 994
entered into force— 26 December 1996
objective— to combat desertification and mitigate
the effects of drought through national action
programs that incorporate long-term strategies
supported by international cooperation and
partnership arrangements
parties— { 124) Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Austria, Bahrain,
Bangladesh, Barbados, Belgium, Benin, Bolivia, Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Comoros, Democratic Republic
of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, EU, Finland, France, Gabon, The Gambia, Germany,
Ghana, Greece, Grenada, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Iceland, India, Iran, Ireland, Israel,
Italy, Jamaica, Jordan, Kazakhstan, Kenya, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya,
Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, Nicaragua, Niger, Nigeria, Norway,
Oman, Pakistan, Panama, Paraguay, Peru, Portugal, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Saudi Arabia, Senegal, Seychelles, Sierra Leone, South Africa, Spain, Sudan, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UK, Uzbekistan,
Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (12) Australia, Colombia, Republic of the Congo, Croatia,
Georgia, Indonesia, South Korea, Philippines, Rwanda, Sao Tome and Principe, US, Vanuatu
586
United Nations Framework Convention on
Climate Change
note— abbreviated as Climate Change
opened for signature— 9 May 1992
entered into force— 21 March 1994
objective— to achieve stabilization of greenhouse
gas concentrations in the atmosphere at a low
enough level to prevent dangerous anthropogenic
interference with the climate system
parties— (174) Albania, Algeria, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denm','7b1433017c56c2cd810e67623e5ade6b12d1a9995aa1891b27dc21b9b776be10','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('545d03186b96a17f3bae6c53b71ad53e1de833dd13aecfd0d79a119ae2b51b36',1998,'ZW','Zimbabwe','transnational-issues',876,'ark, Djibouti, Dominica, Ecuador,
Egypt, El Salvador, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea,
South Korea, Kuwait, Laos, Latvia, Lebanon, Lesotho, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago,
Tunisia, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, former Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (9) Afghanistan, Angola, Belarus, Dominican Republic, Liberia,
Libya, Madagascar, Rwanda, SaoTome and Principe
Wetlands
see Convention on Wetlands of International Importance Especially As Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling
587
Appendix E:
Weights and Measures
Mathematical Notation Mathematical Power
1018 or 1,000,000,000,000,000,000
one quintillion
1015 or 1,000,000,000,000,000
one quadrillion
1012 or 1,000,000,000,000
one trillion
109 or 1 ,000,000,000
one billion
108 or 1,000,000
one million
103 or 1,000
one thousand
102 or 100
one hundred
101 or 10
ten
10° or 1
one
10-’ or 0.1
one-tenth
1 0''2 or 0.01
one-hundredth
10-3 or 0.001
one-thousandth
IO6 or 0.000 001
one-millionth
1 0''9 or 0.000 000 001
one-billionth
10-12 or 0.000 000 000 001
one-trillionth
10''15 or 0.000 000 000 000 001
one-quadrillionth
1 0''18 or 0.000 000 000 000 000 001 one-quintillionth
Metric Interrelationships Prefix Symbol Length, Area Volume
weight, or
capacity
exa
E
1018
1Q36
1054
peta
P
1015
1030
1045
tera
T
1012
1024
1Q36
giga
G
109
1018
1027
mega
M
106
1012
IO18
hectokilo
hk
105
1010
1015
myria
ma
104
108
1012
kilo
k
103
106
109
hecto
h
102
104
106
basic unit
1 meter,
1 gram,
1 liter
1 meter2
1 meter3
deci
d
io-1
io-2
io-3
centi
c
io-2
io-4
io-6
milli
m
IO3
io-6
io-9
decimilli
dm
io-4
io-8
io-12
centimilli
cm
io-5
io-10
io-15
micro
u
io-6
io-12
10-i8
nano
n
io-9
io-18
io-27
pico
P
10-12
io-24
10-36
femto
f
io-15
IQ-30
io-45
atto
a
10-18
10-3e
io-54
588
Conversion Factors To Convert From
To
Multiply by
acres
ares
40.468 564 224
acres
hectares
0.404 685 642 24
acres
square feet
43,560
acres
square kilometers
0.004 046 856 422 4
acres
square meters
4,046.856 422 4
acres
square miles (statute)
0.001 562 50
acres
square yards
4,840
ares
square meters
100
ares
square yards
119.599
barrels, US beer
gallons
31
barrels, US beer
liters
117.347 77
barrels, US petroleum
gallons (British)
34.97
barrels, US petroleum
gallons (US)
42
barrels, US petroleum
liters
158.987 29
barrels, US proof spirits
gallons
40
barrels, US proof spirits
liters
151.416 47
bushels (US)
bushels (British)
0.968 9
bushels (US)
cubic feet
1.244 456
bushels (US)
cubic inches
2,150.42
bushels (US)
cubic meters
0.035 239 07
bushels (US)
cubic yards
0.046 090 96
bushels (US)
dekaliters
3.523 907
bushels (US)
dry pints
64
bushels (US)
dry quarts
32
bushels (US)
liters
35.239 070 17
bushels (US)
pecks
4
cables
fathoms
120
cables
meters
219.456
cables
yards
240
carat
milligrams
200
centimeters
feet
0.032 808 40
centimeters
inches
0.393 700 8
centimeters
meters
0.01
centimeters
yards
0.010 93613
centimeters, cubic
cubic inches
0.061 023 744
centimeters, square
square feet
0.001 076 39
centimeters, square
square inches
0.155 000 31
centimeters, square
square meters
0.000 1
centimeters, square
square yards
0.000 119 599
589
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
chains, square surveyor''s
ares
4.046 86
chains, square surveyor''s
square feet
4,356
chains, surveyor''s
feet
66
chains, surveyor’s
meters
20.1168
chains, surveyor''s
rods
4
cords of wood
cubic feet
128
cords of wood
cubic meters
3.624 556
cords of wood
cubic yards
4.740 7
cups
liquid ounces (US)
8
cups
liters
0.236 588 2
degrees Celsius
degrees Fahrenheit
multiply by 1 .8 and add 32
degrees Fahrenheit
degrees Celsius
subtract 32 and divide by 1 .8
dekaliters
bushels
0.283 775 9
dekaliters
cubic feet
0.353 146 7
dekaliters
cubic inches
610.237 4
dekaliters
dry pints
18.161 66
dekaliters
dry quarts
9.080 829 8
dekaliters
liters
10
dekaliters
pecks
1.135104
drams, avoirdupois
avoirdupois ounces
0.062 55
drams, avoirdupois
grains
27.344
drams, avoirdupois
grams
1.771 845 2
drams, troy
grains
60
drams, troy
grams
3.887 934 6
drams, troy
scruples
3
drams, troy
troy ounces
0.125
drams, liquid (US)
cubic inches
0.226
drams, liquid (US)
liquid drams (British)
1.041
drams, liquid (US)
liquid ounces
0.125
drams, liquid (US)
milliliters
3.696 69
drams, liquid (US)
minims
60
fathoms
feet
6
fathoms
meters
1.828 8
feet
centimeters
30.48
feet
inches
12
feet
kilometers
0.000 304 8
feet
meters
0.304 8
feet
statute miles
0.000 189 39
feet
yards
0.333 333 3
feet, cubic
bushels
0.803 563 95
590
Conversion Factors To Convert From
To
Multiply by
feet, cubic
cubic decimeters
28.316 847
feet, cubic
cubic inches
1,728
feet, cubic
cubic meters
0.028 316 846 592
feet, cubic
cubic yards
0.037 037 04
feet, cubic
dry pints
51.428 09
feet, cubic
dry quarts
25.714 05
feet, cubic
gallons
7.480 519
feet, cubic
gills
239.376 6
feet, cubic
liquid ounces
957.506 5
feet, cubic
liquid pints
59.844 16
feet, cubic
liquid quarts
29.922 08
feet, cubic
liters
28.316 846 592
feet, cubic
pecks
3.214 256
feet, square
acres
0.000 022 956 8
feet, square
square centimeters
929.030 4
feet, square
square decimeters
9.290 304
feet, square
square inches
144
feet, square
square meters
0.092 903 04
feet, square
square yards
0.111 111 1
furlongs
feet
660
furlongs
inches
7,920
furlongs
meters
201.168
furlongs
statute miles
0.125
furlongs
yards
220
gallons, liquid (US)
cubic feet
0.133 680 6
gallons, liquid (US)
cubic inches
231
gallons, liquid (US)
cubic meters
0.003 785 411 784
gallons, liquid (US)
cubic yards
0.004 951 13
gallons, liquid (US)
gills (US)
32
gallons, liquid (US)
liquid gallons (British)
0.832 67
gallons, liquid (US)
liquid ounces
128
gallons, liquid (US)
liquid pints
8
gallons, liquid (US)
liquid quarts
4
gallons, liquid (US)
liters
3.785 411 784
gallons, liquid (US)
milliliters
3,785.411 784
gallons, liquid (US)
minims
61,440
gills (US)
centiliters
11.829 4
gills (US)
cubic feet
0.004177 517"
gills (US)
cubic inches
7.218 75
gills (US)
gallons
0.031 25
591
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply by
gills (US)
gills (British)
0.832 67
gills (US)
liquid ounces
4
gills (US)
liquid pints
0.25
gills (US)
liquid quarts
0.125
gills (US)
liters
0.118 294 118 25
gills (US)
milliliters
118.294118 25
gills (US)
minims
1,920
grains
avoirdupois drams
0.036 571 43
grains
avoirdupois ounces
0.002 285 71
grains
avoirdupois pounds
0.000142 86
grains
grams
0.064 798 91
grains
kilograms
0.000 064 798 91
grains
milligrams
64.798 910
grains
pennyweights
0.042
grains
scruples
0.05
grains
troy drams
0.016 6
grains
troy ounces
0.002 08333
grains
troy pounds
0.000 173 61
grams
avoirdupois drams
0.564 383 39
grams
avoirdupois ounces
0.035 273 961
grams
avoirdupois pounds
0.002 204622 6
grams
grains
15.432 361
grams
kilograms
0.001
grams
milligrams
1,000
grams
troy ounces
0.032 150 746 6
grams
troy pounds
0.002 679 23
hands (height of horse)
centimeters
10.16
hands (height of horse)
inches
4
hectares
acres
2.471 053 8
hectares
square feet
107,639.1
hectares
square kilometers
0.01
hectares
square meters
10,000
hectares
square miles
0.003 861 02
hectares
square yards
11,959.90
hundredweights, long
avoirdupois pounds
112
hundredweights, long
kilograms
50.802 345
hundredweights, long
long tons
0.05
hundredweights, long
metric tons
0.050 802 345
hundredweights, long
short tons
0.056
592
Conversion Factors To Convert From
To
Multiply by
hundredweights, short
avoirdupois pounds
100
hundredweights, short
kilograms
45.359 237
hundredweights, short
long tons
0.044 642 86
hundredweights, short
metric tons
0.045 359 237
hundredweights, short
short tons
0.05
inches
centimeters
2.54
inches
feet
0.083 333 33
inches
meters
0.025 4
inches
millimeters
25.4
inches
yards
0.027 777 78
inches, cubic
bushels
0.000 465 025
inches, cubic
cubic centimeters
16.387 064
inches, cubic
cubic feet
0.000 578 703 7
inches, cubic
cubic meters
0.000 016 387 064
inches, cubic
cubic yards
0.000 021 433 47
inches, cubic
dry pints
0.029 761 6
inches, cubic
dry quarts
0.014 880 8
inches, cubic
gallons
0.004 329 0
inches, cubic
gills
0.138 5281
inches, cubic
liquid ounces
0.554 112 6
inches, cubic
liquid pints
0.034 632 03
inches, cubic
liquid quarts
0.017 316 02
inches, cubic
liters
0.016 387 064
inches, cubic
milliliters
16.387 064
inches, cubic
minims (US)
265.974 0
inches, cubic
pecks
0.001 860 10
inches, square
square centimeters
6.451 600
inches, square
square feet
0.006 944 44
inches, square
square meters
0.000 64516
inches, square
square yards
0.000 771 605
kilograms
avoirdupois drams
564.383 4
kilograms
avoirdupois ounces
35.273 962
kilograms
avoirdupois pounds
2.204 622 622
kilograms
grains
15,432.36
kilograms
grams
1,000
kilograms
long tons
0.000 984 2
kilograms
metric tons
0.001
kilograms
short hundredweights
0.022 046 23
kilograms
short tons
0.001 102 31
kilograms
troy ounces
32.150 75
593
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
kilograms
troy pounds
2.679 229
kilometers
meters
1,000
kilometers
statute miles
0.621 371 192
kilometers, square
acres
247.105 38
kilometers, square
hectares
100
kilometers, square
square meters
1,000,000
kilometers, square
statute miles
0.386 102 16
knots (nautical mi/hr)
kilometers/hour
1.852
knots (nautical mi/hr)
statute miles/hour
1.151
leagues, nautical
kilometers
5.556
leagues, nautical
nautical miles
3
leagues, statute
kilometers
4.828 032
leagues, statute
statute miles
3
links, square surveyor''s
square centimeters
404.686
links, square surveyor''s
square inches
62.726 4
links, surveyor''s
centimeters
20.1168
links, surveyor''s
chains
0.01
links, surveyor''s
inches
7.92
liters
bushels
0.028 377 59
liters
cubic feet
0.035 314 67
liters
cubic inches
61.023 74
liters
cubic meters
0.001
liters
cubic yards
0.001 307 95
liters
dekaliters
0.1
liters
dry pints
1.816166
liters
dry quarts
0.908 082 98
liters
gallons
0.264172 052
liters
gills (US)
8.453 506
liters
liquid ounces
33.814 02
liters
liquid pints
2.113 376
liters
liquid quarts
1.056 688 2
liters
milliliters
1,000
liters
pecks
0.1135104
meters
centimeters
100
meters
feet
3.280 839 895
meters
inches
39.370 079
meters
kilometers
0.001
meters
millimeters
1,000
meters
statute miles
0.000 621 371
594
Conversion Factors To Convert From
To
Multiply by
meters
yards
1.093 613 298
meters, cubic
bushels
28.377 59
meters, cubic
cubic feet
35.314 666 7
meters, cubic
cubic inches
61,023.744
meters, cubic
cubic yards
1.307 950 619
meters, cubic
gallons
264.172 05
meters, cubic
liters
1,000
meters, cubic
pecks
113.5104
meters, square
acres
0.000 247105 38
meters, square
hectares
0.000 1
meters, square
square centimeters
10,000
meters, square
square feet
10.763 910 4
meters, square
square inches
1,550.003 1
meters, square
square yards
1.195 990 046
microns
meters
0.000 001
microns
inches
0.000 039 4
mils
inches
0.001
mils
millimeters
0.025 4
miles, nautical
kilometers
1.852 0
miles, nautical
statute miles
1.150 779 4
miles, statute
centimeters
160,934.4
miles, statute
feet
5,280
miles, statute
furlongs
8
miles, statute
inches
63,360
miles, statute
kilometers
1.609 344
miles, statute
meters
1,609.344
miles, statute
rods
320
miles, statute
yards
1,760
miles, square nautical
square kilometers
3.429 904
miles, square nautical
square statute miles
1.325
miles, square statute
acres
640
miles, square statute
hectares
258.998 811 033 6
miles, square statute
sections
1
miles, square statute
square kilometers
2.589 988 110 336
miles, square statute
square nautical miles
0.755 miles
miles, square statute
square rods
102,400
milligrams
grains
0.015 432 358 35
milliliters
cubic inches
0.061 023 744
milliliters
gallons
0.000 26417
milliliters
gills (US)
0.008 453 5
milliliters
liquid ounces
0.033 814 02
595
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply by
milliliters
liquid pints
0.002 113 4
milliliters
liquid quarts
0.001 056 7
milliliters
liters
0.001
milliliters
minims
16.230 73
millimeters
inches
0.039 370 078 7
minims (US)
cubic inches
0.003 759 77
minims (US)
gills (US)
0.000 520 83
minims (US)
liquid ounces
0.002 083 33
minims (US)
milliliters
0.061 611 52
minims (US)
minims (British)
1.041
ounces, avoirdupois
avoirdupois drams
16
ounces, avoirdupois
avoirdupois pounds
0.062 5
ounces, avoirdupois
grains
437.5
ounces, avoirdupois
grams
28.349 523125
ounces, avoirdupois
kilograms
0.028 349 523 125
ounces, avoirdupois
troy ounces
0.911 458 3
ounces, avoirdupois
troy pounds
0.075 954 86
ounces, liquid (US)
cubic feet
0.001 044 38
ounces, liquid (US)
centiliters
2.957 35
ounces, liquid (US)
cubic inches
1.804 687 5
ounces, liquid (US)
gallons
0.007 812 5
ounces, liquid (US)
gills (US)
0.25
ounces, liquid (US)
liquid drams
8
ounces, liquid (US)
liquid ounces (British)
1.041
ounces, liquid (US)
liquid pints
0.062 5
ounces, liquid (US)
liquid quarts
0.031 25
ounces, liquid (US)
liters
0.029 573 53
ounces, liquid (US)
milliliters
29.573 529 6
ounces, liquid (US)
minims
480
ounces, troy
avoirdupois drams
17.554 29
ounces, troy
avoirdupois ounces
1.097 143
ounces, troy
avoirdupois pounds
0.068 571 43
ounces, troy
grains
480
ounces, troy
grams
31.103 476 8
ounces, troy
pennyweights
20
ounces, troy
troy drams
8
ounces, troy
troy pounds
0.083 333 3
paces (US)
centimeters
76.2
paces (US)
inches
30
596
Conversion Factors To Convert From
To
Multiply by
pecks (US)
bushels
0.25
pecks (US)
cubic feet
0.311 114
pecks (US)
cubic inches
537.605
pecks (US)
cubic meters
0.008 809 77
pecks (US)
cubic yards
0.011 522 74
pecks (US)
dekaliters
0.880 976 75
pecks (US)
dry pints
16
pecks (US)
dry quarts
8
pecks (US)
liters
8.809 767 5
pecks (US)
pecks (British)
0.968 9
pennyweights
grains
24
pennyweights
grams
1.555173 84
pennyweights
troy ounces
0.05
pints, dry (US)
bushels
0.015 625
pints, dry (US)
cubic feet
0.019 444 63
pints, dry (US)
cubic inches
33.600 312 5
pints, dry (US)
dekaliters
0.055 061 05
pints, dry (US)
dry pints (British)
0.968 9
pints, dry (US)
dry quarts
0.5
pints, dry (US)
liters
0.550 610 47
pints, liquid (US)
cubic feet
0.016 710 07
pints, liquid (US)
cubic inches
28.875
pints, liquid (US)
deciliters
4.731 76
pints, liquid (US)
gallons
0.125
pints, liquid (US)
gills (US)
4
pints, liquid (US)
liquid ounces
16
pints, liquid (US)
liquid pints (British)
0.832 67
pints, liquid (US)
liquid quarts
0.5
pints, liquid (US)
liters
0.473 176 473
pints, liquid (US)
milliliters
473.176 473
pints, liquid (US)
minims
7,680
points (typographical)
inches
0.013 837
points (typographical)
millimeters
0.351 459 8
pounds, avoirdupois
avoirdupois drams
256
pounds, avoirdupois
avoirdupois ounces
16
pounds, avoirdupois
grains
7,000
pounds, avoirdupois
grams
453.592 37
pounds, avoirdupois
kilograms
0.453 592 37
pounds, avoirdupois
long tons
0.000 446 428 6
pounds, avoirdupois
metric tons
0.000 453 592 37
pounds, avoirdupois
quintals
0.004 535 92
597
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply by
pounds, avoirdupois
short tons
0.000 5
pounds, avoirdupois
troy ounces
14.583 33
pounds, avoirdupois
troy pounds
1.215 278
pounds, troy
avoirdupois drams
210.651 4
pounds, troy
avoirdupois ounces
13.165 71
pounds, troy
avoirdupois pounds
0.822 857 1
pounds, troy
grains
5,760
pounds, troy
grams
373.241 721 6
pounds, troy
kilograms
0.373 241 721 6
pounds, troy
pennyweights
240
pounds, troy
troy ounces
12
quarts, dry (US)
bushels
0.031 25
quarts, dry (US)
cubic feet
0.038 889 25
quarts, dry (US)
cubic inches
67.200 625
quarts, dry (US)
dekaliters
0.1101221
quarts, dry (US)
dry pints
2
quarts, dry (US)
dry quarts (British)
0.968 9
quarts, dry (US)
liters
1.101 221
quarts, dry (US)
pecks
0.125
quarts, dry (US)
pints, dry (US)
2
quarts, liquid (US)
cubic feet
0.03342014
quarts, liquid (US)
cubic inches
57.75
quarts, liquid (US)
deciliters
9.463 53
quarts, liquid (US)
gallons
0.25
quarts, liquid (US)
gills (US)
8
quarts, liquid (US)
liquid ounces
32
quarts, liquid (US)
liquid pints (US)
2
quarts, liquid (US)
liquid quarts (British)
0.832 67
quarts, liquid (US)
liters
0.946 352 946
quarts, liquid (US)
milliliters
946.352 946
quarts, liquid (US)
minims
15,360
quintals
avoirdupois pounds
220.462 26
quintals
kilograms
100
quintals
metric tons
0.1
rods
feet
16.5
rods
meters
5.029 2
rods
yards
5.5
598
Conversion Factors To Convert From
To
Multiply by
rods, square
acres
0.006 25
rods, square
square meters
25.292 85
rods, square
square yards
30.25
scruples
grains
20
scruples
grams
1.295 978 2
scruples
troy drams
0.333
sections (US)
square kilometers
2.589 988 1
sections (US)
square statute miles
1
spans
centimeters
22.86
spans
inches
9
steres
cubic meters
1
steres
cubic yards
1.307 95
tablespoons
milliliters
14.786 76
tablespoons
teaspoons
3
teaspoons
milliliters
4.928 922
teaspoons
tablespoons
0.333 333
ton-miles, long
metric ton-kilometers
1.635 169
ton-miles, short
metric ton-kilometers
1.459 972
tons, gross register
cubic feet of permanently enclosed','914255e151a1be6f9ff9c20d5cda9a614f21946d9e4d219171b4569c1254aac4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d194d827ee5e4f046ca9b57c24ea950390b52aa63bd64ae77dd97bb82c8d0c5',1998,'TH','Thailand','transnational-issues',884,'Disputes— international: parts of the border with
Laos are indefinite; maritime boundary with Vietnam
resolved, August 1997; parts of border with Cambodia
are indefinite; maritime boundary with Cambodia not
clearly defined
Illicit drugs: a minor producer of opium, heroin, and
marijuana; major illicit transit point for heroin en route
to the international drug market from Burma and Laos;
eradication efforts have reduced the area of cannabis
cultivation and shifted some production to neighboring
countries; opium poppy cultivation has been reduced
by eradication efforts; also a drug money-laundering
center; role in amphetamine production for regional
consumption; increasing indigenous abuse of
methamphetamines and heroin
★
Location: Western Africa, bordering the Bight of
Benin, between Benin and Ghana
Geographic coordinates: 8 00 N, 1 10 E
Map references: Africa
Area:
total: 56,790 sq km
land: 54,390 sq km
water: 2,400 sq km
Area— comparative: slightly smaller than West
Virginia
Land boundaries:
total: 1 ,647 km
border countries: Benin 644 km, Burkina Faso 126
km, Ghana 877 km
Coastline: 56 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 30 nm
Climate: tropical; hot, humid in south; semiarid in
north
Terrain: gently rolling savanna in north; central hills;
southern plateau; low coastal plain with extensive
lagoons and marshes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pic Agou 986 m
Natural resources: phosphates, limestone, marble
Land use:
arable land: 38%
permanent crops: 7%
permanent pastures: 4%
forests and woodland: 17%
other: 34% (1993 est.)
Irrigated land: 70 sq km (1993 est.)
Natural hazards: hot, dry harmattan wind can
reduce visibility in north during winter; periodic
droughts
Environment— current issues: deforestation
attributable to slash-and-burn agriculture and the use
of wood for fuel; recent droughts affecting agriculture
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected
agreements
Disputes— international: none
Illicit drugs: transit hub for Nigerian heroin and
cocaine traffickers
O 1QO 200 km
O 100 200 mi
telephone— [66] (2) 2881234
FAX— [66] (2) 2881000
established— 28 March 1947 as Economic
Commission for Asia and the Far East (ECAFE)
aim— to carry out the commitment of the
Economic and Social Council of the UN to
promote economic development
Economic and Social Commission for members— (12 plus the Palestine Liberation Organization) Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Oman,
Western Asia (ESCWA) Qatar, Saudi Arabia, Syria, UAE, Yemen, Palestine Liberation Organization
address— 28 Abdel Hameed Sharaf Street, P.O.
Box 927115, Amman, Jordan
fe/eptoe— [962] (6) 694351
FAX— [962] (6) 694981,694982
established— 9 August 1973 as Economic
Commission for Western Asia (ECWA)
aim— to promote economic development as a
regional commission for the UN''s Economic and
Social Council
Economic Commission for Africa (ECA)
address— P.O. Box 3001-3005, Addis Ababa,','ad96edfc934a5944f75ae5aaf9c23afa078e8a572362a9106588cc8d692777d0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05a1843e34a5fc20f8f7308491f45f7e331a3d1def6a07eb6737d4af1edc2ab9',1998,'TK','Tokelau','transnational-issues',885,'(territory of New Zealand)
☆ *
'' ☆
o :
20 40 km
0
20 40 mi
&Atafu
South Pacific Ocean
u
Nukunonu
V |
Fakaofo
Disputes— international: none
465','04568b09027692c8d6e6aaac1d203ee3dc133fc35180d140dd6711fc2f12dcb1','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2109340ab90211558543bdbb0d578500eb3557e6315155b94019514f8944a3a9',1998,'TO','Tonga','transnational-issues',892,'O 50 100 Km
0 50 100 mi
„ Niuafo’ou
. Tafahi
Niuatoputapu ''
South Pacific Ocean
Vava’u
Group
Vava’u
Neiafu
* ,,t-Pangai
Ha’apai Group
NUKUALOFA
Tongatapu? A
Group 5
Minerva Reef not shown','7bb81dc09d49488a7884c1c5e1c8ad0de0605ba7d99b3e982b8e07a3b72267f5','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f92b4133dc1cf864b6c1992f778404c5a12b8b13ad852f3374185555f4be80f4',1998,'AF','Afghanistan','transnational-issues',894,'Turks and
Caicos islands
(dependent territory
of the UK)
North Atlantic
Ocean
North
Caicos
Blue
\\HiM
Bottle Creek
%
™ .x Middle Caicos
Providenciales
East Caicos
West
Caicos
>JG
Caicos Islands w? grand turk
Cockburn Harbour cf ^Town^iP
Ambergris Cays m ^
Caicos
T
North Atlantic
Ocean
Seal
Cays
Salt CayFtf
$
lies
0 Torres
Espiritu
Santo
0,°
O
lies
Banks
South
Pacific
Ocean
VA Aoba \\Ma6wo
Lugarwille h «
PentecdU
Ambrym
Malakula) \\
CD
X
CD
^^Forari
PORT® Efat6
VILA
Erromango fjjlpote
Cora! Tanna
See
o
Anatom
Matthew 0
Islands claimed Hunter
by FRANCE
and Vanuatu
O 75 150 km
O 75
150 mi','6b424e4bfeaa0821a2cb81121621751091261711470b418a0a01b942001a236c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7d9884f76f86886ffe05cab423af5d56653ef768314f8ecf3779fe8854466b8',1998,'AE','United Arab Emirates','transnational-issues',908,'Disputes— international: location and status of
boundary with Saudi Arabia is not final, de facto
boundary reflects 1974 agreement; no defined
boundary with most of Oman, but Administrative Line
in far north; claims two islands in the Persian Gulf
occupied by Iran: Lesser Tunb (called Tunb as Sughra
in Arabic by UAE and Jazireh-ye Tonb-e Kuchek in
Persian by Iran) and Greater Tunb (called Tunb al
Kubra in Arabic by UAE and Jazireh-ye Tonb-e
Bozorg in Persian by Iran); claims island in the
Persian Gulf jointly administered with Iran (called Abu
Musa in Arabic by UAE and Jazireh-ye Abu Musa in
Persian by Iran)— over which Iran has taken steps to
exert unilateral control since 1992, including access
restrictions and a military build-up on the island; the
UAE has garnered significant diplomatic support in
the region in protesting these Iranian actions
Illicit drugs: growing role as heroin transshipment
and money-laundering center due to its proximity to
southwest Asian producing countries and the bustling
free trade zone in Dubai
UDEAC
Union Douaniere et Economique de I''Afrique Centrale; see Central African
Customs and Economic Union (UDEAC)
UEMOA
Union economique et monetaire Ouest africaine; see West African Economic and
Monetary Union (WAEMU)
UHF
ultra-high-frequency
UK','5bb9cadd866ed90721cb30fc5e87eceb339cf50e353051d3652e2483b9c5e2f0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b383f6a33344f6444cd49ee5d4b7db2b55c2b001e9c63e78cac01f9ad13b599',1998,'UY','Uruguay','transnational-issues',917,'Disputes— international: two short sections of the
boundary with Brazil are in dispute— Arroyo de la
Invernada (Arroio Invernada) area of the Rio Cuareim
(Rio Quarai) and the islands at the confluence of the
Rio Cuareim (Rio Quarai) and the Uruguay River
495
telephone-1 598] (2) 964590
FAX-{ 598] (2) 964591
established— 26 March 1991
aim— to increase regional economic cooperation
members— (4) Argentina, Brazil, Paraguay, Uruguay
associate member— (1 ) Chile
Statistical Commission
members— (24) selected on a rotating basis from all regions
address— Division for Policy and Coordination
and ECOSOC Affairs, Department for Policy
Coordination and Sustainable Development,
United Nations, Room 2963, New York, NY
10017, US
telephone— {!] (212) 963 1234
FAX— [1 ] (212) 963 5935
established —21 June 1946
aim— to deal with development and
standardization of national statistics of interest
to the UN, as part of the Economic and Social
Council organization
Third World
another term for the less developed countries; the term is fading from use; see less developed countries (LDCs)
underdeveloped countries
refers to those less developed countries with the potential for above-average economic growth; see less developed
countries (LDCs)
undeveloped countries
refers to those extremely poor less developed countries (LDCs) with little prospect for economic growth; see least
developed countries (LLDCs)
Union Douaniere et Economique de I''Afrique
Centrale (UDEAC)
see Central African Customs and Economic Union (UDEAC)
United Nations (UN)
address— United Nations, New York, NY 10017,
US
telephone-^] (212) 963 1234
FAX— [1] (212) 963 4879
established— 26 June 1945
effective— 24 October 1945
aim— to maintain international peace and
security and to promote cooperation involving
economic, social, cultural, and humanitarian
problems
members— (184 excluding Yugoslavia) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Syria, Tajikistan, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe; note— all UN members are
represented in the General Assembly
observers— (2 plus the Palestine Liberation Organization) Holy See, Switzerland, Palestine Liberation Organization
568
United Nations Angola Verification Mission successor to original UNAVEM and UNAVEM II; established 20 December 1 988; renewed for third time 8 February
(UNAVEM ill) 1995; aim was to assist the parties in restoring peace and achieving national reconciliation in Angola on the basis
of the Peace Accords, the Lusaka Protocol, and relevant Security Council resolutions; established by the UN
Security Council; members Bangladesh, Brazil, Bulgaria, Egypt, Fiji, Guinea-Bissau, Hungary, India, Jordan,
Mongolia, Mali, Morocco, Netherlands, Nigeria, Portugal, Sweden, Tanzania, Uruguay, Zambia, Zimbabwe;
disbanded 30 June 1997
established 5 October 1993 to support and provide safe conditions for displaced persons and human rights
monitors, and to assist in training a new national police force; established by the UN Security Council; members
were Argentina, Australia, Austria, Bangladesh, Canada, Chad, Republic of the Congo, Djibouti, Fiji, Germany,
Ghana, Guinea, Guinea-Bissau, India, Jordan, Malawi, Mali, Niger, Nigeria, Pakistan, Russia, Senegal, Switzerland,
Tunisia, Uruguay, Zambia, Zimbabwe; terminated 8 March 1996
United Nations Children''s Fund (UNICEF) members— ( 36) selected on a rotating basis from all regions
note— acronym retained from the predecessor
organization UN International Children''s
Emergency Fund
address— UNICEF House, Three United
Nations Plaza, New York, NY 10017, US
telephone— [\\] (212) 326 7000
FAX— [1] (212) 888 7465, 888 7454
established— 11 December 1946
aim— to help establish child health and welfare
services
United Nations Conference on Trade and members— (1 88) all UN members plus Holy See, Switzerland, Tonga
Development (UNCTAD)
address— UNCTAD, Palais des Nations,
CH-1211 Geneva 10, Switzerland
telephone— [41] (22) 917 12 34, 907 12 34
FAX— {41] (22) 907 00 57
established— 30 December 1964
aim—t o promote international trade _
United Nations Confidence Restoration established 31 March 1 995 to separate Croatian and Krajina Serb forces; to monitor demilitarization of the Prevlaka
Operation in Croatia (UNCRO) Peninsula; to maintain a presence on Croatia''s international borders; to monitor and report the crossing of military
personnel, equipment, supplies and weapons; to facilitate delivery of humanitarian assistance; to aid refugees and
displaced persons; to protect ethnic minorities; and to clear mines; established by the UN Security Council;
members were Argentina, Bangladesh, Belgium, Brazil, Canada, Czech Republic, Denmark, Egypt, Estonia,
Finland, France, Germany, Ghana, Indonesia, Ireland, Jordan, Kenya, Lithuania, Malaysia, Nepal, Netherlands,
Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Senegal, Slovakia, Spain, Sweden, Tunisia, Turkey, Ukraine,
UK, US; disbanded January 1996
United Nations Development Program members— ( 36) selected on a rotating basis from all regions
(UNDP)
address— One United National Plaza, New
York, NY 10017, US
telephone— m (212) 906 5788, 906 5000
FAX— [1] (212) 906 5365
established— 22 November 1965
aim— to provide technical assistance to
stimulate economic and social development
United Nations Assistance Mission for
Rwanda (UNAMIR)
569
Appendix C: International Organizations and Groups (continued)
United Nations Disengagement Observer members— {A) Austria, Canada, Japan, Poland
Force (UNDOF)
address— cfo Department of Peace-keeping
Operations, United Nations, Room S-3260E,
New York, NY 10017, US
telephone— m (212) 963 1234
FAX— [1] (212) 963 4879
established— 31 May 1974
aim— to observe the 1973 Arab-lsraeli
cease-fire; established by the UN Security
Council _ _
members— (185) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Niue, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, SaoTome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu,
Uganda, Ukraine, UAE, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended),
Zambia, Zimbabwe
assodate members— (4) Aruba, British Virgin Islands, Macau, Netherlands Antilles
United Nations Environment Program members— (58) selected on a rotating basis from all regions
(UNEP)
United Nations Educational, Scientific, and
Cultural Organization (UNESCO)
address— 7 place de Fontenoy, F-75352 Paris
07SP, France
telephone— [33] (1)45 6810 00
FAX— {33] (1) 45 67 16 90
established— 16 November 1945
effective— 4 November 1946
aim— to promote cooperation in education,
science, and culture
address— P.O. Box 30552, Nairobi, Kenya
telephone— {254] (2) 230800, 520600
FAX— [254] (2) 226890
established— 15 December 1972
aim—io promote international cooperation on all
environmental matters
United Nations Force in Cyprus (UNFICYP) members— ( 8) Argentina, Australia, Austria, Canada, Finland, Hungary, Ireland, UK
address— Chief of Mission, P.O. Box 1642,
Nicosia, Cyprus
telephone— {357] (2) 359 700
FAX— [357] (2) 359 753
established— 4 March 1964
aim— to serve as a peacekeeping force between
Greek Cypriots and Turkish Cypriots in Cyprus;
established by the UN Security Council
United Nations General Assembly members— (185) all UN members are represented in the General Assembly
address— see United Nations
established— 26 June 1945
effective— 24 October 1945
aim— l o function as the primary deliberative
organ of the UN
570
members— (169) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Somalia, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
United Nations Institute for Training and
Research (UNITAR)
address— Palais des Nations, Bureau 1070,
CH-1211, Geneva 10, Switzerland
telephone— [W] (22) 798-58-50, 798-84-00
FAX— [41] (22) 733-13-83
established— 11 December 1963
aim— to help the UN become more effective
through training and research
United Nations Interim Force in Lebanon members— (9) Fiji, Finland, France, Ghana, Ireland, Italy, Nepal, Norway, Poland
(UNIFIL)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— {!] (212) 963 1234
FAX— [1] (212) 963 4879
established— 19 March 1978
aim— to confirm the withdrawal of Israeli forces,
and assist in reestablishing Lebanese authority
in southern Lebanon; established by the UN
Security Council
United Nations Iraq-Kuwait Observation
Mission (UNIKOM)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, USA
telephone— {]] (212) 963 1234
FAX-[ 1] (212) 963 4879
established— 9 April 1991
aim— to observe and monitor the demilitarized
zone established between Iraq and Kuwait;
established by the UN Security Council
members— (33) Argentina, Austria, Bangladesh, Canada, China, Denmark, Fiji, Finland, France, Germany, Ghana,
Greece, Hungary, India, Indonesia, Ireland, Italy, Kenya, Malaysia, Nigeria, Pakistan, Poland, Romania, Russia,
Senegal, Singapore, Sweden, Thailand, Turkey, UK, US, Uruguay, Venezuela
members (Board of Trustees— (17) Argentina, Australia, Austria, Cameroon, Chile, China, Egypt, France, Germany,
India, Ireland, Italy, Japan, Nigeria, Pakistan, Russia, Switzerland; note— the UN Secretary General can appoint up
to 30 members
United Nations Industrial Development
Organization (UNIDO)
address— Vienna international Center, P.O. Box
300, A- 1400 Vienna, Austria
telephone— [43] (1)211 310
FAX— [43] (1)23 21 56
established— 17 November 1966
effective— 1 January 1967
aim— UN specialized agency that promotes
industrial development especially among the
members
571
Appendix C: International Organizations and Groups (continued)
United Nations Military Observer Group in
India and Pakistan (UNMOGIP)
members— ( 8) Belgium, Chile, Denmark, Finland, Italy, South Korea, Sweden, Uruguay
address— do Department of Peace-keeping
Operations, Room 3727, United Nations, New
York, NY 10017, US
telephone— [\\] (212) 963 5721
FAX''— [1] (212) 758 2718
established— 13 August 1948
aim— to observe the 1949 India-Pakistan
cease-fire; established by the UN Security
Council
United Nations Mission for the Referendum
in Western Sahara (MINURSO)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone^ 1] (212) 963 1234
FAY— [1] (212) 963 4879
established— 29 April 1991
aim— to supervise the cease-fire and conduct a
referendum in Western Sahara; established by
the UN Security Council
members— (28) Argentina, Austria, Bangladesh, China, Egypt, El Salvador, France, Ghana, Greece, Guinea,
Honduras, Hungary, Ireland, Italy, Kenya, South Korea, Malaysia, Nigeria, Norway, Pakistan, Poland, Portugal,
Russia, Togo, Tunisia, US, Uruguay, Venezuela
United Nations Mission in Bosnia and
Herzegovina (UNMIBH)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— {t] (212) 963 1234
FAX— [1] (212) 758 2718
established— 13 December 1995
aim— to establish a UN civilian police force
(IPTF) to implement the Peace Agreement in
Bosnia
members— (39) Argentina, Austria, Bangladesh, Bulgaria, Canada, Chile, Denmark, Egypt, Estonia, Finland,
France, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Ireland, Italy, Jordan, Malaysia, Nepal,
Netherlands, Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Senegal, Spain, Sweden, Switzerland, Tunisia,
Turkey, Ukraine, UK, US
United Nations Mission in Haiti (UNMIH)
established 23 September 1993;aim was to assist in implementing the agreement to transfer power back into the
civilian government; established by the UN Security Council; became the United Nations Support Mission in Haiti
(UNSMIH) 28 June 1996 with the aim to assist in the professionalization of the Haitian National Police; members
were Algeria, Canada, France, India, Mali, Pakistan, Togo, US; disbanded 31 July 1997
United Nations Mission of Observers in
Prevlaka (UNMOP)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— {\\] (212) 963 1234
FAX-11] (212) 7582718
established— 13 December 1992
aim— to monitor the demilitarization of the
Prevlaka peninsula
members— {25) Argentina, Bangladesh, Belgium, Brazil, Canada, Czech Republic, Denmark, Egypt, Finland,
Ghana, Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia,
Sweden, Switzerland, Ukraine
572
United Nations Mission of Observers in members— { 9) Austria, Bangladesh, Bulgaria, Denmark, Jordan, Poland, Switzerland, Ukraine, Uruguay
Tajikistan (UNMOT)
address— cfo Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— (212) 963 1234
FAX— [1] (212) 758 2718
established— 16 December 1994
aim— to monitor and investigate violations of the
cease-fire of 17 September 1994 between
Tajikistan and the Tajik opposition and to assist
in the political negotiation process; established
by the UN Security Council
United Nations Observer Mission in Angola members— (17) Bangladesh, Brazil, Bulgaria, Egypt, Guinea-Bissau, Hungary, India, Jordan, Malaysia, Mali,
(MONUA) Nigeria, Portugal, Sweden, Tanzania, Uruguay, Zambia, Zimbabwe
address— do Department of Peace-keeping
operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— [\\] (212) 963 1234
FAX— [1] (212) 758 2718
established— 1 July 1997
aim— to assist in implementation of peace
agreement; oversee normalization of state
administration throughout National territory;
established by UN Security Council
United Nations Observer Mission in El
Salvador (ONUSAL)
United Nations Observer Mission in Georgia
(UNOMIG)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— [\\] (212) 963 1234
FAX— {1] (212) 963 4879
established— August 1993
aim— to verify compliance with the cease-fire
agreement, to monitor weapons exclusion zone,
and to supervise CIS peacekeeping force for
Abkhazia; established by the UN Security
Council
United Nations Observer Mission in Liberia members— { 6) Bangladesh, Egypt, India, Kenya, Malaysia, Pakistan
(UNOMIL)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephoned 1] (212) 963 1234
FAX— [1] (212) 9634879
established— 22 September 1 993
aim— to assist in the implementation of the
peace agreement; established by the UN
Security Council
members— (22) Albania, Austria, Bangladesh, Czech Republic, Denmark, Egypt, France, Germany, Greece,
Hungary, Indonesia, Jordan, South Korea, Pakistan, Poland, Russia, Sweden, Switzerland, Turkey, UK, US,
established 20 May 1 991 to verify cease-fire arrangements and to monitor the maintenance of public order pending
the organization of a new National Civil Police; established by the UN Security Council; members were Argentina,
Austria, Brazil, Canada, Chile, Colombia, France, Guyana, Ireland, Italy, Mexico, Spain, Sweden, Venezuela;
disbanded April 1995
573
Appendix C: International Organizations and Groups (continued)
United Nations Observer Mission
Uganda-Rwanda (UNOMUR)
established 1 993 for six months to monitor the Uganda/Rwanda border to verify that no military assistance reaches
Rwanda across the border; established by the UN Security Council; members were Bangladesh, Botswana, Brazil,
Hungary, Netherlands, Senegal, Slovakia, Zimbabwe; subsumed by UNAMIR
United Nations Office of the High
Commissioner for Refugees (UNHCR)
address—4 Case postale 2500, Depot, CH-1211
Geneva 2, Switzerland
telephone— [41] (22) 739 81 1 1
FAY— [41] (22) 731 95 46
established— 3 December 1 949
effective— 1 January 1951
aim— to ensure the humanitarian treatment of
refugees and find permanent solutions to
refugee problems
members— (50) Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Brazil, Canada, China, Colombia,
Democratic Republic of the Congo, Denmark, Ethiopia, Finland, France, Germany, Greece, Holy See, Hungary,
India, Iran, Israel, Italy, Japan, Lebanon, Lesotho, Madagascar, Morocco, Namibia, Netherlands, Nicaragua,
Nigeria, Norway, Pakistan, Philippines, Russia, Somalia, Spain, Sudan, Sweden, Switzerland, Tanzania, Thailand,
Tunisia, Turkey, Uganda, UK, US, Venezuela, Yugoslavia
United Nations Operation in Mozambique
(UNOMOZ)
established 16 December 1 992 to supervise the cease-fire; established by the UN Security Council; members were
Argentina, Austria, Bangladesh, Botswana, Brazil, Canada, Cape Verde, China, Czech Republic, Egypt,
Guinea-Bissau, Hungary, India, Ireland, Italy, Japan, Jordan, Malaysia, Netherlands, Norway, Portugal, Russia,
Spain, Sweden, US, Uruguay, Zambia; shut down operations 31 January 1995
United Nations Operation in Somalia
(UNOSOM II)
established 24 April 1 992 to facilitate an immediate cessation of hostilities, to maintain a cease-fire in order to
promote a political settlement, and to provide urgent humanitarian assistance; established by the UN Security
Council; members were Australia, Bangladesh, Botswana, Canada, Egypt, India, Ireland, Malaysia, Nepal, NZ,
Nigeria, Pakistan, Romania, Zimbabwe; UN peacekeepers left Somalia on 1 March 1995; some UN personnel
remain in Somalia engaged in humanitarian work
United Nations Police Mission in Haiti
(MIPONUH)
members — (11) Argentina, Benin, Canada, France, India, Mali, Niger, Senegal, Togo, Tunisia, US
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
established— ! December 1997
aim— to support the professionalization of the
Haitian National Police; established by UN
Security Council
United Nations Population Fund (UNFPA)
members— (34) selected on a rotating basis from all regions
note— acronym retained from predecessor
organization UN Fund for Population Activities
address— 220 East 42nd Street, 1 9th Floor,
Room DN-1901, New York, NY 10017, US
telephone— {t] (212) 297 5000
FAX— [1] (212) 557 6416
established— NA July 1967
aim— to assist both developed and developing
countries to deal with their population problems
United Nations Preventive Deployment Force
(UNPREDEP)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— {1] (212) 963 1234
FAY— [1] (212) 963 4879
established— 31 March 1995
aim— to monitor border activity in the Former
Yugoslav Republic of Macedonia
members— ( 27) Argentina, Bangladesh, Belgium, Brazil, Canada, Czech Republic, Denmark, Egypt, Finland,
Ghana, Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia,
Sweden, Switzerland, Turkey, Ukraine, US
574
United Nations Protection Force
(UNPROFOR)
established 28 February 1 992; to create conditions for peace and security required for the negotiation of an overall
settlement of the "Yugoslav11 crisis; established by the UN Security Council; members we','4f20e084e3bfcc59a7a4e6434e633ff75844a358a1ebdc2b4247b34fad2b016a','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1264780523441b77c4bbf4dc60aadd785583fb07cd10f98259aa63ce78693955',1998,'UY','Uruguay','transnational-issues',918,'re Bangladesh, Belgium,
Brazil, Canada, Czech Republic, Denmark, Egypt, Finland, France, Germany, Ghana, Indonesia, Ireland, Jordan,
Kenya, Malaysia, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Spain, Sweden,
Switzerland, Ukraine, UK, US; disbanded December 1 995; replaced by the Implementation Force (IFOR), which has
been replaced by the Stabilization Force (SFOR)
United Nations Relief and Works Agency for
Palestine Refugees in the Near East
(UNRWA)
members— (11) Austria, Belgium, Egypt, France, Japan, Jordan, Lebanon, Syria, Turkey, UK, US
address— Vienna International Center, P. 0.
Box 700, A-1400 Vienna, Austria
te!ephone—[ 43] (1) 21345, ext. 4531
FAX— [43] (1) 21345-5877
established— 8 December 1949
aim— to provide assistance to Palestinian
refugees
United Nations Research Institute for Social
Development (UNRISD)
members^ 10 country members, but a Board of Directors consisting of a chairman appointed by the UN secretary
general and 10 individual members
ac/c/ress — Palais des Nations, CH-121 1 Geneva
10, Switzerland
telephone— {41] (22) 798 84 00, 798 58 50
FAX— [41] (22) 740 07 91
established— 1 July 1964
aim— to conduct research into the problems of
economic development during different phases
of economic growth
United Nations Secretariat
members— the UN secretary general and staff
address— see United Nations
established— 26 June 1945
effective— 24 October 1945
aim— to serve as the primary administrative
organ of the UN; a Secretary General is
appointed for a five-year term by the General
Assembly on the recommendation of the
Security Council
United Nations Security Council
address— do United Nations, Room S-3520A,
New York, NY 10017, US
telephone— [\\] (212) 963 1234
FAX— [1] (212) 758 2718
established— 26 June 1945
effective— 24 October 1945
aim— to maintain international peace and
security
permanent members— (5) China, France, Russia, UK, US
nonpermanent members— { 1 0) elected for two-year terms by the UN General Assembly; Bahrain (1 998-99), Brazil
(1998-99), Costa Rica (1997-98), Gabon (1998-99), The Gambia (1998-99), Japan (1997-98), Kenya (1997-98), Po¬
land (1996-97), Portugal(1 997-98), Slovenia (1998-99), Sweden(1 997-98)
United Nations Transitional Administration
in Eastern Slavonia, Baranja, and Western
Sirmium (UNTAES)
established 1 2 November 1 995; aim to facilitate and supervise the Basic Agreement between the government of the
Republic of Croatia and the local Serbian community that will lead to a peaceful integration of that region into the
national state of Croatia; members were Argentina, Bangladesh, Belgium, Brazil, Czech Republic, Denmark, Egypt,
Fiji, Finland, Ghana, Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Niger, Norway, Pakistan, Poland, Russian,
Slovakia, Sweden, Switzerland, Tunisia, Ukraine, UK, US; disbanded 15 January 1998; a UN Civilian Police Support
Group was established in December 1997 as follow-on mission to UNTAES; the support group will continue to
monitor the Croatian police in the Danube region, particularly in connection with the return of displaced people
575
Appendix C: International Organizations and Groups (continued)
United Nations Transitional Authority in
Cambodia (UNTAC)
established by the UN Security Council on 28 February 1992 to contribute to the restoration and maintenance of
peace and to the holding of free elections; disbanded sometime after the UN-supervised election in May 1993;
members were Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Brunei, Bulgaria, Cameroon, Canada,
Chile, China, Colombia, Egypt, Fiji, France, Germany, Ghana, Hungary, India, Indonesia, Ireland, Italy, Japan,
Jordan, Kenya, Malaysia, Morocco, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Philippines, Poland,
Russia, Senegal, Singapore, Sweden, Thailand, Tunisia, UK, US, Uruguay
United Nations Truce Supervision
Organization (UNTSO)
members— (20) Argentina, Australia, Austria, Belgium, Canada, Chile, China, Denmark, Estonia, Finland, France,
Ireland, Italy, Netherlands, NZ, Norway, Russia, Sweden, Switzerland, US
address— Government House, P.O. Box 490,
Jerusalem, Israel
telephone— [972] (2) 734 223
FAX— [972] (2) 735 282, 734 223 extension 400
established— HA May 1948
aim— to supervise the 1948 Arab-lsraeli
cease-fire; currently supports timely deployment
of reinforcements to other peacekeeping
operations in the region as needed; initially
established by the UN Security Council
United Nations Trusteeship Council
established on 26 June 1945, effective on 24 October 1945, to supervise the administration of the 1 1 UN trust
territories; members were China, France, Russia, UK, US; it formally suspended operations 1 November 1 995 after
the Trust Territory of the Pacific Islands (Palau) became the Republic of Palau, a constitutional government in free
association with the US; the Trusteeship Council was not dissolved
United Nations University (UNU)
address— 53-70 Jingumae 5-chome,
Shibuya-ku, Tokyo 150, Japan
telephone— [M] (3) 3499 2811
FAX— [81] (3) 3499 2828
established— 6 December 1973
aim— to conduct research in development,
welfare, and human survival and to train
scholars
members— (38 associated institutes in 33 countries) Argentina, Australia, Austria, Bangladesh, Brazil, Canada,
Chile, China, Colombia, Costa Rica, Ethiopia, France, Ghana, Guatemala, Hungary, Iceland, India, Japan, Kenya,
South Korea, Mexico, Netherlands, Nigeria, Philippines, Spain, Sri Lanka, Sudan, Switzerland, Thailand, Trinidad
and Tobago, UK, US, Venezuela
United National Verification Mission in
Guatemala (MINUGUA)
members— ( 18) Argentina, Australia, Austria, Brazil, Canada, Columbia, Ecuador, Germany, Italy, Norway, Russia,
Singapore, Spain, Sweden, Ukraine, US, Uruguay, Venezuela
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone— [1] (212) 963 1234
FAX— [1] (212) 963 4879
established— 20 January 1 997
aim— to verify fulfillment of cease-fire provisions;
established by UN Security Council
576
Universal Postal Union (UPU)
address— Bureau International de I''UPU,
Weltpoststrasse 4, CH-3000 Berne 15,','5c152e7de254a638cb260314f8f2bbcf99c3f39dd038deed5ec362896f6c7d63','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bcbc148b1664a1fbb3538a97a1c17abac0ff34570cc37dda6748db8bb343db8',1998,'UZ','Uzbekistan','transnational-issues',926,'Disputes— international: none
Illicit drugs: limited illicit cultivator of cannabis and
small amounts of opium poppy, mostly for domestic
consumption; limited government eradication
program; increasingly used as transshipment point for
illicit drugs from Afghanistan to Russia and Western
Europe and for acetic anhydride destined for
associate members— (1) "Turkish Republic of Northern Cyprus"
Euro-Atlantic Partnership Council (EAPC)
nofe— began as the North Atlantic Cooperation
Council (NACC); an extension of NATO
address— do NATO, B-1 1 10 Brussels, Belgium
telephone— [32] (2) 728 41 11
FAX-432] (2) 728 45 79
established— 8 November 1991
effective— 20 December 1991
aim— to discuss cooperation on mutual political
and security issues
members— (44) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bulgaria, Canada, Czech Republic,
Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Italy, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova, Netherlands,
Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Tajikistan, Turkey, Turkmenistan,
Ukraine, UK, US, Uzbekistan
European Bank for Reconstruction and
Development (EBRD)
address— EBRD Headquarters, One Exchange
Square, London EC2A2EH, UK
telephone— [44] (171) 338 6000, 338 7931
FAX-444] (171) 338 6100, 338 6139
established— 15 April 1991
aim— to facilitate the transition of seven centrally
planned economies in Europe (Bulgaria, former
Czechoslovakia, Hungary, Poland, Romania,
former USSR, and former Yugoslavia) to market
economies by committing 60% of its loans to
privatization
members— {60) Albania, Armenia, Australia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Egypt, EU, European Investment Bank (EIB),
Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Israel, Italy, Japan, Kazakhstan,
South Korea, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malta, Mexico, Moldova, Morocco, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan;
note— includes all 25 members of the OECD; also includes the EU as a single entity
European Community (or European
Communities, EC)
was established 8 April 1965 to integrate the European Atomic Energy Community (Euratom), the European Coal
and Steel Community (ESC), the European Economic Community (EEC or Common Market), and to establish a
completely integrated common market and an eventual federation of Europe; merged into the European Union (EU)
on 7 February 1992; member states at the time of merger were Belgium, Denmark, France, Germany, Greece,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
547
Appendix C: International Organizations and Groups (continued)
European Free Trade Association (EFTA)
members— (4) Iceland, Liechtenstein, Norway, Switzerland
address— 9-1 1 rue de Varembe, CH-1202
Geneva 20, Switzerland
telephone— [41] (22) 749 13 35
FAX— 41] (22) 733 92 91
established —4 January 1960
effective— 3 May 1960
aim— to promote expansion of free trade
European Investment Bank (EIB)
address— Bd Konrad Adenauer 100, L-2950
Luxembourg, Luxembourg
telephone— {352] 43791
FAX— [352] 437704
established— 25 March 1957
effective — 1 January 1958
aim— to promote economic development of the
EU and its predecessors, the EEC and the EC
members— (15) Austria, Belgium, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg,
Netherlands, Portugal, Spain, Sweden, UK
European Monetary Union (EMU)
note— an integral part of the European Union
address— do European Commission, Rue de la
Loi 200, B-1049 Bruxelles,
telephone— [32] (2) 199 11 11
proposed— 7 February 1 992
aim— to promote a single market by creating a
single currency, the euro; time table— 2 May
1998: European exchange rates are likely to be
fixed for 1 January 1999; 1 January 1999: all
banks and stock exchanges begin using euros;
1 January 2002: the euro goes into circulation; 1
July 2002 local currencies no longer accepted
members— ( 0) likely to be included in the first wave of members: Austria, Beligum, Finland, France, Germany,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain;
nofe—Denmark, Sweden, and UK decided not to join, and Greece did not meet all the criteria to take part
European Organization for Nuclear Research
(CERN)
note— acronym retained from the predecessor
organization Conseil Europeen pour la
Recherche Nucleaire
address— CH-1211 Geneva 23, Switzerland
telephone— [41] (22) 767 61 11
FAX— [41] (22) 767 65 55
established— 1 July 1953
effective— 29 September 1 954
aim— to foster nuclear research for peaceful
purposes only
members— (19) Austria, Belgium, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary, Italy,
Netherlands, Norway, Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers— {7) EU, Israel, Japan, Russia, Turkey, United Nations Educational, Scientific, and Cultural Organization
(UNESCO), Yugoslavia (suspended)
European Space Agency (ESA)
address— 8-10 rue Mario Nikis, F-75738 Paris
CEDEX15, France
telephone— [33] (1) 53 69 76 54
FAX— [33] (1) 53 69 75 60
established —31 July 1973
effective — 1 May 1975
aim— to promote peaceful cooperation in space
research and technology
members — (14) Austria, Belgium, Denmark, Finland, France, Germany, Ireland, Italy, Netherlands, Norway, Spain,
Sweden, Switzerland, UK
cooperating state— (1) Canada
548
European Union (EU)
note— evolved from the European Community
(EC)
address— do European Commission, Rue de la
Loi 200, B-1049 Brussels, Belgium
telephone— [32] (2)29911 11
FAX— [32] (2) 295 01 38 through 295 01 40
established— 7 February 1992
effective — 1 November 1993
aim— to coordinate policy among the 15
members in three fields: economics, building on
the European Economic Community''s (EEC)
efforts to establish a common market and
eventually a common currency to be called the
''euro1, which will supercede the EU''s accounting
unit, the ECU; defense, within the concept of a
Common Foreign and Security Policy (CFSP);
and justice and home affairs, including
immigration, drugs, terrorism, and improved
living and working conditions
members— (15) Austria, Belgium, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg,
Netherlands, Portugal, Spain, Sweden, UK
membership applicant— { 12) Albania, Bulgaria, Cyprus, Czech Republic, Estonia, Hungary, Latvia, Lithuania, Malta,
Poland, Romania, Slovakia
First World
another term for countries with advanced, industrialized economies; this term is fading from use; see developed
countries (DCs)
Food and Agriculture Organization (FAO)
address— Vi ale delle Terme di Caracaila,
1-00100 Rome, Italy
telephone— [39] (6) 52251
FAX— [39] (6) 5225 3152
established— 16 October 1945
aim— to raise living standards and increase
availability of agricultural products, as a UN
specialized agency
members— (175) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, Ei Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Uganda, UAE, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia (suspended), Zambia, Zimbabwe
associate members— { 1) Puerto Rico
former Soviet Union (FSU)
a collective term often used to identify as a group the successor nations to the Soviet Union or USSR; this group of
15 countries consists of Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
former USSR/Eastern Europe (former USSR/
EE)
the middle group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); these countries are in political and economic transition and may well be
grouped differently in the near future; this group of 27 countries consists of Albania, Armenia, Azerbaijan, Belarus,
Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, The Former Yugoslav Republic of Macedonia, Moldova, Poland, Romania, Russia, Serbia and
Montenegro, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan; this group is identical to the IMF
group "countries in transition" except for the IMF''s inclusion of Mongolia
Four Dragons
the four small Asian less developed countries (LDCs) that have experienced unusually rapid economic growth; also
known as the Four Tigers; this group consists of Hong Kong, South Korea, Singapore, Taiwan; these countries are
included in the IMF''s "advanced economies" group
Four Tigers
another term for the Four Dragons; see Four Dragons
549
Appendix C: International Organizations and Groups (continued)
Franc Zone (FZ)
address— Direction Gerterale des Service
Etrangers (Service de !a Zone Franc), Banque
de France, 39 rue Crois-des-Petits-Champs, BP
140-01 , Paris CEDEX 01 , France
telephone— [33] (1) 42 92 31 26
FAX— [33] (1) 42 92 39 88
established— 20 December 1 945
aim— to form a monetary union among countries
whose currencies are linked to the French franc
members— (15) Benin, Burkina Faso, Cameroon, Central African Republic, Chad, Comoros, Republic of the Congo,
Cote d''Ivoire, Equatorial Guinea, France, Gabon, Mali, Niger, Senegal, Togo; note— France includes metropolitan
France, the four overseas departments of France (French Guiana, Guadeloupe, Martinique, Reunion), the two
territorial collectivities of France (Mayotte, Saint Pierre and Miquelon), and the three overseas territories of France
(French Polynesia, New Caledonia, Wallis and Futuna); note— Guinea-Bissau was to become a member on 2 May
1997
Front Line States (FLS)
established to achieve black majority rule in South Africa; has since gone out of existence; members included
Angola, Botswana, Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade
(GATT)
was established 30 October 1947 to promote the expansion of international trade on a nondiscriminatory basis;
subsumed by the World Trade Organization (WTrO) on 1 January 1 995; members at the time were Angola, Antigua
and Barbuda, Argentina, Australia, Austria, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia,
Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi, Cameroon, Canada, Central African Republic, Chad,
Chile, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba,
Cyprus, Czech Republic, Denmark, Dominica, Dominican Republic, Egypt, El Salvador, Fiji, Finland, France,
Gabon, The Gambia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea-Bissau, Guyana, Haiti, Honduras,
Hong Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Kenya, South Korea, Kuwait,
Lesotho, Liechtenstein, Luxembourg, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Senegal, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Suriname,
Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE,
UK, US, Uruguay, Venezuela, Yugoslavia (suspended), Zambia, Zimbabwe
Groupof2(G-2)
informal term that came into use about 1986; to facilitate bilateral economic cooperation between the two most
powerful economic giants Japan, US
Group of 3 (G-3)
members— (3) Colombia, Mexico, Venezuela
established— NA October 1990
aim— mechanism for policy coordination
Groupof5(G-5)
members— (5) France, Germany, Japan, UK, US
established— 22 September 1985
aim— to coordinate the economic policies of five
major noncommunist economic powers
Group of 6 (G-6)
note— also known as Groupe des Six Sur le
Desarmement; not to be confused with the Big
Six
established— 22 May 1984
aim— to achieve nuclear disarmament
members— (6) Argentina, Greece, India, Mexico, Sweden, Tanzania
Group of 7 (G-7)
members— (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada and Italy
nofe— membership is the same as the Big
Seven
established— 22 September 1985
aim— to facilitate economic cooperation among
the seven major noncommunist economic
powers
550
Group of 8 (G-8)
established NA October 1975 to facilitate economic cooperation among the developed countries (DCs) that
participated in the Conference on International Economic Cooperation (CIEC), held in several sessions between NA
December 1975 and 3 June 1977; members were Australia, Canada, EU (as one member), Japan, Spain, Sweden,
Switzerland, US
Group of 9 (G-9)
established— HA
aim— to discuss matters of mutual interest on an
informal basis
members— (9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary, Romania, Sweden, Yugoslavia
Group of 10 (G-10)
note— also known as the Paris Club; includes
the wealthiest members of the IMF who provide
most of the money to be loaned and act as the
informal steering committee; name persists in
spite of the addition of Switzerland on NA April
1984
address— do IMF Office in Europe, 64-66 ave
d''lena, F-75116 Paris, France
telephone— [33] (1) 40 69 30 80
FAX— [33] (1)47 23 40 89
established— HA October 1962
aim— to coordinate credit policy
members— (11) Belgium, Canada, France, Germany, Italy, Japan, Netherlands, Sweden, Switzerland, UK, US
nonstate participants— (4) BIS, EU, IMF, OECD
Group of 11 (G-11)
note— also known as the Cartagena Group
established— 22 June 1984, in Cartagena,
562
newly industrializing countries (NICs)
former term for the newly industrializing economies; see newly industrializing economies (NIEs)
newly industrializing economies (NIEs)
that subgroup of the less developed countries (LDCs) that has experienced particularly rapid industrialization of their
economies; formerly known as the newly industrializing countries (NICs); also known as advanced developing
countries; usually includes the Four Dragons (Hong Kong, South Korea, Singapore, Taiwan), and Brazil
Nonaligned Movement (NAM)
address— Permanent Rep of Colombia to the
United Nations, New York, NY 10017, US
telephone— []] (212) 963 1234
FAX— [1] (212) 758 2718
established— 1 -6 September 1961
aim— to establish political and military
cooperation apart from the traditional East or
West blocs
members— (112 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Ecuador, Egypt, Equatorial
Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho,
Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru,
Philippines, Qatar, Rwanda, Saint Lucia, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe, Palestine Liberation Organization
observers— (20) Afro-Asian Solidarity Organization, Antigua and Barbuda, Arab League, Armenia, Azerbaijan,
Brazil, China, Costa Rica, Croatia, Dominica, El Salvador, Kanaka Socialist National Liberation Front (New
Caledonia), Mexico, Mongolia, Organization of African Unity, Organization of the Islamic Conference, Socialist Party
of Puerto Rico, UN, Uruguay
guests— (22) Australia, Austria, Bosnia and Herzegovina, Bulgaria, Canada, Dominican Republic, Finland,
Germany, Greece, Hungary, Italy, Netherlands, NZ, Norway, Poland, Portugal, Romania, San Marino, Slovenia,
Spain, Sweden, Switzerland
Nordic Council (NC)
address— Store Strandstraede 18, PB 3043,
DK-1021 Kobenhavn K, Denmark
telephone— [45] 33 96 04 00
FAX— [45] 33 1 1 18 70
established— 16 March 1952
effective— 12 February 1953
aim— to promote regional economic, cultural,
and environmental cooperation
members— { 5) Denmark (including Faroe Islands and Greenland), Finland (including Aland Islands), Iceland,
Norway, Sweden
observers— (3) the Sami (Lapp) local parliaments of Finland, Norway, and Sweden
Nordic Investment Bank (NIB)
address— Fabianinkatu 34, P.O. Box 249,
FIN-00171 Helsinki, Finland
telephone— [358] (0) 18001
FAX— [358] (0) 1800210
established— 4 December 1975
effective— 1 June 1976
aim— to promote economic cooperation and
development
members— (5) Denmark (including Faroe Islands and Greenland), Finland (including Aland Islands), Iceland,
Norway, Sweden
North
a popular term for the rich industrialized countries generally located in the northern portion of the Northern
Hemisphere; the counterpart of the South; see developed countries (DCs)
North Atlantic Cooperation Council (NACC)
note— see Euro-Atlantic Partnership Council (EAPC)
North Atlantic Treaty Organization (NATO)
address— B-1110 Brussels, Belgium
telephone— {32} (2) 707 41 1 1
FAX— [32] (2) 707 4579
established— 17 September 1949
a/''rn — to promote mutual defense and
cooperation
members— (16) Belgium, Canada, Denmark, France, Germany, Greece, Iceland, Italy, Luxembourg, Netherlands,
Norway, Portugal, Spain, Turkey, UK, US
563
Appendix C: International Organizations and Groups (continued)
Nuclear Energy Agency (NEA)
address— AEN/NEA, Le Seine St. Germain, 12
bd des lies, F-92130 lssy-!es-Moulineaux,','a35904d607f6a784254a6c53580ba53f6fc2ae2a06d128d2a6cfbe48c06156c4','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ce647c810249afd61cc932805ba96f193322b8780ab36e47dc3f864e58dcc6f',1998,'EH','Western Sahara','transnational-issues',948,'Disputes— international: claimed and administered
by Morocco, but sovereignty is unresolved and the UN
is attempting to hold a referendum on the issue; the
UN-administered cease-fire has been in effect since
September 1991
512
World','8c6b3edef2a511fac30cf33301252365ccec32be81ca67a809c05b84406a7184','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57907aca5fc4c55d0abed0731e53ab89e16e65b1f8abdd2a897e3b8ab357b396',1998,'YE','Yemen','transnational-issues',956,'Disputes— international: a large section of
boundary with Saudi Arabia is not defined; a dispute
with Eritrea over sovereignty of the Hanish Islands in
the southern Red Sea has been submitted to
arbitration under the auspices of the International
Court of Justice; a decision on the Islands is expected
in mid-1998','f56355aa84adbe279048aa15e132ad90ce2185f93095794d09ca2d92068c8d25','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b52c7368410de155422dd3f16bb70876f980a9f743840f349be7d25e45c240e',1998,'ZM','Zambia','transnational-issues',963,'Disputes— international: quadripoint with
Botswana, Namibia, and Zimbabwe is in
disagreement; Democratic Republic of the
Congo-Tanzania-Zambia tripoint in Lake Tanganyika
may no longer be indefinite since it has been
informally reported that the indefinite section of the
Democratic Republic of the Congo-Zambia boundary
has been settled
Illicit drugs: transshipment point for methaqualone,
heroin, and cocaine bound for Southern Africa and
Europe; regional money-laundering center
Location: Southern Africa, northeast of Botswana
Geographic coordinates: 20 00 S, 30 00 E
Map references: Africa
Area:
total: 390,580 sq km
land: 386,670 sq km
water: 3,91 Osq km
Area— comparative: slightly larger than Montana
Land boundaries:
total: 3,066 km
border countries: Botswana 813 km, Mozambique
1 ,231 km, South Africa 225 km, Zambia 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; moderated by altitude; rainy
season (November to March)
Terrain: mostly high plateau with higher central
plateau (high veld); mountains in east
Elevation extremes:
lowest point: junction of the Lundi and Savi rivers
162 m
highest point: Inyangani 2,592 m
Natural resources: coal, chromium ore, asbestos,
gold, nickel, copper, iron ore, vanadium, lithium, tin,
platinum group metals
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 1 3%
forests and woodland: 23%
other: 57% (1993 est.)
Irrigated land: 1 ,930 sq km (1 993 est.)
Natural hazards: recurring droughts; floods and
severe storms are rare
Environment— current issues: deforestation; soil
erosion; land degradation; air and water pollution; the
black rhinoceros herd— once the largest
concentration of the species in the world— has been
significantly reduced by poaching
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked
[ P e o p I e
Population: 11,044,147 (July 1998 est.)
Age structure:
0-14 years: 44% (male 2,439,907; female 2,397,761)
15-64 years: 54% (male 2,914,336; female
3,000,442)
65 years and over: 2% (male 1 33,232; female
158,469) (July 1998 est.)
Population growth rate: 1.12% (1998 est.)
Birth rate: 31 .32 births/1,000 population (1998 est.)
Death rate: 20.09 deaths/1 ,000 population (1998
est.)
Net migration rate: NA migrant(s)/1,000 population
note: there is a small but steady flow of Zimbabweans
into South Africa in search of better paid employment
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.84 male(s)/female (1 998 est.)
Infant mortality rate: 61 .75 deaths/1 ,000 live births
(1998 est.)
Life expectancy at birth:
total population: 39.16 years
male: 39.12 years
female: 39.19 years (1998 est.)
Total fertility rate: 3.86 children born/woman (1 998
est.)
Nationality:
noun: Zimbabwean(s)
adjective: Zimbabwean
Ethnic groups: African 98% (Shona 71%, Ndebele
16%, other 11%), white 1%, mixed and Asian 1%
Religions: syncretic (part Christian, part indigenous
beliefs) 50%, Christian 25%, indigenous beliefs 24%,
Muslim and other 1%
Languages: English (official), Shona, Sindebele (the
language of the Ndebele, sometimes called Ndebele),
numerous but minor tribal dialects
Literacy:
definition: age 15 and over can read and write in
English
total population: 85%
male : 90%
female: 80% (1995 est.)','1d1ab79a601a0a8a426b4c3a52d7e040909810c64ca35573501500b13421e5a2','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fba72ee426cddd2f64e804c4fc44f4b09a41a2ec087b9ed9abd006d2e0de5ae4',1998,'GB','United Kingdom','transnational-issues',964,'UN
United Nations
UNAMIR
United Nations Assistance Mission for Rwanda
UNAVEM III
United Nations Angola Verification Mission III
UNCRO
United Nations Confidence Restoration Operation in Croatia
UNCTAD
United Nations Conference on Trade and Development
UNDOF
United Nations Disengagement Observer Force
UNDP
United Nations Development Program
UNEP
United Nations Environment Program
UNESCO
United Nations Educational, Scientific, and Cultural Organization
UNFICYP
United Nations Force in Cyprus
UNFPA
United Nations Fund for Population Activities; see UN Population Fund (UNFPA)
UNHCR
United Nations Office of the High Commissioner for Refugees
UNICEF
United Nations Children''s Fund
UNIDO
United Nations Industrial Development Organization
UNIFIL
United Nations Interim Force in Lebanon
UNIKOM
United Nations Iraq-Kuwait Observation Mission
UNITAR
United Nations Institute for Training and Research
UNMIH
United Nations Mission in Haiti
UNMIBH
United Nations Mission in Bosnia and Herzegovina
UNMOGIP
United Nations Military Observer Group in India and Pakistan
UNMOP
United Nations Mission of Observers in Prevlaka
UNMOT
United Nations Mission of Observers in Tajikistan
UNOMIG
United Nations Observer Mission in Georgia
UNOMIL
United Nations Observer Mission in Liberia
UNOMOZ
United Nations Operation in Mozambique
UNOMUR
United Nations Observer Mission Uganda-Rwanda
530
UNOSOM II
United Nations Operation in Somalia II
UNPREDEP
United Nations Preventive Deployment Force
UNPROFOR
United Nations Protection Force
UNRISD
United Nations Research Institute for Social Development
UNRWA
United Nations Relief and Works Agency for Palestine Refugees in the Near East
UNSMIH
United Nations Support Mission in Haiti
UNTAC
United Nations Transitional Authority in Cambodia
UNTAES
United Nations Transitional Administration in Eastern Slavonia, Baranja, and
Western Sirmium
UNTSO
United Nations Truce Supervision Organization
UNU
United Nations University
UPU
Universal Postal Union
us','7fde9fca6224a56b0ee241a326fc36c0ae679b8c7005fd44086dff1154a7e01c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19dfc128fa5bf9e14437e00eda5336a34df233c11ebfd099bfeb68c5ef48bcbb',1998,'MA','Morocco','transnational-issues',965,'te/ep/?one — [212] (7) 77 26 82, 77 26 76, 77 26
68
FAX— [212] (7) 77 26 93
established— 1 7 February 1 989
aim— to promote cooperation and integration
among the Arab states of northern Africa
members— (5) Algeria, Libya, Mauritania, Morocco, Tunisia
Arab Monetary Fund (AMF)
address— P.O. Box 281 8, Abu Dhabi, United
Arab Emirates
telephone— {97 ^ (2) 215000, 328500
FAX— [971] (2) 326454
established— 27 April 1976
effective— 2 February 1977
aim— to promote Arab cooperation,
development, and integration in monetary and
economic affairs
members— (20 plus the Palestine Liberation Organization) Algeria, Bahrain, Djibouti, Egypt, Iraq, Jordan, Kuwait,
Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE, Yemen,
Palestine Liberation Organization
Asia Pacific Economic Cooperation (APEC)
address^ 438 Alexandra Road, Alexandra Point
Building, 19th Floor 01/04, Singapore 119958,','38f3d77939e66cea3dff3367823ea183703edf37eb625108db66be386ca1aa4c','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2005bf4b57c49bde066e694b875f1ca4f4bde48cb5a73ddcf0db3c87fc83a036',1998,'SG','Singapore','transnational-issues',966,'telephone— {65] 2761880
FAX— [65] 276 1775
established— 7 November 1989
aim— to promote trade and investment in the
Pacific basin
members— (19) Australia, Brunei, Canada, Chile, China, Hong Kong, Indonesia, Japan, South Korea, Malaysia,
Mexico, NZ, Papua New Guinea, Philippines, Singapore, Taiwan, Thailand, US, Vietnam
observers— (3) Association of Southeast Asian Nations, Pacific Economic Cooperation Conference, South Pacific
Forum
535
Appendix C: International Organizations and Groups (continued)
Asian Development Bank (AsDB)
address— 6 ADB Avenue, Mandaluyong, 0401
METRO Manila, Philippines
telephone— [63] (2)711 3851
FAX— [63] (2) 741 7961,631 6816
established— 19 December 1966
aim— to promote regional economic cooperation
regional members— ( 40) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Cambodia, China, Cook Islands, Fiji,
Hong Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan, Laos, Malaysia, Maldives,
Marshall Islands, Federated States of Micronesia, Mongolia, Nauru, Nepal, NZ, Pakistan, Papua New Guinea,
Philippines, Samoa, Singapore, Solomon Islands, Sri Lanka, Taiwan, Thailand, Tonga, Tuvalu, Uzbekistan,
Vanuatu, Vietnam
nonregional members— { 16) Austria, Belgium, Canada, Denmark, Finland, France, Germany, Italy, Netherlands,
Norway, Spain, Sweden, Switzerland, Turkey, UK, US
Asociacion Latinoamericana de Integracion
(ALADI)
see Latin American Integration Association (LAIA)
Association of Southeast Asian Nations
(ASEAN)
note— the ASEAN Regional Forum (ARF)
consists of the 9 ASEAN members, 2 observers,
2 consultative partners, and 8 dialogue partners:
Australia, Canada, EU, India, Japan, South
Korea, New Zealand, US
address— 70 A Jalan Sisingamangaraja,
Kebayoran Baru, P.O. Box 2072, Jakarta 12110,','9f047e27f4638b028dfb9817570889902f3c75e6df3b52a921bf5fe525373b78','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8be27055ca486659c1a2b1d5bd645c14b5a2cc788894d90eaf2505b6674b1aee',1998,'LU','Luxembourg','transnational-issues',967,'address— Rue de la Regence 39, B-1000
Brussels, Belgium
telephone— [32] (2) 519 38 11
FAX-1 32] (2)513 42 06
established— 3 February 1958
effective— 1 November 1960
aim-A o develop closer economic cooperation
and integration
Big Seven
members— (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus the US
note— membership is the same as the
Group of 7
established— NA 1975
aim— to discuss and coordinate major economic
policies
Big Six
members— (6) Canada, France, Germany, Italy, Japan, UK
note— not to be confused with the Group of 6
established— HA 1967
aim— to foster economic cooperation
Black Sea Economic Cooperation Zone
(BSEC)
address— 1 Hareket Kosku, Dolmabahce Sarayi,
Besiktas 80680, Istanbul, Turkey
telephone— [90] (1) 227 7300 through 227 7305
FAX— [90] (1)227 7306
established— 25 June 1992
aim— to enhance regional stability through
economic cooperation
members— (11) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece, Moldova, Romania, Russia, Turkey,','64449c84abaf1d2757277a41dd512ab953f7909520465b514223cbd5b9180217','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e36336cf3004196383843d1b694be0eb2dcd3ea594f88d7ea30821407e49f5c',1998,'BB','Barbados','transnational-issues',968,'telephone— { 1] (809) 431 1600
FAX— [1] (809) 426 7269
esfaMs/7ec/ — 1 8 October 1969
effective— 26 January 1970
aim— to promote economic development and
cooperation
Cartagena Group
Central African Customs and Economic
Union (UDEAC)
members— (14) Antigua and Barbuda, The Bahamas, Barbados, Belize, Dominica, Grenada, Guyana, Jamaica,
Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago
associate members— (2) British Virgin Islands, Turks and Caicos islands
observers-{ 9) Anguilla, Bermuda, Cayman Islands, Dominican Republic, Haiti, Mexico, Netherlands Antilles,
Puerto Rico, Venezuela
regional members— (20) Anguilla, Antigua and Barbuda, The Bahamas, Barbados, Belize, British Virgin Islands,
Cayman Islands, Colombia, Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Trinidad and Tobago, Turks and Caicos Islands, Venezuela
nonregional members— ( 5) Canada, France, Germany, Italy, UK
see Group of 1 1 _ _ _
members— { 6) Cameroon, Central African Republic, Chad, Republic of the Congo, Equatorial Guinea, Gabon
note— acronym from Union Douaniere et
Economique de 1‘Afrique Centrale
address— BP 969, Bangui, Central African
Republic
telephone— [236] 61 09 22, 61 45 77
FAX— [236] 61 21 35
established— 8 December 1964
effective— 1 January 1966
aim— to promote the establishment of a Central
African Common Market _ _ _ _ _
Central African States Development Bank members— ( 9) Cameroon, Central African Republic, Chad, Republic of the Congo, Equatorial Guinea, France,
(BDEAC) Gabon, Germany, Kuwait
note— acronym from Banque de
Developpement des Etats de I''Afrique Centrale
address— BDEAC, Place du Gouvernement, BP
1177, Brazzaville, Republic of the Congo
telephone— [242] 83 01 26, 83 01 49, 81 02 12,
81 02 21
FAX— [242] 83 02 66
established— 3 December 1975
aim— to provide loans for economic
development _ _ _ ___
538
Central American Bank for Economic
Integration (BCIE)
note— acronym from Banco Centroamericano
de Integracion Economico
address— Apartado Postal 772, Tegucigalpa
DC, Honduras
telephone— [504] 372230 through 372239,
371 184 through 371188
FAX— [504] 370793
established— 3 December 1960
aim— to promote economic integration and
development
members— (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members— { 3) Argentina, Mexico, Taiwan
Central American Common Market (CACM)
address— do SIECA, Apart Postal 1237, 4a
Avenida 10-25, Zona 14, Guatemala 01901,','c2a89592810fb2eb587c9c334c3674045f51d95824a54c72ba47ae5e0f3408f0','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b0af1314b33c3c89a2dfa6f95c6b06e3df4494a1a6bf5b34a2a57cc84683427',1998,'GT','Guatemala','transnational-issues',969,'te/ephone— [502] (2) 682151, 682152, 682153,
682154
FAX— [502] (2) 681071
established— 13 December 1960
effective— 3 June 1961
aim— to promote establishment of a Central
American Common Market
members— ( 6) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua, Panama
Central European Initiative (CEI)
note— evolved from the Hexagonal Group
address — Ministry of Affairs of the Republic of
Poland, Al 1 Ch Szucha 23, PL-00 580 Warsaw,','4aeebc05a3245fa45a091174bc62b66f42313b01753356036d4efacb36bdcf7d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c38c4eaefc98d84cda6e7a1c88ce2278a0e587cf69aaadcd98f2d47a5dd95ef3',1998,'BY','Belarus','transnational-issues',970,'telephone— [375] 293434, 293517
FAX''— [375] 261894, 261944
established— 8 December 1991
effective— 21 December 1991
aim— to coordinate intercommonwealth
relations and to provide a mechanism for the
orderly dissolution of the USSR
members— (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
Commonwealth of Nations
see Commonwealth (C)
Communaute Economique de I’Afrique de
I''Ouest (CEAO)
see West African Economic Community (CEAO)
Communaute Economique des Etats de
TAfrique Centrale (CEEAC)
see Economic Community of Central African States (CEEAC)
Communaute Economique des Pays des
Grands Lacs (CEPGL)
see Economic Community of the Great Lakes Countries (CEPGL)
communist countries
traditionally the Marxist-Leninist states with authoritarian governments and command economies based on the
Soviet model; most of the original and the successor states are no longer communist; see centrally planned
economies
Conference on Security and Cooperation in
Europe (CSCE)
see Organization for Security and Cooperation in Europe (OSCE)
Conseil Europeen pour la Recherche
Nucleaire (CERN)
see European Organization for Nuclear Research (CERN)
Contadora Group (CG)
established 5 January 1983 (on the Panamanian island of Contadora) to reduce tensions and conflicts in Central
America; has evolved into the Rio Group (RG); members included Colombia, Mexico, Panama, Venezuela
Cooperation Council for the Arab States of
the Gulf
see Gulf Cooperation Council (GCC)
Coordinating Committee on Export Controls
(COCOM)
established in 1 949 to control the export of strategic products and technical data from member countries to
proscribed destinations; members were Australia, Belgium, Canada, Denmark, France, Germany, Greece, Italy,
Japan, Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey, UK, US; abolished 31 March 1994; COCOM
members are working on a new organization with expanded membership which focuses on nonproliferation export
controls as opposed to East-West control of advanced technology
Council for Mutual Economic Assistance
(CEMA>
note— also known as CMEA or Comecon
established 25 January 1949 to promote the development of socialist economies and abolished 1 January 1991 ;
members included Afghanistan (observer), Albania (had not participated since 1961 break with USSR), Angola
(observer), Bulgaria, Cuba, Czechoslovakia, Ethiopia (observer), GDR, Hungary, Laos (observer), Mongolia,
Mozambique (observer), Nicaragua (observer), Poland, Romania, USSR, Vietnam, Yemen (observer), Yugoslavia
(associate)
542
Council of Arab Economic Unity (CAEU) members — (1 1 plus the Palestine Liberation Organization) Egypt, Iraq, Jordan, Kuwait, Libya, Mauritania, Somalia,
Sudan, Syria, UAE, Yemen, Palestine Liberation Organization
address— International Trade Centre Building,
12th Floor, 1191 Cornish El Nile, P.O. Box 1,
Mohamad Freed, Cairo, Egypt
telephone— [20] (2) 754252, 755321
FAX— {20] (2) 754090
telephone— [%2] (6) 66 43 26, 66 43 27, 66 43
28
FAX— [962] (6) 66 33 43
established— 3 June 1957
effective— 30 May 1964
aim— to promote economic integration among
Arab nations
Council of Europe (CE)
address— Palais de [''Europe, F-67075
Strasbourg CEDEX, France
telephone— {33] (3) 88 41 20 00
FAX— {33] (3) 88 41 27 81 , 88 41 27 82
established— 5 May 1949
effective— 3 August 1 949
aim— to promote increased unity and quality of
life in Europe
Council of the Baltic Sea States (CBSS) members— ( 11) Denmark, Estonia, Finland, Germany, Iceland, Latvia, Lithuania, Norway, Poland, Russia, Sweden
address— Ministry for Foreign Affairs, Box
16121, S-10323 Stockholm, Sweden
telephone-^ 46] (8) 4051000
FAX— {46] (8) 7231176
established— 6 March 1992
aim— to promote cooperation among the Baltic
Sea states in the areas of aid to new democratic
institutions, economic development,
humanitarian aid, energy and the environment,
cultural programs and education, and
transportation and communication
Council of the Entente (Entente) members— ( 5) Benin, Burkina Faso, Cote d’Ivoire, Niger, Togo
address— BP 3734, Abidjan 01 , Cote d''Ivoire
telephone— 225] 33 10 01 , 33 28 35
FAX— [225] 3311 49
established— 29 May 1959
aim— to promote economic, social, and political
coordination
countries in transition a new term used by the International Monetary FUND (IMF) for the middle group in its hierarchy of advanced
economies, countries in transition, and developing countries; recently published IMF statistics include the following
28 countries in transition: Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech
Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic of
Macedonia, Moldova, Mongolia, Poland, Romania, Russia, Serbia and Montenegro, Slovakia, Slovenia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan; note— this group is identical to the group traditionally referred to as the "former
USSR/Eastern Europe" except for the addition of Mongolia
members— (40) Albania, Andorra, Austria, Belgium, Bulgaria, Croatia, Cyprus, Czech Republic, Denmark, Estonia,
Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia, Liechtenstein, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Malta, Moldova, Netherlands, Norway, Poland, Portugal, Romania,
Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK
guests— (4) Armenia, Azerbaijan, Bosnia and Herzegovina, Georgia
observers— (5) Canada, Israel, Italy, Japan, US
543
Appendix C: International Organizations and Groups (continued)
members— ( 142) Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bangladesh, Belarus, Belgium, Bermuda, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cameroon, Canada, Cape Verde, Central African Republic, Chile, China, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Egypt,
Eritrea, Estonia, Ethiopia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala,
Guinea, Guyana, Haiti, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, Macau, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Niger, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sudan, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia,
Zimbabwe _ _
developed countries (DCs) the top group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and
less developed countries (LDCs); includes the market-oriented economies of the mainly democratic nations in the
Organization for Economic Cooperation and Development (OECD), Bermuda, Israel, South Africa, and the
European ministates; also known as the First World, high-income countries, the North, industrial countries; generally
have a per capita GDP in excess of $10,000 although four OECD countries and South Africa have figures well under
$10,000 and two of the excluded OPEC countries have figures of more than $10,000; the 35 DCs are: Andorra,
Australia, Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland, France, Germany, Greece, Holy
See, Iceland, Ireland, Israel, Italy, Japan, Liechtenstein, Luxembourg, Malta, Mexico, Monaco, Netherlands, NZ,
Norway, Portugal, San Marino, South Africa, Spain, Sweden, Switzerland, Turkey, UK, US; note— similar to the new
International Monetary Fund (IMF) term "advanced economies" which adds Hong Kong, South Korea, Singapore,
and Taiwan but drops Malta, Mexico, South Africa, and Turkey _
developing countries a new term used by the International Monetary FUND (IMF) for the bottom group in its hierarchy of advanced
economies, countries in transition, and developing countries; recently published IMF statistics include the following
126 developing countries: Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Aruba, The Bahamas,
Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya,
Kiribati, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Morocco, Mozambique, Namibia,
Nepal, Netherlands Antilles, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa,
Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
UAE, Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; note— this category would
presumably also cover the following 46 other countries that are traditionally included in the more comprehensive
group of “less developed countries”: American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman Islands,
Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia,
Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Jersey, North Korea, Macau, Isle of
Man, Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk Island, Northern Mariana Islands,
Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and
Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara _
Customs Cooperation Council (CCC)
note— also known as World Customs
Organization (WCO)
address— Rue de (''Industrie 26-38, B-1040
Brussels, Belgium
telephone— {32] (2) 508 42 1 1
FAX— [32] (2)50842 40
established— 5 December 1 950
aim— to promote international cooperation in
customs matters
544
East African Development Bank (EADB) members— ( 3) Kenya, Tanzania, Uganda
address— 4 Nile Avenue, P.O. Box 7128,
Kampala, Uganda, or Bruce House, P.O. Box
47685, Nairobi Kenya, or Nic Investment House,
P.O. Box 9401 , Miranbo Street, Dar es Salaam,
Tanzania
telephone— [256] (41) 230021 , 230825 or [254]
(2) 340642, 340656 or [255] (51) 113194,
113195
FAX— [256] (41 ) 259763 or [255] (51 ) 1 1 31 97
established— 6 June 1967
effective— 1 December 1967
aim— to promote economic development
Economic and Social Commission for Asia
and the Pacific (ESCAP)
address— United Nations Building,
Rajadamnern Avenue, Bangkok 10200,','354317c5400ae0a0ba875555c1954a2e4ed0c3bb42410d25cadc0804faed233d','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f4113fdf1201482e40ac1744ea6e949c5a9a7c87a27724ead13c0188e9598e4',1998,'MC','Monaco','transnational-issues',971,'telephoned 33] (93) 50 65 87
FAX— [33] (93) 25 20 03
established— HA June 1919
effective— NA June 1921
aim— to train hydrographic surveyors and
nautical cartographers to achieve
standardization in nautical charts and electronic
chart displays; to provide advice on nautical
cartography and hydrography; to develop the
sciences in the field of hydrography and
techniques used for descriptive oceanography
members— (170) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cameroon, Canada, Cape
Verde, Central African Republic, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Samoa, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK,
US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
members— (160)
Category I— (22 industrialized aid contributors) Australia, Austria, Belgium, Canada, Denmark, Finland, France,
Germany, Greece, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden,
Switzerland, UK, US
Category II— (12 petroleum-exporting aid contributors) Algeria, Gabon, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria,
Qatar, Saudi Arabia, UAE, Venezuela
Category /// — ( 126 aid recipients) Afghanistan, Albania, Angola, Antigua and Barbuda, Argentina, Armenia,
Azerbaijan, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, India, Israel, Jamaica, Jordan, Kenya, North Korea, South Korea, Kyrgyzstan, Laos,
Lebanon, Lesotho, Liberia, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua,
Niger, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Romania, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Senegal, Seychelles,
Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Uruguay, Vietnam, Yemen,
Yugoslavia (suspended), Zambia, Zimbabwe
members— (60) Argentina, Australia, Bahrain, Belgium, Brazil, Canada, Chile, China, Democratic Republic of the
Congo, Cuba, Cyprus, Denmark, Dominican Republic, Ecuador, Egypt, Fiji, Finland, France, Germany, Greece,
Guatemala, Iceland, India, Indonesia, Iran, Italy, Japan, North Korea, South Korea, Malaysia, Monaco, Netherlands,
NZ, Nigeria, Norway, Oman, Pakistan, Papua New Guinea, Peru, Philippines, Poland, Portugal, Russia, Singapore,
South Africa, Spain, Sri Lanka, Suriname, Sweden, Syria, Thailand, Tonga, Trinidad and Tobago, Turkey, UAE, US,
UK, Uruguay, Venezuela, Yugoslavia
permanent members— (10) Algeria, Bulgaria, Colombia, Croatia, Estonia, Jamaica, Mauritania, Morocco, Qatar,','c4a5aa37c7c779e1d6304b5b18fbd6d1228e5cd463a7da5e15dae8e274fc6eb9','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05a751b86cd1f85db36fd928346d43e0a9ec1d1c38440d326ded4e0198ca9fe1',1998,'BW','Botswana','transnational-issues',972,'telephone-^ 267] (31) 351863, 351864, 351865
FAX— [267] (31)372848
established— 17 August 1992
aim— to promote regional economic
development and integration
members— (16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ,
Niue, Palau, Papua New Guinea, Samoa, Solomon islands, Tonga, Tuvalu, Vanuatu
567
Appendix C: International Organizations and Groups (continued)
Southern Cone Common Market (Mercosur)
note— also known as Mercado Comun del Cono
Sur (Mercosur)
address— Rincon 575 P 12, 1 1000 Montevideo,','b4992bf1f6ff99efa6615d16fbdd9151a75f4dd554ce130ae0c99f5b11cdd68b','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6128e7aadfc17d8046c9df098d08e3d527e497992c98a85acb2673df5a6d0221',1998,'BE','Belgium','transnational-issues',973,'telephone— [32] (2) 230 62 95
FAX— [32] (2) 230 87 22
established— 19 June 1920 as the International
Federation of Christian Trade Unions (1FCTU),
renamed 4 October 1968
aim— to promote the trade union movement
members— ( 99 national organizations) Algeria, Angola, Antigua and Barbuda, Argentina, Aruba, Austria,
Bangladesh, Belgium, Belize, Benin, Bolivia, Bonaire Island, Botswana, Brazil, Burkina Faso, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, Colombia, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Cuba, Curacao, Cyprus, Dominica, Dominican Republic, Ecuador, El Salvador, France, French Guiana,
Gabon, The Gambia, Ghana, Grenada, Guadeloupe, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong,
Indonesia, Iran, Italy, Jamaica, Kenya, Lesotho, Liberia, Liechtenstein, Luxembourg, Madagascar, Malaysia, Mali,
Malta, Martinique, Mauritius, Mexico, Montserrat, Namibia, Netherlands, Nicaragua, Niger, Nigeria, Pakistan,
Panama, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Romania, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Martin, Saint Vincent and the Grenadines, Senegal, Seychelles, Sierra Leone, Spain, Sri Lanka,
Suriname, Switzerland, Taiwan, Tanzania, Thailand, Togo, UK, US, Uruguay, Venezuela, Vietnam, Zambia,','fe3652292ce3c7c68cb37f811c518986e673d0f421ee83822b26f6ea2fe239f8','internet-archive','DTIC_ADA361588','txt','316629e4a8c2a551949a184e9b866edc6a2915b5fbe105ca7d0cce883dc0cde8','https://archive.org/download/DTIC_ADA361588/DTIC_ADA361588_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

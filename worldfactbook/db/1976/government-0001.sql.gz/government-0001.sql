SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fb7784df84d93a359db7ac0644885e42bca0316e88ba371c5d2c4af63f0e1ff',1976,'AF','Afghanistan','government',5,'Legal name: Republic of Afghanistan
Type: republic
Capital: Kabul
Political subdivisions: 28 provinces with centrally
appointed governors
Legal system: based on Islamic law; constitution
nullified July 1973; independent judiciary also
abolished and powers transferred to the Council of
Justice, chaired by Minister of Justice; legal education
at University of Kabul; has not accepted compulsory
ICJ jurisdiction
Branches: Parliament abolished July 1973; all
powers of the parliament and the monarchy
transferred to the President
Approved For Release 2005/04/22 :
Government leaders: President Mohammad
Daoud who also serves as Prime Minister, Foreign
Minister, and Defense Minister, Mohammad Naim,
Daoud''s brother and personal adviser
Suffrage: universal from age 20
Elections: promiscd but no date set
Political parties and leaders: no political parties
permitted
Communists: there are two pro-Moscow Com-
munist groups, Parcham and Khalq, believed to have
several hundred active members, and a smaller pro-
Peking group, Sholaye-Jaweid
Other political or pressure groups: most military
officers support the government; no known organized
opposition
Member of: ADB, Colombo Plan, FAO, IAEA,
IBRD, ICAO, IDA, IFC, LLO, IMF, ITU, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO','267714456925a2aa730a738b4b94bec5e750f229a3baf6dd22b0adb487d8679d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deb049bd98d90645b0d63d9e909e92e6175a89c4902748170d4f5d879baf0af9',1976,'DZ','Algeria','government',11,'Type: republic
Capital: Algiers
Political subdivisions: 31 Wilayas (departments or
provinces)
Legal system: based on French and Islamic law,
with socialist principles; constitution adopted by
referendum 1963 but suspended since June 1965;
judicial review of legislative acts in ad hoc
Constitutional Council composed of various public
officials, including several Supreme Court. justices;
Supreme Court divided into 4 chambers; legal
education at Universities of Algiers, Oran and
Constantine; has not accepted compulsory ICJ
jurisdiction
Branches: executive dominant, unicameral
legislature has not met since June 1965 coup d''etat
but was never formally suspended, judiciary
Government leader: Houari Boumediene, Presi-
dent of Council of the Revolution and President of the
Council of Ministers, overthrew elected President
Ahmed Ben Bella 19 June 1965
Suffrage: universal over age 19
Elections (latest): presidential 15 September 1963;
departmental assemblies 2 June 1974; local assemblies
30 March 1975
Political parties and leaders: National Liberation
Front (FLN)
Voting strength (1963 election): 100% FLN
Communists: 400 (est.); Communist Party illegal
(banned 1962)
Member of; AFDB, Arab League, FAO, GATT (de
facto), IAFA, IBRD, ICAO, IDA, ILO, IMCO, IMF,
ITU, OAPEC, OAU, OPEC, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ALGERIA/ANDORRA','218a960328a8d1981d7b26058a97cc2839c362da9b7bbfa20dbf72177bb15828','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2006823484e2a1181832120bb79116bf0499b75dbe61e5dcd66b37cfdc20baf3',1976,'AO','Angola','government',19,'Angola received independence from Portugal on
November 11, 1975. Three rival liberation groups are
fighting a civil war in order to gain political control
over the former territory. The groups are National
Front for the Liberation of Angola (FNLA) led by
Holden Roberto, Popular Movement for the
Liberation of Angola (MPLA) led by Agostinho Neto,
and National Union for the Total Independence of
Angola (UNITA) led by Jonas Savimbi.
Capital: Luanda','2138b17f513525aa46ecb2f81ca6fc3fbf75a863ba4845863cd6dabf579308fe','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c308386371b76c1b81f33cbc52dff1065ed2a6c12b0988c5d120a6c851c2dfb',1976,'PR','Puerto Rico','government',23,'Legal name: State of Antigua
Type: dependent territory with full internal
autonomy as a British "Associated State"
Capital: St. John’s
Political subdivisions: 6 parishes, 2 dependencies
(Barbuda, Redonda)
Legal system: based on English law: British
Caribbean Court of Appeal has exclusive original
jurisdiction and an appellate jurisdiction, consists of
Chief Justice and 5 justices
Branches: legislative, 21-member popularly elected
House of Representatives; executive, Prime Minister
and Cabinet
Government leaders: Premier George Herbert
Walter; Governor Sir Wilfred Ebenezer Jacobs
Suffrage: universal suffrage age 18 and over
Elections: every 5 years: last general election. 11
Vebruary 1971
Political parties and leaders: Antigua Labor Party
(ALP), Vere C. Bird; Progressive Labor Movement
(PLM). Ceorge Herbert Walter: Antigua People’s
Party (APP), J. Rowan Henry
Voting strength: 1971 election — House of
Representative seats — ALP 4, PLM 13
Communists: negligible
Other political or pressure groups: Afro-
Caribbean Movement (ACM ) a small black
nationalist group led by Timothy Hector: Antigua
Freedom Fighters (AFF), a small black radical group,
leaders unknown
Member of: CARICOM','71e8cafd51a3d7201db124c2a48e347f67d01fa8568de3b7b0f63eac35113c7d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d117d86355d2c3f67ea4d977971ec8cce035d792fc22c7afd66d0f3d52190cda',1976,'AR','Argentina','government',27,'Legal name: Argentine Republic
Type: republic
Capital: Buenos Aires
Political subdivisions: 22 provinces, ] district
(Federal Capital), and ! territory
Legal system: based on Spanish and French civil
codes; constitution adopted 1853 partially superseded
in 1966 by the Statute of the Revolution which takes
precedence over the constitution when the two are in
conflict, further changes may be made by new
government; judicial review of legislative acts; legal
education at University of Buenos Aires and other
public and private universities; has not accepted
compulsory JCJ jurisdiction
Branches: Presidency:
judiciary
Government leader:
Martinez de Peron
Suffrage: universal and compulsory age 18 and
over
Elections: general elections held on 11 March
1978; congressional and gubernatorial runoffs were
held on 15 April; next election in 4 years
Political parties: Justicialistas, the official Peronist
party; Radical Civic Union, moderate leftist and
nationalist, Ricardo Balbin; Federal Popular Alliance,
Francisco Manrique; Movement of Integration and
Development (MID), small left of center party,
former President Frondizi; New Force, conservative
business party, organized by Alvaro Alsogaray for the
1973 elections; Intransigent Party, formerly the
Intransigent Radicals (UCRD, small nationalist party,
Oscar Alende; several provincial parties not organized
on a national basis
legislature; national
President, Maria Estela
Voting strength: Justicialista Front, 61%: Radicals
(former People''s Radical Civic Union, UCRP), 2496;
Federal Popular Alliance, 12%; others, 3%
Communists: some 70,000 members in various
party organizations, including a small nucleus of
activists
Other political or pressure groups: Argentine
armed forces, Peronist-dominated labor movement,
General Economic Confederation (Peronist-leaning
association of small businessmen), Argentine
Industria] Union (manufacturer''s association),
Argentine Rural Society (large landowners as-
sociation), business organizations, students, and the
Catholic Church
0001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00080001
January 1976
ARGENTINA/A USTRALIA
Member of; FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDA. IDB, IFC, IHO, ILO, IMCO, IMF,
ITU, LAFTA. OAS, Seabeds Committee, UN,
UNESCO, UPU. WCL, WFTU, WHO, WMO, Non-
Aligned Nations Group','4474a70eaa490ad53cdf44b01dbea49d4e71c0ace874e8bcb8c94d6757539f7c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b1cdd4b66981b51145908a1ff3cc01439f2f36d33591816592795ab83618f55',1976,'AU','Australia','government',31,'Legal name: Commonwealth of Australia
Type: federal state recognizing Elizabeth 1l as
sovereign or head of state
Capital: Canberra
Political subdivisions: 6 states and 2 territories
(Australian Capital Territory (Canberra) and
Northern Territory)
Legal system: based on English common law;
constitution adopted 1900; High Court has
jurisdiction over cases involving interpretation of the
constitution; accepts compulsory IC] jurisdiction,
with reservations
Branches: Parliament. (House of Representatives
and Senate); Prime Minister and Cabinet responsible
to House; independent judiciary
Government leaders: Governor General Sir John
Kerr; Prime Minister John Malcolm Fraser
Suffrage: universal over age 21
Elections: held at 3-year intervals, or sooner if
Parliament is dissolved by Prime Minister; last
election December 1975
Political parties and leaders: Government. —
Liberal Party (Malcolm Fraser) and National Country
Party (Douglas Anthony); opposition — Labour Party
(Gough Whitlam)
Voting strength (1975 Parliamentary election —
lower House): Liberal-Country Coalition, 91 seats;
Labour Party, 35 seats; 1 seat undecided
Communists: 3,900 members (est. }
Other political or pressure groups: Democratic
Labour Party (anti-Communist Labour Party splinter
group)
Member of: ADB, ANZUS, Colombo Plan,
Commonwealth, DAC, ELDO, ESCAP, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IEA, IFC, 1HO, 1LO,
IMCO, IMF, IPU, ITU, OECD, Scabeds Committee,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Papua New Guinea
Type: independent state within Commonwealth
recognizing Elizabeth II as head of state
Capital: Port Moresby
Political subdivisions: 18 administrative districts
(12 in New Guinea, 6 in Papua)
Legal system: based on English common law
Branches: executive—Executive Council; legisla-
ture — House of Assembly (100 members, plus 4
appointed); judiciary — court system consists of
Supreme Court of Papua New Guinea and various
inferior courts (District Courts, Local Courts,
Children''s Courts, Wardens’ Courts)
Government leader: Governor General, Sir John
Guise; Prime Minister, Michael Somare
Suffrage: universal adult suffrage
Elections: preferential-type elections for 100-
member House of Assembly every 4 years
Political parties: Pangu Party is principal political
group; 5 or 6 other small parties and numerous
independents
Voting strength (1972 election): Pangu Party and
Allies won 52 seats, United Party 42 seats,
Independence 6 seats
Communists: no significant strength
Member of: ADB, Commonwealth, IBRD, IMF,
U.N., WHO (associate)','31985a1018934146f40a2c16d688166f67637cc041957b7553de9565329255b9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72e41741ff15a04e6d86e25765e6f01f11c6834a29b45ec462fb5648d29e6258',1976,'AT','Austria','government',38,'Legal name: The Commonwealth of The Bahamas
Type: independent commonwealth since July 1973,
recognizing Elizabeth II as chief of state
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
THE BAHAMAS/BAHRAIN
Capital: Nassau (New Providence Island)
Legal system: based on English law
Branches: bicameral legislature (appointed Senate,
clected House); executive (Prime Minister and
cabinet); judiciary
Government leaders: Prime Minister Lynden O.
Pindling
Suffrage: universal over age 18
Elections: House of Assembly (9 September 1972)
Political parties and leaders: Progressive Liberal
Party (PLP), predominantly Negro, Lynden O.
Pindling; Free National Movement (FNM) formed by
a merger of United Bahamian Party (UBP) and Free
Progressive Liberal Party (Free PLP), Kendall Isaacs
Voting strength (1972 election): FLP 29 seats,
FNM 9 seats
Communists: negligible
Member of: IMF, Seabeds Committee, U.N.,
WMO','195936cc368a2e160965bdcacd81090947095caeea3072db5bbae9099b176353','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('479ab3ebdf26ebf7c30a7ae1eac4baca261f4821dad46a64a46d15ecde431873',1976,'BH','Bahrain','government',41,'Legal name: State of Bahrain
Type: traditional monarchy: independence
declared in 1971
Capital: Al Manamah
Legal system: based on Islamic law and English
common law: constitution went into effect December
1973
Branches: Emir rules with help of a cabinet led by
Prime Minister; a national assembly, made up of
cabinet and 30 directly elected members, was formed
in early 1974; Emir dissolved assembly in August 1975
and suspended the Constitutional provision for
election of the assembly
Government leader: Emir ‘Isa ibn Salman Al-
Khalifah
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BAHRAIN/BANGLADESH
Political parties and pressure groups: political
parties prohibited; no significant pressure groups
although numerous small clandestine groups are
active
Communists: negligible
Member of: Arab League, FAO, GATT (de facto),
IBRD, ICAO, IMF, OAPEC, Seabeds Committee,
U.N., UNESCO, WHO','21c7466f7fb22d9c33093e3a2795afa5b819375d94f7fa593b41275835c3aa65','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d0f8134a9c7e94414e360a07a1aec9177fe38ebb8f84bc6821c4ab7716b68e6',1976,'BD','Bangladesh','government',46,'Legal name: Peoples Republic of Bangladesh
noun—Bengalee(s); adjective—
13
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BANGLADESH/BARBADOS
Type: independent republic since December 1971;
Government of President Sheikh Mujibur Rahman
overthrown in August 1975; two other coups followed;
country currently governed by military-backed
martial law administration with civilian president and
three military service chiefs as deputy martial law
administrators
Capital: Dacca
Political subdivisions: 19 districts, 413 thanas
(counties), 4,053 unions (village groupings)
Legal system: based on English common law:
constitution adopted December 1972; amended
January 1975 to more authoritarian Presidential
system
Branches: constitution provides for unicameral
legislature, strong President: controlled judiciary;
Parliament dissolved by current regime
Government leader: President A. M. Sayem
Suffrage: universal over age 18
Elections: First Parliament (House of the Nation)
elected in March 1973; elections every 5 years:
Government has banned political activity but has
announced intention to lift ban in 1976, and hold
elections in 1977
Communists: 2.500 members (est. )
Other political or pressure groups: student groups,
bands of former guerrillas
Member of: ADB, Afro-Asian People''s Solidarity
Organization, Colombo Plan, Commonwealth,
ESCAP, GATT, IAEA, IBRD. ICAO, IDA, IMF,
ILO, Seabeds Committee. U.N., UNCTAD,
UNESCO, UPU, WHO','6cea064ecd6417d61ae0bd7908370926edc650f28fc3de75a32b3f87f3376f21','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abec04a4ee1e8e467da3951c24656361917a29f2b71387779a975a179928e1c7',1976,'BB','Barbados','government',50,'Legal name: Barbados
Type: independent sovereign state within the
Commonwealth since November 1966, recognizing
Elizabeth II as chief of state
Capital: Bridgctown
Political subdivisions: 11 parishes
Legal system: English common law; constitution
came into effect upon independence in 1966; no
judicial review of legislative acts; has not accepted
compulsory IC] jurisdiction
Branches: legislature consisting of a 21-member
appointed Senate and a 24-member elected House of
Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister Errol Walton
Barrow; Governor General Sir Winston Scott
Suffrage: universal over age 18
Elections: House of Assembly members have terms
no longer than 5 years; last general election held 9
September 1971
Political parties and leaders: Democratic Labor
Party (DLP), Errol Barrow; Barbados Labor Party
(BLP), J. M. G. "Tom" Adams
Voting strength (1971 election): Democratic
Labor Party (DLP), 57.5%; Barbados Labor Party,
42.5%; Independent, negligible; House of Assembly
scats — DLP 18, BLP 6
Communists: negligible
Other political or pressure groups: People’s
Progressive Movement (PPM), a small black-
nationalist group led by Calvin Alleyne
Member of: CARICOM, Commonwealth, FAO,
GATT, IADB, ICAO, IDB, ILO, IMCO, IMF, ITU,
OAS, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO
Approved For Release 2005/04/22 :','74337a9fb6961fabc68bf9a8688029a80d1fdf5b28603b4fb54ebc96a098fbcd','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e34ece60b0799b8bfc645a8d17b54419da766c0e4dc44a2f41e6dd152987a04',1976,'BE','Belgium','government',54,'Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil law system influenced by
English constitutional theory; constitution adopted
1831, since amended; judicial review of legislative
acts; legal education at 4 law schools; accepts
compulsory [CJ jurisdiction, with reservations
Branches: executive branch consists of King and
cabinet; cabinet responsible to bicameral parliament;
independent judiciury; coalition governments are
usual
Government leader: Head of State, King
Baudouin; Prime Minister Leo Tindemans
16
Suffrage: universal over age 21
Elections: held 10 March 1974 (held at least once
every 4 years)
Political parties and leaders: Social Christian,
Charles-Ferdinand Nothomb and Wilfred Martens,
co-presidents; Socialist, Andre Cools and Willy Claes,
co-presidents; Liberty and Progress, Senator P.
Deschamps, national president; Liberal Democratic
and Pluralist Party, Rolland Gillet, party president;
Francophone Democratic Front-Walloon Rally
(Walloon nationalist), Leo Defosset, national
president; Volksunie (Flemish Nationalist), Hugo
Schlitz, party president; Communist, Louis Van Gent,
president of political bureau
Voting strength (1974 election): 72 seats Social
Christian, 59 seats Socialist, 30 seats Liberty and
Progress, 22 seats Volksunie, 22 seats Francophone
Democratic Front-Walloon Rally, 4 seats Communist,
3 seats Democratic and Pluralist
Communists: 10,000 members (est.)
Other political or pressure groups: Christian and
Socialist Trade Unions; the Federation of Belgium
Industries; numerous other associations representing
bankers, manufacturers, middle-class artisans, and the
legal and medical professions; two major organiza-
tions represent the cultural interests of Flanders and
Wallonia
Member of: ADB, Benelux, BLEU, Council of
Europe, DAC, EC, ECE, ECOSOC, ECSC, EEC,
EIB, ELDO, EMA, ESRO, EURATOM, FAO,
GATT, IAEA, IBRD, ICAO, IDA, IEA, IFC, ILO,
IMCO, IMF, IPU, ITU, NATO, OAS (observer),
OECD, Seabeds Committee, U.N., UNESCO, UPU,
WCL, WEU, WHO, WMO','696b1b4c8506e1dd527a3da3c39d26a30751312f670e1242c691452db70d03d9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4731dd83efa9069d68cc2dcb529de621d58ea220bb43dc13c5472b4f0e4b41ef',1976,'BZ','Belize','government',59,'Legal name: Belize
Type: internal self-governing British colony
Capital: Belmopan
Legal system: English law; constitution came into
force in 1964, although country remains a British
colony
- 00800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0
January 1976
BELIZE/BERM UDA
Branches; 18-member elected National Assembly
and 8-member Senate (either house may choose its
Speaker or president, respectively, from outside its
elected membership); cabinet; judiciary
Government leader: Premier George Price
Suffrage: universa] adult (probably 21)
Elections; must be held within 5 years of last
elections held in October 1974
Political parties and leaders; People''s United
Party (PUP), George Price; United Democratic Party
(UDP), a coalition comprised of the National
Independence Party (NIP) led by Philip Goldson, the
People''s Democratic Union (PDM) led by Dean
Lindo, and the Libera] Party (LP) led by Harry
Laurence; Corozal United Front (CUF), Santiago
Ricalde; United Black Association for Development
(UBAD), Evan X. Hyde
Voting Strength (National Assembly): PUP 12
seats, UDP 6 seats
Communists: negligible
Other political or pressure groups: Christian
Workers’ Union (CWU) which is connected with PUP
Member of; CARICOM, WCI,','f48f0637ac99b49d8c58a81c26f84fb5c87c78b5f5ac44cd85c61961e0b0b40e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3a6ab37d631651a1270d144d93e54535e130bd07fa6fb64fc8c6f1ebcea835d',1976,'BM','Bermuda','government',63,'Legal name: Colony of Bermuda
Type: British colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English law
Branches: Executive Council (cabinet) appointed
by governor, led by government leader; bicameral
legislature with an appointed Legislative Council,
and a 40-member directly elected House of Assembly
Government leaders: Governor Sir Edwin Leather;
Government Leader (equivalent to Premier) Sir
Edward Richards
Suffrage: universal over age 21
Elections: at least once every 5 years; last general
election, June 1972
Political parties and leaders: United Bermuda
Party (UBP), Sir Edward Richards; Progressive Labor
Party (PLP), Walter N.H. Robinson
Voting strength (1972 elections): UBP 61.2%, PLP
38.8%; House of Assembly seats — UBP 30, PLP 10
Communists: negligible
Other politieal or pressure groups: Bermuda
Industrial Union (BIU)','224d54d86aa8698204e77a16157db42db2e7a0a7cdea15537ed1701b35e062e5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82d6893676c332e055fb37339ffe58b2a1ff48b723c370d8d57f3ec5eae5c43e',1976,'IN','India','government',67,'Capital: Thimphu
Political subdivisions: 4 regions (east, central,
west, south), further divided into 15-18 subdivisions
Legal system: based on Indian law and English
common law; in 1964 the monarch assumed full
power — no constitution existed beforehand; a
supreme court hears appeals from district administra-
tors; has not accepted compulsory IC] jurisdiction
Branches: appointed minister and indirectly
clected asscmbly consisting of village elders, monastic
representatives, and all district and senior government
administrators
Government leader: King Jigme Singhi Wangchuk
19
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BHUTAN/BOLIVIA
Suffrage: cach family has one vote
Elections: popular elections on village level held
every 3 years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist
clergy
Member of: Colombo Plan, Scabeds Committee,
UPU, U.N.
Legal name: Republic of Bolivia
Type: republic; de facto military dictatorship
Capital: La Paz (seat of government) Sucre
(judicial capital)
Political subdivisions: 9 departments with limited
autonomy
Legal system: based on Spanish law and Code
Napoleon; constitution adopted 1967; constitution in
force except where contrary to dispositions dictated by
governments since 1969; legal education at University
of San Andres and several others; has not accepted
compulsory [CJ jurisdiction
Branches: executive; congress of two chambers
(Senate and Chamber of Deputies), congress
disbanded after 26 September 1969 ouster of President
Siles; judiciary
Government leaders: President Hugo Banzer
Suarez
Suffrage: universal and compulsory at age 18 if
married, 21 if single
Elections: postponed indefinitely
Political parties and leaders: political activities are
proscribed indefinitely; most party leaders are in exile
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BOLIVIA/ BOTSWANA
Voting strength (1966 elections): Frente de la
Revolucion Boliviana (a coalition composed of the
MPC, PIR, PRA, PSD, and two interest groups, the
campesinos and Chaco War Veterans) 61%, FSB 1296,
MNR 10%, other 17%
Communists: three parties (all proscribed);
PCB/Soviet led by Jorge Kolle Cucto, about 300
members: PCB/Chinese led by Oscar Zamora, 150
(including 100 in exile); POR (Trotskyist), about 50
members divided between three factions led by Hugo
Gonzalez Moscoso, Guillermo Lora Escobar, and
Amadeo Arze
Member of: FAO, IAEA, [ADB, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMF, ITU, International Tin
Council, LAFTA and Andean Sub-Regional Group
(created in May 1969 within LAFTA), OAS, Scabeds
Committee, U.N., UNESCO, WCL, WHO, WMO
Legal name: Republic of India
Type: federal republic
Capital: New Delhi
Political subdivisions: 22 states, 9 union territories
Legal system: based on English common law;
constitution adopted 1950; judicial review of
legislative acts; accepts compulsory IC] jurisdiction,
with reservations
Branches: parliamentary government, national and
state; independent judiciary
Government leader: Prime Minister Indira
Gandhi
Suffrage: universal over age 21
Elections: national and state elections ordinarily
held every 5 years; may be postponed in emergency
and may be held more frequently if government loses
confidence vote; next general election due by March
1976 but may be postponed because of a national
emergency declared on June 26, 1975; most states to
hold state elections in 1977
Political parties and leaders: Indian National
Congress split into two factions in 1969, largest faction
(the Ruling Congress) loyal to Prime Minister Gandhi
led by D. K. Barooah, and dwindling faction (the
Organization Congress) led by Ashoka Mehta;
Communist Party of India (CPI) S. A. Dange,
chairman; Communist Party of India/Marxist
(CPI/M), P. Sundarayya, general secretary;
Communist Party of India/Marxist-Leninist (CPI/
ML), L. K. Advani, chairman; Bharatiya Jana Sangh,
A. B. Vajpayee, president; The Socialist Party,
George Fernandes, chairman, Dravida Munnetra
Kazhagam (DMK), N. Karunanidhi, president;
Bharatiya Lok Dal (BLD), Charan Singh, chairman
Voting strength (1971 election): 43.7% Ruling
Congress, 10.5% Organization Congress, 7.4%
Bharatiya Jana Sangh, 3.1% Swatantra, 4.8% CPI,
5.2% CPI/M, 3.5% Socialist Parties, 3.7% DMK,
18.1% other
Communists: 90,000 members of CPI (est. ), 85,000
members of CPI/M (est.); Communist sympathizers,
13 million
Other political or pressure groups: Anna Dravida
Munnetra Kazhagam (ADMK), M. G. Rama-
chandran, president, opposing DMK in Tamil Nadu;
splintered Akali Dal representing Sikh religious
community in the Punjab; various separatist groups
seeking reorganization of states; numerous “senas” or
militant/chauvinistic organizations, including Shiv
Sena and Dalit Panthers in Bombay, the Anand Marg,
and the Rashtriya Swayamserak Sangh
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
INDIA/INDONESIA
Member of: ADB, Colombo Plan, Commonwealth,
FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHO,
ILO, IMCO, IMF, IPU, ITU, Seabeds Committee,
U.N., UNESCO, UPU, WCL, WFTU, WHO, WMO','a8deeab4eb37af0c0f924d8e120d74c5a225d400a33f8506bf6cc07aef477ee0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3090321772b5b8d1b039ae14a09f4d66ef80ed8b7a563844f5778c5937dbb3ae',1976,'BW','Botswana','government',73,'Legal name: Republic of Botswana
Type: parliamentary republic: independent
inember of commonwealth since 1966
Capital: Gaborone
Political subdivisions: 12 administrative districts
Legal system: based on Reman-Dutch law aud
local customary law: constitution came into effect
1966; judicial review limited to matters of
interpretation; legal education at University of
Botswana, Lesotho and Swaziland (2% years} and
University of Edinburgh (2 years): has not accepted
compulsory IC] jurisdiction
Branches: executive — President appoints and
presides over the cabinet which is responsible to
Legislative Assembly; legislativo — Legislative
Assembly with 32 popularly elected members and 4
members elected by the 31 representatives, House of
Chiefs with deliberative powers only; judicial — local
courts administer customary law, High Court and
subordinate courts have criminal jurisdiction over all
residents, Court of Appeal has appellate jurisdiction
Government leader: President Seretse Khama
Suffrage: universal, age 21 and over
Elections: general elections held 26 October 1974
Political parties and leaders: Botswana Demo-
cratic Party (BDP), Seretse Khama: Bechuanaland
Peoples Party (BPP). Philip Matante; Botswana
Independence Party (BIP). Motsamai Mph»:
Botswana National Front (BNF) Kenneth Koma
Voting strength: (October 1974 election) BDP (27
seats); BPP (2 seats): BNF (2 seats}: BIP (1 seat)
Communists: no known Communist organization:
Koma of BNF has long history of Communist contacts
Member of: AFDB, Commonwealth, FAO, GATT
(de facto), IBRD, IDA, IMF, ITU, OAU, U.N., UPU
WMO
Ex
nS
Approved For Release 2005/04/22','61b74a970f42f700ecf133abcda3e05f6d7d4d4efaeee02da981eaa1067a48a1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('551185495ee4557d03362e5e71a750a7e96aac4b5d653f9d75cd598f31534b75',1976,'BR','Brazil','government',77,'Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presiden-
tial regime since April 1964
Capital: Brasilia
Political subdivisions: 21 states, 4 territories,
federal district (Brasilia)
Legal system: based on Latin codes; dual system of
courts, state and federal; constitution adopted 1967
and extensively amended in 1969; has not aceepted
compulsory ICJ jurisdiction
Branches: strong cxecutive with very broad powers;
bicameral legislature (powers of the two bodies have
been sharply reduced); 11-man Supreme Court
Government leader: President Ernesto Geisel
Suffrage: compulsory over age 18, except illiterates
and those stripped of their political rights;
approximately 30 million registered voters in October
1970
Elections: President Medici''s successor was chosen
by a 505-member electoral college, composed of the
members of Congress and delegates selected from the
state legislatures, on 15 January 1974 and took office
on 15 March 1974; Geisel was the choice of Medici
and top military chiefs
Voting strength: (November 1974 congressional
elections) 33.6% ARENA, 31.9% MDB, 35.5% blank
and void
Political parties and leaders: National Renewal
Alliance (ARENA), pro-government Francelino
Pereira, president; Brazilian Democratic Movement
(MDB), opposition, Ulisses Guimaraes, president
Communists: 6,000, 1,000 militants
Other political or pressure groups: excepting the
military, the Catholic Church is the only active
nationwide pressure group, however, divisions within
the Church often prevent it from speaking with one
voice; labor and student groups have almost no
influence on the government
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, IHO, ILO, IMCO, IMF,
IPU, ITU, LAFTA, OAS, Seabeds Committee, U.N.,
UNESCO, UPU, WCL, WFTU, WHO, WMO
Legal name: British Solomon Islands Protectorate
Type: British protectorate administered as crown
colony
Capital: Honiara
Political subdivisions: 4 administrative districts
Legal system: a High Court plus Magistrates
Courts, also a system of native courts throughout the
islands
Branches: executive authority in High Commis-
sioner; a legislative assembly of 24 elected members, a
few appointed members
Government leaders: Governor D.C.C. Ludding-
ton and Chief Minister Mamaloni
Suffrage: universal age 21 and over
Elections: every 4 years, latest May-June 1973
Political parties and leaders: United Solomon
Islands Party
Member of: ADB
Legal name: State of Brunci
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: 4 administrative districts
Legal system: based on Islamic law; constitution
promulgated by the Sultan in 1959
Branches: chief of state is Sultan (advised by
appointed Privy Council) who appoints Executive
Council and Legislative Council
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 3-tiered system
of indirect elections; popular vote cast for lowest level
(district councilors)
Elections: last elections — March 1965; further
clections postponed indefinitely
Political parties and leaders: antigovernment,
exiled Brunei Peoples Party, Chairman A. M. N.
Azahari
Communists: information not available','96638c8b7f8033928158bbfea790d6c7162016dae6c766cfe023de497c3671b4','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('123759a502619e576dde9d4bf464b3fd85c8d6cf38d0b29b8ed61a39061491da',1976,'BG','Bulgaria','government',82,'Legal name: Socialist Republic of the Union of
Burma
Type: republic under new 1974 constitution
Capital: Rangoon
Political subdivisions: seven divisions and seven
constituent states; subdivided into townships, villages,
and wards
Legal system: People''s Justice system and People’s
Courts instituted under 1974 constitution; legal
education at Universities of Rangoon and Mandalay;
has not accepted compulsory IC] jurisdiction
Branches: State Council rules through a Council of
Ministers; People’s Assembly has legislative power
Government leader: Chairman of State Council
and President, Gen. U. Ne Win
Suffrage: universal over age 18
27
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BURMA/BURUNDI
Elections: People''s Assembly and local People''s
Councils elected in 1974
Political parties and leaders: government-
sponsored Burmese Socialist Program Party only legal
party
Communists: estimated 5,000-8,000
Other political or pressure groups: People’s
Patriotic Party; Kachin Independence Army; Karen
Nationalist Union, several Shan factions
Member of: ADB, Colombo Plan, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO, IMCO,
IMF, ITU, Seabeds Committee, U.N., UNESCO,
UPU, WHO, WMO','8b32cb743e4008d0d359a5df9a282e223a36a70320e9bdf56986e2faa9e6e811','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dfe8bae70bddf2483a379d6e2afb52d7bd5db2698fc92c0818bfc7816ce7bba',1976,'BI','Burundi','government',85,'Legal name: Republic of Burundi
Type: republic; military government since
November 1966; no constitution; new constitution
being drafted
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BURUNDI/CAMBODIA
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into
18 arrondissements and 78 communes
Legal system: based on German and French civil
codes and customary law: has not accepted
compulsory ICJ jurisdiction
Branches: Presidential Cabinet with Council of
Ministers; no legislature
Government leader: President Michel Micombero;
re-elected by party for seven-year term in October
1974
Elections: last legislative election May 1965
Political parties and leaders: National Party of
Unity and Progress (UPRONA), a predominantly
Tutsi party, was declared sole legitimate party in 1966
Communists: no Communist party; resumed
diplomatic relations with The Peoples Republic of
China in October 1971 following a six-year
suspension; U.S.S.R. and North Korea have
diplomatic missions in Burundi
Member of: AFDB, EAMA, ECA, FAO, CATT,
IBRD, ICAO, IDA, ILO, IMF, ITU, OAU, U.N.,
UNESCO, UPU, WHO, WMO','aa46d8648dbf675e03ba5f2e09db4da0087391ebf3125239f14d4028037e4d48','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0d5361e3c517da66671ccad2d808360d6c804c0fd8ed6c5144db55867105144',1976,'GN','Guinea','government',91,'Legal name: United Republic of Cameroon
a Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
| i ci EMEN
Approved
For Release 2005/04/22 : CIA-RDP79-01051A00
January 1976 0800010001-8
CAMEROON/CANADA
Type: unitary republic; one-party presidential Major trade partners: about 70% of total trade
regime with France and other EC countries; about 12% o
Capital: Yaounde total trade with US.
Budget: FY76 budget est. halanced at $500 million
Monetary conversion rate: 216 Communaute
Financiere Africaine francs = US$1 as of January 1975
Fiscal year: 1 July - 30 June
Legal name; Dominion of Canada
Type: federal state recognizing Elizabeth TI
sovereign
Capital: Ottawa
Political subdivisions: 10 provinces and 2
territories
Legal system; based on English common law,
except in Quebec, where civil law system based on
French law prevails; constitution is British North
America Act of 1867 and various amendme
accepts compulsory IC] jurisdiction, with reservatic
Branches: federal executive power vested in cabinet
collectively responsible to House of Commons, and
headed by Prime Minister; federal legislative
authority resides in Parliament consisting of Queen
represented by Governor-Genera],
Commons; judges appointed by Governor-General on
the advice of the government, Supreme Court is
highest tribunal
Government leader: Pierre Flliott Trudeau
Suffrage: universal Over age 18
Elections: legal limit of 5 years, last election July
1974
Political parties and leaders; Liberal, Pierre
Trudeau: Progressive-Conservatives, Robert Stanfield:
New Democratic, David Lewis; Social Credit, Real
Caouette
Voting strength (1974 election); Liberal 43%
seats), Progressive Conservative 35% (95 seats), New
Democratic Party 16% (16 seats), Social Credit 5%
seats), other 1%, Independents hold l seat
Communists; 2.000
Member of; ADB, Colombo Plan, Common-
wealth, DAC, FAQ, GATT, TAFA, IBRD, ICAO,
32
January 1976
Legal name: Republic of Guinea
Type: republic; under one-party presidential
regime
Capital: Conakry
Political subdivisions: 29 administrative regions,
209 arrondissements, about 8,000 local entities at
village level
Legal system: based on French civil law system,
customary law, and presidential decree; constitution
adopted 1958; no constitutional provision for judicial
review of legislative acts; has not accepted compulsory
IC] jurisdiction
Branches: exccutive branch dominant, with power
concentrated in President''s hands and a small group
who are both ministers and members of the party''s
politburo; unicameral National Assembly and
judiciary have little independence
Government leader: President Ahmed Sekou
Toure, who has been designated "The Supreme
Leader of the Revolution"
Suffrage: universal over age 18
Elections: approximate schedule — 5 years
parliamentary, latest in 1975; 7 years Presidential,
latest in 1975
Political parties and leaders: only party is
Democratic Party of Guinea (PDG), headed by Sekou
Toure
Communists: no Communist party, although there
are some sympathizers
Member of: AFDB, ECA, FAO, IBRD, ICAO,
IDA, ILO, IMF, ITU, Niger River Commission,
OAU, U.N., UNESCO, UPU, WCL, WHO, WMO
noun—Guinean(s); adjective—
85
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GUINEA/GUINEA-BISSAU
Legal name: Republic of Senegal
Type: republic
Capital: Dakar
Political subdivisions: 7 regions, each subdivided
into 18 departments, 90 districts, and 84 communes
Legal system: based on French civil law system;
constitution adopted 1960, revised 1963 and 1970;
judicial review of legislative acts in Supreme Court
(which also audits the governments accounting
office); legal education at University of Dakar; has
not accepted compulsory IC] jurisdiction
Branches: Government dominated by President
who is assisted by Prime Minister, appointed by
President and subject to dismissal by President or
censure by National Assembly; 80-member National
Assembly, elected for 5 years (effective 1973);
President elected for 5-year term (effective 1973) by
universal suffrage; judiciary headed by Supreme
Court, with members appointed by President
Government leaders: Leopold Sedar Senghor,
President; Abdou Diouf, Prime Minister
Suffrage: universal adult
Elections: uncontested presidential and legislative
clections held February 1973 for 5-year term
Political parties and leaders: Union Progressiste
Senegalaise (UPS), ruling party led by President
Leopold Senghor; Parti Democratique Senegalaise
181
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SENEGAL/SEYCHELLES
(PDS), legal opposition party founded July 1974,
illegal parties include Communist-backed | Parti
(PAI) and Parti
Communiste Senegalais (PCS), a splinter group
Africain de l''Independence
Communists: a few Communists and sympa-
thizers; PAI is pro-Moscow; PCS in pro-Peking
Other political or pressure groups: labor unions
are controlled by party; students and teachers
occasionally strike
Member of: AFDB, CEAO, EAMA, ECA,
ECOWAS, EIB (associate), FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, ITU,
OAU, OCAM, OMVS (Organization for the
Development of the Senegal River Valley), Seabeds
Committee, U.N., UNESCO, UPU, WCL, WHO,
WMO','5bd61b4f54f86db71545d64dc8d8ff76b47b1926752ca257595ab6f40cb59131','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed7c58f55a2127253ea6197bdf490b756e98dc83208332ac4bc3f25940c9a561',1976,'CA','Canada','government',92,'ICRC, IDA, IDB, IFA, IFC, IHO, ILO, IMCO, IMF,
IPU, ITU, NATO, OAS (observer), OECD, Seabeds
Committee, U.N., UNCTAD, UNESCO, UPU,
WCL, WHO, WMO
Legal name: Republic of Cape Verde
Type: republic; achieved independence from
Portugal in July 1975; government being formed;
expected to establish union with Guinea-Bissau
Capital: Praia
Political subdivisions: 10 islands
Legal system: to be determined
Branches: National Assembly, 56 members; the
official party is the supreme political institution
Government leaders: President of the National
Assembly, Abilio Duarte; Prime Minister, Pedro Pires
Suffrage: universal over age 18
Elections: to be determined
Political parties and leaders: Partido Africano da
Independencia da Guinee c Cabo Verde (PAIGC), led
by Aristide Pereira, only legal party
Communists: none known','3383c6d9071ccbd0124d6f4ee711abbfa8d00b7622a1699043860f096739f96e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64a11c6ee44ae74e8baf641f419f86e2418479545997963fe185a7a11edfd82e',1976,'CF','Central African Republic','government',98,'Legal name: Central African Republic
Type: republic; constitution abrogated following
military coup in January 1966
34
Capital: Bangui
Political subdivisions: 14 prefectures, 47 subpre-
fectures
Legal system: based on French, Islamic, and tribal
law; in 1966 the Chief of State assumed all power and
abrogated the existing constitution; has not accepted
compulsory IC] jurisdiction
Branches: Gen. Bokassa heads government and
rules by decree; assisted by cabinet called Council of
Ministers; judiciary, including Supreme Court, court
of appeals, criminal court, and numerous lower courts
Government leader: President for life Jean-Bedel
Bokassa
Suffrage: universal over age 21
Elections: none have been held under Bokassa
regime
Political parties and leaders: Black African Social
Evolution Movement (MESAN), ruling party under
former regime, still in existence but plays little role,
led by President Jean-Bedel Bokassa
Communists: no Communist Party or significant
number of sympathizers
Member of: AFDB, Conference of East and
Central African States, EAMA, ECA, FAO, GATT.
IBRD, ICAO, IDA, ILO, IMF, ITU, OAU, OCAM,
Seabeds Committee, UDEAC, UN., UNESCO,
UPU, WCL, WHO, WMO','0360cfa5d48543b9411d19b9fb28d739439120fb3622d9927b7b655f35ea0a70','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63aefcba5efadea3812730d6178a62119715ea748be573dc597002317e3e1923',1976,'TD','Chad','government',102,'Legal name: Republic of Chad
Type: republic; military regime in power since
April 1975
Capital: N''Djamena
Political subdivisions: 14 prefectures
Legal system: based on French civil law system
and Chadian customary law; constitution adopted
1962; constitution suspended and national assembly
dissolved April 1975; judicial review of legislative acts
in theory a power of the Supreme Court; has not
accepted compulsory IC] jurisdiction -
Branches: executive authority exercised by
Supreme Military Council composed of 9 officers
Government leader: President of Supreme Military
Council, General Felix Malloum
Suffrage: universal over age 20
Elections: all political activity banned
Political parties and leaders: political parties
banned
Communists: no front organizations or un-
derground party; probably a few Communists and
some sympathizers
Other political or pressure groups: lightly armed
Muslim rebel bands have been opposing the
government since October 1965 in east-central and
since August 1969 in northern Chad
Member of: AFDB, Conference of East and
Central African States, EAMA, ECA, FAO, GATT,
ICAO, IBRD, IDA, ILO, IMF, ITU, Lake Chad
Basin Commission, OAU, OCAM, Scabeds Commit-
tee, UEAC, U.N., UNESCO, UPU, WCL, WHO,
WMO
35
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CHAD/CHILE','795ff3aee0d14e0b677caac02c59bc83a82a972b0140b676ef87faa1ca9c0df7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3388f7bf8083e91c7a9af33feaf1cd02c701976e2a9e5dad61325bb23a6d6b70',1976,'CL','Chile','government',106,'Legal name: Republic of Chile
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Type: republic
Capital: Santiago
Political subdivisions: reorganization of regional
structure in progress
Legal system: based on Code 1857 derived from
Spanish law and subsequent codes influenced by
French and Austrian law; constitution adopted 1925,
amended since then, currently being revised; judicial
review of legislative acts in the Supreme Court; legal
education at University of Chile, Catholic University,
and several others; has not accepted compulsory IC]
jurisdiction
Branches: President and 4-man Military-Police
Junta; bicameral legislature currently dissolved;
independent judiciary
Government leaders: President, Gen. Augusto
Pinochet Ugarte; other Junta members, Adm. jose
Toribio Merino Castro, Gen. Gustavo Leigh Guzman,
Gen. Cezar Mendoza Duran
Suffrage: universal (except enlisted. military and
police) and compulsory at age 18
Elections: none scheduled
Political parties and leaders: Christian Demo-
cratic Party (PDC), Patricio Aylwin and Eduardo
Frei; National Party (PN), Sergio Onofre Jarpa; PDC
and PN are officially in "recess"; Popular Unity
coalition parties (outlawed) — Communist Party
(PCCh), Luis Corvalan (in prison); Socialist Party
(PS) Clodomiro Almeyda and Carlos Altamirano
(both in exile); Radical Party (PR); Christian Left
(IC); United Popular Action Movement (MAPU);
Independent Popular Action (API)
Voting strength (1970 presidential election):
36.6% Popular Unity coalition, 35.3% conservative
independent, 28.176 Christian. Democrat; (1973
Congressional election) 44% Popular Unity coalition,
56% Democratic Confederation (PDC and PN)
Communists: 200,000
Other political or pressure groups: organized
labor; business organizations; landowners associa-
tions (SNA — Sociedad Nacional de Agricultura);
extreme leftist, Movement of Revolutionary Left
(MIR), outlawed; rightist, Patria y Libertad (PyL),
outlawed
Member of: ECOSOC, FAO, GATT, IADB, IAEA,
IBRD, ICAO, IDA, IDB, IFC, IHO, ILO, IMCO,
IMF, IPU, ITU, LAFTA and Andean Sub-Regional
Group (created in May 1969 within LAFTA), OAS,
Seabeds Committce, U.N., UNESCO, UPU, WCL,
WFTU, WHO, WMO
Legal name: Peoples Republic of China
Type: Communist state; real authority lies with
Communist party''s political bureau: the National
People’s Congress, in theory the highest organ of
government, in reality merely rubber stamps the
party''s programs; the State Council is the actual
governing organism
Capital: Peking
Political subdivisions: 21 provinces, 3 centrally
governed municipalities, and 5 autonomous regions
Legal system: before 1966, a complex amalgam of
custom and statute, largely criminal; little ostensible
development of uniform code of administrative and
civil law; highest judicial organ is Supreme People''s
Court although legal activity centered in parallel
nctwork of Public Security organs; laws and legal
procedure clearly subordinated to priorities of party
policy; whole system largely suspended during
Cultural Revolution, but gradually being revived
Branches: prior to 1966 control was exercised by
Chinese Communist Party, through State Council,
which supervised more than 50 ministries, commis-
sions, bureaus, etc., all technically under the standing
committee of the National People''s Congress; this
system broke down under "Cultural Revolution"
pressures but has been reconsolidated and streamlined
to 29 ministries
Government leader: Premier of State Council,
Chou En-lai; government subordinate to central
committee of CCP, under Chairman Mao Tse-tung
Suffrage: universal over age 18, though this is
academic
Elections: no meaningful elections
Political parties and leaders: Chinese Communist
Party (CCP), headed by Mao Tsc-tung; Mao is
Chairman of Central Committee; a new central
committee was formed at the 10th Party Congress
held in August 1978
Voting strength: 100% Communist for practical
purposes; no political nonconformity permitted
Communists: about 28 million party members in
1973
Other political or pressure groups: army (PLA)
remains a major force, although many soldiers who
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CHINA, PEOPLES REPUBLIC OF/CHINA, REPUBLIC OF
acquired a wide range of civil political-administrative
duties during the Cultural Revolution have been
removed; many veteran civilian officials, in eclipse
since the Cultural Revolution, have been reinstated;
mass organizations, such as the trade unions and the
youth league, have been rebuilt in the provinces;
plans are underway to rebuild the national
organizations
Member of: FAO, IAEA, IBRD, ICAO, IDA, IFC,
IHO, ILO, IMCO, IMF, ITU, Red Cross, Seabeds
Committee, U.N., UNESCO, UPU, WFTU, WHO,
WMO, other international bodies','289257909912d54c867a9b333f7b275b6360eb813a32fe13a640f185e22ae058','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8829ca93524248ba6a1b5c78133bcafa391c711b6eae67b9f9eb244103d4ead4',1976,'CN','China','government',110,'Legal name: Republic of China
Type: republic, one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 4 cities, 1
special municipality (Taipei)
Legal system: based on civil law system;
constitution adopted 1947, amended 1960 to permit
Chiang Kai-shek to be reelected, and amended 1972
to permit President to restructure certain government
organs; accepts compulsory IC] jurisdiction, with
reservations
Branches: 5 independent branches (executive,
legislative, judicial, plus traditional Chinese functions
of examination and control), dominated by executive
branch; President and Vice President elected by
National Assembly
Government leaders: President Yen Chia-kan;
Premier Chiang Ching-kuo
39
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CHINA, REPUBLIC OF/COLOMBIA
Suffrage: universal over age 20
Elections: national level — legislative yuan every 3
years but no general election held since 1948 election
on mainland (partial election for Taiwan province
representatives December 1969 and December 1972,
uext elections due December 1975); local level —
provincial assembly, county and municipal executives
every 4 years: county and municipal assemblies every
4 years
Political parties and leaders: Kuomintang, or
National Party, led by Chairman Chiang Ching-kuo,
has no real opposition; 2 insignificant parties are
Democratic Socialist Party, Young China Party
Voting strength (1972 provincial assembly
election): 58 seats Kuomintang, 13 seats in-
dependents
Other political or pressure groups: none
Member of: expelled from U.N. General Assembly
aud Security Council on 25 October 1971 and
withdrew on same date from other charter-designated
subsidiary organs; attempting to retain membership in
international financial institutions','bcb6fe64890860dad4f0e7e9c24905dd4e3459fbd1db19dca2b972364a6bacbb','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87b99f5f45fb40c1a4a585929728a4a4c8d4c8010cf926c35ce90735532785d0',1976,'CO','Colombia','government',114,'Legal name: Republic of Colombia
Type: republic; executive branch dominates
government structure
Capital: Bogota
Political subdivisions: 22 departments, 4 territorial
districts, 4 special districts, 1 federal district
Legal system: based on Spanish law; religious
courts regulate marriage and divorce; constitution
decreed in 1886, amendments codified in 1946 and
1968; judicial review of legislative acts in the Supreme
Court; accepts compulsory ICJ jurisdiction, with
reservations
Branches: President,
judiciary
bicameral legislature,
Government leader: President Alfonso Lopez
Michelsen
Suffrage: universal over age 21
Elections: every fourth year; last presidential and
congressional elections April 1974; municipal and
departmental elections, April 1972
Political parties and leaders: Libcral Party,
President Alfonso Lopez Michelsen, Conservative
Party, Alvaro Gomez Hurtado; National Popular
Alliance (ANAPO), Maria Eugenia Rojas de Moreno
Voting strength: 1974 presidential clection —
Alfonso Lopez Michelsen 55%, Alvaro Gomez
Hurtado 32%, Maria Eujenia Rojas de Moreno 9.5%;
1974 congressional clection — Senate: Liberal Party
59%, Combined Conservative Party 34%, ANAPO
6.2%; Chamber of Deputies: Liberal Party 56%,
Combined Conservative Party 31%, ANAPO 9.5%;
abstention by approximately 50% of eligible voters
Communists: 10,000-12,000 members est.
Other political or pressure groups: Communist
Party (PCC), Gilberto Vieira. White; PCC/ML,
Chinese Line Communist Party, led by Pedro Lupo
Leon Arboleda Roldan
Member of: FAO, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IFC, IHO, ILO, IMF, ITU, LAFTA and
Andean Sub-Regional Group (created in May 1969
within LAFTA), OAS, U.N., UNESCO, UPU, WCL,
WFTU, WHO, WMO
Legal name: Comoro Islands
Type: three of the four islands comprise a de facto
independent republic, following local government''s
unilateral declaration of independence from France in
july 1975; other island disallowed declaration and its
status is undecided; France supports independence in
principle and is negotiating with Comoran
government on legal transfer of sovereignty
Capital: Moroni
Political subdivisions: 3 prefectures, 3 district
councils
Legal system: French and Muslim law
Branches: supreme authority exercised by 1l-
member National Executive Council
Government leader: Said Mohamed Jaffar,
President of National Executive Council
Suffrage: universal adult
Elections: at discretion of Council of Ministers, on
advice of President; must be held betore expiration of
5-vear electoral mandate
Political parties and leaders: Comoran Demo-
cratic Union, Mohammed Dahlani; Democratic
Assembly of Comoros People, Said Mohamed Jaffar;
Comoros Socialist Party; Umma, Prince Said Ibrahim;
Mahorais Movement, Marcel Henry
Voting strength: in elections for Chamber of
Deputies in 1972, independence coalition of CDU
and DACP won 34 seats, Mahorais Movement won 5
Communists: information not available
Member of: OAU','c6dcd7a7176fde4876aa8664884016d9365f10e7e193c263843cd11e706fe772','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a311f86de65fa75dfdc5b2b85a6a7d17da548bd77ee79c9fe9c1f9a217e9592a',1976,'CG','Congo','government',118,'Legal name: Peoples Republic of the Congo
Type: republic; military regime established
September 1968
Capital: Brazzaville
Political subdivisions: 9 regions divided into
districts
Legal system: based on French civil law system
and customary law; constitution adopted 1963 and
1969
Branches: President, Prime Minister, Council of
State; National Assembly; judiciary presumably still
functions according to provisions of 1963 constitution,
all policy made by Congolese Workers Party Central
Committee and Politburo
Government leaders: President, Major Marien
Ngouabi; Prime Minister Henri Lopes
Suffrage: universal over age 18
Elections: last legislative elections June 1973
Political parties and leaders: Congolese Workers
Party (PCT) is only legal party; president, Marien
Ngouabi
Communists: unknown number of Communists
and sympathizers
Other political or pressure groups: Union of
Congolese Socialist Youth (UJSC), Congolese Trade
Union Congress (CSC), Revolutionary Union of
Congolese Union (URFC), General Union of
Congolese Pupils and Students (UGEEC)
Member of: AFDB, Conference of East and
Central African States, EAMA, ECA, EIB (associate),
FAO, GATT, IBRD, ICAO, IDA, ILO, IMF, ITU,
OAU, OCAM, Seabeds Committee, UDEAC, UEAC,
U.N., UNESCO, UPU, WFTU, WHO, WMO','562fc0667e2a8fd2ad832cb156de313ae748dbc2b145e86fa4c0a85d1add53a6','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d1cf2e9c533281f51d1cefbd75cd26f2627d1a1c3747b1cdb56f4dbc2127528',1976,'CK','Cook Islands','government',122,'Legal name: Cook Islands
44
ee
Pacific Ocean
A
o
FIJI ISLANDS
Pacific Ocean
{588 referente map Vil}
Type: self-governing in "free association" with
New Zealand; Cook Islands government fully
responsible for interna] affairs and has right at any
time to move to full independence by unilateral
action; New Zealand retains responsibility for externa]
affairs, in consultation with Cook Islands government
Capital: Rarotonga
Branches: New Zealand Governor General appoints
High Commissioner of Cook Islands, who represents
the Queen and the New Zealand government; High
Commissioner appoints the Premier; Legislative
Assembly of 29 members, popularly elected; House of
Arikis (chiefs), 15 members, appointed by High
Commissioner, an advisory body only
Government leader: Premier Albert Henry
Suffrage: universal adult
Elections: every 4 years, latest in December 1974
Political parties and leaders: Cook Islands Party,
Sir Albert Henry; Democratic Party, Dr. Thomas
Davis
Voting strength (1974): Cook Islands Party, 14
seats; Democratic Party, 8 seats','bfb8ec1daa5e86e93dfaa6baabd7740c8abe44abf489517559c2660f90c40669','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1f11071da7dac0d2c5159b85a03df7ea57709750500055fb4fa5ec425866aa0',1976,'CR','Costa Rica','government',126,'Legal name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system,
constitution adopted 1949; judicial review of
legislative acts in the Supreme Court; legal education
at University of Costa Rica; has not accepted
compulsory IC) jurisdiction
Branches: President, unicameral legislature,
Supreme Court clected by legislature
Government leader: President Daniel Oduber
Suffrage: universal and compulsory age 18 and
Over
Elections: cvery 4 years; next, February 1978
Political parties and leaders: National Liberation
Party (PIN), Daniel Oduber, Jose Figueres; National
Unification (UN), Francisco Calderon Guardia;
National Independent Party (PNI), Jorge Gonzalez
Marten; Democratic Reno-vation Party (PRD),
Rodrigo Carazo; Christian Democratic Party (PDC),
Jorge Monge Zamora, Socialist Action Party (PASO)
(Communist front), Marcial Aguiluz; Popular
Vanguard Party (PVP, Communist, illegal), Manuel
Mora
Voting strength (1974 election): National
Unification (coalition of PUN, PR, and PURA),
30.4% — 16 seats; PLN, 48.5% — 97 seats; PNI, 11%
— 6 seats; PRD, 9% — 8 seats; PASO, 2.396 — 2 seats
Communists: 3,200 members, 10,000 sympathizers
Other political or pressure groups: Costa Rican
Confederation of Democratic Workers (CCTD),
General Confederation of Workers (CGT), Chamber
of Coffee Growers, National Association for Economic
Development (ANFE)
Member of: CACM, FAO, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMF, IPU, ITU, OAS,
ODECA, Scabeds Committee, U.N., UNESCO,
UPU, WCL, WFTU, WHO, WMO
Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: the current system of 6
provinces, 59 regions, and 416 municipalities is being
reorganized, and, in March 1976, a new system
consisting of 14 provinces and from 170 to 180
municipalities will be adopted
Legal system: based on Spanish aud American law,
with large elements of Communist legal theory;
Fundamental Law of 1959 replaced Constitution of
1940; a new constitution was approved at the Cuban
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CUBA/CYPRUS
Communist Party''s First Party Congress in December
1975 and by a popular referendum to take place
immediately after the Congress; positions of the new
constitution will be put into effect on February 24,
1976, by means of a Constitutional Transition Law,
and the entire constitution will become effective on
December 2, 1976; legal education at Universities of
Havana, Oriente, and Las Villas; does not accept
compulsory IC] jurisdiction
Branches: executive; no legislature (Popular
Assemblies will be formed at the provincial and
municipal levels in October 1976 and at the national
level on December 2, 1976—the Popular Assemblies
will have legislative authority at their respective
levels); controlled judiciary
Government leader: Prime Minister Fidel Castro
Ruz
Suffrage: under the new constitution to be adopted
in 1976, suffrage will be universal, but not
compulsory, over age 16
Elections: clection of delegates to the Popular
Assemblies will be held in late summer 1976
Political parties and leaders: Cuban Communist
Party (PCC), First Secretary Fidel Castro Ruz, Second
Secretary Raul Castro Ruz
Communists: approx. 200,000 party members
Member of: CEMA, ECLA, FAO, GATT, IADB
(nonparticipant), ICAO, IHO, ILO, IMCO,
International Rice Commission, International Sugar
Council, International Wheat Agreement, ITU, OAS
(nonparticipant), Permanent Court of Arbitration,
Postal Union of the Americas and Spain, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WFTU,
WHO, WMO','6f4fa4eb9285f91c178156095f6ab95285853052af5f38b85145c693c3795417','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('626eeaadaa8894f0428047a733c6ec8ba7f224c1370c16f2b287484db994c9d3',1976,'CY','Cyprus','government',130,'Legal name: Republic of Cyprus
Type: republic since August 1960; separate de facto
| Greek Cypriot, and Turkish Cypriot governments
have evolved since outbreak of communal strife in
1963: this separation was further solidified following
the Turkish invasion of the island in July 1974;
negotiations, which have been going on since January
1975, have focused on the creation of a federal system
of government with substantial autonomy for each of
the two communities
Capital: Nicosia
Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil
law modifications; negotiations to create the basis for
a new or revised constitution to govern the island and
relations between Greek and Turkish Cypriots have
been going on intermittently
Branches: currently a rump government consisting
basically of Greck Cypriot parts of bodies provided for
by constitution; headed by President of the Republic
and comprised of Council of Ministers, House of
Representatives, and Supreme Court
Government leaders: President, Archbishop
Makarios III (Greek); Vice President, Rauf Denktash
(Turk)
48
Approved For Release 2005/04/22
Suffrage: universal age 21 and over
Elections: held every 5 years; 1965 elections
suspended; 1968 elections only for President and Vice
President; 1970 parliamentary elections demonstrate
notable increase in voting strength of Communist
Party (AKEL); 1973 elections only for President and
Vice President
Political parties and leaders; Reform Party of the
Working People (AKEL) (Communist Party), Ezekias
Papaioannou; Unified Party (UP), Glafkos Clerides:
Progressive Movement (PM) (pro-Makarios), Andreas
Azinas; Democratic National Party (DEK), Takis
Evdokas; United Democratic Union of the Center
(EDEK), Vassos Lyssarides; Turkish National Union
Party (TNUP), Rauf Denktash; Populist Party, Alpet
Othon
Voting strength: (1968 presidential and vice
presidential elections) Greek Cypriot President
Makarios 90%; Turkish Cypriot Vice President Fazil
Kucuk unopposed; (1970 parliamentary elections)
40% of Greek Cypriot vote for Reform Party of the
Working People, 24% of the Greek Cypriot vote for
the Unified Party, 16% of the Greek Cypriot vote for
the Progressive Movement, 9% of the Greek Cypriot
vote for the Democratic National Party as well as 9%
for the United Democratic Union of the Center, 2% of
the Greek Cypriot vote for independents; 76% of the
Greek Cypriot electorate voted; 80% of the Turkish
Cypriot community voted and overwhelmingly
elected 15 of Rauf Denktashs supporters to the Turk
Cypriot House contingent in a separate election; 1973
clections — Makarios unopposed and Rauf Denktash
unopposed
Communists: 12,000; sympathizers estimated to
number 60,000
Other political or pressure groups: United
Democratic Youth Organization (EDON) (Com-
munist-controlled); Pan Cyprian Confederation of
Labor (PEO) (Communist-controlled); Cyprus
Confederation of Labor (SEK) (pro-West): Cyprus
Turkish Federation of Trade Unions (KTBIF)
Member of: Commonwealth, Council of Europe,
FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMF, ITU, Seabeds Committee, U.N., UNESCO,
UPU, WCL, WFTU, WHO, WMO
Legal name: Czechoslovak Socialist Republic
Type: Communist state
Capital: Prague
Political subdivisions: 2 ostensibly separate and
autonomous republics (Czech Socialist Republic and
Slovak Socialist Republic); 7 regions (kraj) in Czech
lands, three regions in Slovakia; national capitals of
Prague and Bratislava have regional status
Legal system: civil law system based on Austrian-
Hungarian codes, modified by Communist legal
theory; revised constitution adopted 1960, amended
in 1968 and 1970; no judicial review of legislative
acts; legal education at Karlova University School of
Law; has not accepted compulsory ICJ jurisdiction
Branches: executive — President (elected by
Federal Assembly), cabinet (appointed by President);
49
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CZECHOSLOVAKIA/DAHOMEY
legislative — Federal Assembly (elected directly),
Czech and Slovak National Councils (also elected
directly) legislate on limited area of regional matters;
judiciary — Supreme Court (elected by Federal
Assembly); entire governmental structure dominated
by Communist Party
Government leaders: President Gustav Husak
(elected May 1975), Premier Lubomir Strougal
Suffrage: universal over age 18
Elections: governmental bodies every 5 years (last
election, November 1971); President every 5 years
(Husak was elected to replace the incapacitated
President Ludvik Svoboda who did not complete his
second five year term)
Dominant political party and leader: Communist
Party of Czechoslovakia (KSC), Gustav Husak,
General Secretary; Communist Party of Slovakia
(KSS) has status of “provincial KSC organization”
Voting strength (1971 election): 99.81% Com-
munist-sponsored single slate
Communists: 1.35 million party members
Other political groups: puppet parties —
Czechoslovak Socialist Party, Czechoslovak People''s
Party, Slovak Freedom Party, Slovak Revival Party
Member of: CEMA, FAO, GATT, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
Seabeds Committce, U.N., UNESCO, UPU, Warsaw
Pact, WFTU, WHO, WMO
Legal name: Peoples Republic of Benin
Type: republic, under military rule since 26
October 1972
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 provinces, 46 districts
Legal system: based on French civil law and
customary law; legal education generally obtained in
France; has not accepted compulsory ICJ jurisdiction
Branches: executive and legislative power vested in
13-man military revolutionary government headed by
a president
Government leader: Lt. Col. Mathieu Kerekou,
President and chief of government, charged with
national defense, planning, coordination of external
aid, information, and national orientation
Suffrage: universal for adults whenever elections or
referendums are held
Elections: current government has held no
clections and none are scheduled
Political parties: none
Communists: no Communist party; some sympa-
thizers
Member of: AFDB, CEAO, EAMA, ECA,
ECOWAS, Entente, FAO, GATT, IBRD, ICAO, IDA,
ILO, IMF, ITU, Niger River Commission, OAU,
OCAM, Seabeds Committee, U.N., UNESCO, UPU,
WCL, WFTU, WHO, WMO','d27cf851b76d0743d95a8d162d625ccb90e61d98fa54bbd4b5a29071b6c90a16','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8a48b10e2eb580376e19fbae7da24caf24c7bc701f023848e934236e5bbf683',1976,'DK','Denmark','government',134,'Legal name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions; 14 counties, 277 communes,
88 towns
Legal system: civil law system; constitution
adopted 1953; judicial review of legislative acts; legal
education at Universities of Copenhagen and Arhus;
accepts compulsory IC] jurisdiction, with reservations
Approved For Release 2005/04/22
Branches: legislative authority rests jointly with
Crown and parliament (Folketing); executive power
vested in Crown but exercised by cabinet responsible
to parliament; Supreme Court, 2 superior courts, 106
lower courts
Government leaders: Queen Margrethe IT; Prime
Minister, Anker Jorgensen
Suffrage: universal, but not compulsory, over age
21
Elections: on call of prime minister but at least
every four years (last election 9 January 1975)
Political parties and leaders: Social Democratic,
Anker Jorgensen; Moderate Liberal, Poul Hartling;
Conservative, Poul Schluter; Radical Liberal, Hilmar
Baunsgaard; Socialist Peoples, Gert Petersen;
Communist. Knud Jespersen; Left Socialist, Preben
Wilhjelm and Steen Folke; Center Democratic,
Erhard Jakobsen: Progressive, Mogens Glistrup;
Christian People’s, Jens Miller; Justice, Ib Christensen
Voting strength (1975 election): 30.0% Social
Democratic, 23.3% Moderate Liberals, 13.6%
Progressive, 7.1% Radical Liberal, 5.5% Conservative,
5.3% Christian Peoples, 4.9% Socialist Peoples, 4.2%
Communist, 2.2% Center Democratic, 3.9% other
Communists: 7,500-8,000; a number of sympa-
thizers, as indicated by 110;809 Communist votes cast
in 1973 elections
Member of: ADB, Council of Europe, DAC, EC,
EEC, ELDO (observer), EMA, ESRD, EURATOM,
FAO, GATT, IAEA, IBRD, ICAO, IDA, IFA, IFC,
IHO, ILO, IMCO, IMF, IPU, ITU, NATO, Nordic
Council, OECD, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Colony of the Falkland Islands
Type: British crown colony
Capital: Stanley
Political subdivisions: local government is
confined to capital
Legal system: English common law
Branches: Governor, Executive Council, Legisla-
tive Council
Government leader: Governor and Commander in
Chief Ernest G. Lewis (also High Commissioner for
British Antarctic Colony)
Suffrage: universal
Legal name: United Kingdom of Great Britain and
Northern Ireland
Type: constitutional monarchy
Capital: London
Political subdivisions: 635 parliamen
encies
Legal system: common law tradition with early
Roman and modern continental influences; no
judicial review of Acts of Parliament;
compulsory ICJ jurisdiction, with reservations
Branches: legislative authority resides in Parlia-
ment; executive authority lies with collectively
responsible cabinet led by Prime Minister; House of
Lords is supreme judicial authority and highest co
of appeal
Government leader: Prime Minister
Wilson
Suffrage: universal over age 18
Elections: at discretion of Prime Minister, but must
be held before expiration of a 5-year electoral
mandate; last election 10 October 1974
Political parties and leaders:
Margaret Thatcher; Labor, Harold Wilson; Li
Jeremy Thorpe; Communist, Gordan McLennan
Voting strength (1974 election): Conservative 277
seats (35.7%); Labor 319 seats (39.3%), Liberal 13
seats (18.3%), 26 seats (6.7%) other
Communists: 29,000; sympathizers 175,000
Other political or pressure groups: Trades Union
Congress, Confederation of British Industry,
Farmers Union
Member of: ADB, CENTO, Colombo Plan,
ELDO, ESRO,
IBRD, ICAO,
IDA, IEA, IFC, IHO, 1LO, IMCO, IMF, IPU,
ITU, NATO, OECD, Seabeds Committee,
Council of Europe, DAC, EC, EEC,
EURATOM, FAO, GATT, IAEA,
UNESCO, UPU, WEU, WHO, WMO','264cb0aed556574ab8fcd7113bdd5ca06dbc5cbf431e26a4234d6edf257dafde','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31854dc8fb0b2e5ed690b5209a97d94bb73253c09fdd082450fbb8c946f6d431',1976,'DM','Dominica','government',138,'Legal name: State of Dominica
Type: dependent territory with full internal
autonomy as a British “Associated State”
Capital: Roscau
Political subdivisions: 10 parishes
Legal system: based on English common law; three
local magistrate courts and the British Caribbean
Court of Appeals
Branches: legislature, 11 member popularly elected
House of Assembly; executive, cabinet headed by
Premier
Government leaders: Premier Patrick John; U.K.
Governor Sir Louis Cools-Lartigue
Suffrage: universal adult suffrage over age 18
Elections: cvery 5 years; most recent March 1975
53
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
DOMINICA/DOMINICAN REPUBLIC
Political parties and leaders: Dominica Labor
Party (DLP), Patrick John; Dominica Freedom Party
(DFP), Miss M. Eugenia Charles (unofficial)
Voting strength: House of Assembly seats—DFP 3
seats, DLP 16 seats, independent 2 seats
Communists: negligible
Member of: CARICOM, WCL','eee3ff8fe01058fc39bb6fa181fa7adece1088c1b74d98c782ca1b5c78e76265','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27fe9e48346ccb8ab2710c126ab0cc51005875d6d8b8cd32dda312fcad5689dc',1976,'DO','Dominican Republic','government',142,'Legal name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 provinces and the
National District
Legal system: based on French civil codes; 1966
constitution
Branches: President popularly elected for a 4-year
term; bicameral legislature consisting of Senate (27
seats) and Chamber of Deputies (74 seats) elected for
4-year terms; members of Supreme Court elected by
Senate
Government leader: President Joaquin Balaguer
Suffrage: universal and compulsory, over age 18 or
married, except members of the armed forces and
police, who cannot vote
Elections: national, last election May 1974, next
election May 1978
Political parties and leaders: Reformist Party
(PR) Joaquin Balaguer; Dominican Revolutionary
Party (PRD), Francisco Pena Gomez, Secundino Gil
Morales; Dominican Liberation Party (PLD), Juan
Bosch, Democratic Quisqueyan Party (POD), Elias
Wessin y Wessin; Revolutionary Social Christian
Party (PRSC), Rogelio Delgado Bogaert; Movement
for National Conciliation (MNC), Jaime Manuel
Fernandez Gonzalez; Anti-reelection Movement of
Democratic Integration (MIDA), Francisco Augusto
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
DOMINICAN REPUBLIC/ECUADOR
Lora; National Civic Union (UCN), Guillermo
Delmonte Urraca; Popular Democratic Party (PDP),
Luis Tajara Burgos; Fourteenth of June Revolutionary
Movement (MR-1J4), split into several factions,
illegal, Dominican Communist Party (PCD), central
committee, illegal; Dominican Popular Movement
(MPD), illegal; 12th of January National Liberation
Movement (ML-I2E), Plinio Matos Moquete, illegal;
Communist Party of the Dominican Republic
(PCRD), Luis Montas Gonzalez, illegal; Popular
Socialist Party (PSP), illegal
Voting strength (1974 election); 85% PR, 15%
PDP, all other parties abstained
Communists: an estimated 1,500 to 1,800 members
in six different factions; effectiveness limited by
ideological differences and organizational inade-
quacies
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, IHO, ILO, IMCO, IMF,
ITU, OAS, Seabeds Committee, U.N., UNESCO,
UPU, WCL, WHO, WMO','b8465d413519ab6347f95a3279be3167074970e56323af29408a1d5be66f66c1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e41648182375d005e3543f6550d9ead9d86341a05f58dca8d63c8bc8ff7b629d',1976,'EC','Ecuador','government',146,'Legal name; Republic of Ecuador
Type: republic; under military regime since
February 1972
Capital: Quito
Political subdivisions: 20 provinces including
Galapagos Islands
Legal system: based on civil law system; modified
1945 constitution re-instituted in February 1972: legal
education at 4 state and 2 private universities; has not
accepted compulsory IC] jurisdiction
Branches: President and Government Council
assumed power February 1972; government decisions
announced by decree over the president’s signature;
judiciary system supervised by Supreme Court: six
special tribunals established in July 1972
Government leader: President, General Guillermo
Rodriguez Lara
Suffrage: universal for literates over age 18
Elections: none scheduled
Political parties and leaders: National Velasquista
Front, personalistic, Jose Maria Velasco Ibarra (in
exile); Radical Liberal Party, Ignacio Hidalgo
Villavicencio; Social Christian Party, generally
conservative, Camilo Ponce; Conservative Party, Galo
Pico Mantilla; Concentration of Popular Forces,
populist, Assad Bucaram; National Revolutionary
Party, leftist, Carlos Julio Arosemena
Voting strength: in June 1968 national elections,
Velasquistas, a center-left coalition, and a rightist
coalition each got approximately one-third
Communists: Communist Party of Ecuador (PCE,
pro-Moscow, Pedro Saad — secretary-general), 500
members plus an estimated 3,000 sympathizers;
Communist Party of Ecuador (PCE/ML, pro-Peking ),
100 members; Revolutionary Socialist Party of
Ecuador (PSRE), 200 members
Member of: ECOSOC, FAO, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, IHO, ILO, IMCO, IMF,
ITU. LAFTA and Andean Sub-Regional Group
(formed in May 1969 within LAFTA), OAS, OPEC,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WFTU, WHO, WMO
Legal name: Arab Republic of Egypt
Approved For Release 2005/04/22
Type: republic; under presidential rule since June
1956
Capital: Cairo
Political subdivisions: 25 governorates
Legal system: based on English common law,
Islamic law, and Napoleonic codes; permanent
constitution written in 1971; judicial review of limited
nature in Supreme Court, also in Council of State
which oversees validity of administrative decisions;
legal education at Cairo University; accepts
compulsory [CJ jurisdiction, with reservations
Branches: exccutive power vested in President, who
appoints cabinet; People’s Assembly has little actual
power (serves mainly for discussion and automatic
approval); independent judiciary administered by
Minister of Justice
Government leader: President Anwar Sadat
Suffrage: universal over age 18
Elections: clections to People''s Assembly every 5
years (most recent October 1971); presidential
elections every 6 years (next scheduled in 1976)
Political parties and leaders: political parties
banned except for the government-sponsored
sociopolitical grouping, Arab Socialist Union (ASU)
Communists: approximately 500, party members
Member of: AAPSO, AFDB, Arab League, FAO,
GATT, IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO,
IMCO, IMF, IPU, ITU, OAPEC, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO,
WPC','bf6a268a61f13d04d3fc10eb63aff8d9f6897c4ef1f43956f6f3b515f6d9dded','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e7fa16645b2d4de366544b0af93ab722d75b5ca64c451a1e16ce4c8505cbf29',1976,'SV','El Salvador','government',150,'Legal name: Republic of El Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of
common law; constitution adopted 1962; judicial
review of legislative acts in the Supreme Court; legal
education at University of El Salvador; accepts
compulsory IC] jurisdiction, with reservations
Branches: traditionally dominant executive, fairly
independent unicameral legislature, Supreme Court
Government leader: President Arturo Armando
Molina
Suffrage: universal over age 18
Elections: legislative elections every 2 years;
presidential elections every 5 years; presidential
elections March 1977, legislative and municipal
elections March 1976
Political parties and leaders: National Concilia-
tion Party (PCN), President Arturo A. Molina:
Christian Democratic Party (PDC), Juan Ramirez
Rauda, Dr. Pablo Mauricio Alvergue, Jose Napoleon
Duarte; Salvadoran Popular Party (PPS), Benjamin
Wilfredo Navarrete, Roberto Quinonez Meza, Dr.
Jose Antonio Guzman; Communist Party of El
Salvador (PCES), illegal, Jorge Shafick Handal:
National Revolutionary Movement (MNR), Dr.
Guillermo Manuel Ungo; National Democratic
Union Party (PUDN), Communist Front, Jorge
Shafisk Handal Francisco Roberto Lima, Julio
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
EL SALVADOR/ EQUATORIAL GUINEA
Ernesto Contreras, Julio Castro Belloso; Independent
Democratic United Front (FUD!), Gen. Jose A.
Medrano, Raul Salaverria
Voting strength: February 1972 presidential
election — PCN 43.4%, PDC, PUDN, and MNR
coalition, 42.1%; FUDI, 12.3%; PPS 2.2%; March
1974 legislative election — PCN, 36 seats; PDC,
MNR, and PUDN coalition, 15 seats; FUDI, 1 seat
Communists: 100 to 200 active members;
sympathizers, 5,000
Other political or pressure groups: the military;
about 100 prominent families; General Confederation
of Trade Unions (CGS); Unifying Federation of
Salvadoran Trade Unions (FUSS) Communist
dominated; Federation of Construction and Transport
Workers Unions (FESINCONSTRANS), independ-
ent; Catholic Church; Salvadoran National Associa-
tion of Educators (ANDES)
Member of: Central American Common Market
(CACM), FAO, IADB, IAEA, IBRD, ICAO, IDA,
IDB, IFC, ILO, IMF, ITU, OAS, ODECA, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WFTU,
WHO, WMO','5943b23411b743603b6f41cfa8f05797d4d76c3e8c1efee980a26df65f330d9d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0235031872b2219b00c2bfdb5c7cbffab27825fd39a7a2cd4f48a4e79b955773',1976,'GQ','Equatorial Guinea','government',154,'Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since
1968
Capital:
Nguema
Malabo, Province Francisco Macias
Political subdivisions: 2 provinces (Province
Francisco Macias Nguema and Rio Muni)
Legal system: based on Spanish civil law system
and customary law, new constitution adopted July
1973; has not accepted compulsory ICJ jurisdiction
Branches: there are legislative and judicial
branches but President exercises virtually unlimited
power
Government leader: President for life, Francisco
Macias Nguema
Suffrage: universal age 21 and over
Elections: parliamentary elections held December
1978
Political parties and leaders: National Unity Party
of Workers (PUNT) is the sole legal party, led by
President Macias
Communists: no significant number of Com.
munists or sympathizers
Member of: Conference of East and Central
African States, ECA, IBRD, ICAO, IDA, IMCO,
IMF, ITU, OAU, Seabeds Committee, U.N., UPU','b7e69af507282ce5db033d2e46db32e89300d481fd93c54605f62410de680d29','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20f9b573682338a2944a03406719ef597d74015d11bd30f96d17449684e03753',1976,'ET','Ethiopia','government',158,'Organized labor: 60,000 registered labor union
members
Legal name: Ethiopia
adjective—
Type: under military rule since mid-1974;
monarchy abolished in March 1975, but republic not
yet declared
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred
to as regional administrations)
Legal system: complex structure with civil, Islamic,
common and customary law influences; constitution
suspended September 1974; military leaders have
promised a new constitution but established no time
frame for its adoption; legal education at Haile
Selassie 1 University; has not accepted compulsory ICJ
jurisdiction
Branches: effective power exercised by Provisional
Military Administrative Council (MAC), an
unorganized group of about 110 young officers and
enlisted men; predominantly civilian cabinet is
ineffectual and holds office at suffrance of military;
Approved
For Release 2005/04/22 : CIA-RDP79-01051A0008000
10001-8
legislature dissolved September 1974; judiciary at
higher levels based on Western pattern, at lower levels
on traditional pattern, without jury system in either
Government leader: Brigadier General Teferi
Benti, Chairman of the Military Administrative
Council
Suffrage: universal over age 21
Elections: lower house of Parliament election in
June 1978
Political parties and leaders: only amorphous
reform groups especially among younger, better
educated Ethiopians
Communists: none
Other political or pressure groups: some dissident
ethnic groups, most important of which are Eritrean
Liberation Front and Popular Liberation Front,
separatist groups operating in northeastern Ethiopia
Member of: AFDB, ECA, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, OAU, U.N.
UNESCO, UPU, WCL, WHO, WMO
Legal name: The Faeroe Islands
Type: self-governing Province within the Kingdom
of Denmark; 2 representatives in Danish Parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, ]
town
Legal system: based on Danish law; Home Rule
Act enacted 1948
Branches: legislative authority rests jointly with
Crown, acting. through appointed High Commis.
sioner, and provincia] parliament (Lagting) in matters
of strictly Faeroese Concern; executive power vested in
Crown, acting through High Commissioner, but
exercised by provincial cabinet responsible to
provincial parliament
Government leaders: Queen Margrethe II; Prime
Minister, Atli Dam; Danish Governor, Leif Groth
Suffrage: universal, but not compulsory, over age
2]
Elections: held every 4 years; next election 1979
Political parties and leaders; Peoples, Hakun
Djurhuus; Republican, Erlendur Patursson; Home
Hule, Samuel Petersen; Progressive, Kjartan Mohr;
Social Democratic, Atli Dam; Union, Kristian
Djurhuus
Voting strength (1975 election): Social Demo-
cratic 25.8%, Republican 22.5%, Peoples 20.5%,
Union 19.1%, Home Rule 7.2%, Progressive 2.5%
Communists: insignificant number
Member of: Nordic Council','7bd1df6e139fac1e9e0770fb925ab43cf3039c89cce2e38c26f2d71fdeb6e1d8','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7c05e4f6f0c2ffe75528f207fee2daaea54728fccf4fcfaea880a0b01d08b04',1976,'FJ','Fiji','government',162,'Legal name: Dominion of Fiji
Type: independent state within Commonwealth:
Elizabeth II recognized as head of state
64
Approved For Release 2005/04/22 :
Capital: Suva
Political subdivisions: 14 provinces
Legal system: based on British
Branches: executive — Prime Minister; legislative
— 52-member House of Representatives; Alliance
Party 33 seats, National Federation Party 19 seats
Government leader: Prime Minister Ratu Sir
Kamisese Mara
Suffrage: universal adult
Elections: every 5 years unless House dissolves
earlier, last held March-April 1972
Political parties: Alliance, primarily Fijian, headed
by Ratu Mara; National Federation, primarily
Indian, headed by S. M. Koya
Communists: few, no figures available
Member of: ADB, Colombo Plan, Commonwealth,
FAO, GATT (de facto), IBRD, ICAO, IDA, IMF,
ITU, Seabeds Committee, U.N., UPU, WHO','57c64a3e41ad48051b4f0295f8ce02e0e95dd81670edd45ee0e875fc6ad4280a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ca19cd78c8ba8cc81aef79e2c86437741563c6c08728977357785d4c10ff12b',1976,'FI','Finland','government',166,'Legal name: Republic of Finland
Type: republic
Capital: Helsinki
Political subdivisions: 12 provinces; 443 com-
munes, 78 towns
Legal system: civil law system based on Swedish
law; constitution adopted 1919; Supreme Court may
request legislation interpreting or modifying laws;
legal education at Universities of Helsinki and Turku;
accepts compulsory IC] jurisdiction, with reservations
Branches: legislative authority rests jointly with
President and parliament (Eduskunta); executive
power vested in President and exercised through
cabinet responsible to parliament; Supreme Court, 4
superior courts, 193 lower courts
Government leader: President Urho K. Kekkonen;
Prime Minister Keijo Liinamaa
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in
1979); presidential, every 6 years (extraordinary
parliamentary legislation extended President Kek-
konens term, which normally expires in 1974, to 1978)
Political parties and leaders: Social Democratic,
Rafael Paasio; Center, Johannes Virolainen; Peoples
Democratic League (Communist front), Ele Alenius;
Conservative, Harri Holker; Liberal, Pekka Tarjanne;
Swedish Peoples Party, Kristan Gestrin; Rural, Veikko
Vennamo; Finnish People''s Unity Party, Eino
Haikala; Communist, Aarne Saarinen
Voting strength (1975 election): 25% Social
Democratic, 18.496 Conservative, 19.096 Peoples
Democratic League, 17.7% Center, 3.6% Rural, 4.7%
Swedish Peoples, 4.4% Liberals, 3.3% Christian
Peoples
Communists: 47,000; an additional 65,000 persons
belong to Peoples Democratic League; a further
number of sympathizers, as indicated by 421,000
votes cast for Peoples Democratic League in 1970
elections
Member of: ADB, CEMA (special cooperation
agreement), DAC, EC (free trade agreement), EFTA
(associate), FAO, GATT, IAEA, IBRD, ICAO, IDA,
IFC, IHO, ILO, IMCO, IMF, IPU, ITU, Nordic
Council, OECD, Seabeds Committee, U.N.,
UNESCO, UPU, WFTU, WHO, WMO','b8c6380c19f1066e914634fecb512055aab0966fd6ac24382ed7612869b0e149','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8959a7c9d6c63a4517711411a72c45a9af394a5b837a39565311b9f91743268',1976,'FR','France','government',170,'Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 95 metropolitan depart-
ments, 21 regional economic districts
Legal system: civil law system. with indigenous
concepts; new constitution adopted 1958, amended
concerning election of President in 1962; judicial
review of administrative but not legislative acts; legal
education at over 25 schools of law
Branches: presidentially appointed Prime Minister
heads Council of Ministers, which is formally
responsible to National Assembly; bicameral
legislature. — National Assembly (490 members),
Senate (283 members) restricted to a delaying action;
judiciary independent in principle
Government leader: President Valery Giscard
d''Estaing
Suffrage: universal over age 18; not compulsory
Elections: National Assembly — every 5 years, last
election March 1973, direct universal suffrage, 2
ballots; Senate — indirect collegiate system for 9
years, renewable by one-third every 3 years; President
— direct, universal suffrage every 7 years, 2 ballots,
last election May 1974
Political parties and leaders: Union of Democrats
for the Republic (UDR), Jacques Chire; Independent
Republicans (IR), Valery Giscard d''Estaing;
Communist (PCF), George Marchais; Progress and
Modern Democracy (PDM), Jacques Duhamel; Left
Radical Party, Robert Fabre; Center Democratic
Party, Jean Lecanuet; Radical Socialists and
Reformers, Gabriel Peronnet; Socialist Party, Francois
Mitterrand; Unified Socialist Party (PSU), Michel
Mousel
Voting strength (first ballot, 1974 election): 43.2%
Communist Socialist Alliance, 32.6% IR, 15.1% UDR,
9.1% other
Communists: 250,000-300,000 (est. ); Communist
voters, 5 million average
Other political or pressure groups: Communist-
controlled labor union (Confederation Generale du
Travail) nearly 1,500,000 members (est. ), National
Council of French Employers (Conseil National du
Patronat Francais — CNPF or Patronat)
Member of: ADB, Council of Europe, DAC, EC,
ECSC, EEC, EIB, ELDO, EMA, ESRO, EURATOM,
FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC,
IHO, ILO, IMCO, IMF, IPU, ITU, NATO
(signatory), OAS (observer), OECD, Seabeds
Committee, South Pacific Commission, U.N.,
UNESCO, UPU, WCL, WEU, WFTU, WHO,
WMO','f7aa73338dfadd3bc9a700c692c9e83847de1bbd49c266f11cc92d8d619f8098','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b30e06686012972ca139eda17a49c46c989a7075177206e4c75c6a19f2be0db1',1976,'GF','French Guiana','government',174,'Legal name: Overseas Department of French
Guiana
Type: overseas department and region of France;
represented by one deputy in French National
Assembly and one senator in French Senate
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19
communes each with a locally elected municipal
council
Legal system: French legal system; highest court is
Court of Appeal based in Martinique with jurisdiction
over Martinique, Guadeloupe, and French Guiana
Branches: executive: prefect appointed by Paris;
legislative: popularly elected 16-member Genera]
Council and a Regional Council composed of
members of the local General Council and of the
locally elected deputy and senator to the French
parliament; judicial, under jurisdiction of French
judicial system
Government leader; Prefect Herve Bourseiller
Suffrage: universal over age 18
Elections: General Council elections coincide with
those for the French National Assembly, normally
every 5 years; last election March 1973; local elections
last held September 1973 last French presidential
election in May 1974
Political parties and leaders: Parti Socialiste
Guyanais (PSG), Leopold Heder, Senator; Union du
Peuple Guyanaise (UPG), weak leftist allied with, but
also reported, to have been absorbed by the PSG;
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FRENCH GUIANA/FRENCH POLYNESIA
Union of Democrats for the Republic (UDR), Hector
Rivierez, delegate to French National Assembly
Communists: Communist party membership
negligible
Member of: WCL, WFTU','34f1425584807b4b4048f753666b91fa7d743dbd3399a2bd2ca79fb72d162438','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f749936d6d7b348f4ce5cb58008bc896e3e7e900d52b14aee0c610e53913d5f',1976,'PF','French Polynesia','government',178,'Legal name: Territory of French Polynesia
Type: overseas territory of France, administered by
French Ministry for Overseas Territories
Capital: Papeete
Political subdivisions: 5 districts
Legal system: based on French; lower and higher
courts
Branches: 30-member Territorial Assembly,
popularly elected; 5-member Council of Government,
elected by Assembly; popular election of one deputy
to National Assembly in Paris, also one Senator
Government leader: Pierre Angeli, Governor,
appointed by French government
Suffrage: universal adult
Elections: every 5 years
Political parties and leaders: Pupu Here Ai''a,
Senator Pouvanna a Oopa, John Teariki; Te F’a Api,
Francis Sanford; Union Tahitienne-Union pour la
Defense de la Republique, Te Autahoera''a
Legal name: Overseas Territory of Afars and Issas
Type: overseas territory of France; represented by
one deputy in French National Assembly and by one
senator in French Senate
Capital: Djibouti
Legal system: based on French civil law system,
traditional practices and Islamic law
Branches: President of Council of Government; 8-
member Council of Government appointed by 40-
member Chamber of Deputies; ultimate political
authority exercised by Paris-appointed President of
the Council of Government, sometimes referred to as
Prime Minister
Government leader: Ali Aref Bourhan
Suffrage: universal
Elections: Chamber of Deputies election. held
November 1973
Political parties and leaders: Rassemblement
Democratique Afar, Ali Aref Bourhan; Union
Democratique Afar; Union Populaire Africaine;
Union Democratique Issa, Oman Farah Iltireh;
African People''s League, Hassan Gouled
Communists: possibly a few sympathizers
Legal name: Overseas Territory of New Caledonia
Type: French overseas territory; represented in
French parliament by one deputy and one Senator
Capital: Noumea
Political subdivisions: 4 islands or island group
dependencies — Isle of Pines, Loyalty Islands, Huon
Islands, Island of New Caledonia
Legal system: French law
Branches: administered by Governor, who is also
High Commissioner for France in the Pacific;
responsible to French Ministry for Overseas France
and Governing Council; Assemblee Territoriale
Government leader: Jean Risterucci, Governor and
French High Commissioner
Suffrage: restricted (1957 election roll listed 32,370
males and females over 21 years of age, of whom
18,964 were classed as indigenous inhabitants)
Elections: Assembly elections in 1972
Political parties: Union Caledonienne, Entente
Democratique et sociale, Union Multiraciale,
Mouvement Liberal Caledonien, Union Democra-
tique, Mouvement Populaire Caledonien
Voting strength (1972 election): Union Caledoni-
enne, 12 seats; Entente Sociale et Democratique, 6
seats; Union Multiraciale, 5 seats; Mouvement
Liberal Caledonien, 5 seats; Union Democratique, 4
seats; Mouvement Populaire Caledonien, 2 seats;
Caledonie Francaise, 1 seat
Communists: number unknown; Union Caledoni-
enne strongly leftist; some politically active
Communists were deported during 1950''s; small
number of North Vietnamese
Other political parties and pressure groups:
several lesser parties
Member of: EIB (associate), WFTU
Legal name: New Hebrides Condominium
Type: Anglo-French condominium
Capital: Vila
Political subdivisions: 4 administrative districts
Legal system: 3 sets of courts; one each for French
and British subjects, one for New Hebrides native
affairs
Branches; Advisory Council of 30 members with no
real legislative powers, majority elected
Government leader: two resident commissioners,
one French, one British
Political parties and leaders: New Hebrides
National Party, founded 1971, chairman, Walter Lini','b1d3ddb75dd0a80e666ed4b54cf742591b038f3519dbf6eb88d0d6627daa38c0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e92e5bf158e76b11349bd8e26558e2a9690cdb477d54f6faa5d679c54bdb6ff',1976,'GA','Gabon','government',182,'Legal name: Gabonese Republic
Type: republic, one-party presidential regime since
1964
Capital: Libreville
Political subdivisions: 9 regions, 6 communes,
4,500 villages
Legal system: based on French civil law system
and customary law; constitution adopted 1961;
judicial review of legislative acts in Constitutional
Chamber of the Supreme Court; legal education at
Center of Higher and Legal Studies at Libreville;
compulsory ICJ jurisdiction not accepted
Branches: power centralized in President, elected
by universal suffrage for 7-year term; unicameral 70-
member National Assembly has limited powers;
judiciary
Government leader: President Omar Bongo
Suffrage: universal over age 21
Elections: Presidential and parliamentary elections
last held February 1973
Political parties and leaders: Gabonese Demo-
cratic Party (PDG) led by President Bongo is only legal
party
Communists: no organized party; probably some
Communist sympathizers
Member of: AFDB, Conference of East and
Central African States, EAMA, EIB (associate), FAO,
GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF,
IPU, ITU, OAU, OCAM, OPEC, UDEAC, U.N.,
UNESCO, UPU, WHO, WMO','21d234c5a18adbe8be3852f40308f6bfb76c4426a450f000c05d4415d7d22be7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93916c5310799c4d2ba9c1fbb3a5e1dde24a96f5fd5c90901ade2a82f7d78a38',1976,'GM','Gambia','government',186,'Legal name: Republic of The Gambia
Type: republic; independent since February 1965
Capital: Banjul
Political subdivisions: Banjul and 5 divisions
noun—Cambian(s); adjective—
Legal system: based on English common law and
customary law; constitution came into force upon
independence in 1965, new republican constitution
adopted in April 1970; accepts compulsory ICJ
jurisdiction, with reservations
Branches: cabinet of 10 members; 4l-member
House of Representatives, in which 4 seats are reserved
for chiefs, 4 are appointed, 32 are filled by election for
5-year terms, a Speaker is elected by the House, and
the Attorney General is an ex officio member;
independent judiciary
Government leader: Dawda K. Jawara, President
Political parties and leaders: People''s Progressive
Party (PPP), Secretary General Dawda K. Jawara, and
United Party (UP), John Forster
: CIA-RDP79-01051A000800010001-8
id ATT
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GAMBIA/GERMANY, EAST
Suffrage: universal adult
Elections: general elections held March 1972; PPP
28 seats, UP 3 seats, 1 independent seat
Communists: insignificant number
Member of: AFBD, Commonwealth, ECA, FAO,
GATT, IBRD, IDA, IMF, OAU, U.N., WCL, WFTU,
WHO
Legal name: German Democratic Republic
Type: Communist state
Capital: East Berlin (not officially recognized by
U.S., U.K., and France, which together with the
U.S.S.R. have special rights and responsibilities in
Berlin)
Political subdivisions: (excluding East Berlin) 14
districts (Bezirke) 218 counties (Kreise), 7,643
communities (Gemeinden)
Legal system: civil law system modified by
Communist legal theory; new constitution adopted
1968 by approx. 95% of the voters in national
(referendum); court system parallels administrative
divisions: no judicial review of legislative acts; legal
73
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GERMANY, EAST/GERMANY, WEST
education at Universities of Berlin, Leipzig, Halle and
Jena; has not accepted compulsory ICJ jurisdiction;
more stringent penal code adopted 1968
Branches: legislative — Volkskammer (elected
directly); executive — Chairman of Council of State,
Chairman of Council of Ministers, Cabinet (approved
by Volkskammer); judiciary — Supreme Court; entire
structure dominated by Socialist Unity (Communist)
Party
Government leaders: Chairman, Council of State,
Willi Stoph (Head of State); Chairman, Council of
Ministers, Horst Sindermann (Head of Government)
Suffrage: all citizens age 18 and over
Elections: national every 4 years; prepared by an
electoral commission of the National Front; ballot
supposed to be secret and voters permitted to strike
names off ballot; more candidates than offices
available; parliamentary elections held 14 November
1971
Political parties and leaders: Socialist Unity
(Communist) Party (SED), headed by First Secretary
Erich Honecker, dominates the regime; 4 token
parties (Christian Democratic Union, National
Democratie Party, Liberal Democratic Party, and
Democratic Peasant''s Party) and an amalgam of
special interest organizations participate with the SED
in National Front
Voting strength: 1971 parliamentary elections:
98.33% voted the regime slate; 1970 local elections:
99.85% voted the regime slate
Communists: 1.9 million party members
Other special interest groups: Free German Youth,
Free German Trade Union Federation, Democratic
Women''s Federation of Germany, German Cultural
Federation (all Communist dominated)
Member of: CEMA, IPU, ITU, Seabeds Commit-
tee, U.N., UNESCO, UPU, Warsaw Pact, WFTU,
WHO
Legal name: Federal Republic of Germany
Type: federal republic
Capital; Bonn
Political subdivisions: 10 Laender (states);
Western sectors of Berlin are governed by U.S., U.K.,
and France which, together with the U.S.S.R., have
special rights and responsibilities in Berlin
Legal system: civil law system with indigenous
concepts; constitution adopted 1949; judicial review
of legislative acts in the Supreme Federal Constitu-
tional Court; has not accepted compulsory IC]
jurisdiction
Branches: bicameral parliament — Bundesrat
(upper house), Bundestag (lower house); President
(titular head), Chancellor (executive head);
independent judiciary
Government leaders: President, Walter Scheel;
Chancellor, Helmut Schmidt leads coalition of Social
Democrats and Free Democrats
Suffrage: universal over age 18
Elections: usually every 4 years; last election held
19 November 1972
Political parties and leaders: Christian Demo-
cratic Union/Christian Social Union (CDU/CSU),
Helmut Kohl, Franz-Josef Strauss, Karl Carstens, Kurt
Biedenkopf; Social Democratic Party (SPD), Willy
Approved For Release 2005/04/22 :
Brandt, Heinz Kuchn, Helmut Schmidt; Free
Democratic Party (FDP), Hans-Dietrich Genscher,
Hans Friderichs, Wolfgang Mischnick; National
Democratic Party (NPD), Martin Mussgnug;
Communist Party (DKP)
Voting strength (1972 election): 45.9% SPD,
44.8% CDU/CSU, 8.4% FDP, 0.9% Splinter groups of
left and right (no parliamentary representation)
Communists: about 30,000 members and sup-
porters
Other political or pressure groups: expellee,
refugee, and veterans groups
Member of: ADB, Council of Europe, DAC, EC,
ECSC, EIB, ELDO, EMA, ESRO, EURATOM,
FAO, GATT, IAEA, IBRD, ICAO, IDA, IEA, IFC,
IHO, IMCO, IMF, IPU, ITU, NATO, OAS
(observer), OECD, Seabeds Committee, U.N.,
UNESCO, UPU, WCL, WEU, WHO, WMO','745ef0ed483ba5099bbc71e31767bcbb6c4f9a1e2286c81c736381beb9394bc1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f2e2d25bcc3f9f395376036ccaa54f7c7cfc13939c67569b3eff9fc5572e749',1976,'GH','Ghana','government',190,'Legal name: Republic of Ghana
Type: republic; independent since March 1957;
Military regime since January 1972
Capital: Accra
Political subdivisions: 8 administrative regions and
separate Greater Accra Area; regions subdivided into
98 districts and 267 local administrative districts
Legal system: based on English common law and
customary law; constitution suspended January 1972;
legal education at University of Ghana (Legon); has
not accepted compulsory IC] jurisdiction
Branches: executive and legislative authority
vested in Supreme Military Council (SMC);
independent judiciary
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Za. sat —— | €—SÓsugüA—
January 1976
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
GHANA/GIBRALTAR
Government leaders: Chief of State, Chairman of
SMC Colonel LK. Acheampong
Suffrage: universal over 21 under previous
constitution, now suspended
Elections: no elections since 1969; none scheduled
Political parties and leaders: parties banned by
military junta which took power 13 January 1972
Communists: a small number of Communists and
sympathizers
Member of: AFDB, Commonwealth, ECA,
ECOWAS, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IFC, ILO, IMCO, IMF, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WHO,
WMO','593933d3fadbfadb6d116377e5b1c74291ec41213f20f3add4e6939776523453','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b815033d0a140be00cd1f5552f208e50b5a9596c3fe954202691dfc417c258fb',1976,'GI','Gibraltar','government',194,'Legal name: Colony of Gibraltar
Type: U.K. colony
Capital: none
Legal system: English law; constitutional talks in
July 1968; new system effected in 1969 after electoral
enquiry
Branches: parliamentary system comprised of the
Gibraltar House of the Assembly (15 elected members
and 8 ex officio member ), the Council of Ministers
headed by the Chief Minister, and the Gibraltar
Council; the Governor is appointed by the Crown
Government leaders; Governor and Commander
in Chief, Marshall of the RAF Sir John Grandy, Chief
Minister, Sir Joshua Hassan
Suffrage: all adult Cibraltarians, plus other U.K.
subjects resident 6 months or more
Elections: every 5 years; last held in July 1972
Political parties and leaders: Association for
Advancement of Civil Rights (AACR), Sir Joshua
Hassan; Labor, Sir Joshua Hassan; Independents,
Peter Isola; Integrationists (IWBP), Maj. Robert
Peliza
Communists: negligible
Other political or Pressure groups: the House-
wives Association: the Chamber of Commerce','3427f92b5404e3c7d5112475333ee62fd7ba74447cf059098b419e6c803aeeab','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('066736b858aa43437852dc5bbbdaa162c5302cc4de1a49da01a480e51c0d712c',1976,'NL','Netherlands','government',199,'Legal name: Gilbert and Ellice Islands Colony
Type: British crown colony with large measure of
self-government
Capital: Tarawa
Political subdivisions: 4 districts
Branches: 28-member House of Assembly elects a
Chief Minister
Government leader: Governor John H. Smith;
Chief Minister, Naboua Ratieva
Political parties and leaders: Gilbertese National
Party, Christian Democratic Party
Member of; ADB
Legal name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at
The Hague
Political subdivisions: 11 provinces governed by
centrally appointed commissioners of Queen
Legal system: civil law system incorporating
French penal theory; constitution of 1815 frequently
amended, reissued 1947; judicial review in the
Supreme Court of legislation of lower order than Acts
of Parliament; legal education at six law schools;
accepts compulsory IC] jurisdiction, with reservations
Branches: executive, (Queen and Cabinet of
Ministers), which is responsible to bicameral states
general (parliament); independent judiciary
Government leader: Head of State, Queen
Juliana; Johannes den Uyl, Prime Minister
Suffrage: universal over age 21
Elections: must be held at least every 4 years for
lower house (most recent November 1972), and every
3 years for upper house (most recent March 1974)
Political parties and leaders: Catholic People''s
Party (KVP), Dr. D. de Zeeuw; Antirevolutionary
(ARP), A. Veerman; Labor (PvdA), Mrs. Ien Van Den
Heuvel; Liberal (VVD), Mrs. H. van Sommeren-
Downer; Christian Historical Union (CHU), Otto W.
A. Barou Van Verschuer; Democrats ''66 (D-66), Jan
ter Brink; Communist (CPN), Henk Hoekstra; Pacifist
Socialist (PSP), P. A. Burggraff; Political Reformed
(SGP), H. G. Abma; Reformed Political Union (GVP),
G. Veurink; Radical Party (PPR), Marcel Van Dam;
Democratic Socialist "70 (DS-70), Fred L. Polak;
Farmers’ Party (BP) Hendrik Koekoek; Roman
Catholic Party (RKPN), leader unknown
Voting strength (1972 election): 17.7% KVP,
14.4% VVD, 8.8% ARP, 4.8% CHU, 27.4% PvdA,
4.2% D-66, 4.1% DS-70, 4.5% CPN, 1.596 PSP, 4.8%
PRP, 2.2% SGP, 1.8% GVP, 1.9% BP, .9% RKP
Communists: 9,000 members; 329,973 votes in
1972 election
145
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NETHERLANDS/NETHERLANDS ANTILLES
Other political or pressure groups: great
multinational firms; Socialist, Catholic, and
Protestant trade unions; Federation of Catholic and
Protestant Employers Associations; the non-
denominational Federation of Netherlands Enter-
prises
Member of: ADB, Benelux, Council of Europe,
DAC, EC, ECE, EEC, EIB, ELDO, EMA, ESRO,
EURATOM, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IEA, IFC, IHO, ILO, IMCO, IMF, IPU, ITU,
NATO, OAS (observer), OECD, Seabeds Committee,
U.N., UNESCO, UPU, WCL, WEU, WHO, WMO
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands,
enjoying complete domestic autonomy
Capital: Willemstad; Curacao, center of govern-
ment
Political subdivisions: 4 island territories — Aruba,
Bonaire, Curacao, and the Windward Islands — St.
Eustatius, southern part of St. Martin (northern part is
French), Saba
Legal system: based on civil law system, with some
English common law influence; Dutch Country
Statute of 1955 serves as constitution
Branches: federal executive power, under nominal
head of Governor (appointed by the Crown), exercised
by 8-member Council of Ministers or Cabinet;
legislative power rests with 22-member Legislative
Council; independent court system under control of
Chief Justice of Supreme Court of Justice (administra-
tive functions under Minister of Justice); each island
territory has island council headed by Lieutenant
Governor for local administration
Government leaders: Minister-President Juan
Evertsz
Suffrage: universal age 18 and over
Elections: general elections held every 4 years, last
held August 1973; Island council elections every 2
years, last held April and May 1975
Political parties and leaders: the Democratic Party
(DP);. Antilles Social Progress Movement (MASA)
led by Ciro Kroon; the Aruba Patriotic Party (PPA) led
by S. J. Trompe; the National People''s Party (NVP), S.
D. Abbad; the Aruba People''s Party (AVP) led by
Dominico Guzman Croes; the National Aruban
Union Party/Independent Aruban Party (UNA/PIA)
led by A. Werleman/M. Croes; Bonaire Democratic
Party led by L. A. Abraham; Windward Island
Democratic Party led by A. C. Wathey; Social
Progressive Action Party, S. R. Goeloe; Antillean
Reform Union (URA), Roberto Suriel; Curacao
Independent Party (COP), Peter Vander Hoven;
Radical People’s Party (PRP), Max de Castro;
Worker''s Party (Frente Obrero); People''s Electoral
Movement (MEP), separatist party
Voting strength (1973 general election): DP/PPA, 8
seats; NVP, 5 seats; Frente Obrero, 3 seats, MEP, 5
seats; labor coalition, 1 seat
Communists: no Communist Party
Member of: EC (associate) WCL, WHO','791bb01bc6def0ce0d3cadb6d19c500ab02b4634030954c910835d6b750eca5b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27829ff5ca940e69be9aa247bea1dee9c05c2f7872bcca8e7e7cba606f8ab0c0',1976,'GR','Greece','government',202,'Legal name: Hellenic Republic
Type: presidential parliamentary government;
monarchy rejected by referendum December 8, 1974
Capital: Athens
Political subdivisions: 52 departments (nomoi)
constitute basic administrative units for country; each
nomos headed by officials appointed by central
government and policy and programs tend to be
formulated by central ministries; degree of flexibility
79
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
each nomos may have in altering or avoiding
programs imposed by Athens depends upon tradition
(Thessaloniki and other areas exercise considerable
traditional autonomy in local administrative
decisions) and influence which prominent local
leaders and citizens may exercise vis-a-vis key figures
in central government
Legal system: new constitution enacted in June
1975
Branches: executive consisting of a President (to be
elected by Parliament) and a Prime Minister and
cabinet; legislative comprising the 300-member
Parliament; independent judiciary
Government leaders: President Constantine
Tsatsos; Prime Minister Constantine Caramanlis
Suffrage: universal age 21 and over
Elections: every 4 years; latest November 17, 1974
Political parties and leaders: Center Union-New
Forces, George Mavros; New Democracy, Constan-
tine Caramanlis; New Democratic Union, Petros
Garoufalias; Panhellenic Socialist Movement,
Andreas Papandreou; Communist Party — Exterior,
Harilaos Florakis; Communist Party — Interior,
Haralambos Drakopoulos; and the United Demo-
cratic Left, Hias Iliou—in disarray since the election
Voting strength: New Democracy, 216 seats;
Center Union-New Forces, 61 seats; Panhellenic
Socialist Movement, 15 seats: Left, 8 seats
Communists: an estimated 25,000-30,000 members
and sympathizers
Member of: EC (associate), EIB (associate), EMA,
GATT, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHO,
ILO, IMCO, IMF, ITU, NATO, OECD, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WHO,
WMO','d9fae0250a0820ae9a5dc5a39ee387c87bebd26c5180014ba5628f00053afc9c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fee43a479b18aac0718da296245c02e2bf9c9716180b7dfa944c81d6f7a44264',1976,'GL','Greenland','government',206,'Legal name: Greenland
Type: province of Kingdom of Denmark; 2
representatives in Danish parliament; separate
Minister for Greenland in the Danish cabinet
Capital; Godthaab (administrative center)
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from
colony to province in 1953
Branches: legislative authority rests jointly with
Crown and Danish parliament; executive power
vested in Crown, acting through provincial governor
responsible to Minister for Greenland; local affairs
handled by provincial council (Landsrad) subject to
approval of provincial governor; 19 lower courts
Government leaders: Queen Margrethe II;
Governor N. O. Christensen
Suffrage: universal, but not compulsory, over age
21
Elections: held every 4 years (next 1979)
Political parties: Inuit (advocating close ties with
Denmark); Sukaq (moderate socialist, advocating
more distinct Greenland identity)','3aa34a6138b25e2996b0fbb2d572aaadb6f12414a2579976d264da98102a1ffc','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4b56f183843310e85bb5afe555349a2bbb3f78d36d7d8b3bda686d7ef144858',1976,'GD','Grenada','government',210,'Legal name: Grenada
Type: independent state since February 1974,
recognizes Elizabeth II as Chief of State
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
Branches: legislative branch consists of 10-member
clected House of Representatives and 13-member
Senate appointed by the Governor; executive branch
is cabinet led by Prime Minister
Government leaders: Prime Minister Eric
Matthew Gairy; U.K. Governor General Leo de Gale
Suffrage: universal adult suffrage
Elections: every 5 years; most recent general
clection 28 February 1972
Political parties and leaders: Grenada United
Labor Party (GULP), Eric Matthew Gairy; Grenada
National Party (GNP), Herbert A. Blaize
Voting strength (1972 election): GULP 58.7%,
GNP 41.3%; Legislative Council seats, GULP 14,
GNP 1
82
Communists: negligible
Member of: CARICOM, IMF, OAS, U.N.','46c6e2fa1fd7762e735357a50430877b55d817b0807dd6e84b1cb4ed1787ef0e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7be5087e7fea5516cdca64efa74438728190259afc0d1cf43b7c86f4acce7a86',1976,'GP','Guadeloupe','government',214,'Legal name: Overseas Department of Guadeloupe
Type: overseas department and region of France;
represented by 3 deputies in the French National
Assembly and 2 Senators in the Senate
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34
communes, each with a locally elected municipal
council
Legal system: French legal system; highest court is
a court of appeal based in Martinique with
jurisdiction over Guadeloupe, French Guiana, and','2d1a7448d43da146e9198e8455f43892de502e1711c9000c8ea366991f89792b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93cac52158fd525162310d6f00769753742425024c84fe1d22cd67b5825877a4',1976,'MQ','Martinique','government',215,'Branches: executive, Prefect appointed by Paris;
legislative, popularly elected General Council of 36
members and a Regional Council composed of
members of the local General Council and the locally
elected deputies and senators to the French
parliament; judicial, under jurisdiction of French
judicial system
Government leader: Prefect Jacques Le Cornec
Suffrage: universal over age 18
Elections: General Council elections coincide with
those for the French National Assembly, normally
every 5 years; last General Council election took place
in March 1973; local clection last held September
1973; last French presidential election in May 1974
Political parties and leaders: Union of Democrats
for the Republic (UDR), Gabriel Lisette; Communist
Party of Guadeloupe (PCG), Henri Bangou; Socialist
Party (MSG), leader unknown; Progressive Party of
Guadeloupe (PPG), Henri Rodes; Independent
Republicans; Federation of the Left
Voting strength: MSG, 1 seat in French National
Assembly; UDG, 2 seats; (1973 election)
Communists: 3,000 est.
Other political or pressure groups: Group of
National Organization of Guadeloupe (GONG)
Member of: WFTU
Legal name: Overseas Department of Martinique
Type: overseas department of France, represented
by 3 deputies in the French National Assembly and 2
Senators in the Senate
Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34
communes, each with a locally elected municipal
council
Legal system: French legal system, highest court is
a court of appeal based in Martinique with
jurisdiction over Guadeloupe, French Guiana, and
133
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MARTINIQUE/MAURITANIA
Branches: executive, prefect appointed by Paris;
legislative, popularly elected council of 36 members
and a Regional Council including all members of the
local general council and the locally elected deputies
and senators to the French parliament; judicial, under
jurisdiction of French judicial system
Government leader: Prefect Herve Bourseilleur
Suffrage: universal over age 18
Elections: General Council elections coincide with
those for the French National Assembly, normally
every five years; last General Council election took
place in March 1973; last local election held
September 1973, last French Presidential election
May 1974
Political parties and leaders: Union of Democrats
for the Republic (UDR), Emile Maurice: Progressive
Party of Martinique (PPM), Aime Cesaire;
Communist Party of Martinique (PCM), Armand
Nicolas; Democratic Union of Martinique (UDM ),
Leon-Laurent Valere; Socialist Party, leader
unknown; Federation of the Left, leader unknown
Voting strength: UDR, 2 seats in French National
Assembly; PPM, 1 seat (1973 election)
Communists: 1,000 estimated
Other political or pressure groups: Proletarian
Action Group (GAP), Socialist Revolution Group
(GRS)
Member of: WFTU','72eb9c8ed9d723a80f444bedab78c0b1d400d5717092da986639e9f00b130998','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d39dc23b945d8e53060e42d20fe11ba99cb4174a05fc836da00c23b4b70bab4a',1976,'GT','Guatemala','government',220,'Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system: civil law system; constitution came
into effect 1966; judicial review of legislative acts;
legal education at University of San Carlos of
Guatemala; has not accepted compulsory ICJ
jurisdiction
Branches: traditionally dominant executive;
elected unicameral legislature; 7-member (minimum)
Supreme Court
Government leader: President Kjell Laugerud
Suffrage: universal over age 18, compulsory for
literates, optional for illiterates
Elections: next elections (President and Congress)
1978
Political parties and leaders: Democratic
Institutional Party (PID), Donaldo Alvarez Ruiz;
Revolutionary Party (PR), Jorge Garcia-Granados
Quinonez (secretary general); National Liberation
Movement (MLN), Mario Sandoval Alarcon;
Guatemalan Christian Democratic Party (DCG),
Vinicio Cerezo Arevalo (sec. gen.)
Voting strength: for President — MLN-PID
298,953 (44.6%), DCG 228,067 (34.0%), PR 143,111
(21.4%); for congressional seats — MLN-PID 36,
DCG 15, PR 10
Communists: Communist party outlawed; under-
ground membership estimated at 750
Other political or pressure groups: outlawed
(Communist) Guatemalan Labor Party (PGT),
Bernardo Alvarado
Member of: CACM, FAO, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, IHO, ILO, IMF, ITU,
Seabeds Committee, OAS, ODECA, U.N., UNESCO,
UPU, WCL, WHO, WMO','a4163f9c34aa00734ca22109a51386234fc4db48997330cd3b42b6b9c9eea5e4','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84d7d9487f4d49855a9d298703d76ac0abc5cd1f323d5c6d759df5c162541af1',1976,'GW','Guinea-Bissau','government',224,'Legal name: Republic of Guinea-Bissau
Type: republic; achieved independence from
Portugal in September 1974; constitution promul-
gated 1974; government being formed: will establish
union with the Republic of Cape Verde
Capital: Bissau
Political subdivisions: 9 municipalities, 3
circumscriptions (predominantly indigenous popula-
tion)
Legal system: to be determined
Branches: National Popular Assembly to be elected
for three-year term; Council of State Commissars, 16
members; the official party is the supreme political
institution.
Government leaders; President of Council of State
and Chief of State is Luis Cabral; Principal
Commissar and Head of Government, Francisco
Mendes; Secretary General of the Official party,
Aristides Pereira
Suffrage: Universal over age 18
Elections: None held to date
noun—Guinean(s); adjective—
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GUINEA-BISSAU/GUYANA
Political parties and leaders: Partido Africano da
Independencia da Guinee e Cabo Verde (PAIGC), led
by Aristide Pereira, only legal party; Front de Lutte
pour l''Independence Nationale de la Guinea
(FLING), a largely dormant, loose coalition of
nationalist elements opposed the PAIGC, leadership
fragmented
Communists: none known
Member of: U.N., UPU','56f7171e56d6d06e60e950e4e1de38c8366ac174870ba68144ea30e5e3569a07','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9d0440ac33da6aa42e64853859a059e5ca20b80848fae1a4d89b3f45a9a5a30',1976,'GY','Guyana','government',228,'Legal name: Cooperative Republic of Guyana
Type: republic within Commonwealth
Capital: Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with
certain admixtures of Roman-Dutch law; has not
accepted compulsory ICJ jurisdiction
Branches: Council of Ministers presided over by
Prime Minister; 53-member unicameral legislative
National Assembly (elected); Supreme Court
Government leader; Prime Minister L.F.S.
Burnham
Suffrage: universal over age 18 as of constitutional
amendment August 1973
Elections: last held in July 1973; next election must
be called within 5 years
Political parties and leaders: People’s National
Congress (PNC), L.F.S. Burnham; People’s Progres-
sive Party (PPP), Cheddi Jagan; United Force (UF),
Feilden Singh
Voting strength (1973 election): 70.2% PNO,
26.2% PPP, 3.6% other
87
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GUYANA/HAITI
Communists: est. 100 hard-core within PPP; top
echelons of PPP and PYO (Progressive Youth
Organization, militant wing of the PPP) include many
Communists, but rank and file is non-Communist
Other political or pressure groups: Liberator Party
(LP) Guyana National Liberation Front (GNLF),
People''s Democratic Movement (PDM), African
Society for Cultural Relations with Independent
Africa (ASCRIA), Afro-Asian-American Association
(AAAA)
Member of: CARICOM, FAO, GATT, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, OAS (observer),
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WHO, WMO
Legal name: Republic of Haiti
Type: republic under the 14-year dictatorship of
Francois Duvalier who was succeeded upon his death
on 21 April 1971 by his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite
constitutional provision for 9)
Legal system: based on Roman civil law system:
constitution adopted 1964 and amended 1971; legal
education at State University in Port-au-Prince an
private law colleges in Cap-Haitien, Les Cayes,
Gonaives, and Jeremie; accepts compulsory IC]
jurisdiction
Branches: lifetime President, unicameral 58-
member legislature of very limited powers. judiciary
appointed by President
Government leader: President-for-life Jean-Claude
Duvalier
Suffrage: universal over age 18
Elections: constitution as amended in 1971
provides for lifetime president to be designated by his
predecessor and ratified by electorate in plebiscite;
legislative elections, which are held every 6 years, last
held February 1973
Political parties: National Unity Party, only legal
party; United Haitian Communist Party (PUCH),
illegal (Communist)
Voting strength (1967 legislative elections): 100%
National Unity Party (Duvalier)
Communists: strength unknown; party leaders
believed in exile
Other political or pressure groups: none
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMCO, IMF, ITU,
OAS, U.N., UNESCO, UPU, WCL, WHO, WMO','ae6d14e11ba92b5758fcd7d337279b5fb3104d1789623d5f572da613c0673e06','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('683b584d026b0527ca268fe977756bd38f6023f43a96e0a8a396c623fc7d44a6',1976,'HN','Honduras','government',232,'Legal name: Republic of Honduras
Type: republic
Capital; Tegucigalpa
Politica] subdivisions: 18 departments
Legal system, based on Roman and Spanish civi]
Branches; constitution provides for elected
President, unicameral legislature, and national
Modesto Rodas Alvarado, Carlos Roberto Reina
Idiaguez, Jorge Bueso Arias; National Party (PNH),
Gonzalo Carias Castillo; National Innovation and
Unity Party (PINU) (uninscribed), Miguel Andonie
90
January 1976
Fernandez; Workers Party of Honduras (PTH)
(Communist) (uninscribed ), Rogue Ochoa; Com.
munist Party of Honduras/Soviet (PCH/S-outlawed),
Dionisio Ramos Bejarano: Communist Party of
Honduras/China (PCH/C-outlawed), Agapito
Robledo Castro
Voting Strength (1971 elections); Nationa] Party
(PNH) 306,028; Liberal Party (PLH) 276,777
Member of; CACM, FAO, IADB, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMC » IMF, ITU, OAS,
Seabeds Committee, UN, UNESCO, UPU, WCL,','30c9573f3c1f7cdc463c8bc9a8631d65dfcddaf8ad01174711607c0a6535333d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a00ffa578b1dac02f9c6e55e6da71045cb6d0b37b3e867b6bba7ce4e73d2e057',1976,'HK','Hong Kong','government',236,'Legal name: Colony of Hong Kong
Type: U.K. crown colony
Capital: Victoria
Political subdivisions: Hong Kong, Kowloon, and
New Territories
Legal system: English common law
Branches: Governor assisted by advisory Executive
Council; he legislates with advice and consent of
Legislative Council; Urban Council which alone
includes elected representatives, responsible for
health, recreation, and resettlement; independent
judiciary
Government leader: C. M. MacLehose, Governor
and Commander in Chief
Suffrage: limited to 200,000 to 300,000 professional
or skilled persons
Elections: every 2 years to select one-half of elected
membership of Urban Council, other Urban Council
members appointed by the Governor
Political parties and leaders: Civic Association,
Hu Pai-fu; Reform Club, B. A. Bernacchi; Socialist
Democratic Party, Sun Po-kong; Hong Kong Labour
Party, Tang Hon-tsai
Voting strength: (elected Urban Council members)
Civic Association 4, Reform Club 3, and 1
independent
Communists: an estimated 2,000 hard core cadres
affiliated with Communist Party of China
Other political or pressure groups: Federation of
Trade Unions (Communist controlled), Hong Kong
and Kowloon Trade Union Council (Nationalist
Chinese dominated), Hong Kong General Chamber of
Commerce, Chinese General Chamber of Commerce
(Communist controlled), Federation of Hong Kong
Industries, Chinese Manufacturers’ Association of
Member of: ADB, WCL','b58c6f94a572e851a6675b3f55b36d02083048f45eae2520e6c4a1d901b2ebb1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bf82465105d87e3ece31ad52f3c6d9c86d503c1925c14381540f4e0fc9403f0',1976,'HU','Hungary','government',240,'Legal name: Hungarian Peoples Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 megyes (counties), 5
autonomous cities in county status, 97 jaras (districts)
Legal system: based on Communist legal theory,
with both civil law system (civil code of 1960) and
common law elements: constitution adopted 1949
amended 1972; Supreme Court renders decisions of
principle that sometimes have the effect of declaring
legislative acts unconstitutional; legal education at
Lorand Eotvos Tudomanyegyetem School of Law in
Budapest and 2 other schools of law; has not accepted
compulsory ICJ jurisdiction
Branches: executive — Presidential Council
(elected by Parliament); legislative — Parliament
(elected by direct suffrage); judicial — Supreme Court
{elected by Parliament)
Government leaders: Gyorgy Lazar, Chairman,
Council of Ministers: Pal Losonczi, President,
Presidential Council
Suffrage: universal over age 18
Elections: every 5 years.
elections are held scparately
adjective—
national and loca]
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
HUNGARY/ICELAND
Political parties and leaders: Hungarian Socialist
(Communist) Workers Party (sole party); Janos Kadar
is First Secretary of Central Committee
Voting strength (1975 election): 7,497,061 (99.6%)
for Communist-approved candidates; 30,108 (0.4%)
invalid and negative votes; total eligible electorate
about 7.76 million; next elections will be held in 1980
Communists: about 754,000 party members
(March 1975)
Member of: CEMA, Danube Commission, FAO,
IAEA, ICAO, ILO, IMCO, IPU, ITU, Seabeds
Committee, U.N., UNESCO, UPU, Warsaw Pact,
WFTU, WHO, WMO','25214e8abc5e8191471aeac4cd0af23083c977a0b346053009732d3474c86184','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53fca1752177d24770f9c7bc42c797847aff01e593dad0c22314fe4b697b3941',1976,'IS','Iceland','government',244,'Legal name: Republic of Iccland
Type: republic
Capital: Reykjavik
Political subdivisions: 23 rural districts, 215
parishes, 14 incorporated towns
Legal system: civil law system based on Danish
law; constitution adopted 1944; legal education at
University of Iceland; does not accept compulsory IC]
jurisdiction
Branches: legislative authority rests jointly with
President and parliament (Althing); executive power
vested in President but exercised by cabinet
responsible to parliament; Supreme Court and 29
lower courts
Government leaders: President Kristjan Eldjarn;
Prime Minister Geir Hallgrimsson
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in
(1978); presidential, every 4 years (next in 1976)
Political parties and leaders: Independence
(conservative), Geir Hallgrimsson; Progressive, Olafur
Johannesson; Social Democratic, Benedikt Grondal;
People''s Alliance (Communist front), Ragnar Arnalds;
Organization of Liberals and Leftists, Magnus Torfi
Olafsson
Voting strength (1974 election): 42.79; Independ-
ence, 24.9% Progressive, 9.1% Social Democratic,
18.3% People''s Alliance, organization of leftists and
liberals 4.6?6
Communists: est. 2,200; a number of sympathizers,
us indicated by 18,055 votes cast for Labor Alliance in
1971 election
Member of: Council of Europe, EC (free trade
agreement pending resolution of fishing limits issue),
EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC,
1HO, ILO, IMCO, IMF, IPU, ITU, NATO, Nordic
Council, OECD, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO
94','7140db5bd791d507fdc139b89b369973bb5b14ce21f4b44722a39005000fd6b6','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17804bce90c56208eb387ea5f272234dd89d4b10665fa3ae0c4da1e7478395fb',1976,'ID','Indonesia','government',248,'Legal name: Republic of Indonesia
Type: rcpublic
Capital: Jakarta
Political subdivisions: 26 first-level administrative
subdivisions or provinces which are further subdivided
into 281 second-level areas
Christian, 296
Legal system: based on Roman-Dutch law,
substantially modified by indigenous concepts,
constitution of 1945 is legal basis of government; legal
education at University of Indonesia, Jakarta; has not
accepted compulsory ICJ jurisdiction
Branches: executive headed by President who is
chief of state and head of cabinet; cabinet selected by
President; unicameral legislature (Parliament), of 460
members (100 appointed, 360 elected); second and
larger body (Congress) of 920 members and includes
the legislature and 460 other members (chosen by
several processes, but not directly elected) elects
President and Vice President, and theoretically
determines national policy
Government leader: President Suharto (elected by
Songress March 1973)
Suffrage: universal over age 17 and married persons
regardless of age
Political parties and leaders: Golkar (quasi-official
“party” based on functional groups), Amir Moertono;
Indonesian Democratic Party (federation of former
Nationalist and Christian parties), Mohammed
Isnaeni; Unity Development Party (federation of
former Islamic parties), Idham Chalid
Voting strength (1971 election): Golkar 236 seats,
Indonesian Democratic 30, Unity Development 94
Communists: Communist Party (PKI) was
officially banned in March 1966; current strength est.
at 1,000, with less than 10% engaged in organized
activity; pre-October 1965 hard-core membership has
been estimated at 1.5 million
Member of: ADB, ASEAN, ESCAP, FAO, IAEA,
IBRD, ICAO, IDA, IFC, THO, ILO, IMCO, IMF,
IPU, ITU,OPEC, Seabeds Committee, U.N.,
UNESCO, UPU, WCL, WFTU, WHO, WMO
Legal name: Empire of Iran
Type: constitutional monarchy, controlled by the
Shah
Capital: Tehran
Political subdivisions: 19 providnces and 3 chief-
governorates, subdivided into districts, sub-districts,
counties, and villages
Legal system: based largely on French law, with
clements drawn from other continental systems;
personal law based on Islamic practice generally with
residual traces of Roman law; constitution adopted
1906 and constitutional law of 1907; High Court of
Appeal may judge disputes relating to government
departments acting according to law; legal education
at University of Teheran; has not accepted
compulsory IC] jurisdiction
98
Branches: executive power rests in Shah who
appoints a Prime Minister; Prime Minister must be
approved by lower house (Majlis); while Cabinet
theoretically responsibility of Prime Minister, Shah
usually exerts strong influence over its selection;
bicameral legislature; Majlis has 268 members elected
to 4-year terms, and Senate 60 members serving 4-vear
terms; half of Senate members appointed by Shah,
other half elected; no provision for judicial review of
constitutionality of legislative acts
Government leaders: Shah Mohammad Reza
Pahlavi and Prime Minister Amir Abas Hoveyda
Suffrage: universal over age 20
Elections: Majlis every 4 years; Senate every 4
years; latest national elections June 1975, next district
and municipal elections in 1976
Political parties and leaders: a single party
system, designated The Resurgence Party of the
People of Iran (RPPL) with Prime Minister Amir
Abbas Hoveyda as Secretary-General, was formed by
Shah in March 1975; all other political parties
disbanded
Voting strength: all candidates government
approved and members of the RPPI
Communists; 1,000-2,000 (hard-core, est.): sympa-
thizers (15,000-20,000 est. ): mostly pro-U.S.S.R. but
pro-Chinese faction developing
Other political or pressure groups: Tudeh Party
(Communist, illegal); National Front (coalition of
neutralist urban elements virtually discredited
because of opposition to Shah’s reform program);
Confederation of Iranian Students (illegal)
Member of: CENTO, Colombo Plan, FAO, IAEA,
IBRD, ICAO, IDA, IFC, THO, ILO, IMCO, IMF,
IPU,ITU, OPEC, RCD, Seabeds Committee, U.N.,
UNESCO, UPU, WFTU, WHO, WMO','088a10e5dab29ef82f89569c4778235e9d5d7b21ec37e7e6ea7e9b77c73ab798','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfceb6f336034f850851c6a0f8cb5af5286de6cdcf5bf9d3b3a71a35acc77cf1',1976,'IQ','Iraq','government',252,'Legal name: Republic of Iraq
Type: republic; National Front Government
consisting of Baath Party (BPI), and Iraq Communist
Party (CPI) formed in July 1973 (Kurds invited to join
National Front government but have refused pending
solution of Kurdish autonomy issue; Communists play
nominal role in government)
Capital: Baghdad
Political subdivisions: 16 provinces under centrally
appointed officials
Legal system: based on Islamic law in special
religious courts, civil law system elsewhere;
provisional constitution adopted in 1968; judicial
review was suspended; legal education at University
of Baghdad; has not accepted compulsory IC]
jurisdiction
Branches: Bath Party of lraq has been in power
since 1968 coup
Government leaders: President Ahmad Hasan al-
Bakr; Deputy Chairman of the Revolutionary
Command Council Saddam Husayn "Abd-al-Majid
al-Tikriti
Suffrage: no elective bodies exist
Elections: no national clections since overthrow of
monarchy in 1958
Communists: Communist Party allowed token
representation in cabinet, est. 2,000 hard-core
Political or pressure groups: political parties
banned, possibly some opposition to regime from
disaffected members of the regime and army officers
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, OAPEC, OPEC,
99
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
IRAQ/IRELAND
Seabeds Committee, U.N., UNESCO, UPU, WFTU,
WHO, WMO','e8935b480cfd1ec852745a394f3f8fad4a600e14f0e7671a4e2781f4bf2caa0c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c855217c6db5cf2440a99108f99add8b642ba0e0577638a4c569928389af5e9',1976,'IE','Ireland','government',256,'Legal name: Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law.
substantially modified by indigenous concepts;
constitution adopted 1937; judicial review of
legislative ucts in Supreme Court: has not accepted
compulsory IC] jurisdiction
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
IRELAND/ISRAEL
Branches: elected President; bicameral parliament
reflecting proportional and vocational representation;
judiciary appointed by President on advice of
Government leaders: President Cearbhall O’ Daigh-
ly, Taoiseach; Prime Minister Liam Cosgrave;
Tanaiste Deputy Prime Minister Brendan Corish
Suffrage: universal over age 18
Elections: Dail (lower house) elected every 5 years
— last election February 1973; President elected for 7-
year term — last election December 1974
Political parties and leaders: Fianna Fail, John
(Jack) Lynch; Labor Party, Brendan Corish; Fine
Gael, Liam Cosgrave; Communist Party of Ireland,
Michael ©’ Riordan
Voting strength: (1973 election) Fianna Fail 46%
(69 seats), Fine Gael 35% (54 seats), Labor Party 14%
(19 seats), other 5% ; Independents hold 2 seats
Communists: approximately 600
Member of: Council of Europe, EC, EEC, ESRO
(observer), EURATOM, FAO, GATT, IBRD, ICAO,
IDA, IEA, IFC, ILO, IMCO, IMF, IPU, ITU,
OECD, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO','d9ab322eced20ef1f61cb4d0e22779c333034fcfcb0f0e6953dce74a506b4c2c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bb8bd486384e8a024ea0220a76264490a0f6fcca80ae5076290efb25887e251',1976,'IL','Israel','government',260,'Legal name: State of Israel
Type: republic
Capital: Jerusalem; not recognized by U.S. which
maintains Embassy in Tel Aviv
Political subdivisions: 6 administrative districts
Legal system: mixture of English common law
and, in personal area, Jewish, Christian and Muslim
legal systems; commercial matters regulated
substantially by codes adopted since 1948; no formal
constitution; some of the functions of a constitution
are filled by the Declaration of Establishment (1948),
the basic laws of the Knesset (legislature) relating to
the Knesset, Israeli lands, the president, the
government and the Israel citizenship law; no judicial
review of legislative acts; legal education at Hebrew
University in Jerusalem; accepts compulsory IC]
jurisdiction, with reservations
Branches: President Ephraim Katzir has largely
ceremonial functions; executive power vested in
cabinet; unicameral parliament (Knesset) of 120
members elected under a system of proportional
102
representation; legislation provides fundamental laws
in absence of a written constitution; 2 distinct court
systems (secular and religious)
Government leader: Prime Minister Yitzhak Rabin
Suffrage: universal over age 18
Elections: held every 4 years unless required by
dissolution of Knesset; last election held in December
1978
Principal political parties and leaders: Israel
Labor Party, Prime Minister Yitzhak Rabin, Golda
Meir, Josef Almogi, Moshe Dayan, Yigal Allon,
Shimon Peres; United Workers Party (MAPAM in
alignment with Israel Labor Party, Meir Talmi;
National Religious Party, Minister of Interior Dr.
Joseph Burg; Independent Liberal Party, Minister of
Tourism Moshe Kol; Herut (Freedom) Party,
Menahem Begin; Liberal Party, Dr. Elimeleda
Rimalt; State List, Yigal Hurwitz; Herut and the
Liberal Party are called the CAHAL bloc and,
together with the State List and Free Center, they
form the Likud bloc led by Menahem Begin; Yadd
(new liberal party) Shulamit Aloni; AKI (Israel
Communist Opposition Party— predominantly
Jewish), leader Esther Wilenska; RAKAH (Com-
munist Party — predominantly Arab), Secretary
General Meir Wilner; Moked (ultra-leftist), leader
Meir Pa''il
Voting strength: out of 120 seats, Israel Labor
Party-MAPAM-Arab List Alignment 53 seats; Likud
bloc 38 seats; National Religious Party 10 seats:
Independent Liberal Party 4 seats; Agudat Religious
Front 5 seats; RAKAH 4 seats; Yadd 4 seats; Moked I
seat; independents 1 scat
Communists: divided between AKI (Jewish party)
with a new splinter group with at most a few hundred
members, and RAKAH (Arab party) with some 1,500
members; neither constitutes a subversive threat
Other political or pressure groups: right-wing
Jewish Defense League led by Rabbi Meir Kahane
Black Panthers, a loosely organized youth group
seeking more benefits for oriental Jews
Member of: FAO, GATT, IAEA, IBRD, ICAO,
IDA, IFC, ILO, IMCO, IMF, IPU, ITU, OAS
(observer), Seabeds Committee, U.N., UNESCO,
UPU, WFTU, WHO, WMO','13d4db8caec75eaf120fe126dd23845f17f3890cf5628a3902b61b46693e62d5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e309f9fe02dd3a56fe08203c7cebe8becf0ad736681cfec47b1e15fe2592270',1976,'IT','Italy','government',264,'Legal name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides for
establishment of 20 regions; 5 (Sicilia, Sardegna,
Trentino-Alto Adige, Friuli-Venezia Giulia, and Valle
d''Aosta) have been functioning for some time and the
remaining 15 regions were instituted on 1 April 1972;
94 provinces
108
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Legal system: based on civil law system, with
ecclesiastical law influence; constitution came into
effect 1 January 1948; judicial review under certain
conditions in Constitutional Court; has not accepted
compulsory ICJ jurisdiction
Branches: executive — President empowered to
dissolve Parliament and call national election: he is
also Commander of the Armed Forces and presides
over the Supreme Defense Council; otherwise,
authority to govern invested in Council of Ministers;
legislative power invested in bicameral, popularly
elected Parliament; Italy has an independent judicial
establishment
Government leaders: President Giovanni Leone;
Premier Aldo Moro
Suffrage: universal over age 18 (except in
Senatorial elections where minimum age of voter is
22)
Elections: national elections for Parliament held
every 5 years (most recent, May 1972); provincial and
municipal elections held every 5 years with some out
of phase; regional elections every 5 years (held June
1975)
Political parties and leaders: Christian Demo-
cratic Party (DC), Benigno Zaccagnini (party
Colombo; Communist Party (PCI), Luigi Longo,
Enrico Berlinguer (secretary general); Italian Socialist
Party (PSI), Francesco De Martino (party secretary),
Pietro Nenni, Giacomo Mancini; Italian Social
Democratic Party (PSDI), Flavio Orlandi; Mario
Tanassi (party secretary), Giuseppe Saragat; Liberal
Party (PLI) Agostino Bignardi (party secretary);
Italian Social Movement (MSI), Giorgio Almirante;
Republican Party (PRI) Oddo Biasini (party
Voting strength (1972 election): 38.8% DC, 27.2%
PCI, 9.6% PSI, 3.9% PLI, 8.7% MSI, 2.9% PRI, 5.1%
PSDI, 3.8% other
Communists: 1,702,562 members (as of July 1975);
number of sympathizers cannot be determined
Other political or pressure groups: the Vatican;
three major trade union confederations (CGIL —
Communist dominated, CISL — Christian Demo-
cratic, and UIL — Social Democratic, Socialist, and
Republican); Italian manufacturers association
(Confindustria); organized farm groups
Member of: ADB, Council of Europe, DAC, EC,
ECOWAS, ECSC, EEC, EIB, ELDO, ESRO,
EURATOM, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IEA, IFC, IHO, ILO, IMCO, IMF, IPU, ITU,
NATO, OAS (observer), OECD, Seabeds Committee,
U.N., UNESCO, UPU, WCL, WEU, WFTU, WHO,
WMO
Legal name: Republic of Ivory Coast
Type: republic, one-party presidential regime
established 1960
Capital; Abidjan
Political subdivisions: 24 departments subdivided
into 127 subprefectures
Legal system: based on French civil law system
and customary law; constitution adopted 1960,
amended 1963; judicial review in the Constitutional
Chamber of the Supreme Court; legal education at
Abidjan School of Law; has not accepted compulsory
IC] jurisdiction
animist,
Branches: President has sweeping powers,
unicameral legislature, separate judiciary
Government leader: President Felix Houphouct-
Boigny
Suffrage: universal over age 21
Elections: uncontested Presidential and legislative
elections held in November 1970 for 5-ycar term
Political parties and leaders: Parti Democratique
de la Cote d''Ivoire (PDCI), (only party); official party
leader is Secretary General Philippe Yace, but
Houphouet-Boigny is in control
Communists: no Communist party; possibly some
sympathizers
Member of: AFDB, CEAO, EAMA, ECA, EIB
(associate), Entente, FAO, GATT, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
Niger River Commission, OAU, OCAM, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO','92c56c220d71b6303edf957eef2a68750334c62703bc4ce8edbfa82d67370dc5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f22dad4768a34d893dea9e4cb404c34ef1c12a45d6e9d3f1688dca7d3b378dfb',1976,'JM','Jamaica','government',268,'Legal name: Jamaica
Type: independent state within Commonwealth
since August 1962, recognizing Elizabeth II as head of
state
Capital: Kingston
Political subdivisions: 12 parishes and the
Kingston-St. Andrew corporate area
Legal system: based on English common law; has
not accepted compulsory ICJ jurisdiction
Branches: cabinet headed by Prime Minister; 53-
member elected House of Representatives; 21-
member Senate (13 nominated by the Prime Minister,
8 by opposition leader); judiciary follows British
tradition under a Chief Justice
Government leader: Prime Minister Michael
Manley
Suffrage: universal, age 18 and over
Elections: at discretion of Governor-General upon
advice of Prime Minister but within 5 years; latest
held 29 February 1972
Political parties and leaders: People’s National
Party (PNP), Michael Manley; Jamaica Labor Party
(JLP), Edward Seaga
Voting strength (1972 general elections): 56.55% >
PNP, 43.21% JLP, 0.24% other
Communists: a few hundred Marxist and
Communist sympathizers
Other political or pressure groups: New World
Group (Caribbean regionalists, nationalists, and leftist
intellectual fraternity); Rastafarians (Negro religious /
racial cultists, pan-Africanists); New Creation
International Peacemakers ‘Tabernacle (leftist group)
Member of: CARICOM, FAO, GATT, IADB,
IAEA, IBRD, ICAO, IDB, IFC, ILO, IMF, ITU,
OAS, Pan American Health Organization, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WHO,
WMO','aeebdd94df69dc79fd7454a5b0b3c1670e8374a44155997f5c1ad935f361b588','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b5cec4e90d047285287e8b150a91968315032f9fbbd57ad045294a01ef25245',1976,'JP','Japan','government',272,'Legal name: Japan
Type: constitutional monarchy
Capital: Tokyo
Political subdivisions: 47 prefectures (Ryukyus
became 47th prefecture on 15 May 1972)
Legal system: civil law system with English-
American influence; constitution promulgated in
1946; judicial review of legislative acts in the Supreme
Court; uccepts compulsory IC] jurisdiction, with
reservations
Branches: Emperor is merely symbol of state;
executive power is vested in cabinet dominated by the
Prime Minister, chosen by the Lower House of the
bicameral, elective legislature (Diet); judiciary is
independent
Government leader: Prime Minister Takeo Miki
Suffrage: universal over age 20
Elections: general elections held every 4 years or
upon dissolution of Lower House. triennially for one-
half of Upper House
108
Approved For Release 2005/04/22
Political parties and leaders: Liberal Democratic
Party (LDP), T. Miki, President: Japan Socialist Party
(JSP), T. Narita, Chairman; Democratic Socialist
Party (DSP), I. Kasuga, Chairman: Japan Communist
Party, K. Miyamoto, Presidium Chair-man; Komeito
(CGP), Y. Takeiri, Chairman
Voting strength (1972 election): 46.8% LDP,
21,9% JSP, 10.5% JCP, 85% CGP, 7.0% DSP, 5.3%
others
Communists: 350,000, 3,000,000 sympathizers
Member of: ADB, ASPAC, Colombo Plan, DAC,
ESCAP, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IEA, IFC, IHO, ILO, IMCO, IMF, IPU, IRC, ITU,
OECD, Seabeds Committee, U.N., UNESCO, UPU,
WCL, WFTU, WHO, WMO','287a3b1e1313e0ec8e845dc3986eb463ddc1149960986c99636991374da63aa6','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81dbf38ba045d3734f0e6c7d2da95943d55b28ebf2f8c76edfc629368e5e08f6',1976,'JO','Jordan','government',276,'Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: ‘Amman
Political subdivisions: 8 districts (3 are under
Israeli occupation) under centrally appointed officials
Legal system: based on Islamic law and French
codes; constitution adopted 1952; judicial review of
legislative acts in a specially provided High Tribunal;
has not accepted compulsory IC] jurisdiction
Branches: King holds balance of power; Prime
Minister exercises executive authority in name of
King; Cabinet appointed by King and responsible to
parliament; bicameral parliament with Chamber of
Deputies last chosen by national elections in April
1967, and dissolved by King in November 1974;
Senate last appointed by King in November 1974;
present. parliament subservient to executive; secular
court system based on differing legal systems of the
former Transjordan and Palestine; law Western in
concept and structure; Sharia (religious) courts for
Muslims, and religious community council courts for
non-Muslim communities; desert police carry out
quasi-judicial functions in desert areas
Government leader: King Husayn ibn Talal al-
Hashimi
Suffrage: all citizens over age 20
Political parties and leaders: political party
activity illegal since 1957; Palestine Liberation
Organization and various smaller fedaycen groups
109
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
JORDAN/KENYA
clandestinely active on West Bank: Ba''th Party of
Jordan, Dr. Munif Razza; Muslim Brotherhood
Communists: party actively repressed, membership
estimated at less than 500
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, Seabeds
Committee, U.N., UNESCO. UPU, WFTU, WHO,
WMO','bf8b798355643b60c65585a5ccb592b42ada8d83645b66ef6fd6a78c455a0c0f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f8c005d4f6180c3d2ef47fc576c03301e9cfd6e4822d76c5aa2870548f298c5',1976,'KE','Kenya','government',280,'Legal name: Republic of Kenya
Type: republic within Commonwealth since
December 1963
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi
Area
Legal system: based on English common law,
tribal law and Islamic law; constitution enacted 1963;
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
KENYA/KOREA, NORTH
judicial review in Supreme Court; legal education at
University Kenya School of Law in Nairobi; accepts
compulsory ICJ jurisdiction, with reservations
Branches: President and Cabinet responsible to
unicameral legislature (National Assembly) of 170
seats, 158 directly elected by constituencies and 12
appointed by the President; Assembly must be
reclected at least every 5 years; High Court, with
Chief Justice and at least 11 justices, has unlimited
original jurisdiction to hear and determine any civil or
criminal proceeding; provision for systems of courts of
appeal with ultimate appeal to East African Court of
Appeals
Government leader: President Jomo Kenyatta
Suffrage: universal over age 21
Elections: general election (October 1974) elected
present National Assembly; next elections due 1979
Political party and leaders: Kenya Africa National
Union (KANU), president, Jomo Kenyatta
Voting strength: KANU holds all seats in the
National Assembly
Communists: may be a few Communists and
sympathizers
Other political or pressure groups: labor unions
Member of: AFDB, EAC, FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
Scabeds Committee, U.N., UNESCO, UPU, WHO,
WMO
Legal name: Democratic Peoples Republic of
Korea
Type: Communist state; one-man tule
Capital: Pyongyang
Political subdivisions: 9 provinces, 3 special cities
(P''yongyang, Hamhung, Ch''ongjin), and 1 special
district (Kaesong)
Legal system: based on German civil law system
with Japanese influences and Communist legal
theory; constitution adopted 1948 and revised 1972;
no judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Branches: Supreme Peoples Assembly theoretically
supervises Legislative and Judicial function
Government and party leaders: Kim Il-song,
President DPRK, and General Secretary of the Korean
Labor Party; Kim Il, Premier
Suffrage: Universal at age 17
Elections: election to SPA every 4 years, but this
constitutional provision not necessarily followed —
last election December 1972
Political party: Korean Labor (Communist) Party;
claimed membership of about 1.6 million, or about
12% of population
Member of: IPU, Seabeds Committee, U.N.
(observer status only), UNCTAD, WFTU, WHO
Legal name: Republic of Korea
Type: republic; power centralized in a strong
executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities;
heads centrally appointed
Legal system: combines elements of continental
European civil law systems, Anglo-American law, and
Chinese classical thought; constitution approved
1972; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative (unicameral),
judiciary, National Conference of Unification
Government leaders: President Pak Chong-hui;
Prime Minister Kim Chong-pil
Suffrage: universal over age 20
Elections: presidential every 6 years indirectly by
the National Conference of Unification, last election
December 1972; two-thirds of the 219-member
National Assembly is elected directly for the same
period within six months of the presidential clection,
remaining third nominated by the President and
elected by the National Conference for a three-year
term; last election February 1978, Revitalization
Group — 73 seats, Democratic Republican Party —
73 seats, New Democratic Party — 52 seats,
Democratic Unification Party — 2 seats, Inde-
pendents — 19 seats
Political parties and leaders: pro-government —
Revitalization Group (appointed) (Chairman, Pak
Tu-Chin) and Democratic Republican Party (Acting
Chairman, Yi Hyo-sang) New Democratic Party
(Chairman, Kim Yong-sam); Democratic Unification
(Chairman, Yang Il-tong)
Voting strength: (1973 election) popular vote
11,896,484; DRP 38.8%, NDP 32.896, DUP 10.2%,
Independent 18.1%, 0.1% invalid
Communists: Communist activity banned by
government; an estimated 37,000-50,000 former
members and supporters
Other political or pressure groups: Federation of
Korean Trade Unions; Korcan Veterans’ Association;
large potentially volatile student population
concentrated in Scoul
Member of: ADB, Asian Parliamentary Union,
Asian People''s Anti-Communist League (APACL),
ASPAC, Colombo Plan, ESCAP, FAO, GATT,
Geneva Conventions of 1949 for the protection of war
victims, IAEA, IBRD, ICAO, IDA, IFC, 1HO,
IMCO, IMF, INTELSAT, INTERPOL, IPU, ITU,
UNESCO, U.N. Special Fund, UPU, WCL, WHO,
WMO, World Anti-Communist League (WACL);
official observer at U.N., does not hold U.N.
membership','9266de3500fa50f0f25192adac0f98f925ed7762538b39b19fc63daade8cb3ff','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('307d255a228889cf7682ad3354911ab0933cae8884ee5df2c0ca9a3ef6e587b0',1976,'KW','Kuwait','government',284,'Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Al Kuwayt
Political subdivisions: 3 governorates, 10 voting
constituencies
Legal system: civil law system with Islamic law
significant in personal matters; constitution took
effect 1963, judicial review of legislative acts not yet
determined; has not accepted compulsory IC]
jurisdiction
Branches: Council of Ministers: National Assembly
Government leader: Emir Sabah al-Salim Al
Sabah
Suffrage: native born and naturalized males age 21
or over
Elections: held every 4 years for National
Assembly; held in January 1975
Political parties and leaders: political parties
prohibited, some small clandestine groups are active
Communists; insignificant
Other political or pressure groups: none
Member of: Arab League, FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU,
ITU, OAPEC, OPEC, U.N., UNESCO, UPU, WHO,
WMO
Legal name: Peoples Democratic Republic of Laos
Type: republic
Capital: Vientiane
Political subdivisions: 13 provinces subdivided
into districts, cantons, and villages
Legal system: based on civil law system; has not
accepted compulsory ICJ jurisdiction
Branches: President; 45-member Supreme Council;
39-member cabinet formed on 4 December; cabinet is
totally Communist but council contains a few
nominal neutralists and non-Communists; National
Assembly due to be re-established in April 1976 after
completion of elections
Government leaders: President, Prince Souphan-
ouvong; Prime Minister, Kaysone Phomvihan;
Deputy Prime Ministers, Nouhak Phoumsavan,
Phoumi Vongvichit, Phoun Sipaseut, and Khamtai
Siphadon
Suffrage: universal over age 18
Elections: elections for new National Assembly
scheduled to be completed on April 1, 1976
115
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LAOS/LEBANON
Political parties and leaders: Lao People’s
Revolutionary Party (Communist) includes Lao
Patriotic Front and Alliance Committee of Patriotic
Neutralist Forces; other parties are moribund
Communists: Lao People''s Revolutionary Party;
membership unknown
Other political or pressure groups: non-
Communist political groups are moribund; most
leaders have fled the country
Member of: ADB, Colombo Plan, ESCAP, FAO,
IBRD, ICAO, IDA, ILO, IMF, IPU, ITU, Mekong
Committee, SEAMES, U.N., UNCTAD, UNESCO,
UPU, WFTU, WHO, WMO','c6654433e5da2edb6691e00c9ed305a7b2be543e3fe50e5cd2d76c75972def24','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10c63c2fa6f8eb10ff14c0b2da2e9fd25acd7cca037914f89419c896311df710',1976,'LB','Lebanon','government',288,'Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law,
and civil law system; constitution mandated in 1920;
no judicial review of legislative acts; legal education
at University of Lebanon; has not accepted
compulsory IC] jurisdiction
Branches: power lies with President elected by
parliament (Chamber of Deputies); Cabinet
appointed by President, approved by parliament,
independent secular courts on French pattern;
religious courts for matters of marriage, divorce,
inheritance, etc.; by custom, President is a Maronite
Christian, Prime Minister a Sunni Muslim, and
president of parliament a Shia Muslim; each of 9
religious communities represented in parliament in
proportion to national numerical strength
Government Jeader: President Sulayman Fran-
jiyah
Suffrage: compulsory for all males over 21;
authorized for women over 21 with elementary
education
Elections: for Chamber of Deputies, held every 4
years or within 3 months of dissolution of Chamber;
held April 1972
Political parties and leaders: political party
activity is organized along sectarian lines; numerous
political groupings exist, consisting of individual
political figures and followers motivated by religious,
clan, and economie considerations; political stability
dependent on maintenance of balance between
religious communities
Communists: only legal Communist party in
Middle East; legalized in 1970; members and
sympathizers estimated at 2,000-3,000
Other political or pressure groups: Palestinian
guerrilla organizations
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
Seabeds Committee, U.N., UNESCO, UPU, WFTU,
WHO, WMO','95e1bbc03a5d4bf9b771406162934d6cd587da6ec29a694ca618483b769b4255','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90beae62d1a2eaea77f2a6048a206af7cdba82daafaf53f0639ddc8077395efd',1976,'LS','Lesotho','government',292,'Legal name: Kingdom of Lesotho
Type: constitutional monarchy under King
Moshoeshoe Il; independent member of com-
monwealth since 1966
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and
Roman-Dutch law; constitution came into effect
1966, judicial review of legislative acts in High Court
and Court of Appeal; legal education at University of
Botswana, Lesotho, and Swaziland (located in
Lesotho); has not accepted compulsory ICJ
jurisdiction
Branches: executive, divided between a largely
ceremonial King and a Prime Minister who leads
cabinet of at least 7 members; Prime Minister
dismissed bicameral legislature in early 1970 and
subsequently has ruled by decree; Prime Minister
convened Interim National Assembly in April 1973 in
order to devise new constitution; judicial — 68
Lesotho courts administer customary law for Africans,
High Court and subordinate courts have criminal
jurisdiction over all residents, Court of Appeal at
Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua
Jonathan
Suffrage: universal for adults
Elections: elections held in January 1970; nullified
allegedly because of clection irregularities: subsequent
elections promised at unspecified date
Political parties and leaders: Basutoland Congress
Party (BCP), Ntsu Mokhele; National Party (BNP),
Chief Leabua Jonathan
118
Voting strength: in 1970 elections for National
Assembly, BNP won 82 seats; BCP, 22 seats; minor
parties, 4 seats
Communists: negligible, Communist Party of
Lesotho banned in early 1970
Member of: Commonwealth, FAO, GATT (de
facto), IBRD, IDA, IFC, IMF, ITU, OAU, U.N.,
UNESCO, UPU, WHO','4d4497588bd0d4b448b523efcb654ad1b40c54f17f3a75b597317274c5ca6088','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef782c03a9599deb15d3c5b432d2caf5d0c7b602d4a9f562ae74a6c7e3484d39',1976,'LR','Liberia','government',296,'Legal name: Republic of Liberia
Type: republic in form; strong executive dominates,
with few constraints
Capital: Monrovia
Political subdivisions: country divided into 9
counties; President appoints all officials of
significance
Legal system: based on U.S. constitutional theory;
recent codes drawn up by Cornell University;
Approved For Release 2005/04/22
constitution adopted 1847; amended 1907, 1926,
1934, 1955, and 1975; no constitutional provision for
judicial review of legislative acts; legal education at
Louis Arthur Grimes School of Law, University of
Liberia; accepts compulsory IC] jurisdiction, with
reservations
Branches: President, elected by popular vote,
limited to a single eight-year term, controls through
appointive powers, authority over national expendi-
tures, and a variety of informal sanctions; 2-house
legislature elected by popular vote; judiciary
consisting of Supreme Court and variety of lower
courts
Government leader: President William R. Tolbert,
Jr.
Suffrage: universal 18 years and over
Elections: members of House of Representatives
clected for 4-year terms, most recently in October
1975; Senate members elected for 6-year terms, one-
half elected in May 1973; President Tolbert,
constitutional successor to President Tubman who
died in July 1971, completed the four year term to
which Tubman was elected and was then elected in
October 1975 for an eight-year term
Political parties and leaders: True Whig Party, in
power since 1878, only political party; President
Tolbert is leader
Voting strength: 1975 elections uncontested; True
Whig Party won all but a handful of votes
Communists: no Communist Party and only a few
sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU,
ITU, OAU, Seabeds Committee, U.N., UNESCO,
UPU, WHO','9dff242a540013f809a24dcd1fdaa9c0647841280fdd8bcd043e451616336eee','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97773bb68e9bb0779633128ec3fea2c816ee556af47672f20d7fbf0203e43985',1976,'LY','Libya','government',300,'Legal name: Libyan Arab Republic
Type: republic; under military control following
ouster of king on 1 September 1969; provisional
constitution promulgated December 1969; loosely
confederated with Egypt and Syria in Confederation
of Arab Republics (CAR) on 1 September 1971
Capital: Tripoli
Political subdivisions: 10 administrative provinces
closely controlled by central government; district
commissioners appointed by revolutionary Command
Council
Legal system: based on Italian civil law system and
Islamic law; separate religious courts; no constitu-
tional provision for judicial review of legislative acts;
legal education at Law School, at University of Libya
at Banghazi; has not accepted compulsory ICJ
jurisdiction
Branches: paramount political power and
authority rests with the ll-man Revolutionary
Command Council (RCC); cabinet of 13 ministers;
Parliament has been dissolved
Government leaders: Revolutionary Command
Council Chairman Colonel Mu''ammar Qadhafi;
Prime Minister, Major Abd al-Salam Jallud
Suffrage: universal
Elections: parliamentary elections last held in May
1965; election for CAR assembly in March 1972
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LIBYA/LIECHTENSTEIN
Political parties and leaders: Libyan Arab
Socialist Union, RCC member Major Bashir Hawadi,
Secretary General; Mu''ammar Qadhafi, President
Communists: no organized party, negligible
membership
Other political or pressure groups: various Arab
nationalist movements and the Arab Socialist
Resurrection (Bath) party with small, almost
negligible memberships may be functioning
clandestinely
Member of: AFDB, Arab League, FAO, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, ITU,
OAPEC, OAU, OPEC, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO','a59d35eb7c15d3e42b15573736c93814d7286a392e18efc5373d201c79351ac7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6db86f5319332e80da756c7667ac5ad80e1fe616dffbe87eaca3f3ce93ff0460',1976,'LI','Liechtenstein','government',304,'Legal name: Principality of Liechtenstein
121
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LIECHTENSTEIN/LUXEMBOURG
Type: hereditary constitutional monarchy
Capital: Vaduz
Political subdivisions: 11 districts
Legal system: based on Swiss law; constitution
adopted 1921; judicial review of legislative acts in a
special Constitutional Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: unicameral Parliament, hereditary
Prince, independent judiciary
Government leaders: Head of State, Prince Franz
Joseph 1I; Chief of Government, Dr. Walter Kieber
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1978
Political parties and leaders: Fatherland Union
Party (VU), Dr. Alfred Hilbe; Progressive Citizens
Party (FBP), Dr. Gerard Batliner
Voting strength (1974 election): FBP over 50%
Communists: none
Member of: IAEA, ITU, UPU, WCL; considering
U.N. membership; desires affiliation with The
Council of Europe; under a 1923 treaty, Switzerland
handles Liechtenstein''s post and telegraph systems,
customs, and foreign relations','cb0867eb90b4d39b0f46974f77fe24dddde90f79f6f072c2b4040cac98a12652','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f672230c231204c8303e9ec2f527b978a680643c2fca718e2a0fcd11715ebb4',1976,'LU','Luxembourg','government',309,'Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for
administrative purposes has 3 districts (Luxembourg,
Diekirch, Grevenmacher) and 12 cantons
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LUXEMBOURG/MACAO
Legal system: based on civil law system;
constitution adopted 1868; judicial review of
legislative acts in the Cassation Court only; accepts
compulsory ICJ jurisdiction
Branches: parliamentary democracy; seven
ministers comprise Council of Government headed by
President, which constitutes the executive; it is
responsible to the unicameral legislature, the
Chamber of Deputies; the Council of State, appointed
for indefinite term, exercises some powers of an upper
house; judicial power exercised by independent courts
Government leaders: Grand Duke Jean, Head of
State; Gaston Thorn, Prime Minister
Suffrage: universal and compulsory over age 18
Elections: every 5 years for entire Chamber of
Deputies; latest elections May 1974
Political parties and leaders: Christian Social
Union, Pierre Werner and Jacques Santer (Party
President); Socialist, Lydie Schmit (Party President);
Social Democrat, Henry Cravatte (Party President);
Democratic, Gaston Thorn (Party President and Prime
Minister); Communist, Dominique Urbany
Voting strength in Chamber of Deputies
(1974): Christian Socialist, 18; Socialist Workers, 17;
Democrats, 14; Social Democrats, 5; Communists, 5
Communists: 500 party members (1974)
Other political or pressure groups: group of steel
industries representing iron and steel industry,
Centrale Paysanne representing agricultural pro-
ducers; Christian and Socialist labor unions,
Federation of Industrialists; Artisans and Shopkeepers
Federation
Member of: Benelux, BLEU, Council of Europe,
EC, ECSC, EEC, EIB, EURATOM, FAO, CATT,
IAEA, IBRD, ICAO, IDA, IEA, IFC, ILO, IMF, IPU,
ITU, NATO, OECD, Seabeds Committee, U.N.,
UNESCO, UPU, WCL, WEU, WHO, WMO','da16dd63df7d791eeca2b6af552ece0ff946e4d7da4ef2732c3790357eb25e53','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82c269075e14b4e795705577771760b2e88929fc5ccd03cc315c7bf11b8cfd86',1976,'PH','Philippines','government',314,'Legal name: Province of Macao
Type: overseas province of Portugal
Capital: Lisbon (Portugal)
Political subdivisions: municipality of Macao, and
2 islands
Legal system: Portuguese civil law system
Branches: Governor, who dominates legislative and
executive branches, assisted by Legislative Council
with unknown number of appointed and 8 elected
members; the Urban Council with 3 governor-
appointed and 4 elected members; all high-ranking
officials appointive under provisions of revised
Organic Overseas Law; new organic law to have come
into effect in January 1973 to replace legislative
council with a legislative assembly
Government leader: Brigadier Jose Manuel Nobre
De Carvalho, Governor
Suffrage: restricted to Portuguese citizens
Elections: conducted every 4 years; last held
December 1972
Political parties and leaders: Portuguese National
Union (Uniao Nacional) only legal party, as in:
Portugal; Governor is leading political figure
124
Communists: numbers unknown
Other political or pressure groups: wealthy
Macanese and Chinese representing local interests,
wealthy pro-Communist merchants representing
China''s interests; in January 1967 Macao Govern-
ment acceded to Chinese demands which gave
Chinese veto power over administration of the enclave
Legal name: Republic of the Philippines
Type: republic
Capital: Quezon
Political subdivisions: 72 provinces
Legal system: based on Spanish, Islamic, and
Anglo-American law; parliamentary constitution
passed 1978; judicial review of legislative acts in the
Supreme Court; legal education at University of the
Philippines, Ateneo de Manila University, and 71
other law schools; accepts compulsory IC] jurisdic-
tion, with reservations; currently being ruled under
martial law
Branches: new constitution (currently suspended)
provides for unicameral National Assembly, and a
strong executive branch under a prime minister;
judicial branch headed by Supreme Court with
descending authority in a Court of Appeals, courts of
First Instance in various provinces, municipal courts
in chartered cities, and justices of the peace in towns
and municipalities; these justices have considerably
more authority than do justices of the peace in the
US.
Government leader:
Marcos
President Ferdinand E.
Suffrage: universal over age 18
Elections: elections suspended for the indefinite
future
Political parties and leaders: political parties
currently in limbo because of martial law
Communists: about 1,900 armed insurgents
Member of: ADB, ASEAN, ASPAC, Colombo
Plan, ESCAP, FAO, IAEA, IBRD, ICAO, IDA, IFC,
IHO, ILO, IMCO, IMF, IPU, ITU, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WFTU,
WHO, WMO','bf1e36cad76e3a543cf2cf59336f61ca020a23393f780a8bb3130ec5c9877b14','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b4bd17715cde2630b85d21979bec73e4692273d1ddf40a6481439d72a79b550',1976,'MG','Madagascar','government',318,'Legal name: Malagasy Republic
Type: republic; military has wielded real authority
since May 1972
Capital: Tananarive
Political subdivisions: 6 provinces
Legal system: based on French civil law system
and traditional Malagasy law; constitution of 1959
modified in October 1972 by law establishing
provisional government institutions; legal education
at National School of Law, University of Madagascar;
has not accepted compulsory ICJ jurisdiction
Branches: executive—an 8-member Supreme
Revolutionary Council; assisted by cabinet called
Council of Ministers; National Popular Development
Council created to replace the legislature in October
1972; Military Committee for Development; regular
Approved For Release 2005/04/22 :
courts are patterned after French system, and a High
Council of Institutions reviews all legislation to
determine its constitutional validity
Government leader: Captain Didier Ratsiraka,
President of Supreme Revolutionary Council
Suffrage: universal for adults
Elections: government in October 1972 postponed
all political elections indefinitely
Political parties and leaders: Malagasy Socialist
Party (PSM), led by Philibert Tsiranana and Andre
Resampa, formed in 1974 asa result of union of Social
Democratic Party (PSD) and Malagasy Socialist
Union (USM); Congress Party for the Independence
of Madagascar (AKFM), led by Richard Andriaman-
jato; National Movement for the Independence of
Madagascar (MONIMA), led by Monja Jaona;
parties are permitted to exist but are barred from
positions of political authority because of postpone-
ment of elections
Voting strength: number of registered voters (1972)
—3.5 million; (in 1973 elections) non-party
candidates won 81% of seats in National Popular
Development Council; AKFM won 33 seats, PSD 5,
USM 1, MONIMA 14
Communists: Communist party of virtually no
importance; small and vocal group of Communists
has gained strong position in leadership of AKFM, the
rank and file of which is non-Communist
Other political or pressure groups: Joint Struggle
Committec (KIM), association of students, teachers,
workers, and unemployed youth
Member of: EAMA, FAO, GATT, IAEA, IBRD,
IFC, ILO, IMF, ITU, OAU, OCAM, Seabeds
Committee, U.N., UNESCO, WCL, WFTU, WHO,
WMO','309a6b95aba1e926115a2b61e266c62257c776e502a42b3f8f23f11864924930','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53654799324f6b6a05b0ed9b1b37918e571e3d0f21e3101836a9881d9b98ab9c',1976,'MW','Malawi','government',322,'Legal name: Republic of Malawi
Type: republic since July 1966; independent
member of Commonwealth since July 1964
Capital: Lilongwe
Political subdivisions: 3 administrative regions and
23 districts
Legal system: based on English common law and
customary law; constitution adopted 1964; judicial
review of legislative acts in the Supreme Court of
Appeal; has not accepted compulsory ICJ jurisdiction
Branches: strong presidential system with cab.net
appointed by President; unicameral National
Assembly of 60 elected and 15 nominated members;
High Court with Chief Justice and at least 2 justices
Government leader: Life President H. Kamuzu
Banda
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MALAWI/MALAYSIA
Suffrage: universal adult
Elections: scheduled for April 1971 but not held
since MCP candidates were unopposed
Political parties and leaders: Malawi Congress
Party (MCP), Dr. H. Kamuzu Banda
Communists: no Communist Party; may be a few
Communist sympathizers
Member of: AFDB, EEC (associate member),
FAO, GATT, IBRD, ICAO, IDA, IFC, ILO, IMF,
IPU, ITU, OAU, U.N., UNESCO, WHO, WMO','e4271e1c2969a7b7e3e37a000f810e888046fbc9b3688e57e2c10b828839441b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0725141c88fcc6bf5a1848475eea2b4a0fbe71906ca8771bfaab44e9b3bb1249',1976,'MY','Malaysia','government',326,'Legal name: Malaysia
Type:
Malaysia: constitutional monarchy nominally
headed by Paramount Ruler (King); a bicameral
Parliament consisting of a 58-member Senate and a
154-member House of Representatives
Peninsular Malaysian states: hereditary rulers in
all but Penang and Malacca where Governors
appointed by Malaysian Government: powers of state
governments limited by federal constitution
128
Approved For Release 2005/04/22 :
Sabah: self-governingstate within Malaysia in
which it holds 16 seats in House of Representatives;
foreign affairs, defense, internal security, and other
powers delegated to federal government
Sarawak: self-governing state within Malaysia in
which it holds 24 seats in House of Representatives;
foreign affairs, defense, and internal security, and
other powers are delegated to federal government
Capital:
Peninsular Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu
Sarawak: Kuching
Political subdivisions: 13 states (including Sabah
and Sarawak)
Legal system: based on English common law;
constitution came into force 1963; judicial review of
legislative acts in the Supreme Court at request of
Supreme Head of the Federation; has not accepted
compulsory ICJ jurisdiction
Branches: 9 state rulers alternate as Paramount
Ruler for 5-year terms; locus of executive power vested
in Prime Minister and cabinet, who are responsible to
bicameral parliament; following communal rioting in
May 1969, government imposed state of emergency
and suspended constitutional rights of all parlia-
mentary bodies; parliamentary democracy resumed in
February 1971
Peninsular Malaysia: executive branches of 11
states vary in detail but are similar in design; a Chief
Minister, appointed by hereditary ruler or Governor,
heads an executive council (cabinet) which is
responsible to an elected, unicameral legislature
Sarawak and Sabah: executive branch headed by
Governor appointed by central government, largely
ceremonial role; executive power exercised by Chief
Minister who heads parliamentary cabinet responsible
to unicameral legislature; judiciary part of Malaysian
judicial system
Government leader: Head of State, Tun Abdul
Razak
Suffrage: universal over age 20
Elections: minimum of every 5 years, last elections
August 1974
Political parties and leaders:
Peninsular Malaysia: National Front, a confedera-
tion of 9 political parties dominated by United
Malays National Organization (UMNO), Tun Abdul
Razak; only opposition party of consequence —
Democratic Action Party (DAP)
Sabah: United Sabah National Organization
(USNO), Tun Mustapha bin Dato Harun; Sabah
Chinese Association (SCA), Khoo Siak Chiew; no
organized opposition
Sarawak: coalition Sarawak Alliance composed of
the Pekaka/Bumipatra Party, the United People''s
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Party (SUPP), Ong Kee Hui and Sarawak Chinese
Association; opposition Sarawak National Party
(SNAP), Stephen Ningkan
Voting strength:
Peninsular Malaysia: (1974 election) National
Front controls 135 of 154 seats in lower house of
parliament
Sabah: (1974 Assembly Elections) Alliance
unopposed, opposition candidates disqualified
Sarawak: (1974 elections) National Front 30 out of
48 state assembly seats
Communists:
Peninsular Malaysia: approx. 1,700 armed
insurgents on Thailand side of Thai/Malaysia border;
approx. 800 on Malaysian side
Sarawak: 170 armed insurgents in Sarawak
Sabah: insignificant
Member of: ADB, ASEAN, Colombo Plan,
Commonwealth, FAO, GATT, IAEA, IBRD, ICAO,
IDA, IFC, ILO, IMCO, IMF, IPU, ITU, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO','3772e6422b8832ac4e87fef9b223b7d18bbdf44fd728ac2564b97e93a3f79262','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98b6fe36b6b13ec1cfd6380d2002a082c90f4227c0446783319a58822688605c',1976,'MV','Maldives','government',330,'Legal name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative districts
corresponding to atolls
Legal system: based on Islamic law with
admixtures of English common law primarily
in commercial matters; has not accepted compulsory
IC] jurisdiction
Branches: popularly elected unicameral national
legislature (Majlis) (members elected for 5-year
terms); elected President, chief executive; appointed
Chief Justice responsible for administration of Islamic
law
Government leader: President Ibrahim Nasir
Suffrage: universal over age 21
Political parties and leaders: no organized
political parties; country governed by the Didi clan
for the past eight centuries
Communists: negligible number
Member of: Colombo Plan, FAO, GATT (de
facto), IMCO, ITU, U.N., UPU, WHO','d693c536f71533f6ef8a302c69277b5a5563e2cb67f7952fb1ab41fc3b769735','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('497695aa6b949fbb162375c2140be4f7e584301145fb3978eea1f23fdcd41c6e',1976,'ML','Mali','government',334,'Legal name: Republic of Mali
Type: republic; under military regime since
November 1968
Capital: Bamako
Political subdivisions: 6 administrative regions; 42
administrative districts (cercles), arrondissements,
villages; all subordinate to central government
Legal system: based on French civil law system
and customary law; constitution adopted 1960,
amended 1961; judicial review of legislative acts in
Constitutional Section of Court of State; has not
accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by Military
Committee of National Liberation (MCNL) com-
posed of 11 army officers; under MCNL functional
cabinet composed of civilians and army officers;
judiciary
Government leaders: Col, Moussa Traore,
president of MCNL, Chief of State and head of
Suffrage: universal over age 21
Political parties and leaders: political activity
proscribed by military government
Elections: MCNL promises elections at unspecified
date
Communists: a few Communists and some
sympathizers
Member of: AFDB, CEAO, ECA, FAO, GATT (de
facto), IAEA, IBRD, ICAO, IDA, ILO, IMF, [TU,
Niger River Commission, OAU, OMVS (Organization
for the development of the Senegal River Valley),
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WHO, WMO
Legal name: Republic of Malta
Type: parliamentary democracy, independent
republic within the Commonwealth since December
1974
Capital: Valletta
Political subdivisions: 2 main populated islands,
Malta and Gozo, divided into 10 electoral districts
(divisions)
Legal system: based on English common law;
constitution adopted 1961, came into force 1964;
has accepted compulsory ICJ jurisdiction, with
reservations
Branches: executive, consisting of prime minister
and cabinet; legislative, comprising 55-member
House of Representatives; independent judiciary
Government leader: Prime Minister Dom Mintoff
Suffrage:
required
universal over age 21; registration
Elections: at the discretion of the Prime Minister,
but must be held before the expiration of a 5-year
electoral mandate; last election June 1971
Political parties and leaders: Nationalist Party,
Georgio Borg Olivier; Malta Labor Party, Dom
Mintoff
Voting strength (1971 election): Labor, 29 seats
(52.7%); Nationalist, 26 seats (47.296)
Communists: less than 100 (est.)
Member of; Commonwealth, Council of Europe,
FAO, GATT, IBRD, ICAO, ILO, IMCO, IMF, ITU,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WHO','a8ada78cdf94b7342e5179be8bfbba6a9665bfc4847c5d4eff39219086c109f0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b393de74a46a282c13b5cdd4875914cabaa3b70ff4726258329f54709303b751',1976,'MR','Mauritania','government',339,'Legal name: Islamic Republic of Mauritania
Type: republic; one-party presidential rule since
1960
Capital: Nouakchott
Political subdivisions: 12 regions and a capital
district
Legal system: based on French civil law system
and Islamic law; constitution adopted 1961; judicial
review of legislative acts in the Supreme Court; has
not accepted compulsory ICJ jurisdiction
Branches: president; Executive; separate judiciary
(appointed by president)
Government leader: President Moktar Ould
Daddah
Suffrage: universal for adults
Elections: presidential and parliamentary election
every 5 years; most recent August 1971
Political parties and leaders: Mauritanian Peoples
Party is only legal party, Secretary General Moktar
Ould Daddah
Communists: no Communist Party, but there is a
scattering of Maoist sympathizers
Member of: AFDB, Arab League, CEAO, EAMA,
EIB (associate), FAO, GATT, IBRD, ICAO, IDA,
IFC, ILO, IMCO, IMF, IPU, ITU, OAU, OMVS
(Organization for the Development of the Senegal
River Valley), Seabeds Committee, U.N., UNESCO,
UPU, WHO, WMO','5be5b5913d15313594077c3ed7747d0c76a61e8874d761f72a3f871c913186bf','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('675afa010e95793d943c0f3e96315c0b29e126418812d514a91030700e984e7b',1976,'MU','Mauritius','government',343,'Legal name: Mauritius
Type: independent state since 1968, recognizing
Elizabeth II as chief of state
Capital: Port Louis
Political subdivisions: 5 organized municipalities
and various island dependencies
Legal system: based on French civil law system
with elements of English common law in certain
areas; constitution adopted 6 March 1968
Branches: executive power exercised by Prime
Minister and 21-man Council of Ministers;
unicameral legislature (National Assembly) with 62
members elected by direct suffrage, 8 specially
elected, and one nominated
Government leader: Prime Minister Dr. Seewoosa-
gur Ramgoolam
Suffrage: universal over age 21
Elections: last held in August 1967; next scheduled
in 1972 postponed at least 4 years by constitutional
amendment
adjective—
136
Political parties and leaders: a loose government
coalition consisting of Labor Party (S. Ramgoolam)
and Muslim Committee of Action (A. R. Mohamed);
opposition parties — Parti Mauricien Social
Democrate (G. Duval), Independent Forward Bloc (S.
Bissoondoyal) Mauritius Democratic Union (M.
Lesage) Mouvement Militant Mauritian (P.
Berenger), Mouvement Militant Mauritian Socialiste
Progressist (D. Virahsawmy)
Voting strength: Muslim Committee of Action, 4
seats; Independent Forward Bloc, 4 seats: Mauritius
Labor Party, 41 seats; Mauritius Democratic Union, 5
seats; Parti Mauricien Social Democrate, 15 seats;
Mouvement Militant Mauritian Socialiste Progressist,
l seat; ] seat vacant
Communists: may be 2,000 sympathizers; several
Communist organizations; Mauritius Lenin Youth
Organization, Mauritius Women''s Committee,
Mauritius Communist Party, Mauritius People''s
Progressive Party, Mauritius Young Communist
League, Mauritius Liberation Front, Chinese Middle
School Friendly Association, Mauritius/USSR
Friendship Society
Other political or pressure groups: Tamil United
Party, Mauritius Workers Party
Member of: Commonwealth, FAO, GATT, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, OAU, OCAM,
U.N., UNESCO, UPU, WCL, WFTU, WHO, WMO
Legal name: Overseas Department of Reunion
Type: overseas department of France; represented
in French Parliament by three Deputies and two
Senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect
appointed by the French Minister of Interior, assisted
by a Secretary-General and an elected 86-man
General Council
Government leader: Prefect Paul Cousseran
Suffrage: universal adult
Elections: last municipal elections in 1971;
parliamentary election March 1973
Political parties and leaders: Reunion Communist
Party (RCP) led by Paul Verges, only organized
political movement on island; other political
candidates affiliated with metropolitan French
parties, which do not maintain permanent organiza-
tions on Reunion
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
REUNION/RHODESIA
Voting strength (parliamentary election 1973):
Union of Democrats for the Republic elected, one
senator and two deputies; Centrist Union, one
deputy; one Senator independent
Communists: Communist Party small — probably
only 15-20 hard-line Communists — but has support
among sugarcane cutters and in Le Port district
Member of: WFTU
Legal name: Colony of Southern Rhodesia
Type: self-proclaimed independent state since 1965
(not recognized by U.S.); provisional settlement with
noun—Bhodesian(s); adjective—
171
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
RHODESIA/ROMANIA
U.K. in November 1971 cancelled by U.K. in May
1972 in response to Pearce Commission''s conclusion
that its terms were unacceptable to the majority of
black Rhodesians
Capital: Salisbury
Political subdivisions: 11 magisterial districts
Legal system: Smith government implemented a
republican constitution on 2 March 1970 which
institutionalized white rule
Branches: President Dupont is ceremonia! head of
state; executive council (cabinet) lead by Prime
Minister Smith; National Assembly gives highly
disproportionate representation to white minority —
50 white constituency seats and 16 black constituency
seats
Government leaders: Prime Minister lan Smith
and President Clifford Dupont
Suffrage: franchise is based on income, property
holdings, and education; there are separate rolls for
Africans and non-Africans
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front,
Prime Minister Smith; Rhodesia Party, Tim Gibbs;
Rhodesia National Party, Leonard Idensohn; African
Progressive Party, Chad Chipunza
Voting strength (1974 elections): Rhodesian Front
won all 50 white constituency seats in Parliament in
July 1974 elections
Communists: negligible
Other pressure groups and leaders: principal
black nationalist group — African National Council,
Abel Muzorewa; since December 1974 ANC has
included membership of three former insurgent groups
— Zimbabwe African National Union (Ndabaningi
Sithole), Zimbabwe African People''s Union (Joshua
Nkomo), Front for the Liberation of Zimbabwe
(James Chikerema); the enlarged ANC split in
September 1975, when Nkomo gained control of the
ANC organization inside Rhodesia, and Muzorewa
aligned with Sithole and other exiled insurgent leaders
Member of: ITU','8eb393f929912f328634e6a701e4c5422a9698f7917efacbf7c74592d5aa3b05','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('876fe8e29e1daa54d4b6b9ee0c3e65c3a387ec5f7e99019713871b122622879a',1976,'MX','Mexico','government',346,'Legal name: United Mexican States
Type: federal republic operating in fact under a
centralized government
Capital: Mexico
Political subdivisions: 31 states, Federal District
Legal system: mixture of U.S. constitutional theory
and civil law system; constitution established in 1917;
judicial review of legislative acts; accepts compulsory
ICJ jurisdiction, with reservations
Branches: dominant executive, bicameral legisla-
ture, Supreme Court
Government leader: President Luis Echeverria
Suffrage: universal over age 18; compulsory but
unenforced
Elections: national elections July 1976
Political parties and leaders: Institutional
Revolutionary Party (PRI), Porfirio Munoz Ledo;
National Action Party (PAN), Efrain Gonzalez
Morfin; Popular Socialist Party (PPS), Jorge
Cruickshank Garcia; Authentic Party of the
Revolution (PARM), Pedro Gonzalez Azcuaga
Voting strength: (1973 congressional elections) PRI
69.5%, PAN 14.7%, PPS 3.5%, PARM 1.8%, others
0.8%, annulled 9.7%
Communists: estimated 5,000 in Communist Party
Other political or pressure groups: Roman
Catholic Church, Confederation of Mexican Workers
(CTM), Confederation of Industrial Chambers
(CONCAMIN), Confederation of National Chambers
of Commerce (CONCANACO), National Cofedera-
tion of Campesinos (CNC), National Confederation
of Popular Organizations (CNOP), Revolutionary
Confederation of Workers and Peasants (CROC)
Member of: FAO, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMCO, IMF, ITU, LAFTA,
137
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MEXICO/MONACO
OAS, Seabeds Committee, U.N., UNESCO, UPU,
WCL, WFTU, WHO, WMO','da48e244c926a48368e087b940012db63595124d9eac508b51dbb91f7e7ec0c0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7d796480babccf84ab84c8538f0d40ba34f18a647aafe52d06e7af7d4064f0d',1976,'MC','Monaco','government',350,'Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections
Legal system: based on French law; new
constitution adopted 1962; has not accepted
compulsory ICJ jurisdiction
Branches: National Council (18 members);
Communal Council (15 members, headed by a
mayor)
Government leader: Prince Rainier III
Suffrage: universal
Elections: National Council every 5 years; most
recent 1973
Political parties and leaders: National Democratic
Entente, Democratic Union Movement, Monegasque
Actionist (1973)
Voting strength: figures for 1978: National
Democratic Entente, 16 seats; Democratic Union
Movement and Monegasque Actionist, 1 seat each
Member of: IAEA, IHO, IPU, ITU, Seabeds
Committee, U.N., UNESCO, UPU, WHO','24164a017628059a87ca2aad916a70f04afde1c07f1d274da179d4dd762f3e9c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e22d337f3bc785a2df43df95b89935443772d2e54a152f65ef0544c0e1f5e532',1976,'MN','Mongolia','government',354,'Legal name: Mongolian Peoples Republic,
Type: Communist state
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 2
autonomous municipalities (Ulaanbaatar and
Darhan)
Legal system: blend of Russian, Chinese, and
Turkish systems of law; new constitution adopted
1960; no constitutional provision for judicial review of
legislative acts; legal education at Ulaanbaatar State
139
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MONGOLIA/MOROCCO
University; has not accepted compulsory IC]
jurisdiction
Branches: constitution provides for a People’s
Great Hural (national assembly) and a highly
centralized administration
Party and government leaders: Y. Tsedenbal, First
Secretary of the MPRP and Chairman of the People''s
Great Hural; J. Batmunh, Chairman of the Council of
Ministers
Suffrage: universal; age 18 and over
Elections: national assembly elections held every 4
yeurs; last elections held in June 1978
Political party: Mongolian People''s Revolutionary
(Communist) Party (MPRP); estimated membership,
58,000 (claimed 1972)
Member of; CEMA, ESCAP, IAEA, ILO, IPU,
ITU, Seabeds Committee, U.N., UNESCO, UPU,
WFTU, WHO, WMO','a8734f75de7c8b6987cc42c977bec80faa91b0671dac98aa743b761379dd740f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c31a650659b6118e8d39b3b6432fc17fa72066e22257b4b180294e8a04fac08',1976,'MA','Morocco','government',358,'Legal name: Kingdom of Morocco
Type: constitutional monarchy (constitution
adopted 1972)
Capital: Rabat
Political subdivisions: 28 provinces and 2
prefectures
Legal system: based on Islamic law and French
and Spanish civil law system; judicial review of
adjective—
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
legislative acts in Constitutional Chamber of Supreme
Court; modern legal education at branches of
Mohamed V University in Rabat and Casablanca and
Karaouine University in Fes; has not accepted
compulsory ICJ jurisdiction
Branches: constitution provides for Prime Minister
and ministers named by and responsible to King; King
has paramount executive powers; unicameral
legislature in abeyance until elections are held (two-
thirds to be directly elected, one third indirectly);
judiciary independent of other branches
Government leaders: King Hassan II; Prime
Minister Ahmed Osman
Suffrage: universal over age 20
Elections: last parliamentary elections held 21 and
28 August 1970 for Council of Representatives which
was dissolved in March 1972; elections for new
parliament created by Constitution adopted 15
March 1972 have not been held
Political parties and leaders: Istiglal Party,
M''hamed Boucetta; Popular Movement (MP),
Mahjoubi Aherdan; Constitutional and Democratic
Popular Movement (MPCD), Dr. Abdelkrim Khatib;
National Union of Popular Forces (UNFP), split into
competitive factions under Abdallah Ibrahim and
Mahjoub Ben Seddik of Casablanca-based faction
and Abderrahim Bouabid of Rabat-based faction with
latter becoming Socialist Union of Popular Forces
(USFP) in September 1974; Democratic Constitu-
tional Party (PDC), Mohamed Hassan Ouazzani;
Party for Progress and Socialism (PPS), legalized in
August 1974, successor to Party for Progress and
Socialisim (PPS), is front for Moroccan Communist
Party (MCP), which was proscribed in 1959, Ali Yata;
Istiglal and the UNFP formed a National Front in
July 1970 to oppose the new constitution, boycotted
the parliamentary elections and the 1972 constitu-
tional referendum
Voting strength: August 1970 elections were
nonpolitical; 1 March 1972 constitutional referendum
tallied 98.7% for new constitution, 1.25% opposed
and National Front abstained from voting
Communists: 300 est.
Member of: AFDB, Arab League, EC (association
until 1974), FAO, GATT, IBRD, ICAO, IDA, IFC,
ILO, IMCO, IMF, IPU, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO','02482963adf714c36ded0bd12fc1ad509da03215a1a84e44987bfc7890b311fa','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d73a9f32b9155bae7d59e74a8e37bf2e1d926f91f70f821d0e263c9d5d3c07f5',1976,'MZ','Mozambique','government',362,'Legal name: Peoples Republic of Mozambique
Type: peoples republic; achieved independence
from Portugal in June 1975
Capital: Lourenco Marques
142
Political subdivisions: 10 districts administered by
district governors; municipalities governed by
appointed official
Legal system: based on Portuguese civil law system
and customary law
Branches: none established
Government leader: President Samora Machel;
Vice-President Marcelino dos Santos
Suffrage: not yet established
Elections: information not available on future
election schedule
Political parties and leaders: the Mozambique
Liberation Front (FRELIMO), led by Samora
Machel, is only legal party
Communists: none known
Member of: OAU, U.N.','2833e8311d078f8b2f33bacbabe231b3870d46974fd3ed9dc6bd535a10fd915c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47ab2825cc87c84a3151bd2ef7cfa69663f0a4fb7ddc363ccdfbfe15ee9f4df3',1976,'NR','Nauru','government',368,'Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices
in Uaboe District
noun—Nauruanís); adjective—
Political subdivisions: 14 districts
Branches: President clected from and by
Parliament for an unfixed term; popularly elected
unicameral legislature, the Parliament; Cabinet to
assist the President, four members, appointed by
President from Parliament members
Government leader: President Hammer De Roburt
Suffrage: universal adult
Elections: last held in January 1971
Political parties and leaders: there are no political
parties; De Roburt is only significant political figure
Member of: no present plans to join U.N.; enjoys
"special membership” in Commonwealth; South
Pacific Commission, ESCAP, INTERPOL, ITU, UPU','a395442085c02fbeff124de9fbdf56d376a9c46e29ce25e775e43d13be7ac818','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09c30ff915de559d0b095e044895e3ef0f75c2574f5239ba6d3f1df903dee812',1976,'NP','Nepal','government',372,'Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Birendra
exercises autocratic control over multitiered
panchayat system of government
Capital; Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and
English common law; legal education at Nepal Law
144
College in Kathmandu; has not accepted compulsory
IC] jurisdiction
Branches: Council of Ministers appointed by the
King; indirectly elected National Panchayat
(Assembly)
Government leader; King Birendra Bir Bikram
Shah Deva; Prime Minister Nagendra Prasad Rijal
Suffrage: universal over age 21
Elections: village and town councils (panchayats)
elected by universal suffrage; district, zonal, and
National Panchayat members indirectly elected, most
for 6-year terms; 15 National Panchayat members
elected from five class organizations (women, workers,
youth, and ex-servicemen), four directly elected by all
voters possessing a B.A. or its equivalent, and 16 are
appointed by the King
Political parties and leaders: all political parties
outlawed
Communists: the combined membership of the two
wings of the Communist Party of Nepal (CPN) may
be on the order of 6,500, the majority (perhaps 5,000)
in the pro-Chinese wing: the CPN continues to
operate more or less openly, but internal dissension
has greatly hindered its effectiveness
Other political or pressure groups: proscribed
Nepali Congress Party led by B.P. Koirala from exile
in India
Member of: ADB, Colombo Plan, FAO, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, U.N,
UNESCO, UPU, Seabeds Committee, WHO, WMO','24f80a11bd54c16d8a512e3b56bc8b12737d2f6b42d12abaa6c21cc693ea756e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6420c6a73af836121f93db705ea89045285cda42861cbe9b8de83e6cefe8e686',1976,'NZ','New Zealand','government',378,'Legal name: Dominion of New Zealand (rarely
used)
Type: independent state within Commonwealth,
recognizing Elizabeth II as head of state
Capital: Wellington
Political subdivisions: 112 counties
Legal system: based on English law, with special
land legislation and land courts for Maori tribesmen;
constitution consists of various documents, including
certain acts of the U.K. and New Zealand
Parliaments; legal education at Victoria, Auckland,
Canterbury, and Otago Universities; accepts
compulsory ICJ jurisdiction, with reservations
Branches: unicameral legislature (General As-
sembly, commonly called Parliament); Cabinet
responsible to Parliament; 3-level court system
(Magistrates Courts, Supreme Court, and Court of
Appeal)
Government leader: Prime Minister Robert D.
Muldoon
Suffrage: universal age 18 and over
Elections: held at 8 year intervals or sooner if
parliament is disolved by Prime Minister; last election
November 1975
Political parties and leaders: National Party
(Government), Robert D. Muldoon; Labour Party
150
(Opposition), Wallace E. Rowling; Social Credit
Political League, Bruce Beetham; Communist Party,
George Victor Wilcox; pro-Soviet Socialist Unity
Party, George Edward Jackson
Voting strength (1975 election): National Party 53
seats, Labour Party 34 seats
Communists: CPNZ about 800, SUP about 100
Member of: ADB, ANZUS, ASPAC, Colombo
Plan, DAC, ESCAP, FAO, GATT, IAEA, IBRD,
ICAO, IEA, IFC, IHO, ILO, IMCO, IMF, IPU, ITU,
OECD, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO','0a0f82e6b3b435e2f62744e270b8e0532ac1eaeef2a12e406c19ba1f096982c8','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae05216898ae71150e51097e0190f24979e50f35f5622af47b484be7a6b8617c',1976,'NI','Nicaragua','government',382,'Legal name: Republic of Nicaragua
Type: republic
Capital: Managua
Political subdivisions: 1 national district and 16
departments
Legal system: based on Spanish civil law system;
constitution adopted in 1974; legal education at
Universidad Nacional de Nicaragua and Universidad
Centroamericana; accepts compulsory IC] jurisdic-
tion
Branches: President (traditionally dominant)
bicameral legislature, judiciary elected by legislature,
and Supreme Electoral Tribunal (4th branch)
Government leaders: President Anastasio Somoza
Suffrage: universal over age 18 if married or
literate, otherwise 21
Elections: every 6 years; municipal elections every
3 years
Political parties and leaders: Nationalist Liberal
Party (PLN), Anastasio Somoza; Nicaraguan
Conservative Party (PCN), Edmundo Paguaga
Voting strength (1974 elections); PLN, 9596 of
votes; 5% of votes; PCN will, however, occupy 40% of
legislative seats by constitutional provision
Communists: Communist movement split into
hard-line Nicaraguan Socialist Party (PSN) illegal, 60
members; soft-line Nicaraguan Communist Party
(PCN) illegal, 40 members, and small pro-Castro
Sandinist National Liberation Front (FSLN) activist,
50-60 members; about 1,000 sympathizers
Other political or pressure groups: Democratic
Union of Liberation (UDEL), an opposition front
lacking legal status of a political party, composed of
anti-Somoza political movements and labor groups
with orientations ranging from conservative to
Christian. Democrat to Communist, leadership
includes Pedro J. Chamorro, Ramiro Sacasa, Ignacio
Zelaya, Manuel Morales, Domingo Sanchez
Member of: CACM, FAO, GATT, IADB, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMF, INTELSAT, IPU,
151
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NICARAGUA/NIGER
ITU, OAS, ODECA, Seabeds Committee U.N.,
UNESCO, UPU, WCL, WHO, WMO','fbaa58a5d8fc6dc95c427e62a49d48b276be89be7358bbe508911616859f6e2a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3eeaee2d500102ee9f425c75e8ecbe36ca85306c888353fed8858d2d8a63279b',1976,'NE','Niger','government',386,'Legal name: Republic of Niger
dá Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NIGER/NIGERIA
Type: republic; military regime in power since
April 1974
Capital: Niamey
Political subdivisions:
arrondissements
Legal system: based on French civil law system
and customary law; constitution adopted 1960,
suspended 1974; judicial review of legislative acts in
Constitutional Chamber of the Supreme Court; has
not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by
Provisional Supreme Military Council (SMC)
composed of 12 army officers
Government leader: President Lt. Col. Seyni
Kountche
Suffrage: universal over age 21
Elections: political activity banned
Political parties and leaders: political parties
banned
Communists: no Communist party; some sympa-
thizers in outlawed Sawaba party
Member of: AFDB, CEAO, EAMA, ECA, Entente,
FAO, GATT, IAEA, IBRD, ICAO, IDA, ILO, IMF,
IPU, ITU, Lake Chad Basin Commission, Niger Hiver
Commission, OAU, OCAM, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO
7 departments, 32','edcb1cdd148001c4a109e2d9854531711661faa3029514e4880bfd288aa506aa','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2eb56c28d7c93a76f528c2e3dc01f443be60377326ab0abc73660bb7829caa3',1976,'NG','Nigeria','government',390,'Legal name: The Federal Republic of Nigeria
Type: federal republic since 1963; under military
rule since January 1966
Capital: Lagos
Political subdivisions: 12 states, headed by a
military governor
Legal system: based on English common law,
tribal law, and Islamic law; new constitution to be
prepared; accepts compulsory ICJ jurisdiction with
reservations
Branches: Federal Military Government; decrees
issued by Supreme Military Council, advised by
largely civilian Federal Executive Council
Government leader: Brigadier Murtala Muham-
med, Head of Federal Military Government and
Commander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage (except for
women in former Northern Region)
Elections: the military has promised to restore
power to an elected civilian regime when state and
federal legislative elections are held between October
1978 and October 1979
Political parties and leaders: political parties and
politically active tribal societies were dissolved by
decree on 24 May 1966; some sub rosa political
activity continues
Communists: the banned Socialist Workers and
Farmers Party and the Nigerian Trade Union
Congres have a limited political following, no
influence on government
Member of: AFDB, Commonwealth, ECA,
ECOWAS, FAO, IAEA, IBRD, ICAO, IDA, IFC,
ILO, IMCO, IMF, ITU, Lake Chad Basin
154
Commission, Niger River Commission, OAU, OPEC,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WFTU, WHO, WMO','55b4d2867566727c768e351679b36b62c7b631fd7c4b9f530d4961ef8610557f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74eaacd0902e58c1d66f6df8c5961476f0f52a510490408b79c1f8892b4dcfc9',1976,'NO','Norway','government',394,'Legal name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 19 counties, 404 communes,
47 towns
Legal system: mixture of customary law, civil law
system, and common law traditions; constitution
adopted 1814, modified 1884; Supreme Court renders
advisory opinions to legislature when asked; legal
education at University of Oslo; accepts compulsory
IC] jurisdiction, with reservations
Branches: legislative authority rests jointly with
Crown and parliament (Storting); executive power
vested in Crown but exercised by cabinet responsible
to parliament; Supreme Court, 5 superior courts, 104
lower courts
Government leaders: King Olav V; Prime Minister
Trygve Bratteli
Suffrage: universal, but not compulsory, over age
20
Elections: held every 4 years (next in September
1977)
Political parties and leaders; Anti-Tax Party,
Arve Loennum; Conservative, Kaare Willoch;
Christian People’s, Lars Korvald; Center, Erland
Steenberg, Dagfinn Vaarvik; Liberal, Hans H.
Rossbach, Eva Kolstad; New Liberal People''s, Ole
Myrvoll, Magne Lerheim; Labor, Reiulf Steen;
combined Socialist Left Party, Berit Aas, chairman
Voting strength (1973 election): 5% Anti-tax;
17.5% Conservative; 12.2% Christian Peoples; 11%
Center; 3.5% Liberal; 3.4% New Liberal Peoples;
35.3% Labor; 11.2% Socialist Electoral Alliance
(includes Democratic Socialist, Socialist People''s, and
Communist Party)
Communists: 2,500 est.; a number of sympathizers
as indicated by the 22,500 Communist votes cast in
the 1969 election
Member of: ADB, Council of Europe, DAC, EC
(Free Trade Agreement), EFTA, ESRO (observer),
FAO, GATT, IAEA, IBRD, ICAO, IDA, IEA
(associate member), IFC, THO, ILO, IMCO, IMF,
IPU, ITU, NATO, Nordic Council, OECD, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO','3383382d2aaed3f0e4aec8d017883e03ae09cfa8609e053369d4ba5d74e27560','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0bedb2f13cacf0d5e797ecbaac90cad95c643a51468081b4a83b04de5d0aefd',1976,'OM','Oman','government',398,'Legal name: Sultanate of Oman
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Mises norit
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
OMAN/PAKISTAN
Type: absolute monarchy; nominally independ-
ent but under strong U.K. influence
Capital: Muscat.
Legal system: based on English common law and
Islamic law; no constitution; ultimate appeal to the
Sultan; has not accepted compulsory IC] jurisdiction
Government leader: Sultan Qabus ibn Sa''id Al Bu
Sa''id
Other political or pressure groups: none
Member of: Arab League, FAO, IBRD, ICAO,
IDA, IFC, IMF, Seabeds Committee, U.N.,
UNESCO, UPU, WHO','c87a757d4215c64f3e0fafd22f8a68fdbae16dc17c3da23a0fb3357f3786049e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e53a105f33e8324b19ba4b62fc4ea282c67ca2c9b794a7d17cc0d92ff620f8c',1976,'PK','Pakistan','government',402,'Legal name: Islamic Republic of Pakistan
Type: parliamentary, federal republic; constitution
adopted April 1973, effective August 1973, provides
for bi-cameral legislature, strong prime minister
Capital: Islamabad
Political subdivisions: 4 provinces — Punjab, Sind,
Baluchistan, and Northwest Frontier — with the
capital territory of Islamabad and certain tribal areas
centrally administered; Pakistan claims that Azad
157
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PAKISTAN/PANAMA
Kashmir is independent pending a settlement of the
dispute with India, but it is in fact under Pakistani
control
Legal system: based on English common law;
accepts compulsory ICJ jurisdiction, with reservations
Government leaders: President Fazal Elahi
Chaudhry; Prime Minister Z. A. Bhutto
Suffrage: universal from age 21
Elections: elections for National Assembly based
on one-man/one-vote formula, and for provincial
assemblies were held in December 1970; under 1973
Constitution, next National Assembly elections must
be held no later than 1977
Political parties and leaders: Pakistan People''s
Party (PPP), Z. A. Bhutto; Pakistan Muslim League
(QML), Abdul Qaiyum Khan; Tehrik-i-Istiqlal,
Asghar Khan; United Muslim League (UML), Pir of
Pigaro; National Awami Party (NAP), Abdul Wali
Khan (party outlawed in February 1975); Jamaat-i-
Islami (JI), Tofail Mohammed; Markazi Jamiat-ul-
Ulema-i-Pakistan (MJUP), Maulana Shah Ahmed
Noorani; Jamiat-ul-Ulema-i-Islam (JUD, Mufti
Mahmud; several of these parties belong to United
Democratic Front (UDF), an opposition coalition
Communists: party membership very small; several
thousand sympathizers
Other political or pressure groups: military
remains potentially strong political force
Member of: ADB, CENTO, Colombo Plan, FAO,
GATT, IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO,
IMCO, IMF, ITU, RCD, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO','a694c0ad03ff4572333d8cb1dad0b25e5a4ce528eed46fa8baeaead9e317f724','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4becbc27ae4b73be8cc2604a9748388c2dce7cb515a66784d330efadc2b9976c',1976,'PA','Panama','government',406,'Legal name: Republic of Panama
Type: republic
Capital: Panama
Political subdivisions: 9 provinces, 1 intendancy
Legal system: based on civil law system;
constitution adopted in 1972; judicial review of
legislative acts in the Supreme Court, legal education
at University of Panama; accepts compulsory IC]
jurisdiction, with reservations
Branches: popularly elected unicameral legislature
which elects the President; presidentially appointed
Supreme Court
Government leaders: Demetrio Lakas is Constitu-
tional President and Chief of State, but subordinate to
Gen. Omar Torrijos, the National Guard Comman-
dant who was given special powers for 6 years by the
Constitutional Assembly in 1972
Suffrage: universal and compulsory over age 21
Elections: elections for assembly of representatives
of the corregimientos August 1972; next election
August 1978
Political parties and leaders: political parties
suspended pending revision of electoral code;
Communist Party illegal but allowed to operate
Voting strength (1968 election): 55% Arnulfo
Arias Madrid (National Union Coalition), 42% David
Samudio (People’s Alliance), 3% Antonio Gonzalez
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Revilla (Christian Democratic Party); no parties were
active in the 1972 elections
Communists: 100 active and several hundred
inactive members People''s Party (PdP); Communist;
1,000 sympathizers; National Liberation Movement
(MLN) and Vanguard of National Action (VAN)
inactive as pro-Castro organizations, 40-60 members
Other political or pressure groups: National
Council of Private Enterprise (CONEP)
Member of: FAO, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMCO, IMF, ITU, OAS,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WFTU, WHO, WMO','8a4ffd786784ad1701f874abd4950bd93225c8fbbad0a336acf0363b6d44c4b6','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f71b417ae89f56f0705a936a2d894bf716c2a43747b5390e2269897975d55c7',1976,'PY','Paraguay','government',410,'Legal name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion
Political subdivisions: 16 departments and the
national capital, 154 municipalities
Legal system: based on Argentine codes, Roman
law, and French codes; constitution promulgated
1967; judicial review of legislative acts in Supreme
Court; legal education at National University of
Asuncion and Catholic University of Our Lady of the
Assumption; does not accept compulsory IC]
jurisdiction
Branches: President heads executive; bicameral
legislature; judiciary headed by Supreme Court
Government leader: President (General) Alfredo
Stroessner
Suffrage: universal; compulsory between ages of
18-60
Elections: President and Congress elected together
every 5 years; last election held in February 1973
Political parties and leaders: Colorado Party, Juan
Ramon Chavez; Liberal Party (Levi-Liberal Party),
Carlos Levi Ruffinelli; Febrerista Party, Roque
Gaona; Radical Liberal Party (regular Liberal Party),
Domingo Laino; Christian Democratic Party (not
officially inscribed), Livis Resck
161
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PARAGUAY/PERU
Voting strength (February 1973 general elec-
tion): 84% Colorado Party, 13% Radical Liberal
Party, 3% Liberal Party, Febrerista Party boycotted
clections
Communists: Oscar Creydt faction and Miguel
Angel Soler faction (both illegal); est. 3,000 to 4,000
party members and sympathizers in Paraguay, very
few are hard core; party in exile is small and deeply
divided
Other political or pressure groups: Popular
Colorado Movement (MoPoCo) led by Epifanio
Mendez Fleitas, in exile
Member of: FAO, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMF, IPU, ITU, LAFTA, OAS,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WHO, WMO','8edb8a05cbe249a6d3ec20335453ae6cb419f0eac69e233ad934cd6781f7ab41','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('141bf6a3414e85ced68f7dfb49768f5c31d3e59fc0c362ceae62e081e12b26fb',1976,'PE','Peru','government',414,'Legal name: Republic of Peru
Type: republic; under military regime since
October 1968
Capital: Lima
Political subdivisions: 23 departments with limited
autonomy plus constitutional Province of Callao
Legal system: based on civil law system; military
government rules by decree; legal education at the
National Universities in Lima, Trujillo, Arequipa, and
Cuzco; has not accepted compulsory IC] jurisdiction
Branches: executive, legislative, judicial; congress
disbanded after 3 October 1968 ouster of President
Fernando Belaunde Terry
Government leader: President, General Francisco
Morales Bermudez Cerrutti
Suffrage: obligatory for citizens (defined as adult
men and women and married persons over age 18)
until age 60
Elections: none scheduled
Political parties and leaders: Christian Demo-
cratic Party (PDC), Juan Lituma Portocarrero,
President, supports the government; opposition parties
include the Popular Action Party (AP), Fernando
Belaunde Terry (in exile but expected to return to Peru
late in 1975 or in early 1976); American Popular
Revolutionary Alliance (APRA), Victor Raul Haya de
la Torre; and Popular Christian Party (PPC), Luis
Bedoya Reyes
Voting strength (1963 election): 39% AP-PDC,
34% APRA, 25% UNO, 1% Communist, 1% other
Communists: pro-Soviet (PCP/S) 2,000; pro-
Chinese (2 factions) 1,200
Other political or pressure groups: government-
sponsored social mobilization system (SINAMOS)
which is being restructured; a pro-government
political organization is currently in the formative
stage
Member of; FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMCO, IMF, ITU,
LAFTA and Andean Pact, OAS, Seabeds Committee,
U.N., UNESCO, UPU, WCL, WFTU, WHO, WMO','36c7511360d79c53ca651238533a8ebf35a7fdf88a7e5596aed9acf9daa27091','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5300c7cc041acd3095b828a6c552c3a4b62b732e3a16c9c025e69437ba426e6',1976,'PL','Poland','government',418,'Legal name: Polish Peoples Republic (PRL)
Type: Communist state
Capital: Warsaw
Political subdivisions: 49 provinces
Legal system: mixture of Continental (Napoleonic)
civil law and Communist legal theory; constitution
adopted 1952; court system parallels administrative
divisions with Supreme Court, composed of 104
justices, at apex; no judicial review of legislative acts;
legal education at 7 law schools; has not accepted
compulsory IC] jurisdiction
Branches: legislative, executive, judicial system
dominated by parallel Communist party apparatus
Government leader: Piotr Jaroszewicz, Premier;
Henryk Jablonski, chairman of Council of State
(President)
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government
every 4 years
165
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
POLAND/PORTUGAL
Dominant political party and leader: Polish
United Workers’ Party (PZPR) (Communist), Edward
Gierek, First Secretary
Voting strength (1972 election): 97% voted for
Communist-approved single slate
Communists: 2,320,000 party members (January
1974)
Other political or pressure groups: National Unity
Front (FJN), including United Peasant Party (ZSI.),
Democratic Party (SD), progovernment pseudo-
Catholic Pax Association and Christian Social
Association, Catholic independent Znak group;
powerful Roman Catholic Church, Stefan Cardinal
Wyszynski, Primate
Member of: CEMA, GATT, ICAO, IHO,
Indochina Truce Commission, IPU, Korea Truce
Commission, Seabeds Committee, U.N. and all
specialized agencies except IMF and IBRD, Warsaw
Pact, Vietnam [CCS (International Commission for
Control and Supervision), WFTU','b94f72007f09b1fc4269ab58a295afce00f7d4a557200c446a9900a4704417f2','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acf90273955389914901d04fbea9cd43aa320136ece618e96aafcda2f80ac4ce',1976,'PT','Portugal','government',422,'Legal name: Republic of Portugal
Type: republic, provisional government formed
May 1974, after military coup by group of young
military officers, known as the Armed Forces
Movement, who overturned the Caetano regime;
major political parties signed document in April 1975
agreeing to continued military rule for the next 8 to 5
years
Capital: Lisbon
Political subdivisions: 18 districts in mainland
Portugal and 4 "autonomous districts" in Azores and
Madeira Islands; 2 overseas provinces—Portuguese
Timor and Macao
Legal system: civil law system; constitution
adopted 1938, frequently amended since; new
constitution is being written by popularly elected
constituent assembly according to guidelines set by
the Armed Forces Movement; no judicial review of
legislative acts; legal education at Universities of
Lisbon and Coimbra; accepts compulsory ICJ
jurisdiction, with reservations
Branches: executive with President and Prime
Minister included in Armed Forces Movement''s 28-
man Revolutionary Council; legislative branch under
new constitution will have civilian assembly and
Armed Forces General Assembly; judicial controlled
by executive branch
Government leaders: President Francisco da Costa
Gomes; Prime Minister Jose Pinheiro de Azevedo
Suffrage: new election law passed in October 1974
enfranchises all citizens over 18, including emigrants
who left Portugal less than 5 years ago; a few
thousand persons have been declared ineligible to vote
because of their activities under the previous regime
Elections: Constituent Assembly election held on
April 25, 1975; new constitution will set date for
election of a civilian legislative assembly, probably in
early 1976
Political parties and leaders: the Portuguese
Socialist Party (PSP) led by Mario Soares, the
Portuguese Communist Party (PCP), under Alvaro
Cunhal, and the Popular Democratic Party (PPD)
headed by Francisco Sa Carneiro are the best
organized; other significant groups include the center-
right Social Democratic Center Party (CDS), led by
Adelino Amaro da Costa, and the Communist-leaning
Portuguese Democratic Movement (MDP), under
Francisco Pereira da Moura
Voting strength: (1975) the Socialists polled 38% of
the vote for a constituent assembly; the PPD received
26%, the Communists 13%, the CDS 8%, and the
MDP 4%
Communists: membership has increased and
cannot be determined since the party became overt in
April 1974
Other political or pressure groups: Association for
the Study of Economic and Social Development
(SEDES) authorized in October 1970 as a discussion
group with political overtones
Member of: EFTA, FAO, GATT, IAEA, IBRD,
ICAO (restricted membership), IFC, IHO, ILO, IMF,
ITU, NATO, OECD, Seabeds Committee, U.N.,
UPU, WHO, WMO
Legal name: Province of Timor
Type: overseas province of Portugal
Capital: Dili
Indonesian troops invaded Portuguese Timor on
December 7. Although Portugal was still the de jure
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PORTUGUESE TIMOR/QATAR
administering power, Lisbon had publicly admitted
that it could no longer control the situation in the
territory and had withdrawn all Portuguese officials
from the capital at Dili. Indonesia is expected to hold
a referendum in Timor, probably under U.N.
auspices, in order to ratify its annexation of Kast
Timor.
Member of: ITU','d7d6d5ecb28dbe07ac225ecbcc41562c2f27416e45c7ce8db1f6154a4037abf3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('914c79790bad33a1f07c30219063dd7141582134c348de996c0fd41edabe20b1',1976,'QA','Qatar','government',426,'Legal name: State of Qatar
Type: traditional monarchy; independence
declared in 1971
Capital: Ad Dawhah
Legal system: discretionary system of law
controlled by the ruler, although new civil codes are
being implemented; Islamic law is significant in
personal matters; a constitution was promulgated in
1970
Government leader: Amir Khalifa ibn Hamad Al-
Thani
Suffrage: no specific provisions for suffrage laid
down
Elections: constitution calls for elections for part of
State Advisory Council, semi-legislative body, but
none have been held
Political parties and pressure groups: none; a few
small clandestine organizations are active
Branches; Council of Ministers
Member of: Arab League, FAO, GATT (de facto),
IBRD, ICAO, ILO, IMF, OAPEC, OPEC, Seabeds
Committee, U.N., UNESCO, UPU, WHO
169
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
QATAR/REUNION','7b4604a515b3eed5417840e2762b966da546c9fdcab160ab4a1360b3c224c910','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f68b408c48516207a4272ae3fff8055a534ef1542ffd477b8e461145b1b33ef',1976,'RO','Romania','government',430,'Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 39 counties and 46
municipalities, including Bucharest that has
administrative status equal to a county
Legal system: mixture of civil law system and
Communist legal theory which increasingly reflects
Romanian traditions; constitution adopted 1965;
legal education at University of Bucharest and two
other law schools; has not accepted compulsory ICJ
jurisdiction
Branches: Presidency; Council of Ministers; the
Grand National Assembly, under which is Office of
Prosecutor General and Supreme Court; Council of
State
Government leaders: Manea Manescu, President
of the Council of Ministers, head of government;
Nicolae Ceausescu, President of the Socialist
Republie, head of state
Suffrage: universal over age 18, compulsory
Elections: elections in Romania held every 4 years
for the local people''s councils and every 5 years for
Grand National Assembly deputies
Political parties and leaders: Communist Party of
Romania only functioning party, Nicolae Ceausescu,
General Secretary
Voting strength (1975 election): overall participa-
tion reached 99.96%; of those registered to vote
(14,900,032), 98.8% voted for party candidates
Approved For Release 2005/04/22
Communists: 2,480,000 party members (December
1974)
Member of: CEMA, FAO, GATT, IAEA, IBRD,
ICAO, ILO, IMCO, IMF, IPU, ITU, Seabeds
Committee, U.N., UNESCO, UPU, Warsaw Pact,
WFTU, WHO, WMO','a7b6033d98ac6aa29bd3401e6ca99cfd7deb2e4a0b1d0cbc1c69bcbad9d3247a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('877f4096d11cd016bad96a78159162227dd7a99de645fa03a0f18002cdadf9ad',1976,'RW','Rwanda','government',434,'Legal name: Republic of Rwanda
Type: republic, presidential system in which
military leaders hold key offices: 1962 constitution
still in force except for Title V on the National
Assembly
Capital: Kigali
Political subdivisions: 10 prefectures, subdivided
into 142 communes
174
Lega! system: based on German and Belgian civil
law systems and customary law; constitution adopted
1962; judicial review of legislative acts in the Supreme
Court; has not accepted compulsory 1CJ jurisdiction
Branches: President, Committee for Peace and
National Unity (composed of high military
command), and 12-member cabinet
Government leader: General Juvenal Hab-
yarimana, Head of State
Suffrage: universal
Elections: last legislative election September 1969;
none allowed by present government; elections of
Communal Counsellors held November 1974
Political parties and leaders: none; all political
activity banned and elections cancelled by military
government after its July 5, 1973 coup
Communists; no Communist party; U.S.S.R. and
People''s Republic of China have diplomatic missions
in Rwanda
Member of: AFDB, EAMA, FAO, GATT, IBRD,
ICAO, IDA, ILO, IMF, IPU, ITU, OAU, OCAM,
U.N., UNESCO, UPU, WCL, WHO, WMO','7f81cb62eb027a819022004fbaf84ae84661d309a6469d649373aaf6e246f1c4','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5547da8f2e929517ce3bc95867934dff9d014baa28ef3e15330846e91a4bf4f3',1976,'AI','Anguilla','government',438,'Legal name: State of St. Christopher-Nevis-
Type: dependent territory with full internal
autonomy as a British * Associated State"; Anguilla
formally seceded in May 1967 but has not been
recognized as an independent state by any
government; in July 1968 a legislative council headed
by Ronald Webster was clected to govern Anguilla; in
March 1969 the U.K. sent troops to Anguilla, placing
the island again under colonial rule; in 1971, Anguilla
reverted to its former colonial relationship with the
U.K. although nominally remaining part of the
Associated state of St. Christopher-Nevis-Anguilla;
Webster became leader of Anguillan Council after
constitutionally held elections (1972)
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law;
constitution of 1960; highest judicial organ is Court of
Appeal of Leeward and Windward Islands
Branches: legislative, 10-member popularly elected
House of Assembly; executive, cabinet headed by
Premier
Government leaders: Premier, Robert L. Brad-
shaw; U.K. Governor, Probyn Inniss
Suffrage: universal adult suffrage
Elections: at least every 9 years; most recent 10
May 1971
Political parties and leaders: St. Christopher-
Nevis-Anguilla Labor Party, Robert L. Bradshaw;
People’s Action Movement (PAM), William Herbert;
Nevis Reformation Party (NRP), Ivor Stevens
Voting strength (May 1971 election): St.
Christopher-Nevis-Anguilla Labor Party won 7 seats
in the House of Assembly, PAM won 1, NRP won 1,
and 1 seat remains open for Anguilla which did not
participate in the election
Communists: none known
Member of: CARICOM
Legal name: State of St. Lucia
Type: dependent territory with full internal
autonomy as a British “Associated State”
Capital: Castries
Political subdivisions: 16 parishes
Legal system: based on English common law;
constitution of 1960; highest judicial body is Court of
Appeal of Leeward and Windward Islands
Branches: legislative, 17-member popularly elected
House of Assembly; executive, cabinet headed by
Premier
Government leaders: Premier John Compton;
U.K. Governor Sir Allen Lewis
Suffrage: universal adult suffrage
Elections: every 5 years; most recent May 1974
Political parties and leaders: United Worker''s
Party (UWP), John Compton; St. Lucia Labor Party
(SLP), Allan Louisy
Voting strength (1974 election); UWP (53% ) won
10 of the 17 elected seats in House of Assembly; SLP
(4596) won 7 seats; independents (2%) no seats
Communists: negligible
Member of: CARICOM
Legal name: State of St. Vincent
Approved For Release 2005/04/22
Type: dependent territory with full internal
autonomy as a British “Associated State"
Capital: Kingstown
Legal system: based on English common law;
constitution of 1960; highest judicial body is Court of
Appeal of Leeward and Windward Islands
Government leader: Premier R. Milton Cato;
Governor General (U.K.) Sir Rupert G. John
Suffrage: universal adult suffrage (18 years old and
over)
Elections: every 5 years; most recent December 9,
1974
Political parties and leaders: People’s Political
Party (PPP), Ebenezer Joshua; St. Vincent Labor
Party (LP), R. Milton Cato; Democratic Freedom
Movement, Parnell Campbell and Kenneth John
Voting strength (1975 election): LP 10 seats, PPP 2
seats, independent 1 seat in the Legislature
Communists: negligible
Member of: CARICOM','20551a500400a2be46904e4e4f19a6ffde1bee0212d92aafc0cacb07e388e996','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c41490ad300fcab846716c4a44ad98455405925e628f9fc3a3207861efd45f5',1976,'ST','Sao Tome and Principe','government',445,'Legal name: Democratic Republic of Sao Tome
and Principe
Type: republic established when independence
received from Portugal on July 1975; constitution not
yet formulated
Capital: Sao Tome
Legal system: based on Portuguese law system and
customary law; has not accepted compulsory ICJ
jurisdiction
Branches: Da Costa heads the government assisted
by a cabinet of ministers, there is a constituent
assembly composed of 18 members
Government leader: President Manuel Pinto Da
Costa
Suffrage: universal for age 18 and over
Elections: elections were held July 1975 for the
President and Constituent Assembly; future elections
will be determined by new government when
constitution is formulated
Political parties and leaders: Movement for the
Liberation of Sao Tome and Principe (MLSTP),
Secretary-General Manuel Pinto Da Costa
Communists: no Communist party, probably a few
Communist sympathizers
Member of: OAU, U.N.','d10d8637606c5cd3ec3bf984efbd985507559a65c6068ed4939a08c5d9b91e38','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ced8e4fba19dd834d3dd4e2e5ec1e33d9d48410fb9d13d1679c2c4f7f31d97ee',1976,'SA','Saudi Arabia','government',449,'Legal name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh; foreign ministry and foreign
diplomatic representatives located in Jiddah
Political subdivisions: 18 amirates
Legal system: largely based on Islamic law, several
secular codes have been introduced; commercial
disputes handled by special committees; has not
accepted compulsory 1C] jurisdiction
Branches: King Khalid (Al Saud, Khalid ibn Abd
al-Aziz) rules in consultation with royal family
(especially Crown Prince Fahd), Council of Ministers,
and religious leaders
Government leader: King Khalid
Communists: negligible
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, IMF, ITU, OAPEC, OPEC, ULN.,
UNESCO, UPU, WHO, WMO','f8bd31325113ad8ea861d8577130b791a4f47e7e698bc03424f9a702ec258d3e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67ca60e3ea576a7cb4dbfa7cf2d93fdd324622ffb7d648b61da2f702bcab0689',1976,'SC','Seychelles','government',453,'Legal name: Colony of the Seychelles
Type: British crown colony with large measure of
internal autonomy; Britain has agreed to grant
independence before late June 1976
Capital: Victoria, Mahe Island
Legal system: based on English common law,
French civil law system, and customary law
Branches: Governor, Prime Minister, Council of
Ministers, Legislative Assembly
Government leaders: Prime Minister, James
Mancham; Governor, Colin H. Allan
Suffrage: universal adult
Elections: April 1974, held every 5 years
Political parties and leaders: Seychelles Demo-
cratic Party (SDP), James R. Mancham, President;
Seychelles Peoples United Party (SPUP), France
Albert Rene, President
Voting strength: SDP won 13 seats in Legislative
Assembly with 52.4% popular vote in 1974 election;
SPUP won 2 seats with 47.6% of votes; under
agreement reached in March 1975, each party named
five new members to the legislature
Communists: negligible
Other political or pressure groups: trade unions
which are appendages of political parties
Member of: WCL','2cc02dc6c6360418c4d56ebe70b1981353db6927e5653e22d1273944595122bc','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4944780a82197e826ba506b59b5e5ed72a2dea1e9319f90db8926eaa1adae2a7',1976,'SL','Sierra Leone','government',457,'Legal name: Republic of Sierra Leone
Type: republic under presidential regime since
April 1971
Capital: Freetown
Political subdivisions: 3 provinces: divided into 12
districts with 146 chiefdoms, where paramount chief
and council of elders constitute basic unit of govern-
ment; plus western area, which comprises Freetown
and other coastal areas of the former colony
Legal system: based on English law and customary
laws indigenous to local tribes: constitution adopted
April 1971; highest court of appeal is the Sierra Leone
Court of Appeals; has not accepted compulsory ICJ
jurisdiction
Branches: executive authority exercised by
President; parliament consists of 100 authorized seats,
85 of which are filled by elected representatives of
constituencies and 12 by Paramount Chiefs elected by
fellow Paramount Chiefs in each district; President
authorized to appoint three members, of which two,
currently, are filled by the heads of the Army and the
Police independent judiciary
Government leader: Siaka Stevens, President,
heads APC government composed of members of his
political party
Suffrage: universal over age 21
Elections: the maximum life of an elected
parliament is 5 years, but it may be dissolved earlier
by the President; parliamentary election held in May
1973; President is elected by parliament for 5 year
term; next presidential election 1976
184
Political parties and leaders: All People''s Congress
(APC) headed by Stevens; Sierra Leone People''s
Party (SLPP) is the opposition party
Communists: no party, although there are a few
Communists and a slightly larger number of
sympathizers
Member of: AFDB, Commonwealth, ECA,
ECOWAS, FAO, CATT, IAEA, IBRD, ICAO, IDA,
IFC, ILO, IMF, IPU, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WHO,
WMO','0991b2e5cbc345dd86a9f65d559e650716a191bdbaacc370739ed7b161857101','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20e3d425f88ff8596e32786890ee0cdeda671c678dccd189f1a88b3c6995e511',1976,'SG','Singapore','government',461,'Legal name: Republic of Singapore
Type: republic within Commonwealth since
separation from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law;
constitution based on preindependence State of
Singapore constitution; legal education at University
of Singapore; has not accepted compulsory ICJ
jurisdiction
Branches: ceremonial President; executive power
exercised by Prime Minister and cabinet responsible to
unitary legislature
Government leaders: President, Dr. Benjamin
Sheares; Prime Minister, Lee Kuan Yew
Suffrage: universal over age 20; voting compulsory
Elections: normally every 5 years
Political parties and leaders: government —
People''s Action Party (PAP) Lee Kuan Yew;
opposition — Barisan Sosialis Party (BSP), Dr. Lee
Siew Chob; Workers Party, J.B. Jeyaretnam;
Communist Party illegal
Voting strength (1972 election): PAP won all 65
seats in parliament and received 709; of vote;
remaining 30% to four opposition parties
Communists: 200-500; Barisan Sosialis Party
infiltrated by Communists
Member of: ADB, ASEAN, Colombo Plan, GATT,
IBRD, ICAO, IFC, IHO, ILO, IMCO, IMF, IPU,
ITU, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO','60f28ad72307bf56f2f57501672d7ed70fa23bdd747a51b17a676c9dc3fb3c4c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2032800af73a99fc9b3127cfc79d774def8fbeb0fd05c3d0b433906a6ca232ba',1976,'SO','Somalia','government',465,'Legal name: Somali Democratic Republic
Type: republic; under military rule since October
1969
Capital: Mogadiscio
Political subdivisions: 12 regions, 56 districts
Organization: the junta has assumed all authority,
calling itself the Supreme Revolutionary Council,
membership of which consists of 17 army and 3 police
officers; the Council has abrogated the constitution,
dissolved the parliament, and banned political parties
Government leader: President of the Supreme
Revolutionary Council, Gen. Mohamed Siad Barre
Communists: possibly some Communist sympa-
thizers in the government hierarchy
Member of: AFDB, EAMA, FAO, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WFTU, WHO,
WMO','360dceda3366f20a5f050bc3f596bfb9e48637da3d985ce6bf64c7f5b4693ae0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c349f4c40a91bf72454ff3233d61504b6cf30402dfd1584786117281179106e',1976,'ZA','South Africa','government',469,'Legal name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape
Town; judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by
centrally appointed administrator; provincial
councils, elected by white electorate, retain limited
powers
Legal system: based on Roman-Dutch law and
English common law; constitution enacted 1961,
changing the Union of South Africa into a Republic;
possibility of judicial review of Acts of Parliament
concerning dual official languages; accepts compul-
sory ICJ jurisdiction, with reservations
Branches: President as formal chief of state; Prime
Minister as head of government; Cabinet responsible
to bicameral legislature; lower house elected directly
by white electorate; upper house indirectly elected
and appointed; judiciary maintains substantial
independence of government influence
Government leader: Prime Minister Balthazar
Johannes Vorster
Suffrage: general suffrage limited to whites over 18
(17 in Natal Province}
Elections: must be held at least every 5 years; last
elections April 1974
Political parties and leaders: National Party, B. J.
Vorster, P. W. Botha, C. Mulder, M. C. Botha,
187
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SOUTH AFRICA/SOUTH-WEST AFRICA
Jan De Klerk: United Party. Sir De Villiers Graaff;
Progressive-Reform Party, Colin Eglin, Harry
Schwarz, Helen Suzman; Herstigte Nasionale party,
Albert Hertzog; Reform Party (split from United Party
in February 1975), Harry Schwarz
Voting strength (1974 general elections):
parliamentary seats: National Party 122, United Party
41, Progressive Party 6
Communists: small Communist Party illegal since
1950; party in exile maintains headquarters in
London; Dr. Yasuf Dadoo. Moses Kotane, Joe Slovo
Other political groups: (insurgent groups in exile)
African. National Congress (ANC), Oliver Tambo;
Pan-Africanist Congress (PAC), leadership in dispute
Member of: GATT, IAEA, IBRD, ICAO, IDA,
IFC, IHO, IMF, ITU, Seabeds Committee, U.N.,
UPU, WFTU, WHO, WMO
Legal name: Territory of South-West Africa
Type: administered as part of Republic of South
Africa, under a League of Nations mandate of 1920;
U.N. formally ended South Africa’s mandate on
October 27, 1966, and status now in dispute
Capital; Windhoek
Political subdivisions: 10 tribal homelands, mostly
in northern sector, and zone open to white settlement
with administrative subdivisions similar to a province
of South Africa
Legal system: based on Roman-Dutch law and
customary law
Branches: administrator, appointec of South
African Government, has jurisdiction over zone of
white settlement with white-elected Legislative
Assembly handling some local matters; white residents
also elect representatives in South African Parliament;
tribal homelands are under South African Department
of Bantu Administration and Development with tribal
chiefs exercising limited autonomy; popularly elected
legislative councils for Ovamboland and Kavango-
land established in August 1973
Government leader: B. J. van der Walt,
Administrator
Suffrage: limited to white adults
Elections: last general election, 1974
Political parties and leaders: white parties —
National Party (NP), led in South- West Africa by A.
H. du Plessis; United National South-West Party
(UNSWP), J. P. Niehaus
Voting strength; NP (1974 election) won 5 of 6
seats in Republic legislature
Communists: no Communist Party, but some
influence by South African Communists and other
Communists on South-West African blacks outside
territory
Other political or pressure groups: nonwhite —
South-West Africa People’s Organization (SWAPO),
almost exclusively based on Ovambo tribe led by Sam
Nujoma, in exile; South-West Africa National Union
(SWANU), primarily based on Herero tribe, leaders in
exile; National Unity Democratic Organization
(NUDO), primarily based on Herero tribe led by
Clements Kapuuo; Namibian National Convention,
an alliance of non-white groups that oppose separate
development for tribal homelands
Legal name: (The) Spanish State
Type: a monarchy facing the problem of how to
liberalize the authoritarian regime of the late
Generalissimo Franco; proclaimed Juan Carlos King,
on November 22, 1975
Capital: Madrid
Political subdivisions: metropolitan Spain,
including the Canaries and Balearics, divided into 50
provinces with governors appointed by the central
government; also 5 places of sovereignty (presidios) in
Africa; [fni province ceded by Spain to Morocco in
June 1969; 2 former provinces comprising Equatorial
Guinea were granted independence in October 1968;
decolonization of Spanish Sahara began in November
1975
Legal system: civil law system, with regional
applications of customary law; 7 basic laws including
Organic Law of the State of January 1967 serve as a
constitution; legal education at 14 schools of law; does
not accept compulsory ICJ jurisdiction
Branches: executive, with King''s acts subject to
counter-signature, Prime Minister likely to dominate
all branches of government through his position as
chief of government; legislative with unicameral
Cortes dominated by executive; judicial, independent
in principle but generally limited to interpretation of
laws
Government leaders: King Juan Carlos I — Chief
of State, Commander in Chief of the armed forces,
and titular head of the National Movement (formerly
called the Falange) Carlos Arias Navarro, Prime
Minister
Suffrage: universal in national referendums, over
age 21
Elections: only two types of direct election other
than referendum provided: representatives to
municipal councils for which only heads of
households vote (latest election November 1978) and,
under new constitutional law of 1967, 104 members of
the Cortes elected by heads of households and married
women for a 4-year term (last election September
1971; September 1975 election postponed until March
1976)
Political parties and leaders: National Movement
only legally recognized party; Prime Minister exercises
leadership assisted by Adolfo Suarez Gonzalez,
headed by Franco, minister-secretary general;
political associations authorized in January 1975;
various semiclandestine opposition groups include —
Christian Democratic factions under Jose Maria Cil
Robles and Joaquin Ruiz Gimenez; the Socialists
include the Spanish Socialist Workers Party (PSOE),
led by “Young Turk" Felipe Gonzalez, the Popular
Socialist Party under Enrique Tierno Galvan, and the
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','2f730e24e8064099983ec943f1cbe2f55bc1f05a148d2989859da7165cbcdc65','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb2f27f95b1fff33b82ff9c265cbd1e65f8ddb6f310b01d2d40ae4672f2b0ef8',1976,'ES','Spain','government',471,'small new Spanish Social Democratic Union; the
Anarchists; Republicans; Monarchists; smaller
regional and national splinter groups; the Spanish
Communist Party, whose secretary general, Santiago
Carrillo Solares, is in exile, as well as a small dissident
pro-Soviet faction led by exiled Enrique Lister Forjan;
and some small radical Communist groups which
appear and disappear under varying names; most of
the opposition groups have joined one of two loosely-
knit coalitions — the Communist-dominated
Democratic Junta, formed in the summer of 1974, and
the Socialist-Christian Democratic Platform of
Democratic convergence, established in the summer
of 1975
Voting strength: 561 scats, but somewhat fewer
members as some hold more than one seat — 19%
representing the family elected directly; 45%
representing municipalities, syndicates, and profes-
sions clected indirectly under close regime control,
and 36% are appointed by regime or are ex officio
Communists: (est.) 5,000 inside Spain, 12,000
outside Spain; sympathizers in Spain, up to 20,000
Other political or pressure groups: on the extreme
left, the illegal Basque Fatherland and Liberty (ETA)
and the Anti-Fascist and Patriotic Revolutionary
Front (FRAP) use terrorism to oppose the government;
on the extreme right, the guerrillas of Christ the King
carry out vigilante attacks on ETA members (on
oceasion following them into France), and other
leftists the state-controlled organization of syndicates,
comprising representatives of management and labor,
an illegal labor group called the Workers’
Commissions, the Catholic Church, business and land
owning interests, Opus Dei, Catholic Action,
university students
Member of: ESRO, FAO, GATT, IAEA, IBRD,
ICAO, IDA, IEA, IFC, IHO, ILO, IMCO, IMF, IPU,
ITU, OAS (observer), OECD, Seabeds Committee,
U.N., UNESCO, UPU, WCL, WHO, WMO
Legal name: Province of Sahara
Type: province of Spain
Capital: El Aaiun
Spain is withdrawing from the territory (decoloniz-
ing) and is expected to complete the process by
192
February 28, 1976. An agreement signed on
November 14, 1975 with Morocco and Mauritania in
Madrid created a provisional administration to govern
the territory until Spain withdraws completely.
As co-administrators, Morocco and Mauritania—
inter alia—are expected to partition the territory
between them. Several Saharan independence groups,
most notably the Algerian-backed POLISARIO Front,
oppose partition and are waging military and
propaganda campaigns in an effort to prevent
annexation.','e3a002fefa35275d58ebecd06e4dfd5447d49775a191766fb3b699b698c2129e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55341976ec14add3daffb4a6fb5b38fff57809c9e9cdf3b6e0ddb841d0967163',1976,'LK','Sri Lanka','government',477,'Legal name: Republic of Sri Lanka
Hindu, 9%
Type: independent state since 1948
Capital: Colombo
Political subdivisions: 9 provinces, 22 administra-
tive districts, and four categories of semiautonomous
elected local governments
Legal system: a highly complex mixture of English
common law, Roman-Dutch, Muslim and customary
law; new constitution 22 May 1972; no judicial
review of legislative acts; legal education at Sri Lanka
Law College and University of Sri Lanka, Peradeniya;
has not accepted compulsory ICJ jurisdiction
Branches: unitary parliamentary form of govern-
ment; unicameral legislature and independent
judiciary
Government leader: Prime Minister Sirimavo
Bandaranaike
Suffrage: universal over age 18, but most Indian
Tamils, who comprise 10.6% of population, are not
enfranchised f
Elections: national elections, ordinarily held every
6 years; must be held more frequently if government
loses confidence vote; last election held May 1970,
but new constitution postpones deadline for next
election until May 1977
Political parties and leaders: Sri Lanka Freedom
Party, Sirimavo Ratwatte Dias Bandaranaike,
President; Lanka Sama Samaja Party (Trotskyite), N.
M. Perera, President; Tamil United Front, $. J. V.
Chelvanayakam, leader; United National Party, J. R.
Jayewardene; Communist Party/ Moscow, Pieter
Keuneman, General Secretary; Communist Party/
Peking, N. Shanmugathasan, General Secretary;
Mahajana Eksath Peramuna (People''s United Front),
M. B. Ratnayaka, President
Voting strength (1970 election): 37% Sri Lanka
Freedom Party, 3896 United National Party, 996
Lanka Sama Samaja Party, 3.596 Communist
Party/Moscow, 596 Federal Party, minor parties and
independents accounted for remainder
Communists: approximately 169,000 voted for the
Communist Party in the May 1970 general election;
Communist Party/Moscow approximately 5,000
members (1975), Communist Party/Peking 1,000
members (1970 est.)
Other political or pressure groups: Buddhist
clergy, Sinhalese Buddhist lay groups; far-left violent
revolutionary groups; labor unions
Member of: ADB, Colombo Plan, Commonwealth,
FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO,
IMF, IPU, Seabeds Committee, U.N., UNESCO,
UPU, WCL, WHO, WMO','f88d635a55daf5c10844a896568ad6bad8d59ab770cc60a01943c6fe41d19ad1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e9d3cad84414e118e767c47a7af54c05cf48c36d1355837eedacb786cb2dfef',1976,'SD','Sudan','government',481,'Legal name: Democratic Republic of the Sudan
Type: republic under military control since coup in
May 1969
Capital; Khartoum
Political subdivisions: 15 provinces, provincial and
local administrations controlled by central govern-
ment; limited regional autonomy in 3 southern
provinces
Legal system: based on English common law and
Islamic law; some separate religious courts;
permanent constitution promulgated April 1973;
Revolutionary Command Council established in 1969
dissolved in October 1971 with the installation
stallation of Ja''far al-Numayri as president and chief
executive; Numayri has reorganized government
through a series of Republican decrees; legal
education at University of Khartoum and Khartoum
extension of Cairo University at Khartoum; accepts
compulsory ICJ jurisdiction, with reservations
Government leader: President and Prime Minister
Ja far al-Numayri
Suffrage: universal adult
94
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
iin April
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SUDAN/SURINAM
Elections: most recent parliamentary elections held
1968; presidential plebiscite held in
September 1971; elections to constituent. assembly
held in September-October 1972; elections for
southern regional assembly held in November 1973;
elections for People''s Assembly held May 1974
Political parties and leaders: all parliamentary
political parties outlawed since May 1969; the ban on
the Sudan Communist Party was not enforced until
after abortive coup in July 1971; the government s
mass political organization, the Sudan Socialist
Union, was formed in January 1972
Communists: party decimated following July 1971
coup and counter-coup, several top leaders including
Secretary-General Mahjub executed; actual hard-core
membership down to lowest point in years; party
control] over labor unions, professional groups and
university student groups ended; Communists purged
from government; party is being reorganized
underground under leadership of Secretary-General
Muhammad Nujud, 3,500 CP members
Other political or pressure groups: Muslim
Brotherhood; Ansar Muslim sect, at odds with the
military regime since the May coup, defeated in
fighting in spring 1970; Sudan Opposition Front,
composed of former political party elements and other
disgruntled conservative interests, operates in exile
Member of: AFDB, Arab League, FAO, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UNESCO, UPU, WFTU,
WHO, WMO
Legal name: Surinam
Type: Parliamentary Democracy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by
district commissioner responsible to Minister of
Internal Affairs
Legal system: Dutch civil law System; Constitution
adopted November 1975
Branches: Council of Ministers headed by a
Prime Minister constitutes the Cabinet; 39-member
legislative council (Staten) popularly elected for 4-
year term; court system administered by Attorney-
General under Minister of Justice and Police
Government leader: Prime Minister, Hendrick A.
F. Arron
Suffrage: universal over age 23
Elections: every 4 years or earlier upon request of
Prime Minister; latest held November 1973 won by
National Party Combination (NPK), a creole-based
election coalition in which the National Party of
Surinam (NPS) is the largest party; new elections will
probably be held in 1976
Political parties and leaders: National Party of
Surinam (NPS), Hendrick A. E. Arron; Nationalist
Republic Party (PNR), Edward Bruma (principal
leftist party); United Hindustani Party (VHP), J.
Lachmon; Progressive National Party (PNP , Frank E.
Essed; Surinam Democratic Party (SDP), B. F. J.
Oostburg; United Indonesian People''s Party (SRI), F.
Karsowidijojo; Javanese Farmers’ Party (KTPI), H. I.
Soemita; United People''s Party (VVP), led by
apolitical or Chinese businessmen
noun—Surinamer(s); adjective —
196
Approved For Release 2005/04/22
Voting strength (1973): NPK 22 seats, VHP 17; the
NPK had a one vote margin as of early November
1975 following defection from both coastlines
Communists: no overt Communist Party; PNP has
some Communist sympathizers
Member of: EC (associate), UPU, WCI,
Legal name: Kingdom of Swaziland
Type: monarchy, under King Sobhuza Il;
independent member of Commonwealth since
September 1968
Capital: Mbabane (administrative), Lobamba
(royal and legislative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-
Dutch law in statutory courts, Swazi traditional law
and custom in traditional courts; legal education at
University of Botswana, Lesotho, and Swaziland
(located in Lesotho), has not accepted compulsory
IC] jurisdiction
Branches: in April 1973 King abolished the
constitution, dismissed parliament, and assumed
personal rule; he intends ruling under a King-in-
Council arrangement with the cabinet being retained
as an advisory council; former members of parliament
continue to receive their salaries and new constitution
probably will be drawn up later
Government leader: Head of State and govern-
ment King Sobhuza II; Prime Minister Makhosini
Dlamini
Suffrage: universal for adults
Elections: first elections for Legislative Council
held in June 1964; latest for House of Assembly in
May 1972
Political parties and leaders: Imbokodvo, the
traditionalist party, controlled by King Sobhuza II;
the opposition Ngwane National Liberatory Congress
(NNLC) led by Dr. Ambrose Zwane, has been
dissolved
Voting strength: in 1972 elections, Imbokodvo won
21 seats, NNLC won 3 seats in the House of Assembly
Communists: no Communist Party
Member of: AFDB, FAO, GATT (de facto), IBRD,
ICAO, IDA, IFC, IMF, ITU, OAU, Seabeds
Committee, U.N., UPU','10b955aafa751330234d35c095cc1a3e8706ce8c24c03597112074ec60aeb567','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dc323ce9923875525be50138fb39f8a5a0afe4e709d6ecf037112567f0f30fb',1976,'SE','Sweden','government',485,'Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces, 624 com-
munes, 224 towns
Legal system: civil law system influenced by
customary law; Acts of 1809, 1810, 1866, and 1949
serve as constitution; legal education at Universities of
Lund, Stockholm, and Uppsala; accepts compulsory
IC] jurisdiction, with reservations
Branches: legislative authority rests with parlia-
ment (Riksdag); executive power vested in cabinet,
responsible to parliament; Supreme Court, 6 superior
courts, 108 lower courts
Government leaders: King Carl XVI Gustaf; Prime
Minister Olof Palme
Suffrage: universal. but not compulsory, over age
20
Elections: every 3 years (next in September 1976)
Political parties and leaders: Moderate Coalition
(conservative), Gosta Bohman; Center, Thorbjorn
Falldin; Liberal, Gunnar Helen; Social Democratic,
Olof Palme; Communist, Carl-Henrik Hermansson;
Communist League of Marxists- Leninists (KFML),
Cunnar Bylin
Voting strength (1973 election): 13.9% Moderate
Coalition, 25.1% Center, 9.4% Liberal, 43.6% Social
Democratic, 5.3% Communist, 2.7% other
Communists: 17,000; a number of sympathizers as
indicated by the 274,929 Communist votes cast in
1973 elections; an additional 8,014 votes cast for
Maoist KFML
Member of: ADB, Council of Europe, DAC, EC
(Free Trade Agreement), EFTA, ESRO, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFA, IFC, IHO, ILO,
IMCO, IMF, IPU, ITU, Nordic Council, OECD,
Seabeds Committee, U.N., UNESCO, UPU, WHO,
WMO','3d4cef651c5f9f9bfa22e20898ce00eaa4d54b9ec2bd1a320e32c8b41eab63b3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18bf156920a936ff3421667597c28a9f418423fbb9f9d607a75dffc84a026df7',1976,'CH','Switzerland','government',488,'Legal name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 22 cantons (3 divided into
half cantons); a local referendum held in Bern Canton
in 1975 indicated that three districts wished to form a
separate canton for a portion of the French-speaking
Jura region
Legal system: civil law system influenced by
since; judicial review of legislative acts, except with
respect to Federal decrees of general obligatory
character; legal education at Universities of Bern,
Geneva and Lausanne, and four other univer
schools of law; accepts compulsory ICJ jurisdict
with reservations
Branches: bicameral parliament has legislative
authority; federal council (Bundesrat) has executive
authority; justice left chiefly to cantons
Government leader: Pierre Graber (l-year term as
President began on January 1975), President
Suffrage: universal over age 20
Elections: held every 4 years; next elections 1979
Political parties and leaders: Social Democratic
Party (SPS), Arthar Schmid, president; Radical
Democratic Party (FDP), Henri Schmitt, president;
Christian Conservative People''s Party (CVP), Franz
Josef Kurmann, president; Farmer, Artisan,
Burghers Party (BGB), Hans Conzett,
Communist Party (PdA), Jean Vincent, leading
Secretariat member; National Action Party (N.A.),
James Schwarzenbach
Voting strength (1975 election): 22.2% FDP,
20.6% CVP, 25.4% SPS, 10.2% BGB, 2.2% PdA, 2.5%
N.A., 3.0% Rep, 6.2% LdU, 2.3% Lidus, 2.0% EvP,
1.3% POSH, 2.25; other
Communists: [ess than two million votes in 1975
election
Other parties: Landesring (LdU); Republican
Movement (Rep); Libera] Democratic Uni
Evangelical Party (EvP); Maoist Party (P
200
lane — —M E
January 1976
Member of; ADB, Council of Europe, DAC,
EFTA, ELDO (observer), ESRO, FAO, GATT, IAEA,
ICAO, IEA, ILO, IMCO, IPU, ITU, OECD, Seabeds
Committee, U.N. (permanent observer), UNESCO,
UPU, WCL, WHO, WMO
Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime
since March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of
Damascus administered as separate unit
Legal system: based on Islamic law and civil law
system; special religious courts; constitution
promulgated in 1973; legal education at Damascus
University and University of Aleppo; has not accepted
compulsory IC] jurisdiction
Branches: executive powers vested in President and
Council of Ministers; legislative power rests in the
People''s Assembly (election pending); seat of power is
the Ba''th Party Regional (Syrian) Command
Government leaders: President Hafiz Al-Asad
Suffrage: universal at age 18
Elections: no electoral laws being drafted; last
elections in December 1961; presidential referendum
in 1971; local councils elected in March 1972,
assembly elections pending
Political parties and leaders: ruling party is the
Arab Socialist Resurrectionist (Ba''th) party; a
"national front" cabinet formed in March 1972,
dominated by Ba''thists, includes independents and
members of the Syrian Arab Socialist Party (ASP),
Arab Socialist Union (ASU), and Syrian Communist
Party (SCP)
Communists: mostly sympathizers, numbering
10,000 to 13,000
Other political or pressure groups: non-Ba''th
parties have little effective political influence;
Communist Party ineffective; greatest threat to
Ba''thist regime lies in factionalism in Ba''th Party
itself; conservative religious leaders
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
OAPEC, Seabeds Committee, U.N., UNESCO, UPU,
WFTU, WHO, WMO
Legal name: United Republic of Tanzania
Type: republic; single parties dominate both on the
mainland and on Zanzibar
Capital: Dar es Salaam
Political subdivisions: 25 regions—20 on main-
land, 5 on Zanzibar islands
Legal system: based on English common law,
Islamic law, customary law, and German civil law
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
a
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TANZANIA
system; interim constitution adopted 1965; judicial
review of legislative acts limited to matters of
interpretation; legal education at University of Dar es
Salaam; has not accepted compulsory ICJ jurisdiction
Branches: President Julius Nyerere has full
executive authority on the mainland; National
Assembly dominated by Nyerere and the Tanganyika
African National Union (TANU); newly restructured
National Assembly consists of 218 members, including
57 appointed from Zanzibar, 65 appointed from the
mainland, plus 96 directly elected from the mainland;
First Vice President Aboud Jumbe and the
Revolutionary Council still run Zanzibar despite the
efforts of Nyerere to integrate the islands into the
political system of the mainland
Government leader: President Julius Nyerere
Suffrage: universal adult
Political party and leaders: Tanganyika African
National Union (TANU), only mainland political
party, dominated by Nyerere with Prime Minister and
Second Vice President Rashidi Kawawa as his top
lieutenant; Afro-Shirazi Party, the only party in
Zanzibar
Voting strength (October 1975 national elec-
tions): over 5 million registered voters, Nyerere
received 95% of about 4 million votes cast; general
parliamentary elections scheduled for Fall of 1980
Communists: a few Communist sympathizers,
especially on Zanzibar
Member of: AFDB, Commonwealth, EAC, FAO,
GATT, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU,
OAU, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO','3bf084cc11b1e7bad4da1ce4df7061be89b9ff3faf741533d6cea035021974f4','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66dbff6d50e86e18bc00e9b1e1205c30647d0d25cfdd213046d09e26ae6aea44',1976,'TG','Togo','government',495,'Legal name: Togolese Republic
Type: republic; under military rule since January
1967
Capital: Lome
Political subdivisions: 21 circumscriptions
Legal system: based on French civil law and
customary practice; no constitution; has not accepted
compulsory IC] jurisdiction
Branches: military government, with civilian-
dominated cabinet, took over on 14 April 1967,
replacing provisional government created after
January coup; no legislature; separate judiciary
including State Security Court established 1970
Government leader: Maj. General Gnassingbe
Eyadema, President
Suffrage: universal adult
Elections: presidential referendum of January 1972
elected Cen. Eyadema for indefinite perio
Political parties: single party formed by President
Eyadema in September 1969, Rassemblement. du
Peuple Togolais, structure and staffing of party closely
controlled by government
Communists: no Communist Party; possibly some
sympathizers
Member of: AFDB, CEAO (observer), EAMA,
ECA, ECOWAS, ENTENTE, FAO, GATT, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, OAU, OCAM,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WHO, WMO','77f9ea2d08d59cb7c1a94784a39f63ba2c8c9884a8048c4c3390bf3f6a10acff','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5f6bff2df7d6ffcdb720b4470dc0f309e0e32e7c1281d8a37214a113394fb83',1976,'TO','Tonga','government',499,'Legal name; Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa
Political subdivisions: 3 main island groups
(Tongatapu, Haapi, Vavau)
Legal system: based on English law
Branches; Executive (King and Privy Council):
Legislative (Legislative Assembly composed of 7
nobles elected by their peers, 7 elected representatives
of the People, 7 Ministers of the Crown; the King
appoints one of the 7 nobles to be the speaker);
Judiciary (Supreme Court, magistrate courts, Land
Court)
Government leaders: King Taufa''ahau Tupou IV;
Premier, Prince Tu''ipelehake (younger brother of the
King)
Suffrage: granted to all literate adults over 21 years
of age who pay taxes
Elections: held perennially
Communists: none known
Member of; ADB, Commonwealth
800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TONGA/TRINIDAD AND TOBAGO','22be515d828faba25618b607a32c24503e2bce052743d7b3c6f5e346242cb949','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b84483faa4cb791319ea9f96722dd32e23c5ad7889c76906842190893de85ca3',1976,'TT','Trinidad and Tobago','government',503,'Legal name: Trinidad and Tobago
Type: independent state since August 1962;
recognizes Elizabeth II as chief of state
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards,
Tobago is 30th)
Legal system: based on English common law;
constitution came into effect 1962; judicial review of
legislative acts in the Supreme Court; has not
accepted compulsory IC] jurisdiction
Branches: legislative branch consists of 36-member
elected House of Representatives and 24-member
Senate (13 nominated by Prime Minister, 4 by
opposition leader, 7 at discretion of Governor
General); executive is cabinet led by the Prime
Minister; judiciary is headed by the Chief Justice and
includes a Court of Appeal, High Court, and lower
courts; criminal cases may be appealed to the Queen''s
Privy Council in London as a court of last resort
Government leader: Prime Minister, Dr. Eric
Williams
Suffrage: universal over age 21
Elections: last election 24 May 1971, PNM won all
seats
Political parties and leaders: People''s National
Movement (PNM), Dr. Eric Williams; Democratic
Labor Party (DLP), Vernon Jamadar; United
Democratic Labor Party (UDLP), Alloy Lequay;
United National Independence Party, (UNIP) James
Millette; Democratic Action Congress (DAC), Arthur
Napoleon Raymond Robinson; West Indian National
Party (WINP), Ashford Sinanani; Tapia House
Group, Lloyd Best
Tobagon-
207
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TRINIDAD AND TOBAGO/TUNISIA
Voting strength (1971 election): 32.9% of
registered voters cast ballots, 83.79; PNM, 16.3%
other
Communists: not significant
Other political pressure groups: National Youth
Congress (NYC); Oilfield Workers Trade Union
(OWTU); National Joint Action Committee (NJAC),
antigovernment, ex-tremist organization; United
Revolutionary Organization. (URO), Marxist-led
amalgam; United Labour Front (ULF), loose
coalition of oilfield and sugar workers
Member of: CARICOM, Commonwealth, FAO,
GATT, IADB, IBRD, ICAO, IDA, IDB, IFC, ILO,
IMCO, IMF, International Coffee Agreement, ITU,
OAS, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO','513e845e3d2c8f83b70dbefeb7416c8f3b3040bb5a315565cf5d5ae43cafd4f5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ba292dd76cc1de03020e0b5d4c5db8f3f481557b63082c5b8079249d1c3f2c0',1976,'TN','Tunisia','government',507,'Legal name: Republic of Tunisia
Type: republic
Capital; Tunis
Political subdivisions: 17 governorates (provinces)
Legal system: based on French civil law system
and Islamic law; constitution patterned on Turkish
and U.S. constitutions adopted 1959; some judicial
review of legislative acts in the Supreme Court in joint
session; legal education at Institute of Higher Studies
and Ecole Superieure de Droit of the University of
Tunis; has not accepted compulsory IC] jurisdiction
Branches: executive dominant; unicameral
legislative largely advisory; judicial, patterned on
French system and Koranic law
Government leader: President Habib Bourguiba;
Prime Minister Hedi Nouira
Suffrage: universal over age 21
Elections: national elections held every 5 years; last
elections 2 November 1974
Political party and leader: Destourian Socialist
Party, Habib Bourguiba
Voting strength (1974 election): 100% Destourian
Socialist Party
Communists: 100 est.; a few sympathizers,
Tunisian Communist Party proscribed in 1962
Member of: AFDB, Arab League, EC (association
until 1974), FAO, IAEA, IBRD, ICAO, IDA, IFC,
ILO, IMCO, IMF, ITU, OAU, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental
legal systems, with remnants of Islamic law;
constitution adopted 1961; judicial review of
legislative acts by Constitutional Court; legal
education at Universities of Ankara and Istanbul;
accepts compulsory ICJ jurisdiction, with reservations
Branches: President elected by parliament; Prime
Minister appointed by President from members of
parliament; Prime Minister is effective executive;
cabinet, selected by Prime Minister and approved by
President, must command majority support in lower
house; parliament bicameral under constitution
promulgated in 1961; National Assembly has 450
members serving 4 years; Senate has 150 elected
members, one-third elected every 2 years, 15
appointed by the President to 6-year terms (one-third
appointed every 2 vears), and 18 life members; highest
court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal,
commercial, basic, and peace courts
Government leaders: President Fahri Koruturk;
Prime Minister Suleyman Demirel heads four-party
coalition government
Suffrage: universal over age 21
210
Elections: National Assembly and Senate (1/3 of
seats) Republican People''s Party won a plurality
October 1973; Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People''s Party (RPP),
Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Republican Reliance Party (RRP), Turhan Feyzioglu;
National Action Party (NAP), Alpaslan Turkes;
Nation Party (NP); Unity Party (UP), Mustafa Timisi;
Communist Party illegal; National Salvation Party
(NSP), Necmettin Erbakan
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government in March 1971
and remains an influential force in government
Member of: CENTO, Council of Europe, EC
(associate member), ECOSOC, FAO, GATT, IAEA.
IBRD, ICAO, IDA, IEA, IFC, IHO, ILO, IMCO,
IMF, IPU, ITU, NATO, OECD, Regional Coopera-
tion for Development, Seabeds Committee, U.N..
UNESCO, UPU, WHO, WMO','c645675adb368a162ee2c754ba22a8e28572af50717d45b21f763e81859a5141','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32ba376f15b40c81ac5ec9b0b32f53fe790b63d40d02792122ffb119bfc8ee17',1976,'UG','Uganda','government',511,'Legal name: Republic of Uganda
Type: republic independent since October 1962
Capital: Kampala
Political subdivisions: 10 provinces and 34 districts
Legal system: based on English common law and
customary law; constitution adopted 1967; present
government rules despotically, has intimidated
judicial officials and has made constitution of no
consequence; legal education at Makerere University,
Kampala; accepts compulsory IC] jurisdiction, with
reservations
Branches: Field Marshall Amin rules by decree;
assisted by Council of Ministers and Defense Council,
a group of military officers
Government leader: Field Marshall Idi Amin,
President
Suffrage: universal adult
Elections: none scheduled by military government
Political parties: none
Communists: possibly a few sympathizers
Member of: AFDB, Commonwealth, EAC, FAO,
GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF,
ITU, OAU, Seabeds Committee, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, 20
autonomous republics, 6 krays, 120 oblasts, and 8
autonomous oblasts
Legal system: civil law system as modified by
Communist legal theory; constitution adopted 1936;
no judicial review of legislative acts: legal education
at 18 universities and 4 law institutes; has not
accepted compulsory ICJ jurisdiction
Branches: Council of Ministers (executive),
Supreme Soviet (legislative), Supreme Court of
U.S.S.R. (judicial)
Government leaders: Leonid 1. Brezhnev, General
Secretary of the Central Committee of the Communist
Party; Aleksey N. Kosygin, Chairman of the Council
of Ministers; Nikolay V. Podgornyy, Chairman of the
Presidium of the U.S.S.R. Supreme Soviet
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every 4 years; 1,517
deputies elected in 1974; 72.2% party members
Political parties and leaders: Communist Party of
the Soviet Union (CPSU) only party permitted
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
acm mma iR
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
U.S.S.R./ UNITED ARAB EMIRATES
Voting strength (1970 election):
persons over 18; claimed 99.96% voted
Communists: 15,000,000 party members
Other political or pressure groups: Komsomol,
trade unions, and other organizations which facilitate
Communist control
Member of: CEMA, Geneva Disarmament
Conference, IAEA, ICAO, ILO, IMCO, IPU, ITU,
Seabeds Committee, U.N., UNESCO, UPU, Warsaw
Pact, WFTU, WHO, WMO, Universal Copyright
Convention','97ac02e94a6541d07052b739644cd431323291e06142700f7bfd807582088210','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae2c0438c134b8c1d9aae93b21e610ec46e42b68d2b2383ca69808afc3fba54d',1976,'AE','United Arab Emirates','government',514,'Legal name: United Arab Emirates (composed of
former Trucial States)
213
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
UNITED ARAB EMIRATES/UNITED KINGDOM
Member states: Abu Dhabi; Ajman; Dubai;
Fujairah; Ras al Khaimah; Sharjah: Umm al Qaiwain
Type: federation; constitution signed December
1971, which delegated specified powers to the United
Arab Emirates central government and reserved other
powers to member sheikhdoms
Capital; Abu Dhabi
Legal system: secular codes are being introduced
by the U.A.E. government and in several member
sheikhdoms; Islamic law remains very influential
Branches: Supreme Council of Rulers (7 members),
from which a President and Vice President are elected;
Prime Minister and Council of Ministers; National
Consultative Council; federal Supreme Court
Government leaders: Sheikh Zayid of Abu Dhabi,
President; Sheikh Rashid of Dubai, Vice President;
Sheikh Maktum of Dubai, Prime Minister
Suffrage: nonc
Elections: none
Political or pressure groups: none; a few small
clandestine groups are active
Member of: Arab League, IBRD, ICAO, ILO,
IMF, OAPEC, OPEC, Seabeds Committee, U.N.,
UNESCO, UPU, WHO','b247727b4a4b45fc96b3aa445cebc369c1c9c181f9314f094ab2b1b9b68c0633','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65b5c58c32188e69a029ef7cfad3ae5767cd48133e9c161c92dc16126addc1cb',1976,'GB','United Kingdom','government',519,'Legal name: Republic of Upper Volta
Type: republic; military regime in power since
January 1966
Capital: Ouagadougou
Political subdivisions: 10 departments, composed
of 44 cercles, headed by military prefects
Legal system: based on French civil law system
and customary law; constitution adopted 1970,
suspended February 1974; judicial review of
legislative acts in Supreme Court; has not accepted
compulsory IC] jurisdiction
Branches: President is an army officer; 57-man
National Assembly was elected in December 1970,
suspended February 1974
Government leader: Gen. Sangoule Lamizana,
President and Prime Minister
Suffrage: universal for adults
Elections: al] political activity has been banned
Political parties and leaders; political parties
banned February 1974
Communists; no Communist Party; some sympa-
thizers
Other political or pressure groups; labor
organizations are badly Splintered, student and
teachers occasionally strike
Member of; AFDB, CEAO, EAMA, ECA, EIB
(associate), Entente, FAO, IBRD, ICAO, IDA, ILO,
IMF, IPu, ITU, Niger River Commission, OAU,
OCAM, UN. UNESCO, UPU, WCL, WHO, WMO','c48339a0daea39df3f7e15ff3fa76d0513ba0e975b097685bbd5e40d22d29e1f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e618a057a4df6554a11810a5222129a318050a11bf0053be5e2b19a14e056693',1976,'UY','Uruguay','government',522,'Legal name: Oriental Republic of Uruguay
Type: republic, government under strong military
influence
Capital: Montevideo
Political subdivisions: 19 departments with limited
autonomy
Legal system: based on Spanish civil law system;
new constitution implemented 1967; judicial review
of legislative acts in Supreme Court, legal education
at University of the Republic at Montevideo; accepts
compulsory ICJ jurisdiction
Branches: exccutive, headed by President; since
1973 the military has had considerable influence
in policymaking; bicameral legislature (closed
indefinitely by presidential decree in June 1973),
Council of State set up to act as legislature; national
judiciary headed by Supreme Court
Government leader: President Juan Maria
Bordaberry
Suffrage: universal over age 18
Elections: every 5 years
Political parties and leaders: political activities are
proscribed
Voting strength (1971 elections): 40.8% Colorado,
40.1% Blanco, 18.6% Frente Amplio, 0.5% Radical
Christian Union
Communists: 35,000-40,000 including Communist
youth group and sympathizers
Other political or pressure groups: Communist
Party (PCU), Rodney Arismendi (in exile in the
U.S.S.R.); Christian Democratic Party (PDC);
217
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
URUGUAY/VATICAN CITY
Socialist Party of Uruguay (PSU); Revolutionary
Movement of Uruguay (MRO) pro-Cuban Commun-
ist Party; National Liberation Movement (MLN-
‘Tupamaros) Marxist revolutionary terrorist group
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDB, IFC, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N., UNESCO, UPU,
WCL, WFTU, WHO, WMO
Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
x Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
a — —
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
VATICAN CITY/ VENEZUELA
Capital: Vatican City
Political subdivisions: Vatican City includes St.
Peters, the Vatican Palace and Museum and
neighboring buildings covering more than 13 acres; 13
buildings in Rome, although outside the boundaries,
enjoy extraterritorial rights
Legal system: Canon law; constitutional laws of
1929 serve some of the functions of a constitution
Branches: the Pope possesses full executive,
legislative, and judicial powers; he delegates these
powers to the governor of Vatican City, who is subject
to pontifical appointment and recall; high Vatican
offices include the Secretariat of State, the College of
Cardinals (chief papal advisers), the Roman Curia
(which carries on the central administration of the
Roman Catholic Church) the Presidence of the
Prefecture for the Economy, and the synod of bishops
(created in 1965)
Government leader: Supreme Pontiff, Paul VI,
(Giovanni Battista Montini, born 26 September 1897,
elected Pope 21 June 1963)
Suffrage: limited to cardinals less than 80 in age
Elections: Supreme Pontiff elected for life by
College of Cardinals
Communists: none known
Other political or pressure groups: none (exclusive
of influence exercised by other church officers in
universal Roman Catholic Church)
Member: IAEA, Seabeds Committee
Legal name: Republic of Venezuela
Type: republic
Capital: Caracas
219
-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001
January 1976
VENEZUELA/VIE TNAM, NORTH
Political subdivisions: 20 states, 1 federal district, 2
federal territories
Legal system: based on Spanish civil law system
with influence of U.S. law; constitution promulgated
1961; judicial review of legislative acts in Cassation
Court only; dual court system, state and federal; legal
education at Central University of Venezuela; has not
accepted compulsory IC] jurisdiction
Branches: executive (President), bicameral
legislature, judiciary
Government leader: President Carlos Andres Perez
Suffrage: universal and compulsory over age 18
Elections: every 5 years; last held 9 December 1973
Political parties and leaders; Accion Democratica
(AD), Carlos Andres Perez, and Gonzalo Barrios;
Social Christian Party (COPEI), Rafael Caldera;
People’s Electoral Movement (MEP), Jesus Angel Paz
Galarraga; Union Republicana Democratica (URD),
Jovito Villalba; Partido Comunista de Venezuela
(PCV), Secretary-General Jesus Faria; Movement to
Socialism (MAS), Teodoro Petkoff, and Pompey
Marquez
Voting strength (1973 election): 49% AD, 37%
COPEI, 5% New Force (MEP & PCV), 4% MAS, 3%
URD, 2% others
Communists: 6,000 members (est.)
Other political or pressure groups: APEL (a
conservative business group); PRO VENEZUELA
(leftist, nationalist economic group); DESARROL-
LISTAS (group of wealthy, independent businessmen
led by former finance minister Pedro Tinoco and
historian Guillermo Moron)
Member of: Andean Pact, FAO, IADB, IAEA,
IBRD, ICAO, IDB, IFC, IHO, ILO, IMF, IPU, ITU,
LAFTA, OAS, OPEC, Seabeds Committee, U.N.,
UNESCO, UPU, WCL, WFTU, WHO, WMO
Legal name: Democratic Republic of Viet-Nam
Confucianism, Buddhism, Taoism,
Type: Communist state
Capital: Hanoi
Political subdivisions: 2 autonomous regions (of 3
and 5 provinces, respectively), 17 other provinces, 2
centrally governed municipalities, 1 special zone
Legal system: based on Communist legal theory
and French civil law system; constitution enacted
1960
Branches: constitution provides for a National
Assembly and highly centralized executive nominally
subordinate to it
Party and government leaders: Ton Duc Thang,
President of DRV; Le Duan, First Secretary; Truong
Chinh, Chairman, Standing Committee of National
Assembly; Pham Van Dong, Premier; Vo Nguyen
Giap, Minister of National Defense
Suffrage: over age 18
Elections: pro forma elections held for national and
local assemblies
Approved For Release 2005/04/22
ruled by Lao Dong Party
(Communist) with membership of approximately
900,000; minor subordinate parties
Political parties:
Member of: no international bodies','bafe4d357c8cf699d1bdb511da0dad7a553eccb0f22b967a6865e2633b97c094','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f9ff68dc0fdc74078c9bc87281889b3cfe44e156d5216f7fb54e4369f6a7297',1976,'TH','Thailand','government',524,'With the end of the war, South Vietnam in effect
has become reunified with the North. For the
foreseeable future, however, a separate, ostensibly
independent administration will be maintained in
the South. Policy decisions however are made in
Hanoi by the Vietnam Workers Party—the
Communist Party—and transmitted to its southern
branch—the People’s Revolutionary Party. Quasi-
military /political people’s revolutionary commit-
tees are overseeing basic administrative tasks in the
countryside while the Provisional Revolutionary
229
Approved For Release 2005/04/22
Government represents southern interests abroad
and apparently will be the entity to which foreign
governments are accredited. When Hanoi becomes
satisfied that the southern administration has
satisfactorily adjusted economically and politically
to a more rigid socialist society, formal reunifica-
tion probably will occur. Currently, there is no way
to estimate the duration of this periods.','38658b58745f7ecf6591d23f09c9b36010cf9b0f261879b590aae5e0061ad496','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d510e33a0419a8808a11c1d67050dc457bf754a26c7ee0b0882d373de85335bd',1976,'WF','Wallis and Futuna','government',527,'Legal name: Territory of the Wallis and Futuna
Islands
Type: overseas territory of France
Capital: Matu Utu
Political subdivisions: 3 districts
Branches: territorial assembly of 20 members;
popular election of one deputy to National Assembly
in Paris, and one Senator
Government leader: Superior Administrator
Jacques de Agostini
Suffrage: universal adult
Elections: every 5 years
Legal name: The Independent State of Western','854a450207dbf562c1f2bdac8140ba75ed3ba30bba97c36b7dc36f1aa531b584','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6490f038a554279e494786c60c0677f1317f539882dbf53b1d3dd3005ee80094',1976,'WS','Samoa','government',529,'Type: constitutional monarchy under native chief:
special treaty relationship with New Zealand
Capital: Apia
Legal system: based on English common law and
local customs; constitution came into effect upon
independence in 1962; judicial review of legislative
acts with respect to fundamental rights of the citizen;
has not accepted compulsory ICJ jurisdiction
Branches: Head of State and Executive Council;
Legislative Assembly; Supreme Court, Court of
Appeal, Land and Titles Court, village courts
Government leaders: Head of State, Malietoa
Tanumafili II; Prime Minister, Tamesese Lealofi
Suffrage: 45 Samoan members of Legislative
Assembly are elected by holders of matai (heads of
family) titles (about 5,000); 2 European members are
elected by universal adult suffrage
Elections: held triennially, last in February 1973
Political parties and leaders: no clearly defined
political party structure
Communists: unknown
Member of: ADB, Commonwealth, ESCAP, IBRD,
IFC, IMF, Scabeds Committee, WHO
Legal name: Peoples Democratic Republic of','62352971e372074e3f452d8300b8771224878643c6b088ae876dfa7b036111ee','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb19a7ca2de525491faf9bfed9b08eb8ca6ee77da4304f409e8add76726f8a38',1976,'YE','Yemen','government',533,'Type: republic; power centered in ruling National
Front Party
Capital: Aden; Madinat ash Sha b, administrative
capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal
matters) and English common law (for commercial
matters); highest judicial organ, Federal High Court,
interprets constitution and determines disputes
between states
Branches: Presidential Council; cabinet; Supreme
People''s Council
Government leaders: Chairman of Presidential
Council, Salim Rubayyi Ali; Prime Minister Ali Nasir
Muhammed al-Hasani: NF Secretary General Abd
ALFattah Ismail
Suffrage: granted by constitution to all citizens 18
and over
Elections: elections for legislative body, Supreme
People’s Council, called for in constitution; none have
been held
Political parties and leaders: National Front
(NF), only legal party
Communists: few known
Member of: FAO, GATT (de facto), IBRD, ICAO,
IDA, ILO, IMF, ITU, Seabeds Committce, U.N.,
UNESCO, UPU, WFTU, WIIO, WMO
Legal name: Yemen Arab Republic
Type: republic; military regime assumed power in
June 1974
Capital: Sana
Political subdivisions: 8 provinces
almost entirely agriculture and
Legal system: based on Turkish law, Islamic law,
and local customary law; first constitution
promulgated December 1970. suspended June 1974:
has not accepted compulsory ICJ jurisdiction
Branches: Military Command Council, Prime
Minister, cabinet, 117-member Consultative As-
sembly
Government leaders: Head of Military Command
Council, Col. Ibrahim Hamdi; Prime Minister
Abd al-Ghani
Communists: few known
Political parties or pressure groups: Yemeni
Union, a small inactive Eovernment party formed in
February 1978; some pro-Iraqi Baathists, other small
clandestine groups supported by Yemen (Aden)
Member of: Arab League, FAO, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, Seabeds Committee,
U.N., UNESCO, UPU, WFTU, WHO, WMO
Legal name:
Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Socialist Federal Republic of
Political subdivisions: 6 republics with 2
autonomous provinces (within the Republic of Serbia)
Legal system: mixture of civil law system and
Communist legal theory; constitution adopted 1974;
legal education at several law schools; has not
accepted compulsory ICJ jurisdiction
Branches: parliament (Federal Assembly) constitu-
tionally supreme; executive includes cabinet (Federal
Executive Council) and the federal administration;
independent judiciary; the State Presidency is a
collective policymaking body composed of a
representative from each republic and province, Tito
presides as President of the Republic
Government leader: Josip Broz Tito, President of
Republic and President of League of Communists of
Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years
by a complicated, indirect system of voting
Political parties and leaders: League of
Communists of Yugoslavia (LCY) only; leaders are
President Tito and influential presidium members
Edvard Kardelj, Vladimir Bakaric, and Stane Dolanc
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Voting strength: Voter participation in national
elections has declined, as follows — 1963, 95.5%;
1965, 93.6%; 1967, 89%; 1969, 88%; 1974, no data
available
Communists: 1,076,000 party members (May
1974)
Other political or pressure groups: Socialist
Alliance of Working People of Yugoslavia (SAWPY),
the major mass front organization for the LCY;
Confederation of Trade Unions of Yugoslavia
(CTUY) Union of Youth of Yugoslavia (UYY),
Federation of Yugoslav War Veterans (SUBNOR)
Member of: CEMA (observer but participates in
certain commissions) EC (5-year non-preferential
trade agreement signed in May 1973), FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO, IMCO,
IMF, IPU, ITU, OECD (participant in some
activities), Seabeds Committee, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of Zaire (until October 1971
known as Democratic Republic of the Congo)
Type: republic; constitution establishes strong
presidential system
Capital: Kinshasa
Political subdivisions: 8 regions and federal district
of Kinshasa
Legal system: based on Belgian civil law system
and tribal law; new constitution promulgated 1967,
revised 1974; legal education at National University
of Zaire; has not accepted compulsory IC] jurisdiction
Branches: president elected 1970 for seven-year
term limited to two five-year terms, thereafter;
National Legislative Council of 210 members elected
for five-year term; the official party is the supreme
political institution
Government leaders: Lt. Gen. Mobutu Sese Seko,
President
Suffrage: universal and compulsory over age 18
Elections: presidential and legislative elections in
October and November 1970
Political parties and leaders: Mouvement
Populaire de Ja Revolution (MPR), only legal party,
organized from above with actual grassroots
popularity not clearly definable
Voting strength: MPR slate polled 96.3% of vote in
1970 elections
Communists: no Communist Party; U.S.S. R. and
Peoples Republic of China have diplomatic
missions in Zaire
Member of: AFDB, EAMA, EIB (associate), FAO,
CATT, IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO,
228
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ZAIRE/ZAMBIA :
IMF, IPU, ITU, OAU, OCAM, Seabeds Committee,
UDEAC, U.N., UNESCO, UPU, WFTU, WHO,
WMO','fbfa6e0f6dc5a82edb9204577e0a36cbc4c374ac1d3674bd53b539156cbaee15','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cba430923bb81f990048744b09ccc1ddff58554195340d264a2b7f565650305',1976,'ZM','Zambia','government',539,'Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
229
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ZAMBIA/UNITED STATES
Political subdivisions: 8 provinces
Legal system: based on English common law and
customary law; new constitution adopted September
1973; judicial review of legislative acts in an ad hoc
constitutional council; legal education at University
of Zambia in Lusaka; has not accepted compulsory
IC] jurisdiction
Branches: modified presidential system; unicam-
eral legislature; judiciary
Government leader: President Kenneth Kaunda;
Prime Minister Elijah Mudenda
Suffrage: universal adult
Elections: last general election December 1978
Political parties and leaders: United National
Independence Party (UNIP), Kenneth Kaunda;
former opposition party banned in December 1972
when 1 party state proclaimed
Voting strength (1973 election): in first
presidential and parliamentary elections under single-
party system, 43% of eligible voters went to polls;
Kaunda was only candidate for President; National
Assembly seats were contested by members of UNIP
Communists; no Communist Party, but sympa-
thizers of socialism in upper levels of government,
UNIP, and labor unions
Member of: AFDB, Commonwealth, FAO, GATT
(de facto), IAEA, IBRD, ICAO, IDA, IDB, IEA, IFC,
11.0, IMF, IPU, ITU, OAU, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO','a62c389559b216a0564d8250f0cb7b81863e764916cce4d24f5bf7eab3b23c52','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83680a3535f723c393b2041c959530fed6cf1d7f5ce5ba878d9dc22983dd66fd',1976,'US','United States','government',543,'Legal name: United States of America
Legal system: based on English common law; dual
system of courts, state and federal; constitution
adopted 1789; judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with reservations
Voting strength (1972 presidential election):
Republican Party (Nixon), 47,170,000; Democratic
Party (McGovern), 29,170,000; minor parties,
1,378,000
Communists: Party membership, 10,000-11,000
(est.); General Secretary, Gus Hall
Member of: ADB, ANZUS, CENTO, Colombo
Plan, DAC, FAO, CATT, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IEA, IFC, 1HO, ILO, IMCO, IMF, IPU,
ITU, NATO, OAS, OECD, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO','92dab5e496abf8365421d0df3741c7c2909d5348a59c5ecdf6a184a43c4155b9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5eeab36fd05fa1dfb249eb75f0c0b67de695721fc28c1eadf663d3228de6a48',1976,'AF','Afghanistan','government',4,'Legal name: Republic of Afghanistan
Type: republic
Capital: Kabul
Political subdivisions: 28 provinces with centrally
appointed governors
Legal system: based on Islamic law; constitution
nullified July 1973; independent judiciary also
abolished and powers transferred to the Council of
Justice, chaired by Minister of Justice; legal education
at University of Kabul; has not accepted compulsory
ICJ jurisdiction
Branches: Parliament abolished July 1973; all
powers of the parliament and the monarchy
transferred to the President
Approved For Release 2005/04/22 :
Government leaders: President Mohammad
Daoud who also serves as Prime Minister, Foreign
Minister, and Defense Minister, Mohammad Naim,
Daoud’s brother and personal adviser
Suffrage: universal from age 20
Elections: promiscd but no date set
Political parties and leaders: no political parties
permitted
Communists: there are two pro-Moscow Com-
munist groups, Parcham and Khalg, believed to have
several hundred active members, and a smaller pro-
Peking group, Sholaye-Jaweid
Other political or pressure groups: most military
officers support the government; no known organized
opposition
Member of: ADB, Colombo Plan, FAO, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO','e823c5ed5865e7a8ace77a13ceef650bcbd014b21a240130dc57eaf195f34204','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6faa5ffd8e9a71b679d77c11b0dc8639e27b3c4a1b2824898e4eb7867d304786',1976,'AL','Albania','government',9,'Legal name: Peoples Republic of Albania
Type: Communist state
Capital: Tirane
Political subdivisons: 27 rethet (districts),
including capital, 200 localities, 2,600 villages
Legal system: based on Soviet law: constitution
adopted 1950; judicial review of legislative acts only
in the Presidium of the People’s Assembly, which is
not a true court; legal education at State University of
Tirane; has not accepted compulsory IC] jurisdiction
Branches: People’s Assembly, Council of Ministers,
judiciary
Government leaders: Chairman of Council of
Ministers, Mehmet Shehu:; President, Presidium of the
People’s Assembly, Haxhi Lleshi
Suffrage: universal and compulsory over age 18
Elections: national clections theoretically held
every 4 years; last elections 6 October 1974: 99.9% of
electorate voted
Political parties and leaders: Albanian Workers
Party only; First Secretary, Enver Hoxha
Communists: 87,000 party members (1971)
Member of: CEMA, IAEA, IPU, ITU. Seabeds
Committee, U.N., UNESCO, UPU. WFTU, WHO,
WMO, has not participated in CEMA since rift with
US.S.R. in 1961; officially withdrew from Warsaw
Pact 13 September 1968
Legal name: Democratic and Popular Republic of','7603df7915948fcc31b31d428e1d94ada3f9b65dfb51c69bfff3ea94b8347dd9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbfc25fc9417bde4865b719f9e23058a03c73d32e4b5faab88d5c2f97315bb17',1976,'DZ','Algeria','government',11,'Type: republic
Capital: Algiers
Political subdivisions: 31 Wilayas (departments or
provinces)
Legal system: based on French and Islamic law,
with socialist principles; constitution adopted by
referendum 1963 but suspended since June 1965,
judicial review of legislative acts in ad hoe
Constitutional Council composed of various public
officials, including several Supreme Court justices;
Supreme Court divided into 4 chambers; legal
education at Universities of Algiers, Oran and
Constantine; has not accepted compulsory ICJ
jurisdiction
Branches: executive dominant, unicameral
legislature has not met since June 1965 coup d''ctat
but was never formally suspended, judiciary
Government leader: Houari Boumediene, Presi-
dent of Council of the Revolution and President of the
Council of Ministers, overthrew elected President
Ahmed Ben Bella 19 June 1965
Suffrage: universal over age 19
Elections (Jatest): presidential 15 September 1963;
departmental assemblies 2 June 1974; local assemblies
30 March 1975
Political parties and leaders: National Liberation
Front (FLN)
Voting strength (1963 election): 100% FLN
Communists: 400 (est.); Communist Party illegal
(banned 1962)
Member of: AFDB, Arab League, FAO, GATT (de
facto), IAEA, IBRD, ICAO, IDA, ILO, IMCO, IMF,
ITU, OAPEC, OAU, OPEC, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ALGERIA/ANDORRA','57e5e4794f75053c638929421e1e2f60a2354604b00fa8758dd0b6ae2b006286','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c32ff525e4fcaad1cbfcc93bc93cefa62b68ba5727f2731abceb11c73754c6fe',1976,'AD','Andorra','government',16,'Legal name: The Valleys of Andorra
Type: unique coprincipality under formal
sovereignty of President of France and Spanish Bishop
of Seo de Urgel, who are represented locally by
officials called veguers
Capital: Andorra
Political subdivisions: 6 districts — Andorra la
Vella, Sant Julia de Loria, Encamp, Canillo, La
Massana, and Ordino
noun—Andorran(s); adjective—
Legal system: based on French and Spanish civil
codes; Plan of Reform adopted 1866 serves us
constitution; no judicial review of legislative acts; has
not accepted compulsory IC] jurisdiction
Branches: legislature (General Council) of 24
members with one-half elected every 2 years for 4-year
term; executive — syndic and a deputy sub-syndic
chosen by General Council for 3-year terms; judiciary
chosen by coprinces who appoint 2 civil judges, a
judge of appeals, and 2 Buatles (court prosecutors)
Suffrage: males of 21 or over who are third
generation Andorrans vote for General Council
members; same right granted to women in April 1970
Elections: half of General Council chosen every 2
years, last election December 1973
Political parties and leaders: no political parties
but only partisans for particular independent
candidates for the General Council, on the basis of
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ANDORRA/ANGOLA
competence, personality and orientation toward Spain
or France; various small pressure groups developed in
1972 ;
Communists: negligible','a739d92784d711c2e8008952fcb3a240ca73c0992f12159fccbda20c575d6c3d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6954974b42ee675cc0561a8c3acc95bfb9021168f50ee06d707aca1bcd694af1',1976,'AO','Angola','government',20,'Angola received independence from Portugal on
November 11, 1975. Three rival liberation groups are
fighting a civil war in order to gain political control
over the former territory. The groups are National
Front for the Liberation of Angola (FNLA) led by
Holden Roberto, Popular Movement for the
Liberation of Angola (MPLA) led by Agostinho Neto,
and National Union for the Total Independence of
Angola (UNITA) led by Jonas Savimbi.
Capital: Luanda','2138b17f513525aa46ecb2f81ca6fc3fbf75a863ba4845863cd6dabf579308fe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('731c1de7b47f6082d5deace1c52fbd8134fa4782bf88fecf231626950c695c83',1976,'PR','Puerto Rico','government',24,'Legal name: State of Antigua
Type: dependent territory with full internal
autonomy as a British “Associated State”
Capital: St. John’s
Political subdivisions: 6 parishes, 2 dependencies
(Barbuda, Redonda)
Legal system: based on English law; British
Caribbean Court of Appeal has exclusive original
jurisdiction and an appellate jurisdiction, consists of
Chief Justice and 5 justices
Branches: legislative, 21-member popularly elected
House of Representatives; executive, Prime Minister
and Cabinet
Government leaders: Premier George Herbert
Walter; Governor Sir Wilfred Ebenezer Jacobs
Suffrage: universal suffrage age 18 and over
Elections: every 5 years: last general election 11
February 1971
Political parties and leaders: Antigua Labor Party
(ALP), Vere C. Bird; Progressive Labor Movement
(PIM), George Herbert Walter: Antigua People’s
Party (APP), J. Rowan Henry
Voting strength: 1971 election — House of
Representative seats — ALP 4, PLM 13
Communists: negligible
Other political or pressure groups: Afro-
Caribbean Movement (ACM), a small black
nationalist group led by Timothy Hector: Antigua
Freedom Fighters (AFF), a small black radical group,
leaders unknown
Member of: CARICOM','29f0c808d95a81cc9d55b4142805f1079456b7fc6763f6b0cf43fd954f6195c7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff5ca0ff0ca0d32d28f5ad334a8ea1c28690540adc9ac360524a5ea2d1fbddeb',1976,'AR','Argentina','government',28,'Legal name: Argentine Republic
Type: republic
Capital: Buenos Aires
Political subdivisions: 22 provinces, | district
(Federal Capital), and 1 territory
Legal system: based on Spanish and French civil
codes; constitution adopted 1853 partially superseded
in 1966 by the Statute of the Revolution which takes
precedence over the constitution when the two are in
conflict, further changes may be made by new
government; judicial review of legislative acts; legal
education at University of Buenos Aires and other
public and_ private universities; has not accepted
compulsory ICJ jurisdiction
Branches: Presidency;
judiciary
Government leader:
Martinez de Peron
Suffrage: universal and compulsory age 18 and
over
Elections: general elections held on 11 March
1973; congressional and gubernatorial runoffs were
held on 15 April; next election in 4 years
Political parties: Justicialistas, the official Peronist
party; Radical Civic Union, moderate leftist and
nationalist, Ricardo Balbin; Federal Popular Alliance,
Francisco Manrique; Movement of Integration and
Development (MID), small left of center party,
former President Frondizi; New Force, conservative
business party, organized by Alvaro Alsogaray for the
1973 elections; Intransigent Party, formerly the
Intransigent Radicals (UCRI), small nationalist party,
Oscar Alende; several provincial parties not organized
on a national basis
Voting strength: Justicialista Front, 61%; Radicals
(former People’s Radical Civic Union, UCRP), 24%;
Federal Popular Alliance, 12%; others, 3%
Communists: some 70,000 members in various
party organizations, including a small nucleus of
legislature; national
President, Maria Estela
activists
Other political or pressure groups: Argentine
armed forces, Peronist-dominated labor movement,
General Economic Confederation (Peronist-leaning
association of small businessmen), Argentine
Industrial Union (manufacturer s association),
Argentine Rural Socicty (large landowner’s as-
sociation), business organizations, students, and the
Catholic Church
0001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00080001
January 1976
ARGENTINA/A USTRALIA
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDA. IDB, IFC, THO, ILO, IMCO, IMF,
ITU, LAFTA, OAS, Seabeds Committee, U.N.,
UNFSCO, UPU. WCL, WFTU, WHO, WMO, Non-
Aligned Nations Group','dc7b607b8dbad5773c85de32aa6834931f7205d72b4b73d35726cb146b512ff8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('236a7a6c70539ebcd075406dc59ecac65d6d32049733c7de274304d4e9cd5600',1976,'AU','Australia','government',32,'Legal name: Commonwealth of Australia
Type: federal state recognizing Elizabeth [1 as
sovereign or head of state
Capital: Canberra
Political subdivisions: 6 states and 2 territories
(Australian Capital Territory (Canberra) and
Northern Territory)
Legal system: based on English common law;
constitution adopted 1900; High Court has
jurisdiction over cases involving interpretation of the
constitution; accepts compulsory 1CJ jurisdiction,
with reservations
Branches: Parliament (House of Representatives
and Senate); Prime Minister and Cabinet responsible
to House; independent judiciary
Government leaders: Governor General Sir John
Kerr; Prime Minister John Malcolm Fraser
Suffrage: universal over age 21
Elections: held at 3-year intervals, or sooner if
Parliament is dissolved by Prime Minister; last
election December 1975
Political parties and leaders: Government —
Liberal Party (Malcolm Fraser) and National Country
Party (Douglas Anthony); opposition — Labour Party
(Gough Whitlam)
Voting strength (1975 Parliamentary election —
lower House}: Liberal-Country Coalition, 91 seats;
Labour Party, 35 seats; 1 seat undecided
Communists: 3,900 members (est.)
Other political or pressure groups: Democratic
Labour Party (anti-Communist Labour Party splinter
group)
Member of: ADB, ANZUS, Colombo Plan,
Commonwealth, DAC, ELDO, ESCAP, FAO, GATT,
1AFA, IBRD, ICAO, IDA, IEA, 1FC, THO, ILO,
IMCO, IMF, 1PU, ITU, OECD, Scabeds Committee,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Papua New Guinea
Type: independent state within Commonwealth
recognizing Elizabeth II as head of state
Capital: Port Moresby
Political subdivisions: 18 administrative districts
(12 in New Guinea, 6 in Papua)
Legal system: based on English common law
Branches: executive—Executive Council; legisla-
ture — House of Assembly (100 members, plus 4
appointed); judiciary — court system consists of
Supreme Court of Papua New Guinea and various
inferior courts (District Courts, Local Courts,
Children’s Courts, Wardens’ Courts)
Government leader: Governor General, Sir John
Guise; Prime Minister, Michael Somare
Suffrage: universal adult suffrage
Elections: preferential-type elections for 100-
member House of Assembly every 4 years
Political parties: Pangu Party is principal political
group; 5 or 6 other small parties and numerous
independents
Voting strength (1972 election): Pangu Party and
Allies won 52 seats, United Party 42 seats,
Independence 6 seats
Communists: no significant strength
Member of: ADB, Commonwealth, IBRD, IMF,
U.N., WHO (associate)','c9ec3e057f2ba5e93a0c6c7c872c9a7d6bb43fd4d1845dbbfbbdabf0b137cfaa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe88f4514b5a2341e5144009f1808099142e5e4951598161d3c5e42f5bb25381',1976,'AT','Austria','government',38,'Legal name: Republic of Austria
10
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (Laender) including
the capital
Legal system: civil law system with Roman law
origin; constitution adopted 1920, repromulgated in
‘B45. judicial review of legislative acts by a
Constitutional Court: Separate administrative and
civil/penal Supreme courts; legal education at
Universities of Vienna, Graz, Innsbruck, Salzburg,
and Linz: has not accepted compulsory ICJ
jurisdiction
Branches: bicameral Parliament, directly elected
President whose functions are largely representational,
independent federal judiciary
Government leaders: President Radolf Kireh-
schlaeger, Chancellor Bruno Kreisky leads a one-party
Socialist government
Suffrage: universal over age 19: compulsory for
presidential elections
Elections: presidential, every 6 vears (next 1980):
parliamentary. every 4 vears (next October)
Political parties and leaders: Socialist Party. of
Austria (SPOe), Bruno Kreisky, Chairman: Austrian
People’s Party (OeVP), Josef Taus, Chairman: Liberal
Party (FPOe). Friedrich Peter. Chairman: Communist
Party, Franz Muhri. Chairman
Voting strength (1975 election): 50,6¢; SPOe,
42.7% OeVP. 5.3% FPOe, 1.2% Communist
Communists: membership 25,000 est.: activists
7.000-8,000
Other political or pressure groups: Federal]
Chamber of Commerce and Industry: Austrian Trade
Union Federation (primarily socialist); three
composite leagues of the Austrian Peoples Party
(OeVP) representing business, labor, and farmers; the
OeVP-oriented League of Austrian Industrialists:
Roman Catholic Church, including its chief lay
organization, Catholic Action
Member of: A DB, Council of Europe, DAC, ECE,
ETA, EMA. ESRO (observer), FAO, GATT, [A EA,
IBRD, ICAO. IDA, IFA, IFC, ILO. IMF. ITU,
OECD, Seabeds Committee, ULN., UNESCO, UPU,
WCL, WETU, WHO, WMO
Legal name: The Commonwealth of The Bahamas
Type: independent commonwealth since July 1978,
recognizing Elizabeth II as chief of state
11
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
THE BAHAMAS/BAHRAIN
Capital: Nassau (New Providence Island)
Legal system: based on English law
Branches: bicameral legislature (appointed Senate,
elected House): executive (Prime Minister and
cabinet); judiciary
Government leaders: Prime Minister Lynden O.
Pindling
Suffrage: universal over age 18
Elections: House of Assembly (9 September 1972)
Political parties and leaders: Progressive Liberal
Party (PLP), predominantly Negro, Lynden Q.
Pindling; Free National Movement (FNM) formed by
a merger of United Bahamian Party (UBP) and Free
Progressive Liberal Party (Free PIP), Kendall Isaacs
Voting strength (1972 election): FIP 29 seats,
NM 9 seats
Communists: negligible
Member of: IMF, Seabeds Committee, U.N.,
WMO','a993e11ad205102471347af215c4082e6352b28d0adaf00fbb95f5be447d1aab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45eb726fccae33a654da6001d7f5c20e6d39b7725a51ffce95eb5def57462da9',1976,'BH','Bahrain','government',42,'Legal name: State of Bahrain
Type: traditional monarchy; independence
declared in 1971
Capital: Al Manamah
Legal system: based on Islamic law and English
common law; constitution went into effect December
1973
Branches: Emir rules with help of a cabinet led by
Prime Minister; a national assembly, made up of
cabinet and 80 directly elected members, was formed
in early 1974; Emir dissolved assembly in August 1975
and suspended the Constitutional provision for
election of the assembly
Government leader: Emir ‘Isa ibn Salman Al-
Khalifah
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BAHRAIN/BANGLADESH
Political parties and pressure groups: political
parties prohibited; no significant pressure groups
although numerous small clandestine groups are
active
Communists: negligible
Member of: Arab League, FAO, GATT (de facto),
IBRD, ICAO, IMF, OAPEC, Seabeds Committee,
U.N., UNESCO, WHO','9d0909e9cca079dcdd45bc97b0229bacbf01b25c5a7175fbb75d22953ec21557','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('248add9e8b4cdbcc0b1c0f37ada19ed25102aa0dab158ac58859cc9e2c72ccc2',1976,'BD','Bangladesh','government',47,'Legal name: Peoples Republic of Bangladesh
noun—Bengalee(s); adjective—
13
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
january 1976
BANGLADESH/BARBADOS
Type: independent republic since December 1971:
Government of President Sheikh Mujibur Rahman
overthrown in August 1975; two other coups followed:
country currently governed by military-backed
niartial law administration with civilian president and
three military service chiefs as deputy martial law
administrators
Capital: Dacca
Political subdivisions: 19 districts, 413 thanas
(counties), 4,053 unions (village groupings)
Legal system: based on English common law:
constitution adopted December 1972; amended
January 1975 to more authoritarian Presidential
system
Branches: constitution provides for unicameral
legislature, strong President: controlled judiciary,
Parliament dissolved by current regime
Government leader: President A. M. Sayem
Suffrage: universal over age 18
Elections: First Parliament (House of the Nation)
elected in March 1973; elections every 5) vears;
Government has banned political activity but has
announced intention to lift ban in 1976, and hold
elections in 1977
Communists; 2,500 members (est. )
Other political or pressure groups: student groups,
bands of former guerrillas
Member of: ADB, Afro-Asian People’s Solidarity
Organization, Colombo Plan, Commonwealth,
ESCAP, GATT, IAEA, IBRD, ICAO, IDA, IMF,
11.0, Seabeds Committee. U.N., UNCTAD,
UNESCO, UPU, WHO','58ef533404ed4ced84acbbf8c666cc0a217022332f1ec93a8a17e2c7c43cc816','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e24778b335565182f867f94735ae5985fe57321006d790f9ad5127af114d9f54',1976,'BB','Barbados','government',51,'Legal name: Barbados
Type: independent sovereign state within the
Commonwealth since November 1966, recognizing
Elizabeth II as chief of state
Capital: Bridgetown
Political subdivisions: 11 parishes
Legal system: English common law; constitution
came into effect upon independence in 1966; no
judicial review of legislative acts; has not accepted
compulsory [CJ jurisdiction
Branches: legislature consisting of a 21-member
appointed Senate and a 24-member elected House of
Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister Errol Walton
Barrow; Governor General Sir Winston Scott
Suffrage: universal over age 18
Elections: House of Assembly members have terms
no longer than 5 years; last general election held 9
September 1971
Political parties and leaders: Democratic Labor
Party (DLP), Errol Barrow; Barbados Labor Party
(BLP), J. M. G. “Tom” Adams
Voting strength (1971 election): Democratic
Labor Party (DLP), 57.5%; Barbados Labor Party,
42.5%; Independent, negligible; House of Assembly
seats — DLP 18, BLP 6
Communists: negligible
Other political or pressure groups: People’s
Progressive Movement (PPM), a small black-
nationalist group led by Calvin Alleyne
Member of: CARICOM, Commonwealth, FAO,
GATT, IADB, ICAO, IDB, ILO, IMCO, IMF, ITU,
OAS, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO
Approved For Release 2005/04/22 :','39d3ebb1d9808ccb11a110f98617608ca0ed50c6b47b4d416a4bf10f4dc9cff7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('143982ec67ce8ef884289d35602b4ef6d6a13cfe773c5799d5cce079e45dafce',1976,'BE','Belgium','government',55,'Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil law system influenced by
English constitutional theory; constitution adopted
1831, since amended; judicial review of legislative
acts; legal education at 4 law schools: accepts
compulsory [CJ jurisdiction, with reservations
Branches: executive branch consists of King and
cabinet; cabinet responsible to bicameral parliament;
independent judiciary; coalition governments are
usual
Government leader: Head of State, King
Baudouin; Prime Minister Leo Tindemans
16
Suffrage: universal over age 21
Elections: held 10 March 1974 (held at least once
every 4 years)
Political parties and leaders: Social Christian,
Charles-Ferdinand Nothomb and Wilfred Martens,
co-presidents; Socialist, Andre Cools and Willy Claes,
co-presidents; Liberty and Progress, Senator P.
Deschamps, national president: Liberal Democratic
and Pluralist Party, Rolland Gillet, party president;
Francophone Democratic Front-Walloon Rally
(Walloon nationalist), Leo Defosset, national
president; Volksunie (Flemish Nationalist), Hugo
Schlitz, party president; Communist, Louis Van Gent,
president of political bureau
Voting strength (1974 election): 72 seats Social
Christian, 59 seats Socialist, 30 seats Liberty and
Progress, 22 seats Volksunie, 22 seats Francophone
Democratic Front-Walloon Rally, 4 seats Communist,
3 seats Democratic and Pluralist
Communists: 10,000 members (est. )
Other political or pressure groups: Christian and
Socialist Trade Unions; the Federation of Belgium
Industries; numerous other associations representing
bankers, manufacturers, middle-class artisans, and the
legal and medical professions; two major organiza-
tions represent the cultural interests of Flanders and
Wallonia
Member of: ADB, Benelux, BLEU, Council of
Europe, DAC, EC, ECE, ECOSOC, ECSC, EEC,
EIB, ELDO, EMA, ESRO, EURATOM, FAO,
GATT, IAEA, IBRD, ICAO, IDA, IEA, IFC, ILO,
IMCO, IMF, IPU, ITU, NATO, OAS (observer),
OECD, Seabeds Committee, U.N., UNESCO, UPU,
WCL, WEU, WHO, WMO','7e3751abe2a49495cc131bd87264a5e1d9008c085f73bd33e62768258020857c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('587eaf7436705e3b2049bfd6c0e95e82f272054bba83533fa693385277a6713c',1976,'BZ','Belize','government',60,'Legal name: Belize
Type: internal self-governing British colony
noun—Belizean(s); adjective—
agriculture, 14%
Capital: Belmopan
Legal system: English law; constitution came into
force in 1964, although country remains a British
colony
17
p
January 1976
BELIZE/BERM UDA
Government leader: Premier George Price
Suffrage: universal adult (probably 21)
Elections: must be held within 5 years of last
elections held in October 1974
Political parties and leaders: People''s United
Party (PUP), George Price; United Democratic Party
(UDP), a Coalition comprised of the National
Independence Party (NIP) led by Philip Goldson, the
People’s: Democratic Union (PDM) fed by Dean
Lindo, and the Liberal Party (LP) led by Harry
Laurence: Corozal United Front (CUF), Santiago
Ricalde; United Black Association for Development
(UBAD), Evan X. Hyde
Voting Strength (National Assembly); PUP 9
seats, UDP 6 seats
Communists: negligible
Other political or Pressure groups: Christian
Workers’ Union (CWU) which is connected with PUP
Member of: CARICOM, WC,','6611b820481f26d2427875a709890c821cfc20398ab60cfe610b3552329daa9b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73ab6755e122a38e09a1a012f616c5964abc6b8a53d1efcd149f4bf8bea0b6d4',1976,'BM','Bermuda','government',64,'Legal name: Colony of Bermuda
Type: British colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English law
Branches: Executive Council (cabinet) appointed
by governor, led by government leader; bicameral
legislature with an appointed Legislative Council,
and a 40-member directly elected House of Assembly
Government leaders: Governor Sir Edwin Leather;
Government Leader (equivalent to Premier) Sir
Edward Richards
Suffrage: universal over age 21
Elections: at Jeast once every 5 years; last general
election, June 1972
Political parties and leaders: United Bermuda
Party (UBP), Sir Edward Richards; Progressive Labor
Party (PLP), Walter N.H. Robinson
Voting strength (1972 elections): UBP 61.2%, PLP
38.8%; House of Assembly seats — UBP 30, PLP 10
Communists: negligible
Other political or pressure groups: Bermuda
Industrial Union (BIU)','1d8d76d972d95bff3e67c6df3fe8fc484ea011bedab42c42ef6ed176c74bbcb4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('007998ffeffdd0322a2b64420024b1ebc0cc0071e27f6f3e4a1e0d1d118d2d51',1976,'IN','India','government',68,'Capital: Thimphu
Political subdivisions: 4 regions (east, central,
west, south), further divided into 15-18 subdivisions
Legal system: based on Indian law and English
common law; in 1964 the monarch assumed full
power — no constitution existed beforehand; a
supreme court hears appeals from district administra-
tors; has not accepted compulsory ICJ jurisdiction
Branches: appointed minister and_ indirectly
clected assembly consisting of village elders, monastic
representatives, and all district and senior government
administrators
Government leader: King Jigme Singhi Wangchuk
19
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BHUTAN/BOLIVIA
Suffrage: cach family has one vote
Elections: popular elections on village level held
every 3 years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist
clergy
Member of: Colombo Plan, Seabeds Committee.
UPU, ULN.
Legal name: Republic of Bolivia
Type: republic; de facto military dictatorship
Capital: La Paz (seat of government): Sucre
(judicial capital)
Political subdivisions: 9 departments with limited
autonomy
Legal system: based on Spanish law and Code
Napoleon; constitution adopted 1967; constitution in
force except where contrary to dispositions dictated by
governments since 1969; legal education at University
of San Andres and several others: has not accepted
compulsory [CJ jurisdiction
Branches: executive; congress of two chambers
(Senate and Chamber of Deputies), congress
disbanded after 26 September 1969 ouster of President
Siles; judiciary
Government leaders: President Hugo Banzer
Suarez
Suffrage: universal and compulsory at age 18 if
married, 21 if single
Elections: postponed indefinitely
Political parties and leaders: political activities are
proscribed indefinitely; most party leaders are in exile
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BOLIVIA/BOTSWANA
Voting strength (1966 elections): Frente de la
Revolucion Boliviana (a coalition composed of the
MPG, PIR, PRA, PSD, and two interest groups, the
campesinos and Chaco War Veterans) 61%, FSB 12%,
MNR 10%, other 17%
Communists: three parties (all proscribed);
PCB/Soviet led by Jorge Kolle Cueto, about 300
members; PCB/Chinese led by Oscar Zamora, 150
(including 100 in exile); POR (Trotskyist), about 50
members divided between three factions led by Hugo
Gonzalez. Moscoso, Guillermo Lora Escobar, and
Amadeo Arze
Member of: FAO, IAEA, IADB, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMF, ITU, International Tin
Council, LAFTA and Andean Sub-Regional Group
(created in May 1969 within LAFTA), OAS, Scabeds
Committee, U.N., UNESCO, WCL, WHO, WMO
Legal name: Republic of India
Type: federal republic
Capital: New Delhi
Political subdivisions: 22 states, 9 union territories
Legal system: based on English common law;
constitution adopted 1950; judicial review of
legislative acts; accepts compulsory [CJ jurisdiction,
with reservations
Branches: parliamentary government, national and
state; independent judiciary
Government leader: Prime Minister Indira
Gandhi
Suffrage: universal over age 21
Elections: national and state elections ordinarily
held every 5 years; may be postponed in emergency
and may be held more frequently if government loses
confidence vote; next general election due by March
1976 but may be postponed because of a national
emergency declared on June 26, 1975; most states to
hold state elections in 1977
Political parties and leaders: Indian National
Congress split into two factions in 1969, largest faction
(the Ruling Congress) loyal to Prime Minister Gandhi
led by D. K. Barooah, and dwindling faction (the
Organization Congress) led by Ashoka Mehta;
Communist Party of India (CPI), S. A. Dange,
chairman; Communist Party of India/Marxist
(CPI/M), P. Sundarayya, gencral secretary;
Communist Party of India/Marxist-Leninist (CPI/
ML), L. K. Advani, chairman; Bharatiya Jana Sangh,
A. B. Vajpayee, president; The Socialist Party,
George Fernandes, chairman; Dravida Munnetra
Kazhagam (DMK), N. Karunanidhi, president;
Bharatiya Lok Dal (BLD), Charan Singh, chairman
Voting strength (1971 election): 43.7% Ruling
Congress, 10.5% Organization Congress, 7.4%
Bharatiya Jana Sangh, 3.1% Swatantra, 4.8% CPI,
5.2% CPI/M, 8.5% Socialist Parties, 3.7% DMK,
18.1% other
Communists: 90,000 members of CPI (est.), 85,000
members of CPI/M (est.),; Communist sympathizers,
13 million
Other political or pressure groups: Anna Dravida
Munnetra Kazhagam (ADMK), M. G. Rama-
chandran, president, opposing DMK in Tamil Nadu;
splintered Akali Dal representing Sikh religious
community in the Punjab; various separatist groups
seeking reorganization of states; numerous “senas’’ or
militant/chauvinistic organizations, including Shiv
Sena and Dalit Panthers in Bombay, the Anand Marg,
and the Rashtriya Swayamserak Sangh
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
INDIA/INDONESIA
Member of: ADB, Colombo Plan, Commonwealth,
FAQ, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHO,
ILO, IMCO, IMF, IPU, ITU, Seabeds Committee,
U.N., UNESCO, UPU, WCL, WFTU, WHO, WMO','472c732694458a32ee1fca9301e68379a2c1e577c0fa768bce2dc33ceba3bc84','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a34f1a224a27a8943a504b4371eab20e17d9348e34e294b8ebec8705d4b43e2d',1976,'BR','Brazil','government',77,'Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presiden-
tial regime since April 1964
Capital: Brasilia
Political subdivisions: 21 states, 4 territories,
federal district (Brasilia)
Legal system: based on Latin codes; dual system of
courts, state and federal; constitution adopted 1967
and extensively amended in 1969; has not aceepted
compulsory ICJ jurisdiction
Branches: strong executive with very broad powers;
bicameral legislature (powers of the two bodies have
been sharply reduced); 11-man Supreme Court
Government leader: President Ernesto Geisel
Suffrage: compulsory over age 18, except illiterates
and those stripped of their political rights;
approximately 30 million registered voters in October
1970
Elections: President Medici’s successor was chosen
by a 505-member electoral college, composed of the
members of Congress and delegates selected from the
state legislatures, on 15 January 1974 and took office
on 15 March 1974; Geisel was the choice of Medici
and top military chiefs
Voting strength: (November 1974 congressional
elections) 33.6% ARENA, 31.9% MDB, 35.5% blank
and void
Political parties and leaders: National Renewal
Alliance (ARENA), pro-government Francelino
Pereira, president; Brazilian Democratic Movement
(MDB), opposition, Ulisses Guimaraes, president
Communists: 6,000, 1,000 militants
Other political or pressure groups: excepting the
military, the Catholic Church is the only active
nationwide pressure group, however, divisions within
the Church often prevent it from speaking with one
voice; labor and student groups have almost no
influence on the government
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, IHO, ILO, IMCO, IMF,
IPU, ITU, LAFTA, OAS, Seabeds Committee, U.N.,
UNESCO, UPU, WCL, WFTU, WHO, WMO
Legal name: British Solomon Islands Protectorate
Type: British protectorate administered as crown
colony
Capital: Honiara
Political subdivisions: 4 administrative districts
Legal system: u High Court plus Magistrates
Courts, also a system of native courts throughout the
islands
Branches: executive authority in High Commis-
sioner; a legislative assembly of 24 elected members, a
few appointed members
Government leaders: Governor D.C.C. Ludding-
ton and Chief Minister Mamaloni
Suffrage: universal age 21 and over
Elections: every 4 years, latest May-June 1973
Political parties and leaders: United Solomon
Islands Party
Member of: ADB
Legal name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: 4 administrative districts
Legal system: based on Islamic law; constitution
promulgated by the Sultan in 1959
Branches: chief of state is Sultan (advised by
appointed Privy Council) who appoints Executive
Council and Legislative Council
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 3-tiered system
of indirect elections; popular vote cast for lowest level
(district councilors)
Elections: last elections — March 1965; further
clections postponed indefinitely
Political parties and leaders: antigovernment,
exiled Brunei People’s Party, Chairman A. M. N.
Azahari
Communists: information not available','511d99141aadab02ac921dd5cf253a9d2516fa444d48a7968726455ee0eeab92','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('720d8a55048c2ce07fbc9a8a7142855ce9a2aac5a850af7ede9d39ed8197197d',1976,'BG','Bulgaria','government',81,'Legal name: Peoples Republic of Bulgaria
Type: Communist state
Capital: Sofiya
Political subdivisions: 28 okrugs (districts),
including capital city of Sofia
Legal system: based on civil law system, with
Soviet law influence, new constitution adopted in
1971; judicial review of legislative acts in the State
Council, legal education at University of Sofiya; has
accepted compulsory ICJ jurisdiction
Branches: legislative (National Assembly), Council
of Ministers, judiciary
Government leaders: Todor Zhivkov, Chairman,
State Council (President and chief of state): Stanko
Todorov, Chairman, Council of Ministers (premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 5 years for
National Assembly; last elections held on 27 June
1971; 99.8% of the electorate voted
Political parties and leaders: Bulgarian Com-
munist Party, Todor Zhivkov, First Secretary;
Bulgarian National Agrarian Union, a puppet party,
Petur Tanchev, secretary
Communists: 700,000 party members (April 1971)
Mass organizations and front groups: Fatherland
Front, Dimitrov Communist Youth League, Central
Council of Trade Unions, National Committee for
Defense of Peace, Union of Fighters Against Fascism
and Capitalism, Committee of Bulgarian Women,
All-National Committee for Bulgarian-Soviet
lriendship
Member of: CEMA, FAO, IAEA, ICAO, ILO,
IMCO, IPU, ITU, Seabeds Committee, U.N.,
UNESCO, UPU, WFTU, WHO, WMO, Warsaw
Pact. Internationa] Organization of Journalists,
International Medical Association, International
Radio and Television Organization
Legal name: Socialist Republic of the Union of
Burma
Type: republic under new 1974 constitution
Capital; Rangoon
Political subdivisions: seven divisions and seven
constituent states; subdivided into townships, villages,
and wards
Legal system: People’s Justice system and People’s
Courts instituted under 1974 constitution, legal
education at Universities of Rangoon and Mandalay;
has not accepted compulsory IC] jurisdiction
Branches: State Council rules through a Council of
Ministers; People’s Assembly has legislative power
Government leader: Chairman of State Council
and President, Gen. U. Ne Win
Suffrage: universal over age 18
27
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BURMA/BURUNDI
Elections: People’s Assembly and local People’s
Councils elected in 1974
Political parties and leaders: government-
sponsored Burmese Socialist Program Party only legal
party
Communists: estimated 5,000-8,000
Other political or pressure groups: People’s
Patriotic Party; Kachin Independence Army; Karen
Nationalist Union, several Shan factions
Member of: ADB, Colombo Plan, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO, IMCO,
IMF, ITU, Seabeds Committee, U.N., UNESCO,
UPU, WHO, WMO','ea6c18caa7fe896894b09a0e780cb3f4145fdedfb326d197a3432c8f7535ea76','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6a2d4d7b6f856e9a0fdaa4a7022fba572b655b4194d9dcd6923eef45576e863',1976,'BI','Burundi','government',85,'Legal name: Republic of Burundi
adjective—
Type: republic; military government since
November 1966: no constitution; new constitution
being drafted
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BURUNDI/CAMBODIA
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into
18 arrondissements and 78 communes
Legal system: based on German and French civil
codes and customary law; has not accepted
compulsory ICJ jurisdiction
Branches: Presidential Cabinet with Council of
Ministers; no legislature
Government leader: President Michel Micombero;
re-elected by party for seven-year term in October
1974
Elections: last legislative election May 1965
Political parties and leaders: National Party of
Unity and Progress (UPRONA), a predominantly
Tutsi party, was declared sole legitimate party in 1966
Communists: no Communist party; resumed
diplomatic relations with The Peoples Republic of
China in October 1971 following a six-year
suspension; U.S.S.R. and North Korea have
diplomatic missions in Burundi
Member of: AFDB, EAMA, ECA, FAO, GATT,
IBRD, ICAO, IDA, ILO, IMF, ITU, OAU, ULN.,
UNESCO, UPU, WHO, WMO','32225b8f517bad506536b17b7695f461624915ade72d1cc3138a9c8ead44791a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0847b88a38afcb6f517a2b008c05213f3b4128b56c8089468a8f0ff6fbe8e998',1976,'KH','Cambodia','government',89,'Type: authoritarian government controlled by the
Khmer Communist Party
Capital: Phnom Penh
Legal system: no post-war data available although
system of “people''s tribunals” reported
Government leader: nominal “head of state” is
Prince Sihanouk; Communist leaders exercise real
power
Political parties and leaders: political life
dominated by Khmer Communist Party and panoply
of mass front organizations
Communists: party strength about 10,000
Other political or pressure groups: none
Member of: replaced former government in United
Nations General Assembly in October 1975','baa6429fae8f4ac6f46ba1fdcf3d1cefaa7cf98d96be6e55c751c1187b908ec5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a133a550bb73354074a2087942243eb8f61d3a93e028241ad6a202aedc691a7e',1976,'GN','Guinea','government',92,'Legal name: United Republic of Cameroon
*0 Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Ca
January 1976
Approved
For Release 2005/04/22 : CIA-RDP79-01051A0008000
10001-8
CAMEROON/CANADA
Type: unitary republic; one-party presidential
regime
Capital: Yaounde
Political subdivisions: 7 provinces divided into 39
departments
Legal system: based on French civil law system,
with common law influence; new unitary constitution
adopted 1972; judicial review in Supreme Court,
when a question of constitutionality is referred to it by
the President of the Republic; has not accepted
compulsory [CJ jurisdiction
Branches: executive, legislative, and judicial
Government leader: President Ahmadou Ahidjo
Suffrage: universal over age 21
Elections: presidential elections held 5 April 1975;
parliamentary elections last held 18 May 1973
Political parties and leaders: single party,
Cameroonian National Union (UNC), President
Ahmadou Ahidjo
Communists: no Communist Party ot significant
number of sympathizers
Other political or pressure groups: Cameroon
Peoples Union (UPC), an iNegal terrorist group now
reduced to scattered acts of banditry with its factional
leaders in exile
Member of: AFBD, EAMA, ECA, EIB (associate),
FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMCO, IMF, PU, ITU, Lake Chad Basin
Commission, Niger River Commission, OAU, OCAM,
UDEAC, U.N., UNFSCO, uPu, WHO, WMO
Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since
1968
Capital:
Nguema
Malabo, Province Francisco Macias
Political subdivisions: 2 provinces (Province
francisco Macias Nguema and Rio Muni)
Legal system: based on Spanish civil law system
and customary law, new constitution adopted July
1973; has not accepted compulsory ICJ jurisdiction
Branches: there are legislative and judicial
branches but President exercises virtually unlimited
power
Government leader: President for life, Francisco
Macias Nguema
Suffrage: universal age 21 and over
Elections: parliamentary elections held December
1973
Political parties and leaders: National Unity Party
of Workers (PUNT) is the sole legal party, led by
President Macias
Communists: no significant number of Com-
miunists or sympathizers
Member of: Conference of East and Central
African States, ECA, IBRD, ICAO, IDA, IMCO,
IMF, ITU, OAU, Seabeds Committee, U.N., UPU
Legal name: Republic of Guinea
Type: republic; under one-party presidential
regime
Capital: Conakry
Political subdivisions: 29 administrative regions,
209 arrondissements, about 8,000 local entities at
village level
Legal system: based on French civil law system,
customary law, and presidential decree; constitution
adopted 1958; no constitutional provision for judicial
review of legislative acts; has not accepted compulsory
ICJ jurisdiction
Branches: executive branch dominant, with power
concentrated in President''s hands and a small group
who are both ministers and members of the party’s
politburo; unicameral National Assembly and
judiciary have little independence
Government leader: President Ahmed Sekou
Toure, who has been designated “The Supreme
Leader of the Revolution”
Suffrage: universal over age 18
Elections: approximate schedule — 5 years
parliamentary, latest in 1975; 7 years Presidential,
latest in 1975
Political parties and leaders: only party is
Democratic Party of Guinea (PDG), headed by Sekou
Toure
Communists: no Communist party, although there
are some sympathizers
Member of: AFDB, ECA, FAO, IBRD, ICAO,
IDA, ILO, IMF, ITU, Niger River Commission,
OAU, U.N., UNESCO, UPU, WCL, WHO, WMO
noun—Guinean(s); adjective—
85
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GUINEA/GUINEA-BISSAU
Legal name: Democratic Republic of Sao Tome
and Principe
Type: republic established when independence
received from Portugal on July 1975; constitution not
yet formulated
Capital: Sao Tome
Legal system: based on Portuguese law system and
customary law; has not accepted compulsory ICJ
jurisdiction
Branches: Da Costa heads the government assisted
by a cabinet of ministers; there is a constituent
assembly composed of 18 members
Government leader: President Manuel Pinto Da
Costa
Suffrage: universal for age 18 and over
Elections: clections were held July 1975 for the
President and Constituent Assembly; future clections
will be determined by new government when
constitution is formulated
Political parties and leaders: Movement for the
Liberation of Sao Tome and _ Principe (MLSTP),
Secretary-General Manuel Pinto Da Costa
Communists: no Communist party, probably a few
Sommunist sympathizers
Member of: OAU, U.N.
Legal name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh; foreign ministry and foreign
diplomatic representatives located in Jiddah
Political subdivisions: 18 amirates
Legal system: largely based on Islamic law, several
secular codes have been introduced; commercial
disputes handled by special committees; has not
accepted compulsory ICJ jurisdiction
Branches: King Khalid (Al Saud, Khalid ibn Abd
al-Aziz) rules in consultation with royal family
(especially Crown Prince Fahd), Council of Ministers,
and religious leaders
Government leader: King Khalid
Communists: negligible
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, IMF, ITU, OAPEC, OPEC, UN,
UNESCO, UPU, WHO, WMO','9034f6eb66875adf01e9a8cf4d81ecdec9b017dce08e0412b58fb6a96e81fdef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88b2a16fc27b71a4d64f602cb3282c6bd7849b763a3b89e86f141024da42df19',1976,'CA','Canada','government',95,'Legal name: Dominion of Canada
Type: federal state recognizing Elizabeth If
sovereign
Capital: Ottawa
Political subdivisions: 10 provinces and 2
territories
Legal system: based on English common law,
except in Quebec, where civil law system based on
French law Prevails: constitution is British North
America Act. of 1867 and Various amendments:
accepts compulsory IC] jurisdiction, with reservations
Branches: federal executive power vested in cabinet
collectively responsible to House of Commons, and
headed by Prime Minister; federal] legislative
authority resides in Parliament consisting of Queen
represented by Governor- General,
Commons; judges appointed by Governor-General on
the advice of the government: Supreme Court is
highest tribunal
Government leader: Pierre Elliott Trudeau
Suffrage: universal Over age 18
Elections: legal limit of 5 years, last election July
1974
Political parties and leaders: Liberal, Pierre
Trudeau; Progressive-Conservatives, Robert Stanfield,
New Democratic, David Lewis; Social Credit, Real
Caouette
Voting strength (1974 election); Liberal 43%
seats}, Progressive Conservative 35% (95 Seats), New
Democratic Party 16% (16 seats), Social Credit 5%
seats), other 1%, Independents hold 1 seat
Communists; 2,000
Member of: ADB, Colombo Plan, Common-
wealth, DAC, FAO, GATT, IAFA, IBRD, ICAO,
32
January 1976
ICRC, IDA, IDB, IFA, IFC, THO, ILO, IMCO, IMF,
IPU, ITU, NATO, OAS (observer), OECD, Seabeds
Committee, ULN,, UNCTAD, UNESCO, UPU,
WCL, WHO, WMO
Legal name: Republic of Cape Verde
Type: republic; achieved independence from
Portugal in July 1975; government being formed;
expected to establish union with Guinca-Bissau
Capital: Praia
Political subdivisions: 10 islands
Legal system: to be determined
Branches: National Assembly, 56 members; the
official party is the supreme political institution
Government leaders: President of the National
Assembly, Abilio Duarte; Prime Minister, Pedro Pires
Suffrage: universal over age 18
Elections: to be determined
Political parties and leaders: Partido Africano da
Independencia da Guinee ¢ Cabo Verde (PAIGC), led
by Aristide Pereira, only legal party
Communists: none known','6046dca9b83b539e00a25163e34a7e66f44d327b089c394e1433fd1e2916fcb0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19986bd38a67c281af193d640803d0f7272104465b2a50f775cb4f87fcea7370',1976,'CF','Central African Republic','government',99,'Legal name; Central African Republic
Type: republic; constitution abrogated following
military coup in January 1966
34
Capital: Bangui
Political subdivisions: 14 prefectures, 47 subpre-
fectures
Legal system: based on French, Islamic, and tribal
law; in 1966 the Chief of State assumed all power and
abrogated the existing constitution; has not accepted
compulsory IC] jurisdiction
Branches: Gen. Bokassa heads government and
rules by decree; assisted by cabinet called Council of
Ministers; judiciary, including Supreme Court, court
of appeals, criminal court, and numerous lower courts
Government leader: President for life Jean-Bedel
Bokassa
Suffrage: universal over age 21
Elections: none have been held under Bokassa
regime
Political parties and leaders: Black African Social
Evolution Movement (MESAN), ruling party under
former regime, still in existence but plays little role,
led by President Jean-Bedel Bokassa
Communists: no Communist Party or significant
number of sympathizers
Member of: AFDB, Conference of Fast and
Central African States, EAMA, ECA. FAO, GATT.
IBRD, ICAO, IDA, ILO, IMF, ITU, OAU, OCAM,
Seabeds Committee, UDEAC, ULN., UNESCO,
UPU, WCL, WHO, WMO','cce7180fbccc440db6f1125c764555a034bc08f7ab37f1ea830119da6b0840d8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aceba18fcbe2cd46f79a69732939352b5f23bbef322c85e1b47e91c6678b3b6c',1976,'TD','Chad','government',103,'Legal name: Republic of Chad
Type: republic; military regime in power since
April 1975
Capital: N''Djamena
Political subdivisions: 14 prefectures
Legal system: based on French civil law system
and Chadian customary law; constitution adopted
1962; constitution suspended and national assembly
dissolved April 1975; judicial review of legislative acts
in theory a power of the Supreme Court; has not
accepted compulsory ICJ jurisdiction .
Branches: executive authority exercised by
Supreme Military Council composed of 9 officers
Government leader: President of Supreme Military
Council, General Felix Malloum
Suffrage: universal over age 20
Elections: all political activity banned
Political parties and leaders: political parties
banned
Communists: no front organizations or un-
derground party; probably a few Communists and
some sympathizers
Other political or pressure groups: lightly armed
Muslim rebel bands have been opposing the
government since October 1965 in east-central and
since August 1969 in northern Chad
Member of: AFDB, Conference of East and
Central African States, EAMA, ECA, FAO, GATT,
ICAO, IBRD, IDA, ILO, IMF, ITU, Lake Chad
Basin Commission, OAU, OCAM, Scabeds Commit-
tee, UEAC, U.N., UNESCO, UPU, WCL, WHO,
WMO
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CHAD/CHILE
Legal name: Republic of Chile
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','ffce7a5d79194b50f4e221063a3cf5b44bc2147814f73cea3e6a71f8c38849dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e81f47fca4703cb5a1d26a3114822283f241d849ebd25b2a4c5dd6a21024b143',1976,'CL','Chile','government',105,'Type: republic
Capital: Santiago
Political subdivisions: reorganization of regional
structure in progress
Legal system: based on Code 1857 derived from
Spanish law and subsequent codes influenced by
French and Austrian law; constitution adopted 1925,
amended since then, currently being revised; judicial
review of legislative acts in the Supreme Court; legal
education at University of Chile, Catholic University,
and several others; has not accepted compulsory IC]
jurisdiction
Branches: President and 4-man Military-Police
Junta; bicameral legislature currently dissolved;
independent judiciary
Covernment leaders: President, Gen. Augusto
Pinochet Ugarte; other Junta members, Adm. Jose
Toribio Merino Castro, Gen. Gustavo Leigh Guzman,
Gen. Cezar Mendoza Duran
Suffrage: universal (except enlisted military and
police) and compulsory at age 18
Elections: none scheduled
Political parties and leaders: Christian Demo-
cratic Party (PDC), Patricio Aylwin and Eduardo
Frei; National Party (PN), Sergio Onofre Jarpa; PDC
and PN are officially in “recess”; Popular Unity
coalition parties (outlawed) — Communist Party
(PCCh), Luis Corvalan (in prison); Socialist Party
(PS), Clodomiro Almeyda and Carlos Altamirano
(both in exile); Radical Party (PR); Christian Left
(IC); United Popular Action Movement (MAPU);
Independent Popular Action (API)
Voting strength (1970 presidential election):
36.6% Popular Unity coalition, 35.3% conservative
independent, 28.1% Christian Democrat; (1973
Congressional election) 44% Popular Unity coalition,
56% Democratic Confederation (PDC and PN)
Communists: 200,000
Other political or pressure groups: organized
labor; business organizations; landowners’ associa-
tions (SNA — Sociedad Nacional de Agricultura);
extreme leftist, Movement of Revolutionary Left
(MIR), outlawed, rightist, Patria y Libertad (PyL),
outlawed
Member of: ECOSOC, FAO, GATT, IADB, IAEA,
IBRD, ICAO, IDA, IDB, IFC, IHO, ILO, IMCO,
IMF, IPU, ITU, LAFTA and Andean Sub-Regional
Group (created in May 1969 within LAFTA), OAS,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WETU, WHO, WMO
Legal name: Peoples Republic of China
Type: Communist state; real authority lies with
Communist party’s political bureau: the National
People’s Congress, in theory the highest organ of
government, in reality merely rubber stamps the
party’s programs; the State Council is the actual
governing organism
Capital: Peking
Political subdivisions: 21 provinces, 3 centrally
governed municipalities, and 5 autonomous regions
Legal system: before 1966, a complex amalgam of
custom and statute, largely criminal: little ostensible
development of uniform code of administrative and
civil law; highest judicial organ is Supreme People''s
Court although legal activity centered in parallel
network of Public Security organs: laws and legal
procedure clearly subordinated to priorities of party
policy; whole system largely suspended during
Cultural Revolution, but gradually being revived
Branches: prior to 1966 control was exercised by
Chinese Communist Party, through State Council,
which supervised more than 50 ministries, commis-
sions, bureaus, etc., all technically under the standing
committee of the National People’s Congress; this
system broke down under ‘Cultural Revolution”
pressures but has been reconsolidated and streamlined
to 29 ministries
Government leader: Premier of State Council,
Chou En-lai; government subordinate to central
committee of CCP, under Chairman Mao Tse-tung
Suffrage: universal over age 18, though this is
academic
Elections: no meaningful elections
Political parties and leaders: Chinese Communist
Party (CCP), headed by Mao Tse-tung; Mao is
Chairman of Central Committee; a new central
committee was formed at the 10th Party Congress
held in August 1973
Voting strength: 100% Communist for practical
purposes; no political nonconformity permitted
Communists: about 28 million party members in
1973
Other political or pressure groups: army (PLA)
remains a major force, although many soldiers who
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CHINA, PEOPLES REPUBLIC OF/CHINA, REPUBLIC OF
acquired a wide range of civil political-administrative
dutics during the Cultural Revolution have been
removed; many veteran civilian officials, in eclipse
since the Cultural Revolution, have been reinstated;
mass organizations, such as the trade unions and the
youth league, have been rebuilt in the provinces;
plans are underway to rebuild the national
organizations
Member of: FAO, IAEA, IBRD, ICAO, IDA, IFC,
IHO, ILO, IMCO, IMF, ITU, Red Cross, Seabeds
Committee, U.N., UNESCO, UPU, WFTU, WHO,
WMO, other international bodies','93da70b523427f49caf69249402b9c2d3b875719e25df7bce606b2af4392e53b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d7a33371f193394a6cb26eaa82d7aea2d0ba4d0a7ac2b7d4d2871bc25435641',1976,'CN','China','government',111,'Legal name: Republic of China
Type: republic; one-party presidential regime
Capital: Taipci
Political subdivisions: 16 counties, 4 cities, 1
special municipality (Taipei)
Legal system: based on civil law system;
constitution adopted 1947, amended 1960 to permit
Chiang Kai-shek to be reelected, and amended 1972
to permit President to restructure certain government
organs; accepts compulsory IC] jurisdiction, with
reservations
Branches: 5 independent branches (executive,
legislative, judicial, plus traditional Chinese functions
of examination and control), dominated by executive
branch; President and Vice President elected by
National Assembly
Government leaders: President Yen Chia-kan;
Premier Chiang Ching-kuo
39
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CHINA, REPUBLIC OF/COLOMBIA
Suffrage: universal over age 20
Elections: national level — legislative yuan every 3
years but no general election held since 1948 election
on mainland (partial election for Taiwan province
representatives December 1969 and December 1972.
next elections due December 1975); local level —
provincial assembly, county and municipal executives
every 4 years: county and municipal assemblies every
‘£ vears
Political parties and leaders: Kuomintang, or
National Party, led by Chairman Chiang Ching-kuo,
has no real opposition; 2 insignificant parties are
Democratic Socialist Party, Young China Party
Voting strength (1972 provincial assembly
election): 58 seats Kuomintang, 13° seats in-
dependents
Other political or pressure groups: none
Member of: expelled from U.N. General Assembly
and Security Council on 25 October 1971 and
withdrew on same date from other charter-designated
subsidiary organs; attempting to retain membership in
international financial institutions','c8e577cd77194ec1ddf7413783246617419809303b25b3c6c95d80ebd4bb7e8f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0819c872760f555e1e6cfaf2162f5394351b36489612985ac62f63cd3d9f11fe',1976,'CO','Colombia','government',115,'Legal name: Republic of Colombia
Type: republic; executive branch dominates
government structure
Capital: Bogota
Political subdivisions: 22 departments, 4 territorial
districts, 4 special districts, 1 federal district
Legal system: based on Spanish law; religious
courts regulate marriage and divorce; constitution
decreed in 1886, amendments codified in 1946 and
1968; judicial review of legislative acts in the Supreme
Court; accepts compulsory ICJ jurisdiction, with
reservations
Branches: President, bicameral legislature,
judiciary
Government leader: President Alfonso Lopez
Michelsen
Suffrage: universal over age 21
Elections: every fourth year; last presidential and
congressional elections April 1974; municipal and
departmental elections, April 1972
Political parties and leaders: Libcral Party,
President Alfonso Lopez Michelsen; Conservative
Party, Alvaro Gomez Hurtado; National Popular
Alliance (ANAPO), Maria Eugenia Rojas de Moreno
Voting strength: 1974 presidential clection —
Alfonso Lopez Michelsen 55%, Alvaro Gomez
Hurtado 82%, Maria Eujenia Rojas de Moreno 9.5%;
1974 congressional clection — Senate: Liberal Party
59%, Combined Conservative Party 34%, ANAPO
6.2%; Chamber of Deputies: Liberal Party 56%,
Combined Conservative Party 31%, ANAPO 9.5%;
abstention by approximately 50% of cligible voters
Communists: 10,000-12,000 members est.
Other political or pressure groups: Communist
Party (PCC), Gilberto Vieira White; PCC/ML,
Chinese Line Communist Party, led by Pedro Lupo
Leon Arboleda Roldan
Member of: FAO, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IFC, IHO, ILO, IMF, ITU, LAFTA and
Andean Sub-Regional Group (created in May 1969
within LAFTA), OAS, U.N., UNESCO, UPU, WCL,
WFTU, WHO, WMO
Legal name: Comoro Islands
Type: three of the four islands comprise a de facto
independent republic, following local government''s
unilateral declaration of independence from France in
july 1975; other island disallowed declaration and its
status is undecided; France supports independence in
principle and is negotiating with Comoran
government on legal transfer of sovereignty
Capital: Moroni
Political subdivisions: 3 prefectures, 3 district
councils
Legal system: French and Muslim law
Branches: supreme authority exercised by I1-
member National Executive Council
Government leader: Said Mohamed Jaffar,
President of National Executive Council
Suffrage: universal adult
Elections: at discretion of Council of Ministers, on
advice of President; must be held before expiration of
3-vear electoral mandate
Political parties and leaders: Comoran Demo-
cratic Union, Mohammed Dahlani; Democratic
Assembly of Comoros People, Said Mohamed Jaffar;
Comoros Socialist Party; Umma, Prince Said Ibrahim;
Mahorais Movement, Marcel Henry
Voting strength: in elections for Chamber of
Deputies in 1972, independence coalition of CDU
and DACP won 34 seats, Mahorais Movement won 5
Communists: information not available
Member of: OAU
Legal name: Peoples Republic of the Congo
Type: republic; military regime established
September 1968
Capital: Brazzaville
Political subdivisions: 9 regions divided into
districts
Legal system: based on French civil law system
and customary law; constitution adopted 1963 and
1969
Branches: President, Prime Minister, Council of
State; National Assembly; judiciary presumably still
functions according to provisions of 1963 constitution;
all policy made by Congolese Workers Party Central
Committee and Politburo
Government leaders: President,; Major Marien
Ngouabi; Prime Minister Henri Lopes
Suffrage: universal over age 18
Elections: last legislative elections June 1973
Political parties and leaders: Congolese Workers
Party (PCT) is only legal party; president, Marien
Ngouabi
Communists: unknown number of Communists
and sympathizers
Other political or pressure groups: Union of
Congolese Socialist Youth (UJSC), Congolese Trade
Union Congress (CSC), Revolutionary Union of
Congolese Union (URFC), General Union of
Congolese Pupils and Students (UGEEC)
Member of: AFDB, Conference of East and
Central African States, EAMA, ECA, EIB (associate),
FAO, GATT, IBRD, ICAO, IDA, ILO, IMF, ITU,
OAU, OCAM, Seabeds Committee, UDEAC, UEFAC,
U.N., UNESCO, UPU, WFTU, WHO, WMO','14a81d442b27b558437dde51870f1fa088492992f82ac871e1f0d49006a1d69f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d50164e313c43bbbd134b40f9f8b1d1cd344770920cfca49ee4e6a4b54a54e2',1976,'CK','Cook Islands','government',119,'Legal name: Cook Islands
44
eee
Pacific Ocean
i " cook
a ISLANDS
Flul ISLANDS aera
Pacific Ocean
(See reference map Vit}
Type: self-governing in “free association” with
action; New Zealand retains responsibility for external
Branches: New Zealand Governor General appoints
High Commissioner of Cook Islands, who represents
the Queen and the New Zealand government; High
Commissioner appoints the Premier; Legislative
Assembly of 22 members, popularly elected; House of
Arikis (chiefs), 15 members, appointed by High
Commissioner, an advisory body only
Government leader: Premier Albert Henry
Suffrage: universal adult
Elections: every 4 years, latest in December 1974
Political parties and leaders: Cook Islands Party,
Sir Albert Henry; Democratic Party, Dr. Thomas
Davis
Voting strength (1974): Cook Islands Party, 14
seats; Democratic Party, 8 seats','759ce1aa1da488f718f1edbecc082dd19384f43b1f3d9d1c1fd429539c36d456','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a653a2929045e9d48c0901096cfd3ea8331651f6c30f050aa4359806c2054019',1976,'CR','Costa Rica','government',123,'Legal name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system;
constitution adopted 1949; judicial review of
legislative acts in the Supreme Court; legal education
at University of Costa Rica; has not accepted
compulsory IC] jurisdiction :
Branches: President, unicameral legislature,
Supreme Court elected by legislature
Government leader: President Daniel Oduber
Suffrage: universal and compulsory age 18 and
over
Elections: cvery 4 years; next, February 1978
Political parties and leaders: National Liberation
Party (PIN), Daniel Oduber, Jose Figucres; National
Unification (UN), Francisco Calderon Guardia;
National Independent Party (PNI), Jorge Gonzalez
Marten; Democratic Reno-vation Party (PRD),
Rodrigo Carazo; Christian Democratic Party (PDC),
Jorge Monge Zamora, Socialist Action Party (PASO)
(Communist front), Marcial Aguiluz; Popular
Vanguard Party (PVP, Communist, illegal), Manuel
Mora
Voting strength (1974 election): National
Unification (coalition of PUN, PR, and PURA),
30.4% — 16 seats; PLN, 43.5% — 97 scats; PNI, 11%
— 6 seats; PRD, 9% — 3 seats, PASO, 2.3% — 2 seats
Communists: 3,200 members, 10,000 sympathizers
Other political or pressure groups: Costa Rican
Confederation of Democratic Workers (CCTD),
General Confederation of Workers (CGT), Chamber
of Coffee Growers, National Association for Economic
Development (ANFE)
Member of: CACM, FAO, [ADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMF, IPU, ITU, OAS,
ODECA, Scabeds Committee, U.N., UNESCO,
UPU, WCL, WFTU, WHO, WMO
Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: the current system of 6
provinces, 59 regions, and 416 municipalities is being
reorganized, and, in March 1976, a new system
consisting of 14 provinces and from 170 to 180
municipalities will be adopted
Legal system: based on Spanish and American law,
with large elements of Communist legal theory;
Fundamental Law of 1959 replaced Constitution of
1940; a new constitution was approved at the Cuban
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CUBA/CYPRUS
Communist Party''s First Party Congress in December
1975 and by a popular referendum to take place
immediately after the Congress; positions of the new
constitution will be put into effect on February 24,
1976, by means of a Constitutional Transition Law,
and the entire constitution will become effective on
December 2, 1976; legal education at Universities of
Ilavana, Oriente, and Las Villas; does not accept
compulsory ICJ jurisdiction
Branches: executive; no legislature (Popular
Assemblies will be formed at the provincial and
municipal levels in October 1976 and at the national
level on December 2, 1976—the Popular Assemblies
will have legislative authority at their respective
levels); controlled judiciary
Covernment leader: Prime Minister Fidel Castro
Ruz
Suffrage: under the new constitution to be adopted
in 1976, suffrage will be universal, but not
compulsory, over age 16
Elections: clection of delegates to the Popular
Assemblies will be held in late summer 1976
Political parties and leaders: Cuban Communist
Party (PCC), First Secretary Fidel Castro Ruz, Second
Secretary Raul Castro Ruz
Communists: approx. 200,000 party members
Member of: CEMA, ECLA, FAO, GATT, IADB
(nonparticipant), ICAO, IHO, ILO, IMCO,
International Rice Commission, International Sugar
Council, International Wheat Agreement, ITU, OAS
(nonparticipant), Permanent Court of Arbitration,
Postal Union of the Americas and Spain, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WFTU,
WHO, WMO','0a959ccafdc7d41960d64893209ac74a3d6ca046813e81ec01306b7d1810401b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29fafd5d5786fe39bd9ec64da8d746492c5c4197e1095129cac14886eab8d38e',1976,'CY','Cyprus','government',127,'Legal name: Republic of Cyprus
_ Type: republic since August 1960; separate de facto
Greek Cypriot, and Turkish Cypriot governments
have evolved since outbreak of communal strife in
1963; this separation was further solidified following
the Turkish invasion of the island in July 1974;
negotiations, which have been going on since January
1975, have focused on the creation of a federal system
of government with substantial autonomy for each of
the two communities
Capital: Nicosia
Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil
law modifications; negotiations to create the basis for
a new or revised constitution to govern the island and
relations between Greek and Turkish Cypriots have
been going on intermittently
Branches: currently a rump government consisting
basically of Greck Cypriot parts of bodies provided for
by constitution; headed by President of the Republic
and comprised of Council of Ministers, House of
Representatives, and Supreme Court
Government leaders: President, Archbishop
Makarios II] (Greek); Vice President, Rauf Denktash
(Turk)
A8
Suffrage: universal age 21 and over
Elections: held every 5 years; 1965 elections
suspended; 1968 elections only for President and Vice
President; 1970 parliamentary elections demonstrate
notable increase in voting strength of Communist
Party (AKEL); 1973 elections only for President and
Vice President
Political parties and leaders: Reform Party of the
Working People (AKEL) (Communist Party), Ezekias
Papaioannou; Unified Party (UP), Glafkos Clerides:
Progressive Movement (PM) (pro-Makarios), Andreas
Azinas; Democratic National Party (DEK), Takis
Fvdokas; United Democratic Union of the Center
(EDEK), Vassos Lyssarides: Turkish National Union
Party (TNUP), Rauf Denktash; Populist Party, Alpet
Othon
Voting strength: (1968 presidential and vice
presidential elections) Greek Cypriot President
Makarios 90%; Turkish Cypriot Vice President Fazil
Kucuk unopposed; (1970 parliamentary elections)
40% of Greek Cypriot vote for Reform Party of the
Working People, 24% of the Greek Cypriot vote for
the Unified Party, 16% of the Greek Cypriot vote for
the Progressive Movement, 9% of the Greek Cypriot
vote for the Democratic National Party as well as 9%
for the United Democratic Union of the Center, 2% of
the Greek Cypriot vote for independents; 76% of the
Greek Cypriot electorate voted; 80% of the Turkish
Cypriot community voted and overwhelmingly
elected 15 of Rauf Denktashs supporters to the Turk
Cypriot House contingent in a separate election; 1973
clections — Makarios unopposed and Rauf Denktash
unopposed
Communists: 12,000; sympathizers estimated to
number 60,000
Other political or pressure groups: United
Democratic Youth Organization (EDON) (Com-
munist-controlled); Pan Cyprian Confederation of
Labor (PEO) (Communist-controlled); Cyprus
Confederation of Labor (SEK) (pro-West): Cyprus
Turkish Federation of Trade Unions (KTBIF)
Member of: Commonwealth, Council of Europe,
FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMF, ITU, Seabeds Committee, U.N., UNESCO,
UPU, WCL, WFTU, WHO, WMO
Legal name: Czechoslovak Socialist Republic
Type: Communist state
Capital: Prague
Political subdivisions: 2 ostensibly separate and
autonomous republics (Czech Socialist Republic and
Slovak Socialist Republic); 7 regions (kraj) in Czech
lands, three regions in Slovakia; national capitals of
Prague and Bratislava have regional status
Legal system: civil law system based on Austrian-
Hungarian codes, modified by Communist legal
theory; revised constitution adopted 1960, amended
in 1968 and 1970; no judicial review of legislative
acts; legal education at Karlova University School of
Law; has not accepted compulsory ICJ jurisdiction
Branches: executive —- President (elected by
Federal Assembly), cabinet (appointed by President);
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CZECHOSLOVAKIA/DAHOMEY
legislative — Federal Assembly (elected directly),
Czech and Slovak National Councils (also elected
directly) legislate on limited area of regional matters;
judiciary — Supreme Court (elected by Federal
Assembly); entire governmental structure dominated
by Communist Party
Government leaders: President Gustav Husak
(elected May 1975), Premier Lubomir Strougal
Suffrage: universal over age 18
Elections: governmental bodies every 5 years (last
election, November 1971); President every 5 years
(Husak was elected to replace the incapacitated
President Ludvik Svoboda who did not complete his
second five year term)
Dominant political party and leader: Communist
Party of Czechoslovakia (KSC), Gustav Husak,
General Secretary; Communist Party of Slovakia
(KSS) has status of “provincial KSC organization
Voting strength (1971 election): 99.81% Com-
munist-sponsored single slate
Communists: 1.35 million party members
Other political groups: puppet parties —
Czechoslovak Socialist Party, Czechoslovak People’s
Party, Slovak Freedom Party, Slovak Revival Party
Member of: CEMA, FAO, GATT, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
Seabeds Committee, U.N., UNESCO, UPU, Warsaw
Pact, WFETU, WHO, WMO
Legal name: Peoples Republic of Benin
Type: republic, under military rule since 26
October 1972
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 provinces, 46 districts
Legal system: based on French civil law and
customary law; legal education generally obtained in
France; has not accepted compulsory IC} jurisdiction
Branches: executive and legislative power vested in
13-man military revolutionary government headed by
a president
Government leader: Lt. Col. Mathieu Kerekou,
President and chief of government, charged with
national defense, planning, coordination of external
aid, information, and national orientation
Suffrage: universal for adults whenever elections or
referendums are held
Elections: current government has held no
elections and none are scheduled
Political parties: none
Communists: no Communist party; some sympa-
thizers
Member of: AFDB, CEAO, EAMA, ECA,
ECOWAS, Entente, FAO, GATT, IBRD, ICAO, IDA,
Approved For Release 2005/04/22
ILO, IMF, ITU, Niger River Commission, OAU,
OCAM, Seabeds Committee, U.N., UNESCO, UPU,
WCL, WFTU, WHO, WMO','b92469eb4dccd68e6b257db702208ebceabdc1c71b51d688f2da358302ca15d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e00d3b59d74a12a3b386f41bcdc51dec26e0c8bc7c6f20b11318210772eb887',1976,'DK','Denmark','government',131,'Legal name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes,
88 towns
Legal system: civil law system: constitution
adopted 1953; judicial review of legislative acts; legal
education at Universities of Copenhagen and Arhus;
accepts compulsory IC] jurisdiction, with reservations
Approved For Release 2005/04/22
Branches: legislative authority rests jointly with
Crown and parliament (Folketing); executive power
vested in Crown but exercised by cabinet responsible
to parliament; Supreme Court, 2 superior courts, 106
lower courts
Government leaders: Queen Margrethe II; Prime
Minister, Anker Jorgensen
Suffrage: universal, but not compulsory, over age
21
Elections: on call of prime minister but at least
every four years (last election 9 January 1975)
Political parties and leaders: Social Democratic,
Anker Jorgensen; Moderate Liberal, Poul Hartling;
Conservative, Poul Schluter;. Radical Liberal, Hilmar
Baunsgaard; Socialist Peoples, Gert Petersen;
Communist, Knud Jespersen; Left Socialist, Preben
Wilhjelm and Steen Folke; Center Democratic,
Erhard Jakobsen; Progressive, Mogens Glistrup;
Christian People’s, Jens Miller; Justice, Ib Christensen
Voting strength (1975 election): 30.0% Social
Democratic, 23.3% Moderate Liberals, 13.6%
Progressive, 7.1% Radical Liberal, 5.5% Conservative,
5.3% Christian Peoples, 4.9% Socialist Peoples, 4.2%
Communist, 2.2% Center Democratic, 3.9% other
Communists: 7,500-8,000; a number of sympa-
thizers, as indicated by 110,809 Communist votes cast
in 1978 elections
Member of: ADB, Council of Europe, DAC, EC,
EEC, ELDO (observer), EMA, ESRD, EURATOM,
FAO, GATT, IAEA, IBRD, ICAO, IDA, IEA, IFC,
THO, ILO, IMCO, IMF, IPU, ITU, NATO, Nordic
Council, OECD, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Colony of the Falkland Islands
Type: British crown colony
Capital: Stanley
Political subdivisions: local government is
confined to capital
Legal system: English common law
Branches: Governor, Executive Council, Legisla-
tive Council
Government leader: Governor and Commander in
Chief Ernest G. Lewis (also High Commissioner for
British Antarctic Colony)
Suffrage: universal','90adfd213ee2e7d22961c691bd19bbc30d2b9ce4901690d2862e0cb634da61e9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed46a7cc8bf1316cf3666c406c7f1972b4cb3e13bb2394540176343ba753c2ba',1976,'DM','Dominica','government',135,'Legal name: State of Dominica
Type: dependent territory with full internal
autonomy as a British “Associated State”
Capital: Roscau
Political subdivisions: 10 parishes
Legal system: based on English common law; three
local magistrate courts and the British Caribbean
Court of Appeals
Branches: legislature, 11 member popularly elected
House of Assembly; executive, cabinet headed by
Premicr
Government leaders: Premier Patrick John; U.K.
Governor Sir Louis Cools-Lartigue
Suffrage: universal adult suffrage over age 18
Elections: every 5 years; most recent March 1975
53
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
DOMINICA/DOMINICAN REPUBLIC
Political parties and leaders: Dominica Labor
Party (DLP), Patrick John; Dominica Freedom Party
(DFP), Miss M. Eugenia Charles (unofficial)
Voting strength: House of Assembly seats—DFP 3
seats, DLP 16 seats, independent.2 seats
Communists: negligible
Member of: CARICOM, WCL','1a3cf0a8185338b8c8d657da9219d89473dba9f5aea6a909f72f1a9c35ac70da','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22d5417fd71753f5381d2271916cedb906885c72dfde629f9429143e5aca7aef',1976,'DO','Dominican Republic','government',139,'Legal name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 provinces and the
National District
Legal system: based on French civil codes; 1966
constitution
Branches: President popularly elected for a 4-year
term; bicameral legislature consisting of Senate (27
seats) and Chamber of Deputies (74 seats) elected for
4-year terms; members of Supreme Court elected by
Senate
Government leader: President Joaquin Balaguer
Suffrage: universal and compulsory, over age 18 or
married, except members of the armed forces and
police, who cannot vote
Elections: national, last election May 1974, next
election May 1978
Political parties and leaders: Reformist Party
(PR), Joaquin Balaguer; Dominican Revolutionary
Party (PRD), Francisco Pena Gomez, Secundino Gil
Morales; Dominican Liberation Party (PLD), Juan
Bosch, Democratic Quisqueyan Party (PQD), Elias
Wessin y Wessin; Revolutionary Social Christian
Party (PRSC), Rogelio Delgado Bogaert; Movement
for National Conciliation (MNC), Jaime Manuel
Fernandez Gonzalez: Anti-reelection Movement of
Democratic Integration (MIDA), Francisco Augusto
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
DOMINICAN REPUBLIC/ECUADOR
Lora; National Civic Union (UCN), Guillermo
Delmonte Urraca; Popular Democratic Party (PDP),
Luis Tajara Burgos; Fourteenth of June Revolutionary
Movement (MR-1J4), split into several factions,
illegal; Dominican Communist Party (PCD), central
committee, illegal; Dominican Popular Movement
(MPD), illegal; 12th of January National Liberation
Movement (ML-12E), Plinio Matos Moquete, illegal;
Communist Party of the Dominican Republic
(PCRD), Luis Montas Gonzalez, illegal, Popular
Socialist Party (PSP), illegal
Voting strength (1974 election): 85% PR, 15%
PDP, all other parties abstained
Communists: an estimated 1,500 to 1,800 members
in six different factions; effectiveness limited by
ideological differences and organizational inade-
quacies
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, THO, ILO, IMCO, IMF,
ITU, OAS, Seabeds Committee, U.N., UNESCO,
UPU, WCL, WHO, WMO','05cdd5e27b52d8ff8e3af1d2abb179983d0e277c485c0712aa4aa73a0a6cea8d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a97e1ac228dc9af5897b4d2a7d82bedcae99d817bb6ebfbb39efc6245463842',1976,'EC','Ecuador','government',143,'Legal name: Republic of Ecuador
Type: republic; under military regime since
February 1972
Capital: Quito
Political subdivisions: 20 provinces including
Galapagos Islands
Legal system: based on civil law system; modified
1945 constitution re-instituted in February 1972; legal
education at 4 state and 2 private universities; has not
accepted compulsory IC] jurisdiction
Branches: President and Government Council
assumed power February 1972; government decisions
announced by decree over the president’s signature;
judiciary system supervised by Supreme Court: six
special tribunals established in July 1972
Government leader: President, General Guillermo
Rodriguez Lara
Suffrage: universal for literates over age 18
Elections: none scheduled
Political parties and leaders: National Velasquista
Front, personalistic, Jose Maria Velasco Ibarra (in
exile); Radical Liberal Party, Ignacio Hidalgo
Villavicencio; Social Christian Party, generally
conservative, Camilo Ponce; Conservative Party, Galo
Pico Mantilla; Concentration of Popular Forces,
populist, Assad Bucaram; National Revolutionary
Party, leftist, Carlos Julio Arosemena
Voting strength: in June 1968 national elections,
Velasquistas, a center-left coalition, and a rightist
coalition each got approximately one-third
Communists: Communist Party of Ecuador (PCE,
pro-Moscow, Pedro Saad — secretary-general), 500
members plus an estimated 3,000 sympathizers;
Communist Party of Ecuador (PCE/ML, pro-Peking),
100 members; Revolutionary Socialist Party of
Fcuador (PSRE), 200 members
Member of: ECOSOC, FAO, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, IHO, ILO, IMCO, IMF,
{TU, LAFTA and Andean Sub-Regional Group
(formed in May 1969 within ILAFTA), OAS, OPEC,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WFTU, WHO, WMO
56
Legal name: Arab Republic of Egypt
Approved For Release 2005/04/22
Type: republic; under presidential rule since June
1956
Capital: Cairo
Political subdivisions: 25 governorates
Legal system: based on English common law,
Islamic law, and Napoleonic codes; permanent
constitution written in 1971; judicial review of limited
nature in Supreme Court, also in Council of State
which oversees validity of administrative decisions;
legal education at Cairo University, accepts
compulsory ICJ jurisdiction, with reservations
Branches: executive power vested in President, who
appoints cabinet; People’s Assembly has little actual
power (serves mainly for discussion and automatic
approval); independent judiciary administered by
Minister of Justice
Government leader: President Anwar Sadat
Suffrage: universal over age 18
Elections: clections to People’s Assembly every 5
years (most recent October 1971); presidential
elections every 6 years (next scheduled in 1976)
Political parties and leaders: political parties
banned except for the government-sponsored
sociopolitical grouping, Arab Socialist Union (ASU)
Communists: approximately 500, party members
Member of: AAPSO, AFDB, Arab League, FAO,
GATT, IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO,
IMCO, IMF, IPU, ITU, OAPEC, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO,
WPC','05530baac23612684a84dbbac9e08695041271bcded3b9fcbc510ba4bbcac85b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ada5df49e6cd1bd5824b2992c7088d6814ee47d69ba2582fdae0832b50f1495f',1976,'SV','El Salvador','government',147,'Legal name: Republic of E] Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of
common law; constitution adopted 1962; judicial
review of legislative acts in the Supreme Court; legal
education at University of El Salvador: accepts
compulsory [CJ jurisdiction, with reservations
Branches: traditionally dominant executive, fairly
independent unicameral legislature, Supreme Court
Government leader: President Arturo Armando
Molina
Suffrage: universal over age 18
Elections: legislative elections every 2 years;
presidential elections every 5 years; presidential
elections March 1977, legislative and municipal
elections March 1976
Political parties and leaders: National Concilia-
tion Party (PCN), President Arturo A. Molina:
Christian Democratic Party (PDC), Juan Ramirez
Rauda, Dr. Pablo Mauricio Alvergue, Jose Napoleon
Duarte; Salvadoran Popular Party (PPS), Benjamin
Wilfredo Navarrete, Roberto Quinonez Meza, Dr.
Jose Antonio Guzman; Communist Party of El
Salvador (PCES), illegal, Jorge Shafick Handal:
National Revolutionary Movement (MNR), Dr,
Guillermo Manuel Ungo; National Democratic
Union Party (PUDN), Communist Front, Jorge
Shafisk Handal, Francisco Roberto Lima, Julio
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
EL SALVADOR/EQUATORIAL GUINEA
Ernesto Contreras, Julio Castro Belloso; Independent
Democratic United Front (FUDI), Gen. Jose A.
Medrano, Raul Salaverria
Voting strength: February 1972 presidential
election — PCN 43.4%, PDC, PUDN, and MNR
coalition, 42.1%; FUDI, 12.3%; PPS 2.2%; March
1974 legislative election — PCN, 36 seats; PDC,
MNR, and PUDN coalition, 15 seats; FUDI, 1 seat
Communists: 100 to 200 active members;
sympathizers, 5,000
Other political or pressure groups: the military;
about 100 prominent families; General Confederation
of Trade Unions (CGS); Unifying Federation of
Salvadoran Trade Unions (FUSS), Communist
dominated; Federation of Construction and Transport
Workers Unions (FESINCONSTRANS), independ-
ent: Catholic Church; Salvadoran National Associa-
tion of Educators (ANDES)
Member of: Central American Common Market
(CACM), FAO, IADB, IAFA, IBRD, ICAO, IDA,
IDB, IFC, ILO, IMF, ITU, OAS, ODECA, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WFTU,
WHO, WMO','659e38cc6aced61a09b090cf3501140262f7beecb22fda7a229ace7783870831','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d9612233d429b778d6e10b64925cb440152b9a071fbec635ea91c6dae983bf1',1976,'ET','Ethiopia','government',151,'Organized labor: 60,000 registered labor union
members
Legal name: Ethiopia
adjective—
Type: under military rule since mid-1974;
monarchy abolished in March 1975, but republic not
yet declared
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred
to as regional administrations)
Legal system: complex structure with civil, Islamic,
common and customary Jaw influences; constitution
suspended September 1974; military leaders have
promised a new constitution but established no time
frame for its adoption; legal education at Haile
Selassie 1 University; has not accepted compulsory CJ
jurisdiction
Branches: effective powe exercised by Provisional
Military Administrative Council (MAC), an
unorganized group of about 110 young officers and
enlisted men; predominantly civilian cabinet is
ineffectual and holds office at suffrance of military;
Approved
p For Release 2005/04/22 : CIA-RDP79-01051A00080001
0001-8
legislature dissolved September 1974; judiciary at
higher levels based on Western pattern, at lower levels
on traditional pattern, without jury system in either
Government leader: Brigadier General Teferi
Benti, Chairman of the Military Administrative
Council
Suffrage: universal over age 21
Elections: lower house of Parliament election in
June 1973
Political parties and leaders: only amorphous
reform groups especially among younger, better
educated Ethiopians
Communists: none
Other political or pressure groups: some dissident
ethnic groups, most important of which are Eritrean
Liberation Front and Popular Liberation Front,
separatist groups operating in northeastern Ethiopia
Member of: AFDB, ECA, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, 1PU, ITU, OAU, ULN.,
UNESCO, UPU, WCL, WHO, WMO
Legal name: The Faerve Islands
Type: self-governing Province within the Kingdom
of Denmark; 2 representatives in Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, |
Legal system: based on Danish law; Home Rule
Act enacted 1948
Branches: legislative authority rests jointly with
Crown, acting through appointed High Commis-
sioner, and provincial parliament (Lagting) in matters
of strictly Faeroese concern; executive power vested in
Crown, acting through High Commissioner, but
exercised by provincial cabinet responsible to
provincial parliament
Government leaders: Queen Margrethe II; Prime
Minister, Atli Dam; Danish Governor, Leif Groth
Suffrage: universal, but not compulsory, over age
2]
Elections: held every 4 years; next election 1979
Political parties and leaders; Peoples, Hakun
Djurhuus; Republican, Erlendur Patursson; Home
Rule, Samuel Petersen; Progressive, Kjartan Mohr;
Social Democratic, Atli Dam, Union, Kristian
Djurhuus
Voting strength (1975 election): Social Demo-
cratic 25.8%, Republican 22.5%, Peoples 20.5%,
Union 19, 1%, Home Rule 7.2%, Progressive 2.5%
Communists: insignificant number
Member of: Nordic Council','a0718bc308a41a231d65c8a832bafee5e47005c4e2c03e4df2edbbbd8e8340ac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a89f3a6d3ad2f3d0c0431962f62e1fb8ea5bd7e715ce7d04d1c5a18e43b7017e',1976,'FJ','Fiji','government',155,'Legal name: Dominion of Fiji
Type: independent state within Commonwealth;
Elizabeth I recognized as head of state
64
Approved For Release 2005/04/22 :
Capital: Suva
Political subdivisions: 14 provinces
Legal system: based on British
Branches; executive — Prime Minister; legislative
~~ 52-member House of Representatives: Alliance
Party 33 seats, National Federation Party 19 seats
Government leader: Prime Minister Ratu Sir
Kamisese Mara
Suffrage: universal adult
Elections: every 5 years unless House dissolves
earlier, last held March-April 1972
Political parties: Alliance, primarily Fijian, headed
by Ratu Mara; National Federation, primarily
Indian, headed by S. M. Koya
Communists: few, no figures available
Member of: ADB, Colombo Plan, Commonwealth,
FAO, GATT (de facto), IBRD, ICAO, IDA, IMF,
ITU, Seabeds Committee, U.N., UPU, WHO','81220bca689c62fff2aef234e98671d31fc7c22b3814f6b095d4b8583e391557','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ea8f46a4609322ac2ce7661bf60e66d8495ec6ad84461f697e7815b6b83e5c8',1976,'FI','Finland','government',159,'Legal name: Republic of Finland
Type: republic
Capital: Helsinki
Political subdivisions: 12 provinces; 443 com-
munes, 78 towns
Legal system: civil law system based on Swedish
law; constitution adopted 1919; Supreme Court may
request legislation interpreting or modifying laws;
legal education at Universities of Helsinki and Turku;
accepts compulsory IC] jurisdiction, with reservations
Branches: legislative authority rests jointly with
President and parliament (Eduskunta); executive
power vested in President and exercised through
cabinet responsible to parliament; Supreme Court, 4
superior courts, 193 lower courts
Government leader: President Urho K. Kekkonen;
Prime Minister Keijo Liinamaa
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in
1979); presidential, every 6 years (extraordinary
parliamentary legislation extended President Kek-
konens term, which normally expires in 1974, to 1978)
Political parties and leaders: Social Democratic,
Rafael Paasio; Center, Johannes Virolainen; Peoples
Democratic League (Communist front), Ele Alenius;
Conservative, Harri Holker; Liberal, Pekka Tarjanne;
Swedish Peoples Party, Kristan Gestrin; Rural, Veikko
Vennamo; Finnish People’s Unity Party, Eino
Haikala; Communist, Aarne Saarinen
Voting strength (1975 election): 25% Social
Democratic, 18.4% Conservative, 19.0% Peoples
Democratic League, 17.7% Center, 3.6% Rural, 4.7%
Swedish Peoples, 4.4% Liberals, 3.3% Christian
Peoples
Communists: 47,000; an additional 65,000 persons
belong to Peoples Democratic League; a further
number of sympathizers, as indicated by 421,000
votes cast for Peoples Democratic League in 1970
elections
Member of: ADB, CEMA (special cooperation
agreement), DAC, EC (free trade agreement), EFTA
(associate), FAO, GATT, IAEA, IBRD, ICAO, IDA,
IFC, IHO, ILO, IMCO, IMF, {PU, ITU, Nordic
Council, OECD, Seabeds Committee, U.N.,
UNESCO, UPU, WFTU, WHO, WMO','651567b2fa2e3639d8829ed60c0a5d6c200076bf2495761c5f2957b4960bdee4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5b85cbbf7569156d0f68844d62a7d7db53b0b15e96ab13664fa4fb1ac0cbb31',1976,'FR','France','government',163,'Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 95 metropolitan depart-
ments, 21 regional economic districts
Legal system: civil law system with indigenous
concepts; new constitution adopted 1958, amended
concerning election of President in 1962; judicial
review of administrative but not legislative acts; legal
education at over 25 schools of law
Branches: presidentially appointed Prime Minister
heads Council of Ministers, which is formally
responsible to National Assembly; bicameral
legislature — National Assembly (490 members),
Senate (283 members) restricted to a delaying action;
judiciary independent in principle
Government leader: President Valery Giscard
d’ Estaing
Suffrage: universal over age 18; not compulsory
Elections: National Assembly — every 5 years, last
election March 1978, direct universal suffrage, 2
ballots; Senate — indirect collegiate system for 9
years, renewable by one-third every 3 years; President
_ direct, universal suffrage every 7 years, 2 ballots,
last election May 1974
Political parties and leaders: Union of Democrats
for the Republic (UDR), Jacques Chire; Independent
Republicans (IR), Valery Giscard d'' Estaing;
Communist (PCF), George Marchais; Progress and
Modern Democracy (PDM), Jacques Duhamel; Left
Radical Party, Robert Fabre; Center Democratic
Party, Jean Lecanuet, Radical Socialists and
Reformers, Gabriel Peronnet; Socialist Party, Francois
Mitterrand; Unified Socialist Party (PSU), Michel
Mousel
Voting strength (first ballot, 1974 election): 43.2%
Communist Socialist Alliance, 32.6% IR, 15.1% UDR,
9.1% other
Communists: 250,000-300,000 (est. ); Communist
voters, 5 million average
Other political or pressure groups: Communist-
controlled Jabor union (Confederation Generale du
Travail) nearly 1,500,000 members (est.), National
Council of French Employers (Conseil National du
Patronat Francais — CNPF or Patronat)
Member of: ADB, Council of Europe, DAC, EC,
ECSC, EEC, EIB, ELDO, EMA, ESRO, EURATOM,
FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC,
1HO, ILO, IMCO, IMF, 1PpU, ITU, NATO
(signatory), OAS. (observer), OECD, Seabeds
Committee, South Pacific Commission, ULN.,
UNESCO, UPU, WCL, WEU, WFTU, WHO,
WMO','32d98653633bd8b5a9b124826049db60ede4020d2a88ea09b9f7e7b77f6857f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('914adab50f73cf700b7ef2dc604e51ecb9c00ac0f90484c026539e5a2586d162',1976,'GF','French Guiana','government',167,'Legal name: Overseas Department of French
Guiana
Type: overseas department and region of France;
represented by one deputy in French National
Assembly and one senator in French Senate
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19
communes each with a locally elected municipal
council
Legal system: French legal system; highest court is
Court of Appeal based in Martinique with jurisdiction
over Martinique, Guadeloupe, and French Guiana
Branches: executive: prefect appointed by Paris:
legislative: popularly elected 16-member General
Council and a Regional Council composed of
members of the local General Council and of the
locally elected deputy and senator to the French
parliament; judicial, under jurisdiction of French
judicial system
Government leader: Prefect Herve Bourseiller
Suffrage: universal over age 18
Elections: General Council elections coincide with
those for the French National Assembly, normally
every 5 years; last election March 1973; local elections
last held September 1973 last French presidential
election in May 1974
Political parties and leaders: Parti Socialiste
Guyanais (PSG), Leopold Heder, Senator; Union du
Peuple Guyanaise (UPG), weak leftist allied with, but
also reported, to have been absorbed by the PSG;
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FRENCH GUIANA/FRENCH POLYNESIA
Union of Democrats for the Republic (UDR), Hector
Rivierez, delegate to French National Assembly
Communists: Communist party membership
negligible
Member of; WCL, WFTU','59819bf5957f53ca67c6c4ff3915968cb1720f54d7011fed17071a7a8f6a80f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7bc8b4b1dcab2e23350503db7241584e46d3f54855548d390cbffff7022353a',1976,'PF','French Polynesia','government',171,'Legal name: Territory of French Polynesia
Type: overseas territory of France, administered by
French Ministry for Overseas Territories
Capital: Papeete
Political subdivisions: 5 districts
Legal system: based on French; lower and higher
courts
Branches: 30-member Territorial Assembly,
popularly elected; 5-member Council of Government,
elected by Assembly; popular election of one deputy
to National Assembly in Paris, also one Senator
Government leader: Pierre Angeli, Governor,
appointed by French government
Suffrage: universal adult
Elections: every 5 years
Political parties and leaders: Pupu Here Aia,
Senator Pouvanna a Oopa, John Teariki; Te E’a Api,
Francis Sanford; Union Tahitienne-Union pour la
Defense de la Republique, Te Autahoera’a
Legal name: Overseas Territory of Afars and Issus
Type: overseas territory of France; represented by
one deputy in French National Assembly and by one
senator in French Senate
Capital: Djibouti
Legal system: based on French civil law system,
traditional practices and Islamic law
Branches: President of Council of Government; 8-
member Council of Government appointed by 40-
member Chamber of Deputies; ultimate political
authority exercised by Paris-appointed President of
the Council of Government, sometimes referred to as
Prime Minister
Government leader: Ali Aref Bourhan
Suffrage: universal
Elections: Chamber of Deputies election held
November 1973
Political parties and leaders: Rassemblement
Democratique Afar, Ali Aref Bourhan: Union
Democratique Afar; Union Populaire Africaine:
Union Democratique Issa, Oman Farah Iltireh:
African People’s League, Hassan Gouled
Communists: possibly a few sympathizers
Legal name: Overseas Territory of New Caledonia
Type: French overseas territory; represented in
French parliament by one deputy and one Senator
Capital: Noumea
Political subdivisions: 4 islands or island group
dependencies — Isle of Pines, Loyalty Islands, Huon
Islands, Island of New Caledonia
Legal system: French law
Branches: administered by Governor, who is also
High Commissioner for France in the Pacific;
responsible to French Ministry for Overseas France
and Governing Council; Assemblee Territoriale
Government leader: Jean Risterucci, Governor and
French High Commissioner
Suffrage: restricted (1957 election roll listed 32,370
males and females over 21 years of age, of whom
18,964 were classed as indigenous inhabitants)
Elections: Assembly elections in 1972
Political parties: Union Caledonienne, Entente
Democratique et sociale, Union Multiraciale,
Mouvement Liberal Caledonien, Union Democra-
tique, Mouvement Populaire Caledonien
Voting strength (1972 election): Union Caledoni-
enne, 12 seats; Entente Sociale et Democratique, 6
seats; Union Multiraciale, 5 seats; Mouvement
Liberal Caledonien, 5 seats; Union Democratique, 4
seats; Mouvement Populaire Caledonien, 2 seats;
Caledonie Francaise, | seat
Communists: number unknown; Union Caledoni-
enne strongly leftist; some politically active
Communists were deported during 1950''s; small
number of North Vietnamese
Other political parties and pressure groups:
several lesser parties
Member of: EIB (associate), WFTU
Legal name: New Hebrides Condominium
Type: Anglo-French condominium
Capital: Vila
Political subdivisions; 4 administrative districts
Legal system: 3 sets of courts; one each for French
and British subjects, one for New Hebrides native
affairs
Branches: Advisory Council of 30 members with no
real legislative powers, majority elected
Government leader: two resident commissioners,
one French, one British
Political parties and leaders: New Hebrides
National Party, founded 1971, chairman, Walter Lini','b0c60828aa63e9ee006071eaf1a898675154889d54763e267a0093dd2a1cb101','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47bf2e8ccaa2e1537e765c41cd4392bc4d80564f4f46a253f101fb0553eeb0f7',1976,'GA','Gabon','government',175,'Legal name: Gabonese Republic
Type: republic; one-party presidential regime since
1964
Capital: Libreville
Political subdivisions: 9 regions, 6 communes,
4,500 villages
Legal system: based on French civil law system
and customary law; constitution adopted 1961,
judicial review of legislative acts in Constitutional
Chamber of the Supreme Court; legal education at
Center of Higher and Legal Studies at Libreville;
compulsory ICJ jurisdiction not accepted
Branches: power centralized in President, elected
by universal suffrage for 7-year term; unicameral 70-
member National Assembly has limited powers;
judiciary
Government leader: President Omar Bongo
Suffrage: universal over age 21
Elections: Presidential and parliamentary elections
last held February 1973
Political parties and leaders: Gabonese Demo-
cratic Party (PDG) led by President Bongo is only legal
party
Communists: no organized party; probably some
Communist sympathizers
Member of: AFDB, Conference of East and
Central African States, EAMA, EIB (associate), FAO,
GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF,
IPU, ITU, OAU, OCAM, OPEC, UDEAC, U.N.,
UNESCO, UPU, WHO, WMO','ca812a11d2f9b4f72be3e56a8ff94397adab628258955d33002e8b890f9d07b2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6743c2b8a739ec07fadb814b87acc4c55908976b98a4f246e8def45c354f6efc',1976,'GM','Gambia','government',179,'Legal name: Republic of The Gambia
Type: republic; independent since February 1965
Capital: Banjul
Political subdivisions: Banjul and 5 divisions
Legal system: based on English common law and
customary law; constitution came into force upon
independence in 1965, new republican constitution
adopted in April 1970; accepts compulsory ICJ
jurisdiction, with reservations
Branches: cabinet of 10 members; 41-member
House of Representatives, in which 4 seats are reserved
for chiefs, 4 are appointed, 32 are filled by election for
5-year terms, a Speaker is elected by the House, and
the Attorney General is an ex officio. member;
independent judiciary
Government leader: Dawda K. Jawara, President
Political parties and leaders: People’s Progressive
Party (PPP), Secretary General Dawda K. Jawara, and
United Party (UP), John Forster
noun—Gambian(s); adjective—
: CIA-RDP79-01051A000800010001-8
ih T ATTT''™!
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GAMBIA/GERMANY, EAST
Suffrage: universal adult
Elections: general elections held March 1972; PPP
28 seats, UP 3 seats, 1 independent seat
Communists: insignificant number
Member of: AFBD, Commonwealth, ECA, FAO,
GATT, IBRD, IDA, IMF, OAU, ULN., WCL, WFTU,
WHO
Legal name: German Democratic Republic
Type: Communist state
Capital; East Berlin (not officially recognized by
U.S., U.K., and France, which together with the
U.S.S.R. have special rights and responsibilities in
Berlin)
Political subdivisions: (excluding East Berlin) 14
districts (Bezirke), 218 counties (Kreise), 7,643
communities (Gemeinden)
Legal system: civil law system modified by
Communist legal theory; new constitution adopted
1968 by approx. 95% of the voters in national
(referendum); court system parallels administrative
divisions; no judicial review of legislative acts; legal
73
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GERMANY, EAST/GERMANY, WEST
education at Universities of Berlin, Leipzig, Halle and
Jena; has not accepted compulsory ICJ jurisdiction;
more stringent penal code adopted 1968
Branches: legislative — Volkskammer (elected
directly); executive — Chairman of Council of State,
Chairman of Council of Ministers, Cabinet (approved
by Volkskammer); judiciary — Supreme Court; entire
structure dominated by Socialist Unity (Communist)
Party
Government leaders: Chairman, Council of State,
Willi Stoph (Head of State); Chairman, Council of
Ministers, Horst Sindermann (Head of Government)
Suffrage: all citizens age 18 and over
Elections: national every 4 years; prepared by an
electoral commission of the National Front; ballot
supposed to be secret and voters permitted to strike
names off ballot; more candidates than offices
available; parliamentary elections held 14 November
1971
Political parties and leaders: Socialist Unity
(Communist) Party (SED), headed by First Secretary
Erich Honecker, dominates the regime; 4 token
parties (Christian Democratic Union, National
Democratic Party, Liberal Democratic Party, and
Democratic Peasant’s Party) and an amalgam of
special interest organizations participate with the SED
in National Front
Voting strength: 1971 parliamentary elections:
98.33% voted the regime slate; 1970 local elections:
99.85% voted the regime slate
Communists: 1.9 million party members
Other special interest groups: Free German Youth,
Free German Trade Union Federation, Democratic
Women’s Federation of Germany, German Cultural
Federation (all Communist dominated)
Member of: CEMA, IPU, ITU, Seabeds Commit-
tee, U.N., UNESCO, UPU, Warsaw Pact, WFTU,
WHO
Legal name: Federal Republic of Germany
Type: federal republic
Capital: Bonn
Political subdivisions: 10 Laender (states);
Western sectors of Berlin are governed by U.S., U.K.,
and France which, together with the U.S.S.R., have
special rights and responsibilities in Berlin
Legal system: civil law system with indigenous
concepts; constitution adopted 1949; judicial review
of legislative acts in the Supreme Federal Constitu-
tional Court; has not accepted compulsory IC]
jurisdiction
Branches: bicameral parliament — Bundesrat
(upper house), Bundestag (lower house); President
(titular head), Chancellor (executive head);
independent judiciary
Government leaders: President, Walter Scheel;
Chancellor, Helmut Schmidt leads coalition of Social
Democrats and Free Democrats
Suffrage: universal over age 18
Elections: usually every 4 years; last election held
19 November 1972
Political parties and leaders: Christian Demo-
cratic Union/Christian Social Union (CDU/CSU),
Helmut Kohl, Franz-Josef Strauss, Karl Carstens, Kurt
Biedenkopf; Social Democratic Party (SPD), Willy
Approved For Release 2005/04/22 :
Brandt, Heinz Kuehn, Helmut Schmidt; Free
Democratic Party (FDP), Hans-Dietrich Genscher,
Hans Friderichs, Wolfgang Mischnick, National
Democratic Party (NPD), Martin Mussgnug;
Communist Party (DKP)
Voting strength (1972 election): 45.9% SPD,
44.8% CDU/CSU, 8.4% FDP, 0.9% Splinter groups of
left and right. (no parliamentary representation)
Communists: about 30,000 members and sup-
porters
Other political or pressure groups: expellee,
refugee, and veterans groups
Member of: ADB, Council of Europe, DAC, EC,
ECSC, EIB, ELDO, EMA, ESRO, EURATOM,
FAO, GATT, IAEA, IBRD, ICAO, IDA, IEA, IFC,
IHO, IMCO, IMF, IPU, ITU, NATO, OAS
(observer), OECD, Seabeds Committee, U.N.,
UNESCO, UPU, WCL, WEU, WHO, WMO','688dffda6927644b797b4108160561ba00c9efe918e4c9035cfc37a80542530d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b683c45c78dec9fcaa813870a6178ebc2470890128be50ba622cec43eb6f9e47',1976,'GH','Ghana','government',183,'Legal name: Republic of Ghana
Type: republic; independent since March 1957:
Military regime since January 1972
Capital: Accra
Political subdivisions: 8 administrative regions and
separate Greater Accra Area; regions subdivided into
58 districts and 267 local administrative districts
Legal system: based on English common law and
customary law; constitution suspended January 1972;
legal education at University of Ghana (Legon); has
not accepted compulsory ICJ jurisdiction
Branches: executive and_ legislative authority
vested in Supreme Military Council (SMC);
independent judiciary
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
rae | a ei AEA
January 1976
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
GHANA/GIBRALTAR
Government leaders: Chief of State, Chairman of
SMC Colonel LK. Acheampong
Suffrage: universal over 21 under previous
constitution, now suspended
Elections: no elections since 1969; none scheduled
Political parties and leaders: parties banned by
military junta which took power 13 January 1972
Communists: a small number of Communists and
sympathizers
Member of: AFDB, Commonwealth, ECA,
ECOWAS, FAO, GATT, IAFA, IBRD, ICAO, IDA,
IFC, ILO, IMCO, IMF, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WHO,
WMO','b1d15a25112785293ad0b93bb84c12ba10dc3e36f512ded65ae95f9c680c37c9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('573d9b87bbc27453096a464eddc9a0b5ef6e41eca96f0caae7c9ccb3a8d90738',1976,'GI','Gibraltar','government',187,'Legal name: Colony of Gibraltar
Type: ULK. colony
Capital: none
Legal system: English law; constitutional talks in
July 1968: new system effected in 1969 after electoral
enquiry
Branches; parliamentary system comprised of the
Gibraltar House of the Assembly (15 elected members
and 3 ex officio members), the Council of Ministers
headed by the Chief Minister, and the Gibraltar
Council; the Governor js appointed by the Crown
Government leaders; Governor and Commander
in Chief, Marshall of the RAF Sir John Grandy, Chief
Minister, Sir Joshua Hassan
Suffrage: all adult Gibraltarians, plus other ULK.
subjects resident 6 months or more
Elections: every 5 years; last held in July 1972
Political parties and leaders: Association for
Advancement of Civil Rights (AACR), Sir Joshua
Hassan; Labor, Sir Joshua Hassan; Independents,
Peter Isola; Integrationists (IWBP), Maj. Robert
Peliza
Communists: negligible
Other political or pressure groups: the House-
wives Association: the Chamber of Commerce','60936f625d8e3e3e470c9f448c6f42c83ed5fa302daa86ca980bf0b487cae45c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31786da9ffe0b68c9ea0892d69a0fbeb24b5cff24c7963615e76129bbaf9bb22',1976,'NL','Netherlands','government',192,'Legal name: Gilbert and Ellice Islands Colony
Type: British crown colony with large measure of
self-government
Capital: Tarawa
Political subdivisions: 4 districts
Branches: 28-member House of Assembly elects a
Chief Minister
Government leader: Governor John H. Smith;
Chief Minister, Naboua Ratieva
Political parties and leaders: Gilbertese National
Party, Christian Democratic Party
Member of: ADB
Legal name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at
The Hague
Political subdivisions: 11 provinces governed by
centrally appointed commissioners of Queen
Legal system: civil law system incorporating
French penal theory; constitution of 1815 frequently
amended, reissued 1947; judicial review in the
Supreme Court of legislation of lower order than Acts
of Parliament; legal education at six law schools;
accepts compulsory IC] jurisdiction, with reservations
Branches: exccutive, (Queen and Cabinet of
Ministers), which is responsible to bicameral states
general (parliament); independent judiciary
Government leader: Head of State, Queen
Juliana; Johannes den Uyl, Prime Minister
Suffrage: universal over age 21
Elections: must be held at least every 4 years for
lower house (most recent November 1972), and every
3 years for upper house (most recent March 1974)
Political parties and leaders: Catholic People’s
Party (KVP), Dr. D. de Zeeuw; Antirevolutionary
(ARP), A. Veerman; Labor (PvdA), Mrs. [en Van Den
Heuvel; Liberal (VVD), Mrs. H. van Sommeren-
Downer; Christian Historical Union (CHU), Otto W.
A. Barou Van Verschuer; Democrats "66 (D-66), Jan
ter Brink; Communist (CPN), Henk Hoekstra; Pacifist
Socialist (PSP), P. A. Burggraff; Political Reformed
(SGP), H. G. Abma; Reformed Political Union (GVP),
G. Veurink; Radical Party (PPR), Marcel Van Dam,
Democratic Socialist "70 (DS-70), Fred L. Polak;
Farmers’ Party (BP), Hendrik Koekoek; Roman
Catholic Party (RKPN), leader unknown
Voting strength (1972 election): 17.7% KVP,
14.4% VVD, 8.8% ARP, 4.8% CHU, 27.4% PydA,
4.2% D-66, 4.1% DS-70, 4.5% CPN, 1.5% PSP, 4.8%
PRP, 2.2% SGP, 1.8% GVP, 1.9% BP, .9% RKP
Communists: 9,000 members; 329,973 votes in
1972 election
145
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NETHERLANDS/NETHERLANDS ANTILLES
Other political or pressure groups: great
multinational firms; Socialist, Catholic, and
Protestant trade unions; Federation of Catholic and
Employers Associations; the non-
denominational Federation of Netherlands Enter-
prises
Protestant
Member of: ADB, Benelux, Council of Europe,
DAC, EC, ECE, EEC, EIB, ELDO, EMA, ESRO,
EURATOM, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IEA, IFC, IHO, ILO, IMCO, IMF, IPU, ITU,
NATO, OAS (observer), OECD, Seabeds Committee,
U.N., UNESCO, UPU, WCL, WEU, WHO, WMO
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands,
enjoying complete domestic autonomy
Capital: Willemstad; Curacao, center of govern-
ment
Political subdivisions: 4 island territories — Aruba,
Bonaire, Curacao, and the Windward Islands — St.
Eustatius, southern part of St. Martin (northern part is
French), Saba
Legal system: based on civil law system, with some
English common law influence; Dutch Country
Statute of 1955 serves as constitution
Branches: federal executive power, under nominal
head of Governor (appointed by the Crown), exercised
by 8-member Council of Ministers or Cabinet;
legislative power rests with 22-member Legislative
Council; independent court system under control of
Chief Justice of Supreme Court of Justice (administra-
tive functions under Minister of Justice); each island
territory has island council headed by Lieutenant
Governor for local administration
Government leaders: Minister-President Juan
Evertsz
Suffrage: universal age 18 and over
Elections: general elections held every 4 years, last
held August 1973; Island council elections every 2
years, last held April and May 1975
Political parties and leaders: the Democratic Party
(DP);. Antilles Social Progress Movement (MASA)
led by Ciro Kroon; the Aruba Patriotic Party (PPA) led
by S. J. Trompe; the National People’s Party (NVP), S.
D. Abbad; the Aruba People’s Party (AVP) led by
Dominico Guzman Croes; the National Aruban
Union Party/Independent Aruban Party (UNA/PIA)
led by A. Werleman/M. Croes; Bonaire Democratic
Party led by L. A. Abraham; Windward Island
Democratic Party led by A. C. Wathey; Social
Progressive Action Party, S$. R. Goeloe; Antillean
Reform Union (URA), Roberto Suriel; Curacao
Independent Party (COP), Peter Vander Hoven;
Radical People’s Party (PRP), Max de Castro;
Worker''s Party (Frente Obrero); People’s Electoral
Movement (MEP), separatist party
Voting strength (1973 general election): DP/PPA, 8
seats; NVP, 5 seats; Frente Obrero, 3 seats, MEP, 5
seats; labor coalition, 1 seat
Communists: no Communist Party
Member of: EC (associate), WCL, WHO','8d3e81b92b244d5372847fb56c0740616b4572f7bd3d7f805f2a8ae71eddf404','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24147299aba71504abd5f260cba91b2bc609fd4a4adaa4881dbdd8dc816dcf17',1976,'GR','Greece','government',195,'Legal name: Hellenic Republic
Type: presidential parliamentary government;
monarchy rejected by referendum December 8, 1974
Capital: Athens
Political subdivisions: 52 departments (nomoi)
constitute basic administrative units for country; each
nomos headed by officials appointed by central
government and _ policy and programs tend to be
formulated by central ministries; degree of flexibility
79
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
each nomos may have in altering or avoiding
programs imposed by Athens depends upon tradition
(Thessaloniki and other areas exercise considerable
traditional autonomy in local administrative
decisions) and influence which prominent local
leaders and citizens may exercise vis-a-vis key figures
in central government
Legal system: new constitution enacted in June
1975
Branches: executive consisting of a President (to be
elected by Parliament) and a Prime Minister and
cabinet; legislative comprising the 300-member
Parliament; independent judiciary
Government leaders: President Constantine
Tsatsos; Prime Minister Constantine Caramanilis
Suffrage: universal age 21 and over
Elections: every 4 years; latest November 17, 1974
Political parties and leaders: Center Union-New
Forces, George Mavros; New Democracy, Constan-
tine Caramanlis; New Democratic Union, Petros
Garoufalias; Panhellenic Socialist Movement,
Andreas Papandreou; Communist Party — Exterior,
Harilaos Florakis; Communist Party — Interior,
Haralambos Drakopoulos; and the United Demo-
cratic Left, Hias Tliou—in disarray since the election
Voting strength: New Democracy, 216 seats;
Center Union-New Forces, 61 seats; Panhellenic
Socialist Movement, I5 seats; Left, 8 seats
Communists: an estimated 25,000-30,000 members
and sympathizers
Member of: EC (associate), EIB (associate), EMA,
GATT, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHO,
ILO, IMCO, IMF, ITU, NATO, OECD, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WHO,
WMO','14819d1507bb575183b4d89cf26bef42f71a3244d3870f22c8a1501661bfb6f5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0b35b07397b7cefd03b68449d6bad99b8f5095c58e9fc2890e2182b49ba93cb',1976,'GL','Greenland','government',199,'Legal name: Greenland
Type: province of Kingdom of Denmark; 2
representatives in Danish parliament; separate
Minister for Greenland in the Danish cabinet
Capital: Godthaab (administrative center)
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from
colony to province in 1953
Branches: legislative authority rests jointly with
Crown and Danish parliament, executive power
vested in Crown, acting through provincial governor
responsible to Minister for Greenland; local affairs
handled by provincial council (Landsrad) subject to
approval of provincial governor; 19 lower courts
Government leaders: Queen Margrethe II;
Governor N. O. Christensen
Suffrage: universal, but not compulsory, over age
21
Elections: held every 4 years (next 1979)
Political parties: Inuit (advocating close ties with
Denmark); Sukaq (moderate socialist, advocating
more distinct Greenland identity)','5e3d647daf01672812c89a722e31836cdc87be2e628891c512c8817ff68e1faa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd3f5657ba59de8ae9c79e5bcc109b731bfea7a98e09d4ed0bbd57d3e501fb58',1976,'GD','Grenada','government',203,'Legal name: Grenada
Type: independent state since February 1974,
recognizes Elizabeth II as Chief of State
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
Branches: legislative branch consists of 10-member
clected House of Representatives and 13-member
Senate appointed by the Governor; executive branch
is cabinet led by Prime Minister
Government leaders; Prime Minister Eric
Matthew Gairy; U.K. Governor General Leo de Gale
Suffrage: universal adult suffrage
Elections: every 5 years; most recent general
clection 28 February 1972
Political parties and leaders: Grenada United
Labor Party (GULP), Eric Matthew Guiry; Grenada
National Party (GNP), Herbert A. Blaize
Voting strength (1972 election): GULP 58.7%,
GNP 41.3%; Legislative Council seats, GULP 14,
GNP 1
82
Communists: negligible
Member of: CARICOM, IMF, OAS, U.N.','1460c3491b131a6d0922663199c8a9cd22473cb6b87c6f951c85d70365379397','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15946033f463615ba64fd4ff8e2a3d8e8cec731751d8e78d7f900adb0b3405e2',1976,'GP','Guadeloupe','government',207,'Legal name: Overseas Department of Guadeloupe
Type: overseas department and region of France;
represented by 3 deputies in the French National
Assembly and 2 Senators in the Senate
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34
communes, each with a locally elected municipal
council
Legal system: French legal system; highest court is
a court of appeal based in Martinique with
jurisdiction over Guadeloupe, French Guiana, and','2d1a7448d43da146e9198e8455f43892de502e1711c9000c8ea366991f89792b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f14385a9f0f4d546e77cf7a9eac73b99664bcd239a564d90607a46f6fa51e49',1976,'MQ','Martinique','government',208,'Branches: executive, Prefect appointed by Paris;
legislative, popularly elected General Council of 36
members and a Regional Council composed of
members of the local General Council and the locally
elected deputies and senators to the French
parliament; judicial, under jurisdiction of French
judicial system
Government leader: Prefect Jacques Le Cornec
Suffrage: universal over age 18
Elections: General Council elections coincide with
those for the French National Assembly, normally
every 5 years; last General Council election took place
in March 1973; local clection last held September
1973; last French presidential election in May 1974
Political parties and leaders: Union of Democrats
for the Republic (UDR), Gabriel Lisette; Communist
Party of Guadeloupe (PCG), Henri Bangou; Socialist
Party (MSG), leader unknown; Progressive Party of
Guadeloupe (PPG), Henri Rodes; Independent
Republicans; Federation of the Left
Voting strength: MSG, 1 seat in French National
Assembly; UDG, 2 seats; (1973 election)
Communists: 3,000 est.
Other political or pressure groups: Group of
National Organization of Guadeloupe (GONG)
Member of: WFTU
Legal name: Overseas Department of Martinique
Type: overseas department of France, represented
by 3 deputies in the French National Assembly and 2
Senators in the Senate
Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34
communes, each with a locally elected municipal
council
Legal system: French legal system; highest court is
a court of appeal based in Martinique with
jurisdiction over Guadeloupe, French Guiana, and
133
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MARTINIQUE/MAURITANIA
Branches: executive, prefect appointed by Paris;
legislative, popularly elected council of 36 members
and a Regional Council including all members of the
local general council and the locally elected deputies
and senators to the French parliament; judicial, under
jurisdiction of French judicial system
Government leader: Prefect Herve Bourseilleur
Suffrage: universal over age 18
Elections: General Council elections coincide with
those for the French National Assembly, normally
every five years; last General Council election took
place in March 1973; last local election held
September 1973, last French Presidential election
May 1974
Political parties and leaders: Union of Democrats
for the Republic (UDR), Emile Maurice; Progressive
Party of Martinique (PPM), Aime Cesaire;
Communist Party of Martinique (PCM), Armand
Nicolas; Democratic Union of Martinique (UDM),
Leon-Laurent Valere; Socialist Party, leader
unknown; Federation of the Left, leader unknown
Voting strength: UDR, 2 seats in French National
Assembly; PPM, 1 seat (1973 election)
Communists: 1,000 estimated
Other political or pressure groups: Proletarian
Action Group (GAP), Socialist Revolution Group
(GRS)
Member of: WFTU','5491e45fb2126dc928a7ca1e849950897a0c1c660f4fdfd0202df8ef46fc7983','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a69d0a9087ff67e6b007cc4c7baebc1d6cd832113ddf2cfe55bc2cfa0fbf3b5',1976,'MX','Mexico','government',213,'Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system: civil law system; constitution came
into effect 1966; judicial review of legislative acts;
legal education at University of San Carlos of
Guatemala; has not accepted compulsory ICJ
jurisdiction
Branches: traditionally dominant executive;
elected unicameral legislature; 7-member (minimum)
Supreme Court
Government leader: President Kjell Laugerud
Suffrage: universal over age 18, compulsory for
literates, optional for illiterates
Elections: next elections (President and Congress)
1978
Political parties and leaders: Democratic
Institutional Party (PID), Donaldo Alvarez Ruiz;
Revolutionary Party (PR), Jorge Garcia-Granados
Quinonez (secretary general); National Liberation
Movement (MLN),
Guatemalan Christian Democratic Party (DCG),
Mario Sandoval Alarcon;
Vinicio Cerezo Arevalo (sec. gen.)
Voting strength: for President — MLN-PID
298,953 (44.6%), DCG 228,067 (34.0%), PR 143,111
(21.4%); for congressional seats — MLN-PID 36,
DCG 15, PR 10
Communists: Communist party outlawed; under-
ground membership estimated at 750
Other political or pressure groups: outlawed
(Communist) Guatemalan Labor Party (PGT),
Bernardo Alvarado
Member of: CACM, FAO, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, IHO, ILO, IMF, ITU,
Seabeds Committee, OAS, ODECA, U.N., UNESCO,
UPU, WCL, WHO, WMO','67de9d10668ea5f3387b3c08ab7fa3322376d2a49b54fe36826b9d5275a0d7ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01d743a8cbb51104c47b4095a70b82a9fffce93ed1d1f48337dfc432a84ce797',1976,'GW','Guinea-Bissau','government',217,'Legal name: Republic of Guinea-Bissau
Type: republic; achieved independence from
Portugal in September 1974; constitution promul-
gated 1974; government being formed; will establish
union with the Republic of Cape Verde
Capital: Bissau
Political subdivisions: 9 municipalities, 3
circumscriptions (predominantly indigenous popula-
tion)
Legal system: to be determined
Branches: National Popular Assembly to be elected
for three-year term; Council of State Commissars, 16
members; the official party is the supreme political
institution.
Government leaders: President of Council of State
and Chief of State is Luis Cabral: Principal
Commissar and Head of Government, Francisco
Mendes; Secretary General of the Official party,
Aristides Pereira
Suffrage: Universal over age 18
Elections: None held to date
noun—Guinean(s); adjective—
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GUINEA-BISSAU/GUYANA
Political parties and leaders: Partido Africano da
Independencia da Guinee e Cabo Verde (PAIGC), led
by Aristide Pereira, only legal party; Front de Lutte
pour l''Independence Nationale de la Guinea
(FLING), a largely dormant, loose coalition of
nationalist elements opposed the PAIGC, leadership
fragmented
Communists: none known
Member of: U.N., UPU','af763ef4e6e37348873b41bfdc9323c49f3e4dc00e82678634ab4f6d4c196d49','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c25f7163df1df1f0eb5409cd81f4eeb87f0a97f77f85af59bc12f9cc8ada3d9',1976,'GY','Guyana','government',221,'Legal name: Cooperative Republic of Guyana
Type: republic within Commonwealth
Capital; Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with
certain admixtures of Roman-Dutch law; has not
accepted compulsory ICJ jurisdiction
Branches; Council of Ministers presided over by
Prime Minister; 53-member unicameral legislative
National Assembly (elected); Supreme Court
Government leader: Prime Minister L.F-.S.
Burnham
Suffrage: universal over age 18 as of constitutional
amendment August 1973
Elections: last held in July 1973; next election must
be called within 5 years
Political parties and leaders: People’s National
Congress (PNC), L.F.S. Burnham; People’s Progres-
sive Party (PPP), Cheddi Jagan; United Force (UF),
Feilden Singh
Voting strength (1973 election): 70.2% PNO,
26.2% PPP, 3.6% other
87
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GUYANA/HAITI
Communists: est. 100 hard-core within PPP; top
echelons of PPP and PYO (Progressive Youth
Organization, militant wing of the PPP) include many
Communists, but rank and file is non-Communist
Other political or pressure groups: Liberator Party
(LP), Guyana National Liberation Front (GNLF),
People’s Democratic Movement (PDM), African
Society for Cultural Relations with Independent
Africa (ASCRIA), Afro-Asian-American Association
(AAAA)
Member of: CARICOM, FAO, GATT, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, OAS (observer),
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WHO, WMO
Legal name: Republic of Haiti
Type: republic under the 14-yeat dictatorship of
Francois Duvalier who was succeeded upon his death
on 21 April 1971 by his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite
constitutional provision for 9)
Legal system: based on Roman civil law system
constitution adopted 1964 and amended 1971; legal
education at State University in Port-au-Prince an
private law colleges in Cap-Haitien, Les Cayes,
Gonaives, and Jeremie; accepts compulsory IC]
jurisdiction
Branches: lifetime President, unicameral 58-
member legislature of very limited powers, judiciary
appointed by President
Government leader: President-for-life Jean-Claude
Duvalier
Suffrage: universal over age 18
Elections: constitution as amended in 197]
provides for lifetime president to be designated by his
predecessor and ratified by electorate in plebiscite;
legislative elections, which are held every 6 years, last
held February 1973
Political parties: National Unity Party, only legal
party; United Haitian Communist Party (PUCH),
illegal (Communist)
Voting strength (1967 legislative elections): 100%
National Unity Party (Duvalier)
Communists: strength unknown; party leaders
believed in exile
Other political or pressure groups: none
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMCO, IMF, ITU,
OAS, U.N. UNESCO, UPU, WCL, WHO, WMO','144b1f8c936575de7a84b6d12b6209b2d0181611ed57b4ec783483e6349f04f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d78063064bcb788b1e190a4e568aad15452c6c9ea46d32173c6fc415627c5c3',1976,'HN','Honduras','government',225,'Legal name; Republic of Honduras
Type: republic
Capital; Tegucigalpa
Politica] subdivisions: 13 departments
Legal system; based on Roman and Spanish civil
law; some influence of English common law:
1965; judicial review of
Constitution provides for elected
President, unicameral legislature, and national
judicial branch
Government leader: Juan Alberto Melgar Castro
Suffrage: universal and compulsory over age 18
Elections: no &eneral election scheduled
Politica] Parties and leaders: al] Parties, even legal
Ones, are dormant at present: Libera] Party (PLH),
Modesto Rodas Alvarado,
Idiaguez, Jorge Bueso Arias; National Party (PNH),
Alejandro Lopez Cantarero,
Augustinus: Mario Rivera Lopez, Martin Aquero;
Fernandez, Workers Party of Honduras (PTH)
(Communist) (uninscribed), Rogue Ochoa; Com.
munist Party of Honduras/Soviet (PCH/S-outlawed),
Dionisio j Communist Party of
Honduras/Ching (PCH/C-outlawed), Agapito
Robledo Castro
Voting Strength (197] elections); National Party
(PNH) 306,028: Liberal Party (PLH) 276,777
Communists: about 800: 2,000 sympathizers
National
Association of Honduran Campesinos (ANACH).','4a70af8aa6ebf4cb91e063d53e57ea025189b8c7ae848fbb12a3416cc58e3538','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('640693b753f99392187a7b13004a3e776c7bd6e9d5cddaf85072354c0be2871f',1976,'HK','Hong Kong','government',229,'Legal name: Colony of Hong Kong
Type: U.K. crown colony
Capital: Victoria
Political subdivisions: Hong Kong, Kowloon, and
New Territories
Legal system: English common law
Branches: Governor assisted by advisory Executive
Council; he legislates with advice and consent of
Legislative Council; Urban Council which alone
includes elected representatives, responsible for
health, recreation, and resettlement; independent
judiciary
Government leader: C. M. MacLehose, Governor
and Commander in Chief
Suffrage: limited to 200,000 to 300,000 professional
or skilled persons
Elections: every 2 years to select one-half of elected
membership of Urban Council; other Urban Council
members appointed by the Governor
Political parties and leaders: Civic Association,
Hu Pai-fu; Reform Club, B. A. Bernacchi; Socialist
Democratic Party, Sun Po-kong; Hong Kong Labour
Party, Tang Hon-tsai
Voting strength: (elected Urban Council members)
Civic Association 4, Reform Club 8, and 1
independent
Communists: an estimated 2,000 hard core cadres
affiliated with Communist Party of China
Other political or pressure groups: Federation of
Trade Unions (Communist controlled), Hong Kong
and Kowloon Trade Union Council (Nationalist
Chinese dominated), Hong Kong General Chamber of
Commerce, Chinese General Chamber of Commerce
(Communist controlled), Federation of Hong Kong
Industries, Chinese Manufacturers’ Association of
Member of: ADB, WCL','fe4bd07f344aee88a2137e2afce12f961adac527c6a187192d49ab1ebe086cc1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('874572b52c089bb072593a9daef8c36ef56e128f2fa9459d442694a49b20be5b',1976,'HU','Hungary','government',233,'Legal name: Hungarian Peoples Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 megyes (counties), 5
autonomous cities in county status, 97 jaras (districts)
Legal system: based on Communist legal theory,
with both civil law system (civil code of 1960) and
common law elements: constitution adopted 1949
amended 1972; Supreme Court renders decisions of
principle that sometimes have the effect of declaring
legislative acts unconstitutional; legal education at
Lorand Eotvos Tudomanyegyetem School of Law in
Budapest and 2 other schools of law; has not accepted
compulsory ICJ jurisdiction
Branches: executive Presidential Council
(elected by Parliament); legislative — Parliament
(elected by direct suffrage): judicial — Supreme Court
(elected by Parliament)
Government leaders: Gyorgy Lazar, Chairman,
adjective—
Calvinist,
Council of Ministers: Pal Losonczi, President,
Presidential Council
Suffrage: universal over age 18
Elections: every 5 years; national and local
elections are held separately
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
HUNGARY/ICELAND
Politica] parties and leaders: Hungarian Socialist
(Communist) Workers Party (sole party); Janos Kadar
is First Secretary of Central Committee
Voting strength (1975 election): 7,497,061 (99.6% )
for Communist-approved candidates; 30,108 (0.4%)
invalid and negative votes; total eligible electorate
about 7.76 million; next elections will be held in 1980
Communists: about 754,000 party members
(March 1975)
Member of: CEMA, Danube Commission, FAO,
IAEA, ICAO, ILO, IMCO, IPU, ITU, Seabeds
Committee, U.N., UNESCO, UPU, Warsaw Pact,
WFTU, WHO, WMO','59c913fb91ec1aa467524aa5280641e206ae4fd7c650b1365fd8cfcc1bf805ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d834a830833f7e310f749fe2357b2e9613ca38b0f364e90c4571b7beb1bf0404',1976,'IS','Iceland','government',237,'Legal name: Republic of Iccland
Type: republic
Capital: Reykjavik
Political subdivisions: 23 rural districts, 215
parishes, 14 incorporated towns
Legal system: civil law system based on Danish
law; constitution adopted 1944; legal education at
University of Iceland; does not accept compulsory ICJ
jurisdiction
Branches: legislative authority rests jointly with
President and parliament (Althing); executive power
vested in President but exercised by cabinet
responsible to parliament; Supreme Court and 29
lower courts
Government leaders: President Kristjan Eldjarn;
Prime Minister Geir Hallgrimsson
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in
(1978); presidential, every 4 years (next in 1976)
Political parties and leaders: Independence
(conservative), Geir Hallgrimsson; Progressive, Olafur
Johannesson; Social Democratic, Benedikt Grondal:
People’s Alliance (Communist front), Ragnar Arnalds;
Organization of Liberals and Leftists, Magnus Torfi
Olafsson
Voting strength (1974 election): 42.7% Independ-
ence, 24.9% Progressive, 9.1% Social Democratic,
18.3% People’s Alliance, organization of leftists and
liberals 4.6%
Communists: est. 2,200; a number of sympathizers,
us indicated by 18,055 votes cast for Labor Alliance in
1971 election
Member of: Council of Europe, EC (free trade
agreement pending resolution of fishing limits issue),
FTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC,
IHO, ILO, IMCO, IMF, IPU, ITU, NATO, Nordic
Council, OECD, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO
04','808fff5a1dd83376b044b60c3a6f831d7ef17866f41adda429dd8ea42ffc4c4f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c0f78959826afd531060fd906b1e165daf4a225b54a417955ab66b476cfdddf',1976,'ID','Indonesia','government',241,'Legal name: Republic of Indonesia
Type: republic
Capital: Jakarta
Political subdivisions: 26 first-level administrative
subdivisions or provinces which are further subdivided
into 281 second-level areas
Legal system: based on Roman-Dutch law,
substantially modified by indigenous concepts;
constitution of 1945 is legal basis of government; legal
education at University of Indonesia, Jakarta; has not
accepted compulsory ICJ jurisdiction
Branches: executive headed by President who is
chief of state and head of cabinet; cabinet selected by
President; unicameral legislature (Parliament), of 460
members (100 appointed, 360 elected), second and
larger body (Congress) of 920 members and includes
the legislature and 460 other members (chosen by
several processes, but not directly elected) elects
President and Vice President, and theoretically
determines national policy
Government leader: President Suharto (elected by
Congress March 1973)
Suffrage: universal over age 17 and married persons
regardless of age
Political parties and leaders: Golkar (quasi-official
“party” based on functional groups), Amir Moertono;
Indonesian Democratic Party (federation of former
Nationalist and Christian parties), Mohammed
Isnaeni; Unity Development Party (federation of
former Islamic parties), Idham Chalid
Voting strength (1971 election): Golkar 236 seats,
Indonesian Democratic 30, Unity Development 94
Communists: Communist Party (PKI) was
officially banned in March 1966; current strength est.
at 1,000, with less than 10% engaged in organized
activity; pre-October 1965 hard-core membership has
been estimated at 1.5 million
Member of: ADB, ASEAN, ESCAP, FAO, IAEA,
IBRD, ICAO, IDA, IFC, THO, ILO, IMCO, IMF,
IPU, ITU,OPEC, Seabeds Committee, U.N.,
UNESCO, UPU, WCL, WFTU, WHO, WMO
Legal name: Empire of Iran
Type: constitutional monarchy, controlled by the
Shah
Capital: Tehran
Political subdivisions: 19 providnces and 3 chief-
governorates, subdivided into districts, sub-districts,
counties, and villages
Legal system: based largely on French law, with
clements drawn from other continental systems:
personal law based on Islamic practice generally with
residual traces of Roman law; constitution adopted
1906 and constitutional law of 1907: High Court of
Appeal may judge disputes relating to government
departments acting according to law; legal education
at University of Teheran; has not accepted
compulsory ICJ jurisdiction
98
Branches: executive power rests in Shah who
appoints a Prime Minister; Prime Minister must be
approved by lower house (Majlis); while Cabinet
theoretically responsibility of Prime Minister, Shah
usually exerts strong influence over its selection:
bicameral legislature; Majlis has 268 members elected
to 4-year terms, and Senate 60 members serving 4-year
terms; half of Senate members appointed by Shah,
other half elected; no provision for judicial review of
constitutionality of legislative acts
Government leaders: Shah Mohammad Reza
Pahlavi and Prime Minister Amir Abas Hoveyda
Suffrage: universal over age 20
Elections: Majlis every 4 years; Senate every 4
years; latest national elections June 1975, next district
and municipal elections in 1976
Political parties and leaders: a single party
system, designated The Resurgence Party of the
People of Iran (RPPI) with Prime Minister Amir
Abbas Hoveyda as Secretary-General, was formed by
Shah in March 1975; all other political parties
disbanded
Voting strength: all candidates government
approved and members of the RPPI
Communists: 1,000-2,000 (hard-core, est.): sympa-
thizers (15,000-20,000 est. ); mostly pro-U.S.S.R. but
pro-Chinese faction developing
Other political or pressure groups: Tudeh Party
(Communist, illegal); National Front (coalition of
neutralist urban elements virtually discredited
because of opposition to Shah''s reform program);
Confederation of Iranian Students (illegal)
Member of: CENTO, Colombo Plan, FAO, IAEA,
IBRD, ICAO, IDA, IFC, IHO, ILO, IMCO, IMF,
IPU,ITU, OPEC, RCD, Seabeds Committee, ULN.,
UNESCO, UPU, WFTU, WHO, WMO','4c7b9bd80669484d19c603df7c72d07dd0037c1db37ba755f227585755d31a38','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d1766d4d8b43d1a25e559264f47b0f6320120d340fe7c39e744113cf1b7867e',1976,'IQ','Iraq','government',245,'Legal name: Republic of Iraq
Type: republic; National Front Government
consisting of Baath Party (BPI), and Iraq Communist
Party (CPI) formed in July 1973 (Kurds invited to join
National Front government but have refused pending
solution of Kurdish autonomy issue; Communists play
nominal role in government)
Capital: Baghdad
Political subdivisions: 16 provinces under centrally
appointed officials
Legal system: based on Islamic law in special
religious courts, civil law system elsewhere;
provisional constitution adopted in 1968; judicial
review was suspended; legal education at University
of Baghdad; has not accepted compulsory IC]
jurisdiction
Branches: Bath Party of Iraq has been in power
since 1968 coup
Government leaders: President Ahmad Hasan al-
Bakr; Deputy Chairman of the Revolutionary
Command Council Saddam Husayn ’Abd-al-Majid
al-Tikriti
Suffrage: no elective bodies exist
Elections: no national clections since overthrow of
monarchy in 1958
Communists: Communist Party allowed token
representation in cabinet; est. 2,000 hard-core
Political or pressure groups: political parties
banned, possibly some opposition to regime from
disaffected members of the regime and army officers
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, OAPEC, OPEC,
99
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
IRAQ/IRELAND
Seabeds Committee, U.N., UNESCO, UPU, WFTU,
WHO, WMO','d879d9b5bad8c227b37ea620c5c6a0cea49145fbdfcb39e800e8e078bf5e231b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcc35d65c461b603bd5a648d0af0a3710accc619addab210baa5f2d27a2aa937',1976,'IE','Ireland','government',249,'Legal name: Ireland, Fire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law,
substantially modified by indigenous concepts:
constitution adopted 1937; judicial review of
legislative acts in Supreme Court: has not accepted
compulsory ICJ jurisdiction
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
IRELAND/ISRAEL
Branches: elected President; bicameral parliament
reflecting proportional and vocational representation,
judiciary appointed by President on advice of
Government Jeaders: President Cearbhall O’Daigh-
ly, Taoiseach; Prime Minister Liam Cosgrave;
Tanaiste Deputy Prime Minister Brendan Corish
Suffrage: universal over age 18
Elections: Dail (lower house) elected every 5 years
_. last election February 1973; President elected for 7-
year term — last election December 1974
Political parties and leaders: Fianna Fail, John
(Jack) Lynch; Labor Party, Brendan Corish; Fine
Gael, Liam Cosgrave; Communist Party of Ircland,
Michael O''Riordan
Voting strength: (1973 election) Fianna Fail 46%
(69 seats), Fine Gael 35% (54 seats), Labor Party 14%
(19 seats), other 5%; Independents hold 2 seats
Communists: approximately 600
Member of: Council of Europe, EC, EEC, ESRO
(observer), EURATOM, FAO, GATT, IBRD, ICAO,
IDA, IEA, IFC, ILO, IMCO, IMF, IPU, ITU,
OECD, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO','01de33c12aae2577a76e3c22c04af9aee3c485aab806853649253722da319078','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef8e388efb15ac45090f3cf8cfa74d54fb487fefb2b92fa7d32f00e14d877671',1976,'IL','Israel','government',253,'Legal name: State of Israel
Type: republic
Capital: Jerusalem; not recognized by U.S. which
maintains Embassy in Tel Aviv
Political subdivisions: 6 administrative districts
Legal system: mixture of English common law
and, in personal area, Jewish, Christian and Muslim
legal systems; commercial matters regulated
substantially by codes adopted since 1948; no formal
constitution; some of the functions of a constitution
are filled by the Declaration of Establishment (1948),
the basic laws of the Knesset (legislature) relating to
the Knesset, Israeli lands, the president, the
government and the Israel citizenship law; no judicial
review of legislative acts; legal education at Hebrew
University in Jerusalem; accepts compulsory IC]
jurisdiction, with reservations
Branches: President Ephraim Katzir has largely
ceremonial functions; executive power vested in
cabinet; unicameral parliament (Knesset) of 120
members elected under a system of proportional
102
representation, legislation provides fundamental laws
in absence of a written constitution; 2 distinct court
systems (secular and religious)
Government leader: Prime Minister Yitzhak Rabin
Suffrage: universal over age 18
Elections: held every 4 years unless required by
dissolution of Knesset; last election held in December
1973
Principal political parties and leaders: Isracl
Labor Party, Prime Minister Yitzhak Rabin, Golda
Meir, Josef Almogi, Moshe Dayan, Yigal Allon,
Shimon Peres; United Workers Party (MAPAM) in
alignment with Israel Labor Party, Meir Talmi;
National Religious Party, Minister of Interior Dr.
Joseph Burg; Independent Liberal Party, Minister of
Tourism Moshe Kol: Herut (Freedom) Party,
Menahem Begin; Liberal Party, Dr. Elimeleda
Rimalt; State List, Yigal Hurwitz; Herut and the
Liberal Party ure called the GAHAL bloc and,
together with the State List and Free Center, they
form the Likud bloc led by Menahem Begin; Yadd
(new liberal party), Shulamit Aloni: AKI (Israel
Communist Opposition Party—predominantly
Jewish), leader Esther Wilenska: RAKAH (Com-
munist Party — predominantly Arab), Secretary
General Meir Wilner; Moked (ultra-leftist), leader
Meir Pa‘ il
Voting strength: out of 120 seats, Israel Labor
Party-MAPAM-Arab List Alignment 53 seats: Likud
bloc 38 seats; National Religious Party 10 seats:
Independent Liberal Party 4 seats: Agudat Religious
Front 5 seats; RAKAH 4 seats: Yadd 4 seats; Moked 1
seat; independents | seat
Communists: divided between AKI (Jewish party)
with a new splinter group with at most a few hundred
members, and RAKAH (Arab party) with some 1,500
members; neither constitutes a subversive threat
Other political or pressure groups: right-wing
Jewish Defense League led by Rabbi Meir Kahane
Black Panthers, 2 loosely organized youth group
seeking more benefits for oriental Jews
Member of: FAO, GATT, IAEA, IBRD, ICAO,
IDA, IFC, ILO, IMCO, IMF, IPU, ITU, OAS
(observer), Seabeds Committee, U.N., UNESCO,
UPU, WFTU, WHO, WMO','0f086866735c73e5a9b92ddf43cf186b24b01d7a4887ed12429fb0568a903373','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('740190a5cb41966315eff7282808f778e984bfc220b653ce1a55d5bd88a0a0d9',1976,'IT','Italy','government',257,'Legal name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides for
establishment of 20 regions; 5 (Sicilia, Sardegna,
Trentino-Alto Adige, Friuli-Venezia Giulia, and Valle
d’ Aosta) have been functioning for some time and the
remaining 15 regions were instituted on 1 April 1972;
94 provinces
103
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Legal system: based on civil law system, with
ecclesiastical law influence; constitution came into
effect 1 January 1948; judicial review under certain
conditions in Constitutional Court; has not accepted
compulsory IC] jurisdiction
Branches: executive — President empowered to
dissolve Parliament and call national election; he is
also Commander of the Armed Forces and presides
over the Supreme Defense Council; otherwise,
authority to govern invested in Council of Ministers;
legislative power invested in bicameral, popularly
clected Parliament; Italy has an independent judicial
establishment
Government leaders: President Giovanni Leone;
Premier Aldo Moro
Suffrage: universal over age 18 (except in
Senatorial elections where minimum age of voter is
22)
Elections: national elections for Parliament held
every 5 years (most recent, May 1972); provincial and
municipal elections held every 5 years with some out
of phase; regional elections every 5 years (held June
1975)
Political parties and leaders: Christian Demo-
cratic Party (DC), Benigno Zaccagnini (party
Colombo; Communist Party (PCI), Luigi Longo,
Enrico Berlinguer (secretary general); Italian Socialist
Party (PSI), Francesco De Martino (party secretary),
Pietro Nenni, Giacomo Mancini; Italian Social
Democratic Party (PSDI), Flavio Orlandi; Mario
‘Yanassi (party secretary), Giuseppe Saragat; Liberal
Party (PLI), Agostino Bignardi (party secretary);
{talian Social Movement (MSI), Giorgio Almirante;
Republican Party (PRI), Oddo Biasini (party
Voting strength (1972 election): 38.8% DC, 27.2%
PCL, 9.6% PSI, 3.9% PLI, 8.7% MSI, 2.9% PRI, 5.1%
PSDI, 3.8% other
Communists: 1,702,562 members (as of July 1975);
number of sympathizers cannot be determined
Other political or pressure groups: the Vatican;
three major trade union confederations (CGIL —
Communist dominated, CISL — Christian Demo-
cratic, and UIL — Social Democratic, Socialist, and
Republican); Italian manufacturers association
(Confindustria); organized farm groups
Member of: ADB, Council of Europe, DAC, EC,
ECOWAS, ECSC, EEC, EIB, ELDO, ESRO,
EURATOM, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IEA, IFC, IHO, ILO, IMCO, IMF, IPU, ITU,
NATO, OAS (observer), OECD, Seabeds Committee,
U.N., UNESCO, UPU, WCL, WEU, WFTU, WHO,
WMO
Legal name: Republic of Ivory Coast
Type: republic, one-party presidential regime
established 1960
Capital: Abidjan
Political subdivisions: 24 departments subdivided
into 127 subprefectures
Legal system: based on French civil law system
and customary law; constitution adopted 1960,
amended 1963; judicial review in the Constitutional
Chamber of the Supreme Court; legal education at
Abidjan School of Law; has not accepted compulsory
IC] jurisdiction
Branches: President has
unicameral legislature, separate judiciary
Government leader: President Felix Houphouct-
Boigny
Suffrage: universal over age 21
Elections: uncontested Presidential and legislative
elections held in November 1970 for 5-year term
Political parties and leaders: Parti Democratique
de la Cote d''Ivoire (PDCI), (only party); official party
leader is Secretary General Philippe Yace, but
Houphouet-Boigny is in control
Communists: no Communist party; possibly some
sympathizers
Member of: AFDB, CEAO, EAMA, ECA, EIB
(associate), Entente, FAO, GATT, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
Niger River Commission, OAU, OCAM, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO','a39afe6cabc65b31891ce0f0f0171b78d05c9a75496f6a6905743713d1223c6a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48d7cf525215d6e021e8d31a31bd8e0800909ef4ede6d0fbe02313d39545f2f5',1976,'CU','Cuba','government',261,'Legal name: Jamaica
Type: independent state within Commonwealth
since August 1962, recognizing Elizabeth II as head of
state
Capital: Kingston
Political subdivisions: 12 parishes and the
Kingston-St. Andrew corporate area
Legal system: based on English common law; has
not accepted compulsory ICJ jurisdiction
Branches: cabinet headed by Prime Minister; 53-
member elected House of Representatives; 21-
member Senate (13 nominated by the Prime Minister,
8 by opposition leader); judiciary follows British
tradition under a Chief Justice
Government leader: Prime Minister Michacl
Manley
Suffrage: universal, age 18 and over
Elections: at discretion of Governor-General upon
advice of Prime Minister but within 5 years; latest
held 29 February 1972
Political parties and leaders: People’s National
Party (PNP), Michael Manley; Jamaica Labor Party
(JLP), Edward Seaga
Voting strength (1972 general elections): 56.55% °
PNP, 43.21% JLP, 0.24% other
Communists: a few hundred Marxist and
Communist sympathizers
Other political or pressure groups: New World
Group (Caribbean regionalists, nationalists, and leftist
intellectual fraternity); Rastafarians (Negro religious/
racial cultists, pan-Africanists); New Creation
International Peacemakers Tabernacle (leftist group)
Member of: CARICOM, FAO, GATT, IADB,
IAEA, IBRD, ICAO, IDB, IFC, ILO, IMF, ITU,
OAS, Pan American Health Organization, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WHO,
WMO','1fc50c21951b0356385aa4a3e5713bb7ea3cc2c6981e367fb20488950ed9c162','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd279f38e839e5ba6f3cdaeb43b5a8cfa0b12882465e2146d211b7c1ab11422a',1976,'JP','Japan','government',265,'Legal name: Japan
Type: constitutional monarchy
Capital: Tokyo
Political subdivisions: 47 prefectures (Ryukyus
hecame 47th prefecture on 15 May 1972)
Legal system: civil law system with English-
American influence; constitution promulgated in
1946; judicial review of legislative acts in the Supreme
Court; accepts compulsory IC] jurisdiction, with
reservations
Branches: Emperor is merely symbol of state:
exccutive power is vested in cabinet dominated by the
Prime Minister, chosen by the Lower House of the
bicameral, elective legislature (Diet); judiciary is
independent
Government leader: Prime Minister Takeo Miki
Suffrage: universal over age 20
Elections: general elections held every 4 years or
upon dissolution of Lower House. triennially for one-
half of Upper House
108
Approved For Release 2005/04/22
Political parties and leaders: Liberal Democratic
Party (LDP), T. Miki, President; Japan Socialist Party
(JSP), T. Narita, Chairman; Democratic Socialist
Party (DSP), I. Kasuga, Chairman: Japan Communist
Party, K. Miyamoto, Presidium Chair-man: Komeito
(CGP), Y. Takeiri, Chairman
Voting strength (1972 election): 46.8% LDP,
21,9% JSP, 10.5% JCP, 8.5% CGP, 7.0% DSP, 5.3%
others
Communists: 350,000, 3,000,000 sympathizers
Member of: ADB, ASPAC, Colombo Plan, DAC,
ESCAP, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IEA, IFC, THO, ILO, IMCO, IMF, IPU, IRC, ITU,
OECD, Seabeds Committee, U.N., UNESCO, UPU,
WCL, WFTU, WHO, WMO
Legal name: Democratic Peoples Republic of
Korea
Type: Communist state; one-man rule
Capital: Pyongyang
Political subdivisions: 9 provinces, 3 special cities
(P’yongyang, Hamhung, Ch’ongjin), and 1 special
district (Kaesong)
Legal system: based on German civil law system
with Japanese influences and Communist legal
theory; constitution adopted 1948 and revised 1972;
no judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Branches: Supreme Peoples Assembly theoretically
supervises Legislative and Judicial function
Government and party leaders: Kim [I-song,
President DPRK, and General Secretary of the Korean
Labor Party; Kim I], Premier
Suffrage; Universal at age 17
Elections: election to SPA every 4 years, but this
constitutional provision not necessarily followed —
last election December 1972
Political party: Korean Labor (Communist) Party;
claimed membership of about 1.6 million, or about
12% of population
Member of: IPU, Seabeds Committee, U.N.
(observer status only), UNCTAD, WFTU, WHO
Legal name: Republic of Korea
Type: republic; power centralized in a strong
executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities;
heads centrally appointed
Legal system: combines elements of continental
European civil law systems, Anglo-American law, and
Chinese classical thought; constitution approved
1972: has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative (unicameral),
judiciary, National Conference of Unification
Government leaders: President Pak Chong-hui;
Prime Minister Kim Chong-pil
Suffrage: universal over age 20
Elections: presidential every 6 years indirectly by
the National Conference of Unification, last election
December 1972; two-thirds of the 219-member
National Assembly is elected directly for the same
period within six months of the presidential clection,
remaining third nominated by the President and
elected by the National Conference for a three-year
term; last election February 1973, Revitalization
Group — 73 seats, Democratic Republican Party —
73 seats, New Democratic Party — 52 seats,
Democratic Unification Party — 2 seats, Inde-
pendents — 19 seats
Political parties and leaders: pro-government —
Revitalization Group (appointed) (Chairman, Pak
Tu-Chin) and Democratic Republican Party (Acting
Chairman, Yi Hyo-sang); New Democratic Party
(Chairman, Kim Yong-sam); Democratic Unification
(Chairman, Yang Il-tong)
Voting strength: (1973 election) popular vote
11,896,484; DRP 38.8%, NDP 32.8%, DUP 10.2%,
Independent 18.1%, 0.1% invalid
Communists: Communist activity banned by
government; an estimated 37,000-50,000 former
members and supporters
Other political or pressure groups: Federation of
Korean Trade Unions; Korean Veterans Association;
large potentially volatile student population
concentrated in Seoul
Member of: ADB, Asian Parliamentary Union,
Asian People’s Anti-Communist League (APACL),
ASPAC, Colombo Plan, ESCAP, FAO, GATT,
Geneva Conventions of 1949 for the protection of war
victims, IAEA, IBRD, ICAO, IDA, IFC, 1HO,
IMCO, IMF, INTELSAT, INTERPOL, IPU, ITU,
UNESCO, U.N. Special Fund, UPU, WCL, WHO,
WMO, World Anti-Communist League (WACL);
official observer at U.N., does not hold U.N.
membership','737fccc517f2a41159f406c69acf6c44a6f127fa31e9fd0cf6dd2b892b110056','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9be485684da20e031746635bc5c8cdf4b4dd0116eaabdfa2a0b07914e6e6c7c4',1976,'JO','Jordan','government',269,'Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: ‘Amman
Political subdivisions: 8 districts (3 are under
Isracli occupation) under centrally appointed officials
Legal system: based on Islamic law and French
codes; constitution adopted 1952; judicial review of
legislative acts in a specially provided High Tribunal;
has not accepted compulsory ICJ jurisdiction
Branches: King holds balance of power; Prime
Minister exercises executive authority in name of
King; Cabinet appointed by King and responsible to
parliament; bicameral parliament with Chamber of
Deputies last chosen by national elections in April
1967, and dissolved by King in November 1974;
Senate last appointed by King in November 1974,
present parliament subservient to executive; secular
court system based on differing legal systems of the
former Transjordan and Palestine; law Western in
concept and structure; Sharia (religious) courts for
Muslims, and religious community council courts for
non-Muslim communities; desert police carry out
quasi-judicial functions in desert areas
Government leader: King Husayn ibn Talal al-
Hashimi
Suffrage: all citizens over age 20
Political parties and leaders: political party
activity illegal since 1957; Palestine Liberation
Organization and various smaller fedayeen groups
109
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
JORDAN/KENYA
clandestinely active on West Bank; Ba’th Party of
Jordan, Dr. Munif Razza; Muslim Brotherhood
Communists: party actively repressed, membership
estimated at less than 500
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, Seabeds
Committee, U.N., UNESCO, UPU, WFTU, WHO,
WMO','58bf4f9f092c27b6a28897d2ff80c6c9c7a270a78a237f3b2a4925744e8bede3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2081c6eaf24d3b8e11cdd0db2d12ca3fab6a0573c702452d4f95fc7e3804320',1976,'KE','Kenya','government',273,'Legal name: Republic of Kenya
Type: republic within Commonwealth since
December 1963
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi
Area
Legal system: based on English common law,
tribal law and Islamic law; constitution enacted 1963:
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
KENYA/KOREA, NORTH
judicial review in Supreme Court; legal education at
University Kenya School of Law in Nairobi; accepts
compulsory ICJ jurisdiction, with reservations
Branches: President and Cabinct responsible to
unicameral legislature (National Assembly) of 170
seats, 158 directly elected by constituencies and 12
appointed by the President; Assembly must be
reelected at least every 5 years; High Court, with
Chief Justice and at least 11 justices, has unlimited
original jurisdiction to hear and determine any civil or
criminal proceeding; provision for systems of courts of
appeal with ultimate appcal to East African Court of
Appeals
Government leader: President Jomo Kenyatta
Suffrage: universal over age 21
Elections: general election (October 1974) elected
present National Assembly; next elections due 1979
Political party and leaders: Kenya Africa National
Union (KANU), president, Jomo Kenyatta
Voting strength: KANU holds all seats in the
National Assembly
Communists: may be a few Communists and
sympathizers
Other political or pressure groups: labor unions
Member of: AFDB, EAC, FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
Scabeds Committee, U.N., UNESCO, UPU, WHO,
WMO','860d96810a2cf8a7c90fa45327054bdeb28e0dbe9744630f148de24d11511d2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f0e11e6ccb46ce2f91b2ff87c4854e6b784140c50ec6af425ab8e0728935c4d',1976,'KW','Kuwait','government',277,'Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Al Kuwayt
Political subdivisions: 3 governorates, 10 voting
constituencies
Legal system: civil law system with Islamic law
significant in personal matters; constitution took
effect 1963, judicial review of legislative acts not yet
determined; has not accepted compulsory IC]
jurisdiction
Branches: Council of Ministers: National Assembly
Government leader: Emir Sabah al-Salim_ Al
Sabah
Suffrage: native born and naturalized males age 21
or over
Elections: held every 4 years for National
Assembly; held in January 1975
Political parties and leaders: political parties
prohibited, some small clandestine groups are active
Communists: insignificant
Other political or pressure groups: none
Member of: Arab League, FAO, GATT, IAEKA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU,
ITU, OAPEC, OPEC, U.N., UNESCO, UPU, WHO,
WMO
Legal name: Peoples Democratic Republic of Laos
Type: republic
Capital: Vientiane
Political subdivisions: 13 provinces subdivided
into districts, cantons, and villages
Legal system: based on civil law system; has not
accepted compulsory ICJ jurisdiction
Branches: President; 45-member Supreme Council;
39-member cabinet formed on 4 December; cabinet is
totally Communist but council contains a few
nominal neutralists and non-Communists; National
Assembly due to be re-established in April 1976 after
completion of elections
Government leaders: President, Prince Souphan-
ouvong; Prime Minister, Kaysone Phomvihan;
Deputy Prime Ministers, Nouhak Phoumsavan,
Phoumi Vongvichit, Phoun Sipaseut, and Khamtai
Siphadon
Suffrage: universal over age 18
Elections: elections for new National Assembly
scheduled to be completed on April 1, 1976
115
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LAOS/LEBANON
Political parties and leaders: Lao People’s
Revolutionary Party (Communist) includes Lao
Patriotic Front and Alliance Committee of Patriotic
Neutralist Forces; other parties are moribund
Communists: Lao People’s Revolutionary Party;
membership unknown
Other political or pressure groups: non-
Communist political groups are moribund; most
leaders have fled the country
Member of: ADB, Colombo Plan, ESCAP, FAO,
IBRD, ICAO, IDA, ILO, IMF, IPU, ITU, Mekong
Committee, SEAMES, U.N., UNCTAD, UNESCO,
UPU, WFTU, WHO, WMO','7ec7c9757f7608801ce9bd50dc6ee1287a824fab5bdb3408ce92f2fda4b33c5f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dc1c9ca1e43dbf8c3361ee5b33d4efb12716108e3832e2ff0041c6846f9dd45',1976,'LB','Lebanon','government',281,'Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law,
and civil law system; constitution mandated in 1920;
no judicial review of legislative acts; legal education
at University of Lebanon; has not accepted
compulsory ICJ jurisdiction
Branches: power lies with President elected by
parliament (Chamber of Deputies); Cabinet
appointed by President, approved by parliament;
independent secular courts on French pattern;
religious courts for matters of marriage, divorce,
inheritance, etc.; by custom, President is a Maronite
Christian, Prime Minister a Sunni Muslim, and
president of parliament a Shia Muslim; each of 9
religious communities represented in parliament in
proportion to national numerical strength
Government leader: President Sulayman Fran-
jiyah
Suffrage: compulsory for all males over 21;
authorized for women over 21 with elementary
education
Elections: for Chamber of Deputies, held every 4
years or within 3 months of dissolution of Chamber;
held April 1972
Political parties and leaders: political party
activity is organized along sectarian lines; numerous
political groupings exist, consisting of individual
political figures and followers motivated by religious,
clan, and economic considerations; political stability
dependent on maintenance of balance between
religious communities
Communists: only legal Communist party in
Middle East; legalized in 1970; members and
sympathizers estimated at 2,000-3,000
Other political or pressure groups: Palestinian
guerrilla organizations
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
Seabeds Committee, U.N., UNESCO, UPU, WFTU,
WHO, WMO','9876e5f20251def8a1283dcddae4454c9854d439afddf482c148d1ce486dc7ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dcfc002366d2950c8e0330cc85e4d2c70f8078a8e1b2f41f6b7495566f45be5',1976,'LS','Lesotho','government',285,'Legal name: Kingdom of Lesotho
Type: constitutional monarchy under King
Moshoeshoe II; independent member of com-
monwealth since 1966
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and
Roman-Dutch law; constitution came into effect
1966; judicial review of legislative acts in High Court
and Court of Appeal; legal education at University of
Botswana, Lesotho, and Swaziland (located in
lesotho); has not accepted compulsory ICJ
jurisdiction
Branches: executive, divided between a largely
ceremonial King and a Prime Minister who leads
cabinet of at least 7 members; Prime Minister
dismissed bicameral legislature in early 1970 and
subsequently has ruled by decree: Prime Minister
convened Interim National Assembly in April 1973 in
order to devise new constitution: judicial — 63
Lesotho courts administer customary law for Africans,
High Court and subordinate courts have criminal
jurisdiction over all residents, Court of Appeal at
Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua
Jonathan
Suffrage: universal for adults
Elections: elections held in January 1970; nullified
allegedly because of election irregularities: subsequent
clections promised at unspecified date
Political parties and leaders: Basutoland Congress
Party (BCP), Ntsu Mokhele: National Party (BNP),
Chief Leabua Jonathan
118
Voting strength: in 1970 elections for National
Assembly, BNP won 82 seats; BCP, 22 seats; minor
parties, 4 seats
Communists: negligible, Communist Party of
Lesotho banned in early 1970
Member of: Commonwealth, FAO, GATT (de
facto), IBRD, IDA, IFC, IMF, ITU, OAU, U.LN.,
UNESCO, UPU, WHO','6e9665a0d34bef3208f7c95a4f0c4bd14c1afa611bcd6d8c95e355e87bde2965','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42e7a9ec8dfb5f665a4051af979b5bc75cf50ba30edf82afa9956a6108180d03',1976,'LR','Liberia','government',289,'Legal name: Republic of Liberia
Type: republic in form, strong executive dominates,
with few constraints
Capital: Monrovia
Political subdivisions: country divided into 9
counties; President appoints all officials of
significance
Legal system: based on U.S. constitutional theory;
recent codes drawn up by Cornell University;
Approved For Release 2005/04/22
constitution adopted 1847; amended 1907, 1926,
1934, 1955, and 1975; no constitutional provision for
judicial review of legislative acts; legal education at
Louis Arthur Grimes School of Law, University of
Liberia; accepts compulsory ICJ jurisdiction, with
reservations
Branches: President, clected by popular vote,
limited to a single eight-year term, controls through
appointive powers, authority over national expendi-
tures, and a variety of informal sanctions; 2-house
legislature elected by popular vote; judiciary
consisting of Supreme Court and variety of lower
courts
Government leader: President William R. Tolbert,
Jr.
Suffrage: universal 18 years and over
Elections: members of House of Representatives
elected for 4-year terms, most recently in October
1975; Senate members elected for 6-year terms, one-
half elected in May 1973; President Tolbert,
constitutional successor to President Tubman who
died in July 1971, completed the four year term to
which Tubman was elected and was then clected in
October 1975 for an eight-year term
Political parties and leaders: Truc Whig Party, in
power since 1878, only political party; President
Tolbert is leader
Voting strength: 1975 elections uncontested; True
Whig Party won all but a handful of votes
Communists: no Communist Party and only a few
sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU,
ITU, OAU, Seabeds Committee, U.N., UNESCO,
UPU, WHO','9e9e2a4465a6093d6bc7aafa8c62c32a8a4e8b97b0a782d24cde697e58eb9c56','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d05c466923930614918d044e6dea0204cb6c27be3af387ebdc6cbf91f02fd697',1976,'LY','Libya','government',293,'Legal name: Libyan Arab Republic
Type: republic; under military control following
ouster of king on 1 September 1969; provisional
constitution promulgated December 1969: loosely
confederated with Egypt and Syria in Confederation
of Arab Republics (CAR) on 1 September 1971
Capital: Tripoli
Political subdivisions: 10 administrative provinces
closely controlled by central government; district
commissioners appointed by revolutionary Command
Council
Legal system: based on Italian civil law system and
Islamic law; separate religious courts; no constitu-
tional provision for judicial review of legislative acts:
legal education at Law School, at University of Libya
at Banghazi; has not accepted compulsory IC]
jurisdiction
Branches: paramount political power and
authority rests with the ll-man Revolutionary
Command Council (RCC); cabinet of 13 ministers:
Parliament has been dissolved
Government leaders: Revolutionary Command
Council Chairman Colonel Mu’ammar Qadhafi;
Prime Minister, Major Abd al-Salam Jallud
Suffrage: universal
Elections: parliamentary elections last held in May
1965; election for CAR assembly in March 1972
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LIBYA/LIECHTENSTEIN
Political parties and leaders: Libyan Arab
Socialist Union, RCC member Major Bashir Hawadi,
Secretary General; Mu’ammar Qadhafi, President
Communists: no organized party, negligible
membership
Other political or pressure groups: various Arab
nationalist movements and the Arab Socialist
Resurrection (Bath) party with small, almost
negligible memberships may be functioning
clandestinely
Member of: AFDB, Arab League, FAO, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, ITU,
OAPEC, OAU, OPEC, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO','fa1fa46f9a531785ec61a23f364092e4404f4b91d494a8cd6ac25575e89e3f18','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9537fa14f978debf37bb7eacb872398a23badeee606976c527ec2f3d12b2055',1976,'LI','Liechtenstein','government',297,'Legal name: Principality of Liechtenstein
121
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LIECHTENSTEIN/LUXEMBOURG
Type: hereditary constitutional monarchy
Capital: Vaduz
Political subdivisions: 11 districts
Legal system: based on Swiss law; constitution
adopted 1921; judicial review of legislative acts in a
special Constitutional Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: unicameral Parliament, hereditary
Prince, independent judiciary
Government leaders: Head of State, Prince Franz
Joseph II, Chief of Government, Dr. Walter Kieber
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1978
Political parties and leaders: Fatherland Union
Party (VU), Dr. Alfred Hilbe; Progressive Citizens
Party (FBP), Dr. Gerard Batliner
Voting strength (1974 election): FBP over 50%
Communists: none
Member of: IAEA, ITU, UPU, WCL,; considering
U.N. membership; desires affiliation with The
Council of Europe; under a 1923 treaty, Switzerland
handles Liechtenstein’s post and telegraph systems,
customs, and foreign relations','a90c793a543dc64527425d0cfe759639101dd8c6c1c25acb1183156da12c5ab2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('353735256d388e65407be89b3b63a7e8a857e310ba2895ab6444a832dd015b59',1976,'LU','Luxembourg','government',302,'Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for
administrative purposes has 3 districts (Luxembourg,
Diekirch, Grevenmacher) and 12 cantons
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LUXEMBOURG/MACAO
Legal system: based on civil law system;
constitution adopted 1868, judicial review of
legislative acts in the Cassation Court only; accepts
compulsory ICJ jurisdiction
Branches: parliamentary democracy; seven
ministers comprise Council of Government headed by
President, which constitutes the executive; it is
responsible to the unicameral legislature, the
Chamber of Deputies; the Council of State, appointed
for indefinite term, exercises some powers of an upper
house; judicial power exercised by independent courts
Government leaders: Grand Duke Jean, Head of
State; Gaston Thorn, Prime Minister
Suffrage: universal and compulsory over age 18
Elections: every 5 years for entire Chamber of
Deputies; latest elections May 1974
Political parties and leaders: Christian Social
Union, Pierre Werner and Jacques Santer (Party
President); Socialist, Lydie Schmit (Party President);
Social Democrat, Henry Cravatte (Party President);
Democratic, Gaston Thorn (Party President and Prime
Minister); Communist, Dominique Urbany
Voting strength in Chamber of Deputies
(1974): Christian Socialist, 18; Socialist Workers, 17;
Democrats, 14; Social Democrats, 5; Communists, 5
Communists: 500 party members (1974)
Other political or pressure groups: group of steel
industries representing iron and steel industry,
Centrale Paysanne representing agricultural pro-
ducers; Christian and Socialist labor unions,
Federation of Industrialists; Artisans and Shopkeepers
Federation
Member of: Benelux, BLEU, Council of Europe,
EC, ECSC, EEC, EIB, EURATOM, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IEA, IFC, ILO, IMF, IPU,
ITU, NATO, OECD, Seabeds Committee, U.N.,
UNESCO, UPU, WCL, WEU, WHO, WMO','b0fe5b12b4006dd567745ebc92f6cede0284f14fa4f4784e20037dac575e7fcf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfcaf8dba71106572be9aaf657be147660ee91d9ec1fa7cb3705db0e28e4a645',1976,'PH','Philippines','government',307,'Legal name: Province of Macao
noun—Macaon(s); adjective—
Type: overseas province of Portugal
Capital: Lisbon (Portugal)
Political subdivisions: municipality of Macao, and
2 islands
Legal system: Portuguese civil law system
Branches: Governor, who dominates legislative and
executive branches, assisted by Legislative Council
with unknown number of appointed and 8 elected
members; the Urban Council with 3 governor-
uppointed and 4 elected members; all high-ranking
officials appointive under provisions of revised
Organic Overseas Law; new organic law to have come
into effect in January 1973 to replace legislative
council with a legislative assembly
Government leader: Brigadier Jose Manuel Nobre
De Carvalho, Governor
Suffrage: restricted to Portuguese citizens
Elections: conducted every 4 years; last held
December 1972
Political parties and leaders: Portuguese National
Union (Uniao Nacional) only legal party, as in~
Portugal; Governor is leading political figure
124
Communists: numbers unknown
Other political or pressure groups: wealthy
Macanese and Chinese representing local interests,
wealthy pro-Communist merchants representing
China’s interests; in January 1967 Macao Govern-
ment acceded to Chinese demands which gave
Chinese veto power over administration of the enclave
Legal name: Republic of the Philippines
Type: republic
Capital: Quezon
Political subdivisions: 72 provinces
Legal system: based on Spanish, Islamic, and
Anglo-American law; parliamentary constitution
passed 1978; judicial review of legislative acts in the
Supreme Court; legal education at University of the
Philippines, Ateneo de Manila University, and 71
other law schools; accepts compulsory ICJ jurisdic-
tion, with reservations; currently being ruled under
martial law
Branches: new constitution (currently suspended)
provides for unicameral National Assembly, and a
strong executive branch under a prime minister;
judicial branch headed by Supreme Court with
descending authority in a Court of Appeals, courts of
First Instance in various provinces, municipal courts
in chartered cities, and justices of the peace in towns
and municipalities; these justices have considerably
more authority than do justices of the peace in the
US.
Government leader: President Ferdinand E.
Marcos
Suffrage: universal over age 18
Elections: elections suspended for the indefinite
future
Political parties and leaders: political parties
currently in limbo because of martial law
Communists: about 1,900 armed insurgents
Member of: ADB, ASEAN, ASPAC, Colombo
Plan, ESCAP, FAO, IAEA, IBRD, ICAO, IDA, IFC,
IHO, ILO, IMCO, IMF, IPU, ITU, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WFTU,
WHO, WMO','417feeb4064ef278b70aaf053cfb65ee7bec2b95005308edcc350de41f951916','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba06858681fcf44bd3c7be6b531f6f3bfab307c930992b38653c4b39488864fe',1976,'MG','Madagascar','government',311,'Legal name: Malagasy Republic
Type: republic; military has wielded real authority
since May 1972
Capital: Tananarive
Political subdivisions: 6 provinces
Legal system: based on French civil law systern
and traditional Malagasy law; constitution of 1959
modified in October 1972 by law establishing
provisional government institutions; legal education
at National School of Law, University of Madagascar;
has not accepted compulsory ICJ jurisdiction
Branches: executive—an 8-member Supreme
Revolutionary Council; assisted by cabinet called
Council of Ministers; National Popular Development
Council created to replace the legislature in October
1972; Military Committee for Development; regular
Approved For Release 2005/04/22 :
courts are patterned after French system, and a High
Council of Institutions reviews all legislation to
determine its constitutional validity
Government leader: Captain Didier Ratsiraka,
President of Supreme Revolutionary Council
Suffrage: universal for adults
Elections: government in October 1972 postponed
all political elections indefinitely
Political parties and leaders: Malagasy Socialist
Party (PSM), led by Philibert Tsiranana and Andre
Resampa, formed in 1974 as a result of union of Social
Democratic Party (PSD) and Malagasy Socialist
Union (USM); Congress Party for the Independence
of Madagascar (AKFM), led by Richard Andriaman-
jato; National Movement for the Independence of
Madagascar (MONIMA), led by Monja Jaona;
parties are permitted to exist but are barred from
positions of political authority because of postpone-
ment of elections
Voting strength: number of registered voters (1972)
—3.5 million; (in 1973 elections) non-party
candidates won 81% of seats in National Popular
Development Council; AKFM won 38 seats, PSD 5,
USM 1, MONIMA 14
Communists: Communist party of virtually no
importance; small and vocal group of Communists
has gained strong position in leadership of AKFM, the
rank and file of which is non-Communist
Other political or pressure groups: Joint Struggle
Committee (KIM), association of students, teachers,
workers, and unemployed youth
Member of: EAMA, FAO, GATT, IAEA, IBRD,
IFC, ILO, IMF, ITU, OAU, OCAM, Seabeds
Committee, U.N., UNESCO, WCL, WFTU, WHO,
WMO
Legal name: Colony of the Seychelles
Type: British crown colony with large measure of
internal autonomy; Britain has agreed to grant
independence before late June 1976
Capital: Victoria, Mahe Island
Legal system: based on English common law,
French civil law system, and customary law
Branches: Governor, Prime Minister, Council of
Ministers, Legislative Assembly
Government leaders: Prime Minister, James
Mancham; Governor, Colin H. Allan
Suffrage: universal adult
Elections: April 1974, held every 5 years
Political parties and leaders: Seychelles Demo-
cratic Party (SDP), James R. Mancham, President;
Seychelles Peoples United Party (SPUP), France
Albert Rene, President
Voting strength: SDP won 13 seats in Legislative
Assembly with 52.4% popular vote in 1974 election,
SPUP won 2 seats with 47.6% of votes; under
agreement reached in March 1975, each party named
five new members to the legislature
Communists: negligible
Other political or pressure groups: trade unions
which are appendages of political parties
Member of: WCL','daa40509f7f7bcbda7b8ccf9c1256129cb63d7d83dfab0d14312d9ac6ce5b44e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a0bcc901008d874dbb7c0f7290d86769134730d9e9e1f9762616292924499b4',1976,'MW','Malawi','government',315,'Legal name: Republic of Malawi
Type: republic since July 1966; independent
member of Commonwealth since July 1964
Capital: Lilongwe
Political subdivisions: 3 administrative regions and
23 districts
Legal system: based on English common law and
customary law; constitution adopted 1964; judicial
review of legislative acts in the Supreme Court of
Appeal; has not accepted compulsory ICJ jurisdiction
Branches: strong presidential system with cab.net
appointed by President; unicameral National
Assembly of 60 elected and 15 nominated members;
High Court with Chief Justice and at least 2 justices
Government leader: Life President H. Kamuzu
Banda
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MALAWI/MALAYSIA
Suffrage: universal adult
Elections: scheduled for April 1971 but not held
since MCP candidates were unopposed
Political parties and leaders: Malawi Congress
Party (MCP), Dr. H. Kamuzu Banda
Communists: no Communist Party; may be a few
Communist sympathizers
Member of: AFDB, EEC (associate member),
FAO, GATT, IBRD, ICAO, IDA, IFC, ILO, IMF,
IPU, ITU, OAU, U.N., UNESCO, WHO, WMO','e4271e1c2969a7b7e3e37a000f810e888046fbc9b3688e57e2c10b828839441b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9675044a9db32749608e8cc6f2f243110a8e50b9a041fbe1e019574e2c4f9e6',1976,'MY','Malaysia','government',319,'Legal name: Malaysia
Type:
Malaysia: constitutional monarchy nominally
headed by Paramount Ruler (King); a bicameral
Parliament consisting of a 58-member Senate and a
154-member House of Representatives
Peninsular Malaysian states: hereditary rulers in
all but Penang and Malacca where Governors
appointed by Malaysian Government: powers of state
governments limited by federal constitution
noun—Malaysian(s); adjective—
128
Approved For Release 2005/04/22 :
Sabah: self-governingstate within Malaysia in
which it holds 16 seats in House of Representatives;
foreign affairs, defense, internal security, and other
powers delegated to federal government
Sarawak: self-governing state within Malaysia in
which it holds 24 seats in House of Representatives,
foreign affairs, defense, and internal security, and
other powers are delegated to federal government
Capital:
Peninsular Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu
Sarawak: Kuching
Political subdivisions: 13 states (including Sabah
and Sarawak)
Legal system: based on English common law;
constitution came into force 1963; judicial review of
legislative acts in the Supreme Court at request of
Supreme Head of the Federation; has not accepted
compulsory IC] jurisdiction
Branches: 9 state rulers alternate as Paramount
Ruler for 5-year terms; locus of executive power vested
in Prime Minister and cabinet, who are responsible to
bicameral parliament; following communal rioting in
May 1969, government imposed state of emergency
and suspended constitutional rights of all parlia-
mentary bodies; parliamentary democracy resumed in
February 1971
Peninsular Malaysia: executive branches of 11]
states vary in detail but are similar in design; a Chief
Minister, appointed by hereditary ruler or Governor,
heads an executive council (cabinet) which is
responsible to an elected, unicameral legislature
Sarawak and Sabah: executive branch headed by
Governor appointed by central government, largely
ceremonial role; executive power exercised by Chief
Minister who heads parliamentary cabinet responsible
to unicameral legislature; judiciary part of Malaysian
judicial system
Government leader: Head of State, Tun Abdul
Razak
Suffrage: universal over age 20
Elections: minimum of every 5 years, last elections
August 1974
Political parties and leaders:
Peninsular Malaysia: National Front, a confedera-
tion of 9 political parties dominated by United
Malays National Organization (UMNO), Tun Abdul
Razak; only opposition party of consequence —
Democratic Action Party (DAP)
Sabah: United Sabah National Organization
(USNO), Tun Mustapha bin Dato Harun; Sabah
Chinese Association (SCA), Khoo Siak Chiew; no
organized opposition
Sarawak: coalition Sarawak Alliance composed of
the Pekaka/Bumipatra Party, the United People’s
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Party (SUPP), Ong Kee Hui and Sarawak Chinese
Association; opposition Sarawak National Party
(SNAP), Stephen Ningkan
Voting strength:
Peninsular Malaysia: (1974 election) National
Front controls 135 of 154 seats in lower house of
parliament
Sabah: (1974 Assembly Elections) Alliance
unopposed, opposition candidates disqualified
Sarawak: (1974 elections) National Front 30 out of
48 state assembly seats
Communists:
Peninsular Malaysia: approx. 1,700 armed
insurgents on Thailand side of Thai/Malaysia border;
approx. 300 on Malaysian side
Sarawak: 170 armed insurgents in Sarawak
Sabah: insignificant
Member of: ADB, ASEAN, Colombo Plan,
Commonwealth, FAO, GATT, IAEA, IBRD, ICAO,
IDA, IFC, ILO, IMCO, IMF, IPU, ITU, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO','d79d9495250e66e9b9ea5105f8abc128ad11f13c985d057ce9df6a5503194ea3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aca54a3f4495ffc9a3ea9d4df9a1be77fdefa7e52924c39edfb09021448e9a59',1976,'MV','Maldives','government',323,'Legal name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative districts
corresponding to atolls
Legal system: based on Islamic law with
admixtures of English common law_ primarily
in commercial matters; has not accepted compulsory
ICJ jurisdiction
Branches: popularly elected unicameral national
legislature (Majlis) (members elected for 5-year
terms); elected President, chief executive; appointed
Chief Justice responsible for administration of Islamic
law
Government leader: President Ibrahim Nasir
Suffrage: universal over age 21
Political parties and leaders: no organized
political parties; country governed by the Didi clan
for the past eight centuries
Communists: negligible number
Member of: Colombo Plan, FAO, GATT (de
facto), IMCO, ITU, U.N., UPU, WHO','72893645a8ff51569ed2fba1ceaf8466f196d19fa81262aec8fa7d0792386ac0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c99d715e0ae464686cbd43b0974cccf3fbae3f37ceef325d2642c366f4efcfd',1976,'ML','Mali','government',327,'Legal name: Republic of Mali
Type: republic; under military regime since
November 1968
Capital: Bamako
Political subdivisions: 6 administrative regions; 42
administrative districts (cercles), arrondissements,
villages; all subordinate to central government
Legal system: based on French civil law system
and customary law; constitution adopted 1960,
amended 1961; judicial review of legislative acts in
Constitutional Section of Court of State; has not
accepted compulsory ICJ jurisdiction
Branches: exccutive authority exercised by Military
Committee of National Liberation (MCNL) com-
posed of 11 army officers; under MCNL functional
cabinet composed of civilians and army officers;
judiciary
Government leaders: Col. Moussa Traore,
president of MCNL, Chief of State and head of
Suffrage: universal over age 21
Political parties and leaders: political activity
proscribed by military government
Elections: MCNL promises elections at unspecified
date
Communists: a few Communists and some
sympathizers
Member of: AFDB, CEAO, ECA, FAO, GATT (de
facto), IAEA, IBRD, ICAO, IDA, ILO, IMF, ITU,
Niger River Commission, OAU, OMVS (Organization
for the development of the Senegal River Valley),
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WHO, WMO
Legal name: Republic of Malta
Type: parliamentary democracy, independent
republic within the Commonwealth since December
1974
Capital: Valletta
Political subdivisions: 2 main populated islands,
Malta and Gozo, divided into 10 electoral districts
(divisions)
Legal system: based on English common law;
constitution adopted 1961, came into force 1964,
has accepted compulsory ICJ jurisdiction, with
reservations
Branches: executive, consisting of prime minister
and cabinet; legislative, comprising 55-member
House of Representatives; independent judiciary
Government leader: Prime Minister Dom Mintoff
Suffrage: universal over age 21; registration
required
Elections: at the discretion of the Prime Minister,
but must be held before the expiration of a 5-year
electoral mandate; last election June 1971
Political parties and leaders: Nationalist Party,
Georgio Borg Olivier; Malta Labor Party, Dom
Mintoff
Voting strength (1971 election): Labor, 29 seats
(52.7%); Nationalist, 26 seats (47.2%)
Communists: less than 100 (est. )
Member of: Commonwealth, Council of Europe,
FAO, GATT, IBRD, ICAO, ILO, IMCO, IMF, ITU,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WHO','c83766aea13b7f07b66f2cdc618d620faede9887c384f110602a26b3b10646b6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fc1bb149dce1461d599bde0ab11bab2becb1cb304bdc3fd532dee98e89a9dca',1976,'MR','Mauritania','government',332,'Legal name: Islamic Republic of Mauritania
Type: republic; one-party presidential rule since
1960
Capital: Nouakchott
Political subdivisions: 12 regions and a capital
district
Legal system: based on French civil law system
and Islamic law; constitution adopted 1961, judicial
review of legislative acts in the Supreme Court, has
not accepted compulsory ICJ jurisdiction
Branches: president; Executive; separate judiciary
(appointed by president)
Government leader: President Moktar Ould
Daddah
Suffrage: universal for adults
Elections: presidential and parliamentary election
every 5 years; most recent August 1971
Political parties and leaders: Mauritanian Peoples
Party is only legal party, Secretary General Moktar
Ould Daddah
Communists: no Communist Party, but there is a
scattering of Maoist sympathizers
Member of: AFDB, Arab League, CEAO, EAMA,
EIB (associate), FAO, GATT, IBRD, ICAO, IDA,
IFC, ILO, IMCO, IMF, IPU, ITU, OAU, OMVS
(Organization for the Development of the Senegal
River Valley), Seabeds Committee, U.N., UNESCO,
UPU, WHO, WMO','0f6bdec2067434219c406050d9b0e3bd5ca3ba94af56bb955f4e0e693219c584','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('593d081131ea3bde7812ab7add4064a06c8feeb01f6de1ec2d95190fba78703b',1976,'MU','Mauritius','government',336,'Legal name: Mauritius
Type: independent state since 1968, recognizing
Elizabeth II as chief of state
Capital: Port Louis
Political subdivisions: 5 organized municipalities
and various island dependencies
Legal system: based on French civil law system
with elements of English common law in certain
areas; constitution adopted 6 March 1968
Branches: executive power exercised by Prime
Minister and 21-man Council of Ministers;
unicameral legislature (National Assembly) with 62
members elected by direct suffrage, 8 specially
elected, and one nominated
Government leader: Prime Minister Dr. Seewoosa-
gur Ramgoolam
Suffrage: universal over age 21
Elections: last held in August 1967; next scheduled
in 1972 postponed at least 4 years by constitutional
amendment
136
Political parties and leaders: a loose government
coalition consisting of Labor Party (S. Ramgoolam)
and Muslim Committee of Action (A. R. Mohamed);
Opposition parties — Parti Mauricien Social
Democrate (G. Duval), Independent Forward Bloc (S.
Bissoondoyal), Mauritius Democratic Union (M.
Lesage), Mouvement Militant Mauritian (P.
Berenger), Mouvement Militant Mauritian Socialiste
Progressist (D. Virahsawmy)
Voting strength: Muslim Committee of Action, 4
seats; Independent Forward Bloc, 4 seats; Mauritius
Labor Party, 41 seats; Mauritius Democratic Union, 5
seats; Parti Mauricien Social Democrate, 15 seats:
Mouvement Militant Mauritian Socialiste Progressist,
1 seat; 1 seat vacant
Communists: may be 2,000 sympathizers: several
Communist organizations; Mauritius Lenin Youth
Organization, Mauritius Women’s Committee,
Mauritius Communist Party, Mauritius People’s
Progressive Party, Mauritius Young Communist
League, Mauritius Liberation Front, Chinese Middle
School Friendly Association, Mauritius/USSR
Friendship Society
Other political or pressure groups: Tamil United
Party, Mauritius Workers Party
Member of: Commonwealth, FAO, GATT, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, OAU, OCAM,
U.N., UNESCO, UPU, WCL, WFTU, WHO, WMO
Legal name: Overseas Department of Reunion
Type: overseas department of France; represented
in French Parliament by three Deputies and two
Senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect
appointed by the French Minister of Interior, assisted
by a Secretary-General and an elected 36-man
General Council
Government leader: Prefect Paul Cousseran
Suffrage: universal adult
Elections: last municipal elections in 1971;
parliamentary election March 1973
Political parties and leaders: Reunion Communist
Party (RCP) led by Paul Verges, only organized
political movement on island; other political
candidates affiliated with metropolitan French
parties, which do not maintain permanent organiza-
tions on Reunion
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
REUNION/RHODESIA
Voting strength (parliamentary election 1973):
Union of Democrats for the Republic elected, one
senator and two deputies; Centrist Union, one
deputy; one Senator independent
Communists: Communist Party small — probably
only 15-20 hard-line Communists — but has support
among sugarcane cutters and in Le Port district
Member of: WFTU','01b47a1d4eb7790fb6be4117f4fea6eb8e50f901df31102f418359efb429259d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67b0c0eb2eacff536d88b2e904a881588005e643cb2aef74d36de5bc2a912998',1976,'US','United States','government',340,'Legal name: United Mexican States
Type: federal republic operating in fact under a
centralized government
Capital: Mexico
Political subdivisions: 31 states, Federal District
Legal system: mixture of U.S. constitutional theory
and civil law system; constitution established in 1917;
judicial review of legislative acts; accepts compulsory
{CJ jurisdiction, with reservations
Branches: dominant exccutive, bicameral legisla-
ture, Supreme Court
Government leader: President Luis Echeverria
Suffrage: universal over age 18; compulsory but
unenforced
Elections: national elections July 1976
Political parties and leaders: Institutional
Revolutionary Party (PRI), Porfirio Munoz Ledo;
National Action Party (PAN), Efrain Gonzalez
Morfin; Popular Socialist Party (PPS), Jorge
Cruickshank Garcia; Authentic Party of the
Revolution (PARM), Pedro Gonzalez Azcuaga
Voting strength: (1973 congressional elections) PRI
69.5%, PAN 14.7%, PPS 3.5%, PARM 1.8%, others
0.8%, annulled 9.7%
Communists: estimated 5,000 in Communist Party
Other political or pressure groups: Roman
Catholic Church, Confederation of Mexican Workers
(CTM), Confederation of Industrial Chambers
(CONCAMIN), Confederation of National Chambers
of Commerce (CONCANACO), National Cofedera-
tion of Campesinos (CNC), National Confederation
of Popular Organizations (CNOP), Revolutionary
Confederation of Workers and Peasants (CROC)
Member of: FAO, JADB, IAEA, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMCO, IMF, ITU, LAFTA,
137
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MEXICO/MONACO
OAS, Seabeds Committee, U.N., UNESCO, UPU,
WCL, WFTU, WHO, WMO
Legal name: United States of America
Legal system: based on English common law; dual
system of courts, state and federal; constitution
adopted 1789; judicial review of legislative acts;
accepts compulsory IC] jurisdiction, with reservations
Voting strength (1972 presidential election):
Republican Party (Nixon), 47,170,000; Democratic
Party (McGovern), 29,170,000; minor parties,
1,378,000
Communists: Party membership, 10,000-11,000
(est.); General Secretary, Gus Hall
Member of: ADB, ANZUS, CENTO, Colombo
Plan, DAC, FAO, GATT, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IEA, IFC, IHO, ILO, IMCO, IMF, IPU,
ITU, NATO, OAS, OECD, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO','ee332a92cf097a8f016591e4fa191ac308ccdd74c6399997546403f51b4bc257','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d3a4d71db95530b4642adfd46cfbde19617217e45f1b6c6edf2fd04d6ce5be6',1976,'MC','Monaco','government',344,'Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections
Legal system: based on French law; new
constitution adopted 1962; has
compulsory ICJ jurisdiction
not accepted
Branches: National Council (18 members);
Communal Council (15 members, headed by a
mayor)
Government leader: Prince Rainier Ill
Suffrage: universal
Elections: National Council every 5 years; most
recent 1973
Political parties and leaders: National Democratic
Entente, Democratic Union Movement, Monegasque
Actionist (1973)
Voting strength: figures for 1973: National
Democratic Entente, 16 seats; Democratic Union
Movement and Monegasque Actionist, 1 seat each
Member of: IAEA, THO, IPU, ITU, Seabeds
Committee, U.N., UNESCO, UPU, WHO','6f7cdf97b153db2365aee8eb15c2d8b253d09ffd54f0e900a9e7ebbf8e7c7567','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c1d110af4e8e0c447b5dfde8a55dddd3b68b04f4192def9cfefcd177caeb836',1976,'MN','Mongolia','government',348,'Legal name: Mongolian Peoples Republic,
Type: Communist state
Capital; Ulaanbaatar
Political subdivisions: 18 provinces and 2
autonomous municipalities (Ulaanbaatar and
Darhan)
Legal system: blend of Russian, Chinese, and
Turkish systems of law; new constitution adopted
1960: no constitutional provision for judicial review of
legislative acts; legal education at Ulaanbaatar State
139
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MONGOLIA/MOROCCO
University; has not accepted compulsory IC]
jurisdiction
Branches: constitution provides for a People’s
Great Hural (national assembly) and a_ highly
centralized administration
Party and government leaders: Y. Tsedenbal, First
Secretary of the MPRP and Chairman of the People’s
Great Hural; J. Batmunh, Chairman of the Council of
Ministers
Suffrage: universal; age 18 and over
Elections: national assembly elections held every 4
years; last elections held in June 1973
Political party: Mongolian People’s Revolutionary
(Communist) Party (MPRP); estimated membership,
58,000 (claimed 1972)
Member of: CEMA, ESCAP, TAFA, ILO, IPU,
ITU, Seabeds Committee, U.N., UNESCO, UPU,
WFTU, WHO, WMO','8a5e20ae6f298b419aba64fb573f66e59949fdc97e4be43e0758b8cf1f869e9e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e58dd38953e92104adec99e28def06568d56ca3e35742d945c7ec8d4fdd2780',1976,'MA','Morocco','government',352,'Legal name: Kingdom of Morocco
Type: constitutional monarchy (constitution
adopted 1972)
Capital: Rabat
Political subdivisions: 28 provinces and 2
prefectures
Legal system: based on Islamic law and French
and Spanish civil law system; judicial review of
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
legislative acts in Constitutional Chamber of Supreme
Court; modern legal education at branches of
Mohamed V University in Rabat and Casablanca and
Karaouine University in Fes; has not accepted
compulsory ICJ jurisdiction
Branches: constitution provides for Prime Minister
and ministers named by and responsible to King; King
has paramount executive powers; unicameral
legislature in abeyance until elections are held (two-
thirds to be directly elected, one third indirectly);
judiciary independent of other branches
Government leaders: King Hassan II; Prime
Minister Ahmed Osman
Suffrage: universal over age 20
Elections: last parliamentary elections held 21 and
28 August 1970 for Council of Representatives which
was dissolved in March 1972; elections for new
parliament created by Constitution adopted 15
March 1972 have not been held
Political parties and leaders: Istiqlal Party,
M’hamed Boucetta; Popular Movement (MP),
Mahjoubi Aherdan; Constitutional and Democratic
Popular Movement (MPCD), Dr. Abdelkrim Khatib;
National Union of Popular Forces (UNFP), split into
competitive factions under Abdallah Ibrahim and
Mahjoub Ben Seddik of Casablanca-based faction
and Abderrahim Bouabid of Rabat-based faction with
latter becoming Socialist Union of Popular Forces
(USFP) in September 1974; Democratic Constitu-
tional Party (PDC), Mohamed Hassan Quazzani;
Party for Progress and Socialism (PPS), legalized in
August 1974, successor to Party for Progress and
Socialisim (PPS), is front for Moroccan Communist
Party (MCP), which was proscribed in 1959, Ali Yata;
Istiqlal and the UNFP formed a National Front in
July 1970 to oppose the new constitution, boycotted
the parliamentary elections and the 1972 constitu-
tional referendum
Voting strength: August 1970 elections were
nonpolitical; 1 March 1972 constitutional referendum
tallied 98.7% for new constitution, 1.25% opposed
and National Front abstained from voting
Communists: 300 est.
Member of: AFDB, Arab League, EC (association
until 1974), FAO, GATT, IBRD, ICAO, IDA, IFC,
ILO, IMCO, IMF, IPU, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO','d70d2dcac25bfd174ab6364df9a3c6b6bdba8c31f3a6c796fad96d121e40bf5c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd05263ee5f3d962fa78ecdefe59ccc9cd3984748acc6ce2145cfadf84609d08',1976,'MZ','Mozambique','government',356,'Legal name: Peoples Republic of Mozambique
Type: peoples republic; achieved independence
from Portugal in June 1975
Capital: Lourenco Marques
142
Political subdivisions: 10 districts administered by
district governors; municipalities governed by
appointed official
Legal system: based on Portuguese civil law system
and customary law
Branches: none established
Government leader: President Samora Machel:
Vice-President Marcelino dos Santos
Suffrage: not yet established
Elections: information not available on future
election schedule
Political parties and leaders: the Mozambique
Liberation Front (FRELIMO), led by Samora
Machel, is only legal party
Communists: none known
Member of: OAU, U.N.','32ca54d7da897f846b85284697708dcf3b9a24f3de8d915f2434ffaab1f2ef35','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89bf11758e599eaf2182c508d981ec3826cb347f33f8d2c95e4ff150e8a2eb18',1976,'NR','Nauru','government',362,'Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices
in Uaboe District
noun—Nauruan(s); adjective—
Political subdivisions: 14 districts
Branches: President elected from and by
Parliament for an unfixed term; popularly elected
unicameral legislature, the Parliament; Cabinet to
assist the President, four members, appointed by
President from Parliament members
Government leader: President Hammer De Roburt
Suffrage: universal adult
Elections: last held in January 1971
Political parties and leaders: there are no political
parties; De Roburt is only significant political figure
Member of: no present plans to join U.N.; enjoys
“special membership” in Commonwealth; South
Pacific Commission, ESCAP, INTERPOL, ITU, UPU','7ae31f8720e8d8d53374cfed73b3eafbf780690b8260a69b34611856489c2476','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('832a08ad7c754e61a4bb9e8e0449607d65f82db5633bb6f070fb5adeb24c883f',1976,'NP','Nepal','government',366,'Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Birendra
exercises autocratic control over multitiered
panchayat system of government
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and
English common law; legal education at Nepal Law
144
College in Kathmandu; has not accepted compulsory
ICJ jurisdiction
Branches: Council of Ministers appointed by the
King; indirectly elected National Panchayat
(Assembly)
Government leader: King Birendra Bir Bikram
Shah Deva; Prime Minister Nagendra Prasad Rijal
Suffrage: universal over age 21
Elections: village and town councils (panchayats)
elected by universal suffrage; district, zonal, and
National Panchayat members indirectly elected, most
for 6-year terms; 15 National Panchayat members
elected from five class organizations (women, workers,
youth, and ex-servicemen), four directly elected by all
voters possessing a B.A. or its equivalent, and 16 are
appointed by the King
Political parties and leaders: all political parties
outlawed
Communists: the combined membership of the two
wings of the Communist Party of Nepal (CPN) may
be on the order of 6,500, the majority (perhaps 5,000)
in the pro-Chinese wing; the CPN continues to
operate more or less openly, but internal dissension
has greatly hindered its effectiveness
Other political or pressure groups: proscribed
Nepali Congress Party led by B.P. Koirala from exile
in India
Member of: ADB, Colombo Plan, FAO, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, U.N.,
UNESCO, UPU, Seabeds Committee, WHO, WMO','e536df98d802db49492bfe603c6ff541231f39e09f350e7d38d3c333d8ee4c9d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f38cdfe8d7bfb1fdbed29054e4412c0e4357d6f774d1f2d6a5b948dbe01988b6',1976,'NZ','New Zealand','government',372,'Legal name: Dominion of New Zealand (rarely
used)
Type: independent state within Commonwealth,
recognizing Elizabeth II as head of state
Capital: Wellington
Political subdivisions: 112 counties
Legal system: based on English law, with special
land legislation and land courts for Maori tribesmen;
constitution consists of various documents, including
certain acts of the U.K. and New Zealand
Parliaments; legal education at Victoria, Auckland,
Canterbury, and Otago Universities; accepts
compulsory ICJ jurisdiction, with reservations
Branches: unicameral legislature (General As-
sembly, commonly called Parliament); Cabinet
responsible to Parliament; 3-level court system
(Magistrates’ Courts, Supreme Court, and Court of
Appeal)
Government leader: Prime Minister Robert D.
Muldoon
Suffrage: universal age 18 and over
Elections: held at 3 year intervals or sooner if
parliament is disolved by Prime Minister; last election
November 1975
Political parties and leaders: National Party
(Government), Robert D. Muldoon; Labour Party
150
(Opposition), Wallace E. Rowling; Social Credit
Political League, Bruce Beetham; Communist Party,
George Victor Wilcox; pro-Soviet Socialist Unity
Party, George Edward Jackson
Voting strength (1975 election): National Party 53
seats, Labour Party 34 seats
Communists: CPNZ about 300, SUP about 100
Member of: ADB, ANZUS, ASPAC, Colombo
Plan, DAC, ESCAP, FAO, GATT, IAEA, IBRD,
ICAO, IFA, IFC, IHO, 1LO, IMCO, IMF, IPU, ITU,
OECD, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO','358a834ee65dfa9223d0e92092874c6c3c26ff7027472116ae719f9ffb443f13','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c501eaed9f45aefd6a99ab3894b632a7f46ac179d22999a40dd00ad440fd3577',1976,'NI','Nicaragua','government',376,'Legal name: Republic of Nicaragua
Type: republic
Capital: Managua
Political subdivisions: 1 national district and 16
departments
Legal system: based on Spanish civil law system;
constitution adopted in 1974; legal education at
Universidad Nacional de Nicaragua and Universidad
Centroamericana; accepts compulsory ICJ jurisdic-
tion
Branches: President (traditionally dominant)
bicameral legislature, judiciary elected by legislature,
and Supreme Electoral Tribunal (4th branch)
Government leaders: President Anastasio Somoza
Suffrage: universal over age 18 if married or
literate, otherwise 21
Elections: every 6 years; municipal elections every
3 years
Political parties and leaders: Nationalist Liberal
Party (PLN), Anastasio Somoza; Nicaraguan
Conservative Party (PCN), Edmundo Paguaga
Voting strength (1974 elections): PLN, 95% of
votes; 3% of votes; PCN will, however, occupy 40% of
legislative seats by constitutional provision
Communists: Communist movement split into
hard-line Nicaraguan Socialist Party (PSN) illegal, 60
members; soft-line Nicaraguan Communist Party
(PCN) illegal, 40 members, and small pro-Castro
Sandinist National Liberation Front (FSLN) activist,
50-60 members; about 1,000 sympathizers
Other political or pressure groups: Democratic
Union of Liberation (UDEL), an opposition front
lacking legal status of a political party, composed of
anti-Somoza political movements and labor groups
with orientations ranging from conservative to
Christian Democrat to Communist, leadership
includes Pedro J. Chamorro, Ramiro Sacasa, Ignacio
Zelaya, Manuel Morales, Domingo Sanchez
Member of: CACM, FAO, GATT, IADB, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMF, INTELSAT, IPU,
151
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NICARAGUA/NIGER
ITU, OAS, ODECA, Seabeds Committee ULN.,
UNESCO, UPU, WCL, WHO, WMO','fde698de18e2145a8cd1009c03dcce43e7c5e48d568c050e8124ad93a92daf32','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('663103e6211fc17548f0ac245640a80279e6299a27ef13f7a01f5b864ddb2180',1976,'NE','Niger','government',380,'Legal name: Republic of Niger
“ Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NIGER/NIGERIA
Type: republic; military regime in power since
April 1974
Capital: Niamey
Political subdivisions:
arrondissements
Legal system: based on French civil law system
and customary law; constitution adopted 1960,
suspended 1974; judicial review of legislative acts in
Constitutional Chamber of the Supreme Court; has
not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by
Provisional Supreme Military Council (SMC)
composed of 12 army officers
Government leader: President Lt. Col. Seyni
Kountche
Suffrage: universal over age 21
Elections: political activity banned
Political parties and leaders: political parties
banned
Communists: no Communist party; some sympa-
thizers in outlawed Sawaba party
Member of: AFDB, CEAO, EAMA, ECA, Entente,
FAO, GATT, IAEA, IBRD, ICAO, IDA, ILO, IMF,
IPU, ITU, Lake Chad Basin Commission, Niger River
Commission, OAU, OCAM, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO
7 departments, 82','8f7291193353061d7d121eb52569136fe5386ac8c8990d313554091cfd62a7be','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4673f205331d57b89e1dfd2ae6b30ee74a0e0e5075792bfb44798f4bb2feb55',1976,'NG','Nigeria','government',384,'Legal name: The Federal Republic of Nigeria
Type: federal republic since 1963; under military
rule since January 1966
Capital: Lagos
Political subdivisions: 12 states, headed by a
military governor
Legal system: based on English common law,
tribal law, and Islamic law; new constitution to be
prepared; accepts compulsory ICJ jurisdiction with
reservations
adjective—
Branches: Federal Military Government; decrees
issued by Supreme Military Council, advised by
largely civilian Federal Executive Council
Government leader: Brigadier Murtala Muham-
med, Head of Federal Military Government and
Commander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage (except for
women in former Northern Region)
Elections: the military has promised to restore
power to an elected civilian regime when state and
federal legislative elections are held between October
1978 and October 1979
Political parties and leaders: political parties and
politically active tribal societies were dissolved by
decree on 24 May 1966; some sub rosa _ political
activity continues
Communists: the banned Socialist Workers and
Farmers Party and the Nigerian Trade Union
Congress have a limited political following, no
influence on government
Member of: AFDB, Commonwealth, ECA,
ECOWAS, FAO, IAEA, IBRD, ICAO, IDA, IFC,
ILO, IMCO, IMF, ITU, Lake Chad Basin
154
Commission, Niger River Commission, OAU, OPEC,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WFTU, WHO, WMO','d77e6df29238de41efc31b1be515a8e6c8efaa9d80d683476cd5ac932b46c524','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19c615893ff9629f79ed4256e7405e44f49ea0618d3d53134d1b675897f60a1d',1976,'NO','Norway','government',388,'Legal name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 19 counties, 404 communes,
47 towns
Legal system: mixture of customary law, civil law
system, and common law traditions; constitution
adopted 1814, modified 1884; Supreme Court renders
advisory opinions to legislature when asked; legal
education at University of Oslo; accepts compulsory
IC] jurisdiction, with reservations
Branches: legislative authority rests jointly with
Crown and parliament (Storting); executive power
vested in Crown but exercised by cabinet responsible
to parliament; Supreme Court, 5 superior courts, 104
lower courts
Government leaders: King Olav V; Prime Minister
Trygve Bratteli
Suffrage: universal, but not compulsory, over age
20
Elections: held every 4 years (next in September
1977)
Political parties and leaders: Anti-Tax Party,
Arve Loennum; Conservative, Kaare Willoch;
Christian People’s, Lars Korvald; Center, Erland
Steenberg, Dagfinn Vaarvik; Liberal, Hans H.
Rossbach, Eva Kolstad; New Liberal People’s, Ole
Myrvoll, Magne Lerheim; Labor, Reiulf Steen;
combined Socialist Left Party, Berit Aas, chairman
Voting strength (1973 election): 5% Anti-tax;
17.5% Conservative; 12.2% Christian Peoples; 11%
Center; 3.5% Liberal; 3.4% New Liberal Peoples;
35.3% Labor; 11.2% Socialist Electoral Alliance
(includes Democratic Socialist, Socialist People’s, and
Communist Party)
Communists: 2,500 est.; a number of sympathizers
as indicated by the 22,500 Communist votes cast in
the 1969 election
Member of: ADB, Council of Europe, DAC, EC
(Free Trade Agreement), EFTA, ESRO (observer),
FAO, GATT, IAEA, IBRD, ICAO, IDA, IEA
(associate member), IFC, THO, ILO, IMCO, IMF,
IPU, ITU, NATO, Nordic Council, OECD, Seabeds
Committee, U.N., UNESCO, UPU, WHO, WMO
Legal name: Sultanate of Oman
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
mien sei
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
OMAN/ PAKISTAN
Type: absolute monarchy; nominally independ-
ent but under strong U.K. influence
Capital: Muscat |
Legal system: based on English common law and
Islamic law; no constitution; ultimate appeal to the
Sultan; has not accepted compulsory IC] jurisdiction
Government leader: Sultan Qabus ibn Sa‘id Al Bu
Sa‘id
Other political or pressure groups: none
Member of: Arab League, FAO, IBRD, ICAO,
IDA, IFC, IMF, Seabeds Committee, ULN.,
UNESCO, UPU, WHO','c56c1aaedccb4d7eb8a4a0fb31b22223e0442b9f0774ada367797d3ac48532df','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ead6e8ce7c4c1345ead6e986784cd038ac55ce20f8f29c322c65480e7e29973',1976,'PK','Pakistan','government',392,'Legal name: Islamic Republic of Pakistan
Type: parliamentary, federal republic; constitution
adopted April 1973, effective August 1973, provides
for bi-cameral legislature, strong prime minister
Capital: Islamabad
Political subdivisions: 4 provinces — Punjab, Sind,
Baluchistan, and Northwest Frontier — with the
capital territory of Islamabad and certain tribal areas
centrally administered; Pakistan claims that Azad
157
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PAKISTAN/PANAMA
Kashmir is independent pending a settlement of the
dispute with India, but it is in fact under Pakistani
contro]
Legal system: based on English common law;
accepts compulsory IC] jurisdiction, with reservations
Government leaders: President Fazal Elahi
Chaudhry; Prime Minister Z. A. Bhutto
Suffrage: universal from age 21
Elections: elections for National Assembly based
on one-man/one-vote formula, and for provincial
assemblies were held in December 1970; under 1973
Constitution, next National Assembly elections must
be held no later than 1977
Political parties and leaders: Pakistan People’s
Party (PPP), Z. A. Bhutto; Pakistan Muslim League
(QML), Abdul Qaiyum Khan; Tehrik-i-Istiqlal,
Asghar Khan; United Muslim League (UML), Pir of
Pigaro; National Awami Party (NAP), Abdul Wali
Khan (party outlawed in February 1975); Jamaat-i-
Islami (JI), Tofail Mohammed; Markazi Jamiat-ul-
Ulema-i-Pakistan (MJUP), Maulana Shah Ahmed
Noorani; Jamiat-ul-Ulema-i-Islam (JUI), Mufti
Mahmud; several of these parties belong to United
Democratic Front (UDF), an opposition coalition
Communists: party membership very small; several
thousand sympathizers
Other political or pressure groups: military
remains potentially strong political force
Member of: ADB, CENTO, Colombo Plan, FAO,
GATT, IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO,
IMCO, IMF, ITU, RCD, Seabeds Committee, U.N.,
UNESCO, UPU, WHO, WMO','118589ef667c8173bc4f6bcd2f892e5db52e185447043a545e93211ba3a7712e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5879eaaa19e7fa5b11f3217f18c480998e2b9bdea1881046fb3dba44e6c521a5',1976,'PA','Panama','government',396,'Legal name: Republic of Panama
Type: republic
Capital: Panama
Political subdivisions: 9 provinces, 1 intendancy
Legal system: based on civil law system;
constitution adopted in 1972; judicial review of
legislative acts in the Supreme Court, legal education
at University of Panama; accepts compulsory IC]
jurisdiction, with reservations
Branches: popularly elected unicameral legislature
which elects the President; presidentially appointed
Supreme Court
Government leaders: Demetrio Lakas is Constitu-
tional President and Chief of State, but subordinate to
Gen. Omar Torrijos, the National Guard Comman-
dant who was given special powers for 6 years by the
Constitutional Assembly in 1972
Suffrage: universal and compulsory over age 21
Elections: elections for assembly of representatives
of the corregimientos August 1972; next election
August 1978
Political parties and leaders: political parties
suspended pending revision of electoral code;
Communist Party illegal but allowed to operate
Voting strength (1968 election): 55% Arnulfo
Arias Madrid (National Union Coalition), 42% David
Samudio (People’s Alliance), 3% Antonio Gonzalez
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Revilla (Christian Democratic Party), no parties were
active in the 1972 elections
Communists: 100 active and several hundred
inactive members People’s Party (PdP); Communist;
1,000 sympathizers; National Liberation Movement
(MLN) and Vanguard of National Action (VAN)
inactive as pro-Castro organizations, 40-60 members
Other political or pressure groups: National
Council of Private Enterprise (CONEP)
Member of; FAO, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMCO, IMF, ITU, OAS,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WFTU, WHO, WMO','0eb77e7f731fd07da6b22bf86cb2b7c161399f1c1e5a36fc165a8e8ae96d5772','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deb58448d96bfe0c8f9a03b9482a40632b41affe854ed29353a7050ba97d758c',1976,'PY','Paraguay','government',401,'Legal name: Republic of Paraguay
Type: republic; under authoritarian tule
Capital: Asuncion
Political subdivisions: 16 departments and the
national capital, 154 municipalities
Legal system: based on Argentine codes, Roman
law, and French codes; constitution promulgated
1967; judicial review of legislative acts in Supreme
Court; legal education at National University of
Asuncion and Catholic University of Our Lady of the
Assumption; does not accept compulsory IC]
jurisdiction
Branches: President heads executive; bicameral
legislature; judiciary headed by Supreme Court
Government leader: President (General) Alfredo
Stroessner
Suffrage: universal; compulsory between ages of
18-60
Elections: President and Congress elected together
every 5 years; last election held in February 1973
Political parties and leaders: Colorado Party, Juan
Ramon Chavez; Liberal Party (Levi-Liberal Party),
Carlos Levi Ruffinelli; Febrerista Party, Roque
Gaona; Radical Liberal Party (regular Liberal Party),
Domingo Laino; Christian Democratic Party {not
officially inscribed), Livis Resck
161
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PARAGUAY/PERU
Voting strength (February 1973 general elec-
tion): 84% Colorado Party, 18% Radical Liberal
Party, 3% Liberal Party, Febrerista Party boycotted
elections
Communists: Oscar Creydt faction and Miguel
Angel Soler faction (both illegal); est. 3,000 to 4,000
party members and sympathizers in Paraguay, very
few are hard core; party in exile is small and deeply
divided
Other political or pressure groups: Popular
Colorado Movement (MoPoCo) led by Epifanio
Mendez Fleitas, in exile
Member of: FAO, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMF, IPU, ITU, LAFTA, OAS,
Seabeds Committee, U.N., UNESCO, UPU, WCL,
WHO, WMO','4e35db2bf87fd2b91f0acdc0946d688ac3eb3df68095d17367e871150e1ecf89','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a1575dfbf691b5aabd4fcc3f56cbb97bdfc6fe9203b4cc1a74ee5986e64616b',1976,'PE','Peru','government',405,'Legal name: Republic of Peru
Type: republic; under military regime since
October 1968
Capital: Lima
Political subdivisions: 23 departments with limited
autonomy plus constitutional Province of Callao
Legal system: based on civil law system; military
government rules by decree; legal education at the
National Universities in Lima, Trujillo, Arequipa, and
Cuzco; has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative, judicial; congress
disbanded after 3 October 1968 ouster of President
Fernando Belaunde Terry
Government leader: President, General Francisco
Morales Bermudez Cerrutti
Suffrage: obligatory for citizens (defined as adult
men and women and married persons over age 18)
until age 60
Elections: none scheduled
Political parties and leaders: Christian Demo-
cratic Party (PDC), Juan Lituma Portocarrero,
President, supports the government; opposition parties
include the Popular Action Party (AP), Fernando
Belaunde Terry (in exile but expected to return to Peru
late in 1975 or in early 1976); American Popular
Revolutionary Alliance (APRA), Victor Raul Haya de
la Torre; and Popular Christian Party (PPC), Luis
Bedoya Reyes
Voting strength (1963 election): 39% AP-PDC,
34% APRA, 25% UNO, 1% Communist, 1% other
Communists: pro-Soviet (PCP/S) 2,000; pro-
Chinese (2 factions) 1,200
Other political or pressure groups: government-
sponsored social mobilization system (SINAMOS)
which is being restructured; a pro-government
political organization is currently in the formative
stage
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMCO, IMF, ITU,
LAFTA and Andean Pact, OAS, Seabeds Committee,
U.N., UNESCO, UPU, WCL, WFTU, WHO, WMO','8958be3540e8945073d15877709ae858337183c47abbc9ded3c32b9fe56c9d1d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ea7769e6fe3dae4bf3152e1a437b3a6824f44d2241b62bf67a2ce613968b542',1976,'PL','Poland','government',409,'Legal name: Polish Peoples Republic (PRL)
Type: Communist state
Capital: Warsaw
Political subdivisions: 49 provinces
Legal system: mixture of Continental (Napoleonic)
civil law and Communist legal theory; constitution
adopted 1952; court system parallels administrative
divisions with Supreme Court, composed of 104
justices, at apex, no judicial review of legislative acts;
legal education at 7 law schools; has not accepted
compulsory ICJ jurisdiction
Branches: legislative, executive, judicial system
dominated by parallel Communist party apparatus
Government leader: Piotr Jaroszewicz, Premier;
Henryk Jablonski, chairman of Council of State
(President)
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government
every 4 years
165
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
POLAND/PORTUGAL
Dominant political party and leader: Polish
United Workers’ Party (PZPR) (Communist), Edward
Gierek, First Secretary
Voting strength (1972 election): 97% voted for
Communist-approved single slate
Communists: 2,320,000 party members (January
1974)
Other political or pressure groups: National Unity
Front (FJN), including United Peasant Party (ZSI,),
Democratic Party (SD), progovernment pseudo-
Catholic Pax Association and Christian Social
Association, Catholic independent Znak group;
powerful Roman Catholic Church, Stefan Cardinal
Wyszynski, Primate
Member of: CEMA, GATT, ICAO, IHO,
Indochina Truce Commission, IPU, Korea Truce
Commission, Seabeds Committee, U.N. and_ all
specialized agencies except IMF and IBRD, Warsaw
Pact, Vietnam ICCS (International Commission for
Control and Supervision), WFTU','ab8ef648c51c8b053a1a0d03fdcc58eb4ae4a792e75b2c54fb448474476b0542','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11f7bc0bc6e93b842ae10d6b95d8fe6a3ddf953d060652316b23a159ed8f1e77',1976,'PT','Portugal','government',413,'Legal name: Republic of Portugal
Type: republic, provisional government formed
May 1974, after military coup by group of young
military officers, known as the Armed Forces
Movement, who overturned the Caetano regime,
major political parties signed document in April 1975
agreeing to continued military rule for the next 3 to 5
years
Capital: Lisbon
Political subdivisions: 18 districts in mainland
Portugal and 4 “autonomous districts’ in Azores and
Madeira Islands; 2 overseas provinces—Portuguese
Timor and Macao
Legal system: civil law system; constitution
adopted 1938, frequently amended since; new
constitution is being written by popularly elected
constituent assembly according to guidelines set by
the Armed Forces Movement; no judicial review of
legislative acts; legal education at Universities of
Lisbon and Coimbra; accepts compulsory IC]
jurisdiction, with reservations
Branches: executive with President and Prime
Minister included in Armed Forces Movement’s 28-
man Revolutionary Council; legislative branch under
new constitution will have civilian assembly and
Armed Forces General Assembly; judicial controlled
by executive branch
Government leaders: President Francisco da Costa
Gomes; Prime Minister Jose Pinheiro de Azevedo
Suffrage: new election law passed in October 1974
enfranchises all citizens over 18, including emigrants
who left Portugal less than 5 years ago; a few
thousand persons have been declared ineligible to vote
because of their activities under the previous regime
Elections: Constituent Assembly election held on
April 25, 1975; new constitution will set date for
election of a civilian legislative assembly, probably in
early 1976
Political parties and leaders: the Portuguese
Socialist Party (PSP), led by Mario Soares, the
Portuguese Communist Party (PCP), under Alvaro
Cunhal, and the Popular Democratic Party (PPD)
headed by Francisco Sa Carneiro are the best
organized; other significant groups include the center-
right Social Democratic Center Party (CDS), led by
Adelino Amaro da Costa, and the Communist-leaning
Portuguese Democratic Movement (MDP), under
Francisco Pereira da Moura
Voting strength: (1975) the Socialists polled 38% of
the vote for a constituent assembly; the PPD received
26%, the Communists 13%, the CDS 8%, and the
MDP 4%
Communists: membership has increased and
cannot be determined since the party became overt in
April 1974
Other political or pressure groups: Association for
the Study of Economic and Social Development
(SEDES) authorized in October 1970 as a discussion
group with political overtones
Member of: EFTA, FAO, GATT, IAEA, IBRD,
ICAO (restricted membership), IFC, IHO, ILO, IMF,
ITU, NATO, OECD, Seabeds Committee, ULN.,
UPU, WHO, WMO
Legal name: Province of Timor
Type: overseas province of Portugal
Capital: Dili
Indonesian troops invaded Portuguese Timor on
December 7. Although Portugal was still the de jure
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PORTUGUESE TIMOR/QATAR
administering power, Lisbon had publicly admitted
that it could no longer control the situation in the
territory and had withdrawn all Portuguese officials
from the capital at Dili. Indonesia is expected to hold
a referendum in Timor, probably under U.N.
auspices, in order to ratify its annexation of East
Timor.
Member of: ITU','eb08d11aa40b7fe472855cd11c1c1b483c96d0b8a9eae81a83f9eb3c0408fd95','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3442176dda2b30da71b68b37c7ec4c6cfdb380c490c23454766aa2ef7289c1b',1976,'QA','Qatar','government',417,'Legal name: State of Qatar
Type: traditional monarchy; independence
declared in 1971
Capital: Ad Dawhah
Legal system: discretionary system of law
controlled by the ruler, although new civil codes are
being implemented; Islamic law is significant in
personal matters; a constitution was promulgated in
1970
Government leader: Amir Khalifa ibn Hamad Al-
Thani
Suffrage: no specific provisions for suffrage laid
down
Elections: constitution calls for elections for part of
State Advisory Council, semi-legislative body, but
none have been held
Political parties and pressure groups: none; a few
small clandestine organizations are active
Branches: Council of Ministers
Member of: Arab League, FAO, GATT (de facto),
IBRD, ICAO, ILO, IMF, OAPEC, OPEC, Seabeds
Committee, U.N., UNESCO, UPU, WHO
169
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
QATAR/REUNION','c9074c9266e4813a69f414f30c53212da369e90b0533d2620052335a3a6a1cba','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef142c2b2e214df7764caeab54d157e6ab8e5049991d0b4ffcc524a30c398ba3',1976,'ZM','Zambia','government',421,'Legal name: Colony of Southern Rhodesia
noun—Rhodesian(s); adjective—
Type: self-proclaimed independent state since 1965
(not recognized by U.S.); provisional settlement with
171
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
RHODESIA/ROMANIA
U.K. in November 1971 cancelled by U.K. in May
1972 in response to Pearce Commission’s conclusion
that its terms were unacceptable to the majority of
black Rhodesians
Capital: Salisbury
Political subdivisions: 11 magisterial districts
Legal system: Smith government implemented a
republican constitution on 2 March 1970 which
institutionalized white rule
Branches: President Dupont is ceremonial head of
state; executive council (cabinet) lead by Prime
Minister Smith; National Assembly gives highly
disproportionate representation to white minority —
50 white constituency seats and 16 black constituency
seats
Government leaders: Prime Minister lan Smith
and President Clifford Dupont
Suffrage: franchise is based on income, property
holdings, and education; there are separate rolls for
Africans and non-Africans
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front,
Prime Minister Smith; Rhodesia Party, Tim Gibbs;
Rhodesia National Party, Leonard Idensohn; African
Progressive Party, Chad Chipunza
Voting strength (1974 elections): Rhodesian Front
won all-50 white constituency seats in Parliament in
July 1974 elections
Communists: negligible
Other pressure groups and leaders: principal
black nationalist group — African National Council,
Abel Muzorewa; since December 1974 ANC has
included membership of three former insurgent groups
— Zimbabwe African National Union (Ndabaningi
Sithole), Zimbabwe African People’s Union (Joshua
Nkomo), Front for the Liberation of Zimbabwe
(James Chikerema); the enlarged ANC split in
September 1975, when Nkomo gained control of the
ANC organization inside Rhodesia, and Muzorewa
aligned with Sithole and other exiled insurgent leaders
Member of: ITU
Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
noun—Zambian(s); adjective—
229
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
january 1976
ZAMBIA/UNITED STATES
Political subdivisions: 8 provinces
Legal system: based on English common law and
customary Jaw; new constitution adopted September
1978; judicial review of legislative acts in an ad hoc
constitutional council; legal education at University
of Zambia in Lusaka; has not accepted compulsory
{CJ jurisdiction
Branches: modified presidential system; unicam-
eral legislature; judiciary
Government leader: President Kenneth Kaunda;
Prime Minister Elijah Mudenda
Suffrage: universal adult
Elections: last general election December 1973
Political parties and leaders: United National
Independence Party (UNIP), Kenneth Kaunda;
former opposition party banned in December 1972
when | party state proclaimed
Voting strength (1973 election): in first
presidential and parliamentary elections under single-
party system, 43% of eligible voters went to polls;
Kaunda was only candidate for President; National
Assembly seats were contested by members of UNIP
Communists; no Communist Party, but sympa-
thizers of socialism in upper levels of government,
UNIP, and labor unions
Member of: AFDB, Commonwealth, FAO, GATT
(de facto), IAEA, IBRD, ICAO, IDA, IDB, IEA, IFC,
11.0, IMF, IPU, ITU, OAU, Seabeds Committee,
ULN., UNESCO, UPU, WHO, WMO','1eeaf9e49f2b84e25ba9f9d4ff37077c153397ff92421ba9798055c481332125','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c43e2b54134816d8498e83d79d873eea8136baf8d9b23cb19a92bceae058405a',1976,'RO','Romania','government',425,'Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 39 counties and 46
municipalities, including Bucharest that has
administrative status equal to a county
Legal system: mixture of civil law system and
Communist legal theory which increasingly reflects
Romanian traditions; constitution adopted 1965;
legal education at University of Bucharest and two
other law schools; has not accepted compulsory ICJ
jurisdiction
Branches: Presidency; Council of Ministers; the
Crand National Assembly, under which is Office of
Prosecutor General and Supreme Court; Council of
State
Government leaders: Manea Manescu, President
of the Council of Ministers, head of government;
Nicolae Ceausescu, President of the Socialist
Republic, head of state
Suffrage: universal over age 18, compulsory
Elections: elections in Romania held every 4 years
for the local people’s councils and every 5 years for
Grand National Assembly deputies
Political parties and leaders: Communist Party of
Romania only functioning party, Nicolae Ceausescu,
General Secretary
Voting strength (1975 election): overall participa-
tion reached 99.96%; of those registered to vote
(14,900,032), 98.8% voted for party candidates
Approved For Release 2005/04/22 :
Communists: 2,480,000 party members (December
1974)
Member of: CEMA, FAO, GATT, IAEA, IBRD,
ICAO, ILO, IMCO, IMF, IPU, ITU, Seabeds
Committee, U.N., UNESCO, UPU, Warsaw Pact,
WETU, WHO, WMO','9406cf6007ca1489d4de561bf03ac81c9c17791cb7f9059d7c51775b5a40b1e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deb5952b56310b29876461b128339ee3670c0eae94ee729ea8db84a726699556',1976,'RW','Rwanda','government',429,'Legal name: Republic of Rwanda
Type: republic, presidential system in which
military leaders hold key offices: 1962 constitution
still in force except for Title V on the National
Assembly
Capital: Kigali
Political subdivisions: 10 prefectures, subdivided
into 142 communes
Catholic, 9% Protestant, 1%
174
Legal system: based on German and Belgian civil
law systems and customary law; constitution adopted
1962; judicial review of legislative acts in the Supreme
Court; has not accepted compulsory IC] jurisdiction
Branches: President, Committee for Peace and
National Unity (composed of high military
command), and 12-member cabinet
Government leader: General Juvenal Hab-
yarimana, Head of State
Suffrage: universal
Elections: last legislative election September 1969;
none allowed by present government: elections of
Communal Counsellors held November 1974
Political parties and leaders: none; all political
activity banned and elections cancelled by military
government after its July 5, 1973 coup
Communists: no Communist party; U.S.S.R. and
People’s Republic of China have diplomatic missions
in Rwanda
Member of: AFDB, EAMA, FAO, GATT, IBRD,
ICAO, IDA, ILO, IMF, IPU, ITU, OAU, OCAM,
U.N., UNESCO, UPU, WCL, WHO, WMO','dc19405e531824395f47a5c4d99a7051ef4d1fe44d87b2715334dd7f75951075','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23c29e5e8c1761d0261c661f28c7e53de6883754773c8c22799f31e69258f278',1976,'AI','Anguilla','government',433,'Legal name: State of St. Christopher-Nevis-
Type: dependent territory with full internal
autonomy as a British “Associated State”; Anguilla
formally seceded in May 1967 but has not been
recognized as an independent state by any
government; in July 1968 a legislative council headed
by Ronald Webster was elected to govern Anguilla; in
March 1969 the U.K. sent troops to Anguilla, placing
the island again under colonial rule; in 1971, Anguilla
reverted to its former colonial relationship with the
U.K. although nominally remaining part of the
Associated state of St. Christopher-Nevis-Anguilla;
Webster became leader of Anguillan Council after
constitutionally held elections (1972)
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law;
constitution of 1960; highest judicial organ is Court of
Appeal of Leeward and Windward Islands
Branches: legislative, 10-member popularly elected
House of Assembly; executive, cabinet headed by
Premier
Government leaders: Premier, Robert L. Brad-
shaw; U.K. Governor, Probyn Inniss
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent 10
May 1971
Political parties and leaders: St. Christopher-
Nevis-Anguilla Labor Party, Robert L. Bradshaw;
People’s Action Movement (PAM), William Herbert;
Nevis Reformation Party (NRP), Ivor Stevens
Voting strength (May 1971 election): St.
Christopher-Nevis-Anguilla Labor Party won 7 seats
in the House of Assembly, PAM won 1, NRP won 1,
and 1 seat remains open for Anguilla which did not
participate in the election
Communists: none known
Member of: CARICOM
Legal name: State of St. Lucia
Type: dependent territory with full internal
autonomy as a British “Associated State”
Capital: Castries
Political subdivisions: 16 parishes
Legal system: based on English common law;
constitution of 1960; highest judicial body is Court of
Appeal of Leeward and Windward Islands
Branches: legislative, 17-member popularly elected
House of Assembly; executive, cabinet headed by
Premier
Government leaders: Premier John Compton;
U.K. Governor Sir Allen Lewis
Suffrage: universal adult suffrage
Elections: every 5 years; most recent May 1974
Political parties and leaders: United Worker''s
Party (UWP), John Compton; St. Lucia Labor Party
(SLP), Allan Louisy
Voting strength (1974 election): UWP (53% ) won
10 of the 17 elected seats in House of Assembly; SLP
(45% ) won 7 seats: independents (2%) no seats
Communists: negligible
Member of: CARICOM
Legal name: State of St. Vincent
Approved For Release 2005/04/22
Type: dependent territory with full internal
autonomy as a British “Associated State”
Capital: Kingstown
Legal system: based on English common law;
constitution of 1960; highest judicial body is Court of
Appeal of Leeward and Windward Islands
Government leader: Premicr R. Milton Cato;
Governor General (U.K.) Sir Rupert G. John
Suffrage: universal adult suffrage (18 years old and
over)
Elections: every 5 years; most recent December 9,
1974
Political parties and leaders: People’s Political
Party (PPP), Ebenezer Joshua; St, Vincent Labor
Party (LP), R. Milton Cato; Democratic Freedom
Movement, Parnell Campbell and Kenneth John
Voting strength (1975 election): LP 10 seats, PPP 2
seats, independent 1 seat in the Legislature
Communists: negligible
Member of: CARICOM','6925cc3771d3ca1d24072cd5e26a8735c7bb7f1d23d762076233b1bae8fb6f86','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cfedb77f8e43191192a81f89723849a71614e6c72f6bf503c6e9ee3d80c7fcb',1976,'SM','San Marino','government',437,'Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in
1862 the Kingdom of Italy concluded a treaty
guarantecing the independence of San Marino;
although legally sovercign, San Marino is vulnerable
to pressure from the Italian Government
Capital: San Marino
Political subdivisions: San Marino is divided into 9
sections: Guaita, Fratta, Serravalle, Domagnano,
Acquaviva, Fiorentino, Montegiardino, Faetano,
Chiesanuova
Sanmurinese (sing. & pl.):
Legal system: based on civil law system with
Italian law influences; electoral law of 1926 serves
some of the functions of a constitution: has not
accepted compulsory ICJ jurisdiction
Branches: the Grand and General Council is the
legislative body elected by popular vote; jts 60
members serve 5-year terms; Council in turn elects
178
two Cuaptains-Regent who exercise executive power for
term of 6 months, the Council of State whose
members head government administrative depart-
ments and the Council. of Twelve, the supreme
judicial body; actual executive power is wielded by
the Secretary of State for Foreign Affairs and the
Secretary of State for Internal Affairs
Government leaders: Secretary of State for Foreign
Affairs Gian Luigi Berti (Christian Democratic party);
Secretary of State for Internal Affairs Giuseppe
Lonferini (Christian Democratic party); Secretary for
finance, budget, and planning Remy Giacomini
(Socialist)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General
Council required at least every 5 years; next elections
1979
Political parties and leaders: Christian Demo-
cratic party (DCS), Gian Luigi Berti: Social
Democratic Party (PSDSM), Alvaro Casali; Socialist
Party (PSS), Remy Giacomini; Communist Party
(PCS), Umberto Barulli; People’s Democratic Party
(PDP), leader unknown; Committee for the Defense
of the Republic (CDR), leader unknown
Voting strength (1974 election): 39.6% DCS,
23.7% PCS, 15.4% PSDIS, 13.9% PSS, 1.9% PDP,
2.9% CDR
Communists: approx. 300 members (number of
sympathizers cannot be determined); PSS, in
government with Christian Democrats since March
1973, formed a government with the PCS from the
end of World War II to 1957
Other political parties or pressure groups:
Political parties influenced by policies of their
counterparts in Italy, the two Socialist parties are not
united
Member of: ICJ, International Institute for
Unification of Private Law, International Relief
Union, IRC, UPU, WFTU','02c42eb00108517653bcf04e3952af0e938191fdfe2d8126d2a14a4410d9968a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a3662a027d0ff7fee0331f079a590f3390c2828002e47de6832c654912d3b6c',1976,'SN','Senegal','government',441,'Legal name: Republic of Senegal
Type: republic
Capital: Dakar
Political subdivisions: 7 regions, cach subdivided
into 18 departments, 90 districts, and 34 communes
Legal system: based on French civil law system,
constitution adopted 1960, revised 1963 and 1970;
judicial review of legislative acts in Supreme Court
(which also audits the government''s accounting
office); legal education at University of Dakar; has
not accepted compulsory ICJ jurisdiction
Branches: Government dominated by President
who is assisted by Prime Minister, appointed by
President and subject to dismissal by President or
censure by National Assembly; 80-member National
Assembly, elected for 5 years (effective 1973);
President elected for 5-year term (effective 1973) by
universal suffrage; judiciary headed by Supreme
Court, with members appointed by President
Government leaders: Leopold Scdar Senghor,
President; Abdou Diouf, Prime Minister
Suffrage: universal adult
Elections: uncontested presidential and legislative
clections held February 1978 for 5-year term
Political parties and leaders: Union Progressiste
Senegalaise (UPS), ruling party led by President
Leopold Senghor; Parti Democratique Senegalaise
181
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SENEGAL/SEYCHELLES
(PDS), legal opposition party founded July 1974,
illegal parties include Communist-backed Parti
(PAI) and Parti
Communiste Senegalais (PCS), a splinter group
Africain de I''Independence
Communists: «a few Communists and sympa-
thizers; PAI is pro-Moscow; PCS in pro-Peking
Other political or pressure groups: labor unions
are controlled by party; students and teachers
occasionally strike
Member of: AFDB, CEAO, EAMA, ECA,
ECOWAS, EIB (associate), FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, 11.0, IMCO, IMF, ITU,
OAU, OCAM, OMVS (Organization for the
Development of the Sencgal River Valley), Seabeds
Committee, U.N., UNESCO, UPU, WCL, WHO,
WMO','d686aa87780642199c09835aca712f18faae47a52dd246f383f01e2da62722f6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41674ea7ad4b92734af7656ed0cf9fed464497d9a122d80199377d76bbced6ef',1976,'SL','Sierra Leone','government',445,'Legal name: Republic of Sierra Leone
Type: republic under presidential regime since
April 1971
Capital: Freetown
Political subdivisions: 3 provinces; divided into 12
districts with 146 chiefdoms, where paramount chief
and council of elders constitute basic unit of govern-
ment; plus western area, which comprises Freetown
and other coastal areas of the former colony
Legal system: based on English law and customary
laws indigenous to local tribes: constitution adopted
April 1971; highest court of appeal is the Sierra Leone
Court of Appeals; has not accepted compulsory IC]
jurisdiction
Branches: executive authority exercised by
President; parliament consists of 100 authorized seats,
85 of which are filled by elected representatives of
constituencies and 12 by Paramount Chiefs elected by
fellow Paramount Chiefs in each district; President
authorized to appoint three members, of which two,
currently, are filled by the heads of the Army and the
Police independent judiciary
Government leader: Siaka Stevens, President,
heads APC government composed of members of his
political party
Suffrage: universal over age 21
Elections: the maximum life of an elected
parliament is 5 years, but it may be dissolved earlier
by the President; parliamentary election held in May
1973; President is elected by parliament for 5 year
term; next presidential election 1976
184
Political parties and leaders: All People''s Congress
(APC), headed by Stevens; Sierra Leone People’s
Party (SLPP) is the opposition party
Communists: no party, although there are a few
Communists and a slightly larger number of
sympathizers
Member of: AFDB, Commonwealth, ECA,
ECOWAS, FAO, GATT, IAEA, IBRD, ICAO, IDA,
IFC, ILO, IMF, IPU, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WCL, WHO,
WMO','c996376588cee3b84a1cec20ca4998dbffa8aacd1d137ddcbac3251627294d60','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5b7664da676699bb157e17205882db42fadfad212d85bd1b784a16b9177dc0f',1976,'SG','Singapore','government',449,'Legal name: Republic of Singapore
Type: republic within Commonwealth since
separation from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law;
constitution based on preindependence State of
Singapore constitution; legal education at University
of Singapore; has not accepted compulsory ICJ
jurisdiction
Branches: ceremonial President; exccutive power
exercised by Prime Minister and cabinet responsible to
unitary legislature
Government leaders: President, Dr. Benjamin
Sheares; Prime Minister, Lee Kuan Yew
Suffrage: universal over age 20; voting compulsory
Elections: normally every 5 years
Political parties and leaders: government —
People’s Action Party (PAP), Lee Kuan Yew,
opposition — Barisan Sosialis Party (BSP), Dr. Lee
Siew Choh; Workers’ Party, J.B. Jeyaretnam,
Communist Party illegal
Voting strength (1972 election): PAP won all 65
seats in parliament and received 70% of vote;
remaining 30% to four opposition parties
Communists: 200-500; Barisan Sosialis Party
infiltrated by Communists
Member of: ADB, ASEAN, Colombo Plan, GATT,
IBRD, ICAO, IFC, IHO, ILO, IMCO, IMF, IPU,
ITU, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO','eeb6aed2727859f8a1564eca83af76af33085ce34ca5c3ab5f9de21dd1040f76','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d777ca5775ce697ee1b4fc19062509b010c333319d5144db1a1c3f3359946aa',1976,'SO','Somalia','government',453,'Legal name: Somali Democratic Republic
Type: republic; under military rule since October
1969
Capital: Mogadiscio
Political subdivisions: 12 regions, 56 districts
Organization: the junta has assumed all authority,
calling itself the Supreme Revolutionary Council,
membership of which consists of 17 army and 3 police
officers; the Council has abrogated the constitution,
dissolved the parliament, and banned political parties
Government leader: President of the Supreme
Revolutionary Council, Gen. Mohamed Siad Barre
Communists: possibly some Communist sympa-
thizers in the government hierarchy
Member of: AFDB, EAMA, FAO, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, OAU, Seabeds
Committee, U.N., UNESCO, UPU, WFTU, WHO,
WMO','360dceda3366f20a5f050bc3f596bfb9e48637da3d985ce6bf64c7f5b4693ae0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a27a7746a942151b1be44c916f29adf0e804e999db0ce3485b7b2da82dc968d5',1976,'ZA','South Africa','government',457,'Legal name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape
Town; judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by
centrally appointed administrator; provincial
councils, elected by white electorate, retain limited
powers
Legal system: based on Roman-Dutch law and
English common law; constitution enacted 1961,
changing the Union of South Africa into a Republic;
possibility of judicial review of Acts of Parliament
concerning dual official languages; accepts compul-
sory ICJ jurisdiction, with reservations
Branches: President as formal chief of state; Prime
Minister as head of government; Cabinet responsible
to bicameral legislature; lower house elected directly
by white electorate; upper house indirectly elected
and appointed; judiciary maintains substantial
independence of government influence
Government leader: Prime Minister Balthazar
Johannes Vorster
Suffrage: general suffrage limited to whites over 18
(17 in Natal Province)
Elections: must be held at least every 5 years; last
elections April 1974
Political parties and leaders: National Party, B. J.
Vorster, P. W. Botha, C. Mulder, M. C. Botha,
187
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SOUTH AFRICA/SOUTH-WEST AFRICA
Jan De Klerk; United Party, Sir De Villiers Graaff;
Progressive-Reform Party, Colin Eglin, Harry
Schwarz, Helen Suzman; Herstigte Nasionale party,
Albert Hertzog; Reform Party (split from United Party
in February 1975), Harry Schwarz
Voting strength (1974 general elections):
parliamentary seats: National Party 122, United Party
41, Progressive Party 6
Communists: small Communist Party illegal since
1950; party in exile maintains headquarters in
London; Dr. Yasuf Dadoo, Moses Kotane, Joe Slovo
Other political groups: (insurgent groups in exile)
African National Congress (ANC), Oliver Tambo;
Pan-Africanist Congress (PAC), leadership in dispute
Member of: GATT, IAEA, IBRD, ICAO, IDA,
IFC, IHO, IMF, ITU, Seabeds Committee, U.N.,
UPU, WFTU, WHO, WMO
Legal name: Territory of South-West Africa
Type: administered as part of Republic of South
Africa, under a League of Nations mandate of 1920;
U.N. formally ended South Africa’s mandate on
October 27, 1966, and status now in dispute
Capital: Windhoek
Political subdivisions: 10 tribal homelands, mostly
in northern sector, and zone open to white settlement
with administrative subdivisions similar to a province
of South Africa
Legal system: based on Roman-Dutch law and
customary law
Branches: administrator, appointee of South
African Government, has jurisdiction over zone of
white settlement with white-elected Legislative
Assembly handling some local matters; white residents
also elect representatives in South African Parliament;
tribal homelands are under South African Department
of Bantu Administration and Development with tribal
chiefs exercising limited autonomy; popularly elected
legislative councils for Ovamboland and Kavango-
land established in August 1973
Government leader: B. J. van der Walt,
Administrator
Suffrage: limited to white adults
Elections; last gencral election, 1974
Political parties and leaders: white parties —
National Party (NP), led in South-West Africa by A.
H. du Plessis; United National South-West Party
(UNSWP), J. P. Nichaus
Voting strength: NP (1974 election) won 5 of 6
seats in Republic legislature
Communists: no Communist Party, but some
influence by South African Communists and other
Communists on South-West African blacks outside
territory
Other political or pressure groups: nonwhite —
South-West Africa People’s Organization (SWAPO),
almost exclusively based on Ovambo tribe led by Sam
Nujoma, in exile; South-West Africa National Union
(SWANU), primarily based on Herero tribe, leaders in
exile; National Unity Democratic Organization
(NUDO), primarily based on Herero tribe led by
Clements Kapuuo; Namibian National Convention,
an alliance of non-white groups that oppose separate
development for tribal homelands :
Legal name: (The) Spanish State
Type: a monarchy facing the problem of how to
liberalize the authoritarian regime of the late
Generalissimo Franco; proclaimed Juan Carlos King,
on November 22, 1975
Capital: Madrid
Political subdivisions: metropolitan Spain,
including the Canaries and Balearics, divided into 50
provinces with governors appointed by the central
government; also 5 places of sovereignty (presidios) in
Africa; Ifni province ceded by Spain to Morocco in
June 1969; 2 former provinces comprising Equatorial
Guinea were granted independence in October 1968;
decolonization of Spanish Sahara began in November
1975
Legal system: civil law system, with regional
applications of customary law; 7 basic laws including
Organic Law of the State of January 1967 serve as a
constitution; legal education at 14 schools of law; does
not accept compulsory [C] jurisdiction
Branches: executive, with King’s acts subject to
counter-signature, Prime Minister likely to dominate
all branches of government through his position as
chief of government; legislative with unicameral
Cortes dominated by executive; judicial, independent
in principle but generally limited to interpretation of
laws
Government leaders: King Juan Carlos I — Chief
of State, Commander in Chief of the armed forces,
and titular head of the National Movement (formerly
called the Falange), Carlos Arias Navarro, Prime
Minister
Suffrage: universal in national referendums, over
age 21
Elections: only two types of direct election other
than referendum provided: representatives to
municipal councils for which only heads of
households vote (latest election November 1973) and,
under new constitutional law of 1967, 104 members of
the Cortes elected by heads of households and married
women for a 4-year term (last election September
1971; September 1975 election postponed until March
1976)
Political parties and leaders: National Movement
only legally recognized party; Prime Minister exercises
leadership assisted by Adolfo Suarez Gonzalez,
headed by Franco, minister-secretary general;
political associations authorized in January 1975;
various semiclandestine opposition groups include —
Christian Democratic factions under Jose Maria Gil
Robles and Joaquin Ruiz Gimenez; the Socialists
include the Spanish Socialist Workers Party (PSOE),
led by “Young Turk’’ Felipe Gonzalez, the Popular
Socialist Party under Enrique Tierno Galvan, and the
0
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','342b340debda112d27f00a4640a0895ac512a8919045945398296937ec9bc861','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4a2d7ef5333571845182bba366ba244a046e9f340e3a81a398118672d7aa606',1976,'ES','Spain','government',459,'small new Spanish Social Democratic Union; the
Anarchists; Republicans; Monarchists; smaller
regional and national splinter groups; the Spanish
Communist Party, whose secretary general, Santiago
Carrillo Solares, is in exile, as well as a small dissident
pro-Soviet faction led by exiled Enrique Lister Forjan;
and some small radical Communist groups which
appear and disappear under varying names, most of
the opposition groups have joined one of two loosely-
knit coalitions — the Communist-dominated
Democratic Junta, formed in the summer of 1974, and
the Socialist-Christian Democratic Platform of
Democratic convergence, established in the summer
of 1975
Voting strength: 561 seats, but somewhat fewer
members as some hold more than one seat — 19%
representing the family elected directly; 45%
representing municipalities, syndicates, and _profes-
sions clected indirectly under close regime control;
and 36% are appointed by regime or are ex officio
Communists: (est.) 5,000 inside Spain, 12,000
outside Spain; sympathizers in Spain, up to 20,000
Other political or pressure groups: on the extreme
left, the illegal Basque Fatherland and Liberty (ETA)
and the Anti-Fascist and Patriotic Revolutionary
Front (FRAP) use terrorism to oppose the government;
on the extreme right, the guerrillas of Christ the King
carry out vigilante attacks on ETA members (on
occasion following them into France), and other
leftists the state-controlled organization of syndicates,
comprising representatives of management and labor,
an illegal labor group called the Workers’
Commissions, the Catholic Church, business and land
owning interests, Opus Dei, Catholic Action,
university students
Member of: ESRO, FAO, GATT, IAEA, IBRD,
ICAO, IDA, IEA, IFC, IHO, ILO, IMCO, IMF, IPU,
ITU, OAS (observer), OECD, Seabeds Committee,
U.N., UNESCO, UPU, WCL, WHO, WMO
Legal name: Province of Sahara
Type: province of Spain
Capital: E! Aaiun
Spain is withdrawing from the territory (decoloniz-
ing) and is expected to complete the process by
192
February 28, 1976. An agreement signed on
November 14, 1975 with Morocco and Mauritania in
Madrid created a provisional administration to govern
the territory until Spain withdraws completely.
As co-administrators, Morocco and Mauritania—
inter alia—are expected to partition the territory
between them. Several Saharan independence groups,
most notably the Algerian-backed POLISARIO Front.
oppose partition and are waging military and
propaganda campaigns in an effort to prevent
annexation.','8d3f9342edb33b2568306e3b782a6c1ea4d62228ee0124b9e90449648592daec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b9b1194816a5a096aa8131ba61f0efedf48491905f82f1078838bf271821204',1976,'LK','Sri Lanka','government',465,'Legal name: Republic of Sri Lanka
Type: independent state since 1948
Capital: Colombo
Political subdivisions: 9 provinces, 22 administra-
tive districts, and four categories of semiautonomous
elected local governments
Legal system: a highly complex mixture of English
common law, Roman-Dutch, Muslim and customary
law; new constitution 22 May 1972; no judicial
review of legislative acts; legal education at Sri Lanka
Law College and University of Sri Lanka, Peradeniya;
has not accepted compulsory ICJ jurisdiction
Hindu, 9%
Branches: unitary parliamentary form of govern-
ment; unicameral legislature and independent
judiciary
Government leader:
Bandaranaike
Suffrage: universal over age 18, but most Indian
Tamils, who comprise 10.6% of population, are not
enfranchised ‘
Elections: national elections, ordinarily held every
6 years; must be held more frequently if government
loses confidence vote; last election held May 1970,
but new constitution postpones deadline for next
election until May 1977
Political parties and leaders: Sri Lanka Freedom
Party, Sirimavo Ratwatte Dias Bandaranaike,
President; Lanka Sama Samaja Party (Trotskyite), N.
M. Perera, President; Tamil United Front, S. J. V.
Chelvanayakam, leader; United National Party, J. R.
Jayewardene; Communist Party/ Moscow, Pieter
Keuneman, General Secretary; Communist Party/
Peking, N. Shanmugathasan, General Sccretary;
Mahajana Eksath Peramuna (People’s United Front),
M. B. Ratnayaka, President
Voting strength (1970 election): 37% Sri Lanka
Freedom Party, 38% United National Party, 9%
Lanka Sama Samaja Party, 3.5% Communist
Party/Moscow, 5% Federal Party, minor parties and
independents accounted for remainder
Communists: approximately 169,000 voted for the
Communist Party in the May 1970 general election;
Communist Party/Moscow approximately 5,000
members (1975), Communist Party/Peking 1,000
members (1970 est.)
Other political or pressure groups: Buddhist
clergy, Sinhalese Buddhist lay groups; far-left violent
revolutionary groups; labor unions
Member of: ADB, Colombo Plan, Commonwealth,
FAO, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO,
IMF, IPU, Seabeds Committee, U.N., UNESCO,
UPU, WCL, WHO, WMO','b920af15b79ce2638951111980f6492c3350e7583fe2730f97d588d2c9c74340','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1be5aaae195bd621002027fed95721c571499d75b2f05b3d814588f76ed818b7',1976,'SD','Sudan','government',469,'Legal: name: Democratic Republic of the Sudan
Type: republic under military control since coup in
May 1969
Capital: Khartoum
Political subdivisions: 15 provinces, provincial and
local administrations controlled by central govern-
ment; limited regional autonomy in 3 southern
provinces
Legal system: based on English common law and
Islamic law; some separate religious courts;
permanent constitution promulgated April 1973;
Revolutionary Command Council established in 1969
dissolved in October 1971 with the installation
stallation of Jafar al-Numayri as president and chief
executive; Numayri has reorganized government
through a series of Republican decrees; legal
education at University of Khartoum and Khartoum
extension of Cairo University at Khartoum; accepts
compulsory IC] jurisdiction, with reservations
Government leader: President and Prime Minister
Ja far al-Numayri
Suffrage: universal adult
94
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
A
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SUDAN/SURINAM
Elections: most recent parliamentary elections held
‘in April 1968; presidential plebiscite held in
September 1971; elections to constituent assembly
held in September-October 1972; elections for
southern regional assembly held in November 1973;
elections for People’s Assembly held May 1974
Political parties and leaders: all parliamentary
political parties outlawed since May 1969; the ban on
the Sudan Communist Party was not enforced until
after abortive coup in July 1971, the government s
mass political organization, the Sudan Socialist
Union, was formed in January 1972
Communists: party decimated following July 1971
coup and counter-coup, several top leaders including
Secretary-General Mahjub executed; actual hard-core
membership down to lowest point in years; party
control over labor unions, professional groups and
university student groups ended; Communists purged
from government, party is being reorganized
underground under leadership of Secretary-General
Muhammad Nujud, 3,500 CP members
Other political or pressure groups: Muslim
Brotherhood, Ansar Muslim sect, at odds with the
military regime since the May coup, defeated in
fighting in spring 1970; Sudan Opposition Front,
composed of former political party elements and other
disgruntled conservative interests, operates in exile
Member of: AFDB, Arab League, FAO, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, OAU,
Seabeds Committee, U.N., UNESCO, UPU, WFTU,
WHO, WMO
Legal name: Surinam
Type: Parliamentary Democracy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by
district commissioner responsible to Minister of
Internal Affairs
Legal system: Dutch civil law system; Constitution
adopted November 1975
Branches: Council of Ministers headed by a
Prime Minister constitutes the Cabinet; 39-member
legislative council (Staten) popularly elected for 4-
year term; court system administered by Attorney-
General under Minister of Justice and Police
Government leader: Prime Minister, Hendrick A.
FE. Arron
adjective—
Suffrage: universal over age 23
Elections: every 4 years or earlier upon request of
Prime Minister; latest held November 1973 won by
National Party Combination (NPK), a creole-based
election coalition in which the National Party of
Surinam (NPS) is the largest party; new elections will
probably be held in 1976
Political parties and leaders: National Party of
Surinam (NPS), Hendrick A. F. Arron; Nationalist
Republic Party (PNR), Edward Bruma (principal
leftist party); United Hindustani Party (VHP), J.
Lachmon; Progressive National Party (PNP), Frank E.
Essed; Surinam Democratic Party (SDP), B. F. J.
Oostburg; United Indonesian People’s Party (SRI), F.
Karsowidijojo; Javanese Farmers’ Party (KTPI), H. I.
Soemita; United People’s Party (VVP), led by
apolitical or Chinese businessmen
196
Approved For Release 2005/04/22
Voting strength (1973): NPK 22 seats, VHP 17; the
NPK had a one vote margin as of early November
1975 following defection from both coastlines
Communists: no overt Communist Party; PNP has
some Communist sympathizers
Member of: EC (associate), UPU, WCL.
Legal name: Kingdom of Swaziland
Type: monarchy, under King Sobhuza HI;
independent member of Commonwealth since
September 1968
Capital: Mbabane (administrative), Lobamba
(royal and legislative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-
Dutch law in statutory courts, Swazi traditional law
and custom in traditional courts; legal education at
University of Botswana, Lesotho, and Swaziland
(located in Lesotho); has not accepted compulsory
IC] jurisdiction
Branches: in April 1973 King abolished the
constitution, dismissed parliament, and assumed
personal rule; he intends ruling under a King-in-
Council arrangement with the cabinet being retained
as an advisory council; former members of parliament
continue to receive their salaries and new constitution
probably will be drawn up later
Government leader: Head of State and govern-
ment King Sobhuza II; Prime Minister Makhosini
Dlamini
Suffrage: universal for adults
Elections: first elections for Legislative Council
held in June 1964; latest for House of Assembly in
May 1972
Political parties and leaders: Imbokodvo, the
traditionalist party, controlled by King Sobhuza II;
the opposition Ngwane National Liberatory Congress
(NNLC), led by Dr. Ambrose Zwane, has been
dissolved
Voting strength: in 1972 elections, Imbokodvo won
21 seats, NNLC won 8 seats in the House of Assembly
Communists: no Communist Party
Member of: AFDB, FAO, GATT (de facto), IBRD,
ICAO, IDA, IFC, IMF, ITU, OAU, Seabeds
Committee, U.N., UPU','4454a4e298de1e2fe856ca4ae95d4a1a6335cbfc521fff522ccf38b331c7fdbe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7257500661c801bb0f0ba28b703655b41fff0dd415cec9f439b6b2072fa7e94f',1976,'SE','Sweden','government',473,'Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces, 624 com-
munes, 224 towns
Legal system: civil law system influenced by
customary law; Acts of 1809, 1810, 1866, and 1949
serve as constitution; legal education at Universities of
Lund, Stockholm, and Uppsala; accepts compulsory
ICJ jurisdiction, with reservations
Branches: legislative authority rests with parlia-
ment (Riksdag); executive power vested in cabinet,
responsible to parliament; Supreme Court, 6 superior
courts, 108 lower courts
Government leaders: King Carl XVI Gustaf; Prime
Minister Olof Palme
Suffrage: universal, but not compulsory, over age
20
Elections: every 3 years (next in September 1976)
Political parties and leaders: Moderate Coalition
(conservative), Gosta Bohman; Center, Thorbjorn
Falldin; Liberal, Gunnar Helen; Social Democratic,
Olof Palme; Communist, Carl-Henrik Hermansson;
Communist League of Marxists-Leninists (KFML.),
Gunnar Bylin
Voting strength (1973 election): 13.9% Moderate
Coalition, 25.1% Center, 9.4% Liberal, 43.6% Social
Democratic, 5.3% Communist, 2.7% other
Communists: 17,000; a number of sympathizers as
indicated by the 274,929 Communist votes cast in
1973 elections; an additional 8,014 votes cast for
Maoist KFML
Member of: ADB, Council of Europe, DAC, EC
(Free Trade Agreement), EFTA, ESRO, FAO, GATT,
IAFA, IBRD, ICAO, IDA, IEA, IFC, IHO, ILO,
IMCO, IMF, IPU, ITU, Nordic Council, OECD,
Seabeds Committee, U.N., UNESCO, UPU, WHO,
WMO','fe8e1e29655608f9545d89332f89c62037f042619ef5688d44a692f2b37f4d9f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db6ddfd799427b8f03160351cd0de21fbaa40c20ec95fe7b7330a1373ac4a94c',1976,'CH','Switzerland','government',476,'Legal name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 29 cantons (3 divided into
half cantons): a local referendum held in Bern Canton
in 1975 indicated that three districts wished to form a
separate canton for a portion of the French-speaking
Jura region
Legal system: civil law system influenced by
customary law; constitution adopted 1874, amended
Since; judicial review of legislative acts, except with
respect to Federal decrees of 8eneral obligatory
character; legal education at Universities of Bern,
Geneva and Lausanne, and four other univer
schools of law: accepts compulsory IC] jurisdict
with reservations
Branches: bicameral parliament has legislative
authority; federal council (Bundesrat)
authority; justice left chiefly to cantons
Government leader: Pierre Graber (1-year term as
President began on January 1975), President
Suffrage: universal over age 20
Josef Kurmann, president; Farmer, Artisan, and
Burghers Party (BGB), Hans Conzett,
Communist Party (PdA), Jean Vincent, leading
Secretariat member; National Action Party
James Schwarzenbach
Voting strength (1975. election): 22.2%
20.6% CVP, 25.4% SPS, 10.2% BGB, 2.2%
N.A., 3.0% Rep, 6.2% LdU, 2.3% Lidus, 2.0% EvpP,
1.3% POSH, 2.9% other
Communists: less than two million votes in 1975
election
Other parties: Landesring (LdU); Republican
Movement (Rep); Liberal Democratic Uni
Evangelical Party (EvP): Maoist Party (P
200
Te
January 1976
Member of: ADB, Council of Europe, DAC,
EFTA, ELDO (observer), ESRO, FAO, GATT, IAEA,
ICAO, IEA, ILO, IMCO, IPU, ITU, OECD, Seabeds
Committee, U.N, (permanent observer), UNESCO,
UPU, WCL, WHO, WMO
Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime
since March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of
Damascus administered as separate unit
Legal system: based on Islamic law and civil law
system; special religious courts; constitution
promulgated in 1973; legal education at Damascus
University and University of Aleppo; has not accepted
compulsory ICJ jurisdiction
Branches: executive powers vested in President and
Council of Ministers; legislative power rests in the
People’s Assembly (election pending); seat of power is
the Ba’th Party Regional (Syrian) Command
Government leaders: President Hafiz Al-Asad
Suffrage: universal at age 18
Elections: no electoral laws being drafted; last
elections in December 1961; presidential referendum
in 1971; local councils elected in March 1972,
assembly elections pending
Political parties and leaders: ruling party is the
Arab Socialist Resurrectionist (Ba''th) party; a
“national front’? cabinet formed in March 1972,
dominated by Ba’thists, includes independents and
members of the Syrian Arab Socialist Party (ASP),
Arab Socialist Union (ASU), and Syrian Communist
Party (SCP)
Communists: mostly sympathizers, numbering
10,000 to 13,000
Other political or pressure groups: non-Ba’th
parties have little effective political influence;
Communist Party ineffective; greatest threat to
Ba''thist regime lies in factionalism in Ba’th Party
itself; conservative religious leaders
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
OAPEC, Seabeds Committee, U.N., UNESCO, UPU,
WFTU, WHO, WMO
Legal name: United Republic of Tanzania
Type: republic; single parties dominate both on the
mainland and on Zanzibar
Capital: Dar es Salaam
Political subdivisions: 25 regions—20 on main-
land, 5 on Zanzibar islands
Legal system: based on English common law,
Islamic law, customary law, and German civil law
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
eine A a NTT TT
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TANZANIA
system; interim constitution adopted 1965; judicial
review of legislative acts limited to matters of
interpretation; legal education at University of Dar es
Salaam; has not accepted compulsory IC] jurisdiction
Branches: President Julius Nyerere has full
executive authority on the mainland; National
Assembly dominated by Nyerere and the Tanganyika
African National Union (TANU); newly restructured
National Assembly consists of 218 members, including
57 appointed from Zanzibar, 65 appointed from the
mainland, plus 96 directly elected from the mainland;
First Vice President Aboud Jumbe and the
Revolutionary Council still run Zanzibar despite the
efforts of Nyerere to integrate the islands into the
political system of the mainland
Government leader: President Julius Nyerere
Suffrage: universal adult
Political party and leaders: Tanganyika African
National Union (TANU), only mainland political
party, dominated by Nyerere with Prime Minister and
Second Vice President Rashidi Kawawa as his top
lieutenant; Afro-Shirazi Party, the only party in
Zanzibar
Voting strength (October 1975 national elec-
tions): over 5 million registered voters; Nyerere
received 95% of about 4 million votes cast; general
parliamentary elections scheduled for Fall of 1980
Communists: a few Communist sympathizers,
especially on Zanzibar
Member of: AFDB, Commonwealth, EAC, FAO,
GATT, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU,
OAU, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO','3261e61349f887745d9dfed862c3548efb5d8af336e3e0c1ab4d79db4e5c1178','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d8555a0a100d21ec8b1cd703c173f3902a0fe890550e6cee67f4224b6170162',1976,'TH','Thailand','government',480,'Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions:
provinces
Legal system: based on civil law system, with
influences of common law; new constitution
promulgated 7 October 1974; legal education at
Thammasat University; has not accepted compulsory
ICJ jurisdiction
Branches: King is head of state with nominal
powers; Prime Minister heads a 3l-man cabinet;
National Assembly bicameral, senate appointed,
Buddhist, 4% Muslim, 0.5%
71 centrally controlled
204
Approved For Release 2005/04/22
house elected; judiciary relatively independent except
in important political subversive cases
Government leaders: King Phumiphon Adundet:
Khukrit Pramot, Prime Minister; Praman Adireksan,
Deputy Prime Minister
Suffrage: universal
Elections: 26 January 1975
Political parties and leaders: 22 political parties
won seats in 269-seat National Assembly; key parties
include Social Action, Democrat, Thai Nation, Social
Justice, Social Agrarian, Social Nationalist, Socialist
Party of Thailand, and New Force
Communists: strength of illegal Communist Party
is about 1,000; Thai Communist insurgents
throughout Thailand total about 8,000
Other political or Pressure groups: National
Student Center of Thailand (NSCT): labor
associations, People for Democracy, Federation of
Independent Students
Member of: ADB, ASEAN, ASPAC, Colombo
Plan, ESCAP, FAO, IAEA, IBRD, ICAO, IDA, IFC,
THO, ILO, IMF, IPU, ITU, Seabeds Committee,
SEAMES, U.N., UNESCO, UPU, WCL, WHO,
WMO
With the end of the war, South Vietnam in effect
has become reunified with the North. For the
foreseeable future, however, a separate, ostensibly
independent administration will be maintained in
the South. Policy decisions however are made in
Hanoi by the Vietnam Workers Party—the
Communist Party—and transmitted to its southern
branch—the People’s Revolutionary Party. Quasi-
military /political people’s revolutionary commit-
tees are overseeing basic administrative tasks in the
countryside while the Provisional Revolutionary
229
Approved For Release 2005/04/22
Government represents southern interests abroad
and apparently will be the entity to which foreign
governments are accredited. When Hanoi becomes
satisfied that the southern administration has
satisfactorily adjusted economically and politically
to a more rigid socialist society, formal reunifica-
tion probably will occur, Currently, there is no way
to estimate the duration of this periods.','c5a189b8e9f6496cdf7e2e93c5466643b9824cc410c7116954a00351c90777aa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c69fd8db9dc027e5350460149a801650f54f6f7c6489b699b5a8fe6d0c274440',1976,'TG','Togo','government',484,'Legal name: Togolese Republic
Type: republic; under military rule since January
1967
Capital: Lome
Political subdivisions: 21 circumscriptions
Legal system: based on French civil law and
customary practice; no constitution; has not accepted
compulsory IC] jurisdiction
Branches: military government, with civilian-
dominated cabinet, took over on 14 April 1967,
replacing provisional government created after
January coup; no legislature; separate judiciary
including State Security Court established 1970
Government leader: Maj. General Gnassingbe
Eyadema, President
Suffrage: universal adult
Elections: presidential referendum of January 1972
elected Gen. Eyadema for indefinite period
Political parties: single party formed by President
Eyadema in September 1969, Rassemblement du
Peuple Togolais, structure and staffing of party closely
controlled by government
Communists: no Communist Party; possibly some
sympathizers
Member of: AFDB, CEAO (observer), EAMA,
ECA, ECOWAS, ENTENTE, FAO, GATT, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, OAU, OCAM,
Seabeds Committec, U.N., UNESCO, uPU, WCL,
WHO, WMO','e86fc7dfdab02012e5d2fd771f14e9f334132cf2ebba1f0798691d7540b565dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62c1ab7f3b09ba8c897b3e043cc66c11d57320dd9b084ebbc75c02b6d854d0aa',1976,'TO','Tonga','government',488,'Legal name; Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa
Political subdivisions: 3 main island groups
(Tongatapu, Haapi, Vavau)
Legal system: based on English law
Branches: Executive (King and Privy Council);
Legislative (Legislative Assembly composed of 7
nobles elected by their peers, 7 elected representatives
of the people, 7 Ministers of the Crown; the King
appoints one of the 7 nobles to be the speaker);
Judiciary (Supreme Court, magistrate courts, Land
Court)
Government leaders: King Taufa’ahau Tupou IV;
Premier, Prince Tu ''ipelehake (younger brother of the
King)
Suffrage: granted to all literate adults over 21 years
of age who pav taxes
Elections; held perennially
Communists: none known
Member of: ADB, Commonwealth
800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000
I
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TONGA/TRINIDAD AND TOBAGO','b342ffa40c0012fecba64c35b4a181c4be6b1f5f2ec75c8be938f05f6c0aecc3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11f8be74720e2b1a938b5bb1541a67a860ffe07bf786ad809f14505fdbe67acc',1976,'TT','Trinidad and Tobago','government',492,'Legal name: Trinidad and Tobago
Type: independent state since August 1962;
recognizes Elizabeth II as chief of state
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards,
Tobago is 80th)
Legal system: based on English common law;
constitution came into effect 1962; judicial review of
legislative acts in the Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: legislative branch consists of 86-member
elected House of Representatives and 24-member
Senate (13 nominated by Prime Minister, 4 by
opposition leader, 7 at discretion of Governor
General); executive is cabinet led by the Prime
Minister; judiciary is headed by the Chief Justice and
includes a Court of Appeal, High Court, and lower
courts; criminal cases may be appealed to the Queen’s
Privy Council in London as a court of last resort
Government leader: Prime Minister, Dr. Eric
Williams
Suffrage: universal over age 21
Elections: last election 24 May 1971, PNM won all
seats
Political parties and leaders: People’s National
Movement (PNM), Dr. Eric Williams, Democratic
Labor Party (DLP), Vernon Jamadar; United
Democratic Labor Party (UDLP), Alloy Lequay;
United National Independence Party, (UNIP) James
Millette; Democratic Action Congress (DAC), Arthur
Napoleon Raymond Robinson; West Indian National
Party (WINP), Ashford Sinanani; Tapia House
Group, Lloyd Best
207
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TRINIDAD AND TOBAGO/TUNISIA
Voting strength (1971 election): 32.9% of
registered voters cast ballots, 83.7% PNM, 16.3%
other
Communists: not significant
Other political pressure groups: National Youth
Congress (NYC); Oilfield Workers Trade Union
(OWTU); National Joint Action Committee (NJAC),
antigovernment, ex-tremist organization; United
Revolutionary Organization (URO), Marxist-led
amalgam; United Labour Front (ULF), loose
coalition of oilfield and sugar workers
Member of: CARICOM, Commonwealth, FAO,
GATT, IADB, IBRD, ICAO, IDA, IDB, IFC, ILO,
IMCO, IMF, International Coffee Agreement, ITU,
OAS, Seabeds Committee, U.N., UNESCO, UPU,
WHO, WMO','93d9640029a8af9add55eaeebfef292d521f1e403f3788ae376f3dfcf75f0f84','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0372b1456cbffbf49a94f7a32027fa858c7d246cc9e50feb8ea633afb50a788f',1976,'TN','Tunisia','government',496,'Legal name: Republic of Tunisia
Type: republic
Capital; Tunis
Political subdivisions: 17 governorates (provinces)
Legal system: based on French civil law system
and Islamic law; constitution patterned on Turkish
and U.S. constitutions adopted 1959; some judicial
review of legislative acts in the Supreme Court in joint
session; legal education at Institute of Higher Studies
and Ecole Superieure de Droit of the University of
Tunis; has not accepted compulsory ICJ jurisdiction
Branches: executive dominant; unicameral
legislative largely advisory; judicial, patterned on
French system and Koranic law
Government leader: President Habib Bourguiba;
Prime Minister Hedi Nouira
Suffrage: universal over age 21
Flections: national elections held every 5 years; last
elections 2 November 1974
Political party and leader: Destourian Socialist
Party, Habib Bourguiba
Voting strength (1974 election): 100% Destourian
Socialist Party
Communists: 100 est.; a few sympathizers;
Tunisian Communist Party proscribed in 1962
Member of: AFDB, Arab League, EC (association
until 1974), FAO, IAEA, IBRD, ICAO, IDA, IFC,
ILO, IMCO, IMF, ITU, OAU, Seabeds Committee,
U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental
legal systems, with remnants of Islamic law:
constitution adopted 1961; judicial review of
legislative acts by Constitutional Court; legal
education at Universities of Ankara and Istanbul,
accepts compulsory IC] jurisdiction, with reservations
Branches: President elected by parliament; Prime
Minister appointed by President from members of
parliament; Prime Minister is effective executive;
cabinet, selected by Prime Minister and approved by
President, must command majority support in lower
house; parliament bicameral under constitution
promulgated in 1961; National Assembly has 450
members serving 4 years; Senate has 150 elected
members, one-third elected every 2 years, 15
appointed by the President to 6-year terms (one-third
appointed every 2 years), and 18 life members: highest
court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal,
commercial, basic, and peace courts
Government leaders: President Fahri Koruturk;
Prime Minister Suleyman Demirel heads four-party
coalition government
Suffrage: universal over age 21
210
Elections: National Assembly and Senate (1/3 of
seats), Republican People’s Party won a plurality
October 1973; Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People’s Party (RPP),
Bulent Ecevit; Democrat Party (DP), Ferruh Bozbeyli;
Republican Reliance Party (RRP). Turhan Feyzioglu;
National Action Party (NAP), Alpaslan Turkes:
Nation Party (NP); Unity Party (UP), Mustafa Timisi;
Communist Party illegal; National Salvation Party
(NSP), Necmettin Erbakan
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government in March 197]
and remains an influential force in government
Member of: CENTO, Council of Europe, EC
(associate member), ECOSOC, FAO, GATT, IAEA,
IBRD, ICAO, IDA, IEA, IFC, IHO, ILO, IMCO,
IMF, IPU, ITU, NATO, OECD, Regional Coopera-
tion for Development, Seabeds Committee, U.N..
UNESCO, UPU, WHO, WMO','225d02ba2a5985a4a5ecb6df32f80f7ae026bfc47ad8f6902b48f2cb8c15927a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b82e99dabb01f3e829162387e9bd4f8fdce39d71e01994f6c8b7be07fea563fd',1976,'UG','Uganda','government',500,'Legal name: Republic of Uganda
Type: republic independent since October 1962
Capital: Kampala
Political subdivisions: 10 provinces and 34 districts
Legal system: based on English common law and
customary law; constitution adopted 1967; present
government rules despotically, has intimidated
judicial officials and has made constitution of no
consequence; legal education at Makerere University,
Kampala; accepts compulsory IC] jurisdiction, with
reservations
Branches: Field Marshall Amin rules by decree;
assisted by Council of Ministers and Defense Council,
a group of military officers
Government leader: Field Marshall Idi Amin,
President
Suffrage: universal adult
Elections: none scheduled by military government
Political parties: none
Communists: possibly a few sympathizers
Member of: AFDB, Commonwealth, EAC, FAO,
GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF,
ITU, OAU, Seabeds Committee, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, 20
autonomous republics, 6 krays, 120 oblasts, and 8
autonomous oblasts
Legal system: civil law system as modified by
Communist legal theory; constitution adopted 1936;
no judicial review of legislative acts; legal education
at 18 universities and 4 law institutes; has not
accepted compulsory ICJ jurisdiction
Branches: Council of Ministers (executive),
Supreme Soviet (legislative), Supreme Court of
U.S.S.R. (judicial)
Government leaders: Leonid I. Brezhnev, General
Secretary of the Central Committee of the Communist
Party; Aleksey N. Kosygin, Chairman of the Council
of Ministers; Nikolay V. Podgornyy, Chairman of the
Presidium of the U.S.S.R. Supreme Soviet
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every 4 years; 1,517
deputies elected in 1974, 72.2% party members
Political parties and leaders: Communist Party of
the Soviet Union (CPSU) only party permitted
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
ST
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
U.S.S.R./UNITED ARAB EMIRATES
Voting strength (1970 election): 153,237,112
persons over 18; claimed 99.96% voted
Communists: 15,000,000 party members
Other political or pressure groups: Komsomol,
trade unions, and other organizations which facilitate
Communist control
Member of: CEMA, Geneva Disarmament
Conference, IAEA, ICAO, ILO, IMCO, IPU, ITU,
Seabeds Committee, U.N., UNESCO, UPU, Warsaw
Pact, WFETU, WHO, WMO, Universal Copyright
Convention','9d08796888cd7e40fda702ee468f7a727eebc764970b0fd5fa9ba24f7f22632c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b92827593d159017fe4c82cc0ea865c3035dd43f0c75d150a5b072611676e38',1976,'AE','United Arab Emirates','government',503,'Legal name: United Arab Emirates (composed of
former Trucial States)
213
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
UNITED ARAB EMIRA TES/UNITED KINGDOM
Member states: Abu Dhabi; Ajman; Dubai:
Fujairah; Ras al Khaimah; Sharjah; Umm al Qaiwain
Type: federation; constitution signed December
1971, which delegated specified powers to the United
Arab Emirates central government and reserved other
powers to member sheikhdoms
Capital: Abu Dhabi
Legal system: secular codes are being introduced
by the U.A.E. government and in several member
sheikhdoms; Islamic law remains very influential
Branches: Supreme Council of Rulers (7 members),
from which a President and Vice President are elected;
Prime Minister and Council of Ministers; National
Consultative Council; federal Supreme Court
Government leaders: Sheikh Zayid of Abu Dhabi,
President; Sheikh Rashid of Dubai, Vice President;
Sheikh Maktum of Dubai, Prime Minister
Suffrage: nonc
Elections: none
Political or pressure groups: none; a few small
clandestine groups are active
Member of: Arab League, IBRD, ICAO, ILO,
IMF, OAPEC, OPEC, Seabeds Committee, U.N.,
UNESCO, UPU, WHO','ff988082d1a2da630eeabcc058534c9f08d150d532df9169f851ea30798da390','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54d526a00a1532208a508d5bd933010be32829ef0127a3eba85de4c5d60070c1',1976,'GB','United Kingdom','government',507,'Legal name: United Kingdom of Great Britain and
Northern Ireland
Type: constitutional monarchy
Capital: London
Political subdivisions: 635 parliamentary constitu-
encies
Legal system: common Jaw tradition with early
Roman and modern continental influen
judicial review of Acts of Parliament; accepts
compulsory 1CJ jurisdiction, with reservations
des in Parlia-
h collectively
Branches: legislative authority resi
ment; executive authority lies wit
responsible cabinet led by Prime Minister;
Lords is supreme judicial authority and highest court
of appeal
Government leader: Prime Minister Harold
Wilson
Suffrage: universal over age 18
Elections: at discretion of Prime Minister, but must
be held before expiration of a 5-yea
mandate; last election 10 October 1974
Political parties and leaders:
Margaret Thatcher, Labor, Harold Wilso
Jeremy Thorpe; Communist, Gordan McLennan
Voting strength (1974 election): Conservative 277
seats (35.7%); Labor 319 seats (39.3%),
seats (18.3%), 26 seats (6.7% ) other
Communists: 29,000; sympathizers 175,000
Other political or pressure groups: Trades Union
Congress, Confederation of British Industry, National
Farmers Union
Member of: ADB, CENTO, Colombo Plan,
Council of Europe, DAC, EC, EEC, ELDO, ESRO,
EURATOM, FAO, GATT, IAEA, IB
IDA, IFA, IFC, tHO, ILO, IMCO, IMF, IPU,
ITU, NATO, OECD, Seabeds Committce,
UNESCO, UPU, WEU, WHO, WMO
Legal name: Republic of Upper Volta
Type: republic; military regime in power since
January 1966
Capital: Ouagadougou
Political subdivisions: 10 departments, composed
of 44 cercles, headed by military prefects
Legal system: based on French civil law system
and customary law; constitution adopted 1970,
suspended February 1974; judicial review of
legislative acts in Supreme Court: has not accepted
compulsory IC] jurisdiction
Branches; President is an army officer; 57-man
National Assembly was elected in December 1970,
suspended February 1974
Government leader: Gen, Sangoule Lamizana,
president and Prime Minister
Suffrage: universal] for adults
Elections: al] political activity has been banned
Political parties and leaders: political parties
banned February 1974
Communists: no Communist party; some sympa-
thizers
Other political Or pressure groups: labor
Organizations are badly splintered, students and
teachers occasionally strike
Member of: AFDB, CEAO, EAMA, ECA, EIB
(associate), Entente, FAO, IBRD, ICAO, IDA, ILO,
IMF, IPu, ITU, Niger River Commission, OAU,
OCAM, UN., UNESCO, UPU, WCL, WHO, WMO','58e3fd5166c14981d43a779ac3decf2f0021c3b38714d5cabe3dd7ae3d020c91','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9981ee92f3375fffcf9e8148e87dabade78f234a9dc8d2985574114ebb3ac29',1976,'UY','Uruguay','government',511,'Legal name: Oriental Republic of Uruguay
Type: republic, government under strong military
influence
Capital: Montevideo
Political subdivisions: 19 departments with limited
autonomy
Legal system: based on Spanish civil law system;
new constitution implemented 1967; judicial review
of legislative acts in Supreme Court, legal education
at University of the Republic at Montevideo; accepts
compulsory ICJ jurisdiction
Branches: exccutive, headed by President; since
1973 the military has had considerable influence
in policymaking; bicameral legislature (closed
indefinitely by presidential decree in June 1973),
Council of State set up to act as legislature; national
judiciary headed by Supreme Court
Government leader: President Juan Maria
Bordaberry
Suffrage: universal over age 18
Elections: every 5 years
Political parties and leaders: political activities are
proscribed
Voting strength (1971 elections): 40.8% Colorado,
40.1% Blanco, 18.6% Frente Amplio, 0.5% Radical
Christian Union
Communists: 35,000-40,000 including Communist
youth group and sympathizers
Other political or pressure groups: Communist
Party (PCU), Rodney Arismendi (in exile in the
U.S.S.R.); Christian Democratic Party (PDC);
217
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
URUGUAY/VATICAN CITY
Socialist Party of Uruguay (PSU); Revolutionary
Movement-of Uruguay (MRO) pro-Cuban Commun-
ist Party; National Liberation Movement (MLN-
‘Tupamaros) Marxist revolutionary terrorist group
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDB, IFC, ILO, IMCO, IMF, ITU, LAFTA,
OAS, Seabeds Committee, U.N., UNESCO, UPU,
WCL, WFTU, WHO, WMO
Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
VATICAN CITY/VENEZUELA
Capital: Vatican City
Political subdivisions: Vatican City includes St.
Peter''s, the Vatican Palace and Museum and
neighboring buildings covering more than 18 acres; 13
buildings in Rome, although outside the boundaries,
enjoy extraterritorial rights
Legal system: Canon law; constitutional laws of
1929 serve some of the functions of a constitution
Branches: the Pope possesses full executive,
legislative, and judicial powers; he delegates these
powers to the governor of Vatican City, who is subject
to pontifical appointment and recall; high Vatican
offices include the Secretariat of State, the College of
Cardinals (chief papal advisers), the Roman Curia
(which carries on the central administration of the
Roman Catholic Church) the Presidence of the
Prefecture for the Economy, and the synod of bishops
(created in 1965)
Government leader: Supreme Pontiff, Paul VI,
(Giovanni Battista Montini, born 26 September 1897,
elected Pope 21 June 1963)
Suffrage: limited to cardinals less than 80 in age
Elections: Supreme Pontiff elected for life by
College of Cardinals
Communists: none known
Other political or pressure groups: none (exclusive
of influence exercised by other church officers in
universal Roman Catholic Church)
Member: IAEA, Seabeds Committee
Legal name: Republic of Venezucla
Type: republic
Capital: Caracas
219
-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001
January 1976
VENEZUELA/VIE TNAM, NORTH
Political subdivisions: 20 states, 1 federal district, 2
federal territories
Legal system: based on Spanish civil law system
with influence of U.S. law; constitution promulgated
1961; judicial review of legislative acts in Cassation
Court only; dual court system, state and federal; legal
education at Central University of Venezuela; has not
accepted compulsory IC] jurisdiction
Branches: executive (President), bicameral
legislature, judiciary
Government leader: President Carlos Andres Perez
Suffrage: universal and compulsory over age 18
Elections: every 5 years; last held 9 December 1973
Political parties and leaders: Accion Democratica
(AD), Carlos Andres Perez, and Gonzalo Barrios;
Social Christian Party (COPEI), Rafael Caldera;
People’s Electoral Movement (MEP), Jesus Angel Paz
Galarraga; Union Republicana Democratica (URD),
Jovito Villalba: Partido Comunista de Venezuela
(PCV), Secretary-General Jesus Faria; Movement to
Socialism (MAS), Teodoro Petkoff, and Pompey
Marquez
Voting strength (1973 election): 49% AD, 37%
COPEI, 5% New Force (MEP & PCV), 4% MAS, 3%
URD, 2% others
Communists: 6,000 members (est. )
Other political or Pressure groups; APEL (a
conservative business group); PRO VENEZUELA
(leftist, nationalist economic group); DESARROL-
LISTAS (group of wealthy, independent businessmen
led by former finance minister Pedro Tinoco and
historian Guillermo Moron)
Member of: Andean Pact, FAO, IADB, IAEA,
IBRD, ICAO, IDB, IFC, THO, ILO, IMF, IPU, ITU,
LAFTA, OAS, OPEC, Seabeds Committee, ULN.,
UNESCO, UPU, WCL, WFTU, WHO, WMO
Legal name: Democratic Republic of Viet-Nam
Type: Communist state
Capital: Hanoi
Political subdivisions: 2 autonomous regions (of 3
and 5 provinces, respectively), 17 other provinces, 2
centrally governed municipalities, 1 special zone
Legal system: based on Communist legal theory
and French civil law system, constitution enacted
1960
Branches: constitution provides for a National
Assembly and highly centralized executive nominally
subordinate to it
Party and government leaders: Ton Duc Thang,
President of DRV; Le Duan, First Secretary; Truong
Chinh, Chairman, Standing Committee of National
Assembly; Pham Van Dong, Premier; Vo Nguyen
Giap, Minister of National Defense
Suffrage: over age 18
Elections: pro forma elections held for national and
local assemblies
Approved For Release 2005/04/22
Political parties: ruled by Lao Dong Party
(Communist) with membership of approximately
900,000; minor subordinate parties
Member of: no international bodies','528f1a0d374f43bb55a0e0418f77aa49dd0fb724ba1626fba36104dde584ebdf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e53486ac0fe395efdaa1ed2960a47acaced385078328ffb1f6276f697240c649',1976,'WF','Wallis and Futuna','government',515,'Legal name: Territory of the Wallis and Futuna
Islands
Type: overseas territory of France
Capital: Matu Utu
Political subdivisions: 3 districts
Branches: territorial assembly of 20 members;
popular election of one deputy to National Assembly
in Paris, and one Senator
Government leader: Superior Administrator
Jacques de Agostini
Suffrage: universal adult
Elections: every 5 years
Legal name: The Independent State of Western','854a450207dbf562c1f2bdac8140ba75ed3ba30bba97c36b7dc36f1aa531b584','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('585e70fcb576165c4bbab64d978f41baa4d14c3541bcd9732d8252edf849a2f5',1976,'WS','Samoa','government',517,'Type: constitutional monarchy under native chief:
special treaty relationship with New Zealand
Capital: Apia
Legal system: based on English common law and
local customs; constitution came into effect upon
independence in 1962; judicial review of legislative
acts with respect to fundamental rights of the citizen;
has not accepted compulsory IC] jurisdiction
Branches: Head of State and Executive Council;
Legislative Assembly; Supreme Court, Court of
Appeal, Land and Titles Court, village courts
Government leaders: Head of State, Malietoa
Tanumafili II, Prime Minister, Tamesese Lealofi
Suffrage: 45 Samoan members of Legislative
Assembly are elected by holders of matai (heads of
family) titles (about 5,000); 2 European members are
elected by universal adult suffrage
Elections: held triennially, last in February 1973
Political parties and leaders: no clearly defined
political party structure
Communists: unknown
Member of: ADB, Commonwealth, ESCAP, IBRD,
{[FC, IMF, Scabeds Committee, WHO
Legal name: Peoples Democratic Republic of','f545ae41ce88daac2ade05db0ebd47502c591226977b5699b5fee523601cf47b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3c099af3c3fb8b6940eb3087b3274217493c1ec22487c5c6fcbfb12246679da',1976,'YE','Yemen','government',521,'Type: republic; power centered in ruling National
Front Party
Capital: Aden; Madinat ash Sha’b, administrative
capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal
matters) and English common law (for commercial
matters); highest judicial organ, Federal High Court,
interprets constitution and determines disputes
between states
Branches: Presidential Council; cabinet; Supreme
People’s Council
Government leaders: Chairman of Presidential
Council, Salim Rubayyi Ali; Prime Minister Ali Nasir
Muhammed al-Hasani; NF Secretary General Abd
Al-Fattah Ismail
Suffrage: granted by constitution to all citizens 18
and over
Elections: elections for legislative body, Supreme
People’s Council, called for in constitution; none have
been held
Political parties and leaders: National Front
(NF), only legal party
Communists: few known
Member of: FAO, CATT (de facto), IBRD, ICAO,
IDA, ILO, IMF, ITU, Seabeds Committee, U.N.,
UNESCO, UPU, WFTU, WHO, WMO
Legal name: Yemen Arab Republic
Type: republic; military regime assumed power in
June 1974
Capital: Sana
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law,
and local customary law; first constitution
promulgated December 1970. suspended June 1974:
has not accepted compulsory ICJ jurisdiction
Branches; Military Command Council, Prime
Minister, cabinet, 117-member Consultative As-
sembly
Government leaders: Head of Military Command
Council, Col. Ibrahim Hamdi; Prime Minister
Abd al-Ghani
Communists: few known
Political parties or pressure groups: Yemeni
Union, a small inactive government party formed in
Vebruary 1973: some pro-Traqi Baathists, other small
clandestine groups supported by Yemen (Aden)
Member of; Arab League, FAO, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, Seabeds Committee,
U.N., UNESCO, UPU, WFTU, WHO, WMO
Legal name: Socialist Federal Republic of
Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Political subdivisions: 6 republics with 2
autonomous provinces (within the Republic of Serbia)
Legal system: mixture of civil law system and
Communist legal theory; constitution adopted 1974;
legal education at several law schools; has not
accepted compulsory ICJ jurisdiction
Branches: parliament (Federal Assembly) constitu-
tionally supreme; executive includes cabinet (Federal
Executive Council) and the federal administration;
independent judiciary; the State Presidency is a
collective policymaking body composed of a
representative from each republic and province, Tito
presides as President of the Republic
Government leader: Josip Broz Tito, President of
Republic and President of League of Communists of
Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years
by a complicated, indirect system of voting
Political parties and leaders: League of
Communists of Yugoslavia (LCY) only; leaders are
President Tito and influential presidium members
Edvard Kardelj, Vladimir Bakaric, and Stane Dolanc
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Voting strength: Voter participation in national
elections has declined, as follows — 1963, 95.5%;
1965, 93.6%; 1967, 89%; 1969, 88%; 1974, no data
available
Communists: 1,076,000 party members (May
1974)
Other political or pressure groups: Socialist
Alliance of Working People of Yugoslavia (SAWPY),
the major mass front organization for the LCY;
Confederation of Trade Unions of Yugoslavia
(CTUY), Union of Youth of Yugoslavia (UYY),
Federation of Yugoslav War Veterans (SUBNOR)
Member of: CEMA (observer but participates in
certain commissions), EC (5-year non-preferentia]
trade agreement signed in May 1973), FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFC, [HO, ILO, IMCO,
IMF, IPU, ITU, OECD (participant in some
activities), Seabeds Committee, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of Zaire (until October 1971
known as Democratic Republic of the Congo)
Type: republic; constitution establishes strong
presidential system
Capital: Kinshasa
Political subdivisions: 8 regions and federal district
of Kinshasa
Legal system: based on Belgian civil law system
and tribal law; new constitution promulgated 1967,
revised 1974; legal education at National University
of Zaire; has not accepted compulsory IC]J jurisdiction
Branches: president elected 1970 for seven-year
term limited to two five-year terms, thereafter;
National Legislative Council of 210 members elected
for five-year term; the official party is the supreme
political institution
Government leaders: Lt. Gen. Mobutu Sese Seko,
President
Suffrage: universal and compulsory over age 18
Elections: presidential and legislative elections in
October and November 1970
Political parties and leaders: Mouvement
Populaire de Ja Revolution (MPR), only legal party,
organized from above with actual grassroots
popularity not clearly definable
Voting strength: MPR slate polled 96.3% of vote in
1970 elections
Communists: no Communist Party; U.S.S.R. and
People’s Republic of China have diplomatic
missions in Zaire
Member of: AFDB, EAMA, EIB (associate), FAO,
GATT, IAEA, IBRD, ICAO, IDA, IFC, THO, ILO,
228
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ZAIRE/ZAMBIA -
IMF, IPU, ITU, OAU, OCAM, Seabeds Committee,
UDEAC, U.N., UNESCO, UPU, WFTU, WHO,
WMO','b98966dd8db68969dcae260f3fa56d2222b00118e4ebb2419c23bead18eb5e21','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

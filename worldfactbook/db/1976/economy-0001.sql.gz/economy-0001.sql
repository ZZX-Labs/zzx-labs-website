SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db4f592cad59f51139a62718b2b9808bf03026674300e2d1e7e6a53a6b6e01ba',1976,'AF','Afghanistan','economy',6,'GNP: $1.2 billion (FY74, at current prices), well
below $100 per capita; real growth rate about 3.7%
(1967-73)
Agriculture: agriculture and animal husbandry
account for over 50% of GNP and occupy nearly 80%
of the labor force; main crops — wheat and other
grains, cotton, fruits, nuts; largely self-sufficient; food
shortages — wheat, sugar, tea
Major industries: cottage industries, food
processing, textiles, cement, coal mining
Electric power: 298,000 kw. capacity (1974); 520
million kw.-hr. produced (1974), 27 kw.-hr. per capita
Exports: 160 million (£.o.b., FY74); fresh and dried
fruits, hides and skins, natural gas, cotton, carpets and
rugs, wool
Imports: $123 million (c.i.F., FY74); transportation
equipment, non-metallic minerals, tea, sugar,
petroleum
Major trade partners: exports — U.S.S.R., India,
U.K., West Germany, Pakistan; imports — Japan,
U.S.S.R., India, West Germany, U.K., U.S.
Aid: economic — U.S.S.R. (1954-74) $837 million
extended, $620 million drawn; Eastern Europe (1954-
74) $39 million extended, $11 million drawn; China
(1965-74) $74 million extended, $27 million drawn;
U.S. (FY49-73) $484 million committed; international
organizations (1946-73) $99 million; military —
U.S.S.R. (1956-74) $492 million extended, $430
million drawn; Eastern Europe (1955-74) $22 million
extended, $20 million drawn; U.S. (FY53-73) $5
million committed
Budget: current expenditures $162 million, capital
expenditures $110 million for FY75
Monetary conversion rate: 45 Afghanis - US$]
(official); 58 Afghanis = US$1 (December 1974)
Fiscal year: 21 March - 20 March','f45e89a9844883a0a78d9616ac1c6df104c56936140994ca253709ac5e09c63d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94f79fc81f3d8d0e51625f3e20046cb17233ab0379aaa2457a00df14a6014066',1976,'AL','Albania','economy',10,'CNP: $1.2 billion in 1972 (at 1972 prices), $520 per
capita
Agriculture: food deficit area: main crops — corn,
wheat, tobacco, sugar beets, cotton: food shortages —
wheat; caloric intake, 2.100 calories per day per capita
(1961/62)
Major industries: agricultural processing, textiles
and clothing, lumber, and extractive industries
Shortages: spare parts, machinery and equipment,
wheat
Electric power: 500.000 kw. capacity (1974); 1.6
billion kw.-hr. produced (1974), 660 kw.-hr. per
capita
Exports: $91 million (1970 est.); 1964 trade — 55%
minerals, metals, fuels; 17% agricultural materials
(except foods); 23% foodstuffs (including cigarettes);
5% consumer goods
Imports: $159 million (1970 est.); 1964 trade
50% machinery, equipment, and spare parts; 16%
minerals, metals, fuels construction materials; 7%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ALBANIA/ ALGERIA
fertilizers, other chemicals, rubber; 4% agricultural
materials (except foodstuffs), 16% foodstuffs; 7%
consumer goods
Monetary conversion rate: 5 leks = US$1 (commer-
cial); 12.5 leks = US$1 (noncommercial)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake,
which is reported for consumption year 1 July - 30
June','ef534b6e128f27083c92649d1da2c6743827a342b3d2819b1880dd8cd7cf5bfc','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('445ebcca0a36f4b575ee4409850f63223fd06fab30a8c35665e9a2684c517ea5',1976,'DZ','Algeria','economy',12,'CNP: $12.1 billion (1974 provisional), $719 per
capita, average annual increase since 1971 (current
prices), 2696
Agriculture: main crops — wheat, barley, grapes,
citrus fruits
Major industries: petroleum, light industries,
natural gas, mining, petrochemical, electrical, and
automotive plants under construction
Electric power: 1,770,000 kw. capacity (1974): 2.8
billion kw.-hr. produced (1974), 169 kw.-hr. per
capita
Exports: $4,600 million (f£.0.b., 1974); crude
petroleum 87%, other items—natural gas, wine, citrus
fruit, iron ore, vegetables, to France 24%, West
Germany 24%, Benelux 9%, Italy 8%, U.S.S.R. 7%
(1973)
Imports: $4,039 million (cif, 1974), major
items—capital goods 3596, semi-finished goods 28%,
foodstuffs 23%; from France 38%, West Germany 9%,
Italy 9%, U.S. 8% (1973)
Monetary conversion rate: 4.18 dinars = US$1
Fiscal year: calendar year','0f3b257da64b116edf7fec23849a7bd84d376aa6e28ac9e68b71a691cb8d1e85','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f278b3ce2379cf51458f21321b81da00f449de3d2c5e157ebce1ec8759c0e5a',1976,'AD','Andorra','economy',16,'Agriculture: sheep raising; small quantities of
tobacco, ryc, wheat, barley, oats, and some vegetables
(only 25% of land can be used for agriculture)
Major industries: tourism ($1 million annually),
one cigarette factory (annual output $1 million),
handicrafts, smuggling (tobacco to France; manufac-
tured items, including automobiles and cameras, to
Spain)
Shortages: food
Electric power: 25,000 kw. capacity (1974); 100
million kw.-hr. produced (1974), 380 kw.-hr. per
capita; power is mainly exported to Spain and France
Major trade partners: Spain, France','eb5442311d03294c7d574b6684d31df048ff324a126860cc0b1d37d5a2b64342','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1c67510aa51edc817d85a5afdad0aad724c4614203099dfe195970d25ea4a36',1976,'AO','Angola','economy',20,'GDP: $3.0 billion (1974 est.), $500 per capita, 6.196
real growth (1970-72)
Agriculture: cash crops — coffee, sisal, corn,
cotton, sugar, manioc, and tobacco; food crops —
cassava, corn, vegetables, plantains, bananas, and
other local foodstuffs; largely self-sufficient in food
Fishing: catch 599,000 metric tons, $18.3 million
(1972); exports $18.7 million; imports $5.5 million
(1971)
Major industries: mining (oil, iron, diamonds), fish
processing, brewing, tobacco, sugar processing,
cement, food processing plants, building construction
Electric power: 465,000 kw. capacity (1974); 984
million kw.-hr. produced (1974), 163 kw.-hr. per
capita
Exports: $1.8 billion (est. f.0.b., 1974); oil, coffee,
diamonds, sisal, fish and fish products, iron ore,
timber, and corn
Imports: $600 million (est. c.i.f., 1974); capital
equipment (machinery and electrical equipment),
wines, bulk iron and ironwork, steel and metals,
vehicles and spare parts, textiles and clothing,
medicines
Major trade partners: main partner Portugal,
followed by West Germany, U.S., U.K., Japan
Aid: Portugal only donor
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
january 1976
ANGOLA/ ANTIGUA
Budget: (1975) balanced at about $740 million,
prelim. est.
Monetary conversion rate: 26.68 escndos= US$ as
of August 1975 (floating since February 1973)
Fiscal year: calendar year','bb077eac32cac57bcbcec051736afa7cb9c16a1ce763d575e0468d4c411820da','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('256d7bb73bf892c4284f7e0d7802429ad8d577bc3878c097277fe9ab387dc676',1976,'PR','Puerto Rico','economy',24,'GDP: $30 million (1973 est.) $395 per capita
Agriculture: main crop. cotton
Major industries: oil refining, tourism
Shortages: clectric power
Electric power: 23,000 kw. capacity (1974); 46
million. kw.-hr. produced (1974), 540 kw.-hr. per
capita
Exports: $29 million (£o.b.. 1973); petroleum
products, cotton
Imports: $47 million (c.i.f., 1973); crude oil, food,
clothing
Major trade partners: U.K. 30%. U.S. 25%
Commonwealth Caribbean countries 18%
Aid: economic — U.S. (FY46-71), $1.5 million in
loans
Monetary conversion rate: 2.07 East Caribbean
dollars = US$1 (May 1975), now floating with pound
sterling
CIA-RDP79-01051A000800010001-8
E M :
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ANTIGUA/ ARGENTINA','665c2cd00270794c6d7d3f9a4decbfb301851d8953803f2e83d41a4b033b1532','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b25020c81672f711e00563cc9ec3239c41dcba174446218f5d4c5d55124feadc',1976,'AR','Argentina','economy',28,'GDP: $38.9 billion (at average theoretical parity
exchange rate, 1974) $1,580 Der capita; 77%
consumption, 20% investment (1974); real growth
rate 1974, 7.2%
Agriculture: main products — cereals, oilseeds,
livestock products; Argentina is a major world
exporter of temperate zone foodstuffs
Fishing: catch 238,000 metric tons (1972), $44.6
million (1972). exports $25 million (1973), imports
$3.6 million (1970)
Major industries: food processing (especially
meatpacking), motor vehicles. consumer durables,
textiles, chemicals, printing, and metallurgy
Crude steel: 2.4 million metric tons produced
(1974), 90 kilograms per capita
Electric power: 8,349,000 kw. capacity (1974);
27.9 billion kw.-hr. produced (1974 ), 1,090 kw.-hr. per
capita
Exports: $4.01 billion (Lo.b.. 1974) —meat, corn,
wheat, wool, hides, oilseeds
Imports: $3.57 billion (cif, 1974)— machinery,
fuel and lubricating oils, iron and steel, intermediate
industrial products
Major trade partners (1973): exports—EC 40%.
LAFTA 24%, US. 8%, Japan 4%. imports—EC 30%.
LAFTA 19%, U.S, 21%, Japan 11%
Aid: economic — extensions from U.S. (FY46-73),
$879 million in loans, $17.8 million in grants: from
international organizations (FY46-73), $1.3 billion:
from other Western countries (1960-66), $315.5
million; from Communist countries (1954-74) 8490
million ($40.0 million drawn); military — assistance
from U.S, (FY46-73), $174 million
Monetary conversion rate: commercial 37.7
pesos = US$1; financial—4g 3 pesos = US$1, parallel
market 115 pesos =US81 (October 1975)
Fiscal year: calendar year','47d7fa11eafef63af8b6b37220f0305ea8f8ccdf0130333380edba68894fd6cb','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94ba12e644053d6af0679501501cd1153b714bc910f64ff425f020920158a3fb',1976,'AU','Australia','economy',32,'GNP: $78.9 billion (1974), $5,900 per capita; 60%
private consumption, 13% government current
expenditure, 25% investment (FY75); real average
annual growth (1969-74), 4%
Agriculture: large areas devoted to livestock
grazing; 60% of arca used for crops is planted in
wheat; major products — wool, livestock, wheat,
fruits, sugarcane self-sufficient in food; caloric intake,
3,300 calories per day per capita
Appro
pproved For Release 2005/04/22 : CIA-RDP79-01051A00080001000
1-8
Fishing: catch 118,000 metric tons, $102 million
(1972); exports $102.5 million (FY74), imports $109.9
million (FY74)
Major industries: mining, bauxite, industrial and
transportation equipment, food processing, chemicals
Crude steel: 8.1 million metric tons produced
(FY75), 590 kilograms per capita
Electric power: 19,830,000 kw. capacity (1974);
12.8 billion kw.-hr. produced (1974), 5,430 kw.-hr. per
capita
Exports: $11.1 billion (f.0.b., 1974) principal
products (FY75)—agricultural products 34%,
metalliferous ores 14%, wool 8%, coal 8%
Imports: $12.4 billion (cif, 1974)
Major trade partners: (FY75) exports— 2856 Japan,
109; U.S., 696 New Zealand, 5% U.K; imports—21%
US, 15% U.K., 17% Japan
Aid: economic — Australian aid abroad $1.9 billion
(FY65-74); $371 million (FY74). 68% for Papua New
CNP: $1.3 billion (1973 est.); real average annual
growth rate (1960-69) 7.5%
Agriculture: main crops — coconuts, coffee, cocoa,
tea
Major industries: sawmilling and timber process-
ing, copper mining (Bougainville)
Electric power: 223,000 kw. capacity (1974); 560
million kw.-hr. produced (1974), 203 kw.-hr. per
capita
Exports: $721 million (£o.b., FY74); principal
products — copper, coconut products, coffee beans,
timber
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PAPUA NEW GUINEA/PARAGUAY
Imports: $365 million (f.o.b., FY74)
Major trade partners: Australia, U.K., Japan
Aid: economic — Australia — $254 million
extended 1973; World Bank group (1968-September
1969) — $7.5 million committed; U.S. (FY70-
74) $32.5 million extended
Budget: (75-76) receipts 400 Australian dollars,
expenditures 408 Australian dollars
Monetary conversion rate: Kina $1 2 A81
Fiscal year: 1 July - 30 June
Aid: $82 million in aid during 1974-76 from U.K.;
US (FY53-73) $0.5 million
Budget: FY73 — revenucs $9 million, expenditures
$10 million (approx. )
Monetary conversion rate: 5.4 Seychelles
rupees = US$1
Fiscal year: calendar year','27299331e6c2b2eab329fd7b068e79eed467922f54bd192bc09b4fbd34a56f78','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96da940d2d686008cc2fc994e2f0a1f4657fd65648fbd13a01deabd1c0b9e16c',1976,'GN','Guinea','economy',33,'Budget: expenditures, A$17.6 billion; receipts
A$15.4 billion (FY75)
Monetary conversion rate: 0.80 Australian
dollar =US$1 (A81 = US$1.25), October 1975
Fiscal year: 1 July - 30 June
GDP: about $398 million (1973), $90 per capita
Agriculture: cash crops — coffee, bananas, palm
products, peanuts, and pineapples; staple food crops
— cassava, rice, millet, corn, sweet potatoes; livestock
raised in some areas
Major industries: alumina, light manufacturing
and processing industries, bauxite mining
Electric power: 99,700 kw. capacity (1974); 500
milion kw.-hr. produced (1974), 115 kw.-hr. per
capita
Exports: export receipts, $49 million (1973);
alumina, bauxite, coffee, pineapples, bananas, palm
kernels
Imports: $146 million (1973); petroleum products,
metals, machinery and transport equipment,
foodstuffs, textiles
Major trade partners: Communist countries,
Western Europe (including France), U.S.
Budget: FY72 ordinary budget (est.)—$113 million
Monetary conversion rate: 22.7 syli- US$1
(October 1972)
Fiscal year: 1 October - 30 September
GDP: $930 million (1973 est.); $230 per capita; real
growth rate probably zero or negative since 1972
(1966-71)
Agriculture: main crops — peanuts, millet,
sorghum, manioc, rice; peanuts primary cash crop:
production of food crops increasing but still
insufficient for domestic requirements
Fishing: catch 249,000 metric tons, $55.2 million,
(1972); exports $12 million (1971), imports (not
uvailable)
Major industries: fishing, agricultural processing
plants, light manufacturing, mining
Electric power: 107,800 kw. capacity (1974); 425
million kw.-hr. produced (1974), 106 kw.-hr. per
capita
Exports: $427 million (£o.b,, 1974); approx. 35%
peanuts and peanut products; phosphate rock;
canned fish
Imports: $543 million (c.i.f., 1974); food, consumer
goods, machinery, transport equipment
Major trade partners: France, EC (other than
France), and franc zone
Aid: economic — France (1966-70) $115 million;
China (1973) $49.1 million; U.S. (FY1961-73) $44
million; U.S.S.R. 87.1 million; EC (1961-73) $154
million; military — U.S. (FY61-73) $2.8 million
Budget: 1976—balanced at $535.5 million
Monetary conversion rate: francs; about 219.98
Communaute Financiere Africaine francs = US$] as of
August 1975 (floating since February 1973)
Fiscal year: 1 July - 30 June','3d73355f7e6699d5af2565d242da4b1a087cba9d93f53dbc9819d9573a3613ef','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8de9e1ce949fc85ee816bdf07047e52a582fc279c4cec68171106a8e2f9a282d',1976,'AT','Austria','economy',37,'GNP: $30.5 billion (1974), $4,070 per capita;
55.1% consumption, 31.4% 14.4%
government, —() 49; net foreign balance, —0.5% net
errors and omissions (1972). 1974 growth rate
435% constant prices
investment,
Agriculture: livestock, cereals, potatoes, sugar
beets: 84% self-sufficient: caloric intake 3.230 calories
per day per capita (1969-70)
Major industries: foods, iron and steel, machinery,
textiles. chemicals, electrical, paper and pulp
800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000
EE
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
AUSTRIA/THE BAHAMAS
Crude steel: 4.7 million metric tons produced
(1974), 630 kilograms per capita (1974)
Electric power: 9,239,000 kw. capacity (1974);
33.9 billion kw.-hr. produced (1974), 4,530 kw.-hr. per
capita
Exports: $7.1 billion (£o.b., 1974); iron and steel
products, machinery and equipment, lumber, textiles
and clothing, paper products, chemicals
Imports: $9.0 billion (c.i.f., 1974); machinery and
equipment, chemicals, textiles, coal, petroleum,
foodstuffs
Major trade partners: (1974) West Germany 31%,
Italy 8.2% Switzerland 10%, U.K. 5.2%, U.S. 3.1%
EC 54%; EFTA 14%; Communist countries 13%
Aid: economic — authorized — U.S. $1,218 million
through FY73; IBRD $105 million through FY73,
none since FY62; military — U.S., $116 million
(FY52-73); net official economic aid delivered to less
developed areas and multilateral agencies — $205
million (FY62-72), $17 million in FY72
Budget: expenditures, $8,880 million; receipts,
$8,332 million; deficit, $548 million (1974)
Monetary conversion rate: 18.69 shillings = US$1,
average 1974 (floating rate)
Fiscal year: calendar year
GNP: $496 million (at market prices, 1973), $2,490
per capita
Agriculture: muin crops — fruits, vegetables
Major industries: tourism. cement, oil refining,
lumber, salt production
Electric power: 230,000 kw. capacity (1974); 650
million kw.-hr. produced (1974), 3,200 kw.-hr. per
capita
Exports: $1.4 billion (f.o.b., 1974); fuel oil,
pharmaceuticals, cement, rum
Imports: $1.9 billion (cif, 1974); crude oil,
foodstuffs, manufactured goods
Major trade partners: exports — U.S. 86%. U.K.
2%, Canada 2%; imports —U. S, 2496, Libya 20%,
Nigeria 16% (1973)
Aid: economic — authorizations from U.S. (FY56-
73) — $24.8 million in loans, $0.3 million in grants
Monetary conversion rate: 1 Bahamian dollar
(B$1)=US$1
Fiscal year: calendar year','4372f30f44967c690a22454642faffde7dd2d11d7c06347aba53aa1748ceeb70','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b219db9a0e9a684cbe831bae7b0c21a892bed58d02b02b7519f4901452e0379c',1976,'BH','Bahrain','economy',42,'GNP: $390 million (1973), $1,650 per capita,
dominated by oil industry; crude oil production in
1974 estimated at the rate of approx. 70,000 bbls. per
day; refinery produced about 90 million bbls. in 1974;
government oil revenues for 1974 are estimated at
$165 million including refinery income and Saudi
Arabia’s payment for the Abu Saf''an field production
Agriculture: produces dates, alfalfa, vegetables;
dairy and poultry farming; fishing; not self-sufficient
in food
Major industries: petroleum refining, boatbuild-
ing, shrimp fishing, and sailmaking on a small scale;
major development projects include aluminum
smelter, flourmill, and ISA town; OAPEC dry dock to
be built by 1977
Electric power: 108,000 kw. capacity (1974); 270
million kw.-hr. produced (1974), 1,139 kw.-hr. per
capita
Exports: non-oil exports $80 million (1973)
Imports: non-oil, $317 million (1978)
Major trade partners: U.K., Japan, U.S., EC
Aid: received $110 million in bilateral commit-
ments and committed itself $8.5 million to
multilateral agencies in CY74
Budget: (1974 revised) $227 million, 85% of
revenues from oil
Monetary conversion rate: 1 Bahrain dinar-
US$2.52 (since January 1973)
Fiscal year: calendar year','9dcf6cbb72652b8dbb068e1b1a0a9aded9badb843bd9e590f8cbfed98f29ddb5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcd6c3992afe9741c0b0587c476020f89d28b77789ab6b72bf9868593153106b',1976,'BD','Bangladesh','economy',47,'GNP: $6.4 billion FY74 est. (EY70 prices), less than
$100 per capita: real annual per capita growth
(74/70) —0.5%
Agriculture: large subsistence farming, heavily
dependent on monsoon rainfall: main crops are jute
and rice; shortages — rice, cotton, and oilseeds
Fishing: catch 818,000 metric tons (1973)
Major industries: jute manufactures, food
processing and cotton textiles
Electric power: 762,000 kw. capacity (1974): 1.2
billion kw.-hr. produced (1974), 15 kw.-hr. per capita
Exports: $371.8 million (FY74); raw and
manufactured jute, leather, tea
Imports: $917.6 million (FY74); foodgrains, fuels,
raw cotton, yarn, manufactured products
Major trade partners: West Pakistan (until
December 1971), U.S., U.K., U.S.S.R., India
Aid: Bangladesh received roughly one-third of the
estimated $8 billion in total economic aid received by
Pakistan between 1950 and 1971: since independence
(December 1971-30 June 1974) commitments $2.15
billion, disbursements $1.25 billion: for FY75,
la
commitments $1.1 billion of which U.S. $316 million,
Bank Group $150 million, U.S.S.R. $77 million
Budget: (FY76) revenue expenditures, $413
million; capital expenditures, $655 million
Monetary conversion rate: 14.5 taka=US$1
(October 1975)
Fiscal year: 1 july - 30 June','f72cffb4d5a3dd26ecc95686592fa786c56caf2c547883bb257ec3e4902e6470','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('679ba2507770240db02befd90ab379c413b8672e9fd57cb242a3fe4ee6d53a8a',1976,'BB','Barbados','economy',51,'GDP: $264 million (1974), $1,100 per capita; real
growth rate 1974, — 11%
Agriculture: main products — sugar, subsistence
foods
Major industries: tourism, sugar milling, manufac-
turing
Electric power: 66,860 kw. capacity (1974); 200
millon kw.-hr. produced (1974), 600 kw.-hr. per
capita
Exports: $86 million (£o.b., 1974); sugar and
sugarcane by-products, clothing
Imports: $209 million (cif, 1974); foodstuffs,
machinery, manufactured goods :
Major trade partners: exports — U.K. 28%, U.S.
14%, CARIFTA 28%, other 30%; imports — U.K.
25%, U.S. 21%, Canada 11%, CARIFTA 18%, other
30% (1973)
Aid: economic — U.S. (FY67-73), $1.4 million,
from international organizations (FY63-73), $4.9
million
Monetary conversion rate: 2 Barbados dol-
lars=US$1 (September 1975), now floating with
pound sterling
Fiscal year: 1 April - 31 March','f519961f6c055c2388f6e3a123f96752b885bbf63e29c94e062351c52f36d606','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84b956c7c2f0aa139fa31e8678d7bc5e468e86b477cf8e0d6cb87cf2c0754c2a',1976,'BE','Belgium','economy',55,'CNP: $47.8 billion (1974, in 1978 prices), $4,890
per capita (1973); 1973 — 60% consumption, 22%
investment, 15% government, 3% net foreign balance;
1974 real GNP growth rate 4.1%
Agriculture: livestock. production predominates;
main crops — grains, beets, potatoes; 80% self-
sufficient in food; caloric intake, 3,230 calories per
day per capita (1969-70)
Fishing: catch 42,200 metric tons, $30.4 million
(1973); exports $28.0 million (1973), imports $74.0
million (1973)
Major industries: engineering and metal products,
processed food and beverages, chemicals, basic
metals, textiles, and petroleum
Shortages: iron ore, nonferrous minerals, petroleum
Crude steel: capacity 14.8 million metric tons:
16.227 million metric tons produced: 1,660 kg. per
capita (1974 est.)
Electric power: 9,397,000 capacity (1974); 42.7
billion kw.-hr. produced (1974), 3,700 kw.-hr. per
capita
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
sol A UÓÓÁMÀ—
January 1976
Approved
p For Release 2005/04/22 : CIA-RDP79-01051A00080001
0001-8
BELGIUM/ BELIZE
Exports: $28.2 billion (£.o.b., 1974), ferrous metals,
finished or semifinished precious stones, textile
produets
Imports: $29.7 billion (ci. E, 1974), nonelectrical
machinery, motor vehicles, textiles, chemicals
Major trade partners: (Belgium-Luxembourg
Economic Union, 1973) EC-nine 72% (West Germany
24%, France 20%, Netherlands 17%, U.K. 6%, Italy
4%); U.S. 696; Communist countries 2%
Aid: economic — received, U.S., $783.8 million
authorized (¥ Y46-19), $2.5 million in FY73; IBRD,
$200.8 million (1949-73); military — received,
$1,260.8 million authorized (FY46-73); net official
economic aid to less developed areas and multilateral
agencies, $1,092 million (FY60-10), $235.6 million in
1973
Ordinary budget, 1975 (projected): revenue
$16.19 billion, projected expenditures $19 billion (!
franc = US$0.0257 floating)
Monetary conversion rate 1974 average: l
franc=US$0.0257 floating
Fiscal year: calendar yeur','221ba0c5034bf70cf26d9d70ace52c656dc91333c11edf68ac7d4ab4e90d9d4f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0383d86ae014022348488810808e47747b0215b86075cd08fd7546c8a9e3420',1976,'BZ','Belize','economy',60,'GDP; $75.0 million (1973 est.), $570 per capita;
78% private consumption, 17% public consumption,
36% domestic investment, —31% net foreign balance
(1968); real growth rate 197] 3.5%
Agriculture; main produets — Sugar, citrus fruits,
Corn, rice, beans, bananas, livestock Products; net
importer of food: caloric intake, 2,500 calories per day
per capita
Major industries: timber and forest products, food
Processing, furniture, rum, soap
Electric power; 7,000 kw. Capacity (1974); 28
million kw.-hr. produced (1974), 210 kw.-hr. per
Capita
Exports: 831.7 million (Lo.b., 1973 est.); sugar,
lumber, citrus fruits, fish
Imports: $49.9 million (cif, 1973); vehicles,
petroleum, food, textiles, machinery
Major trade Partners: exports — U.S. 30%, U.K.
24%, Mexico 22%, Canada 13%; imports — U.S.
34%, U.K. 25%, Jamaica 7% (1970)
Aid: economie — US. (FY46-73), $6.6 million,
grants; from international] organizations (1946-73),
$1.7 million
Monetary Conversion rate; $BH1.66= US$]
(March 1975)
Fiscal year: calendar year','4568441b76c7c125be380fe4b56d98e7426d6a99fbcdc5e1da60a0db53de922e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('019d9daae5a704184ae3c0c60400af4f33560832307e899759b0f65fcd6a55a7',1976,'BM','Bermuda','economy',64,'GNP: $300-$350 million (at market prices, 1974),
$5,000-$6,000 per capita
Agriculture: main products — bananas, vegeta-
bles, Easter lilies, dairy products, citrus fruits
Major industries: tourism, finance
Electric power: 86,120 kw. capacity (1974); 298
million kw.-hr. produced (1974), 5,820 kw.-hr. per
capita
Exports: $29.4 million (f.o.b.,
reexports of drugs and bunker fuel
Imports: $154.6 million (f.o.b.,
foodstuffs, machinery
Major trade partners: U.S. 45%, U.K. 22%,
Canada 9% (1971)
Monetary conversion rate: 1 Bermuda dol-
lar= US$1
Fiscal year: 1 April - 31 March','1df8f6f460b197ba59b38e6ea14c64c6c35abc5a7faa9a0341e8fff71306b3d5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f64bd159f7c4214e66a5ec1bafdf8376394871d5d7e944e929c52281321da4b',1976,'IN','India','economy',68,'GNP: under $100 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 1,900 kw. capacity (1974); 5
million kw.-hr. produced (1974), 4 kw.-hr. per capita
Exports: about $1 million annually; rice, dolomite.
and handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic — India (FY61-72) $180 million
Monetary conversion rate: both ngultrums and
Indian rupees are legal tender; 8.77 ngultrums =8.77
Indian rupees 2 US$1 as of October 1975
Fiscal year: 1 April - 31 March
GNP: $1.16 billion (1974, in 1973 dollars), $230 per
capita; 69% private consumption, 11% public
consumption, 16% gross domestic investment, +4%
net foreign balance (1974); real growth rate 1971-74
average 5.9%
Agriculture: main crops — potatoes, corn, rice,
sugarcane, yucca, bananas; imports significant
quantities of foodstuffs including lard, vegetable oils,
and wheat; calorie intake, 1,800 calories per day per
capita (1971)
Major industries: mining, smelting, petroleum
refining, food processing, textiles, and clothing
Electric power: 309,000 kw. capacity (1974); 904
million kw.-hr. produced (1974), 180 kw.-hr. per
capita
Exports: $555.1 million (Lo.b., 1974 est) tin,
petroleum, lead, zinc, silver, tungsten, antimony,
bismuth, gold, coffce, sugar, cotton
Imports: $390.8 million (Lob. 1974 est.)
foodstuffs, chemicals, capital goods, pharmaceuticals
Major trade partners: exports — U.K. 26%, US.
17%, West Europe 4%, Latin America 20%; imports
— US. 28%, Latin America 27%, Japan 17%,
Western Europe 26% (1972)
Aid: economic — extensions from U.S. (FY46-73)
$300 million in loans, $319 million in grants; from
international organizations (FY46-73), $228 million;
from other Western countries (1960-72), $53.3
million; Communist countries (1970-74), $60.2
million; military — assistance from U.S. (FY52-73),
$36 million (1974, in 1973 dollars)
Budget: $152 million revenues, $159 million
expenditures
Monetary conversion rate: 20 pesos = US$1
Fiscal year: calendar year
CNP: $66 billion (1974, in 1973 prices), $112 per
capita; real growth 1.4% (FY70-74), 1% est.
Agriculture: main crops — rice, other cereals,
pulses, oilseeds, cotton, jute, sugarcane, tobacco, tea,
and coffee; must import foodgrains; caloric intake is
low and diet is deficient in protein
Fishing: catch 2.3 million metric tons (FY73);
value of fish catch, $357 million (FY73); exports
$114 million (FY73), imports $2 million
Major industries: textiles, food processing, steel,
machinery, transportation equipment, cement, jute
manufactures
Crude steel: 7 million metric tons produced (FY74)
Electric power: 19,480,000 kw. capacity (1974);
78.8 billion kw.-hr. produced (1974), 124 kw.-hr. per
capita
Exports: $4.1 billion (fo.b., FY74); tea, jute
manufactures, iron ore, cotton textiles, leather and
leather products, sugar
Imports: $5.5 billion (c.i.f., FY74); machinery and
transport equipment, petroleum, iron and steel, grains
and flour, fertilizers
Major trade partners: U.S., U.K., U.S.S.R. and
Eastern Europe, Japan, Iran
Budget: (FY75) revenue expenditures $7.4 billion,
capital expenditures $4.9 billion
Monetary conversion rate: 8.77 rupees- US$1
(October 1975)
Fiscal year: 1 April, stated year — 31 March','d5860113a6d09234cf4ba7391c8b2d86d9ce3f79ac101717d2e21042974d4196','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e3e8f6666c320998c090e6c6d1a9e641440e30186e3c776afd1bf4921500ea6',1976,'BW','Botswana','economy',74,'GDP: $142.6 million (April 1971 - March 1972),
about $210 per capita, growth in current prices about
25% annually (FY''s 1968-72)
Agriculture: principal crops are corn and sorghum,
livestock raised and exported
Major industries: livestock processing, mining of
diamonds, copper. nickel. coal. asbestos, and
manganese
Flectric power: 14,900 kw. capacity (1974): 64
million kw.-hr. produced (1974), 96 kw.-hr. per capita
Exports: $107 million (1974 est.); cattle, animal
products, minerals
Imports: $147 million (1974 est); foodstuffs,
vehicles, textiles
Major trade partners: South Africa and U.K.
Budget: (1976) revenue $134 million ($108 million
fram domestic taxes and $26 million from borrowing
and foreign aid), current expenditures $75 million,
investment expenditures $59 million
Monetary conversion rate: | SA Rand = US$1.15 as
of November 1975 (Botswana uses the South African
Rand)
Fiscal year: 1 April - 31 March','03f59cc84ece6d2c43347b38de16f7d52e0b1befee14e2e4efd85603457f004f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2326d15978a1f70a8cc32ed1f4c1619778583009c079742a6bf089de3f4a3dd',1976,'BR','Brazil','economy',78,'GNP: $77 billion (1974, in 1973 prices), $810 per
capita; 28% gross investment, 79% consumption,
—7% net foreign balance (1974); real growth rate
1974, 9.6%
Agriculture: main products — coffee, rice, beef,
corn, milk, sugarcane, soybeans; nearly self-sufficient;
caloric intake, 2,900 calories per day per capita (1962)
Fishing: catch 581,000 metric tons (1971) valued at.
$160 million (1971); exports (£o.b.) $26.7 million,
imports (f.0.b.) $27.5 million (1971)
Major industries: textiles and other consumer
goods, cement, lumber, steel, motor vehicles, other
metalworking industries
Crude steel: 8.5 million metric tons capacity (1974
est.); 7.5 million metric tons produced (1974); 72
kilograms per capita
Electric power: 17,643,000 kw. capacity (1974
est.); 74.3 billion kw.-hr. produced (1974), 700 kw.-hr.
per capita
Exports: $7,967 million (f.0.b., 1974); coffee,
manufactures, iron ore, cotton, soybeans, sugar, wood,
cocoa, beef, shoes
Imports: $14,161 million (c.i.f., 1974); machinery,
chemicals, pharmaceuticals, petroleum, wheat
Major trade partners: exports — U.S. 21%, West
Germany 7%, Italy 6%, Netherlands 7%, Japan 6%,
U.K. 6%; imports—U.S. 24%, West Germany 12%,
Japan 9%, U.K. 3%, Italy 396 (1974)
Aid: economic — extensions from U.S. (FY46-73)—
loans $4.8 billion, grants $655 million; from
23
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BRAZIL/BRITISH SOLOMON ISLANDS
international organizations (FY46-73) $3.0 billion;
from other Western countries (1960-71) $617.0
million; from Communist countries (1959-74) $330.6
million; drawings (1959-74) $120 million
Budget: (1974) revenues $11.3 billion, expenditures
$10.7 billion
Monetary conversion rate: 8.670 cruzeiros = US$1
(October 1975, changes frequently)
Fiscal year: calendar year
GDP: $29 million (1971)
Agriculture: largely dominated by coconut
production with subsistence crops of yams, taro,
bananas; self-sufficient in rice
Electric power: 5,600 kw. capacity (1974); 12
million kw.-hr. produced (1974), 66 kw.-hr. per capita
Exports: $10.3 million (1973); timber 40%, copra
30%, fish 17%
Imports: $12.0 million (1973)
Major trade partners: exports — Japan 42%, EEC
excluding U.K. 28%; imports—Australia 43%, Japan
12%, U.K. 11% (average 1972-74)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BRITISH SOLOMON ISLANDS/BRUNEI
Budget: (1971) revenues $9.8 million, expenditures
$9.9 million
Monetary conversion rate:
lar= US$1.31 (1975)
GNP: $420 million (1974 est.), $2,800 per capita
Agriculture: main crops — rubber, rice, pepper,
must import most food
Major industry: crude petroleum, liquefied natural
gas
Electric power: 84,000 kw. capacity (1974); 210
million kw.-hr. produced (1974), 1,354 kw.-hr. per
capita
Exports: $360 million (f.0.b. 1972); 96% crude
petroleum and liquefied natural gas
Imports: $88 million (c.i.f. 1972); 47% machinery
and transport equipment, 30% manufactured goods,
8% food
Major trade partners: exports of crude petroleum
and liquefied natural gas to Japan; imports from
Japan 30%, U.S. 24%, U.K. 15%, Singapore 9%
Monetary conversion rate: 2.54 Brunei dol-
lars = US$1
Fiscal year: calendar year','c364b7ab3a3b1937704ec29141275e178c7482998d5d7f33747bda43c25c6bb3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28eba80b3be6d1ee0926edb34d4d5bfb329d7de7bff699a275d95f55ebf9b8bb',1976,'BG','Bulgaria','economy',81,'GNP: $17.6 billion, 1974 (at 1973 prices), $2,020
per capita, 1971-74 real growth rate 7.2%
Agriculture: mainly self-sufficient; main crops —
grain, vegetables; caloric intake, 3,000 calories per
day per capita (1969/70)
Fishing: catch 98,000 metric tons (1978)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BULGARIA/BURMA
Major industries: agricultural processing, machin-
ery, textiles and clothing, mining, ore processing,
timber
Shortages: some raw materials, metal products,
meat and dairy products; fodder
Crude steel: 2.2 million metric tons produced
(1974), 260 kg. per capita
Electric power: 6,084,000 kw. capacity (1974);
99.8 billion kw.-hr. produced (1974), 2,620 kw.-hr. per
capita
Exports: $3,838 million (f.0.b., 1974) 41%
machinery, equipment, and transportation. equip-
ment; 1796 fuels, minerals, raw materials, metals, and
other industrial material; 3% agricultural raw
materials, 29% foodstuffs, raw materials for food
industry, and animals; 10% industrial consumer goods
(1974)
Imports: $4,283 million (f.0.b., 1974), 42%
machinery, equipment, and transportation equip-
ment; 37% fuels, minerals, raw materials, metals,
other materials; 8% agricultural raw materials; 8%
foodstuffs and animals; 6% industria] consumer goods
(1974)
Major trade partners: 27% with non-Communist
countries; 73% with Communist countries
Monetary conversion rate: (commercial) 0.97 leva,
(noncommercial) 1.20 leva US$1 (April 1975)
Fiscal year: calendar year; economic data reported
for calendar years except for culoric intake, which is
reported for consumption year 1 July - 30 June
Note: foreign trade figures were converted at the
1974 rate of 0.97 leva = US$1
GDP: $2.9 billion (FY75, in current prices), $96 per
capita; real growth rate 8.5% (FY75)
Agriculture: main crops — paddy, sugarcane, corn,
peanuts; almost 100% self-sufficient; most rice grown
in deltaic land
Fishing: catch 446,000 metric tons (1972), $80
million (1971)
Major industries: agricultural processing; textiles
and footwear, wood and wood products; petroleum
refining
Electric power: 397,000 kw. capacity (1974); 720
million kw.-hr. produced (1974), 24 kw.-hr. per capita
Exports: $199 million (f.o.b.. 1974); rice, teak
Imports: $125 million (c.i.£., 1974); machinery and
transportation equipment, textiles, other manufac-
tured goods
Major trade partners: exports — India, Western
Europe, U.K., Japan; imports — Japan, Western
Europe, India, U.K.
Budget: (FY75) $351 million revenues; $594
million expenditures; $243 million deficit; 30%
military, 70% civilian
Monetary conversion rate: 6.239 kyat = US$1
(official)
Fiscal year: 1 April - 31 March','fe6765c7051238e34f0aa00fc032d0ad58cbadbe2a181fcd81f6a96cafe86286','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed0a94059b5f88d0beca3db3e9ba65916b58153db19b6505aee67debf5d2b212',1976,'BI','Burundi','economy',86,'GNP: about $227 million (1972 est.), $60 per capita
Agriculture: major cash crops — coffee, cotton;
main food crops — manioc, yams, corn, sorghums,
bananas, haricot beans; not self-sufficient
Industries: light consumer goods such as beverages,
shoes, soap
Electric power: 13,100 kw. capacity (1974); 26
million kw.-hr. produced (1974), 7 kw.-hr. per capita
Exports: $28 million (£.o.b., 1974); coffee, cotton,
hides, skins
Imports: $42 million (c.i.f, 1974); textiles,
foodstuffs, transport equipment, petroleum products
Major trade partners: U.S., Belgium, Congo;
much trade unrecorded
Aid: $17.7 million (1970), includes Belgium $7.4
million, U.N. $3.1 million, EDF $2.9 million; France
$2.0 million (1970); U.S. $10 million (FY61-73)
Budget: FY75—revenue $37 million, current
expenditure $34 million
Monetary conversion rate: 78.80 Burundi
francs = US$1 (official)
Fiscal year: calendar year','e6e9ba6f361886a23b3ef07f42f51c84c72c29320490de56f0e1e72876a53d18','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21cca6e373a678b2f8a1eb81506814331f358815daeabb0061bbae06526c905e',1976,'KH','Cambodia','economy',89,'GNP: $950 million (1971). $140 per capita (1971
prices); considerably lower in 1975
Agriculture: mainly subsistence except for rubber
plantations; main crops — rice, rubber, corn; food
shortages—rice, meat, vegetables, dairy products,
sugar, flour
Major industries: rice milling, fishing, wood and
wood products, textiles
Shortages: fossil fuels
Electric power: 122,000 kw. capacity (1974);
280,000 kw.-hr. produced (1974), 36 kw.-hr. per
capita
Exports: $15 million est. (f.o.b., 1974); rubber
Imports: $210 million est. (f.0.b., 1974); rice,
machinery and equipment, petroleum products,
transport equipment
Major trade partners: exports — Singapore,
Hong Kong, South Vietnam; imports — U.S., Japan,
France; negligible with Communist countries (1973)
Budget: (1974) revenues, 23.1 billion riels;
expenditures, 84.0 billion riels; deficit, 60.9 billion
dels; 62% military, 38% civilian
Monetary conversion rate: not announced yet by
uew Khmer Rouge government
Fiscal year: calendar year','a83e6b9a31fea6e61b9e141f286cd4eb6b9d9e83cbf336da44460d585bb2731a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e93a9a98b8afed93a3800d4e0a427a48fc40570c1f3c17c832d13081fea6259a',1976,'CA','Canada','economy',93,'GNP: $126.6 billion (1974, in 1973 prices), $5,650
per capita (1974); 57% consumption, 20% investment,
23% government (1974); growth rate 4.85; (1970-74).
constant prices
Agriculture: main products — livestock, grains
(principally. wheat), dairy products; food shortages —
fresh fruits and vegetables; caloric intake, 3,180
calories per day per capita (1966-67)
Fishing: catch 8 million metric tons; exports 2
million metric tons (1974)
Major industries; mining, metals food products,
wood and Paper produets, transportation equipment,
chemicals
Shortages: rubber, rolled steel, textile fibers and
yarns, fruits, Precision instruments
Crude steel: 13.6 million metric tons produced
(1974)
Electric Power: 58,000,000 kw. capacity (1974);
278.9 billion kw.-hr. produced (1974), 10,500 kw.-hr.
per capita
Exports: $34,228 million (É.o.b., 1974, UN.
source); principal items — transportation equipment,
wood and wood products, ferrous and nonferrous ores,
crude petroleum, wheat; Canada is a major food
exporter
Imports; $34,573 million (cif, 1974. U.N. source);
Principal items — transportation equipment.
machinery, crude petroleum, communication
equipment, textiles, steel, fabricated metals, office
machines, fruits ang vegetables
Major trade partners: 66% Us. 13% EC, 7%
Japan (1974)
Aid: economic — (received) U.S., $204 million
(FY49-73), $148 million (FY74), none (FY58-67).
Bross official aid to less developed countries and
million (1978); military — U.S., $13.1 million (FY49.
Budget: total revenues $30,013 million; current
expenditures $28 459 million; gross capital formation
$955 million; budget surplus $606 million (1974)
(National Accounts Basis)
Monetary Conversion rate: there js no designated
1970; since then the Canadian dollar has moved
between US$0.98-1.04 in value, 1974 average
IC$ = US$1.0225
Fiscal year; ] April - 31 March
- 000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CANADA/CAPE VERDE ISLANDS
CDP: $33.5 million (1973 est.), based on 1970
census of 272,000; $123 per capita income
Agriculture: main crops—corn, beans, manioc,
sweet potatoes; barely self-sufficient in food
Fishing: largely undeveloped but provides major
source of export carnings (4,858 metric tons in 1970)
Major industries: salt mining (17,590 tons 1970)
Electric power: 5,700 kw. capacity (1974); 6
million kw.-hr. produced (1974); 22 kw.-hr. per capita
Exports: $1.6 million (f.o.b., 1971); fish, bananas,
salt
Imports: $20.3 million (c.i.f., 1971); machinery,
textiles
Major trade partners: Portugal, African neighbors
Aid: Portugal, $20 million (1974), for civil service
salaries, food, medicines; U.S., $5 million (1975), for
food and employment of rural workers
Budget: (est. 1974) $32 million expenditures, $12
million revenues
Monetary conversion rate: 27 escudos = US$1
(September 1975)
Fiscal year: probably calendar year
33
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CAPE VERDE ISLANDS/CENTRAL AFRICAN REPUBLIC','c23c6159cc02a65f82a1d55145a8a4b1c660ff55c57993792f7cfa31ebe435a0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe037c94163b9977a6e4b419265454f8980ceeae4fef98de9c60a2c1f511aafc',1976,'CF','Central African Republic','economy',99,'GDP: $266 million (1974), $150 per capita
Agriculture: commercial — cotton, coffee,
peanuts, sesame, wood; main food crops — manioc,
corn, peanuts, rice, potatoes, beef; requires wheat,
flour, rice, beef, and sugar imports
Major industries: sawmills, cotton textile mills,
brewery, diamond mining and splitting
Electric power: 16,850 kw. capacity (1974); 50
million kw.-hr. produced (1974), 30 kw.-hr. per capita
Exports: $71 million (f.0.b., 1974), diamonds
(4396), coffee, cotton, lumber
Imports: $89 million (c.i.f., 1974 est.); textiles,
petroleum products, machinery and electrical
equipment, motor vehicles and equipment, chemicals
and pharmaceuticals
Aid: economic — U.S. (FY61-73) $8.3 million;
(1972 est. disbursements) EC $6.4 million, IDA $3.9
million, U.S. $2.8 million, U.N. 812 million,
communist countries (1964-74) $6.8 million
Major trade partner: France; preferential tariff
applied to EC countries and franc zone; U.S,
Budget: 1974 budget estimates — receipt $65.4
million, current expenditure $71.7 million
Monetary conversion rate: 216 Communaute
Financiere Africaine francs = US$1 as of January 1975
(floating since February 1973)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CENTRAL AFRICAN REPUBLIC/CHAD
Fiscal year: calendar year','26c74a75f5f1ab281afd0d17a630c7251778b8740efc05bea4e04f302aa68930','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7431e97c16e228d74aff07fad079b6780852e651b300ad8496fdc3062b5f3639',1976,'TD','Chad','economy',103,'GDP: $300 million (1971), $85 per capita;
estimated real annual growth rate 2.5% (1963-68)
Agriculture: commercial — cotton, gum arabic,
livestock, fish; food crops — peanuts, millet, sorghum,
rice, dates, manioc, wheat: imports food
Fishing: catch 120,000 metric tons (1971), $14
million; exports $300,000 (1969)
Major industries: agricultural and livestock
processing plants (cotton textile mill, slaughterhouses,
brewery), natron
million kw.-hr. produced (1974), 15 kw.-hr. per capita
Exports: $38 million (f.o.b., 1973); cotton 65.7%
Imports: $82 million (cif. 1973); cement,
petroleum, foodstuffs, machinerv, textiles, and motor
vehicles; $1.3 million from Communist. countries
(1967)
Major trade partners: France (about 40% in 1969)
and UDEAC countries; preferential tariffs to EC and
franc zone countries
Aid: major source France, $469 million, 1961-69;
EDF $393 million (1965-70); U.S. (FY62-73) $11.1
million; U.S.S.R. $4.1 million (1968-74); China, $50. 1
million, 1971-74; military aid (1954-68) — $5.4
million, from France $4.1 million, remainder from
West Germany and Israel, more than $10 million
annually (est.) in French military aid (1969-71)
Budget: 1974 ordinary budget—$90 million
Monetary conversion rate: 218.75 Communaute
Vinanciere Africaine franes=US$1 as of August 1975
(floating since February 1973)
Fiscal year: calendar year','042cf0aef97821a84dc130d70b3669a512dd80c615779c90ae8530818f6b6919','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a084345052ef5e9f79dc38a0c40e19d556146b114692136f5ce492e6cac0001b',1976,'CL','Chile','economy',107,'GDP: $8.11 billion (1974, in 1973 prices), $840 per
capita; 68% private consumption, 16% government
consumption; 19% gross investment, —3% net
imports and factor payments abroad (1972 est.); real
growth rate, 1970-74 average annual increase 2.8%
Agriculture: main crops — wheat, other cereals,
potatoes; about 65% self-sufficient; 2,650 calories per
day per capita (1971 est.)
Fishing: catch 664,000 metric tons (1973); exports
$20.3 million, imports $2.1 million (1972)
Major industries: copper, nitrates, foodstuffs, fish
processing, textiles and apparel, iron and steel, pulp
and paper
Crude steel: 0.7 million metric tons capacity
(1967); 596,000 metric tons produced (1974), 61 kg.
per capita
Electric power: 2,500,000 kw. capacity (1974); 9
billion kw.-hr. produced (1974), 900 kw.-hr. per
capita
Exports: $2.0 billion (f.o.b., 1974 est.); copper, iron
ore, nitrates, and iodine
Imports: $2.2 billion (c.i.£., 1974 est.); foodstuffs,
machinery and equipment, chemicals
Major trade partners: exports — EC 44%, Japan
14%, U.S, 8%, LAFTA 1196; imports — EC 28%,
U.S. 16%, Japan 3%, LAFTA 18% (1972)
Aid: economic — extensions from U.S. (FY46-73)
— $1,488.5 million ($1,265 million loans, $224
million grants); from international organizations
(FY46-73) — $600 million (of which IBRD $233
million, IDB $273 million); from other Western
countries (1960-66) — $170.6 million; from
Communist countries (1967-74) — $447.7 million;
military (FY53-73) — from U.S., $48 million in loans,
$137 million in grants
Budget: $1.9 billion revenues, $2.7 billion
expenditures (1974)
Monetary conversion rate: 6.70 pesos=US$1
(October 1975), changes frequently
Fiscal year: calendar year
GNP: $223 billion (1974), $240 per capita
Agriculture: main crops — tice, wheat, miscellane-
ous grains, cotton; caloric intake, 2,000 calories per
day per capita (1974); agriculture mainly subsistence,
grain imports 7.0 million tons in 1974
Major industries: iron and steel, coal, machine
building, armaments, textiles
Shortages: complex machinery and equipment,
highly skilled scientists and technicians
Crude steel: 23.8 million metric tons produced, 26
kilograms per capita (1974)
Exports: $6.5 billion (f.o.b., 1974); agricultural
products, minerals and metals, manufactured goods
Imports: $7.5 billion (c.1.£., 1974); grain, chemical
fertilizer, industrial raw materials, machinery and
equipment
Major trade partners: Japan, U.S., Hong Kong,
West Germany, Singapore/Malaysia, Canada,
Australia, France, U.K., U.S.S.R. (1974)
Monetary conversion rate: about 2 yuan=US$1
(arbitrarily established )
Fiscal year: calendar year','29e6e84dde0a646f1205e323cc603f6b3cc78552dedd889c63c690ce5a8b4f55','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('370403b36a157cf6de757dfa57f73a6e895bd8a09b6cc4aff589aff096a1303b',1976,'CN','China','economy',111,'GNP: $10.3 billion (1974. in 1973 prices), 8660.per
capita; real growth, —9.4% (1970-74 average)
Agriculture: most arable land intensely farmed —
60% cultivated land under irrigation; main crops —
rice, sweet potatoes, sugarcane, bananas, pineapples,
citrus fruits; food shortages — wheat, corn, soybeans
Fishing: catch 697,425 metric tons (1974)
Major industries: textiles, clothing, chemicals,
plywood, electronics, sugar milling, food processing.
cement, ship building
Electric power: 4,450,000 kw. capacity (1974); 21
billion kw.-hr. produced (1974); 1.865 kw.-hr. per
capita
Exports: $5,623 million (f.0.b., 1974); textiles 26%.
electrical machinery 17%, plywood and wood
products 6%, machinery and metal products 7%.
plastics 6%, sugar 5%
Imports: $6,988 million (c.i£., 1974); machinery
16%, electrical machinery 10%, basic metals 12%.
crude oil 10%, chemical products 9%
Major trade partners: exports—37% U.S., 15%
Japan; imports—32% Japan, 24% U.S. (1974)
Aid: economic — U.S. (FY53-74) $8.1 billion
committed; IBRD (1964-74) $311 million committed;
Japan (1965-73) $247 million committed; ADB (1968-
74) 893 million committed; military—U.S. (FY49-74)
$3.5 billion committed
Budget: $2.3 billion (FY76)
Monetary conversion rate: NT$38 (New Tai-
wan)= US$]
Fiscal year: 1 July - 30 June
10','c0376853a5a57e87d3de3341f23801fd5901328c8eac7ca3b16f12c6a8e88252','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b92e903bba3dda4d74b83c5ae172bf1dd716bd13cb9a26a062351dc3f76d86a1',1976,'CO','Colombia','economy',115,'GNP: $10.52 billion, est. (1974, in 1973 prices),
$420 per capita; 73% private consumption, 8% public
consumption, 20% gross investment (1973); real
growth rate 1974, 5.6%.; average real growth rate,
1971-74, 6.3%
Agriculture: main crops — coffee, rice, corn,
sugarcane, plantains, bananas, cotton, tobacco;
caloric intake, 2,140 calories per day per capita (1970)
Fishing: catch 91,200 metric tons 1972; exports
$4.7 million (1969), imports $5.9 million (1969)
Major industries: textiles, food processing, clothing
and footwear, beverages, chemicals, and metal
products
Crude steel: 0.39 million metric tons production
(1972), 17 kilograms per capita
Electric power: 3,200,000 kw. capacity (1974);
11.9 billion kw.-hr. produced (1974), 480 kw.-hr. per
capita ''
Exports: $1.6 billion (fo.b., 1974 est.); coffee,
petroleum, cotton, tobacco, sugar, textiles, cattle and
hides
Imports: $1.7 billion (c.i.f., 1974 est.); transporta-
tion equipment, machinery, industrial metals and raw
materials, chemicals and pharmaceuticals, fuels,
fertilizers, paper and paper products, foodstuffs and
beverages
Major trade partners: exports — U.S. 36%,
Germany 16%, Spain 7%; imports — U.S. 40%,
Germany 10%, Japan 8%, Spain 4% (1973)
Aid: economic — extensions from U.S. (FY46-73),
$1,296 million loans, $270 million grants; from
international organizations (FY46-73), $1.6 billion;
from other Western countries (1960-71), $77.6
million; from Communist countries (1968-74) $24.5
million ($2.7 million drawn) military — assistance
from U.S. (FY46-73) — $142 million
Budget: (1974) revenues $860 million; expenditures
$960 million
Monetary conversion rate: 30.361 pesos- US$1
(April 1975, changes frequently)
Fiscal year: calendar year
GDP: about $25 million (1968); $100 per capita;
growth probably negligible through 1974
Agriculture: food crops — rice, manioc, potatoes,
fruits, vegetables; export crops — essential oils for
perfumes (mainly ylang-ylang), vanilla, copra, sisal
Exports: $6.0 million (1972); perfume oils, vanilla,
copra, sisal
Imports: $11.3 million (1972); foodstuffs, cement,
fuels, chemicals, textiles
Major trade partners: France, Malagasy Republic,
Italy, Kenva, Tanzania and U.S.
Electric power: 1,000 kw. capacity (1974); 3.2
million kw.-hr. produced (1974); 11 kw.-hr. per capita
Aid: French aid in 1971 was about $2.7 million, or
about 50% of the islands entire budget
Budget: 1972
expenditures $6.2 million, investment expenditures
$0.7 million
Monetary conversion rate: 216 Communaute
Financiere Africaine (CFA) francs=US$1 as of
January 1975 (floating since February 1973)','78d5bce24a687718691e5d00012fc3781134e7f6d4632526de2faedd69fe09f7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bf68bcc12abafd0471f9141c9a4c66851a6c94458e8e09b0fcab7696ba7ad70',1976,'CG','Congo','economy',119,'GDP: about $277 million (1970 est.), $310 per
capita, real growth rate about 4% per year
Agriculture: cash crops — sugarcane, wood, coffee,
cocoa, palm kernels, peanuts, tobacco; food crops —
root crops, rice, corn, bananas, manioc, fish
Fishing: catch 21,000 metric tons, $5.6 million
(1972)
Major industries: sawmills, brewery, cigarettes.
sugar mill, soap
Electric power: 42,000 kw. capacity (1974); 120
million kw.-hr. produced (1974), 90 kw.-hr. per capita
Exports: $62 million (f.0.b., 1973); lumber, sugar,
tobacco, vencer, and plywood
Imports: $85 million (c.i£, 1973); machinery,
transport equipment, manufactured consumer goods,
iron and steel, foodstuffs, petroleum products
43
0001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00080001
January 1976
CONGO/COOK ISLANDS
Major trade partners; France and other EC
countries on preferential basis
Budget: 1973 —revenuc $82 million, expenditure
$104 million
Monetary conversion rate: 216 Communaute
Financiere Africaine francs = US$l as of January 1975
Fiscal year: calendar year','d67e76b4a4134e1d66c9240a567ac4d5c48cb35cb7973cd7f6b61fcb62636f8e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f52a94f469fd5cc469f3e1b659d5535a8ceca3b7f538411877d330a470d70e4',1976,'CK','Cook Islands','economy',123,'GDP: $400 per capita (1973)
Agriculture: export crops include copra, citrus
fruits, pineapple, tomatoes, and bananas, with
subsistence crops of yams and taro
Industry: fruit Processing
Electric power: 2,800 kw. capacity (1974). 8
million kw.-hr. produced (1974), 381 kw.-hr. per
capita
Exports: $2.7 million (1971): fruit juice, clothing,
citrus fruits
Imports: $5.8 million (1971)
Major trade Partners: (1970) exports — 98% New
Zealand, imports — 76% New Zealand, 7% Japan
Monetary conversion rate: 1 NZ$=US81.3535
(February 1975)','d343835399ff6bacbb319448d5c77386b6ce049c4fccb35c4b4799e4b8829278','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('238d6bf4d89c65670cba7f70d2a6bcb974a85995efe4a509c00e1f77ba3d0b6f',1976,'CR','Costa Rica','economy',127,'GNP: $1.5 billion (1974, in current prices), $770 per
capita; real growth rate 1974, 4%; average growth
1969-73, 6.4%
Agriculture: main products — bananas, coffee,
sugarcane, rice, corn, cocoa, livestock products;
caloric intake, 2,610 calories per day per capita (1966)
Fishing: catch 8,900 metric tons, $2.5 million
(1972); exports, $1.8 million (1970), imports $0.5
million (1970)
45
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
COSTA RICA/CUBA
Major industries: food processing, textiles and
clothing, construction materials, fertilizer
Electric power: 321,000 kw. capacity (1974); 1.4
billion kw.-hr. produced (1974), 720 kw.hr. per
cupita
Exports: $441 inillion (fo.b., 1974); coffee,
bananas, becf, sugar, cacao
Imports: $716 million (c.i.f, 1974); manufactured
products, machinery, transportation. equipment,
chemicals, fuels, foodstuffs, fertilizer
Major trade partners: exports—33% U.S., 25%
CACM, 13% West Germany: imports—35% U.S.,
20% CACM, 7% West Germany, 9% Japan (1973)
Aid: economic — extensions from U.S. (FY46-73),
$122 million loans, $101 million grants; from
international organizations (FY46-73), $208 million;
From other Western countries (1960-71 ), $7.7 million;
military — assistance from U.S. (FY60-73) $1.9
million; Communist—$15 million (economic) from
US.SR. (1971)
Monetary conversion rate: 8.54 colones = US$1
(official buying rate); 8.60 colones=US$1 (official
selling rate)
Fiscal year: calendar year
GDP: $6.1 billion (1974 est., in 1974 prices), $670
per capita; 60% private consumption, 20% public
consumption, 20% gross investment; real growth rate
1974, 5%
Agriculture: main crops — sugar, tobacco, coffec,
rice, potatoes, tubers, citrus fruits
Fishing: catch 163,000 metric tons (1974); exports
$50 million (1974), imports $13.1 million (1972)
Major industries: sugar milling, petroleum
refining, food and tobacco processing, textiles,
chemicals, paper and wood products, metals
Shortages: spare parts for transportation and
industrial machinery, consumer goods
Crude steel: 0.35 million metric tons capacity
(planned); 220,600 metric tons produced (1973); 20
kg. per capita
Electric power: 1,216,000 kw. capacity (1974); 5.6
billion kw.-hr. produced (1974), 650 kw.-hr. per
capita
Exports: $2,745 million (£o.b., 1974 est.); sugar,
nickel, tobacco
Imports: $2,450 million (c.if., 1974 est.); capital
goods, industrial raw materials, food, petroleum
Major trade partners: exports — U.S.S.R. 34%,
China 5%, other Communist countries 15%, Japan
16%; imports—U.S.S.R. 48%, China 7%, other
Communist countries 10% (1974 est.)
Monetary conversion rate: 1 peso = US$1.21
(nominal)
Fiscal year: calendar year','59f840ed9f7a06165a0b360a9de949aafb97b5966f02b39d385bed6057462956','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('748544b1ba19a9a560559bb6a2278fa53aea95bc11672a700c7f2f42d53e7cb8',1976,'CY','Cyprus','economy',131,'GNP: $871.0 million (1974), $1,300 per capita;
1974 real growth rate 2.09;
Agriculture: main crops — vine products, citrus,
potatoes, other vegetables; food shortages — grain,
dairy products, meat, fish; caloric intake, 2,460
calories per day per capita (1964-66)
Major industries: mining (cupreous and iron
pyrites, asbestos), manufactures principally for local
consumption — food, beverages, footwear
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CYPRUS/CZECHOSLOVAKIA
Shortages: water, petroleum
Electric power: 204,000 kw. capacity (1974); 830
million kw.-hr. produced (1974), 985 kw.-hr. per
capita
Exports: $160 million (f.o.b., 1974— converted at
average trade conversion factor of 1 Cyprus
pound = US$2.85); principal items — copper, pyrites,
citrus, raisins, and other agricultural products
Imports: $400 million (c.i.f, 1974—converted at
average trade conversion factor of 1 Cyprus
pound = US$2,85); principal items — manufactured
goods,
petroleum products, foods
Major trade partners: (1973) imports — U.K. 25%,
West Germany 9%, Italy 8%, France 7%, U.S. 796;
exports — U.K. 42%, West Germany 7%, Nether-
lands 4%, U.S.S.R. 4%
Aid: economic — U.S., $32.5 million authorized
FY46-73; IBRD, $56.1 million (FY46-73); UN.
Technical Assistance, $1.7 million (FY46-72); U.N.
Special Fund, $9.9 million (FY46-72)
Budget: 1974—revenues $137 million, expenditures
$263 million, deficit $126 million
Monetary conversion rate: 1 Cyprus pound=
US$2.61 (December 1971 through January 1973), 1
Cyprus pound = US$2.823 (trade conversion factor as
of May 1975)
Fiscal year: calendar year
NOTE: 1974 GNP, import, export, and budget
figures are Government of Cyprus figures which
include 100% of island until August 1974 and 60% of
island thereafter; the Turkish sector of island for last 4
months of 1974 is part of Turkish mainland economy
GNP: $43.6 billion in 1974 (at 1973 prices), $2,970
per capita; 1974 real growth rate 4.6%
Agriculture: diversified agriculture, main crops —
wheat, rye, potatoes, sugar beets; net food importer —
meat, wheat, vegetable oils, fresh fruits and
vegetables; caloric intake, 3,100 calories per day per
capita (1967)
Major industries: machinery, food processing,
metallurgy, textiles, chemicals
Shortages: ores, crude oil
Crude steel: 13.6 million metric tons produced
(1974), 930 kg. per capita
Electric power: 12,796,000 kw. capacity (1974); 56
billion kw.-hr. produced (1974), 3,800 kw.-hr. per
capita
Exports: $7,033 million (f.o.b., 1974); 5096
machinery, equipment; 28% fuels, raw materials; 4%
foods, food products, and live animals; 1856 consumer
goods, excluding foods (1973)
Imports: $7.504 million (fo.b., 1974) 37%
machinery, equipment; 43% fuels, raw materials; 13%
foods, food products, and live animals; 7% consumer
goods, excluding foods (1973)
Monetary conversion rate: noncommercial 9.27
crowns = US$1, commercial 5.43 crowns z US$1
(average through July 1975)
0 ^ Approved For Release 2005/04/22
Fiscal year: calendar year
Note: foreign trade figures were converted at the
rate of 5:80 crowns=US$1
GNP: $849 million (1974), $111 per capita; real
growth rate, 4.6% per annum (1967-71)
Agriculture: major cash crop is oil palms; peanuts,
cotton, coffee, sheanuts, and tobacco also produced
commercially; main food crops — corn, cassava,
yams, sorghum and millet; livestock, fish
Fishing: catch 32,900 metric tons (1971); exports
122.2 metric tons, imports 4,000 metric tons
Major industries: palm oil and palm kernel oil
processing
Electric power: 11,310 kw. capacity (1974); 50
million kw.-hr. produced (1974), 16 kw.-hr. per capita
Exports: about $43 million (£o.b., 1974); palm
products (34%); other agricultural products
Imports: $126 million (cif, 1974); clothing and
other consumer goods, cement, lumber, fuels,
foodstuffs, machinery, and transport equipment
Major trade partners: France, EC, franc zone;
preferential tariffs to EC and franc zone countries
Aid: economic (through FY78) — EC, $4.5 million;
U.N., $8.9 million; West Germany, $1 million;
Taiwan, $1 million; U.S. (FY59-73), $14.7 million;
China, $44 million extended (1972)
Budget: 1974 est. — receipts $48 million,
expenditures $52.2
Monetary conversion rate: 216 Communaute
Financiere Africaine francs = US$1 as of January 1975
Fiscal year: calendar year','2d300bcc0a873ede93827736d973bea9147a081ede0ed6681904a838aaa746d5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1bd17216b780c5eb5526f913ed928e581a90cb7776c9eca8ef2842892862140',1976,'DK','Denmark','economy',135,'GNP: $27.3 billion (1974), $5,410 per capita; 54%
private consumption, 26% investment, 20% govern-
ment; 1974 growth rate 1.5%, constant prices
Agriculture: highly intensive, specializes in
dairying and animal husbandry; main crops —
cereals, root crops; food shortages — oilseeds, grain,
feedstuffs; caloric intake, 3,180 calories per day per
capita (1968-69)
Fishing: catch 1.44 million metric tons valued at
$211 million, exports $391 million (1973)
Major industries: food processing, machinery and
equipment, textiles and clothing, chemical products,
electronics, transport equipment, metal products,
brick and mortar, furniture and other wood products
Shortages: most industrial raw materials and fuels
Crude steel: 449,000 metric tons produced (1978),
90 kg. per capita
Electric power: 5,588,000 kw. capacity (1974);
18.7 billion kw.-hr. produced (1974), 2,900 kw.-hr. per
capita
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
DENMARK/DOMINICA
Exports: $7,697 million (f.0.b., 1974); principal
items — meat, dairy products, industrial machinery
and equipment, textiles and clothing, chemical
products, transport. equipment, fish, furs, and
furniture
Imports: $9,919 million (c.i.f., 1974); principal
items — industrial machinery, transport equipment,
petroleum, textile fibers and yarns, iron and steel
products, chemicals, grain and feedstuffs, wood and
paper
Major trade partners: EC-nine 44.37% (U.K.
13.60%; West Germany 16.01%); Sweden 14.71%,
U.S. 5.90%; Communist countries 3.90% (1974)
Aid: economic — U.S., $343 million authorized
FY46-73; IBRD, $85.0 million through 1973, none
since 1964; net official economic aid given to less
developed areas and multilateral agencies, $250.5
million (1960-70), $58.3 million (1969), $63.2 million
(1970), $80 million (1971 provisional); military —
U.S., $626 million (FY49-73)
Budget: (1974) expenditures $11.0 billion, revenues
$11.3 billion
Monetary conversion rate: 1 Kroner = US$0.164,
1974, average exchange rate
Fiscal year: 1 April - 31 March
Government budget: Colony — revenues, $1.0
million (FY68); expenditures, $1.1 million (FY68)
Agriculture: Colony — predominantly sheep
farming; dependencies — whaling and sealing
Major industries: Colony — wool processing;
dependencies — whale and seal processing
Electric power: 1,200 kw. capacity (1974); 2.8
million. kw.-hr. produced (1974), 1,100 kw.-hr. per
capita
Exports: Colony — $2.28 million (1969); wool,
hides and skins, and other; dependencies — no exports
in 1968 or 1969
Imports: Colony — $1.22 million (1969); food,
clothing, fuels, and machinery; dependencies —
$8,368 (1969); mineral fuels and lubricants, food, and
machinery
Major trade partners: nearly all exports to the
U.K., also some to the Netherlands and to Japan;
imports from Curacao, Japan, and the U.K.
Monetary conversion rate: 1 Falkland Island
pound - US$2.60
GNP: $183 billion (1974), $3,260 per capita; 63.4%
consumption, 20.8% investment, 20.196 government,
— 4.99; net foreign balance; 1972 GDP growt
5.9%
Agriculture: mixed farming predomi
products — wheat, barley, potatoes,
livestock, dairy products; 50% self-su
shortages — meat, fruits, vegetables, cereals, dairy
products; caloric intake, 8,170 calories per
capita (1970-71)
Approv
proved For Release 2005/04/22 : CIA-RDP79-01051A000800010
001-8','90f4a2baefd5e563f8b3d7dec5213ce4b978d2d47e3a24be1d28894d560270c7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11a76c111b4b07355e2ef5ae5b45ddc0d9a4b277348d487246939c72ab7969fd',1976,'DM','Dominica','economy',139,'GDP: $21.0 million (1971 est.), $270 per capita;
8.8% increase in 1971 — including price changes
Agricultural products: bananas, citrus, coconuts,
cocoa
Major industries: agricultural processing, tourism
Electric power: 5,500 kw. capacity (1974); 16
million kw.-hr. produced (1974), 230 kw.-hr. per
capita
Exports: $6.1 million (f.o.b., 1970); bananas, lime
juice and oil, cocoa, reexports
Imports: $16.3 million (c.i.f., 1970); machinery
and equipment, foodstuffs, manufactured articles
Major trade partners: U.K. 53%, Commonwealth
Caribbean countries 15%, Canada 10%, US. 7%
(1963)
Monetary conversion rate: 2.07 East Caribbean
dollars=US$1 (May 1975), now floating with pound
sterling','d2db710b52cd87fa87bd91df3e2e893a276196f07e377e3067883c7de10c7341','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3ea0d659dc8e0d265420a8628798fed9d6cc58fdc5e6652772bec5a364f4b20',1976,'DO','Dominican Republic','economy',143,'GNP: $3.0 billion (1974), $660 per capita; real
growth rate 1974, 8.8%
Agriculture: main crops — sugarcane, coffee,
cocoa, tobacco, rice, corn; self-sufficient in rice;
caloric intake, 2,200 calories per day per capita (1966)
Major industries: sugar processing, nickel mining,
bauxite mining, peanut processing, textiles, cement
Electric power: 356,665 kw. capacity (1974), 1.4
billion kw.-hr. produced (1974), 310 kw.-hr. per
capita
Exports: $637 million (f.0.b., 1974); sugar, nickel,
coffee, tobacco, cocoa, bauxite
Imports: $774 million (cif, 1974); foodstuffs,
petroleum, industrial raw materials, capital
equipment
Major trade partners: exports—U.S. 5696 (1974);
imports—U.$. 60% (1974)
Aid: economic — from U.S. (FY46-73), $224
million in grants, $297 million in loans; from
international organizations (FY46-72), $147 million;
from other western countries (1960-71), $11.7 million
military — assistance from U.S. (FY53-73), $33
million
Monetary conversion rate: | peso = US$1
Fiscal year: calendar year','116ea7e6b79cc61945f01ba6b27b6d5885daddc4dc0d0d55d5e860a51b22a1de','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e003c58af814edef020873734fe0780783670211dbe8081b13b98a591a203278',1976,'EC','Ecuador','economy',147,'GNP: $3.1 billion (1974), $450 per capita; 629;
private consumption, 16% public consumption, 22%
gross investment (1974 est.); real growth rate 1974,
14%
Agriculture: main crops — bananas, coffee, cocoa,
sugarcane, cotton, corn, potatoes, rice; caloric intake,
1,970 calories per day per capita (1970)
Fishing: catch 105,000 metric tons (1971); exports
$30.0 million (1973), imports negligible (1971)
Major industries: food processing, textiles,
chemicals, fishing, petroleum
Electric power: 390,000 kw. capacity (1974); 1.4
billion kw.-hr. produced (1974), 184 kw.-hr. per
capita
Exports: $834 million (fo.b., 1974); bananas,
petroleum, coffee, cocoa, sugar, fish products
Imports: $602 million (f.o.b., 1974); agricultural
and industrial machinery, wheat, petroleum products,
chemical products, transportation and communica-
lion equipment
Major trade partners: exports — U.S. 35%, EC
15%, Japan 5%, imports—U.S. 33%, EC 26%, Japan
11% (1973)
Aid: economic — extensions from U.S. (FY46-73),
$209 million loans, $118 million grants; from
international organizations (FY46-73), $273 million;
from Communist countries (1967-74), $15.4 million
loans; military — assistance from U.S. (FY49-72), $63
million
Budget: $600 million
Monetary conversion rate: 25.25 sucres = US$1
(official selling rate)
Fiseal year: calendar year
GNP: $9 billion (1974 est., in 1973 prices), $240 per
capita; inter war annual growth rate of 1% or less
accelerated to 495-596 since 1973
Agriculture: main cash crop — cotton; other crops
— rice, onions, beans, citrus fruit, wheat, corn, barley;
not self-sufficient in food, but agriculture a net carner
of foreign exchange
Major industries: textiles, food processing,
chemicals, petroleum, construction, cement
Electric power: 4,476,000 kw. capacity (1974), 8
billion kw.-hr. produced (1974), 220 kw.-hr. per
capita
Monetary conversion rate: 1 Egyptian pound=
US$2.54 (selling rate); 0.394 Egyptian pound = US$1
(selling rate)
Fiscal year: calendar year, beginning in 1973','e07e52b9ee9d1a672ed2f78daeda01fe914fc6019623cda3ed301c5e422f44f3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ceed0c9cbaf41fe4b425db021275556901e47315f9566d83626471b832a063c0',1976,'SV','El Salvador','economy',151,'GNP: $1.6 billion (1974 est.), $410 per capita; 78%
private consumption, 1176 government consumption,
20% domestic investment, —9% net foreign balance
(1974 cst.); real growth rate 1974, 5.7%
Agriculture: main crops — coffee, cotton, corn,
sugar, rice, beans; caloric intake, 2,000 calories per
day per capita (1963-64)
Fishing: catch 15,600 metric tons (1972); exports
$6.0 million (1971), imports $0.5 million (1972)
Major industries: food processing, textiles,
clothing, petroleum products
Electric power: 225,000 kw. capacity (1974); 860
million kw.-hr. produced (1974), 225 kw.-hr. per
capita
Exports: $463 million (L.o.b., 1974); coffee, cotton,
sugar
Imports: $562 million (cif, 1974); machinery,
automotive vehicles, petroleum, food-stuffs, fertilizer
Major trade partners: exports — U.S. 33%, CACM
32%, EC 18%, Japan 10% (1973); imports—U.S.
30%, CACM 20%, EC 20%, Japan 7% (1974)
Aid: economic — from U.S. (FY46-73), $90.6
million loans, $67.2 million grants, from international
organizations (FY46-73), $193 million; from other
Western countries (1960-71) $9.8 million; military —
assistance from U.S. (FY53-73), $8 million
Budget: $426 million
Monetary conversion rate: 2.5 colones=US$1
(official)
Fiscal year: calendar year
Approved For Release 2005/04/22 :','8c250a4a129658b416b2487d27a50f2b04de83bdee0680575b1a7fe8ea96d245','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e56b03d5a644811e10b7af076e56792ce90fc8b03cf67fe0f3873ace8e437697',1976,'GQ','Equatorial Guinea','economy',155,'GNP: $70 million (1972); 8240 per capita
Agriculture: major cash crops — Rio Muni, timber,
coffee; Fernando Po, cocoa; main food products —
rice, yams, cassava, bananas, oil palm nuts, manioc,
and livestock
Fishing: catch 4,000 metric tons (1970); exports
$86,000 (1970)
Major industries: fishing, sawmilling
Electric power: 2,800 kw. capacity (1974); 23
million kw.-hr. produced (1974), about 75 kw.-hr. per
capita
Exports: $19 million (1973); cocoa, coffee, and
wood
Imports: $21 million (1973); foodstuffs, chemicals
and chemical products, textiles
Major trade partner: Spain
Aid: Spain, $14.0 million (1969); Libya, $1 million
(1971); China 824 million extended (1971)
Budget: 1978 budget receipts $9 million,
expenditures $12 million
Monetary conversion rate: 64.47 Guinean
pesetas = US$I (official)','059eb6e5bca61e167f708c7a20fa6daf390c38c3d545e0bae7382676c3c6a12d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eab45ccb7b6970e46c855a17229aaf1653f3463449889273c61f7ca28a80e420',1976,'ET','Ethiopia','economy',159,'GDP: $2,450 million (1972), $80 per capita;
average annual real growth rate 4% (1967-72)
Agriculture: main crops — coffee, teff, durra,
barley, wheat, corn, sugarcane, cotton, pulses,
oilseeds; livestock
Major industries: cement, sugar refining, cotton
textiles, food processing, oil refinery
Electric power: 384,000 kw. capacity (1974), 678
million kw.-hr. produced (1974), 25 kw.-hr. per capita
Exports: $267 million (£.o.b., 1974); coffee 27%,
pulses 17%, hides and skins 8%, oilseeds, oilcakes, and
nuts 20% ; $4.6 million to Communist countries (1971)
Imports: $273 million (c.i... 1974); metals,
machinery and vehicles 47%, petroleum and
chemicals 17%, foodstuffs, live animals, and
beverages 7%; $9.7 million from Communist countries
(1970)
Major trade partners: imports — Italy, Japan,
West Germany, and U.S.; exports — U.S., West
Germany, Italy, Saudi Arabia, Japan
Monetary conversion rate: 92.09 Ethiopian
dollars = US$1
Fiscal year: 8 July - 7 july
GDP: $90.9 million (1971), about $2,270 per capita
Agriculture; sheep and cattle grazing
Fishing: catch 208,000 metric tons; exports, $60
million (1973)
Major industry; fishing
Electric power; 28,000 kw. capacity (1974), 82
million kw.-hr. produced (1974), 1,800 kw.-hr. per
capita
Exports: $79 million (Lo.b., 1978); fish and fish
products
Imports: $68 million (cif, 1973); machinery and
transport equipment, petroleum and petroleum
products, food products
Major trade partners: (1972) Denmark 47%, EC-
six 12%, U.K, 8%, U.S. 8%, Norway 4%, Sweden 4%
Budget: (FY72) expenditures $22] million,
revenues $22.4 million
- 00800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FAEROE ISLANDS/FALKLAND ISLANDS (MALVINAS)
Monetary conversion rate: 1 Danish Kroner-
US$0.164 (1974)
Fiscal year: 1 April - 81 March','649305088b4be1505bb18684a12a8c5fc8c02796a84ad179fdcd55de8220a8e5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4e0cf589504991c94a7edb84fb2f4239ec2d64c5596b56013dd1a380fab80c4',1976,'FJ','Fiji','economy',163,'GNP: $329 million (1973), $600 per capita; 6.895
real growth rate (1971-73)
Agriculture: main crops — sugar, coconut
products, bananas, rice; major deficiency, grains
Major industries: sugar processing, tourism
Electric power: 76,000 kw. capacity (1974); 230
million. kw.-hr. produced (1974), 410 kw.-hr. per
capita
Exports: $154 million (£o.b., 1974, including
reexports); sugar 48%, copra 8%, copper 8%
Imports: $271 million (cif, 1974); machinery
25%, manufactured goods 25%, food 20%
Major trade partners: exports—U.K. 40%,
Australia 14 %, U.S. 14%, Canada 11%; imports—
Australia 30%, Japan 16%, U.S. 14%, New Zealand
12%
Aid: disbursed 1968 — Australia $1.5 million, U.S.
$0.6 million, U.K. $4.2 million
Monetary conversion rate:
lar=US$1,2774 (April 1975)
Fiscal year: calendar year','ef435d2aca7ba08a065e49e1be37d934febf6876d5c9460bc6f93844fd36b5b3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d804f2658cec21e71c24cfd5b8445b8a4c459eae7ad1d4597c5eeaaa1e53f585',1976,'FI','Finland','economy',167,'GNP: $21 billion (1974), $4,500 per capita; 51.8%
consumption, 31.6% investment, 22.6% government,
—6.0% net exports of goods and services; 1974 growth
rate 5.2%, constant prices
65
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FINLAND/FRANCE
Agriculture: animal husbandry, especially
dairying, predominates; forestry important secondary
occupation for rural population; main crops —
cereals, sugar beets, potatoes; 85% self-sufficient;
shortages — food and fodder grains; caloric intake
2,940 calories per day per capita (1970-71)
Major industries: include metal manufacturing
and shipbuilding, forestry and wood processing (pulp,
paper), copper refining
Shortages: fossil fuels; industrial raw materials,
except wood, and iron ore
Crude steel: 1.7 million metric tons produced
(1974), 370 kilograms per capita
Electric power: 7,294,720 kw. capacity (1974);
27.4 billion kw.-hr. produced (1974), 5,800 kw.-hr. per
capita
Exports: $5.5 billion (f.o.b., 1974); timber, paper
and pulp, ships, machinery, iron and steel, clothing
and footwear
Imports: $6.8 billion (c.i.f, 1974); foodstuffs,
petroleum and petroleum products, chemicals,
transport equipment, iron and steel, machinery,
textile yarn and fabrics
Major trade partners (1974); 40% EC-nine (12%
West Germany, 13% U.K.), 18% Sweden; 16%
U.S.S.R; 6% U.S.
Aid: U.S. $182 million authorized FY46-73, $22.1
million in FY71, none in 1972, 1.5 million in 1973;
IBRD—$296.5 million authorized through 1946-73,
$20 million in 1973; Finnish foreign aid programs
have amounted to $28 million 1961-69, $15,000 in
1970
Budget: (1974) expenditures $5.2 billion, revenues
$5.4 billion
Monetary conversion rate: new markka (Fmk)
3.75= US$1 (1974 trade conversion factor, IMF)
Fiscal year: calendar year','7ba698357fbb11e46dcd6c6ea4d115b55b601d18f0e2648a7fd85e0ba0cd504e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72b5ac8ef8cac24e44e73373b2e136d43be96acfefe2de7682c878fcfc20e664',1976,'FR','France','economy',171,'GNP: $275.4 billion (1974), $5,230 per capita;
60.6% consumption, 28.3% investment (including
government), 12.4% government consumption;
—1.3% net foreign balance (1974); 1974 real growth
rate 3.8%
Agriculture: Western Europes foremost producer;
main products — beef, cereals, sugar beets, potatoes,
wine grapes, self-sufficient for most temperate zone
foodstuffs; food shortages — fats and oils, tropical
produce; caloric intake, 3,270 calories per day per
capita (1969-70)
Fishing: catch 783,000 metric tons, $380 million
(1972); exports $64 million, imports $300 million
(1972)
Major industries: steel, machinery and equipment,
textiles and clothing, chemicals, food processing,
metallurgy
Shortages: crude oil, textile fibers, most nonferrous
ores, coking coal, fats and oils
Crude steel: 27.0 million metric tons produced
(1974), 513 kilograms per capita
Electric power: 45,200,000 kw. capacity (1974);
188.3 billion kw.-hr. produced (1974); 3,000 kw.-hr.
per capita
Exports: $46.4 billion (f.0.b., 1974); principal items
— machinery and transportation equipment,
foodstuffs, agricultural products, iron and steel
products, textiles and clothing, chemicals
Imports: $52.1 billion (c.i.f., 1974); principal items
— crude petroleum, machinery and equipment,
chemicals, iron and steel products, foodstuffs,
agricultural products
Major trade partners: West Germany 1856;
Belgium-Luxembourg 11%: Italy 9%; U.S. 6%;
Netherlands 5%; U.K. 5%; Eastern Europe 3%;
U.S.S.R. 1%; Franc Zone 4%
Aid: economic (received) — U.S., $5,382 million
authorized (FY46-73), 544 million in FY78; military
— US. $4,355 million authorized (FY46-73); net
official economic aid to less developed areas and
multilateral agencies — $8,400 million (FY60-70),
$1,125 million in 1971, $457 million in 1974
Budget: (1974) expenditures 236.7 billion francs,
revenues 240.5 billion francs, surplus 3.8 billion francs
Monetary conversion rate: 1 franc = U$$0.2079
(1974 average)
Fiscal year: calendar year
67
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
1-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00080001000
January 1976
FRANCE/FRENCH GUIANA','7c27d1f31549aef2a11e275a2b477e17cd3a90c8c3914aec0786d640fa42aac5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4993eed52cb06af43258da3790ee57d3e7b9636b6dab8225d302e53d34efffd2',1976,'GF','French Guiana','economy',175,'GNP: $40 million (at market prices, 1970), $800 per
capita
Agriculture: main crops — rice, corn, manioc, -
cocoa, bananas, sugarcane
Fishing: catch 1,300 metric tons (1972); shrimp
exports $3.9 million; imports $2.3 million (1969)
Major industries: timber, rum, gold mining,
production of rosewood essence, and space center
Electric power: 28,600 kw. capacity (1974), 56
million kw.-hr. produced (1974), 1,080 kw.-hr. per
capita
Exports: $5 million (f.o.b., 1973); shrimp, timber,
rum, rosewood essence
Imports: $56 million (c.i, 1973); food (grains,
processed meat), other consumer goods, producer
goods and petroleum
Major trade partners: exports — U.S. 78%, France
11%, Martinique 5%; imports — France 49%, U.S.
10%, Trinidad and Tobago 3% (1969)
Monetary conversion rate: 4.44 French francs =
US$1 (1973)
Fiscal year: calendar year','90d54cef8672236309c1c95beb18276b01698db02cd6cffef7d4e649b5819706','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b3e736f54f4be164ce0608a7a26f7af911bd4fb5f40992508978c96c54f947d',1976,'PF','French Polynesia','economy',179,'GDP; $259 million (1970) $1,963 per capita (1971)
Agriculture: coconut main crop
Major industries: maintenance of French nuclear
test base, tourism
Electric power: 36,000 kw. capacity (1974); 79
million kw.-hr. produced (1974), 577 kw.-hr. per
capita
69
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FRENCH POLYNESIA/FRENCH TERRITORY OF THE AFARS AND ISSAS
Exports: $19 million (1973); principal products —
coconut products (79%), mother-of-pearl (14%)
(1971)
Imports: $211 million (1973)
Major trade partners: imports — 59% France, 14%
U.S.; exports — 86% France
Aid: France $16 million (1973)
Monetary conversion rate: 100 CFP=1NZ$ (1971)
Gross territorial product: $68 million (1970)
Agriculture: livestock; desert conditions limit
commercial erops to about 15 acres, including fruits
and vegetables
Industry: ship repairs and services of port and
railroad
Electric power: 23,200 kw. capacity (1974); 56.3
million kw.-hr. produced (1974), 470 kw.-hr. per
capita
Imports: $60 million (1972), almost all domes-
tically needed goods
Exports: $27 million, including perhaps $18 million
of transit trade (1972); hides and skins, and transit of
coffee
Aid: $2.4 million in 1967 from France
Monetary conversion rate: 177 Djibouti francs=
US$1
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FRENCH TERRITORY OF THE AFARS AND ISSAS/ GABON
Fiseal year: probably same as that for France
(calendar year)
GNP: $193 million, $1,800 per capita (1971 est.)
Agriculture: large areas devoted to cattle grazing;
major products — coffee and vegetables; 60% self
sufficient in beef; must import grains and vegetables
Industry: mining of nickel
Electric power: 261,000 kw. capacity (1974); 1.6
billion kw.-hr. produced (1974), 12,698 kw.-hr. per
capita
Exports: $263 million (f.o.b., 1974); 9996 nickel
Imports: $283 million (c.f, 1974); machinery,
transport equipment, food
Major trade partners: (1972) exports — France
55%, Japan 24%, U.S. 1196; imports — France 52%,
Australia 13%, rest of EEC 12%
Monetary conversion rate: 86 CFP francs- US$1
(1972)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NEW CALEDONIA/NEW HEBRIDES/NEW ZEALAND
Agriculture: export crops of copra, cocoa, coffee,
some livestock and fish production; subsistence crops
of copra, taro, yams
Electric power: 4,200 kw. capacity (1974); 11
million kw.-hr. produced (1974), 122 kw.-hr. per
capita
Exports: $14 million (1978); copra, frozen fish
Imports: $28 million (1973)
Monetary conversion rate: 1 pound=US$2.37
(official currency), 0.74 Australian $=US$1, 86
Colonial Franc Pacifique (CFP)=US$1 (1972)','a17c97b75785b6e5e43dd95186442e12e0580b2f4a84279ec771d640fe229bcd','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('607dc70ef3916bcbd5f2d812a2d8be180f7fc23b20bdb90a0cdc07abbbcc4b52',1976,'GA','Gabon','economy',183,'GDP: $1,389 million (1974 est.), $2,671 per capita;
87% growth (1973-74)
Agriculture: commercial — cocoa, coffee, wood,
palm oil, rice; main food crops — bananas, manioc,
peanuts, root crops; imports food
Fishing: catch 4,000 metric tons (1970); exports
$600,000 (1970)
Major industries: petroleum production, sawmills,
petroleum refinery, natural gas, agricultural
71
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GABON/GAMBIA
processing; mining of increasing importance; major
minerals — manganese, uranium, gold, and iron
Electric power: 60,000 kw. capacity (1974); 165
million kw.-hr. produced (1974), 306 kw.-hr. per
capita
Exports: $928 million (f.0.b., 1974); wood and
wood products, minerals (manganese, uranium
concentrates, gold)
Imports: $440 million (cif, 1974) excluding
UDEAC trade; mining, roadbuilding machinery,
electrical equipment, transport vehicles, foodstuffs,
textiles
Major trade partners: France, U.S., West
Germany, and Curacao; preferential tariffs to EC and
franc zone
Budget: 1975 est. — receipts $630 million, current
expenditures $184 million, investment expenditures
$446 million
Monetary conversion rate: 216 Communaute
Vinanciere Africaine francs = US$1 as of January 1975
Fiscal year: calendar year','f16f8a53546b3b34806e35ee59c713a458cb0d9dcf3c5cc3f3845539bdcc222c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f80c59d9e89d35d8f5132868b84ce30603dcf1ba245b04651e8b993cf19492b',1976,'GM','Gambia','economy',187,'GDP: $62 million (FY73 est.), about $120 per
capita
Agriculture: main crops — peanuts, rice, palm
kernels
Fishing: catch 6,000 metric tons (1971); exports
$108,000 (1971)
Major industry: peanut processing
Electric power: 9,600 kw. capacity (1974); 12
million kw.-hr. produced (1974), 38 kw.-hr. per capita
Exports: $23 million (FY73), peanuts and peanut
products 90% to 95%, palm kernels
Imports: $29 million (FY73); textiles, foodstuffs,
tobacco, machinery, petroleum products
Major trade partners: exports — U.K. and France;
imports — U.K. and Japan
Aid: economic — U.K. (1968-71) about $8 million
commitment; U.S. (FY56-73) $5.2 million
Budget: (FY74 est.) current expenditures $14
million, receipts $14 million; development expendi-
tures $5.7 million, development receipts $1 million
Monetary conversion rate: 1 Dalasi=US$0.59
Fiscal year: 1 July - 30 June
GNP: $54.3 billion in 1974 (1973 prices), $3,210 per
capita, 1974 growth rate 5,79;
Agriculture: food deficit area; main crops —
potatoes, rye, wheat, barley, oats, industrial crops;
shortages in grain, vegetables, vegetable oil, beef:
caloric intake, 3,000 calories per day per capita (1970-
71)
Fish catch: 325,000 metric tons (1974)
Major industries: metal fabrication, chemicals,
light industry, brown coal, and shipbuilding
Shortages: coking coal, coke, crude oil, rolled steel
products, nonferrous metals
Crude steel: 6 million metric tons produced (1974),
approx. 360 kg. per capita
Electric power: 15,808,000 kw. capacity (1974);
80.3 billion kw.-hr. produced (1974), 4,755 kw -hr. per
capita
74
Approved For Release 2005/04/22 :
Exports: $8,846 million (£o.b. delivering country,
1974)
Imports: $9,719 million (£o.b, delivering country,
1974)
Major trade partners; $18,565 million (1974); 309;
U.S.S.R., 32% other Communist countries, 38% non-
Communist countries
Monetary conversion rate: 3.53 DME=US$1 for
trade data (1974 rate)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake,
which is reported for the consumption year 1 July - 30
June
GNP: $383.8 billion (1974), $6,180 per capita
(including West Berlin) (1973); 54% consumption,
22% investment, 20% government; net foreign
balance 4%; 1974 growth rate 0.4%, 1962 constant
prices
Agriculture: main crops — grains, potatoes, sugar
beets; 7596 self-sufficient; food shortages — fats and
oils, pulses, tropical products; caloric intake, 2,984
calories per day per capita (1973-74)
Fishing: catch 492,070 metric tous, $200 million
(1974); exports $109 million, imports $302 million
(1974)
Major industries: among world''s largest producers
of iron, steel, coal, cement, chemicals, machinery,
ships, vehicles
Shortages: fats and oils, sugar, cotton, wool,
rubber, petroleum, iron ore, bauxite, nonferrous
metals, sulfur
Crude steel: 60.6 million metric tons capacity; 53.2
million metric tons produced (1974); 860 kilograms
per capita
Electric power: 65,000,000 kw. capacity (1974);
313 billion kw.-hr. produced (1974), 4,660 kw.-hr. per
capita
Exports: $89.0 billion (f.0.b., 1974); manufactures
88.396 (machines and machine tools, chemicals, motor
vehicles, iron and steel products); agricultural
products 4.496; fuels 3.4%; raw materials 2.6%
Imports: $69 billion (c.i.f, 1974); manufactures
52,5%, fuels 19.3%, agricultural products 14.0%, raw
materials 11.3%
Major trade partners: EC 46% (France 12%,
Netherlands 12%, Belgium-Luxembourg 8%, Italy
7%; other Europe 17%; U.S. 8%; OPEC 8%;
Communist countries 6%
75
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GERMANY, WEST/GHANA
Aid: economic — U.S. $4,162 million authorized
(FY46-78); $16 million authorized (FY78); military.—
U.S., $939 million authorized (FY46-73), none since
FY64; net official aid flows to less developed countries
and multilateral agencies (1962-74)—$9,394 million,
$1,526 million (1974)
Budget: (1974) expenditures $51.4 billion, revenues
$47.5 billion, deficit $5 billion
Monetary conversion rate: DM 2.59 (West
German marks) - US$1 (1974 average)
Fiscal year: calendar year','d198d47181ed2d2236cf00f9f45fd5e580d928b684c0ce4209b12cc22b46c924','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9610eb2fad72ba45e33e9964366419eac2a739962770ca365afbf850fa42b97',1976,'GH','Ghana','economy',191,'GNP: $3.7 billion (1974) at current prices, about
$390 per capita; growth rate 8.7% (1974)
Agriculture: main crop — cocoa, other crops
include root crops, corn, sorghum and millet, peanuts;
not self-sufficient, but can become so
Fishing: catch 281,000 metric tons (1972), $45.7
million
Major industries: mining, lumbering, light
manufacturing, fishing, aluminum
Electric power: 893,000 kw. capacity (1974); 3.5
billion kw.-hr. produced (1974), 380 kw.-hr. per
capita
Exports: $672 million (f.0.b., 1974); cocoa (about
65%), wood, gold, diamonds, manganese, bauxite,
and aluminum (aluminum regularly excluded from
balance of payments data)
Imports: $713 million (c.i.L, 1974); textiles and
other manufactured goods, food, fuels, transport
equipment
Major trade partners: U.K., EC, and U.S.
Budget: FY74—revenue $532 million, current
expenditure $525 million, capital expenditure $157
million
Monetary conversion rate: 1 Cedi=US$0.87
Fiscal year: 1 July - 30 June','d136d25ebe8d15736f3247feeaf6c2af755e488982c0350eec9fa3c25dbb8bac','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('611ee40e7c11dce18ebf0f932dc8c11a6f639f1fd2ce06043d15c5c25b821f86',1976,'GI','Gibraltar','economy',195,'Economic activity in Gibraltar centers on
commerce and large British naval and air bases;
nearly all trade in the well-developed port is transit
trade and port serves also as important supply depot
for fucl, water, and ships'' wares; recently built
dockyards and machine shops provide maintenance
and repair services to 3,500-4,000 vessels that call at
Gibraltar each year.
U.K. military establishments and civil government
employ nearly half the insured labor force; local
industry is confined to manufacture of tobacco,
roasted coffee, ice, mineral waters, candy, and canned
fish; some factories for manufacture of clothing are
being developed; a small segment of loca] population
makes its livelihood by fishing; in recent years tourism
has increased in importance.
Electric power: 25,000 kw. capacity (1974); 50
million kw.-hr. produced (1974), 1,500 kw.-hr. per
capita
Exports: $2.9 million (£o.b., 1971); principally
reexports of tobacco, petroleum, and wine; principally
to the EC (3196) and the U.K. (16%)
78
hau o s
Imports: $23.1 million; principally from the EC
(21%) and the U.K. (49%)
Major trade partners; U.K., Morocco, Portugal,','3fd5df4f09368de83a9332ce36c161ac7e888b5b88f2f1d23d62582e7dec7cfa','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c6a4588b2346f016edc6b00778e664bf51950b47a2d8f8c48ee143173249c00',1976,'NL','Netherlands','economy',196,'Monetary conversion rate: 1 Gibraltar pound
US$2.414 (as of September 28, 1973, floating)
GDP: $740 per capita (1974)
Agriculture: copra, subsistence crops of vegetables,
supplemented by domestic fishing
Industry: phosphate production, expected to cease
in 1978
Electric power: 15,000 kw. capacity (1974); 38
million kw.-hr. produced (1974), 633 kw.-hr. per
capita
Exports: $8.6 million (1970 est.); 70% phosphate,
copra
Imports: $3.1 million (1970 est.); foodstuffs, fuel
Budget: (est.) revenue 5.877 million NZ$,
expenditure 4.577 million NZ$
Monetary conversion rate: 0.74 Australian
$=US$1 February 1975
GNP: $69.2 billion (1974 in current prices), $5,120
per capita; 56% consumption, 22% investment, 17%
government; 5% foreign balance; 1974 growth rate
3.3% in constant prices
Agriculture: animal husbandry predominates:
main crops — horticultural crops, grains, potatoes,
sugar beets; food shortages — grains, fats, oils: calorie
intake, 3,186 calories per day per capita (1970-71)
Fishing: catch $23,000 metric tons, $150 million
(1973); exports 251,398 metric tons, imports 131,488
metric tons (1973)
Major industries: food processing, metal and
engineering products, electrical and electronic
machinery and equipment, chemicals, and petroleum
products
Shortages: crude petroleum, raw cotton, base
metals and ores, pulp, pulpwood, lumber, feedgrains,
and oilseeds
Crude steel: 6.1 million metric ton capacity; 5.8
million metric tons produced (1974), 430 kilograms
per capita
Electric power: 12,200,000 kw. capacity (1974);
55.2 billion kw.-hr. produced (1974), 3,350 kw.-hr. per
capita
Exports: $32,698 million (£o.b., 1974); foodstuffs,
machinery, transportation equipment, consumer
manufactures, chemicals, petroleum products, textiles
Imports: $32,512 million (c.i.f., 1974); machinery,
transportation equipment, consumer manufactures,
crude petroleum, foodstuffs, chemicals, raw cotton,
base metals and ores, pulp
Major trade partners: (1974) 64% EC, 28% W,
Germany, 13% Belgium-Luxembourg, 6% U.S.
Aid: economic — U.S., $1,367 million authorized
(FY46-73); IBRD, $236 million authorized (FY46-78),
none since 1958; military — U.S., $1,955 million
authorized (FY49-73), none since FY65; net official
aid delivered to less developed areas and multilateral
agencies, $1,458 million (FY62-72), $315 million
(1972)
146
Budget: (1974) revenues $18.6 billion, expenditures
$19.7 billion, deficit $1.1 billion
Monetary conversion rate: 2.689 guilders - US$1,
average 1974, floating
Fiscal year: calendar year
GNP: $209 million (1973), $890 per capita
Agriculture: little production
Major industries: petroleum refining on Curacao
and Aruba; tourism on Curacao, Aruba, and St.
Martin; phosphate mining on Curacao
Electric power: 300,000 kw. capacity (1974); 1.5
billion kw.-hr. produced (1974), 5,600 kw.-hr. per
capita
Exports: $1,379 million (f.o.b., 1973); petroleum
products, phosphate
Imports: $1,604 million (cif, 1973); crude
petroleum, food manufactures
Major trade partners: exports — U.S. 43%, EC
16%, Latin America 13%, U.K. 10%, Canada 7%;
imports — Venezuela 72%, U.S. 10%, Netherlands 4%
(1968)
Monetary conversion rate: 1.79 Netherlands
Antillean florins (NAF)=US81, official
Fiscal year: calendar year','99c30376e828e443b0875e5ae88629f4fd4053988d711ce4ca3eb7aa15cba550','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c2ed57444d9953bc8acffb5ce65e434d17fb387d3820a8cdbd5a04656c64a77',1976,'GR','Greece','economy',203,'GNP: $20.3 billion (1974 est.), $2,260 per capita;
65.4% consumption, 32.5% investment, 11.3%
government (1973); net foreign balance —9.2%. real
growth rate —2% (1974)
Agriculture: subject to droughts; main crops —
wheat, olives, tobacco, cotton; nearly self-sufficient;
food shortages — livestock products; caloric intake,
2,960 calories per day per capita (1963)
Major industries: food processing, tobacco,
chemicals, textiles, petroleum refining, aluminum
processing
Shortages: petroleum, minerals, feed grains
Crude steel: 900,000 metric tons produced (1973),
100 kg. per capita
Electric power: 3,442,500 kw. capacity (1974);
13.7 billion kw.-hr. produced (1974), 1,059 kw.-hr. per
capita
Exports: $1,774 million (£o.b., 1974); principal
items — tobacco, cotton, fruits, textiles
80
Approved For Release 2005/04/22
Imports: $4,635 million (c.if., 1974); principal
items — machinery and automotive equipment,
manufactured consumer goods, petroleum and
petroleum products, chemicals, meat and live animals
Major trade partners: (January to November 1974)
— 44% EC, 18% U.S., 9% other European countries,
8% CEMA countries
Aid: economic (authorized) — U.S., $1,992.2
million (FY46-73); International Finance Cor-
poration, $15 million through FY73; U.N. Technical
Assistance, $4.3 million through FY72; U.N. Special
Fund, $63.1 million through 1972; IBRD, $118.9
million (FY68-73), $25 million in 1972; Consortium,
$40 million in 1966; EC (FY64-72) $69.2 million:
U.S.S.R. $7.7 million (1954-74); military — US,
$2,337 million (FY1946-73)
Budget: (1974) expenditures $4,249 million,
revenues $3,506 million, deficit $743 million
Monetary conversion rate: 1 drachma - US$0.033
(approx.)
Fiscal year: calendar year','05407975fa5b5f83139e210e5a5808d6638df6ef60cb05d8b05e7d3aecad4fdd','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d2055f58a33e16cbfdce56858212914e74437ed8cc03aac6b3ca34b28feeb1c',1976,'GL','Greenland','economy',207,'GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep
grazing; garden produce
Fishing: catch 51,200 tons (1974); exports $30.8
million (1974)
Major industries: mining, slaughtering, fishing,
sealing
Electric power: 54,000 kw. capacity (1974); 105
million. kw.-hr. produced (1974), 1,700 kw.-hr. per
capita
Exports: $90.4 million (f.0.b., 1974); fish and fish
products, nonmetallic minerals
Imports: $104.0 million (f.o.b., 1974); machinery
and transport equipment, petroleum and petroleum
products, food products
Major trade partners: (1974) Denmark 62%,
France 12%, Finland 11%
Monetary conversion rate: | Danish Kroner=
US$0.182 (1975)
Fiscal year: 1 April - 31 March','8113e1bc860e821cc427714cd022b0d0f4752c89d4d29c261a9050083733fc87','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8fbf4aa588617f27ae32e1b573cbd5956febbf6f5d29f1efd37cf9c41f0062c',1976,'GD','Grenada','economy',211,'GDP: $24 million (in current prices, 1974), $250
per capita; —1.6% decrease in current prices (1974)
Agriculture: main crops — cocoa, spices, bananas
Fishing: 1,800 metric tons (1972)
Electric power: 7,000 kw. capacity (1974); 20
million kw.-hr. produced (1974), 150 kw.-hr. per
capita
Exports: $8.1 million (£o.b., 1974); cocoa beans,
bananas, nutmeg, mace
Imports: $16.3 million (cif,
machinery, building materials
Major trade partners: U.K. 41%, U.S. 8%, Canada
9% (1968)
Monetary conversion rate: 2.00 East Caribbean
dollars = US$1','ac20e24bd765bdfca599590e2f173a73d191851e432d7fca5ecab62aa6ceda83','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcd225b67015cde1301c0b63119d32199da07216d786b2f822899af5a3212e2a',1976,'MQ','Martinique','economy',216,'GDP; $302 million (1971), $880 per capita; real
growth rate (1971) 5.9%
Agriculture: main crops, sugarcane and bananas
Major industries: agricultural processing, sugar
milling and rum distillation
Electric power: 33,000 kw. capacity (1974); 125
million kw.-hr. produced (1974), 350 kw.-hr. per
capita
Exports: $58 million (£o.b., 1974); sugar, bananas,
rum
Imports: $230 million (c.i.f., 1974); foodstuffs,
clothing and other consumer goods, raw materials and
supplies, and petroleum
Major trade partners: exports — France 71%, U.S.
17%, Germany 7%, other 5%; imports — France 70%,
U.S. 9%, Germany 3%, Netherlands Antilles 3%,
Netherlands 3%, other 12% (1968)
Monetary conversion rate: 4.44 French francs=
US$1 (1974)
Fiscal year: calendar year
GNP: $339 million (at market prices, 1971), $930
per capita; real growth rate (1971) 8.5%
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, par-
ticularly sugar milling and rum distillation; cement,
oil refining and tourism
Electric power: 32,000 kw. capacity (1974); 144
million kw.-hrs. produced (1974), 420 kw.-hrs. per
capita
Exports: $72 million (£o.b., 1974); bananas,
refined petroleum products, rum, sugar, pineapples
Imports: $293 million (c.if., 1974); foodstuffs,
clothing and other consumer goods, raw materials and
supplies, and petroleum
Major trading partners: exports — France 82%,
Italy 9%, other 9%; imports — France 70%, United
States 6%, Netherlands Antilles 3%, Netherlands 395,
other 1896 (1968)
Monetary conversion rate: 4.44 French francs =
US$1 (1974)
Fiscal year: calendar year','65f21dc7d88b47785baab07ab1e55578a24885ab0a8db7bb7682a9d79ad8d684','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95760805712fed46f7e95de623589d0f90c2f28bf991e7f3014af64067f4cae6',1976,'GT','Guatemala','economy',221,'GDP: $2,660 million (1974, in 1973 prices, est.),
$410 per capita; 78% private consumption, 7%
government consumption, 17% domestic investment,
—2% net foreign balance (1974); real growth rate
(1974), 5.2%
Agriculture: main products — coffee, cotton, corn,
beans, sugarcane, bananas, livestock; caloric intake,
2,200 calories per day per capita (1967)
Fishing: catch 5,000 metric tons (1970); exports
$1.6 million (1970), imports $0.5 million (1970)
Major industries: food processing, textiles and
clothing, furniture, chemicals, nonmetallic minerals,
metals
Electric power: 212,000 kw. capacity (1974); 910
million kw.-hr. produced (1974), 170 kw.-hr. per
capita
Exports: $588 million (f.0.b., 1974); coffee, cotton,
sugar, bananas, meat
Imports: $685 million (c.i.f., 1974); manufactured
products, machinery, transportation equipment,
chemicals, fuels
Major trade partners: exports (1973)—U.S. 33%,
CACM 80%, West Germany 9%, Japan 696; imports
(1973) — U.S. 31%, CACM 21%, West Germany
10%, Japan 10%, Venezuela 6%
Aid: economic — from U.S. (FY46-73), $139
million loans, $191 million grants; from international
organizations (FY46-73) $156 million; from other
western countries (1960-71), $12.8 million; military —
assistance from U.S. (FY53-73), $30 million
Central government budget (1975): budgeted
expenditures $397.2
Monetary conversion rate: 1 quetzal-US$l
(official)
Fiscal year: calendar year
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GUATEMALA/GUINEA','7229969599db36f02884c92840f5b5a6cd2e81fc362a86c6a43043597b6e2b08','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('450f1e07f275ae731e636b722a8a47e4d8369314e87ea41cdb9b45f9b757b0d6',1976,'GW','Guinea-Bissau','economy',225,'GNP: $107 million (1969, in 1963 constant prices),
$200 per capita
Agriculture: main crops—palm oil, root crops, rice,
coconuts, peanuts
Electric power: 10,742 kw. capacity (1974); 3
million kw.-hr. produced (1974), 6 kw.-hr. per capita
Exports: $3.6 million (f.o.b., 1969); principally
peanuts, coconuts
Imports: $23.3 million (c.i.£., 1969); manufactured
goods, fuels, transport equipment, rice
Major trade partners: mostly Portugal, also
immediate neighbors
Aid: Portugal, small amounts
Monetary conversion rate: 25.5 escudos- US$1,
(fixed, February 1973)
Fiscal year: probably is the calendar year','43e3adf6e662af665a21bf912b447e8508fcba0ec96f313e76341bb63e12ef46','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17875da65e0051da4e19ec7aff895930e15806a614cb9c605bc76c8d379a83bb',1976,'GY','Guyana','economy',229,'GNP: $415.2 million (1974), $520 per capita; real
growth rate 1973 est. —3.1%
Agriculture: main crops — sugarcane, rice, other
food crops; food shortages — wheat flour, potatoes,
processed meat, dairy products; caloric intake, 2,180
calories per day per capita (1967)
Fishing: catch 17,600 metric tons (1972), $10
million (1972); exports $4.8 million (1972), imports
$1.2 million (1971)
Major industries: bauxite mining, alumina
production, sugar and rice milling
Electric power: 120,000 kw. capacity (1974); 370
million kw.-hr. produced (1974), 470 kw.-hr. per
capita
Exports: $268 million (f.o.b., 1974); bauxite, sugar,
alumina, rice, shrimp, molasses, timber, diamonds,
rum
Imports: $256 million (c.i.f., 1974); manufactures,
machinery, food, petroleum
Major trade partners: exports—U.S. 25%, U.K.
20%, CARICOM 14%, Canada 4.5%; imports—U.S,
26%, U.K. 21%, CARICOM 27%, Canada 5% (1974)
Aid: economic — from U.S. (FY53-73), $58 million
loans, $26 million grants; from U.K. (FY60-70), $73.9
million; from China (1972-73), $26.0 million
extended; from international organizations (FY46-73),
$41 million
Monetary conversion rate: floating with pound, 1
pound = G$5.21
Fiscal year: calendar year
GDP: $816 million (FY14), $160 per capita; real
growth rate 1974, 3.596
Agriculture: main crops — coffee, sugarcane, rice,
corn, sorghum, pulses; caloric intake, 1,850 calories
per day per capita
Major industries: Sugar refining, textiles, flour
milling. cement manufacturing. bauxite mining,
tourism, light assembly industries
Electric power: 64,440 kw. capacity (1974); 162
million kw.-hr. produced (1974), 30 kw.-hr. per capita
Exports: $71 million (f.0.b., 1974); coffee, light
industrial products, bauxite, sugar, essential oils, sisal
Approved Fo
r Release 2005/04/22 : CIA-RDP79-01051A000
- 800010001-8
Imports: $74 million (c.i. E., 1973); consumer
durables, foodstuffs, industrial equipment, petroleum
products, construction materials
Major trade partners: exports— 7246
imports—U.5. 56% (FY72)
Aid: economic — from U.S., $38 million loans, $97
million grants (FY46-73): international organizations,
$42. million (FY46-13); from other Western countries
(1960-71) $2.4 million; military — U.S., $4 million
(FY53-73)
Monetary conversion rate: 5 gourdes= US$1
Fiscal year: 1 October - 30 September','af56aff0892bc1e9c727804e58a1b8408a14df1c8671ac5b8c1d57d1ba699fd9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('572f69b79a1761030a297e0319a25d67d5b20c2da120168aef8e106ce306b8b6',1976,'HN','Honduras','economy',233,'GNP: $850 million (1974, in 1973 Prices, est.), $300
Per capita; 78% Private consumption, 11%
government consumption, 26% domestic investment;
— 1596 net foreign balance (1973); rea] growth rate,
Agriculture; main crops — bananas, coffee, corm,
beans, cotton, sugarcane, tobacco; caloric intake,
2,300 calories per day per Capita (1964-65)
Fishing: exports $1.7 million (1972). imports $0.5
million (1970)
Major industries; agricultural Processing, textiles,
clothing, wood products
Electric Power: 166,000 kw. Capacity (1974). 410
million kw -hr. produced (1974), 140 kw.-hr. per
capita
Exports: $309 million (fo, b., 1974); bananas,
lumber, Coffee, meat, petroleum products
Imports: $379 million (cif, 1974); manufactured
Products, machinery, transportation equipment,
chemicals, petroleum
Major trade Partners: exports — U.S. 56%, West
Germany 12%, CACM 7%; imports — U.S. 40%,
CACM 12%, Japan 10%, Venezuela 8%, West
Germany 4% (1973)
Aid: economic — extensions from US. (FY46-73),
$74 million loans, $70 million grants; from
international organizations (FY46-73), $205 million;
from other Western countries (1960-73), $7.0 million;
military — assistance from US. (FY46-73), $10.0
million
Monetary Conversion rate, 2 lempiras = US$]
(official)
Fiscal year; calendar year','7dea40c431bc5a95ef63d29a8b5d373068414fc1eb18ff57fdc5d24a636c48d3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2cd0d96e6f22dda078fedd5bafe5ab0224310523d4f745bd8067c744f5ffb1d',1976,'HK','Hong Kong','economy',237,'GDP: $5.9 billion (1974, in 1973 prices), $1,370 per
capita (est.); average real growth 6.1% (1970-74)
Agriculture: agriculture occupies a minor position
in the economy; main products — rice, vegetables,
91
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
HONG KONG/HUNGARY
dairy products; less than 20% self-sufficient: food
shortages — rice, wheat
Major industries: textiles and clothing, tourism,
plastics, electronics, light metal products, food
processing
Shortages: industrial raw materials, water, food
Electric power: 2,335,000 kw. capacity (1974); 6.5
billion kw.-hr. produced (1974), 1,510 kw.-hr. per
capita
Exports: $6.2 billion (f.o.b., 1974), including $1.5
billion reexports; principal products clothing, plastic
articles, textiles, electrical goods, wigs, footwear, light
inetal manufactures
Imports: $7.0 billion (c.i f., 1974)
Major trade partners: 1974 exports—U.S. 26%,
U.K. 10%, West Germany 8%; imports—Japan 21%,
China 18%, U.S, 14%
Budget: (75/76) $1.27 billion
Monetary conversion rate: HK$5.085 = US$1
Fiscal year: 1 April - 31 March','1bae6cb8b270c2a228886f7c190e7322d1e3850e421f9169d143aed2255e94aa','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98ed7ce47a953980f9ad70f97646ce66edf05e69db5ce96828534179dc4472a4',1976,'HU','Hungary','economy',241,'GNP: 21.3 billion in 1974 (at 1973 prices), $2,030
per capita; 1974 growth rate 5.4%
Agriculture: normally self-sufficient; main crops —
corn, wheat, potatoes, sugar beets, wine grapes;
caloric intake 3,140 calories per day per capita (1970)
Major industries: mining, metallurgy, engineering
industries, processed foods, textiles, chemicals
(especially pharmaceuticals)
Shortages: metallic ores (except bauxite), copper,
high grade coal, forest products, crude oil
Crude steel: 3.47 million metric tons produced
(1974), 330 kg. per capita
Electric power: 3,760,000 kw. capacity (1974);
18.9 billion kw.-hr. produced (1974), 1,810 kw.-hr. per
capita
Exports: $5,129 million (£o.b., 1974); 28%
machinery, 19% industrial consumer goods, 28% raw
materials and semimanufactures, 24% food and raw
materials for the food industry, energy sources 1%
(distribution for 1974)
Imports: $5,575 million (1974), 21% machinery,
9% industrial consumer goods, 52% raw materials and
semimanufactures; 11% food and raw materials for
the food industry, energy sources 7% (distribution for
1974)
Major trade partners: $10,704 million (1974); 62%
with Communist countries, 38% with non-Commu-
nist countries
Aid: U.S.S.R. — $338 million extended (1956-66),
$10 million extended in 1967, $167 million extended
in 1968; to less developed non-Communist countries-
—-$537.5 million (1954-74)
Monetary conversion rate: 8.5 forints- US$1
(statistical); 20.4 forints = US$1 (noncommercial) as of
1 March 1975
Fiscal year: same as calendar year; economic data
reported for calendar years
NOTE: Foreign trade figures were converted at the
1974 rate of 9.15 forints=US$1','ec40ff15400548c1760574d1a1a2c9b156d52c739b3bbba1eb8d890aa01048c9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d82fe66c638753304f27b679bb6864fca7f24e2fdea202e7ffe42e4dda3adab8',1976,'IS','Iceland','economy',245,'GNP: $1,330 million (1974), $6,190 per capita;
66% consumption, 35% investment, 11% government,
—12% net foreign balance (1974); 1974 growth rate
4.3%, constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes,
turnips; food shortages — grains, sugar, vegetable and
other fibers; caloric intake, 2,900 calories per day per
capita (1964-66)
Fishing: catch 938,486 metric tons; exports $246
million (1974)
Major industries: fish processing, aluminum
smelting, diatomite production
Shortages: grain, fuel, wood, minerals, vegetable
fibers
Electric power: 468,629 kw. capacity (1974); 2.3
billion kw.-hr. produced (1974), 7,750 kw.-hr. per
capita
Exports: $329 million (f.o.b., 1974); fish and fish
products, animal products, aluminum, diatomite
Imports: $526 million (c.i.f., 1974); machinery and
transportation equipment, petroleum, foodstuffs,
textiles
Major trade partners: (1974) exports—U.S. 22%,
EC 2996, U.S.S.R. 8%; imports— EC 45%, U.S. 8%,
U.S.S.R. 9%
Aid: economic — U.S. authorized (1949-73) $90.2
million, $1.2 million in FY72, $0.9 million in FY73;
IBRD $30 million through September 1978
Budget: (1974) expenditures $294 million, revenues
$292. million
Monetary conversion rate: 1 kronur- US$0.0100
(average, 1974); 90.135 kronur=US$1 (1973); 99.952
kronur= US$1 (1974)
Fiscal year: calendar year','83bf60eeb025589e884506423520a1599e30be7484f8480ac93744df5e1879cb','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fdfa930ab6934c8f6571bea6834ed36236ea1c8e6d48e5c7063583c33233c5e',1976,'ID','Indonesia','economy',249,'GDP: $20 billion (1974), about $160 per capita;
real average annual growth (1970-74) 7.8%
Approved For Release 2005/04/22 :
Agriculture: subsistence food production, and
smallholder and plantation production for export;
main crops — rice, rubber, copra, other tropical
products; food shortage — rice
Fishing: catch 1.3 million tons (1972); exports $20
million (1972), imports $0.3 million (1970)
Major industriest^processing agricultural products
and petroleum, textiles, mining
Electric power: 1,630,000 kw. capacity (1974); 4.3
billion kw.-hr. produced (1974), 83 kw.-hr. per capita
Exports: $7,426 million (cif, 1974) timber,
rubber, tin, copra, tea, coffee, tobacco, palm oil;
petroleum, $5,211 million (424 million bbls.) (1974)
Imports: $3,842 million (f.0.b., 1974); rice, other
foodstuffs, textiles, chemicals, iron and steel products,
machinery, transport equipment, consumer durables
Major trade partners: exports (1974)—20% U.S.,
54% Japan, 8% Singapore, 2% Netherlands;
imports—16% U.S., 30% Japan, 9% West Germany,
6% Singapore
Budget: (1975-76) expenditures $6.6 billion;
54% current, 46% development expenditures; planned
receipts $6.5 billion, negligible deficit
Monetary conversion rate: 415 rupiah = US$1
Fiscal year: 1 April - 31 March
GNP: $36.4 billion (1974, in 1973 dollars), $1,130
per capita; recent GNP growth
Agriculture: wheat, barley, rice, sugar bects,
cotton, dates, raisins, tea, tobacco, sheep, and goats
Electric power: 3,172,000 kw. capacity (1974):
12.9 billion kw.-hr. produced (1974), 395 kw.-hr. per
capita
Exports: $24.0 billion (f£o.b., 1974); 97%
petroleum; also carpets, raw cotton, fruits, and nuts,
hide and leather items, ores
Imports: (non-military) $5.7 billion (c.i.f., 1974);
machinery, iron and steel products, chemicals,
pharmaceuticals, electrical equipment, agricultural
products
Major trade partners: exports — U.S., Japan, West
Germany, U S.S.R. and other Communist countries:
imports — U.S., West Germany, Japan, U.K.,
U.S.S.R.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
IRAN/IRAQ
Budget: (FY74-75) $18.4 billion
Monetary conversion rate: 67.88 rials = USS1
Fiscal year: 21 March -20 March','d502f107f817bbf80cb1bda39783a299486fb03bb7e7c03ef3dbc9509f8d6d8c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b511ebc1e6f9215f45458931f08bb1e9cc1ae4707685d48694c0f23e42a545d1',1976,'IQ','Iraq','economy',253,'GNP: $13 billion (1975 est.), $1,180 per capita
Agriculture: dates, wheat, barley, rice, livestock
Major industry: crude petroleum (third largest
producer in Middle East); 2.3 million b/d (mid-
1975); petroleum revenues estimated for 1974, $7.1
billion
Electric power: 958,000 kw. capacity (1974); 4.2
billion kw.-hr. produced (1974), 398 kw.-hr. per
capita
Exports: $7.4 billion (1974); net receipts from oil,
$7.1 billion; non-oil, $100 million est.
Imports: $2.9 billion (1974); 269; from Com-
munist countries (1973)
Major trade partners: exports — U.S. 2%, Italy
22%, France 19%, Netherlands 6%, U.K. 4%; imports
— US. 5.6%, U.K. 85%, U.S.S.R. 8.8%, France
3.4%, Japan 6.7%, Brazil 5.9%, Czechoslovakia 5.5%
(1973)
Budget (FY74/75 est.): revenue $6.0 billion (oil
rev. $5.4 billion), expenditures $6.3 billion, of which
current expenditures are $4.6 billion
Monetary conversion rate: 1 Iraqi dinar = US$3.38
(end of July 1973)
Fiscal year: 1 April - 31 March, FY75 1 April - 31
December 1975','2eec2b4c195d03c0235a5836c015c0f6990a926962c9cf3b4678bf80cde804c4','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58f96c854462d60562c6a092e4babdf260b5ba0ff8701f726952e3cb6dfc2e04',1976,'IE','Ireland','economy',257,'GNP: $6.7 billion (1974), $2,190 per capita;
67.8% consumption, 27.1% investment, 18.6%
government; —13.5% net export of goods and
services; 1972 real growth rate 3%
Agriculture: about 2/3 of agricultural area used for
permanent hay and pasture; main products —
livestock and dairy products, barley, potatoes, sugar
bects, wheat; 85% self-sufficient; food shortages —
grains, fruits, vegetables; caloric intake 3,510 calories
per day per capita (1970)
Fishing: catch 92,000 metric tons (1972); exports of
fish and fish products $13.3 million (1971), imports of
fish and fish products $4.4 million (1971)
Major industries: food products, brewing, textiles
and clothing, machinery and transportation
equipment
Shortages: coal, petroleum, timber and woodpulp,
steel and nonferrous metals, fertilizers, cereals and
animal feeds, textile fibers and textiles
Crude steel: 112,000 metric tons produced in
1974, 40 kilograms per capita
Electric power: 1,943,000 kw. capacity (1974); 7.3
billion kw.-hr. produced (1974), 2,200 kw.-hr. per
capita
Exports: $2,628 million (f.o.b., 1974); live animals,
meat, textile products, clothing, machinery, dairy
products, chemicals
Imports: $3,800 million (c.i.f., 1974); machinery,
chemicals, textiles, transportation equipment,
petroleum, metal manufactures, cereals
Approved For Release 2005/04/22 :
Major trade partners: 70.9% EC-nine (U.K.
50.6%, West Germany 7.09%); 8.4% U.S.; 13%
Communist countries (1974)
Aid: economic — U.S., $187.8 million authorized
(FY49-73), no activity (FY55-66), $12.6 million
authorized in FY69, none authorized in FY70-73;
IBRD $72.5 million authorized (FY64-72) $28 million
authorized (FY72)
Monetary conversion rate: 1 Irish pound =
US$2.453 (1973 average)
Fiscal year: 1 April - 31 March','a9bb1edcf5595c4c72ce813fb6f97a0bb190873f9e029cab97208458032c4f63','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ace0aa106bc38f4c88cdc2823aa8ab22d4a73a0c2f809ca284252e84df0b2bb7',1976,'IL','Israel','economy',261,'GNP; $8.8 billion (1974), $2.618 per capita
(converted to dollars at 6.0 Israeli pounds = US$1):
1974 growth of real GNP 5% in constant 1970 dollars
Agriculture: main products — citrus and other
fruits, vegetables, beef and dairy products, poultry
products
Major industries: food processing, textiles and
clothing, diamond cutting and polishing, chemicals,
metal products, transport equipment, electrical
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ISRAEL/ITALY
equipment, miscellaneous machinery, rubber and
plastic products, potash mining
Electric power: 1,745,000 kw. capacity (1974); 9.8
billion kw.-hr. produced (1974), 2,780 kw.-hr. per
capita
Exports: $1,825 million (f.o.b., 1974); major items
— polished diamonds, citrus and other fruits, textiles
and clothing, processed foods, fertilizer and chemical
products; tourism is leading foreign exchange earner
Imports: $4,237 million (c.i.f., 1974); major items
— rough diamonds, chemicals, machinery, iron and
steel, cereals, textiles, vehicles, ships, and aircraft
Major trade partners: exports — EC, U.S., U.K.,
Japan, Hong Kong, Switzerland; imports — EC, U.S.,
U.K., Switzerland, Japan
Budget: FY ending 31 March 76—$9.4 billion
(converted at 6.0 Israeli pounds = US$1)
Monetary conversion rate: $6.864 Israeli pounds =
US$1; par value protected by a system of export
subsidies and import duties and by legal restrictions
on conversion
Fiscal year: 1 April - 31 March','2374a9231cb83f0190823bdee0cc46395b92af1728f7aeada09a66bcd60f5e3f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('492b95285b93a792f5d383aa7855d6e1fe47df241778af6ca8422e7a2a83b8bf',1976,'IT','Italy','economy',265,'GDP: $150 billion (1974), $2,710 per capita;
66.9% private consumption, 25.2% gross private
104
investment, 14.0% government, net foreign balance
— 6.195; 1973 growth rate 6.3%, 1974 growth rate
3.4%, 1970 constant prices
Agriculture: important producer of fruits and
vegetables; main crops — cereals, potatoes, olives;
95% self-sufficient; food shortages — fats, meat, fish,
und eggs; caloric intake, 3,100 calories per capita
(1970)
Fishing: catch 462,000 metric tons (1973), $336
million (1973); exports $29 million (1973), imports
$252 million (1973)
Major industries: machinery and transportation
equipment, iron and steel, chemicals, food processing,
textiles
Shortages: coal, fuels, minerals
Crude steel: 23.8 million metric tons produced
(1974), 431 kilograms per capita
Electric power: 40,000,000 kw. capacity (1974);
147.0 billion kw.-hr. produced (1974), 2,350 kw.-hr.
per capita
Exports: $30.3 billion (£o.b., 1974); principal items
— machinery and transport. equipment, textiles,
foodstuffs, chemicals, footwear
Imports: $40.9 billion (c.i.f., 1974); principal items
— machinery and transport equipment, foodstuffs,
ferrous and nonferrous metals, wool, cotton,
petroleum
Major trade partners: (1974) 43.6% EC-nine
(18% West Germany, 13% France, 4% Netherlands,
4% U.K., 3% Belgium-Luxembourg); 8% U.S.; 2%
U.S.S.R. and 3% other Communist countries of
Eastern Europe
Aid: economic — U.S., $4,154 million (FY46-73),
$78.2 million authorized FY73; IBRD, $398 million
authorized through FY73, none since FY65;
International Finance Corporation, $1 million
authorized through FY72, none since FY60; military
—U.S., $2,402 million (FY46-73), $11.6 million
authorized in FY73
Monetary conversion rate: Smithsonian rate as of
December 1973, 650.4 lira - US$1; average of Friday
closing rates in 1975 to September—645 lira = US$1
Fiscal year: calendar year
GDP: $3.7 billion (1974), $700 per capita; average
annual growth rate in constant prices, 7.0%
Agriculture: commercial — coffee, wood, cocoa,
bananas, pineapples, palm oil; food crops — corn,
millet, yams, rice; other commodities — cotton,
105
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
IVORY COAST/JAMAICA
rubber, tobacco, fish; self-sufficient in mest
foodstuffs, but rice, sugar, and meat imported
Fishing: catch 72,400 metric tons (1972); $15.6
inillion, exports $2.6 million (1970), imports $5.2
million (1971)
Major industries: food and lumber processing. oil
refinery, automobile assembly plant, textiles, soap,
flour mill, matches, three small shipyards, fertilizer
plant, and battery factory
Electric power: 371,000 kw. capacity (1974); 788
million kw.-hr. produced (1974), 163 kw.-hr. per
capita
Exports: 81.2 billion (f.o.b., 1974); coffee, tropical
woods, cocoa, 70% of total; bananas, pineapples,
palm oil
Imports: $976 million (c.i.f, 1974); consumer
goods about 40%, raw materials and fuels 10%,
manufactured goods and semi-finished products,
about 50%
Major trade partners: France and other EC
countries about 65%, U.S. 18%, Communist countries
about 1%
Aid: economic — France (1960-69) $312 million;
EC $149 million, through FY1978; U.S. (FY61-73),
$114 million; others (1960-71), $76 million, including
$18.5 million committed; no Communist aid
programs; military — non-Communist countries, $7.3
million (1954-67)
Budget: 1975 est.—revenues $580 million, current
expenditures $454 million, investment expenditures
$247 million
Monetary conversion rate: about 218.75 Com-
munaute Financiere Africaine francs=US$1, August
1975; floating since February 1973
Fiscal year: calendar year','d0d2645ddff6381eab86fd03c27336057d019cf4d2488658ae427fea90d4d371','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bb62784a8d6dbe888342c166a6f76aba039c778422317550ba9660582f35491',1976,'JM','Jamaica','economy',269,'GNP: $2,383 million (1974), $1,150 per capita;
real growth rate 1974, 4.3%
Agriculture: main crops — sugarcane, citrus fruits,
bananas, pimento, coconuts, coffee, cocoa
Major industries: bauxite mining, textiles, food
processing, light manufactures, tourism
Electric power: 575,000 kw. capacity (1974);
2.1 billion kw.-hr. produced (1974), 1,040 kw.-hr. per
capita
Exports: $694 million (fo.b., 1974); alumina,
bauxite, sugar, bananas, citrus fruits and fruit
products, rum, cocoa
Approved For Release 2005/04/22
Imports: $963 million (c.i.f., 1974); machinery,
transportation and electrical equipment, food, fuels,
fertilizer
Major trade partners: exports — U.S. 48%, U.K.
16%, Canada 4.5%, Norway 11%; imports — U.S.
37%, U.K. 19%, Canada 7% (1974)
Aid: economic — from U.S. (FY56-73), $90 million
in loans; $51 million grants: from international
organizations (FY46-73), $113 million, from other
Western countries (1960-71), $90.2 million; military
— assistance from U.S. (FY63-73) $1.1 million
Budget: FY74-75, prelim.—revenues $658 million,
expenditures $798 million
Monetary conversion rate: 1 Jamaican dol-
lar- US$1.10
Fiscal year: 1 April - 31 March','e52bc6d4ba5a08bdea73905870a5640e0b9d435218d088c2973c4a8851b2d551','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4318d25ce75121ff1aad41074206ca69a7c4288e41a62aa6a1c9ab0407f92b3',1976,'JP','Japan','economy',273,'GNP: $451 billion (1974 at 292 yen=US$1;
$373 billion in 1973 prices); $4,100 per capita (1974);
52% personal consumption, 38% investment, 9%
government current expenditure; real growth rate
—2% (1974); average annual growth rate 1970-74,
7.0%
Agriculture: land intensively cultivated — rice,
wheat, barley, sugar, potatocs, fruits; 7195 self-
sufficient; food shortages — meat, wheat, feed grains,
edible oil and fats; caloric intake, 2,526 calories per
day per capita- (1973 est.)
Fishing: catch 10.7 million metric tons (1973)
Major industries: metallurgical and engineering
industries, electrical and electronic industries, textiles,
chemicals
Shortages: fossil fuels, most industrial raw materials
Crude steel: 117 million metric tons produced
(1974)
Electric power: 103,140,000 kw. capacity (1974);
460.7 billion kw.-hr. produced (1974), 4,203 kw.-hr.
per capita
Exports: $54.5 billion (f.0.b., 1974); machinery and
equipment 4796, metals and metal products 25%,
textiles 7% (79%)
Imports: $53.0 billion (f.0.b., 1974); fossil fuels
47%, metals and metal products 15%, foodstuffs 15%,
machinery and equipment 8%
Major trade partners: exports—23% U.S., 11%
EC, 8% Communist counties, 10% OPEC, 13% Far
East; imports—24% U.S., 7% EC, 6% Far East, 7%
Communist countries, 38% OPEC, 6% Australia
Aid: Japanese official foreign economic aid
disbursements 1973—$1,011 million
Monetary conversion rate: 2915 yen- US$]
(1974 average rate), floating since February 1973
Fiscal year: 1 April - 31 March
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
JAPAN/JORDAN','fb1cf9c0ab63b2ed458f017ef4d6b3ae0d88370000a0b217005cff7eb88ab39a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71061622cd6e1b28b5a44a8f9e604815baf1e5a5e2824568ae970ae6c88ce9a3',1976,'JO','Jordan','economy',277,'GNP: $850 million (1974 est.), $328 per capita
Agriculture: main crops — wheat, fruits,
vegetables, olive oil; not self-sufficient. in many
foodstuffs
Major industries: phosphate mining, petroleum
refining, and cement production
Electric power: 110,000 kw. capacity (1974); 180
million kw.-hr. produced (1974), 68 kw.-hr. per
capita, East Bank only
Exports: $157 million (£.o.b., 1974); fruits and
vegetables, phosphate rock; Communist share 2% of
total (1978)
Imports: $495 million (c.if, 1974); petroleum
products, textiles, capital goods, motor vehicles,
foodstuffs; Communist share 7*5 of total (1973)
Aid: economic — U.S., $813 million economic
assistance (FY49-74), of which $57 million loans, $756
million grants; military — $277 million total from
U.S. (FY49-74) including $195 million in MAP grants
Budget: 1974 Est. — expenditures $552 million
(uon-military $234 million, military $167 million,
development $151 million); deficit $66 million
Monetary conversion rate: 1 Jordanian dinar=
US$3.05, freely convertible; 0.3279 Jordanian dinar=
US$1
Fiscal year: calendar year','2d39dc22787d786fad6d330afe8bf0b687829f9a8bfc4d591f115a86a4a85651','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2faa93992dde40ecf2fe07fca0620651ab73c4d0f1f08a3dc92209cef417be78',1976,'KE','Kenya','economy',281,'GDP: $2,338 million at current prices (1974), $180
per capita; 3.6% real growth
Agriculture: main cash crops — coffec, sisal, tea,
pyrethrum, cotton, livestock; food crops — corn,
wheat, rice, cassava; largely self-sufficient in food
Fishing: $4.2 million (1970)
Major industries: small-scale consumer goods
(plastic, furniture, batteries, textiles, soap, agricultural
processing, cigarettes, flour), oil refining, cement
Electric power: 250,000 kw. capacity (1974);
814 million kw.-hr. produced (1974), 68 kw.-hr. per
capita
Exports: $611 million (f.o.b., 1974); coffee, tea,
livestock products, pyrethrum, soda ash, wattle-bark
tanning extract
Imports: $1,025 million (c.i.f., 1974); machinery,
transport equipment, crude oil, paper and paper
products, iron and steel products, and textiles
Major trade partners: U.K. and EC, also Uganda
and Tanzania, which are part of East African
Economic Community
Budget: FY76 current revenues $1,009 million;
current. expenditures $1,057 million; development
expenditures $193 million
Approved For Release 2005/04/22 :
Monetary conversion rate: 7.143 Kenya shil-
lings = US$1
Fiscal year: 1 July - 30 June
GNP: $7 billion (1974 est.), $440 per capita
Agriculture: main crops — rice, corn, vegetables;
food shortages — meat, cooking oils; production of
foodstuffs adequate for domestic needs at low levels of
corsumption
Major industries: machine building, electric
power, chemicals, mining, metallurgy, textiles, food
processing
Shortages: complex machinery and equipment,
bituminous and coking coal, petroleum, rubber
Crude steel: 3.4 million metric tons produced
(1974), 210 kilograms per capita
112
Approved For Release 2005/04/22 :
Electric power: 3,350,000 kw. capacity (1974); 19
billion kw.-hr. produced (1974), 1,188 kw.-hr. per
capita
Exports: $685 million; minerals, chemical and
metallurgical products (1974)
Imports: $1,260 million; machinery and equip-
ment, petroleum, foodstuffs, coking coal (1974)
Major trade partners: total trade turnover
$1.9 billion; 52% with non-Communist countries,
48% with Communist countries
Aid: economic and military aid from the U.S.S.R.
and China
Monetary conversion rate:
(arbitrarily established)
Fiscal year: calendar year
GNP: $13.4 billion (1974 in 1973 prices); real
growth 8.6% (1974); real growth 9.8% (1970-74
average)
Agriculture: 4596 of the population live on the
land, but agriculture, forestry and fishery constitute
26% of GNP; main crops — rice, barley, wheat; not
self-sufficient; food shortages — barley, wheat, dairy
products, rice, corn
Fishing: catch 2,026,000 metric tons (1974)
Major industries: textiles and clothing, food
processing, chemical fertilizers, chemicals, plywood,
steel
Shortages: base metals, fertilizer, petroleum,
lumber and certain food grains
Electric power: 4,860,000 kw. capacity (1974);
11.8 billion kw.-hr. produced (1974), 517 kw.-hr. per
capita
Exports: $4.5 billion (f.o.b. 1974); clothing,
electrical. machinery, plywood, footwear, processed
food
Imports: $6.9 billion (eif., 1974); oil, ships, steel,
wood, wheat, organic chemicals
Major trade partners: exports — U.S. 34%, Japan
31%; imports—Japan 38%, U.S. 25% (1974)
Aid: economic — U.S. (FY46-74), $6.1 billion
committed; Japan (1965-73), 1.8 billion extended;
military — U.S. (FY46-74), $6.2 billion committed
Budget: $2.5 billion (1974)
Monetary conversion rate: rate fixed at 484
won=US$1 since December 1974
Fiscal year: calendar year','fa54643b49d1862b83f6df35a3cf96837ae936323531efa6e167c8cda236c448','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e9ab4839bff8e694ac0ded93390588d6cdde996ccdca814b42179005fc4ec79',1976,'KW','Kuwait','economy',285,'GNP: $9.6 billion (1974 est.). $10,060 per capita
est.
Agriculture: virtually none, dependent on imports
for food; approx. 75% of potable water must be
distilled or imported
Major industries: crude petroleum production
averaging 2.2 million b/d (includes Kuwait''s share of
neutral zone) (1975 est.): government revenues from
taxes and royalties on production, refining, and
consumption $7.3 billion est. for 1974; refinery
capacity 504,000 b/d est (1970) other major
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
KUWAIT/LAOS
industries include fishing, processing of building
materials, fertilizers, chemicals, and flour
Electrie power: 1,070,000 kw. capacity (1974);
4.1 billion kw.-hr. produced (1974), 4,295 kw.-hr. per
capita
Exports: $10,741 million (£o.b., 1974 prelim.), of
which petroleum accounted for about 98%;
nonpetroleum exports are mostly reexports, $137
million (f.o.b., FY71-72)
Imports: $1,550 million (cif, 1974 prelim.)
exclusive of oil company imports; major suppliers —
U.S., Japan, U.K., West Germany
Aid: an aid donor, committed bilaterally or through
multilateral agencies over $2 billion in economic
assistance in 1974 alone; amount equal to previous
total extensions of grants and loans during 1961-72
time period
Budget: (FY75/76) 83.075 billion revenues
Monetary conversion rate: 1 Kuwaiti dinar=
US$3.38 (October 1973)
Fiscal year: 1 April - 31 March
GNP: $220 million, $70 per capita (1972 est.)
Agriculture: main crops — rice (overwhelmingly
dominant), corn, vegetables; largely self-sufficient;
food shortages (due in part to distribution
deficiencies) including rice
Major industries: tin mining, timber, tobacco
Shortages: capital equipment, petroleum, transpor-
tation system
Electric power: 54,500 kw. capacity (1974);
240,000 kw.-hr. produced (1974), 78 kw.-hr. per
capita
Exports: $9.7 million (£o.b.. 1973 est.); forest
products, tin concentrates; coffee, undeclared exports
of opium and tobacco
Imports: $62 million (c.f, 1973 est.); rice and
other foodstuffs, petroleum products, machinery,
transportation equipment
Major trade partners: imports from Thailand,
Japan, U.S., France, U.K., Hong Kong; exports to
Malaysia and Thailand; trade with Communist
countries insignificant; Laos a major transit point in
world gold trade; value of 1973 gold re-exports $55
million
Budget: (1973-74) receipts, 13.3 billion kip;
expenditures, 36.0 billion kip; deficit 22.7 billion kip
(provisional totals); 45% military, 55% civilian
Monetary conversion rate: 750 kip - USS1 (official
rate); 1,200 kip=US$1 for most import transactions;
free market rate of 1,500-3,000 kip=US$1 for
numerous market transactions
Fiscal year: 1 July - 30 June','bae891100118da38e1cb5924e909d7a7daf896c7faf64c6ddf7318ec02c1d16c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('357186a9304db5d84532cb66613720af59bc0b2aa6e5383567e1a1720b05987f',1976,'LB','Lebanon','economy',289,'Agriculture: fruits, wheat, corn, barley, potatoes,
tobacco, olives, onions; not self-sufficient in food
Major industries: service industries, food
processing, textiles, cement, oil refining, chemicals,
some metal fabricating, tourism
Electric power: 818,000 kw. capacity (1974); 2.0
billion kw.-hr. produced (1974), 830 kw.-hr. per
capita
Major trade partners: exports $1 billion est. (£o.b.,
1974); most to Arab countries; imports $1.7 billion
(cif, 1974); chiefly from EC, U.K., and Arab
countries; trade deficit covered by large net receipts
from invisibles (particularly tourism and transporta-
tion) and private capital inflow
Budget: (1975) expenditures $863 million, current
expenditures $758 million, investment expenditures
$105 million
Monetary conversion rate: 1 Lebanese pound=
US$0.44 as of August 1975
Fiscal year: calendar year','3d635a4e7dc5c0a0b7bb6a61eff797837ca09d25afbe3f0e5f1358380cf4d078','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5137006be3477c70d8704881040313b0c15709a3e0f1f4f13b661e4a4ab903e7',1976,'LS','Lesotho','economy',293,'GNP: $80 million (FY71 est) $80 per capita;
growth rate (in current prices), 6% annually (FY67-71
est.)
Agriculture: exceedingly primitive, mostly
subsistence farming and livestock; principal crops are
corn, wheat, pulses, sorghum, barley
Major industries: none
Electric power: 2,820 kw. capacity (1974); 6
million kw.-hr. produced (1974), 6 kw.-hr. per capita
Exports: labor to South Africa (remittances $11
million est. in FY72); $6 million (f.0.b., FY73), wool,
mohair, wheat, cattle, diamonds, peas, beans, corn,
hides, skins
Imports: $55 million (f.o.b., FY73); mainly corn,
building materials, clothing, vehicles, machinery,
POL
Major trade partner: South Africa
Aid: economic aid; U.K. 89.4 million (plan FY71-
75), other $17.5 million (plan FY71-75); U.S, 815.4
million authorized (FY61-73); no military aid
Budget: (FY76) revenues— $63. million, expendi-
tures—current $38 million, development—$25
million
Monetary conversion rate: Lesotho uses the South
African rand; 1 SA rand =US$1.15 (as of November
1975)
Fiscal year: 1 April - 31 March','ccf013242331fdf09102794188bf830092f8643b45032fc92d3069119dad6eae','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1f6f7e64bf71f0fec5c03e540ebf9aa4d3b2262608e2bd872fae5d599c18e04',1976,'LR','Liberia','economy',297,'CDP: $574 million (1974), $290 per capita; 1096
current annual growth rate
Agriculture: rubber, rice, oil palm, cassava, coffee,
cocoa; imports of rice, wheat, and live cattle and beef
are necessary for basic diet
Fishing: catch 15,500 metric tons, $6.5 million
(1974)
Industry: rubber processing, food processing,
construction materials, furniture, palm oil processing,
mining (iron ore, diamonds), 10,000 b/d oil refinery
Electric power: 225,000 kw. capacity (1974); 600
million kw.-hr. produced (1974), 345 kw.-hr. per
capita
Exports: $400 million (f.0.b., 1974) iron ore,
rubber, diamonds, lumber and logs, coffee, cocoa
Imports: $290 million (c.if., 1974); machinery,
transportation equipment, petroleum products,
manufactured goods, foodstuffs
119
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LIBERIA/LIBYA
Major trade partners: U.S., West Germany,
Netherlands, Italy, Belgium
Aid: economic — (FY46-75) U.S., $230 million;
military — (FY53-74) U.S., $11.7 million; other aid
sources include IBRD, U.N.. IMF, West Germany,
Republic of China
Budget: (FY74) expenditures and revenues $108
million, development budget, $14.2 million
Monetary conversion rate: Liberia uses U.S.
currency
Fiscal year: calendar year','9d9036a74dbb023c3ad80a763c8442936e5e082d49030882b5c0f3c37b8a9dea','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86893c99e50a7c173516159bcd3735727c72080cc6666c49956b9c617d47010c',1976,'LY','Libya','economy',301,'GDP: $6.5 billion (1973), $3,010 per capita
Agriculture: main crops — wheat, barley, olives,
dates, citrus fruits, peanuts; not self-sufficient in food
Major industries: petroleum production averaged
1.5 million b/d (1974); food processing, textiles,
handicrafts
Electric power: 280,000 kw. capacity (1974); 696
million kw.-hr. produced (1974), 305 kw.-hr. per
capita
Exports: $3,858 million (1973); over 99%
petroleum
Imports: $1,723 million (1972, c.i.f.)
Major trade partners: imports — Italy, West
Germany, U.$.; exports — Italy, West Germany,
U.K., France
Aid: economic — no Communist country
assistance; U.S. aid extended $212.5 million (FY49-
73); military — arms obtained by cash purchase; chief
suppliers France, U.S.S.R., Czechoslovakia; U.S.
suspended since September 1969
Monetary conversion rate: 1 Libyan pounds
US$3.38
Fiscal year: 1 January - 31 December (beginning
1974); formerly 1 April - 31 March','a9f747f4756a1207014f19c36b0d21463fea0f1b0a07b88cf55e1f1389ab07bb','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5f3bb09317bc6178dd2c3192a31388e19dc7d19c33168c57be96c0288c63d40',1976,'LI','Liechtenstein','economy',305,'Despite its small size and sparse natural resources,
Liechtenstein has a prosperous economy based
primarily on small-scale light industry and farming.
Textiles, ceramics, precision instruments, phar-
maceuticals, and canned foods are the principal
manufactures produced, almost entirely for export.
Livestock raising and dairying are the main sources of
farm income; cereals and potatoes are the most
important farm crops. The Liechtenstein economy is
tied closely to that of Switzerland in a virtual customs
union. No national accounts data are available.
Major trade partners: exports (1972) — $138.6
million; 34% Switzerland, 35% EC, 48% EFTA
Electric power: 22,600 kw. capacity (1974); 55
million. kw.-hr. produced (1974), 1,800 kw.-hr. per
capita; power is exchanged with Switzerland, but net
exports average 35 million kw.-hr. yearly','f26d1e6c9975c4d79604de884de9eab8b829ec8440e9b05d8e2091dff277e973','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63265778e94b149b60ae7f50018987b91c9b6585b04f8c067bec440ca1a29074',1976,'LU','Luxembourg','economy',310,'GNP: $1,693 million (1974, in 1973 prices), $4,810
per capita; 1974 growth rate 5.5% at constant prices;
5396 consumption, 27% investment, 11% government,
996 net exports of goods and services (1973)
Agriculture: mixed farming; main crops — grains,
potatoes, fodder beets; food shortages — sugar, bread
grains, fats; caloric intake, 3,150 calories per day per
capita (1968-69)
Major industries: iron and steel, food processing,
chemicals, metal products and engineering, tires
Crude steel: 6.4 million metric tons produced
(1973), 18,630 kg. per capita
Electric power: 1,204,000 kw. capacity (1974); 2
billion kw.-hr. produced (1974), 6,900 kw.-hr. per
capita
Exports: $1,493 million (f.o.b., 1973)
Imports: $1,329 million (c.i.f., 1973)
Major trade partners: Luxembourg and Belgium
form an economic and customs union and report their
foreign trade jointly (see Belgium); Luxembourg''s
principal exports are iron and steel products; principal
imports are coal and consumer products; most foreign
trade is with Germany, Belgium, and other EC
countries
Aid: foreign aid to Luxembourg is included in aid
to Belgium
Budget (projected): (1975) expenditures $650
million, revenues $659 million, surplus $9 million
Monetary conversion rate: 1974 average |
franc = US$$0.0257 floating; under the BLEU
agreement, the Luxembourg franc is equal to the
Belgian frane which circulates freely in Luxembourg
Fiscal year: calendar year','c5f975aaf034e8f0ddfd945a376b9c2c0f40d6eeabe5cc0bb45535bf5d1991b9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b42c5841817bdcd976c576bb7619e9780f2cc4d6b1337c324f44f734d3b6c8a4',1976,'PH','Philippines','economy',315,'Agriculture: main crops — rice, vegetables; food
shortages — rice, vegetables, meat; depends mostly on
imports for food requirements
Major industries: textiles, fireworks
Electric power: 73,500 kw. capacity (1974); 175
million. kw.-hr. produced (1974), 700 kw.-hr. per
capita
Exports: $108 million (f.o.b., 1974); textiles and
clothing, foodstuffs, fireworks
Imports: $127 million (c.i.f., 1974)
Major trade partners: exports — Portuguese
colonies 20%, West Germany 16%, Hong Kong 1856;
imports — Hong Kong 67%, China 26% (1974)
Monetary conversion rate: 5.35 patacas=US$1
(December 1975)
Fiscal year: calendar year
GNP: $14.0 billion (1974), $340 per capita, 5.8%
real growth, 1974
Agriculture: main crops — rice, corn, coconut,
sugarcane, bananas, abaca, tobacco
Fishing: catch 1.3 million metric tons (1974)
Major industries: agricultural processing, textiles,
chemicals and chemical products
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
mp ecd
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PHILIPPINES/POLAND
Electric power: 2,993,000 kw. capacity (1974);
11.9 billion kw.-hr. produced (1974), 287 kw.-hr. per
capita
Exports: $2,625 million (Lo.b. 1974); sugar,
coconut products, logs and lumber, copper
concentrates, abaca
Imports: $3,140 million (f.o.b., 1974); petroleum,
industrial equipment, grains
Major trade partners: (1974) exports—42% U.S.,
35% Japan; imports—28% Japan, 23% U.S.
Aid: economic — U.S. (FY46-74), $2.1 billion
committed; Japan (CY70-74), $266 million commit-
ted; IBRD/IDA (CY66-74), $466 committed; military
— U.S. (FY46-74), $735 million committed
Budget; (FY75) revenues $2.1 billion, expenditures
$2.5 billion, deficit $0.4 billion; 11% military, 84%
civilian
Monetary conversion rate: 7.5 pesos=US$l,
August 1975
Fiscal year: 1 July - 30 June','7e447585ef84bd04bccfe0342db4c45fa7c333be0fd802b25cf44806d1ea8bd5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62f0f896ee9f1c003d2330ccc0a3df86188351bff3b25bde2f33f949a4a86e52',1976,'MG','Madagascar','economy',319,'GDP: $1.4 billion (1974), about $200 per capita; an
increase of about 7.0% annually since 1971
Agriculture: cash crops — coffee, vanilla, sugar,
tobacco, sisal, rice, cloves, raphia; food crops — rice,
cassava, cereals, potatoes, corn, beans, bananas,
coconuts, and peanuts; animal husbandry wide-
spread; self-sufficient in foodstuffs, but some milk and
cereals imported
Fishing: catch 49,000 metric tons (1972); exports
$4.4 million (1971), imports $800,000 (1971)
Major industries: agricultural processing (meat
canneries, soap factories, brewery, tanneries, sugar
refining), light consumer goods industries (textiles,
glasswarc), cement plant, auto assembly plant, paper
mill, oil refinery
Electric power: 90,000 kw. capacity (1974); 240
million kw.-hr. produced (1974), 30 kw.-hr. per capita
125
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MADAGASCAR/MALAWI
Exports: $226 million (f.o.b., 1974); coffee 30%,
rice 1%, vanilla 5%, sugar 4%; agricultural and
livestock products account for about 85% of export
carnings
Imports: $291 million (cif, 1974); consumer
goods about 30%, foodstuffs 15%, primary products
(crude oil, fertilizers, metal products) 25%, capital
goods 28% (1971)
Major trade partners: France (in 1971 accounted
for 34% of exports and 56% of imports); U.S.,
preferential tariffs to EC and franc zone countries;
trade with Communist countries remains a minute
part of total trade
Budget: (FY75) revenues $450 million (including
$78 million projected borrowing), expenditures $450
million of which $324 million current, $126 million
development
Monetary conversion rate: 219.98 Malagasy
francs=US$1 as of August 1975 (floating since
February 1973); member of French frane zone
Fiscal year: calendar year','c4ca3ab95515df903c81fb648f847e2e49eff4d332dcc5ac263a87ae69443d3b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e876cbd89e21bfccb1a708feaad67e5bdcbc86ad0dad1829d42de8ca69022d1c',1976,'MW','Malawi','economy',323,'GDP: $641 million (1974 current prices), $110 per
capita; real growth rate 6.5% (1972-74)
Agriculture: cash crops — tea, tobacco, peanuts,
cotton, tung; subsistence crops — corn, sorghum,
millet, pulses, root crops, fruit, vegetables, rice
Electric power: 88,000 kw. capacity (1974); 216
million kw.-hr. produced (1974); 46 kw.-hr. per capita
Major industries: agricultural processing (tea,
tobacco, sugar), sawmilling, cement, consumer goods
Exports: $122 million (Lo.b., 1974); tobacco, tea,
groundnuts, sugar, maize, rice, cotton
Imports: $185 million (c.i.f., 1974); manufactured
goods, machinery and transport equipment, building
and construction materials, food, fuels, fertilizer
Major trade partners: exports — U.K., other EEC,
Rhodesia, South Africa; imports — South Africa,
U.K., Rhodesia, other EEC
Aid: economic — U.K. provides major develop-
ment support, about $144 million (1964-74); U.S. aid
commitments, $50 million (FY56-74), military —
U.K., $2.4 million (1954-68)
Budget: (FY75) $123 million
Monetary conversion rate: | Malawi Kwacha=
US$1.20
Fiscal year: 1 April - 31 March','bcd75072aaf06bcb8c59d22cd303f0a3c93100d3dcb4245f2dea4d52dd96cb74','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('568ed7bf651133a1ea970a47a6d6d3c61e0dd2a7edd41ba4edb6ae5020d28ab2',1976,'MY','Malaysia','economy',327,'GNP:
Malaysia: $8.7 billion (1974), $715 per capita;
average annual real growth 6.4% (1968-74), 6%
(1974)
Agriculture:
Peninsular Malaysia: natural rubber, rice, oil
palm; 10%-15% of rice requirements imported
Sabah: mainly subsistence; main crops — rubber,
timber, coconut, rice; food deficit — rice
Sarawak: main crops — rubber, timber, pepper;
food deficit — rice
Fishing: catch 359,000 metric tons, $151 million
(1972)
Major industries:
Peninsular Malaysia: rubber and oil palm
processing and manufacturing, light manufacturing
industry, tin mining and smelting, logging and
processing timber
Sabah: logging, petroleum production
Sarawak: agriculture processing, petroleum
production and refining, logging
Electric power:
Peninsular Malaysia: 1,075,000 kw. capacity
(1974); 5 billion kw.-hr. produced (1974), 515 kw.-hr.
per capita
Sabah: 75,000 kw. capacity (1974); 190 million
kw.-hr. produced (1974); 252 kw.-hr. per capita
Sarawak: 63,000 kw. capacity (1974); 174 million
kw.-hr. produced (1974), 158 kw.-hr. per capita
Exports: $5 billion (f.o.b., 1974); natural rubber,
palm oil, tin, timber, petroleum
Imports: $4.4 billion (c.i.f., 1974)
Major trade partners: exports—22% Singapore,
18% Japan, 12% U.S.; imports — 24% Japan, 10%
U.K., 8% Singapore, 8% U.S.
Aid: economic — U.K. (1946-69) $260 million
disbursed; Japan (1966-68) $50 million extended;
IBRD (1959 - July 1974) $500 million (committed);
U.S. (1954-74) $118 million; military — (FY62-74)
$59 million committed
Budget: 1975 revenues $2.1 billion; expenditures
$3.0 billion; deficit $900 million; 16% military, 84%
civilian
Monetary conversion rate: (Malaysia) 2.5
Malaysian dollars=US$1 (August 1975)
Fiscal year: calendar year','4f5f46064cd9404859a1cebb1ceabd3c2b84a36e15324d27c9b42c877de2138d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a06597bbdb7cf3ea2d47c12f174af7caa878b23ff2495d1c8ec6e551078ee687',1976,'MV','Maldives','economy',331,'GNP: under $100 per capita
Agriculture: crops — coconut and millet; shortages
— rice, wheat
Fishing: catch 69,200 metric tons (1972)
Major industries: fishing; some coconut processing
Electric power: 2,500 kw. capacity (1974); 9
million kw.-hr. produced (1974), 76 kw.-hr. per capita
Exports: $2.4 million (f.0.b., 1968); fish
Imports: $2 million (c.i.f., 1968)
Major trade partner: Sri Lanka
Aid: U.K. (1960-65), $1.4 million drawn; Sri Lanka
(1967), $1 million committed
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MALDIVES/MALI
Monetary conversion rate: 6.39 rupees = US$1
Fiscal year: calendar year','7a99b9a99cd5c1abb8e70583d5d16b8de1098558f7ce0602a5150a2ffc2cf000','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f31964bf03c3caf461365ef9e2b531ef7a421c76c4673abd02b6d33305035bd4',1976,'ML','Mali','economy',335,'GDP: about $457 million (1974), $83 per capita;
annual real growth rate negative since 1972
Agriculture: main crops — millet, sorghum, rice,
corn, peanuts; cash crops — peanuts, cotton, livestock
Fishing: catch 90,000 metric tons (1971) exports
$670,000 (1971)
Major industries: sinall local consumer goods and
processing
Electric power: 27,000 kw. capacity (1974); 60
million kw.-hr. produced (1974), 10 kw.-hr. per capita
Exports: $60 million (f.0.b., 1974); livestock,
peanuts, dried fish, cotton, skins
Imports: $183 million (cif, 1974); textiles,
vehicles, petroleum products, machinery, and sugar
Major trade partners: mostly with franc zone and
Western Europe; also with U.S.S.R., China
131
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MALI/MALTA
Budget: 1974 est. — receipts $54 million, current
expenditures $69 million
Monetary conversion rate: 439.96 Mali francs=
US$1, August 1975
Fiscal year: calendar year
GNP: $395 million (1974), $1,240 per capita; 69%
private consumption, 24% gross investment
Agriculture: overall, 20% self-sufficient; adequate
supplies of vegetables, poultry, milk and pork
132
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MALTA/MARTINIQUE
products; shortages in beef, grain, animal fodder, and
fruits at various seasons; main products — potatoes,
cauliflowers, grapes, wheat, barley, tomatoes, citrus,
cut flowers, green peppers, hogs, poultry, eggs; 2,680
calories per day per capita
Major industries: ship repair yard, building
industry, food manufacturing, textiles, tourism
Shortages: most consumer and industrial needs
(fuels and raw materials) must be imported
Electric power: 115,000 kw. capacity (1974); 312.0
million kw.-hr. produced (1974), 920 kw.-hr. per
capita
Exports: $134 million (£.o.b., 1974); textiles, scrap
metal, wine, agricultural products, and footwear
Imports: $360 million (c.i.£., 1974)
Major trade partners: EC-nine 65% (U.K. 25%,
Italy 15%); U.S. 5%; Communist countries 5% (1974)
Aid: economic — U.S., $84 million (FY49-73),
$10.5 million in 1972, and $14.9 million in 1978,
Agreement (loans and grants) (1964-74), $140 million;
U.N. Special Fund, $2.2 million through FY72; U.N.
Technical Assistance, $1.4 million through FY72,
China, $45 million (1972)
Monetary conversion rate: 1 Maltese pound=
US$2.67 (Smithsonian Agreement), December 1971;
the Maltese pound began floating in June 1972, with
the rate being determined between that of sterling and
that of the currencies of Maltas major trading
partners; average trade conversion factor, year 1974: 1
Maltese pound = US$2.59
Fiscal year: 1 April - 31 March','7b0a6543055812bafb5ccd9aceda97d17b0a5cb3889afaf064df089154bf5399','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45646126e20eb683393d05c165238c90da6cabb6f6e18be5d83483d853f91be7',1976,'MR','Mauritania','economy',340,'GDP; about $230 million (1972), average annual
increase in current prices about 5.0% (1968-72), about
$190 per capita
Agriculture: most Mauritanians are nomads or
subsistence farmers; main products — livestock,
livestock, small grains, dates; cash crop — gum
arabic; livestock
Fishing: catch, traditional river fishing, 15,000
metric tons (1969), traditional sea fishing, 2,750
metric tons (valued at $437,000); fish supplied to
processing plants by foreign fishing fleets from France,
Spain, Canary Islands using Mauritanian waters;
exports 22,100 metric tons, $8 million (1970)
Major industries: mining of iron ore, salt fishing,
exploitation of copper resources planned
Electric power: 38,600 kw. capacity (1974);
78 million kw.-hr. produced (1974), 70 kw.-hr. per
capita
Approved For Release 2005/04/22 :
Exports: $185 million (f.o.b., 1974); iron ore, fish,
gum arabic
Imports: $177 million (c.i.£, 1974); sugar, cloth,
iea, and fuels
Major trade partners: (trade figures not complete
because Mauritania has a form of customs union with
Senegal and much local trade unrcported) France and
other EC members, U.K., and U.S. are main overseas
partners
Budget: 1974 est. — receipts $67.9 million, current
expenditures $67.4 million, investment expenditures
$7.2 million
Monetary conversion rate: 41.33 Ouguyia - US$1
as of June 1975 (currency floating since February
1973) (official)
Fiscal year: calendar year','116f9c89afb41cf4cd5e40a07bf4efaebf40a1192c2a1b435c4ea130817c96be','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1bff6cf77dadf15434509ed14502f7002205510bd1d5374f3a877798a4a29bc',1976,'MU','Mauritius','economy',344,'GNP: $370 million est. (1974), $420 per capita
Agriculture: sugar crop is major economic asset;
about 40% of land area is planted to sugar; tea
production rising slowly; most food imported — rice is
the staple food — and since cultivation is already
intense and expansion of cultivable areas is unlikely,
heavy reliance on food imports except sugar and tea
will continue
Shortage: land
Industries: mainly confined to processing
sugarcane, tea; some small-scale, simple manufac-
tures; tobacco fiber; some fishing; tourism, diamond
cutting, weaving and textiles, electronics
Electric power: 73,800 kw. capacity (1974); 204
million kw.-hr. produced (1974), 281 kw.hr. per
capita
Exports: $312 million (f.o.b., 1974); mainly sugar,
tea, molasses
Imports: $309 million (c.i.f., 1974); foodstuffs 30%,
manufactured goods about 25%
Major trade partners: all EC-nine countries and
U.S. have preferential treatment, U.K. buys over 50%
of Mauritius sugar export at heavily subsidized
prices; small amount of sugar exported to Canada,
U.S., and Italy; imports from U.K. and EC primarily,
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
usi 1 RI —
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MAURITIUS/MEXICO
also from South Africa, Australia, and Burma; some
minor trade with China
Budget: revenues $172 million, current ex-
penditures $168 million, investment expenditure $65
million (1976) y
Monetary conversion rate: 6.32 Mauritian
rupees- US$1 in August 1975 (floating with pound
sterling)
Fiscal year; 1 July - 30 June
Agriculture: cash crops — almost entirely
sugarcane, small amounts of vanilla and perfume
plants; food crops — tropical fruit and vegetables,
manioc, bananas, corn, market garden produce, also
some tea, tobacco, and coffee; food crop inadequate,
most food needs imported
Major industries: 12 sugar processing mills, rum
distilling plants, cigarette factory, 2 tea plants, fruit
juice plant, canning factory, a slaughterhouse, and a
number of small shops producing handicraft items
Electric power: 54,400 kw. capacity (1974); 168
million kw.-hr. produced (1974), 344 kw.-hr. per
capita
Exports: $72 million (f.o.b., 1974); 90% sugar, 496
perfume essences, 5% rum and molasses, 1% vanilla
and tea
Imports: $352 million (c.i.f., 1974); manufactured
goods, food, beverages, and tobacco, machinery and
transportation. equipment, raw materials and
petroleum products
Major trade partners: France (in 1970 supplied
62% of Reunions imports, purchased 76% of its
exports); Mauritius (supplied 12% of imports)
Monetary conversion rate: about 216 Com-
munaute Financiere Africaine francs=US$1 as of
January 1975 (floating since February 1973)
Fiscal year: probably calendar year
GDP: $3.0 billion (1974), $475 per capita; real
growth rate 10% (1975)
Agriculture: main crops — tobacco, corn, sugar,
cotton; livestock; self-sufficient in foodstuffs except
wheat
Major industries: mining and steel, textiles
Electric power: 1,323,000 kw. capacity (1974); 5.8
billion kw.-hr. produced (1974), 934 kw.-hr. per
capita
Exports: $652 million (f.o.b., 1973), including net
gold sales and reexports; tobacco, asbestos, copper,
meat, chrome, gold, nickel, clothing, sugar
172
Imports: $541 million (c.i.f., 1973); machinery,
petroleum products, wheat, transport equipment
Major trade partners: South Africa, Portugal, and
Portuguese territories
Aid: no substantial military or economic aid
Budget: FY1976—revenues $678 million, expendi-
tures $895 million, deficit $217 million
Monetary conversion rate: 1 Rhodesian dol-
lar US$1.54; 0.649 Rhodesian dollar = US$1
Fiscal year: 1 July - 30 June','ff3cd7e800add5115d3a10bce01a4fed407f2bd0a867a82b6cbc45c760dc82d5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08557ca44b026c0ad887a8d58b3403ddda142143b879d7913a8f865140507983',1976,'MX','Mexico','economy',347,'GDP: $64.8 billion (1974 est.), $1,120 per capita;
7096 private consumption, 9% public consumption,
21% domestic investment (1973 est.); real growth rate
1974, 6.0% est.
Agriculture; main crops — corn, cotton, wheat,
coffee, sugarcane, sorghum, oilseeds, pulses, and
vegetables; general self-sufficiency with minor
exceptions in meat and dairy products; caloric intake,
3,110 calories per day per capita (1968}
Fishing: catch 402,500 metric tons, $95.1 million
(1971); exports $61,060,000. imports $12,516,000
(1970)
Major industries: processing of food, beverages,
and tobacco; chemicals, basic metals and metal
products, petroleum products, mining, textiles and
clothing, and transport equipment
Crude steel: 5.2 million metric tons capacity
(1973); 5.1 million metric tons produced (1974); 90
kilograms per capita (1974)
Electric power: 9,000,000 kw, capacity (1974); 38
billion kw.-hr. produced (1974), 660 kw.-hr. per
capita
Exports: $2,804 million (fo.b., 1974); cotton,
coffee, nonferrous minerals (including lead and zinc),
sugar, shrimp, petroleum, sulfur, salt, cattle and meat,
fresh fruit and tomatoes
Imports: $6,219 million (c.i.f., 1974); machinery,
equipment, industrial vehicles, and intermediate
goods
Major trade partners; exports — U.S. 65%, EC
11%, Japan 4% (1974); imports—U.S. 65%, EC 16%,
Jupan 3%
Aid: economic — extensions from U.S. (FY46-73),
$1,228 million in loans; $164.2 million in grants: from
international organizations (FY46-73), $2,337 million;
from other Western countries (1960-66), $122.7
million; military — assistance from U.S. (FY46-72),
$14 million
Budget: 1974 est. federal, revenues $5,660 million,
expenditures $7,800 million
Monetary conversion rate:
(official)
Fiscal year: calendar year','65abf8ee5a19febc3ea2ef90514ed7b1f4d2a38cd73b05f2c30600a64bf13701','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dba9449a4df8037b4dce6b5b30c4900b3b7d3bf73c6872b6e5436d4c45c9cd26',1976,'MC','Monaco','economy',351,'GNP: 55% tourism; 2596-3076 industry (small and
primarily tourist oriented); 10975-1596 registration fees
and sales of postage stamps; about 4% traceable to the
Monte Carlo casino
Major industries: chemicals, food processing,
precision instruments, glassmaking, printing
Electric power: 8,000 kw. capacity (1974); 80
million kw.-hr. supplied by France (1974), 2,000 kw.-
hr. per capita
Trade: full customs integration with France, which
collects and rebates Monacan trade duties
Monetary conversion rate: 1 franc = US$0.2253','582db44cc47a254dee8832bddd052c23a8b58f7a188ee9d34f5a23eddd7263f4','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a806125dd09d709fbe3e8601b5b30f7d9498e6f978afd84b15373faf269cf30',1976,'MN','Mongolia','economy',355,'Agriculture; livestock raising predominates; main
crops — wheat, oats, barley
Industries: Processing of animal products: building
materials; mining
Electric power: 246,600 kw. capacity (1974): 740
million kw.-hr. produced (1974), 521 kw.-hr. per
capita
Exports: beef for slaughter meat products, wool,
fluorspar, other minerals
Imports: machinery. and equipment, petroleum,
clothing, building materials sugar, and tea
Major trade partners: nearly all trade with
Communist countries (approx. 80% with U.S.S.R.);
total turnover over $600 million (1974)
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 3.31 tugriks=US$1
(arbitrarily established)
Fiscal year: calendar year','2f1db15218d32bea5eb24643088faf92c13a590015ed261c176edb5ac15a6772','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bc15c4ced42e4c278fdabd6bf16bbf44309c235f42c533427ec187ea3f3720d',1976,'MA','Morocco','economy',359,'GNP: $6 billion (1975 est. in 1974 dollars), about
$350 per capita; average annual real growth 496
during 1970-78
Agriculture: cereal farming and livestock raising
predominate; main products — wheat, barley, citrus
fruit, wine, vegetables, olives; some fishing
Fishing: catch 246,000 metric tons, $21.0 million
(1972); exports $37.9 million (1971)
Major sectors: mining and mineral processing
(phosphates, smaller quantities of iron, manganese,
lead, zinc, and other minerals), food processing,
textiles, construction and tourism
Electric power: 745,000 kw. capacity (1974); 2.6
billion kw.-hr. produced (1974), 152 kw.-hr. per
capita
Exports: $1,706 million (f.0.b., 1974); phosphates
55%, agricultural goods 25%, other 20%
Imports: $1,914 million (f.o.b., 1974); raw material
and semi-finished goods 42%, food 24%, equipment
20%, consumer goods 14%
Major trade partners: exports — France 32%, West
Germany 8%, Italy 8%, Benelux 7%, U.K. 2%;
imports — France 31%, U.S. 8%, West Germany 7%,
Italy 6% (1972)
Monetary conversion rate: 4.15 dirhams=US$1
(trade rate in 1974)
Fiscal year: calendar year','01a453a514fa86da7996bb7cb41b37d4ad2d09b002437b422a58386c5c40511f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db7390b47c330bc52457d72ae5db9fc1bc584c4a94cc033fd08f400c646f168f',1976,'MZ','Mozambique','economy',363,'GNP: $2.3 billion (1972), about $250 per capita;
average annual growth probably stagnant or falling
Agriculture: cash crops — raw cotton, cashew nuts,
sugar, tea, copra, sisal; other crops — corn, wheat,
peanuts, potatoes, beans, sorghum, and.cassava; self-
sufficient in food except for wheat which must be
imported
Major industries: food processing (chiefly sugar,
tea, wheat, flour, cashew kernels); chemicals
(vegetable oil, oilcakes, soap, paints); petroleum
products; beverages; textiles; nonmetallic mineral
products (cement, glass, asbestos, cement products):
tobacco
Electric power: 442,000 kw. capacity (1974); 558
million kw.-hr. produced (1974), 66 kw.-hr. per capita
Exports: $240 million (f.0.b., 1974); cashew nuts,
cotton, sugar, mineral products, timber products, tea,
copra, petroleum products
Imports: $480 million (c.i.f., 1974 prelim.); (c.if.,
1972); machinery and electrical equipment, cotton
textiles, vehicles, petroleum products, wine, iron and
steel
Major trade partners: over one-third of foreign
trade with Portugal; South Africa, U.S., U.K., West','407f05015621b6e2444970a5171ef0ab144cf28551d9ca7772e40c682ac7fc20','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6389ea12ed793a7bd324fca04295a89bbca98060ccefb3f36ed18e48a472342',1976,'DE','Germany','economy',364,'Aid: mainly from Portugal
Budget: (FY75) balanced at $530 million prelim.
Monetary conversion rate: 26.68 escudos = US$1 as
of August 1975 (approximate realigned rate), floating
Fiscal year: calendar year
Budget: expenditures, FY76— current expenditures,
$1,438 million; capital expenditures, $1,385 million
Monetary conversion rate: 9.9 rupees = US$1
(since February 1973)
158
Fiscal year: 1 July - 30 June
Aid: U.S., FY62-73, $8.3 million; Belgium, France,
West Germany, and Canada, FY64-67, $33.4 million
obligated; China $22 million extended 1972
Budget: balanced at $34.7 million (FY74)
Monetary conversion rate: 92.84 Rwanda
francs=US$1 (official) since January 1974
Fiscal year: calendar year
Monetary conversion rate: 1 Saudi riyal = US$0.29
as of March 1975 (linked to SDR, freely convertible)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SAUDI ARABIA/SENEGAL
Fiscal year: follows Islamic year; the 1973-74
Saudi fiscal year covers the period 30 July 1973
through 1 July 1974
Aid: economic — U.S. (FY61-73) $508 million;
(1971 estimated disbursements) Belgium, $31.4
million; France, $6.6 million; other bilateral aid $5.4
million; U.N., $9.4 million; EC, $18.9 million; China
(1973) $100 million; military — U.S., $50 million
(FY62-73)
Budget: 1974—revenue $1,076 million, expendi-
ture $1,229 million, capital expenditure $261
Monetary conversion rate: 1 zaire- US$2
Fiscal year: calendar year','2cf89b1c1150a1afdd15e68fb40c5f9c5420c5e48caa04c85a9a501130b42207','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d968f0433cb50b4bd7a4403b1ca4e6d4b0d0028f0b8a8b3d3091d93050c9e947',1976,'NR','Nauru','economy',369,'GNP: $28 million (1970), $4,000 per capita (est.)
Agriculture: negligible; almost completely
dependent on imports for food, water
Major industries: mining of phosphates, about 2
million tons per year (1970)
Electric power: 8,300 kw. capacity (1974); 24
milion kw.-hr. produced (1974), 8,428 kw.-hr. per
capita
Exports: $27 million (f.o.b., 1970 est.), consisting
entirely of phosphates
Imports: $5 million (c.i.f., FY70)
Major trade partners: exports—Australia 58%,
New Zealand 22%, Japan 18%; imports—Australia
75%, U.K. 8%, New Zealand 5%, Japan 5%
Monetary conversion rate: 1 Australian dol-
lar=US$1.31 (official) (1975)
Fiscal year: 1 July - 30 June','5f08650c48291a65578d257ae150cf5e8dbc45769398712add41e0407f76b4cf','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d0f6c56b34519ea5ef76c147619b3908d161a76b38bf1d010df977cf627d327',1976,'NP','Nepal','economy',373,'GDP: $1,071 million (FY73 at current prices), less
than $100 per capita; 2% real growth in FY73
Agriculture: over 90% of population engaged in
agriculture; main crops — rice, corn, wheat,
sugarcane, oilseeds
Major industries: small rice, jute, sugar, and
oilseed mills; match, cigarette, and brick factories
Electric power: 64,000 kw. capacity (1974); 110
million kw.-hr. produced (1974), 9 kw.-hr. per capita
Exports: $48 million est. (FY70); rice and other
food products, jute, timber
Imports: $84 million est. (FY70); manufactured
consumer goods, fuel, construction materials, food
products
Major trade partner: over 80% India
Monetary conversion rate: 12.5 Nepalese
rupees z US$1 (October 1975)
Fiscal year: 15 July - 14 July','1680a2864127662ce16bbeb6130d6c9c8c043d130cf045d9a186907248995dcc','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29ada452e2a0e4b96decdde89765354ed2a2e15491f9926372f832ad733c839a',1976,'NZ','New Zealand','economy',379,'GNP: $11.7 billion (1974), $3,870 per capita; real
average annual growth (1969-74) 3.8%
Agriculture: fodder and silage crops about one-half
of area planted in field crops; main products — wool,
meat, dairy products; New Zealand is food surplus
country; caloric intake, 3,500 calories per day per
capita (1964)
Fishing: catch 58,000 metric tons (1972), 829.4
million 1973
Major industries: food processing, textile
production, machinery, transport equipment; wood
and paper products
Electric power: 4,653,000 kw. capacity (1974);
18.8 billion kw.-hr. produced (1974), 6,101 kw.-hr. per
capita
Exports: $2.1 billion including re-exports (f.o.b.,
trade year 1975); principal products (1974) — meat
30%, wool 20%, dairy products 17%
Imports: $3.7 billion (c.i.f., trade year 1975); ma-
chinery 3096, manufactured goods 2496, chemicals
12% (1974)
Major trade partners: trade year 1975); exports—
22% U.K., 12% U.S., 12% Japan, 11% Australia;
imports—19% Australia, 19% U.K., 14% Japan,
13% US.
Aid: gross official aid deliveries to LDC and
multilateral agencies 1973, $27.6 million
Budget: expenditures, 3,325 million NZ$, receipts,
3,070 million NZ$ (FY75)
Monetary conversion rate: NZ$1=US$1.06,
October 1975
Fiscal year: 1 April - 31 March
NOTE: trade data are for year ending 30 June
1975; trade year and fiscal year do not correspond','3a3a4fd4f57934eac2838e96455f44385356128bc3184317aea3ff7c457589bf','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7fe3e12749ee2408b1175efb91584fc5ac5090b97e315cee1ef5af57daf9c15',1976,'NI','Nicaragua','economy',383,'GDP: $1,230 million (1973 prices, 1974), $580 per
capita; 70% private consumption, 6% government
consumption, 27% domestic investment, —3% net
foreign balance (1973); real growth rate 1974, 11%
Agriculture: main crops — cotton, coffee,
sugarcane, rice, corn, beans, cattle; caloric intake,
2,300 calories per day per capita (1966)
Fishing: catch 11,200 metric tons (1972), $9.6
million (1970); exports $6.1 million (1971)
Major industries: food processing, chemicals,
metal products, textiles and clothing
Electric power: 217,000 kw. capacity (1974); 700
million kw.-hr. produced (1974), 345 kw.-hr. per
capita
Exports: $382 million (f.0.b., 1974); cotton, coffee,
chemical products, meat, sugar
Imports: $563 million (c.i.f., 1974); food and non-
food agricultural products, chemicals and phar-
maceuticals, transportation equipment, machinery,
construction materials, clothing, petroleum
Major trade partners: exports — U.S. 33%, Japan
12%, CACM 22%, West Germany 9%; imports —U.S.
34%, CACM 27%, Japan 7%, West Germany 7%,
Venezuela 5% (1978)
Aid: economic — extensions from U.S. (U.S. FY46-
73), $137 million loans, $76 million grants;
international organizations (U.S. FY46-73), $240
million; military — from U.S. (U.S. FY46-73), $17
million
Monetary conversion rate: 7 cordobas=US$1
(official)
Fiscal year: calendar year','f3dd73d45ba85a391ce75f1ee8972455b757d881b39ded4c1a9e836f546ee91a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d0d135a7333832883d58a7456c57e66cd97bdfaf0fd8186adb2eccde6ef5c61',1976,'NE','Niger','economy',387,'GDP: $400 million (1972 est.), $100 per capita
Agriculture: commercial — peanuts, ootton,
livestock; main food crops — millet, sorghum, niebe
beans, vegetables
Major industries: cement plant, brick factory, rice
mill, small cotton gins, oil presses, slaughterhouse, and
a few other small light industries; uranium production
began in 1971
Electric power: 61,200 kw. capacity (1974); 59
million kw.-hr. produced (1974), 13 kw.-hr. per capita
Exports: $62 million (f.o.b, 1973); about 60%
peanuts and related products, rest largely livestock,
hides, skins; exports understated because much
regional trade not recorded
Imports: $86 million (c.i.f., 1973); fuels,
machinery, transport equipment, foodstuffs, consum-
er goods (largely for European residents); sizable
imports unrecorded
Major trade partners: France (over 50% ), other EC
countries, Nigeria, UDEAC countries, U.S.;
preferential tariff to EC and franc zone countries
Aid: economic — France (1960 to mid-1967) $68
million; EC (FY61-73) $100 million; U.S. (FY61-73)
$26 million; West Germany, Israel, Republic of
China, and U.N. have also extended aid; military —
$2.8 million (1954-68)
Budget: projected to balance at about $70 million
(1975)
Approved For Release 2005/04/22 :
Monetary conversion rate: about 219.98 Com-
munaute Financiere Africaine=US$1 as of August
1975, floating since February 1973
Fiscal year: 1 October - 30 September','018fae0ee8c6a37b070be7d479581056b83f9daf6d232ce10892ef700eb284ae','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd9ac1bebf06d730f9e0240dc3e89d11638567ad175533110d9170df3d4a4873',1976,'NG','Nigeria','economy',391,'GDP: $23 billion (1974 current prices), $380 per
capita; 1096 growth rate (1973-74)
Agriculture: main crops — peanuts, cotton, cocoa,
rubber, yams, cassava, sorghum, palm kernels, millet,
corn, rice; livestock; almost self-sufficient
Fishing: catch 156,000 metric tons (1970); imports
$3.7 million (1971)
Major industries: mining — crude oil, natural gas,
coal, tin, columbite; processing industries — oil palm,
peanut, cotton, rubber, petroleum, wood, hides, skins;
manufacturing industries — textiles, cement, building
materials, food products, footwear, chemical,
printing, ceramics
Electric power: 1,330,000 kw. capacity (1974); 2.6
billion kw.-hr. produced (1974), 42 kw.-hr. per capita
Exports: $9.3 billion (f.o.b, 1974); oil (92%),
peanuts, palm products, cocoa, rubber, cotton,
timber, tin
Imports: $2.8 billion (c.i.f., 1974); machinery and
transport equipment, manufactured goods, chemicals
Major trade partners: U.K., EC, U.S.
Budget: FY75 est. — current revenue $5.1 billion,
current expenditure $1.5 billion, capital expenditure
$2.6 billion, $1 billion transferred to States
Monetary conversion rate: 1 Naira- US$1.62
(official)
Fiscal year: 1 April - 31 March','921c1e33c596fef750e4048f52e793ce6996bc30d964f1a22bcc01c6a046499e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d0843eccef0fe63c3449f8ad08257fa6f3d2e9292f6f211955a763150af3abb',1976,'NO','Norway','economy',395,'GNP; $23.4 billion in 1974 (at 1974 prices), $5,860
per capita; 52.3% private consumption; 33.8%
investment; 16.5% government; net foreign balance
—2.6%; 1974 growth rate 3.7%, in constant prices
155
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NORWAY/OMAN
Agriculture: animal husbandry predominates;
main crops — feed grains, potatoes, fruits, vegetables;
40% self-sufficient; food shortages — food grains,
sugar; caloric intake, 2,940 calories per day per capita
(1969-70)
Fishing: catch 2.4 million metric tons (1974); value
$290 million (1974); exports $28 million
Major industries: food processing, shipbuilding,
wood pulp, paper products, metals, chemicals
Shortages: most raw materials with the exception of
timber, iron, copper, and ilmenite ore, dairy products
and fish
Crude steel: 944,000 metric tons produced (1974),
236 kilograms per capita
Electric power: 15,400,000 kw. capacity (1974);
76.7 billion kw.-hr. produced (1974), 15,500 kw.-hr.
per capita
Exports: 86,313 million (f.0.b., 1974); principal
items—metals, pulp and paper, fish products, ships,
chemicals
Imports: $8,314 million (cif, 1974); principal
items—foodstuff, ships, fuels, motor vehicles, iron and
steel, chemical compounds, textiles
Major trade partners: EC 44.4% (U.K. 12.8%,
West Germany 12.7%, Denmark 6.7%); Sweden
18.3%; U.S. 6.995; Sino-Soviet countries 3.3% (1974)
Aid: economic — U.S., $482 million authorized
(FY46-73), $39.7 million in 1973; IBRD, $145 million
authorized through 1973, none since 1964; net official
economic aid delivered to less developed areas and
multilateral agencies, $134.2 million (1960-69); $36.8
million (1970); $42.4 million (1971), $63 million
(1972), $87 million (1973), $183 million (1974), $177
million (appropriated for 1975), $228 million
(proposed for 1976); military—U.S., $914.3 million
authorized (FY46-73), none since 1967
Budget: (1975) revenues $6,817 million, expendi-
tures $7,498 million
Monetary conversion rate: 1 kroner = US$0.1786
Fiscal year: calendar year','53efbf9f15e98f87551be3d8df625a837b566a9f35c758f56cc665bf6361524f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02d632bef024dc7b020df9c7fb48d5134f31fa16a1f0238440d64fce51f07bdd',1976,'OM','Oman','economy',399,'GNP: $900 million (1974 est.), $1,840 per capita
est.
Agriculture: based on subsistence farming (fruits,
dates, cereals, cattle, camels, fish) and trade
Major industries: petroleum discovery in 1964;
production began in 1967; production. 1975 est.
320,000 b/d; pipeline capacity 400,000 b/d; revenue
for 1974 est. at $687 million
Electric power: 27,000 kw. capacity (1974); 70
million kw.-hr. produced (1974) 143 kw.-hr. per
capita
Exports: mostly petroleum; non-oil exports $1.2
million (1974)
Imports: $711 million (1974)
Major trade partners: U.K., Gulf states, India,
Australia, China, Japan
Aid: bilateral assistance pledged, $184 million in
1974, IBRD $8 million; aid commitment by Oman,
$39 million to miltilateral institutions
Budget: (1974 revised) revenues $695 million,
expenditures $720 million
Monetary conversion rate: 1 Riyal Omani=
US$2.90 (as of October 1973)
Fiscal year: calendar year','ed918ba9cd7a2dec98955ca275143b1ead31aee28d4a7c67c4ab994fcb8517b7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('399fda766810ee9b6b27eb94c4b7256b76c845a4d05dd92c017bf84e632160b0',1976,'PK','Pakistan','economy',403,'GDP: $9.9 billion (FY75) at exchange rate of 9.9
rupees = US$] prevailing June 1973, $140 per capita;
real growth 2.5% (FY75)
Agriculture: extensive irrigation; main crops —
wheat and cotton; foodgrain shortage, 1.5 million tons
imported in FY75
Fishing: catch 208,200 metric tons (1974)
Major industries: cotton textiles, food processing,
tobacco, engineering, chemicals, natural gas
Electric power: 2,370,000 kw. capacity (1974);
10.4 billion kw.-hr. produced (1974), 152 kw.-hr. per
capita
Exports: $1,047 million (£o.b., FY75); cotton (raw
and manufactured), rice
Imports: $2,140 million (c.i.£., FY75); wheat, crude
oil, machinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West','3607096f5d5d5293e21e9724e5618a1cc01f9037fa98925e3ece2615bb164b6a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d204dd122b5caec0318def3e0d257c8b32923a99f600caf08cb18eeb4ef347e4',1976,'PA','Panama','economy',407,'GDP: 1,460 million (1978 est.), $930 per capita;
62% private consumption, 14% government con-
sumption, 30% gross fixed investment, —6% net
foreign balance (1973); real growth (1974), 3.5%
Agriculture: main crops — bananas, rice, corn,
coffee, sugarcane; self-sufficient in most basic foods;
2,450 calories per day per capita (1969)
Fishing: catch 56,500 metric tons, $10.4 million
(1971); exports $13.3 million (1971); imports $2.0
million (1971)
Major industries: food processing, metal products,
construction materials, petroleum products, clothing
Electric power (including Canal Zone): 380,000
kw. capacity (1974); 1.1 billion kw.-hr. produced
(1974), 715 kw.-hr. per capita
Exports: $205 million (£o.b., 1974); bananas,
petroleum products, shrimp, sugar, meat, coffee
Imports: $800 million (c.i.f., 1974); manufactures,
transportation equipment, crude petroleum, chemi-
cals, foodstuffs
Major trade partners: exports — U.S. 44%, Canal
Zone NA, West Germany 15%; imports — USS.
35%, Ecuador 11%, Venezuela 7% (1973)
Aid: economic — from U.S. (FY46-73), $254
million loans, $137 million grants; from international
organizations (FY46-73), $178 million; from other
Western countries (1960-71), $28.9 million; military
— assistance from U.S. (FY46-73), $6 million
Monetary conversion rate: 1 balboa=US$1
(official)
Fiscal year: calendar year','9aa662a6e5bdafd1b31913963b99f73afa7e3afff1db64b250377620c2b8d25a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5aa24cb87b3faa827b64e60ebc7d3b9306a917fc80fc27a1cadc21abf15463a7',1976,'PY','Paraguay','economy',411,'GDP: $1.0 billion (1974, in 1973 dollars), $400 per
capita; 84% consumption; 16% gross domestic
investment (1973); real growth rate 1974 est., 8.0%
Agriculture: main crops — oilseeds, cotton, wheat,
manioc, sweet potatoes, tobacco, corn, rice,
sugarcane; self-sufficient in most foods; caloric intake,
2,580 calories per day per capita (1963-64); protein
intake, 70 grams per day per capita (20 grams of
animal origin)
Major industries: meat packing, oilseed crushing,
milling, brewing, textiles, light consumer goods,
cement
Electric power: 202,000 kw. capacity (1974); 300
million kw.-hr. produced (1974), 125 kw.-hr. per
capita
Exports: $172.9 million (fo.b., 1974); meat,
timber, oilseeds, tobacco, cotton, quebracho extract,
hides, yerba mate, coffee
Imports: $198.2 million (f.o.b., 1974); foodstuffs,
machinery, transport equipment, fuels and lubricants,
textiles, chemicals
Major trade partners: U.S. 15%, Argentina 14%,
West Germany 13%, U.K. 9%
Aid: economic assistance — extensions from U.S.
(FY46-74), $79.0 million loans, $70.5 million grants;
from international organizations (FY46-73), $195.5
million; from other Western countries (1960-70),
$21.9 million; military — assistance from U.S. (FY57-
74), $19.0 million
Monetary conversion rate: 126 guaranies=US$1
(official rate)
Fiscal year: calendar year','d0bb3b79dba1c97efd759991a35b825079a16bb3d9490a40456088b9a244f6af','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddb4bab252d4a02c0a9d522249eefaf2c177046254610c8ff320e952ee674ebf',1976,'PE','Peru','economy',415,'GNP: $8.56 billion (1974), $590 per capita; 73%
private consumption, 10% public consumption, 12%
gross investment (1972); 596 net foreign balance; real
growth rate 1974, 6.3%
Agriculture: main crops — wheat, potatoes, beans,
barley, coffee, cotton, sugarcane; imports—wheat,
meat, lard and oils, rice, corn; caloric intake, 2,300
calories per day per capita (1964)
Fishing: catch 3.9 million metric tons (1974);
exports $250.0 million (1974)
Major industries: mining of metals, petroleum,
fishing, textiles and clothing, food processing, cement,
auto assembly, steel, ship-building, metal fabrication
Electric power: 2,500,000 kw. capacity (1974); 6.9
billion kw.-hr. produced (1974), 500 kw.-hr. per
capita
Exports: $2,405 million (f.o.b., 1974); fish and fish
products, copper, silver, iron, cotton, sugar, lead, zinc,
petroleum, coffee
Imports: $1,795 million (1974); foodstuffs,
machinery, transport equipment, iron and steel
semimanufactures, chemicals, pharmaccuticals
Major trade partners: exports — U.S. 33%,
Western Europe 30.2%, Japan 14%, Communist Bloc
countries 10,2%, Latin America 7%; imports — U.S.
29%, Western Europe 34%, Latin America 15%,
Japan 8% (1972)
Aid: economic — extensions from U.S. (FY46-73),
$583 million loans, $216 million grants; from
international organizations (FY46-73), $506 million;
from other Western countries (1960-72), $136.1
million; Communist countries (1969-74) $268 million;
military — assistance from U.S. (FY49-73), $143
million; from Communist countries (1974), $38
million
Monetary conversion rate: 45 soles = US$1 (trade);
48.38 soles=US$1 (non-trade)
Fiscal year: calendar year','144ef9d5b7fe0beadbc9bc9ac8c596d8327ad949a8d9aeb12ae3eeaafa2c0321','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('020f66e426aa27fd007dc04989115598e21835796fce8b6d0ffa4c15d3850afe',1976,'PL','Poland','economy',419,'GNP: $69.1 billion in 1974 at 1973 prices, $2,050
per capita; 1974 growth rate 7.6%
Agriculture: self-sufficient for minimum require-
ments; main crops — grain, sugar beets, oilseeds,
potatoes, exporter of livestock products and SUgar;
importer of grains; 3,200 calories per day per capita
(1970)
Fishing: catch 582,400 metric tons (1974)
Major industries: machine building, iron and steel,
extractive industries, chemicals, shipbuilding, and
food processing
Crude steel: 14.6 million. metric tons produced
(1974), about 430 kg. per capita
Electric power: 19,130,000 kw. capacity (1974);
91.6 billion kw.-hr. produced (1974), 2,710 kw.-hr. per
capita
Exports: $8,321 million (Éo.b. 1974) 34%
machinery and equipment, 39% fuels, raw materials,
and semimanufactures, 13% agricultural and food
products, 9% light industrial products
Imports: $10,489 million (Lo.b, 1974); 42%
machinery and equipment; 41% fuels, raw materials,
and semimanufactures; 17% agricultural and food
products; 5% light industrial products
Major trade partners: $18,803 million (1974); 49%
with Communist countries, 51% with West
Monetary conversion rate: 3,32 zlotys = US$1
(commercial); 19.92 zlotys=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data
are reported for calendar years except for caloric
intake which is reported for the consumption year, 1
July - 30 June
166','5147f822ef84be4785781d862b6feb279e6596da3b030554a40ccb227ebb56f3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea5b2ba45856e58768d3c669e077eb7d0494d31a2a65759f68c084e85c675047',1976,'PT','Portugal','economy',423,'GNP: continental Portugal — $14.1 billion est.
(1974), $1,650 per capita; 71.2% consumption, 20.2%
investment, 13.6% government, —5.0% net exports of
goods and services (1972), real growth rate 2.5% in
1974
Agriculture: generally underdeveloped; main crops
— grains, potatoes, olives, grapes for wine; food
shortages — sugar, wheat; caloric intake, 2,730
calories per day per capita (1969)
Fishing: landed 283,540 metric tons, $144 million
(1974)
Major industries: cotton textiles, cork processing,
fish canning, petroleum refining, pulp and paper,
chemical fertilizer
Shortages: coal, petroleum, cotton, steel
Crude steel: 317,000 metric tons produced (1974),
50 kg. per capita
Electric power: 3,200,000 kw. capacity (1974), 10.5
billion kw.-hr. produced (1974), 1,000 kw.-hr. per
capita
167
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PORTUGAL/PORTUGUESE TIMOR
Exports: $2,262 million (f.o.b. 1974): principal
items — cotton textiles, cork and cork products,
canned fish, wine, timber and timber products, resin
Imports: $4,459 million (c.i.f., 1974); principal
items — petroleum, cotton, industrial machinery, iron
and steel, chemicals
Major trade partners: (1974) EC 45% (U.K. 14%.
W. Germany 12%, France 7%, Italy 5%); U.S. 9%;
Angola 7%; Spain 4%; Sweden 4%
Aid: economic — U.S., $240 million (FY49-73), $13
million authorized FY73; IBRD, $57.5 million
authorized (1964-66), none since 1966; net official aid
to less developed areas and multilateral agencies $578
million (1961-70), $79.5 million (1969), $57.1 million
(1970); military — U.S., $345 million authorized
(FY1949-73)
Budget: 1974 — receipts $2.275 billion, expendi-
tures $2.957 billion
Monetary conversion rate: 1 escudo - US$0.0394
(1974 average); 1 escudo = US$0.0375 (August 1975)
Fiscal year: calendar year
GNP: less than $100 per capita
Agriculture: staple crops — corn, rice, sweet
potatoes; cash crops — coffee, copra, rubber
Major industries: minimal light manufacturing,
tourism
Electric power: 3,500 kw. capacity (1974); 12
million kw.-hr. produced (1974), 18 kw.-hr. per capita
Exports: $4.6 million (f.0.b., 1973); 90% coffee, 6%
copra, timber, and rubber
Imports: $7.1 million (c.i.f., 1973); textiles,
machinery and equipment, petroleum, foodstuffs
Major trade partners: exports — Portugal, EEC,
Singapore; imports — EEC, Singapore, Macao, Hong
Kong, Australia
Budget: 1973 expeditures of $10.1 million, $4.6
million of which was provided by Portugal
Monetary conversion rate: Portuguese escudo
known in Timor as pataca; 28.75 patacas = US$1
Fiscal year: calendar year','4b9daf7fb9a3e1dc4c4d10d342bf562987a3d9ad0ebd6a19fd0c573e8d994bdb','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2abb0667ac07d28a0839945fc4dd888458f54502027fadbfe9b51fc61d5df27e',1976,'QA','Qatar','economy',427,'GNP; $1.6 billion (1974) $9,090 per capita
Agriculture: farming and grazing on small scale;
commercial fishing increasing in importance; most
food imported; rice and dates staple diet
Major industries: oil production and refining;
crude oil production from onshore and offshore
averaged 280,000 b/d (current); oil revenues accrued
$2.0 billion in 1974, representing 91% of govern-
ment/royal family income; major development
projects include $7 million harbor at Ad Dawhah,
fertilizer plant, 2 desalting plants, refrigerated storage
for fishing, and a cement plant
Electric power: capacity 85,000 kw. (1974); 279
million kw.-hr. produced (1974), 1,505 kw.-hr. per
capita
Exports: crude oil dominates; non-oil exports $19
million (1974 est.)
Imports: $265 million (c.if., 1974 est.)
Aid: aid donor, pledged $450 million 1974,
disbursed $200 million
Budget: (1975) budgeted expenditures $495 million
Monetary conversion rate: 1 Qatar-Dubai
riyal = US$0.26 (as of March 1975)
Fiscal year: 1 April - 31 March','05669062d7374622f2ada314567d87b53ba529e5cf74c0ef1745335e8eefd4ce','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0739f0dd4c0e9cc41015cc487918286ab00a6ed984f0e01ef810398ffe688a5b',1976,'RO','Romania','economy',431,'GNP: $39.3 billion in 1974 (at 1973 prices), $1,860
per capita; real growth rate 8.8% (1971-74)
Agriculture: net exporter; main crops — corn,
wheat, oilseed; livestock — cattle, hogs, sheep; caloric
intake, 3,000 calories per day per capita (1967-68)
Fish catch: 85,000 metric tons (1972)
Major industries: machinery, metals, fuels,
chemicals, textiles, food processing, timber processing
Shortages: iron ore, coking coal, metallurgical
coke, cotton fibers, natural rubber
Crude steel: 8.8 million metric tons produced
(1974), 420 kg. per capita
Electric power: 10,900,000 kw. capacity (1974);
49.3 billion kw.-hr. produced (1974), 2,330 kw.-hr. per
capita
Exports: $4,874 million (f.o.b., 1974); 4376 fuels,
raw materials, semifinished products; 21% machinery
and equipment; 20% foodstuffs; and 1696 consumer
goods (1974)
Imports: $5,144 million (mixture f.o.b. and cif,
1974); 84% machinery and equipment; 54% fuels,
raw materials, semifinished products; 8% foodstuffs;
and 4% consumer goods (1974)
Major trade partners: $10,018 million in 1974;
58% non-Communist countries, 42% Communist
countries (1974)
Monetary conversion rate: 4.97 lei=US$1
(commercial) 12 lei=US$1 (tourist)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake,
which is reported for consumption year, 1 July - 30
June','52f1dfe593eeaa77eb50f1d155f323bfb2ead00031e14448b1631275041430c2','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('266ac69ba0d2ba2ce5630980cf7388aca97a40c71a847d6986bc19e58f0e4195',1976,'RW','Rwanda','economy',435,'GDP: $240 million (1971), $60 per capita
Agriculture; cash crops — mainly coffee, tea,
cotton, some pyrethrum; main food crops — bananas,
cassava; stock raising; self-sufficiency increasing but
country still imports some foodstuffs
Major industries: mining of cassiterite (tin ore),
agricultural processing, and light consumer goods
Electric power: 21,460 kw. capacity (1974); 100
million kw.-hr. produced (1974), 24 kw.-hr. per capita
Exports: $36 million (£o.b., 1974); mainly coffee,
tea, pyrethrum, cassiterite
Imports: $31.1 million (cif. 1973); textiles,
foodstuffs, machines, equipment
Major trade partners: U.S., Belgium, West','2100a819b49140067f0371e036446fcf219f89fdd29b71132268e37bc7611df1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61914a419b51f8cba22565b8214311ab6f0d5f0086a4a26d4007609487b68320',1976,'AI','Anguilla','economy',439,'GDP: $15.2 million (1969), $260 per capita
Agriculture: main crops — sugar on St.
Christopher, cotton on Nevis
Major industries: sugar processing, salt extraction
Electric power: 15,000 kw. capacity (1974); 20
million kw.-hr. produced (1974), 550 kw.-hr. per
capita
Exports: $6.1 million (£o.b., 1972); sugar,
molasses, cotton, salt, copra
Imports: $15.3 million (ci.£, 1972); foodstuffs,
fuel, manufactures
Major trade partners: U.K. 45%, Canada 14%,
U.S. 12% (1966)
175
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ST. CHRISTOPHER-NEVIS-ANGUILLA/ST. LUCIA
Monetary conversion rate: 2.07 East Caribbean
dollars = US$1 (May 1975); now floating with pound
sterling
GDP: $33.2 million (1971 est.), $290 per capita;
real growth rate 1971, 5.8%
Agriculture: main crops — bananas, copra, sugar,
cocoa, spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 13,500 kw. capacity (1974); 34
million kw.-hr. produced (1974); 250 kw.-hr. per
capita
Exports: $4.4 million (f.0.b., 1970); sugar, bananas,
cocoa
Imports: $27.3 million (cif, 1970); foodstuffs,
machinery and equipment, fertilizers, petroleum
products
Major trade partners: U.K. 51%, Canada 9%, U.S.
17% (1970)
Monetary conversion rate: 2.07 East Caribbean
dollars= US$1 (May 1975); now floating with pound
sterling
GDP: $20 million (1971 est.), $200 per capita; 6.9%
growth in 1971
Agriculture: main crops — bananas, arrowroot,
coconut
Major industries: food processing
Electric power: 5,000 kw. capacity (1974); 15.5
million. kw.-hr. produced (1974), 160 kw.-hr. per
capita
Exports: $2.9 million (Lob. 1971); bananas,
arrowroot, copra, cotton
Imports: $17.4 million (cif, 1971); fertilizer,
flour, transportation equipment, lumber, textiles
Major trade partners: U.K. 39%, U.S. 7%, Canada
10% (1971)
Monetary conversion rate: 2.07 East Caribbean
dollars=US$1 (May 1975), now floating with pound
sterling','6ae07b8de3d9260dd038d686bcb00067e836aa67d52b132a9eac0562f2efcbee','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3eec873a1effd1f43f1535ad816bdab894c48f8ed394464657c923e1743bc32d',1976,'SM','San Marino','economy',442,'Principal economic activities of San Marino are
farming, livestock raising, light manufacturing, and
tourism; the government''s total budget for FY7I was
about $12 million, with the largest share of revenue
derived from the sale of postage stamps throughout
the world and from payments by the Italian
government in exchange for Italy''s monopoly in
retailing tobacco, gasoline, and a few other goods;
main problem is finding an additional $3 million to
finance badly needed water and electric power
systems expansions
Agriculture: principal crops are wheat (average
annual output about 4,400 metric tons/year) and
grapes (average annual output about 700 metric
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SAN MARINO/SAO TOME AND PRINCIPE
tons/year); other grains, fruits, vegetables, and animal
feedstuffs are also grown; livestock population
numbers roughly 6,000 cows, oxen, and sheep; cheese
and hides are most important livestock products
Electric power: obtained from Italy, 1974
Manufacturing: consists mainly of cotton textile
production at Serravalle, brick and tile production at
Dogane, cement production at Acquaviva, Dogane,
and Fiorentino, and pottery production at Borgo
Maggiore; some tanned hides, paper, candy, baked
goods, Moscato wine, and gold and silver souvenirs
are also produced
Foreign transactions: dominated by tourism; in
summer months 20,000 to 30,000 foreigners visit San
Marino every day; a number of hotels and restaurants
have been built in recent years to accommodate them,
remittances from Sanmarinese abroad also represent
an important net forcign inflow; commodity trade
consists primarily of exchanging building stone, lime,
wood, chestnuts, wheat, wine, baked goods, hides,
and ceramics for a wide variety of consumer
manufactures','70780b8f55ee7e041f5b19ad4f732bfe556c4d78292cafa8b17ed2d24097f841','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f126d1845328c525eef59e46129ecb31bf26fd9be286aeef2818f416f8703b33',1976,'ST','Sao Tome and Principe','economy',446,'GNP: $19.6 million (1968 estimate based on 1970
census of 74,000); per capita income $265 (1968)
Agriculture: cash crops—cocoa, copra, coconut,
coffce, palm oil, bananas
Major industries: food processing on small scale,
timber
Electric power: 3,300 kw. capacity (1974); 5.4
million kw.-hr. produced (1974); 75 kw.-hr. per capita
Exports: $8.7 million (f.0.b., 1970); mainly cocoa
(70%), copra (12%), coconut, coffee, palm oil
179
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SAO TOME AND PRINCIPE/SAUDI ARABIA
Imports: $9.6 million (c.i.f., 1970); communica-
tions equipment, light and heavy vehicles, food
products, beverages, fuels and lubricants
Major trade partners: main partner, Portugal;
followed by Netherlands, West Germany, African
neighbors
Aid: Portugal
Budget: total expenditures $6.4 million (1970);
balance on ordinary budget $0.7 million (1970)
Monetary conversion rate: 27 escudos = US$1
(September 1975)
Fiscal year: probably calendar year','ab2b484b07a0b36fdf00682c40076842833363bfdb5d389b8814780567648ced','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dffed14c9c6e2c6b856e71a610b3e7c0348e65f5da3a6e7e507f67757f0d0592',1976,'SA','Saudi Arabia','economy',450,'GNP: $21 billion (1974 est., 1973 prices), $3,700
per capita; annual growth in real GNP approx. 30%
(1978/74 average)
Agriculture: dates, grains, livestock; not self-
sufficient in food
Major industries: petroleum production 8.4 million
b/d (current); payments to Saudi Arabian Govern-
ment, $25 billion (1974 est.); cement production and
small steel-rolling mill and oil refinery; several other
light industries, including factories producing
detergents, plastic products, furniture, etc.;
PETROMIN, a semipublic agency associated with the
Ministry of Petroleum, has recently completed a
major fertilizer plant
Electric power: 341,000 kw. capacity (1974); 1.1
billion kw.-hr. produced (1974), 183 kw.-hr. per
capita
Exports: $31.4 billion (fo.b.. 1974 est.); 99%
petroleum and petroleum products
Imports: $3.6 billion (c.i.f., 1974 est.); manufac-
tured goods, transportation equipment, construction
materials, and processed food products
Major trade partners: exports — U.S., Western
Europe, Japan; imports — U.S, Japan, West','f62ccd6a5bac301eef88a83cee19d7c6330eeb3c5496d6b2f381ad0e6dd0faa7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c825e9acc527cb8259f9e83d45139339450e6946c946daf39a97f26c3287194',1976,'SC','Seychelles','economy',454,'Agriculture: islands depend largely on coconut
production and export of copra; cinnamon, vanilla,
and patchouli (used for perfumes) are other cash
crops; food crops — small quantities of sweet
potatoes, cassava, sugarcane, and bananas; islands
not self-sufficient in foodstuffs and the bulk of the
supply must be imported
Major industries: processing of coconut and
vanilla, fishing, small-scale manufacture of consumer
goods, coir rope factory, tea factory
Electric power: 3,500 kw. capacity (1974); 9
million kw.-hr. produced (1974), 171 kw.-hr. per
capita
Exports: $3 million (f.o.b., 1974); cinnamon (bark
and oil) and vanilla account for almost 50% of the
total, copra accounts for about 40%, the remainder
consisting of patchouli, fish, and guano
Imports: $27 million (c.i.f., 1974); food, tobacco,
and beverages account for about 40% of imports,
manufactured goods about 25%, machinery and
transport equipment, petroleum products, textiles
Major trade partners: exports — India, U.S.;
imports — U.K., Burma, India, South Africa, Kenya,','bb3053f52bc60ea26c2189feab90b66a2b078109eb5709bbb294e548967d0df9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e24e0ab565a54b95f24ffc535c17c492dc988991a9a64ab14f8a7ec17152912',1976,'SL','Sierra Leone','economy',458,'GDP: $493 million (1974), approx. $180 per capita;
growth rate 22% (1973-74)
Agriculture: main crops — palm kernels, coffee,
cocoa, rice, yams, millet, ginger, cassava; much of
cultivated land devoted to subsistence farming; food
crops insufficient for domestic consumption
Fishing: catch 51,000 metric tons (1972), $6.6
million (1972), imports $2.7 million (1971)
Major industries: mining — diamonds, iron ore,
bauxite, rutile; manufacturing — beverages, textiles,
cigarettes, construction goods; 1 oil refinery
Electric power: 57,000 kw. capacity (1974); 270
million kw.-hr. produced (1974), 63 kw.-hr. per capita
Exports: $141 million (f.o.b., 1974); 60%
diamonds; iron ore, palm kernels, cocoa, coffee
Imports: $216 million (c.i.f., 1974); machinery and
transportation. equipment, manufactured goods,
foodstuffs, petroleum products
Major trade partners: U.K., EC, Japan, U.S.,
Communist countries
Budget: (FY74) current revenues $106 million,
current expenditures $82 million
Monetary conversion rate: 1 leone = US$1.19
Fiscal year: 1 July - 30 June (since 1 July 1966)','d7a564558533964787162ae28b14f731ea29db04943f110ff8d9df41a0618d12','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61e933eb04c4b41d2fd78c471da1c9fa58bc73e82daf1598249aa2d48dcf227e',1976,'SG','Singapore','economy',462,'GNP: $5.5 billion (1974), $2,400 per capita; 12.3%
average annual real growth (1966-74), 6.8% (1974)
Agriculture: occupies a position of minor
importance in the economy, self-sufficient in pork,
poultry, and eggs, must import much of its other food
requirements; major crops — rubber, copra, fruit and
vegetables
Fishing: catch 15,700 metric tons (1972), imports
— 47,000 metric tons (1972)
Major industries: petroleum refining, oil drilling
equipment, rubber processing and rubber products,
processed food and beverages, electronics, ship repair,
entrepot trade, financial services
Electric power: 1,109,000 kw. capacity (1974); 3.9
billion kw.-hr. produced (1974), 1,778 kw.-hr. per
capita
Exports: $6.2 billion (f.o.b., 1974); 40% reexports;
petroleum products, rubber, manufactured goods
Imports: $8.9 billion (cif, 1974); 18% goods
reexported; major retained imports — capital
equipment, manufactured goods, petroleum
Major trade partners: exports — Malaysia,
U.S., Japan, U.K., Indonesia; imports — Japan,
Malaysia, U.S., U.K.
Aid: U.K. — (1960 - September 1969) $254 million
disbursed, (1969-73) $120 million extended; IBRD —
185
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SINGAPORE/SOMALIA
(1963-74) $143 million committed, $61 million
disbursed; U.S. — (FY53-74) $102 million committed
Budget: (FY75/76) revenues $1.1 billion, expendi-
tures $1.8 billion, deficit $700 million; 25% military,
75% civilian
Monetary conversion rate: 2.48 Singapore
dollars = US$1 (August 1975)
Fiscal year: 1 April - 31 March','3c6386c85312070b24d3d13e08792cd5df46d507820136d4371715b51889d69a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e92c24e5122f16eb7a796ece3ee6001c559e55ee824b1323e189689e3f6d80c',1976,'SO','Somalia','economy',466,'GDP: $220 million (1973 est.), $70 per capita
Agriculture: mainly a pastoral country: main crops
— bananas, sugarcane, cotton, cereals; livestock
Major industries: a few small industries, including
a sugar refinery, tuna and beef canneries, iron rod
plant
Electric power: 9,000 kw. capacity (1974); 38
million kw.-hr. produced (1974), 12 kw.-hr. per capita
Exports: $55 million (fob., 1974); bananas,
livestock, hides, skins
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SOMALIA/SOUTH AFRICA
Imports: $157 million (c.i.f., 1974); textiles, cereals,
transport. equipment,
equipment
Major trade partners: Italy and Arab countries;
$29 million imports from Communist countries (1978
est.)
Monetary conversion rate: 6.205 Somali shil-
lings=US$1
Fiscal year: 1 January - 31 December','46bf784ad8440066c25e033a1e14870f78b256abe34dafe84392332c8a44e01b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9864caaeee724ec0e1428804adc83b2ea89427b9b73aa2d243920b17aaefbb79',1976,'ZA','South Africa','economy',470,'GDP: $31 billion (1974), $1,240 per capita; real
growth rate 7.2% (1974)
Agriculture: main crops — corn, wool, wheat,
sugarcane, tobacco, citrus fruits; dairy products; self-
sufficient in foodstuffs
Fishing: catch 1.3 million metric tons (1973), $176
million (1973)
Major industries: mining, automobile assembly,
metalworking, machinery, textiles, iron and steel,
chemical, fertilizer, fishing
Electric power: 11,635,000 kw. capacity (1974);
70.8 billion kw.-hr. produced (1974), 2,750 kw.-hr. per
capita
Exports: $4.4 billion (f.o.b.. 1974, excluding gold);
wool, diamonds, corn, uranium, sugar, fruit, hides,
skins, metals, metallic ores, asbestos, fish products;
gold output $3.6 billion (1974)
Imports: $8.0 billion (£o.b., 1974); motor vehicles,
machinery, metals, petroleum products, textiles,
chemicals
Major trade partners: U.K. and other Common-
wealth nations, U.S., West Germany, Japan
Aid: no substantial military or economic aid
Budget: FY76 — revenue $9.1 billion, expenditures
$9.6 billion
Monetary conversion rate: | SA Rand - US$1.15 as
of November 1975, 0.87 SA Rand 2 US$1
Fiscal year: 1 April - 31 March
NOTE: Foreign trade figures are official South
African data converted at $1.40
Agriculture: livestock raising (cattle and sheep)
predominates, subsistence crops (millet, sorghum,
corn, and some wheat) are raised but most food must
be imported
Fishing: catch 567,600 metric tons (1972)
(processed mostly in South African enclave of Walvis
Bay)
Major industries: meatpacking, fish processing,
copper, lead, and diamond mining, dairy products
Electric power: 155,200 kw. capacity (1974); 543
milion kw.-hr. produced (1974), 690 kw.-hr. per
capita
Aid: South Africa is only major donor
Monetary conversion rate: 1 South African
Rand=US$1.15 (as of June 1974); 0.87 SA
Rand- US$1
Fiscal year: 1 April - 81 March','82b475a17e65f45b45413eca2cede58f6dd08754eeb844020bad4370cb6d3cdf','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f660957218d06765ae200a29528760674b61ab2540c50e441c41fb5b993db2d',1976,'ES','Spain','economy',472,'GNP: 873.3 billion est. (1974); $2,080 per capita;
65.4% consumption, 23.5% investment, 11.1%
government 1973, real growth rate 4.9% (1974)
Agriculture: main crops — cereals, oranges, grapes
for wine, potatoes, olives, sugar beets; virtually self-
sufficient in good crop years; caloric intake, 2,750
calories per day per capita (1969-70)
Fishing: landed 850,578 metric tons valued at
$458.4 million in 197
Major industries: food processing, textiles and
apparel (including footwear), metal manufacturing,
chemicals, shipbuilding, automobiles
Shortages: crude petroleum
Approved For Release 2005/04/22
Crude steel: 11.5 million metric tons produced
(1974), 330 kilograms per capita
Electric power: 24,933,410 kw. capacity (1974);
80.8 billion kw.-hr. produced (1974), 2,050 kw.-hr. per
capita .
Exports: $7,091 million (Lo.b., 1974); principal
items — oranges and other fruits, iron and steel
products, textiles, wines, mercury, ships, canned fruits,
vegetables
Imports: $15,428 million (c.i.f., 1974); principal
items — machinery and transportation equipment,
petroleum and petroleum products, grains, cotton,
iron and steel
Major trade partners: (1974) EC 32%, U.S. and
Canada 1596, Latin America 8%, CEMA 2%
Aid: economie — U.S., $2.3 billion authorized
(FY46-73), IBRD, $427 million authorized (FY64-73),
$50.0 million authorized (EY73); military — U.S.,
$839 million authorized (FY53-73)
Budget: (1974) receipts 618 billion pesetas,
expenditures 625 billion pesetas, deficit 10 billion
pesetas
Monetary conversion rate: 1 peseta = US$0.0178
(1974 average}
Fiscal year: calendar year
Agriculture: practically none; some barley is grown
in nondrought years; fruit and vegetables in the few
oases; food imports are essential; camels, sheep, and
goats are kept by the nomadic natives: cash economy
exists largely for the garrison forces
Major industries: confined to fishing and
handicrafts; exploitation of huge phosphate deposit is
planned
Shortages: water
Electric power: 3,450 kw. capacity (1974); 8.4
million. kw.-hr. produced (1974), 110 kw.-hr. per
capita
Exports: $445,600 (1968); dried fish, goatskins
Imports: $1,443,000 (1968); fuel for fishing fleet,
foodstuffs
Major trade partners: monctary trade largely with
Spain and Spanish possessions
Aid: small amounts from Spain
Monetary conversion rate: 58.03 pesetas = US$]
(official), set February 1973','3c67a0b10cb0d415975555cbb2dea36335dc86449983d869af4aa3c896590a4e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09371c5f21bef733581fba88eee1b01386e385da775817fcfd32e79a2db3b580',1976,'LK','Sri Lanka','economy',478,'GNP: $2.3 billion in 1974 (1973 prices), $170 per
capita; real growth rate 3.4% (1974)
Agriculture: agriculture accounts for about 3596 of
GNP; main crops — rice, rubber, tea, coconuts; 60%
self-sufficient in food; food shortages — rice, wheat,
sugar
Fishing: catch 99,116 metric tons (1973)
Major industries: processing of rubber, tea, and
other agricultural commodities; consumer goods
manufacture
Electric power: 422,000 kw. capacity (1974); 1.2
billion kw.-hr. produced (1974), 88 kw.-hr. per capita
Exports: $537 million (1974); tea, rubber, coconut
products
193
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SRI LANKA/SUDAN
Imports: $717 million (1974); food, petroleum,
machinery and equipment
Major trade partners: (1973) exports — U.K.
115%, China 9.1%, Pakistan 82%, U.S. 6.9%,
U.S.S.R. 2.4%; imports — U.K. 6.8%, China 7.8%,
India 3.0%, U.S. 9.0%, U.S.S.R. 1.7%
Monetary conversion rate: 7.57 rupees=US$l
(October 1975), official rate
Fiscal year: 1 January - 31 December (starting
1973)','2ba33ca7f83672f89a1d01ebb7ff5ee33107ad714757d220a5788b164c394268','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3098f1dc294f6dbd4d43fa95e5804329975080da3e14ae4aed009f9687ee51d',1976,'SD','Sudan','economy',482,'GDP: $1.6 billion (1972), under $100 per capita;
8% growth at current prices 1968-69
Agriculture: main crops — sorghum, millet, wheat,
sesame, peanuts, beans, barley; not self-sufficient in
food production; main cash crops — cotton, gum
arabic
Major industries: cotton ginning, textiles, brewery,
cement, edible oils, soap, distilling, shoes, phar-
maceuticals
Electric power: 553,000 kw. capacity (1974); 655
million kw.-hr. produced (1974), 37 kw.-hr. per capita
Exports: $350 million (f.0.b., 1974); cotton (36%),
gum arabic, peanuts, sesame; $102 million exports to
Communist countries (FY71)
Imports: $642 million (cif, 1974); textiles,
petroleum products, vehicles, tea, wheat; $75 million
imports from Communist countries (FY71)
Major trade partners: U.K., West Germany, Italy,
India, U.S.S.R., China
Monetary conversion rate: 1 Sudanese pound=
US$2.87 (official); 0.348 Sudanese pound = US$1
Fiscal year: 1 July - 30 June
Approved For Release 2005/04/22 :
GNP: $395 million (1974); $850 per capita; real
growth rate 1974, 5.7%
Agriculture: main crops — rice, sugarcane,
bananas; self-sufficient in major staple (rice); caloric
intake 2,350 calories per day per capita (1968)
Major industries: bauxite mining, alumina and
aluminum production, lumbering, food processing
Electric power: 300,000 kw. capacity (1974); 1.7
billion kw.-hr. produced (1974), 3,800 kw.-hr. per
capita
Exports: $252 million (f.0.b., 1974); bauxite,
alumina, aluminum, wood and wood products, rice
Imports: $228 million (cif, 1974) capital
equipment, petroleum, iron and steel, cotton, flour,
meat, dairy products
Major trade partners: exports — U.S. 39%,
Canada 2%, Netherlands 14%; imports — US. 35%,
Netherlands 22% , Europe 18% (1971)
Aid: economic — extensions from U.S. (FY53-73),
$5.0 million loans, $4.8 million grants; from
international organizations (FY49-73), $47.1 million
Monetary conversion rate: L.79 Surinam guilders
(S. fL) 2 US$1 (27 December 1971)
Fiscal year: calendar year
GDP; approx. $120 million (FY72), about $280 per
capita; growth rate in current prices as much as 14.5%
(FY68-72)
Agriculture: main crops — maize, cotton, rice,
sugar, and citrus fruits
Major industry: mining
Electric power: 67,800 kw. capacity (1974); 220
million kw.-hr. produced (1974), 500 kw.-hr. per
capita
Exports: $93 million (fo.b., 1972); iron ore,
asbestos, sugar, wood and forest products, citrus, meat
products, cotton
Imports: $76 million (f.o.b., 1972); food products,
manufactured goods, machinery, fertilizer, fuel
Major trade partners: Japan, U.K., South Africa
Aid: economic aid — U.K. $147 million
(budgeted, 1971-73), U.S. $6.6 million (FY61-73),
others approximately $1.3 million; no military aid
Budget: FY76 — revenue $85 million, recurrent
expenditure $50 million, development expenditure
$37 million
197
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SWAZILAND/SWEDEN
Monetary conversion rate: | Lilangeni= US$1.15
(as of November 1975)
Fiscal year: 1 April - 31 March','528e5dd20b26f5a853e6636fe99e9c3450c82dfd40b41c7ba2f519a763508aff','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c2628b8a6c452876eb87233a098cfc5ae2adbbbf3a428804d345fba2774ae36',1976,'SE','Sweden','economy',486,'GNP: $56.0 billion, $6,850 per capita (1974);
53.2% consumption, 23.5% investment, 23.0%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Appro
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
SWEDEN/SWITZERLAND
government; 0.3% net exports of goods and services
(1973); 1974 growth rate 4.5% in constant prices
Agriculture: animal husbandry predominates with
milk and dairy products accounting for 40% of farm
income; main crops — grains, sugar bects, potatoes;
80% self-sufficient; food shortages — oils and fats,
tropical products; caloric intake, 2,880 calories per
day per capita (1967-68)
Fishing: catch 212,000 metric tons (1978), exports
$27 million, imports $136 million
Major industries: iron and steel, precision
equipment (bearings, radio and telephone parts,
armaments), shipbuilding, wood pulp and paper
products, processed foods, textiles, chemicals
Shortages: coal, petroleum, textile fibers, potash,
salt
Crude steel: 6.0 million metric tons produced
(1974), 733 kilograms per capita
Electric power: 19,426,000 kw. capacity (1974);
74.3 billion kw.-hr. produced (1974), 8,200 kw.-hr. per
capita
Exports: $15,854 million (f.0.b., 1974); machinery,
motor vehicles and ships, wood pulp, paper products,
iron and steel products, metal ores and scrap,
chemicals
Imports: $15,764 million (c.i.L., 1974); machinery,
motor vehicles, petroleum and petroleum products,
textile yarn. and fabrics, iron and steel, chemicals,
food, and live animals
Major trade partners: (1974) West Germany 14%,
U.K. 12%, US. 5%, Norway 9%, Denmark 8%; EC-9
51%; U.S.S.R. and Eastern Europe 5%
Aid: economic — U.S., $308.6 million authorized
(FY46-73); $77.5 million in 1973; $24.7 million in
1972; net official aid to less developed countries and
multilateral agencies, $662.4 million (1960-70), $159
million in 1971, $198 million in 1972, $275 million in
1973
Budget: 1974 — revenues $16.2 billion, ex-
penditures $18.0 billion
Monetary conversion rate: 1 kronor = US80.225
average exchange rate 1974
Fiscal year: 1 July - 30 June','87561b4df86203e9f094898df332b328361a61c3c49baebc1d7529776a302793','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7543b1c793fc305757c2024dc9c63a7d5876e4f830599fc3e9a71e16a48fa563',1976,'CH','Switzerland','economy',489,'GNP: $46.8 billion (1974, in current Prices), $7,120
per capita; 60% consumption, 26% investment, 12%
government, net foreign balance 296 (1974); 1974
growth rate 70.8%, constant prices
Agriculture; dairy farming predominates; less than
50% self-sufficient; food shortages — fish, refined
sugar, fats and oils (other than butter), grains, eggs,
fruits, vegetables, meat; caloric intake, 3,190 calories
per day per capita (1969-70)
Major industries; machinery, chemicals, watches,
textiles, precision instruments
Shortages: practically all important raw materials
except hydroelectric energy
Electric power: 11,600,000 kw, capacity (1974).
35.8 billion kw.-hr. produced (1974), 5,300 kw.-hr. per
capita
Exports: $11.9 billion (Eo.b., 1974); principal
items— machinery and equipment, precision
instruments, textiles, foodstuffs
Imports: $144 billion (cif, 1974); principal
items— machinery and transportation equipment,
metals and metal products, foodstuffs, chemicals,
textile fibers and yarns
Major trade Partners: West Germany 22%, France
12%, U.S. 7%, Austria 6%, Italy 9%, U.K. 6%; EC
56%: EFTA 11%; Communist countries 4% (1974)
Aid: economic — authorized, U.S. $63 million
through FY73; net official economic aid delivered to
less developed areas and multilateral agencies $194
million (FY62-72), $67 million in FY72
Budget: receipts, $4,030 million, expenditures
$4,378 million, deficit $348 million (1974)
Monetary conversion rate: 2.981 Swiss francs =
US$1 (average 1974. floating); 2.506 Swiss
francs = US$] (average first-half 1975, floating)
Fiscal year: calendar year
GDP: $2.1 billion, est. (1974), $300 per capita; real
GDP growth rate 12% 1973 est.
201
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SYRIA/TANZANIA
Agriculture: main crops — cotton, wheat, barley
and tobacco; sheep and goat raising; self-sufficient in
most foods in years of good weather
Major industries: textiles, petroleum (est. 50,000
b/d production, refining capacity was 54,000 b/d per
day, but reduced by war damage) food processing,
beverages, tobacco
Electric power: 447,500 kw. capacity (1974); 1.2
billion kw.-hr. produced (1974), 166 kw.-hr. per
capita
Exports: $787 million (f.o.b., 1974); petroleum,
cotton, fruits and vegetables, grain, wool, and
livestock
Imports: $1,235 million (c.if, 1974); machinery
and metal products, textiles, fuels, foodstuffs
Major trade partners: exports — U.S.S.R., Italy,
and Lebanon; imports — Lebanon, West Germany,
Italy, U.S.S. R., Japan, and France
Budget: 1975 est.—revenues $1.6 billion, expendi-
tures $1.7 billion
Monetary conversion rate: 3.70 Syrian pounds=
US$1
Fiscal year: calendar year
Mainland:
GDP: $1,919 million at current prices (1974 prov. )
about $180 per capita; growth rate in constant 1966
prices for 1973-74 2%
Agriculture: main crops — cotton, coffee, sisal on
mainland; largely self-sufficient in food
Fishing: catch 157,000 metric tons, $19.6 million
(1972); exports $1.7 million, imports $724,000 (1971)
Major industries: primarily agricultural processing
(sugar, beer, cigarettes, sisal twine), diamond mine, oil
refinery, shoes, cement, textiles, wood products
Electric power: 175,000 kw. capacity (1974); 513
million kw.-hr. produced (1974), 34 kw.-hr. per capita
Exports: 8428 million (f.o.b., 1974); coffee, cotton,
sisal, cashew nuts, meat, diamonds, cloves, tobacco,
tea
Imports: $811 million (c.i.f., 1974); manufactured
goods, machinery and transport equipment, cotton
piece goods, crude oil, foodstuffs (mainly for
Zanzibar)
Major trade partners: exports — China, U.K.,
Hong Kong. India, Kenya, U.S.; imports — U.K.,
China, Kenya, West Germany, U.S., Japan
Budget: (1972) receipts $306.3 million, expendi-
tures $306.6 million
Monetary conversion rate: 7.143 Tanzanian
shillings = US$1
Fiscal year: 1 July - 30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops — cloves, coconuts
Industries: agricultural processing
Electric power: see Tanganyika (above)
Exports: $12.6 million (1968); cloves and clove
products, coconut products
Imports: $5.6 million (1968); mainly foodstuffs and
consumer goods
Major trade partners: imports — China, Japan.
and mainland Tanzania; exports — Singapore,
China, Hong Kong. Indonesia, India, Pakistan
Aid: U.K. principal source of aid until 1964; U.S.
$86 million FY58-73; China is currently major source
Exchange rate: 1 Tanzanian shilling = US$0. 14;
7.143 Tanzanian shillings=US$1
Fiscal year: 1 July - 30 June','524bb6d5c6ab1daaaf356c43a6df045c167ea1b4b50bdc22f77351577daf424e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9eb23601af15194ef74940d838e779990498098435c01d9927edcd2a4a04bd39',1976,'TH','Thailand','economy',492,'GDP; $12.2 billion (1974 in current prices), $280
per capita; estimated 4.5% real growth in 1974 (6.6%
real growth, 1967-74)
Agriculture: world’s third largest rice exporter in
1974; main crops — rice, sugar, corn, rubber, tapioca;
almost 100% self-sufficient in food
Fishing: catch 1.7 million metric tons valued at
$465 million (1974); exports, 53,000 metric tons, $36
million (1972)
Major industries: agricultural processing, textiles,
wood and wood products, cement, tin and tungsten
ore mining; world''s second largest tungsten producer
and third largest tin producer
Shortages: fuel sources, including coal, petroleum;
scrap iron, and fertilizer
Electric power: 2,211,000 kw. capacity (1974); 8.3
million. kw.-hr. produced (1974), 210 kw.-hr. per
capita
Exports: $2,477 million (f.0.b., 1974); rice, sugar,
corn, rubber, tin, tapioca, kenaf
Imports: $3,168 million (c.if., 1974); excluding
U.S. military imports; machinery and transport
equipment, fuels and lubricants, base metals,
chemicals, and fertilizer
Major trade partners: exports — Japan, U.S.,
Singapore, Netherlands, Hong Kong, Malaysia:
imports — Japan, U.S., West Germany, U.K.; about
1% or less trade with Communist countries
Budget: (FY76) receipts $2,433 million, expendi-
tures $3,184 million, deficit $701 million; 17%
military, 88% civilian
: CIA-RDP79-01051A000800010001-8
zi A ————ÓÉHÓM
Appro
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
THAILAND/TOGO
Monetary conversion rate: 20.0 baht = US$1
Fiscal year: 1 October - 30 September
GNP: $3.0 billion (1974 est.), $150 per capita; no
real growth estimated for 1974, large decline
anticipated for 1975
Agriculture: main crops — rice, rubber, fruits and
vegetables; major food imports — rice, wheat, dairy
products
Fishing: catch 728,000 metric tons (1974); growing
trade in fish and fish products
Major industries: manufacturing on small scale,
mainly light manufacturing and processing of local
agricultural and forest products; factories produce
textiles, beer, cigarettes, glass, tires, sugar, paper,
cement, soft drinks
Shortages: capital goods
Electric power: 883,000 kw. capacity (1974); 1.9
million kw.-hr, produced (1974), 95 kw.-hr. per capita
Exports: $70 million (f.0.b., 1974); major
commodities—fish and fish products, rubber, forestry
products, scrap metal
Imports: $879 million (cif, 1974); major
commodities—food, petroleum products, fertilizer,
pharmaceuticals, iron and steel products, machinery,
textiles
Major trade partners: (1974) exports—Japan,
Hong Kong, Singapore, France; imports—U.S.,
Japan, France; no trade with Communist countries up
to 1975 9
Aid: (prior to 30 April 1975) economic—U.S.
(including P.L. 480) $477 million (FY70), $576
million (FY71), $455 million (FY72), $502 million
(FY73); approx. $654 million (FY74); approx. $500
million (FY75); numerous other non-Communist
countries providing assistance: military — U.S.,
$1,728 million (FY70), $1,895 million (FY71), $2,398
million (FY72), $2,168 million (FY73), $946 million
(FY74)
Budget: (prior to 30 April 1975) $1,083 million (est.
1975), 44% military, 56% civilian; deficit of $325
million (est. 1975)
Monetary conversion rate: last official pre-
takeover rate was 755 piasters=US81 (April 1975);
Communists issued new currency in September 1975
at rate of 500 old piasters=1 new piaster; no dollar
rate established but nominal value thought to be 3
new piasters= US$1
Fiscal year: calendar year
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
VIETNAM, SOUTH/WALLIS AND FUTUNA/WESTERN SAMOA','49147a5bc20fd61fbc4bd9b5ed5ccded6e4c4c5758a6dcaa3629ac663c5cdf8b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6cd4e91a71327d3bdb272793b3266c5bb780e04144e6fee5ab5949470f42b93',1976,'TG','Togo','economy',496,'GDP: $365 million (1973), about $170 per capita,
estimated real growth 1966-70, 5.3% average annual
rate
205
800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000
January 1976
TOGO/TONGA
Agriculture: main cash crops — coffee, cocoa;
major food crops — yams, cassava, corn, beans, rice,
fish: must import some foodstuffs
Major industries: phosphate mining, agricultural
Processing, handicrafts, textiles, beverages
Electric power: 24,300 kw. capacity (1974); 74.4
million kw.-hr. produced (1974), 37 kw.-hr. per capita
Exports; $88 million (Éo.b., 1974), phosphates,
cocoa, coffee, palm kernels, and Cassava
Imports: $138 million (cif, 1974); consumer
goods, fuels, machinery, tobacco, foodstuffs
Major trade partners: mostly with France and
other EC countries
Aid: 1970 disbursements — France $2.3 million,
West Germany $2.0 million, U.S. $1.0 million; FY59-
73 total commitments — EC $59.0 million, U.S. $2]
million, U.N. $16.0 million, others $1.1 million;
Budget: 1974 est. revenues and expenditures, $67.7
million
Monetary COnversion rate; Communaute Finan-
ciere Africaine 216 franes- US$] as of January 1975
(floating since February 1973)
Fiscal year: calendar year','5fe45e68573eaf8ffe2cf09405ec46b0f318fdc77f1954ea98dcec72e5dbc7fd','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fea62a46e51317753cd0766b33412d072631aa8ed911788e0333b789c423f9c9',1976,'TO','Tonga','economy',500,'GNP: $23 million (1973 est.), $160 per capita
Agriculture: largely dominated by coconut and
banana production with subsistence crops of taro,
yams, sweet potatoes, and bread fruit
Electric power: 2,000 kw. capacity (1974); 6
million kw.-hr. produced (1974), 62 kw.-hr. per capita
Exports: $7 million (f.0.b., FY74); copra, coconut
products 78%, bananas 9%
Imports: $17 million (c.i.L, FY74); food,
machinery, and petroleum
Major trade partners: (FY74) exports — 2596
Netherlands, 22% Australia, 20% New Zealand, 1196
Norway; imports — 6396 New Zealand and Australia
Budget: (FY73 est) revenues $6.1 million,
expenditures $7.0 million
Monetary conversion rate:
lar US$1.31 (1975)
Fiscal year: 1 July - 30 June','97adef80e082ce65983c60e5078b794ba849ababc828013499851e847e797112','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f80d8f9d745e98c41e826aa79f3ad81f96b1d4798686deb16016b76a7fe4cbe',1976,'TT','Trinidad and Tobago','economy',504,'GDP: $1,500 million (1974), 81,500 per capita; real
growth rate 1974, negl.
Agriculture: main crops — sugarcane, cocoa,
coffee, rice, citrus, bananas; largely dependent upon
imports of food
Fishing: catch 3,977 metric tons (1972); exports
$1.0 million (1971), imports $2.6 million (1971)
Major industries: petroleum, tourism, food
processing, cement
Electric power: 334,000 kw. capacity (1974); 1.2
billion kw.-hr. produced (1974), 1,240 kw.-hr. per
capita
Exports: $2.0 billion (£o.b., 1974); petroleum and
petroleum products (8990 million), sugar, cocoa
Imports: $1.9 billion (c.i.£., 1974); crude petroleum
($1.1 billion), machinery, fabricated metals,
transportation equipment, manufactured goods, food
Major trade partners: (excludes trade under
petroleum agreement) exports — U.S. 37%, U.K.
11%, CARIFTA 21%; imports — U.S. 34%, U.K.
23%, CARIFTA 10% (1972)
Aid: economic — from U.S. (FY56-73) $29 million
loans, $40 million grants; from international
organizations (FY53-73), $110 million
Monetary conversion rate: floating with pound
sterling; in September 1974, TT$2.25 - US$1
Fiscal year: calendar year','f4ee0cad6c4a09d2f93b1ff2c5f114baa4a7187647f1f524d8b3bd7358f48b7e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c15a65a7a62bc9e241b00c74dda8a3e2b467774d871fab9a2cadbd8ad4e81506',1976,'TN','Tunisia','economy',508,'CNP: $3.0 billion (1974 est.), $530 per capita;
10.6% average annual growth rate 1970-72, and 12%
in 1974
Agriculture: cereal farming and livestock herding
predominate, main crops — wheat, barley, olives,
fruits (especially citrus), viticulture, vegetables, dates
Major sectors: tourism, mining, food processing,
textiles and leather, light manufacturing, construction
materials, chemical fertilizers, petroleum
Electric power: 332,000 kw. capacity (1974); 1.1
billion kw.-hr. produced (1974), 193 kw.-hr. per
capita
Exports: $920 million (f.o.b., 1974); 34%
petroleum, 20% phosphates, 18% olive oil
Imports: $1,130 million (cif, 1974) 36% raw
materials, 23% machinery and equipment, 1496
consumer goods, 19% food and beverages, 3% energy,
5% other
Major trade partners: exports — France 19%, Italy
19%, West Germany 13%, Libya 10%; imports —
France 36%, U.S. 15%, Italy 9%, West Germany 7%
(1971)
Monetary conversion rate: 0.436 dinar = US$1
(trade rate)
Fiscal year: calendar year
GNP; $30.8 billion (1974), $790 per capita; 6.0%
average annual real growth 1974, 6.7% average
annual real growth 1972
Agriculture: main products — cotton, tobacco,
cereals, sugar beets, fruits, nuts, and livestock
products; self-sufficient in food in average years, 2,900
calories per day per capita (1972)
Major industries: textiles, food processing, mining
(coal, chromite, copper, boron minerals), steel,
petroleum
Crude steel: 1.6 million tons produced (1974), 40
kilograms per capita
Electric power: 3,300,000 kw. capacity (1974);
12.3 billion kw.-hr. produced (1974), 242 kw.-hr. per
capita
Exports: $1,532 million (f.o.b., 1974), cotton,
tobacco, fruits, nuts, metals, livestock products,
textiles and clothing
Imports: $3,777 million (c.i.f., 1974); machinery,
transport equipment, metals, mineral fucls, fertilizers,
chemicals
Major trade partners: exports — West Germany
21%, U.S. 12%, Switzerland 9%, Italy 6%; imports —
West Germany 19%, U.S. 12%, U.K. 11%, Italy 11%
Budget: (FY74) revenues $5,043 million, ex-
penditures $5,422 million, deficit $379 million
Monetary conversion rate: 14.75 Turkish liras=
US$1 (current)
Fiscal year: 1 March - 28 February','a20e6165de6ab8679974d7e3558452031aecbfa1c0d5c957796400cfc7d09e5f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f42dcd3a64a6ad27e970733d210a0cf9065f60a7519f2b9cbff4f0d46dbed7e',1976,'UG','Uganda','economy',512,'GDP: $1,053 million (1973) at 1966 prices, $100
per capita; 1% real growth between 1972 and 1973
Agriculture: main cash crops — coffee, cotton;
other cash crops — sugar, tobacco, tea, fish, livestock;
self-sufficient in food
Fishing: catch 170,000 metric tons (1972), $26.2
million (1971)
Major industries: agricultural processing (textiles,
sugar, coffee, plywood, beer), cerent, copper smelter,
corrugated iron sheet, shoes, fertilizer
Electric power: 234,000 kw. capacity (1974), 780
million kw.-hr. produced (1974), 69 kw.-hr. per capita
Exports: $315 million (£o.b., 1974); coffee, cotton,
copper, tea; $13.4 million to Communist countries
(1971)
211
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
UGANDA/U.S.S.R.
Imports: $213 million (cif, 1974); petroleum
products, machinery, cotton piece goods, metals,
transport equipment; $8.3 million from Communist
countries (1971)
Major trade partners: U.K., U.S., Kenya (Uganda,
Kenya, and Tanzania form East African Economic
Community)
Monetary conversion rate: 7.143 Uganda shil-
lings=US$1
Fiscal year: 1 July - 30 June
Agriculture: principal food crops — grain
(especially wheat), potatoes; main industrial crops —
sugar cotton, sunflowers, and flax; degree of self-
sufficiency depends on fluctuations in crop yields;
given normal yields, U.S.S.R. is self-sufficient; caloric
intake, 3,000-3,200 calories per day per capita in
recent years
Fishing: catch 9.5 million metric tons (1974);
exports 260.4 thousand metric tons (1973), imports
15.0 thousand metric tons (1972)
Major industries: diversified, highly developed
capital goods industries, consumer goods industries
comparatively less developed
153,237,112
Shortages: natural rubber, bauxite and alumina,
tantalum, tin, tungsten and fluorspar
Crude steel: 148 million metric ton capacity as of 1
January 1975; 136 million metric tons produced in
1974, 540 kilograms per capita
Exports: $27,874 million (£o.b., 1974); fuels
(particularly petroleum and derivatives), metals,
agricultural products (timber, grain) and a wide
variety of manufactured goods (primarily capital
goods)
Imports: $24,861 million (f.o.b., 1974); specialized
and complex machinery and equipment, textile fibers,
consumer manufactures, and any significant shortages
in domestic production (for example, wheat imported
following poor domestic harvests)
Major trade partners: $52 billion (1974) trade
54% with Communist countries, 31% with industrial-
ized West, and 15% with less developed countries
Official monetary conversion rate: 0.7600
rubles=US$1; 1 ruble=US$1.3158 (October 1975)
Fiscal year: calendar year','dff60eeac53df093d77de415f993f0b4dd50f24efc9457f88f37f7d6327f4c78','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be8f105afed2e3baf8936529ae23b378d5b4ecbf563db10fa46d32778b1e2a44',1976,'AE','United Arab Emirates','economy',515,'Agriculture: food imported, but some dates,
alfalfa, vegetables, fruit, tobacco raised
Electric power: 102,120 kw. capacity (1974); 273.6
billion kw.-hr. produced (1974), 4,000 kw.-hr. per
capita
Exports: crude petroleum, pearls, fish
Imports: $1.4 billion (cif, 1974 est), food,
consumer and capital goods
Major trade partners: Japan, U.K., India, U.S.
Aid: donor, led by Abu Dhabi; 1974 commitment
$1.8 billion
Budget: (1974) $215 million; Abu Dhabi (1974)
$1.5 billion; Dubai (1973) 8151 million
Monetary conversion rate: l Qatar-Dubai
riyal=US$0,25; Abu Dhabi, 1 Bahrain dinar-
US$2.52 (as of October 1973)','6a14136c5fa1e674154a7ad87cc9cab97c5c3d83ec38cc9fc2dbbf6b9023f0bd','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('752184722932f8a80ce6a2fa1e730ed33c612d194cd22aa02d5dd14e19127f4f',1976,'GB','United Kingdom','economy',516,'Fishing: catch 1.0 million metric tons (1973), $368
million (1973); exports $106 million, imports $324
million (1979)
Major industries: machinery and transport
equipment, metals, food processing, paper and paper
products, textiles, chemicals, clothing
Shortages: rubber, petroleum, timber and
woodpulp, textile fibers, nonferrous metals, foodstuffs
Crude steel: 29.5 million metric tons capacity
(1974); 22.4 million metric tons produced (1974), 400
kg. per capita
Electric power: 76,000,000 kw. capacity (1974);
273.6 billion kw.-hr. produced (1974), 4,000 kw.-hr.
per capita
Exports: $38.6 billion (£.o.b., 1974); machinery,
transport equipment, chemicals, metals, nonmetallic
mineral manufactures, textiles, beverages
Imports: $54.1 billion (cif, 1974); foodstuffs,
petroleum, machinery, crude materials, chemicals,
nonferrous metals
Major trade partners: (1973) exports — 11%,
Australia 3%, Canada 496, Ireland 496, South Africa
3%; Sterling area 24%; EC-nine 33%; U.S.S.R. and
Eastern Europe 3%
Aid: economic — (authorized) U.S., $8.7 billion
(FY46-73), $26 million in FY73; 51.4 million in FY72;
net official economic aid to less developed areas and
multilateral agencies, $5,073 million (1960-69), $562
million in 1971; $609 million in 1972; military —
U.S., $1.1 billion (FY46-73)
Budget (public sector): (1973/74) expenditures
$81.8 billion, revenues $71.3 billion
Monetary conversion rate: pound sterling floating,
average daily exchange rate 1974, US$0.4275=1
pound
Fiscal year: 1 April - 31 March
GDP: $366 million (1973 est., in constant prices),
$65 per capita
Agriculture; cash crops — peanuts, shea nuts,
sesame, cotton: food crops — sorghum, millet, corn,
tice; livestock; largely self-sufficient
Fishing: catch 5,000 metric tons (1971)
Major industries: agricultural processing plants,
brewery, bottling, and brick plants; a few other light
industries
Electric power; 16,700 kw. capacity (1974); 49
million kw.-hr. produced (1974), 8 kw.-hr. Per capita
Exports: $19 million (f.o, b., 1973); livestock (on the
oof), peanuts, shea nut products, cotton, sesame
Imports: $75 million (c.i f. 1973); textiles, food,
and other consume; goods, transport equipment,
machinery, fuels
Major trade partners: volume understated because
much regiona] trade is unrecorded: Ivory Coast and
Ghana; overseas trade mainly with France and other
| 800010001-8
T Approved For Release 2005/04/22 : CIA-RDP79-01051A000
ee
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
UPPER VOLTA/URUGUAY
EC countries; preferential tariff to EC and franc zone
countries
Aid: economic — France (1964-September 1970)
$46 million; EC (FY1960-72) $87 million; U.S.S.R.,
China, Ghana, West Germany, and Israel have also
extended aid; U.S. (FY61-73) $25 million; inter-
national organizations (FY1960-73) $28 million;
China $43 million (1973-74); military — France, $3.7
million (1964-70); U.S., $0.1 million (FY1962-73)
Budget: (1974) balanced at $56 million
Monetary conversion rate: about 219.98 Com-
munaute Financiere Africaine francs=US$1 as of
August 1975, floating since February 1973
Fiscal year: calendar year','9aa5eab75ee9aabd6c2d6747506f568cfb35048dab772115e3afb2b04f51cfc0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9079015e285d8ab630b38af43042f858ad137914e713664bdf69435834b441f',1976,'UY','Uruguay','economy',523,'GNP: $2.55 billion (at 1974 prices); $840 per
capita; 74% private consumption, 12% public
consumption, 14% gross investment (1969); real
growth rate 1974, 2%
Agriculture: large areas devoted to extensive
livestock grazing (17 million sheep, 9 million cattle);
main crops — wheat, rice, corn; self-sufficient in most
basic foodstuffs; caloric intake, 3,000 calories per day
per capita, with high protein content
Major industries: meat processing, wool and hides,
textiles, footwear, cement, petroleum refining
Crude steel: 13,000 metric tons produced (1972), 5
kilograms per capita
Electric power: 546,000 kw. capacity (1974); 2.4
billion kw.-hr. produced (1974), 860 kw.-hr. per
capita
Exports: $382 million (f.o.b., 1974); beef, wool,
hides
Imports: $481 million (c.i.f., 1974); fuels, metals,
machinery, transportation equipment
Major trade partners: exports — EC 3496, U.K.
14%, U.S. 7%, LAFTA 15%; imports — LAFTA 30%,
U.S. 14%, U.K. 6%, EC 19% (1969)
Aid: economic — extensions from U.S. (FY46-
73), loans $129 million, grants $28 million; from
international organizations (FY46-73), $258 million;
from other western countries (1960-71), $14.2 million;
from Communist countries (1966-74) $45.5 million;
military — U.S. (FY46-73), $59.8 million
Monetary conversion rate: commercial rate new
pesos 2.33=US$1, financial rate new pesos
2.802 US$1 (August 1975)
Fiscal year: calendar year
The Vatican City, seat of the Holy See, is supported
financially by contributions (known as Peter''s pence)
from Roman Catholics throughout the world; some
income derived from sale of Vatican postage stamps
and tourist mementos, fees for admission to Vatican
museums, and sale of publications; industrial activity
consists solely of printing and production of a small
amount of mosaics and staff uniforms
The banking and financial activities of the Vatican
are worldwide; the Institute for Religious Agencies
carries out fiscal operations and invests and transfers
funds of Roman Catholic religious communities
throughout the world, the Cardinal’s Commission
controls the administration of ordinary assets of the
Holy See and a Special Administration manages the
Holy See''s capital assets
Electric power: obtained from Rome city grid,
standby diesel powerplant with 2,100 kw. capacity
GNP: $22.5 billion (1974, in 1973 dollars), $1,930
per capita; 47% private consumption, 13% public
consumption, 2895 gross investment, 12% foreign
sector (1973), real growth rate 1974 est. 5%
Agriculture: main crops — cotton, sugarcane, corn,
coffee, rice; self-sufficient in rice and chicken, imports
wheat (U.S.) and meat (Colombia): caloric intake
2,600 calories per day per capita (1972)
Fishing: catch 152,000 metric tons, $34.1 million
(1972); exports $10.1 million (1970), imports $5.6
million (1970)
Major industries: petroleum, iron-ore mining,
construction, food processing, textiles
Crude steel: 1.1 million metric tons produced
(1973), 100 kilograms per capita
Electric power: 3,400,000 kw. capacity (1974); 16
billion kw.-hr. produced (1974), 1,390 kw.-hr. per
capita
220
Approved For Release 2005/04/22 :
Exports: $11.0 billion (Éo.b., 1974); petroleum
$10.4 billion (1974), iron ore, coffee
Imports: $4.2 billion (cif, 1974); industrial
machinery and equipment, chemicals, manufactures,
wheat
Major trade partners: imports — U.S. 42%, West
Germany 13%, Japan 8%; exports — U.S. 41%,
Canada 13%, Aruba 12%, Argentina 9%
Aid: economic assistance—extensions from U.S.
(FY46-74), $127.9 million loans; $71.1 million grants;
from international organizations (FY46-73), $665
million; from Communist countries (1954-74), $10
million; military — assistance from U.S. (FY46-74),
$141.3 million
Budget: 1975—revenues $9.5 billion; expenditures,
$9.4 billion, capital $1.9 billion
Monetary conversion rate: 4.285 bolivares = US$]
(selling rate)
Fiscal year: calendar year
Agriculture: mainly subsistence; main crops —
rice, corn, sweet potatocs, manioc, sugarcane; food
shortages — rice, meat, sugar, caloric intake, 1,700-
9,200 calories per day per capita
Major industries: food processing, textiles,
machine building, mining, cement, chemical fertilizer
Shortages: petroleum, complex machinery and
equipment, fertilizer, foodstuffs
Electric power: 252,000 kw. capacity (1974);
750,000 kw.-hr. produced (1974), 32 kw.-hr. per
capita
Monetary conversion rate (nominal): 3.0
dong=US$1 (1975)
Fiscal year: calendar year','076ecd4caa77a776615c27fe07c7a955f219f81185ab09fb6d6f33501b478109','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88f67bbc28f31e2ffb6313263a674ff51f5fe88e571fd974dae4be0c76f7f4fe',1976,'WF','Wallis and Futuna','economy',528,'Agriculture: dominated by coconut production
with subsistence crops of yams, taro, bananas
Exports: negligible
Imports: $1.4 million (1972), largely foodstuffs and
some equipment associated with development
programs
Monetary conversion rate: 70 Colonial Franc
Pacifique (CFP)- US$1','6a2aec1841bebe2399420caeda372a6f4f1262ba8167a22d70a72b13675b4c52','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41753b07734472a70a76d5c450460b6e0e8396bd4bd2d75f3f3c4341c08f9725',1976,'WS','Samoa','economy',530,'GNP; $38 million (1971), $260 per capita
Agriculture: cocoa, bananas, copra; staple foods
include coconut, bananas, taro, and yams
Exports: $13 million (£o.b., 1974); copra 63%,
cocoa 18%, timber 8%
224
Imports: $25 million (cif, 1974); food 30%.
manufactured goods 24%, machinery 9%
Major trade partners: exports—New Zealand 33%,
Netherlands 18%, West Germany 15%, U.S. 13%:
imports—New Zealand 33%, Australia 22%, Japan
11%
Aid: New Zealand, $7 million (est. 1972-76)
Budget: 1974 est., revenues $15 million, expendi-
tures $18 million
Monetary conversion rate: WS Tala=US$1.67
(August 1973), 0.61 WS Tala = US$1
Major industries: timber, tourism','770bd192b25e9974b3793a1b9840b74bdae3a3f2de4f1ca302b73d1049155bfe','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c5e12975e44ede4813d90cb5184e20b1bd6bb349bb33d2dbe873e52060f95c5',1976,'YE','Yemen','economy',534,'GNP: $100 million (1974 est.), $60 per capita
Agriculture (all outside Aden): cotton is main cash
crop; cereals, dates, kat (qat), coffee, and livestock are
raised and there is a growing fishing industry; large
amount of food must be imported (particularly for
Aden); cotton, hides, skins, dried and salted fish are
exported
Major industries: petroleum refinery (production
150,000 b/d) mid-1971; capacity 178,000 b/d at
? Excluding the islands of Perim and Kamaran for which
no data are available.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Little Aden operates on imported crude; oil
exploration activity
Electric power: 128,000 kw. capacity (1974); 448
million. kw.-hr. produced (1974), 276 kw.-hr. per
capita
Exports: $26 million (1974), excluding petroleum
products but including re-exports
Imports: $188 million (1974 provisional)
Major trade partners: Yemen, East Africa, but
some cement and sugar imported from Communist
countries; crude oil imported from Persian. Gulf,
exported mainly to U.K. and Japan
Budget: (FY1973-74, est.) — revenues $39 million,
expenditures 68 million
Monetary conversion rate; 1 S. Yemeni dinar-
US$2.90
Fiscal year: 1 April - 31 March
GNP: $300 million (1974 est.), $50 per capita
Agriculture: sorghum and millet, qat (a mild
narcotic), cotton, coffee, fruits and vegetables; largely
self-sufficient in food
Major industries: cotton textiles and leather goods
Produced on a small scale; handicraft and some
fishing; small aluminum products factory
Electric power; 4,000 kw. capactiy (1974); 14
million kw.-hr. produced (1974), 2 kw.-hr. per capita
Exports: $15 million (1974 est.), qat, cotton, coffee,
hides, vegetables
Imports: $220 million (1974 est.), textiles and other
manufactured consumer goods, petroleum products,
sugar, grain, flour, other foodstuffs, and cement
Major trade partners: China, Yemen (Aden),
U.S.S.R., Japan, U.K., Australia, Saudi Arabia
Aid: bilateral pledges received—$167 million 1974,
multilateral—$36 million 1974 through August 1972,
$170 million drawn through 1970; major donors
include U.S.S.R., China, U.S., West Germany, Saudi
226
Approved For Release 2005/04/22
Pee
Arabia; military — $78 million from U.S.S.R.; $30
million from Eastern Europe; $7 million western
military aid through 1973
Budget: (1974/75 est.) $92 million
Monetary conversion rate: 1 Yemeni rial =
US$0.22 as of October 1973
Fiscal year: 1 July - 30 June
GNP: $27.9 billion (1974 est., at 1973 prices),
$1,320 per capita; 1974 real growth rate approx. 6.5%
Agriculture: diversified agriculture with many
small private holdings and large agricultural
combines; main crops — corn, wheat, tobacco, sugar
beets, and sunflowers; generally a net exporter of
foodstuffs and live animals; self-sufficient in food
except for tropical products, cotton, wool, and
vegetable meal feeds; caloric intake, 3,210 calories per
day per capita (1967)
Major industries: metallurgy, machinery and
equipment, textiles, wood processing, food processing
Shortages: fuels, steel, textile fibers, chemicals
Crude steel: 2.8 million metric tons produced
(1974), 130 kg. per capita
Electric power: 8,850,000 kw. capacity (1974);
39.5 billion kw.-hr. produced (1974), 1,855 kw.-hr. per
capita
Exports: $3,805 million (f.0.b., 1974) 1196
foodstuffs and tobacco; 2196 raw materials, fuels, and
chemicals; 23% machinery and equipment; 45% other
manufactures
Imports: $7,542 million (c.i.f., 1974); 9% foodstuffs
and tobacco; 3796 raw materials, fuels, chemicals;
26% machinery and equipment; 28% other
manufactures
Major trade partners: 71% non-Communist
countries (35% EC, 6% U.S., 30% other non-
Communist countries), 29% Communist countries
Aid: postwar credits extended mainly by the U.S.
(about $3.6 billion, including grants and $0.7 billion
in military aid); Western Europe (more than $1.2
billion); IBRD ($1.0 billion); IMF (more than $580
million); Communist countries extended credits
227
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
YUGOSLAVIA/ZAIRE
totaling $464 million in 1956 ($125 million drawing
balance suspended in 1958) and $576 million during
1962-70 and $540 million in 1972; $173 million in
1974; Yugoslavia has extended credits totaling about
$700 million to 27 less developed countries of Africa,
Asia, and Latin America
Monetary conversion rate: 17.0 new dinars = US$1
Fiscal year: same as calendar year (all data refer to
calendar year or to middle or end of calendar year as
indicated)
GDP: $3.6 billion (1974 current prices), $150 per
capita; real growth rate 6.3% p.a. 1968-72
Agriculture: main cash crops — coffee, palm oil,
rubber; main food crops — manioc, bananas, root
crops, corn; some provinces self-sufficient
Fishing: catch 124,000 metric tons (1971); imports
$18 million (1972 est.)
Major industries: mining, mineral processing, light
industries
Electric power: 861,380 kw. capacity (1974); 3.5
billion kw.-hr. produced (1974) 126 kw.-hr. per
capita
Exports: $1,294 million (fo.b., 1974); copper,
cobalt, diamonds, other minerals, coffee, palm oil
Imports: $911 million (cif, 1974); consumer
goods, foodstuffs mining and other machinery,
transport equipment, fuels
Major trade partners: Belgium, U.S., and West','ffc3a58e8134a66fc1ab5e17804ae8179797ff8ca34ac0b155e38f097c0538b3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfa5676ea2a11df2c9f5216fb02817fe45e32763dfa97d8c9e9ec3eb8b430586',1976,'ZM','Zambia','economy',540,'GNP: $2.0 billion (1973 est.), $430 per capita; real
annual growth rate 1.4% between 1970 and 1973
Agriculture: main crops — corn, tobacco, cotton;
net importer of most major agricultural products
Fishing: catch 34,800 metric tons (1972); imports
$5.3 million (1970)
Major industries: copper mining and processing
Electric power: 891,800 kw. capacity (1974); 5.9
billion kw.-hr. produced (1974), 1,227 kw.-hr. per
capita
Exports: $1,406 million (f.o.b., 1974); copper, zinc,
cobalt, lead, tobacco
Imports: $904 million (c.i.f., 1974); consumer
goods, machinery, transport equipment, foodstuffs,
fuels
Major trade partners: U.K., South Africa, Japan,
Western Europe
Aid: economic—China $280 million (1967-74);
(1964-67) U.K. $63 million; IBRD $242 million (1965-
73); U.S. $77 million (FY53-73); U.S.S.R. $9 million;
Eastern Europe $50 million; military — $9 million
(1964-69), mainly U.K. and Canada
Budget: 1975—revenue $1,005 million, expendi-
ture $1,179 million
230
Monetary conversion rate: 1 Zambia kwacha=
US$1.555 (official), 0.643 Zambia kwacha=US$1
Fiscal year: calendar year','cecac7834e4d46e41b05747724209703ab049f3373a955dabbc9149f547e8f47','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c43e5193d6819f10ad913682a74ab6ae6128124fabf9f4b275f4bd6519bfe99',1976,'US','United States','economy',544,'GNP: $1,397 billion (1974); 63% private
consumption, 15% private investment, 22% govern-
ment; $6,600 per capita; 1974 growth rate —2%
(constant 1958 dollars)
Fishing: catch 2.7 million metric tons (1973),
valued at $704 million; imports $914 million (1971);
exports $136 million (1971)
Crude steel: 132 million metric tons produced
(1974), 620 kg. per capita
Electric power: 476,000,000 kw. capacity (1974);
1,865 billion kw.-hr. produced (1974), 8,400 kw.-hr.
per capita est.
Exports: $97.9 billion (f.0.b., 1974); machinery and
transport equipment, chemicals, cereals, mineral fuels
Imports: $100.2 billion (cif, 1974) transport
equipment, machinery, mineral fuels, steel, nonfer-
rous metals, metal ores
Major trade partners: Canada 21%, Japan 12%,
West Germany 6%, U.K. 4% (1973)
Official development assistance (aid): obligations
and loan authorizations (FY74), economic $3.9
billion, military $5.1 billion
Fiscal year: 1 July - 30 June','aacac4da13aba7c89b862f7249b55c498c0dfc318cf8de6c8c083ac19fad3a4c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c5f83ec92de62c668fdbee0f9d2c51a3133b5b9c2927fb5018c3d1d4fe620a4',1976,'AF','Afghanistan','economy',5,'GNP: $1.2 billion (FY74, at current prices), well
below $100 per capita; real growth rate about 3.7%
(1967-73)
Agriculture: agriculture and animal husbandry
account for over 50% of GNP and occupy nearly 80%
of the labor force; main crops — wheat and other
grains, cotton, fruits, nuts; largely self-sufficient, food
shortages — wheat, sugar, tea
Major industries: cottage industries,
processing, textiles, cement, coal mining
Electric power: 298,000 kw. capacity (1974); 520
million kw.-hr. produced (1974), 27 kw.-hr. per capita
Exports: 160 million (f.0.b., FY74); fresh and dried
fruits, hides and skins, natural gas, cotton, carpets and
rugs, wool
Imports: $123 million (c.if., FY74); transportation
equipment, non-metallic minerals, tea, sugar,
petroleum
Major trade partners: cxports — U.S.S.R., India,
U.K., West Germany, Pakistan; imports — Japan,
U.S.S.R., India, West Germany, U.K., U.S.
Aid: economic — U.S.S.R. (1954-74) $837 million
extended, $620 million drawn; Eastern Europe (1954-
74) $39 million extended, $11 million drawn; China
(1965-74) $74 million extended, $27 million drawn,
U.S. (FY49-73) $484 million committed; international
organizations (1946-73) $99 million, military —
U.S.S.R. (1956-74) $492 million extended, $430
million drawn; Eastern Europe (1955-74) $22 million
extended, $20 million drawn; U.S. (FY53-73) $5
million committed
Budget: current expenditures $162 million, capital
expenditures $110 million for FY75
Monetary conversion rate: 45 Afghanis = US$1
(official); 58 Afghanis = US$1 (December 1974)
Fiscal year: 21 March - 20 March','7ca5ea73795a9e34bbbf7c2f2079b2618b62875c6c0844185c26527e31318556','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbda63189ccebf9dfa9ec4a9e753d3db657dba6ebbe955b579848aae22c5125c',1976,'AL','Albania','economy',10,'GNP: $1.2 billion in 1972 (at 1972 prices), $520 per
capita
Agriculture: food deficit area; main crops — corn,
wheat, tobacco, sugar beets, cotton: food shortages —
wheat; caloric intake, 2,100 calories per day per capita
(1961/62)
Major industries: agricultural processing, textiles
and clothing, lumber, and extractive industries
Shortages: spare parts, machinery and equipment,
wheat
Electric power: 300,000 kw. capacity (1974); 1.6
billion kw.-hr. produced (1974), 660 kw.-hr. per
capita
Exports: $91 million (1970 est.): 1964 trade — 55%
minerals, metals, fuels; 17% agricultural materials
(except foods); 23% foodstuffs (including cigarettes):
5% consumer goods
Imports: $159 million (1970 est.); 1964 trade —
50% machinery, equipment, and spare parts; 16%
minerals, metals, fuels, construction materials, 7%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ALBANIA/ ALGERIA
fertilizers, other chemicals, rubber; 4% agricultural
materials (except foodstuffs); 16% foodstuffs, 7%
consumer goods
Monetary conversion rate: 5 leks = US$1 (commer-
cial); 12.5 leks = US$1 (noncommercial)
Fiscal year: same as calendar year, economic data
reported for calendar years except for caloric intake,
which is reported for consumption year 1 July - 30
June','948d7cb361ade471cb936cb93cac8fd8ad2a4ebd701551a224e214aecdbf5ae8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63e815920ab6b3826f17ad487d1769041209a2d12fc98284311d94566c8d9985',1976,'DZ','Algeria','economy',12,'GNP: $12.1 billion (1974 provisional), $719 per
capita, average annual increase since 1971 (current
prices), 26%
Agriculture: main crops — wheat, barley, grapes,
citrus fruits
Major industries: petroleum, light industries,
uatural gas, mining, petrochemical, electrical, and
automotive plants under construction
Electric power: 1,770,000 kw. capacity (1974): 2.8
billion kw.-hr. produced (1974), 169 kw.-hr. per
capita
Exports; $4,600 million (f£.0.b., 1974); crude
petroleum 87%, other items—natural gas, wine, citrus
fruit, iron ore, vegetables; to France 24%, West
Germany 24%, Benelux 9%, Italy 8%, U.S.S.R. 7%
(1973)
Imports: $4,039 million (cif, 1974); major
items—capital goods 35%, semi-finished goods 28%,
foodstuffs 23%; from France 38%, West Germany 9%,
Italy 9%, U.S. 8% (1973)
Monetary conversion rate: 4.18 dinars = US$1
Fiscal year: calendar year','7b6b26dfde316ac268c2f5a17fb6761b2008e3cec98ade09d0d23039e11fc6a5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('529eec082b7e993c1f97fd5d126541b7077bf8a45207225c4417b655c7fdfe62',1976,'AD','Andorra','economy',17,'Agriculture: sheep raising; small quantities of
tobacco, rye, wheat, barley, oats, and some vegetables
(only 25% of land can be used for agriculture)
Major industries: tourism ($1 million annually),
one cigarette factory (annual output $1 million),
handicrafts, smuggling (tobacco to France; manufac-
tured items, including automobiles and cameras, to
Spain)
Shortages: food
Electric power: 25,000 kw. capacity (1974); 100
million kw.-hr. produced (1974), 380 kw.-hr. per
capita; power is mainly exported to Spain and France
Major trade partners: Spain, France','45f5a16b7ddc6cfdd31ade7c328636eb1084a461ff5630f888c6f43f7256c01e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('901223f710147b6531fdef3b43ff810a45ab377bb47d031105505684fabbe4a9',1976,'AO','Angola','economy',21,'GDP: $3.0 billion (1974 est. ), $500 per capita, 6.1%
real growth (1970-72)
Agriculture: cash crops — coffee, sisal, corn,
cotton, sugar, manioc, and tobacco; food crops —
cassava, corn, vegetables, plantains, bananas, and
other local foodstuffs; largely self-sufficient in food
Fishing: catch 599,000 metric tons, $18.3 million
(1972); exports $18.7 million; imports $5.5 million
(1971)
Major industries: mining (oil, iron, diamonds), fish
processing, brewing, tobacco, sugar processing,
cement, food processing plants, building construction
Electric power: 465,000 kw. capacity (1974); 984
million kw.-hr. produced (1974), 163 kw.-hr. per
capita
Exports: $1.3 billion (est. f.o.b., 1974); oil, coffee,
diamonds, sisal, fish and fish products, iron ore,
timber, and corn
Imports: $600 million (est. cif., 1974); capital
equipment (machinery and electrical equipment),
wines, bulk iron and ironwork, steel and metals,
vehicles and spare parts, textiles and clothing,
medicines
Major trade partners: main partner Portugal,
followed by West Germany, U.S., U.K., Japan
Aid: Portugal only donor
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
january 1976
ANGOLA/ANTIGUA
Budget: (1975) balanced at about $740 million,
prelim. est.
Monetary conversion rate: 26.68 escudos = USS$1 as
of August 1975 (floating since February 1973)
Fiscal year: calendar year','ebfa6ae305159e9fff9ce5fccca400f18cd73e3a4691f0d9a744ca2097e7740f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4ed84eba101cc940d759320e434abe4ba9c6b98ef8eb213d259f065a22b7917',1976,'PR','Puerto Rico','economy',25,'GDP: $30 million (1973 est.), $395 per capita
Agriculture: main crop. cotton
Major industries: oil refining, tourism
Shortages: clectric power
Electric power: 23,000 kw, capacity (1974); 46
million kw.-hr. produced (1974), 540 kw.-hr. per
capita
Exports: $29 million (f.0.b., 1973): petroleum
products, cotton
Imports: $47 million (c.i.f., 1973): crude oil, food,
clothing
Major trade partners: U.K. 30%, U.S. 25%
Commonwealth Caribbean countries 18%
Aid: economic — U.S. (FY46-71), $1.5 million in
loans
Monetary conversion rate: 2.07 East Caribbean
dollars = US$1 (May 1975), now floating with pound
sterling
: CIA-RDP79-01051A000800010001-8
Pw ee -
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ANTIGUA/ARGENTINA','ea7d03b445899c7750ec908fde7860a60f87cbd7106408c96166a00590d773d4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0984ef8f68d861ddc35c3c7392f15a8875e8861008bd7b559ff5f0785f291be1',1976,'AR','Argentina','economy',29,'GDP: $38.9 billion (at average theoretical purity
exchange rate, 1974) $1,580 per capita: 77%
consumption, 20% investment (1974): real growth
tate 1974, 7.2%
Agriculture: muin products — cereals, oilseeds,
livestock products; Argentina is a major world
exporter of temperate zone foodstuffs
Fishing: catch 238,000 metric tons (1972). $44.6
million (1972). exports $25 million (1973), imports
$3.6 million (1970)
Major industries: food processing (especially
meatpacking), motor vehicles, consumer durables,
textiles, chemicals, printing, and metallurgy
Crude steel: 2.4 million metric tons produced
(1974), 90 kilograms per capita
Electric power: 8,349,000 kw. capacity (1974).
27.9 billion kw.-hr. produced (1974 ), 1,090 kw.-hr. per
capita
Exports: $4.01 billion (f.o.b., 1974 )—meut, corn,
wheat, wool, hides, oilseeds
Imports: $3.57 billion (cif, 1974)— machinery,
fuel and lubricating oils, iron and steel, intermediate
industrial products
Major trade partners (1973): exports—EC 40%.
LAFTA 24%, U.S. 8%, Japan 4%: imports—EC 30%.
LAFTA 19%. U.S. 21%, Japan 11%
Aid: economic — extensions from U.S, (FY46-73).
$879 million in loans, $17.8 million in grants: from
international organizations (FY46-73), $1.3 billion:
from other Western countries (1960-66), $315.5
million; from Communist countries (1954-74) $490
million ($40.0 million drawn): military — assistance
from U.S, (FY46-73), $174 million
Monetary conversion rate: commercial 37.7
pesos = US$1; financial—4g 3 pesos = US$1,_ parallel
market 115 pesos =US$1 (October 1975)
Fiscal year: calendar year','0e4072b156b8e997508b09f374ba880660855a3858c0f144e2cc286122bcc3cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40d18110128aa0d6a3aa3033b36e72375a44d894e2e54b347f52b311c3dcf91c',1976,'AU','Australia','economy',33,'GNP: $78.9 billion (1974), $5,900 per capita; 60%
private consumption, 15% government current
expenditure, 25% investment (FY75); real average
annual growth (1969-74), 4%
Agriculture: large areas devoted to livestock
grazing; 60% of arca used for crops is planted in
wheat; major products. — wool, livestock, wheat,
fruits, sugarcanc self-sufficient in food; caloric intake,
3,300 calories per day per capita
Appr
pproved For Release 2005/04/22 : CIA-RDP79-01051A00080001000
1-8
Fishing: catch 118,000 metric tons, $102 million
(1972); exports $102.5 million (FY74), imports $109.9
million (FY74)
Major industries: mining, bauxite, industrial and
transportation equipment, food processing, chemicals
Crude steel: 8.1 million metric tons produced
(FY75), 590 kilograms per capita
Electric power: 19,830,000 kw. capacity (1974);
72,8 billion kw.-hr. produced (1974), 5,430 kw.-hr. per
capita
Exports: $11.1 billion (f.0.b., 1974); principal
products (FY75)—agricultural products 34%,
metalliferous ores 14%, wool 8%, coal 8%
Imports: $12.4 billion (c.i-f., 1974)
Major trade partners: (FY75) exports—28% Japan,
10% U.S., 6% New Zealand, 5% U.K.; imports—21%
US., 15% U-K., 17% Japan
Aid: economic — Australian aid abroad $1.9 billion
(FY65-74); $371 million (FY74), 68% for Papua New
GNP: $1.3 billion (1978 est.); real average annual
growth rate (1960-69) 7.5%
Agriculture: main crops — coconuts, coffee, cocoa,
tea
Major industries: sawmilling and timber process-
ing, copper mining (Bougainville)
Electric power: 223,000 kw. capacity (1974); 560
million kw.-hr. produced (1974), 203 kw.-hr. per
capita
Exports: $721 million (f.0.b., FY74); principal
products — copper, coconut products, coffee beans,
timber
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PAPUA NEW GUINEA/PARAGUAY
Imports: $365 million (f.0.b., FY74)
Major trade partners: Australia, U.K., Japan
Aid: economic — Australia — $254 million
extended 1973; World Bank group (1968-September
1969) — $7.5 million committed; U.S. (FY70-
74) $32.5 million extended
Budget: (75-76) receipts 400 Australian dollars,
expenditures 408 Australian dollars
Monetary conversion rate: Kina $1=A$1
Fiscal year: 1 July - 30 June
Aid: $32 million in aid during 1974-76 from U.K.;
US (FY53-73) $0.5 million
Budget: FY73 — revenucs $9 million, expenditures
$10 million (approx. )
Monetary conversion rate: 5.4 Scychelles
rupees = US$1
Fiscal year: calendar year','7241f7307a4f77253739fd339e19cc0d272a345d1a72c0586fd20802cde1ed60','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44e742a5218c8bafb18ebbb10f50905d83cb1315a5b859f6d07101a2535d7286',1976,'GN','Guinea','economy',34,'Budget: expenditures, A$17.6_ billion; receipts
A$15.4 billion (FY75)
Monetary conversion rate: 0.80 Australian
dollar=US$1 (A$1 =US$1.25), October 1975
Fiscal year: 1 July - 30 Junc
GDP: $1,425 million (1973), pet capita about $240;
real growth rate about 7% per annum
Agriculture: commercial and food crops — cocoa,
coffee, timber, cotton, rubber, bananas, peanuts,
palm oil and palm kernels, root starches, livestock,
millet, sorghum, and rice
Fishing: imports 6,137 metric tons, $2.5 million,
exports 1,718 metric tons (largely shrimp), $2.7
million (1972)
Major industries: small aluminum plant, food
processing and light consumer goods industries,
sawmills
Electric power: 304,000 kw. capacity (1974); 1.7
billion kw.-hr. produced (1974), 323 kw.-hr. per
capita
Exports: $523 million (f.0.b., 1974), cocoa and
coffee about 55%; other exports include timber,
aluminum, cotton, natural rubber, bananas, peanuts,
tobacco, and tea
Imports: $477 million (cif, 1974); consumer
goods, machinery, transport equipment, alumina for
refining, petroleum products, food and beverages;
about 2.2% from Communist countries
Approved
For Release 2005/04/22 : CIA-RDP79-01051A0008000
10001-8
Major trade partners: about 70% of total trade
with France and other EC countries; about 12% of
total trade with US.
Budget: FY76 budget est. balanced at $500 million
Monetary conversion rate: 216 Communaute
Financiere Africaine francs = US$1 as of January 1975
Fiscal year: | July - 30 June
GNP: $70 million (1972); $240 per capita
Agriculture: major.cash crops — Rio Muni, timber,
cotfee; Fernando Po, cocoa: main food products —
rice, yams, cassava, bananas, oil palm nuts, manioc,
and livestock
Fishing: catch 4,000 metric tons (1970); exports
$86,000 (1970)
Major industries: fishing, sawmilling
Electric power: 2,800 kw. capacity (1974); 23
million kw.-hr. produced (1974), about 75 kw.-hr. per
capita
Exports: $19 million (1973); cocoa, coffee, and
wood
Imports: $21 million (1973); foodstuffs, chemicals
and chemical products, textiles
Major trade partner: Spain
Aid: Spain, $14.0 million (1969): Libya, $1 million
(1971); China $24 million extended (1971)
Budget: 1973 budget receipts $9 million,
expenditures $12 million
Monetary conversion rate: 64.47 Cuinean
pesetas = US$1 (official)
GDP: about $398 million (1973), $90 per capita
Agriculture: cash crops — coffee, bananas, palm
products, peanuts, and pineapples; staple food crops
— cassava, rice, millet, corn, sweet potatoes: livestock
raised in some areas
Major industries: alumina, light manufacturing
and processing industries, bauxite mining
Electric power: 99,700 kw. capacity (1974); 500
million kw.-hr. produced (1974), 115 kw.-hr. per
capita
Exports: export receipts, $49 million (1973):
alumina, bauxite, coffee, pineapples, bananas, palm
kernels
Imports: $146 million (1973): petroleum products,
metals, machinery and transport equipment,
foodstuffs, textiles
Major trade partners: Communist countries,
Western Europe (including France), U.S.
Budget: FY72 ordinary budget (est.)—$113 million
Monetary conversion rate: 22.7 syli= US$1
(October 1972)
Fiscal year: 1 October - 30 September
GNP: $19.6 million (1968 estimate based on 1970
census of 74,000); per capita income $265 (1968)
Agriculture: cash crops—cocoa, copra, coconut,
coffee, palm oil, bananas
Major industries: food processing on small scale,
timber
Electric power: 3,300 kw. capacity (1974); 5.4
million kw.-hr. produced (1974); 75 kw.-hr. per capita
Exports: $8.7 million (f.0.b., 1970); mainly cocoa
(70%), copra (12% }, coconut, coffee, palm oil
179
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SAO TOME AND PRINCIPE/SAUDI ARABIA
Imports: $9.6 million (c.i.f,, 1970); communica-
tions equipment, light and heavy vehicles, food
products, beverages, fuels and lubricants
Major trade partners: main partner, Portugal;
followed by Netherlands, West Germany, African
neighbors
Aid: Portugal
Budget: total expenditures $6.4 million (1970):
balance on ordinary budget $0.7 million (1970)
Monetary conversion rate: 27 escudos = US$1
(September 1975)
Fiscal year: probably calendar year
GNP: $21 billion (1974 est., 1973 prices), $3,700
per capita; annual growth in real GNP approx. 30%
(1973/74 average)
Agriculture: dates, grains, livestock: not. self-
sufficient in food
Major industries: petroleum production 8.4 million
b/d (current); payments to Saudi Arabian Govern-
ment, $25 billion (1974 est.); cement production and
small steel-rolling mill and oil tefinery; several other
light industries, including factories producing
detergents, plastic products, furniture, ete.:
PETROMIN, a semipublic agency associated with the
Ministry of Petroleum, has recently completed a
major fertilizer plant
Electric power: 341,000 kw. capacity (1974); 1.1
billion kw.-hr, produced (1974), 183 kw.-hr. per
capita
Exports: $31.4 billion (f.0.b., 1974 est.); 99%
petroleum and petroleum products
Imports: $3.6 billion (c.i.f,, 1974 est.); manufac-
tured goods, transportation equipment, construction
materials, and processed food products
Major trade partners: exports — U.S., Western
Kurope, Japan; imports — US., Japan, West','c7381507cf1bac59a16debfc56069207e218e5c33a3039e0b7313c7eeca42241','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('545abdffb3728269960090fadb8a61de39f5e180260a8410234b354a97f0648b',1976,'AT','Austria','economy',39,'GNP: $30.5 billion (1974), $4,070 per capita:
55.1% consumption, 31.4% investment, 14.4%
government, —0.4% net foreign balance. —0.5% net
errors and omissions (1972); 1974 growth rate
4.5% constant prices
Agriculture: livestock, cereals, potatoes, sugar
beets: 84% self-sufficient: caloric intake 3.230 calories
per day per capita (1969-70)
Major industries: foods, iron and steel, machinery,
textiles. chemicals. electrical, Paper and pulp
00010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008
EE
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
AUSTRIA/THE BAHAMAS
Crude steel: 4.7 million metric tons produced
(1974), 630 kilograms per capita (1974)
Electric power: 9,239,000 kw. capacity (1974);
33.9 billion kw.-hr. produced (1974), 4,530 kw.-hr. per
capita
Exports: $7.1 billion (f.0.b., 1974); iron and steel
products, machinery and equipment, lumber, textiles
and clothing, paper products, chemicals
Imports: $9.0 billion (c.i.f., 1974); machinery and
equipment, chemicals, textiles, coal, petroleum,
foodstuffs
Major trade partners: (1974) West Germany 31%,
Italy 8.2% Switzerland 10%, U.K. 5.2%, U.S. 3.1%
EC 54%; EFTA 14%; Communist countries 13%
Aid: economic — authorized — U.S. $1,218 million
through FY73; IBRD $105 million through FY73,
none since FY62; military — U.S., $116 million
(FY52-73); net official economic aid delivered to less
developed areas and multilateral agencies — $205
million (FY62-72), $17 million in FY72
Budget: expenditures, $8,880 million; receipts,
$8,332 million; deficit, $548 million (1974)
Monetary conversion rate: 18.69 shillings = US$1,
average 1974 (floating rate)
Fiscal year: calendar year
GNP: $496 million (at market prices, 1973), $2,490
per capita
Agriculture: main crops — fruits, vegetables
Major industries: tourism, cement, oil refining,
lumber, salt production
Electric power: 230,000 kw. capacity (1974); 650
million kw.-hr. produced (1974), 3,200 kw.-hr. per
capita
Exports: $1.4 billion (f.o0.b., 1974); fuel oil,
pharmaceuticals, cement, rum
Imports: $1.9 billion (cif.
toodstuffs, manufactured goods
Major trade partners: exports — U.S. 86%. U.K.
2%, Canada 2%; imports—U-S, 24%, Libya 20%,
Nigeria 16% (1973)
Aid: economic — authorizations from U.S. (FY56-
73) — $24.8 million in loans, $0.3 million in grants
Monetary conversion rate: 1 Bahamian dollar
(B$1)=US$1
Fiscal year: calendar year','45d878501020b75d1af26d578187396c949d69333fc9adbbfc69ad5b31e055ff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edb6cd9edc7c09e6ecad1d531b5e92951994f468026495972ef85da73795344a',1976,'BH','Bahrain','economy',43,'GNP: $390 million (1973), $1,650 per capita,
dominated by oil industry; crude oil production in
1974 estimated at the rate of approx. 70,000 bbls. per
day; refinery produced about 90 million bbls. in 1974;
government oil revenues for 1974 are estimated at
$165 million including refinery income and Saudi
Arabia’s payment for the Abu Saf’an field production
Agriculture: produces dates, alfalfa, vegetables;
dairy and poultry farming; fishing; not self-sufficient
in food
Major industries: petroleum refining, boatbuild-
ing, shrimp fishing, and sailmaking on a small scale;
major development projects include aluminum
smelter, flourmill, and ISA town; OAPEC dry dock to
be built by 1977
Electric power: 108,000 kw. capacity (1974); 270
million kw.-hr. produced (1974), 1,189 kw.-hr. per
capita
Exports: non-oil exports $80 million (1973)
Imports: non-oil, $317 million (1973)
Major trade partners: U.K., Japan, U.S., EC
Aid: received $110 million in bilateral commit-
ments and committed itself $8.5 million to
multilateral agencies in CY74
Budget: (1974 revised) $227 million, 85% of
revenues from oil
Monetary conversion rate: 1 Bahrain dinar=
US$2.52 (since January 1973)
Fiscal year: calendar year','eab6911ba2116d0a6b353f21d2cb725f09875726caec7e8c6a4a1fdf96c2c078','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3583c635c192a31a360fc7fa0a408aa2ee2b6e08bcde9cbefcca91d7c6dc765',1976,'BD','Bangladesh','economy',48,'GNP: $6.4 billion FY74 est. (FY70 prices), less than
$100 per capita; real annual per capita growth
(74/70) —0.5%
Agriculture: large subsistence farming, heavily
dependent on monsoon rainfall: main crops are jute
and rice; shortages — rice, cotton, and oilseeds
Fishing: catch 818,000 metric tons (1973)
Major industries: jute manufactures, food
processing and cotton textiles
Electric power: 762,000 kw. capacity (1974); 1.2
billion kw.-hr. produced (1974), 15 kw.-hr. per capita
Exports: $371.8 million (FY74); raw and
manufactured jute, leather, tea
Imports: $917.6 million (FY74); foodgrains, fuels,
raw cotton, yarn, manufactured products
Major trade partners: West Pakistan (until
December 1971), U.S., U.K., U.S.S.R., India
Aid: Bangladesh received roughly one-third of the
estimated $8 billion in total economic aid received by
Pakistan between 1950 and 1971: since independence
(December 1971-30 June 1974) commitments $2.15
billion, disbursements $1.25 billion; for FY75,
Id
commitments $1.1 billion of which U.S. $316 million,
Bank Group $150 million, U.S.S.R. $77 million
Budget: (FY76) revenue expenditures, $413
million; capital expenditures, $655 million
Monetary conversion rate: 14.5 taka=US$1
(October 1975)
Fiscal year: 1 July - 30 June','20ef5fee03f074c4e4519e62b88ff34049ae915971d2e1dd7d9bae3591e7803a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('175becc0b880e50513da0ef1841438224ea2c068d879e86554ee7dbf3e885107',1976,'BB','Barbados','economy',52,'GDP: $264 million (1974), $1,100 per capita; real
growth rate 1974, —11%
Agriculture; main products — sugar, subsistence
foods
Major industries: tourism, sugar milling, manufac-
turing
Electric power: 66,860 kw. capacity (1974), 200
million kw.-hr. produced (1974), 600 kw.-hr. per
capita
Exports: $86 million (f.0.b., 1974); sugar and
sugarcane by-products, clothing
Imports: $209 million (c.i-f., 1974); foodstuffs,
machinery, manufactured goods :
Major trade partners: exports — U.K. 28%, U.S.
14%, CARIFTA 28%, other 30%; imports — U.K.
25%, U.S. 21%, Canada 11%, CARIFTA 13%, other
30% (1973)
Aid: economic — U.S. (FY67-73), $1.4 million;
from international organizations (FY63-73), $4.9
million
Monetary conversion rate: 2 Barbados dol-
lars=US$1 (September 1975), now floating with
pound sterling
Fiscal year: | April - 31 March','6eedf16ca1caf25791d2dc37003aef450d103f2dd556f825e359392d9a0d18dc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5587134b7c94e4b64ab84d3869206309c2a1ff841b7d019e74b7fac16c0e9e1d',1976,'BE','Belgium','economy',56,'GNP: $47.8 billion (1974, in 1973 prices), $4,890
per capita (1973); 1973 — 60% consumption, 22%
investment, 15% government, 3% net foreign balance;
1974 real GNP growth rate 4.1%
Agriculture: livestock production predominates;
main crops — grains, beets, potatoes; 80% self-
sufficient in food; caloric intake, 3,230 calories per
day per capita (1969-70)
Fishing: catch 42,200 metric tons, $30.4 million
(1973); exports $28.0 million (1973), imports $74.0
million (1973)
Major industries: engineering and metal products,
processed food and beverages, chemicals, basic
metals, textiles, and petroleum
Shortages: iron ore, nonferrous minerals, petroleum
Crude steel: capacity 14.8 million metric tons:
16.227 million metric tons produced: 1,660 kg. per
capita (1974 est.)
Electric power: 9,397,000 capacity (1974); 42.7
billion kw.-hr. produced (1974), 3,700 kw.-hr. per
capita
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
| a
January 1976
BELGIUM/ BELIZE
Exports: $28.2 billion (f.0.b., 1974), ferrous metals,
finished or semifinished precious stones, textile
products
Imports: $29.7 billion (cif, 1974), nonelectrical
machinery, motor vehicles, textiles, chemicals
Major trade partners: (Belgium-Luxembourg
Economic Union, 1973) EC-nine 72% (West Germany
24%, France 20%, Netherlands 17%, U.K. 6%, Italy
4%), U.S. 6%, Communist countries 2%
Aid: economic — received, U.S., $783.8 million
authorized (FY46-73), $2.5 million in FY73; IBRD,
$200.8 million (1949-73); military — received,
$1,260.8 million authorized (FY46-73); net official
economic aid to less developed areas and multilateral
agencies, $1,092 million (FY60-70), $235.6 million in
1973
Ordinary budget, 1975 (projected): revenue
$16.19 billion, projected expenditures $19 billion (1
franc = US$0.0257 floating)
Monetary conversion rate 1974 average: 1
franc = US$0.0257 floating
Fiscal year: calendar year','825c8c6421464ad5b5473fb5b0fe997154694ab4fdf6701c0e4e6d8c21d377e1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e06838dc2a4a3878df9172b0e4a739a9125ba764acce30f512a1d8f7c22b1353',1976,'BZ','Belize','economy',61,'GDP: $75.0 million (1973 est.), $570 per capita:
78% private consumption, 17% public consumption,
36% domestic investment, —31% net foreign balance
(1968): real growth rate 197] 3.5%
Agriculture: main products — Sugar, citrus fruits,
corn, rice, beans, bananas, livestock products; net
importer of food: caloric intake, 2,500 calories per day
per capita
Major industries: timber and forest products, food
Processing, furniture, rum, soap
Electric Power: 7,000 kw. Capacity (1974). 98
million kw.-hr. produced (1974), 210 kw.-hr. per
capita
Exports: $31.7 million (f.o.b., 1973 est.) sugar,
lumber, citrus fruits, fish
Imports; $49.9 million (cif, 1973): vehicles,
petroleum, food, textiles, machinery
Major trade Partners: exports — U.s. 30%, U.K.
24%, Mexico 22%, Canada 13%; imports — U.S.
34%, UK. 25%, Jamuica 7% (1970)
Aid: economic — US. (FY46-73), $6.6 million,
grants; from international] organizations (1946-73),
$1.7 million
Monetary conversion rate: $BH1.66= US$]
(March 1975)
Fiscal year: calendar year','0e6966cd426b5f63015cab12d1c1d3c2b83579cc36affc96e914a425ccc679ef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51e903c7ac33eb5359db35752f0d33c92a4a9e894133cc072f26821f72be3f2c',1976,'BM','Bermuda','economy',65,'GNP: $300-$350 million (at market prices, 1974),
$5,000-$6,000 per capita
Agriculture: main products — bananas, vegeta-
bles, Easter lilies, dairy products, citrus fruits
Major industries: tourism, finance
Electric power: 86,120 kw. capacity (1974); 298
million kw.-hr. produced (1974), 5,320 kw.-hr. per
capita
Exports: $29.4 million (f.o.b., 1973); mostly
reexports of drugs and bunker fuel
Imports: $154.6 million (f.0.b., 1974); fuel,
foodstuffs, machinery
Major trade partners: U.S. 45%, U.K. 22%,
Canada 9% (1971)
Monetary conversion rate: 1 Bermuda dol-
lar = US$1
Fiscal year: 1 April - 81 March','f6948050cbe4d605fb9d5226a9a5a194b9b5c93ee1c2118894250a7b5d0b6f0c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('604e411c558501c46ac67122381002348e3ae8f93e9777d558a5929c4e760d66',1976,'IN','India','economy',69,'GNP: under $100 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 1,900 kw. capacity (1974): 5
million kw.-hr. produced (1974), 4 kw.-hr. per capita
Exports: about $1 million annually; rice, dolomite.
and handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic — India (FY61-72) $180 million
Monetary conversion rate: both ngultrums and
{Indian rupees are legal tender: 8,77 ngultrums =8.77
Indian ripees=US$1 as of October 1975
Fiscal year: | April - 31 March
GNP: $1.16 billion (1974, in 1973 dollars), $230 per
capita; 69% private consumption, 11% public
consumption, 16% gross domestic investment, +4%
net foreign balance (1974); real growth rate 1971-74
average 5.9%
Agriculture: main crops — potatoes, corn, rice,
sugarcane, yucca, bananas; imports significant
quantities of foodstuffs including lard, vegetable oils,
and wheat: caloric intake, 1,800 calories per day per
capita (1971)
Major industries: mining, smelting, petroleum
refining, food processing, textiles, and clothing
Electric power: 309,000 kw. capacity (1974); 904
million kw.-hr. produced (1974), 180 kw.-hr, per
capita
Exports: $555.1 million (f.0.b., 1974 est); tin,
petroleum, lead, zine, silver, tungsten, antimony,
bismuth, gold, coffce, sugar, cotton
Imports: $390.8 million (f.0.b., 1974 est.);
foodstuffs, chemicals, capital goods, pharmaccuticals
Major trade partners: exports — U.K. 26%, US.
17%, West Europe 4%, Latin America 20%; imports
— US. 28%, Latin America 27%, Japan 17%,
Western Europe 26% (1972)
Aid: economic — extensions from U.S. (FY46-73)
$300 million in loans, $319 million in grants; from
international organizations (FY46-73), $228 million;
from other Western countries (1960-72), $53.3
million; Communist countries (1970-74), $60.2
million; military — assistance from U.S. (FY52-73),
$36 million (1974, in 1973 dollars)
Budget: $152 million revenues, $159 million
expenditures
Monetary conversion rate: 20 pesos = US$1
Fiscal year: calendar year
Approved For Release 2005/04/22 :
GNP: $66 billion (1974, in 1973 prices), $112 per
capita; real growth 1.4% (FY70-74), 1% est.
Agriculture: main crops — rice, other cereals,
pulses, oilseeds, cotton, jute, sugarcane, tobacco, tea,
and coffee; must import foodgrains; caloric intake is
low and diet is deficient in protein
Fishing: catch 2.3 million metric tons (FY73);
value of fish catch, $357 million (FY73); exports
$114 million (FY73), imports $2 million
Major industries: textiles, food processing, steel,
machinery, transportation equipment, cement, jute
manufactures
Crude steel: 7 million metric tons produced (FY74)
Electric power: 19,480,000 kw. capacity (1974);
73.8 billion kw.-hr. produced (1974), 124 kw.-hr. per
capita
Exports: $4.1 billion (f.0.b., FY74); tea, jute
manufactures, iron ore, cotton textiles, leather and
leather products, sugar
Imports: $5.5 billion (c.if., FY74); machinery and
transport equipment, petroleum, iron and steel, grains
and flour, fertilizers
Major trade partners: U.S., U.K., U.S.S.R. and
Kastern Europe, Japan, Iran
Budget: (FY75) revenue expenditures $7.4 billion,
capital expenditures $4.9 billion
Monetary conversion rate: 8.77 rupees=US$1
(October 1975)
Fiscal year: 1 April, stated year — 3] March','088115e10683aede0a9ee21d37a511ef0193f59d960a9d65d7db153393414475','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e451e9b76f13aff6d76cfa7819e9661d4c54580697feb547ee30a34b577312c',1976,'BW','Botswana','economy',74,'GDP: $142.6 million (April 1971 - March 1972),
about $210 per capita, growth in current prices about
25% annually (FY''s 1968-72)
Agriculture: principal crops are corn and sorghum,
livestock raised and exported
Major industries: livestock processing. mining of
diamonds. copper. nickel, coal, asbestos, and
manganese
Flectric power: 14,900 kw. capacity (1974): 64
million kw.-hr. produced (1974), 96 kw.-hr per capita
Fxports: $107 million (1974 est.); cattle. animal
products. minerals
Imports: $147 million (1974 est.}: foodstuffs.
vehicles, textiles
Major trade partners; South Africa and U.K.
Budget: (1976) revenue $134 million ($108 million
from domestic taxes and $26 million from borrowing
and foreign aid), current expenditures $75 million,
investment expenditures $59 million
Monetary conversion rate: | SA Rand= USS$1.15 as
of November 1975 (Botswana uses the South African
Rand)
Fiscal year: | April - 31 March','b29c5291a4ba7f4f918633ddb74545db673bfc2943262cab27b150951f09c9de','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02cc37b499b47bcd971f59420d90e2f6b2d95a17e1df0756ccd715e32c7d19c4',1976,'BR','Brazil','economy',78,'GNP: $77 billion (1974, in 1973 prices), $810 per
capita; 28% gross investment, 79% consumption,
—7% net foreign balance (1974); real growth rate
1974, 9.6%
Agriculture: main products — coffee, rice, beef,
corn, milk, sugarcane, soybeans; nearly self-sufficient;
caloric intake, 2,900 calories per day per capita (1962)
Fishing: catch 581,000 metric tons (1971) valued at.
$160 million (1971); exports (f.0.b.) $26.7 million,
imports (f.0.b.) $27.5 million (1971)
Major industries: textiles and other consumer
goods, cement, lumber, steel, motor vehicles, other
metalworking industries
Crude steel: 8.5 million metric tons capacity (1974
est.); 7.5 million metric tons produced (1974); 72
kilograms per capita
Electric power: 17,643,000 kw. capacity (1974
est.); 74.3 billion kw.-hr. produced (1974), 700 kw.-hr.
per capita
Exports: $7,967 million (f.0.b., 1974); coffee,
manufactures, iron ore, cotton, soybeans, sugar, wood,
cocoa, beef, shoes
Imports: $14,161] million (c.if., 1974); machinery,
chemicals, pharmaceuticals, petroleum, wheat
Major trade partners: exports — U.S. 21%, West
Germany 7%, Italy 6%, Netherlands 7%, Japan 6%,
U.K. 6%; imports—U.S. 24%, West Germany 12%,
Japan 9%, U.K. 3%, Italy 3% (1974)
Aid: economic — extensions from U.S. (FY46-73)—
loans $4.3 billion, grants $655 million; from
23
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BRAZIL/BRITISH SOLOMON ISLANDS
international organizations (FY46-73) $3.0. billion:
from other Western countries (1960-71) $617.0
million; from Communist countries (1959-74) $330.6
million; drawings (1959-74) $120 million
Budget: (1974) revenues $11.3 billion, expenditures
$10.7 billion
Monetary conversion rate: 8.670 cruzeiros = US$1
(October 1975, changes frequently)
Fiscal year: calendar year
GDP: $29 million (1971)
Agriculture: largely dominated by coconut
production with subsistence crops of yams, taro,
bananas; self-sufficient in rice
Electric power: 5,600 kw. capacity (1974); 12
million kw.-hr. produced (1974), 66 kw.-hr. per capita
Exports: $10.3 million (1973); timber 40%, copra
30%, fish 17%
Imports: $12.0 million (1973)
Major trade partners: exports — Japan 42%, EEC
excluding U.K. 28%; imports—Australia 48%, Japan
12%, U.K. 11% (average 1972-74)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BRITISH SOLOMON ISLANDS/BRUNEI
Budget: (1971) revenues $9.8 million, expenditures
$9.9 million
Monetary conversion rate:
lar=US$$1.31 (1975)
GNP; $420 million (1974 est.), $2,800 per capita
Agriculture: main crops — rubber, rice, pepper,
must import most _food
Major industry: crude petroleum, liquefied natural
gas
Electric power: 84,000 kw. capacity (1974); 210
million kw.-hr. produced (1974), 1,354 kw.-hr. per
capita
Exports: $360 million (f.0.b. 1972); 96% crude
petroleum and liquefied natural gas
Imports: $88 million (c.i.f. 1972), 47% machinery
and transport equipment, 30% manufactured goods,
8% food
Major trade partners: exports of crude petroleum
and liquefied natural gas to Japan; imports from
Japan 30%, U.S. 24%, U.K. 15%, Singapore 9%
Monetary conversion rate: 2.54 Brunei dol-
lars = US$1
Fiseal year: calendar year','87f8fba929897ad46b2dfcc2209a789d8067b3c04f4e410fa7ab4211ad924123','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d3d5e0ecb4f27462b5b93fb3a53589888f2cf953b35318f963fc992349fa498',1976,'BG','Bulgaria','economy',82,'GNP: $17.6 billion, 1974 (at 1973 prices), $2,020
per capita, 1971-74 real growth rate 7.2%
Agriculture: mainly self-sufficient; main crops —
grain, vegetables; caloric intake, 3.000 calories per
day per capita (1969/70)
Fishing: catch 98,000 metric tons (1973)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BULGARIA/BURMA
Major industries: agricultural processing, machin-
ery, textiles and clothing, mining, ore processing,
timber
Shortages: some raw materials, metal products,
meat and dairy products; fodder
Crude steel: 2.2 million metric tons produced
(1974), 260 kg. per capita
Electric power: 6,084,000 kw. capacity (1974);
29.8 billion kw.-hr. produced (1974), 2,620 kw.-hr. per
capita
Exports: $3,838 million (f.o.b., 1974); 41%
machinery, cquipment, and_ transportation equip-
ment; 17% fuels, minerals, raw matcrials, metals, and
other industrial material; 3% agricultural raw
materials; 29% foodstuffs, raw materials for food
industry, and animals; 10% industrial consumer goods
(1974)
Imports: $4,283 million (f.0.b., 1974), 42%
machinery, cquipment, and transportation equip-
ment; 37% fuels, mincrals, raw materials, metals,
other materials; 8% agricultural raw materials; 8%
foodstuffs and animals; 6% industrial consumer goods
(1974)
Major trade partners: 27% with non-Communist
countries; 73% with Communist countries
Monetary conversion rate: (commercial) 0.97 leva,
(noncommercial) 1.20 leva = US$1 (April 1975)
Fiscal year: calendar year; economic data reported
for calendar years except for caloric intake, which is
reported for consumption year 1 July - 30 June
Note: foreign trade figures were converted at the
1974 rate of 0.97 leva= US$1
GDP: $2.9 billion (FY75, in current prices), $96 per
capita; real growth rate 3.5% (FY75)
Agriculture: main crops — paddy, sugarcane, corn,
peanuts; almost 100% self-sufficient; most rice grown
in deltaic land
Fishing: catch 446,000 metric tons (1972), $80
million (1971)
Major industries: agricultural processing; textiles
and footwear, wood and wood products; petroleum
refining
Electric power: 397,000 kw. capacity (1974); 720
million kw.-hr. produced (1974), 24 kw.-hr. per capita
Exports: $199 million (f.0.b., 1974); rice, teak
Imports: $125 million (c.i.f., 1974); machinery and
transportation equipment, textiles, other manufac-
tured goods
Major trade partners: exports — India, Western
Europe, U.K., Japan; imports — Japan, Western
Europe, India, U.K.
Budget: (FY75) $351 million revenues; $594
million expenditures; $243 million deficit; 30%
military, 70% civilian
Monetary conversion rate: 6.239 kyat = US$1
(official)
Fiscal year: 1 April - 31 March','b7a0e422e775df13acc0c54ffdc41fc4d73517c85d1a5dbe6401147739c7f996','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffdbafe046c34a40f42479510f1e770d58fa37f5d5e1a440f4bd060bb0bbf99b',1976,'BI','Burundi','economy',86,'GNP: about $227 million (1972 est.), $60 per capita
Agriculture: major cash crops — coffce, cotton;
main food crops — manioc, yams, corn, sorghums,
bananas, haricot beans; not self-sufficient
Industries: light consumer goods such as beverages,
shoes, soap
Electric power: 13,100 kw. capacity (1974); 26
million kw.-hr. produced (1974), 7 kw.-hr. per capita
Exports: $28 million (f.0.b., 1974); coffee, cotton,
hides, skins
Imports: $42 million (c.if., 1974); textiles,
foodstuffs, transport equipment, petroleum products
Major trade partners: U.S., Belgium, Congo;
much trade unrecorded
Aid: $17.7 million (1970), includes Belgium $7.4
million, U.N. $3.1 million, EDF $2.9 million; France
$2.0 million (1970); U.S. $10 million (FY61-73)
Budget: FY75—revenue $37 million, current
expenditure $34 million
Monetary conversion rate: 78.80 Burundi
francs = US$1 (official)
Fiscal year: calendar year','7660d29c366e874e7fe2e94d25c24cb870a9398308954430139bd2d724d63f40','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0cd55c99b98beafc3f3dd1bd3a87f91399e1d0984d4944bc85612c5ab0d2f3e',1976,'KH','Cambodia','economy',90,'GNP: $950 million (1971), $140 per capita (1971
prices); considerably lower in 1975
Agriculture: muinly subsistence except for rubber
plantations; main crops — rice, rubber, corn: food
shortages—rice, meat, vegetables, dairy products,
sugar, flour
Major industries: rice milling, fishing, wood and
wood products, textiles
Shortages: fossil fuels
Electric power: 122,000 kw. capacity (1974);
280,000 kw.-hr. produced (1974), 36 kw.-hr. per
capita
Exports: $15 million est. (f.0.b., 1974); rubber
Imports: $210 million est. (f.0.b., 1974): rice,
machinery and equipment, petroleum products,
transport equipment
Major trade partners: exports — Singapore,
Hong Kong, South Vietnam, imports — U.S., Japan,
France; negligible with Communist countries (1973)
Budget: (1974) revenues, 23.1 billion riels:
expenditures, 84.0 billion riels; deficit, 60.9 billion
tiels; 62% military, 38% civilian
Monetary conversion rate: not announced yet by
new Khmer Rouge government
Fiscal year: calendar year','3df1d559aca3253f8dd8aa55aee69db21d69d056d7f8931e8d981e1bf9e79e27','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6963a00e8646f8f0bc4929d1c851bba66664d2f23423ab5c5c1832e70a6a1d9b',1976,'CA','Canada','economy',96,'GNP: $126.6 billion (1974, in 1973 Prices), $5,650
per capita (1974): 57% consumption, 20% investment,
23% government (1974); growth rate 4.8% (1970-74).
constant prices
Agriculture: main products — livestock, grains
(principally wheat), dairy products; food shortages —
fresh fruits and vegetables; caloric intake, 3,180
calories per day per Capita (1966-67)
Fishing: catch .g million metric tons: exports 2
million metric tons (1974)
Major industries: mining, metals, food products,
wood and Paper products, transportation equipment,
chemicals
Shortages; rubber, rolled steel, textile fibers and
yarns, fruits, Precision instruments
Crude steel; 13.6 million metric tons produced
(1974)
Electric Power: 58,000,000 kw. Capacity (1974):
278.9 billion kw.-hr. produced (1974), 10,500 kw. -hr.
per capita
Exports: $34,228 million (f.0.b., 1974, UN.
source ); Principal items — transportation equipment,
wood and wood products, ferrous and nonferrous ores,
crude petroleum, wheat; Canuda is a major food
exporter
Imports: $34,573 million (cif, 1974, U.N. source):
Principal items — transportation equipment,
machinery, crude petroleum, communication
equipment, textiles, steel, fabricated metals, office
machines, fruits and vegetables
Major trade Partners: 66% US, 13% EC, 7%
Japan (1974)
Aid: economic — (received) ULS., $204 million
(FY49-73), $148 million (FY74), none (FY58-67).
Bross official aid to less developed countries and
multilateral agencies, $3,688 million (1960-73), 3637
million (1973): military — U.S., $13.1 million (FY49-
73), none since 196]
Budget: total revenues $30,013 million; current
expenditures $28 459 million; gross capital formation
$955 million; budget surplus $606 million (1974)
(National Accounts Basis)
Monetary conversion rate: there is no designated
par value for the Canadian dollar, which was allowed
Fiscal year; | April - 81 March
- 00800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CANADA/CAPE VERDE ISLANDS
GDP: $33.5 million (1973 est.), based on 1970
census of 272,000; $123 per capita income
Agriculture: main crops—corn, beans, manioc,
sweet potatoes; barely self-sufficient in food
Fishing: largely undeveloped but provides major
source of export earnings (4,858 metric tons in 1970)
Major industries: salt mining (17,590 tons 1970)
Electric power: 5,700 kw. capacity (1974), 6
million kw.-hr, produced (1974); 22 kw.-hr. per capita
Exports: $1.6 million (f.0.b., 1971); fish, bananas,
salt
Imports: $20.3 million (c.if., 1971); machinery,
textiles
Major trade partners: Portugal, African neighbors
Aid: Portugal, $20 million (1974), for civil service
salaries, food, medicines; U.S., $5 million (1975), for
food and employment of rural workers
Budget: (est. 1974) $32 million expenditures, $12
million revenues
Monetary conversion rate: 27 escudos = US$1
(September 1975)
Fiscal year: probably calendar year
33
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CAPE VERDE ISLANDS/CENTRAL AFRICAN REPUBLIC','d0f01d5ba5437dbb4421ee89e2d0331d6fd642c90ccaa4b67517e002f4bbc133','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3b627eac98db6502bb8f2062cacf2a06ceb8971a8485d820dcb04b170105a0f',1976,'CF','Central African Republic','economy',100,'GDP: $266 million (1974), $150 per capita
Agriculture: commercial — cotton, coffee,
peanuts, sesame, wood; main food crops — manioc,
corn, peanuts, rice, potatoes, beef; requires wheat,
flour, rice, beef, and sugar imports
Major industries: sawmills, cotton textile mills,
brewery, diamond mining and splitting
Electric power: 16,850 kw. capacity (1974): 50
million kw.-hr. produced (1974), 30 kw.-hr. per capita
Exports: $71 million (f.0.b., 1974), diamonds
(43%), coffee, cotton, lumber
Imports: $89 million (c.i.f., 1974 est.); textiles,
petroleum products, machinery and_ electrical
equipment, motor vehicles and equipment, chemicals
and pharmaceuticals
Aid: economic — U.S. (FY6I-73) $8.3 million:
(1972 est. disbursements) EC $6.4 million, IDA $3.9
million, U.S. $2.3 million, U.N, $1.2 million,
communist countries (1964-74) $6.8 million
Major trade partner: France: preferential tariff
applied to EC countries and frane zone; U.S,
Budget: 1974 budget estimates — receipt $65.4
million, current expenditure $71.7 million
Monetary conversion rate: 216 Communaute
Financiere Africaine francs = US$1 as of January 1975
(floating since February 1973)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CENTRAL AFRICAN REPUBLIC/CHAD
Fiscal year: calendar year','52be5ecd41714085e77c161608ed7e09a3e2884c3fc888639bab534845f9adff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b82626d8db1afc0f88d7d3939334ce7be457e4664ca541a354eb459f7211dd1',1976,'TD','Chad','economy',104,'GDP: $300 million (1971), $85 per capita;
estimated real annual growth rate 2.5% (1963-68)
Agriculture: commercial — cotton, gum arabic,
livestock, fish; food crops — peanuts, millet, sorghum,
rice, dates, manioc, wheat: imports food
Fishing: catch 120,000 metric tons (1971), $14
million; exports $300,000 (1969)
Major industries: agricultural and_ livestock
processing plants (cotton textile mill, slaughterhouses,
brewery), natron
Electric power: 24,800 kw. capacity (1974); 57
million kw.-hr. produced (1974), 15 kw.-hr. per capita
Exports: $38 million (f.0.b., 1973); cotton 65.7%
Imports: $82 million (cif., 1973); cement,
petroleum, foodstuffs, machinery, textiles, and motor
vehicles: $1.3 million from Communist. countries
(1967)
Major trade partners: France (about 40% in 1969)
and UDEAC countries; preferential tariffs to EC and
franc zone countries
Aid: major source France, $469 million, 1961-69;
EDF $393 million (1965-70); U.S. (FY62-73) $11.1
million; U.S.S.R. $4.1 million (1968-74); China, $50.1
million, 1971-74: military aid (1954-68) — $5.4
million, from France $4.1 million, remainder from
West Germany and Israel, more than $10 million
annually (est.) in French military aid (1969-71)
Budget: 1974 ordinary budget—$90 million
Monetary conversion rate: 218.75 Communaute
Vinanciere Africaine francs=US$1 as of August L975
(floating since February 1973)
Fiscal year: calendar year','f0f345ca3b16b964744b545205aee2d74e504174a96a842c90fbe2724a209b4a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac385f4bce5f7169fbef19fae9ce45bae9e8256eed0dcf10fae3ec7a3871aa08',1976,'CL','Chile','economy',106,'GDP: $8.11 billion (1974, in 1973 prices), $840 per
capita; 68% private consumption, 16% government
consumption, 19% gross investment, —3% net
imports and factor payments abroad (1972 est.); real
growth rate, 1970-74 average annual increase 2.8%
Agriculture: main crops — wheat, other cereals,
potatoes; about 65% self-sufficient; 2,650 calories per
day per capita (1971 est.)
Fishing: catch 664,000 metric tons (1973); exports
$20.3 million, imports $2.1 million (1972)
Major industries: copper, nitrates, foodstuffs, fish
processing, textiles and apparel, iron and steel, pulp
and paper
Crude steel: 0.7 million metric tons capacity
(1967); 596,000 metric tons produced (1974), 61 kg.
per capita
Electric power: 2,500,000 kw. capacity (1974); 9
billion kw.-hr. produced (1974), 900 kw.-hr. per
capita
Exports: $2.0 billion (f.0.b., 1974 est.); copper, iron
ore, nitrates, and iodine
Imports: $2.2 billion (c.i.f., 1974 est.); foodstuffs,
machinery and equipment, chemicals
Major trade partners: exports — EC 44%, Japan
14%, U.S, 8%, LAFTA 11%; imports — EC 28%,
U.S. 16%, Japan 3%, LAFTA 18% (1972)
Aid: economic — extensions from U.S. (FY46-73)
— $1,488.5 million ($1,265 million loans, $224
million grants); from international organizations
(FY46-73) — $600 million (of which IBRD $233
million, IDB $273 million); from other Western
countries (1960-66) — $170.6 million; from
Communist countries (1967-74) — $447.7 million;
military (FY53-73) — from U.S., $48 million in loans,
$137 million in grants
Budget: $1.9 billion revenues,
expenditures (1974)
Monetary conversion rate: 6.70 pesos=US$1
(October 1975), changes frequently
Fiscal year: calendar year
GNP: $223 billion (1974), $240 per capita
Agriculture: main crops — rice, wheat, miscellane-
ous grains, cotton; caloric intake, 2,000 calories per
day per capita (1974); agriculture mainly subsistence,
grain imports 7.0 million tons in 1974
Major industries: iron and steel, coal, machine
building, armaments, textiles
Shortages: complex machinery and equipment,
highly skilled scientists and technicians
Crude steel: 23.8 million metric tons produced, 26
kilograms per capita (1974)
Exports: $6.5. billion (f.o.b., 1974); agricultural
products, mincrals and metals, manufactured goods
Imports: $7.5 billion (cif, 1974); grain, chemical
fertilizer, industrial raw materials, machinery and
equipment
Major trade partners: Japan, U.S., Hong Kong,
West Germany, Singapore/Malaysia, Canada,
Australia, France, U.K., U.S.S.R. (1974)
Monetary conversion rate: about 2 yuan = US$1
(arbitrarily established)
Fiscal year: calendar year','f88f4b2394e1172442a30cc23beffeef908dcae382cf92dd5183b71c149bd3d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53f5054ad229f54e3eb9cc6ff9ffe776e8960f397acb15c785a6ee752f17d701',1976,'CN','China','economy',112,'GNP: $10.3 billion (1974, in 1973 prices), $660 per
capita; real growth, —9.4% (1970-74 average)
Agriculture: most arable land intensely farmed —
605 cultivated land under irrigation: main crops —
rice, sweet potatoes, sugarcane, bananas, pineapples,
citrus fruits; food shortages — wheat, corn, soybeans
Fishing: catch 697,425 metric tons (1974)
Major industries: textiles, clothing, chemicals,
plywood, electronics, sugar milling, food processing.
cement, ship building
Electric power: 4,450,000 kw. capacity (1974): 21
billion kw.-hr, produced (1974); 1,365 kw.-hr. per
capita
Exports: $5,623 million (f.0.b., 1974); textiles 26%.
electrical machinery 17%, plywood and) wood
machinery and metal products 7%,
plastics 6%, sugar 5%
Imports: $6,988 million (c.if., 1974); machinery
16%, electrical machinery 10%, basic metals 12%,
crude oil 10%, chemical products 9%
Major trade partners: exports—37% U.S.. 15%
Japan; imports—32% Japan, 24% U.S. (1974)
Aid: economic — U.S. (FY53-74) $3.1 billion
coramitted: IBRD (1964-74) $311 million committed;
Japan (1965-73) $247 million committed; ADB (1968-
74) $93 million committed; military—U.S, (FY49-74)
$3.5 billion committed
Budget: $2.3 billion (FY76)
Monetary conversion rate: NT$38 (New Tai-
wan)= US$]
Fiscal year: 1 July - 30 June
products 6%,
‘AY','48ea6c789fe91e944059a1337bb82fc87dd7ddfb0500d857769885877183fc59','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf3abbac1b80229898f57477c471ee7291ea1ea2e110442b81d5fd99713c805d',1976,'CO','Colombia','economy',116,'GNP: $10.52 billion, est. (1974, in 1973 prices),
$420 per capita; 73% private consumption, 8% public
consumption, 20% gross investment (1973); real
growth rate 1974, 5.6%.; average real growth rate,
1971-74, 6.38%
Agriculture: main crops — coffee, rice, corn,
sugarcane, plantains, bananas, cotton, tobacco;
caloric intake, 2,140 calories per day per capita (1970)
Fishing: catch 91,200 metric tons 1972; exports
$4.7 million (1969), imports $5.9 million (1969)
Major industries: textiles, food processing, clothing
and footwear, beverages, chemicals, and metal
products
Crude steel: 0.39 million metric tons production
(1972), 17 kilograms per capita
Electric power: 3,200,000 kw. capacity (1974);
11.9 billion kw.-hr. produced (1974), 480 kw.-hr. per
capita .
Exports: $1.6 billion (f.0.b., 1974 est.); coffee,
petroleum, cotton, tobacco, sugar, textiles, cattle and
hides
Imports: $1.7 billion (c.i.f., 1974 est.); transporta-
tion equipment, machinery, industrial metals and raw
materials, chemicals and pharmaceuticals, fuels,
fertilizers, paper and paper products, foodstuffs and
beverages
Major trade partners: exports — U.S. 36%,
Germany 16%, Spain 7%; imports — U.S. 40%,
Germany 10%, Japan 8%, Spain 4% (1973)
Aid: economic — extensions from U.S. (FY46-73),
$1,296 million loans, $270 million grants; from
international organizations (FY46-73), $1.6 billion;
from other Western countries (1960-71), $77.6
million; from Communist countries (1968-74) $24.5
million ($2.7 million drawn) military — assistance
from U.S. (FY46-73) — $142 million
Budget: (1974) revenues $860 million; expenditures
$960 million
Monetary conversion rate: 30.361 pesos=US$1
(April 1975, changes frequently)
Fiscal year: calendar year
GDP: about $23 million (1968); $100 per capita;
growth probably negligible through 1974
Agriculture: food crops — rice, manioc, potatoes,
fruits, vegetables; export crops — essential oils for
perfumes (mainly ylang-ylang), vanilla, copra, sisal
Exports: $6.0 million (1972); perfume oils, vanilla,
copra, sisal
{mports: $11.3 million (1972); foodstuffs, cement,
fuels, chemicals, textiles
Major trade partners: France, Malagasy Republic,
Italy, Kenva, Tanzania and USS.
Electric power: 1,000 kw. capacity (1974), 3.2
million kw.-hr. produced (1974); 11 kw.-hr. per capita
Aid: French aid in 1971 was about $2.7 million, or
about 50% of the islands entire budget
Budget: 1972—revenues $7.6 million, current
expenditures $6.2 million, investment expenditures
$0.7 million
Monetary conversion rate: 216 Communaute
Financiere Africaine (CFA) francs=US$1 as of
January 1975 (floating since February 1973)
GDP: about $277 million (1970 est.), $310 per
capita, real growth rate about 4% per year
Agriculture: cash crops — sugarcane, wood, coffee,
cocoa, palm kernels, peanuts, tobacco; food crops —
root crops, rice, corn, bananas, manioc, fish
Fishing: catch 21,000 metric tons, $5.6 million
(1972)
Major industries: sawmills, brewery, cigarettes,
sugar mill, soap
Electric power: 42,000 kw. capacity (1974); 120
million kw.-hr. produced (1974), 90 kw.-hr. per capita
Exports: $62 million (f.0.b., 1973); lumber, sugar,
tobacco, vencer, and plywood
Imports: $85 million (c.i.f., 1973); machinery,
transport equipment, manufactured consumer goods,
iron and steel, foodstuffs, petroleum products
43
001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010
January 1976
CONGO/COOK ISLANDS
Major trade partners: France and other FC
countries on preferential basis
Budget: 1973—revenue $82 million, expenditure
$104 million
Monetary conversion rate: 216 Communaute
Financicre Africaine francs =US$1 us of January 1975
Fiscal year: calendar year','128a710ee3c8a1ea8ad042707281bba686f3ed2f266a55c48410debaf9312788','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f23f6c1b64917a088deb1cde0559df8dff76d0227094653ad330fa6be100c906',1976,'CK','Cook Islands','economy',120,'GDP: $400 per capita (1973)
Agriculture: export crops include copra, citrus
fruits, pineapple, tomatoes, and bananas, with
subsistence crops of yams and taro
Industry: fruit processing
Electric power: 2,800 kw, Capacity (1974): §
million kw.-hr, produced (1974), 38] kw.-hr. per
capita
Exports: $2.7 million (1971): fruit juice, clothing,
citrus fruits
Imports: $5.8 million (1971)
Major trade partners; (1970) exports — 98% New
Zealand, imports — 76% New Zealand. 7% Japan
Monetary conversion rate: 1 NZ$=US$1.3535
(February 1975)','54a4e7e473be1917d76429fea9f9ea9959904e2b58d488df8a418c237df638a5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('316e7649e4aba3d956363a47367dd96268c80f688ab3642b05e260bd95ed00ce',1976,'CR','Costa Rica','economy',124,'GNP: $1.5 billion (1974, in current prices), $770 per
capita; real growth rate 1974, 4%; average growth
1969-73, 6.4%
Agriculture: main products — bananas, coffee,
sugarcane, rice, corn, cocoa, livestock products;
caloric intake, 2,610 calories per day per capita (1966)
Fishing: catch 8,900 metric tons, $2.5 million
(1972); exports, $1.8 million (1970), imports $0.5
million (1970)
45
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
COSTA RICA/CUBA
Major industries: food processing, textiles and
clothing, construction materials, fertilizer
Electric power: 321,000 kw. capacity (1974): 1.4
billion kw.-hr. produced (1974), 720 kw.-hr. per
capita
Exports: $441 inillion (f.o.b., 1974); coffee,
bananas, beef, sugar, cacao
Imports: $716 million (c.if., 1974): manufactured
products, machinery, transportation equipment,
chemicals, fuels, foodstuffs, fertilizer
Major trade partners: exports—33% U.S.. 25%
CACM, 13% West Germany: imports—35% U-S.,
20% CACM, 7% West Germany, 9% Japan (1973)
Aid: economic — extensions from U.S. (FY46-73),
$122 million loans, $101
international organizations (FY46-73), $203 million;
from other Western countries (1960-71 ), $7.7 million;
inilitary — assistance from U.S. (FY60-73) $1.9
million; Communist—$15 million (economic) from
US.S°R. (1971)
Monetary conversion rate: 8.54 colones = US$1
(official buying rate); 8.60 colones=US$1 (official
selling rate)
million grants; from
Fiscal year: calendar year
GDP: $6.1 billion (1974 est., in 1974 prices), $670
per capita; 60% private consumption, 20% public
consumption, 20% gross investment, real growth rate
1974, 5%
Agriculture: main crops — sugar, tobacco, coffee,
rice, potatoes, tubers, citrus fruits
Fishing: catch 163,000 metric tons (1974); exports
$50 million (1974), imports $18.1 million (1972)
Major industries: sugar milling, petroleum
refining, food and tobacco processing, textiles,
chemicals, paper and wood products, metals
Shortages: spare parts for transportation and
industrial machinery, consumer goods
Crude steel: 0.35 million metric tons capacity
(planned); 220,600 metric tons produced (1973); 20
kg. per capita
Electric power: 1,216,000 kw. capacity (1974); 5.6
billion kw.-hr. produced (1974), 650 kw.-hr. per
capita
Exports: $2,745 million (f.0.b., 1974 cst.); sugar,
nickel, tobacco
Imports: $2,450 million (c.iif., 1974 est.); capital
goods, industrial raw materials, food, petroleum
Major trade partners: exports — U.S.S.R. 34%,
China 5%, other Communist countries 15%, Japan
16%; imports—U.S.S.R. 48%, China 7%, other
Communist countries 10% (1974 est.)
Monetary conversion rate: 1 peso = US$1.21
(nominal)
Fiscal year: calendar year','1c096b4bcaeab32547777b2ab2e413138678dbadb637bef40c4c51315d7caa54','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21fd0c893d7fffd02cb92c95d4f23c03c9b17d34cb3cc9f1322f2a9eef4da75f',1976,'CY','Cyprus','economy',128,'GNP: $871.0 million (1974), $1,300 per capita;
1974 real growth rate 2.0%
Agriculture: main crops — vine products, citrus,
potatoes, other vegetables; food shortages — grain,
dairy products, meat, fish; caloric intake, 2,460
calories per day per capita (1964-66)
Major industries: mining (cupreous and iron
pyrites, asbestos), manufactures principally for local
consumption — food, beverages, footwear
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CYPRUS/CZECHOSLOVAKIA
Shortages: water, petroleum
Electric power: 204,000 kw. capacity (1974); 830
million kw.-hr. produced (1974), 985 kw.-hr. per
capita
Exports: $160 million (f.0.b., 1974—converted at
average trade conversion factor of 1 Cyprus
pound = US$2.85); principal items — copper, pyrites,
citrus, raisins, and other agricultural products
Imports: $400 million (c.i.f., 1974—converted at
average trade conversion factor of 1 Cyprus
pound = US$2.85); principal items — manufactured
goods, machinery and transport equipment,
petroleum products, foods
Major trade partners: (1973) imports — U.K. 25%,
West Germany 9%, Italy 8%, France 7%, U.S. 7%:
exports — U.K. 42%, West Germany 7%, Nether-
lands 4%, U.S.S.R. 4%
Aid: economic — U.S., $32.5 million authorized
FY46-73; IBRD, $56.1 million (FY46-73); U.N.
Technical Assistance, $1.7 million (FY46-72); U.N.
Special Fund, $9.9 million (FY46-72)
Budget: 1974—revenues $137 million, expenditures
$263 million, deficit $126 million
Monetary conversion rate: 1 Cyprus pound=
US$2.61 (December 1971 through January 1973), 1
Cyprus pound = US$2.823 (trade conversion factor as
of May 1975)
Fiscal year: calendar year
NOTE: 1974 GNP, import, export, and budget
figures are Government of Cyprus figures which
include 100% of island until August 1974 and 60% of
island thereafter; the Turkish sector of island for last 4
months of 1974 is part of Turkish mainland economy
GNP: $43.6 billion in 1974 (at 1973 prices), $2,970
per capita; 1974 real growth rate 4.6%
Agriculture: diversified agriculture; main crops —
wheat, rye, potatoes, sugar beets; net food importer —
meat, wheat, vegetable oils, fresh fruits and
vegetables; caloric intake, 3,100 calories per day per
capita (1967)
Major industries: machinery, food processing,
metallurgy, textiles, chemicals
Shortages: ores, crude oil
Crude steel: 13.6 million metric tons produced
(1974), 930 kg. per capita
Electric power: 12,796,000 kw. capacity (1974); 56
billion kw.-hr. produced (1974), 3,800 kw.-hr. per
capita
Exports: $7,033 million (f.0.b., 1974); 50%
machinery, equipment; 28% fuels, raw materials; 4%
foods, food products, and live animals; 18% consumer
goods, excluding foods (1973)
Imports: $7,504 million (f.o0.b., 1974); 37%
machinery, equipment; 43% fuels, raw materials; 138%
foods, food products, and live animals, 7% consumer
goods, excluding foods (1973)
Monetary conversion rate: noncommercial 9.27
crowns =US$1, commercial 5.43 crowns = US$1
(average through July 1975)
an Approved For Release 2005/04/22
Fiscal year: calendar year
Note: foreign trade figures were converted at the
rate of 5:80 crowns = US$1
GNP: $349 million (1974), $111 per capita; real
growth rate, 4.6% per annum (1967-71)
Agriculture: major cash crop is oil palms; peanuts,
cotton, coffee, sheanuts, and tobacco also produced
commercially; main food crops — corn, cassava,
yams, sorghum and millet; livestock, fish
Fishing: catch 32,900 metric tons (1971); exports
122.2 metric tons, imports 4,000 metric tons
Major industries: palm oil and palm kernel oil
processing
Electric power: 11,310 kw. capacity (1974); 50
million kw.-hr. produced (1974), 16 kw.-hr. per capita
Exports: about $43 million (f.0.b., 1974); palm
products (34%); other agricultural products
Imports: $126 million (c.i.f., 1974); clothing and
other consumer goods, cement, lumber, fuels,
foodstuffs, machinery, and transport equipment
Major trade partners: France, EC, frane zone;
preferential tariffs to EC and franc zone countries
Aid: economic (through FY73) — EC, $4.5 million;
U.N., $8.9 million; West Germany, $1 million;
Taiwan, $1 million; U.S. (FY59-73), $14.7 million;
China, $44 million extended (1972)
Budget: 1974 est. — receipts $48 million,
expenditures $52.2
Monetary conversion rate: 216 Communaute
Financiere Africaine francs = US$1 as of January 1975
Fiscal year: calendar year','9eb8d6b71b7f5aa054de82e0b324b9c7bd6201a7314231a3de56765fa13226e9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3081bacc89dd374dff8c065f757a812452194d5a621bc93a2f3f75300eb78ee3',1976,'DK','Denmark','economy',132,'GNP: $27.3 billion (1974), $5,410 per capita; 54%
private consumption, 26% investment, 20% govern-
ment; 1974 growth rate 1.5%, constant prices
Agriculture: highly intensive, specializes in
dairying and animal husbandry; main crops —
cereals, root crops; food shortages — oilseeds, grain,
feedstuffs; caloric intake, 3,180 calories per day per
capita (1968-69)
Fishing: catch 1.44 million metric tons valued at
$211 million, exports $391 million (1973)
Major industries: food processing, machinery and
equipment, textiles and clothing, chemical products,
electronics, transport equipment, metal products,
brick and mortar, furniture and other wood products
Shortages: most industrial raw materials and fuels
Crude steel: 449,000 metric tons produced (1973),
90 kg. per capita
Electric power: 5,588,000 kw. capacity (1974);
18.7 billion kw.-hr. produced (1974), 2,900 kw.-hr. per
capita
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
DENMARK/ DOMINICA
Exports: $7,697 million (f.o.b., 1974); principal
items — meat, dairy products, industrial machinery
and cquipment, textiles and clothing, chemical
products, transport equipment, fish, furs, and
furniture
Imports: $9,919 million (c.i-f., 1974); principal
items — industrial machinery, transport equipment,
petroleum, textile fibers and yarns, iron and steel
products, chemicals, grain and feedstuffs, wood and
paper
Major trade partners: EC-nine 44.37% (U.K.
13.60%; West Germany 16.01%); Sweden 14.71%,
U.S. 5.90%; Communist countries 3.90% (1974)
Aid: economic — U.S., $343 million authorized
FY46-73: IBRD, $85.0 million through 1973, none
since 1964; net official economic aid given to less
developed areas and multilateral agencies, $250.5
million (1960-70), $58.3 million (1969), $63.2 million
(1970), $80 million (1971 provisional); military —
U.S., $626 million (FY49-73)
Budget: (1974) expenditures $11.0 billion, revenues
$11.3 billion
Monetary conversion rate: 1 Kroner = US$0. 164,
1974, average exchange rate
Fiscal year: 1 April - 31 March
Government budget: Colony — revenues, $1.0
million (FY68); expenditures, $1.1 million (FY68)
Agriculture: Colony — predominantly sheep
farming; dependencies — whaling and sealing
Major industries: Colony — wool processing;
dependencies — whale and seal processing
Electric power: 1,200 kw. capacity (1974); 2.3
million kw.-hr. produced (1974), 1,100 kw.-hr, per
capita
Exports: Colony — $2.28 million (1969); wool,
hides and skins, and other; dependencies — no exports
in 1968 or 1969
Imports: Colony — $1.22 million (1969); food,
clothing, fuels, and machinery; dependencies —
$8,368 (1969); mineral fuels and lubricants, food, and
machinery
Major trade partners: nearly all exports to the
U.K., also some to the Netherlands and to Japan;
imports from Curacao, Japan, and the U.K.
Monetary conversion rate: 1 Falkland Island
pound = US$2.60','238e1ba556335a6bcb1fd934cebca73516fba1fcb00f5e4463f404bb3c8e4d5a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9fa790168db1ef79c4010d533d955ef7c49f249f5e0d56083aabd956b19bdea',1976,'DM','Dominica','economy',136,'GDP: $21.0 million (1971 est. ), $270 per capita;
8.8% increase in 1971 — including price changes
Agricultural products: bananas, citrus, coconuts,
cocoa
Major industries: agricultural processing, tourism
Electric power: 5,500 kw. capacity (1974); 16
million kw.-hr. produced (1974), 230 kw.-hr. per
capita
Exports: $6.1 million (f.0.b., 1970): bananas, lime
juice and oil, cocoa, reexports
Imports: $16.3 million (c.if., 1970); machinery
and equipment, foodstuffs, manufactured articles
Major trade partners: U.K. 53%, Commonwealth
Caribbean countries 15%, Canada 10%, U.S. 7%
(1963)
Monetary conversion rate: 2.07 East Caribbean
dollars = US$1 (May 1975), now floating with pound
sterling','e6ec4ffe2226c3b3c208ce4fc2296d49c101c28038c7b4ba86e078d85fbff66a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dec0ae5ee4b1e43e54661acd924a5342ffe6f8b50fbf81e98f11e075b045a395',1976,'DO','Dominican Republic','economy',140,'CNP: $3.0 billion (1974), $660 per capita, real
growth rate 1974, 8.8%
Agriculture: main crops — sugarcane, coffee,
cocoa, tobacco, rice, corn; self-sufficient in rice;
caloric intake, 2,200 calories per day per capita (1966)
Major industries: sugar processing, nicke] mining,
bauxite mining, peanut processing, textiles, cement
Electric power: 356,665 kw. capacity (1974); 1.4
billion kw.-hr. produced (1974), 310 kw.-hr. per
capita
Exports: $637 million (f.0.b., 1974); sugar, nickel,
coffee, tobacco, cocoa, bauxite
Imports: $774 million (c.i.f., 1974); foodstuffs,
petroleum, industrial raw materials, capital
equipment
Major trade partners: exports—U.S. 56% (1974);
imports—U.S. 60% (1974)
Aid: economic — from US. (FY46-73), $224
million in grants, $297 million in loans; from
international organizations (FY46-72), $147 million,
from other western countries (1960-71), $11.7 million
military — assistance from U.S. (FY53-73), $33
million
Monetary conversion rate: 1 peso= US$1
Fiscal year: calendar year','505a28832bacea29cd9183dea679fa10f38c933cd51228ffa66f249414672f9f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52865d0b9be3229ebdcca4d96ffe621ddb4a967fb823159bef125ff8dd6137ea',1976,'EC','Ecuador','economy',144,'GNP: $3.1 billion (1974), $450 per capita; 62%
private consumption, 16% public consumption, 22%
gross investment (1974 est.); real growth rate 1974,
14%
Agriculture: main crops — bananas, coffee, cocoa,
sugarcane, cotton, corn, potatoes, rice; caloric intake,
1,970 calories per day per capita (1970)
Fishing: catch 105,000 metric tons (1971); exports
$30.0 million (1973), imports negligible (1971)
Major industries: food processing, textiles,
chemicals, fishing, petroleum
Electric power: 390,000 kw. capacity (1974): 1.4
billion kw.-hr. produced (1974), 184 kw.-hr. per
capita
Exports: $834 million (f.0.b., 1974): bananas,
petroleum, coffee, cocoa, sugar, fish products
Imports: $602 million (f.0.b., 1974); agricultural
and industrial machinery, wheat, petroleum products,
chemical products, transportation and communica-
tion equipment
Major trade partners: exports — U.S. 35%, EC
15%, Japan 5%, imports—U.S. 83%, EC 26%, Japan
11% (1973)
Aid: economic — extensions from U.S. (FY46-73),
$209 million loans, $118 million grants; from
international organizations (FY46-73), $273 million;
from Communist countries (1967-74), $15.4 million
loans; military — assistance from U.S. (FY49-72), $63
million
Budget: $600 million
Monetary conversion rate: 25.25 sucres=US$1
(official selling rate)
Fiscal year: calendar year
GNP: $9 billion (1974 est., in 1973 prices), $240 per
capita; inter war annual growth rate of 1% or less
accelerated to 4%-5% since 1973
Agriculture: main cash crop — cotton; other crops
— rice, onions, beans, citrus fruit, wheat, corn, barley;
not self-sufficient in food, but agriculture a net earner
of foreign exchange
Major industries: textiles, food processing,
chemicals, petroleum, construction, cement
Electric power: 4,476,000 kw. capacity (1974); 8
billion kw.-hr. produced (1974), 220 kw.-hr. per
capita
Monetary conversion rate: 1 Egyptian pound=
US$2.54 (selling rate); 0.394 Egyptian pound =US$1
(selling rate)
Fiscal year: calendar year, beginning in 1973','249185fcaad994106b52e8719b5ae346446bf0b006bf2e9ad124b1280b741c2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60f1e9fac9c495151a3a6e201ffc10a6b4b0346be3ad9c4b51e9042ef6fc0855',1976,'SV','El Salvador','economy',148,'GNP: $1.6 billion (1974 est.), $410 per capita; 78%
private consumption, 11% government consumption,
20% domestic investment, —9% net foreign balance
(1974 cst.); real growth rate 1974, 5.7%
Agriculture: main crops — coffee, cotton, corn,
sugar, rice, beans; caloric intake, 2,000 calories per
day per capita (1963-64)
Fishing: catch 15,600 metric tons (1972); exports
$6.0 million (1971), imports $0.5 million (1972)
Major industries: food processing, textiles,
clothing, petroleum products
Electric power: 225,000 kw. capacity (1974); 860
million kw.-hr. produced (1974), 225 kw.-hr. per
capita
Exports: $463 million (£.0.b., 1974); coffee, cotton,
sugar
Imports: $562 million (c.i.f., 1974); machinery,
automotive vehicles, petroleum, food-stuffs, fertilizer
Major trade partners: exports — U.S. 33%, CACM
32%, EC 18%, Japan 10% (1973); imports—U.S.
30%, CACM 20%, EC 20%, Japan 7% (1974)
Aid: economic — from U.S. (FY46-73), $90.6
million loans, $67.2 million grants; from international
organizations (FY46-73), $193 million; from other
Western countries (1960-71) $9.8 million; military —
assistance from U.S. (FY53-73), $8 million
Budget: $426 million
Monetary conversion rate: 2.5 colones= US$1
(official)
Fiscal year: calendar year
Approved For Release 2005/04/22 :','44d859dabbb66f27c60d02a362b333b66b98a2facc2c7597bf03d1d27683ff87','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b3577218497c894d736a20426e33179c828418433a8089bde773f3eb3bc05c1',1976,'ET','Ethiopia','economy',152,'GDP: $2,450 million (1972), $80 per capita;
average annual real growth rate 4% (1967-72)
Agriculture: main crops — coffee, teff, durra,
barley, wheat, corn, sugarcane, cotton, pulses,
oilseeds; livestock
Major industries: cement, sugar refining, cotton
textiles, food processing, oil refinery
Electric power: 384,000 kw. capacity (1974); 673
million kw.-hr. produced (1974), 25 kw.-hr. per capita
Exports: $267 million (f.0.b., 1974); coffee 27%,
pulses 17%, hides and skins 8%, oilseeds, oilcakes, and
nuts 20%; $4.6 million to Communist countries (1971)
Imports: $2738 million (cif, 1974); metals,
machinery and vehicles 47%, petroleum and
chemicals 17%, foodstuffs, live animals, and
beverages 7%; $9.7 million from Communist countries
(1970)
Major trade partners: imports — Italy, Japan,
West Germany, and U.S.; exports — U.S., West
Germany, Italy, Saudi Arabia, Japan
Monetary conversion rate: 9.09 Ethiopian
dollars = US$1
Fiscal year: 8 July -7 July
GDP: $90.9 million (1971), about $2,270 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 208,000 metric tons; exports, $60
million (1973)
Major industry; fishing
Electric power; 28,000 kw. capacity (1974). 39
million kw.-hr. produced (1974), 1,800 kw.-hr. per
capita
Exports: $79 million (f.0.b., 1978); fish and fish
products
Imports: $68 million (cif, 1973). machinery and
transport equipment, petroleum and petroleum
products, food products
Major trade partners: (1972) Denmark 47%, EC-
six 12%, U_K. 8%, U.S. 8%, Norway 4%, Sweden 4%
Budget: (FY72) expenditures $29 ] million,
revenues $22.4 million
- 00800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FAEROE ISLANDS/FALKLAND ISLANDS (MALVINAS)
Monetary conversion rate: 1| Danish Kroner=
US$0.164 (1974)
Fiscal year: 1 April - 31 March','ee7eb98c32d566fef393dec5313337ba5f43d1183301ff06646e6c29f4952949','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e78a86720a8fe6fcde0ceb3709beccdaf5e3df20fb4900b9391c0f08049e0940',1976,'FJ','Fiji','economy',156,'GNP: $329 million (1973), $600 per capita; 6.8%
real growth rate (1971-73)
Agriculture: main crops — sugar, coconut
products, bananas, rice; major deficiency, grains
Major industries: sugar processing, tourism
Electric power: 76,000 kw. capacity (1974); 230
million kw.-hr. produced (1974), 410 kw.-hr. per
capita
Exports: $154 million (f.0.b., 1974, including
reexports); sugar 48%, copra 8%, copper 8%
Imports: $271 million (cif., 1974); machinery
25%, manufactured goods 25%, food 20%
Major trade partners: exports—U.K. 40%,
Australia 14 %, U.S. 14%, Canada 11%: imports—
Australia 30%, Japan 16%, U.S. 14%, New Zealand
12%
Aid: disbursed 1968 — Australia $1.5 million, U.S.
$0.6 million, U.K. $4.2 million
Monetary conversion rate:
lar = US$1.2774 (April 1975)
Fiscal year: calendar year','c404e9316fb3086f49c7dfb4c54196c405907adcd51440347a69f478de668313','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90265a4f24aeb114cf160ecf529e052e8b3088fb861df23d1f6c8d3626f7dc34',1976,'FI','Finland','economy',160,'GNP: $21 billion (1974), $4,500 per capita; 51.8%
consumption, 31.6% investment, 22.6% government,
—6.0% net exports of goods and services; 1974 growth
rate 5.2%, constant prices
65
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FINLAND/FRANCE
Agriculture: animal husbandry, especially
dairying, predominates; forestry important secondary
occupation for rural population; main crops —
cereals, sugar beets, potatoes; 85% self-sufficient;
shortages — food and fodder grains; caloric intake
2,940 calories per day per capita (1970-71)
Major industries: include metal manufacturing
and shipbuilding, forestry and wood processing (pulp,
paper), copper refining
Shortages: fossil fuels; industrial raw materials,
except wood, and iron ore
Crude steel: 1.7 million metric tons produced
(1974), 370 kilograms per capita
Electric power: 7,294,720 kw. capacity (1974);
27.4 billion kw.-hr. produced (1974), 5,800 kw.-hr. per
capita
Exports: $5:5 billion (f.0.b., 1974); timber, paper
and pulp, ships, machinery, iron and steel, clothing
and footwear
Imports: $6.8 billion (c.i.f., 1974); foodstuffs,
petroleum and petroleum products, chemicals,
transport equipment, iron and _ steel, machinery,
textile yarn and fabrics
Major trade partners (1974): 40% EC-nine (12%
West Germany, 13% U.K.); 18% Sweden; 16%
U.S.S.R.; 6% U.S.
Aid: U.S. $182 million authorized FY46-73, $22.1
million in FY71, none in 1972, 1.5 million in 1973;
1BRD—$296.5 million authorized through 1946-73,
$20 million in 1973; Finnish foreign aid programs
have amounted to $23 million 1961-69, $15,000 in
1970
Budget: (1974) expenditures $5.2 billion, revenues
$5.4 billion
Monetary conversion rate: new markka (Fmk)
3.75 = US$1 (1974 trade conversion factor, IMF)
Fiscal year: calendar year','cb6eada2564e6d531d3d952bafc12624d26b0bb1fc80d9dde4630e3b700f37a4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6244c0a9fc6fa520ff2d8dc5b942018955d92b22ae4d6b48bbf36fb5ea3dd0de',1976,'FR','France','economy',164,'GNP: $275.4 billion (1974), $5,230 per capita;
60.6% consumption, 28.3% investment (including
government), 12.4% government consumption;
—1.3% net foreign balance (1974); 1974 real growth
rate 3.8%
Agriculture: Western Europes foremost producer;
main products — beef, cereals, sugar beets, potatoes,
wine grapes; self-sufficient for most temperate zone
foodstuffs; food shortages — fats and oils, tropical
produce; caloric intake, 3,270 calories per day per
capita (1969-70)
Fishing: catch 783,000 metric tons, $380 million
(1972); exports $64 million, imports $300 million
(1972)
Major industries: steel, machinery and equipment,
textiles and clothing, chemicals, food processing,
metallurgy
Shortages: crude oil, textile fibers, most nonferrous
ores, coking coal, fats and oils
Crude steel: 27.0 million metric tons produced
(1974), 513 kilograms per capita
Electric power: 45,200,000 kw. capacity (1974);
188.3 billion kw.-hr. produced (1974); 3,000 kw.-hr.
per capita
Exports: $46.4 billion (f.0.b., 1974); principal items
— machinery and transportation equipment,
foodstuffs, agricultural products, iron and _ steel
products, textiles and clothing, chemicals
Imports: $52.1 billion (c.if., 1974); principal items
— crude petroleum, machinery and equipment,
chemicals, iron and _ steel products, foodstuffs,
agricultural products
Major trade partners: West Germany 18%;
Belgium-Luxembourg 11%; Italy 9%; US. 6%;
Netherlands 5%; U.K. 5%, Eastern Europe 3%;
U.S.S.R. 1%; Frane Zone 4%
Aid: economic (received) — U.S., $5,382 million
authorized (FY46-78), $44 million in FY73; military
— US., $4,855 million authorized (FY46-73), net
official economic aid to less developed areas and
multilateral agencies — $8,400 million (FY60-70),
$1,125 million in 1971, $457 million in 1974
Budget: (1974) expenditures 236.7 billion francs,
revenues 240.5 billion francs, surplus 3.8 billion francs
Monetary conversion rate: | franc=U$$0.2079
(1974 average)
Fiscal year: calendar year
67
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
1-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00080001000
January 1976
FRANCE/FRENCH GUIANA','270154ed865c98f7e4f75fd056cff6e336ee8a271dd01ca9d38f344b60051c56','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('449f86b1fafe0c239f8d28a6ad08201463ad336dd7e4d5af443d522fc2b7bfc9',1976,'GF','French Guiana','economy',168,'GNP: $40 million (at market prices, 1970), $800 per
capita
Agriculture: main crops — rice, corn, manioc, -
cocoa, bananas, sugarcane
Fishing: catch 1,300 metric tons (1972); shrimp
exports $3.9 million; imports $2.3 million (1969)
Major industries: timber, rum, gold mining,
production of rosewood essence, and space center
Electric power: 28,600 kw. capacity (1974); 56
million kw.-hr. produced (1974), 1,080 kw.-hr. per
capita
Exports: $5 million (f.0.b., 1973); shrimp, timber,
rum, rosewood essence
Imports: $56 million (c.i.f., 1973); food (grains,
processed meat), other consumer goods, producer
goods and petroleum
Major trade partners: exports — U.S. 78%, France
11%, Martinique 5%; imports — France 49%, US.
10%, Trinidad and Tobago 3% (1969)
Monetary conversion rate: 4.44 French francs =
US$1 (1973)
Fiscal year: calendar year','354f99da022693f8ca3ac71587a125180b53a5d78db506720b9eda4fc20fbc4a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f5ae7a0a4d3a3b76120080339a1fc3bd815905fef0b9c4ee9ea526db6db7c66',1976,'PF','French Polynesia','economy',172,'GDP: $259 million (1970) $1,963 per capita (1971)
Agriculture: coconut main crop
Major industries: maintenance of French nuclear
test base, tourism
Electric power: 36,000 kw. capacity (1974); 79
million kw.-hr. produced (1974), 577 kw.-hr. per
capita
69
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FRENCH POLYNESIA/FRENCH TERRITORY OF THE AFARS AND ISSAS
Exports: $19 million (1973); principal products —
coconut products (79%), mother-of-pearl (14%)
(1971)
Imports: $211 million (1973)
Major trade partners: imports — 59% France, 14%
U.S.; exports — 86% France
Aid: France $16 million (1973)
Monetary conversion rate: 100 CFP = 1 NZ$ (1971)
Gross territorial product: $68 million (1970)
Agriculture: livestock; desert conditions limit
commercial crops to about 15 acres, including fruits
and vegetables
Industry: ship repairs and services of port and
railroad
Electric power: 23,200 kw. capacity (1974); 56.3
million kw.-hr. produced (1974), 470 kw.-hr. per
capita
Imports: $60 million (1972), almost all domes-
tically needed goods
Exports: $27 million, including perhaps $18 million
of transit trade (1972); hides and skins, and transit of
coffee
Aid: $2.4 million in 1967 from France
Monetary conversion rate: 177 Djibouti francs =
US$1
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FRENCH TERRITORY OF THE AFARS AND I1SSAS/GABON
Fiscal year: probably same as that for France
(calendar year)
GNP: $193 million, $1,800 per capita (1971 est.)
Agriculture: large areas devoted to cattle grazing;
major products — coffee and vegetables; 60% self
sufficient in beef; must import grains and vegetables
Industry: mining of nickel
Electric power: 261,000 kw. capacity (1974); 1.6
billion kw.-hr. produced (1974), 12,698 kw.-hr. per
capita
Exports: $263 million (f.0.b., 1974); 99% nickel
Imports: $283 million (c.if., 1974); machinery,
transport equipment, food
Major trade partners: (1972) exports — France
55%, Japan 24%, U.S. 11%; imports — France 52%,
Australia 13%, rest of EEC 12%
Monetary conversion rate: 86 CFP francs = US$1
(1972)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NEW CALEDONIA/NEW HEBRIDES/NEW ZEALAND
Agriculture: export crops of copra, cocoa, coffee,
some livestock and fish production; subsistence crops
of copra, taro, yams
Electric power: 4,200 kw. capacity (1974); 11
million kw.-hr. produced (1974), 122 kw.-hr. per
capita
Exports: $14 million (1973); copra, frozen fish
Imports: $28 million (1973)
Monetary conversion rate: 1 pound=US$2.37
(official currency), 0.74 Australian $=US$1, 86
Colonial Franc Pacifique (CFP)=US$1 (1972)','01e505f52cb7c47a02702d02d85251e9d07f88ba902d8bf2e902b75b4a6a5038','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a60c2484138e2ba44d54515aae39f46168ef4059f20df987d336ce157ed8c02c',1976,'GA','Gabon','economy',176,'GDP; $1,389 million (1974 est. ), $2,671 per capita;
87% growth (1973-74)
Agriculture: commercial — cocoa, coffee, wood,
palm oil, rice; main food crops — bananas, manioc,
peanuts, root crops; imports food
Fishing: catch 4,000 metric tons (1970); exports
$600,000 (1970)
Major industries: petroleum production, sawmills,
petroleum refinery, natural gas, agricultural
71
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GABON/GAMBIA
processing; mining of increasing importance; major
minerals — manganese, uranium, gold, and iron
Electric power: 60,000 kw. capacity (1974); 165
million kw.-hr. produced (1974), 306 kw.-hr. per
capita
Exports: $928 million (f.0.b., 1974); wood and
wood products, minerals (manganese, uranium
concentrates, gold)
Imports: $440 million (ci.f., 1974) excluding
UDEAC trade; mining, roadbuilding machinery,
electrical equipment, transport vehicles, foodstuffs,
textiles
Major trade partners: France, U.S., West
Germany, and Curacao; preferential tariffs to EC and
franc zone
Budget: 1975 est. — receipts $630 million, current
expenditures $184 million, investment expenditures
$446 million
Monetary conversion rate: 216 Communaute
Financiere Africaine francs = US$1 as of January 1975
Fiscal year: calendar year','253af3e143d7d53428b97f351fab98198adfebce6a877717205a928b47b61754','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbc94c449543e42b9c7e39076da3704c6a1de906cac7af63b5656ba31cb3d58a',1976,'GM','Gambia','economy',180,'GDP: $62 million (FY73 est.), about $120 per
capita
Agriculture: main crops — peanuts, rice, palm
kernels
Fishing: catch 6,000 metric tons (1971); exports
$108,000 (1971)
Major industry: peanut processing
Electric power: 9,600 kw. capacity (1974); 12
million kw.-hr. produced (1974), 38 kw.-hr. per capita
Exports: $23 million (FY73); peanuts and peanut
products 90% to 95%, palm kernels
Imports: $29 million (FY73); textiles, foodstuffs,
tobacco, machinery, petroleum products
Major trade partners: exports — U.K. and France;
imports — U.K. and-Japan
Aid: economic — U.K. (1968-71) about $8 million
commitment; U.S. (FY56-73) $5.2 million
Budget: (FY74 est.) current expenditures $14
million, receipts $14 million; development expendi-
tures $5.7 million, development receipts $1 million
Monetary conversion rate: 1 Dalasi=US$0.59
Fiscal year: 1 July - 80 June
GNP: $54.3 billion in 1974 (1973 prices), $3,210 per
capita, 1974 growth rate 5.7%
Agriculture: food deficit area: main crops —
potatoes, rye, wheat, barley, oats, industrial crops;
shortages in grain, vegetables, vegetable oil, beef:
caloric intake, 3,000 calories per day per capita (1970-
71)
Fish catch: 325,000 metric tons (1974)
Major industries: metal fabrication, chemicals,
light industry, brown coal, and shipbuilding
Shortages: coking coal, coke, crude oil, rolled steel
products, nonferrous metals
Crude steel: 6 million metric tons produced (1974),
approx. 360 kg. per capita
Electric power: 15,808,000 kw. capacity (1974);
80.3 billion kw.-hr. produced (1974), 4,755 kw.-hr. per
capita
74
Approved For Release 2005/04/22
Exports: $8,846 million (f.0.b. delivering country,
1974)
Imports: $9,719 million (f.0.b. delivering country,
1974)
Major trade partners: $18,565 million (1974); 30%
U.S.S.R., 32% other Communist countries, 88% non-
Communist countries
Monetary conversion rate: 3.53 DME=US$1 for
trade data (1974 rate)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake,
which is reported for the consumption year 1 July - 30
June
GNP: $383.8 billion (1974), $6,180 per capita
(including West Berlin) (1973); 54% consumption,
22% investment, 20% government; net foreign
balance 4%; 1974 growth rate 0.4%, 1962 constant
prices
Agriculture: main crops — grains, potatoes, sugar
beets: 75% self-sufficient; food shortages — fats and
oils, pulses, tropical products; caloric intake, 2,984
calories per day per capita (1973-74)
Fishing: catch 492,970 metric tons, $200 million
(1974); exports $109 million, imports $302 million
(1974)
Major industries: among world’s largest producers
of iron, steel, coal, cement, chemicals, machinery,
ships, vehicles
Shortages: fats and oils, sugar, cotton, wool,
rubber, petroleum, iron ore, bauxite, nonferrous
metals, sulfur
Crude steel: 60.6 million metric tons capacity; 53.2
million metric tons produced (1974); 860 kilograms
per capita
Electric power: 65,000,000 kw. capacity (1974);
313 billion kw.-hr. produced (1974), 4,660 kw.-hr. per
capita
Exports: $89.0 billion (f.0.b., 1974); manufactures
88.3% (machines and machine tools, chemicals, motor
vehicles, iron and steel products); agricultural
products 4.4%; fuels 3.4%; raw materials 2.6%
Imports: $69 billion (c.i.f., 1974); manufactures
52,5%, fuels 19.3%, agricultural products 14.0%, raw
materials 11.8%
Major trade partners: EC 46% (France 12%,
Netherlands 12%, Belgium-Luxembourg 8%, Italy
7%: other Europe 17%; U.S. 8%; OPEC 8%,
Communist countries 6%
75
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GERMANY, WEST/GHANA
Aid: economic — U.S. $4,162 million authorized
(FY46-73); $16 million authorized (FY73), military-—
U.S., $939 million authorized (FY46-73), none since
FY64; net official aid flows to less developed countries
and multilateral agencies (1962-74 )—$9,394 million,
$1,526 million (1974)
Budget: (1974) expenditures $51.4 billion, revenues
$47.5 billion, deficit $5 billion
Monetary conversion rate: DM 2.59 (West
German marks) =US$1 (1974 average)
Fiscal year: calendar year','6bba43bd201ba85d0465f55ff56360615257104e12829a435b82f5ab379d731c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f1a84c177c3c5c7fdd016824acf8e1d9a5286bd485a3ef6bc417ec342ef48e5',1976,'GH','Ghana','economy',184,'GNP: $3.7 billion (1974) at current prices, about
$390 pcr capita, growth rate 8.7% (1974)
Agriculture: main crop — cocoa, other crops
include root crops, corn, sorghum and millet, peanuts;
not self-sufficient, but can become so
Fishing: catch 281,000 metric tons (1972), $45.7
million
Major industries: mining, lumbering, light
manufacturing, fishing, aluminum
Electric power: 893,000 kw. capacity (1974); 3.5
billion kw.-hr. produced (1974), 380 kw.-hr. per
capita
Exports: $672 million (f.0.b., 1974); cocoa (about
65%), wood, gold, diamonds, manganese, bauxite,
and aluminum (aluminum regularly excluded from
balance of payments data)
Imports: $715 million (c.i.f., 1974); textiles and
other manufactured goods, food, fuels, transport
equipment
Major trade partners: U.K., EC, and U.S.
Budget: FY74—revenue $532 million, current
expenditure $525 million, capital expenditure $157
million
Monetary conversion rate: 1 Cedi=US$0.87
Fiscal year: | July - 30 June','c4fded7ed0dd4787ca517444bbdd484de4d23b92324e01a91990417837280558','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec1f8bb6ca40fb8d358b28821d6093eeb4cc2bca8b1f5c96c5cecbfaf80e4a99',1976,'GI','Gibraltar','economy',188,'Economic activity in Gibraltar centers on
commerce and large British naval and air bases:
nearly all trade in the well-developed port is transit
trade and port serves also as important supply depot
for fuel, water, and_ ships’ wares; recently built
dockyards and machine shops provide maintenance
and repair services to 3,500-4,000 vessels that call at
Gibraltar each year.
U.K. military establishments and civil government
employ nearly half the insured labor force; local
industry is confined to manufacture of tobacco,
roasted coffee, ice, mineral waters, candy, and canned
fish; some factories for manufacture of clothing are
being developed: a small segment of local population
makes its livelihood by fishing; in recent years tourism
has increased in importance,
Electric power: 25,000 kw. capacity (1974); 50
million kw.-hr, produced (1974), 1,500 kw.-hr. per
capita
Exports: $2.9 million (f.0.b., 1971); principally
reexports of tobacco, petroleum, and wine: principally
to the EC (31%) and the U.K. (16% )
78
/__ 7
Imports: $23.1 million; Principally from the EC
(21%) and the U.K. (49%)
Major trade partners: U.K., Morocco, Portugal,','5276df15d0ee2e75041a8c9b4d12f3bbcae330da762a3e4c57a14bc04ad2c340','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86ab9f802aa59889aa5052ba50ffdf2a6984231a6013042245a5296aae791be2',1976,'NL','Netherlands','economy',189,'Monetary conversion rate: 1 Gibraltar pound=
US$2.414 (as of September 28, 1973, floating)
GDP: $740 per capita (1974)
Agriculture: copra, subsistence crops of vegetables,
supplemented by domestic fishing
Industry: phosphate production, expected to cease
in 1978
Electric power: 15,000 kw. capacity (1974), 38
million kw.-hr. produced (1974), 633 kw.-hr. per
capita
Exports: $8.6 million (1970 est.): 70% phosphate,
copra
Imports: $3.1 million (1970 est.); foodstuffs, fuel
Budget: (est.) revenue 5.877 million NZ$,
expenditure 4.577 million NZ$
Monetary conversion rate: 0.74 Australian
$=US$1 February 1975
GNP: $69.2 billion (1974 in current prices), $5,120
per capita, 56% consumption, 22% investment, 17%
government; 5% foreign balance; 1974 growth rate
3.3% in constant prices
Agriculture: animal husbandry predominates:
main crops — horticultural crops, grains, potatoes,
sugar beets; food shortages — grains, fats, oils: calorie
intake, 3,186 calories per day per capita (1970-71)
Fishing: catch 323,000 metric tons, $150 million
(1973); exports 251,398 metric tons, imports 131,438
metric tons (1973)
Major industries: food processing, metal and
engineering products, electrical and electronic
machinery and equipment, chemicals, and petroleum
products
Shortages: crude petroleum, raw cotton, base
metals and ores, pulp, pulpwood, lumber, feedgrains,
and oilseeds
Crude steel: 6.1 million metric ton capacity; 5.8
million metric tons produced (1974), 430 kilograms
per capita
Electric power: 12,200,000 kw. capacity (1974);
55.2 billion kw.-hr. produced (1974), 3,350 kw.-hr. per
capita
Exports: $32,698 million (f.0.b., 1974); foodstuffs,
machinery, transportation equipment, consumer
manufactures, chemicals, petroleum products, textiles
Imports: $32,512 million (c.i.f., 1974); machinery,
transportation equipment, consumer manufactures,
crude petroleum, foodstuffs, chemicals, raw cotton,
base metals and ores, pulp
Major trade partners: (1974) 64% EC, 28% W.
Germany, 13% Belgium-Luxembourg, 6% U.S.
Aid: economic — U.S., $1,367 million authorized
(FY46-73); IBRD, $236 million authorized (FY46-73),
none since 1958; military — U.S., $1,255 million
authorized (FY49-73), none since FY65; net official
aid delivered to less developed areas and multilateral
agencies, $1,458 million (FY62-72), $315 million
(1972)
146
Budget: (1974) revenues $18.6 billion, expenditures
$19.7 billion, deficit $1.1 billion
Monetary conversion rate: 2.689 guilders = US$],
average 1974, floating
Fiscal year: calendar year
GNP: $209 million (1973), $890 per capita
Agriculture: little production
Major industries: petroleum refining on Curacao
and Aruba; tourism on Curacao, Aruba, and St.
Martin; phosphate mining on Curacao
Electric power: 300,000 kw. capacity (1974); 1.5
billion kw.-hr. produced (1974), 5,600 kw.-hr. per
capita
Exports: $1,379 million (f.0.b., 1973); petroleum
products, phosphate
Imports: $1,604 million (cif., 1973); crude
petroleum, food manufactures
Major trade partners: exports — U.S. 43%, EC
16%, Latin America 13%, U.K. 10%, Canada 7%;
imports — Venezuela 72%, U.S. 10%, Netherlands 4%
(1968)
Monetary conversion rate: 1.79 Netherlands
Antillean florins (NAF)=US81, official
Fiscal year: calendar year','dd1aa489709b309c09346364a9e3b1d12a2375350ba596b3116ff69bcc28a341','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e7c66de4b0e73f7e51daf60660b869e266f5e7c159d5ec4dd480cea0a8127ac',1976,'GR','Greece','economy',196,'GNP: $20.3 billion (1974 est.), $2,260 per capita;
65.4% consumption, 32.5% investment, 11.3%
government (1973); net foreign balance —9.2%, real
growth rate —2% (1974)
Agriculture: subject to droughts; main crops —
wheat, olives, tobacco, cotton: nearly self-sufficient;
food shortages — livestock products; caloric intake,
2,960 calories per day per capita (1963)
Major industries: food Processing, tobacco,
chemicals, _ textiles, petroleum refining, aluminum
processing
Shortages: petroleum, minerals, feed grains
Crude steel; 900,000 metric tons produced (1978),
100 kg. per capita
Electric power: 3,442,500 kw. capacity (1974);
13.7 billion kw.-hr. produced (1974), 1,059 kw.-hr. per
capita
Exports: $1,774 million (f.0.b., 1974); principal
items — tobacco, cotton, fruits, textiles
80
Approved For Release 2005/04/22
Imports: $4,635 million (c.i.f., 1974); principal
items — machinery and automotive equipment,
manufactured consumer goods, petroleum and
petroleum products, chemicals, meat and live animals
Major trade partners: (January to November 1974)
— 44% EC, 18% U.S., 9% other European countries,
8% CEMA countries
Aid: economic (authorized) — U.S., $1,992.2
million (FY46-73): International Finance Cor-
poration, $15 million through FY73; U.N. Technical
Assistance, $4.3 million through FY72; U.N. Special
Fund, $63.1 million through 1972; IBRD, $118.9
million (FY68-73), $25 million in 1972; Consortium,
$40 million in 1966; EC (FY64-72) $69.2 million:
U.S.S.R. $7.7. million (1954-74);military — U\\S.,
$2,337 million (FY1946-73)
Budget: (1974) expenditures $4,249 million,
revenues $3,506 million, deficit $743 million
Monetary conversion rate: 1 drachma=US$0,.033
(approx. )
Fiscal year: calendar year','fdf57a05fc3b9e73c9f9591df9942c820fbd729010c2ff5ea8551502f1df70d3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('faa85e404d1622320f450066dbe007d224d4cabede927ed04d629b70b231cbf2',1976,'GL','Greenland','economy',200,'GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep
grazing; garden produce
Fishing: catch 51,200 tons (1974); exports $30.8
million (1974)
Major industries: mining, slaughtering, fishing,
sealing
Electric power: 54,000 kw. capacity (1974); 105
million kw.-hr. produced (1974), 1,700 kw.-hr. per
capita
Exports: $90.4 million (f.0.b., 1974); fish and fish
products, nonmetallic minerals
Imports: $104.0 million (f.0.b., 1974); machinery
and transport equipment, petroleum and petroleum
products, food products
Major trade partners: (1974) Denmark 62%,
France 12%, Finland 11%
Monetary conversion rate: | Danish Kroner=
US$0.182 (1975)
Fiscal year: 1 April - 31 March','92080fd5ae105707a22faa2c3f31c572524d082104b1da6c00bae01bd631fc12','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca164e58570120956f9d40f7c8d5b360ace5e577521d68629313344d80692bd4',1976,'GD','Grenada','economy',204,'GDP: $24 million (in current prices, 1974), $250
per capita; —1.6% decrease in current prices (1974)
Agriculture: main crops — cocoa, spices, bananas
Fishing: 1,800 metric tons (1972)
Electric power: 7,000 kw. capacity (1974); 20
million kw.-hr. produced (1974), 150 kw.-hr. per
capita
Exports: $8.1 million (f.0.b., 1974); cocoa beans,
bananas, nutmeg, mace
Imports: $16.3 million (c.if.,
machinery, building materials
Major trade partners: U.K. 41%, U.S. 8%, Canada
9% (1968)
Monetary conversion rate: 2.00 East Caribbean
dollars = US$1','411038405a834f9919f61b799b9f9a7f3f9f3a5df1d7e0131859ec2f2bde55fb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c07492978d24af37b80e3d94d1da2ae73d91d4c232dc3cdc2be33293d2babf60',1976,'MQ','Martinique','economy',209,'GDP: $302 million (1971), $880 per capita; real
growth rate (1971) 5.9%
Agriculture: main crops, sugarcane and bananas
Major industries: agricultural processing, sugar
milling and rum distillation
Electric power: 33,000 kw. capacity (1974); 125
million kw.-hr. produced (1974), 350 kw.-hr. per
capita
Exports: $58 million (f.0.b., 1974); sugar, bananas,
rum
Imports: $230 million (c.if., 1974); foodstuffs,
clothing and other consumer goods, raw materials and
supplies, and petroleum
Major trade partners: exports — France 71%, U.S.
17%, Germany 7%, other 5%; imports — France 70%,
U.S. 9%, Germany 3%, Netherlands Antilles 3%,
Netherlands 3%, other 12% (1968)
Monetary conversion rate: 4.44 French francs=
US$1 (1974)
Fiscal year: calendar year
GNP: $339 million (at market prices, 1971), $930
per capita; real growth rate (1971) 8.5%
Agriculture: bananas, sugarcanc, and pineapples
Major industries: agricultural processing, par-
ticularly sugar milling and rum distillation; cement,
oil refining and tourism
Electric power: 32,000 kw. capacity (1974); 144
million kw.-hrs. produced (1974), 420 kw.-hrs. per
capita
Exports: $72 million (f.0.b., 1974); bananas,
refined petroleum products, rum, sugar, pineapples
Imports: $293 million (c.i.f., 1974); foodstuffs,
clothing and other consumer goods, raw materials and
supplies, and petroleum
Major trading partners: exports — France 82%,
Italy 9%, other 9%; imports — France 70%, United
States 6%, Netherlands Antilles 3%, Netherlands 3%,
other 18% (1968)
Monetary conversion rate: 4.44 French francs=
US$1 (1974)
Fiscal year: calendar year','94b4efe5b3dc1c2be3dbe203d3e03340856ccaf81cf9282d19bafc2698245fbb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a34ff86d2db0e0c287e039e8a30adc93e1ba7291db884101a8451ecafe1883b2',1976,'MX','Mexico','economy',214,'GDP: $2,660 million (1974, in 1973 prices, est. ),
$410 per capita; 78% private consumption, 7%
government consumption, 17% domestic investment,
—2% net foreign balance (1974); real growth rate
(1974), 5.2%
Agriculture: main products — coffee, cotton, corn,
beans, sugarcane, bananas, livestock; caloric intake,
2,200 calories per day per capita (1967)
Fishing: catch 5,000 metric tons (1970); exports
$1.6 million (1970), imports $0:5 million (1970)
Major industries: food processing, textiles and
clothing, furniture, chemicals, nonmetallic minerals,
metals
Electric power: 212,000 kw. capacity (1974); 910
million kw.-hr. produced (1974), 170 kw.-hr. per
capita
Exports: $588 million (f.0.b., 1974); coffee, cotton,
sugar, bananas, meat
Imports: $685 million (c.if., 1974); manufactured
products, machinery, transportation equipment,
chemicals, fuels
Major trade partners: exports (1973)—U.S. 33%,
CACM 30%, West Germany 9%, Japan 6%; imports
(1973) — U.S. 31%, CACM 21%, West Germany
10%, Japan 10%, Venezuela 6%
Aid: economic — from U.S. (FY46-73), $189
million loans, $191 million grants; from international
organizations (FY46-73), $156 million; from other
western countries (1960-71), $12.3 million; military —
assistance from U.S. (FY53-73), $30 million
Central government budget (1975): budgeted
expenditures $397.2
Monetary conversion rate: 1 quetzal=US$1
(official)
Fiscal year: calendar year
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GUATEMALA/GUINEA','9a5f724f58a416d0625f2759eb7408b0d1d989a3a8f81b1554a8543dc2fe45d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71cf6010c4e95f73dcee08499e45c0615d0544a76c4501dc7c98631002027c17',1976,'GW','Guinea-Bissau','economy',218,'GNP: $107 million (1969, in 1963 constant prices),
$200 per capita
Agriculture: main crops—palm oil, root crops, rice,
coconuts, peanuts
Electric power: 10,742 kw. capacity (1974), 3
million kw.-hr. produced (1974), 6 kw.-hr. per capita
Exports: $3.6 million (f.o.b., 1969); principally
peanuts, coconuts
Imports: $23.3 million (c.i.f., 1969); manufactured
goods, fuels, transport equipment, rice
Major trade partners: mostly Portugal, also
immediate neighbors
Aid: Portugal, small amounts
Monetary conversion rate: 25.5 escudos = US$1,
(fixed, February 1973)
Fiscal year: probably is the calendar year','954524aae7711441e6a5c641cffad24239becc214df14596536ec249fcf39ef5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b18e64bddceda072e40e5c4e009889a4ff8dcfedc1ce2c897c725f1b1a8e0711',1976,'GY','Guyana','economy',222,'GNP: $415.2 million (1974), $520 per capita; real
growth rate 1973 est. —3.1%
Agriculture: main crops — sugarcane, rice, other
food crops; food shortages — wheat flour, potatoes,
processed meat, dairy products; caloric intake, 2,180
calories per day per capita (1967)
Fishing: catch 17,600 metric tons (1972), $10
million (1972); exports $4.8 million (1972), imports
$1.2 million (1971)
Major industries: bauxite mining, alumina
production, sugar and rice milling
Electric power: 120,000 kw. capacity (1974); 370
million kw.-hr. produced (1974), 470 kw.-hr. per
capita
Exports: $268 million (f.0.b., 1974); bauxite, sugar,
alumina, rice, shrimp, molasses, timber, diamonds,
rum
Imports: $256 million (c.i.f., 1974); manufactures,
machinery, food, petroleum
Major trade partners: exports—U.S, 25%, U.K.
20%, CARICOM 14%, Canada 4.5%; imports—U.S.
26%, U.K. 21%, CARICOM 27%, Canada 5% (1974)
Aid: economic — from U.S. (FY53-73), $58 million
loans, $26 million grants; from U.K. (FY60-70), $73.9
million; from China (1972-73), $26.0 million
extended; from international organizations (FY46-73),
$41 million
Monetary conversion rate: floating with pound, |
pound =G$5.21
Fiscal year: calendar year
GDP: $816 million (FY74), $160 per capita; real
growth rate 1974, 3.5%
Agriculture: main crops — coffee, sugarcane, rice,
corn, sorghum, pulses; caloric intake, 1,850 calories
per day per capita
Major industries: sugar refining, textiles, flour
milling, cement manufacturing, bauxite mining,
tourism, light assembly industries
Electric power: 64,440 kw. capacity (1974); 162
million kw.-hr. produced (1974), 30 kw.-hr. per capita
Exports: $71 million (f.0.b., 1974); coffee, light
industrial products, bauxite, sugar, essential oils, sisal
Approved Fo
r Release 2005/04/22 : CIA-RDP79-01051A000
- 800010001-8
Imports: $74 million (cif. 1973); consumer
durables, foodstuffs, industrial equipment, petroleum
products, construction materials
Major trade partners: exports—72% U.S.;
imports—U.S. 56% (FY72)
Aid: economic — from U.S., $38 million loans, $97
million grants (FY46-73); international organizations,
$42 million (FY46-73); from other Western countries
(1960-71) $2.4 million; military — USS., $4 million
(FY53-73)
Monetary conversion rate: 5 gourdes= US$1
Fiscal year: 1 October - 30 September','214025698fc4fabefec5c83ef8ec9bf7d07ebc98c763f1b3582ec71e1371ab64','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3101faf9254f1c24c81694c4b4e74482ec73456f6a28ea2344d2f7af4f30404',1976,'HN','Honduras','economy',226,'GNP: $850 million (1974, in 1973 Prices, est. ), $300
Per capita; 78% Private consumption, 1] %
80vernment consumption, 26% domestic investment:
—15% net foreign balance (1973): real growth rate,
aver. 1971-73, 4.3%
Agriculture; main crops — bananas, coffee, cor,
beans, cotton, sugarcane, tobacco; caloric intake,
2,300 calories Per day per capita (1964-65)
Fishing: €xports $1.7 million (1972): imports $0.5
million (1970)
Major industries: agricultural Processing, textiles,
clothing, wood products
Electric power: 166,000 kw. Capacity (1974). 419
million kw.-hr. produced (1974), 140 kw.-hr. per
capita
Exports: $302 million (f.0.b., 1974). bananas,
Imports: $379 million (c.i.f., 1974). manufactured
Products, machinery, transportation equipment,
chemicals, petroleum
Major trade Partners: exports — U.S. 56%, West
Germany 12%, CACM 7%; imports — U.S. 40%,
CACM 12%, Japan 10%, Venezuela 8%, West
Germany 4% (1973)
Aid: economic — extensions from US. (FY46-73),
$74 million loans, $70 million Srants; from
international Organizations (FY46-73), $205 million:
from other Western countries (1960-73), $7.0 million:
military — assistance from US, (FY46-73), $10.0
million
Monetary Conversion rate: 9 lempiras= US$]
(official)
Fiscal year, calendar year','88bb8e0b30f42b42fdb8ec508d340139a4b46cfbb1209c878a64c2e2fba208e2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c733ccc1cad5e60dc48b51d70fcb3fcaeacf10912f66737444c784d50890a863',1976,'HK','Hong Kong','economy',230,'GDP: $5.9 billion (1974, in 1973 prices), $1,370 per
capita (est.); average real growth 6.1% (1970-74)
Agriculture: agriculture occupies a minor position
in the economy; main products — rice, vegetables,
91
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
HONG KONG/HUNGARY
dairy products; less than 20% self-sufficient; food
shortages — rice, wheat
Major industries: textiles and clothing, tourism,
plastics, electronics, light metal products, food
processing
Shortages: industrial raw materials, water, food
Electric power: 2,335,000 kw. capacity (1974): 6.5
billion kw.-hr, produced (1974), 1,510 kw.-hr. per
capita
Exports: $6.2 billion (f.0.b., 1974), including $1.5
billion reexports: principal products clothing, plastic
articles, textiles, electrical goods, wigs, footwear, light
metal manufactures
Imports: $7.0 billion (c.i.f., 1974)
Major trade partners: 1974 exports—U.S. 26%,
U.K. 10%, West Germany 8%: imports—Japan 21%,
China 18%, U.S. 14%
Budget: (75/76) $1.27 billion
Monetary conversion rate: HK$5.085 = US$1
Fiscal year: 1 April - 31 March','00e38173d145f6fd6ec88adac67cc79b05104845d5a83e69a28dde777e1c498b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dda9e7f6c78c8c9fae7db27814284967252b2684dc61fb3f6eb76e6c6595f286',1976,'HU','Hungary','economy',234,'GNP: 21.3 billion in 1974 (at 1973 prices), $2,030
per capita; 1974 growth rate 5.4%
Agriculture: normally self-sufficient; main crops —
com, wheat, potatoes, sugar beets, wine grapes;
caloric intake 8,140 calories per day per capita (1970)
Major industries: mining, metallurgy, engineering
industries, processed foods, textiles, chemicals
(especially pharmaceuticals)
Shortages: metallic ores (except bauxite), copper,
high grade coal, forest products, crude oil
Crude steel: 3.47 million metric tons produced
(1974), 330 kg. per capita
Electric power: 3,760,000 kw. capacity (1974);
18.9 billion kw.-hr. produced (1974), 1,810 kw.-hr. per
capita
Exports: $5,129 million (f.o.b., 1974); 28%
machinery, 19% industrial consumer goods, 28% raw
materials and semimanufactures, 24% food and raw
materials for the food industry, energy sources 1%
(distribution for 1974)
Imports: $5,575 million (1974); 21% machinery,
9% industrial consumer goods, 52% raw materials and
semimanufactures; 11% food and raw materials for
the food industry, energy sources 7% (distribution for
1974)
Major trade partners: $10,704 million (1974); 62%
with Communist countries, 38% with non-Commu-
nist countries
Aid: U.S.S.R. — $338 million extended (1956-66),
$10 million extended in 1967, $167 million extended
in 1968; to less developed non-Communist countries-
—$537.5 million (1954-74)
Monetary conversion rate: 8.5 forints=US$1
(statistical); 20.4 forints = US$1 (noncommercial) as of
1 March 1975
Fiscal year: same as calendar year; economic data
reported for calendar years
NOTE: Foreign trade figures were converted at the
1974 rate of 9.15 forints=US$1','e7edac704f00f949ac5220a22dd8b9cde1cd05877edfc16e743f1f922bf8a529','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26d91a280f4d48806143ad55bee171200709250cce4288b758b31f841edb2173',1976,'IS','Iceland','economy',238,'GNP: $1,330 million (1974), $6,190 per capita;
66% consumption, 35% investment, 11% government,
—12% net foreign balance (1974); 1974 growth rate
4.3%, constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes,
turnips; food shortages — grains, sugar, vegetable and
other fibers; caloric intake, 2,900 calories per day per
capita (1964-66)
Fishing: catch 938,486 metric tons; exports $246
million (1974)
Major industries: fish processing, aluminum
smelting, diatomite production
Shortages: grain, fuel, wood, minerals, vegetable
fibers
Electric power: 468,629 kw. capacity (1974); 2.3
billion kw.-hr. produced (1974), 7,750 kw.-hr. per
cupita
Exports: $329 million (f.0.b., 1974); fish and fish
products, animal products, aluminum, diatomite
Imports: $526 million (c.i.f., 1974); machinery and
transportation equipment, petroleum, foodstuffs,
textiles
Major trade partners: (1974) exports—U.S. 22%,
EC 29%, U.S.S.R. 8%; imports—EC 45%, U.S. 8%,
U.S.S.R. 9%
Aid: economic — U.S. authorized (1949-73) $90.2
million, $1.2 million in FY72, $0.9 million in FY73;
IBRD $80 million through September 1973
Budget: (1974) expenditures $294 million, revenues
$292 million
Monetary conversion rate: | kronur=US$0.0100
(average, 1974); 90.135 kronur=US$1 (1973); 99.952
kronur=US$1 (1974)
Fiscal year: calendar year','7e1ec91acdac1dd13fc294c04c4db1c4fc84bb1516c5fdb2b19f076a9c99c0f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34efb626581d3d981c241d3cbdca9e643bbf1b02b3b909dffa5236a77552e214',1976,'ID','Indonesia','economy',242,'GDP: $20 billion (1974), about $160 per capita;
real average annual growth (1970-74) 7.8%
Christian, 2%
Approved For Release 2005/04/22 :
Agriculture: subsistence food production, and
smallholder and plantation production for export;
main crops — rice, rubber, copra, other tropical
products; food shortage — rice
Fishing: catch 1.3 million tons (1972); exports $20
million (1972), imports $0.3 million (1970)
Major industries:processing agricultural products
and petroleum, textiles, mining
Electric power: 1,630,000 kw. capacity (1974); 4.3
billion kw.-hr. produced (1974), 33 kw.-hr. per capita
Exports: $7,426 million (if, 1974); timber,
rubber, tin, copra, tea, coffee, tobacco, palm oil;
petroleum, $5,211 million (424 million bbls.) (1974)
Imports: $3,842 million (f.0.b., 1974); rice, other
foodstuffs, textiles, chemicals, iron and steel products,
machinery, transport equipment, consumer durables
Major trade partners: exports (1974)—20% U.S.,
54% Japan, 8% Singapore, 2% Netherlands;
imports—16% U.S., 30% Japan, 9% West Germany,
6% Singapore
Budget: (1975-76) expenditures $6.6 _ billion;
54% current, 46% development expenditures; planned
receipts $6.5 billion, negligible deficit
Monetary conversion rate: 415 rupiah = US$]
Fiscal year: 1 April - 31 March
GNP: $36.4 billion (1974, in 1973 dollars), $1,130
per capita; recent GNP growth
Agriculture: wheat, barley, rice, sugar beets,
cotton, dates, raisins, tea, tobacco, sheep, and goats
Electric power: 3,172,000 kw. capacity (1974);
12.9 billion kw.-hr. produced (1974), 395 kw.-hr. per
capita
Exports: $24.0 billion (f.0.b., 1974); 97%
petroleum; also carpets, raw cotton, fruits, and nuts,
hide and leather items, ores
Imports: (non-military) $5.7 billion (c.i-f., 1974):
machinery, iron and_ steel products, chemicals,
pharmaceuticals, electrical equipment, agricultural
products
Major trade partners: exports — U.S., Japan, West
Germany, U.S.S.R. and other Communist countries:
imports — U.S., West Germany, Japan, U.K.,
ULS.S.R.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
IRAN/IRAQ
Budget: (FY74-75) $18.4 billion
Monetary conversion rate: 67.88 rials = US$1
Fiscal year: 21 March -20 March','b4e402c0506a62c4c20b45f9227f3baebb45aeb1fdb00624e2383c887d5089bb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c1566dd40d8e201be019c01691ea9edf99ae7cc223e544d086313054aeb6e6c',1976,'IQ','Iraq','economy',246,'GNP: $13 billion (1975 est.), $1,180 per capita
Agriculture: dates, wheat, barley, rice, livestock
Major industry; crude petroleum (third largest
producer in Middle East); 2.3 million b/d (mid-
1975); petroleum revenues estimated for 1974, $7.1
billion
Electric power: 958,000 kw. capacity (1974): 4.2
billion kw.-hr. produced (1974), 393 kw.-hr. per
capita
Exports: $7.4 billion (1974); net receipts from oil,
$7.1 billion; non-oil, $100 million est.
Imports: $2.9 billion (1974); 26% from Com-
munist countries (1973)
Major trade partners: exports — U.S. 2%, Italy
22%, France 19%, Netherlands 6%, U.K. 4%: imports
— US. 5.6%, U.K. 8.5%, U.S.S.R. 8.8%, France
8.4%, Japan 6.7%, Brazil 5.9%, Czechoslovakia 5.5%
(1973)
Budget (FY74/75 est.): revenue $6.0 billion (oil
tev. $5.4 billion), expenditures $6.3 billion, of which
current expenditures are $4.6 billion
Monetary conversion rate: | Iraqi dinar = US$3.38
(end of July 1973)
Fiscal year: | April - 31 March, FY75 1 April - 31
December 1975','1e6e3dc1666eb13a58a5c7e57f1477a69e26528527fcea5ca22d0712fd5d17e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('061471f5586fdc0d132ced2d1e1332fd21785da685711036f3c5a947fa81af0f',1976,'IE','Ireland','economy',250,'GNP: $6.7 billion (1974), $2,190 per capita;
67.8% consumption, 27.1% investment, 18.6%
government; —13.5% net export of goods and
services; 1972 real growth rate 3%
Agriculture: about 2/3 of agricultural area used for
permanent hay and pasture; main products —
livestock and dairy products, barley, potatoes, sugar
bects, wheat; 85% self-sufficient; food shortages —
grains, fruits, vegetables; caloric intake 3,510 calories
per day per capita (1970)
Fishing: catch 92,000 metric tons (1972); exports of
fish and fish products $13.3 million (1971), imports of
fish and fish products $4.4 million (1971)
Major industries: food products, brewing, textiles
and clothing, machinery and transportation
equipment
Shortages: coal, petroleum, timber and woodpulp,
steel and nonferrous metals, fertilizers, cereals and
animal feeds, textile fibers and textiles
Crude steel: 112,000 metric tons produced in
1974, 40 kilograms per capita
Electric power: 1,943,000 kw. capacity (1974); 7.3
billion kw.-hr. produced (1974), 2,200 kw.-hr. per
capita
Exports: $2,628 million (f.0.b., 1974); live animals,
meat, textile products, clothing, machinery, dairy
products, chemicals
Imports: $3,809 million (c.i.f., 1974); machinery,
chemicals, textiles, transportation equipment,
petroleum, metal manufactures, cereals
Major trade partners: 70.9% EC-nine (U.K.
50.6%, West Germany 7.09%); 8.4% U.S.; 13%
Communist countries (1974)
Aid: economic — U.S., $187.8 million authorized
(FY49-73), no activity (FY55-66), $12.6 million
authorized in FY69, none authorized in FY70-73;
IBRD $72.5 million authorized (FY64-72) $28 million
authorized (FY72)
Monetary conversion rate: 1 Irish pound =
US$2.453 (1973 average)
Fiscal year: 1 April - 31 March','ec23c000e3d4e57f57223ade688ce897b66060e73dcd36a0ac686c36f4459ba2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4013fee2fa140c40e7d49c47b765d05efd8ac63a03346fad003bba18e49485a',1976,'IL','Israel','economy',254,'GNP; $8.8 billion (1974), $2,618 per capita
(converted to dollars at 6.0 Israeli pounds = US$1);
1974 growth of real GNP. 5% in constant 1970 dollars
Agriculture: main products — citrus and other
fruits, vegetables, beef and dairy products, poultry
products
Major industries: food processing, textiles and
clothing, diamond cutting and polishing, chemicals,
metal products, transport equipment, electrical
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ISRAEL/ITALY
equipment, miscellaneous machinery, rubber and
plastic products, potash mining
Electric power: 1,745,000 kw. capacity (1974); 9.3
billion kw.-hr. produced (1974), 2,780 kw.-hr, per
capita
Exports: $1,825 million (f.0.b., 1974); major items
— polished diamonds, citrus and other fruits, textiles
and clothing, processed foods, fertilizer and chemical
products; tourism is leading foreign exchange earner
Imports: $4,237 million (c.i.f., 1974); major items
— rough diamonds, chemicals, machinery, iron and
steel, cereals, textiles, vehicles, ships, and aircraft
Major trade partners: exports — EC, U.S., U.K.,
Japan, Hong Kong, Switzerland; imports — EC, U.S.,
U.K., Switzerland, Japan
Budget: FY ending 31 March 76—$9.4 billion
(converted at 6.0 Israeli pounds = US$1)
Monetary conversion rate: $6.864 Israeli pounds =
US$1; par value protected by a system of export
subsidies and import duties and by legal restrictions
on conversion
Fiscal year: 1 April - 31 March','8ac9414c03211945f419786afd3356c8d985cb0b2ce57a92399716cd044eaae3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26efa3d54bee885243cf0ac9ad93810216e0ab6a97eeacf2a0982175d543d52b',1976,'IT','Italy','economy',258,'GDP: $150 billion (1974), $2,710 per capita;
66.9% private consumption, 25.2% gross private
104
investment, 14.0% government, net foreign balance
—6.1%; 1973 growth rate 6.3%, 1974 growth rate
3.4%, 1970 constant prices
Agriculture: important producer of fruits and
vegetables; main crops —— cereals, potatoes, olives;
95% self-sufficient; food shortages — fats, meat, fish,
und eggs; caloric intake, 3,100 calories per capita
(1970)
Fishing: catch 462,000 metric tons (1973), $336
million (1973); exports $29 million (1973), imports
$252 million (1973)
Major industries: machinery and transportation
equipment, iron and steel, chemicals, food processing,
textiles
Shortages: coal, fuels, minerals
Crude steel: 23.8 million metric tons produced
(1974), 431 kilograms per capita
Electric power: 40,000,000 kw. capacity (1974);
147.0 billion kw.-hr. produced (1974), 2,350 kw.-hr.
per capita
Exports: $30.3 billion (f.0.b., 1974); principal items
— machinery and transport equipment, textiles,
foodstuffs, chemicals, footwear
Imports: $40.9 billion (c.i.f., 1974); principal items
— machinery and transport equipment, foodstuffs,
ferrous and nonferrous metals, wool, cotton,
petroleurn
Major trade partners: (1974) 43.6% EC-nine
(18% West Germany, 13% France, 4% Netherlands,
4% U.K., 3% Belgium-Luxembourg); 8% U.S.; 2%
U.S.S.R. and 3% other Communist countries of
Eastern Europe
Aid: economic — U.S., $4,154 million (FY46-73),
$78.2 million authorized FY73; IBRD, $398 million
authorized through FY73, none since FY65;
International Finance Corporation, $1 million
authorized through FY72, none since FY60; military
—U.S., $2,402 million (FY46-73), $11.6 million
authorized in FY73
Monetary conversion rate: Smithsonian rate as of
December 1978, 650.4 lira=US$1; average of Friday
closing rates in 1975 to September—645 lira = US$1
Fiscal year: calendar year
GDP: $3.7 billion (1974), $700 per capita; average
annual growth rate in constant prices, 7.0%
sweeping powers,
Agriculture: commercial — coffee, wood, cocoa,
bananas, pineapples, palm oil; food crops — corn,
millet, yams, ricc; other commodities — cotton,
105
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
IVORY COAST/JAMAICA
rubber, tobacco, fish; self-sufficient in most
foodstuffs, but rice, sugar, and meat imported
Fishing: catch 72,400 metric tons (1972); $15.6
million, exports $2.6 million (1970), imports $5.2
million (1971)
Major industries: food and lumber processing, oil
refinery, automobile assembly plant, textiles, soap,
flour mill, matches, three small shipyards, fertilizer
plant, and battery factory
Electric power: 371,000 kw. capacity (1974); 788
million kw.-hr. produced (1974), 163 kw.-hr. per
capita
Exports: $1.2 billion (f.0.b., 1974); coffee, tropical
woods, cocoa, 70% of total; bananas, pineapples,
palm oil
Imports: $976 million (c.if., 1974); consumer
goods about 40%, raw materials and fuels 10%,
manufactured goods and semi-finished products,
about 50%
Major trade partners: France and other EC
countries about 65%, U.S. 18%, Communist countries
ubout 1%
Aid: economic — France (1960-69) $312 million;
EC $149 million, through FY1973; U.S. (FY61-73),
$114 million; others (1960-71), $76 million, including
$18.5 million committed; no Communist aid
programs; military — non-Communist countries, $7.3
million (1954-67)
Budget: 1975 est.—revenues $580 million, current
expenditures $454 million, investment expenditures
$247 million
Monetary conversion rate: about 218.75 Com-
munaute Financiere Africaine francs=US$$1, August
1975; floating since February 1973
Fiscal year: calendar year','7113eeb689228ef318b74619aa09ab666c9e29a2f3b7ae68dc3b8de73558612f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5299c1611667eeacecb05a1f8d7e5bb09d51e8470ed065984be04eebd6008bcb',1976,'CU','Cuba','economy',262,'GNP: $2,383 million (1974), $1,150 per capita;
real growth rate 1974, 4.3%
Agriculture; main crops — sugarcane, citrus fruits,
bananas, pimento, coconuts, coffee, cocoa
Major industries: bauxite mining, textiles, food
processing, light manufactures, tourism
Electric power: 575,000 kw. capacity (1974);
9.1 billion kw.-hr. produced (1974), 1,040 kw.-hr. per
capita
Exports: $694 million (f.0.b., 1974); alumina,
bauxite, sugar, bananas, citrus fruits and fruit
products, rum, cocoa
Approved For Release 2005/04/22
Imports: $963 million (c.i.f., 1974); machinery,
transportation and electrical equipment, food, fuels,
fertilizer
Major trade partners: exports — U.S. 48%, U.K.
16%, Canada 4.5%, Norway 11%; imports — US.
37%, U.K. 19%, Canada 7% (1974)
Aid: economic — from U.S. (FY56-73), $90 million
in loans, $51 million grants; from international
organizations (FY46-73), $118 million; from other
Western countries (1960-71), $90.2 million; military
__ assistance from U.S. (FY63-73) $1.1 million
Budget: FY74-75, prelim.—revenues $658 million,
expenditures $798 million
Monetary conversion rate: 1 Jamaican dol-
lar = US$1.10
Fiscal year: 1 April - 31 March','540e83c1186d84e5f6a9c7f886188e7646f96df1da9260a0a5ed299ea9af6ec8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd3d616adc4fbedde2291915a3c2041605f35ec5d9286e25db5db157fc28c187',1976,'JP','Japan','economy',266,'GNP: $451 billion (1974 at 292 yen= US$1:
$373 billion in 1973 prices); $4,100 per capita (1974):
52% personal consumption, 38% investment, 9%
Bovernment current expenditure; real growth rate
—2% (1974); average annual growth rate 1970-74,
7.0%
Agriculture: land intensively cultivated — rice,
wheat, barley, sugar, potatoes, fruits; 71% self-
sufficient; food shortages — meat, wheat, feed grains,
edible oil and fats: caloric intake, 2,526 calories per
day per capita (1973 est.)
Fishing: catch 10.7 million metric tons (1973)
Major industries: metallurgical and engineering
industries, electrical and electronic industries, textiles,
chemicals
Shortages: fossil fuels, most industrial raw materials
Crude steel: 117 million metric tons produced
(1974)
Electric power: 103,140,000 kw. capacity (1974).
460.7 billion kw.-hr. produced (1974), 4,203 kw.-hr.
per capita
Exports: $54.5 billion (f.0.b., 1974): machinery and
equipment 47%, metals and metal products 25%,
textiles 7% (79%)
Imports: $53.0 billion (f.0.b., 1974); fossil fuels
47%, metals and metal products 15%, foodstuffs 15%,
machinery and equipment 8%
Major trade partners: exports—23% U.S., 11%
EC, 8% Communist counties, 10% OPEC, 13% Far
East; imports—24% US., 7% EC, 6% Far East, 7%
Communist countries, 88% OPEC, 6% Australia
Aid: Japanese official foreign economic aid
disbursements 1973—$1,011 million
Monetary conversion rate: 291.5 yen=US$1
(1974 average rate), floating since February 1973
Fiscal year: | April - 31 March
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
JAPAN/JORDAN
GNP: $7 billion (1974 est.), $440 per capita
Agriculture: main crops — rice, corn, vegetables:
food shortages — meat, cooking oils; production of
foodstuffs adequate for domestic nceds at low levels of
consumption
Major industries: machine building, electric
power, chemicals, mining, metallurgy, textiles, food
processing
Shortages: complex machinery and equipment.
bituminous and coking coal, petroleum, rubber
Crude steel: 3.4 million metric tons produced
(1974), 210 kilograms per capita
112
Electric power: 3,350,000 kw. capacity (1974), 19
billion kw.-hr. produced (1974), 1,188 kw.-hr. per
capita
Exports: $685 million; minerals, chemical and
metallurgical products (1974)
Imports: $1,260 million; machinery and equip-
ment, petroleum, foodstuffs, coking coal (1974)
Major trade partners: total trade turnover
$1.9 billion; 52% with non-Communist countries,
48% with Communist countries
Aid: economic and military aid from the U.S.S.R.
and China
Monetary conversion rate: 2.15 won=US5$1
(arbitrarily established)
Fiscal year: calendar year
GNP: $13.4 billion (1974 in 1973 prices); real
growth 8.6% (1974); real growth 9.8% (1970-74
average)
Agriculture: 45% of the population live on the
land, but agriculture, forestry and fishery constitute
26% of GNP; main crops — rice, barley, wheat; not
self-sufficient; food shortages — barley, wheat, dairy
products, rice, corn
Fishing: catch 2,026,000 metric tons (1974)
Major industries: textiles and clothing, food
processing, chemical fertilizers, chemicals, plywood,
steel
Shortages: base metals, fertilizer, petroleum,
lumber and certain food grains
Electric power: 4,860,000 kw. capacity (1974);
17.3 billion kw.-hr. produced (1974), 517 kw.-hr. per
capita
Exports: $4.5 billion (f.0.b., 1974); clothing,
electrical machinery, plywood, footwear, processed
food
Imports: $6.9 billion (c.i.f., 1974); oil, ships, steel,
wood, wheat, organic chemicals
Major trade partners: exports — US. 34%, Japan
31%; imports—Japan 38%, U.S. 25% (1974)
Aid: economic — U.S. (FY46-74), $6.1 billion
committed; Japan (1965-73), 1.8 billion extended;
military — U.S. (FY46-74), $6.2 billion committed
Budget: $2.5 billion (1974)
Monetary conversion rate: rate fixed at 484
won = US$1 since December 1974
Fiscal year: calendar year','987c5c6b1a44aed26238a07b683561a94e6df18a007d21ab195556b3fb544409','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a95acefaa5e039a251e0784a39395f7bcc1502592d1714f81737f06147d8df1',1976,'JO','Jordan','economy',270,'GNP: $850 million (1974 est.), $328 per capita
Agriculture: main crops — wheat, fruits,
vegetables, olive oil; not. self-sufficient in many
foodstuffs
Major industries: phosphate mining, petroleum
refining, and cement production
Electric power: 110,000 kw. capacity (1974); 180
million kw.-hr. produced (1974), 68 kw.-hr. per
capita, East Bank only
Exports: $157 million (f.0.b., 1974); fruits and
vegetables, phosphate rock; Communist share 2% of
total (1973)
Imports: $495 million (c.i-f., 1974); petroleum
products, _ textiles, capital goods, motor vehicles,
foodstuffs; Communist share 7% of total (1973)
Aid: economic — U.S., $813 million economic
assistance (FY49-74), of which $57 million loans, $756
million grants; military — $277 million total from
U.S. (FY49-74) including $195 million in MAP grants
Budget: 1974 Est. — expenditures $552 million
(non-military $234 million, military $167 million,
development $151 million); deficit $66 million
Monetary conversion rate: 1 Jordanian dinar=
US§3.05, freely convertible; 0.8279 Jordanian dinar=
US$1
Fiscal year: calendar year','cefb15b8ba7c8e65576eb701d583b8cc868222161b4e9253941138a8ab2aabfd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cd449f0dd7b2153245593a02b2e044499b00abab79e3cdf954815b7b661af5e',1976,'KE','Kenya','economy',274,'GDP: $2,338 million at current prices (1974), $180
per capita; 3.6% real growth
Agriculture: main cash crops — coffee, sisal, tea,
pyrethrum, cotton, livestock; food crops — corn,
wheat, rice, cassava; largely self-sufficient in food
Fishing: $4.2 million (1970)
Major industries: small-scale consumer goods
(plastic, furniture, batteries, textiles, soap, agricultural
processing, cigarettes, flour), oil refining, cement
Electric power: 250,000 kw. capacity (1974);
814 million kw.-hr. produced (1974), 68 kw.-hr. per
capita
Exports: $611 million (f.0.b., 1974); coffee, tea,
livestock products, pyrethrum, soda ash, wattle-bark
tanning extract
Imports: $1,025 million (c.i.f., 1974); machinery,
transport equipment, crude oil, paper and paper
products, iron and steel products, and textiles
Major trade partners: U.K. and EC, also Uganda
and Tanzania, which are part of East African
Economic Community
Budget: FY76 current revenues $1,009 million;
current expenditures $1,057 million; development
expenditures $193 million
Monetary conversion rate: 7.143 Kenya. shil-
lings = US$1
Fiscal year: 1 July - 30 June','af95b3650c9788cce7f45ac943babac6660486815be9ef5708fb1434e96918da','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('befe5c031aadbbd51ea155dd43d2233730d008a982ba95dbced67f9149a6ef4d',1976,'KW','Kuwait','economy',278,'GNP: $9.6 billion (1974 est.), $10,060 per capita
est.
Agriculture: virtually none, dependent on imports
for food; approx. 75% of potable water must be
distilled or imported
Major industries: crude petroleum production
averaging 2.2 million b/d (includes Kuwait''s share of
neutral zone) (1975 est. ); government revenues from
taxes and royalties on production, refining, and
consumption $7.3 billion est. for 1974: refinery
capacity 504,000 b/d est. (1970): other major
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
KUWAIT/LAOS
industries include fishing, processing of building
materials, fertilizers, chemicals, and flour
Electric power: 1,070,000 kw. capacity (1974);
4.1 billion kw.-hr. produced (1974), 4,295 kw.-hr. per
capita
Exports: $10,741 million (f.0.b., 1974 prelim.), of
which petroleum accounted for about 98%;
nonpetroleum exports are mostly reexports, $137
million (f.0.b., FY71-72)
Imports: $1,550 million (cif., 1974 prelim.)
exclusive of oil company imports; major suppliers —
U.S., Japan, U.K., West Germany
Aid: an aid donor, committed bilaterally or through
multilateral agencies over $2 billion in economic
assistance in 1974 alone; amount equal to previous
total extensions of grants and loans during 1961-72
time period
Budget: (FY75/76) $3.075 billion revenues
Monetary conversion rate: 1 Kuwaiti dinar=
US$3.38 (October 1973)
Fiscal year: 1 April - 31 March
GNP: $220 million, $70 per capita (1972 est.)
Agriculture: main crops — rice (overwhelmingly
dominant), corn, vegetables; largely self-sufficient;
food shortages (due in part to distribution
deficiencies) including rice
Major industries: tin mining, timber, tobacco
Shortages: capital equipment, petroleum, transpor-
tation system
Electric power: 54,500 kw. capacity (1974),
240,000 kw.-hr. produced (1974), 73 kw.-hr. per
capita
Exports: $9.7 million (f.o.b., 1973 est.); forest
products, tin concentrates; coffee, undeclared exports
of opium and tobacco
Imports: $62 million (c.i-f., 1973 est.); rice and
other foodstuffs, petroleum products, machinery,
transportation equipment
Major trade partners: imports from Thailand,
Japan, U.S., France, U.K., Hong Kong; exports to
Malaysia and Thailand; trade with Communist
countries insignificant; Laos a major transit point in
world gold trade; value of 1978 gold re-exports $55
million
Budget: (1973-74) receipts, 13.3 billion kip;
expenditures, 36.0 billion kip; deficit 22.7 billion kip
(provisional totals); 45% military, 55% civilian
Monetary conversion rate: 750 kip=US$1 (official
rate); 1,200 kip=US$1 for most import transactions;
free market rate of 1,500-3,000 kip=US$1 for
numerous market transactions
Fiscal year: 1 July - 30 June','9f3717dd7ba6c2308f7be8fe4a1f6c954fcaca0f28cc7488ccbb66134f438393','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('944beb7e45864cf1245bb00158ced8baac6d7115f73c1d2196e738d9f12f5bc5',1976,'LB','Lebanon','economy',282,'Agriculture: fruits, wheat, corn, barley, potatoes,
tobacco, olives, onions; not self-sufficient in food
Major industries: service industries, food
processing, textiles, cement, oil refining, chemicals,
some metal fabricating, tourism
Electric power: 818,000 kw. capacity (1974); 2.0
billion kw.-hr. produced (1974), 830 kw.-hr. per
capita
Major trade partners: exports $1 billion est. (f.o.b.,
1974); most to Arab countries; imports $1.7 billion
(c.if., 1974); chiefly from EC, U.K., and Arab
countries; trade deficit covered by large net receipts
from invisibles (particularly tourism and transporta-
tion) and private capital inflow
Budget: (1975) expenditures $863 million, current
expenditures $758 million, investment expenditures
$105 million
Monetary conversion rate: | Lebanese pound =
US$0.44 as of August 1975
Fiscal year: calendar year','cb9714e0e4bd8027aca61e9ed8d7ecab4a7568bb66226578ca6587460da4bee0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('736eee5412a797a30d102390fa36ecb3b377d19d4cb4114df161ad954fa432f5',1976,'LS','Lesotho','economy',286,'GNP: $80 million (FY71 est.), $80 per capita;
growth rate (in current prices), 6% annually (FY67-71
est.)
Agriculture: exceedingly primitive, mostly
subsistence farming and livestock; principal crops are
com, wheat, pulses, sorghum, barley
Major industries: none
Electric power: 2,820 kw. capacity (1974); 6
million kw.-hr. produced (1974), 6 kw.-hr. per capita
Exports: labor to South Africa (remittances $11
million est. in FY72); $6 million (f.0.b., FY73), wool,
mohair, wheat, cattle, diamonds, peas, beans, corn,
hides, skins
Imports: $55 million (f.0.b., FY73): mainly corn,
building materials, clothing, vehicles, machinery,
POL
Major trade partner: South Africa
Aid: economic aid; U.K. $9.4 million (plan FY71-
75); other $17.5 million (plan FY71-75); U.S. $15.4
million authorized (FY61-73); no military aid
Budget: (FY76) revenucs—$63 million, expendi-
tures—current $38 million, development—$25
million
Monetary conversion rate: Lesotho uses the South
African rand; | SA rand=US$1.15 (as of November
1975)
Fiscal year: 1 April - 31 March','ecc87ae1a35b61aced90a9cef060baaf207187220174af1accf049fa95d07d4c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45f31de8167558415b85d8b009417c3806508734f07b44998de357b00355343f',1976,'LR','Liberia','economy',290,'CDP: $574 million (1974), $290 per capita; 10%
current annual growth rate
Agriculture: rubber, rice, oil palm, cassava, coffee,
cocoa; imports of rice, wheat, and live cattle and beef
are necessary for basic diet
Fishing: catch 15,500 metric tons, $6.5 million
(1974)
Industry: rubber processing, food processing,
construction materials, furniture, palm oil processing,
mining (iron ore, diamonds), 10,000 b/d oil refinery
Electric power: 225,000 kw. capacity (1974); 600
million kw.-hr. produced (1974), 345. kw.-hr. per
capita
Exports: $400 million (f.0.b., 1974); iron ore,
rubber, diamonds, lumber and logs, coffee, cocoa
Imports: $290 million (c.if., 1974); machinery,
transportation equipment, petroleum products,
manufactured goods, foodstuffs
119
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LIBERIA/LIBYA
Major trade partners: U.S., West Germany,
Netherlands, Italy, Belgium
Aid: economic — (FY46-75) U.S., $230 million;
military — (FY53-74) U.S.. $11.7 million; other aid
sources include IBRD, U.N.. IMF, West Germany,
Republic of China
Budget: (FY74) expenditures and revenues $108
million, development budget, $14.2 million
Monetary conversion rate: Liberia uses U.S.
currency
Fiscal year: calendar year','80e6f638f453ea26e27f5a04905f5363df5a6e7355195abe4cca4eb7bcba9aae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c17b4659793667f8df37d2c13503b3fe05b0a1c6d8b6e392729b8a845af61ddd',1976,'LY','Libya','economy',294,'GDP: $6.5 billion (1973), $3,010 per capita
Agriculture: main crops — wheat, barley, olives,
dates, citrus fruits, peanuts; not self-sufficient in food
Major industries: petroleum production averaged
1.5 million b/d (1974); food processing, textiles,
handicrafts
Electric power: 280,000 kw. capacity (1974); 696
million kw.-hr. produced (1974), 305 kw.-hr. per
capita
Exports:
petroleum
Imports: $1,723 million (1972, c.i.f.)
Major trade partners: imports — Italy, West
Germany, U.S.; exports — Italy, West Germany,
U.K., France
Aid: economic — no Communist country
assistance; U.S. aid extended $212.5 million (FY49-
73); military — arms obtained by cash purchase; chief
suppliers France, U.S.S.R., Czechoslovakia; U.S.
suspended since September 1969
Monetary conversion rate: 1 Libyan pound=
US$3.38
Fiscal year: 1 January - 31 December (beginning
1974); formerly 1 April - 31 March','ca4a3790657043566a46f70a7eedbbd1fa9b9f4c3498bc188ac9761c0574bafa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ce35efa7a7d7ee604a19f4c581e866a232ebe510c9c2d71c0434324b6a1d854',1976,'LI','Liechtenstein','economy',298,'Despite its small size and sparse natural resources,
Liechtenstein has a prosperous economy based
primarily on small-scale light industry and farming.
Textiles, ceramics, precision instruments, phar-
maceuticals, and canned foods are the principal
manufactures produced, almost entirely for export.
Livestock raising and dairying are the main sources of
farm income; cereals and potatoes are the most
important farm crops. The Liechtenstein economy is
tied closely to that of Switzerland in a virtual customs
union. No national accounts data are available.
Major trade partners: exports (1972) — $138.6
million; 34% Switzerland, 35% EC, 48% EFTA
Electric power: 22,600 kw. capacity (1974); 55
million kw.-hr. produced (1974), 1,800 kw.-hr. per
capita; power is exchanged with Switzerland, but net
exports average 35 million kw.-hr. yearly','ca8aaf8aa9fed8ebc29cbfc41ab175ba15f4a5dd6254114b778d2cd5ddabb893','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('586502f6fcb553f405e2d8d0045b489e97203f2166735407466a72b4eb9a64ed',1976,'LU','Luxembourg','economy',303,'GNP: $1,698 million (1974, in 1973 prices), $4,810
per capita; 1974 growth rate 5.5% at constant prices;
53% consumption, 27% investment, 11% government,
9% net exports of goods and services (1973)
Agriculture: mixed farming; main crops — grains,
potatoes, fodder beets; food shortages — sugar, bread
grains, fats; caloric intake, 3,150 calories per day per
capita (1968-69)
Major industries: iron and steel, food processing,
chemicals, metal products and engineering, tires
Crude steel: 6.4 million metric tons produced
(1973), 18,630 kg. per capita
Electric power: 1,204,000 kw. capacity (1974); 2
billion kw.-hr. produced (1974), 6,900 kw.-hr. per
capita
Exports: $1,493 million (f.0.b., 1973)
Imports: $1,329 million (c.i.f., 1973)
Major trade partners: Luxembourg and Belgium
form an economic and customs union and report their
foreign trade jointly (see Belgium); Luxembourg’s
principal exports are iron and steel products; principal
imports are coal and consumer products, most foreign
trade is with Germany, Belgium, and other EC
countries
Aid: foreign aid to Luxembourg is included in aid
to Belgium
Budget (projected): (1975) expenditures $650
million, revenues $659 million, surplus $9 million
Monetary conversion rate: 1974 average 1
franc=US$0.0257 floating; under the BLEU
agreement, the Luxembourg franc is equal to the
Belgian france which circulates freely in Luxembourg
Fiscal year: calendar year','a90a42aa431cd5beb7fb7928f0257d68ffdef6ca985e017b8c935a3576a408ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bccf65f8280ec5a16490c5622fa8e18a99b000088130706c1b8fb7bab527034b',1976,'PH','Philippines','economy',308,'Agriculture: main crops — rice, vegetables, food
shortages — rice, vegetables, meat; depends mostly on
imports for food requirements
Major industries: textiles, fireworks
Electric power: 73,500 kw. capacity (1974); 175
million kw.-hr. produced (1974), 700 kw.-hr. per
capita
Exports: $108 million (f.o.b., 1974), textiles and
clothing, foodstuffs, fireworks
Imports: $127 million (c.i.f., 1974)
Major trade partners: exports — Portuguese
colonies 20%, West Germany 16%, Hong Kong 18%;
imports — Hong Kong 67%, China 26% (1974)
Monetary conversion rate: 5.35 patacas=US$1
(December 1975)
Fiscal year: calendar year
GNP: $14.0 billion (1974), $340 per capita, 5.8%
real growth, 1974
Agriculture: main crops — rice, corn, coconut,
sugarcane, bananas, abaca, tobacco
Fishing: catch 1.3 million metric tons (1974)
Major industries: agricultural processing, textiles,
chemicals and chemical products
4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
marae tp
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PHILIPPINES/POLAND
Electric power: 2,993,000 kw. capacity (1974);
11.9 billion kw.-hr. produced (1974), 287 kw.-br. per
capita
Exports: $2,625 million (f.o.b., 1974); sugar,
coconut products, logs and lumber, copper
concentrates, abaca
Imports: $3,140 million (f.0.b., 1974); petroleum,
industrial equipment, grains
Major trade partners: (1974) exports—42% US.,
35% Japan; imports—28% Japan, 23% US.
Aid: economic — U.S. (FY46-74), $2.1 billion
committed; Japan (CY70-74), $266 million commit-
ted; IBRD/IDA (CY66-74), $466 committed; military
— U.S. (FY46-74), $735 million committed
Budget: (FY75) revenues $2.1 billion, expenditures
$2.5 billion, deficit $0.4 billion; 11% military, 84%
civilian
Monetary conversion rate: 7.5 pesos= US$1,
August 1975
Fiscal year: 1 July - 30 June','3d6cbacfb76a317558e5bc6610bdcf909efc879fa2c02db334cf73fde84c4a1a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a652c1e85dbd248a5f32c847fc2608db853fbbc1d364a0325ebbc32eb2a3310d',1976,'MG','Madagascar','economy',312,'GDP: $1.4 billion (1974), about $200 per capita; an
increase of about 7.0% annually since 1971
Agriculture: cash crops — coffee, vanilla, sugar,
tobacco, sisal, rice, cloves, raphia; food crops — rice,
cassava, cereals, potatoes, corn, beans, bananas,
coconuts, and peanuts; animal husbandry wide-
spread; self-sufficient in foodstuffs, but some milk and
cereals imported
Fishing: catch 49,000 metric tons (1972); exports
$4.4 million (1971), imports $800,000 (1971)
Major industries: agricultural processing (meat
canneries, soap factories, brewery, tanneries, sugar
refining), light consumer goods industries (textiles,
glassware), cement plant, auto assembly plant, paper
mill, oil refinery
Electric power: 90,000 kw. capacity (1974); 240
million kw.-hr. produced (1974), 30 kw.-hr. per capita
125
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MADAGASCAR/MALAWI
Exports: $226 million (f.0.b., 1974); coffee 30%,
rice 1%, vanilla 5%, sugar 4%; agricultural and
livestock products account for about 85% of export
carnings
Imports: $291 million (c.if., 1974); consumer
goods about 30%, foodstuffs 15%, primary products
(crude oil, fertilizers, metal products) 25%, capital
goods 28% (1971)
Major trade partners: France (in 1971 accounted
for 34% of exports and 56% of imports); U.S.,
preferential tariffs to EC and franc zone countries:
trade with Communist countries remains a minute
part of total trade
Budget: (FY75) revenues $450 million (including
$78 million projected borrowing), expenditures $450
million of which $324 million current, $126 million
development
Monetary conversion rate: 219.98 Malagasy
francs=US$1 as of August 1975 (floating since
February 1973); member of French france zone
Fiscal year: calendar year
Agriculture: islands depend largely on coconut
production and export of copra; cinnamon, vanilla,
and patchouli (used for perfumes) are other cash
crops; food crops — small quantities of sweet
potatoes, cassava, sugarcane, and bananas; islands
not self-sufficient in foodstuffs and the bulk of the
supply must be imported
Major industries: processing of coconut and
vanilla, fishing, small-scale manufacture of consumer
goods, coir rope factory, tea factory
Electric power: 3,500 kw. capacity (1974); 9
million kw.-hr. produced (1974), 171 kw.-hr. per
capita
Exports: $3 million (f.0.b., 1974); cinnamon (bark
and oil) and vanilla account for almost 50% of the
total, copra accounts for about 40%, the remainder
consisting of patchouli, fish, and guano
Imports: $27 million (c.i.f., 1974); food, tobacco,
and beverages account for about 40% of imports,
manufactured goods about 25%, machinery and
transport equipment, petroleum products, textiles
Major trade partners: exports — India, U.S.;
imports — U.K., Burma, India, South Africa, Kenya,','55c6036fb416cb1192a2663abf06ea8bfa978100f1792fd8b283de761eeed115','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45f7593664e7678c3031bf35e02bd6f99f5e267a337b9d86c7be8c1386ecba82',1976,'MW','Malawi','economy',316,'GDP: $641 million (1974 current prices), $110 per
capita; real growth rate 6.5% (1972-74)
Agriculture: cash crops — tea, tobacco, peanuts,
cotton, tung; subsistence crops — corn, sorghum,
millet, pulses, root crops, fruit, vegetables, rice
Electric power: 88,000 kw. capacity (1974); 216
million kw.-hr, produced (1974); 46 kw.-hr. per capita
Major industries: agricultural processing (tea,
tobacco, sugar), sawmilling, cement, consumer goods
Exports: $122 million (f.0.b., 1974); tobacco, tea,
groundnuts, sugar, maize, rice, cotton
Imports: $185 million (c.if., 1974); manufactured
goods, machinery and transport equipment, building
and construction materials, food, fuels, fertilizer
Major trade partners: exports — U.K., other EEC,
Rhodesia, South Africa; imports — South Africa,
U.K., Rhodesia, other EEC
Aid: economic — U.K. provides major develop-
ment support, about $144 million (1964-74); U.S. aid
commitments, $50 million (FY56-74), military —
U.K., $2.4 million (1954-68)
Budget: (FY75) $123 million
Monetary conversion rate: | Malawi Kwacha=
US$1.20
Fiscal year: 1} April - 31 March','830d1fa81fd4ef8ddcff4cfd24cdcba3fed3439e5f30036cad8986a3c4c095cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d0ee28b5b56957c98522dc9e1d5a6daf86539c0f5e93fbb50373cf168a53a6b',1976,'MY','Malaysia','economy',320,'GNP:
Malaysia: $8.7 billion (1974), $715 per capita;
average annual real growth 6.4% (1968-74), 6%
(1974) ;
Agriculture:
Peninsular Malaysia; natural rubber, rice, oil
palm; 10%-15% of rice requirements imported
Sabah: mainly subsistence; main crops — rubber,
timber, coconut, rice; food deficit — rice
Sarawak: main crops — rubber, timber, pepper;
food deficit — rice
Fishing: catch 359,000 metric tons, $151 million
(1972)
Major industries:
Peninsular Malaysia: rubber and oil palm
processing and manufacturing, light manufacturing
industry, tin mining and smelting, logging and
processing timber
Sabah: logging, petroleum production
Sarawak: agriculture processing, petroleum
production and refining, logging
Electric power:
Peninsular Malaysia: 1,075,000 kw. capacity
(1974); 5 billion kw.-hr. produced (1974), 515 kw.-hr.
per capita
Sabah: 75,000 kw. capacity (1974); 190 million
kw.-hr. produced (1974); 252 kw.-hr. per capita
Sarawak: 63,000 kw. capacity (1974); 174 million
kw.-hr. produced (1974), 158 kw.-hr. per capita
Exports: $5 billion (f.0.b., 1974); natural rubber,
palm oil, tin, timber, petroleum
Imports: $4.4 billion (c.i.f., 1974)
Major trade partners: exports—-22% Singapore,
18% Japan, 12% U.S.; imports — 24% Japan, 10%
U.K., 8% Singapore, 8% U.S.
Aid: economic — U.K. (1946-69) $260 million
disbursed; Japan (1966-68) $50 million extended;
IBRD (1959 - July 1974) $500 million (committed);
U.S. (1954-74) $118 million; military — (FY62-74)
$59 million committed
Budget: 1975 revenues $2.1 billion; expenditures
$3.0 billion; deficit $900 million; 16% military, 84%
civilian
Monetary conversion rate: (Malaysia) 2.5
Malaysian dollars = US$1 (August 1975)
Fiscal year: calendar year','308212b426103d47a4ad85597def18b3a830e0d9ffb4c2e542f94fa6b00c0301','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eac715f43b2614cb2adb6f8a56a59e5d371928117e7de57a375c71bb90e66260',1976,'MV','Maldives','economy',324,'GNP: under $100 per capita
Agriculture: crops — coconut and millet; shortages
— rice, wheat
Fishing: catch 69,200 metric tons (1972)
Major industries: fishing; some coconut processing
Electric power: 2,500 kw. capacity (1974); 9
million kw.-hr. produced (1974), 76 kw.-hr. per capita
Exports: $2.4 million (f.0.b., 1968); fish
Imports: $2 million (c.i.f., 1968)
Major trade partner: Sri Lanka
Aid: U.K. (1960-65), $1.4 million drawn; Sri Lanka
(1967), $1 million committed
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MALDIVES/MALI
Monetary conversion rate: 6.39 rupees= US$1
Fiscal year: calendar year','67d4b798b7864ddc5ec42c6f4e875f36a64a70a465027af7c5ea75b9224b871b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cebe81a2752757685637dce529671c711350741ba735a91a3ca879b212c3a3e7',1976,'ML','Mali','economy',328,'GDP: about $457 million (1974), $83 per capita;
annual real growth rate negative since 1972
Agriculture: main crops — millet, sorghum, rice,
corn, peanuts; cash crops — peanuts, cotton, livestock
Fishing: catch 90,000 metric tons (1971) exports
$670,000 (1971)
Major industries: small local consumer goods and
processing
Electric power: 27,000 kw. capacity (1974); 60
million kw.-hr. produced (1974), 10 kw.-hr. per capita
Exports: $60 million (f.o.b., 1974); livestock,
peanuts, dried fish, cotton, skins
Imports: $183 million (c.if., 1974); textiles,
vehicles, petroleum products, machinery, and sugar
Major trade partners: mostly with franc zone and
Western Europe; also with U.S.S.R., China
131
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MALI/MALTA
Budget: 1974 est. — receipts $54 million, current
expenditures $69 million
Monetary conversion rate: 439.96 Mali francs=
US$1, August 1975
Fiscal year: calendar year
GNP: $395 million (1974), $1,240 per capita; 69%
private consumption, 24% gross investment
Agriculture: overall, 20% self-sufficient; adequate
supplies of vegetables, poultry, milk and pork
132
: Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MALTA/MARTINIQUE
products; shortages in beef, grain, animal fodder, and
fruits at various seasons; main products — potatoes,
cauliflowers, grapes, wheat, barley, tomatoes, citrus,
cut flowers, green peppers, hogs, poultry, eggs; 2,680
calories per day per capita
Major industries: ship repair yard, building
industry, food manufacturing, textiles, tourism
Shortages: most consumer and industrial needs
(fuels and raw materials) must be imported
Electric power: 115,000 kw. capacity (1974); 312.0
million kw.-hr. produced (1974), 920 kw.-hr. per
capita
Exports: $134 million (f.0.b., 1974); textiles, scrap
metal, wine, agricultural products, and footwear
Imports: $360 million (c.if., 1974)
Major trade partners: EC-nine 65% (U.K. 25%,
Italy 15%); U.S. 5%; Communist countries 5% (1974)
Aid: economic — U.S., $34 million (FY49-73),
$10.5 million in 1972, and $14.9 million in 1973;
Agreement (loans and grants) (1964-74), $140 million;
U.N. Special Fund, $2.2 million through FY72; U.N.
Technical Assistance, $1.4 million through FY72,
China, $45 million (1972)
Monetary conversion rate: 1 Maltese pound=
US$2.67 (Smithsonian Agreement), December 1971,
the Maltese pound began floating in June 1972, with
the rate being determined between that of sterling and
that of the currencies of Maltas major trading
partners; average trade conversion factor, year 1974: 1
Maltese pound = US$2.59
Fiscal year: 1 April - 31 March','9b58d2a55a883d3846653a9daf77fe80c4914353a738dfe818292233cdc95595','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74e5b7474e31c6b7d5375a7efa08a08a1c9f9db2c6ae9a127fb9ae05087c6263',1976,'MR','Mauritania','economy',333,'GDP: about $230 million (1972), average annual
increase in current prices about 5.0% (1968-72), about
$190 per capita
Agriculture: most Mauritanians are nomads or
subsistence farmers; main products — livestock,
livestock, small grains, dates; cash crop — gum
arabic; livestock
Fishing: catch, traditional river fishing, 15,000
metric tons (1969), traditional sea fishing, 2,750
metric tons (valued at $437,000); fish supplied to
processing plants by foreign fishing fleets from France,
Spain, Canary Islands using Mauritanian waters,
exports 22,100 metric tons, $8 million (1970)
Major industries: mining of iron ore, salt fishing,
exploitation of copper resources planned
Electric power: 38,600 kw. capacity (1974);
78 million kw.-hr. produced (1974), 70 kw.-hr. per
capita
Approved For Release 2005/04/22 :
Exports: $185 million (f.0.b., 1974); iron ore, fish,
gum arabic
Imports: $177 million (c.i.f, 1974); sugar, cloth,
iea, and fuels
Major trade partners: (trade figures not complete
because Mauritania has a form of customs union with
Senegal and much local trade unreported) France and
other EC members, U.K., and U.S. are main overseas
partners
Budget: 1974 est. — receipts $67.9 million, current
expenditures $67.4 million, investment expenditures
$7.2 million
Monetary conversion rate: 41.33 Ouguyia = US$1
as of June 1975 (currency floating since February
1973) (official)
Fiscal year: calendar year','f37c774dbf59aacf44bc0ae5554aab99e02d4d645e7c6e7347d813f6041a1238','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11bab78c86580b455792cdc925cea876defc636ea799c3116dbe547079cbd09f',1976,'MU','Mauritius','economy',337,'GNP; $370 million est. (1974), $420 per capita
Agriculture: sugar crop is major economic asset;
about 40% of land area is planted to sugar; tea
production rising slowly; most food imported — rice is
the staple food — and since cultivation is already
intense and expansion of cultivable areas is unlikely,
heavy reliance on food imports except sugar and tea
will continue
Shortage: land
Industries: mainly confined to processing
sugarcane, tea; some small-scale, simple manufac-
tures; tobacco fiber; some fishing; tourism, diamond
cutting, weaving and textiles, electronics
Electric power: 73,800 kw. capacity (1974): 204
million kw.-hr. produced (1974), 231 kw.-hr. per
capita
Exports: $312 million (f.0.b., 1974); mainly sugar,
tea, molasses
Imports: $309 million (c.i:f., 1974); foodstuffs 80%,
manufactured goods about 25%
Major trade partners: all EC-nine countries and
U.S. have preferential treatment, U.K. buys over 50%
of Mauritius’ sugar export at heavily subsidized
prices; small amount of sugar exported to Canada,
U.S., and Italy; imports from U.K. and EC primarily,
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
ooo
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MAURITIUS/MEXICO
also from South Africa, Australia, and Burma; some
minor trade with China
Budget: revenues $172 million, current ex-
penditures $168 million, investment expenditure $65
million (1976)
Monetary conversion rate: 6.32 Mauritian
rupees = US$1 in August 1975 (floating with pound
sterling)
Fiscal year: 1 July - 30 June
Agriculture: cash crops — almost entirely
sugarcane, small amounts of vanilla and perfume
plants; food crops — tropical fruit and vegetables,
manioc, bananas, corn, market garden produce, also
some tea, tobacco, and coffee; food crop inadequate,
most food needs imported
Major industries: 12 sugar processing mills, rum
distilling plants, cigarette factory, 2 tea plants, fruit
juice plant, canning factory, a slaughterhouse, and a
number of small shops producing handicraft items
Electric power: 54,400 kw. capacity (1974); 168
million kw.-hr. produced (1974), 344 kw.-hr. per
capita
Exports: $72 million (f.0.b., 1974); 90% sugar, 4%
perfume essences, 5% rum and molasses, 1% vanilla
and tea
Imports: $352 million (c.i.f., 1974); manufactured
goods, food, beverages, and tobacco, machinery and
transportation equipment, raw materials and
petroleum products
Major trade partners: France (in 1970 supplied
62% of Reunions imports, purchased 76% of its
exports); Mauritius (supplied 12% of imports)
Monetary conversion rate: about 216 Com-
munaute Financiere Africaine francs=US$1 as of
January 1975 (floating since February 1973)
Fiscal year: probably calendar year','c19a2acb358eef2722dc3c886255686b7b0d3de9fcd65946a8ad8596f4876cbf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3dc67a72f4e6933b30818fbb4ec7376e810790aff2c0971e3dbb0b1c5152d3dc',1976,'US','United States','economy',341,'GDP: $64.8 billion (1974 est.), $1,120 per capita;
70% private consumption, 9% public consumption,
21% domestic investment (1973 est.); real growth rate
1974, 6.0% est.
Agriculture: main crops — corn, cotton, wheat,
coffee, sugarcane, sorghum, oilseeds, pulses, and
vegetables; general self-sufficiency with minor
exceptions in meat and dairy products; caloric intake,
3,110 calories per day per capita (1968)
Fishing: catch 402,500 metric tons, $95.1 million
(1971): exports $61,060,000. imports $12.516,000
(1970)
Major industries: processing of food, beverages,
and tobacco; chemicals, basic metals and metal
products, petroleum products, mining, textiles and
clothing, and transport equipment
Crude steel: 5.2 million metric tons capacity
(1973); 5.1 million metric tons produced (1974): 90
kilograms per capita (1974)
Electric power: 9,000,000 kw. capacity (1974): 38
billion kw.-hr. produced (1974), 660 kw.-hr. per
capita
Exports: $2,894 million (f.0.b., 1974); cotton,
coffee, nonferrous minerals (including lead and zinc),
sugar, shrimp, petroleum, sulfur, salt, cattle and meat,
fresh fruit and tomatoes
Imports: $6,219 million (c.i.f., 1974); machinery,
equipment, industrial vehicles, and intermediate
goods
Major trade partners; exports — U.S. 65%, EC
11%, Japan 4% (1974); imports—U.S, 65%, EC 16%,
Jupan 3%
Aid: economic — extensions from U.S. (FY46-73),
$1,228 million in loans; $164.2 million in grants; from
international organizations (FY46-73), $2,337 million:
from other Western countries (1960-66), $122.7
million; military — assistance from U.S. (FY46-72),
$14 million
Budget: 1974 est. federal, revenues $5,660 million,
expenditures $7,800 million
Monetary conversion rate: 12:5 pesos = US$1
(official)
Fiseal year: calendar year
GNP: $1,397 billion (1974); 63% private
consumption, 15% private investment, 22% govern-
ment; $6,600 per capita; 1974 growth rate —2%
(constant 1958 dollars)
Fishing: catch 2.7 million metric tons (1973),
valued at $704 million; imports $914 million (1971);
exports $136 million (1971)
Crude steel: 132 million metric tons produced
(1974), 620 kg. per capita
Electric power: 476,000,000 kw. capacity (1974);
1,865 billion kw.-hr. produced (1974), 8,400 kw.-hr.
per capita est.
Exports: $97.9 billion (f.0.b., 1974); machinery and
transport equipment, chemicals, cereals, mineral fuels
Imports: $100.2 billion (c.i.f., 1974); transport
equipment, machinery, mineral fuels, steel, nonfer-
rous metals, metal ores
Major trade partners: Canada 21%, Japan 12%,
West Germany 6%, U.K. 4% (1973)
Official development assistance (aid): obligations
and loan authorizations (FY74), economic $3.9
billion, military $5.1 billion
Fiscal year: 1 July - 30 June','cebf08d203e1604cae8671cf677010d710a2cb289a72bd5814c39febd8cfb279','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d0a85355bc287be2d2a9202edf2703554da22af01f0174aa877fbf4504b0233',1976,'MC','Monaco','economy',345,'GNP: 55% tourism; 25%-30% industry (small and
primarily tourist oriented); 10%-15% registration fees
and sales of postage stamps; about 4% traceable to the
Monte Carlo casino
Major industries: chemicals, food processing,
precision instruments, glassmaking, printing
Electric power: 8,000 kw. capacity (1974); 80
million kw.-hr. supplied by France (1974), 2,000 kw.-
hr. per capita
Trade: full customs integration with France, which
collects and rebates Monacan trade duties
Monetary conversion rate: 1 franc = US$0.2253','c8e6d43ad17797616d5eeb323c141e4d0e69add6dfda6a42c9e691d22e3cf537','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41ca3eac5f7b2904597b7e24e3fc2901c93460b7aa4c5fd820de7110d4f2da73',1976,'MN','Mongolia','economy',349,'Agriculture: livestock raising predominates; main
crops — wheat, oats, barley
Industries: processing of animal products; building
materials; mining
Electric power: 246,600 kw. capacity (1974): 740
million kw.-hr. produced (1974), 521 kw.-hr. per
capita
Exports: beef for slaughter meat products, wool,
fluorspar, other minerals
Imports: machinery and equipment, petroleum,
clothing, building materials sugar, and tea
Major trade partners: nearly all trade with
Communist countries (approx. 80% with U.S.S.R.);
total turnover over $600 million (1974)
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 3.31 tugriks= US$]
(arbitrarily established)
Fiscal year: calendar year','dc290e115280f5214f22acf591d4ef56e91c17d59c621dea8f308e73c08acdac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('918ca8a91fc64f8669472cce0881d358176f574c895fd9071cc2428567ce6f96',1976,'MA','Morocco','economy',353,'GNP: $6 billion (1975 est. in 1974 dollars), about
$350 per capita; average annual real growth 4%
during 1970-73
Agriculture: cereal farming and livestock raising
predominate; main products — wheat, barley, citrus
fruit, wine, vegetables, olives; some fishing
Fishing: catch 246,000 metric tons, $21.0 million
(1972); exports $37.9 million (1971)
Major sectors: mining and mineral processing
(phosphates, smaller quantities of iron, manganese,
lead, zinc, and other minerals), food processing,
textiles, construction and tourism
Electric power: 745,000 kw. capacity (1974); 2.6
billion kw.-hr. produced (1974), 152 kw.-hr. per
capita
Exports: $1,706 million (f.0.b., 1974); phosphates
55%, agricultural goods 25%, other 20%
Imports: $1,914 million (f.0.b., 1974); raw material
and semi-finished goods 42%, food 24%, equipment
20%, consumer goods 14%
Major trade partners: exports — France 32%, West
Germany 8%, Italy 8%, Benelux 7%, U.K. 2%;
imports — France 31%, U.S. 8%, West Germany 7%,
Italy 6% (1972)
Monetary conversion rate: 4.15 dirhams=US$1
(trade rate in 1974)
Fiscal year: calendar year','aee2b216a077616b0d61369465ef1454900f0ff83a11275818038cad010fc020','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('397a867c4e6d9d2501b52c817d040cd9ebe3515a1d9deaaaf9ee84b93c54f684',1976,'MZ','Mozambique','economy',357,'GNP: $2.3 billion (1972), about $250 per capita;
average annual growth probably stagnant or falling
Agriculture: cash crops — raw cotton, cashew nuts,
sugar, tea, copra, sisal; other crops — corn, wheat,
peanuts, potatoes, beans, sorghum, and cassava; self-
sufficient in food except for wheat which must be
imported
Major industries: food processing (chiefly sugar,
tea, wheat, flour, cashew kernels); chemicals
(vegetable oil, oilcakes, soap, paints); petroleum
products; beverages; textiles; nonmetallic mineral
products (cement, glass, asbestos, cement products);
tobacco
Electric power: 442,000 kw. capacity (1974); 558
million kw.-hr. produced (1974), 66 kw.-hr. per capita
Exports: $240 million (f.0.b., 1974); cashew nuts,
cotton, sugar, mineral products, timber products, tea,
copra, petroleum products
Imports: $480 million (c.i.f., 1974 prelim.); (c.i.f.,
1972); machinery and electrical equipment, cotton
textiles, vehicles, petroleum products, wine, iron and
steel
Major trade partners: over one-third of foreign
trade with Portugal; South Africa, U.S., U.K., West','92c356e27c6cb8820bdbf5baf020f53fa1c465525d032b49b1cc30dde2e80dd7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db0abe317b18248d9510004387f8a3c23de0efbf3175e6138eac8ab104a4b543',1976,'DE','Germany','economy',358,'Aid: mainly from Portugal
Budget: (FY75) balanced at $530 million prelim.
Monetary conversion rate: 26.68 escudos = US$1 as
of August 1975 (approximate realigned rate), floating
Fiseal year: calendar year
Budget: expenditures, FY76—current expenditures,
$1,438 million; capital expenditures, $1,385 million
Monetary conversion rate: 9.9 rupees = US$]
(since February 1973)
158
Fiseal year: 1 July - 80 June
Aid: U.S., FY62-73, $8.3 million; Belgium, France,
West Germany, and Canada, FY64-67, $33.4 million
obligated; China $22 million extended 1972
Budget: balanced at $34.7 million (FY74)
Monetary conversion rate: 92.84 Rwanda
francs = US$1 (official) since January 1974
Fiscal year: calendar year
Monetary conversion rate: 1 Saudi tiyal = US$0.29
as of March 1975 (linked to SDR, freely convertible)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SAUDI ARABIA/SENEGAL
Fiscal year: follows Islamic year; the 1973-74
Saudi fiscal year covers the period 30 July 1973
through 1 July 1974
Aid: economic — U.S. (FY61-73) $503 million;
(1971 estimated disbursements) Belgium, $31.4
million; France, $6.6 million; other bilateral aid $5.4
million; U.N., $9.4 million; EC, $18.9 million; China
(1973) $100 million; military — U.S., $50 million
(FY62-73)
Budget: 1974—revenue $1,076 million, expendi-
ture $1,229 million, capital expenditure $261
Monetary conversion rate: 1 zaire = US$2
Fiscal year: calendar year','1348013817d0cd3ef9ab423ed1a8a48364311dd2fe78a21b191a24d6e2643f2e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59706343535e67a0567b69ec5fcce8f4cdd9fde04ae4c7b5f3b232e8c13433df',1976,'NR','Nauru','economy',363,'GNP: $28 million (1970), $4,000 per capita (est. )
Agriculture: negligible; almost completely
dependent on imports for food, water
Major industries: mining of phosphates, about 2
million tons per year (1970)
Electric power: 8,300 kw. capacity (1974); 24
million kw.-hr. produced (1974), 3,428 kw.-hr. per
capita
Exports: $27 million (f.o.b., 1970 est.), consisting
entirely of phosphates
Imports: $5 million (c.i.f., FY70)
Major trade partners: exports—Australia 58%,
New Zealand 22%, Japan 18%; imports—Australia
75%, U.K. 8%, New Zealand 5%, Japan 5%
Monetary conversion rate: 1 Australian del-
lar = US$1.31 (official) (1975)
Fiscal year: 1 July - 30 June','a89cedaf1af0d91130008e84abaa8a923694cf551b28fd3b517ba011a2a7c18f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25049c78dcd5cd6931cebc15f8287ed65485cdbacb918cc015aba48c7b3c73e9',1976,'NP','Nepal','economy',367,'GDP: $1,071 million (FY78 at current prices), less
than $100 per capita; 2% real growth in FY73
Agriculture: over 90% of population engaged in
agriculture; main crops — rice, corn, wheat,
sugarcane, oilseeds
Major industries: small rice, jute, sugar, and
oilseed mills; match, cigarette, and brick factories
Electric power: 64,000 kw. capacity (1974); 110
million kw.-hr. produced (1974), 9 kw.-hr. per capita
Exports: $48 million est. (FY70); rice and other
food products, jute, timber
Imports: $84 million est. (FY70); manufactured
consumer goods, fuel, construction materials, food
products
Major trade partner: over 80% India
Monetary conversion rate: 12.5 Nepalese
rupees = US$1 (October 1975)
Fiscal year: 15 July - 14 July','6bbea3143991e33ad6ea1f126cdd4d1935e5ab6c593b265c2b2b197291bb8f60','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d43fa2f3e4556a796c19f067c0c9d8d7b89ce370bcacb148e1828bf5da70679c',1976,'NZ','New Zealand','economy',373,'GNP: $11.7 billion (1974), $3,870 per capita; real
average annual growth (1969-74) 3.8%
Agriculture: fodder and silage crops about one-half
of area planted in field crops; main products — wool,
meat, dairy products; New Zealand is food surplus
country; caloric intake, 3,500 calories per day per
capita (1964)
Fishing: catch 58,000 metric tons (1972), $29.4
million 1973
Major industries: food processing, textile
production, machinery, transport equipment; wood
and paper products
Electric power: 4,653,000 kw. capacity (1974);
18.3 billion kw.-hr. produced (1974), 6,101 kw.-hr. per
capita
Exports: $2.1 billion including re-exports (f.0.b.,
trade year 1975); principal products (1974) — meat
30%, wool 20%, dairy products 17%
Imports: $3.7 billion (c.i.f., trade year 1975); ma-
chinery 30%, manufactured goods 24%, chemicals
12% (1974)
Major trade partners: trade year 1975); exports—
22% U.K., 12% U.S., 12% Japan, 11% Australia;
imports—19% Australia, 19% U.K., 14% Japan,
13% USS.
Aid: gross official aid deliveries to LDC and
multilateral agencies 1973, $27.6 million
Budget: expenditures, 3,325 million NZ$, receipts,
3,070 million NZ$ (FY75)
Monetary conversion rate: NZ$1=US$1.06,
October 1975
Fiseal year: 1 April - 31 March
NOTE: trade data are for year ending 30 June
1975; trade year and fiscal year do not correspond','2805e53c5f83b1069cc79329182d424894697ff1292760cdcb39c26545dc2771','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30448d9e542e67db530f34e418286e48e033d486ea41114a7a3a9ba76cc8333d',1976,'NI','Nicaragua','economy',377,'GDP: $1,230 million (1973 prices, 1974), $580 per
capita; 70% private consumption, 6% government
consumption, 27% domestic investment, —3% net
foreign balance (1973); real growth rate 1974, 11%
Agriculture: main crops — cotton, coffee,
sugarcane, rice, corn, beans, cattle; caloric intake,
2,300 calories per day per capita (1966)
Fishing: catch 11,200 metric tons (1972); $9.6
million (1970); exports $6.1 million (1971)
Major industries: food processing, chemicals,
metal products, textiles and clothing
Electric power: 217,000 kw. capacity (1974); 700
million kw.-hr. produced (1974), 345 kw.-hr. per
capita
Exports: $382 million (f.0.b., 1974); cotton, coffee,
chemical products, meat, sugar
Imports: $563 million (c.i.f., 1974); food and non-
food agricultural products, chemicals and phar-
maceuticals, transportation equipment, machinery,
construction materials, clothing, petroleum
Major trade partners: exports — U.S. 33%, Japan
12%, CACM 22%, West Germany 9%; imports —U.S.
34%, CACM 27%, Japan 7%, West Germany 7%,
Venezuela 5% (1978)
Aid: economic — extensions from U.S. (U.S. FY46-
73), $137 million loans, $76 million grants;
international organizations (U.S. FY46-73), $240
million; military — from U.S. (U.S. FY46-73), $17
million
Monetary conversion rate: 7 cordobas=US$1
(official)
Fiscal year: calendar year','f0dab2d04d374a17ec4d8655e408faf8ea6798817daafee829681c57cdfc11e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('123b05f40512307640383653deb0d145a6e4298b955112f25db6a80347160031',1976,'NE','Niger','economy',381,'GDP: $400 million (1972 est.), $100 per capita
Agriculture: commercial — peanuts, cotton,
livestock; main food crops — millet, sorghum, niebe
beans, vegetables
Major industries: cement plant, brick factory, rice
mill, small cotton gins, oil presses, slaughterhouse, and
a few other small light industries; uranium production
began in 1971
Electric power: 61,200 kw. capacity (1974); 59
million kw.-hr. produced (1974), 13 kw.-hr. per capita
Exports: $62 million (f.o.b., 1973); about 60%
peanuts and related products, rest largely livestock,
hides, skins; exports understated because much
regional trade not recorded
Imports: $86 million (c.i.f., 1973); fuels,
machinery, transport equipment, foodstuffs, consum-
er goods (largely for European residents); sizable
imports unrecorded
Major trade partners: France (over 50% ), other EC
countries, Nigeria, UDEAC countries, U:S.;
preferential tariff to EC and franc zone countries
Aid: economic — France (1960 to mid-1967) $68
million; EC (FY61-73) $100 million; U.S. (FY61-73)
$26 million; West Germany, Israel, Republic of
China, and U.N. have also extended aid; military —
$2.8 million (1954-68)
Budget: projected to balance at about $70 million
(1975)
Monetary conversion rate: about 219.98 Com-
munaute Financiere Africaine=US$1 as of August
1975, floating since February 1973
Fiscal year: 1 October - 30 September','305900cf1e6a0bf40e46665fcfe184864c9992004065a7f87a5a4d4394b1b9d2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4f0e129242ac3f33063e07a9de988dd41a80caf6c2b75c9023ee86062237250',1976,'NG','Nigeria','economy',385,'GDP: $23 billion (1974 current prices), $380 per
capita; 10% growth rate (1973-74)
Agriculture: main crops — peanuts, cotton, cocoa,
rubber, yams, cassava, sorghum, palm kernels, millet,
corn, rice; livestock; almost self-sufficient
Fishing: catch 156,000 metric tons (1970); imports
$3.7 million (1971)
Major industries: mining — crude oil, natural gas,
coal, tin, columbite; processing industries — oil palm,
peanut, cotton, rubber, petroleum, wood, hides, skins;
manufacturing industries — textiles, cement, building
materials, food products, footwear, chemical,
printing, ceramics
Electric power: 1,330,000 kw. capacity (1974); 2.6
billion kw.-hr. produced (1974), 42 kw.-hr. per capita
Exports: $9.3 billion (f.o.b., 1974); oil (92%),
peanuts, palm products, cocoa, rubber, cotton,
timber, tin
Imports: $2.8 billion (c.i.f., 1974); machinery and
transport equipment, manufactured goods, chemicals
Major trade partners: U.K., EC, U.S.
Budget: FY75 est. — current revenue $5.1 billion,
current expenditure $1.5 billion, capital expenditure
$2.6 billion, $1 billion transferred to States
Monetary conversion rate: | Naira=US$1.62
(official)
Fiscal year: 1 April - 31 March','71a2ffdb26b14db2bb8450d5918772ff1542f1424630519e336eb6582b2144b3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ab99c2694b7e4ee5f6554a9e760fe074a73ea0f8adf9296ccc76f0622273ead',1976,'NO','Norway','economy',389,'GNP: $23.4 billion in 1974 (at 1974 prices), $5,860
per capita; 52.3% private consumption; 33.8%
investment; 16.5% government; net foreign balance
—2.6%; 1974 growth rate 3.7%, in constant prices
155
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NORWAY/OMAN
Agriculture: animal husbandry predominates;
main crops — feed grains, potatoes, fruits, vegetables;
40% self-sufficient; food shortages — food grains,
sugar; caloric intake, 2,940 calories per day per capita
(1969-70)
Fishing: catch 2.4 million metric tons (1974); value
$290 million (1974); exports $28 million
Major industries: food processing, shipbuilding,
wood pulp, paper products, metals, chemicals
Shortages: most raw materials with the exception of
timber, iron, copper, and ilmenite ore, dairy products
and fish
Crude steel: 944,000 metric tons produced (1974),
236 kilograms per capita
Electric power: 15,400,000 kw. capacity (1974);
76.7 billion kw.-hr. produced (1974), 15,500 kw.-hr.
per capita
Exports: $6,313 million (f.0.b., 1974); principal
items—metals, pulp and paper, fish products, ships,
chemicals
Imports: $8,314 million (c.if., 1974); principal
items—foodstuff, ships, fuels, motor vehicles, iron and
steel, chemical compounds, textiles
Major trade partners: EC 44.4% (U.K. 12.8%,
West Germany 12.7%, Denmark 6.7%); Sweden
18.3%; U.S. 6.9%; Sino-Soviet countries 3.3% (1974)
Aid: economic — U.S., $482 million authorized
(FY46-73), $39.7 million in 1973; IBRD, $145 million
authorized through 1973, none since 1964; net official
economic aid delivered to less developed areas and
multilateral agencies, $134.2 million (1960-69); $36.8
million (1970); $42.4 million (1971), $63 million
(1972), $87 million (1973), $133 million (1974), $177
million (appropriated for 1975), $228 million
(proposed for 1976); military—U.S., $914.3 million
authorized (FY46-73), none since 1967
Budget: (1975) revenues $6,817 million, expendi-
tures $7,498 million
Monetary conversion rate: 1 kroner = US$0.1786
Fiscal year: calendar year
GNP: $900 million (1974 est.), $1,840 per capita
est.
Agriculture: based on subsistence farming (fruits,
dates, cereals, cattle, camels, fish) and trade
Major industries: petroleum discovery in 1964;
production began in 1967; production 1975. est.
320,000 b/d; pipeline capacity 400,000 b/d; revenue
for 1974 est. at $687 million
Electric power: 27,000 kw. capacity (1974); 70
million kw.-hr. produced (1974), 143 kw.-hr. per
capita
Exports: mostly petroleum; non-oil exports $1.2
million (1974)
Imports: $711 million (1974)
Major trade partners: U.K., Gulf states, India,
Australia, China, Japan
Aid: bilateral assistance pledged, $134 million in
1974, IBRD $8 million; aid commitment by Oman,
$39 million to miltilateral institutions
Budget: (1974 revised) revenues $695 million,
expenditures $720 million
Monetary conversion rate: 1 Riyal Omani=
US$2.90 (as of October 1973)
Fiscal year: calendar year','becbedd8d5a120827a8cff66eec5aa277b93fbd0156c0fe8b610b57b3129d9b0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8d15a5f98837988c4f99c4f08eac7643c064e64223c4934923f0634998be802',1976,'PK','Pakistan','economy',393,'GDP: $9.9 billion (FY75) at exchange rate of 9.9
rupees= US$1 prevailing June 1973, $140 per capita;
real growth 2.5% (FY75)
Agriculture: extensive irrigation; main crops —
wheat and cotton; foodgrain shortage, 1.5 million tons
imported in FY75
Fishing: catch 208,200 metric tons (1974)
Major industries: cotton textiles, food processing,
tobacco, engineering, chemicals, natural gas
Electric power: 2,370,000 kw. capacity (1974);
10.4 billion kw.-hr. produced (1974), 152 kw.-hr. per
capita
Exports: $1,047 million (f.0.b., FY75); cotton (raw
and manufactured), rice
Imports: $2,140 million (c.i.f., FY75); wheat, crude
oil, machinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West','aca2bf941a1bf3e2bf73b38eb0d2f186cc90c26f47166ae4978d45ad3be99019','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6429706df10e7a2df480e7f5cbb41558f4f7b6c89faeed496beb272f829474b',1976,'PA','Panama','economy',397,'GDP: 1,460 million (1978 est.), $930 per capita;
62% private consumption, 14% government con-
sumption, 80% gross fixed investment, —6% net
foreign balance (1973); real growth (1974), 3.5%
Agriculture: main crops — bananas, rice, corn,
coffee, sugarcane; self-sufficient in most basic foods;
2,450 calories per day per capita (1969)
Fishing: catch 56,500 metric tons, $10.4 million
(1971); exports $13.3 million (1971); imports $2.0
million (1971)
Major industries: food processing, metal products,
construction materials, petroleum products, clothing
Electric power (including Canal Zone): 380,000
kw. capacity (1974); 1.1 billion kw.-hr. produced
(1974), 715 kw.-hr. per capita
Exports: $205 million (f.0.b., 1974); bananas,
petroleum products, shrimp, sugar, meat, coffee
Imports: $800 million (c.i.f., 1974); manufactures,
transportation equipment, crude petroleum, chemi-
cals, foodstuffs
Major trade partners: exports — U.S. 44%, Canal
Zone NA, West Germany 15%; imports — U.S.
35%, Ecuador 11%, Venezuela 7% (1973)
Aid: economic — from U.S. (FY46-73), $254
million loans, $137 million grants; from international
organizations (FY46-73), $178 million; from other
Western countries (1960-71), $28.9 million; military
— assistance from U.S. (FY46-78), $6 million
Monetary conversion rate: 1 balboa=US$1
(official)
Fiscal year: calendar year','3130f9e4823437e94f588d1d018b9de8ceef31c81f152638833e962ed0d30d3a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee6244361665a3c08d8b57cdba4a9dd62e2728588e8977ed89a29737cba1a0ed',1976,'PY','Paraguay','economy',402,'GDP: $1.0 billion (1974, in 1973 dollars), $400 per
capita; 84% consumption; 16% gross domestic
investment (1973); real growth rate 1974 est., 8.0%
Agriculture: main crops — oilseeds, cotton, wheat,
manioc, sweet potatoes, tobacco, corn, rice,
sugarcane; self-sufficient in most foods; caloric intake,
2,580 calories per day per capita (1963-64); protein
intake, 70 grams per day per capita (20 grams of
animal origin)
Major industries: meat packing, oilseed crushing,
milling, brewing, textiles, light consumer goods,
cement
Electric power: 202,000 kw. capacity (1974); 300
million kw.-hr. produced (1974), 125 kw.-hr. per
capita
Exports: $172.9 million (f.0.b., 1974); meat,
timber, oilseeds, tobacco, cotton, quebracho extract,
hides, yerba mate, coffee
Imports: $198.2 million (f.0.b., 1974); foodstuffs,
machinery, transport equipment, fuels and lubricants,
textiles, chemicals
Major trade partners: U.S. 15%, Argentina 14%,
West Germany 13%, U.K. 9%
Aid: economic assistance — extensions from U.S.
(FY46-74), $79.0 million loans, $70.5 million grants;
from international organizations (FY46-73), $195.5
million; from other Western countries (1960-70),
$21.9 million; military — assistance from U.S. (FY57-
74), $19.0 million
Monetary conversion rate: 126 guaranies=US$1
(official rate)
Fiscal year: calendar year','49a3e7a9b605eaefb62824e4b5d83e09a404987cc6f36e399b6fcb938c52ee95','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('937f3bf1b34f770adb5c07c4f2c632cd87b5051c0bc44c82ef867f9c91b4a0e9',1976,'PE','Peru','economy',406,'GNP: $8.56 billion (1974), $590 per capita; 73%
private consumption, 10% public consumption, 12%
gross investment (1972); 5% net foreign balance; real
growth rate 1974, 6.3%
Agriculture: main crops — wheat, potatoes, beans,
barley, coffee, cotton, sugarcane; imports—wheat,
meat, lard and oils, rice, corn; caloric intake, 2,300
calories per day per capita (1964)
Fishing: catch 3.9 million metric tons (1974);
exports $250.0 million (1974)
Major industries: mining of metals, petroleum,
fishing, textiles and clothing, food processing, cement,
auto assembly, steel, ship-building, metal fabrication
Electric power: 2,500,000 kw. capacity (1974); 6.9
billion kw.-hr. produced (1974), 500 kw.-hr. per
capita
Exports: $2,405 million (f.0.b., 1974); fish and fish
products, copper, silver, iron, cotton, sugar, lead, zinc,
petroleum, coffee
Imports: $1,795 million (1974); foodstuffs,
machinery, transport equipment, iron and _ steel
semimanufactures, chemicals, pharmaceuticals
Major trade partners: exports — U.S. 33%,
Western Europe 30.2%, Japan 14%, Communist Bloc
countries 10.2%, Latin America 7%; imports — U.S.
29%, Western Europe 34%, Latin America 15%,
Japan 8% (1972)
Aid: economic — extensions from U.S. (FY46-73),
$583 million loans, $216 million grants; from
international organizations (FY46-73), $506 million;
from other Western countries (1960-72), $136.1
million; Communist countries (1969-74) $263 million;
military — assistance from U.S. (FY49-73), $148
million; from Communist countries (1974), $38
million
Monetary conversion rate: 45 soles = US$1 (trade);
48.38 soles=US$1 (non-trade)
Fiscal year: calendar year','85e71b205a00fa28f187756963807de2778c45d5a07bf8f93441a721f4502332','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da53ed2044759172c5acd2d32f9f67580ccb4478a0493665aa76913b9d37d537',1976,'PL','Poland','economy',410,'GNP: $69.1 billion in 1974 at 1973 prices, $2,050
per capita; 1974 growth rate 7.6%
Agriculture: self-sufficient for minimum require-
ments; main crops — grain, sugar beets, oilseeds,
potatoes, exporter of livestock products and sugar;
importer of grains; 3,200 calories per day per capita
(1970)
Fishing: catch 582,400 metric tons (1974)
Major industries: machine building, iron and steel,
extractive industries, chemicals, shipbuilding, and
food processing
Crude steel: 14.6 million metric tons produced
(1974), about 430 kg. per capita
Electric power: 19,130,000 kw. capacity (1974);
91.6 billion kw.-hr. produced (1974), 2,710 kw.-hr. per
capita
Exports: $8,321 million (f.0.b., 1974); 34%
machinery and equipment, 39% fuels, raw materials,
and semimanufactures, 13% agricultural and food
products, 9% light industrial products
Imports; $10,489 million (f.0.b., 1974); 42%
machinery and equipment; 41% fuels, raw materials,
and semimanufactures; 17% agricultural and food
products; 5% light industrial products
Major trade partners: $18,803 million (1974); 49%
with Communist countries, 51% with West
Monetary conversion rate: 3,32 zlotys=US$1
(commercial); 19.92 zlotys=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data
ure reported for calendar years except for caloric
intake which is reported for the consumption year, 1
July - 30 June ,
166','306e4854d0f02b4ff5e416fc179daa2cad57cc27c0b0d056b28b42a1537cc8fe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d33a012dcd1cf76bbef92a55277d8672275c307cf3c61bb50f80c225b835aec2',1976,'PT','Portugal','economy',414,'GNP: continental Portugal — $14.1 billion est.
(1974), $1,650 per capita; 71.2% consumption, 20.2%
investment, 13.6% government, —5,0% net exports of
goods and services (1972), real growth rate 2.5% in
1974
Agriculture: generally underdeveloped; main crops
— grains, potatoes, olives, grapes for wine; food
shortages — sugar, wheat; caloric intake, 2,730
calories per day per capita (1969)
Fishing: landed 283,540 metric tons, $144 million
(1974)
Major industries: cotton textiles, cork processing,
fish canning, petroleum refining, pulp and paper,
chemical fertilizer
Shortages: coal, petroleum, cotton, steel
Crude steel: 317,000 metric tons produced (1974),
50 kg. per capita
Electric power: 3,200,000 kw. capacity (1974), 10.5
billion kw.-hr. produced (1974), 1,000 kw.-hr. per
capita
167
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PORTUGAL/PORTUGUESE TIMOR
Exports: $2,262 million (f.0.b. 1974): principal
items — cotton textiles, cork and cork products,
canned fish, wine, timber and timber products, resin
Imports: $4,459 million (c.i.f., 1974); principal
items — petroleum, cotton, industrial machinery, iron
and steel, chemicals
Major trade partners: (1974) EC 45% (U.K. 14%,
W. Germany 12%, France 7%, Italy 5%); U.S. 9%:
Angola 7%; Spain 4%; Sweden 4%
Aid: economic — U.S., $240 million (FY49-73), $13
million authorized FY73; IBRD, $57.5 million
authorized (1964-66), none since 1966; net official aid
to less developed areas and multilateral agencies $578
million (1961-70), $79.5 million (1969), $57.1 million
(1970); military — U.S., $345 million authorized
(FY1949-73)
Budget: 1974 — receipts $2.275 billion, expendi-
tures $2.957 billion
Monetary conversion rate: 1 escudo=US$0.0394
(1974 average); 1 escudo= US$0.0375 (August 1975)
Fiscal year: calendar year
GNP: less than $100 per capita
Agriculture: staple crops — corn, rice, sweet
potatoes; cash crops — coffee, copra, rubber
Major industries: minimal light manufacturing,
tourism
Electric power: 3,500 kw. capacity (1974); 12
million kw.-hr. produced (1974), 18 kw.-hr. per capita
Exports: $4.6 million (f.0.b., 1973); 90% coffee, 6%
copra, timber, and rubber
Imports: $7.1 million (c.i.f., 1973); textiles,
machinery and equipment, petroleum, foodstuffs
Major trade partners: exports — Portugal, EEC,
Singapore; imports — EEC, Singapore, Macao, Hong
Kong, Australia
Budget: 1973 expeditures of $10.1 million, $4.6
million of which was provided by Portugal
Monetary conversion rate: Portuguese escudo
known in Timor as pataca; 28.75 patacas= US$L
Fiscal year: calendar year','588e838938b2235efe345f9564db86e5b8380ecd3df9cf2769493574903936c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8093561e8508ed65276aef94ac3ee2fd8238bc2ce3ae3f5c748a2317589d36e1',1976,'QA','Qatar','economy',418,'GNP: $1.6 billion (1974) $9,090 per capita
Agriculture: farming and grazing on small scale;
commercial fishing increasing in importance; most
food imported; rice and dates staple diet
Major industries: oil production and _ refining;
crude oil production from onshore and offshore
averaged 280,000 b/d (current); oil revenues accrued
$2.0 billion in 1974, representing 91% of govern-
ment/royal family income; major development
projects include $7 million harbor at Ad Dawhah,
fertilizer plant, 2 desalting plants, refrigerated storage
for fishing, and a cement plant
Electric power: capacity 85,000 kw. (1974); 279
million kw.-hr. produced (1974), 1,505 kw.-hr. per
capita
Exports: crude oil dominates; non-oil exports $19
million (1974 est.)
Imports: $265 million (c.i.f., 1974 est.)
Aid: aid donor, pledged $450 million 1974,
disbursed $200 million
Budget: (1975) budgeted expenditures $495 million
Monetary conversion rate: 1 Qatar-Dubai
riyal = US$0.26 (as of March 1975)
Fiscal year: 1 April - 31 March','2d9bc5d42035ce7b0ed6d3ea239503861151216dcfc57723acb980a3a5599ca8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f4b10b9aeca51dbae6eaf8fe44e1cff9b00354e2fdd5ab7140be53f9a3b0538',1976,'ZM','Zambia','economy',422,'GDP: $3.0 billion (1974), $475 per capita; real
growth rate 10% (1975)
Agriculture: main crops — tobacco, corn, sugar,
cotton; livestock; self-sufficient in foodstuffs except
wheat
Major industries: mining and steel, textiles
Electric power: 1,323,000 kw. capacity (1974); 5.8
billion kw.-hr. produced (1974), 934 kw.-hr. per
capita
Exports: $652 million (f.0.b., 1973), including net
gold sales and reexports; tobacco, asbestos, copper,
meat, chrome, gold, nickel, clothing, sugar
172
Imports: $541 million (c.i.f., 1973); machinery,
petroleum products, wheat, transport equipment
Major trade partners: South Africa, Portugal, and
Portuguese territories
Aid: no substantial military or economic aid
Budget: FY1976—revenues $678 million, expendi-
tures $895 million, deficit $217 million
Monetary conversion rate: 1 Rhodesian dol-
lar = US$1.54; 0.649 Rhodesian dollar =US$1
Fiscal year: 1 July - 30 June
GNP: $2.0 billion (1973 est.), $430 per capita; real
annual growth rate 1.4% between 1970 and 1973
Agriculture: main crops — corn, tobacco, cotton;
net importer of most major agricultural products
Fishing: catch 34,800 metric tons (1972); imports
$5.3 million (1970)
Major industries: copper mining and processing
Electric power: 891,800 kw. capacity (1974); 5.9
billion kw.-hr. produced (1974), 1,227 kw.-hr. per
capita
Exports: $1,406 million (f.0.b., 1974); copper, zinc,
cobalt, lead, tobacco
Imports: $904 million (ci.f., 1974); consumer
goods, machinery, transport equipment, foodstuffs,
fuels
Major trade partners: U.K., South Africa, Japan,
Western Europe
Aid: economic—China $280 million (1967-74);
(1964-67) U.K. $63 million; IBRD $242 million (1965-
73); U.S. $77 million (FY53-73): U.S.S.R. $9 million;
Eastern Europe $50 million; military — $9 million
(1964-69), mainly U.K. and Canada
Budget: 1975—revenue $1,005 million, expendi-
ture $1,179 million
230
Monetary conversion rate: 1 Zambia kwacha=
US$1.555 (official), 0.643 Zambia kwacha = US$1
Fiscal year: calendar year','bf31f8b1171ca9abbac21cfeb342957446ee5e491fb159da41bddea84c2113c7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1eb2933d99f1c97e898ff85f66f7da70acca77c0dc156c780bdffcf640aa2b2b',1976,'RO','Romania','economy',426,'GNP: $39.3 billion in 1974 (at 1973 prices), $1,860
per capita, real growth rate 8.8% (1971-74)
Agriculture: net exporter; main crops — corn,
wheat, oilseed; livestock — cattle, hogs, sheep; caloric
intake, 3,000 calories per day per capita (1967-68)
Fish catch: 85,000 metric tons (1972)
Major industries: machinery, metals, fuels,
chemicals, textiles, food processing, timber processing
Shortages: iron ore, coking coal, metallurgical
coke, cotton fibers, natural rubber
Crude steel: 8.8 million metric tons produced
(1974), 420 kg. per capita
Electric power: 10,900,000 kw. capacity (1974);
49.3 billion kw.-hr. produced (1974), 2,330 kw.-hr. per
capita
Exports: $4,874 million (f.0.b., 1974); 43% fuels,
raw materials, semifinished products; 21% machinery
and equipment, 20% foodstuffs; and 16% consumer
goods (1974)
Imports: $5,144 million (mixture f.o.b. and ci.£,
1974); 34% machinery and equipment; 54% fuels,
raw materials, semifinished products; 8% foodstuffs;
and 4% consumer goods (1974)
Major trade partners: $10,018 million in 1974;
58% non-Communist countries, 42% Communist
countries (1974)
Monetary conversion rate: 4.97 lei=US$1
(commercial) 12 lei=US$1 (tourist)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake,
which is reported for consumption year, 1 July - 30
June','f99ae79629248c0a320826fbc6a8cee43528711b9c845a30ada743b8aa444f06','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0317674bf26004e61d6e8bf700b1038640fefdd17daaccc5b7b8fa807b6c7db4',1976,'RW','Rwanda','economy',430,'GDP: $240 million (1971), $60 per capita
Agriculture: cash crops — mainly coffee, tea,
cotton, some pyrethrum; main food crops — bananas,
cassava; stock raising; self-sufficiency increasing but
country still imports some foodstuffs
Major industries: mining of cassiterite (tin ore),
agricultural processing, and light consumer goods
Electric power: 21,460 kw. capacity (1974); 100
million kw.-hr. produced (1974), 24 kw.-hr. per capita
Exports: $36 million (£.0.b., 1974); mainly coffee,
tea, pyrethrum, cassiterite
Imports: $31.1 million (c.i.f£, 1973); textiles,
foodstuffs, machines, equipment
Major trade partners: U.S., Belgium, West','4cb78ed9b489b3a93d417c451c6759152675ad3bb16f1e634fc6a41b6ad772e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b91ad767f61d4b765700c868d7bc37e8382373d5fa484be6af3119b4244fd31',1976,'AI','Anguilla','economy',434,'GDP: $15.2 million (1969), $260 per capita
Agriculture: main crops — sugar on St.
Christopher, cotton on Nevis
Major industries: sugar processing, salt extraction
Electric power: 15,000 kw. capacity (1974); 20
million kw.-hr. produced (1974), 9550 kw.-hr. per
capita
Exports: $6.1 million (f.0.b., 1972); sugar,
molasses, cotton, salt, copra
Imports: $15.3 million (c.if., 1972); foodstuffs,
fuel, manufactures
Major trade partners: U.K. 45%, Canada 14%,
U.S. 12% (1966)
175
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ST. CHRISTOPHER-NEVIS-ANGUILLA/ST. LUCIA
Monetary conversion rate: 2.07 East Caribbean
dollars = US$1 (May 1975): now floating with pound
sterling
GDP: $33.2 million (1971 est.), $290 per capita:
real growth rate 1971, 5.8%
Agriculture: main crops — bananas, copra, sugar,
cocoa, spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 13,500 kw. capacity (1974); 34
million kw.-hr. produced (1974); 250 kw.-hr. per
capita
Exports: $4.4 million (f.0.b., 1970): sugar, bananas,
cocoa
Imports: $27.3 million (c.if., 1970); foodstuffs,
machinery and equipment, fertilizers, petroleum
products
Major trade partners: U.K. 51%, Canada 9%, U.S.
17% (1970)
Monetary conversion rate: 2.07 East Caribbean
dollars = US$1 (May 1975); now floating with pound
sterling
GDP: $20 million (1971 est.), $200 per capita; 6.9%
growth in 1971
Agriculture: main crops — bananas, arrowroot,
coconut
Major industries: food processing
Electric power: 5,000 kw. capacity (1974); 15.5
million kw.-hr. produced (1974), 160 kw.-hr. per
capita
Exports: $2.9 million (f.0.b., 1971); bananas,
arrowroot, copra, cotton
Imports: $17.4 million (c.i.f., 1971); fertilizer,
flour, transportation equipment, lumber, textiles
Major trade partners: U.K. 39%, U.S. 7%, Canada
10% (1971)
Monetary conversion rate: 2.07 East Caribbean
dollars =US$1 (May 1975), now floating with pound
sterling','5d11085bfbd1932c86dad7d730a345ed2c414fa546304d9c5b21be957cab0ae4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8931b1cee8c0fa6b068e1e498b6bc76b92a6dea429c4d6296b510c69e67f80c0',1976,'SM','San Marino','economy',438,'Principal economic activities of San Marino are
farming, livestock raising, light manufacturing, and
tourism; the government''s total budget for FY71 was
about $12 million, with the largest share of revenue
derived from the sale of postage stamps throughout
the world and from payments by the Italian
government in exchange for Italy’s monopoly in
retailing tobacco, gasoline, and a few other goods;
main problem is finding an additional $3 million to
finance badly needed water and electric power
systems expansions
Agriculture: principal crops are wheat (average
annual output about 4,400 metric tons/year) and
grapes (average annual output about 700 metric
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SAN MARINO/SAO TOME AND PRINCIPE
tons/year); other grains, fruits, vegetables, and animal
feedstuffs are also grown; livestock population
numbers roughly 6,000 cows, oxen, and sheep; cheese
and hides are most important livestock products
Electric power: obtained from Italy, 1974
Manufacturing: consists mainly of cotton textile
production at Scrravalle, brick and tile production at
Dogane, cement production at Acquaviva, Dogane,
and Fiorentino, and pottery production at Borgo
Maggiore; some tanned hides, paper, candy, baked
goods, Moscato wine, and gold and silver souvenirs
are also produced
Foreign transactions: dominated by tourism; in
summer months 20,000 to 30,000 foreigners visit San
Marino every day; a number of hotels and restaurants
have been built in recent years to accommodate them;
remittances from Sanmarinese abroad also represent
an important net forcign inflow; commodity trade
consists primarily of exchanging building stone, lime,
wood, chestnuts, wheat, wine, baked goods, hides,
and ceramics for a wide variety of consumer
manufactures','5b97ee438357e63d7c550883f826a1faa9d5057d98d6c8b20b19661473601c0f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d78cc24b99783296672d31320c58a35b027c0b1e847a478c8e629931343900a1',1976,'SN','Senegal','economy',442,'GDP: $930 million (1973 est. ); $230 per capita; real
growth rate probably zero or negative since 1972
(1966-71)
Agriculture: main crops — peanuts, millet,
sorghum, manioc, rice; peanuts primary cash crop;
production of food crops increasing but still
insufficient for domestic requirements
Fishing: catch 249,000 metric tons, $55.2 million,
(1972); exports $12 million (1971), imports (not
available)
Major industries: fishing, agricultural processing
plants, light manufacturing, mining
Electric power: 107,800 kw. capacity (1974); 425
million kw.-hr. produced (1974), 106 kw.-hr. per
capita
Exports: $427 million (f.0.b., 1974), approx. 35%
peanuts and peanut products; phosphate rock;
canned fish
Imports: $543 million (c.i.f., 1974); food, consumer
goods, machinery, transport equipment
Major trade partners: France, EC (other than
France), and france zone
Aid: economic — France (1966-70) $115 million:
China (1973) $49.1 million; U.S. (FY1961-73) $44
million; U.S.S.R. $7.1 million; EC (1961-73) $154
million; military — U.S. (FY61-73) $2.8 million
Budget: 1976—balanced at $535.5 million
Monetary conversion rate: francs; about 219.98
Communaute Financiere Africaine francs = US$1 as of
August 1975 (floating since February 1973)
Fiscal year: | July - 30 June','91e980c88eae15dcd2d39b5024e04999d4906275d23d8561605d6fd57d3b70d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f663954900fdcb3276dee899e592e893ef0a7964d6a1d83d596d1e1250fe39f',1976,'SL','Sierra Leone','economy',446,'GDP: $493 million (1974), approx. $180 per capita;
growth rate 22% (1973-74)
Agriculture: main crops — palm kernels, coffee,
cocoa, rice, yams, millet, ginger, cassava; much of
cultivated land devoted to subsistence farming; food
crops insufficient for domestic consumption
Fishing: catch 51,000 metric tons (1972), $6.6
million (1972), imports $2.7 million (1971)
Major industries: mining — diamonds, iron ore,
bauxite, rutile; manufacturing — beverages, textiles,
cigarettes, construction goods; 1 oi] refinery
Electric power: 57,000 kw. capacity (1974); 270
million kw.-hr. produced (1974), 63 kw.-hr. per capita
Exports: $141 million (f.o.b., 1974); 60%
diamonds; iron ore, palm kernels, cocoa, coffee
Imports: $216 million (c.i.f., 1974); machinery and
transportation equipment, manufactured goods,
foodstuffs, petroleum products
Major trade partners: U.K., EC, Japan, U.S,
Communist countries
Budget: (FY74) current revenues $106 million,
current expenditures $82 million
Monetary conversion rate: 1 leone =US$1.19
Fiscal year: 1 July - 30 June (since 1 July 1966)','83a2f061956742975231cb62ac8945252489b80dbdb6678d49c90ceae089dc80','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31bdd4ce7d0241030468321cd7ff1faafe1f703483cc7997feb2b7051f6d302b',1976,'SG','Singapore','economy',450,'GNP: $5.5 billion (1974), $2,400 per capita; 12.3%
average annual real growth (1966-74), 6.8% (1974)
Agriculture: occupies a position of minor
importance in the economy, self-sufficient in pork,
poultry, and eggs, must import much of its other food
requirements; major crops — rubber, copra, fruit and
vegetables
Fishing: catch 15,700 metric tons (1972), imports
— 47,000 metric tons (1972)
Major industries: petroleum refining, oil drilling
equipment, rubber processing and rubber products,
processed food and beverages, electronics, ship repair,
entrepot trade, financial services
Electric power: 1,109,000 kw. capacity (1974); 3.9
billion kw.-hr. produced (1974), 1,773 kw.-hr. per
capita
Exports: $6.2 billion (f.0.b., 1974): 40% reexports;
petroleum products, rubber, manufactured goods
Imports: $8.9 billion (c.i.f., 1974); 18% goods
reexported; major retained imports — capital
equipment, manufactured goods, petroleum
Major trade partners: exports — Malaysia,
U.S., Japan, U.K., Indonesia; imports — Japan,
Malaysia, U.S., U.K.
Aid: U.K. — (1960 - September 1969) $254 million
disbursed, (1969-73) $120 million extended; IBRD —
185
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SINGAPORE/SOMALIA
(1963-74) $143 million committed, $61 million
disbursed; U.S. — (FY53-74) $102 million committed
Budget: (FY75/76) revenues $1.1 billion, expendi-
tures $1.8 billion, deficit $700 million; 25% military,
75% civilian
Monetary conversion rate: 2.48 Singapore
dollars = US$1 (August 1975)
Fiscal year: } April - 31 March','3b3c1a3138322fdb4fb2421dc2041d00f46c41526087f48f636a2702ced888df','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('925e472abdf126179a6e8027a496f12b7178684c9c869ae454fb8ea8a574a499',1976,'SO','Somalia','economy',454,'GDP: $220 million (1978 est.), $70 per capita
Agriculture: mainly a pastoral country; main crops
— bananas, sugarcane, cotton, cereals: livestock
Major industries: a few small industries, including
a sugar refinery, tuna and beef canneries, iron rod
plant
Electric power: 9,000 kw. capacity (1974); 38
million kw.-hr. produced (1974), 12 kw.-hr. per capita
Exports: $55 million (f.0b., 1974); bananas,
livestock, hides, skins
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SOMALIA/SOUTH AFRICA
Imports: $157 million (c.if., 1974); textiles, cereals,
transport equipment,
equipment
Major trade partners: Italy and Arab countries;
$29 million imports from Communist countries (1973
est.)
Monetary conversion rate: 6.295 Somali. shil-
lings=US$1
Fiscal year: 1 January - 31 December','b7748e69c5fc2d77e02ac2f791e4a244889580100ebc1e7d33c78c919a88ae5d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d31f46364be2f105a3eb3f2d95fb1774182dc24bcf865920584c12cf81048e36',1976,'ZA','South Africa','economy',458,'GDP: $31 billion (1974), $1,240 per capita; real
growth rate 7.2% (1974)
Agriculture: main crops — corn, wool, wheat,
sugarcane, tobacco, citrus fruits; dairy products; self-
sufficient in foodstuffs
Fishing: catch 1.3 million metric tons (1973), $176
million (1973)
Major industries: mining, automobile assembly,
metalworking, machinery, textiles, iron and steel,
chemical, fertilizer, fishing
Electric power: 11,635,000 kw. capacity (1974);
70.8 billion kw.-hr. produced (1974), 2,750 kw.-hr. per
capita
Exports: $4.4 billion (f.0.b.. 1974, excluding gold);
wool, diamonds, corn, uranium, sugar, fruit, hides,
skins, metals, metallic ores, asbestos, fish products;
gold output $3.6 billion (1974)
Imports: $8.0 billion (f.0.b., 1974); motor vehicles,
machinery, metals, petroleum products, _ textiles,
chemicals
Major trade partners: U.K. and other Common-
wealth nations, U.S., West Germany, Japan
Aid: no substantial military or economic aid
Budget: FY76 — revenue $9.1 billion, expenditures
$9.6 billion
Monetary conversion rate: | SA Rand = US$1.15 as
of November 1975, 0.87 SA Rand =US$1
Fiscal year: 1 April - 31 March
NOTE: Foreign trade figures are official South
African data converted at $1.40
Agriculture: livestock raising (cattle and sheep)
predominates, subsistence crops (millet, sorghum,
corn, and some wheat) are raised but most food must
be imported
Fishing: catch 567,600 metric tons (1972)
(processed mostly in South African enclave of Walvis
Bay)
Major industries: meatpacking, fish processing,
copper, lead, and diamond mining, dairy products
Electric power: 155,200 kw. capacity (1974), 543
million kw.-hr. produced (1974), 690 kw.-hr. per
capita
Aid: South Africa is only major donor
Monetary conversion rate: 1 South African
Rand=US$1.15 (as of June 1974); 0.87 SA
Rand=US$1
Fiscal year: 1 April - $1 March','92e2d3741374f8b840218207b56c96bb7ab7a57f058951e6108f3218ffd9719b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a49c2d8afdcb72f771c70d8239914745c6f7c5fd74cbc6c9453c526e2f1bd0b',1976,'ES','Spain','economy',460,'GNP: $73.3 billion est. (1974); $2,080 per capita;
65.4% consumption, 23.5% investment, 11.1%
government 1973; real growth rate 4.9% (1974)
Agriculture: main crops — cereals, oranges, grapes
for wine, potatoes, olives, sugar beets; virtually self-
sufficient in good crop years; caloric intake, 2,750
calories per day per capita (1969-70)
Fishing: landed 850,578 metric tons valued at
$458.4 million in 1973
Major industries: food processing, textiles and
apparel (including footwear), metal manufacturing,
chemicals, shipbuilding, automobiles
Shortages: crude petroleum
Approved For Release 2005/04/22 :
Crude steel: 11.5 million metric tons produced
(1974), 330 kilograms per capita
Electric power: 24,933,410 kw. capacity (1974);
80.8 billion kw.-hr. produced (1974), 2,050 kw.-hr. per
capita
Exports: $7,091 million (f.0.b., 1974); principal
items — oranges and other fruits, iron and steel
products, textiles, wines, mercury, ships, canned fruits,
vegetables
Imports: $15,428 million (c.i.f., 1974); principal
items — machinery and transportation equipment,
petroleum and petroleum products, grains, cotton,
iron and steel
Major trade partners: (1974) EC 32%, U.S. and
Canada 15%, Latin America 8%, CEMA 2%
Aid: economic — U.S., $2.8 billion authorized
(FY46-73), IBRD, $427 million authorized (FY64-73),
$50.0 million authorized (FY73); military — U.S.,
$839 million authorized (FY53-73)
Budget: (1974) receipts 615 billion pesetas,
expenditures 625 billion pesetas, deficit 10 billion
pesetas
Monetary conversion rate: | peseta = US$0.0178
(1974 average)
Fiscal year: calendar year
Agriculture: practically none; some barley is grown
in nondrought years; fruit and vegetables in the few
oases; food imports are essential; camels, sheep, and
goats are kept by the nomadic natives: cash economy
exists largely for the garrison forces
Major industries: confined to fishing and
handicrafts; exploitation of huge phosphate deposit is
planned
Shortages: water
Electric power: 3,450 kw. capacity (1974); 8.4
million kw.-hr. produced (1974), 110 kw.-hr. per
capita
Exports: $445,600 (1968); dried fish, goatskins
Imports: $1,443,000 (1968): fuel for fishing fleet,
foodstuffs
Major trade partners: monctary trade largely with
Spain and Spanish possessions
Aid: small amounts from Spain
Monetary conversion rate: 58.03 pesetas = US$1
(official), set February 1973','d8f84319a213fda746b6925f627a877b0930394ddc4b45fe52429ba19a06d49f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1382693b094222f480d6855c20a037f3220a0f4470ed4b7219ddec9c825db78',1976,'LK','Sri Lanka','economy',466,'GNP: $2.3 billion in 1974 (1973 prices), $170 per
capita; real growth rate 3.4% (1974)
Agriculture: agriculture accounts for about 35% of
GNP; main crops — rice, rubber, tea, coconuts; 60%
self-sufficient in food; food shortages — rice, wheat,
sugar
Fishing: catch 99,116 metric tons (1973)
Major industries: processing of rubber, tea, and
other agricultural commodities; consumer goods
manufacture
Electric power: 422,000 kw. capacity (1974); 1.2
billion kw.-hr. produced (1974), 88 kw.-hr. per capita
Exports: $537 million (1974); tea, rubber, coconut
products
Prime Minister Sirimavo
193
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SRI LANKA/SUDAN
Imports: $717 million (1974); food, petroleum,
machinery and equipment
Major trade partners: (1973) exports — U.K.
11,5%, China 9.1%, Pakistan 8.2%, U.S. 6.9%,
U.S.S.R. 2.4%; imports — U.K. 6.8%, China 7.8%,
India 3.0%, U.S. 9.0%, U.S.S.R. 1.7%
Monetary conversion rate: 7.57 rupees=US$1
(October 1975), official rate
Fiscal year: | January - 31 December (starting
1973)','1f77369974f7a0cc6230a5817ea2b53d92528f392f66d7a4a827db88fb012b30','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf70f73f0d836aa1999a6e986e2db3647b023cccd78ae32bedfa57dcde857e81',1976,'SD','Sudan','economy',470,'GDP: $1.6 billion (1972), under $100 per capita;
8% growth at current prices 1968-69
Agriculture: main crops — sorghum, millet, wheat,
sesame, peanuts, beans, barley; not self-sufficient in
food production; main cash crops — cotton, gum
arabic
Major industries: cotton ginning, textiles, brewery,
cement, edible oils, soap, distilling, shoes, phar-
maceuticals
Electric power: 553,000 kw. capacity (1974); 655
million kw.-hr. produced (1974), 37 kw.-hr. per capita
Exports: $350 million (f.0.b., 1974); cotton (36%),
gum arabic, peanuts, sesame; $102 million exports to
Communist countries (FY71)
Imports: $642 million (cif., 1974); textiles,
petroleum products, vehicles, tea, wheat; $75 million
imports from Communist countries (FY71)
Major trade partners: U.K., West Germany, Italy,
India, U.S.S.R., China
Monetary conversion rate: 1 Sudanese pound =
US$2.87 (official), 0.348 Sudanese pound = US$1
Fiscal year: 1 July - 30 June
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
GNP: $395 million (1974); $850 per capita; real
growth rate 1974, 5.7%
Agriculture: main crops — rice, sugarcane,
bananas; self-sufficient in major staple (rice); caloric
intake 2,350 calories per day per capita (1968)
Major industries: bauxite mining, alumina and
aluminum production, lumbering, food processing
Electric power: 300,000 kw. capacity (1974): 1.7
billion kw.-hr. produced (1974), 3,800 kw.-hr. per
capita
Exports: $252 million (f.0.b., 1974); bauxite,
alumina, aluminum, wood and wood products, rice
Imports: $228 million (c.i.f., 1974); capital
equipment, petroleum, iron and steel, cotton, flour,
meat, dairy products
Major trade partners; exports — U.S. 39%,
Canada 2%, Netherlands 14%; imports — U.S, 85%,
Netherlands 22%, Europe 18% (1971)
Aid: economic — extensions from U.S. (FY53-73),
$5.0 million loans, $4.8 million grants; from
international organizations (FY49-73), $47.] million
Monetary conversion rate: 1.79 Surinam guilders
(S. fl.)=US$1 (27 December 1971)
Fiscal year: calendar year
GDP: approx. $120 million (FY72), about $280 per
capita; growth rate in current prices as much as 14.5%
(FY68-72)
Agriculture: main crops — maize, cotton, rice,
sugar, and citrus fruits
Major industry: mining
Electric power: 67,800 kw. capacity (1974); 220
million kw.-hr. produced (1974), 500 kw.-hr. per
capita
Exports: $93 million (f.o.b., 1972); iron ore,
asbestos, sugar, wood and forest products, citrus, meat
products, cotton
Imports: $76 million (f.0.b., 1972); food products,
manufactured goods, machinery, fertilizer, fuel
Major trade partners: Japan, U.K., South Africa
Aid: economic aid — U.K. $14.7 million
(budgeted, 1971-73), U.S. $6.6 million (FY61-73),
others approximately $1.3 million; no military aid
Budget: FY76 — revenue $85 million, recurrent
expenditure $50 million, development expenditure
$37 million
197
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SWAZILAND/SWEDEN
Monetary conversion rate: | Lilangeni=US$1.15
(as of November 1975)
Fiscal year: | April - 31 March','3bdc3cbd96fa2429b94676d3c91ccce2b14c9c1d503466e1e5b51b4cea1126ba','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3472d7a540bb63c28bf614d07d61f318194ad6daeb7a645b8a42eb361c668742',1976,'SE','Sweden','economy',474,'GNP: $56.0 billion, $6,850 per capita (1974):
53.2% consumption, 23.5% investment, 23.0%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Appro
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
SWEDEN/SWITZERLAND
government, 0.3% net exports of goods and services
(1973); 1974 growth rate 4.5% in constant prices
Agriculture: animal husbandry predominates with
milk and dairy products accounting for 40% of farm
income; main crops — grains, sugar bects, potatoes,
80% self-sufficient, food shortages — oils and fats,
tropical products; caloric intake, 2,880 calories per
day per capita (1967-68)
Fishing: catch 212,000 metric tons (1973), exports
$27 million, imports $136 million
Major industries: iron and _ steel, precision
equipment (bearings, radio and telephone parts,
armaments), shipbuilding, wood pulp and paper
products, processed foods, textiles, chemicals
Shortages: coal, petroleum, textile fibers, potash,
salt
Crude steel: 6.0 million metric tons produced
(1974), 733 kilograms per capita
Electric power: 19,426,000 kw. capacity (1974);
74.3 billion kw.-hr. produced (1974), 8,200 kw.-hr. per
capita
Exports: $15,854 million (f.0.b., 1974); machinery,
motor vehicles and ships, wood pulp, paper products,
iron and_ steel products, metal ores and scrap,
chemicals
Imports: $15,764 million (c.i-f., 1974); machinery,
motor vehicles, petroleum and petroleum products,
textile yarn and fabrics, iron and steel, chemicals,
food, and live animals
Major trade partners: (1974) West Germany 14%,
U.K. 12%, US. 5%, Norway 9%, Denmark 8%; EC-9
51%, U.S.S.R. and Eastern Europe 5%
Aid: economic — U.S., $308.6 million authorized
(FY46-73); $77.5 million in 1973; $24.7 million in
1972; net official aid to less developed countries and
multilateral agencies, $662.4 million (1960-70), $159
million in 1971, $198 million in 1972, $275 million in
1973
Budget: 1974 — revenues $16.2 billion, ex-
penditures $18.0 billion
Monetary conversion rate: 1 kronor = US$0.225
average exchange rate 1974
Fiscal year: 1 July - 30 June','f2ef43a66c8b67696b71caf7e6c1c428eacc0c6ce09bf0f9d8e586af1ce195d3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82e5590f2d7de8639f8e604f96d38abba519e2e44ce675251eeb4fd3f31a5d32',1976,'CH','Switzerland','economy',477,'GNP: $46.3 billion (1974, in current prices), $7,120
per capita; 60% consumption, 26% investment, 12%
government, net foreign balance 2% (1974): 1974
growth rate —0.8%, constant prices
Agriculture: dairy farming predominates; less than
50% self-sufficient: food shortages — fish, refined
Sugar, fats and oils (other than butter), rains, eggs,
fruits, vegetables, meat; caloric intake, 3,190 calories
per day per capita (1969-70)
Major industries; machinery, chemicals, watches,
textiles, precision instruments
Shortages: practically all important raw materials
except hydroelectric energy
Electric power: 11,600,000 kw, Capacity (1974).
35.8 billion kw.-hr. produced (1974), 5.300 kw.-hr. per
capita
Exports: $11.9 billion (f£.0.b., 1974): principal
items— machinery and equipment, precision
instruments, textiles, foodstuffs
Imports: $14.4 billion (c.i.f., 1974), principal
items— machinery and transportation equipment,
metals and metal products, foodstuffs, chemicals,
textile fibers and yarns
Major trade partners: West Germany 22%. France
12%, US. 7%, Austria 6%, Italy 9%, U_K. 6%; EC
56%; EFTA 11%; Communist countries 4% (1974)
Aid: economic — authorized, U.S. $63 million
through FY73; net official economic aid delivered to
less developed areas and multilateral agencies $194
million (FY62-72) $67 million in FY72
Budget: receipts, $4,030 million, expenditures
$4,378 million, deficit $348 million (1974)
Monetary conversion rate: 2.98] Swiss francs =
US$1 (average 1974, floating): 2.506 Swiss
francs = US$] (average first-half 1975, floating)
Fiscal year: calendar year
GDP: $2.1 billion, est. (1974), $300 per capita; real
GDP growth rate 12% 1973 est.
201
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SYRIA/TANZANIA
Agriculture: main crops — cotton, wheat, barley
and tobacco; sheep and goat raising; self-sufficient in
most foods in years of good weather
Major industries: textiles, petroleum (est. 50,000
b/d production, refining capacity was 54,000 b/d per
day, but reduced by war damage) food processing,
beverages, tobacco
Electric power: 447,500 kw. capacity (1974); 1.2
billion kw.-hr. produced (1974), 166 kw.-hr. per
capita
Exports: $787 million (f.o.b., 1974); petroleum,
cotton, fruits and vegetables, grain, wool, and
livestock
Imports: $1,235 million (c.i.f., 1974); machinery
and metal products, textiles, fuels, foodstuffs
Major trade partners: exports — U.S.S.R., Italy,
and Lebanon; imports — Lebanon, West Germany,
Italy, U.S.S.R., Japan, and France
Budget: 1975 est.—revenues $1.6 billion, expendi-
tures $1.7 billion
Monetary conversion rate: 3.70 Syrian pounds=
US$1
Fiscal year: calendar year
Mainland:
GDP: $1,919 million at current prices (1974 prov. ),
about $130 per capita; growth rate in constant 1966
prices for 1973-74 2%
Agriculture: main crops — cotton, coffee, sisal on
mainland; largely self-sufficient in food
Fishing: catch 157,000 metric tons, $19.6 million
(1972); exports $1.7 million, imports $724,000 (1971)
Major industries: primarily agricultural processing
(sugar, beer, cigarettes, sisal twine), diamond mine, oil
refinery, shoes, cement, textiles, wood products
Electric power: 175,000 kw. capacity (1974); 513
million kw.-hr. produced (1974), 34 kw.-hr. per capita
Exports: $428 million (f.0.b., 1974); coffee, cotton,
sisal, cashew nuts, meat, diamonds, cloves, tobacco,
tea
Imports: $811 million (c.i.f., 1974); manufactured
goods, machinery and transport equipment, cotton
piece goods, crude oil, foodstuffs (mainly for
Zanzibar)
Major trade partners: exports — China, U.K.,
Hong Kong, India, Kenya, U.S.; imports — U.K.,
China, Kenya, West Germany, U.S., Japan
Budget: (1972) receipts $306.3 million, expendi-
tures $306.6 million
Monetary conversion rate: 7.143 Tanzanian
shillings = US$1
Fiscal year: 1 July - 30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops — cloves, coconuts
Industries: agricultural processing
Electric power: see Tanganyika (above)
Exports: $12.6 million (1968); cloves and clove
products, coconut products
Imports: $5.6 million (1968); mainly foodstuffs and
consumer goods
Major trade partners: imports — China, Japan,
and mainland Tanzania; exports — Singapore,
China, Hong Kong, Indonesia, India, Pakistan
Aid: U.K. principal source of aid until 1964; U.S.
$86 million FY58-73; China is currently major source
Exchange rate: 1 Tanzanian shilling = US$0. 14;
7.143 Tanzanian shillings=US$1
Fiscal year: 1 July - 30 June','f0a2abfb308b3410fd2f4828869b8ecfa07eb5df0e7731b283e07546f87370d5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('673d9572f973c88e2c56e8adb1a8005d7c2bb4ec87396ee5ccd0888ddf9a3664',1976,'TH','Thailand','economy',481,'GDP: $12.2 billion (1974 in current prices), $280
per capita; estimated 4.5% real growth in 1974 (6.6%
real growth, 1967-74)
Agriculture: world’s third largest rice exporter in
1974; main crops — rice, sugar, corn, rubber, tapioca:
almost 100% self-sufficient in food
Fishing: catch 1.7 million metric tons valued at
$465 million (1974). exports, 53,000 metric tons, $36
million (1972)
Major industries: agricultural processing, textiles,
wood and wood products, cement, tin and tungsten
ore mining; world’s second largest tungsten producer
and third largest tin producer
Shortages: fuel sources, including coal, petroleum;
scrap iron, and fertilizer
Electric power: 2,211,000 kw. capacity (1974); 8.3
million kw.-hr. produced (1974), 2l0 kw.-hr. per
capita
Exports: $2,477 million (f.0.b., 1974); rice, sugar,
corn, rubber, tin, tapioca, kenaf
Imports: $3,168 million (c.if., 1974). excluding
U.S. military imports; machinery and transport
equipment, fuels and lubricants, base metals,
chemicals, and fertilizer
Major trade partners: exports — Japan, U.S.,
Singapore, Netherlands, Hong Kong, Malaysia:
imports — Japan, U.S., West Germany, U.K.; about
1% or less trade with Communist countries
Budget: (FY76) receipts $2,433 million, expendi-
tures $3,134 million, deficit $701 million; 17%
military, 83% civilian
: CIA-RDP79-01051A000800010001-8
soll a
Appro
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001
-8
January 1976
THAILAND/TOGO
Monetary conversion rate: 20.0 baht = US$1
Fiscal year: 1 October - 30 September
GNP: $3.0 billion (1974 est. ), $150 per capita; no
real growth estimated for 1974; large decline
anticipated for 1975
Agriculture: main crops — rice, rubber, fruits and
vegetables; major food imports — rice, wheat, dairy
products
Fishing: catch 728,000 metric tons (1974): growing
trade in fish and fish products
Major industries: manufacturing on small scale,
mainly light manufacturing and processing of local
agricultural and forest products; factories produce
textiles, beer, cigarettes, glass, tires, sugar, paper,
cement, soft drinks
Shortages: capital goods
Electric power: 883,000 kw. capacity (1974): 1.9
million kw.-hr. produced (1974), 95 kw.-hr. per capita
Exports: $70 million (f.o.b., 1974); major
commodities—fish and fish products, rubber, forestry
products, scrap metal
Imports: $879 million (c.if., 1974): major
commodities—food, petroleum products, fertilizer,
pharmaceuticals, iron and steel products, machinery,
textiles
Major trade partners: (1974) exports—Japan,
Hong Kong, Singapore, France: imports—U.S.,
Japan, France; no trade with Communist countries up
to 1975 *
Aid: (prior to 30 April 1975) economic—U.5.
(including P.L. 480), $477 million (FY70), $576
million (FY71), $455 million (FY72), $502 million
(FY73); approx. $654 million (FY74); approx. $500
million (FY75); numerous other non-Communist
countries providing assistance; military — U.S,
$1,728 million (FY70), $1,895 million (FY71), $2,398
million (FY72), $2,168 million (FY73), $946 million
(FY74)
Budget: (prior to 30 April 1975) $1,083 million (est.
1975), 44% military, 56% civilian; deficit of $395
million (est. 1975)
Monetary conversion rate: last official pre-
takeover rate was 755 piasters = US$1 (April 1975);
Communists issued new currency in September 1975
at rate of 500 old piasters=1 new piaster; no dollar
rate established but nominal value thought to be 3
new piasters = US$1
Fiscal year: calendar year
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
VIETNAM, SOUTH/WALLIS AND FUTUNA/WESTERN SAMOA','5e915cdd1a92014b2e3169be6e187374408a5f0d86f4bb3e6f84ff640d76923c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('271f19b91d564b8dc2cc2f53a6dc6c97b057c185d9b86a8d63ce30e5b1e48c8c',1976,'TG','Togo','economy',485,'GDP: $365 million (1973), about $170 per capita;
estimated real growth 1966-70, 5.3% average annual
rate
205
00010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008
January 1976
TOGO/TONGA
Agriculture: main cash crops — coffee, cocoa:
major food crops — yams, cassava, corn, beans, rice,
fish; must import some foodstuffs
Major industries; Phosphate mining, agricultural
Processing, handicrafts, textiles, beverages
Electric power; 24,300 kw. capacity (1974): 74.4
million kw.-hr. produced (1974), 37 kw.-hr, per capita
Exports: $88 million (f.0.b., 1974). phosphates,
cocoa, coffee, palm kernels, and cassava
Imports: $138 million (c.i.f,, 1974); consumer
goods, fuels, machinery, tobacco, foodstuffs
Major trade partners: mostly with France and
other EC countries
Aid: 1970 disbursements — France $2.3 million,
West Germany $2.0 million, U.S, $1.0 million; FY59-
73 total commitments — EC $59.0 million, U.S, $2]
million, U.N. $16.0 million, others $1.1 million;
China (1973) $45 million
Budget: 1974 est. revenues and expenditures, $67.7
million
Monetary conversion rate: Communaute Finan-
ciere Africaine 216 francs=US$1 as of January 1975
(floating since February 1973)
Fiscal year: calendar year','a4e739735e0d44dbb2e8f081a5686433b575c3ea7a59ba1702438db6db7be8c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d331c5af312a07eeb1869ee048566ed5c0bcfb92acac7c4c5063e667782d4a9',1976,'TO','Tonga','economy',489,'GNP: $23 million (1973 est.), $160 per capita
Agriculture: largely dominated by coconut and
banana production with subsistence crops of taro,
yams, sweet potatoes, and bread fruit
Electric power: 2,000 kw. capacity (1974); 6
million kw.-hr. produced (1974), 62 kw.-hr. per capita
Exports: $7 million (f.0.b., FY74); copra, coconut
products 78%, bananas 9%
Imports: $17 million (c.i.f., FY74); food,
machinery, and petroleum
Major trade partners: (FY74) exports — 25%
Netherlands, 22% Australia, 20% New Zealand, 11%
Norway; imports — 63% New Zealand and Australia
Budget: (FY73 est.) revenues $6.1 million,
expenditures $7.0 million
Monetary conversion rate:
lar=US$1.31 (1975)
Fiscal year: 1 July - 30 June','64503ccb0c20c7416b223430323dfac628e395ff655f0bea48ace7a8cb3255ce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('343b6da06ded5b0061d71fa6e665fab374f9a0f0f0e34af61c65cec2b922ad97',1976,'TT','Trinidad and Tobago','economy',493,'GDP: $1,500 million (1974), $1,500 per capita; real
growth rate 1974, negl.
Agriculture: main crops — sugarcane, cocoa,
coffee, rice, citrus, bananas; largely dependent upon
imports of food
Fishing: catch 3,977 metric tons (1972); exports
$1.0 million (1971), imports $2.6 million (1971)
Major industries:
processing, cement
Electric power: 334,000 kw. capacity (1974); 1.2
billion kw.-hr. produced (1974), 1,240 kw.-hr. per
capita
Exports: $2.0 billion (f.0.b., 1974); petroleum and
petroleum products ($990 million), sugar, cocoa
Imports: $1.9 billion (c.i-f., 1974); crude petroleum
($1.1 billion), machinery, fabricated metals,
transportation equipment, manufactured goods, food
Major trade partners: (excludes trade under
petroleum agreement) exports — U.S. 37%, U.K.
11%, CARIFTA 21%; imports — U.S. 34%, U_K.
23%, CARIFTA 10% (1972)
Aid: economic — from U.S. (FY56-73) $29 million
loans, $40 million grants; from international
organizations (FY53-73), $110 million
Monetary conversion rate: floating with pound
sterling; in September 1974, TT$2.25=US$1
Fiscal year: calendar year','11ded0d1ee3b767e7c7b7fd91771f799a1fc7c8d8372f7bf2b9cc3642b870dbe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fb0832a6b62ebd36f266d1992f29810c7483186a1715af1b215dd86c320b611',1976,'TN','Tunisia','economy',497,'GNP: $3.0 billion (1974 est.), $530 per capita;
10.6% average annual growth rate 1970-72, and 12%
in 1974
Agriculture: cereal farming and livestock herding
predominate; main crops — wheat, barley, olives,
fruits (especially citrus), viticulture, vegetables, dates
Major sectors: tourism, mining, food processing,
textiles and leather, light manufacturing, construction
materials, chemical fertilizers, petroleum
Electric power: 332,000 kw. capacity (1974); 1.1
billion kw.-hr. produced (1974), 193 kw.-hr. per
capita
Exports: $920 million (f.0.b., 1974); 34%
petroleum, 20% phosphates, 18% olive oil
Imports: $1,130 million (c.if., 1974); 36% raw
materials, 23% machinery and equipment, 14%
consumer goods, 19% food and beverages, 3% energy,
5% other
Major trade partners: exports — France 19%, Italy
19%, West Germany 13%, Libya 10%; imports —
France 36%, U.S. 15%, Italy 9%, West Germany 7%
(1971)
Monetary conversion rate:
(trade rate)
Fiscal year: calendar year
GNP; $30.8 billion (1974), $790 per capita; 6.0%
average annual real growth 1974, 6.7% average
annual real growth 1972
Agriculture: main products — cotton, tobacco,
cereals, sugar beets, fruits, nuts, and livestock
products; self-sufficient in food in average years, 2,900
calories per day per capita (1972)
Major industries: textiles, food processing, mining
(coal, chromite, copper, boron minerals), steel,
petroleum
Crude steel: 1.6 million tons produced (1974), 40
kilograms per capita
Electric power: 3,300,000 kw. capacity (1974);
12.3 billion kw.-hr. produced (1974), 242 kw.-hr. per
capita
Exports: $1,532 million (f.o.b., 1974); cotton,
tobacco, fruits, nuts, metals, livestock products,
textiles and clothing
Imports: $3,777 million (c.i.f., 1974); machinery,
transport equipment, metals, mineral fuels, fertilizers,
chemicals
Major trade partners: exports — West Germany
21%, U.S. 12%, Switzerland 9%, Italy 6%; imports —
West Germany 19%, U.S. 12%, U.K. 11%, Italy 11%
Budget: (FY74) revenues $5,043 million, ex-
penditures $5,422 million, deficit $379 million
Monetary conversion rate: 14.75 Turkish liras=
US$1 (current)
Fiscal year: 1 March - 28 February','8ef29996c588d764fbe11f1beddb79df6d800e5db033d3a3a75fa81d74c33bd9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('839b26ebfc3dbb3acf1151c194aafd29de4bbd9af67eea152ead519e60698dc4',1976,'UG','Uganda','economy',501,'GDP: $1,053 million (1973) at 1966 prices, $100
per capita; 1% real growth between 1972 and 1973
Agriculture: main cash crops — coffee, cotton;
other cash crops — sugar, tobacco, tea, fish, livestock;
self-sufficient in food
Fishing: catch 170,000 metric tons (1972), $26.2
million (1971)
Major industries: agricultural processing (textiles,
sugar, coffee, plywood, beer), cement, copper smelter,
corrugated iron sheet, shoes, fertilizer
Electric power: 234,000 kw. capacity (1974); 780
million kw.-hr. produced (1974), 69 kw.-br. per capita
Exports: $315 million (f.0.b., 1974); coffee, cotton,
copper, tea; $13.4 million to Communist countries
(1971)
211
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
UGANDA/U.S.S.R.
Imports: $213 million (cif, 1974); petroleum
products, machinery, cotton piece goods, metals,
transport equipment; $8.3 million from Communist
countries (1971)
Major trade partners: U.K., U.S., Kenya (Uganda,
Kenya, and Tanzania form East African Economic
Community)
Monetary conversion rate: 7.143 Uganda shil-
lings = US$1
Fiscal year: 1 July - 30 June
Agriculture: principal food crops — grain
(especially wheat), potatoes; main industrial crops —
sugar cotton, sunflowers, and flax; degree of self-
sufficiency depends on fluctuations in crop yields;
given normal yields, U.S.S.R. is self-sufficient; caloric
intake, 3,000-3,200 calories per day per capita in
recent years
Fishing: catch 9.5 million metric tons (1974);
exports 260.4 thousand metric tons (1973), imports
15.0 thousand metric tons (1972)
diversified, highly developed
consumer goods industries
Major industries:
capital goods industries,
comparatively less developed
Shortages: natural rubber, bauxite and alumina,
tantalum, tin, tungsten and fluorspar
Crude steel: 148 million metric ton capacity as of 1
January 1975; 136 million metric tons produced in
1974, 540 kilograms per capita
Exports: $27,374 million (f.0.b., 1974); fuels
(particularly petroleum and derivatives), metals,
agricultural products (timber, grain) and a wide
variety of manufactured goods (primarily capital
goods)
Imports: $24,861 million (f.0.b., 1974); specialized
and complex machinery and equipment, textile fibers,
consumer manufactures, and any significant shortages
in domestic production (for example, wheat imported
following poor domestic harvests)
Major trade partners: $52 billion (1974); trade
54% with Communist countries, 31% with industrial-
ized West, and 15% with less developed countries
Official monetary conversion rate: 0.7600
rubles = US$1; 1 ruble = US$1.3158 (October 1975)
Fiscal year: calendar year','f623fbbcaf04c689e096bad950454970da3fd4721e0def2e9058c42f92af920f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8769ce8a040cc57da3a36f90ff5625eff3842a0373db867ce854002f5e5e6069',1976,'AE','United Arab Emirates','economy',504,'Agriculture: food imported, but some dates,
alfalfa, vegetables, fruit, tobacco raised
Electric power: 102,120 kw. capacity (1974): 273.6
billion kw.-hr. produced (1974), 4,000 kw.-hr. per
capita
Exports: crude petroleum, pearls, fish
Imports: $1.4 billion (cif, 1974 est.) food,
consumer and capital goods
Major trade partners: Japan, U.K., India, U.S.
Aid: donor, led by Abu Dhabi; 1974 commitment
$1.8 billion
Budget: (1974) $215 million; Abu Dhabi (1974)
$1.5 billion; Dubai (1973) $151 million
Monetary conversion rate: 1 Qatar-Dubai
riyal = US$0.25: Abu Dhabi, 1 Bahrain dinar=
US$2.52 (as of October 1973)','47fd46281915f414cc3a05e2ed7fd6b55de04293ca0eed68cfcb662e96440451','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52d7ef667b40245c90243ae0f66eb63cf22f021551bac1d74e71822fb6b4b355',1976,'GB','United Kingdom','economy',508,'GNP: $183 billion (1974), $3,260 per capita; 63.4%
consumption, 20.8% investment, 90.1% government,
—4,.3% net foreign balance; 1972 GDP growth rate
5.9%
Agriculture: mixed farming predominates;
products — wheat, barley, potatoes, sugar beets,
livestock, dairy products; 50% self-sufficie
shortages — meat, fruits, vegetables, cereals, dairy
products; caloric intake, 3,170 calories per
capita (1970-71)
Appro
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010
001-8
Fishing: catch 1.0 million metric tons (1973), $368
million (1973); exports $106 million, imports $324
million (1973)
Major industries: machinery and transport
equipment, metals, food processing, paper and paper
products, textiles, chemicals, clothing
Shortages: rubber, petroleum, timber and
woodpulp, textile fibers, nonferrous metals, foodstuffs
Crude steel: 29.5 million metric tons capacity
(1974); 22.4 million metric tons produced (1974), 400
kg. per capita
Electric power: 76,000,000 kw. capacity (1974);
273.6 billion kw.-hr. produced (1974), 4,000 kw.-hr.
per capita
Exports: $38.6 billion (£.0.b., 1974), machinery,
transport equipment, chemicals, metals, nonmetallic
mineral manufactures, textiles, beverages
Imports: $54.1 billion (cif. 1974); foodstuffs,
petroleum, machinery, crude materials, chemicals,
nonferrous metals
Major trade partners: (1973) exports — 11%,
Australia 3%, Canada 4%, Ireland 4%, South Africa
3%; Sterling area 94%; EC-nine 83%; U.S.S.R. and
Eastern Europe 8%
Aid: economic — (authorized) U.S., $8.7 billion
(FY46-73), $26 million in FY78, 51.4 million in FY72,
net official economic aid to less developed areas and
multilateral agencies, $5,078 million (1960-69), $562
million in 1971; $609 million in 1972; military —
U-S., $1.1 billion (FY46-73)
Budget (public sector): (1973/74) expenditures
$81.8 billion, revenues $71.3 billion
Monetary conversion rate: pound sterling floating,
average daily exchange rate 1974, US$0.4275=1
pound
Fiscal year: | April - 31 March
GDP: $366 million (1973 est., in constant Prices),
$65 per capita
Agriculture: cash crops — peanuts, shea nuts,
sesame, cotton: food crops — sorghum, millet, corn,
tice; livestock; largely self-sufficient
Fishing: catch 5,000 metric tons (1971)
Major industries: agricultural processing plants,
brewery, bottling, and brick plants; a few other light
industries
Electric power: 16,700 kw. capacity (1974): 49
million kw,-hr. produced (1974), 8 kw.-hr. per capita
Exports: $19 million (f.0.b., 1973); livestock (on the
oof), peanuts, shea nut products, cotton, sesame
Imports: $73 million (c.i-f., 1973); textiles, food,
and other consumer goods, transport equipment,
machinery, fuels
Major trade Partners: volume understated because
much regional trade is unrecorded; Ivory Coast and
Ghana; overseas trade mainly with France and other
800010001-8
° Approved For Release 2005/04/22 : CIA-RDP79-01051A000
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
UPPER VOLTA/URUGUAY
EC countries; preferential tariff to EC and franc zone
countries
Aid: economic — France (1964-September 1970)
$46 million; EC (FY1960-72) $87 million; U.S.S.R.,
China, Ghana, West Germany, and Israel have also
extended aid; U.S. (FY61-73) $25 million; inter-
national organizations (FY1960-73) $28 million;
China $43 million (1973-74); military — France, $3.7
million (1964-70); U.S., $0.1 million (FY1962-78)
Budget: (1974) balanced at $56 million
Monetary conversion rate: about 219.98 Com-
munaute Financiere Africaine francs=US$1 as of
August 1975, floating since February 1973
Fiscal year: calendar year','e01df97a051cae08d65c7ae49b1f9c6a1ca6b7e386ab12a4e01082d178b007c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f56af3c71936752f3d341cab1baa3a2ac617f9bce9b107753e448d8d28a76730',1976,'UY','Uruguay','economy',512,'GNP: $2.55 billion (at 1974 prices); $840 per
capita; 74% private consumption, 12% public
consumption, 14% gross investment (1969); real
growth rate 1974, 2%
Agriculture: large areas devoted to extensive
livestock grazing (17 million sheep, 9 million cattle);
main crops — wheat, rice, corn; self-sufficient in most
basic foodstuffs; caloric intake, 3,000 calories per day
per capita, with high protein content
Major industries: meat processing, wool and hides,
textiles, footwear, cement, petroleum refining
Crude steel: 13,000 metric tons produced (1972), 5
kilograms per capita
Electric power: 546,000 kw. capacity (1974); 2.4
billion kw.-hr. produced (1974), 860 kw.-hr. per
capita
Exports: $382 million (f.0.b., 1974); beef, wool,
hides
Imports: $481 million (c.i.f., 1974); fuels, metals,
machinery, transportation equipment
Major trade partners: exports — EC 34%, U.K.
14%, U.S. 7%, LAFTA 15%; imports — LAFTA 30%,
U.S. 14%, U.K. 6%, EC 19% (1969)
Aid: economic — extensions from U.S. (FY46-
73), loans $129 million, grants $28 million; from
international organizations (FY46-73), $258 million;
from other western countries (1960-71), $14.2 million;
from Communist countries (1966-74) $45.5 million;
military — U.S. (FY46-73), $59.8 million
Monetary conversion rate: commercial rate new
pesos 2.33=US$1, financial rate new pesos
2.80 = US$1 (August 1975)
Fiscal year: calendar year
The Vatican City, seat of the Holy See, is supported
financially by contributions (known as Peter''s pence)
from Roman Catholics throughout the world; some
income derived from sale of Vatican postage stamps
and tourist mementos, fees for admission to Vatican
museums, and sale of publications; industrial activity
consists solely of printing and production of a small
amount of mosaics and staff uniforms
The banking and financial activities of the Vatican
are worldwide; the Institute for Religious Agencies
carries out fiscal operations and invests and transfers
funds of Roman Catholic religious communities
throughout the world, the Cardinal''s Commission
controls the administration of ordinary assets of the
Holy See and a Special Administration manages the
Holy See''s capital assets
Electric power: obtained from Rome city grid;
standby diese] powerplant with 2,100 kw. capacity
GNP: $22.5 billion (1974, in 1973 dollars), $1,930
per capita; 47% private consumption, 13% public
consumption, 28% gross investment, 12% foreign
sector (1973), real growth rate 1974 est. 5%
Agriculture: main crops — cotton, sugarcane, corn,
coffee, rice; self-sufficient in tice and chicken, imports
wheat (U.S.) and meat (Colombia): caloric intake
2,600 calories per day per capita (1972)
Fishing: catch 152,000 metric tons, $34.1 million
(1972); exports $10.1 million (1970), imports $5.6
million (1970)
Major industries: petroleum, iron-ore mining,
construction, food processing, textiles
Crude steel: 1.1 million metric tons produced
(1973), 100 kilograms per capita
Electric power: 3,400,000 kw. capacity (1974). 16
billion kw.-hr. produced (1974), 1,390 kw.-hr. per
capita
220
Exports: $11.0 billion (f.0.b., 1974): petroleum
$10.4 billion (1974), iron ore, coffee
Imports: $4.2 billion (cif, 1974); industrial
machinery and equipment, chemicals, manufactures,
wheat
Major trade partners: imports — U.S. 42%, West
Germany 13%, Japan 8%: exports — U.S. 41%,
Canada 13%, Aruba 12%, Argentina 9%
Aid: economic assistance—extensions from US.
(FY46-74), $127.9 million loans; $71.1 million grants:
from international organizations (FY46-73), $665
million; from Communist countries (1954-74), $10
million; military — assistance from U.S. (FY46-74),
$141.3 million
Budget: 1975—revenues $9.5 billion; expenditures,
$9.4 billion, capital $1.9 billion
Monetary conversion rate: 4.285 bolivares = US$]
(selling rate)
Fiscal year: calendar year
Agriculture: mainly subsistence; main crops —
rice, corn, sweet potatocs, manioc, sugarcane; food
shortages — rice, meat, sugar, caloric intake, 1,700-
2,200 calories per day per capita
Major industries: food processing, textiles,
machine building, mining, cement, chemical fertilizer
Shortages: petroleum, complex machinery and
equipment, fertilizer, foodstuffs
Electric power: 252,000 kw. capacity (1974);
750,000 kw.-hr. produced (1974), 32 kw.-hr. per
capita
Monetary conversion rate (nominal): 3.0
dong = US$1 (1975)
Fiscal year: calendar year','c4e1511d535e8376d0473b5036072a0de19281a8a4b137b934a09bea75eb18d2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63b72d073dd1aebcc6d56deca89a856e032229948f6a3f088c556c084ff4749f',1976,'WF','Wallis and Futuna','economy',516,'Agriculture: dominated by coconut production
with subsistence crops of yams, taro, bananas
Exports: negligible
Imports: $1.4 million (1972), largely foodstuffs and
some equipment associated with development
programs
Monetary conversion rate: 70 Colonial Franc
Pacifique (CFP)=US§1','3f2ec2c43a82ebf416f22823d38372b654342d194e8dc3f95595420db4fa05f2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42fcb9628bf2bbf1e967fb2ce760c9733cee77183bc4b18b75301d6abf44a793',1976,'WS','Samoa','economy',518,'GNP: $38 million (1971), $260 per capita
Agriculture: cocoa, bananas, copra: staple foods
include coconut, bananas, taro, and yams
Exports: $13 million (f.0.b., 1974); copra 63%,
cocoa 18%, timber 8%
224
Imports; $25 million (c.if., 1974): food 30%.
manufactured goods 24%, machinery 9%
Major trade partners: exports—New Zealand 33%,
Netherlands 18%, West Germany 15%, U.S. 13%;
imports—New Zealand 33%, Australia 22%, Japan
11%
Aid: New Zealand, $7 million (est. 1972-76)
Budget: 1974 est., revenues $15 million, expendi-
tures $18 million
Monetary conversion rate: WS Tala=US$1.67
(August 1973), 0.61 WS Tala=US$1
Major industries: timber, tourism','e9bd2c21600d3d582c0df46f7411301d5806960a43c42bf72c506ca574c4e6d2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f286287136305d80f316e2144a6dbf6ed417cfd24032eb8b5ad0dde3bc4cd51c',1976,'YE','Yemen','economy',522,'GNP; $100 million (1974 est.), $60 per capita
Agriculture (all outside Aden): cotton is main cash
crop; cercals, dates, kat (qat), coffee, and livestock are
raised and there is a growing fishing industry; large
amount of food must be imported (particularly for
Aden); cotton, hides, skins, dried and salted fish are
exported
Major industries: petroleum refinery (production
150,000 b/d) mid-1971; capacity 178,000 b/d at
2Excluding the islands of Perim and Kamaran for which
no data are available.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Little Aden operates on imported crude; oil
exploration activity
Electric power: 128,000 kw. capacity (1974); 448
million kw.-hr. produced (1974), 276 kw.-hr. per
capita
Exports: $26 million (1974), excluding petroleum
products but including re-exports
Imports: $188 million (1974 provisional)
Major trade partners: Yemen, East Africa, but
some cement and sugar imported from Communist
countries; crude oil imported from Persian Gulf,
exported mainly to U.K. and Japan
Budget: (FY1973-74, est.) — revenues $39 million,
expenditures 68 million
Monetary conversion rate: 1 §. Yemeni dinar=
US$2.90
Fiscal year: | April - 31 March
GNP: $300 million (1974 est. ), $50 per capita
Agriculture: sorghum and millet, gat (a mild
Narcotic), cotton, coffee, fruits and vegetables; largely
self-sufficient in food
almost entirely agriculture and
Major industries: cotton textiles and leather goods
produced on a small scale; handicraft and some
fishing; small aluminum products factory
Electric power: 4,000 kw. capactiy (1974); 14
million kw.-hr. produced (1974), 2 kw.-hr. per capita
Exports: $15 million (1974 est. ), gat, cotton, coffee,
hides, vegetables
Imports: $220 million (1974 est.), textiles and other
manufactured consumer goods, petroleum products,
sugar, grain, flour, other foodstuffs, and cement
Major trade partners; China, Yemen (Aden),
U.S.S.R., Japan, U.K., Australia, Saudi Arabia
Aid: bilateral pledges received—$167 million 1974,
multilateral—$36 million 1974 through August 1972,
$170 million drawn through 1970: major donors
include U.S.S.R., China, U.S., West Germany, Saudi
226
Approved For Release 2005/04/22
Arabia; military — $78 million from U.S.S.R.; $30
million from Eastern Europe; $7 million western
military aid through 1973
Budget: (1974/75 est.) $92 million
Monetary conversion rate: 1 Yemeni rial =
US$0.22 as of October 1973
Fiscal year: 1 July - 30 June
GNP: $27.9 billion (1974 est., at 1978 prices),
$1,320 per capita; 1974 real growth rate approx. 6.5%
Agriculture: diversified agriculture with many
small private holdings and large agricultural
combines; main crops — corn, wheat, tobacco, sugar
beets, and sunflowers; generally a net exporter of
foodstuffs and live animals; self-sufficient in food
except for tropical products, cotton, wool, and
vegetable meal feeds; caloric intake, 3,210 calories per
day per capita (1967)
Major industries: metallurgy, machinery and
equipment, textiles, wood processing, food processing
Shortages: fuels, steel, textile fibers, chemicals
Crude steel: 2.8 million metric tons produced
(1974), 130 kg. per capita
Electric power: 8,850,000 kw. capacity (1974);
39.5 billion kw.-hr. produced (1974), 1,855 kw.-hr. per
capita
Exports: $3,805 million (f.o.b., 1974); 11%
foodstuffs and tobacco; 21% raw materials, fuels, and
chemicals; 23% machinery and equipment; 45% other
manufactures
Imports: $7,542 million (c.i.f., 1974); 9% foodstuffs
and tobacco; 37% raw materials, fuels, chemicals;
26% machinery and equipment; 28% other
manufactures
Major trade partners: 71% non-Communist
countries (835% EC, 6% U.S., 30% other non-
Communist countries), 29% Communist countries
Aid: postwar credits extended mainly by the U.S.
(about $3.6 billion, including grants and $0.7 billion
in military aid); Western Europe (more than $1.2
billion); IBRD ($1.0 billion); IMF (more than $580
million); Communist countries extended credits
227
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
YUGOSLAVIA/ZAIRE
totaling $464 million in 1956 ($125 million drawing
balance suspended in 1958) und $576 million during
1962-70 and $540 million in 1972; $173 million in
1974; Yugoslavia has extended credits totaling about
$700 million to 27 less developed countries of Africa,
Asia, and Latin America
Monetary conversion rate: 17.0 new dinars = US$1
Fiscal year: same as calendar year (all data refer to
calendar year or to middle or end of calendar year as
indicated)
GDP: $3.6 billion (1974 current prices), $150 per
capita; real growth rate 6.8% p.a. 1968-72
Agriculture: main cash crops — coffee, palm oil,
rubber; main food crops — manioc, bananas, root
crops, corn; some provinces self-sufficient
Fishing: catch 124,000 metric tons (1971); imports
$18 million (1972 est.)
Major industries: mining, mineral processing, light
industries
Electric power: 861,380 kw. capacity (1974); 3.5
billion kw.-hr. produced (1974), 126 kw.-hr. per
capita
Exports: $1,294 million (f.0.b., 1974), copper,
cobalt, diamonds, other minerals, coffee, palm oil
Imports: $911 million (cif, 1974); consumer
goods, foodstuffs, mining and other machinery,
transport equipment, fuels
Major trade partners: Belgium, U.S., and West','eddb4b5e01750058b34364066ad0578082cb957c703ac12c9344a8e17336f21f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

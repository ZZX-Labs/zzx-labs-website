SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b17b4a6a04e993c34c2810fe2dd885d832a7bdec604201e7e52fb418c20cbc8',1976,'AF','Afghanistan','communications',7,'Railroads: 0.4 mi. (single track) 5''0"-gage,
government-owned spur of Sovict line
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
AFGHANISTAN/ ALBANIA
Highways: 11.170 mi. (1974): 1.615 mi paved,
2,200 mi. gravel, 3,895 mi. improved earth, and
3,470 mi. unimproved earth
Inland waterways: total navigability 760 mi.;
steamers use Amu Darya
Ports: only minor river ports
Civil air: 5 major transport aircraft
Airfields: 41 total, 36 usable; 9 with permanent-
surface runways; 6 with runwavs 8,000-1 1,999 ft., 11
with runways 4,000-7,999 ft.
Telecommunications: limited telephone, tele-
graph, and radiobroadcast services, barely sufficient
to meet civil and military requirements; 24.528
telephones; 111,000 radio receivers; no TV receivers: 2
AM, no FM, no TV stations
DEFENSE FORCES
Military manpower: inales 15-49, about 4.9
million; 2.6 million fit for military service; about
177,000 reach military age (22) annually
Supply: dependent on foreign sources, almost
exclusively the U.S.S.R.','5cab07ef6c5c0ac4a82ed07923c09fa40e78effaa38a621c40051407d2ed74eb','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe3f05afdb5843e5c9c8e1fb619d4cfe91374e6ebf21d8c95575199624b7a643',1976,'AL','Albania','communications',8,'(Ses reference map IVj
LAND
11,100 sq. mi.; 19% arable, 24% other agricultural,
43% forested, 14% other
Land boundaries: 445 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 260 mi. (including Sazan Island)
Railroads: 172 mi. standard gage, single track;
government owned (1974)
Highways: 3,100 mi.; 800 mi. paved, 1,000 mi.
crushed stone and/or gravel, 1,300 mi. improved or
unimproved earth (1974)
Inland waterways: 27 mi. plus Albanian sections of
Lake Scutari, Lake Ohrid, and Lake Prespa (1975)
Freight carried: rail — 3.1 million short tons, 123.3
million short ton/mi. (1971); highways — 43.0
million short tons, 616.4 million short ton/mi. (1971)
Ports: 2 major (Durres, Vlore), 2 minor (1975)
Pipelines: crude oil, 110 mi.
Civil air: no major transport aircraft (1975)
DEFENSE FORCES
Military budget (announced); for fiscal year
ending 31 December 1975, 653 million leks; about 9%
of total budget
Atlantic
Dezan
{See reference map V)
LAND
950,000 sq. mi.; 3% cultivated, 16% pasture and
meadows, 1% forested, 80% desert, waste, or urban
Land boundaries: 3,890 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 735 mi.','3b106f666164981198840560a1e5c40ff443fb7c8c10bcb5af6db360293d2f30','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc7868fd7831bdc6f021061532b503bf2806cbdb9f1b449bf0cd070475067136',1976,'DZ','Algeria','communications',13,'Railroads: 2,414 mi.; 1,660 mi standard gage, 663
ini. 35%” gage, 91 mi. meter gage; 188 mi.
electrified; 120 mi. double track
Highways: 48,614 mi., of which 27,943 mi. are
paved and the remainder earth
Ports: 9 major, 8 minor
Pipelines: crude oil, 2,950 mi.; refined products,
150 mi.; natural gas, 1,785 mi.
Civil air: 28 major transport aircraft
Airfields: 190 total, 189 usable; 58 with
permanent-surface runways; 21 with runways 8,000-
11,999 ft, 107 with runways 4,000-7,999 ft; 3
scaplane stations
Telecommunications: adequate domestic and
international facilities in the north, primarily radio
communications in the desert; satellite ground
stations; 220,800 telephones; 1,150,000 radio
reccivers; 310,000 TV receivers; 15 AM and 39 TV
stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 3,974,000:
2,347,000 fit for military service; average number
reaching military age (19) annually 163,000
Military budget: for fiscal year ending 31
December 1975, $257,693,200; 4.7% of national
budget','e21ea94ee914586210a446a873039a6b3d4badecd0172d73f0d60e2d9ce0755f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11326ca314665637424bf2de7dfd55147b237c7386bd8e6fcdd8257c8ce3c6e5',1976,'AD','Andorra','communications',14,'LAND
180 sq. mi.
Approved For Release 2005/04/22
Atlantic
Ücean
PO x:
: 1.9
e
Mediterranean
Sea
¡Ses reference map IV)
Land boundaries: 65 mi.
Railroads: none
Highways: about 60 mi.
Civil air: no major transport aircraft
Airfields: none
Telecommunications: international circuits to
Spain and France; 2 AM, 1 FM, 1 TV station; about
2,800 telephones; 8,000 radio receivers, 3,000 TV
receivers
DEFENSE FORCES
Andorra has no defense forces; Spain and France
are responsible for protection as needed','47355a78c41026915ad7499dbef5b7893ffa04eace4b8e4254708845fa20cca3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbe0a95bfdd6d9f46d0ca4e69d204540d6414965995c51e62610583876cfe357',1976,'AO','Angola','communications',17,'LAND
481,000 sq. mi.; 1% cultivated, 44% forested, 22%
meadows and pastures, 33% other (including fallow)
Land boundaries: 3,150 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 1,000 mi.
Railroads: 1,918 mi.: 1,724 mi. 3''6” gage, 194 mi.
111%" gage
Highways: 45,000 mi.; 4.970 mi. bituminous-
surface treatment, 28,000 mi. crushed stone, gravel, or
improved earth, remainder unimproved earth
Inland waterways: 2,000 mi. navigable
Ports: 3 major (Luanda, Lobito, Mocamedes). 15
minor
Pipelines: crude oil, 111 mi
Civil air: 15 major transport aircraft
Airfields: 552 total, 498 usable; 26 with
permanent-surface runways; l with runway over
12.000 ft., 6 with runways 8,000-1 1,999 ft., 77 with
runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: network of open-wire and
radio-relay facilities; satellite ground station; 37,500
telephones; 116,000 radio receivers; 24 AM, 11 FM,
and no TV stations
ANTIGUA
Atlantic
Ocean
DOMINICAN
REPUBLIC','1e8fbcb6e3726c2d5cd54a1eb8fa02eb441e0c53c764903d700205c7ed586971','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d2606488dad8d11961a7d4db749de09682cc39eb19addf3038e3bce117bd512',1976,'PR','Puerto Rico','communications',21,'`
ANTIGUA pus
3
Caribbean Sea
¡See reference map $)
LAND
108 sq. mi.; 54% arable, 5% pasture, 14% forested,
9% unused but potentially productive, 18% wasteland
and built on
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 95 mi.
Railroads: 49 mi. narrow gage (26), employed
almost exclusively for bandling cane
Highways: 235 mi; 150 mi, main, 85 mi.
secondary
Ports: ! major (St. John’s), | minor
Civil air: 9 major transport aircraft
Airfields: 3 total, 2 usable; 1 with asphalt runway
9,000 ft.; 2 seaplane stations
Telecommunications: automatic telephone sys-
tem; 3,150 telephones; tropospheric scatter links with
Tortola and St. Lucia; 22,000 radio receivers, 12,300
TY sets; 2 AM, 1 FM, and 1 TV stations; 2 coaxial
submarine cables','59967b8600ea3ff73d26a1711065e1d84da24f731ccc1f517e284c8b4e6e81b0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07b1fc68af15f7b09bc77dd590945f4a68ed1cc98b67ab1138f818070141f135',1976,'AR','Argentina','communications',25,'Pacific
Ocean
Buenos Aires
Atlantic Ocean
(See reference map Hil)
LAND
1,070,000 sq. mi; 57% agricultural (11% crops.
improved pasture and fallow, 46% natural grazing
land), 25% forested, 18% mountain, urban, or waste
Land boundaries: 5,850 mi.
WATER
Limits of territorial waters (claimed): 200 n. mi.
(continental shelf, including sovercignty over
superjacent waters)
Coastline: 3,100 mi.
Railroads: 24,350 mi; 2,000 mi. standard gage
(4''8:&"). 13.750 mi broad gage (5''6") 8,402 mi.
meter gage (38057). 75 mi 2514" gage, 130 mi.
11154" gage; about 1.035 mi. double and multiple
track; 76 mi. electrified
Highways: 180.000 mi, of which 24,500 mi.
paved, 46,500 mi. gravel, 100,000 mi improved earth
Inland waterways: 6,800 navigable mi.
Ports: 7 major, 21 minor
Pipelines: crude oil, 2,540 mi.; refined products,
1,370 mi.; natural gas, 5,670 mi.
E o 5 gg xo
Civil air; 45 major transport aircraft, includes l
leased from a foreign country
Airfields: 2,447 total, 2,149 usable; 83 with
permanent-surface runways; 20 with runways 8,000-
11,999 ft, 291 with runways -4,000-7,999 ft: 6
seaplane stations
Telecommunications: extensive modern system,
telephone network has 2,240,000 sets, radio relay
widely used, 2 communications satellite ground
stations; estimated 11 million radio receivers and 4
million TV sets: 145 AM, 12 FM, and 60 TY stations
DEFENSE FORCES
Military manpower: males 15-49, 6,312,000:
5,094,000 fit for military service: average number
reaching tnilitary age (20) annually about 214,000
Military budget; proposed for fiscal year ending 31
December 1975, $684.9 million; about 109; of total
central government budget
Bahia.
"Bianca
1000 Miles
1000 Kilometers
e Falkland Is.
«2 sas Malvinas)
(Admin. by U.K.
claimed by
Argentina}
South Georgia
(UK)
BOUNDARY REPRESENTATION IS
NOT NECESSARILY AUTHORITATIVE
502849 1-76
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
II
E
FE
; *
Washington" 1?
pua ads
Ear
LUI
ees United States T
E ^ pu
r 2 Bermuda
x $ HELKI)
m A t la n t
O ce a
YN A «Hermosillo
| ps
| iN
N
B
N. q T M
| d a
EY. a EN Monterrey, p fa g
ES N Gulf of Mexico i %
N S ly
A A Mazatlán x y "E
ur Li H ^ lo
Merce Havana \\
e (Tampico P Zi; ara
ES Guadalajara An Zee 8.
1 E U.K)
S P ZEN: s
* * P a MS. Naval Base ve i:
^ Mexico Veracruz (Uk .* Qd Py) I.
Nu 4 E uu m pulls ve Sante D
` ES No y C e Domingo
W Acapulco Kingston
2 " EN
: M A us Gudtemala Caribbean Sea
P a € : f ! c Guatemala
et Netherlands Antilles
San Salvado
P ds
a
Canal Zone
(4.5. admi
Bogotá','3705c9406c5274ad051456a5ded27b4898d59e6e04cc7baa7571240e5ac67a61','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0dac00ebe5e4c21eae477441b09f19f993520b340f77cadba5bb47b514ac0fe8',1976,'AU','Australia','communications',29,'f ; ê
NDONESIA.
Sae oc ques
{See reference map VI)
LAND
2,970,000 sq. mi; 6% arable, 58% pasture, 2%
forested, 34% other
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.; prawn and cravfish on continental
shelf)
Coastline: about 16,000 mi.
(See reference map Viti)
LAND
183,540 sq. mi.
Land boundaries: 600 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: about 3,200 mi.
Railroads: none
Highways: approx. 8,910 mi.; about 5,225 mi.
suitable for heavy and medium traffic, and about
3,685 mi. suitable for light traffic
Inland waterways: 6,800 mi.
Ports: 5 principal, 8 minor
Civil air: 22 major transport aircraft; Air Niugini,
new national airline, began operations in November
1973
Airfields: 514 total, 478 usable; 13 with
permanent-surface runways; 46 with runways 4,000-
7,999 ft.; 1 with runway 8,000 ft. — Nadzab
Telecommunications: Papua New Guinea telecom
services are adequate and are being improved;
principal telecom centers include Goroka, Lae,
Madang, Mount Hagen, and Wewak in New Guinea;
and Daru, Port Moresby and Samarai in Papua;
facilities provide radiobroadcast, radiotelephone and
telegraph, coastal radio, aeronautical radio and
international radiocommunication services; numerous
privately owned radio facilities exist; submarine
cables extend from Madang to Australia and Guam;
32,384 telephones, 102,000 radios, but no TV sets; 29
AM, no FM and no TV facilities
DEFENSE FORCES
Military manpower: males 15-49, 693,400, about
329,000 fit for military service
Defense is responsibility of Australia
Railroads: none
Highways: 141 mi; 78 mi. bituminous, 63 mi.
crushed stone or earth
Ports: 1 minor port (Victoria)
Civil air: no major transport aircraft
Airfields; 4 total, 4 usable on (Praslin Island,
Astove Island, Bird Island, Mahe Island) 1 permanent
surface 8,000-11,999 ft.
Telecommunications: direct radiocommunications
with adjacent islands and African coastal countries;
2,470 telephones; 15,000 radio, and no TV sets; 2 AM,
no FM, and no TV stations; submarine cables extend
to Aden, Tanzania, and Sri Lanka
DEFENSE FORCES
Military manpower: males 15-49, 13,000; 7,000 fit
for military service
1200 Miles : ces
Melbou me
1200 Kilometers
NAMES ANO BOUNDARY REPRESENTATION
ARE NOT NECESSARILY AUTHORITATIVE
502853 1-76 (540317)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
A
502852 1-76
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
North
Atlantic
Ocean
2
Portugal Spain —
ms
rE
ML
Algiers
p
Mórocco
Canary is. (Sp)
4 "
[ow','d229ef5aaf8364ba027b639db8e3344fe6d26f08f9d73994d14c03fc2018072f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61ee876a55a1e97221c6439114634728ad0a7cb2884dfccec7e7f1294fdf85b2',1976,'GN','Guinea','communications',34,'Railroads: 25.95] mi; 5,715 mi. 5/3" gage, 8,323
mi. 48%” gage. 11,213 mi. 3''6" gage; 497 mi.
electrified (June 1962); government owned (except for
few hundred miles of privately owned track)
Highways: 530,685 mi. (1974); 129,390 mi. paved,
130,420 mi. gravel, crushed stone, or stabilized soil
surface, 276,925 mi. unimproved carth
Inland waterways: 5,200 mi; mainly by small,
shallow-draft craft
Freight carried: rail — 87.3 million short tons
(based on Lst 10 months of FY72); coastal and inland
shipping — 32.6 million tons
Ports: 12 major, numerous minor
Pipelines: crude oil, 460 mi.; refined products, 211
mi.; natural gas, 4,317 mi.
Civil air: 159 major transport aircraft
Airfields: 1,738 total, 1,645 usable; 188 with
permanent-surface runways, 2 with runways over
12,000 ft.; 12 with runways 8,000-11,999 ft., 648 with
runways 4,000-7,999 ft.; 8 scaplane stations
Telecommunications: very good international and
domestic service; 4,659,182 telephones; 12.3 million
radio receivers; 3.6 million TV receivers; 183 AM
stations in 127 cities, no FM, 104 TV stations and 47
repeaters; 3 earth satellite stations; submarine cables
to New Zealand, New Guinea, Singapore. Malaysia,
Hong Kong, and Guam
00010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008
January 1976
AUSTRALIA/AUS TRIA
DEFENSE FORCES
Military manpower: males 15-49, 3,227,000:
2,842,000 fit for military service; 122.000 reach
military age (17) annually
Military budget: for fiscal year ending 30 June
1975, 82.1 billion: about 10% of total central
government budget
(See reference map VI)
LAND
183,400 sq. mi.; 4% cultivated, 18% grazing, 13%
fallow, 50% forest, 15% other
Land boundaries: 2,830 mi.
WATER
Limits of territorial waters (claimed): 18 n. mi.
Coastline: 250 mi.
Railroads: 623 mi.; 533 mi. meter gage, 90 mi.
]''1194" gage
Highways: approximately 14,000 mi; including
900 mi. bituminous, 13,100 mi. gravel and earth
Political subdivisions: 7 provinces divided into 39
departments
Legal system: based on French civil law system,
with common law influence; new unitary constitution
adopted 1972; judicial review in Supreme Court,
when a question of constitutionality is referred to it by
the President of the Republic; has not accepted
compulsory 1C] jurisdiction
Branches: executive, legislative, and judicial i
Government leader: President Ahmadou Ahidjo Inland waterways: 1,800 Tm
A Ports: 1 major (Douala), 3 minor
Suffrage: universal over age 21
Elections: presidential elections held 5 April 1975;
parliamentary clections last held 18 May 1973
Civil air: 6 major transport aircraft
Airfields: 53 total, 52 usable; 7 with permanent-
surface runways; 2 with runways 8,000-1 1,999 ft., 20
Political i 1 . singl art
olitical partes and leaders: singi pary, with runways 4,000-7,999 ft.; 1 seaplane station
Cameroonian National Union (UNC), President
Ahmadou Ahidjo
Communists: no Communist Party or significant
number of sympathizers
Telecommunications: good telephone service
between Douala and Yaounde, fair in southern part;
fair to good telegraph service; 21.900 telephones;
230,000 radio reccivers; 4 AM, no FM, and no TV
stations; 1 submarine cable; microwave radio-relay
under construction Yaounde to Fort Fourcau; satellite
ground station at Yaounde
Other political or pressure groups: Cameroon
Peoples Union (UPC), an illegal terrorist group now
reduced to scattered acts of banditry with its factional
leaders in exile
Member of: AFBD, EAMA, ECA, EIB (associate), DEFENSE FORCES
FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO, Military manpower males 15-49, 1,434,000;
IMCO, IMF, 1PU, ITU, Lake Chad Basin 711,000 fit for military service; average number
Commission, Niger River Commission, OAU, OCAM, reaching, military age (18) annually about 62,000
UDEAC, U.N. UNESCO, UPU, WHO, WMO Military budget: for fiscal year ending 30 June
ECONOMY 1976, $54,178,204; 10.9% of total budget
GDP: $1,425 million (1973), per capita about $240;
yeal growth rate about 7% per annum
Agriculture: commercial and food crops — cocoa,
coffee, timber, cotton, rubber, bananas, peanuts,
palm oil and palm kernels; root starches, livestock,
millet, sorghum, and rice
Fishing: imports 6,137 metric tons, $2.5 million;
exports 1,718 metric tons (largely shrimp), $2.7
million (1972)
Major industries: small aluminum plant, food
processing and light consumer goods industries,
sawmills
Electric power: 304,000 kw. capacity (1974); 1.7
billion. kw.-hr. produced (1974), 323 kw.-hr. per
capita
Exports: $523 million (Lo.b., 1974); cocoa and
coffee about 5596; other exports include timber,
aluminum, cotton, natural rubber, bananas, peanuts,
tobacco, and tea
Imports: $477 million (cif, 1974); consumer LAND
{See referente map y
goods, machinery, transport equipment, alumina for 3,850,000 sq. mi.; 4% cultivated, 2% meadows and
refining, petroleum products, food and beverages; pastures, 44% forested, 42% waste or urban, 8%
about 2.2% from Communist countrics inland water
Approved i
For Release 2005/04/22 : CIA-RDP79-01051A0008000
10001-8
- 00800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0
Land boundaries; 5,600 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 56,500 mi.
(Ses reference map Vi)
LAND
95,000 sq. mi.; 3% cropland, 10% forest
Land boundaries: 2,160 mi.
WATER
Limits of territorial waters (claimed): 130 n. mi.
Approved For Release 2005/04/22
Coastline: 215 mi.
Railroads: 500 mi. meter gage, 5 mi. standard gage
Highways: 4,725 mi.; 465 mi. paved, 2,610 mi. all
weather, 1,650 mi. unimproved earth
Inland waterways: 1,115 mi.; 310 mi. navigable by
small oceangoing vessels, 805 mi. navigable by
shallow-draft steamers and barges
Ports: 1 major (Conakry), 3 minor
Civil air: 5 major transport aircraft
Airfields: 17 total, 17 usable: 4 with permanent-
surface runways; 4 with runways 8,000-11,999 ft., 7
with runways 4,000-7,999 ft.; 3 seaplane landing areas
Telecommunications: inadequate system of open-
wire lines, small radiocommunication stations, and 1
radio-relay link; principal center Conakry, secondary
center Kankan; 8,300 telephones; 105,000 radio
receivers; 1 AM, no FM, and no TV stations; 2
submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 924,000; 465,000
fit for military service
Military budget: for fiscal year ending 30
September 1970 (latest information available),
$6,073,000; 8.0% of total budget
BISSAU
Atlantic
Ocean
(See reference man VI)
LAND
76,000 sq. mi.; 13% forested, 4096 agricultural (12%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 1,665 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing 110 n. mi.; fisheries zone beyond territorial
sca)
Coastline: 330 mi.
Railroads: 640 mi. meter gage; 40 mi. double track
Highways: 8,725 mi.; 1,335 mi. bituminous, 990
mi. gravel, 400 mi. improved earth, 6,000 mi.
unimproved earth
18
Inland waterways: 935 mi.
Ports: 1 major (Dakar), 2 minor
Civil air: 5 major transport aircraft
Airfields: 27 total, 27 usable; 11 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 19
with runways 4,000-7,999 ft.; 8 seaplane stations
Telecommunications: relatively advanced for
Africa; 31,500 telephones; 286,000 radio receivers:
1,675 TV receivers; 3 AM, no FM, and 1 TV stations;
3 submarine cables; satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 965,000; 485,000
fit for military service; 52,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 June
1975, $29,817,536; about 9.895 of total budget
Conakry;
Freetown}
Sierr
Leone
Monrovia
Libe','d112aa16aa1a0029a493b423f0f987f51d7813c240bc4efb1fc4159236ae8c8f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c7eb90c8da9f15aaa1c45c867069cb8128e2b9ef701c9ba5488fa554486a858',1976,'AT','Austria','communications',35,'Vienna,
fco reference map tV]
LAND
32,400 sq. mi.: 20% cultivated. 266; meadows and
pastures, 15% waste or urban, 38% forested, 15;
inland water
Land boundaries: 1.605 mi.
Railroads: 4,073 mi; 3,673 mi. government
owned; 3,373 mi. standard gage of which 1,408 mi.
clectrified and 833 mi. double tracked; 300 mi.
narrow gage (26) of which 57 mi. electrified; 400 mi.
privately owned; 229 mi. standard gage of which 109
mi. electrified; 171 mi. narrow gage (2''6” and 38/2")
of which 55 mi. electrified
Highways: approximately 21,000 mi. total national
classified network, including 6,500 mi. federal and
14,500 mi. provincial roads; about 13,000 mi. paved
(bituminous, concrete, stone block) and 8,000 mi.
unpaved (gravel, crushed stone, stabilized soil);
additional 38,000 mi. communal roads (mostly
gravel, crushed stone, earth)
Inland waterways: 267 mi.; carries 5% freight, 6%
passengers
Ports: 2 major river (Vienna, Linz)
Pipelines: crude oil, 500 mi.; natural gas, 1,440 mi.
Civil air: 11 major transport aircraft, including l
registered but leased from a foreign country
Airfields: 54 total, 51 usable; 18 with permanent-
surface runways; 3 with runways 8,000-11,999 ft., 7
with runways 4,000-7,999 ft.
Telecommunications: highly developed and
efficient; extensive TV and radiobroadcast systems
with 100 AM, 89 FM, and 235 TV stations; 2.06
million telephones; 2.64 million radio receivers; 1.88
million television receivers; COMSAT station is
planned
DEFENSE FORCES
Military manpower: males 15-49, 1,714,000;
1,378,000 fit for military service; avcrage number
reaching military age (19) annually about 56,000
Military budget: for fiscal year ending 31
December 1975, $412 million; about 3.8% of the
federal budget
THE BAHAMAS
Atlantic Ocean
THE
4 Y BAHAMAS
DOMINICAN
REPUBLIC
Caribbean Sea
(See reference map tt}
LAND
4,400 sq. mi; 1% cultivated, 29% forested, 70%
built on, wasteland, and other
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 2,200 mi. (New Providence Is. 47 mi.)
Railroads: none
Highways: 1,300 mi. total: 530 mi. paved, 770 mi.
gravel
Ports: 2 major (Freeport, Nassau), 9 minor
Civil air: 10 major transport aircraft
Airfields: 51 total, 48 usable: 16 with permanent-
surface runways; 3 with runways 8,000-11,999 ft., 21
with runways 4,000-7,999 ft.: 4 seaplane stations
Telecommunications: telecom facilities highly
developed, including 58,000 telephones in totally
automatic system; tropospheric scatter link with
Florida; 90,000 radio receivers and 30,000 TV sets, 3
AM and 2 FM stations; 3 coaxial submarine cables
12','773b4650c5efba54f20e71af3b7bff44d58a847e2fa3ce12ca243ca5382a05f2','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d660c78dc185c845cdd9c0ce0c59e4f46281fe61103d0651ff90a98c9adcc479',1976,'BH','Bahrain','communications',39,'Arabian
Ses
(See reference map Vj
LAND
230 sq. mi. plus group of 32 smaller islands; 5%
cultivated, negligible forested area, remainder desert,
waste, or urban
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 100 mi.
Highways: 120 mi. bituminous surfaced; undeter-
mined mileage of natural surface tracks
Ports: 1 major (Bahrain)
Pipelines: crude oil, 35 mi.; refined products, 10
mi.; natural gas, 20 mi.
Civil air: 11 major transport aircraft (all registered
in the U.K.)
Airfields: 2 total, 1 usable; 1 with permanent-
surface runway; 1 with runway over 12,000 ft; 1
seaplane station
Telecommunications: excellent international
telecommunications; limited domestic services;
17,700 telephones; 82,000 radio receivers; 10,000 TV
sets; 1 AM radiobroadcast station; satellite earth
station; tropospherie scatter Bahrain to Qatar and','17098e68cd3fd5843b10d09a2379e8cd53176f35c93096a4d41d255cea542506','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c504bda35f3cdb2a4ce83fa8d9cb0dd8c158a22bc4c7a8ec6ff2df89c7e2684',1976,'AE','United Arab Emirates','communications',43,'Approved For Release 2005/04/22 :
DEFENSE FORCES
Military manpower: males 15-49, 62,000; fit for
military service 34,000
Supply: mostly from U.K.
Military budget: for fiscal year ending 31
December 1975; $14.05 million, 4.3% of total budget
(See reference map Viii
LAND
32,000 sq. mi.; almost all desert, waste or urban
Land boundaries: 680 mi. (does not include
boundaries between adjacent U.A.E. states)
WATER
Limits of territorial waters (claimed): 3 n. mi. for
all states except Sharjah (12 n. mi.)
Coastline: 900 mi.
Railroads: none
Highways: 175 mi. bituminous, undetermined
mileage of earth tracks
Pipelines: crude oil, 175 mi.
Ports: 5 major, 3 minor
Civil air: 2 major transport aircraft
Airfields: 55 total, 41 usable; 10 with permanent-
surface runways; 2 with runways over 12,000 ft., 2
with runways 8,000-1 1,999 ft., 11 with runways 4,000-
1,999 ft.
Telecommunications; telephone system in Dubayy
and Ash Shariqah also links these towns; Abu Dhabi
Petroleum operates a telecom system throughout the
sheikhdom; key centers are at At Tarif, Habshan, and
Az Zannah; 26,100 telephones; 51,000 radio and
17,000 TV receivers; 3 AM, 1 FM, and 2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 1,550,000;
about 857,000 fit for military service','095cf09a25353e37bc0777090f69ab19a3aa4478b5420cb4e9461ce07b11c696','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('172722fb122308cac981ddeebf6d82ed37593da68f3bfb740bbf22961ad45e94',1976,'BD','Bangladesh','communications',44,'Bay of Bengal
(See reference map VII)
LAND
55,000 sq. mi.; 6696 arable (including cultivated
and fallow), 18% not available for cultivation, 16%
forested
Land boundaries: 1,575 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 360 mi.
Railroads: 1,785 mi.; 1,175 mi. meter gage, 610 mi.
broad gage, 180 mi. double track; government-owned
Highways: 27,500 mi.; 2,500 mi. paved: 1,450 mi.
gravel, 23,610 mi. earth
Inland waterways: 4,850 mi.; river steamers
navigate main waterways
Ports: 1 major; 5 minor
Pipelines: natural gas, 93 mi.
Civil air: 9 major transport aircraft
Airfields: 26 total, 19 usable; 19 with permanent
surface runways; 2 with runways 8,000-11,999 ft., 10
with runways 4,000-7,999 ft.
Telecommunications: inadequate international
radiocommunications and landline service; fair
domestic wire and radiocommunication service; fair
broadcast service; 67,000 (est.) telephones; 400,000
radio sets; 15,000 (est.) TV sets; 10 AM, 1 FM, 1 TV,
and ] ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 19,307,000;
10,725,000 fit for military service
Military budget: for fiscal year ending 30 June
1975, $88.8 million; about 7% of the central
government budget','da3ae98ea3a7289398089f7958b38c1e63b7bba2d911d1f15017e34707a103aa','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a1d323eb89449c98836ec781f5309d01771d99bc90ab3a138518b9e192eccde',1976,'BB','Barbados','communications',48,'DOMINICAN
a REPUBLIC
fx.
PUERTO™
RICO
Atlantic
Ocean
(See reference map fl)
LAND
166 sq. mi; 60% cropped, 10% permanent
meadows, 3056 built on, waste, other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BARBADOS/BELGIUM
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 60 mi.
Railroads: none
Highways: 850 mi.; 800 mi. paved, and 50 mi.
gravel, and earth
Ports: 1 major (Bridgetown), 2 minor
Civil air: 5 major transport aircraft
Airfields: 1 with permanent-surface runway 8,000-
11,999 ft.; 1 seaplane station
Telecommunications: islandwide automatic
telephone system with 42,500 telephones; tropo-
spherie scatter link to Trinidad; VHF links to St.
Vincent and St. Lucia; 100,000 radio and 35,000 TV
sets, 2 AM, 1 FM, and 1 TV stations; 1 telegraph
submarine cable; communications satellite carth
station
DEFENSE FORCES
Military manpower: males 15-49, 51,000; 37,000
fit for military service; average number reaching
military age, (18) annually, 3,000; no conscription','21cdd880e0b02878cdae8f4c1ff6c22feb21aeb9dcfd6f5fd71ac93e19237817','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b7abc729d1d61f7d621e4e0c60fcf0d07b3a8da9e93feb374a7b0f468963473',1976,'BE','Belgium','communications',52,'LAND
11,800 sq. mi.; 28% cultivated, 24% meadow and
pasture, 28% waste, urban, or other; 20% forested
Land boundaries: 856 mi.
15
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
North Sea
(See reference map IV)
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 40 mi.
Railroads: 2,746 mi.; 2,573 mi. standard gage and
government owned, 1,585 mi. double track, 765 mi.
electrified; 173 mi. privately owned, electrified
narrow (3''3%"'')
Highways: approximately 65,000 mi., including
650 mi. limited access divided * Autoroute" ; about
50% paved (bituminous, stone block, concrete) and
5096 unpaved (erushed stone, gravel, improved earth)
Inland waterways: 1.270 mi., of which 950 are in
regular use by commercial transport
Ports: 5 major, ] minor
Pipelines: refined products, 600 mi.; crude, 100
mi.; natural gas, 1,800 mi.
Civil air: 56 major transport aircraft
Airfields: 45 total, 44 usable; 22, with permanent-
surface runways; 12, with runways 8,000-11,999 ft., 7
with runways 4,000-7,999 ft.
Telecommunications: excellent domestic and
international telephone and telegraph facilities: 2.71
million telephones; 3.8 million radio receivers; 2.51
million TV receivers; 1 AM, 18 FM, and 21 TV
stations; 9 coaxial submarine cables; 1 comunica-
ations satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,238,000;
1,793,000 fit for military service; average number
reaching military age (19) annually 76,000
Military budget: proposcd for fiscal year ending 31
December 1975, $1,899 million; about 9% of
proposed central government budget
Approved
For Release 2005/04/22 : CIA-RDP79-01051A00080001
0001-8','e785bfdd23cb8ef7bb9e9b4900b015e2c67c3cfe90747e1caf551c37a00957f1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9033a15d41baaceb2c18ec3849baa14dccee359baaa9683f9400d5dba1dcd6c',1976,'BZ','Belize','communications',56,'(formerly British Honduras)
$
Gulf of
Pacific
Ocean
{See reference map i)
LAND
8,870 sq. mi; 3896 agricultural (596 cultivated),
46% exploitable forest, 16% urban, waste, Water,
offshore islands or other
Land boundaries: 390 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 240 mi.
Railroads: nonc
Highways: 1,400 mi.; 200 mi. paved, 500 mi.
gravel, 550 mi. improved earth and 150 mi.
unimproved earth
18
Inland waterways: 514 mi. river network used by
shallow-draft craft
Ports: 1 major (Belize), 4 minor
Civil air: no Major transport aircraft
Airfields: 36 total, 36 usable; 4 with permanent.
surface runways; 1 with runway 4,000-7 999 ft; 1
seaplane station
Telecommunications: 4,000 telephones in auto-
matic and manual network; radio-relay system under
construction; 68,000 radio receivers; 4 AM Stations
DEFENSE FORCES
Military manpower: males 15-49, 30,000; 19,000
fit for military Service; 1,500 reach military age (18)
annually','83800515296c401c2686d826d2194851659e91ddf90db241c4283e99e21a074c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09bbaf1220800a5b20392b09488efd2bd7b8e3f63c9de174282e77f6bd9af72d',1976,'MX','Mexico','communications',57,'Caribbean
Sea
xBelmopan
¡See yere map il}
LAND
764,000 sq. mi.; 12% cropland, 40% pasture, 22%
forested, 26% other (including waste, urban areas and
public lands)
Land boundaries: 2,620 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 5,800 mi.
Approved For Release 2005/04/22
Railroads: 12,300 mi.; 11,610 mi. 4''8 le” gage: 690
mi. 30" gage; 64 mi. electrified; 12,233 mi.
government owned, 67 mi. privately owned
Inland waterways: 1,800 mi. navigable rivers and
coastal canals
Pipelines: crude oil, 2,410 mi.; refined products,
2,090 mi.; natural gas, 3,470 mi.
12.5 pesos = US$1
138
Ports: 9 major, 20 minor
Civil air: 182 major transport aircraft
Airfields: 1,497 total, 1,467 usable; 116 with
permanent-surface runways; 2 with runways over
12,000 ft., 22 with runways 8,000-11,999 ft., 242 with
runways 4,000-7,999 ft.; 9 seaplane stations
Telecommunications: highly developed telecom
system with extensive radio relay links: connection
into Central American microwave net; communica-
tion satellite ground station; 2.6 million telephones,
about 6.5 million radio and 4.8 million TV receivers,
600 AM, 100 FM, and 115 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 12,821,000;
9,758,000 fit for military service; average number
reaching military age (18) annually, 675,000
Military budget: for year ending 31 December
1975, $581.0 million; about 4.6% of direct federal
budget (includes merchant marine and military
industry)','12c1c7953ef6cd145eca2e6475555533d55fd5c40bb19c402e1430c74e8ea859','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ae239fbc05c650537860bcc5a9bcd075d4dac3f0c32dc4df775babc9992f4ca',1976,'BM','Bermuda','communications',61,'Atlantic
Ücean
,BERMUDA
(See reference map Hj
LAND
21 sq. mi.; 8% arable, 60% forested, 21% built on,
wasteland, and other, 11% leased for air and naval
bases
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 64 mi,
Railroads: none
Highways: 130 mi., all paved
1973), mostly
1974); fucl,
Ports: 3 major (Hamilton, St. George''s Freeport,
Ireland Island)
Civil air: no major transport aircraft
Airfields: 1 with concrete runway 9,710 ft; 1
seaplane station
Telecommunications: modern telecom system,
includes fully automatic telephone system with 36,500
scts; 50,000 radio and 22,000 TV receivers, 2 AM, 2
FM, and 2 TV stations; 3 coaxial submarine cables
Approved For Release 2005/04/22 :','8bf184570f77d64acc36610ab08f9b06256746268d54f9cccb9ccdb98f075897','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47e96613c6d816dbc07b35197009bc23315b7988351c917f9a6d96b7bce78635',1976,'BT','Bhutan','communications',65,'Bay of
Bengal
(See reference map VI!)
LAND
18,000 sq. mi.; 15% agricultural, 15% desert, waste,
urban, 70% forested
Land boundaries: about 540 mi.','4bb987151539f1eeff7a17d3b5e0161b89d6e0367ce176b40a8229b86855b246','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73375cda4b58aed7d9b33bc7f7c153707af31f7172a601663c89511d73bd2859',1976,'IN','India','communications',69,'Highways: 810 mi.; 260 mi. surfaced, 320 mi.
improved, 230 mi. unimproved carth
Freight carried: not available, very light traffic
Civil air: no major transport aircraft
Airfields: 2 total. 1 asphalt runway 4,500 ft., and I
with concrete runway 2,950 ft.
Telecommunications: facilities almost nonexistent;
570 telephones; 6,000 est. radio sets; no TV sets; I FM
and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 279,000; 150,000
fit for military service; about 9,000 reach militarv age
(18) annually
Supply: dependent on India
BOLIVIA
LAND
424,000 sq. mi.; 2% cultivated and fallow, 11%
pasture and meadow. 45% urban, desert, waste, or
other, 40% forest, 2% inland water
Land boundaries: 3,780 mi.
Railroads: 2,310 mi., single track; 2,290 mi., meter
gage, 20 mi., 2''6” gage; all government owned except
60 mi. of meter-gage track; 5.6 mi. of meter-gage
track clectrified
Highways: 23,200 mi.; 700 mi. paved, 4,100 mi.
gravel, 8,700 mi. improved earth, 14,700 mi.
unimproved earth
Inland waterways: officially estimated to be 6,250
mi. of commercially navigable waterways
Pipelines: crude oil, 1,040 mi.; refined products
and crude 930 mi.; natural gas 350 mi.
Ports: none (Bolivian cargo moved through Arica
and Antofagasta, Chile, and Matarani, Peru)
Civil air: 60 major transport aircraft
Airfields: 561 total, 520 usable; 4 with permanent-
surface runways; 1 with runway over 12,000 ft., 4 with
runways 8,000-11,999 ft., 116 with runways 4,000-
7,999 ft.
Telecommunications: poorest telecom facilities on
continent; radio-relay network under construction;
53,000 telephones; est. 2.5 million radio and 44,000
TV receivers; 84 AM, 17 FM, and 2 TV stations;
COMSAT station planned
DEFENSE FORCES
Military manpower: males 15-49 1,227,000,
770,000 fit for military service; average number
reaching military age (19) annually about 58,000
(See reference map VII)
LAND
1,211,000 sq. mi. (includes Indian part of Jammu-
Kashmir, Sikkim, Goa, Damao and Diu); 50% arable,
5% permanent meadows and pastures, 20% desert,
waste, or urban, 22% forested, 3% inland water
Land boundaries: 7,880 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi; additional 100 mi. is fisheries
conservation. zone, December 1968; archipelago
concept baselines)
Coastline: 4,378 mi. (includes offshore islands)
Railroads: 38,076 mi.; 16,259 mi. meter (3894)
gage, 18,892 mi. broad gage, 2,796 mi. (2/6" and
2''0''*) narrow gage government owned; 129 mi. 2''6”
and 2''0” gage privately owned; 7,800 mi. double
track; 2,485 mi. electrified
Highways: 795,607 mi.; 148,621 mi. paved,
111,876 mi. gravel or crushed stone, 216,044 mi.
improved earth, 319,066 mi. unimproved earth
Inland waterways: 8,750 mi.; 1,600 mi. navigable
by river steamers
Pipelines: crude oil, 794 mi.; refined products,
1,168 mi.; natural gas, 228 mi.
Ports: 8 major, 80 minor
Civil air: 86 major transport aircraft
Airfields: 374 total, 348 usable; 181 with
permanent-surface runways; 2 with runways over
12,000 ft., 52 with runways 8,000-11,999 ft., 118 with
runways 4,000-7,999 ft.
96
Telecommunications: fair domestic telephone
service where available; telegraph facilities wide-
spread; AM broadcast adequate; TV limited to
Bombay and New Delhi; international radio
communications adequate; 1,590,000 telephones;
14,033,919 radio and 75,000 TV sets; about 124 AM
stations at 80 locations, 6 TV stations, one earth
satellite station; submarine cables extend to Malaysia,
Sri Lanka, and Aden
DEFENSE FORCES
Military manpower: males 15-49, 141,619,000;
13,295,000 fit for military service; about 6,400,000
reach military age (17) annually
Military budget: for fiscal year ending 31 March
1976, $3.1 billion; 22% of total budget','f7d6a0eff84382d5648fa3aa043f94ef5d154436e26e2d7185786b717d332862','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97bb8e73c74c7421b6ae36d1fa58788a83872caa2a3ad80e4f55db9e00e6b926',1976,'BW','Botswana','communications',71,'Atlantic
Ocean
(See reference map VI)
LAND
220,000 sq. mi.; about 6% arable, less than 1%
under cultivation, mostly desert
Land boundaries: 2,345 mi.
Railroads: 400 mi. 3''6" gage, single track: owned
and operated by the Rhodesia Railroads
Highways: 12,900 mi.; 50 mi. paved; 730 mi.
crushed stone or gravel; remainder improved earth
and unimproved earth
Inland waterways: native craft only; of local
importance
Civil air: 2 major transport aircraft
Airfields: 84 total, 74 usable: 3 with permanent-
surface runways; 18 with runwavs 4,000-7,999 ft.
Telecommunications: the system is a minimal
combination of open wire lines, radio relay links, and
a few radiocommunication stations: Gaborone is the
center; 6,170 telephones; 55,000 radio receivers: 1
AM, I FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 161,000; 83,000
fit for military service; 8,000 reach military age (18)
annually','fc6c8970109ebb3e4f6bdbd700f2f6db0bdf219677275faeeb8302e4cdd43f81','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e24fa54ef4942c11575aa65df3b911a2d8fdfb203511cd444e6262f6c952c147',1976,'BR','Brazil','communications',75,'LAND
3.290.000 sq. mi; 4% cultivated, 13% pastures,
23% bnilt-on area, waste, and other, 60% forested
Land boundaries: 8.125 mi
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Atlantic
Ocean
Brasilia
*
(See reference map Il}
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 4,655 mi.
Railroads: 19.935 mi.; 17,586 mi. 33%" gage.
2,085 mi. 5''3" gage, 121 mi. 448%” gage, 143 mi.
narrow gages; 1,621 mi. electrified
Highways: 811,000 mi.; 48.000 mi. paved, 763,000
mi. gravel or earth
Inland waterways: 31,000 mi. navigable
Ports: 6 major, 25 significant minor
Pipelines: crude oil, 770 mi.: refined products, 290
mi.; natural gas, 24 mi.
Civil air: 181 major transport aircraft
Airfields: 4,044 total, 3,933 usable; 147 with
permanent-surface runways; 14 with runways 8,000-
11,999 ft, 399 with runways 4,000-7,999 ft. 18
scaplane stations
Telecommunications: moderately good telecom
system; radio relay widely used; 4 communications
satellite ground stations; 2.75 million telephones; est.
32 million radio and 9.0 million TV receivers; 1,005
AM, 150 FM, and 165 TV stations; 6 submarine
cables, including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 24,561,000:
16,031,000 fit for military service; 1,200,000 reuch
militarv age (18) annually
Military budget: for fiscal year ending 31
December 1975, $1,321 million; 8.7% of federal
budget
BRITISH SOLOMON ISLANDS
LAND
About 11,500 sq. mi.
WATER
Limits of territorial waters: 3 n. mi.
Coastline: about 3,300 mi.
Railroad: none
l Australian dol-
Highways: 518 mi.; 150 mi. sealed or all-weather
Inland waterways: nonc
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 22 total, 21 usable; 1 permanent surface
runway 6,300 ft.; 6 natural surface runways 4,000-
7,999 ft., 14 natural surface runways less than 3,999
ft.; 8 scaplane stations
Telecommunications: 3 AM broadcast, no FM,
and no TV stations; 7,700 radio receivers, 1,526
telephones, no TV sets; international connections with
London, England, via cable broadcasts
BRUNEI
TH
NAM
South China Sea P d
BRUNEI
Bandar Seri Begawa
{See reference map VII]
LAND
2,280 sq. mi.; 3% cultivated; 22% industry, waste,
urban or other; 75% forested
Land boundaries: 237 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 100 mi.
Railroads: 6 mi. narrow gage (20)
Highways: 750 mi; 234 mi. paved (bituminous
treated), 250 mi. gravel or stone, 266 mi. unimproved
Inland waterways: 180 mi.; navigable by craft
drawing less than 4 ft.
Ports: 2 minor (Bandar Seri Begawan, formerly
Brunei, and Kuala Belait)
25
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BRUNEI/BULGARIA
Pipelines: crude oil, 84 mi; refined products, 35
mi., natural gas, 35 mi.; crude oil and natural gas, 150
imi. under construction
Civil air: 2 major transport aircraft
Airfields: 3 total, 3 usable: 2 with permanent-
surface runway; I with runway over 12,000 ft.; 2 with
runways 4,000-7,999 ft.
Telecommunications: service throughout country
is adequate for present needs: international service
good to adjacent Sabah and Sarawak; radiobroadcast
coverage good; 7,788 telephones; 20,000 radio and
3,000 est. TV sets; Radio Brunei broadcasts from 3
AM, 1 FM, and ! TV station
DEFENSE FORCES
Military manpower: males 15-49, 37,000; 22.000
fit for military service; about 1.000 reach military age
(18) annually
zd A —MnU M
Approved
p For Release 2005/04/22 : CIA-RDP79-01051A00080001
0001-8
I Canada
Ellesmer
island
x
m nited
E Fairbanks «
af Yukon }
Territory V =
tias "i
Ms
AN
M à
d. Yellowknite Terri t
l i» Great
z irman, Slave Lake
: H T :
«f Prince Rupert j qu
1 / o aen i
.«( British ; i : f .
Columbia 7 S / | ony y
E y F
È x Edmonton / c | a n a d a Schatteriles Goose Bay.
a EE |] Manitoba ge TE oe Pd
& Vancouver ? Saskatchewan : V ui
Quebec
\\
4 calgary! Saskatoon i "d
) l | d d
. ¡, bake ^ i
Regina e | Winnipeg |
iWinnipe
l *
Halifax
ji Scotia
— R san Lake Ciy : :
as DP. Milwaukee
PEN NM Chicago J :
: PA ie cenit i axl Atlantic Ocean
o e geles” pigias : fg Washington » )
bos Bogeles Kansas City * : ; iss
A DER + St. Louis H
United States E
“2 Oklahoma City * p
a [v] 500 Miles
(o) 500 Kilometers
zc BOUNDARY REPRESENTATION 18 ^.
HOT NECESSARILY AUTHORITATIVE
502847 1-76
Approved
p For Release 2005/04/22 : CIA-RDP79-01051A00080001(
0001-8
a
p
INDIAN
OCEAN
502854 1-76
^in
M
2
donesia
e
ortuguese
Timor
ae
Arafura Sea
Approved For Release 2005/04/22 :
MARIANA .
ISLANDS
Saipan
Guam ws) $
Trust Territory of the Pacific Islands
U.S.) >
Truk
Islands":
T Solomon Islands
Choiseul (UK)
D Santa Isabel
Hohiarg, A Malaita : SANTA
Guadalcanal” «en Cristobal “CRUZ
d * Rennelf s.
Santo, 1
New Hebrides ©
(Anglo-French Condomini)
New i B
m. $ A
New Caledonia F
(Fr)
Tasmania
lobart
Wake US)
CIA-RDP79-01051A000800010001-8
o Kavai
Oskua
ISLANDS
{United
States)
„Johnston
us)
NORTH PAC
€
du
US)
"Washington
"Fanning
VIII
Hawauan P
Hawaii
LFIC
4
<
¡Christmas
Howland US.)
Baker US.)
HUS 4LK. joint admin.) Jarvis
y^ US)
(Canton. PHOENIX IS.
Phoenix * (U.K. admin.. US. claim)
Gardner’ Hull ^
Gilbert Islands
, Tuvalu ls. (U.K.)
„ „~ Administered by New Zealand e.
S^ maes,
American','264eef5a89ef34095ba53f1349202c59a7746478568d8f0d001d5998106631ca','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51546cbb5e39fa8be2b563d90bca6c490cc2c80d796f383abe41b23ce3fe99cd',1976,'BG','Bulgaria','communications',79,'? BULGARIA
* Solia
(Ser reference map iV}
LAND
42,800 sq. mi.; 41% arable, 11% other agricultural,
33% forested, 15% other
Land boundaries: 1,170 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 220 mi.
Railroads: 2,646 mi.; about 2,494 mi. standard
gage, 152 mi. narrow gage; 157 mi. double track; 692
mi. electrified; government owned (1975)
Highways: 22,300 mi.; 13,100 mi. paved, 6,100 mi.
crushed stone and gravel, 3,100 mi. carth (1974)
Inland waterways: 300 mi. (1975)
Freight carried: rail — 85.8 million short tons, 11.8
billion short ton/mi. (1974); highway—698.5 million
short tons, 6.5 billion short ton/mi. (1974),
waterway—4.9 million short tons, 1.7 billion short
ton/mi. (excl. int''l. transit traffic) (1974)
Ports: 2 major (Varna, Burgas), 5 minor (1975)
Civil air: 41 major transport aircraft (1975)
DEFENSE FORCES
Military budget: for fiscal year ending 31
December 1975, est. 549 million leva; about 6% of
total budget
BURMA
LAND
262,000 sq. mi; 28% arable, of which 12% is
cultivated, 62% forest, 10% urban and other (1969)
Approved For Release 2005/04/22
Bay
of Bengal
South
China Sea
(Sea reference map VIT)
Land boundaries: 3,630 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,900 mi.
Railroads: 2,041 mi.; 1,971 mi. meter gage, 70 mi.
narrow-gage industrial lines; 204 mi, double track;
government owned
Highways: 15,535 mi.; 4,205 mi. paved, 4,775 mi.
gravel, 6,555 mi. unimproved earth
Inland waterways: 8,000 mi.; 2,000 mi. navigable
by large commercial vessels
Ports: 4 major, 6 minor
Civil air: 14 major transport aircraft
Airfields: 80 total, 79 usable; 23 with permanent-
surface runways, 2 with runways 8,000- 11,999 ft., 38
with runways 4,000-7,999 ft.
28
Telecommunications: provide minimum require-
ments for local intercity service; international service
is fair; radiobroadcast coverage is limited to the more
populous areas; 29,411 telephones: 627,000 radio, and
no TV sets; 1 AM, 1 FM, and no TV stations','8111038baa824799ba8691ce20760721dc072b84dfaabc62dd70b3686c97d224','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6172f99b965b26a9c2e3fb8fb7ae1dae12e651c1a67ff47045e7f04fb2f806b1',1976,'BI','Burundi','communications',83,'(See reference map VI)
LAND
11,000 sq. mi.; about 37% arable (about 66%
cultivated), 23% pasture, 10% scrub and forest, 30%
other
Land boundaries: 605 mi.
Railroads: none
Highways: 3,700 mi.; 338 mi. bituminous,
remainder crushed stone, gravel, laterite, and
improved or unimproved earth
Inland waterways: Lake Tanganyika navigable for
lake steamers and barges
Ports: 1 minor lake
Civil air: 3 major transport aircraft
Airfields: 12 total, 12 usable; 1 with permancnt-
surface runway; 1 with runway 8,000-11,999 ft.
Telecommunications: telegraph is principal
service, limited telephones; 4,800 telephones, 100,000
radio receivers; 2 AM, 1 FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 888,000; 461,000
fit for military service; 48,000 reach military age (16)
annually
Ships: 3 high speed boats
Military budget: for fiscal year ending 31
December 1975, $8,556,000; about 23.4% of ordinary
budget','1d8b114a54ec524773aea0e1f14ce5376da5a59da909bcf3a62411d3bba41e41','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d25ed8d4e8d8fde5dae7ede619cd75becdf53b88feb9fe5d6f722f78b16fe76',1976,'KH','Cambodia','communications',87,'(See reference map Vil}
LAND
70,000 sq. mi.; 1696 cultivated, 7496 forested, 10%
built-on area, wasteland, and other
Land boundaries: 1,515 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: about 275 mi.
Railroads: 380 mi. meter gage; government owned:
many sections in disrepair due to hostilities
Highways: 8,100 mi.; 1,510 ini. bituminous, 4,370
mi. crushed stone, gravel, or improved earth; and
2,220 mi. unimproved earth; some roads not operable
because of recent hostilities
Inland waterways: 2,300 mi. navigable all year to
craft drawing 2 ft.: 175 navigable to craft drawing 6 ft
Ports: 2 major, 5 minor
Airfields: 60 total, 25 usable: 7 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 6
with runways 4,000-7,999 ft.: 1 seaplane station
DEFENSE FORCES
Military manpower: males 15-49, 1,776,000:
986,000 fit for military service; 78,000 reach military
age (18) annually
Guif of','10a095ead116b2d6c557ca026b3d39312c1bb7ac3f044f729f502ac85bff5a6f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2f4313b2a6324386f3df375b1383e24d7e9b15f7576ef057702eeb3206d5704',1976,'CA','Canada','communications',94,'Railroads: 46,351 mi.; 45,513 mi. 4''8''4" gage (27
mi. electrified), 727 mi. 3''6" gage (in New-
foundland); 111 mi. 3'' gage
Highways: 518,177 mi.; 396,088 mi. surfaced
(109,234 mi. paved), 122,089 mi. earth
Inland waterways: 1,875 mi.
Pipelines: oil, 13,140 mi.; natural gas, 46,425 mi.
Ports: 19 major, 300 minor
Civil air: 596 major transport aircraft
Airfields: 1,764 usable; 263 with permanent-
surface runways; 3 with runways over 12,000 ft., 29
with runways 8,000-11,999 ft, 276 with runways
4,000-7,999 ft.; 58 seaplane stations
Telecommunications: excellent service provided by
modern telecom media; 12.8 million telephones; 22.0
million radiobroadeast receivers; 9.2 million TV
receivers; countrywide AM, FM, and TV coverage
including 630 AM, 80 FM, and 480 TV stations; 8
coaxial submarine cables; 3 satellite earth stations
DEFENSE FORCES
Military manpower: males 15-49, 5,556,000;
4,777,000 fit for military service; average number
reaching military age (17) annually 230,000
Military budget: proposed for fiscal year ending 31
March 1976, $2.8 billion; about 10% of proposed
central government budget
CAPE VERDE ISLANDS
CAPE VERDE ISLANDS
Wom oD
"EV
20 Bos
Atlantic Ocean BISSAU
F
(See reference map IV}
LAND
1,560 sq. mi., divided among 10 islands and several
islets
WATER
Limits of territorial waters: 6 n. mi. (fishing 12 n.
mi.)
Coastline: 600 mi.
Airfields: 6 total, 6 usable; 4 permanent surface
rTunways; 1 with runway 8,000-11,999 ft. 4 with
runways 4,000-7,999 ft.; 1 seaplane station','6025623d113f3a5db583caf1bc4cafbba51467f6bede9e5420bcfb8524bafe82','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d867af97f2ae563cffe0fdbb58abf54d466a2f305610cc735e827ef3bfd978b6',1976,'CF','Central African Republic','communications',96,'(See reference map VI)
LAND
242,000 sq. mi.; 10%-15% cultivated, 5% dense
forests, 8095-859; grazing, fallow, vacant arable land,
urban, waste
Land boundaries: 3,095 mi.
Railroads: none
Highways: 13,250 mi.; 115 mi. bituminous, 2,265
mi. gravel and/or crushed stone, 3,420 mi. improved
earth, 7,450 mi. unimproved carth
Inland waterways: 4,400 mi.; traditional trade
carried on by means of dugouts on the extensive
system of rivers and streams; the Oubangui River
between Bangui and Brazzaville is navigable for
about 8 months a year, and short sections of the
Sangha and the Lobaye Rivers are navigable
throughout year; during high-water period (July -
December) Oubangui navigable upstream from
Bangui as far as Ouango
Ports: Bangui, Ouango (river ports)
Civil air: 4 major transport aircraft
Airfields: 58 total, 48 usable; 3 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 18
with runways 4,000-7,999 ft.
Telecommunications: facilities are meager and
provide only barely sufficient services; network is
composed of low-capacity, low-powered radiocom-
munication stations and radio-relay links; single
center of Bangui has only international radio
connections; 5,100 telephones; 70,000 radio receivers;
1 AM, 1 FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 457,000; 235,000
fit for military service
Supply: mainly dependent on France, but has
received equipment from Israel, Italy, U.S.S.R.','0a443e5d22293979b68174c76037b80b0d0b8412e563d09dd2c515873a383e24','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('828043154de5bede81f37ca5268f70a9e5381dd80f9f36f30e0fcf0f0f03639a',1976,'TD','Chad','communications',100,'{Sea reference map VI)
LAND
496,000 sq. mi.; 17% arable, 35% pastureland, 2%
forest and scrub, 46% other uses and waste
Land boundaries: 3,720 mi.
Approved For Release 2005/04/22
Railroads: none
Highways: 19,200 mi.; 160 mi. bituminous, 3,300
mi. gravel and laterite, and 15,740 mi. unimproved
Electric power: 24,800 kw. capacity (1974); 57
Inland waterways: approximately 1,300 mi. of
year-round navigability, increased to 3,000 mi. during
high-water period
Civil air; 3 major transport aircraft
Airfields: 67 total, 63 usable: 4 with permanent-
surface runways: 1 with runway 8,000-11,999 ft., 25
with runways 4,000-7,999 ft.
Telecommunications: fair svstem of radiocom-
munication stations only for intercity links; principal
center N''Djamena, secondary center Sarh; 5.100
telephones; 70,000 radio receivers: 1 AM, no FM, and
no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 964,000; 495,000
Hit for military service; average number reaching
military age (20) annually about 37,000
36
Supply: dependent on France primarily
Military budget: for fiscal year ending 31
December 1978, $15,228,000; about 21% of total
budget','54ca0c684f9b2e0d3d52732fecd773643150e3af4eff33a0ba3e92f5ec39ecba','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b193c226d996f3c671ebf9d962118325dc376fce37799d6d6a21078cfaf1e26',1976,'CL','Chile','communications',104,'Santiago A
Pacific
Ocean
Atlantic
Ocean
(See reference map ttl}
LAND
286,000 sq. mi; 2% cultivated, 7% other arable,
15% permanent pasture, grazing, 29% forest, 47%
barren mountains, deserts, and cities
Land boundaries: 3,930 mi.
WATER
Limits of territorial waters (claimed); 3 n. mi.
(fishing 200 n. mi.)
Coastline: 4,000 mi.
Railroads: 5,511 mi.; 2,086 mi. 5''6” gage, 154 mi.
4/84" gage, 2,644 mi. 33%” gage, 69 mi. 2''6" gage,
22 mi. 11154" gage, 536 mi. specific gage not given;
199 mi. double track; 711 mi. electrified
Highways: 39,600 mi.; 5,500 mi. paved, 19,800 mi.
gravel, 14,300 mi. improved and unimproved earth
Inland waterways: 451 mi.
Pipelines: crude oil, 470 mi.; refined products, 490
mi.; natural gas, 200 mi.
Ports: 10 major, 20 minor
Civil air: 41 major transport aircraft
Airfields: 361 total, 361 usable; 43 with
permanent-surface runways; 3 with runways 8,000-
11,999 ft., 55 with runways 4,000-7,999 ft.; 6 seaplane
stations
Telecommunications: extensive radio relay
network; telephone network modern, 465,000
37
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CHILE/ CHINA, PEOPLES REPUBLIC OF
instruments; communications satellite ground station;
2.75 million radio and 1 million TV receivers; 153
AM, 30 FM, and 55 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 2,508,000;
1,892,000 fit for military service; average number
rcaching military age (19) annually about 94,000
Military budget: for fiscal year ending 31
December 1975, US$353.5 million; about 18.7% of
central government budget
CHINA, PEOPLES REPUBLIC OF
[Sae reference map Viti
LAND
3.7 million sq. mi; 11% cultivated, sown arca
extended by multicropping, 78% desert, waste, or
urban (32% of this arca consists largely of denuded
wasteland, plains, rolling hills, and basins from which
about 3% could be reclaimed), 8% forested: 2%-3%
inland water
Land boundaries: 15,000 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 9,000 mi.
Airfields: 382 total; 243 with permanent-surface
runways; 7 with runways over 12,000 ft., 78 with
runways 8,000-11,999 ft., 212 with runways 4,000-
1,999 ft.; 2 seaplane stations
CHINA, REPUBLIC OF
LAND
14,000 sq. mi. (Taiwan and Pescadores); 2496
cultivated, 6% pasture, 55% forested, 1596 other
(urban, industrial, denuded, water area)
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 615 mi. Taiwan, 285 mi. offshore islands
Approved For Release 2005/04/22 :
Taipei
REPUBLIC. OF','1d779f38404895594e2ecfd535c7ee5f36fca3b0f72861f923989d4d307f8586','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('081b2960359da0291e575638e7510e58e71e02eaee0e0af4295e6eeb0900f33a',1976,'CN','China','communications',108,'Ò
South China :
y PHILIPPINES
E (Sor reference map Vil}
Pipelines: 382 mi. refined products, 60 mi. natural
gas
Airfields: 37 total, 37 usable; 27 with permanent-
surface runways; 2 with runways over 12,000 ft., 10
with runways 8,000-11,999 ft., 11 with runways 4,000-
7,999 ft.; 2 seaplane stations
Telecommunications: good international and
domestic service; 742,304 telephones: est. 3 million
radio receivers; 1.3 million TV receivers: 111 AM, 4
FM broadcast stations; 8 TV systems: 2 satellite
ground stations; radio relay links to Hong Kong and
the Philippines; new inter-island submarine cables;
Manila submarine cable planned
DEFENSE FORCES
Military manpower: males 15-49. 3,980,000:
3,110,000 fit for military service: average number
currently reaching military age (19) annually 192.000','e6f03092028a2e925fc07acec4b47053373c651ae96209c00eaf9c481336bbb3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e22860f450f054eafedddc793f1423a5a65c8460670d451ebb1e5cadcad2fa06',1976,'CO','Colombia','communications',112,'SV» mp c2
+ Bogotá
ECUADOR Z. m
Pacific
Ocean
(Sen reference map tit)
LAND
440,000 sq. mi: settled arca 28% consisting of
cropland and fallow 596, pastures 14%, woodland,
swamps, and water 6%, urban and other 3%:
unsettled area 72% — mostly forest and savannah
Land boundaries: 3.750 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,500 mi.
Railroads: 2,160 mi., all 3''0” gage, single track, 22
mi. electrified
Highways: 32,700 mi.; 4,500 mi. paved, 23,200 mi.
crushed stone or gravel, 5,000 mi. improved earth
Inland waterways: 8,900 mi., navigable by river
boats
Pipelines: crude oil, 2,000 mi.; refined products,
830 mi.; natural gas, 370 mi.; natural gas liquids 80
mi.
Ports: 5 major, 5 minor
Civil air; 105 major transport aircraft
Airfields: 714 total, 700 usable; 44 with
permanent-surface runways; 1 with runway over
12,000 ft.; 6 with runways 8,000-11,999 ft., 86 with
runways 4,000-7,999 ft.; 11 seaplane stations
4]
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
COLOMBIA/COMORO ISLANDS
Telecommunications: nationwide radio-relay
telecom. system; communications satellite ground
station; 1.22 million telephones; 6.5 million radio and
1.4 million TV receivers; 325 AM, 130 FM, and 55 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 5,869,000;
3.710,000 fit for military service; average number
reaching military age (18) annually about 248,000
Military budget: proposed for fiscal year ending 31
December 1975, 8115.5 million; about 8.996 of central
government budget
COMORO ISLANDS
Indian Ocean |
COMORO
« ISLANDS
ASCAR
(See reference map Vi}
LAND
838 sq. mi: 4 main islands; forests 16%, pasture
7%, cultivable area 4896, non-cultivable area 29%
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 211 mi.
Railroads: none
revenues $7.6 million, current
Highways: 621 mi., approximately 183 mi.
bituminous, remainder crushed stone or gravel
Ports: | minor (Moroni on Grande Comore)
Civil air: 7 major transports (registered in France)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
ee mismá—H t0 0808
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
COMORO ISLANDS/CONGO
Airfields: 5 total, 5 usable; 5 with permanent
surface runways; 1 with runway 8,000 to 11,999 feet, 4
with runways 4,000-7,999 ft.
Telecommunications: minimal system of HF
radiocommunication stations for interisland island
and external communications to Malagasy and
Reunion; Dzaoudzi center but of slight significance;
1,300 telephones; 35,500 radio receivers; 1AM,1FM,
and no TV stations
Fouito: Jw.
Ecuador, n : Manaus
Es Io/ ne
Lo,
s eli
i-e
Guayag;
e “Iquitos, ;
Braz
¿“Salvador
¿Brasilia
Bolivia
xSucre
J
AS
Sao Paulo, y *"''Rio de Janeiro
A
Sout h Antofagasta
iy
Pacific
Ocean Chil
South
Atlantic
Buenos Aires”
Montevideo
Ocean
800 Miles
o
^ Galapagos Is.
(Ecuador)
800 Kilometers
400
BOUNDARY REPRESENTATION IS
NOT NECESSARILY AUTHORITATIVE
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Venezuela
Middle Americ
Puerto. Rico virgin is. (US. UK
US) av ¿Anguilla (U.K)
St Christonhet LT Ki
vq eAntigua (UK)
Ta Nevis (UK)
© ,G Guadeloupe (Er
e SDominicatu.K
$ eee ti','6910c41baafd13e4e5b75adaad626509c12715178ea369d6e0ab364a650bd6ca','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b5c506ce8383c5e1794b353fc3610cc90feb67eb4b512b31af7ab7e25e6b984',1976,'CG','Congo','communications',116,'"CENTRAL ^
AFRICAN REPUBLICA
(See reference map Vi)
LAND
135,000 sq. mi.; 63% dense forest or woodland, 33%
cultivable or grazing (2% cultivated est.), 4% urban or
waste
Land boundaries: 2,805 mi.
WATER
Limits of territorial waters (claimed): 30 n. mi.
Coastline: 105 mi.
Railroads: 490 mi., 3''6” gage, single track
Highways: 6,741 mi.: 380 mi. bituminous surface
treated; remainder gravel, laterite, or improved earth
Inland waterways: 4,030 mi. navigable
Ports: 1 major (Pointe Noire)
Civil air: 7 major transport aircraft
Airfields: 71 total, 53 usable; 2 with permanent-
surface runways; | with runway 8,000-11,999 ft., 18
with runways 4,000-7,999 ft.; | seaplane station
Telecommunications: services adequate for
Eovernment and public; network js comprised of low-
capacity, low-powered radio communication stations,
coaxial cables and wire lines, connect key centers of
Brazzaville, Pointe-Noire, and Dolisie with maximum
of 21 channels; 10,200 telephones; 75,000 radio
receivers; 2.600 TV receivers; 3 AM, no FM, and 1 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 324,000; 162,000
fit for military service: about 13,000 reach military
age (20) annually
Military budget: for fiscal year ending 31
December 1975, $37,331,882; about 10.8% of total
budget','316f63b46bb7ace1ffab6047eb0a4198682d6773f0f4364696e9604b0b98e058','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c90850fc660f8c26d00627f5daf2c3ea4d306ce74f6e25e233f04503d480928b',1976,'CK','Cook Islands','communications',120,'LAND
About 93 sq. mi.
WATER
Limits of territorial waters: 3 n. mi.
Coastline: about 75 mi.
Railroads: none
10001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008000
EN
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
COOK ISLANDS/ COSTA RICA
Highways: 162 mi.: 12 mi. paved, 68 mi. gravel, 52
mi. improved earth, 30 mi. unimproved carth
Inland waterways: nonc
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 3 total; 1 with composite surface runway
7,240 ft., 3 with natural surface runways 4,000-7,900
ft.; 2 seaplane stations
Telecommunications: 3 AM, no FM, and no TV
stations: 7,000 radio receivers, and 740 telephones;
microwave relay station provides connection with
(New Zealand)
FUFISLANDS >;
^ Tonga
a a y
3 A „Niue A
s
‘Nuku''alofa Rarotonga,
North island
gton
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
-
$
c
>
ÁIR. admin
U.S. claim)
z
o
“a
ILES MARQUISES
i „Papeete
ES
Fo, Tarii
Se .
Muruřoa +
, AES AUs; : 1 y
> 784, es F rench Nes Gambier
Polynesia Lt
Pitcairn Island
(UK)
Rapa
Line of separation
(not a formal international
boundary or territorial limit)
1000 Nautical Mites
1000 Statute Miles
BOUNDARY STATION 15,
NOT Neces: TATE
Oceania','3cc2bd5afa1c50ba5fb1a236ce47cbcc83d021b4eb60fe36186c0b6d00f9b890','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d07ffe05a380f03251c5da3b55e568e050574ebfca8c239ad2842fb36f4789e6',1976,'CR','Costa Rica','communications',124,'A
(Sea reference map n
LAND
19,700 sq. mi.; 309 agricultural land (8%
cultivated, 22% meadows and pasture), 60% forested,
10% waste, urban, and other
Land boundaries: 415 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing 200 n. mi.; specialized competence over living
resources to 200 n. mi.)
Coastline: 800 mi.
Railroads: 407 mi.; 395 mi. 376" gage, 12 mi. 3''0"
gage, all single track, 72 mi. electrified
Highways: 14,300 mi.; 1,000 mi. paved, 4,100 mi.
otherwise improved, 9,200 mi. unimproved earth
Inland waterways: about 455 mi. perennially
navigable
Pipelines: refined products, 80 mi.
Ports: 3 major (Limon, Golfito, Puntarenas), 4
minor
Civil air: 24 major transport aircraft
Airfields: 151 total, 149 usable; 19 with
permanent-surtace runways; 9 with runways 4,000-
7,999 ft.; 2 seaplane stations
Telecommunications: good domestic telephone
service; 99,100 telephones; connection into Central
American microwave net; 350,000 radio and 175,000
TV receivers; 45 AM, 10 FM, and 11 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 426,000; 280,000
Ht for military service; average number reaching
military age (18) annually about 24,000
Supply: dependent on imports from U.S.
Military budget: for fiscal year ending 31
December 1973, $5.2 million for Ministry of Public
Security, including the Civil Guard; about 2.3% of
total central government budget
AG
Atlantic
Ocean
d s d
{Sae reference map 1)
LAND
44,200 sq. mi.; 35% cultivated, 30% meadow and
pasture, 20% waste, urban, or other, 15% forested
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 2,320 mi.
Railroads: 9,150 mi. government owned; 3,150 mi.
common carrier lines (8 mi. double track and 95 mi.
electrified) and about 6,000 mi. plantation-
industrial lines; common carrier lines comprise 3,100
mi. 481" standard gage, and about 50 mi. 3''0” and
2''6” narrow gage; plantation-industrial lines comprise
about 4,000 mi. standard gage and 2,000 mi. narrow
gage
Highways: 12,800 mi.; 5,400 mi. paved, 7,400 mi.
gravel and earth surfaced
Inland waterways: 150 mi.
Pipelines: natural gas, 50 mi.
Ports: 8 major (including U.S. Naval Base at
Guantanamo), 44 minor; Guantanamo under U.S.
control
Civil air: 32 major transport aircraft
Airfields: 194 total, 182 usable; 44 with
permanent-surface runways; 1 with runway over
12,000 ft., 8 with runways 8,000-11,999 ft., 28 with
runways 4,000-7,999 ft.; 11 seaplane stations
Telecommunications: modern facilities adequately
serve military and most civil needs; excellent
international facilities, satellite ground station;
360,000 telephones; 2.0 million radio and 600,000 TV
receivers; 100 AM, 25 FM, and 16 TV stations; 6
submarine cables, including 1 coaxial
DEFENSE FORCES
Military budget: for fiscal year ending 31
December 1966 (last announced budget) $213
million; about 7.896 of total budget','92317d950edb0a84125cbb4984d9ced245ae0a595ad58c7fc103e129f25ee74b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff0f78ed30c431e85028f99963eef4cf5372cdf3e1d4f5ea6b3d2a5a0ad06815',1976,'CY','Cyprus','communications',128,'LAND
3,572 sq. mi; 47% arable and land under
permanent crops, 18% forested, 10% meadows and
pasture, 25% waste, urban areas, and other
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 400 mi. (approx.)
47
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Mediterranean
(See raference map V}
Railroads: none
Highways: 5,000 mi.; 2,100 mi. bituminous surface
treated; 2,900 mi. gravel, crushed stone, and earth
machinery and transport equipment,
Ports: 3 major (Famagusta, Larnaca, Limassol), 6
minor
Civil air: 5 major transport aircraft
Airfields: 12 total, 10 usable; 8 with permanent-
surface runways; 2 with runways 8,000-11,999 ft.; 5
with runways 4,000-7,999 ft.
Telecommunications: moderately good telecom-
munication system; 63,000 telephones; 205,600 radio
receivers; 85,400 TV receivers; 12 AM, 5 FM, and 4
TV stations; tropospheric scatter circuits to Greece and
Turkey
DEFENSE FORCES
Military budget: for fiscal year ending 31
December 1974, $18.5 million about 13.1% of central
government budget
CZECHOSLOVAKIA
(See PUER map IV)
LAND
49,400 sq. mi.; 42% arable, 14% other agricultural,
35% forested, 9% other
Land boundaries: 2,200 mi.
Railroads: 8,255 mi.; 8,075 mi. standard gage, 70
mi. broad gage, 110 mi. narrow gage; 1,741 mi.
double track; 1,742 mi. electrified; government
owned (1975)
Highways: 45,613 mi.; 863 mi. concrete; 34,500
mi. bituminous; 1,800 mi. cobblestone, brick sett,
stone block; 8,450 mi. crushed stone, gravel, improved
earth (1975)
Inland waterways: 517 mi. (1975)
Pipelines: crude oil, 900 mi.; refined products, 535
mi.; natural gas, 3,200 mi.
Freight carried: rail —294.3 million short tons, 44.5
billion short ton/mi. (1974); highway—1,050.5
million short tons, 9.3 billion short ton/mi. (1974);
waterway—5.4 million short tons, 1.9 billion short
ton/mi. (excl. intl. transit traffic) (1974)
Ports: no maritime ports; outlets are Gdynia,
Gdansk, Szczecin in Poland; Rijeka, Yugoslavia;
Hamburg, West Germany; Rostock, East Germany;
principal river ports are Prague, Melnik, Usti nad
Labem, Decin, Komarno, Bratislava (1975)
Civil air: 58 major transport aircraft (1975)
DEFENSE FORCES
Military budget: (announced) for fiscal year
ending 31 December 1975, est. 19.3 billion crowns,
about 796 of total budget
DAHOMEY
ENIN,
orto ás
Novo Y
S è
Atlantic Ocean . a
j Pes
(See reference map VI)
On November 30, 1975, President Kerekou
announced that Dahomey would henceforth be
known as Benin. The long-form name of the State is
the Peoples Republic of Benin.
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
DAHOMEY
LAND
44,700 sq. mi.; southern third of country is most
fertile; arable land 80% (actually cultivated 11%),
forests and game preserves 19%, non-arable 1%
Land boundaries: 1,220 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(100 n. mi. mineral exploitation limit)
Coastline: 75 mi.
Railroads: 360 mi., all meter gage (3''3%")
Highways: 4,300 mi.; 547 mi. paved, 2,665 mi.
gravel and/or improved earth, remainder unimproved
Inland waterways: 400 mi. navigable
Ports; 1 major (Cotonou), 1 minor
Civil air: no major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-
surface runway; 4 with runways 4,000-7,999 ft.
Telecommunications: system of open wire and
radio relay; 8,825 telephones; 54,000 radio receivers; 2
AM, no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 718,000; 359,000
fit for military service; about 30,000 males and 29,000
females reach military age (18) annually; both sexes
liable for military service !
Supply: dependent on France and Guinea
Military budget: for fiscal year ending 31
December 1974, $6,664,300; about 11.4% of total
budget
5l
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','e9d7738c4c031df7bde34d2a155d692d165802f60f140ee63d934ced3441c504','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c173d4a5793f1606ecc09fdc9f901c3ef904896d0229835ed17fa34241145675',1976,'DK','Denmark','communications',132,'(See reference map IV)
LAND
16,600 sq. mi. (exclusive of Greenland and Faeroe
Islands); 64% arable, 8% meadows and pastures, 11%
forested, 17% other
Land boundaries: 42 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing 12 n. mi.)
Coastline: 2,100 mi.
Railroads: 1,810 mi. Danish State Railways (DSB);
1.461 mi. standard gage (48%”), 52 mi. clectrified
and 453 mi. double tracked; remaining 349 mi. of
standard gage lines are privately owned and operated
Highways: 38,295 mi; 31,196 mi. concrete,
bitumen, or stone block; 5,645 mi. gravel and crushed
stone; 1,454 mi. improved earth
Inland waterways: 259 mi.
Pipelines: refined products, 260 mi.
Ports: 16 major, 44 minor
Civil air: 84 major transport aircraft including 9
belonging to Greenland
Airfields: 142 total, 109 usable; 18 with
permanent-surface runways; 8 with runways 8,000-
11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane
station
Telecommunications: excellent telephone, tele-
graph, and broadcast services; 2,220,000 telephones;
1,710,000 radiobroadcast receivers; 1,690,000 TV
receivers; 4 AM, 13 FM, and 30 TV stations; 14
submarine coaxial cables
DEFENSE FORCES
Military manpower: males 15-49, 1,195,000,
1,050,000 fit for military service, 38,000 reach military
age (20) annually
Military budget: proposed for fiscal year ending 31
March 1976, $824 million; about 7% of central
government budget
Approved For Release 2005/04/22
FALKLAND ISLANDS (MALVINAS)!
XU Ue
Atlantic
Ocean
es FALKLAND
sete? ISLANDS
(See reference map 111)
LAND
Colony — 4,700 sq. mi.; area consists of some 200
small islands, chief of which are East Falkland (2,580
sq. mi.) and West Falkland (2,038 sq. mi.);
dependencies — consists of the South Sandwich
Islands, South Georgia, and the Shag and Clerke
Rocks
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 800 mi.
Railroads: none
Highways: 22 mi.; 10 mi. paved, 12 mi. gravel, and
earth: no other made-up roads in the islands beyond
the immediate vicinity of Stanley
Ports: 1 major (Port Stanley), 4 minor
Civil air: no major transport aircraft
Airfields: 1 usable airfield, 1 seaplane station
63
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FALKLAND ISLANDS (MALVINAS)/FIJI
Telecommunications: government-operated open-
wire and radiotelephone networks providing effective
service to almost all points on both islands; approx-
imately 600 telephones; 1 AM station and 1,100 est.
radiobroadcast receivers
UNITED
IREL H^
| KINGDOM
De NE[
*
Atlantic
Ocean
(See reference map IV)
LAND
94,200 sq. mi; 30% arable, 50% meadow and
pasture, 12% waste or urban, 7% forested, 1% inland
water
Land boundaries: 224 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 7,725 mi.','cd0b7a5a47d3e3c3c738270a7e13c38b7de2d75d6d1357b71186e742bc5ed7d7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b2f31a188dbb7f76aa015380b61c14d2b911797b1cad9b763db59b311180be4',1976,'DM','Dominica','communications',136,'DOMINICAN E Atlantic
; PUERTO : Ocean
bo poles
= epi
zu
E
DOMINICA?
Caribbean Sea f E.
(Ses reference map tt}
LAND
805 sq. mi.; 24% arable, 2% pasture, 67% forests,
7% other
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 92 mi.
Railroads: none
Highways: 460 mi.; 230 mi. paved, 160 mi. gravel,
erushed stone, or stabilized earth surface, 70 mi.
unimproved
Ports: 2 minor (Roseau, Portsmouth)
Civil air: no major transport aircraft
Airfields: 1 with asphalt runway 4,830 ft.
Telecommunications: 2,900 telephones in fully
automatic network; VHF link to St Lucia; 15,000
radio receivers; 150 TV receivers; 1 AM station','4ffdf629c641cf2144fb4b038a464602b5475dfd6073e6534ce2a18976832a54','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ee716663efe5679779fe4461115e27e66a2640ed6fbc0e92f8ab70a9a49e565',1976,'DO','Dominican Republic','communications',140,'LAND
18,800 sq. mi; 14% cultivated, 4% fallow, 17%
meadows and pastures, 45% forested, 20% built-on or
waste
Land boundaries: 224 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 800 mi.
Railroads: 1,000 route mi. of which 65 mi.
government-owned common carrier (3''6” gage) and
935 mi. privately owned plantation network (approxi-
mately 4 different gages ranging from 110%" to
4''812", with 2/6" predominating)
Highways: 7,000 mi.; 3,500 mi. paved, 3,500 mi.
gravel and improved carth
Approved For Release 2005/04/22
Pipelines: product lines (1.5 mi. and 43 mi.) under
construction
Ports: 5 major (Santo Domingo, Barahona, Haina,
Las Calderas, San Pedro de Macoris), 17 minor
Civil air: 23 major transport aircraft
Airfields; 50 total, 43 usable; 9 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 9
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: relatively efficient domestic
system based on islandwide radio relay. network;
96,500 telephones; 600,000 radio and 190,000 TV
receivers, 110 AM, 31 FM, and 11 TV stations; 3
submarine cables, including 1 coaxial; planned
COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 1,067,000;
676,000 fit for military service; 52,000 reach military
age (18) annually','37c21e9477ab743deccf387596bb970acf9ddc52494747be4eb3c245e652ed6f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5c08ac44785098334adc87dc309a162a73f4b10422223c0fb9da5f69654f53b',1976,'EC','Ecuador','communications',144,'Galapagos
Islands
Pacific Ocean
(See reference map III)
LAND
106,000 sq. mi. (including Galapagos Islands); 11%
cultivated, 8% meadows and pastures, 55% forested,
26% waste, urban, or other (excludes the Oriente and
the Galapagos Islands, for which information is not
available)
Land boundaries: 1,200 mi.
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,390 mi. (includes Galapagos Is.)
Railroads: 660 mi.; 615 mi. 3''6" gage, 45 mi.
2/54" gage; all single track
Highways: 12,700 mi.; 2,100 mi. paved, 10,600 mi.
otherwise improved
Inland waterways: 960 mi.
Pipelines: crude oil, 390 mi.: refined products, 320
mi.
Ports: 3 major (Cuayaquil, Manta, Puerto Bolivar),
11 minor
Civil air: 29 major transport aircraft
Airfields: 175 total, 175 usable; 17 with
permanent-surface runways; 6 with runways 8,000-
11,999 ft., 21 with runways 4,000-7,999 ft.: 3 seaplane
stations
Telecommunications: facilities adequate only in
largest cities; satellite ground station; 135,000
telephones; 1.7 million radio and 250,000 TV
receivers; 240 AM, 38 FM, and 12 TV stations
€ Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ECUADOR/EGYPT
DEFENSE FORCES
Military manpower: males 15-49, 1,667,000;
1,088,000 fit for military service; average number
reaching military age (20) annually 71,000
^
(Ses reference map Vj
LAND
386,200 sq. mi. (including 22,200 sq. mi. occupied
by Israel); 2.8% cultivated (of which about 70%
multiple cropped); 96.5% desert, waste, or urban;
0.7% inland water
Land boundaries: 1,570 mi. (1967), excludes
occupied area 1,534 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(plus 6 n. mi. "necessary supervision zone )
Coastline: 2,140 mi. (1967), excludes occupied area
1,340 mi.
Railroads: 3,358 mi.; 570 mi. double track; 15 mi.
electrified; 2,976 mi. 448%” gage, 156 mi. 33%"
gage, 226 mi. 2251" gage
Highways: 29,358 mi.; 5,914 mi. paved, 279 mi.
gravel and crushed stone, 6,398 mi. improved carth,
16,767 mi. unimproved earth
57
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
EGYPT/EL SALVADOR
Inland waterways: 2,100 mi.; Suez Canal, 100 mi.
long, temporarily closed to navigation because of
sunken vessels: normally used by ocean-going vessels
drawing up to 38 ft. of water; Alexandria-Cairo
waterway navigable by barges of 500-ton capacity;
Nile and large canals by barges of 420-ton capacity;
Ismailia Canal by barges of 200- to 300-ton capacity;
secondary canals by sailing craft of 10- to 70-ton
capacity
Freight carried: Suez Canal (1966) — 242 million
tons of which 175.6 million tons were POL
Pipelines: crude oil, 185 mi.; refined products, 390
mi.; natural gas, 30 mi.
Ports: 3 major (Alexandria, Port Said, Suez), 8
minor
Civil air: 15 major transport aircraft
Airfields: 98 total, 84 usable: 69 with permanent-
surface runways; 41 with runways 8,000-11,999 ft., 9
with runways over 12,000 feet, 19 with runways 4,000-
7,999 ft.; 2 seaplane stations
Telecommunications: second best system of
coaxial and multiconductor cables, open-wire lines,
and radiocommunication stations in Africa; principal
centers Alexandria and Cairo, secondary centers Al
Mansurah, Ismailia, and Tanta; 471,800 telephones;
5.1 million radio and 610,000 TV receivers; 12 AM, 1
FM, and 22 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 8,545,000;
5,409,000 fit for military service; about 390,000 reach
military age (20) annually','24ac92e94e7398b1702812ee274b645c59854755aa37fc5944261662c6af2d98','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dd28ba2746cc25a2292c828408138081c14bd7e9ec144725f746ea8c360e2bc',1976,'SV','El Salvador','communications',148,'Caribbean
Sea
San Salvador
Pacific Ocean
(See reference map $)
LAND
8,260 sq. mi.; 32% cropland (9% corn, 5% cotton,
7% coffee, 11% other), 26% meadows and pastures,
31% nonagricultural, 11% forested
Land boundaries: 320 mi.
Approved For Release 2005/04/22
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 190 mi.
Railroads: 375 mi., 30” gage; single-tracked; 285
mi. privately owned, 90 mi. government owned
Highways: 6,700 mi.; 800 mi. bituminous, 1,200
mi. gravel or crushed stone, 4,700 mi. earth
Inland waterways: Lempa River partially
navigable
Ports: 3 major (Acajutla, La Union, La Libertad), 1
minor
Civil air: 8 major transport aircraft
Airfields: 146 total, 145 usable; 9 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: nationwide trunk radio relay
system; connection into Central American microwave
net; 48,500 telephones; 600,000 radio and 115,000 TV
receivers; 53 AM, 6 FM, and 5 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 927,000; 569,000
fit for military service; 44,000 reach military age (18)
annually
Military budget: for fiscal year ending 31
December 1975, $17.7 million, 6.5% of central
government budget','fc43564fcfc230348e57d57003145dc54be12fa6b8ebe8a1b290a8bde4a47b46','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('656e792dc31af159944503191d0224d37adca8b8db6e8a29d4cc7787f3b48e2a',1976,'GQ','Equatorial Guinea','communications',152,'Atlantic
‘Ocean.
(See reference map VI]
LAND
10,800 sq. mi; Rio Muni, about 10,000 sq. mi.,
largely forested; Fernando Po, about 800 sq. mi.
Land boundaries: 335 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 184 mi.
Railroads: none
Highways: Rio Muni — 1,553 mi., including
approx. 115 mi. bituminous, remainder gravel and
carth; Fernando Po — 186 mi. including 91 mi.
bituminous, remainder gravel and earth
Inland waterways: Rio Muni has approximately
104 mi. of year-round navigable waterway, used
inostly by pirogues
Ports: 2 major (Macias Nguema Biyogo, Rey
Malabo), 3 minor
Civil air: no major transport aircraft
Airfields: 5 total, 3 usable: 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 1
with runway 4,000-7,999 ft.
Telecommunications: fairly adequate for the size
and stage of development of the country; interna-
tional communications by radio from Bata and
Malabo to Cameroon, Nigeria, and Spain; 1,500
telephones; 96,500 radio and 500 TV receivers; 2 AM,
no FM, and 1 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 74,000; 37,000
fit for military service
Major equipment: 10 Soviet amphibious personnel
carriers (3 small and 7 large); 4 P-6 motor gunboats, 1
unidentified patrol craft; 1 Alouette III helicopter
Military budget: for fiscal year ending 81
December 1970, $3,475,700: 14.3% of total budget','2cba33321863effe8afd480990d2169998c924dcb6673e559f3df3b6fbce9513','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25b58058565f98c434f18012f7bc0565f8252e653d05602f3c943368fef27088',1976,'ET','Ethiopia','communications',156,'LAND
455,000 sq. mi.; 10% cropland and orchards, 55%
meadows and natural pastures, 6% forests and
woodlands, 29% wasteland, built-on areas, and other
Land boundaries: 3,230 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.;
sedentary fisheries extends to limit of fisheries
Coastline: 680 mi. (includes offshore islands)
= Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
A
January 1976
Approved
p For Release 2005/04/22 : CIA-RDP79-01051A00080001
0001-8
(See referansa map LUI
Railroads: 630 mi.; 420 mi. 3894" gage, 20 mi. 3''6”
gage, 190 mi. 3''134" gage; all single track
Highways: 14,500 mi.; 1,675 mi. bituminous, 3,100
mi. crushed stone, gravel, or stabilized earth,
remainder earth
Inland waterways: navigation possible on Lake
Tana and on approx. 140 mi. of unconnected and
basically unimproved waterways, of which only 71
mi. are navigable year round
61
0800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00
January 1976
ETHIOPIA/FAEROE ISLANDS
Ports: 2 major (Assab, Mussawa), 1 minor
Civil air; 17 major transport aircraft
Airfields: 169 total, 150 usable; 7 with permanent-
surface runways; ! with runway over 12,000 ft., 6 with
runways 8,000-11,999 ft, 46 with runways 4,000-
7,999 ft.
Telecommunications; system better. than most
African countries; composed of open-wire lines,
radiocommunication stations, and small number of
multiconductor cable and radio-relay links; principal
center Addis Ababa, Secondary center Asmara; 60,800
telephones; 500,000 radio receivers; 20,000 Tv
receivers; 4 AM. no FM, and | Ty stations
DEFENSE FORCES
Military manpower; males 15-49, 7,028,000;
3,745,000 fit for military service; average number
reaching military age (18) annually 278,000
Military budget: for fiscal year ending 7 August
1976, $83,653,846; 13.1% of total budget
FAEROE ISLANDS
Norwegian
Sea
FAEROE *
ISLANDS
Atlantic
Ücean
(See referen, mag IV)
LAND
540 sq. mi.; less than 5% arable, of which only a
fraction cultivated; archipelago consisting of 18
inhabited islands and a few uninhabited islets
WATER
Limits of territorial waters (claimed); 3 n. mi.;
fishing, 12 n. mi. (from extended base lines)
Coastline; 475 mi.
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less
than 4,000 ft.
Civil air; no major transport aircraft
Telecommunications: good international com-
munications; fair domestic facilities; 13,010 tele-
phones, 12,000 radio receivers; 1 AM, and 3 FM
stations 3 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49 included with
Q 500 Miles
Addis Ababa* 0 500 Kilometers
NAMES AND BOUNDARY REPRESENTATION L indian Ocean
ARE NOT NEGESSARILY AUTHORITATIVE ES
502851 1-76
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
IV Europe
400 Miles
400 Kilometors
2 Jan Mayen
(Nor.
Murmansk
MD rdc Norwegian
ayy
y Reykjavík
£7 Iceland
N
WT.
Arkangel''sk
Faeroe Is.
¥ (Den)
North $
Leningrad
Moscow
¿Edinburgh North
o
El
Atlantic de opghhagen
eVitoyus U.S.S.R.
¿Minsk
¿3cedñ
gom d
Hepablit ^
ux
$ or Germany
© Municha
Romania: ^
| France
Lyone
" Bordeaux
Bucharest,
pA
Istan d Ankara,
> e
Marsen”
| seille e ; j
Bs sat) : l A
std ai Barcelona j E
a
«5 Sardinia Ñ
2 Balearic is. a
a
«Malta
Mediterranean Sea
Turkey
tisnon
/
502850 1-76
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-010514DD08@08H-America
i > A GNE EET
Jamaic 5-5 Haiti V Dom. puerto © Ca
Rep. Rico ee
: (U.S) 3
Honduras 5
ps ? E
Caribbean Sea £ Barbados
^i : cia E North
Nicaragua D Å Sau: n ¿Grenada
* $t 2 Li
B il toc Trinidad and Tobago Atlantic
Canal Zone 7 fe CR ;
(U.S, admin.)
Ocean
Venezuela arated
Medellin y paramaribo
h 2
¡Bogotá ` Surina','89970ea6a1a0fccdc7204f75f53c4e2bc744ce9f7b4527bbdd6a317080190fd6','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ee79c30750f8509f1ac10a0a2303243921291aaaddb7e4ceec1e0aa32334e5d',1976,'FJ','Fiji','communications',160,'Pacific Qcean
Coral Sea $ BE ey
FE.
ISLANDS :
(See reference map VIIJ
LAND
7,055 sq. mi; landownership — 83.69; Fijians,
1.7% Indians, 6.4% government, 7.2% European,
1.1% other; about 30% of land area is suitable for
farming
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 700 mi. (est.)
Railroads: none
Highways: 1,757 mi. (1974); 173 mi. paved, 1,584
mi. gravel or crushed stone
Inland waterways: 126 mi.; 76 mi. navigable by
motorized craft and 200-ton barges
Ports: 1 major, 6 minor
Civil air: 5 major transport aircraft
Airfields: 15 total, 15 usable; 2 with permanent
surface runways, 1 with runway 8,000-11,999 ft.,
! with runway 4,000-7,999 ft., 2 seaplane stations
Telecommunications: modern local, interisland,
and international (wire/radio integrated) public and
l Fijian dol-
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FIJ1/FINLAND
special-purpose telephone, telegraph, and teleprinter
facilities; regional radio center, important COMPAC
cable link between U.S./Canada and New Zealand/
Australia, et al; 22,528 telephones; 251,000 radio
receivers; 6 AM, 2 FM, and no TV stations; 1 ground
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 146,000; 81,000
fit for military service; 6,000 reach military age (18)
annually
Military budget: the defense of the Fiji Islands was
the responsibility of the U.K. until 10 October 1970;
military budget for 1971, $314,000','25e7971da587144c67837eb4e92c7b62478946092e559495af2a8b53593c041a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eca1ebaf8d78c3e34bdc9d746c2ec93549bc113f0bfa3d08921060c45e238fd1',1976,'FI','Finland','communications',164,'‘Norwegian.
ey ee
(See reference mep (V)
LAND
130,000 sq. mi.; 8% arable, 58% forested, 34% other
Land boundaries: 1,575 mi.
WATER
Limits of territorial waters (claimed): 4 n. mi.;
Aland Islands, 3 n. mi.
Coastline: 700 mi. (approx.) excludes islands and
coastal indentations
Railroads: 3,695 mi.; Finnish State Railways (VR)
operate a total 3,677 mi. broad gage (5''0”), 296 mi.
multiple track, and 245 mi. electrified; 14 mi. narrow
gage (2''5/9") and 4 mi. broad gage are privately
owned
Highways: about 45,000 mi. in national classified
network, including 18,000 mi. paved (bituminous,
concrete, bituminous surface treated) and 27,000 mi.
unpaved (stabilized gravel, gravel, earth); additional
17,700 mi. of private (state subsidized) roads
Inland waterways: 4,100 mi. total (including
Saimaa Canal) 2,300 mi. suitable for steamers;
Saimaa Canal locks (278 ft. by 43.3 ft. with a 17.0 ft.
depth over sill) can accommodate vessels of up to 269
ft. in length, 38.6 ft. beam, 14.3 ft. draft, and 80.4 ft.
mast height
Pipelines: natural gas, 100 mi.
66
Ports: 11 major, 14 minor
Civil air: 34 major transport aircraft
Airfields: 106 total, 104 usable; 36 with
permanent-surface runways; 17 with runways 8,000-
11,999 ft., 24 with runways 4,000-7,999 ft.
Telecommunications: facilities provide essential
services for government, publie, and industry;
1,720,000 telephones; 2,100,000 radiobroadcast
receivers; 1,440,000 TV receivers; 13 AM, 40 FM, and
65 TV stations; 4 submarine cables, including 1
coaxial
DEFENSE FORCES
Military manpower: males 15-49, 1,205,000;
975,000 fit for military service; 39,000 reach military
age (17) annually','057cc18366c02f962813b7c6101be1a9afa7a2383a3e53e36509756a1178adda','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c1290c83d9ba1ef6b60594e48ae459ce43399e09d22a5dd29e2334d107dfb67',1976,'FR','France','communications',168,'7 Werth Son
VITED.
EDOM
n
Atlantic
“Ocean ES Paris e
FRANCE s
j z EN acu
. ¥
3 Mediterranean Sea dec
y puse map IV}
LAND
213,000 sq. mi.; 35% cultivated, 26% meadows and
pastures, 1496 waste, urban, or other, 2595 forested
Land boundaries: 1,795 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,130 mi. (includes Corsica, 400 mi.)
Railroads: 22,930 mi.; 22,200 mi. standard gage,
730 mi. other gages (3''3%" to 4''9”); 5.810 mi.
electrified, 9,770 mi. double or multiple track
Highways; National, Departmental, and Commu-
nal roads total 497,200 mi. comprising 292,600 mi.
paved, 190,000 mi. crushed stone and gravel, and
14,600 mi. improved earth; in addition, there are
approximately 434,000 mi. of local farm and forest
roads
Inland waterways: 9,320 mi.; 4,670 mi. heavily
traveled
Pipelines: crude oil, 1,400 mi.; refined products,
2,700 mi.; natural gas, 9,300 mi.
Ports: 23 major, 165 minor
Civil air: 306 major transport aircraft (including 13
foreign based but French registered)
Airfields: 464 total, 432 usable; 208 with
permanent-surface runways; 2 with runways over
12,000 ft., 25 with runways 8,000-11,999 ft., 119 with
runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications; highly developed system
Provides satisfactory telephone, telegraph, and radio
and TV broadcast services; 12.7 million telephones;
18.3 million radiobroadcast receivers; 14.3 million TV
receivers; 40 AM, 84 FM, and 1,400 TV stations; 19
submarine cables (18 coaxial); 4 communication
satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 12,843,000; fit
for military service 10,340,000; 424,000 reach military
age (18) annually
Military budget: for fiscal year ending 31
December 1975, $9.7 billion; about 17% of central
government budget
Military budget: for fiscal year ending 31
December 1975, $9,693,453; 6.4% of total budget','a47292346de8e0a436341a13e7c1868b74608d353c831714470f8cb50d82c0e8','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40136bfb8c48b62ebe44510428ef775f4778ed47530d8c0902a7d0f3055b6eae',1976,'GF','French Guiana','communications',172,'LAND
35,100 sq. mi.; 90% forested, 109; wasteland, built-
on, inland water and other, of which .05% is
cultivated and pasture
Land boundaries: 735 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline; 235 mi.
Railroads: 20 mi. private plantation line, 1''1155"
gage; 8 mi. abandoned narrow-gage line
Highways: 300 mi.; 250 mi. paved, 50 mi.
improved and unimproved earth
Inland waterways: 290 mi., navigable by small
oceangoing vessels and river and coastal steamers;
2,110 mi. possibly navigable by native craft
Ports: | major (Cayenne), 7 minor
Civil air: no major transport aircraft
Airfields: 13 total, 10 usable; 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft.
Telecommunications: limited open-wire telecom
system with about 6,950 telephones; 7,100 radio
receivers and 3,100 TV receivers, 2 AM, 2 FM and 2
TV stations; satellite communications station
DEFENSE FORCES
Military manpower: males 15-49, 13,000; 9,000 fit
for military service','76fdca97edb694544e502352d69dd58733730e4ebec0d58d6229c0f8411a3c6d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('981388e2c127e563f221fc6df948c33d6bb469dd1010ac202f513d06bdc355e5',1976,'PF','French Polynesia','communications',176,'LAND
About 1,544 sq. mi.
WATER
Limits of territorial waters: 12 n. mi.
Approved For Release 2005/04/22
(See reference map VII)
Coastline: about 975 mi.
Highways: 2,300 mi., all types
Ports: 1 major (Papeete), 6 minor
Airfields: 19 total, 19 usable: 10 with permanent
surface runways, 2 with runways 8,000-11,999 ft., 9
with runways 4,000-7,999 ft.; 2 seaplane stations
Civil air: no major transport
Telecommunications: 10,856 telephones; 70,000
radio and 13,000 TV sets; 1 AM, no FM, and 4 TV
stations
FRENCH TERRITORY OF THE
AFARS AND ISSAS
RENCH TERRITORY OF THE
AFARS AND ISSA
(Sea reference map Vi)
LAND
9,000 sq. mi.; 8996 desert wasteland, 109
permanent pasture, and less than 1% cultivated
Land boundaries: 321 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 195 mi. (includes offshore islands)
Railroads: 60 mi. meter gage
Highways: 1,180 mi.; 62 mi. paved, 1,118 mi.
improved earth
Ports: 1 major (Djibouti)
Airfields: 7 total, 7 usable; 1 with permanent-
surface runway; 1 with runway 8,000-11,999 ft., 4
with runways 4,000-7,999 ft.
Civil air: 6 major transport aircraft (registered in
France)
Telecommunications: fair system of urban
facilities in Djibouti and radiocommunication stations
at outlying places; 2,900 telephones; 12,000 radio
receivers; 3,000 TV receivers; 1 AM, no FM, and 1 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, about 30,000;
about 17,000 fit for military service
Defense is responsibility of France
Railroads: none
Highways: 3,206 mi.; 228 mi. paved; 808 mi.
gravel, crushed stone, or stabilized surface; 495 mi.
improved earth; 1,675 mi. earth
Inland waterways: none
Ports: 1 major (Noumea), 21 minor
Civil air: no major transport aircraft
Airfields: 31 total, 31 usable; 2 with permanent-
surface runways; 2 with runways 4,000-7,999 ft.; 1
airfield over 8,000 ft.; 1 seaplane station
Telecommunications: 14,364 telephones; 30,500
radio and 13,000 TV sets; 1 AM, no FM, and 3 TV
stations; 1 earth satellite station
NEW HEBRIDES
Pacific
Su to v Ocean
. BRITISH
Ab V SOLOMONS
ic :
"Ww.
HEBRIDES’.
*
a
NEON
CALEDONIA
(See reference map Viti}
LAND
About 5,700 sq. mi.
WATER
Limits of territorial waters: 3 n. mi.
Coastline: about 1,570 mi.
Railroads: none
Highways: at least 150 mi. sealed or all-weather
roads
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Telecommunications: 1 AM broadcast station;
10,000 radio receivers, and 800 telephones
DEFENSE FORCES
Personnel: no military forces maintained, however,
the French and British maintain constabularies of
about 70 men each','f6d21aa80b8bd585e75c22375d9c69beea7dfc3bbf83ed49d336ffe4c25210c4','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a53167c4c8f8dc2016c776c471c29603655fe136a231b2d8084ce774b535cc44',1976,'GA','Gabon','communications',180,'Atlantic
Océan...
(See reference map Vij
LAND
102,000 sq. mi.; 75% forested, 15% savanna, 9%
urban and wasteland, less than 1% cultivated
Land boundaries: 1,505 mi.
WATER
Limits of territorial waters (claimed): 100 n. mi.
Coastline: 550 mi.
Railroads: none
Highways: 4,000 mi.; 140 mi. paved, 3,268 mi.
gravel and/or improved earth, remainder unimproved
earth
Inland waterways: approximately 1,000 mi.
perennially navigable
Pipelines: crude oil, 40 mi.
Ports: 3 major (Libreville, Port-Gentil, Owendo), 2
minor
Civil air: 24 major transport aircraft
Airfields: 166 total, 103 usable; 5 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 20
with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: system of open-wire, radio-
relay, tropospheric scatter links and radiocommunica-
tion stations; satellite ground station; 4 AM and 2 TV
stations; 7,000 telephones; 90,000 radio receivers;
5,200 TV receivers
DEFENSE FORCES
Military manpower: males 15-49, 126,000; 65,000
fit for military service; 5,000 reach military age (20)
annually
Military budget: for fiscal year ending 31
December 1975, $17,850,079; 2.4% of total budget','a07132f5dfd09dbb495bed750918f55dab3ffe76bdee3472cfb084566bcff666','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afae75013a126daada8536cd675deab948aa3188aabd615ee310931b41f50047',1976,'GM','Gambia','communications',184,'LAND
4,000 sq. mi; 25% uncultivated savanna, 16%
swamps, 4% forest parks, 55% upland cultivable
areas, built-up areas, etc.
Land boundaries: 460 mi.
72
Approved For Release 2005/04/22
(See reference map VI)
WATER
Limits of territorial waters (claimed): 50 n. mi.
Coastline: 50 mi.
Railroads: none
Highways: 775 mi; 185 mi. bituminous surface
treated, 320 mi. gravel/laterite, 270 mi. unimproved
earth
Inland waterways: 377 mi.
Ports: 1 major (Banjul)
Civil air: no major transport aircraft
Airfields: 1 usable with permanent-surface runway
4,000-7,999 ft.; 1 seaplane station (non-operational)
Telecommunications: adequate network of radio-
relay; 1,900 telephones; 60,000 radio receivers; 1 AM,
1 FM and no TV stations; 1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 120,000; 61,000
fit for military service
GERMANY, EAST
LAND
41,800 sq. mi.; 43% arable, 15% meadows and
pasture, 27% forested, 15% other
Approved For Release 2005/04/22
North Sea
icon
(See reference map IV}
Land boundaries: 1,435 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 560 mi. (including islands)
Railroads: 8,895 route mi.; 8,673 mi. standard
gage, 222 mi. meter or other narrow gage, 1,400 mi.
double track standard gage; 860 mi. overhead
electrified (1973)
Highways: about 28,359 mi. classified highways;
7,696 mi. state highways including 928 mi. autobahn;
20,663 mi. district roads; additionally about 34,465
mi. unclassified minor unpaved roads (1973)
Inland waterways: 1,562 mi. (1975)
Freight carried: rail — 325.6 million short tons,
32.2 billion short ton/mi. (1973), highway — 600.6
million short tons, 10.3 billion short ton/mi. (1973),
waterway—13.4 million short tons, 1.3 billion short
ton/mi. (excl. intl. transit traffic) (1974)
Pipelines: crude oil, 500 mi; refined products, 150
mi.; natural gas 300 mi.
Ports: 4 major (Rostock, Wismar, Stralsund,
Sassnitz), 13 minor (1975)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 31 December 1975, 9.6 billion DME; about
9% of total budget
GERMANY, WEST
LAND
96,000 sq. mi. (including West Berlin); 33%
cultivated, 23% meadows and pastures, 13% waste or
urban, 29% forested, 2% inland water
Land boundaries: 2,630 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 925 mi. (approx.)
Railroads: 21,360 mi; 18,597 mi. government
owned, standard gage (4’8%"), 7,807 mi. double
track; 6,100 mi. electrified; 2,763 mi. non-government
owned; 2,498 mi. standard gage; 134 mi. electrified:
265 mi. narrow gage (3855); 116 mi. electrified
Highways: 249,200 mi.; 100,875 mi. classified,
includes 95,725 mi. cement-concrete, bituminous, or
stone block (includes 3,295 mi. of autobahnen); 5,150
mi. gravel, crushed stone, improved earth; in
addition, 148,325 mi. of unclassified roads of various
surface types
Inland waterways: 8,100 mi. of which almost 709;
usable by craft of 1,100-short-ton capacity or larger
Pipelines: crude oil, 1,200 mi.; refined products,
1,000 mi.; natural gas, 59,300 mi.
Ports: 10 major, 11 minor
Civil air: 167 major transport aircraft
Airfields: 438 total, 878 usable; 194 with
permanent-surface runways; 3 with runways over
12,000 ft., 35 with runways 8,000-11,999 ft., 36 with
runways 4,000-7,999 ft.
Telecommunications: highly developed, modern
telecommunication service to all parts of the country;
fully adequate in all respects; 19.3 million telephones;
21.3 million radio and 19.8 million TV receivers: 92
AM, 127 FM, and 1,960 TV stations; 5 submarine
cables; 4 communication satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 14,749,000;
12,357,000 fit for military service; 450,000 reach
military age (18) annually','56e00c5b1e6471b1619b248adef44ddc90d4de4ad33c16aec6c7b32d13838400','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c74acdba32f5f51a57da991029a576c2786d491f7da67652206e1c2d1d816e5b',1976,'GH','Ghana','communications',188,'LAND
92,000 sq. mi.; 19% agricultural, 60% forest and
brush, 2195 other
Land boundaries: 1,420 mi.
WATER
Limits of territorial waters (claimed): 30 n. mi.
{undefined protective areas may be proclaimed
76
(See reference map Vi}
seaward of territorial sea, and up to 100 n. mi.
seaward may be proclaimed fishing conservation
zone)
Coastline: 335 mi.
Railroads: 592 mi. — all 3''6 gage; 20 mi. double
track; diesel locomotives gradually replacing steam
engines
Highways: 21,450 mi, 3,000 mi. concrete or
bituminous surface, 5,250 mi. gravel or laterite, 3,600
mi. improved earth, 9,300 mi. unimproved earth
Inland waterways: Volta, Ankobra, and Tano
rivers provide 145 mi. of perennial navigation for
launches and lighters; additional routes navigable
seasonally by small craft; Lake Volta reservoir
provides 700 mi. of arterial and feeder waterways
Pipelines: refined products, 2 mi.
Ports: 2 major (Tema, Takoradi) 1 naval base
(Sekondi), 4 minor
Civil air: 8 major transport aircraft
Airfields: 19 total, 18 usable; 4 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 9
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: good system of open-wire
and cable, radio-relay links and radiocommunication
stations; 52,000 telephones; 1,058,000 radio and
95,500 TV receivers; 3 AM, no FM, and 5 TV stations;
2, submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 2,248,000;
1,247,000 fit for military service; 114,000 reach
military age (18) annually
Military budget: for fiscal year ending 30 June
1975, $83,336,500; 9.4% of total budget','872f059d53c3b574eeae52c8638eae322222bf8e1908d738916634c15d4cb8e3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('308c4e559b3e20e4a487d25aaf039e139ee7083a73131ef1faa159d3c329f7e3',1976,'GI','Gibraltar','communications',192,'‘Atlantic Ocean
(See reference map mv
LAND
2.5 sq. mi.
Land boundaries: 1 mi
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 7.5 mi.','484487acea9ebd3203aa5531273b65a2eebe75c645236aae042e6f9a5bdf07da','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39821ecc7ac2ee68a2d4edcdbe9657d768afbf9d149f4a12529730f0bdd14ca7',1976,'NL','Netherlands','communications',197,'Railroads: none
Highways: 35 miles, mostly paved
Ports: 1 major (Gibraltar)
Civil air: 1 major transport aircraft
Airfields: 1 permanent-surface runway, 4,000-
7,999 ft.; 1 seaplane station
Telecommunications: international radiocom-
munication facilities; automatic telephone system
serving 7,000 telephones; 7,200 radio: receivers; 6,950
TV receivers, 1 AM, 1 FM, and 2 TV stations; 13
submarine telegraph cables
DEFENSE FORCES
Military manpower: males 15-49, about 6,000;
about 3,000 fit for military service
Defense is responsibility of United Kingdom
GILBERT AND ELLICE ISLANDS
E e UNES,
* Pacific Ocean dus
AT GILBERT An P
. ELLICE ISLANDS
ie s
(See reference mep Vill)
NOTE: The Ellice Islands were separated from the
Gilbert and Ellice Island; Colony (GEIC) on 1
October 1975 to form a new colony, Tuvalu, with its
capital at Funafuti. The new colony has an 8-member
House of Assembly, The Chief Minister is Toalipi
Lauti.
The remainder of the GEIC has been renamed the
Gilbert Islands.
LAND
About 376 sq. mi.
10001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008000
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GILBERT AND ELLICE ISLANDS/ GREECE
WATER
Limits of territorial waters: 3 n. mi.
Coastline; about 725 mi.
Railroads: none
Highways: 300 mi. of motorable roads
Inland waterways: small network of canals,
totaling 8 miles, in Northern Line Islands
Ports: 1 minor
Civil air: no major transport aircraft
Telecommunications: 1 AM broadcast station;
8,100 radio receivers, no TV sets, and 435 telephones;
connected with Lisbon, Portugal, via cable broadcasts
Approved For Release 2005/04/22
LAND
19,100 sq. mi.; 70% cultivated, 5% waste, 876
forested, 8% inland water, 9% other
Land boundaries: 635 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 280 mi.
Railroads: 1,862 mi., standard gage; 1,758
government-owned (NS), 1,023 mi. electrified, 970
mi. double track; 104 mi. privately-owned
Highways: approximately 63,100 mi. including 900
mi. of limited access, divided “Motorways”; about
51,400 mi. paved (bituminous, concrete, stone block)
and 1,700 mi. unpaved (gravel, crushed stone,
stabilized earth)
Inland waterways: 3,940 mi., of which 35% is
usable by craft of 1,000 short-ton capacity or larger
Pipelines: crude oil, 260 mi.; refined products, 600
mi.; natural gas, 2,790 mi.
Ports: 8 major, 5 minor
Civil air: 110 major transport aircraft (including 8
aircraft registered in the Netherlands but leased from
a foreign country)
Airfields: 28 total, 27 usable; 16 with permanent-
surface runways; 13 with runways 8,000-11,999 ft., 3
with runways 4,000-7,999 ft.
Telecommunications: highly developed, ex-
cellently maintained, and well integrated; extensive
system of multiconductor cables, supplemented by
radio-relay links; 4.86 million telephones; 9 million
radiobroadcast and 3.65 million TV receivers; 5 AM,
12 FM, and 11 TV stations; 12 coaxial submarine
cables; communications satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 3,393,000;
3,046,000 fit for military service; average number
reaching military age (20) annually 117,000
Military budget: proposed for fiscal year ending 31
December 1975, $2,735 million; about 12% of central
government budget
NETHERLANDS ANTILLES
LAND
394 sq. mi.; 5% arable, 95% waste, urban, or other
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 226 mi.
Railroads: none
Highways: 700 mi; 350 mi. paved, 220 mi.
otherwise improved, 130 mi. unimproved
Ports: 3 major (Willemstad, Oranjestad, Caracor
Baai), 6 minor
Civil air: 6 major transport aircraft
Airfields: 7 total, all usable; 7 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 2
with runways 4,000-7,999 ft.; 1 seaplane station
147
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NETHERLANDS ANTILLES/NEW CALEDONIA
Telecommunications: generally adequate telecom
facilities; extensive interisland VHF links; 40,000
telephones, 132,000 radio and 35,000 TV receivers, 11
AM and 3 TV stations, 5 submarine cables, including
l coaxial
DEFENSE FORCES
Military manpower: males 15-49, 60,000; 34,000
fit for military service; about 2,000 reach military age
(20) annually
Defense is responsibility of the Netherlands','7c0c2fafd91ae2688fad3d2d896dd973b76241ba63291bffca5ad889e7f2fa2d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6209ef1b3231cbefcd81889f233b2f7dbd341b9e355bd8107516c854bc8669e1',1976,'GR','Greece','communications',200,'(See reference map IV}
LAND
51,200 sq. mi; 29% arable and land under
permanent crops, 409; meadows and pastures, 2096
forested, 1196 wasteland, urban, other
Land boundaries: 740 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
Coastline: 8,500 mi.
Railroads: 1,598 mi.; 969 mi. standard gage
(48 4"), 597 mi. meter gage (8894), 20 mi. 111%"
narrow gage, 10 mi. 25%” narrow gage; all
Eovernment owned
Highways: 24,200 mi.; 10,000 mi. paved, 8,500 mi.
crushed stone and gravel 3,500 mi. improved earth,
2,200 mi. unimproved earth
Inland waterways: system consists of 3 coastal
canals and 8 unconnected rivers which provide
navigable length of just less than 50 mi.
Pipelines: crude oil, 16 mi., refined products, 340
mi.
Ports: 17 major, 37 minor
Airfields: 68 total, 61 usable; 40 with permanent-
surface runways; 17 with runways 8,000-11,999 ft., 21
with runways 4,000-7,999 ft.
Civil air: 35 major transport aircraft (including 3
withdrawn from service)
Telecommunications: adequate modern networks
reach all areas on mainland and islands; 1.95 million
telephones; 3.0 million radio receivers; 1.1 million TV
receivers; 32 AM, 18 FM and 37 TV stations; 3 coaxial
submarine cables; 2 communications satellite ground
stations
DEFENSE FORCES
Military manpower: males 15-49, 2,256,000;
1,728,000 fit for military service; about 75,000 reach
military age (21) annually
Military budget: est. for fiscal year ending 31
December 1974, $691 million; about 24% of central
government budget
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GREENLAND/GRENADA','8e9be7a7a9cfd7cf546e39173e93b2e6338bb72f861a5d94f6b95955b36e2991','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c705c479c61501329280464d6eb41e730e40f2456c09f931ddff2c8912a79a1',1976,'GL','Greenland','communications',204,'(Ses reference map t}
LAND
840,000 sq. mi.; less than 1% arable (of which only
a fraction cultivated), 84% permanent ice and snow,
15% other
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 27,400 mi. (approx. includes minor
islands)
Railroads: none
Highways: none
Ports: 9 major, 23 minor
Civil air: 9 major transport aircraft (registered in
Denmark)
Airfields: 11 total, 7 usable; 3 with permanent-
surface runways; 3 with runways 8,000-11,999 ft, 3
with runways 4,000-7,999 ft.; 7 seaplane stations
Telecommunications: adequate domestic and
international service provided by cables and radio;
1,660 telephones; 7,800 radiobroadcast receivers; 5
AM, 2 FM, and 2 TV stations; 2 coaxial submarine
cables
DEFENSE FORCES
Military manpower: males 15-49, included with','614575ab12148a89a85f81eeb24edb1d066c22114600858e84a1df1d4d0db2c4','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b1823f14dcd9fbbda04f081c8029ab9f164872fdd7525da908a03319742a30e',1976,'GD','Grenada','communications',208,'LAND
133 sq. mi. (Grenada and southern Grenadines);
44% cultivated, 4% pastures, 12% forests, 17% unused
but potentially productive, 23% built on, wasteland,
other
81
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GRENADA/GUADELOUPE
Atlantic
PUERTO
Al Ocean
SED RICO
Caribbean
m
¿GRENADA
LÀ
(Sae reference map il}
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 75 mi.
Railroads: none
Highways: 600 mi.; 380 mi. paved, 100 mi.
otherwise improved; 120 mi. unimproved
Ports: | major (St. Georges), 1 minor
Civil air: no major transport aircraft
Airfields: 4 total, 3 usable; 1 with asphalt runway
5,000 ft.
Telecommunications: automatic, islandwide
telephone system with 4,950 telephones; VHF links to
Trinidad and Carriacou; 21,000 radios and 150 TV
receivers; 3 AM stations
1974); food,
“Trinidad
ers of Spaing! and Tob
= p oba','c548c2cdc08620332ef93ce01b738025acda34f61d29926678d855045f3fc6e6','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('124d77554973943bce5c7b49ec8a684fe7f2c7a86d48cc847c48703b545833e6',1976,'GP','Guadeloupe','communications',212,'m en PUERTO
emp RO
E
GUADELOUPE (>
Caribbean Sea
(See reference map HH)
LAND
687 sq. mi; 24% cropland, 9% pasture, 4%
potential cropland, 16% forest, 47% wasteland, built
on; area consists of two islands
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GUADELOUPE/GUATEMALA
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 190 mi.','55b4ad9a587e55287bce0b8c2dcea936101a83b98a10c96ed936c9b9b6a9d6dd','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1c427aff35d71a6992c89e1819a8eec661586cb7ff81f4ecc022008b8dcb022',1976,'MQ','Martinique','communications',217,'Railroads: privately owned, narrow-gage planta-
tion lines
Highways: 1,260 mi.; 930 mi. paved, 330 mi.
gravcl and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 2 major transport
Airfields: 8 total, 8 usable, 7 with permanent-
surface runways; 1 with runway 8,000-11,999 ft.; 2
seaplane stations
Telecommunications: domestic facilities inade-
quate; 21,700 telephones; inter-island VHF radio
links; 2 AM and 3 TV transmitters; about 30,000 radio
and 13,200 TV receivers
DEFENSE FORCES
Military manpower: males 15-49, included with
Atlantic Ocean |
Caribbean Sea EN EUET
AST C CO MARTINIBUES ©
(See reference map IT)
LAND
425 sq. mi.; 31% cropland, 16% pasture, 29% forest,
24% wasteland, built on
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 180 mi.
Railroads: none
Highways: 900 mi.; 600 mi. paved, 300 mi. gravel
and earth
Ports: 1 major (Fort-de-France), 5 minor
Civil air: no major transport
Airfields: 3 usable; 1 with permanent-surface
runway; 1 with runway 8,000-11,999 ft.; 1 seaplane
station
Telecommunications: domestic facilities inade-
quate; 29,300 telephones, inter-island VHF radio
links; satellite earth station; 1 AM, 1 FM, and 5 TV
stations; about 40,000 radio and 17,000 TV receivers
DEFENSE FORCES
Military manpower: males 15-49, included in','880258291568c10d240818222a220b6b6998ac66555f628bd01ef3856a751911','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0669b4cfcd1ebc4e166957ccb5d0fd62900fb7abfecec9ccaf24903feefae6ff',1976,'GT','Guatemala','communications',218,'LAND
42,040 sq. mi.; 14% cultivated, 10% pasture, 57%
forest, 1996 other
Land boundaries: 1,010 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 250 mi.
83
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Caribbean
(Ses reference mag if}
Railroads: 592 mi., 30 gage; single-tracked; 520 mi.
government owned, 72 mi. privately owned
Highways: 7,700 mi., 1,600 mi. bituminous, 3,950
mi. gravel, 2,150 mi. improved or unimproved earth
Inland waterways: 164 mi. navigable year-round;
additional 458 mi. navigable during high-water
season
Pipelines: crude oil, 30 mi.
Freight carried: rail (1960) — 191.8 million
ton/miles, 1.1 million tons
Ports: 2 major (Puerto Barrios, Santo Tomas de
Castilla), 3 minor
Airfields; 341 total, 337 usable; 7 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 17
with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 12 major transport aircraft
Telecommunications: modern telecom facilities
limited to Guatemala City; 57,400 telephones;
360,000 radio and 108,000 TV receivers, 97 AM, 20
FM, and 5 TV stations; connection into Central
American microwave net
DEFENSE FORCES
Military manpower: males 15-49, 1,427,000;
879,000 fit for military service; about 65,000 reach
military age (18) annually
Military budget: proposed for fiscal year ending 31
December 1975, $26.4 million; 6.6% of central
government budget','6c6418c458d3f679e8e8c302093a5bc85336b8054408e1219eee0b79a4cd3f20','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4158bf0226ac11899bb25348bcc5c4b855aa41aee73e9c2316e398966bec9fa9',1976,'GW','Guinea-Bissau','communications',222,'(formerly Portuguese Guinea)
LAND
14,000 sq. mi. (includes Bijagos archipelago)
Land boundaries: 460 mi.
86
Atlantic Ocean.
i bu ia map B
WATER
Limits of territorial waters (claimed): 150 n. mi.
Coastline: 170 mi.
Railroads: none
Highways: approx. 2,000 mi. (260 mi. bituminous,
remainder earth)
Inland waterways: 994 mi.
Ports: 1 major (Bissau), 2 minor
Civil air: no major transport aircraft
Airfields: 60 total, 60 usable; 5 with permanent-
surface runways; 10 with runways 4,000-7,999 ft.; 1
seaplane station
Telecommunications: limited system of open-wire
lines and radiocommunication stations; 2,700
telephones; 9,000 radio receivers; 1 AM, no FM or TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 115,000; 64,000
fit for military service','5432f30dbcf052adbabd2b4db27590dc0d7306488279b0aae828f0e911871ce5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f6b2e0ac974a960a0a1f6b5aa6bd1549f53674ba02bc02bf54c0049f931198b',1976,'GY','Guyana','communications',226,'LAND
83,000 sq. mi; 1% cropland, 3% pasture, 8%
savanna, 66% forested, 22% water, urban, and waste
Land boundaries: 1,600 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 285 mi.
Approved For Release 2005/04/22 :
Atlantic —
Caribbean"
Ses “Ocean
2 VENEZUELA
{See reference map Hi)
Railroads: 103 mi., all single track; 85 mi. 3''0"
gage, 18 mi. 3''6" gage
Highways: 2,200 mi.; 500 mi. paved, 1,000 mi.
otherwise improved, 700 mi. unimproved
Inland waterways: 8,700 mi.; Demerara River
navigable to Mackenzie by ocean steamers, others by
ferryboats, small craft only
Ports: 1 major (Georgetown), 3 minor
88
Civil air: 5 major transport aircraft
Airfields: 96 total, 89 usable; 4 with permanent-
surface runways; 12 with runways 4,000-7,999 ft.; 2
seaplane stations
Telecommunications: highly developed telecom
system with radio relay network and over 18,900
telephones; tropospheric scatter link to Trinidad:
280,000 radio receivers, 2 AM and 1 FM stations
DEFENSE FORCES
Military manpower: males 15-49, 180,000; 143,000
fit for military service
Military budget: for fiscal year ending 31
December 1971, $2.65 million; 2.7% of central
government budget
(See reference map 11)
LAND
10,700 sq. mi.; 3196 cultivated, 18% rough pastures,
7% forested, 44% unproductive
Land boundary: 224 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing 15 n. mi.)
Coastline: 1,100 mi.
Railroads: 50 mi. 2''6" gage. single-track, privately
owned industrial line; 5 mi. dual-gage 2/6''''-3''6";
government line, dismantled
Highways: 2,000 mi.; 400 mi. paved, 600 mi.
otherwise improved, 1,000 mi. unimprove
U.S.;
Inland waterways: negligible; about 60 mi.
navigable
Ports: 2 major (Port-au-Prince, Cap Haitian), 12
minor
Civil air: 7 major transpott aircraft
Airfields: 16 total, 15 usable; 3 with permanent-
surface runways; 1 with runway 8,000-11,999 ft, 5
with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: all domestic facilities
inadequate, international facilities slightly better;
telephone expansion program underway; only 9,500
telephones, 300,000 radio and 13,400 TV receivers, 32
AM, 5 FM, and 1 TV station, COMSAT station under
construction
DEFENSE FORCES
Military manpower: males 15-49, 1,259,000,
669,000 fit for military service; about 52,000 reach
military age (18) annually
Military budget: for fiscal year ending 30
September 1975, $8.0 million; about 2076 of
operational budget','d30da5978b17c23be67adc56a49f5e87624b4a1a914130cfd442ea4d2505923e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46927d74a523c9050b8ef5389ee51f2f6694083f92b24764ae9e0eb5993d9631',1976,'HN','Honduras','communications',230,'LAND
49,800 sq. mi.; 27% forested, 3076 pasture, 36%
waste and built-up, 7% cropland
Land boundaries: 950 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 510 mi.
Railroads: 357 mi.; 202 mi. of 3''6” Eage, 155 mi. of
3''0" gage
1-8
-01051A00080001000
ed For Release 2005/04/22 : CIA-RDP79-010
Approv
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
HONDURAS/HONG KONG
Highways: 5,400 mi.; 700 mi. bituminous surfaced,
1,550 mi. gravel surfaced or improved earth, 3,150
unimproved earth
Inland waterways: 750 mi. navigable by small
craft
Ports: 3 major (Puerto Cortes, La Caiba, Tela), 9
minor
Civil air: 24 major transport aircraft
Airfields: 247 total, 222 usable; 4 with permanent-
surface runways; 8 with runways 4,000-7,999 ft.; 2
seaplane stations
Telecommunications: improved, but still inade-
quate; connection into Central American microwave
net; 15,000 telephones; 300,000 radio and 46,000 TV
receivers; 96 AM, 11 FM, and 5 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 107,000; 414,000
fit for military service; about 29,000 reach military
age (18) annually
Military budget: proposed for fiscal year ending 31
December 1975, $17.3 million; about 8.896 of central
government budget (includes the armed forces and
other military)','40957b221d2ae5b467163e8a87add1ef9896efabb41422264e830c0d78de15c0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f2d20b2fdb09b8459d0f440d5b9034644c936f8944e20af73892a0c883b446b',1976,'HK','Hong Kong','communications',234,'pH. j "E:
{See reforance map Vi)
LAND
400 sq. mi.; 14% arable, 10% forested, 76% other
(mainly grass, shrub, steep hill country)
Land boundaries: 15 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 455 mi.
Ports: | 1 major
Civil air: 14 major transport aircraft
Airfields: 2 total, 2 usable. 2 with permanent-
surface runways: 1 with runway 8,000-11,999 ft., 1
with runway 4,000-7,999 ft.; 1 seaplane station
Telecommunications: modern facilities provide
domestic and international services; excellent
broadcast coverage provided by wired and radio
broadcast stations; closed-circuit TV and TV
broadcast facilities; 913,411 telephones; 2.5 million
radio receivers; 100,000 wired-speakers; 1 FM,2 AM
stations; wired-radiobroadcast network; 2 TV stations,
2 closed-circuit TV networks; 2 satellite ground
stations; radio relay to Taiwan/Philippines; new
coaxial cable link to Canton; 5 submarine cables;
Taiwan submarine cable planned
DEFENSE FORCES
Military manpower: males 15-49, 1,081,000;
839,000 fit for military service; about 53,000 reach
military age (18) annually
Defense is the responsibility of U.K.
Ships: Hong Kong Marine Police, 88 police boats:
U.K. naval ships homeported in the U.K. operate in
the Indian Ocean, Gulf, and Far East; they rotate
assignments within the area: one destroyer escort
permanently assigned as the Hong Kong guard ship: a
varied number of auxiliary/service craft are assigned
to the Commander Hong Kong','08e8dbd8b4fb61e91b80692ba278333859b9a5ae76790b9fdcc2aa3f5a3cad67','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d9a6e47606e5a93b421a9b83ee006c701aa20aa2d7a346fd70aaf59a63d8f64',1976,'HU','Hungary','communications',238,'LAND
35,900 sq. mi.; 60% arable, 14% other agricultural,
16% forested, 10% other
92
Approved For Release 2005/04/22
{See reference map IV}
Land boundaries: 1,395 mi.
Railroads: 5,353 route mi.; 4,598 mi. standard
gage, 798 mi. narrow gage (mostly 2/575"), 22 mi.
broad gage (5/0), 720 mi. double track, 755 mi.
electrified; government owned (1978)
Highways: 18,516 mi.; 478 mi. concrete, 11,992
mi. bituminous, 236 mi. stone block, 5,157 mi. gravel,
652 mi. earth (1973)
Pipelines: crude oil, 700 mi.; refined products, 180
mi.; natural gas, over 1,600 mi.
Inland waterways: 1,049 mi. (1975)
Freight carried: rail—142.8 million short tons
(1974), 15.8 billion short ton/mi. (1974); highway—
535.7 million short tons, 5.3 billion short ton/mi.
(1974); waterway—est. 15.6 million short tons, 5.7
billion short ton/mi. incl. int''l. transit traffic (1974)
River ports: 2 principal (Budapest, Dunaujvaros);
no maritime ports; outlets are Rostock, East Germany,
and Gdansk, Gdynia, and Szezecin in Poland
DEFENSE FORCES
Military manpower: males 15-49, 2,662,000;
2,144,000 fit for military service; about 78,000 reach
military age (18) annually
Military budget (announced): for fiscal year
ending 81 December 1975, 11.3 billion forints; about
8.5% of total budget','edc356a96a54c7a9fa23fb25a9d8d0491902dfc7192a9a68913251423508c1f8','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3064607af93fac9dab7394e971f3726ee87b4221f9bab14c44f84d98faa918c4',1976,'IS','Iceland','communications',242,'(See reference map iV}
LAND
89,750 sq. mi.; arable negligible, 22% meadows and
pastures, forested negligible, 78% other
WATER
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 50 n. mi., effective 1 September 1972)
Coastline: 3,100 mi.
93
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Railroads: none
Highways: 6,905 mi; 4,760 mi. crushed stone
(including lava) and gravel, 2,055 mi. unsurfaced
roads and motorable tracks, 90 mi. concrete or paved
Ports: 4 major (Akureyri, Hafnarfjordhur,
Reykjavik, Seydhisfjordhur), and about 50 minor
Civil air: 22 major transport aircraft registered
Airfields: 111 total, 107 usable; 4 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 13
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate domestic service,
wire and radio communication system; 87,500
telephones; 78,000 radio and 53,500 TV receivers; 17
AM, 14 FM, and 82 TV stations; 2 coaxial submarine
cables
DEFENSE FORCES
Military manpower: males 15-49, 53,000; 48,000
fit for military service (Iceland has no conscription or
compulsory military service)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','f742cd6d1c41ce03de823e2af458240856d8c7ed3870738f0f6782cc52702800','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7895289b3563911727a60256d8a570f4c7f5b075e5a65c10c7dd78a2bc7e4cb9',1976,'ID','Indonesia','communications',246,': M ‘South China :
"Seg
Indian Ocean
bi y
es reference map VI!)
LAND
736,000 sq. mi.; 12% small holdings and estates,
64% forests, 24% inland water, waste, urban, and
other
Land boundaries: 1,700 mi.
WATER
Limits of territorial waters (claimed): under an
archipelago theory, claim is 12 n. mi., measured
seaward from straight baselines connecting the
vutermost islands
Coastline: 34,000 mi.
Railroads: 4,364 mi.; 3,990 mi. 3''6" gage, 317 mi.
2:54" gage, 57 mi. 111%" gage: 132 mi. double
track; 74 mi. electrified; government owned
Highways: 57,460 mi.; 12,600 mi. paved, 25,200
mi. gravel or crushed stone, 19,660 mi. improved or
unimproved carth
Inland waterways: 13,410 mi.; Sumatra 3,400 mi.,
Java and Madura 510 mi., Borneo 6,500 mi., Celebes
150 mi., and Irian Barat 2,850 mi.
Ports: 10 major, 63 minor
Civil air: 88 major transport aircraft (includes 2
leased)
Airfields: 327 total, 270 usable; 49 with
permanent-surface runways; 9 with runways 8,000-
11,999 ft., 63 with runways 4,000-7,999 ft.
Telecommunications: extensive police net for
interisland service; international and domestic service
fair but improving; radiobroadcast coverage adequate
but TV limited to Java only; 268,963 telephones; 5
million radio and 293,000 TV sets; 137 AM, 1 FM,
and 12 TV stations; 1 earth satellite station on java; 2
submarine cables to Singapore no longer in service
IRAN
LAND
636,000 sq. mi.; 1496 agricultural, 1196 forested,
16% cultivable with adequate irrigation, 51% desert,
waste, or urban, 8% migratory grazing and other
97
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
IRAN
Arabian
Sea
¡See reference map Vj
Land boundaries: 3,305 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 50 n. mi.)
Coastline: 1,980 mi., including islands, 420 mi.
Railroads: 2,373 mi. 4''8 4" gage, 57 mi. 5''6” gage
Highways: 27,000 mi.; 7,500 mi. bituminous and
bituminous treatment, 14,250 mi. gravel and crushed
stone, 5,250 mi. improved earth
Inland waterways: 565 mi., excluding the Caspian
Sea, 64.6 mi. on the Shatt al Arab
Pipelines: crude oil, 1,640 mi.; refined products,
2.985 mi.; natural gas, 1,440 mi.
Ports: 7 major, 6 minor
Civil air: 36 major transport aircraft
Airfields: 163 total, 154 usable; 55 with
permanent-surface runways; 1l with runways over
12,000 ft., 17 with runways 8,000-11,999 ft., 57 with
runways 4,000-7,999 ft.
Telecommunications: advanced system of high-
capacity radio-relay links, open-wire lines, cables, and
tropospheric links; principal center Tehran, secondary
centers Isfahan, Meshed, and Tabriz; 552,500
telephones; 2.0 million radio and 1.0 million TV
receivers; 31 AM, 1 FM, and 67 TV stations; satellite
earth station
DEFENSE FORCES
Military manpower: males 15-49, 7,687,000;
4,553,000 fit for military service; about 340,000 reach
military age (21) annually
Military budget: for fiscal year ending 20 March
1976, $9.2 billion est; 36% of general budget','e62fded16cc2207be7365271b79e650b45481610938453b791fc5d9b0a1cc57c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('346a0e287a81f477b89c2a319a39953dcce902f7c501bf4ee5bb9a2aa1a78e38',1976,'IQ','Iraq','communications',250,': ud i. | Caspian
to ea
(See reference map Vj
LAND
172,000 sq. mi.; 18% cultivated, 68% desert, waste,
or urban, 1096 seasonal and other grazing land, 496
forest and woodland
Approved For Release 2005/04/22
Land boundaries: 2,280 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 36 mi.
Railroads: 1,057 mi.; 698 mi. 4''8 15" gage, 359 mi.
meter (3854) gage; 10 mi. meter gage double track
Highways: 12,900 mi.: 4,000 mi. paved; 2,900 mi.
crushed stone, gravel, or improved earth; 6,000 mi.
carth and sand tracks
Inland waterways: 685 mi. Shatt al Arab
navigable by maritime traffic for about 65 mi.; Tigris
and Euphrates navigable by shallow-draft steamers
Ports: 3 major (Basra, Umm Qasr, Al Faw)
Pipelines: crude oil, 1,660 mi.; 25 mi. refined
products; 430 mi. natural gas
Civil air: 11 major transport aircraft
Airfields: 89 total, 72 usable; 24 with permanent-
surface runways; 43 with runways 8,000-11,999 ft.,
15 with runways 4,000-7,999 ft.
Telecommunieations: network consists of open-
wire lines, radio-relay links, and radiocommunication
stations; 129,400 telephones; 1.25 million radio
receivers; 350,000 TV receivers; 5 TV and 7 AM
stations
DEFENSE FORCES
Military manpower: males 15-49, 2,491,000;
1,392,000 fit for military service; about 120,000 reach
military age (18) annually
Military budget: for fiscal year ending 31 March
1975, $797,228,700: 12.9% of total budget
100','e187bf2f0ace6c35daccac4f3147a9ece32086a8ac3e62128fb28e13cd82d420','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bd3378a68e7038404eb1c216f8cb6a3e327365251eaeb4627eb508af32ad122',1976,'IE','Ireland','communications',254,'Atlantic Of,
A :
;
Ocean
Qu.
IRELAND; Oo"
[Ses reference map IV)
LAND
26,600 sq. mi; 17% arable, 51% meadows and
pastures, 3% forested, 2% inland water, 27% waste
and urban
Land boundaries: 224 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 900 mi.
Railroads: 1,361 mi, 5''3” gage: government
owned
Highways: 53,700 mi.; 46,950 mi. surfaced, 6,750
mi. earth
Inland waterways: approx. 650 mi.
Ports: 6 major, 38 minor
Civil air: 21 major transport aircraft
Airfields: 89 total, 38 usable; 8 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 4
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: small, modern system; all
cities interconnected for telephone and telegraph
service; 397,000 telephones; 895,000 radiobroadcast
receivers; 620,000 TV receivers; 3 AM, 7 FM, and
93 TV stations; 4 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 703,000; 551,000
fit for military service; about 28,000 reach military
age (17) annually
Military budget: for fiscal year ending 31 March
1974, $89.4 million; about 4.5% of the central
government budget','b9edcdf3323a7b2410974e2ffdc0050f931941264ac0f2cfdced3daee9c1a36f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cdc75277812c8063cb94ddb96384b4ba6f7c84ca723b18b662abf30264a8b86',1976,'IL','Israel','communications',258,'(See reference mep Vj
NOTE: The Arab territories occupied since the 1967
war are not included in the data below.
101
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LAND
8,000 sq. mi. (excluding about 25,000 sq. mi. of
oceupied territory in Jordan, Egypt, and Syria); 20%
cultivated, 40% pastureland and meadows, 4%
forested, 4% desert, waste, or urban, 3% inland water,
29% unsurveyed
Land boundaries: 644 mi. (1967): including
occupied areas, 490 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
Coastline: 125 mi. (1967); including occupied
areas, 925 mi.
Railroads: 477 mi. 48%" gage
Highways: 2,500 mi.; 2,300 mi. paved, 200 mi.
otherwise improved; additional mileage (mostly
paved) in occupied territories (670 mi. in Jordan,
1,150 mi. in Egypt (Sinai), 75 mi. in Syria)
Pipelines: crude oil, 440 mi.; refined products, 180
mi.; natural gas, 55 mi.
Ports: 3 major (Haifa, Ashdod, Elat), 5 minor
Airfields: 53 total, 42 usable; 21 with permanent-
surface runways; 5. with runways 8,000-11,999 ft., 10
with runways 4,000-7,999 ft.
Civil air: 23 major transport aircraft
Telecommunications: most modern and highly
developed in the Middle East; 685,400 telephones;
441,000 radio and 440,000 TV receivers; 28 TV, 13
AM, and 10 FM stations; 1 submarine cable; earth
satellite station
DEFENSE FORCES .
Military manpower: Jewish males 15-49, 712,000;
613,000 fit for military service; average number of
Jews reaching military age (18) annually — 28,000
males, 27,000 females; both sexes liable for military
service
Military budget: for fiscal year ending 31 March
1975, $3.7 billion; about 4096 of total budget','afe7444c7bd7a9ca22b0cd51b9b45d4abdc8d7ec6fdceb25b97b478625aaea7d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b469b2f1b648786fd1eac60729f8f2c4147ffef4512ef0a5bbbadaa3d785e6cb',1976,'IT','Italy','communications',262,'` LAND
116,300 sq. mi.; 50% cultivated, 17% meadow and
pasture, 21% forest, 3% unused but potentially
productive, 9% waste or urban
(See reference map (V)
Land boundaries: 1,058 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 3,105 mi.
Railroads: 12,857 mi.; 9,907 mi. government
owned; 9,805 mi. standard gage; 4,906 mi. electrified;
102 mi. narrow gage (3''1%''''); 2,950 mi. non-
government owned; 1,567 mi. standard gage; 794 mi.
electrified; 1,383 mi. narrow gage; 328 electrified
Highways: 179,000 mi.; autostrade 3,000 mi., state
highways 25,750 mi., provincial highways 57,000 mi.,
communal highways 93,250 mi.; 159,000 mi.
concrete, bituminous, or stone block, 15,500 mi.
gravel and crushed stone, 4,500 mi. earth
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ITALY/IVORY COAST
Inland waterways: 1,538 mi. navigable routes; 708
mi. rivers, 529 mi. canals, 307 mi. are lake routes
Pipelines: crude oil, 1,100 mi.; refined products,
900 mi.; natural gas, 6,869 mi.
Ports: 16 major, 22 significant minor
Civil air: 141 major transport aircraft
Airfields: 147 total, 147 usable; 77 with
permanent-surface runways; 2 with runways over
19,000 ft., 29 with runways 8,000-11,999 ft., 49 with
runways 4,000-7,999 ft.; 11 seaplane stations
Telecommunications: well engineered, well
constructed, and efficiently operated; 14.1 million
tclephones; 13.7 million radio and 12.6 million TV
reccivers; 82 AM, 606 FM, and 873 TV stations; 11
coaxial submarine cables; 3 communication satellite
ground stations
DEFENSE FORCES
Military manpower: males 15-49, 13,841,000;
11,586,000 fit for military service; 423,000 reach
military age (18) annually
IVORY COAST
(See reference map VI)
LAND
125,000 sq. mi.; 40% forest and woodland, 8%
cultivated, 52% grazing, fallow, and waste, 200 mi. of
lagoons and connecting canals along eastern coast
Land boundaries: 2,005 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 320 mi.
Railroads: 408 mi. of the 728 mi. Abidjan to
Ouagadougou, Upper Volta line, all single track meter
gage; only diesel locomotives in use
Highways: 24,600 mi.; 1,045 mi. bituminous and
bituminous-surface treatment; 21,385 mi. gravel,
crushed stone, laterite, and improved earth; 12,600
mi. unimproved earth roads
Inland waterways: 460 mi. navigable rivers and
numerous coastal lagoons
Ports: 2 major (Abidjan, San Pedro), 3 minor
Civil air: 14 major transport aircraft
Airfields: 45 total, 44 usable; 3 with permanent-
surface runways; 2 with runways 8,000-11,999 feet;
7 with runways 4,000-7,999 feet; 1 seaplane station
Telecommunications: system only slightly above
African average; consists of open-wire lines and radio
relay links, which provide incomplete coverage of
country; Abidjan is only center; 25,200 telephones;
106
205,000 radio and 100,000 TV receivers; 2 AM, no
FM, and 4 TV stations; 1 submarine cable; satellite
earth station
DEFENSE FORCES
Military manpower: males 15-49, 1,060,000;
553,000 fit for military service; 57,000 males reach
military age (18) annually','bf223f7ac5cb1260823daae80d1a5346b7728820f4106cb040ac0c8672947eba','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6fc21830d570d30037ea8b1b2e2c089eeb031c618f39925ab193690cbbe6acd',1976,'JM','Jamaica','communications',266,'Atlantic
Ocean
MINICAN
REPUBLIC
{See reference map 11)
LAND
4,410 sq. mi; 21% arable, 23% meadows and
pastures, 19% forested, 37% waste, urban, or other
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 635 mi.
Railroads: 204 mi. government-owned, 43 mi.
privately owned, all standard gage, single track
Highways: 8,100, mi.; 3,000 mi. paved, 3,000 mi.
gravel, 2,100 mi. unimproved earth surfaces
Pipelines: refined products, 6 mi.
Ports: 3 major (Kingston, Montego Bay, Montego
Freeport), 10 minor
Civil air: 10 major transport aircraft
Airfields: 43 total, 23 usable; 12 with permanent-
surface runways; 2 with runways 8,000-11,999 ft.,
1 with runway 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fully automatic domestic
telephone network with 91,000 telephones; satellite
ground station; 600,000 radio and 105,000 TV
receivers; 8 AM, 8 FM, and 9 TV stations; 5
submarine cables, including 2 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 432,000; 307,000
fit for military service; no conscription; average
number currently reaching minimum volunteer age
(18) 22,000
Supply: dependent on U.K. and U.S.','aea1997b1fefdd2cbd293525588dde853a4af1cfcb86f633a1da941d612e3fe9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a7ef6a306fc9561a7c66344c9fb2bbb23f0846c20333c3d7b8456535fd63438',1976,'JP','Japan','communications',270,'LAND
143,000 sq. mi.; 16% arable and cultivated, 3%
grassland, 12% urban and waste, 69% forested
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 7,500 mi. Japan; 1,000 mi. Ryukyus
Railroads: 17,620 mi.; 320 mi. standard gage,
17,300 mi. predominantly narrow gage (8''6''), 4,297
mi. double track, 7,485 mi. electrified; 7396
government owned i
Highways: 650,260 mi. (1974); 164,530 mi. paved,
most of remainder gravel or crushed stone
Inland waterways: approx. 1,100 mi.; seagoing
craft ply all coastal “inland seas”
Pipelines: crude oil, 41 mi.; natural gas, 580 mi.
Ports: 53 major, over 2,000 minor
Civil air: 212 major transport aircraft (includes 2
leased)
Airfields: 191 total, 188 usable; 118 with
permanent-surface runways; 2 with runways over
12,000 ft.; 22 with runways 8,000-11,999 ft., 44 with
runways 4,000-7,999 ft., 6 seaplane stations
DEFENSE FORCES
Military manpower: males 15-49, 31,187,000;
26,341,000 fit for military service; about 805,000
reach military age (18) annually
Military budget: for fiscal ycar ending 31 March
1976, $4.4 billion; about 6.2% of total proposed
budget and 0.8% of GNP','8fc1422fc7a0c60f7056e7ff78c3bf4132be2e2ff57b9550ce9edf480127d3f3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21642bca052d667517a64718b7cb3d428a18b5b639f8cbe53335a6634e3ff645',1976,'JO','Jordan','communications',274,'A
Miti TIT.
ISRAE
ERE ENS
(Sea reference mi 7
NOTE: The war between Israel and the Arab states
in June 1967 ended with Israel in control of West
Jordan. Although approx. 930,000 persons resided in
this area prior to the start of the war, fewer than
750,000 of them remain there under the Israeli oc-
cupation, the remainder having fled to East Jordan.
Over 14,000 of those who fled were repatriated in
August 1967, but their return has been more than off-
set by other Arabs who have crossed and are contin-
uing to cross from West to East Jordan. These and
certain other effects of the 1967 Arab-Israeli war are
not included in the data below.
Approved For Release 2005/04/22
LAND
37,100 sq. mi. (including about 2,100 sq. mi.
occupied by Israel); 11% agricultural, 88% desert,
waste, or urban, 1% forested
Land boundaries: 1,100 mi. (1967, 1,087 mi.
excluding occupied areas)
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 16 mi.
Railroads: 388 mi. 3''5%" gave, single track
Highways: 4,400 mi.; 3,652 mi. bituminous, 124
mi. improved earth; 624 unimproved earth
Pipelines: crude oil, 130 mi.
Ports: 1 major (Aqaba)
Civil air: 8 major transport aircraft
Airfields: 24 total, 15 usable; 12 with permanent-
surface runways; 1 with runways over 12,000 ft., 10
with runways 8,000-11,999 ft., 2 with runways 4,000-
7,999 ft.
Telecommunications: adequate telecommunica-
tion system for the needs of the country; 40,500
telephones; 529,000 radio and 132,000 TV receivers: 1
AM and 1 TV stations; 1 earth satellite station
DEFENSE FORCES
Military manpower: males 15-49, 588,000; 417,000
fit for military service; average number currently
reaching military age (18) annually 30,000
110
Approved For Release 2005/04/22
Military budget: for fiscal year ending 31
December 1975, $154,539,600; 22% of total budget','95ef813ba57ac39a6ac385cf583bc91e030dd6355a235dda6e306ead68aa7f2b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4e9dc50213d4651cacefcd4d1e2c24b07a0b31633bfbd7537e1d13de894f863',1976,'KE','Kenya','communications',278,'` Indian
Ocean
(See reference mag Vij
LAND
225,000 sq. mi.; about 21% forest and woodland,
18% suitable for agriculture, 66% mainly grassland
adequate for grazing (1971)
Land boundaries: 2,093 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 333 mi.
Railroads: 1,275 mi.; meter gage
Highways: 30,200 mi.; 2,315 mi. paved, 27,885 mi.
gravel and/or earth
Inland waterways: part of Lake Victoria and Lake
Rudolph are within boundaries of Kenya
Ports: 1 major (Mombasa), 3 minor
Civil air: 9 major transport aircraft
Airfields: 233 total, 216 usable; 6 with permanent-
surface runways; 1 with runway over 12,000 ft., 2 with
runways 8,000-11,999 ft., 41 with runways 4,000-
7,999 ft.
Telecommunications: in top group of African
systems; consists of radio-relay links, open-wire lines,
and radiocommunication stations; principal center
Nairobi, secondary centers Mombasa and Nakuru;
85,200 telephones; 774,000 radio and 37,000 TV
receivers; 4 AM, 1 FM, and 5 TV stations; satellite
ground station
DEFENSE FORCES
Military manpower: males 15-49, 2,899,000;
1,779,000 fit for military service; no conscription
Military budget: for fiscal year ending 30 June
1974, $32,759,000; about 4.3% of total budget
KOREA, NORTH
Sea of
dapan
NORTH
¿KOREA
Chine Sea
(See reference map Vit)
LAND
47,000 sq. mi.; 17% arable and cultivated, 74% in
forest, scrub, and brush; remainder wasteland and
urban
Land boundaries: 1,040 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
111
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
KOREA, NORTH/KOREA, SOUTH
Coastline: 1,550 mi.
Highways: about 12,600 mi., 95% gravel or earth
surface
2.15 won=US$l
Inland waterways: 1,400 mi.; mostly navigable by
small craft only
Ports: 6 major, 26 minor
DEFENSE FORCES
Military manpower: males 15-49, 3,650,000;
2,217,000 fit for military service; 186,000 reach
military age (18) annually
KOREA, SOUTH
(See reference map VII]
LAND
38,000 sq. mi.; 2396 arable (22% cultivated), 10%
urban and other, 67% forested
Land boundaries: 150 mi.
WATER
Limits of territorial waters: 3 n. mi. (fishing, 20-
200 n. mi, continental shelf including sovereignty
over superjacent waters)
Coastline: 1,500 mi.
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
KOREA, SOUTH
Railroads: 1,967 mi.; 1,915 mi. standard gage, 32
mi. (26^) narrow gage; 270 mi. double track; 175 mi.
electrified; government owned
113
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
KOREA, SOUTH/KUWAIT
Highways: 29,095 mi.; 4,860 mi. paved, 20,040 mi.
gravel, 2,015 mi. improved earth, 2,180 mi.
unimproved earth (1973)
Inland waterways: 1,000 mi.; use restricted to
small native craft
Freight carried: rail (1973) 5.8 billion short
ton/mi., 37.7 million short tons; highway 24 million
short tons; air (1959) 796,260 lbs. carried
Pipelines: 255 mi, refined products, under
construction
Ports: 10 major, 18 minor
Civil air: 26 major transport aircraft
Airfields: 116 total, 114 usable; 52 with
permanent-surface runways; 15 with runways 8,000-
11,999 ft., 13 with run ways 4,000-7,999 ft.: 2 seaplane
stations
DEFENSE FORCES
Military manpower: males 15-49, 8,184,000,
5,329,000 fit for military service; average number
reaching military age (18) annually 358,000
Military budget: for fiscal year ending 81
December 1975, $888 million; about 279; of total
budget','74dffc5dfe9725dccb534f16e34425b9bf193f8b50775c8fa9fbb91c6de07a23','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6300f25edba8b5f5eacd25bee2274f5d3f764de186314aeb694b45ee18eeddda',1976,'KW','Kuwait','communications',282,'{See reference map Vj
LAND
6,200 sq. mi. (excluding neutral zone but including
islands); insignificant amount forested; nearly all
desert, waste, or urban
Land boundaries: 285 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 310 mi.
Railroads: none
Highways: 1,550 mi.; 465 mi. bituminous; 1,085
mi. earth, sand, light gravel
Pipelines: crude oil, 545 mi.; refined products, 25
mi.; natural gas, 75 mi.
Ports: 3 major (Ash Shuwaikh, Ash Shuaybah,
Mina al Ahmadi), 4 minor
Civil air: 9 major transport aircraft
Airfields: 11 total, 5 usable; 3 with permanent-
surface runway; 3 with runways 8,000-11,999 ft.,
2 with runways 4,000-7,999 ft.
Telecommunications: excellent international
and adequate domestic telecommunication facilities;
95,100 telephones; 215,000 radio and 132,000 TV sets;
3 AM and 8 TV stations; satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, about 311,000;
about 179,000 fit for military service
Coast Guard: 12 patrol boats
Military budget: for fiscal year ending 31 March
1975, $136,008,620; 6.9% of total budget
LAOS
LAND
91,430 sq. mi.; 8% agricultural, 60% forests, 32%
urban, waste, and other; except in very limited areas,
soil is very poor; most of forested area is not
exploitable
Land boundaries: 3,140 mi.
Approved For Release 2005/04/22 :
(See reference map Vil}
Highways: about 9,700 mi. (including Communist-
held areas); 800 mi. bituminous or bituminous
treated, 2,700 mi. gravel, crushed stone, or improved
earth; 6,200 mi. unimproved earth and often
impassable during rainy season mid-May to mid-
September
Inland waterways: about 2,850 mi., primarily
Mekong and tributaries; 1,800 additional miles are
sectionally navigable by craft drawing less than 1.5 ft.
116
Ports (river): 5 major, 4 minor
Airfields: 113 total, 84 usable; 7 with permanent-
surface runways; 11 with runways 4,000-7,999 ft., 1
with runway 8,000-11,999 ft.
DEFENSE FORCES
Military manpower: males 15-49, 788,000; 423,000
fit for military service; average number currently
reaching usual military age (18) annually, 33,000; no
conscription age specified','c9c84f195bb1f2118cadc6c0c38625a74643bdeed1ec7e1ce52e9a5373096407','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1d9731535364ad4e5ae43720345a23c3296f84a9f93fb4b8c4b96a8bf566f8a',1976,'LB','Lebanon','communications',286,'Mediterranean
Ses
IBRAE
(Sae referance map V}
LAND
4,000 sq. mi.; 27% agricultural land, 64% desert,
waste, or urban, 996 forested
Land boundaries: 285 mi.
WATER
Limits of territorial waters (claimed): no specific
claims (fishing, 6 n. mi.)
Coastline: 140 mi.
Railroads: 238 mi.; 184 mi. 48%”, 51 mi. 35%";
all single track
Highways: 5,160 mi.; 3,850 mi. paved, 310 mi.
gravel and crushed stone, 404 mi. improved earth, 596
mi. unimproved earth
Pipelines: crude oil, 45 mi.
Ports: 3 major (Beirut, Tripoli, Sayda), 5 minor
Civil air: 30 major transport aircraft
Airfields: 5 total, 3 usable; 3 with permanent-
surface runways; 3 with runways 8,000-11,999 fe.
Telecommunications: excellent international
telecommunication facilities include satellite ground
station; good domestic telephone and telegraph
service; 227,000 telephones; 1.3 million radio and
375,000 TV receivers; 7 TV, 2 FM, and 1 AM
radiobroadcast stations; 1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 772,000; 472,000
fit for military service; average of about 30,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
December 1975, $141,225,650; 16% of total budget','dcabe0590913fdf5d97859423800f6d9d6fc59c8eb47c3e1c05d7c3fedf06711','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d327bc957109bacb6becab196e577aa5be89df6eecccff2366ab8779ac54f08',1976,'LS','Lesotho','communications',290,'LAND
11,700 sq. mi; 15% cultivable; largely mountain-
ous
Land boundaries: 500 mi.
Railroads: | mi.; owned, operated, and included in
the statistics of the Republic of South Africa
Highways: approx. 1,370 mi.; 120 mi. paved; 580
mi. crushed stone, gravel, or stablized soil; 670 mi.
improved or unimproved earth
Civil air: no major transport aircraft
Airfields: 27 total, 20 usable; 3 with runways
4,000-7,999 ft., 1 with permanent surface runway
Telecommunications: system a modest one
consisting of a few landlines, a small radio-relay
system, and minor radiocommunication stations;
Maseru is the center; 3,425 telephones; 11,000 radio
receivers; 2 AM, no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 214,000. fit for
military service 116,000
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','2737e65c9ec6123f9767be0ffb130d0ddade1b3b0774a6ab2317b5e3b8b1b6b3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59816be7391f814947d8a5daf62c30df0aad6c3334eda1582bb5ec881c00eba9',1976,'LR','Liberia','communications',294,'LIBERI
Monrovia ~
Atlantic Ocean
[See reference map VI}
LAND
43,000 sq. mi.; 20% agricultural, 30% jungle and
swamps, 40% forested, 10% unclassified
Land boundaries: 830 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 360 mi.
Railroads: 312 mi.; 220 mi. standard gage, 90 mi.
narrow gage (3''6”''); all lines single track; rail systems
owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 4,950 mi.; 340 mi. bituminous treated;
remainder improved and unimproved laterite, gravel,
and/or earth
Inland waterways: 230 mi. navigable
Ports: 3 major (Monrovia, Buchanan, Greenville-
Sino Harbor), 4 minor
Civil air: 3 major transport aircraft
Airfields: 80 total, 78 usable; 2 with permanent-
surface runways; ] with runway 8,000-11,999 ft.. 6
with runways 4,000-7,999 ft.; | seaplane station
Telecommunications: telephone and telegraph
limited; main center is Monrovia; 3,400 telephones;
261,000 radio and 8,500 TV receivers; 5 AM, no FM,
3 TV stations; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 407,000; 217,000
fit for military service; no conscription
Military budget: for year ending 31 December
1975, $4,664,000; 3.9% of total budget','01cf427e22c37d40600b34efb05b28d562c4db0c4f8cb92da73409fc05034b5d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28524df22b3417872daf93b2e5fdd1eb58e67c14744379e04319b49d3b51d43c',1976,'LY','Libya','communications',298,'LAND
679,000 sq. mi.; 6% agricultural, 1% forested, 93%
desert, waste, or urban
Land boundaries: 2,700 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(except for Gulf of Sidra where sovereignty is claimed
und northern limit of jurisdiction fixed at 32°30''N.
and the unilaterally proclaimed 100 n. mi zone
around Tripoli)
Coastline: 1,100 mi.
Railroads: none
Highways: 10,050 mi.; 4,780 mi. bituminous or
bituminous treated, 5,270 mi. improved and
unimproved earth and gravel
Pipelines: crude oil 1,520 mi.; natural gas 175 mi.;
refined products 140 mi.; liquid petroleum gas 135 mi.
Ports: 3 major (Tobruk, Tripoli, Banghazi), 6 minor
Civil air: 12 major transport aircraft; an additional
25 major transports are operated by external carriers
engaged in charter work for several oil companies
Airfields: 86 total, 79 usable; 13 with permanent-
surface runways, 1 with runway over 12,000 ft., 10
with runways 8,000-11,999 ft., 35 with runways 4,000-
7,999 ft.; 2 seaplane stations
Approved For Release 2005/04/22
Telecommunications: system is just within top
one-third of African systems; consists of radio-relay
and tropospheric-scatter links, open-wire lines, and
radiocommunication stations; principal centers are
Tripoli and Banghazi; 49,800 telephones; 225,000
radio and 6,000 TV receivers; 7 AM, 1 FM, and 2 TV
stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 500,000; 292,000
fit for military service; about 22,000 reach military
age (17) annually; conscription now being imple-
mented
Military budget: estimated for period 1 April - 31
December 1973, $88,800,000; 4.1% of announced
total budget for nine-month period','1c402b471a585e3ed94918c331a3266648859a13d19cd642f46aeddc131cc254','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('892759a06f8b1da9fd94194138903c2eaaba31c98fa8f86585b1e4bcb59b8b22',1976,'LI','Liechtenstein','communications',302,'3. AUSTRIA.
{Sea reference mep IV)
LAND
65 sq. mi.
Land boundaries: 47 mi.
Railroads: 9.94 mi. 48%” gage, electrified;
owned, operated, and included in statistics of Austrian
Federal Railways
Highways: no information on total mileage
Civil air: 2 major transport aircraft registered in','2386821eb6eb6da5094940bf136363b163483a7bd7b2cfe2e8c64d0b35534f80','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cca7c5b16d3748304e958fa2bf7dd02d4b48d67fe79ffdaf4112470d8fe90fb5',1976,'CH','Switzerland','communications',306,'Airfields: none
Telecommunications: automatic telephone system
serving about 14,800 telephones; no broadcast
facilities; 5,500 radio and 4,700 TV receivers
(programs from Switzerland)
122
Approved For Release 2005/04/22
DEFENSE FORCES
Defense is responsibility of Switzerland
(See reference map Ww
LAND
16,000 sq. mi; 10% arable, 43% meadows and
pastures, 20% waste or urban, 24% forested, 3%
inland water
Land boundaries: 1,171 mi.
Railroads: 3,186 mi; 1,809 government owned
(SBB), 1,768 mi. 48%" gage, 46 mi. 3''3%"" gage, 837
mi. double track, 972 mi. single track, 99% electrified.
1,377 mi. non-government owned, 444 mi. 484"
gage, 886 mi. 3''3%" gage, 47 mi. 27$" gage, 100%
electrified
Highways; 37,158 mi., all paved
Pipelines: crude oil, 195 mi.; natural gas, 650 mi.
Inland waterways: 41 mi. Rhine River-Basel to
Rheinfelden, Schaffhausen to Constanz; in addition,
800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SWITZERLAND/SYRIA
there are 12 navigable lakes ranging in size from Lake
Geneva to Hallwilersee
Ports: 1 major (Basel), 2 minor
Civil air: 79 major transport aircraft (including 4
leased from a foreign country)
Airfields: 91 total, 75 usable; 37 with permanent-
surface runways; 2 with runways over 12,000 ft., 8
with runways 8,000-11,999 ft., 11 with runways 4,000-
7,999 ft. .
Telecommunications: excellent domestic, interna-
tional, and broadcast services; 3.90 million
telephones; communications satellite station; 2.06
million radio and 1.75 million TV receivers; 7 AM, 94
FM, and 811 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,539,000;
1,331,000 fit for military service; 47,000 reach military
age (20) annually
Military budget: for fiscal year ending 31
December 1975, $1,148 million; 19% of central
government budget |:
(See reference map V}
LAND
72,000 sq. mi. including 500 sq. mi. of Israeli-
occupied territory; 48% arable, 29% grazing, 2%
forest, 21% desert
Land boundaries:
occupied arca 1,340 mi.)
WATER
Limits of territorial waters (claimed): 12 n. mi.
(plus 6 n. mi. "necessary supervision zone")
Coastline: 120 mi.
Railroads: 959 mi.; 769 mi. standard gage, 190 mi.
narrow gage (8''594"'')
Highways: 7,150 mi.; 4,800 mi. paved, 810 mi.
gravel or crushed stone, 1,540 mi. improved earth, 500
mi. unimproved earth
Inland waterways: 420 mi.; of little importance
Pipelines: crude oil, 810 mi.; refined products, 320
mi.; natural gas 140 mi.
Ports: 3 major (Tartus, Latakia, Baniyas), 2 minor
Civil air: 5 major transport aircraft
Airfields: 37 total, 32 usable; 22 with permanent-
surface runways; 21 with runways 8,000-11,999 ft., 2
with runways 4,000-7,999 ft.
Telecommunications: good international and
domestic service; 143,300 telephones; 1 million radio
and 187,000 TV receivers; 5 TV and 5 AM stations
DEFENSE FORCES
Military manpower: males 15-49, 1,708,000;
953,000 fit for military service; about 89,000 reach
military age (19) annually
Military budget: for fiscal year ending 31
December 1974, $394 million; 23% of total budget
TANZANIA
LAND
362,800 sq. mi. (including islands of Zanzibar and
Pemba, 1,020 sq. mi.) 6% inland water, 15%
202
Indian
Ocean
TANZANIA Á''
3 Dar es Salaam |
H 4
À, MOZAMBIQUE
(See reference map VI)
cultivated, 31% grassland, 48% bush forest,
woodland, on mainland, 60% arable, of which 40%
cultivated on islands of Zanzibar and Pemba
Land boundaries: 2,413 mi.
WATER
Limits of territorial waters (claimed): 50 n. mi.
Coastline: 885 (this includes Mafia Island, 70;
Pemba Island, 110; and Zanzibar, 132)
Railroads: 2,222 mi.; 600 mi. 3’6" gage; 1,622 mi.,
meter gage, 4 mi. double track; Tanzania portion of
Tan-Zam Railroad completed
Highways: total 30,000 mi., including 390 mi. on
Zanzibar Island and 277 mi. on Pemba and Mafia
Islands; about 1,400 mi. bituminous treated, (370 mi.
on Zanzibar and Pemba); 28,600 mi. gravel, crushed
stone, or unimproved earth
Pipelines: refined products 610 mi.
Inland waterways: 730 mi. of navigable streams,
several thousand mi. navigable on Lakes Tanganyika,
Victoria, and Nyasa
Ports: 8 major (Dar es Salaam, Mtwara, Tanga)
Civil air: 9 major transport aircraft
Airfields: 107 total, 100 usable; 9 with permanent-
surface runways; 1 with runway 8,000 to 11,999 ft., 42
with runways 4,000-7,999 ft.
Telecommunications: telephone and telegraph
good in main centers, only fair outside main towns;
40,150 telephones; 931,000 radio receivers; 4 AM, no
FM or TV stations; 4 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 3,459,000;
1,919,000 fit for military service
Military budget: for fiscal year ending 30 June
1976, $156 million; 17% of total budget
203
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','04ba898da2e8a4298c0173b3f2a4c664214016f985bc7ba20fc78b5e9fbb8cc1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8039f732c51369a0092c7504aea6005f90a23d71420c7dc6e9b69b1e6a99de46',1976,'LU','Luxembourg','communications',307,'Do DWED 7
"A germany E
{See reference map IV}
LAND
1,000 sq. mi; 25% arable, 27% meadows and
pasture, 1596 waste or urban, 3396 forested, negligible
amount of inland water
Land boundaries: 221 mi.
Railroads: 169 mi. standard gage; 100 mi. double
track; 85 mi. electrified
Highways: 3,070 mi; all paved; about 50 mi.
limited access divided highway completed or under
construction
Pipelines: refined products, 30 mi.
Inland waterways: 23 mi.; Moselle River
Port: (river) Mertert
Civil air: 10 major transport aircraft (includes 3
registered in Iceland)
Airfields: 1 total, 1 usable with permanent-surface
runway 8,000-11,999 ft.
Telecommunications: adequate and efficient
system; 146,100 telephones; 200,000 radiobroadcast
receivers; 90,000 TV receivers; 2 AM, 1 FM, 2 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 82,000; 69,000
fit for military service; about 3,000 reach military age
(19) annually
Military budget: for fiscal year ending 31
December 1974, $17.5 million; 3.3% of central
government budget','4a507c610bb2e12efd80793c634e85d8f765baf22f9076d6a3217839ef0eda0b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56c07e2900e77c047a4c7ee7474016b8819f42ba871ca5c8a79d899f43f81287',1976,'MO','Macao','communications',311,'LAND
6 sq. mi.; 10% agricultural, 90% urban
Land boundaries: 220 yds.
WATER
Limits of territorial waters (claimed): 6 n. mi.;
fishing, 12 n. mi.
Coastline: 25 mi.
128
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MACAO/MADAGASCAR
ESHONG KONG','716917ac7ed96a968f839594c38e0935810517cb58cbdaf8d2d38fe84726b90f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bc09d0a5855007dee6f5a6039d301515cddd932c06d873511521edcf30a5a99',1976,'PH','Philippines','communications',312,'(See reference map Vit)
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; ! seaplane station
Telecommunications: fairly modern facilities
provide adequate services for domestic and
international requirements; broadcast coverage is
provided by AM and FM radiobroudcast facilities and
a wired broadcast network; 8,459 telephones; 65,000
radio receivers; 2 AM and 2 FM radio stations; no TV
stations; no submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 60,000; 35,000
fit for military service
Defense is responsibility of Portugal
Philippine Sea
Quez
South ar
n
3
(See reference map Vil}
LAND
116,000 sq. mi.; 53% forested, 30% arable land, 5%
permanent pasture; 12% other
WATER
Limits of territorial waters (claimed): 0-300 n. mi.
(under an archipelago theory, waters within straight
lines joining appropriate points of outermost islands
ure considered internal waters; waters between these
baselines and the limits described in the Treaty of
Paris, December 10, 1898, the U.S.-Spain Treaty of
November 7, 1900, and the U.S.-U.K. Treaty of
January 2, 1930 are considered to be the territorial sea)
Coastline: about 14,000 mi.
Railroads: 2,177 mi.; 2 common-carrier systems
(8''6" gage) totaling about 727 mi. 19 industrial
systems with 4 different gages totaling 1,450 mi.;
34% government owned
Highways: 61,600 mi. (1974); 12,610 mi. paved;
29,725 mi. gravel, crushed stone, or stabilized soil
surface; 19,265 mi. improved earth
Inland waterways: 2,000 mi.; limited to shallow-
draft (less than 5 ft.) vessels
Pipelines: refined products, 157 mi.
Ports: 11 major, 100 minor
Civil air: 52 major transport aircraft
Airfields: 334 total, 312 usable; 46 with
permanent-surface runways; 7 with runways 8,000-
11,999 ft., 25 with runways 4,000-7,999 ft.
DEFENSE FORCES
Military manpower: males 15-49, 9,318,000;
6,691,000 fit for military service; about 400,000 reach
military age (20) annually
Supply: limited small arms ammunition, small
patrol craft, and helicopter production; other materiel
obtained almost exclusively from U.S.; naval ships
and equipment from Australia, Japan, Singapore,
U.S., and Italy; aircraft and helicopters from West
Germany and U.S.
Military budget: for fiscal year ending 30 June
1975, $403 million; about 19% of total budget','f79b1626f666dc3aaedac611ff2189dbb47e437e4c49e58c1405a8e3fbbfd9a2','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c5a87004e9d97367c12a5f0150ec50a8e1846b40c33e511cee50cdb1637f445',1976,'MG','Madagascar','communications',316,'LAND
230,000 sq. mi.; 5% cultivated, 58% pastureland,
21% forested, 8% wasteland, 2% rivers and lakes, 6%
other
WATER
Limits of territorial waters (claimed): 50 n. mi.
Coastline: 3,000 mi.
Railroads: 549 mi. of meter gage
Highways: 5,300 mi.; 1,875 mi. paved, 2,225 mi.
crushed stone, gravel, or stabilized soil; 1,200 mi.
improved and unimproved earth; remainder are tracks
Inland waterways: 600 mi. perennially navigable;
Lac Alaotra (200 sq. mi.)
Ports: 4 major (Tamatave, Diego Suarez, Majunga,
Tulear)
Civil air: 9 major transport aircraft
Airfields: 249 total, 129 usable; 28 with
permanent-surface runways; 3 with runways 8,000-
11,999 ft., 46 with runways 4,000-7,999 ft.
Telecommunications: system above African
average; includes open-wire lines, some radio-relay
and coaxial links and a communication satellite
ground station; 29,300 telephones; 605,000 radio and
7,100 TV receivers; 1 AM, no FM, and 1 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,683,000;
993,000 fit for military service; average number
reaching military age (20) annually about 77,000
Military budget: for fiscal year ending 31
December 1974, $25,536,864; ubout 6.3% of total
budget','2b7bff85fc52e5ff1d151dc0878d926f9b50d9bce65a10ed59727f32cea6687c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62c942a7d6484d2eeed2adc8065b12c99d5ffb05cb4edbe25bfa5b93f988cc2c',1976,'MW','Malawi','communications',320,'LAND
36,700 sq. mi.; about 31% of land area arable (of
which less than half is cultivated), nearly 25%
forested, 6% meadow and pasture, 38% other
126
Indian
- TANZANIA
(See reference map Vi}
Land boundaries: 1,790 mi.
Railroads: 352 mi. (3''6" gage)
Highways: 6,710 mi; 540 mi. paved; 4,040 mi.
crushed stone, gravel, or stabilized soil; 2,130 mi.
unimproved earth
Inland waterways: Lake Nyasa (Lake Malawi),
800 route mi. and Shire River, 90 mi.
Ports: 3 lake
Civil air: 6 major transport aircraft
Airfields: 46 total, 45 usable; 1 with permanent-
surface runway; 7 with runways 4,000-7,999 ft.
Telecommunications: the system is barely above
average for African countries and consists of thinly
spread open-wire lines, radio-relay links, and
radiocommunication stations; principal centers are
Blantyre, Zomba, Lilongwe, and Muzuzu; 16,800
telephones; 125,000 radio receivers; 5 AM, 4 FM and
no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,041,000; about
528,000 fit for military service','f271526ea691fd77bbcfb38b3b630bea655374cec94292a12cb4c4664e564ef6','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0292c863ed304c9d2855cd459d50a47d7c14206cdbfef2b19620bdb9c927f230',1976,'MY','Malaysia','communications',324,'VL
SOUTH
VIETNAM
South China
Sea :
Jaya Sea
NOTE: Malaysia, which came into being on 16
September 1963, consists of Peninsular Malaysia,
which includes 11 states of the former Federation
of Malaya, plus East Malaysia, which includes
the 2 former colonies of North Borneo (renamed
Sabah) and Sarawak
LAND
Peninsular Malaysia: 50,700 sq. mi; 2096
cultivated, 26% forest reserves, 54% other
Sabah: 29,400 sq. mi.; 13% cultivated, 34% forest
reserves, 53% other
Sarawak: 48,300 sq. mi.; 21% cultivated, 24%
forest reserves, 55% other
Land boundaries: Peninsular Malaysia 315 mi.,
East Malaysia 1,110 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: Peninsular Malaysia, 1,285 mi., East
Malaysia 1,620 mi.
Railroads:
Peninsular Malaysia: 1,035 mi. 3''3%"'' gage; 8 mi.
double track; government-owned
East Malaysia: 96 mi. meter gage in Sabah
Highways:
Peninsular Malaysia: 11,247 mi.; 9,809 mi. hard
surfaced (mostly bituminous surface treatment), 975
mi. crushed stone/gravel, 463 mi. improved or
unimproved earth
East Malaysia: about 2,823 mi. (1,022 in Sarawak,
1,801 in Sabah); 509 mi. hard surfaced (mostly
bituminous surface treatment), 1,858 mi. gravel or
crushed stone, 767 mi. earth
Inland waterways:
Peninsular Malaysia: 1,985 mi.
East Malaysia: 2,540 mi. (975 mi. in Sabah, 1,565
mi. in Sarawak)
Ports:
Peninsular Malaysia: 3 major, 10 minor
East Malaysia: 4 major, 7 minor (8 major, 3 minor
in Sabah; 1 major, 4 minor in Sarawak)
Civil air: 27 major transport aircraft (including 1
Boeing 707 leased from U.K.)
Pipelines: crude oil, 90 mi.; refined products, 35
mi.
Airfields:
Peninsular Malaysia: 73 total, 78 usable; 16 with
permanent-surface runways; 2 with runways 8,000-
11,999 ft., 12 with runways 4,000-7,999 ft.
Sabah: 33 total, 33 usable; 5 with permanent-
surface runways; 1 with runway 8,000 to 11,999 ft.; 4
with runways 4,000-7,999 ft.
Sarawak: 45 total, 45 usable; 5 with permanent-
surface runways; 4 with runways 4,000-7,999 ft.
Telecommunications:
Peninsular Malaysia: good intercity service
provided mainly by microwave relay; international
service good; good coverage by radio and television
broadcasts; 217,000 telephones; 425,000 radio and
129
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MALAYSIA/MALDIVES
355,000 TV receivers; 30 AM stations; no FM, 15 TV
stations; submarine cables extend to India, Ceylon,
and Singapore; connected to SEACOM submarine
cable terminal at Singapore by microwave relay; 1
ground satellite station
Sabah: adequate intercity radio-relay network
extends to Sarawak via Brunei; 18,500 telephones;
35,274 radio receivers; 3,014 TV receivers; 4 AM, 1
FM, 5 TV stations; SEACOM submarine cable links
to Hong Kong and Singapore
Sarawak: adequate intercity radio-relay network
extends to Sabah via Brunei; 22,000 telephones;
104,289 radio and 500 TV receivers; 1 AM, no FM, no
TV stations
DEFENSE FORCES
Military manpower:
Peninsular Malaysia: males 15-49, 2,299,000;
1,456,000 fit for military service
Sabah: males 15-49, 177,000; 113,000 fit for
military service
Sarawak: males 15-49, 252,000; 159,000 fit for
military service; conscription age for Malaysia is 21 —
an age reached by about 122,000 annually
External defense dependent on loose Five Power
Defense Agreement (FPDA) which replaced Anglo-
Malayan Defense Agreement of 1957 as amended in
1963
Military budget: for fiscal year ending 31
December 1975, $442.6 million; about 15% of central
government budget','d0b8f0f48adf08fcd96e068d1aecbd73e30a530dbc89501ed4321e9c97bba14e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93d476709ca5744f5e94f9d001fe097241db489674292155e672edeb6239634e',1976,'MV','Maldives','communications',328,'Arabían
Sea
. J SRI
3 taccadivo LANKA
Sea
MALDIVES `.
Indian Ocean
{See reference map Vit}
LAND
115 sq. mi.; 2,000 islands grouped into 12 atolls,
about 220 islands inhabited
WATER
Limits of territorial waters (claimed): the land
and sea between latitudes 7°9’N. and 0%45''S. and
130
between longitudes 72°30''E. and 73?48''E; these
coordinates form a rectangle of approximately 37,000
sq. n. mi.; territorial sea ranges from 2.75 to 55 n. mi.
Coastline: 400 mi. (approx.)
Railroads: none
Highways: none
Ports: 2 minor
Civil air: 2 major transport aircraft
Airfields: 2 total 2 usable; 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 1
with runway 4,000-7,999 ft.
Telecommunications: minimal domestic and
international telecommunication facilities; 300
telephones; 2,400 radio sets; 1 AM station','1b899127241b82d026cb334294dcf1202ed479805e6144490fdbc8fac41b4577','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('183588dca0cc56f614cf1c371680add64068e19bf39fca2d2f82123768f2ac50',1976,'ML','Mali','communications',332,'(See reference map YI)
LAND
465,000 sq. mi.; only about a fourth of area arable,
forests negligible, rest sparse pasture or desert
Land boundaries: 4,635 mi.
Railroads: 400 mi. meter gage
Highways: approximately 8,200 mi.; 1,010 mi.
bituminous, 1,050 mi. improved earth, 6,140 mi.
unimproved earth
Inland waterways: 1,141 mi. navigable
Civil air: 4 major transport aircraft
Airfields: 42 total, 38 usable; 7 with permanent-
surface runways; 2 with runway 8,000-11,999 ft., 11
with runways 4,000-7,999 ft.
Telecommunications: system poor and provides
only minimum service to government, business, and
public; open-wire and radiocommunication used for
long distance telecommunications; radio sometimes
only link to outlying points; 7,800 telephones; 75,000
radio receivers; 2 AM, no FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,304,000;
732,000 fit for military service; no conscription
Military budget: for fiscal year ending 31
December 1973, $9,954,042; about 16.7% of total
budget
Mediterranean Sea
(Ses reference map NW)
LAND
121 sq. mi; 45% agricultural, negligible amount
forested, remainder urban, waste, or other (1965)
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 87 mi.
Highways: 760 mi., 650 mi. paved (asphalt), 80 mi.
crushed stone or gravel 30 mi. improved and
unimproved earth
Ports: 1 major (Valletta), 2 minor
Civil air: 2 major transport aircraft (both leased)
Airfields: 4 total, 2 usable; 2 with permanent-
surface runways; 2 with runways 4,000-7,999 ft; 1
seaplane station
Telecommunications: modern automatic tele-
phone system centered in Valletta; 48,800 telephones;
140,000 radio and 75,000 television receivers, 3AM,3
FM, and 1 TV stations; 8 submarine cables, including
1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 89,000; 67,000
fit for military service
Supply: has received 2 patrol boats, small arms, and
mortars from Libya; vehicles and engineer equipment
from Italy
Military budget: for fiscal year ending 31 March
1976, $9,079,000; about 4.5% of central government
budget','cc8fdf423af068ae06dcf629e6e7abb972c7e249c34c5dabcde30b753ac9a517','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb377f36524f307d2b895be24441dcb38d4f8a31f868beb332089b40de995ecf',1976,'MR','Mauritania','communications',337,'MAURITANIA |
Nouakchott
Atlantic
Ocean
(See reference map Vij
LAND
419,000 sq. mi. ; less than 1% suitable for crops,
10% pasture, 90% desert
Land boundaries: 3,180 mi.
WATER
Limits of territorial waters (claimed): 30 n. mi.
(fishing, 6 n. mi. exclusive rights, 6 n. mi. contiguous
zone)
Coastline: 490 mi.
Railroads: 400 mi. standard gage, single track,
privately owned
Highways: 9,800 mi.; 350 mi. paved; 380 mi.
gravel, crushed stone, or otherwise improved; 3,070
mi. unimproved
Inland waterways: 500 mi.
Ports: 1 major (Nouakchott), 2 minor
Civil air: 7 major transport aircraft
Airfields: 30 total, 30 usable; 9 with permanent-
surface runways; 1 with runway 8,000-11,999 ft.; 16
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone poor, telegraph
fair; 1,300 telephones; 81,500 radio receivers; 1 AM,
no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 306,000; 146,000
fit for military service; conscription law not
implemented
Supply: primarily dependent on France
Military budget: for fiscal year ending 31
December 1975 (revised), $17,054,253; 16.1% of total
budget','2987c2b634d4c5b4024c6a16dd8521a4207c5d66d1a3a38f6c3b4038b79d3ee5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6231f9625cc66ad4558c5d81af926623c03abcc389fc8c11cb58fcc829d3893',1976,'MU','Mauritius','communications',341,'LAND
720 sq. mi. (excluding dependencies); 50%
agricultural, intensely cultivated, 39% forests,
woodlands, mountains, river, and natural reserves; 3%
built-up areas; 5% water bodies, 2% roads and tracks,
1% permanent wastclands
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 110 mi.
135
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
RÉUNIDN
Indian Ocean
(See reference map VI)
Highways: 1,100 mi.; 990 mi. paved, 110 mi. earth
Civil air: no major transport aircraft
Ports: 1 major (Port Louis), 2 minor
Airfields: 6 total, 5 usable; 1 with permanent-
surface runway; 1 with runway 8,000-11,999 ft.
Telecommunications: 22,600 telephones; radio
telegraph service with Reunion, Malagasy Republic,
Seychelles, Zanzibar, and other places in Africa; 1
AM, no EM, and 4 TV stations; 160,000 radio and
25,300 TV sets; submarine cables extend to Republic
of South Africa and Seychelles Islands
DEFENSE FORCES
Military manpower: males 15-49, 206,000; 103,000
fit for military service
Military budget: for fiscal year ending 30 June
1973, $3,981,038; 6.5% of total budget
(See reference map VI)
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 125 mi.
Railroads: none
Highways: 1,415 mi; 1,155 mi. paved, 260 mi.
gravel, crushed stone, or stabilized earth
Ports: 1 major (Port des Galets)
Civil air: no major transport aircraft
Airfields; 6 total, 6 usable; 1 with permanent-
surface runway; 1 with runway 8,000-11,999 ft., 2
with runways 4,000-7,999 ft.
Telecommunications: adequate system for size of
island of fairly modern open-wire lines and
radiocommunication stations; principal center Saint-
Denis; external radiocommunications to Comoro
Islands, France, Malagasy, and Mauritius; 22,900
telephones; 90,000 radio and 30,200 TV receivers; 2
AM, no FM, and 8 TV stations; 1 satellite ground
station
DEFENSE FORCES
Military manpower: military age males included
with France
RHODESIA
Indian Ocean
“SOUTH AFRICA
p reference mag Vij
LAND
151,000 sq. mi.; 40% arable (of which 6%
cultivated); 60% available for extensive cattle
grazing; European alienated lands (farmed by
modern methods) 39%, African 48%, national land
7%, 6% not alienated
Land boundaries: 1,875 mi.
Railroads: 1,607 mi. narrow gage (3''6"); 26 mi.
double track
Highways: 48,733 mi.; 4,968 mi. paved, 20,415 mi.
crushed stone, gravel, stabilized soil, or improved
earth; 23,350 mi. unimproved earth
Inland waterways: 175 mi. on Lake Kariba
Airfields: 273 total, 272 usable; 8 with permanent-
surface runways; 1 with runway over 12,000 ft., 1 with
runway 8,000-11,999 ft., 23 with runways 4,000-7,999
ft.
Civil air: 10 major transport aircraft
Telecommunications: system is one of the best in
Africa; consists of radio-relay links, open-wire lines,
and radiocommunication stations; principal center
Salisbury, secondary center Bulawayo; 160,300
telephones; 225,000 radio and 58,000 TV receivers; 8
AM, no FM and 2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,420,000;
866,000 fit for military service; average number
reaching military age (18) annually, 63,000
Military budget: for fiscal year ending 30 June
1975, $132,310,192; 17.9% of total budget','9cfeb1f7f7ccdb7d34ba4ba37dbc64feaac807d788826709d848d3d8c19cb00c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33589d5130530ade85112278934635e1f96a805f20164a69d1e241619afe173d',1976,'MC','Monaco','communications',348,'Mediterranean Sea
(See reference map IV}
LAND
0.6 sq. mi.
Land boundaries: 2.3 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2.6 mi.
Railroads: 1 mi (see France)
Highways: none; city streets
Ports: 1 minor
Civil air: no major aircraft
Airfields: none
Telecommunications: served by the French
communications system; automatic telephone system
with about 21,300 telephones; 2 AM, 1 FM, and 1 TV
station; 12,000 radio and 16,000 TV receivers
DEFENSE FORCES
Vrance responsible for defense','8d839497dacc8f133ab921750d0b0d63e76a12012664d80de0173cec7b34f776','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('127924753394d6684109959bbf1f4afc3a06bda5a67ed00bd5937d636619e34a',1976,'MN','Mongolia','communications',352,'q
(See reference map Vil)
LAND
604,100 sq. mi.; almost 90% of land area is pasture
or desert wasteland, varying in uscfulness, less than
1% arable, 10% forested
Land boundaries: 4,975 mi.
Railroads: 909 route mi.; all broad gage (5''0"^)
(1974)
Inland waterways: 385 miles of principal routes
(1975)
Freight carried: rail — 5.1 million short tons, 1,046
million short ton mi. (1974); highway—about 16.0
million short tons (1973); 1,120 million short ton/mi.
(1974)
DEFENSE FORCES
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 3]
December 1975, 268 million tugriks, 10% of total
budget
140','614d86bde7328b7973f5c9b38cc6c4baacbf2cd6ea0e35f9df6a75e6cbf6de5c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('948cadc484490e5b1a48a6f013930f306a1a29de5e94d2dd29f2758576aeef6d',1976,'MA','Morocco','communications',356,'PORTUG
Atlantic
(Sse reference map Vi
LAND
158,100 sq. mi.; about 32% arable and grazing
land, 17% forest and esparto, 51% desert, waste, and
urban
Land boundaries: 1,240 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 70 n. mi.)
Coastline: 1,140 mi.
Railroads: 1,091 mi. standard gage, 93 mi. double
track; 493 mi. electrified
Highways: 32,180 mi; 11,203 mi. bituminous,
3,244 mi. gravel, crushed stone, and improved earth,
17,733 mi. unimproved earth
Pipelines: crude oil, 85 mi.; refined products, 305
mi.; natural gas, 60 mi.
Ports: 8 major (including Spanish-controlled Ceuta
and Melilla), 10 minor
Civil air: 12 major transport aircraft
Airfields: 83 total, 83 usable; 24 with permanent-
surface runways; 2 with runways over 12,000 ft., 11
with runways 8,000-11,999 ft., 36 with runways 4,000-
7,999 ft.; 4 seaplane stations
Telecommunications: superior system by African
standards composed of open-wire lines, coaxial,
multiconductor and submarine cables and radio-relay
links; principal centers Casablanca and Rabat,
secondary centers Fes, Marrakech, Oujda, Sebaa
Aioun, Tangier and Tetouan; 181,000 telephones; 1.5
million radio and 386,000 TV receivers; 24 Moroccan
AM, 1 Voice of America AM, 3 FM, 17 TV stations;
11 submarine cables; 1 satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 3,779,000;
2,242,000 fit for military service; about 185,000 reach
military age (18) annually; limited conscription
Military budget: for fiscal year ending 31
December 1975, $339,248,800; 8.7% of total budget
141
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','e4fc17f887a8ddb75b0b8b2b10dee9931e672fb45f5bd6a428143fd07c9057d7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('106163dbc5eb07457849ea9f344293557640ee8ba0df04c3ec7a353598533926',1976,'MZ','Mozambique','communications',360,'Indían Ücean
¡See reference map VI)
LAND
303,769 sq. mi.; 30% arable, of which 1%
cultivated, 56% woodland and forest, 14% wasteland
and inland water
Land boundaries: 2,875 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,535 mi.','1d4d0bcf3b17d9a840129c2ed2779b53133d5a942b21f813f4ae8f610dae238b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('650a7134320bde0872437d11304365bee736d483e7810b9cd4fef01cb512bb92',1976,'DE','Germany','communications',365,'Railroads: 1,965 mi.; 1,877 mi. 3''6 gage (6 mi.
double track), 88 mi. 2572" gage
Highways: 20,000 mi.; 1,740 mi. paved; 18,260
other (mostly earth)
Inland waterways: approx. 2,330 mi. of navigable
routes
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MOZAMBIQUE/NAURU
Pipelines: crude oil, 190 mi.
Ports: 3 major (Lourenco Marques, Beira, Nacala),
2 significant minor
Civil air; 18 major transport aircraft
Airfields: 332 total, 327 usable; 28 with
permanent-surface runways; 5 with runways 8,000-
11,999 ft.; 39 with runways 4,000-7,999 ft.
DEFENSE FORCES
Military manpower: males 15-49, 2,204,000,
1,108,000 fit for military service
Railroads: 5,465 mi.; 277 mi. meter gage, 4,808
mi. broad gage, 380 mi. narrow gage; 635 mi.
double track; 178 mi. electrified; government owned
Highways: 43,500 mi.; 11,992 mi. paved, 8,040 mi.
gravel, 1,146 mi. improved earth; 22,392 mi. unim-
proved earth
Inland waterways: 1,150 mi.
Pipelines: crude oil, 143 mi.; natural gas, 1,200 mi.
Ports: 1 major, 5 minor
Civil air: 20 major transport aircraft
Airfields: 112 total, 109 usable; 65 with
permanent-surface runways; 1 with runway over
12,000 ft., 25 with runways 8,000-11,999 ft., 50 with
runways 4,000-7,999 ft.
Telecommunications: excellent international
radiocommunication service over CENTO links:
domestic wire and radiocommunieation and
broadcast service very good; 195,325 (est.) telephones;
1,015,000 radio and 125,000 TV sets; 20 AM, no FM,
3 TV stations, and 3 repeaters; 1 ground satellite
station
DEFENSE
Military manpower: males 15-49, 17,093,000;
9,494,000 fit for military service; 833,000 reach
military age (17) annually
Military budget: for fiscal year ending 30 June
1975 $607 million; about 31% of total budget
Railroads: none
Highways: 3,815 mi.; 36 mi. paved, 19 mi. gravel,
1,867 mi. improved earth, 2,398 mi. unimproved;
2,485 mi. secondary roads; most roads improved or
unimproved earth
Inland waterways: Lake Kivu navigable by
steamers and barges
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
—
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
RWANDA/ST. CHRISTOPHER-NEVIS- ANGUILLA
Civil air: 1 major transport aircraft
Airfields: 10 total, 9 usable; 2 with permanent-
surface runways; 2 with runways 4,000-7,999 ft., 1
with runway 8,000-11,999 ft.
Telecommunications: telephone and telegraph
limited; main center is Kigali; 2,480 telephones;
60,000 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 956,000; 462,000
fit for military service; no conscription; 40,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
December 1974, $6,522,000; 17.396 of total budget
ST. CHRISTOPHER-NEVIS-
Railroads: 350 mi., 48%” gage
Highways: 9,300 mi.; 5,600 mi. bituminous, 3,700
mi. gravel and improved carth, undetermined mileage
of earth roads and tracks
Pipelines: crude oil, 1,500 mi.; refined products,
240 mi.; natural gas, 61 mi.
Ports: 3 major (Jidda, Ad Damman, Ras Tanura), 6
minor
Civil air: 17 major transport aircraft
Airfields: 101 total, 79 usable; 23 with permanent-
surface runways; 14 with runways 8,000-11,999 ft., 40
with runways 4,000-7,999 ft., 2 with runways over
12,000 ft.
Telecommunications: excellent international tele-
communications; fair domestic service; 84,100
telephones; 255,000 radio and 150,000 TV receivers;
11 TV, 1 FM, and 4 AM stations; 2 submarine cables;
2 satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 1,453,000;
804,000 fit for military service; about 64,000 reach
military age (18) annually
Military budget: for fiscal year ending 12 July
1975, $2,536 million; about 22% of total budget
Railroads: 3,218 mi.; 2,419 mi. 3''6" gage, 78 mi.
9835" gage, 85 mi. 2''0A" gage, 636 mi. 1''1194"" gage;
532 mi. of 3''6” gage electrified
Highways: 87,800 mi; 1,200 mi. bituminous,
11,800 mi: gravel or crushed stone, 75,300 mi. earth
Inland waterways: comprising the Zaire, its
tributaries, and unconnected lakes, the waterway
systern affords over 9,320 mi. of navigable routes
Ports: 2 major (Matadi, Boma), 1 minor
Pipelines: refined products, 460 mi.
Civil air: 37 major transport aircraft
Airfields: 385 total, 294 usable; 20 with
permanent-surface runways; 1 with runway over
12,000 ft., 2 with runways 8,000-11,999 ft., 54 with
runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: limited, barely adequate
telephone service, telegraph service good; 25,000
telephones; 100,000 radio receivers; 7,100 TV
receivers; 12 AM, 1 FM, and 2 TV stations; 1 satellite
ground station
DEFENSE FORCES
Military manpower: males 15-49, 5,963,000;
2,986,000 fit for military service
Military budget: for fiscal year ending 31
December 1974, $147,033,460; about 16.5% of total
budget','e0e8997661f9f2b4632d9c0bafd89a065fe8c8e259d779327fda0458b9c39a09','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5d3673c8eaa5fb50223174d978b743267dfa57eb493bd55eaeb659002a4c2b9',1976,'NR','Nauru','communications',366,'NAURU»
a Pacific Ocean
a
m
bl
Coral Sea
(See reference map VIII)
LAND
8.2 sq. mi; insignificant arable land, no urban
areas, extensive phosphate mines
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 15 mi.
Railroads: none
Highways: about 17 mi; 13 mi. paved, 4 mi.
improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 3 major transport aircraft
Airfields: 1, coral-surfaced, 5,270 ft.
Telecommunications: adequate intraisland and
international radiocommunications provided via
Australian facilities; 540 telephones; 3,575 radio
receivers, 1 AM, but no TV or FM radiobroadcasting
facilities
DEFENSE FORCES
Military manpower: males 15-49, about 1,800; fit
for military service, about 1,000; average number
reaching military age (18) annually, 1975-79, less than
100
No formal defense structure and no regular armed
forces
143
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','a4a2835326ffb5bc2ab8b04b43ba9018fb9f5eca7dabb84904a6a1e1ee5f43e9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ce2d9e350ef521695549d8c21d41772fbae67b4ffadd7fa83ca771330bb2c99',1976,'NP','Nepal','communications',370,'Bay
of Bengal
(See reference map VII)
LAND
54,600 sq. mi.; 16% agricultural area, 14%
permanent meadows and pastures, 38% alpine land
(unarable), waste, or urban; 32% forested
Land boundaries: 1,720 mi.
Railroads: 105 mi., all narrow gage (2''6’’); mostly
government owned; all in Terai close to Indian
border; only 33 mi. sector from border to Bizalpura
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NEPAL/NETHERLANDS
presently in use; a 28 mi. segment has been
abandoned and 44 mi. utilized to transport rock from
quarry near Dharau to Kosi Dam near Rajbiras
Highways: 1,686 mi; 510 mi. paved, 270 mi.
gravel or crushed stone, 906 mi. improved and
unimproved earth, 200 mi. of seasonally motorable
tracks
Civil air: 5 major transport aircraft
Airfields: 57 total, 56 usable; 5 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 6
with runways 4,000-7,999 ft.
Telecommunications: poor telephone and tele-
graph service; good radiocommunication and
broadcast service; international radiocommunication
service is poor; 9,162 telephones, 76,000 radio and no
TV sets, 3 AM, no FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 8,073,000;
1,550,000 fit for military service; 140,000 reach
military age (17) annually
Military budget: for fiscal year ending 15 July
1975, $9.7 million; 5.696 of total budget','0e99998c9227a5e2773ac0699857aa973ef08c35a6992310b5a0c705f7b26a9e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07ebca65a55cd3c4d9668c817cfdca5b19fd3b2b2a56a128683455e7034a279f',1976,'NC','New Caledonia','communications',374,'Coral Sea x:
NEWS”
CALEDONIA Pacific
Ocean
Tasman Sea t
NEW
Š ZEALAND
(See reference map VII!)
LAND
8,500 sq. mi; 6% cultivable, 22% pasture land,
15% forests, 57% waste or other
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 3 n. mi.)
Coastline: 1,400 mi.','e9484031cb9c6b89bf055006434dc98b260f7bbc77ce421f93a484fc81ff37da','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b63618774a6da1e3c6600296b5938ed1c0b165c36a3740285ae40954fb92933',1976,'NZ','New Zealand','communications',376,'LAND
103,736 sq. mi.; 3% cultivated, 50% pasture; 10%
parks and reserves; 20% waste, water, etc., 1% urban,
16% forested; 4 principal islands, 2 minor inhabited
islands, several minor uninhabited islands
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: about 9,400 mi.
Railroads: 2,982 mi.; all 3''6" gage; 170 mi. double
track; 70 mi. electrified; over 99% government owned
Highways: 57,400 mi. (1974); 27,925 mi. paved,
29,475 mi. gravel or crushed stone
Inland waterways: 1,000 mi.; of little importance
to transportation
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NEW ZEALAND/NICARAGUA
Pipelines: natural gas, 488 mi.
Ports: 3 major
Civil air: 57 major transport aircraft
Airfields: 182 total, 177 usable; 22 with
permanent-surface runways; 2 with runways 8,000-
11,999 ft., 48 with runways 4,000-7,999 ft.; 4 seaplane
stations
Telecommunications: excellent international and
domestic systems; 1,410,532 telephones; 2,700,000
radio and 760,847 TV sets; 60 AM stations in 31 cities,
no FM, and 4 TV stations, and 120 repeaters;
submarine cables extend to Australia and Fiji Islands;
1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 723,000; 610,000
fit for military service; average number reaching
military age (20) annually about 25,000
Military budget: proposed for fiscal year ending 31
March 1976, $238.3 million; about 4% of central
government budget','b436d8e10f01f488e6cbf2ef74c4459ee1280eb1da34c1bbf0ac4e769c19c7e1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf589694d7ee6e9f5070dacbe5a19ca3a76aa153cd55754e3f4d100980982596',1976,'NI','Nicaragua','communications',380,'Caribbean Sea
Managua
Pacitic Ocean
(See reference mag li}
LAND
57,100 sq. mi.; 7% arable, 7% prairie and pasture,
50% forest, 36% urban, waste, or other
Land boundaries: 760 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 200 n. mi; continental shelf, including
sovereignty over superjacent waters)
Coastline: 565 mi.
Railroads: 220 mi; 200 mi of 3''6" gage,
government owned; 20 mi. narrow gage, privately
owned
Highways: 8,050 mi; 850 mi. paved, 3,200 mi.
otherwise improved, 4,000 mi. unimproved
Inland waterways: 1,380 mi., including 2 large
lakes
Pipelines: crude oil, 45 mi.
Ports; 4 major (Carinto, Puerto Cabezas, Puerto
Somaza, San Juan del Sur), 6 minor
Civil air: 10 major transport aircraft
Airfields: 421 total, 414 usable; 6 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 8
with runways 4,000-7,999 ft.: 2 seaplane stations
Telecommunications: low-capacity wire and
radio-relay network; connection into Central
American microwave net; satellite ground station;
18,500 telephones; est. 700,000 radio and 75,000 TV
receivers; 75 AM, 30 FM, and 7 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 516,000; 316,000
fit for military service; 23,000 reach military age (18)
annually
Military budget: for fiscal year ending 81
December 1975, $19.7 million for the Ministry of
Defense, including civil functions (e.g., police and
civil air); 7.4% of central government budget
ee mu qu d EE','508a4a37b07c2ce9fb718ae13f63dc120106b6871d45b18d8627697612a3dba2','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e00c8e1b3eccaf146f369088503c4a63e631e8c24cc23bb19fb43ceaacff1058',1976,'NE','Niger','communications',384,'Niame
Pee
"BENIN
Gulf of Guinea
(See reference map Vi}
LAND
489,000 sq. mi.; about 3% cultivated, perhaps 20%
somewhat arable, remainder desert
Land boundaries: 3,570 mi.
Railroads: none
Highways: approx. 4,640 mi.; 580 mi. bituminous,
1,640 mi. gravel, 2,420 mi. unimproved earth
Inland waterways: Niger River navigable 185 miles
from Niamey to Gaya on the Dahomey frontier from
mid-December through March
Ports: Niger landlocked; outlet to sea is Cotonou,
Dahomey
Civil air: 5 major transport aircraft
Airfields: 63 total, 60 usable; 5 with permanent-
surface runways; 1 with runway 8,000-11,999 ft.,
17 with runways 4,000-7,999 ft.
Telecommunications: principal telecommunica-
tion center Niamey; telephone poor, telegraph fair,
8,300 telephones; 100,000 radio and 500 TV receivers;
4 AM, no FM, and 1 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,042,000,
556,000 fit for military service; about 43,000 reach
military age (18) annually','4d4380b112a4e026fd07005352cb0579035150dfc57928f13bdc241f6eb1e3ea','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bc6c29019bdc052c86dfdfafbe4eaec14bed57ef63a401f896550aaa93c118e',1976,'NG','Nigeria','communications',388,'Lagos
Bul ©
voaf Guinda *
(Sea reference map VI)
LAND
357,000 sq. mi.; 24% arable (13% of total land area
under cultivation), 35% forested, 41% desert, waste,
urban, or other
Land boundaries: 2,507 mi.
WATER
Limits of territorial waters (claimed): 30 n. mi.
Coastline: 530 mi.
158
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Railroads: 2,180 route mi.; 3''6" gage
Highways: 55,425 mi.; 9,500 mi. paved (mostly
bituminous surface treatment); 45,925 mi. laterite,
gravel, crushed stone, improved earth
Inland waterways: 5,330 mi. consisting of Niger
and Benue rivers and smaller rivers and creeks;
additionally, the newly formed Kainji Lake has
several hundred miles of navigable lake routes
Pipelines: crude oil, 645 mi.; natural gas, 40 mi.;
refined products, 3 mi.
Ports: 2 major (Lagos, Port Harcourt), 10 minor
Civil air: 17 major transport aircraft
Airfields: 91 total, 77 usable; 15 with permanent-
surface runways; 5 with runways 8,000-11,999 ft., 25
with runways 4,000-7,999 ft.; 4 seaplane stations
Telecommunications: composed of radio-relay
links, open-wire lines, and radiocommunication
stations; principal center Lagos, secondary centers
Ibadan and Kaduna; 106,300 telephones; 5 million
radio and 90,000 TV receivers; 25 AM, 6 FM, and 8
TV stations; 2 submarine cables; 1 satellite ground
station
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NIGERIA/NORWAY
DEFENSE FORCES
Military manpower: males 15-49, 14,199,000;
8,233,000 fit for military service; average number
reaching military age (18) annually 740,000
Military budget: for fiscal year ending 31 March
1976, $1,283,400,000; 17.9% of total budget
xLagos
Lomé
Eq. Guinea
fs Sao Tome and
M Principe e
South
Atlantic
Ocean
1000 Miles
1000 Kilometers
VI Africa
U. S. S. R.
a Öp
< Caspian
Sea
Ei Cyprus
Mediterranean Sea p,
Israeli.
a
N,
Port Sudan el SN
\\Red Y
S
M
Khartoum, — Ag','1c8651fb7da9a91ef2761dd558326f0b3e1a2665b8f3f599ff6272f70e851082','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef97455a7f562f7bed60b9e0961addd876c3230755c1f4fee227e593f23205c0',1976,'NO','Norway','communications',392,'- Norwegian.
MIRES
(See reference E
LAND
Norway: 125,000 sq. mi.; Svalbard, 24,000 sq. mi.;
Jan Mayen, 144 sq. mi.; 3% arable, 296 meadows and
pastures, 21% forested, 74% other
Land boundaries: 1,603 mi.
WATER
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.)
Coastline: mainland 2,125 mi.; islands 1,500 mi.
(excludes long fjords and numerous small islands and
minor indentations which total as much as 10,000 mi.
overall)
Railroads: 2,662 mi.; State (NSB) operates 2,636
mi. standard gage, 2,589 mi. single track, 1,516 mi.
electrified, 47 mi. double track; 10 mi. standard gage
electrified privately owned; 16 mi. meter (3834) gage
electrified privately owned
Highways: 46,000 mi.; 9,000 mi. paved, 37,000 mi.
crushed stone and gravel
Inland waterways: 980 mi.; 5-8 ft. draft vessels
maximum
Pipelines: refined products, 33 mi.
Ports: 9 major, 69 minor
Civil air: 54 major transport aircraft
156
Airfields: 93 total, 93 usable; 48 with permanent-
surface runways; 10 with runways 8,000-11,999 ft., 14
with runways 4,000-7,999 ft.; 20 seaplane stations
Telecommunications: high-quality domestic and
international telephone, telegraph, and telex service;
1.38 million telephones; 2.2 radiobroadcast and 1.02
million TV receivers; 36 AM, 316 FM, and 654 TV
stations; 5 coaxial submarine cables; COMSAT
station
DEFENSE FORCES
Military manpower: males 15-49, 918,000; 755,000
fit for military service; average number reaching
military age (20) annually, 32,000','c9d1c278c0ab1fce3ab91e1b8aa309a449eb2adedd202b469ca596587c74792b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b71428200dfb68b01db2090dd7d14a2255ea8033c39e2648ffef09bbe8cb4bb',1976,'OM','Oman','communications',396,'Arabian Sea
(See reference mi Vy
LAND
About 82,000 sq. mi.; negligible amount forested,
remainder desert, waste, or urban
Land boundaries: 860 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing 50 n. mi.)
Coastline: 1,300 mi.
Highways: 1,750 mi. total; 3 mi. bituminous
surface, remainder motorable natural-surface track
Pipelines: crude oil 230 mi.
Ports: 1 major (Qaboos), 6 minor
Civil air: no major transport aircraft
Airfields: 145 total, 189 usable; 5 with permanent-
surface runways; 3 with runways 8,000-11,999 ft., 51
with runways 4,000-7,999 ft.
Telecommunications: fair international and
domestic service; 3,400 telephones; 1 AM station
DEFENSE FORCES
Military manpower: males 15-49, 118,000; 68,000
fit for military service
Military budget: for fiscal year ending December
1974, est. $87,000,000, about 14.9% of total budget
Approved For Release 2005/04/22 :
TE
"Pert DUM Red
: Sea
A
ra \\
Arabian
A.
~~ Socatra','60e3d32df332b4a3da991b5dfadd51c1cda719826a6ba43eebf09b11043782cc','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f008b36eba338fb92058bb6f6a6f38e5cac7a0c31c9e276a6610c633d6928d4',1976,'PK','Pakistan','communications',400,'PAKISTAN Z
Arabian Sea
{See reference map VII)
LAND
310,000 sq. mi. (includes Pakistani part of Jammu-
Kashmir); 40% arable, including 24% cultivated; 23%
unsuitable for cultivation; 34% unreported, probably
mostly waste; 3% forested
Land boundaries: 3,650 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing 50 n. mi.; plus right to establish 100 n. mi.
conservation zones beyond territorial sea)
Coastline: 650 mi.','bce14a6244b402661a9be306a49d2b2484c90f376950d68328af198c008eedbf','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08306d40ad6fda68054913ae4cd69bcfd0789c6bc01280f278afefa0f40471be',1976,'PA','Panama','communications',404,'Caribbean Sea
Pacific Ocean
(See reference map tt)
LAND
29,208 sq. mi. (excluding Canal Zone, 553 sq. mi.);
24% agricultural land (9% fallow, 49; cropland, 11%
pasture), 20% exploitable forest, 56% other forests,
urban, and waste
Land boundaries: 390 mi.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
WATER
Limits of territorial waters (claimed): 200 n. mi.
(continental shelf including sovereignty over super
jacent waters)
Coastline: 1,545 mi.
Railroads: 305 mi.; 48 mi. 5''0” gage, 107 mi. 3''0”
gage; 150 mi. plantation feeder lines
Highways: 4,450 mi.; 1,400 mi. paved, 1,150 mi.
gravel or crushed stone, 1,900 mi. improved and
unimproved earth; Panama Canal Zone 145 mi.; 140
mi. paved; 5 mi. gravel
Inland waterways: 500 mi. navigable by shallow
draft vessels; 51-mile Panama Canal
159
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PANAMA/PAPUA NEW GUINEA
Pipelines: refined products, 60 mi.
Ports: 2 major (Cristobal/Colon/Coco Solo,
Balboa/Panama City), 10 minor
Civil air: 27 major transport aircraft
Airfields: 121 total, 119 usable; 26 with
permanent-surface runways; 3 with runways 8,000-
11,999 ft.; 13 with runways 4,000-7,999 ft.; 2 seaplane
stations
Telecommunications: domestic and international
telecom facilities well developed, including nearly
nationwide radio-relay system; connection into
central American microwave net; communications
satellite ground station; 127,000 telephones; 575,000
radio and 240,000 TV receivers; 80 AM, 30 FM, and
13 TV stations; 1 coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 366,000; 252,000
fit for military service; no conscription
Military budget: for fiscal year ending 31
December 1972, $18 million; about 11% of central
government budget','b366caa0bb124fec7bd3d01d41a799882c20dd4705dc01dedf58cef82836d154','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3e88223e091760bca97d0302002d3f378c0d09b9efabfc52835cfec4a0cf145',1976,'PY','Paraguay','communications',408,'LAND
157,000 sq. mi.; 2% under crops, 24% meadow and
pasture, 52% forested, 22% urban, waste, and other
Land boundaries: 2,140 mi.
Railroads: 652 mi.; 273 mi. standard gage, 85 mi.
3''3%" gage, 294 mi. various narrow gage (privately
owned)
162
Highways: 9,900 mi.; 400 mi. bituminous treated,
3,100 mi. otherwise improved, 6,400 mi. unimproved
earth
Inland waterways: 1,970 mi.
Ports: 1 major (Asuncion), 9 minor (all river)
Civil air: 7 major transport aircraft
Airfields: 917 total, 822 usable; 1 with permanent-
surface runway; 2 with runways 8,000-11,999 ft., 22
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: local telecom facilities in
Asuncion good, intercity microwave net; 33,000
telephones; 750,000 radio and 60,000 TV receivers: 25
AM, 8 FM, and 1 TV station; COMSAT station under
construction
DEFENSE FORCES
Military manpower: males 15-49, 614,000; 465,000
fit for military service; average number currently
reaching military age (17) annually, 28,000','45efba45cf5c6ddf346567eb666372b86ca4ac3ae1262c8d518083a99dc12a67','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f80e571d731e7ba68fb30b8efac537ace8ee454a73a8ec05190594776b1756b8',1976,'PE','Peru','communications',412,'Pacific
(See reference map {it}
LAND
496,000 sq. mi. (other estimates range as low as
482,000 sq. mi.); 2% cropland, 14% meadows and
pastures, 55% forested, 29% urban, waste, other
Land boundaries: 3,810 mi.
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,500 mi.
Railroads: approx. 1,560 mi; 1,227 mi. 4’8%"
gage; 41 mi. gage less than 3''0"; 282 mi. 3''0" gage; 9
mi. double track
Highways: 31,500 mi.; 3,100 mi. paved, 6,200 mi.
gravel or crushed stone, 9,200 mi. improved earth,
1,800 mi. unimproved earth
Inland waterways: 5,400 mi. of navigable
tributaries of Amazon River system and 130 mi. Lake
Titicaca
Pipelines: crude oil, 200 mi.; natural gas and
natural gas liquids, 40 mi.
Ports: 7 major, 20 minor
Civil air: 34 major transport aircraft
Airfields: 306 total, 306 usable; 22 with
permanent-surface runways; 2 with runways over
12,000 £t., 19 with runways 8,000-11,999 ft., 49 with
runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fairly adequate for most
requirements; new radio-relay system under
163
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PERU/PHILIPPINES
construction; communications satellite ground
station; 335,000 telephones; 2.2 million radio and
500,000 TV receivers; 200 AM, 7 FM, and 31 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 3,355,000;
2,273,000 fit for military service; average number
currently reaching military age (20) annually, 150,000
Military budget: a biennial budget for 1 January
1975 through 31 December 1976, $871 million; about
15.296 of central government biennial budget','8fe4a0888e8cc6fb797cca94f22aa6ec9c992de7cd3d542b8ec5fcd7f6f74845','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc6ce63aeb1a9f34d3ed9307cdee8c40983e950751740354b94aa85526afd5e2',1976,'PL','Poland','communications',416,'LAND
120,600 sq. mi.; 49% arable, 14% other
agricultural, 27% forested, 10% other
Approved For Release 2005/04/22 :
(See reference map IV}
Land boundaries: 1,920 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 305 mi.
Railroads: 16,530 route mi.; 14,450 mi. standard
gage, 2,080 mi. narrow gage; 4,645 mi. double track;
3,225 mi. electrified; government owned (1975)
Highways: 190,095 mi.; 40,390 mi. paved; 39,480
mi. crushed stone, gravel; 110,225 mi. earth
(improved and unimproved) (1974)
Inland waterways: 3,158 mi navigable streams
and canals (1975)
Pipelines: 2,200 mi. for natural gas; 875 mi. for
crude oil; 200 ħi. for refined products
Freight carried: rail — 499.3 million short ton,
85.6 billion short ton/mi. (1974); highway 1,550.0
million short tons, 18,5 billion short ton/mi. (1974);
waterway—12.8 million short tons, 1.5 billion short
ton/mi. excl. int. transit traffic (1974)
Ports: 4 major (Gdansk, Gdynia, Szczecin,
Swinoujscie), 6 minor (1975)
DEFENSE FORCES
Military budget announced: for fiscal year ending
31 December 1975, 49.9 billion zlotys; about 8.4% of
total budget and 4.8% of est. GNP','5cc13e600af58d5f0fef55244b05d01c74d83cbab8c4edd08b314f3bdf5d53b8','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ac40109f56535735d6ec6f2178a0918cfc9b6f4dcc0038eea4b1d2e27adbaec',1976,'PT','Portugal','communications',420,'Atlantic
(See reference mop IV}
LAND
Metropolitan Portugal: 36,400 sq. mi., including
the Azores and Madeira Islands; 48% arable, 6%
meadow and pasture, 31% forested, 15% waste and
urban, inland water, and other
Land boundaries: 750 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 535 mi. (excludes Azores (440 mi.) and
Madeira (140 mi.))
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Railroads: 2,230 mi.; 472 mi. meter gage (3''3%”),
1,758 mi. broad gage (5/5949); 265 mi. double track;
268 mi. electrified
Highways: 18,500 mi; 11,000 mi. bituminous,
bituminous treatment, concrete and stoneblock; 7,200
mi. gravel and crushed stone; 300 mi. improved earth;
plus an additional 10,500 mi. of unimproved earth
roads (motorable tracks)
Inland waterways: 508 mi. navigable; relatively
unimportant to national economy, used by shallow-
draft craft limited to 330-ton cargo capacity
Pipelines: crude oil, 7 mi.
Ports: 6 major, 34 minor
Civil air: 30 major transport aircraft
Airfields (including Azores and Madeira Islands):
61 total, 54 usable; 31 with permanent-surface
runways; 1 with runway over 12,000 ft., 10 with
runways 8,000-11,999 ft, 10 with runways 4,000-
7,999 ft.; 6 seaplane stations
Telecommunications: facilities are generally
adequate; 1.05 million telephones; 1.8 million radio
and 725,000 television receivers: 38 AM, 34 FM, and
40 TV stations; 2 coaxial submarine cables; COMSAT
station
DEFENSE FORCES
Military manpower: males 15-49, 2,079,000;
1,686,000 fit for military service; average number
reaching age (20) annually, about 75,000
Military budget: proposed for fiscal year ending 31
December 1975, $762.2 million; about 33% of central
government budget
168
PORTUGUESE TIMOR
INDONESIA à
d
2
v dee ro PORTUGUESE
$ ,& Uii TIMOR
Ya
Arafura Sea
{Sae reference map Vist}
LAND
7,000 sq. mi.; 34% forest, 33% grassland, and 33%
cultivated
Land boundaries: 90 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 400 mi.
Railroads: none
Highways: 463 mi; 293 mi. gravel or crushed
stone, 170 mi. improved and unimproved earth
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 11 total, 10 usable; 1 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 5
with runways 4,000-7,999 ft.
Telecommunications: domestic and international
radio stations used primarily for administrative and
military purposes; 1 low-power AM radiobroadcast
station; unreliable open-wire lines and 58 small
manual switchboards serve 912 telephones; 13,500
radio sets','c75181c0f924ef35c9b4afa269f22b617041bc89c7d9e9d46d62e72f51654d64','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('526ad2b49835d6fd95916d7e1261f85a0b8437442497cc7691781e3cf56d1e8d',1976,'QA','Qatar','communications',424,'LAND
About 4,000 sq. mi.; negligible amount forested;
mostly desert, waste, or urban
Land boundaries: 35 mi.
^ SAUDLARABIA. =
(Ses reference map VJ
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 350 mi.
Railroads: none
Highways: 275 mi. bituminous; 225 mi. gravel
surfaced; undetermined mileage of earth tracks
Pipelines: crude oil, 105 mi.; natural gas, 60 mi.
Ports: 1 major (Ad Dawhah), 1 minor
Airfields: 2 total, 1 usable; 1 with permanent-
surface runway over 12,000 ft.
Civil air: 1 major transport aircraft, registered in
the U.S.
Telecommunications: all international telecom
traffic is by tropospheric scatter through Bahrain; fair
domestic facilities; 16,125 telephones; 35,000 radio
and 28,500 TV receivers; 1 AM and 1 TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 41,000;
about 24,000 fit for military service
Supply: mostly from U.K.
Military budget: for fiscal year ending 24 January
1974, $53,680,900; 18% of total budget
REUNION
LAND
970 sq. mi.; two-thirds of island extremely rugged,
consisting of volcanic mountains; 120,000 acres (less
than one-fifth of the land) under cultivation
170
Indian','dcdf332b6aabdff3501da6b87d25b4c01ba00d05b00d72ec4928d5ee596cd181','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b92fab7f369eaa2ecdc44c45324b4d97ba652c708c2857c1de209b5b1914e492',1976,'RO','Romania','communications',428,'LAND
91,700 sq. mi.; 44% arable, 19% other agriculture,
27% forested, 10% other
Land boundary: 1,845 mi.
WATER
Limits of territorial waters (claimed): 112 n. mi.
Coastline: 140 mi.
Railroads: 7,464 mi.; 6,442 mi. standard gage,
1,014 mi. narrow gage, 8 mi. broad gage; 569 mi.
electrified, 850 mi. double track; government owned
(1974)
Highways: 48,000 mi.; 7,600 mi. paved; 16,300 mi.
other improved surfaces, 24,100 mi. earth (1974)
Inland waterways: 1,445 mi. (1975)
Pipelines: crude oil, 1,600 mi.; refined products,
888 mi.; natural gas, 9,100 mi.
Freight carried: rail — 2395 million short tons,
37.4 billion short ton/mi. (1974); highway — 579.8
million short tons, 5.7 billion short ton/mi.
(1974); waterway — 6.4 million short tons, est. 1.4
billion short ton/mi. (excl. int''l. transit traffic) (1974)
173
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ROMANIA/RWANDA
Ports: 4 major (Constanta, Galati, Braila,
Mangalia), 2 minor (1975)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 31 December 1975, 9.7 billion lei; about 4.1%
of total budget','3874d28684a477dcb28e31f2a8f163445e3b36fa995c33100a1f617917e4d2fa','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1c65ad906bfd6ed5c2e955a2ce69d88a5b723c826ba251dd620701eb14c9cc1',1976,'RW','Rwanda','communications',432,'(See reference map VI)
LAND
10,000 sq. mi.; almost all the arable land, about Y
under cultivation, about % pastureland
Land boundaries: 545 mi.','32c9465557e61d10d1807b053a77c1bd345823a7ca5f187dacb87bf94308a6d4','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ba4b52cab8ab8bd85596596265181ae576d5471318a75560a620588227fcf88',1976,'AI','Anguilla','communications',436,'S gx
3
(See reference map I!)
LAND
150 sq. mi.; 4076 arable, 10% pasture, 17% forest,
33% wasteland and built-on
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.
Railroads: 36 mi., narrow gage (2/6") on St. Kitts
for sugar cane
Highways: 180 mi.; 60 mi. paved, 90 mi. otherwise
improved, 30 mi. unimproved earth
Ports: 3 minor (1 on each island)
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 1 with asphalt runway
7,600 ft.
Telecommunications: good interisland VHF radio
connections and international link via Antigua; about
1,800 telephones; 10,000 radio and 1,6600 TV
receivers; 3 AM and 5 TV stations
ST. LUCIA
Atlantic Ücean
`
* ST. LUCIA
(See reference man [jl
LAND
238 sq. mi.; 50% arable, 3% pasture, 19% forest, 5%
unused but potentially productive, 23% wasteland
and built-on
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline; 98 mi.
Railroads: none
Highways: 415 mi; 175 mi. paved; 240 mi.
otherwise improved
Ports: 1 major (Castries), 1 minor
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ST. LUCIA/ST. VINCENT
Civil air: 2 major transport aircraft
Airfields: 2 airfields with permanent surface
runways; one with a 9,000 foot runway; one with a
5,700 foot runway; 2 seaplane stations
Telecommunications: fully automatic telephone
system with 6,500 telephones; direct radio link with
Martinique; interisland tropospheric links to Barbados
and Antigua; 25,000 radio and 600 TV receivers; 3
AM, and 1 TV station
ST. VINCENT
Atlantic Ocean
` E: "
Caribtean Sea 700008
P st. VINCENT
{See reference mag tf}
LAND
150 sq. mi. (including northern Grenadines); 50%
arable, 3% pasture, 44% forest, 3% wasteland and
built-on
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 52 mi.
Railroads: none
Highways: 1,100 mi.; 400 mi. paved; 600 mi.
otherwise improved; 100 mi. unimproved earth
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Airfields: 3 total; 2 usable, 1 with asphalt runway
4,800 ft.
Telecommunications: islandwide fully automatic
telephone system with 4,800 instruments; VHF
interisland links to Barbados and the Grenadines;
10,000 radio and 600 TV reccivers; 2 AM stations
177
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','7bf0ec280cccba4c196d63ec1972a4d8743c4bb932df4293976a8eee7d78921f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e107fdde315cbc2d63c9b2d64aedda80aa91df0a5d7e8cf30e5943a99b8d384d',1976,'SM','San Marino','communications',440,'"pa
RV m f
Mediterranean Sea
(See reference map IV]
LAND
24 sq. mi: 74% cultivated, 29% meadows and
pastures, 4% built-on
Land boundaries: 21 mi.
Railroads: none
Highways: about 65 mi.
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system
serving 5,000 telephones; no radiobroadcasting or
television facilities, 4,400 radio and 3,300 TV receivers
(Italian broadcasts)','ee680f91acf7d31d379b84431a303fe12633441482039ffc81914a8f567799f7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c4f30ee112cb357bb0f16b309067793476bcb29a449e9b1c3fb18c749f83825',1976,'ST','Sao Tome and Principe','communications',443,'(See reference ae V)
LAND
372 sq. mi. (Sao Tome, 380 sq. mi. and Principe, 42
sq. mi.; including small islets of Pedras Tinhosas)
Approved For Release 2005/04/22 :
WATER
Limits of territorial waters: 6 n. mi. (fishing, 12 n.
mi.)
Coastline: cstimated 130 mi.
Airfields: 4 total, 4 usable: 2 permanent surface
runways; 2 with runways 4,000-7,999 ft.
DEFENSE FORCES
A company of 150 local troops has been formed into
a fledgling army.','a388b9634ddb1694e6b636f4db6d5e6abb3aa3d9d977a6fcda43c18b75f26be4','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3230f041b7567d7ffcf25b74d53c1a4dbd0ff22598e555164ab046fcdc93df9b',1976,'SA','Saudi Arabia','communications',447,'Riyadh
SAUDI
ARABIA
" Arabian
Sea
{See reference map Vj
LAND
Estimated at about 900,000 sq. mi. (boundaries
undefined and disputed): 1% agricultural, 1%
forested, 98% desert, waste, or urban
Land boundaries: 2,820 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(plus 6 n. mi. "necessary supervision zone’)
Coastline: 1,560 mi.','4b7109985d0340b6222e14f3ab4e3688dd8191ce6902b619fab9935c63b58e76','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c56d6308b7e6ec9c4e0327cb5b9083b4e7e51b4a86531cbfcbbdeea9abceca78',1976,'SC','Seychelles','communications',451,'Indian Ocean
SEYCHELLES :;
(See reference map VI)
LAND
156 sq. mi.; 54% arable land, nearly all of it is
under cultivation, 17% wood and forest land, 29%
other (mainly reefs and other surfaces unsuited for
agriculture); 40 granitic and 43 coral islands
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing 12 n. mi.)
Coastline: 305 mi. (Mahe Island 58 mi.)','ba7fee4accaf81e2a5f73f0c0e392af123d64dc3b9ce686fbad03a57ce26e4d1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f63bff7ef12d7177e047bba3ba0d903d121dd94c4f2e738b321ca8da3ce80b8',1976,'SL','Sierra Leone','communications',455,'GHNE.
BISSAU
Atlantic
Ocean
(See reference map Vl)
LAND
27,900 sq. mi.; 65% arable (6% of total land area
under cultivation), 27% pasture, 4% swampland, 4%
forested
Land boundaries: 580 mi.
183
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline:.250 mi.
Railroads: about 60 mi. narrow gage (3''6")
privately owned mineral line operated by the Sierra
Leone Development Company
Highways: 5,130 mi. 550 mi. bituminous
(including some bituminous treatment), 1,470 mi.
laterite (some gravel), and 3,110 mi. earth
Inland waterways: 500 mi.; 372 mi. navigable
year-round
Ports: 1 major (Freetown), 2 minor
Civil air: no major transport aircraft
Airfields: 15 total, 15 usable; 5 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 4
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications; telephone and telegraph are
adequate: 7,850 telephones; 61,000 radio and 6,000
TV receivers; 1 AM, no FM, and 1 TV stations; 3
submarine cables
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SIERRA LEONE/SINGAPORE
DEFENSE FORCES
Military manpower: males 15-49, 640,000; 307,000
fit for military service; no conscription
Military budget: for year ending 30 June 1975,
$9,548,203; 6.97% of total budget','c7ddc27498437026d9cc0daf8d39f20b1982c5e7f1cb70e0eea20d681d5dfe8d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('add1ec5b92430a79e45d4dae5a1f3e94fb2c0ca994e5e150bb85c7617f3e0895',1976,'SG','Singapore','communications',459,'South
China Sea J
(Sea reference map Vil}
LAND
225 sq. mi.; 31% built up area, roads, railroads, and
airfields, 22% agricultural, 47% other
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.
Organized labor: 24% of labor force
Railroads: 24 mi. of meter gage
Highways: 1,340 mi. (1974); 1,035 mi. paved, 305
mi. crushed stone or improved earth
Ports: 3 major
Civil air: 19 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 9
with runways 4,000-7,999 ft.
Telecommunications: adequate domestic facilities:
good international service; good radio and television
broadcast coverage; 350,159 telephones; 311,409
radio and 240,314 TV sets; 2 AM, 5 FM, and 2 TV
stations; new seacom submarine cable extends to
Hong Kong via Sabah, Malaysia; 1 ground satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 596,000; 424.000
fit for military service
Military budget: for fiscal year ending 31 March
1976, $335 million; about 18% of total budget','32c98a973de2853e3c2ba7ca02ff1036bedf047acbca80ccc0ddac1f369fe610','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fc52c30de083ce753015291a2493ee3c64f56e4266b4854cdd8be49d17b6211',1976,'SO','Somalia','communications',463,'^ SOMALIA
T d s
egadiscio
Indian
Ücean
(See reference map VI)
LAND
246,000 sq. mi.; 13% arable (0.3% cultivated), 32%
grazing, 14% scrub and forest, 41% mainly desert,
urban, or other
Land boundaries: 1,406 ini.
186
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,880 mi.
Railroads: none
Highways: 8,414 mi; 582 mi. paved; 478 mi.
crushed stone, gravel, or stabilized soil; 7,854 mi.
improved or unimproved earth
Inland waterways: Fiume Giuba navigable 345 mi.
from May to mid-June and August to late November
machinery, construction
Ports: 3 major (Mogadiscio, Berbera, Chisiamaio)
Civil air: 5 major transport aircraft
Airfields: 64 total, 44 usable; 3 with permanent-
surface runways; 1 with runway over 12,000 ft.; 4 with
runways 8,000-11,999 ft, 15 with runways 4,000-
7,999 ft.
Telecommunications: telephone poor, telegraph
fair; 4,740 telephones; 67,500 radio receivers; 2 AM,
no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 754,000; 416,000
fit for military service; no conscription
Military budget: for fiscal year ending 31
December 1972, 19,400,000; 25.3% of total budget','989ccd7e0420b395c1033dbf179603a378c02bdfe0f18816835cd233e904d4a7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0479254dc48696699c54c7895d23d5ff69e5db8e289b19badecd09e4f9d52f88',1976,'ZA','South Africa','communications',467,'SOUTH
AFRICA
(See reference map Vi}
LAND
472,000 sq. mi. (includes enclave of Walvis Bay,
434 sq. mi.); 12% cultivable, 2% forested, 86% desert,
waste, or urban
Land boundaries: 1,270 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,790 mi.
Railroads: 12,318 mi.; 11,879 mi. 3''6" gage of
which 1,323 mi. are multiple track; 2,726 mi.
electrified; 440 mi. 2''0'''' gage single track
188
Highways: 220,000 mi.; 31,700 mi. paved, 42,650
mi. crushed stone or gravel, 145,650 mi. improved and
unimproved earth
Pipelines: crude oil, 520 mi.; refined products, 450
mi.; natural gas, 200 mi.
Ports: 5 major, 6 minor
Civil air: 64 major transport aircraft
Airfields: 662 total, 531 usable; 57 with
permanent-surface runways; l with runway over
12,000 ft., 8 with runways 8,000-11,999 ft., 180 with
runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: the system is the best
developed, most modern, and highest capacity in
Africa and consists of carrier-equipped open-wire
lines, coaxial cables, radio-relay links, and
radiocommunication stations; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg,
Port Elizabeth, and Pretoria; 1.8 million telephones:
2.5 million radio receivers; 13 AM, 60 FM, and no TV
stations; 4 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 5,617,000;
3,437,000 fit for military service; obligation for service
in Citizen Force begins at 18; volunteers for service in
permanent force must be 17
Military budget: for year ending 31 March 1976,
$1,393,502,866; 18% of total budget
SOUTH-WEST AFRICA
Atlantic
Ücean
SOUTH-WEST
Windhoek ,
AFRICA
Indian
Ocean
(See reference map VI)
LAND
318,000 sq. mi.; mostly desert except for interior
plateau and area along northern border
Land boundaries: 2,360 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SOUTH-WEST AFRICA
Coastline: 925 mi.
Railroads: 1,454 mi., all 3''6" gage, single track
Highways: 21,000 mi.; 2,944 mi. bituminous
treated, 220 mi. gravel and 18,436 mi. earth road and
tracks
Ports: 1 major (Walvis Bay), 1 minor
Civil air: 5 major transport aircraft (registered in
South Africa)
Airfields: 114 total, 98 usable; 11 with permanent-
surface runways; 1 with runway over 12,000 ft.; 3 with
runways 8,000-11,999 ft, 41 with runways 4,000-
7,999 ft.
Telecommunications: system is a meager combina-
tion of open-wire lines, a single short radio-relay link,
and scattered radiocommunication stations; Wind-
hoek is the center; 40,450 telephones; unknown
number of radio receivers; no AM, 1 FM, and no TV
stations
189
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SOUTH-WEST AFRICA/SPAIN
DEFENSE
Military manpower: males 15-49, about 195,000;
about 116,000 fit for military service
Defense is responsibility of Republic of South Africa
Atlantic
Ücean
CANARY
ISLANDS |
Sey CA
(See referance map 1V)
LAND
195,000 sq. mi., including Canary (2,900 sq. mi.)
and Balearic Islands (1,940 sq. mi.); 41% arable and
land under permanent crops, 27% meadow and
pasture, 22% forest, 10% urban or other
Land boundaries: 1,180 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 3,085 mi. (includes Balearic Islands, 420
mi., and Canary Islands, 720 mi.)','f28a6680cdf88dcb995a54b5eccc2a1df1444f28f17c3e4e50574df20685059f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4e9234dc6185d3b8085f215f1e33db5213e46617953b94a6146e77361c33788',1976,'ES','Spain','communications',473,'Railroads: 10,203 mi.; 8,324 mi. (5''6" gage), 1,879
mi. other gages (4''814" to 11155); 1,310 mi., double
track; 2,612 mi. electrified; all government-owned
except 627 mi. privately-owned
Highways: 86,600 mi.; national — 35,175 mi.
bituminous treatment, 9,400 mi. crushed stone, 4,225
mi. bituminous, stone block and concrete; provincial -
18,200 mi. bituminous treatment, 18,400 crushed
stone, 1,200 mi. bituminous, concrete, and stone block
Inland waterways: about 650 mi; of minor
importance as transport arteries and contribute little
to economy
Pipelines: crude oil, 240 mi.; refined products, 609
mi.; natural gas, 100 mi.
Ports: 23 major, 150 minor
Civil air: 196 major transport aircraft (including 3
registered but leased from a foreign country)
‘Airfields (including Balearic and Canary
Islands): 112 total, 84 usable; 47 with permanent-
surface runways; 4 with runways over 12,000 ft., 17
with runways 8,000-11,999 ft., 35 with runways 4,000-
7,999 ft.; 5 seaplane stations
Telecommunications: generally adequate, modern
facilities; 7.39 million telephones; 8.5 million radio
and 6.3 million television receivers; 170 AM, 231 FM,
and 694 TV stations; 7 coaxial submarine cables; 4
communication satellite ground stations
191
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SPAIN/SPANISH SAHARA/SRI LANKA
DEFENSE FORCES
Military manpower: males 15-49, 8,620,000;
6,631,000 fit for military service; 280,000 reach
military age (20) annually
Military budget: for fiscal year ending 31
December 1975, $2,884 million; about 2595 of central
government budget
SPANISH SAHARA
Atlantic Ocean
CANARY
ISLANDS ,
LP
*
f
SPANISH
SAHARA
(See reference map VI)
LAND
103,000 sq. mi., nearly all desert
Land boundaries: 1,296 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 690 mi.
Railroads: none
Highways: 3,790 mi; 305 bituminous treated,
3,485 mi. unimproved earth roads and tracks
Ports: 2 major (El Aaiun, Villa Cisneros), 2 minor
Civil air: no major transport aircraft
Airfields: 17 total, 17 usable; 3 with permanent-
surface runways; 5 with runways 4,000-7,999 ft.
Telecommunications: telephone and telegraph
poor; 600 telephones; 16,000 radio receivers; 1 AM,
no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 16,000; 8,000 fit
for military service','f342a52a14cbe3dd85c27bbdfc6c023f14316dbc430936893e9d7cf32b868e78','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25d572b6efadb3d1f8da0c2c93cf4a61e5364f806fb9954b2e318b7ac55bf095',1976,'LK','Sri Lanka','communications',475,'(formerly Ceylon)
LAND
25,300 sq. mi.; 25% cultivated; 44% forested; 31%
waste, urban, and other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Arabian
Sea
SRI
B
Colombo
Indian Ocean
(See reference map VI)
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi. plus pearling in the Gulf of
Mannar, and right to establish 100 n. mi. conservation
zone)
Coastline: 835 mi.
Railroads: 938 mi.; 851 mi. 5''6" gage, 87 mi. 2''6"
gage; 63 mi. double track; no electrification;
government owned
Highways: 36,900 mi. (1974); 15,200 mi. paved
(mostly bituminous treated), 15,260 mi. crushed stone
or gravel, 9,140 mi. improved earth or unimproved
earth; in addition several thousand mi. of tracks,
mostly unmotorable
Inland waterways: 270 mi.; navigable by shallow-
draft craft
Ports: 3 major, 9 minor
Civil air: 5 major transport (including 1 leased)
Airfields: 14 total, 10 usable; 10 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 6
with runways 4,000-7,999 ft.
Telecommunications: an inadequate telephone
and a less extensive but more efficient telegraph
system serves most areas, with greatest concentration
around Colombo and Kandy; all areas are served by
radio and/or wire broadcast; excellent international
service; 67,753 (est. ) telephones; 525,000 radio sets, no
TV sets; 8 AM stations, 2 FM, and no TV stations;
submarine cables extend to India, Malaysia, Seychelle
Islands, and Aden; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,233,000;
2,426,000 fit for military service; 153,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
December 1975, $39 million, 8.6% of total budget','ced294ad7b7f8d34dd4fbe593fe5dac38683d997a51dc2987b9ce08979438026','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('056c9ad77d04c640e9eb68b9645b8a8e879c49ebd15383629ea94a8efa6b994e',1976,'SD','Sudan','communications',479,'LAND
967,000 sq. mi.; 37% arable (3% cultivated), 15%
grazing, 33% desert, waste, or urban, 15% forest
Land boundaries: 4,850 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(plus 6 n. mi. "necessary supervision zone”)
Coastline: 530 mi.
I
Khartoum ,
{See reference map Vi}
Railroads: 3,398 mi.; 2,953 mi. 3''6" gage, 445 mi.
2'' gage plantation line
Highways: 6,550 mi.; 190 mi. bituminous-treated,
680 mi. crushed stone or gravel, and 5,680 mi.
improved and unimproved carth roads; in addition,
there are an undetermined number of tracks
Inland waterways: 3,300 mi. navigable
Ports: 1 major (Port Sudan), 7 minor
Civil air: 7 major transport aircraft
Airfields: 74 total, 66 usable; 6 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 28
with runways 4,000-7,999 ft.
Telecommunications: large system by African
standards, but still barely adequate for size of country;
consists of open-wire lines, radio-relay links,
multiconductor cables, radiocommunication stations
and a tropospheric-scatter link; principal center
Khartoum, secondary centers Al Fashir and Port
Sudan; 50,950 telephones; 650,000 radio and 100,000
TV receivers; 2 AM, no FM, and 1 TV stations; 5
submarine cables; satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 8,982,000;
2,364,000 fit for military service; average number
reaching military age (18) annually, 170,000
Military budget: for fiscal year ending 30 June
1978, $118.5 million; 20.8% of total budget
SURINAM
=
Caribbean 4
Sea Atlantic
Ocean
Paramaribo
tk FRENCH
ANA
(Seo reference map Hi)
LAND
55,100 sq. mi.; negligible amount of arable land,
meadows and pastures, 7676 forest, 8% unused but
potentially productive, 1676 built-on area, wasteland,
and other
Land boundaries: 970 mi.
195
CIA-RDP79-01051A000800010001-8
-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001
January 1976
SURINAM
WATER
Limits of territoria] waters (claimed): 3 n. mi.
Coastline: 240 mi.
Railroads: 104 mi.; 54 mi. 3375" gage (government
owned) and 50 mi. narrow gage (industrial lines); all
single track
Highways: 1,550 mi.; 300 mi. paved, 130 mi.
gravel, 370 mi. improved earth, 750 mi. unimproved
earth
Inland waterways: 2,850 mi; most important
means of transport; oceangoing vessels with drafts
ranging from 14 to 23 ft. can navigate many of thc
principal waterways while native canoes navigate
upper reaches
Ports: 1 major (Paramaribo), 6 minor
Civil air: 1 major transport aircraft
Airfields: 30 total, 29 usable; 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 4
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: international facilities good;
domestic tadio-relay system; 13,100 telephones;
110,000 radio and 35,000 TV receivers, 5 AM, 1 FM,
and 3 TV stations
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SURINAM/SWAZILAND
DEFENSE FORCES
Military manpower: males 15-49, 98,000; 54,000
fit for military service
SWAZILAND
AMBIQUE
(See reference map VI)
LAND
6,700 sq. mi.; most of area suitable for crops or
pasturcland
Land boundaries: 270 mi.
Railroads: 139 mi., 3''6" gage, single track
Highways: 2,100 mi.; 150 mi. paved; 850 mi.
crushed stone, gravel, or stabilized soil; 1.100 mi.
improved or unimproved earth
Civil air: 3 major transport aircraft
Airfields: 33 total, 28 usable; ] with runway 4,000-
7,999 ft.
Telecommunications: the system consists of à few
open-wire lines and low-powered radiocommunica-
tion stations; Mbabane is the center; 5,900
telephones; 52,500 radio receivers; 1 AM, no FM or
TV stations
DEFENSE FORCES
Military manpower: males 15-49, 109,000; 64,000
fit for military service
Jj Nporle-Novo Cameroon
bu AE
MalaboS Yaoundé
"Mogadiscio
A ombasa SEYCHELLES ‘y,
ñ wK) C
atte
p Dar es Salaam X
fomoro is.
“y
ou
xTajanarive
Madagascar, Mauritius,
3
Reunion
ter)
"Lourenco
¿3 Marques
Cape Town
Names and boundary representation
are not necessarily authoritative
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
V The Middle East
Caspian
Sea
Cyprus. —
Į Nicosia | D Syria.
^. Mediterranean Sea Leban
Beir
Tehran y
7, Damascu E
israg !
ADA Rot son? i
Qd Aerea
Wa A ¿Jordan
.
Shiraz
IS Bandar ‘Abbas
Sy d Ps
“ty, ~ wu x
R Bahrain sore
: C A A s
Gulf of','e086d3ab98e6509743f1fa299a2226815859ccbfe6ec4c2dd1201b7cfb847a1f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85b8ba84b76426d044885ca248a902cf9045f204a51290eaa8f307f1cf2085b3',1976,'SE','Sweden','communications',483,'Norwegian
Sea
(See referent wea IV}
LAND
173,000 sq. mi; 8% arable, 1% meadows and
pastures, 55% forested, 36% other
Land boundaries: 1,365 mi.
WATER
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.)
Coastline: 2,000 mi.
Railroads: 7,451 mi; Swedish State Railways
(SJ) — 6,946 mi. standard gage (48%), 113 mi. nar-
row gage (3''6" and 2''11"), 4,324 mi. electrified, 715
mi. double tracked; 294 mi. standard gage (48 Ve"),
(98 mi. narrow gage (211") 284 mi. clectrified
| are privately owned and operated
Highways: 60,945 mi.; 44,550 mi. are crushed
stone, gravel, or improved earth; and 16,395 mi. are
bitumen, concrete, stone block, or cobblestone
Inland waterways: 1,275 mi. navigable for small
steamers and barges
Ports: 17 major, and 30 significant minor
Civil air: 61 major transports
Airfields: 250 total, 224 usable; 123 with
permanent-surface runways, 6 with runways 8,000-
11,999 ft., 84 with runways 4,000-7,999 ft.
Telecommunications: excellent domestic and
international facilities: 5.21 million telephones; 9
AM, 91 FM, and 233 TV stations; 5 million radio and
2.88 million TV receivers; 10 submarine cables,
including 4 coaxial; COMSAT ground station
DEFENSE FORCES
Military manpower: males 15-49, 1,885,000,
1,679,000 fit for military service; 57,000 reach military
age (19) annually
Military budget: for fiscal year ending 80 June
1976, $2.48 billion; about 11% of central government
budget','f7889aec9c996d9bf8bbaed2978dcbdebb28f0460f9a108f6c5ddfbd455bda8b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd241b3c74628e6c1903fb50d80bfbf5b4d0d5d3e57f0d5bbacce78e77c732e2',1976,'TH','Thailand','communications',490,'of Bengal
/
‘See reforence map VIIJ
LAND
198,000 sq. mi.; 24% in farms, 56% forested, 20%
other
Land boundaries: 3,025 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,000 mi.
Railroads: 2,382 mi. meter gage; 60 mi. double
track
Highways: 17,900 mi. (1974); 9,180 mi. paved,
2,940 mi. crushed stone or gravel, 5,780 mi. earth and
laterite
Inland waterways: 2,485 mi. principal waterways;
2,300 mi. with navigable depths of 3 ft. or more
throughout the year; numerous minor waterways
navigable by shallow-draft native craft
Ports: 2 major, 16 minor
Civil air: 21 major transport aircraft
Airfields: 164 total, 163 usable; 53 with
permanent-surface runways; 10 with runways 8,000-
11,999 ft., 27 with runways 4,000-7,999 ft.
DEFENSE FORCES
Military manpower: males 15-49, 10,193,000;
6,205,000 fit for military service; about 435,000 reach
military age (18) annually
Military budget: for fiscal year ending 30
September 1975, $411 million; 1796 of central
government budget
(Ses reference mag vi)
WATER
Limits of territorial waters (claimed); 3 n. mi.
(fishing, 50 n. mi.)
Coastline: 1,650 mi.
Railroads: 800 mi. meter gauge, single track; 400
mi. serviceable and 175 mi. undergoing reconstruc-
tion; remainder out of service or abandoned
Highways: 12,100 mi.; 2,500 mi. bituminous, 4,700
mi. gravel or improved earth, 4,900 mi. unimproved
earth
Inland waterways: about 6,800 mi. navigable;
more than 1,400 mi. navigable at all times by vessels
up to 6 ft. draft
Ports: 6 major, 20 minor
Airfields: 189 total, 153 usable; 62 with
permanent-surface runways, 8 with runways 8,000-
11,999 ft., 18 with runways 4,000-7,999 ft.; 2 seaplane
stations
DEFENSE FORCES
Military manpower: males 15-49, 4,720,000;
3,000,000 fit for military service; 191,000 reach
military age (18) annually','b93b6af022f70536e2c26b01db2027eb499f0da685ab63bab8ea0f82aad444f8','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77fe9e17dd30c5aab6b58f7dca2a69f8629b6c1a48cf29d2467af75bc08ae23c',1976,'TG','Togo','communications',493,'Gulf af Guinea
(See reference map V)
LAND
22,000 sq. mi.; nearly one-half is arable, under 15%
cultivated
Land boundaries: 1,023 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 35 mi.
Railroads: 275 mi. meter gage, single track
Highways: approx. 4,475 mi.; 415 mi. paved, 120
mi. gravel 730 mi improved earth, 3,210 mi.
unimproved
Inland waterways: section of Mono River and
about 30 mi. of coastal lagoons and tida] creeks
Ports: 1 major (Lome), 1 minor
Civil air; 2 major transport aircraft
Airfields: 11 total, 11 usable; 1 with permanent-
surface runway 4,000-7,999 ft.
Telecommunications: Togo has poor system based
on skeletal network of open-wire lines supplemented
by a few radiocommunication stations; only center is
Lome; 6,100 telephones; 50,000 radio receivers; |
AM, no FM or TV stations
DEFENSE FORCES
Military manpower: males 15.49, 474,000; 244.000
fit for military service; no conscription
Supply: most military materiel obtained from','775925e727657b9fb09c6a845637ff355e184cd47477ca7cfc3b1f28c2fadb95','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3dd1c8d1de8966d0bbbd7f1bfb96c0d0afd53c92dcb9009c12b29b28cf2f3dd',1976,'TO','Tonga','communications',497,'LAND
385 sq. mi. (150 islands): 77% arable, 3% pasture,
13% forest, 3% inland water, 4% other
206
COME E
e
1 “TONGA
NEWS " Nukifalofa
CALEDONIA
Pacific Ocean
is
ZEALAND”
(See reference map VI)
WATER
Limits of territoria] waters (claimed): 12 n. mi.
Coastline: 260 mi. (est.)
Railroads: none
Highways: 155 mi. (1974); 110 mi. rolled stone; 45
mi. coral base
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 4 total; 4 usable, with grass runways
7,000 ft.; 1 seaplane station, adequate overseas, but
inadequate domestic service
Telecommunications: 1,090 telephones; 10,000
radio sets; no TV sets; 1 AM station
1 Tonga dol-','5cd236ce650fce02ea07cbe297a8722fb8672e47f8a1c86f2d230c15d5cb0fcf','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f704723a328c8116fc224413b79fdc6b5d497227ee8718dc093616916030d1e9',1976,'TT','Trinidad and Tobago','communications',501,'Atlantic Ocean
D
Caribbean See &.
4
AX Port
Qi
«Span TRINIDAD
23 AND TOBAGO
(See reference mag It}
LAND
1,980 sq. mi; 41.9% in farms (of which 25.7%
cropped or fallow, 1.5% pasture, 10.6% forests, 4.1%
unused or built-on), 58.1% outside of farms, including
grassland, forest, built-up area, and wasteland
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 225 mi.
Railroads: none
Highways: 4,200 mi.; 2,500 mi. paved, 1,700 mi.
gravel or otherwise improved
Pipelines: crude oil, 270 mi.: refined products, 12
mi.; natural gas, 130 mi.
Ports: 3 major (Port of Spain, Chaguaramar Bay,
Point Tembladora), 6 minor
Civil air: 15 major transport aircraft
208
Airfields: 8 total, 6 usable; 4 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 2
with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international
service via tropospheric scatter links to Barbados and
Guyana; good local service; satellite ground station;
68,000 telephones; 300,000 radio and 93,000 TV
receivers; 2 AM, 2 FM, and 3 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 252,000; 178,000
fit for military service
Supply: mostly from U.K.','7f17d4e4cf976bc235b4321d9b9d7ea94da9938a3d3f02a0367d63e32e90d55e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('432cca6ba449a4e2f79ae1537905d37ff5d413ddea574c610b90da77c2121018',1976,'TN','Tunisia','communications',505,'(See reference map VI)
LAND
63,400 sq. mi.; 28% arable land and tree crops, 23%
range and esparto grass, 6% forest, 43% desert, waste
or urban
Land boundaries: 875 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi. exclusive fisheries zone follows the
50-meter isobath for part of the coast, maximum 65 n.
mi.)
Coastline: 710 mi. (includes offshore islands)
Railroads: 1,273 mi.; 309 mi. standard gage
(4’8%4''"), double 964 mi. meter gage (3''3%4"")
Highways: 14,800 mi.; 4,770 mi. mostly
bituminous treatment, 4,835 mi. gravel and crushed
stone, 1,125 mi. improved earth, 4,070 mi.
unimproved earth
Pipelines: crude oil, 495 mi.; refined products, 6
mi.; natural gas, 45 mi.
Ports: 4 major, 8 minor
Civil air: 9 major transport aircraft
Airfields: 35 total, 30 usable; 11 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 17
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is above the
African average in amount and capacity of facilities
which consist of open-wire lines with multiconductor
cable or radio relay on trunk routes; key centers are
Safaqis, Susah, Bizerte, and Tunis; 96,300 telephones;
401,000 radio and 92,500 TV receivers; 3 AM, 3 FM,
and 7 TV stations; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 1,478,000,
815,000 fit for military service; about 64,000 rcach
military age (20) annually
Military budget: for fiscal year ending 31
December 1975, $70,100,000; 5.2% of total budget
TURKEY
LAND
296,000 sq. mi.; 3596 cropland, 2596 meadows and
pastures, 23% forested, 17% other
Land boundaries: 1,600 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi. (fishing, 12 n.
mi.)
Coastline: 4,475 mi.
Railroads: 5,075 mi.; 5,055 mi. 4814" gage, 89 mi.
double track; 45 mi. electrified; 20 mi. 25%” gage
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TURKEY/UGANDA
Highways: 37,282 mi; 13,049 mi. bituminous,
17,898 mi. gravel or crushed stone, 1,553 mi.
improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oil, 402 mi.; refined. products,
1,277 mi.
Ports: 10 major, 35 minor
Civil air: 22 major transport aircraft
Airfields: 119 total, 101 usable; 34 with
permanent-surface runways; 3 with runways over
12,000 ft., 20 with runways 8,000-11,999 ft., 24 with
runways 4,000-7,999 ft.
Telecommunications: excellent international and
fair domestic telecommunication services; 913,000
telephones; 4.5 million radio and 400,000 TV
receivers; 42 AM, 4 FM, and 82 TV stations
DEFENSE FORCES :
Military manpower: males 15-49, 10,144,000;
5,978,000 fit for military service; about 420,000 reach
military age (20) annually
Military budget: proposed for fiscal year ending 28
February 1976, $1,637 million; about 21% of
proposed central government budget','6a7dcea5b6971ef3f82251b3cf7efa14abd591a6147dc436fdae97355bd68f20','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac1e6eded7d595cfba989196e804acf9dd8b80faf2fd75af8d62ac5be6195ebd',1976,'UG','Uganda','communications',509,'Indian
Ücean
4
[Saa reference map VI)
LAND
91,000 sq. mi; 21% inland water and swamp,
including territorial waters of Lake Victoria, about
21% cultivated, 13% national parks, forest, and game
reserves, 45% forest, woodland, and grassland
Land boundaries: 1,665 mi.
Railroads: 760 mi.; all meter gage, single track
Highways: 31,330 mi. total; 1,200 mi. bituminous
surface treatment; 10,130 mi. crushed stone, gravel,
laterite, and improved earth; 20,000 mi. unimproved
earth roads and tracks
Inland waterways: Lake Victoria, Lake Albert,
Lake Kyoga, Lake George, and Lake Edward (6,010
mi.); Kagera River and Victoria Nile (380 mi.)
Civil air: 7 major transport aircraft
Airfields: 54 total, 50 usable; 5 with permanent-
surface runways; 1 with runway over 12,000 ft., 3 with
runways 8,000-11,999 ft, 12 with runways 4,000-
7,999 ft.
Telecommunications: telephone and telegraph
services fair, intercity connections based on 3 or 12
channel carrier systems: 34,200 telephones; 275,000
radio and 68,000 TV receivers; 2 AM, no FM, and 6
TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 2,599,000;
about 1,391,000 fit for military service
Military budget: for fiscal year ending 30 June
1972, $42.7 million; 16.6% of total budget
U.S.S.R.
LAND
8,600,000 sq. mi.; 9.3% cultivated, 37.195 forest
and brush, 2.6% urban, industrial, and transportation,
16.8% pasture and natural hay land, 34.2% desert,
swamp, or waste
Land boundaries: 12,595 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 29,000 mi. (incl. Sakhalin)
Railroads: 91,263 mi; 90,059 mi. broad gage.
1.204 mi. narrow gage; 68,064 mi. broad gage single
track; 21,995 mi. electrified; does not include
industrial lines (1974)
Highways: 901,763 mi;
218,940 mi. gravel, crushed stone,
improved or unimproved earth (1974)
182,199 mi. paved,
505,667 mi.
Approved For Release 2005/04/22
Inland waterways: 90,000 mi. navigable, exclusive
of Caspian 5ea (1975)
Pipelines: crude oil, 30,000 mi.; refined products,
6,400 mi.; natural gas, 56,000 mi.
Ports: 63 major (most important: Leningrad,
Murmansk, Odessa, Novorossiysk, Ilichevsk, Vladivo-
stok, Nakhodka, Arkhangel''sk, Riga, Tallinn,
Kaliningrad, Liepaja, Ventspils, Nikolayev, Sevas-
topol); 116 selected minor (1975)
Freight carried: rail — 3,834.9 million short tons,
2,121.1 billion short ton/mi. (1973); highways — 21.1
billion short tons, 213.6 billion short ton/mi. (1974);
waterway — 497.2 million short tons, 144.2 billion
short ton/mi. (1974)','8838a681fde7c32a6c038dcaa7f11705738fd75f85b69a45b7bcf76216779e6a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71e883d93fba8a976af50c35b3b26efb4e53598e9f07f39060e892685463b6f1',1976,'GB','United Kingdom','communications',517,'Railroads: Great Britain—11,400 mi.; 11,325 mi.
standard gage (4''8 121”); 115 mi. narrow gage (various
widths); 2,365 mi. electrified; 7,090 mi. double track,
1,470 mi. multiple track; Northern Ireland — 203 mi.
5/8" gage; 118 mi. double track
Highways: approx. 210,000 mi. and 14,000 route
mi. in Northern Ireland
Inland waterways: 1,100 mi. of commercial routes
Pipelines: crude oil, 580 mi., almost all
insignificant; refined products, 1,807 mi., natural gas
1,100 mi.
Ports: 23 major, 350 minor
Civil air: 520 major transport aircraft
Telecommunications: modern, efficient domestic
and international system; 91.3 million telephones;
41.7 million radio and 18.5 million TV receivers;
excellent countrywide AM, FM, and TV service; 88
215
0800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00
January 1976
UNITED KINGDOM/ UPPER VOLTA
AM, 114 FM and 365 TV Stations; 44 submarine
cables, 41 coaxial; 3 earth satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 12,649,000;
10,720,000 fit for military Service; no conscription;
432,000 teach military age (18) annually
Military budget: Proposed for fiscal year ending 3]
March 1976, $10.7 billion: about 16.5% of central
government budget
UPPER VOLTA
Atlantic
Ücean
pe c A
{See reference map Vip
LAND
106,000 sq. mi; 50% Pasturcland, 21% fallow,
10% cultivated, 9% forest. and scrub, 10% waste
and other uses
Land boundaries: 2,055 mi.
Railroads: 728 mi., 320 mi. meter gage, single
track; Ouagadougou to Abidjan, Ivory Coast line
Highways: 10,380 mi.; 325 mi. paved, 3,425 mi.
improved, 6,630 mi. unimproved
Civil air: no major transport aircraft
Airfields: 54 total, 53 usable; 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 8
with runways 4,000-7,999 ft.
Telecommunications: all services generally poor;
1,800 telephones; 100,000 radio and 6,000 TV
receivers; 2 AM, no FM, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 1,381,000;
692,000 fit for military service; no conscription
Supply: dependent on France
Military budget: for fiscal year ending 31
December 1975, $8,383,594; 11.3% of total budget','12e0c1cf35f6e202728289a1564167dba815b231d8ccbc5561e33c8880ac098b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06075596ff84ae163a4d08c71c2c406be083b4d99ea19c3a3371f5b9afd5dfc7',1976,'UY','Uruguay','communications',520,'Atlantic
Ocean
A "
Montevideo
(See reference map IV)
LAND
72,200 sq. mi.; 84% agricultural land (73% pasture,
11% cropland) 16% forest, urban, waste and other
Land boundaries: 840 mi.
WATER
Limits of territorial waters (claimed): 200 n. mi.
(fishing 12 n. mi.)
Coastline: 410 mi.
Railroads: 1.870 mi., all standard gage and
government owned
Highways: 32,200 mi.; 3,700 mi. paved, 4,600 mi.
otherwise surfaced, 9,600 mi. improved earth, 14,300
mi. earth tracks
Inland waterways: 1,070 mi.; used by coastal and
shallow-draft river craft
Freight carried: highways 80% of total cargo
traffic, rail 15%, waterways 5%
Ports: 4 major (Montevideo, Colonia, Fray Bentos,
Paysandu), 6 minor
Civil air: 16 major transport aircraft
Airfields: 94 total, 79 usable; 7 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 9
with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: most modern facilities
concentrated in Montevideo; 257,500 telephones; 1.5
million radio and 350,000 TV receivers; 75 AM, 3
FM, and 17 TV stations; 2 submarine cables;
COMSAT station planned
DEFENSE FORCES
Military manpower: males 15-49, 738,000; 594,000
fit for military service; no conscription
Military budget: proposed for fiscal year ending 31
December 1975, $82.2 million; 15.6% of central
government budget
VATICAN CITY
Mediterranean
Sea
{Sae reference map IV}
LAND
0.169 sq. mi.
Land boundaries: 2 mi.
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Telecommunications: 1 AM and 1 FM radio-
broadcasting station; 2,000-line automatic telephone
exchange
DEFENSE FORCES
Defense is responsibility of Italy
VENEZUELA
Atlantic
{See reference map itt}
LAND
352,000 sq. mi.; 4% cropland, 18% pasture, 21%
forest, 57% urban, waste, and other
Land boundaries: 2,598 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,740 mi.
Railroads: 233 mi. 4814" gage; all single track;
107 mi. government owned, 126 mi. privately owned
Highways: 40,000 mi.; 12,000 mi. paved, 11,000
mi. gravel, 6,000 mi. improved earth, 11,000
mi. unimproved (including trails)
Inland waterways: 4.450 mi.; Orinoco River and
Lake Maracaibo accept oceangoing vessels
Pipelines: crude oil, 3,800 mi.; refined products,
250 mi.; natural gas, 1,550 mi.
Ports: 6 major, 17 minor
Civil air: 63 major transport aircraft
Airfields: 29] total, 260 usable; 98 with
permanent-surface runways; 8 with runways 8,000-
11,999 ft., 75 with runways 4,000-7,999 ft.; 2 seaplane
stations
Telecommunications: modern expanding telecom
System; satellite ground station; 549,000 telephones;
3.2 million radio and 1.3 million TV receivers: 157
AM, 50 FM, and 43 TV stations; 3 submarine cables,
including 1 coaxial
DEFENSE FORCES
Military manpower: males
1,810,000 fit for military service;
military age (18) annually
15-49, 2,568,000;
126,000 reach
VIETNAM, NORTH
LAND
61,300 sq. mi.; 14% cultivated, 509; forested, 36%
urban inland water, and other
Land boundaries: 1,850 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
VIETNAM, NORTH/VIETNAM, SOUTH
Gulf of
Tankian No.
ow. SOUTH
EA VIETNAM
Bult of
Ape Thailand.
[See reference map Vit)
Coastline: 490 mi. (excluding islands)
Highways: 13,500 mi., including 900 mi.
bituminous surface-treated, 2,100 mi. gravel, 10,000
mi. improved carth, 500 mi. unimproved earth
Inland waterways: 4,200 mi.; 1,800 mi. navigable
perennially by craft drawing 6 ft.
Ports: 3 major, 3 minor
Airfields: 16 total; 11 with permanent-surface
runways; 2 with runway 8,000-11,999 ft., 12 with
runways 4,000-7,999 ft.
DEFENSE FORCES
Supply: dependent chiefly on U.S.S.R. and China
for virtually all equipment; smaller amounts from
other Communist countries; produces negligible
quantities of infantry weapons, ammunition, and
explosive devices
Military budget: no recent data available; for fiscal
year ending 31 December 1962, estimated defense
expenditures 382 million dongs; about one-fifth of
total budget (estimated value $103 million); military
aid from U.S.S.R. and China now so extensive that
actual allocation of North Vietnam''s domestic
resources to defense would not be indicative of total
military effort
NOTE: VN figures preliminary
VIETNAM, SOUTH
LAND
66,000 sq. mi.; 25% arable (15% cultivated), 33%
forested, 42% other
Land boundaries: 1,025 mi.
221
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
- VIETNAM, SOUTH
tee
Gulf of
<a Tonkin
South
China Sea
SOUTH
VIETNAM','3a4d5100b457dacce9cac8ed3a7a4c3305c23720e96c004b727f08b51deee852','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f626fa263609debb93724ce1837f1a79e37548369b0dd95661ff03bcfa9188b3',1976,'WF','Wallis and Futuna','communications',525,'E š
KE Filka
s ES
NEW S, — WALLIS
CALEDONIA” AND FUTUNA
Pacific Ocean
A ESE NEW. .
OEP ZEALAND
0
(See reference map VIII)
LAND
About 80 sq. mi.
WATER
Limits of territorial waters: 12 n. mi.
Coastline: about 80 mi.
Highways: 62 mi. of improved road on Uvea Island
(1972)
Ports: 2 minor
Airfields: 2 total, all usable; 1 4,000-7,999 ft., 1
seaplane station
Telecommunications: 43 telephones
DEFENSE
No formal defense structure; no regular Armed
Forces
WESTERN SAMOA
WESTERN
*e SOMOA
(Sea reference map VI)
LAND
1,100 sq. mi.; comprised of 2 large islands of Savai''i
and Upolu and several smaller islands, including
Manono and Apolima; 65% forested, 24% cultivated,
11% industry, waste, or urban
223
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
WESTERN SAMOA/YEMEN (ADEN)
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 250 mi.','0b6889af711651c0fae8e4eb7341c6151f41b87966f0aca801c043131179d5cb','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('510d157ba754b4627bf23a548d1ee92ce8d0d6b15910ac846f4a3bdb7149eb9d',1976,'WS','Samoa','communications',531,'Railroads: none
Highways: 487 mi.; 233 mi. bituminous, remainder
mostly gravel, crushed stone, or earth
Inland waterways: nonc
Ports: 1 principal (Apia), 1 minor
Civil air: 2 major transport aircraft
Airfields: 4 total, all usable; 1 with runway 4,000-
7,999 ft.
Telecommunications: 2,270 telephones; 10,100
radio receivers; 1 AM station
YEMEN (ADEN)
3 Arabian :
t. dem.
Indian
Ocean
(See reference map Vj
LAND
111,000 sq. mi. (border with Saudi Arabia
undefined); only about 1% arable (of which less than
25% cultivated)
Land boundaries: 1,120 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(300 meters plus exploitability, plus 6 n. mi.
“necessary supervision zone”)
Coastline: 860 mi.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
uel rms ÍT
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
YEMEN (ADEN)/YEMEN (SANA)
3 t 1S.
.. 7 Wallis and Futuna “Gare U5)
Fiji (Fr) o _ Dago
pa Apia” Pago
Tutuíià','e57b9625185544fbed001a2483a231ce9c4047200acc282dd2d727c472487606','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83516da85dbe3a745071d0aa4e8e054a3d02dbc53ec6ec3a592831b2f4bf732f',1976,'YE','Yemen','communications',535,'Railroads: none
Highways: 3,300 mi.; 200 mi. bituminous trcated,
180 mi. crushed stone and gravel, 2,920 motorable
track
Ports: | major (Aden)
Pipelines: refined products, 20 mi.
Civil air: 6 major transport aircraft
Airfields: 95 total, 57 usable; 2 with permanent-
surface runways; 4 with runways 8,000-11,999 ft., 31
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: small system of open-wire
line, multiconductor cable, and radiocommunications
stations; only center Aden; 9,900 telephones; 250,000
radio and 30,000 TV receivers; 8 TV and 1 AM
stations; 4 submarine cables (2 operational)
DEFENSE FORCES
Military manpower: males 15-49, 389,000; 215,000
fit for military service
Military budget: for fiscal year ending 31 March
1971, $15,816,000; about 34.4% of total budget
YEMEN (SANA)
LAND
About 75,000 sq. mi. (parts of border with Saudi
Arabia and Southern Yemen undefined), 20%
agricultural, 1% forested, 79% desert, waste, or urban
Land boundaries: 950 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(plus 6 n. mi. "necessary supervision zone")
Coastline: 325 mi.
Railroads: none
Highways: 2,160 mi.; 290 mi. bituminous; 270 mi.
crushed stone and gravel; 1,600 mi. earth, sand, and
light gravel
Ports: 1 major (Al Hudaydah), 2 minor
Civil air: 9 major transport aircraft
Airfields: 26 total, 18 usable; 6 with permanent-
surface runways; 1 with runway over 12,000 ft., 4 with
runways 8,000-11,999 ft., 6 with runways 4,000-7,999
ft.
Telecommunications: systems among mideast''s
worst; consists of meager open-wire lines and low.
power radiocommunication stations; principal center
Sana, secondary centers A] Hudaydah and Taizz;
4,600 telephones; 86,000 radio receivers; 1 AM radio-
broadcast station
DEFENSE FORCES
Military manpower: males 15-49, 1,550,000;
857,000 fit for military service; about 72,000 reach
military age (18) annually: universal military
conscription law (10 January 1963) makes military
service obligatory for all Yemeni males 18-30
Military budget: for fiscal year ending June 1974,
$29.7 million; 419; of total budget
YUGOSLAVIA
Belgrade,
N YUGOSLAVIA(B-
e
*^
ES
>
(See reference map ttt}
LAND
98,800 sq. mi.: 32% arable, 25% meadows and
pastures, 34% forested, 9% other
Land boundaries: 1,865 mi.
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
YUGOSLAVIA
WATER
Limits of territorial waters (claimed): 10 n. mi.
(fishing, 12 n. mi.)
Coastline: 945 mi. (mainland), plus 1,500 mi.
(offshore islands)
Railroads: 6,411 route mi.; 5,811 mi. standard
gage, 600 mi. narrow gage; 494 mi. double track;
1,243 mi. electrified (1973)
Highways: 61,119 mi.; 341 mi. concrete, 20,956
mi. bituminous, 684 mi. stone block, 23,312 mi.
gravel, 15,825 mi. earth (1973)
Inland waterways: 1,231 mi. (1975)
Freight carried: rail —89.7 million short tons, 15.8
billion short ton/mi. (1974); highway—88.7 million
short tons, 6.71 billion short ton/mi. (1974);
waterway—est 21.4 million short tons, est. 3.7 billion
short ton/mi. (incl. int]. transit traffic) (1974)
Pipelines: crude oil, 200 mi.; natural gas, 320 mi.-
Ports: 9 major (most important: Rijeka, Split,
Koper, Bar), 24 minor (1975)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 31 December 1975, 29 billion dinars; about
8.596 of estimated national income
Atlantic
Ocean
(See reference map V)
LAND
905,000 sq. mi.; 22% agricultural land (1%
cultivated), 45% forested, 33% other
Land boundaries: 6,153 mi.
9
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 23 mi.','5b2f59ff3463f954cdf1b5ba3c7518b7fc682040989d0da8a5971fc3773afbfa','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e3a6309a9bf2e7f12233b3ab9db56efa070bc3ea4c08c833faf6911ad63d786',1976,'ZM','Zambia','communications',537,'X wma ]-
MADAGASCAR,
MOZAMBIQUE. I
; Indian
Ocean.
(Ses reference map Vi)
LAND
288,000 sq. mi.; 5% under cultivation, 5% arable,
10% grazing, 18% dense forest, 6% marsh, 61%
scattered trees and grassland
Land boundaries: 3,730 mi.
Railroads: 1,219 mi, government owned, all
narrow gage (3''6"); 8 mi. double track
Highways: 21,375 mi.; 2,145 mi. paved, 4,690 mi.
crushed stone, gravel, or stabilized soil; 14,540 mi.
improved and unimproved earth
Inland waterways: 1,409 mi. including Zambezi
River, Luapula River, Lake Kariba, Lake Bangweulu,
Lake Tanganyika; principal port on Lake Tanganvika
is Mpulungu
Pipelines: 450 mi. refined
Civil air: 9 major transport aircraft
Airfields: 169 total, 169 usable; 11 with
permanent-surface runways; 1 with runway over
12,000 ft., 2 with runways 8,000-11,999 ft., 22 with
runways 4,000-7,999 ft.
Telecommunications: all services being modern-
ized and increased; presently adequate but must be
expanded to permit growth; high-capacity wire and
radio relay connect centers of Kitwe in northern
mining region and Lusaka along axial north-south
route; 59,300 telephones; 100,000 radio and 21,000
TV receivers; 4 AM, 1 FM, and 2 TV stations; 1
satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 1,140,000;
545,000 fit for military service
Military budget: for fiscal year ending 31
December 1972, $70,000,000; 11.6% of total budget','732c4608f13cfd3b40a7d25368703eb6eaa719ee765f80b0f411fb7e01e8dc2f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0620d1d05603261844d828ae652f1b84608843dcf7732165bf9fc3b9174c24e',1976,'US','United States','communications',541,'This " Factsheet’’ on the U.S. is provided solely as a
service to those wishing to make rough comparisons of
foreign country data with a U.S. “yardstick.”
Information is from U.S. open sources and
publications and in no sense represents estimates by
the U.S, intelligence community.
LAND
3,615,211 sq. mi. (contiguous U.S. plus Alaska and
Hawaii); 19% cultivated, 27% grazing and pasture,
32% forested, 22% waste, urban, and other
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Railroads: 202,775 mi. (1972)
Highways: 3,787,000 mi.
Inland waterways: 25,260 mi. of navigable inland
channels, exclusive of the Great Lakes; freight carried
951 million short tons (1970)
Pipelines: petroleum, 174,000 mi. (1972)
Ports: 25 major
Merchant marine: 600 ships (1,000 GRT or over)
totaling 9,982,730 CRT, 14,722,666 DWT; includes 3
passenger, 9 short-sea passenger, 163 cargo, 119
container, 14 roll-on/roll-off cargo, 934 tanker, 1
liquefied gas, 17 bulk, 2 combination ore/oil, 23
LASH Seebee and barge carriers, 19 specialized
carriers; in addition there are 178 ships in reserve fleet
Civil air: 5,214 major transport aircraft (1973)
Airfields: 12,405 (1972)
Telecommunications: 4,398 AM, 3,151 FM, 940
TV broadcast stations (1974); 147,000,000 telephones
(1975), 65 telephones per 100 population (1975); 360
million radio and 110 million TV receivers
DEFENSE FORCES
Personnel: army 1,148,000, navy and marines
1,065,000, air force 942,000 (1973)
Military budget: $80.6 billion (1974 est.)
231
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-010515000090010001-8.. nd Asia
eKuybyshev
eVolgograd
Ws.
Caspian
Yerevan Sea
b ah
*rehrán
Saudi
Arabia
Arabian Sea
Maldives +
indian
, Narih Pole
Yakutsk
.
*Sverdlovak
f
«Novosibirsk Pacific
Ocean
(Harbin) *
Shen-yang, P
(Urumchi)
* K''c-shih
(Kashgar) A
Ch''ing-tao
on, Indian claim (Teingtao)
> Lan-chou y
Pine A
e Hsi-an
3 Chinese line China ‘sea
of control Shang-hai
e Wuhan
eCh''eng-tu
: ia "d
eK''un-ming Meet
Macao ni Kong
- QE
Luzon
P Philippines
Je ES
‘Kuala Lumpur Sarawg
at, Malaysia
Su tra een
Spal many, gP
Indonesi
„Surabaya .
Er
Java c hen .Timor
Jogha SR oases','9d1a2c29f853d20b0d21cb9f6cb8d9d64a5268233751fbf2ab845b552e116f8a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eec8cded436efb034a43ef54497aadfcf242f7ce5fafe52c6bc7aecc8b322bd1',1976,'AF','Afghanistan','communications',6,'Railroads: 0.4 mi. (single track) 5’0''-gage,
government-owned spur of Sovict line
food
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
AFGHANISTAN/ ALBANIA
Highways: 11,170 mi. (1974): 1,615 mi. paved,
2,200 mi. gravel, 3,895 mi. improved earth, and
3,470 mi. unimproved earth
Inland waterways: total navigability 760 mi.-
steamers use Amu Darya
Ports: only minor river ports
Civil air: 5 major transport aircraft
Airfields: 41 total, 36 usable; 9 with permanent-
surface runways; 6 with runways 8,000-1 1,999 ft., 11
with runways 4,000-7,999 ft.
Telecommunications: limited telephone, tele-
graph, and radiobroadcast services. barely sufficient
to meet civil and military requirements; 24.528
telephones; 111,000 radio receivers: no TV receivers: 2
AM, no FM, no TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 4.9
million; 2.6 million fit for tuilitary service; about
177,000 reach military age (22) annually
Supply: dependent on foreign sources, almost
exclusively the U.S.S:R.','f3cd7dc67c534f501c6e06783c88a30a15ebc0a30d806403720446d3fb86a674','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2941dec7197e7dc3646ef9326db2b024402e4fc134264810de49c44c71c7946a',1976,'AL','Albania','communications',7,'{See reference map (Yj
LAND
11,100 sq. mi.; 19% arable, 24% other agricultural,
43% forested, 14% other
Land boundaries: 445 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 260 mi. (including Sazan Island)
Railroads: 172 mi. standard gage, single track;
government owned (1974)
Highways: 3,100 mi.; 800 mi. paved, 1,000 mi.
crushed stone and/or gravel, 1,300 mi. improved or
unimproved earth (1974)
Inland waterways: 27 mi. plus Albanian sections of
Lake Scutari, Lake Ohrid, and Lake Prespa (1975)
Freight carried: rail — 3.1 million short tons, 123.3
million short ton/mi. (1971); highways — 43.0
million short tons, 616.4 million short ton/mi. (1971)
Ports: 2 major (Durres, Vlore), 2 minor (1975)
Pipelines: crude oil, 110 mi.
Civil air: no major transport aircraft (1975)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 31 December 1975, 653 million leks; about 9%
of total budget
“Atlentic = Gen
2 Oepan : ‘ f aoe
io
Mediterranea C4
2 cg VJ
Cs.”
(See reference map V)
LAND
950,000 sq. mi.; 3% cultivated, 16% pasture and
meadows, 1% forested, 80% desert, waste, or urban
Land boundaries: 3,890 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 735 mi.','7d5a2fbdb66cfb50998c079e3a92faee166ba9aeda7c067e45a9319834bbd741','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b3d6c2a20f702974a79c5666bd1d974c698d38fed1cf977fbc636c98705090d',1976,'DZ','Algeria','communications',13,'Railroads: 2,414 mi.; 1,660 mi. standard gage, 663
int, 3''5%6" gage, 91 mi. meter gage; 188 mi.
ciectrified; 120 mi. double track
Highways: 48,614 mi., of which 27,943 mi. are
paved and the remainder earth
Ports: 9 major, 8 minor
Pipelines: crude oil, 2,250 mi.; refined products,
180 mi.; natural gas, 1,785 mi,
Civil air: 28 major transport aircraft
Airfields: 190 total, 189 usable; 58 with
permanent-surface runways; 21 with runways 8,000-
11,999 ft., 107 with runways 4,000-7,999 ft.. 3
seaplane stations
Telecommunications: adequate domestic and
international facilities in the north, primarily radio
communications in the desert: satellite ground
stations; 220,800 telephones: 1,150,000 radio
receivers; 310,000 TV receivers; 15 AM and 39 TV
stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 3,974,000:
2,347,000 fit for military service: average number
reaching military age (19) annually 163,000
Military budget: for fiscal year ending 31
December 1975, $257,693,200; 4.7% of national
budget','8ba8697e586277f6887b3bfa438fc7b0327fcc7c27c410ee2c7bcdb571cdf952','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30f98dac3b4719bc23bde5253b61089d682a49a24f88ccf1b266e2f51f90698c',1976,'AD','Andorra','communications',14,'LAND
180 sq. mi.
Approved For Release 2005/04/22 :
Atlantic
Ocean
Po =
4 3
: ®
e
Mediterranean
Sea
(See reference map 1V}
Land boundaries: 65 mi.
Railroads: none
Highways: about 60 mi.
Civil air: no major transport aircraft
Airfields: none
Telecommunications: international circuits to
Spain and France; 2 AM, 1 FM, 1 TV station; about
2.800 telephones; 8,000 radio receivers, 3,000 TV
receivers
DEFENSE FORCES
Andorra has no defense forces; Spain and France
are responsible for protection as necded','22cc894397ed66386e752aeaf95ae40b9ef9716a287bc778abbe30669dc0ecf2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47c1e347935c1a077f8f085feb0ec6e81f107b74c7e72a7475e19e6d20d1642e',1976,'AO','Angola','communications',18,'LAND
481,000 sq. mi.; 1% cultivated, 44% forested, 22%
meadows and pastures, 33% other (including fallow)
Land boundaries: 3,150 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 1,000 mi.
Railroads: 1,918 mi.; 1,724 mi. 3''6" gage, 194 mi.
11158" gage
Highways: 45,000 mi; 4.970 mi. bituminous-
surface treatment, 28,000 mi. crushed stone, gravel, or
improved earth, remainder unimproved earth
Inland waterways: 2,000 mi. navigable
Ports: 3 major (Luanda, Lobito, Mocamedes). 15
minor
Pipelines: crude oil, 111 mi
Civil air: 15 major transport aircraft
Airfields: 552 total, 498 usable; 26 with
permanent-surface runways: 1 with runway over
12.000 ft., 6 with runways 8,000-11,999 ft.. 77 with
runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: network of open-wire and
radio-relay facilities; satellite ground station; 37,500
telephones; 116,000 radio receivers: 24 AM, 11 FM,
and no TV stations
ANTIGUA
Atlantic
Oeaan
DOMINICAN
EPUBLIC','80b72f2b1a4301227f2eda5c8b608a1ee1272fa3661b569fa5a4f633ed3c5c23','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2969de8b12748ee0bb4ddf8df17a87950e8a68c9208d8df68fd94e74376baa06',1976,'PR','Puerto Rico','communications',22,'a
ANTIGUA A“
Caribbean Sea
(Ser reference map tH)
LAND
108 sq. mi.; 54% arable, 5% pasture, 14% forested,
9% unused but potentially productive, 18% wasteland
and built on
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 95 mi.
Railroads: 49 mi. narrow gage (2''6”), employed
almost exclusively for handling cane
Highways: 235 mi; 150 mi.
secondary
Ports: | major (St. John’s), | minor
Civil air: 9 major transport aircraft
Airfields: 3 total, 2 usable; 1 with asphalt runway
9,000 ft.; 2 seaplane stations
Telecommunications: automatic telephone sys-
tem; 3,150 telephones; tropospheric scatter links with
‘Tortola and St. Lucia; 22.000 radio receivers, 12,300
TV sets; 2 AM, 1 FM, and | TV stations; 2 coaxial
submarine cables
main, 85 mi.','3049879e34530815b32e86ded9d890ffca37c2000414a611c01e3c0946bede1b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16818d37d61b40268fafa5fc4a390059aa697aeaf6e15ba5e1ff119d112fc083',1976,'AR','Argentina','communications',26,'Pacific
Buenos Aires
Atlantic Ocean
(See reference map Wy
LAND
1,070,000 sq. mi.; 57% agricultural (11% crops,
improved pasture and fallow, 46% natural grazing
jand), 25% forested, 18% mountain, urban, or waste
Land boundaries: 5,850 mi.
WATER
Limits of territorial waters (claimed): 200 n. mi.
(continental shelf, including sovercignty over
superjacent waters)
Coastline: 3,100 mi.
Railroads: 24,350 mi.; 2,000 mi. standard gage
(4''8''4"), 13,750 mi. broad Sage (5''6"), 8.402 mi.
meter gage (3''3%"'') 75 mi. 2''54"" gaye, 130 mi.
VI” gage: about 1.035 mi. double and multiple
track; 76 mi. electrified
Highways: 180,000 mi., of which 24,500 mi.
paved, 46,500 mi. gravel, 100,000 mi. improved earth
Inland waterways: 6,800 navigable mi.
Ports: 7 major, 2] minor
Pipelines: crude oil. 2,540 mi.: refined products,
1,370 mi.; natural gas, 5,670 mi.
Civil air; 45 major transport aircraft, includes |
leased from a foreign country
Airfields: 2,447 total, 2.149 usable; 83 with
permanent-surface runways; 20 with runways 8,000-
11,999 ft., 291 with runways 4,000-7,999 ft.. 6
seaplane stations
Telecommunications;: extensive modern system:
telephone network has 2,240,000 sets, radio relay
widely used, 2 communications satellite ground
stations; estimated 1] million radio receivers and 4
million TV sets; 145 AM, 12 FM, and 60 TY stations
DEFENSE FORCES
Military manpower: males 15-49, 6,312,000:
5,094,000 fit for military service: average number
reaching military age (20) annually about 214,000
Military budget: Proposed for fiscal year ending 31
December 1975, $684.9 million: about 10% of total
central government budget
Bahia--~
Pan
e
1000 Miles
1000 Kilometers
2 Falkland Is.
SED iislas Malvinas)
(Admin. by U.K.
claimed by
Argentina)
ts South Georgia
(U.K)
BOUNDARY REPRESENTATION IS
NOT NECESSARILY AUTHORITATIVE
502849 1-76
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
II Middle Americ
TaN
. Washington + s
‘<Q Ve
{
¢
weg ee United States
¥
‘\\ i Hermosillo
oe
1 oN
\\
¢
u
35 © N\\
An iy
\\ - 1 Maz atlan
\\
Si -Guadalajara
— Puerto Rico yj,
Cs oa qin 1s. (U.S.. UK.)
X *M Jf ee Lo UE haval Bose i}Rep., 2 S US.) i - Anguilla(u.K)
\\ mage Neracruz bs Jamaica Port- ce Cee “ey St. Christopher (U. K)
gee muca
£ (UK
Atlantic
Ocean
Monterrey,
Gulf of Mexico','dd520a7c0f3b812904b44d9dd273e753a8d7c3ba592aa919b9ad105344a957b2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bc14141a22d260eaaefcfb9ec5d1d4f567b51a5ae5b2c9b54e6aa89894c1ed7',1976,'AU','Australia','communications',30,'ic ONEsiAe *
et al al
2
{See reference map Vit}
LAND
2,970,000 sq. mi.; 6% arable, 58% pasture, 2%
forested, 34% other
WATER
Limits of territorial waters (claimed); 3 n. mi.
(fishing, 12 n. mi.: prawn and crayfish on continental
shelf)
Coastline: about 16,000 mi.
(See reference map Vill)
LAND
183,540 sq. mi.
Land boundaries: 600 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: about 3,200 mi.
Railroads: none
Highways: approx. 8,910 mi.; about 5,225 mi.
suitable for heavy and medium traffic, and about
3,685 mi. suitable for light traffic
Inland waterways: 6,800 mi.
Ports: 5 principal, 8 minor
Civil air; 22 major transport aircraft; Air Niugini,
new national airline, began operations in November
1973
Airfields: 514 total, 478 usable; 13 with
permanent-surface runways; 46 with runways 4,000-
7,999 ft.; 1 with runway 8,000 ft. — Nadzab
Telecommunications: Papua New Guinea telecom
services are adequate and are being improved;
principal telecom centers include Goroka, Lae,
Madang, Mount Hagen, and Wewak in New Guinea;
and Daru, Port Moresby and Samarai in Papua;
facilities provide radiobroadcast, radiotelephone and
telegraph, coastal radio, aeronautical radio and
international radiocommunication services; numerous
privately owned radio facilities exist; submarine
cables extend from Madang to Australia and Guam;
32,384 telephones, 102,000 radios, but no TV sets; 29
AM, no FM and no TV facilities
DEFENSE FORCES
Military manpower: males 15-49, 693,400, about
329,000 fit for military service
Defense is responsibility of Australia
Railroads: none
Highways: 141 mi.; 78 mi. bituminous, 63 mi.
crushed stone or earth
Ports: 1 minor port (Victoria)
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable on (Praslin Island,
Astove Island, Bird Island, Mahe Island) 1 permanent
surface 8,000-11,999 ft.
Telecommunications: direct radiocommunications
with adjacent islands and African coastal countries;
2,470 telephones; 15,000 radio, and no TV sets; 2AM,
no FM, and no TV stations; submarine cables extend
to Aden, Tanzania, and Sri Lanka
DEFENSE FORCES
Military manpower: males 15-49, 13,000; 7,000 fit
for military service
ame ‘
ae Va
os Geass
2
7
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
dl
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
North
Atlantic
Canary is. (Sp)
4
Freetown 4
Sierr
Leone
Monrovia
Libe
Malabos> vy
Eq. Guinea
a Sao Tome and
“. Principe @
“~
hoy
South
Atlantic
Ocean
500 1000 Miles
500 1000 Kilometers
502852 1-76
ea Fel. et or,
fp Hep. *.
af','f6d9a35b4cc55ca5b8da6d463a8632a264979228539113839128213f0d7a0c6c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee3a087d9e065f0578c84be9984ba503c024195df7dd8bb9a680e5a2e34592b0',1976,'GN','Guinea','communications',35,'Railroads: 25,251 mi.; 5,715 mi. 5''3" gage, 8,323
mi, 4''8''%"" gage, 11,213 mi. 36" gage; 497 mi.
electrified (June 1962); government owned (except for
few hundred miles of privately owned track)
Highways: 530,685 mi. (1974); 129,390 mi. paved,
130,420 mi. gravel, crushed stone, oT stabilized soil
surface, 276,925 mi. unimproved carth
Inland waterways: 5,200 mi.; mainly by small,
shallow-draft craft
Freight carried: rail — 87.3 million short tons
(based on Ist 10 months of FY72); coastal and inland
shipping — 32.6 million tons
Ports: 12 major, numerous minor
Pipelines: crude oil, 460 mi.; refined products, 211
mi.; natural gas, 4,317 mi.
Civil air: 159 major transport aircraft
Airfields: 1,738 total, 1,645 usable, 188 with
permanent-surface runways, 2 with runways over
12,000 ft.; 12 with runways 8,000-11,999 ft., 648 with
runways 4,000-7,999 ft., 3 scaplane stations
Telecommunications: very good international and
domestic service, 4,659,182 telephones; 12.3 million
radio receivers; 3.6 million TY receivers; 183 AM
stations in 127 cities, no FM, 104 TV stations and 47
repeaters; 3 earth satellite stations; submarine cables
to New Zealand, New Guinea, Singapore, Malaysia,
Hong Kong, and Guam
800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000
January 1976
A USTRALIA/AUSTRIA
DEFENSE FORCES
Military Manpower: males 15-49, 3,227,000:
2,842,000 fit for military service; 122,000 reach
military age (17) annually
Military budget: for fiscal year ending 30 June
1975, $2.1 billion: about 10% of total central
zoverament budget
°
(See reference map Vi}
LAND
183,400 sq. mi.; 4% cultivated, 18% grazing, 13%
fallow, 50% forest, 15% other
Land boundaries: 2,830 mi.
WATER
Limits of territorial waters (claimed): 18 n. mi.
Coastline: 250 mi.
Railroads: 623 mi; 533 mi. meter gage, 90 mi.
111%" gage
Highways: approximately 14,000 mi.; including
900 mi. bituminous, 13,100 mi. gravel and earth
Inland waterways: 1,300 mi.
Ports: | major (Douala), 3 minor
Civil air: 6 major transport aircraft
Airfields: 53 total, 52 usable; 7 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 20
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: good telephone service
between Douala and Yaounde, fair in southern part;
fair to good telegraph service; 21,900 telephones;
930,000 radio receivers; 4 AM, no FM, and no TV
stations; 1 submarine cable; microwave radio-relay
under construction Yaounde to Fort Koureau; satellite
ground station at Yaounde
DEFENSE FORCES
Military manpower: males 15-49, 1,434,000;
711,000 fit for military service; average number
reaching military age (18) annually about 62,000
Military budget: for fiscal year ending 30 June
1976, $54,178,204; 10.9% of total budget
fe @
Atlantic
‘Ocean
(See reference map VI}
LAND
10,800 sq. mi.; Rio Muni, about 10,000 sq. mi.,
largely forested; Fernando Po, about 800 sq. mi.
Land boundaries: 335 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 184 mi.
Railroads: none
Highways: Rio Muni — 1,553 mi, including
approx. 115 mi. bituminous, remainder gravel and
earth; Fernando Po — 186 mi. including 91 mi.
bituminous, remainder gravel and earth
Inland waterways: Rio Muni has approximately
104 mi. of year-round navigable waterway, used
mostly by pirogues
Ports: 2 major (Macias Nguema Biyogo, Rey
Malabo}, 3 minor
Civil air: no major transport aircraft
Airfields: 5 total, 3 usable: 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 1
with runway 4,000-7,999 ft.
Telecommunications: fairly adequate for the size
and stage of development of the country; interna-
tional communications by radio from Bata and
Malabo to Cameroon, Nigeria, and Spain; 1,500
telephones; 96,500 radio and 500 TV receivers; 2 AM,
no FM, and 1 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 74,000; 37,000
fit for military service
Major equipment: 10 Soviet amphibious personne!
carriers (3 small and 7 large); 4 P-6 motor gunboats, 1
unidentified patrol craft: 1 Alouette LI helicopter
Military budget: for fiscal year ending 31
December 1970, $3,475,700; 14.3% of total budget
{Ses reference map VI)
LAND
95,000 sq. mi.; 3% cropland, 10% forest
Land boundaries: 2,160 mi.
WATER
Limits of territorial waters (claimed): 130 n. mi.
Approved For Release 2005/04/22
Coastline: 215 mi.
Railroads: 500 mi. meter gage, 5 mi. standard gage
Highways: 4,725 mi.; 465 mi. paved, 2,610 mi. all
weather, 1,650 mi. unimproved earth
Inland waterways: 1,115 mi.; 310 mi. navigable by
small oceangoing vessels, 805 mi. navigable by
shallow-draft steamers and barges
Ports: I major (Conakry), 3 minor
Civil air: 5 major transport aircraft
Airfields: 17 total, 17 usable; 4 with permanent-
surface runways; 4 with runways 8,000-11,999 ft., 7
with runways 4,000-7,999 ft.; 3 seaplane landing areas
Telecommunications: inadequate system of open-
wire lines, small radiocommunication stations, and 1
radio-relay link; principal center Conakry, secondary
center Kankan; 8,300 telephones; 105,000 radio
receivers; | AM, no FM, and no TV stations: 2
submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 924,000; 465,000
fit for military service
Military budget: for fiscal year ending 30
September 1970 (latest information available),
$6,073,000; 8.0% of total budget
(See reference mtd V}
LAND
372 sq. mi. (Sao Tome, 330 sq. mi. and Principe, 42
sq. mi.; including small islets of Pedras Tinhosas)
Approved For Release 2005/04/22 :
WATER
Limits of territorial waters: 6 n. mi. (fishing, 12 n.
mi.)
Coastline: estimated 130 mi.
Airfields: 4 total, 4 usable: 2 permanent surface
runways; 2 with runways 4,000-7,999 ft.
DEFENSE FORCES
A company of 150 local troops has been formed into
a fledgling army.
Riyadh,
SAUDI
ARABIA
"Arabian
Sea
{See reference map Vj
LAND
Estimated at about 900,000 sq. mi. (boundaries
undefined and disputed); 1% agricultural, 1%
forested, 98% desert, waste, or urban
Land boundaries: 2,820 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(plus 6 n. mi. “necessary supervision zone’)
Coastline: 1,560 mi.','1ed7dc66de19b0a5b632a08396a0169e8801b18a653c34227062b46e90749015','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e85fc179ae98848099430b4552c6f08a3d75416a21f387244044287434707ed0',1976,'AT','Austria','communications',36,'es CZECHOSLOVAKIA
Vienna,
(Sse reference map lv)
LAND
32.400 sq. mi.; 20% cultivated 26% meadows and
Pastures, 15% waste or urban, 38% forested, 1;
inland water
T.and boundaries: 1.605 mi,
Railroads: 4,073 mi.; 3,673 mi. government
owned; 3,373 mi. standard gage of which 1,408 mi.
electrified and 833 mi. double tracked; 300 mi.
narrow gage (2’6"") of which 57 mi. electrified; 400 mi.
privately owned; 229 mi. standard gage of which 109
mi. electrified; 171 mi. narrow gage (2''6” and 3''3°/¢"'')
of which 55 mi. electrified
Highways: approximately 21,000 mi. total national
classified network, including 6,500 mi. federal and
14,500 mi. provincial roads; about 13,000 mi. paved
(bituminous, concrete, stone block) and 8,000 mi.
unpaved (gravel, crushed stone, stabilized soil);
additional 38,000 mi. communal
gravel, crushed stone, earth)
Inland waterways: 267 mi.; carries 5% freight, 6%
passengers
roads (mostly
Ports: 2 major river (Vienna, Linz)
Pipelines: crude oil, 500 mi.; natural gas, 1,440 mi.
Civil air: 11 major transport aircraft, including 1
registered but leased from a foreign country
Airfields: 54 total, 51 usable; 13 with permanent-
surface runways; 3 with runways 8,000-11,999 ft., 7
with runways 4,000-7,999 ft.
Telecommunications: highly developed and
efficient; extensive TV and radiobroadcast systems
with 100 AM, 89 FM, and 235 TV stations, 2.06
million telephones; 2.64 million radio receivers; 1.88
million television receivers; COMSAT station is
planned
DEFENSE FORCES
Military manpower: males 15-49, 1,714,000;
1,378,000 fit for military service, average number
reaching military age (19) annually about 56,000
Military budget: for fiscal year ending 31
December 1975, $412 million; about 3.8% of the
federal budget
THE BAHAMAS
Atlantic Ocean
THE
4 \\ BAHAMAS
aa
OMINICAN
REPUBLIC
Caribbean Sea
(See reference map tt}
LAND
4,400 sq. mi.; 1% cultivated, 29% forested, 70%
built on, wasteland, and other
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 2,200 mi. (New Providence Is. 47 mi.)
Railroads: none
Highways: 1,300 mi. total; 530 mi. paved, 770 mi.
gravel
Ports: 2 major (Freeport, Nassau), 9 minor
Civil air: 10 major transport aircraft
Airfields: 51 total, 48 usable: 16 with permanent-
surface runways; 3 with runways 8,000-11,999 ft., 21
with runways 4,000-7,999 ft.. 4 seaplane stations
Telecommunications: telecom facilities highly
developed, including 58,000 telephones in totally
automatic system; tropospheric scatter link with
Florida; 90,000 radio receivers and 30,000 TV sets, 3
AM and 2 FM stations: 3 coaxial submarine cables
1974); crude oil,
12','03f9a1823be872a2ce88fa4d22cf9f3ea296c0bfc4657d8991b9f59240aa5a82','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('872a4c0e9ea26c64dc4d25116edd43aab2f724ad2dd5639aa73e957c5ff1be36',1976,'BH','Bahrain','communications',40,'Arabian
Sea
{See reference map Vj
LAND
230 sq. mi. plus group of 32 smaller islands. 5%
cultivated, negligible forested area, remainder desert,
waste, or urban
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 100 mi.
Highways: 120 mi. bituminous surfaced; undeter-
mined mileage of natural surface tracks
Ports: 1 major (Bahrain)
Pipelines: crude oil, 35 mi.; refined products, 10
mi.; natural gas, 20 mi.
Civil air: 1] major transport aircraft (all registered
in the U.K.)
Airfields: 2 total, 1 usable; 1 with permanent-
surface runway; 1 with runway over 12,000 ft; 1
seaplane station
Telecommunications: excellent international
telecommunications; limited domestic services;
17,700 telephones; 82,000 radio receivers; 10,000 TV
sets; 1 AM _ radiobroadcast station; satellite earth
station; tropospheric scatter Bahrain to Qatar and','c9088cf686cf917ca968c182de15ff682daf176122f4fd126f8e69706e9e44bc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c6305c1de3325512af90dc2687bab60cd61be4997839e75d391888cf49433f6',1976,'AE','United Arab Emirates','communications',44,'Approved For Release 2005/04/22 :
DEFENSE FORCES
Military manpower: males 15-49, 62,000; fit for
military service 34,000
Supply: mostly from U.K.
Military budget: for fiscal year ending 31
December 1975; $14.05 million, 4.3% of total budget
(See reference map Vili}
LAND
32,000 sq. mi.; almost all desert, waste or urban
Land boundaries: 680 mi. (does not include
boundaries between adjacent U.A.E. states)
WATER
Limits of territorial waters (claimed): 3 n. mi. for
all states except Sharjah (12 n. mi.)
Coastline: 900 mi.
Railroads: none
Highways: 175 mi. bituminous, undetermined
mileage of earth tracks
Pipelines: crude oil, 175 mi.
Ports: 5 major, 3 minor
Civil air: 2 major transport aircraft
Airfields: 55 total, 41 usable; 10 with permanent-
surface runways; 2 with runways over 12,000 ft., 2
with runways 8,000-1 1,999 ft., 11 with runways 4,000-
7,999 ft.
Telecommunications: telephone system in Dubayy
and Ash Shariqah also links these towns; Abu Dhabi
Petroleum operates a telecom system throughout the
sheikhdom; key centers are at At Tarif, Habshan, and
Az Zannah; 26,100 telephones; 51,000 radio and
17,000 TV receivers; 3 AM, I FM, and 2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 1,550,000;
about 857,000 fit for military service','632f5706ae9a9d6133e1e2dff7b70a84828a7b72ace465aa8ca90b49b2be2d71','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28e36be7fde51cd0885efaff4118ba5bd81cf4887ea1c7eb218df864313c5962',1976,'BD','Bangladesh','communications',45,'Bay of Bengal
(See raference map Vil)
LAND
55,000 sq. mi.; 66% arable (including cultivated
and fallow), 18% not available for cultivation, 16%
forested
Land boundaries: 1,575 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 360 mi.
Railroads: 1,785 mi.; 1,175 mi. meter gage, 610 mi.
broad gage, 180 mi. double track; government-owned
Highways: 27,500 mi.; 2:500 mi. paved: 1,450 mi.
gravel, 23,610 mi. earth
Inland waterways: 4,350 mi.; river steamers
navigate main waterways
Ports: | major; 5 minor
Pipelines: natural gas, 93 mi.
Civil air: 9 major transport aircraft
Airfields: 26 total, 19 usable: 19 with permanent
surface runways; 2 with runways 8,000-11,999 ft., 10
with runways 4,000-7,999 ft.
Telecommunications: inadequate international
radiocommunications and_ landline service; fair
domestic wire and radiocommunication service: fair
broadeast service; 67,000 {est.) telephones; 400,000
radio sets; 15,000 (est.) TV sets; 1O AM, 1 FM, 1 TV,
and 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 19,307,000:
10,725,000 fit for military service
Military budget: for fiscal year ending 30 June
1975, $88.8 million; about 7% of the central
government budget','1593b19364f4efe1f84784845260e75d293b66402f49a6c8c37bc043ea04220e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc33b96b90d1448d3b3bbe898408c0aee73f78129fe538abf9378316027486f5',1976,'BB','Barbados','communications',49,'DOMINICAN
REPUBLIC .
Atlantic
&=>- z Ocean
PUERTO” =, +
RICO ee
&
8
Caribbean Sea :
a
'' BARBADOS
4, WN a
(See reference map fj
LAND
166 sq. mi.; 60% cropped, 10% permanent
meadows, 30% built on, waste, other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BARBADOS/BELGIUM
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 60 mi.
Railroads: none
Highways: 850 mi.; 800 mi. paved, and 50 mi.
gravel, and earth
Ports: 1 major (Bridgetown), 2 minor
Civil air: 5 major transport aircraft
Airfields: 1 with permanent-surface runway 8,000-
11,999 ft.; 1 seaplane station
Telecommunications: islandwide automatic
telephone system with 42,500 telephones; tropo-
spheric scatter link to Trinidad; VHF links to St.
Vincent and St. Lucia; 100,000 radio and 35,000 TV
sets, 2 AM, 1 FM, and 1 TV stations; 1 telegraph
submarine cable; communications satellite carth
station
DEFENSE FORCES
Military manpower: males 15-49, 51,000; 37,000
fit for military service; average number reaching
military age, (18) annually, 3,000; no conscription','bc561c7882f95201a38bc06bd0a0b88288a0fcf10c13a5b18d5106d8e042a648','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e14711d628d6951b780ac1f6bd5dfade7e571226424b1bf035ac0c3ae4ddcf2',1976,'BE','Belgium','communications',53,'LAND
11,800 sq. mi.; 28% cultivated, 24% meadow and
pasture, 28% waste, urban, or other; 20% forested
Land boundaries: 856 mi.
15
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
{See reference map IV)
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 40 mi.
Railroads: 2,746 mi.; 2,573 mi. standard gage and
government owned, 1,585 mi. double track, 765 mi.
electrified; 173 mi- privately owned, electrified
narrow (3''3%''")
Highways: approximately 65,000 mi., including
650 mi. limited access divided “ Autoroute” ; about
50% paved (bituminous, stone block, concrete) and
50% unpaved (crushed stone, gravel, improved earth)
Inland waterways: 1,270 mi., of which 950 are in
regular use by commercial transport
Ports: 5 major, | minor
Pipelines: refined products, 600 mi.; crude, 100
mi.; natural gas, 1,800 mi.
Civil air: 56 major transport aireraft
Airfields: 45 total, 44 usable; 22 with permanent-
surface runways; 12, with runways 8,000-11,999 ft., 7
with runways 4,000-7,999 ft.
Telecommunications: excellent domestic and
international telephone and telegraph facilities; 2.71
million telephones; 3.8 million radio receivers, 2.51
million TV receivers; 7 AM, 13 FM, and 21 TV
stations; 5 coaxial submarine cables; 1 comunica-
ations satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,238,000;
1,793,000 fit for military service; average number
reaching military age (19) annually 76,000
Military budget: proposed for fiscal year ending 31
December 1975, $1,899 million; about 9% of
proposed central government budget
Approved
p For Release 2005/04/22 : CIA-RDP79-01051A00080001
0001-8','813157bc34c3a8953cf94ee88afdcdef1486362b20220656cb3bec114f8b5368','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaa050cd77936351a09849c42d9918aaf223e1ce681a481b710e06f1687faf0d',1976,'BZ','Belize','communications',57,'(formerly British Honduras)
Gulf of
Pacific
Ocean
S
{See reference map it}
LAND
8,870 sq. mi; 38% agricultural (5% cultivated),
46% exploitable forest, 16% urban, waste, water,
offshore islands or other
Land boundaries: 320 mi.
WATER
Limits of territorial waters (claimed): 3 0. mi.
Coastline: 240 mi.
Railroads: none
Highways; 1,400 mi; 200 mi. paved, 500 mi.
Sravel, 550 mi. improved earth and 150 mi.
unimproved earth
18
Inland waterways: 514 mi. river network used by
shallow-draft craft
Ports: | major (Belize), 4 minor
Civil air: no major transport aircraft
Airfields: 36 total, 36 usable: 4 with permanent-
surface runways; ] with Tunway 4,000-7,999 ft.; 1
seaplane station
Telecommunications: 4,000 telephones in auto-
matic and manual network; radio-relay system under
construction; 68,000 radio receivers; 4 AM Stations
DEFENSE FORCES
Military manpower: males 15-49, 30,000; 19,000
fit for military service; 1,500 reach military age (18)
annually
Atlantic
Ocean','92bb86ee4e626333398d6ef76db093c5ab666a56b851d3ab7120defd3f0e239e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9667a2ed9572c11f1e8618bc3516abb565230c23f1cea1a567024542c35f87d2',1976,'MX','Mexico','communications',58,'Caribbean
Sea
x Balmopan
Caribbean
(Ses reference map if}
Railroads: 592 mi., 30 gage; single-tracked; 520 mi.
government owned, 72 mi. privately owned
Highways: 7,700 mi., 1,600 mi. bituminous, 3,950
mi. gravel, 2,150 mi. improved or unimproved earth
Inland waterways: 164 mi. navigable year-round;
additional 458 mi. navigable during high-water
season
Pipelines: crude oil, 30 mi.
Freight carried: rail (1960) — 191.8 million
ton/miles, 1.1 million tons
Ports: 2 major (Puerto Barrios, Santo Tomas de
Castilla), 3 minor
Airfields: 341 total, 337 usable; 7 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 17
with runways 4,000-7,999 ft.; 1 seaplane station
Civil air: 12 major transport aircraft
Telecommunications: modern telecom facilities
limited to Guatemala City; 57,400 telephones;
360,000 radio and 108,000 TV receivers; 97 AM, 20
FM, and 5 TV stations; connection into Central
American microwave net
DEFENSE FORCES
Military manpower: males 15-49, 1,427,000;
879,000 fit for military service; about 65,000 reach
military age (18) annually
Military budget: proposed for fiscal year ending 31
December 1975, $26.4 million; 6.6% of central
government budget
. ~
ampico
P Prk and
ed Caicos Is.
(U.K
\\ Peacto ae. _eAntigua (U.K.
ee Domingo tg Nevis (U.K. :
Kingston % Guadeloupe (Fr
% aera? S ABaminicalU.K
is & (Martinique (
- i O 4St w
Caribbean Sea © aS bucian
Pacific seer
Netherlands Antilles = *Grenada
7 = “Trinidad
oO Cc e a n inte iy fagao Pess-ot Seeing and Toba
S eo
ae . cates aes MN
Venezuela
y Bogota','8b78afc8f3d5298059c25955aabe0929ba39577b1b61acce37e64b252a43145e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5c3280822a658a9c81fd921b73551e41a0b22628c2018899fd32e69d9675ac2',1976,'BM','Bermuda','communications',62,'(See reference Map It)
LAND
21 sq. mi.; 8% arable, 60% forested, 21% built on,
wasteland, and other, 11% leased for air and naval
bases
WATER
Limits of territorial waters (claimed): 3 pn. mi.
Coastline: 64 mi.
Railroads: none
Highways: 130 mi., all paved
Ports: 3 major (Hamilton, St. George’s Freeport,
Ireland Island)
Civil air: no major transport aircraft
Airfields: 1 with concrete runway 9,710 ft; 1
seaplane station
Telecommunications: modern telecom system,
includes fully automatic telephone system with 36,500
sets; 50,000 radio and 22,000 TV receivers, 2 AM, 2
FM, and 2 TV stations; 3 coaxial submarine cables
Approved For Release 2005/04/22','6b9acb05b8161d4b4e55638c01b518587928702be3488af2591bc29107aaf736','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aeddcb1d04b511fe84dd5dbd6ae23f1b506dfbf15ea091809ebbaa05945859ca',1976,'BT','Bhutan','communications',66,'Bay of
Bengal
(See reference map Vif)
LAND
18,000 sq. mi.; 15% agricultural, 15% desert, waste,
urban, 70% forested
Land boundaries: about 540 mi.','a37a3c561f5d1f44b085530903bda5a6073d160a2521d2096c6c720c509fb49a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('345a94581a61254775a690417c3e88d5b01d6fea4f585729a92ca2954c383e37',1976,'IN','India','communications',70,'Highways: 810 mi.; 260 mi. surfaced, 320 mi.
improved, 230 mi. unimproved earth
Freight carried; not available, very light traffic
Civil air: no major transport aircraft
Airfields: 2 total, 1 asphalt runway 4,500 ft., and I
with concrete runway 2,950 ft.
Telecommunications: facilities almost nonexistent;
570 telephones; 6,000 est. radio sets; no TV sets: 1 FM
and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 279,000: 150.000
fit for military service; about 9,000 reach military age
(18) annually
Supply: dependent on India
BOLIVIA
LAND
424,000 sq. mi.; 2% cultivated and fallow, 11%
pasture and meadow, 45% urban, desert waste, or
other, 40% forest, 2% inland water
Land boundaries: 3,780 mi.
Railroads: 2,310 mi., single track; 2,290 mi., meter
gage, 20 mi., 2''6"’ gage; all government owned except
60 mi. of meter-gage track; 5.6 mi. of meter-gage
track electrified
Highways: 23,200 mi.; 700 mi. paved, 4,100 mi.
gravel, 3,700 mi. improved earth, 14,700 mi.
unimproved earth
Inland waterways: officially estimated to be 6,250
mi. of commercially navigable waterways
Pipelines: crude oil, 1,040 mi.; refined products
and crude 930 mi.; natural gas 350 mi.
Ports: none (Bolivian cargo moved through Arica
and Antofagasta, Chile, and Matarani, Peru)
Civil air: 60 major transport aircraft
Airfields: 561 total, 520 usable; 4 with permanent-
surface runways; 1 with runway over 12,000 ft., 4 with
runways 8,000-11,999 ft., 116 with runways 4,000-
7,999 ft.
Telecommunications: poorest telecom facilities on
continent; radio-relay network under construction;
53,000 telephones; est. 2.5 million radio and 44,000
TV receivers; 84 AM, 17 FM, and 2 TV stations,
COMSAT station planned
DEFENSE FORCES
Military manpower: males 15-49 1,227,000;
770,000 fit for military service, average number
reaching military age (19) annually about 58,000
(See reference map Vit}
LAND
1,211,000 sq. mi. (includes Indian part of Jammu-
Kashmir, Sikkim, Goa, Damao and Diu); 50% arable,
5% permanent meadows and pastures, 20% desert,
waste, or urban, 22% forested, 3% inland water
Land boundaries: 7,880 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi.; additional 100 mi. is fisheries
conservation zone, December 1968; archipelago
concept baselines)
Coastline: 4,378 mi. (includes offshore islands)
Railroads: 38,076 mi.; 16,259 mi. meter (3''3%"’)
gage, 18,892 mi. broad gage, 2,796 mi. (2’6" and
2’0") narrow gage government owned; 129 mi. 2''6”’
and 2''0” gage privately owned; 7,300 mi. double
track; 2,485 mi. electrified
Highways: 795,607 mi.; 148,621 mi. paved,
111,876 mi. gravel or crushed stone, 216,044 mi.
improved earth, 319,066 mi. unimproved earth
Inland waterways: 8,750 mi.; 1,600 mi. navigable
by river steamers
Pipelines: crude oil, 794 mi.; refined products,
1,163 mi.; natural gas, 223 mi.
Ports: 8 major, 80 minor
Civil air: 86 major transport aircraft
Airfields: 374 total, 348 usable; 181 with
permanent-surface runways; 2 with runways over
12,000 ft., 52 with runways 8,000-11,999 ft., 118 with
runways 4,000-7,999 ft.
96
Telecommunications: fair domestic telephone
service where available; telegraph facilities wide-
spread; AM _ broadcast adequate; TV limited to
Bombay and New Delhi; international radio
communications adequate; 1,590,000 telephones;
14,033,919 radio and 75,000 TV sets; about 124 AM
stations at 80 locations, 6 TV stations, one earth
satellite station; submarine cables extend to Malaysia,
Sri Lanka, and Aden
DEFENSE FORCES
Military manpower: males 15-49, 141,619,000;
73,295,000 fit for military service; about 6,400,000
reach military age (17) annually
Military budget: for fiscal year ending 31 March
1976, $3.1 billion; 22% of total budget','801e974dd27de9b53cf0eaa181ef8ce5d561110389ac3b6d0cadf7b3171f0730','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a535a957aab7f9f79f8cdb59c2568a26025a960e62fc000ec23d2a287f33338',1976,'BW','Botswana','communications',72,'Atlantic
Ocean
(See reference map VI)
LAND
220,000 sq. mi.; about 6% arable, less than 1%
under cultivation, mostly desert
Land boundaries: 2,345 mi.
Railroads: 400 mi. 3''6” gage, single track: owned
and operated by the Rhodesia Railroads
Highways: 12,900 mi.; 50 mi. paved: 730 mi.
crushed stone or gravel; remainder improved earth
and unimproved earth
Inland waterways: native craft only; of local
importance
Civil air: 2 major transport aircraft
Airfields: 84 total, 74 usable: 3 with permanent-
surface runways; 18 with runways 4,000-7,999 ft.
Telecommunications: the system is a minimal
combination of open wire lines, radio telav links, and
a few radiocommunication stations: Gaborone is the
center; 6,170 telephones; 55,000 radio receivers: 1
AM, I FM, and no TV stations
DEFENSE. FORCES
Military manpower: males 15-49, 161,000; 83,000
fit for military service: 8,000 reach military age (18)
annually','cc18b6a7fb73bdcaf189683a34f84632d0a0781065bd17e3535d981f2e54cf2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce4c14465405907b484277363d3fbe6af908c3e9c1e8c069d6d9c75ab4a8d1bc',1976,'BR','Brazil','communications',75,'LAND
3,290,000 sq. mi.; 4% cultivated, 13% pastures,
23% built-on area, waste, and other, 60% forested
Land boundaries: 8,125 mi
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Atlantic
Brasilia
*
{See reference map tit}
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 4,655 mi.
Railroads: 19,935 mi.; 17.586 mi. 3''3%" gage,
2,085 mi. 5''3"" gage, 121 mi. 4’8%" gage, 143 mi.
narrow gages; 1,621 mi. electrified
Highways: 811,000 mi.; 48.000 mi. paved, 763,000
mi. gravel or earth
Inland waterways: 31,000 mi. navigable
Ports: 6 major, 25 significant minor
Pipelines: crude oil, 770 mi.: refined products, 290
mi.; natural gas, 24 mi.
Civil air: 181 major transport aircraft
Airfields: 4,044 total, 3,933 usable; 147 with
permanent-surface runways; 14 with runways 8,000-
11,999 ft., 899 with runwavs 4,000-7,999 ft.. 18
seaplane stations
Telecommunications: moderately good telecom
system; radio relay widely used; 4 communications
satellite ground stations; 2.75 million telephones; est.
32 million radio and 9.0 million TV receivers: 1,005
AM, 150 FM, and 165 TV stations; 6 submarine
cables, including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 24,561,000;
16,031,000 fit for military service; 1,200,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
December 1975, $1,321 million; 8.7% of federal
budget
BRITISH SOLOMON ISLANDS
LAND
About 11,500 sq. mi.
WATER
Limits of territorial waters: 3 n. mi.
Coastline: about 3,300 mi.
Railroad: none
Highways: 518 mi.; 150 mi. sealed or all-weather
1 Australian dol-
Inland waterways: nonc
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 22 total, 21 usable; 1 permanent surface
runway 6,300 ft.; 6 natural surface runways 4,000-
7,999 ft., 14 natural surface runways less than 3,999
ft.; 3 seaplane stations
Telecommunications: 3 AM broadcast, no FM,
and no TV stations; 7,700 radio receivers, 1,526
telephones, no TV scts; international connections with
London, England, via cable broadcasts
BRUNEI
BRUNEI
Bandar Seri Begaw:
{See reference map Vit}
LAND
2,230 sq. mi.; 3% cultivated; 22% industry, waste,
urban or other; 75% forested
Land boundaries: 237 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 100 mi.
Railroads: 6 mi. narrow gage (20)
Highways: 750 mi.; 234 mi. paved (bituminous
treated), 250 mi. gravel or stone, 266 mi. unimproved
Inland waterways: 130 mi.; navigable by craft
drawing less than 4 ft.
Ports: 2 minor (Bandar Seri Begawan, formerly
Brunei, and Kuala Belait)
25
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BRUNEI/BULGARIA
Pipelines: crude oil, 84 mi.: refined products, 35
mi.; natural gas, 35 mi.; crude oil and natural gas, 150
mi. under construction
Civil air: 2 major transport aircraft
Airfields: 3 total, 3 usable: 2 with permanent-
surface runway; | with runway over 12,000 ft.; 2 with
runways 4,000-7,999 ft.
Telecommunications: service throughout country
is adequate for present needs: international service
good to adjacent Sabah and Sarawak; radiobroadcast
coverage good; 7,788 telephones; 20,000 radio and
3.000 est. TV sets: Radio Brunei broadcasts from 3
AM, 1 FM, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 37,000; 22.000
fit for military service; about 1,000 reach military age
(18) annually','2c6481eb67d0e047ae40355548280d185080deef30dc59a732b7696c8b1a9d82','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66c640adccf44cdebdceaae552d44011484752ea6d0f80862b85eda077343440',1976,'BG','Bulgaria','communications',79,'(See reference map iV}
LAND
42,800 sq. mi.; 41% arable, 11% other agricultural,
88% forested, 15% other
Land boundaries: 1,170 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 220 mi.
Railroads: 2,646 mi.; about 2,494 mi. standard
gage, 152 mi. narrow gage; 157 mi. double track; 692
mi. electrified; government owned (1975)
Highways: 22,300 mi.; 13,100 mi. paved, 6,100 mi.
crushed stone and gravel, 3,100 mi. carth (1974)
Inland waterways: 300 mi. (1975)
Freight carried: rail — 85.8 million short tons, 11.8
billion short ton/mi. (1974); highway—698.5 million
short tons, 6.5 billion short ton/mi. (1974);
waterway—4.9 million short tons, 1.7 billion short
ton/mi. (excl. int''l. transit traffic) (1974)
Ports: 2 major (Varna, Burgas), 5 minor (1975)
Civil air: 41 major transport aircraft (1975)
DEFENSE FORCES
Military budget: for fiscal year ending 31
December 1975, est. 549 million leva; about 6% of
total budget
BURMA
LAND
262,000 sq. mi. 28% arable, of which 12% is
cultivated, 62% forest, 10% urban and other (1969)
Approved For Release 2005/04/22
Bay
of Bengal
{Sea reference map Vil)
Land boundaries: 3,630 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,900 mi.
Railroads: 2,041 mi.:; 1,971 mi. meter gage, 70 mi.
narrow-gage industrial lines; 204 mi. double track:
government owned
Highways: 15,535 mi. 4,205 mi. paved, 4,775 mi.
gravel, 6,555 mi. unimproved earth
Inland waterways: 8,000 mi.: 2,000 mi. navigable
by large commercial vessels
Ports: 4 major, 6 minor
Civil air: 14 major transport aircraft
Airfields: 80 total, 79 usable; 23 with permanent-
surface runways, 2 with runways 8,000-11,999 ft., 38
with runways 4,000-7,999 ft.
28
Telecommunications: provide minimum require-
ments for local intercity service; international service
is fair; radiobroadcast coverage is limited to the more
populous areas; 29,411 telephones; 627,000 radio, and
no TV sets; 1 AM, 1 FM, and no TV stations
Cyprus. _7 oi
( xNicosia
Mediterranean Sea Lebanagf,
Beiruf”
isra
*
2p ~Amman,
“f
Gulf of','fa781ef1d0e472c4a538044116aa82a0e4ec0f817570a48783be6bccef56c1f7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e62da1313faf8a8e0ad8c3f84ff1813765431a044deb9dd1e9fab3591d98af5',1976,'BI','Burundi','communications',83,'(See reference map Vi)
LAND
11,000 sq. mi.; about 87% arable (about 66%
cultivated), 23% pasture, 10% scrub and forest, 30%
other
Land boundaries: 605 mi.
Railroads: nonce
Highways: 3,700 mi.; 338 mi. bituminous,
remainder crushed stone, gravel, laterite, and
improved or unimproved earth
Inland waterways: Lake Tanganyika navigable for
lake steamers and barges
Ports: 1 minor lake
Civil air: 8 major transport aircraft
Airfields: 12 total, 12 usable; 1 with permanent-
surface runway; | with runway 8,000-11,999 ft.
Telecommunications: telegraph is principal
service, limited telephones; 4,800 telephones, 100,000
radio receivers; 2 AM, 1 FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 888,000; 461,000
fit for military service; 43,000 reach military age (16)
annually
Ships: 3 high speed boats
Military budget: for fiscal year ending 31
December 1975, $8,556,000; about 23.4% of ordinary
budget','43712a70459e37ef9b11c2fbca249e87cbfb86fbc5661a917723c1507203aa96','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76fb1c311b49c84647ca88d382a4ad3948279226f778d4c38afd9959132df067',1976,'KH','Cambodia','communications',87,'{See reference map Vit)
LAND
70,000 sq. mi.; 16% cultivated, 74% forested, 10%
built-on area, wasteland, and other
Land boundaries: 1,515 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: about 275 mi.
Railroads: 380 mi. meter gage: government owned:
many sections in disrepair due to hostilities
Highways: 8,100 mi.; 1,510 mi. bituminous, 4.370
mi. crushed stone, gravel, or improved earth; and
2,220 mi. unimproved earth; some roads not operable
because of recent hostilities
Inland waterways: 2,300 mi. navigable all year to
craft drawing 2 ft.; 175 navigable to craft drawing 6 ft
Ports: 2 major, 5 minor
Airfields: 60 total, 25 usable: 7 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 6
with runways 4,000-7,999 ft.: 1 seaplane station
DEFENSE FORCES
Military manpower: males 15-49, 1,776,000:
986,000 fit for military service; 78,000 reach military
age (18) annually','d33a8be5142b1d0e927da1330c6550a586ddb604eced425e82b66eb59bceea4d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d03522799d6f1e07751d3872bbef469f7a9f71b37db7aae422d23b07125df9c0',1976,'CA','Canada','communications',93,'Arctic 0 a0
(See reference map H
LAND
3,850,000 sq. mi.; 4% cultivated, 2% meadows and
pastures, 44% forested, 42% waste oF urban, 8%
inland water
31
00800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0
Land boundaries: 5,600 mi.
WATER
Limits of territorial waters (claimed); 12 n mi.
Coastline: 56,500 mi.
Railroads: 46,351 mi.; 45,513 mi. 4’8%" gage (27
mi. clectrified); 727 mi. 3/6" gage (in New-
foundland); 111 mi. 3’ gage
Highways: 518,177 mi.; 396,088 mi. surfaced
(109,234 mi. paved), 122,089 mi. earth
Inland waterways: 1,875 mi.
Pipelines: oil, 13,140 mi.; natural gas, 46,425 mi.
Ports: 19 major, 300 minor
Civil air: 596 major transport aircraft
Airfields: 1,764 usable; 263 with permanent-
surface runways; 3 with runways over 12,000 ft., 29
with runways 8,000-11,999 ft., 276 with runways
4,000-7,999 ft.; 58 seaplane stations
Telecommunications: excellent service provided by
modern telecom media; 12.8 million telephones; 22.0
million radiobroadcast receivers; 9.2 million TV
receivers; countrywide AM, FM, and TV coverage
including 630 AM, 80 FM, and 480 TV stations; 8
coaxial submarine cables; 3 satellite earth stations
DEFENSE FORCES
Military manpower: males 15-49, 5,556,000;
4,777,000 fit for military service; average number
reaching military age (17) annually 230,000
Military budget: proposed for fiscal year ending 31
March 1976, $2.8 billion; about 10% of proposed
central government budget
CAPE VERDE ISLANDS
CAPE VERDE ISLANDS
oe 0
6 ©
28 Bernie
GUINEA:
VEL
BISSAU v4
e
(See reference map IV)
-..- Atlantic Ocean
LAND
1,560 sq. mi., divided among 10 islands and several]
islets
WATER
Limits of territorial waters: 6 n. mi. (fishing 12 n.
mi.)
Coastline: 600 mi.
Airfields: 6 total, 6 usable; 4 permanent surface
Tunways; | with runway 8,000-11,999 ft.. 4 with
runways 4,000-7,999 ft.; | seaplane station','a947c7fb985dd7507315024b93397e0967eb905d8a3276fd489bb3ba85a5fba8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47d8053982545f57bb1a414911f59b0f0fc25524dd6c19ebc7228e333e477380',1976,'CF','Central African Republic','communications',97,'{See reference map V1)
LAND
242.000 sq. mi.; 10%-15% cultivated, 5% dense
forests, 80%-85% grazing, fallow, vacant arable land,
urban, waste
Land boundaries: 3,095 mi.
Railroads: none
Highways: 13,250 mi.; 115 mi. bituminous, 2,265
mi. gravel and/or crushed stone, 3,420 mi. improved
earth, 7,450 mi. unimproved carth
Inland waterways: 4,400 mi.; traditional trade
carried on by means of dugouts on the extensive
system of rivers and_ streams; the Oubangui River
between Bangui and Brazzaville is navigable for
about 8 months a year, and short sections of the
Sangha and the Lobaye Rivers are navigable
throughout year; during high-water period (July -
December) Oubangui navigable upstream from
Bangui as far as Ouango
Ports: Bangui, Ouango (river ports)
Civil air: 4 major transport aircraft
Airfields: 58 total, 48 usable; 3 with permanent-
surface runways; | with runway 8,000-11,999 ft., 18
with runways 4,000-7,999 ft.
Telecommunications: facilities are meager and
provide only barely sufficient services; network is
composed of low-capacity, low-powered radiocom-
munication stations and radio-relay links; single
center of Bangui has only international radio
connections; 5,100 telephones; 70,000 radio receivers;
1 AM, 1 FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 457,000; 235,000
fit for military service
Supply: mainly dependent on France, but has
received equipment from Israel, Italy, U.S.S.R.','d57049652253edc8ac4c1809a0eee0a554598b06fda9bfe64d643df62513d66d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28d880d9716d33437a53df27b0bad997dc4dddae4ff9e9ec9dc5bf3ed7fa5206',1976,'TD','Chad','communications',101,'{Sea reference map Vi}
LAND
496,000 sq. mi.; 17% arable, 35% pastureland, 2%
forest and scrub, 46% other uses and waste
Land boundaries: 3,720 mi.
Approved For Release 2005/04/22
Railroads: none
Highways: 19,200 mi.; 160 mi. bituminous, 3,300
mi. gravel and laterite, and 15,740 mi, unimproved
Inland waterways: approximately 1,300 mi. of
year-round navigability, increased to 3,000 mi. during
high-water period
Civil air: 3 major transport aircraft
Airfields: 67 total, 63 usable: 4 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 25
with runways 4,000-7,999 ft.
Telecommunications: fair system of radiocom-
munication stations only for intercity links: principal
center N''Djamena, secondary center Sarh: 5.100
telephones; 70,000 radio receivers: 1 AM, no FM, and
no TY stations
DEFENSE FORCES
Military manpower: males 15-49, 964,000; 495,000
fit for military service: average number reaching
military age (20) annually about 37,000
36
Supply: dependent on France primarily
Military budget: for fiscal year ending 3]
December 1973, $15,228,000; about 21% of total
budget
Pacific
Ocean
Atlantic
Ocean
(See reference map ttl}
LAND
286,000 sq. mi; 2% cultivated, 7% other arable,
15% permanent pasture, grazing, 29% forest, 47%
barren mountains, deserts, and cities
Land boundaries: 3,930 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing 200 n. mi.)
Coastline: 4,000 mi.','9c1585580849efe174215abc7ecfc62455db94479c9b97612d22287cea7e4412','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e882dbd87981557f29da639aa2b293f9cded51d015de4ee98346b3d07a170bf',1976,'CL','Chile','communications',107,'Railroads: 5,511 mi.; 2,086 mi. 5''6” gage, 154 mi.
4''814" gage, 2,644 mi. 3’3%" gage, 69 mi. 2’6"'' gage,
92 mi. 1/1154" gage, 536 mi. specific gage not given;
199 mi. double track; 711 mi. electrified
Highways: 39,600 mi.; 5,500 mi. paved, 19,800 mi.
gravel, 14,300 mi. improved and unimproved earth
Inland waterways: 451 mi.
Pipelines: crude oil, 470 mi.; refined products, 490
mi.; natural gas, 200 mi.
Ports: 10 major, 20 minor
Civil air: 41 major transport aircraft
Airfields: 361 total, 361 usable; 43 with
permanent-surface runways; 3 with runways 8,000-
11,999 ft., 55 with runways 4,000-7,999 ft.; 6 seaplane
stations
$2.7 billion
Telecommunications: extensive radio relay
network; telephone network modern, 465,000
37
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CHILE/CHINA, PEOPLES REPUBLIC OF
instruments; communications satellite ground station;
2.75 million radio and 1 million TV receivers; 153
AM, 30 FM, and 55 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 2,508,000:
1,892,000 fit for military service: average number
reaching military age (19) annually about 94,000
Military budget: for fiscal year ending 31
December 1975, US$353.5 million: about 18.7% of
central government budget
CHINA, PEOPLES REPUBLIC OF
(See reference map Vilj
LAND
3.7 million sq. mi.; 11% cultivated, sown areca
extended by multicropping, 78% desert, waste, or
urban (32% of this area consists largely of denuded
wasteland, plains, rolling hills, and basins from which
about 3% could be reclaimed), 8% forested: 2%-3%
inland water
Land boundaries: 15,000 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 9,000 mi.
Airfields: 382 total; 243 with permanent-surface
runways; 7 with runways over 12,000 ft., 78 with
runways 8,000-11,999 ft., 212 with runways 4,000-
7,999 ft.; 2 seaplane stations
CHINA, REPUBLIC OF
LAND
14,000 sq. mi. (Taiwan and Pescadores); 24%
cultivated, 6% pasture, 55% forested, 15% other
(urban, industrial, denuded, water area)
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 615 mi. Taiwan, 285 mi. offshore islands
Approved For Release 2005/04/22 :
Taipei
REPUBLIC. OF','60068ac5c3b9048990803d70c0f7e4e04de0a9e0ec431b3a8fab0a257f6f08ab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('beb0da1b68198bd2bd30ff5707eff95f3315f86ac7f1bfe04e7824c92b7b906a',1976,'CN','China','communications',109,'3, PHILIPPINES
” (See relatoned map Vil}
Pipelines: 382 mi. refined products, 60 mi. natural
gas
Airfields: 37 total, 37 usable; 27 with permanent-
surface runways; 2 with runways over 12,000 ft., 10
with runways 8,000-11,999 ft., 11 with runways 4,000-
7,999 ft.; 2 seaplane stations
Telecommunications: good international and
domestic service; 742,304 telephones; est. 3 million
radio receivers; 1.3 million TV receivers: 11] AM, 4
FM _ broadcast stations; 3 TV systems: 2 satellite
ground stations; radio relay links to Hong Kong and
the Philippines; new inter-island submarine cables:
Manila submarine cable planned
DEFENSE FORCES
Military manpower: mules 15-49. 3,980,000:
3,110,000 fit for military service: average number
currently reaching military age (19) annuallv 192.000','6504e4371759f3efa9ecea1b20e0c61ae09b5327932782a3c51a68afacbc03be','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55b368de391a3595ffd86c21ce0063626c5b082e13cea128781e51806dd3eb25',1976,'CO','Colombia','communications',113,'oo mS =
+ Bogota
Pacific
Ocean
(See reference map tit)
LAND
440,000 sq. mi.; settled area 28% consisting of
cropland and fallow 5%, pastures 14%, woodland,
swamps, and water 6%, urban and other 3%:
unsettled area 72% — mostly forest and savannah
Land boundaries: 3.750 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,500 mi.
Railroads: 2,160 mi., all 3''0” gage, single track, 22
mi. electrified
Highways: 32,700 mi.; 4,500 mi. paved, 23,200 mi.
crushed stone or gravel, 5,000 mi. improved carth
Inland waterways: 8,900 mi., navigable by river
boats
Pipelines: crude oil, 2,000 mi.; refined products,
830 mi.; natural gas, 370 mi.; natural gas liquids 80
mi.
Ports: 5 major, 5 minor
Civil air; 105 major transport aircraft
Airfields: 714 total, 700 usable; 44 with
permanent-surface runways; 1 with runway over
12,000 ft.; 6 with runways 8,000-11,999 ft., 86 with
runways 4,000-7,999 ft.; 11 seaplane stations
4]
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
COLOMBIA/COMORO ISLANDS
Telecommunications: nationwide radio-relay
telecom system; communications satellite ground
station: 1.22 million telephones; 6.5 million radio and
1.4 million TV receivers; 8325 AM, 130 FM, and 55 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 5,869,000,
3,710,000 fit for military service; average number
reaching military age (18) annually about 248,000
Military budget: proposed for fiscal year ending 31
December 1975, $115.5 million; about 8.9% of central
government budget
COMORO ISLANDS
fndian Ocean |
comoro
, ISLANDS
CAR
(See reference map VI)
LAND
838 sq. mi.; 4 main islands; forests 16%, pasture
7%, cultivable area 48%, non-cultivable area 29%
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 211 mi.
Railroads: none
Highways: 621 mi.; approximately 183 mi.
bituminous, remainder crushed stone or gravel
Ports: | minor (Moroni on Grande Comore)
Civil air: 7 major transports (registered in France)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
eh DOOD SSN
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
COMORO ISLANDS/CONGO
Airfields: 5 total, 5 usable; 5 with permanent
surface runways; | with runway 8,000 to 11,999 feet, 4
with runways 4,000-7,999 ft.
Telecommunications: minimal system of HF
radiocommunication stations for interisland island
and external communications to Malagasy and
Reunion; Dzaoudzi center but of slight significance,
1,300 telephones; 35,500 radio receivers; 1AM,1FM,
and no TV stations
(See reference map Vi)
LAND
135,000 sq. mi.; 63% dense forest or woodland, 33%
cultivable or grazing (2% cultivated est.), 4% urban or
waste
Land boundaries: 2,805 mi.
WATER
Limits of territorial waters (claimed): 30 n. mi.
Coastline: 105 mi.
Railroads: 490 mi., 3''6” Zage, single track
Highways: 6,741 mi. 380 mi. bituminous surface
treated; remainder gravel, laterite, or improved earth
Inland waterways: 4,030 mi. navigable
Ports: | major (Pointe Noire)
Civil air: 7 mujor transport aircraft
Airfields: 7] total, 53 usable; 2 with permanent-
surface runways; | with runway 8,000-11,999 ft., 18
with runways 4,000-7,999 ft.: 1 seaplane station
Telecommunications: services adequate for
government and public; network js comprised of low-
capacity, low-powered radio communication stations,
coaxial cables and wire lines, connect key centers of
Brazzaville, Pointe-Noire, and Dolisie with maximum
of 2] channels; 10,200 telephones; 75,000 radio
receivers; 2,600 TV receivers; 3AM, no FM, and 1 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 324,000; 162,000
fit for military service; about 13,000 reach military
age (20) annually
Military budget: for fiscal year ending 31
December 1975, $37,331,882: about 10.8% of total
budget
Manaus
200,
Age
Braz
“Salvador
S Brasilia
Bolivia
Sucre
Antofagas . OS
ntofaga: Sao Paulo, _- “*Rio de Janeiro
es
va
South
Atlantic
Buenos Aires*® : f
Montevideo
Ocean
400 800 Miles
400 800 Kilometers a
Ve cs
alapagos Is.
BOUNDARY REPRESENTATION IS G (ae ae)
NOT NECESSARILY AUTHORITATIVE
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
vad aL EN
Approved
p For Release 2005/04/22 : CIA-RDP79-01051A000800010
001-8
T Canada
Ellesmer''
island
2604
aM nited. ,
og tat es tee
“Fairbanks ‘
Thule® 2
Baffin Bay
2 a
Py 5
/ yukon }
Territory \\ geariake
Ch 7 nen if ay
Jungal N \\
Pi ms,
re a8 Yellowknife ‘i
ae > a ~ Territ
Vig rh, slave Lake
/ on
ef Pri R .
a rince Rupert ’) pa
Pacific « British / i :
Ocean coiwmbia / Albert | | Churchill
4 ert] ;
‘Edmonton \\ c | a >
5 5 j Manitoba /
Vancouver ! Saskaichewan S
Re : Calgary? Saskatoon ! wr
eattle / | f
ee ; > Lake
cif Rodina» fewer l Ontario
fi ‘Winnipe
ee a
F Halifax.
Nqva Scotia
\\ Montreal »
a .
~—
aie ry Ry alt Lake City
L. Michigan
Milwaukee
Ghicago
ae : Atlantic Ocean
Washington x
Los fingeles : Kansas city * :
“gags Ys ener ‘@ St. Louts
nited States
“6 \\Qklahoma City *
: f =.
Na Geek | \\
os 0 590 Miles
0 500 Kilometers
io BOUNDARY REPRESENTATION is
NOT NECESSARILY AUTHORITATIVE
502847 1-76
Approved
p For Release 2005/04/22 : CIA-RDP79-01051A000800010
001-8
action: \\(tai
macae Hong Kong N Talwar
(Port) (U.K)
Brunei
GLE.
Java Sea 3.
Banda Sea
‘indonesia
<p =. < 9° e fi
Pes he gc: Chee ne * =
L/
eC
é
INDIAN
OCEAN
502854 1-76
ortuguese
Timor
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
} Wake U.S.)
MARIANA .
ISLANDS ©
Saipan
Guam WS.) e
Trust Territory of the Pacificisiands =e
Yap 7 P “US.) a Rog
Kwajaiein
VIII Oceania
Se>Maui
HAWAHAN:
ISLANDS
(United
States.
, dofinston ,
a8.)
N OR T H
> Hawaii
PAC Hl FE
1 PALAU
ISLANDS
Arafura Sea
CAROL ing
~ ><, New Ireland
es
ea ‘ as
inea
Truk : :
Islands". :. Ponapes Kingman Reet
ws)
* ISLANDS
Howland (U.S)
Baker (U.S.)}
° oo, (SUK, joint admin.)
Canton.*" PHOENIX IS.
Phoenix .-~ ° (U.K. admia., US. claim}
Gardner’ Hulf
fbert
(U.K)
invitl
pecseinuls Solomon islands ae G i
wChoiseul CULK.)
ha Santa isabe! » OK)
es 4 ELLICE ": roe
Malaita p
Honiar. \\ : SANTA ISLANDS =: US Bhaimed by U8.) :
Guadalcanal gan Cristobal“ CRUZ d American ;
= Rennell oe ae Samos ,
. BS tS, Western (U.S.)
: . Wallis and Futuna samoa
Fiji a) og Pago
“ Apia” a" 490
Tutuila
Tuvalu Is.','23ba5c60e587a7ae81ce7cd2a6d2c26108fdf0b34399665ef6f8cefa4f761f71','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7572a1a7e6774ec1c8ce3afb19af9c5219d0b206fc5f914faa44b44cad7c8909',1976,'CK','Cook Islands','communications',117,'LAND
About 93 sq. mi.
WATER
Limits of territorial waters: 3 0. mi.
Coastline: about 75 mi.
Railroads: none
0001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00080001
4,
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
COOK ISLANDS/COSTA RICA
Highways: 162 mi.: 12 mi. paved, 68 mi. gravel, 52
mi. improved earth, 30 mi. unimproved earth
Inland waterways: nonc
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 3 total; 1 with composite surface runway
7,240 ft., 3 with natural surface runways 4,000-7,900
ft., 2 seaplane stations
Telecommunications: 3 AM, no FM, and no TV
stations: 7,000 radio receivers, and 740 telephones;
microwave relay station provides connection with
(New Zealand)
Santo s
New Hebrides 4
(Aagia-Freneca Condominium) é
FIU} ISLANDS |. f
Vanua Leva? z Tonga
Viti Levit
Suva
2
g ‘
8 4 _ | Niue
&
ry
New:
_ Caledonia *,Nuku‘aiofa Rarotonga .
New Caledonia “>.
{Fry
5 0 U TH
Tasmania
obart
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
'' Palmyra
WS.)
, ,
darvis
ws)
|fslandes
~ Administered ay New Zealand~»..
”
4
“Washington
"Fanning
Christmas
Pd
er
c
>
rs
o
(OK adsnin.,
U.S. claim}
iLES MARQUISES
7 ._Papeete
oes
Fy. Talli
%
&,
“%
_ hes Aty ; Mururoea *
iS. : 3
tah § TRage, F rence h Hes Gambier
ace ve
Polynesia
Pitéairn Island
UK)
Rapa:
Line of separation
{not a formal international
boundary or territorial limit)
500 1000 Nautical Miles
500 1000 Staiute Miles
RESENTATION 1S
LY AUTHORITATIVE','44af106901bb349dd22100e48226a75f614681316f6e3c63492bf76e665855d7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72a8a003f3c2fc41294cc921703c8047a982dc4b7980e736501df51c733f6429',1976,'CR','Costa Rica','communications',121,'. : “3
(See reference map iy
LAND
19,700 sq. mi.; 30% agricultural land (8%
cultivated, 22% meadows and pasture), 60% forested,
10% waste, urban, and other
Land boundaries: 415 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing 200 n, mi.; specialized competence over living
resources to 200 n. mi.)
Coastline: 800 mi.
Railroads: 407 mi.; 395 mi. 3''6" gage, 12 mi. 3''0”
vage, all single track, 72 mi. electrified
Highways: 14,300 mi.; 1,000 mi. paved, 4,100 mi.
otherwise improved, 9,200 mi. unimproved earth
Inland waterways: about 455 mi.
navigable
Pipelines: refined products, 80 mi.
Ports: 3 major (Limon, Golfito, Puntarenas), 4
minor
perennially
Civil air: 24 major transport aircraft
Airfields: 151 total, 149 usable; 19 with
permanent-surtace runways; 9 with runways 4,000-
7,999 ft.; 2 seaplane stations
Telecommunications: good domestic telephone
service; 99,100 telephones; connection into Central
American microwave net; 350,000 radio and 175,000
TY receivers; 45 AM, 10 FM, and LL TV stations
DEFENSE FORCES
Military manpower: males 15-49, 426,000: 280,000
fit for military service: average number reaching
military age (18) annually about 24,000
Supply: dependent on imports from U.S.
Military budget: for fiscal year ending 31
December 1973, $5.2 million for Ministry of Public
Security, including the Civil Guard; about 2.3% of
total central government budget
A6
Gulf . Atlantic
Ocean
4 ‘
Haven \\
S e se
CUBA... ©
of Mexico
(See reference map Il}
LAND
44,200 sq. mi.; 35% cultivated, 30% meadow and
pasture, 20% waste, urban, or other, 15% forested
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 2,320 mi.
Railroads: 9,150 mi. government owned; 3,150 mi.
common carrier lines (8 mi. double track and 95 mi.
electrified) and about 6,000 mi. plantation-
industrial lines; common carrier lines comprise 3,100
mi. 4''8''4" standard gage, and about 50 mi. 3’0” and
2''6" narrow gage; plantation-industrial lines comprise
about 4,000 mi. standard gage and 2,000 mi. narrow
gage
Highways: 12,800 mi.; 5,400 mi. paved, 7,400 mi.
gravel and earth surfaced
Inland waterways: 150 mi.
Pipelines: natural gas, 50 mi.
Ports: 8 major (including U.S. Naval Base at
Guantanamo), 44 minor; Guantanamo under U.S.
control
Civil air: 32 major transport aircraft
Airfields: 194 total, 182 usable; 44 with
permanent-surface runways; 1 with runway over
12,000 ft., 8 with runways 8,000-11,999 ft., 28 with
runways 4,000-7,999 ft.; 11 seaplane stations
Telecommunications: modern facilities adequately
serve military and most civil needs; excellent
international facilities, satellite ground station;
360,000 telephones; 2.0 million radio and 600,000 TV
receivers, 100 AM, 25 FM, and 16 TV stations; 6
submarine cables, including 1 coaxial
DEFENSE FORCES
Military budget: for fiscal year ending 31
December 1966 (last announced budget), $218
million; about 7.8% of total budget','fd615cc48d94e8c0e2f2f72ef52351b0b41005a2bb8f5958183207cfc92da93e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ea434175be9f448609a9764fed5cb064300e62d08308a8f892d915cd2883b71',1976,'CY','Cyprus','communications',125,'LAND
3,572 sq. mi; 47% arable and land under
permanent crops, 18% forested, 10% meadows and
pasture, 25% waste, urban areas, and other
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 400 mi. (approx. )
47
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Mediterranean
(See raference map V}
Railroads: none
Highways: 5,000 mi.; 2,100 mi. bituminous surface
treated; 2,900 mi. gravel, crushed stone, and earth
Ports: 3 major (Famagusta, Larnaca, Limassol), 6
minor
Civil air: 5 major transport aircraft
Airfields: 12 total, 10 usable; 8 with permanent-
surface runways; 2 with runways 8,000-11,999 ft.; 5
with runways 4,000-7,999 ft.
Telecommunications: moderately good telecom-
munication system; 63,000 telephones; 205,600 radio
receivers; 85,400 TV receivers; 12 AM, 5 FM, and 4
TV stations; tropospheric scatter circuits to Greece and
Turkey
DEFENSE FORCES
Military budget: for fiscal year ending 31
December 1974, $18.5 million about 13.1% of central
government budget
CZECHOSLOVAKIA
CZECHOSLOVAKIA ™
{See reference map /V)
LAND
49,400 sq. mi.; 42% arable, 14% other agricultural,
35% forested, 9% other
Land boundaries: 2,200 mi.
Railroads: 8,255 mi.; 8,075 mi. standard gage, 70
mi. broad gage, 110 mi. narrow gage; 1,741 mi.
double track; 1,742 mi. electrified; government
owned (1975)
Highways: 45,613 mi.; 863 mi. concrete; 34,500
imi. bituminous; 1,800 mi. cobblestone, brick sett,
stone block; 8,450 mi. crushed stone, gravel, improved
earth (1975)
Inland waterways: 517 mi. (1975)
Pipelines: crude oil, 900 mi.; refined products, 535
mi.; natural gas, 3,200 mi.
Freight carried: rail—294.3 million short tons, 44.5
billion short ton/mi. (1974); highway—1,050.5
million short tons, 9.3 billion short ton/mi. (1974);
waterway—5.4 million short tons, 1.9 billion short
ton/mi. (excl. int''l. transit traffic) (1974)
Ports: no maritime ports; outlets are Gdynia,
Gdansk, Szczecin in Poland; Rijeka, Yugoslavia;
Hamburg, West Germany; Rostock, East Germany;
principal river ports are Prague, Melnik, Usti nad
Labem, Decin, Komarno, Bratislava (1975)
Civil air: 58 major transport aircraft (1975)
DEFENSE FORCES
Military budget: (announced) for fiscal year
ending 31 December 1975, est. 19.3 billion crowns,
about 7% of total budget
DAHOMEY
= ENIN,
corte ss Be x =
Novo : ee oe
=
Atlantic Ocean . ap
ug
(See reference map VI)
On November 30, 1975, President Kerekou
announced that Dahomey would henceforth be
known as Benin. The long-form name of the State is
the Peoples Republic of Benin.
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
DAHOMEY
LAND
44,700 sq. mi.; southern third of country is most
fertile, arable land 80% (actually cultivated 11%),
forests and game preserves 19%, non-arable 1%
Land boundaries: 1,220 mi.
WATER
Limits of territorial waters (claimed); 12 n. mi.
(100 n. mi. mineral exploitation limit)
Coastline: 75 mi.
Railroads: 360 mi., all meter gage (3''3%4"’)
Highways: 4,300 mi.; 547 mi. paved, 2,665 mi.
gravel and/or improved earth, remainder unimproved
Inland waterways: 400 mi. navigable
Ports: 1 major (Cotonou), | minor
Civil air: no major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-
surface runway; 4 with runways 4,000-7,999 ft.
Telecommunications: system of open wire and
radio relay; 8,325 telephones; 54,000 radio receivers; 2
AM, no FM, and no TY stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 718,000; 359,000
fit for military service; about 30,000 males and 29,000
females reach military age (18) annually; both sexes
liable for military service ;
Supply: dependent on France and Guinea
Military budget: for fiscal year ending 31
December 1974, $6,664,300; about 11.4% of total
budget
51
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','130906f9ae9153797b129482375e78a2ae24f93ab01b38c62b6ecb326e0e1a5b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de482c93c8ae5a7c1b8316999b9d1ce79fb1a3bab31897fe2c25f4392ae845f7',1976,'DK','Denmark','communications',129,'{See referance map IV)
LAND
16,600 sq. mi. (exclusive of Greenland and Faeroe
Islands); 64% arable, 8% meadows and pastures, 11%
forested, 17% other
Land boundaries: 42 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing 12 n. mi.)
Coastline: 2,100 mi.
Railroads: 1,810 mi. Danish State Railways (DSB);
1,461 mi. standard gage (4’8 2"), 52 mi. electrified
and 453 mi. double tracked; remaining 349 mi. of
standard gage lines are privately owned and operated
Highways: 38,295 mi.; 31,196 mi. concrete,
bitumen, or stone block; 5,645 mi. gravel and crushed
stone; 1,454 mi. improved earth
Inland waterways: 259 mi.
Pipelines: refined products, 260 mi.
Ports: 16 major, 44 minor
Civil air: 84 major transport aircraft including 9
belonging to Greenland
Airfields: 142 total, 109 usable; 18 with
permanent-surface runways; 8 with runways 8,000-
11,999 ft., 7 with runways 4,000-7,999 ft.; 1 seaplane
station
Telecommunications: excellent telephone, tele-
graph, and broadcast services; 2,220,000 telephones;
1,710,000 radiobroadcast receivers; 1,690,000 TV
receivers; 4 AM, 18 FM, and 80 TV stations; 14
submarine coaxial cables
DEFENSE FORCES
Military manpower: males 15-49, 1,195,000;
1,050,000 fit for military service; 38,000 reach military
age (20) annually
Military budget: proposed for fiscal year ending 31
March 1976, $824 million; about 7% of central
government budget
Approved For Release 2005/04/22
FALKLAND ISLANDS (MALVINAS)!
Atlantic
Ocean
~~ FALKLAND
“222 ISLANDS
(See reference map It}
LAND
Colony — 4,700 sq. mi.; area consists of some 200
small islands, chief of which are East Falkland (2,580
sq. mi.) and West Falkland (2,038 sq. mi.);
dependencies — consists of the South Sandwich
Islands, South Georgia, and the Shag and Clerke
Rocks
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 800 mi.
Railroads: none
Highways: 22 mi.; 10 mi. paved, 12 mi. gravel, and
earth: no other made-up roads in the islands beyond
the immediate vicinity of Stanley
Ports: 1 major (Port Stanley), 4 minor
Civil air: no major transport aircraft
Airfields: 1 usable airfield, 1 seaplane station
63
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FALKLAND ISLANDS (MALVINAS)/FIJI
Telecommunications: government-operated open-
wire and radiotelephone networks providing effective
service to almost all points on both islands; approx-
imately 600 telephones; 1 AM station and 1,100 est.
radiobroadcast receivers','3120e62770a51e699faae5b1a245302e3d44a76bc6a7185eacfacaaae7777958','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bad7f5e4495d44e4d90bb1db0821ed23143184496634c068e5e3901b1e4ace62',1976,'DM','Dominica','communications',133,'~ Atlantic
REPUBLIC
ae punta’ ce Deen
: ep
c''s
ee
“DOMINICA?
DOMINICAN
Caribbean Sea oan
{Ses reference map tl}
LAND
305 sq. mi.; 24% arable, 2% pasture, 67% forests,
7% other
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 92 mi.
Railroads: none
Highways: 460 mi.; 230 mi. paved, 160 mi. gravel,
crushed stone, or stabilized earth surface, 70 mi.
unimproved
Ports: 2 minor (Roseau, Portsmouth)
Civil air: no major transport aircraft
Airfields: 1 with asphalt runway 4,830 ft.
Telecommunications: 2,900 telephones in fully
automatic network; VHF link to St. Lucia; 15,000
radio receivers; 150 TV receivers; | AM station','1896ceeb7fd81b2eeceb50f2bb2db16ee535bca28ae2f9670a2bed778fa293fc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6471741db86629ded7b430272dba7eff5afc6d5516a64e3b0cccfc7218e1f131',1976,'DO','Dominican Republic','communications',137,'LAND
18,800 sq. mi.; 14% cultivated, 4% fallow, 17%
meadows and pastures, 45% forested, 20% built-on or
waste
Land boundaries: 224 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 800 mi.
Railroads: 1,000 route mi. of which 65 mi.
government-owned common carrier (3''6” gage) and
985 mi. privately owned plantation network (approxi-
mately 4 different gages ranging from 1/10%"'' to
4''8%", with 2''6" predominating)
Highways: 7,000 mi.; 3,500 mi, paved, 3,500 mi.
gravel and improved earth
Approved For Release 2005/04/22
Pipelines: product lines (1.5 mi. and 43 mi.) under
construction
Ports: 5 major (Santo Domingo, Barahona, Haina,
Las Calderas, San Pedro de Macoris), 17 minor
Civil air: 23 major transport aircraft
Airfields: 50 total, 43 usable; 9 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 9
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: relatively efficient domestic
system based on islandwide radio relay network;
96,500 telephones; 600,000 radio and 190,000 TV
receivers, 110 AM, 31 FM, and 11 TV stations; 3
submarine cables, including 1 coaxial; planned
COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 1,067,000;
676,000 fit for military service; 52,000 reach military
age (18) annually','370aa4fbf12dd2e35d31c65dd81f54d0c087c8c8cc124fb2a17e327f23f785e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6b2f5369f76c2bd69e9d8e1222d981451fafdef6b8da5da3e5720b33dbece1c',1976,'EC','Ecuador','communications',141,'Galapagos
Islands
Pacific Ocean
(See reference map fil)
LAND
106,000 sq. mi. (including Galapagos Islands); 11%
cultivated, 8% meadows and pastures, 55% forested,
26% waste, urban, or other (excludes the Oriente and
the Galapagos Islands, for which information is not
available}
Land boundaries: 1,200 mi.
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,390 mi. (includes Galapagos Is.)
Railroads: 660 mi.; 615 mi. 3''6” gage, 45 mi.
2''5%"" gage; all single track
Highways: 12,700 mi.-: 2,100 mi. paved, 10,600 mi.
otherwise improved
Inland waterways: 960 mi.
Pipelines: crude oil, 390 mi.; refined products, 320
mi.
Ports: 3 major (Guayaquil, Manta, Puerto Bolivar),
11 minor
Civil air: 29 major transport aircraft
Airfields: 175 total, 175 usable: 17 with
permanent-surface runways; 6 with runways 8,000-
11,999 ft., 21 with runways 4,000-7,999 ft.; 3 seaplane
stations
Telecommunications: facilities adequate only in
largest cities; satellite ground station; 135,000
telephones; 1.7 million radio and 250,000 TV
receivers; 240 AM, 38 FM, and 12 TV stations
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ECUADOR/EGYPT
DEFENSE FORCES
Military manpower: males 15-49, 1,667,000;
1,088,000 fit for military service; average number
reaching military age (20) annually 71,000
(See reference map V}
LAND
386,200 sq. mi. (including 22,200 sq. mi. occupied
by Israel); 2.8% cultivated (of which about 70%
multiple cropped); 96.5% desert, waste, or urban;
0.7% inland water
Land boundaries: 1,570 mi. (1967), excludes
occupied area 1,534 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(plus 6 n. mi. “necessary supervision zone’)
Coastline: 2,140 mi. (1967), excludes occupied area
1,340 mi.
Railroads: 3,358 mi.; 570 mi. double track; 15 mi.
electrified; 2,976 mi. 4’8%" gage, 156 mi. 3''3%”’
gage, 226 mi. 2’5%4"'' gage
Highways: 29,358 mi.; 5,914 mi. paved, 279 mi.
gravel and crushed stone, 6,398 mi. improved carth,
16,767 mi. unimproved earth
57
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
EGYPT/EL SALVADOR
Inland waterways: 2,100 mi.; Suez Canal, 100 mi.
long, temporarily closed to navigation because of
sunken vessels; normally used by ocean-going vessels
drawing up to 38 ft. of water; Alexandria-Cairo
waterway navigable by barges of 500-ton capacity;
Nile and large canals by barges of 420-ton capacity;
Ismailia Canal by barges of 200- to 300-ton capacity;
secondary canals by sailing craft of 10- to 70-ton
capacity
Freight carried: Suez Canal (1966) — 242 million
tons of which 175.6 million tons were POL
Pipelines: crude oil, 185 mi.; refined products, 390
mi.; natural gas, 30 mi.
Ports: 3 major (Alexandria, Port Said, Suez), 8
minor
Civil air: 15 major transport aircraft
Airfields: 98 total, 84 usable; 69 with permanent-
surface runways; 41 with runways 8,000-11,999 ft., 2
with runways over 12,000 feet, 19 with runways 4,000-
7,999 ft.; 2 seaplane stations
Telecommunications: second best system of
coaxial and multiconductor cables, open-wire lines,
and radiocommunication stations in Africa; principal
centers Alexandria and Cairo, secondary centers Al
Mansurah, Ismailia, and Tanta: 471,800 telephones;
5.1 million radio and 610,000 TV receivers; 12 AM, 1
FM, and 22 TV stutions
DEFENSE FORCES
Military manpower: males 15-49, 8,545,000:
5,409,000 fit for military service; about 390,000 reach
military age (20) annually','ed377757b48fe7965aae0effba8f26e9275cecf4298cdd0db782b6c1ed738d68','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a602ac752130f857a7ab2302411ae901c94ca58d3a0e3e219a5b33aac3910206',1976,'SV','El Salvador','communications',145,'Caribbean
Sea
San Salvador™
EL SALVADOR S 3
Pacific Ocean
{See reference map tH)
LAND
8,260 sq. mi.; 82% cropland (9% corn, 5% cotton,
7% coffee, 11% other), 26% meadows and pastures,
31% nonagricultural, 11% forested
Land boundaries: 320 mi.
Approved For Release 2005/04/22
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 190 mi.
Railroads: 375 mi., 30” gage; single-tracked; 285
mi. privately owned, 90 mi. government owned
Highways: 6,700 mi.; 800 mi. bituminous, 1,200
mi. gravel or crushed stone, 4,700 mi. earth
Inland waterways: Lempa_ River partially
navigable
Ports: 3 major (Acajutla, La Union, La Libertad), 1
minor
Civil air: 8 major transport aircraft
Airfields: 146 total, 145 usable; 9 with runways
4,000-7,999 ft.; 1 seaplane station
Telecommunications: nationwide trunk radio relay
system; connection into Central American microwave
net; 48,500 telephones; 600,000 radio and 115,000 TV
receivers; 53 AM, 6 FM, and 5 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 927,000; 569,000
fit for military service; 44,000 reach military age (18)
annually
Military budget: for fiscal year ending 31
December 1975, $17.7 million; 6.5% of central
government budget','d452296116e8bd38239382f191fcf128be2a390a66188adedec9abf1cc232898','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55f7a3bf5cd7269e491d873af20020311fd30f59edfedd626f05afb7e3bbcb27',1976,'ET','Ethiopia','communications',149,'LAND
455,000 sq. mi.; 10% cropland and orchards, 55%
meadows and natural pastures, 6% forests and
woodlands, 29% wasteland, built-on areas, and other
Land boundaries: 3,230 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.:
sedentary fisheries extends to limit of fisheries
Coastline: 680 mi. (includes offshore islands)
°° Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
i
January 1976
Approved
p For Release 2005/04/22 : CIA-RDP79-01051A00080001
0001-8
Indian
Ocean
(See reference Map vi}
Railroads: 630 mi.; 420 mi. 3/334" gage, 20 mi. 3''6"
gage, 190 mi. 3''134"" gage; all single track
Highways: 14,500 mi.; 1,675 mi. bituminous, 3,100
mi. crushed stone, gravel, oF stabilized earth,
remainder earth
Inland waterways: navigation possible on Lake
Tana and on approx. 140 mi. of unconnected and
basically unimproved waterways, of which only 71
mi. are navigable year round
61
0800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00
January 1976
ETHIOPIA/FAEROE ISLANDS
Ports: 2 major (Assab, Mussawa), | minor
Civil air: 17 Major transport aircraft
Airfields: 162 total, 150 usable; 7 with permanent-
surface runways; | with runway over 12,000 ft,, 6 with
runways 8,000-11,999 ft., 46 with runways 4,000-
7,999 ft.
center Addis Ababa, secondary center Asmara; 60,800
telephones; 500,000 radio receivers; 20,000 Ty
receivers; 4 AM, no FM, and 1 Ty Stations
DEFENSE FORCES
Military manpower: males 15-49, 7,028,000;
3,745,000 fit for military service; average number
reaching military age (18) annually 278 000
Military budget: for fiscal year ending 7 August
1976, $83,653,846, 13.1% of total budget
FAEROE ISLANDS
Norwegian
Sea
FAEROE *
ISLANDS
. Atlantic
Ocean
{See reference map lV)
LAND
540 sq. mi.: less than 5% arable, of which only a
fraction cultivated: archipelago consisting of 18
inhabited islands and a few uninhabited islets
WATER
Limits of territorial waters (claimed): 3 n. mi.;
fishing, 12 n. mi. (from extended base lines}
Coastline: 475 mi.
Railroads: none
Highways: none
Ports: | minor
Airfields: 1 with permanent-surface runway, less
than 4,000 ft.
Civil air: no major transport aircraft
Telecommunications: good international com-
munications; fair domestic facilities; 13,010 tele-
phones, 12,000 radio receivers; 1 AM, and 8 FM
stations 3 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49 included with','2bdc5a7996e59ada036eeb5f21282b1a9359478262fc03d399e8fb717a333b0c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46c738bafbd921157e677e69039a84dfcd02d627863987308a66fdc9e2f393b1',1976,'FJ','Fiji','communications',153,'Qa
FE”:
ISLANDS :
Coral Sea A i.
(See reference map Vill}
LAND
7,055 sq. mi.; landownership — 83.6% Fijians,
1.7% Indians, 6.4% government, 7.2% European,
1.1% other; about 30% of land area is suitable for
farming
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 700 mi. (est.)
Railroads: none
Highways: 1,757 mi. (1974); 173 mi. paved, 1,584
mi. gravel or crushed stone
Inland waterways: 126 mi.; 76 mi. navigable by
motorized craft and 200-ton barges
Ports: 1 major, 6 minor
Civil air: 5 major transport aircraft
Airfields: 15 total, 15 usable; 2 with permanent
surface runways, 1 with runway 8,000-11,999 ft.,
| with runway 4,000-7,999 ft., 2 seaplane stations
Telecommunications: modern local, interisland,
and international (wire/radio integrated) public and
1 Fijian dol-
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
FIJ1/FINLAND
special-purpose telephone, telegraph, and teleprinter
facilities; regional radio center; important COMPAC
cable link between U.S./Canada and New Zealand/
Australia, et al; 22,523 telephones; 251,000 radio
receivers; 6 AM, 2 FM, and no TV stations; 1 ground
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 146,000; 81,000
fit for military service; 6,000 reach military age (18)
annually
Military budget: the defense of the Fiji Islands was
the responsibility of the U.K. until 10 October 1970;
military budget for 1971, $314,000','68bfd2306b028acddf37792eb1f00b0b61fef9f10a9ddab8fcf707c44c79c9d1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4b2a7bb5b2aedcc76068c7d8720706fc5391c47951a37b167d67605048be617',1976,'FI','Finland','communications',157,'‘Norwegian
2 Sea
(See reference map {¥)
LAND
130,000 sq. mi.; 8% arable, 58% forested, 34% other
Land boundaries: 1,575 mi.
WATER
Limits of territorial waters (claimed): 4 n. mi.;
Aland Islands, 3 n. mi.
Coastline: 700 mi. (approx.) excludes islands and
coastal indentations
Railroads: 3,695 mi.; Finnish State Railways (VR)
operate a total 3,677 mi. broad gage (5''0"’), 296 mi.
multiple track, and 245 mi. electrified; 14 mi. narrow
gage (2’542"") and 4 mi. broad gage are privately
owned
Highways: about 45,000 mi. in national classified
network, including 18,000 mi. paved (bituminous,
concrete, bituminous surface treated) and 27,000 mi.
unpaved (stabilized gravel, gravel, earth); additional
17,700 mi. of private (state subsidized) roads
Inland waterways: 4,100 mi. total (including
Saimaa Canal); 2,300 mi. suitable for steamers;
Saimaa Canal locks (278 ft. by 43.3 ft. with a 17.0 ft.
depth over sill) can accommodate vessels of up to 269
ft. in length, 38.6 ft. beam, 14.3 ft. draft, and 80.4 ft.
mast height
Pipelines: natural gas, 100 mi.
66
Ports: 11 major, 14 minor
Civil air: 34 major transport aircraft
Airfields: 106 total, 104 usable; 36 with
permanent-surface runways; 17 with runways 8,000-
11,999 ft., 24 with runways 4,000-7,999 ft.
Telecommunications: facilities provide essential
services for government, public, and industry;
1,720,000 telephones; 2,100,000 radiobroadcast
receivers; 1,440,000 TV receivers; 13 AM, 40 FM, and
65 TV stations; 4 submarine cables, including 1
coaxial
DEFENSE FORCES
Military manpower: males 15-49, 1,205,000;
975,000 fit for military service; 39,000 reach military
age (17) annually','ed8d3ad10b2d6913a7a07bfeb3071bf6c5a92a6b505a2c3046e887780ec7ed04','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1414e3f4b9b480e457b36ceb7f332eccdb7f017a3136343c61d5ef0d7d66ba65',1976,'FR','France','communications',161,'¢
Atlantic Pan
x ars
~ Ocean =~ oe
f 3 d effec
«= ¥
Mediterransan Seq SE
(See reference map IV}
LAND
213,000 sq. mi.; 35% cultivated, 26% meadows and
pastures, 14% waste, urban, or other, 25% forested
Land boundaries: 1,795 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,130 mi. (includes Corsica, 400 mi.)
Railroads: 22,930 mi.. 22,200 mi. standard gage,
730 mi. other gages (3''3%"'' to 4''9"); 5.810 mi.
electrified, 9,770 mi. double or multiple track
Highways: National, Departmental, and Commu-
nal roads total 497,200 mi. comprising 292,600 mi.
paved, 190,000 mi. crushed stone and gravel, and
14,600 mi. improved earth; in addition, there are
approximately 434,000 mi. of local farm and forest
roads
Inland waterways: 9,320 mi.; 4,670 mi. heavily
traveled
Pipelines: crude oil, 1,400 mi.; refined products,
2,700 mi.; natural gas, 9,300 mi.
Ports: 23 major, 165 minor
Civil air: 306 major transport aircraft (including 13
foreign based but French registered)
Airfields: 464 total, 432 usable; 203 with
permanent-surface runways; 2 with runways over
12,000 ft., 25 with runways 8,000-11,999 ft., 119 with
tunways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: highly developed system
Provides satisfactory telephone, telegraph, and radio
and TV broadcast services; 12.7 million telephones,
18.3 million radiobroadcast receivers; 14.3 million TV
receivers; 40 AM, 84 FM, and 1,400 TV stations; 19
submarine cables (18 coaxial); 4 communication
satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 12,843,000; fit
for military service 10,340,000; 424,000 reach military
age (18) annually
Military budget: for fiscal year ending 31
December 1975, $9.7 billion; about 17% of central
government budget
Military budget: for fiscal year ending 3]
December 1975, $9,693,453; 6.4% of total budget','1b30119b9b113c931e30bdbcc9ed6b83e9389ceefbb51dade7045001988ac115','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6047398f42dbd6d84ea7c7b1c29a2d914ff3f9e97273484b62ded6c855f3f254',1976,'GF','French Guiana','communications',165,'LAND
35,100 sq. mi.; 90% forested, 10% wasteland, built-
on, inland water and other, of which .05% is
cultivated and pasture
Land boundaries: 735 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 235 mi.
Railroads: 20 mi. private plantation line, 1’11%"
gage; 8 mi. abandoned narrow-gage line
Highways: 300 mi.; 250 mi. paved, 50 mi.
improved and unimproved earth
Inland waterways: 290 mi., navigable by small
oceangoing vessels and river and coastal steamers;
2,110 mi. possibly navigable by native craft
Ports: 1 major (Cayenne), 7 minor
Civil air: no major transport aircraft
Airfields: 13 total, 10 usable; 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft.
Telecommunications: limited open-wire telecom
system with about 6,950 telephones; 7,100 radio
receivers and 3,100 TV receivers, 2 AM, 2 FM and 2
TV stations; satellite communications station
DEFENSE FORCES
Military manpower: males 15-49, 13,000; 9,000 fit
for military service','c21f75d2b8615fe200db0b3ff35bee871391167e1d151be09083b91ea3b86ce0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39b0661dd9c661954e604d8788c401f0f13ca37bf9dc94c464d6ed5c35b73606',1976,'PF','French Polynesia','communications',169,'LAND
About 1,544 sq. mi.
WATER
Limits of territorial waters: 12 n. mi.
Approved For Release 2005/04/22
(See reference map Vill)
Coastline: about 975 mi.
Highways: 2,300 mi., all types
Ports: 1 major (Papeete), 6 minor
Airfields: 19 total, 19 usable; 10 with permanent
surface runways, 2 with runways 8,000-11,999 ft., 9
with runways 4,000-7,999 ft.; 2 seaplane stations
Civil air: no major transport
Telecommunications: 10,856 telephones; 70,000
radio and 13,000 TV sets; 1 AM, no FM, and 4 TV
stations
FRENCH TERRITORY OF THE
AFARS AND ISSAS
Red Sea *
TRENCH TERRITORY OF THE
FARS AND ISSA
oti
{Sae reference map Vi)
LAND
9,000 sq. mi.; 89% desert wasteland, 10%
permanent pasture, and less than 1% cultivated
Land boundaries: 321 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 195 mi. (includes offshore islands)
Railroads; 60 mi. meter gage
Highways: 1,180 mi.; 62 mi. paved, 1,118 mi.
improved earth
Ports: 1 major (Djibouti)
Airfields: 7 total, 7 usable; 1 with permanent-
surface runway; 1 with runway 8,000-11,999 ft., 4
with runways 4,000-7,999 ft.
Civil air: 6 major transport aircraft (registered in
France)
Telecommunications: fair system of urban
facilities in Djibouti and radiocommunication stations
at outlying places; 2,900 telephones; 12,000 radio
receivers; 3,000 TV receivers; 1 AM, no FM, and 1 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, about 30,000;
about 17,000 fit for military service
Defense is responsibility of France
Railroads: none
Highways: 3,206 mi.; 228 mi. paved; 808 mi.
gravel, crushed stone, or stabilized surface; 495 mi.
improved earth; 1,675 mi. earth
Inland waterways: none
Ports: 1 major (Noumea), 21 minor
Civil air: no major transport aircraft
Airfields: 31 total, 31 usable; 2 with permanent-
surface runways; 2 with runways 4,000-7,999 ft.; 1
airfield over 8,000 ft.; 1 seaplane station
Telecommunications: 14,364 telephones; 30,500
radio and 13,000 TV sets; 1 AM, no FM, and 3 TV
stations; 1 earth satellite station
NEW HEBRIDES
Pacific
a Ree Ocean
ve BRITISH
“bw soLomons
See
seh
se
. wi
HEBRIDES’.
.Y
.
news
CALEDONIA
(See reference map Vill)
LAND
About 5,700 sq. mi.
WATER
Limits of territorial waters: 3 n. mi.
Coastline: about 1,570 mi.
Railroads: none
Highways: at least 150 mi. sealed or all-weather
roads
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Telecommunications: 1 AM _ broadcast station,
10,000 radio receivers, and 800 telephones
DEFENSE FORCES
Personnel: no military forces maintained, however,
the French and British maintain constabularies of
about 70 men each','ae00b6b20d5c5c9fcc6b4c55e35e1420a3768efcdb447222acdbfd51e6af5faf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1717161d5569d3e4f8bc8414a6fe6c1c15c8321a24c0fe22989fc5294b1300a',1976,'GA','Gabon','communications',173,'Atlantic
Oeean
(See reference map Vij
LAND
102,000 sq. mi.; 75% forested, 15% savanna, 9%
urban and wasteland, less than 1% cultivated
Land boundaries: 1,505 mi.
WATER
Limits of territorial waters (claimed): 100 n. mi.
Coastline: 550 mi.
Railroads: none
Highways: 4,000 mi.; 140 mi. paved, 3,268 mi.
gravel and/or improved earth, remainder unimproved
earth
Inland waterways: approximately 1,000 mi.
perennially navigable
Pipelines: crude oil, 40 mi.
Ports: 3 major (Libreville, Port-Gentil, Owendo), 2
minor
Civil air: 24 major transport aircraft
Airfields: 166 total, 103 usable; 5 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 20
with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: system of open-wire, radio-
relay, tropospheric scatter links and radiocommunica-
tion stations; satellite ground station; 4 AM and 2 TV
stations; 7,000 telephones; 90,000 radio receivers;
5,200 TV receivers
DEFENSE FORCES
Military manpower: males 15-49, 126,000; 65,000
fit for military service; 5,000 reach military age (20)
annually
Military budget: for fiscal year ending 31
December 1975, $17,850,079; 2.4% of total budget','a0f3e961976bd0ee2e13fa66877c4d49b21b8d2e2d3e6a75ba72948499737e2a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a334e78758058e814be721c1e03bf86536e39c3c46c31ef3c7fda55f66c1d789',1976,'GM','Gambia','communications',177,'LAND
4,000 sq. mi; 25% uncultivated savanna, 16%
swamps, 4% forest parks, 55% upland cultivable
areas, built-up areas, etc.
Land boundaries: 460 mi.
72
Approved For Release 2005/04/22
(See reference map VI)
WATER
Limits of territorial waters (claimed): 50 n. mi.
Coastline: 50 mi.
Railroads: none
Highways: 775 mi.; 185 mi. bituminous surface
treated, 320 mi. gravel/laterite, 270 mi. unimproved
earth
Inland waterways: 377 mi.
Ports: I major (Banjul)
Civi] air: no major transport aircraft
Airfields: 1 usable with permanent-surface runway
4,000-7,999 ft.; 1 seaplane station (non-operational)
Telecommunications: adequate network of radio-
relay; 1,900 telephones; 60,000 radio receivers; 1 AM,
1 FM and no TV stations; 1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 120,000; 61,000
fit for military service
GERMANY, EAST
LAND
41,800 sq. mi.; 43% arable, 15% meadows and
pasture, 27% forested, 15% other
Approved For Release 2005/04/22
North Sea
(See reference map 1V)
Land boundaries: 1,435 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 560 mi. (including islands)
Railroads: 8,895 route mi.; 8,673 mi. standard
gage, 222 mi. meter or other narrow gage, 1,400 mi.
double track standard gage; 860 mi. overhead
electrified (1973)
Highways: about 28,359 mi. classified highways;
7,696 mi. state highways including 928 mi. autobahn;
20,663 mi. district roads; additionally about 34,465
mi. unclassified minor unpaved roads (1973)
Inland waterways: 1,562 mi. (1975)
Freight carried: rail — 325.6 million short tons,
32.2 billion short ton/mi. (1973); highway — 600.6
million short tons, 10.3 billion short ton/mi. (1973);
waterway—13.4 million short tons, 1.3 billion short
ton/mi. (excl. int’l. transit traffic) (1974)
Pipelines: crude oil, 500 mi; refined products, 150
mi.; natural gas 300 mi.
Ports: 4 major (Rostock, Wismar, Stralsund,
Sassnitz), 13 minor (1975)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 31 December 1975, 9.6 billion DME; about
9% of total budget
GERMANY, WEST
LAND
96,000 sq. mi. (including West Berlin); 33%
cultivated, 23% meadows and pastures, 13% waste or
urban, 29% forested, 2% inland water
Land boundaries: 2,630 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 925 mi. (approx.)
Railroads: 21,360 mi.; 18,597 mi. government
owned, standard gage (4''8%"''), 7,807 mi. double
track; 6,100 mi. electrified; 2,763 mi. non-government
owned; 2,498 mi. standard gage; 134 mi. electrified:
265 mi. narrow gage (3''3%’’); 116 mi. electrified
Highways: 249,200 mi.; 100,875 mi. classified,
includes 95,725 mi. cement-concrete, bituminous, or
stone block (includes 3,295 mi. of autobahnen); 5,150
mi. gravel, crushed stone, improved earth; in
addition, 148,325 mi. of unclassified roads of various
surface types
Inland waterways: 3,100 mi. of which almost 70%
usable by craft of 1,100-short-ton capacity or larger
Pipelines: crude oil, 1,200 mi.; refined products,
1,000 mi.; natural gas, 59,300 mi.
Ports: 10 major, 11 minor
Civil air: 167 major transport aircraft
Airfields: 488 total, 378 usable: 194 with
permanent-surface runways: 3 with runways over
12,000 ft., 35 with runways 8,000-11,999 ft., 36 with
runways 4,000-7,999 ft.
Telecommunications: highly developed, modern
telecommunication service to all parts of the country;
fully adequate in all respects; 19.3 million telephones;
21.3 million radio and 19.3 million TV receivers: 92
AM, 127 FM, and 1,960 TV stations; 5 submarine
cables; 4 communication satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 14,749,000;
12,357,000 fit for military service; 450,000 reach
military age (18) annually','fe3a45771c499b2c2768d30f63aac853cb1a73bf41f2050fa9c798a17ddb055d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33f16dc83cab820ed51b5c89a2a230dbbb5068a8fcfc44eecf89955d58f50407',1976,'GH','Ghana','communications',181,'LAND
92,000 sq. mi.; 19% agricultural, 60% forest and
brush, 21% other
Land boundaries: 1,420 mi.
WATER
Limits of territorial waters (claimed): 30 n. mi.
(undefined protective areas may be proclaimed
76
(See reference map Vi}
seaward of territorial sea, and up to 100 n. mi.
seaward may be proclaimed fishing conservation
zone)
Coastline: 335 mi.
Railroads: 592 mi. — all 3''6" gage; 20 mi. double
track; diesel locomotives gradually replacing steam
engines
Highways: 21,450 mi., 3,000 mi. concrete or
bituminous surface, 5,250 mi. gravel or laterite, 3,600
mi. improved earth, 9,300 mi. unimproved earth
Inland waterways: Volta, Ankobra, and Tano
rivers provide 145 mi. of perennial navigation for
launches and lighters; additional routes navigable
seasonally by small craft; Lake Volta reservoir
provides 700 mi. of arterial and feeder waterways
Pipelines: refined products, 2 mi.
Ports: 2 major (Tema, Takoradi), 1 naval base
(Sekondi), 4 minor
Civil air: 8 major transport aircraft
Airfields: 19 total, 18 usable; 4 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 9
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: good system of open-wire
and cable, radio-relay links and radiocommunication
stations; 52,000 telephones; 1,058,000 radio and
25,500 TV receivers; 3 AM, no FM, and 5 TV stations;
2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 2,248,000;
1,247,000 fit for military service; 114,000 reach
military age (18) annually
Military budget: for fiscal year ending 30 June
1975, $83,336,500; 9.4% of total budget','6a31d612d9478fbe92fb81fbacfaa1270c1ce3c62ac16a8f8dabfced465e88dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b0f0874f023e2f0bcb950e8dc488f5d52658a55c72f9b51a92766611d866bd3',1976,'GI','Gibraltar','communications',185,'Es
Atlantic Ocean
(See reference map WV)
LAND
2.5 sq. mi.
Land boundaries: | mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 7.5 mi.','9deeca7281847c0ecefe8ac58de2dd1ffd467c043cf44a366e8ac75751d46a09','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ef23e113f4a2fd2982679572a08261a8c68c2d38fac2a7672008a68575da6b5',1976,'NL','Netherlands','communications',190,'Railroads: none
Highways: 35 miles, mostly paved
Ports: | major (Gibraltar)
Civil air: 1 major transport aircraft
Airfields: 1 permanent-surface runway, 4,000-
7,999 ft.; 1 seaplane station
Telecommunications: international radiocom-
munication facilities; automatic telephone system
serving 7,000 telephones; 7,200 radio- receivers; 6,950
TV receivers, ] AM, 1 FM, and 2 TV stations: 13
submarine telegraph cables
DEFENSE FORCES
Military manpower: males 15-49, about 6,000:
about 3,000 fit for military service
Defense is responsibility of United Kingdom
GILBERT AND ELLICE ISLANDS
> GNITED”S
states..©
Pacific Ocean
“GILBERT vg
_ -ELLICE ISLANDS
ae 3
(See reference map Vill}
NOTE: The Ellice Islands were separated from the
Gilbert and Ellice Islands Colony (GEIC) on 1
October 1975 to form a new colony, Tuvalu, with its
capital at Funafuti. The new colony has an 8-member
House of Assembly. The Chief Minister is Toalipi
Lauti.
The remainder of the GEIC has been renamed the
Gilbert Islands,
LAND
About 376 sq. mi.
10001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008000
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GILBERT AND ELLICE ISLANDS/GREECE
WATER
Limits of territorial waters: 3 n. mi.
Coastline: about 725 mi.
Railroads: none
Highways: 300 mi. of motorable roads
Inland waterways: small network of canals,
totaling 3 miles, in Northern Line Islands
Ports: 1 minor
Civil air: no major transport aircraft
Telecommunications: 1 AM broadcast station;
8,100 radio receivers, no TV sets, and 435 telephones;
connected with Lisbon, Portugal, via cable broadcasts
Approved For Release 2005/04/22
TF
ton
: Ww :
«GERMANY.
(See reference map IV}
LAND
18,100 sq. mi.; 70% cultivated, 5% waste, 8%
forested, 8% inland water, 9% other
Land boundaries: 635 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 280 mi.
Railroads: 1,862 mi., standard gage; 1,758
government-owned (NS), 1,023 mi. electrified, 970
mi. double track; 104 mi. privately-owned
Highways: approximately 63,100 mi. including 900
mi. of limited access, divided “Motorways”; about
51,400 mi. paved (bituminous, concrete, stone block)
and 1,700 mi. unpaved (gravel, crushed stone,
stabilized earth)
Inland waterways: 3,940 mi., of which 35% is
usable by craft of 1,000 short-ton capacity or larger
Pipelines: crude oil, 260 mi.; refined products, 600
mi.; natural gas, 2,790 mi.
Ports: 8 major, 5 minor
Civil air: 110 major transport aircraft (including 8
aircraft registered in the Netherlands but leased from
a foreign country)
Airfields: 28 total, 27 usable; 16 with permanent-
surface runways; 13 with runways 8,000-11,999 ft., 3
with runways 4,000-7,999 ft.
Telecommunications: highly developed, ex-
cellently maintained, and well integrated; extensive
system of multiconductor cables, supplemented by
radio-relay links; 4.86 million telephones; 9 million
radiobroadcast and 3.65 million TV receivers; 5 AM,
12 FM, and 11 TV stations; 12 coaxial submarine
cables; communications satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 3,393,000:
3,046,000 fit for military service; average number
reaching military age (20) annually 117,000
Military budget: proposed for fiscal year ending 31
December 1975, $2,735 million; about 12% of central
government budget
NETHERLANDS ANTILLES
LAND
394 sq. mi.; 5% arable, 95% waste, urban, or other
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 226 mi.
Railroads: none
Highways: 700 mi.; 350 mi. paved, 220 mi.
otherwise improved, 130 mi. unimproved
Ports: 3 major (Willemstad, Oranjestad, Caracor
Baai), 6 minor
Civil air: 6 major transport aircraft
Airfields: 7 total, all usable; 7 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 2
with runways 4,000-7,999 ft.; 1 seaplane station
147
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NETHERLANDS ANTILLES/NEW CALEDONIA
Telecommunications: generally adequate telecom
facilities; extensive interisland VHF links; 40,000
telephones, 132,000 radio and 35,000 TV receivers, 11
AM and 8 TV stations, 5 submarine cables, including
L coaxial
DEFENSE FORCES
Military manpower: males 15-49, 60,000; 34,000
fit for military service; about 2,000 reach military age
(20) annually
Defense is responsibility of the Netherlands','7b1aeb85b1083220b2629ebd0e7b6104c3825b2cb334eea5e97342cce1982ab0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1711357e15291d1c1354d43a21c50a12e8eb28727df9fdf6ce9ed80151a3a54',1976,'GR','Greece','communications',193,'once wap iV)
LAND
51,200 sq. mi.; 29% arable and land under
permanent crops, 40% meadows and pastures, 20%
forested, 11% wasteland, urban, other
Land boundaries: 740 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
Coastline: 8,500 mi.
Railroads: 1,598 mi; 969 mi. standard gage
(4''8 2"), 597 mi. meter gage (3''3%"’), 20 mi. 1/1154”
narrow gage, 10 mi. 2''5%" narrow gage; all
government owned
Highways: 24,200 mi.; 10,000 mi. paved, 8,500 mi.
crushed stone and gravel 3,500 mi. improved earth,
2,200 mi. unimproved earth
Inland waterways: system consists of 3 coastal
canals and 3 unconnected rivers which provide
navigable length of just less than 50 mi.
Pipelines: crude oil, 16 mi., refined products, 340
mi.
Ports: 17 major, 37 minor
Airfields; 68 total, 61 usable; 40 with permanent-
surface runways; 17 with runways 8,000-11,999 ft., 21
with runways 4,000-7,999 ft.
Civil air: 35 major transport aircraft (including 3
withdrawn from service)
Telecommunications: adequate modern networks
reach all areas on mainland and islands; 1.95 million
telephones; 3.0 million radio receivers; 1.1 million TV
receivers; 832 AM, 18 FM and 37 TV stations; 3 coaxial
submarine cables; 2 communications satellite ground
stations
DEFENSE FORCES
Military manpower: males 15-49, 2,256,000;
1,728,000 fit for military service; about 75,000 reach
military age (21) annually
Military budget: est. for fiscal year ending 31
December 1974, $691 million; about 24% of central
government budget
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GREENLAND/GRENADA','09f5df6082bda5eb2bcdd4deb16d9d1c1f861f25513f70d263e4e2de431a5997','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('844ca63075cd377234d4197cf72e5463d8685c82f87565ca6b6900ab043193a8',1976,'GL','Greenland','communications',197,'(Ses reference mag t}
LAND
$40,000 sq. mi.; less than 1% arable (of which only
a fraction cultivated), 84% permanent ice and snow,
15% other
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 27,400 mi. (approx., includes minor
islands)
Railroads: none
Highways: none
Ports: 9 major, 23 minor
Civil air: 9 major transport aircraft (registered in
Denmark)
Airfields: 11 total, 7 usable; 3 with permanent-
surface runways; 3 with runways 8,000-11,999 ft., 3
with runways 4,000-7,999 ft.; 7 seaplane stations
Telecommunications: adequate domestic and
international service provided by cables and radio;
7,660 telephones; 7,800 radiobroadcast receivers; 5
AM, 2 FM, and 2 TV stations; 2 coaxial submarine
cables
DEFENSE FORCES
Military manpower: males 15-49, included with','8ef038500645b0dae2319c1f47f56530692934cf863c3f1c9599703299030796','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('221c7f10bf5b41a0e0ad69881220b15b626a5419ee8a3de1774c243a4e299968',1976,'GD','Grenada','communications',201,'LAND
133 sq. mi. (Grenada and southern Grenadines);
44% cultivated, 4% pastures, 12% forests, 17% unused
but potentially productive, 23% built on, wasteland,
other
81
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GRENADA/GUADELOUPE
Atlantic¢
Ocean
Caribbean
6a
5
{See reference map il}
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 75 mi.
Railroads: none
Highways: 600 mi.; 380 mi. paved, 100 mi.
otherwise improved; 120 mi. unimproved
1974): food,
Ports: | major (St. Georges), 1 minor
Civil air: no major transport aircraft
Airfields: 4 total, 3 usable; 1 with asphalt runway
5,000 ft.
Telecommunications: automatic, islandwide
telephone system with 4,950 telephones; VHF links to
Trinidad and Carriacou; 21,000 radios and 150 TV
receivers; 3 AM stations','875d176efe33378932f2c8df7584ccfa051642c9dfe2d22201877f0b4de34ae7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50596874ab09042b0a32d6daef6de3a6483adcffd55758a6314d4f857bb903c1',1976,'GP','Guadeloupe','communications',205,'DOMINICAN
EPUBLIC
SNS PUERTO
ee nico
@
&
Caribbean Sea ’
(See reference map HH)
LAND
687 sq. mi.; 24% cropland, 9% pasture, 4%
potential cropland, 16% forest, 47% wasteland, built
on; area consists of two islands
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GUADELOUPE/GUATEMALA
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 190 mi.','e263cab648d75bb9b1c837c674de0c0db2f045880ef8fe80eb38920cdd650e67','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bc2a320091067ee1b6b621a0cbdf61daf9ec4fb90da59a7baeffa60ab1af210',1976,'MQ','Martinique','communications',210,'Railroads: privately owned, narrow-gage planta-
tion lines
Highways: 1,260 mi.; 930 mi. paved, 330 mi.
gravel and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 2 major transport
Airfields: 8 total, 8 usable, 7 with permanent-
surface runways; | with runway 8,000-11,999 ft.; 2
seaplane stations
Telecommunications: domestic facilities inade-
quate; 21,700 tclephones; inter-island VHF radio
links; 2 AM and 8 TV transmitters; about 30,000 radio
and 13,200 TV receivers
DEFENSE FORCES
Military manpower: males 15-49, included with
Atlantic Ocean
eee
: 4 oe
Carihhean Sea Set ee
Wf MARTINIQUESS
Sobites race eae EEL
LAND
425 sq. mi,; 831% cropland, 16% pasture, 29% forest,
24% wasteland, built on
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 180 mi.
Railroads: none
Highways: 900 mi.; 600 mi. paved, 300 mi. gravel
and earth
Ports: 1 major (Fort-de-France), 5 minor
Civil air: no major transport
Airfields: 3 usable; 1 with permanent-surface
runway; 1 with runway 8,000-11,999 ft.; 1 seaplane
station
Telecommunications: domestic facilities inade-
quate; 29,300 telephones, inter-island VHF radio
links; satellite earth station; 1 AM, 1 FM, and 5 TV
stations; about 40,000 radio and 17,000 TV receivers
DEFENSE FORCES
Military manpower: males 15-49, included in','523167be981ea26fe832f518191c36ae57f4bb00893c057c817cb26d1ac773dc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70f7756a9b15fe928969a06660360d0892d50538256a1204d03f0a30e69df882',1976,'GT','Guatemala','communications',211,'LAND
42,040 sq. mi.; 14% cultivated, 10% pasture, 57%
forest, 19% other
Land boundaries: 1,010 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 250 mi.
83
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Gulf of','252e5aeaabe5ff4cda86540382159578c7b76f51d6ad908430e22703ee8944af','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eef6c9e3e29aaec366ced056371e0dceea8368c4976eded3ecce0b9834b2bb94',1976,'GW','Guinea-Bissau','communications',215,'(formerly Portuguese Guinea)
LAND
14,000 sq. mi. (includes Bijagos archipelago)
Land boundaries: 460 mi.
86
Atlantic Ocean.
" fa meee map mi
WATER
Limits of territorial waters (claimed): 150 n. mi.
Coastline: 170 mi.
Railroads: none
Highways: approx. 2,000 mi. (260 mi. bituminous,
remainder earth)
Inland waterways: 994 mi.
Ports: 1 major (Bissau), 2 minor
Civil air: no major transport aircraft
Airfields: 60 total, 60 usable; 5 with permanent-
surface runways; 10 with runways 4,000-7,999 ft.; 1
seaplane station
Telecommunications: limited system of open-wire
lines and radiocommunication stations, 2,700
telephones; 9,000 radio receivers; 1 AM, no FM or TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 115,000; 64,000
fit for military service','8ca141c7aaf424e0f135b7373f9696c5c3d2e4b07b0c1abf7360e4bd5ee5d5a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9268804232983f662a17dc20d2a36e6dc31d33d6f1c506ac34508e1c72b5a3b',1976,'GY','Guyana','communications',219,'LAND
83,000 sq. mi; 1% cropland, 3% pasture, 8%
savanna, 66% forested, 22% water, urban, and waste
Land boundaries: 1,600 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 285 mi.
Approved For Release 2005/04/22 :
~ Athntic-
Caribbean-
o60 Ocean
VENEZUELA
{See reference mag tf}
Railroads: 103 mi., all single track; 85 mi. 3''0”
gage, 18 mi. 3''6" gage
Highways: 2,200 mi.; 500 mi. paved, 1,000 mi.
otherwise improved, 700 mi. unimproved
Inland waterways: 3,700 mi.; Demerara River
navigable to Mackenzie by ocean steamers, others by
ferryboats, small craft only
Ports: 1 major (Georgetown), 3 minor
88
Civil air: 5 major transport aircraft
Airfields: 96 total, 89 usable; 4 with permanent-
surface runways; 12 with runways 4,000-7,999 ft.; 2
seaplane stations
Telecommunications: highly developed telecom
system with radio relay network and over 18,900
telephones; tropospheric scatter link to Trinidad:
280,000 radio receivers, 2 AM and 1 FM stations
DEFENSE FORCES
Military manpower: males 15-49, 180,000; 143,000
fit for military service
Military budget: for fiscal year ending 31
December 1971, $2.65 million; 2.7% of central
government budget
(Ses reference map Il}
LAND
10,700 sq. mi.; 31% cultivated, 18% rough pastures,
7% forested, 44% unproductive
Land boundary: 224 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing 15 n. mi.)
Coastline: 1,100 mi.
Railroads: 50 mi. 2''6" gage, single-track, privately
owned industrial line; 5 mi. dual-gage 2''6"''-3''6"
government line, dismantled
Highways: 2,000 mi.; 400 mi. paved, 600 mi.
otherwise improved, 1,000 mi, unimprove
Inland waterways: negligible; about 60 mi.
navigable
Ports: 2 major (Port-au-Prince, Cap Haitian), \\2
minor
Civil air: 7 major transport aircraft
Airfields: 16 total, 15 usable; 3 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 5
with runways 4,000-7,999 ft,, 2 seaplane stations
Telecommunications: all domestic facilities
inadequate, international facilities slightly better;
telephone expansion program underway; only 9,5
telephones, 300,000 radio and 13,400 TV receivers, 32
AM, 5 FM, and 1 TV station; COMSAT station under
construction
DEFENSE FORCES
Military manpower: males 15-49, 1,259,000,
669,000 fit for military service; about 52,000 reach
military age (18) annually
Military budget: for fiscal yeat ending 30
September 1975, $8.0 million; about 20% of
operational budget','cb926d94d9524f40d54afe7cf9b188e7acce3f615579ab4294c5d730819b1f72','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('592732d8c128989d7323f542dc8abfce47cd90f96406cd67fbe52a660b016c8b',1976,'HN','Honduras','communications',223,'LAND
43,300 sq. mi.; 27% forested, 30% pasture, 36%
waste and built-up, 1% cropland
Land boundaries: 950 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 510 mi.
Railroads: 357 Mi.; 202 mi. of 3''6” 8age, 155 mi. of
30" gage
1-8
-01051A00080001000
ed For Release 2005/04/22 : CIA-RDP79-010
Approv
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
HONDURAS/HONG KONG
Highways: 5,400 mi.; 700 mi. bituminous surfaced,
1,550 mi. gravel surfaced or improved earth, 3,150
unimproved earth
Inland waterways: 750 mi. navigable by small
craft
Ports: 3 major (Puerto Cortes, La Caiba, Tela), 9
minor
Civil air: 24 major transport aircraft
Airfields: 247 total, 222 usable; 4 with permanent-
surface runways; 8 with runways 4,000-7,999 ft.; 2
seaplane stations
Telecommunications: improved, but still inade-
quate; connection into Central American microwave
net; 15,000 telephones; 300,000 radio and 46,000 TV
receivers; 96 AM, 11 FM, and 5 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 707,000; 414,000
fit for military service; about 29,000 reach military
age (18) annually
Military budget: proposed for fiscal year ending 31
December 1975, $17.3 million; about 8.8% of central
government budget (includes the armed forces and
other military)','4f6289bcccb7f4e2d94f699f6178083dbdb5e2051ad089ce03f2674ae1014d64','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('191f8b43e5edd18ed2bb94947179b8cd03ce07b729a71a064774b0fd5f01f4a3',1976,'HK','Hong Kong','communications',227,'(Sen reteranco ip vi}
LAND
400 sq. mi.; 14% arable, 10% forested, 76% other
(mainly grass, shrub, steep hill country)
Land boundaries: 15 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 455 mi.
Ports: | 1 major
Civil air: 14 major transport aircraft
Airfields: 2 total, 2 usable: 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 1
with runway 4,000-7,999 ft.: 1 seaplane station
Telecommunications: modern facilities provide
domestic and international services; excellent
broadcast coverage provided by wired and radio
broadcast Stations; closed-circuit TV and TV
broadcast facilities; 913,411 telephones; 2.5 million
radio receivers: 100,000 wired-speakers: ] FM, 2AM
stations; wired-radiobroadecast network; 2 TV stations,
2 closed-circuit TV networks; 2. satellite ground
stations; radio relay to Taiwan/Philippines; new
coaxial cable link to Canton; 5 submarine cables;
Taiwan submarine cable planned
DEFENSE FORCES
Military manpower: males 15-49, 1,081,000:
839,000 fit for military service; about 53,000 reach
niilitary age (18) annually
Defense is the responsibility of U.K.
Ships: Hong Kong Marine Police, 38 police boats:
U.K. naval ships homeported in the U.K. operate in
the Indian Ocean, Gulf, and Far East; they rotate
assignments within the area: one destroyer escort
permanently assigned as the Hong Kong guard ship; a
varied number of auxiliary/service craft are assigned
to the Commander Hong Kong','733ad02099b71bbb3446ccc4ad9009892060345833322d810e6f4ca0ece6cbee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bafbd6380d80b961aabf15acfbdad32eac5c90a768cbaca85ed78e7951369f6f',1976,'HU','Hungary','communications',231,'LAND
35,900 sq. mi.; 60% arable, 14%
16% forested, 10% other
other agricultural,
92
Approved For Release 2005/04/22
{See reference map tV}
Land boundaries: 1,395 mi.
Railroads: 5,353 route mi.; 4,593 mi. standard
gage, 738 mi. narrow gage (mostly 2’5%''"), 22 mi.
broad gage (5''0"), 720 mi. double track, 755 mi.
electrified; government owned (1973)
Highways: 18,516 mi.; 478 mi. concrete, 11,992
mi. bituminous, 236 mi. stone block, 5,157 mi. gravel,
652 mi. earth (1973)
Pipelines: crude oil, 700 mi.; refined products, 180
mi.; natural gas, over 1,600 mi.
Inland waterways: 1,049 mi. (1975)
Freight carried: rail—142.8 million short tons
(1974), 15.8 billion short ton/mi. (1974); highway—
535.7 million short tons, 5.3 billion short ton/mi.
(1974); waterway—est. 15.6 million short tons, 5.7
billion short ton/mi. incl. int''l. transit traffic (1974)
River ports: 2 principal (Budapest, Dunaujvaros);
no maritime ports; outlets are Rostock, East Germany,
and Gdansk, Gdynia, and Szczecin in Poland
DEFENSE FORCES
Military manpower: males 15-49, 2,662,000;
2,144,000 fit for military service; about 78,000 reach
military age (18) annually
Military budget (announced): for fiscal year
ending 31 December 1975, 11.3 billion forints; about
3.5% of total budget','c431076a3fc6042856265c5cd27e1c4ff7293d00128d4401833ff76804345c6e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfed90ffe7df5c6d0a3b6f1eb5d0a19a8e0dd764cfdaafec1a8f37bfaddeca57',1976,'IS','Iceland','communications',235,'fe
(See sélotings map iV]
LAND
39,750 sq. mi.; arable negligible, 22% meadows and
pastures, forested negligible, 78% other
WATER
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 50 n. mi., effective 1 September 1972)
Coastline: 3,100 mi.
93
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Railroads: none
Highways: 6,905 mi.; 4,760 mi. crushed stone
(including lava) and gravel, 2,055 mi. unsurfaced
roads and motorable tracks, 90 mi. concrete or paved
Ports: 4 major (Akureyri, Hafnarfjordhur,
Reykjavik, Seydhisfjordhur), and about 50 minor
Civil air: 22 major transport aircraft registered
Airfields: 111 total, 107 usable; 4 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 13
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: adequate domestic service,
wire and radio communication system; 87,500
telephones; 78,000 radio and 53,500 TV receivers; 17
AM, 14 FM, and 82 TV stations; 2 coaxial submarine
cables
DEFENSE FORCES
Military manpower: males 15-49, 53,000; 48,000
fit for military service (Iceland has no conscription or
compulsory military service)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','7ffac62a23cbbbc2451ae61e0280779e90b3e67fd4d40fa3ac2e2c5dddf9fcf9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2feb57fdb3c2acd8587e24bc8303b7ed524456651bd036f30166151f10abb4e3',1976,'ID','Indonesia','communications',239,'ee SOUTH, AFAQPHILIPPINES.
= South China
= Sea ay
Pacific’
Ocean.
Indian Ocean
(See reference mep Vil}
LAND
736,000 sq. mi.; 12% small holdings and estates,
64% forests, 24% inland water, waste, urban, and
other
Land boundaries: 1,700 mi.
WATER
Limits of territorial waters (claimed): under an
archipelago theory, claim is 12 n. mi., measured
seaward from straight baselines connecting the
outermost islands
Coastline: 34,000 mi.
Railroads: 4,364 mi.; 3,990 mi. 3’6” gage, 317 mi.
2''5%" gage, 57 mi. 1''11%'''' gage; 132 mi. double
track: 74 mi. electrified; government owned
Highways: 57,460 mi.; 12,600 mi. paved, 25,200
mi. gravel or crushed stone, 19,660 mi. improved or
unimproved carth
Inland waterways: 13,410 mi.; Sumatra 3,400 mi.,
Java and Madura 510 mi., Borneo 6,500 mi., Celebes
150 mi., and Irian Barat 2,850 mi.
Ports: 10 major, 63 minor
Civil air: 88 major transport aircraft (includes 2
leased)
Airfields: 327 total, 270 usable; 49 with
permanent-surface runways; 9 with runways 8,000-
11,999 ft., 63 with runways 4,000-7,999 ft.
Telecommunications: extensive police net for
interisland service; international and domestic service
fair but improving; radiobroadcast coverage adequate
but TV limited to Java only; 268,963 telephones; 5
million radio and 293,000 TV sets; 187 AM, 1 FM,
and 12 TV stations; 1 earth satellite station on Java; 2
submarine cables to Singapore no longer in service
IRAN
LAND
636,000 sq. mi.; 14% agricultural, 11% forested,
16% cultivable with adequate irrigation, 51% desert,
waste, or urban, 8% migratory grazing and other
97
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
IRAN
Arabian
Sea
{See reference map Vj
Land boundaries: 3,305 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 50 n. mi.)
Coastline: 1,980 mi., including islands, 420 mi.
Railroads: 2,373 mi. 4''8 4" gage, 57 mi. 5''6” gage
Highways: 27,000 mi.; 7,500 mi. bituminous and
bituminous treatment, 14,250 mi. gravel and crushed
stone, 5,250 mi. improved earth
Inland waterways: 565 mi., excluding the Caspian
Sea, 64.6 mi. on the Shatt al Arab
Pipelines: crude oil, 1,640 mi.; refined products,
2,235 mi,; natural gas, 1,440 mi.
Ports: 7 major, 6 minor
Civil air: 36 major transport aircraft
Airfields: 163 total, 154 usable; 55 with
permanent-surface runways; 11 with runways over
12,000 ft., 17 with runways 8,000-11,999 ft., 57 with
runways 4,000-7,999 ft.
Telecommunications: advanced system of high-
capacity radio-relay links, open-wire lines, cables, and
tropospheric links; principal center Tehran, secondary
centers Isfahan, Meshed, and Tabriz; 552,500
telephones; 2.0 million radio and 1.0 million TV
receivers; 31 AM, 1 FM, and 67 TV stations; satellite
earth station ,
DEFENSE FORCES
Military manpower: males 15-49, 7,687,000,
4,553,000 fit for military service; about 340,000 reach
military age (21) annually
Military budget: for fiscal year ending 20 March
1976, $9.2 billion est; 36% of general budget','4a2f50bcf8fe92441a019ce7bdb62c7d88ff1e399dc5d2182f689db9e830d484','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95ffdbbf8dba8c664667026884225b490be1865e551f18d31255eb4cdbf20854',1976,'IQ','Iraq','communications',243,'ae 3 i : Caspian
Sea
Baghdad,
(See reference weap vj
LAND
172,000 sq. mi.; 18% cultivated, 68% desert, waste,
or urban, 10% seasonal and other grazing land, 4%
forest and woodland
Approved For Release 2005/04/22 :
Land boundaries: 2,280 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 36 mi.
Railroads: 1,057 mi.: 698 mi. 4’8''%4" gage, 359 mi.
ineter (3''3%"") gage; 10 mi. meter gage double track
Highways: 12,900 mi.: 4,000 mi. paved; 2,900 mi.
crushed stone, gravel, or improved earth: 6,000 mi.
earth and sand tracks
Inland waterways: 635 mi.; Shatt al Arab
navigable by maritime traffic for about 65 mi.; Tigris
and Euphrates navigable by shallow-draft steamers
Ports: 3 major (Basra, Umm Qasr, Al Faw)
Pipelines: crude oil, 1,660 mi; 25 mi. refined
products; 430 mi. natural gas
Civil air: 11 major transport aircraft
Airfields: 89 total, 72 usable: 24 with permanent-
surface runways; 43 with runways 8,000-11,999 ft;
15 with runways 4,000-7,999 ft.
Telecommunications: network consists of open-
wire lines, radio-relay links, and radiocommunication
stations; 129,400 telephones; 1.25 million radio
receivers; 350,000 TV receivers: 5 TV and 7 AM
stations
DEFENSE FORCES
Military manpower: males 15-49, 2,491,000:
1,392,000 fit for military service; about 120,000 reach
military age (18) annually
Military budget: for fiscal year ending 31 March
1975, $797,228.700: 12.9% of total budget
100','dccf7637be48fecd7adb101d80c43ce129aefed229da80f740d45ae12c1d4359','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1856a21ce809497e0320f6265e564ccbeec9668aa71872ee50f24e9e7e3fe57b',1976,'IE','Ireland','communications',247,'Atlantic
IRELAND?
(See reference map {V}
LAND
26,600 sq. mi; 17% arable, 51% meadows and
pastures, 3% forested, 2% inland water, 27% waste
and urban
Land boundaries: 224 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 900 mi.
Railroads: 1,361 mi, 53 gage; government
owned
Highways: 53,700 mi.; 46,950 mi. surfaced, 6,750
mi. earth
Inland waterways: approx. 650 mi.
Ports: 6 major, 38 minor
Civil air: 21 major transport aircraft
Airfields: 89 total, 38 usable; 8 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 4
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: small, modern system; all
cities interconnected for telephone and telegraph
service; 397,000 telephones; 895,000 radiobroadcast
receivers; 620,000 TV receivers; 3 AM, 7 FM, and
23 TV stations; 4 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 703,000; 551,000
fit for military service; about 28,000 reach military
age (17) annually
Military budget: for fiscal year ending 31 March
1974, $89.4 million, about 4.5% of the central
government budget','91bba464710d12a43c73593717445dda1da5013ad82c9d746b99ed5158d9ed67','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f662a942892945c4069ddaa5f76645e7b32f8d1067dd7c43ae4017ee2cf13cbd',1976,'IL','Israel','communications',251,'e
{See reference map V}
NOTE: The Arab territories occupied since the 1967
war are not included in the data below.
101
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LAND
8,000 sq. mi. (excluding about 25,000 sq. mi. of
occupied territory in Jordan, Egypt, and Syria); 20%
cultivated, 40% pastureland and meadows, 4%
forested, 4% desert, waste, or urban, 3% inland water,
29% unsurveyed
Land boundaries: 644 mi. (1967); including
occupied areas, 490 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
Coastline: 125 mi. (1967); including occupied
areas, 925 mi.
Railroads: 477 mi. 4’8''%" gage
Highways: 2,500 mi.; 2,300 mi. paved, 200 mi.
otherwise improved; additional mileage (mostly
paved) in occupied territories (670 mi. in Jordan,
1,150 mi. in Egypt (Sinai), 75 mi. in Syria)
Pipelines: crude oil, 440 mi.; refined products, 180
mi.; natural gas, 55 mi.
Ports: 3 major (Haifa, Ashdod, Elat), 5 minor
Airfields: 53 total, 42 usable; 21 with permanent-
surface runways; 5 with runways 8,000-11,999 ft., 10
with runways 4,000-7,999 ft.
Civil air: 23 major transport aircraft
Telecommunications; most modern and _ highly
developed in the Middle East; 685,400 telephones;
441,000 radio and 440,000 TV receivers; 28 TV, 13
AM, and 10 FM stations; 1 submarine cable; earth
satellite station
DEFENSE FORCES :
Military manpower: Jewish males 15-49, 712,000;
613,000 fit for military service; average number of
Jews reaching military age (18) annually — 28,000
males, 27,000 females; both sexes liable for military
service
Military budget: for fiscal year ending 31 March
1975, $3.7 billion; about 40% of total budget','d472789315ac5821b6649e483473b68c37beaa42976db4793290c653e5d6f432','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feeb2359efd9f1b0484590f8612223179dce9f83fbe1595f5a6c2cec15fca885',1976,'IT','Italy','communications',255,'* LAND
116,300 sq. mi.; 50% cultivated, 17% meadow and
pasture, 21% forest, 3% unused but potentially
productive, 9% waste or urban
(See reference map {Vj
Land boundaries: 1,058 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 3,105 mi.
Railroads: 12,857 mi.; 9,907 mi. government
owned; 9,805 mi. standard gage; 4,906 mi. electrified;
102 mi. narrow gage (3''1%''’); 2,950 mi. non-
government owned; 1,567 mi. standard gage; 794 mi.
electrified; 1,383 mi. narrow gage; 323 electrified
Highways: 179,000 mi.; autostrade 3,000 mi., state
highways 25,750 mi., provincial highways 57,000 mi.,
communal highways 93,250 mi.; 159,000 mi.
concrete, bituminous, or stone block, 15,500 mi.
gravel and crushed stone, 4,500 mi. earth
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ITALY/IVORY COAST
Inland waterways: 1,538 mi. navigable routes; 708
mi. rivers, 529 mi. canals, 307 mi. are lake routes
Pipelines: crude oil, 1,100 mi.; refined products,
900 mi.; natural gas, 6,869 mi.
Ports: 16 major, 22 significant minor
Civil air: 141 major transport aircraft
Airfields: 147 total, 147 usable; 77 with
permanent-surface runways; 2 with runways over
12,000 ft., 29 with runways 8,000-11,999 ft., 42 with
runways 4,000-7,999 {t.; 11 seaplane stations
Telecommunications: well engineered, well
constructed, and efficiently operated; 14.1 million
telephones; 13.7 million radio and 12.6 million TV
receivers; 82 AM, 606 FM, and 873 TV stations; 11
coaxial submarine cables; 3 communication satellite
ground stations
DEFENSE FORCES
Military manpower: males 15-49, 13,841,000;
11,586,000 fit for military service; 423,000 reach
military age (18) annually
IVORY COAST
{See reference map Vi)
LAND
125,000 sq. mi.; 40% forest and woodland, 8%
cultivated, 52% grazing, fallow, and waste, 200 mi. of
lagoons and connecting canals along eastern coast
Land boundaries: 2,005 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 320 mi.
Railroads: 408 mi. of the 728 mi. Abidjan to
Ouagadougou, Upper Volta line, all single track meter
gage; only diesel locomotives in use
Highways: 24,600 mi.; 1,045 mi. bituminous and
bituminous-surface treatment; 21,385 mi. gravel,
crushed stone, laterite, and improved earth; 12,600
mi. unimproved earth roads
Inland waterways: 460 mi. navigable rivers and
numerous coastal lagoons
Ports: 2 major (Abidjan, San Pedro), 8 minor
Civil air: 14 major transport aircraft
Airfields: 45 total, 44 usable; 3 with permanent-
surface runways; 2 with runways 8,000-11,999 feet,
7 with runways 4,000-7,999 feet; 1 seaplane station
Telecommunications: system only slightly above
African average; consists of open-wire lines and radio
relay links, which provide incomplete coverage of
country; Abidjan is only center; 25,200 telephones;
106
205,000 radio and 100,000 TV receivers; 2 AM, no
FM, and 4 TV stations; 1 submarine cable; satellite
earth station
DEFENSE FORCES
Military manpower: males 15-49, 1,060,000;
553,000 fit for military service; 57,000 males reach
military age (18) annually','97338c2d92c7f868ad051f0c5a8182201d9707bc9e7a2be908e668e278bd2376','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07d542292ac2ce6b6fbd24fc8cf47b1a7da870d86fa5f6288a7850acd51c89db',1976,'CU','Cuba','communications',259,'JAMAICA Ringston
Caribbean Sea
{See reference map tH)
LAND
4,410 sq. mi.; 21% arable, 23% meadows and
pastures, 19% forested, 37% waste, urban, or other
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 635 mi.
Railroads: 204 mi. government-owned, 43 mi.
privately owned, all standard gage, single track
Highways: 8,100, mi.; 3,000 mi. paved, 3,000 mi.
gravel, 2,100 mi. unimproved earth surfaces
Pipelines: refined products, 6 mi.
Ports: 3 major (Kingston, Montego Bay, Montego
Freeport), 10 minor
Civil air: 10 major transport aircraft
Airfields: 43 total, 23 usable; 12 with permanent-
surface runways; 2 with runways 8,000-11,999 ft.,
1 with runway 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fully automatic domestic
telephone network with 91,000 telephones; satellite
ground station; 600,000 radio and 105,000 TV
receivers; 8 AM, 8 FM, and 9 TV stations; 5
submarine cables, including 2 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 482,000; 307,000
fit for military service; no conscription; average
number currently reaching minimum volunteer age
(18) 22,000
Supply: dependent on U.K. and U.S.','34ac25a1688df8783288a8b104f4372ef8bca2c6823f4ab4c5f44dde20797459','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2fd613471f4c5e00f53f1e1075826b5bde3489bbcdef2bfbc921f0ab009dee7',1976,'JP','Japan','communications',263,'LAND
143,000 sq. mi.; 16% arable and cultivated, 3%
grassland, 12% urban and waste, 69% forested
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 7,500 mi. Japan; 1,000 mi. Ryukyus
Railroads: 17,620 mi.; 320 mi. standard gage,
17,300 mi. predominantly narrow gage (3''6"), 4,297
mi. double track, 7,485 mi. electrified; 73%
government owned -
Highways: 650,260 mi. (1974); 164,530 mi. paved,
most of remainder gravel or crushed stone
Inland waterways: approx. 1,100 mi.; seagoing
craft ply all coastal “inland seas”
Pipelines: crude oil, 41 mi., natural gas, 580 mi.
Ports: 53 major, over 2,000 minor
Civil air: 212 major transport aircraft (includes 2
leased)
Airfields: 191 total, 188 usable; 118 with
permanent-surface runways; 2 with runways over
12,000 ft.; 22 with runways 8,000-11,999 ft., 44 with
runways 4,000-7,999 ft., 6 seaplane stations
DEFENSE FORCES
Military manpower: males 15-49, 31,187,000;
96,341,000 fit for military service; about 805,000
reach military age (18) annually
Military budget: for fiscal year ending 31 March
1976, $4.4 billion; about 6.2% of total proposed
budget and 0.8% of GNP
NORTH
China Sea
(See reference map Vit}
LAND
47,000 sq. mi.; 17% arable and cultivated, 74% in
forest, scrub, and brush; remainder wasteland and
urban
Land boundaries: 1,040 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
111
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
KOREA, NORTH/KOREA, SOUTH
Coastline: 1,550 mi.
Highways: about 12,600 mi., 95% gravel or earth
surface
Inland waterways: 1,400 mi.,; mostly navigable by
small craft only
Ports: 6 major, 26 minor
DEFENSE FORCES
Military manpower: males 15-49, 3,650,000;
2,217,000 fit for military service; 186,000 reach
military age (18) annually
KOREA, SOUTH
(See reference map Vif}
LAND
38,000 sq. mi.; 23% arable (22% cultivated), 10%
urban and other, 67% forested
Land boundaries: 150 mi.
WATER
Limits of territorial waters: 3 n. mi. (fishing, 20-
200 n. mi., continental shelf including sovereignty
over superjacent waters)
Coastline: 1,500 mi.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
KOREA, SOUTH
Railroads: 1,967 mi.; 1,915 mi. standard gage, 32
mi. (2''6”) narrow gage; 270 mi. double track; 175 mi.
electrified; government owned
113
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
KOREA, SOUTH/KUWAIT
Highways: 29,095 mi.: 4,860 mi. paved, 20,040 mi.
gravel, 2,015 mi. improved earth, 2,180 mi,
unimproved earth (1973)
Inland waterways: 1,000 mi.; use restricted to
small native craft
Freight carried: rail (1973) 5.3 billion short
ton/mi., 37.7 million short tons; highway 24 million
short tons; air (1959) 796,260 lbs. carried
Pipelines: 255 mi.,
construction
tefined products, under
Ports: 10 major, 18 minor
Civil air: 26 major transport aircraft
Airfields: 116 total, 114 usable; 52 with
permanent-surface runways; 15 with runways 8,000-
11,999 ft., 13 with runways 4,000-7,999 ft.; 2 seaplane
stations
DEFENSE FORCES
Military manpower: males 15-49, 8,184,000;
5,329,000 fit for military service: average number
reaching military age (18) annually 353,000
Military budget: for fiscal year ending 31
December 1975, $883 million; about 27% of total
budget','1b043b3448ea40bc432cfdb214e370520b76f244541c4c20535dfef48222e15e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bb955db08c22725aa3b8b7cc803b5847edeec394433b91dc81ed1097989c359',1976,'JO','Jordan','communications',267,'(See reference map V}
NOTE: The war between Israel and the Arab states
in June 1967 ended with Israel in control of West
Jordan. Although approx. 930,000 persons resided in
this area prior to the start of the war, fewer than
750,000 of them remain there under the Israeli oc-
cupation, the remainder having fled to East Jordan.
Over 14,000 of those who fled were repatriated in
August 1967, but their return has been more than off-
set by other Arabs who have crossed and are contin-
uing to cross from West to East Jordan. These and
certain other effects of the 1967 Arab-Israeli war are
not included in the data below.
LAND
37,100 sq. mi. (including about 2,100 sq. mi.
occupied by Israel); 11% agricultural, 88% desert,
waste, or urban, 1% forested
Land boundaries: 1,100 mi. (1967, 1,037 mi.
excluding occupied areas)
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 16 mi.
Railroads: 388 mi. 3''554"’ gage, single track
Highways: 4,400 mi.; 3,652 mi. bituminous, 124
mi. improved earth; 624 unimproved earth
Pipelines: crude oil, 130 mi.
Ports: | major (Aqaba)
Civil air: 8 major transport aircraft
Airfields: 24 total, 15 usable; 12 with permanent-
surface runways; 1 with runways over 12,000 ft., 10
with runways 8,000-11,999 ft., 2 with runways 4,000-
7,999 ft.
Telecommunications: adequate telecommunica-
tion system for the needs of the country; 40,500
telephones; 529,000 radio and 132,000 TV receivers: 1
AM and | TV stations; 1 earth satellite station
DEFENSE FORCES
Military manpower: males 15-49, 588,000; 417,000
fit for military service: average number currently
reaching military age (18) annually 30,000
110
Approved For Release 2005/04/22
Military budget: for fiscal year ending 31
December 1975, $154,539,600; 22% of total budget','10f6340eec8dd44733651680a5b808f4c0224e365982da1f14cfb298d4edfac3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70cfdf31da95eecb4d8a2e667fc36805553fb44bc9213dda90701ba399106521',1976,'KE','Kenya','communications',271,'(See reference map V1}
LAND
225,000 sq. mi.; about 21% forest and woodland,
13% suitable for agriculture, 66% mainly grassland
adequate for grazing (1971)
Land boundaries: 2,093 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 333 mi.
Railroads: 1,275 mi.; meter gage
Highways: 30,200 mi.; 2,315 mi. paved, 27,885 mi.
gravel and/or earth
Inland waterways: part of Lake Victoria and Lake
Rudolph are within boundaries of Kenya
Ports: | major (Mombasa), 3 minor
Civil air; 9 major transport aircraft
Airfields: 233 total, 216 usable; 6 with permanent-
surface runways; 1 with runway over 12,000 ft., 2 with
runways 8,000-11,999 ft., 41 with runways 4,000-
7,999 ft.
Telecommunications: in top group of African
systems; consists of radio-relay links, open-wire lines,
and radiocommunication stations; principal center
Nairobi, secondary centers Mombasa and Nakuru;
85,200 telephones; 774,000 radio and 37,000 TV
receivers; 4 AM, 1 FM, and 5 TV stations; satellite
ground station
DEFENSE FORCES
Military manpower: males 15-49, 2,899,000;
1,779,000 fit for military service; no conscription
Military budget: for fiscal ycar ending 30 June
1974, $32,759,000; about 4.3% of total budget
KOREA, NORTH
Sea of','6528b7382f7f56552ab725ca1476ab4078b2c950b8b770468fce9938aed43675','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a14217e93e41b0ba2e068988ea480735b66fba70288ad511e9df270388d4486b',1976,'KW','Kuwait','communications',275,'(See reference map V}
LAND
6,200 sq. mi. (excluding neutral zone but including
islands); insignificant amount forested; nearly all
desert, waste, or urban
Land boundaries: 285 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 310 mi.
Railroads: none
Highways: 1,550 mi.; 465 mi. bituminous: 1,085
mi. earth, sand, light gravel
Pipelines: crude oil, 545 mi.; refined products, 25
mi.; natural gas, 75 mi.
Ports: 3 major (Ash Shuwaikh, Ash Shuaybah,
Mina al Ahmadi), 4 minor
Civil air: 9 major transport aircraft
Airfields: 11 total, 5 usable; 3 with permanent-
surface runway; 3 with runways 8,000-11,999 ft.,
2 with runways 4,000-7,999 ft.
Telecommunications: excellent international
and adequate domestic telecommunication facilities;
95,100 telephones; 215,000 radio and 132,000 TV sets;
3 AM and 8 TV stations; satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, about 811,000;
about 179,000 fit for military service
Coast Guard: 12 patrol boats
Military budget: for fiscal year ending 31 March
1975, $136,008,620; 6.9% of total budget
LAOS
LAND
91,430 sq. mi.; 8% agricultural, 60% forests, 32%
urban, waste, and other; except in very limited areas,
soil is very poor; most of forested area is not
exploitable
Land boundaries: 3,140 mi.
Approved For Release 2005/04/22 :
(See reference map Vil}
Highways: about 9,700 mi. (including Communist-
held areas); 800 mi. bituminous or bituminous
treated, 2,700 mi. gravel, crushed stone, or improved
earth; 6,200 mi. unimproved earth and often
impassable during rainy season mid-May to mid-
September
Inland waterways: about 2;850 mi., primarily
Mekong and tributaries; 1,800 additional miles are
sectionally navigable by craft drawing less than 1.5 ft.
116
Ports (river): 5 major, 4 minor
Airfields: 113 total, 84 usable; 7 with permanent-
surface runways; 11 with runways 4,000-7,999 ft., 1
with runway 8,000-11,999 ft.
DEFENSE FORCES
Military manpower: males 15-49, 788,000; 423,000
fit for military service; average number currently
reaching usual military age (18) annually, 33,000; no
conscription age specified','2b085c414e8f5ce56e12f04676e1e448b0c5924f50a9770d848e410a1ffef6d3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b12c94cb368d6a79bb622a3b905a11d010024cedd2b43ec0ed3503838fc4c008',1976,'LB','Lebanon','communications',279,'vie aie Sra
(See reference map V}
LAND
4,000 sq. mi.; 27% agricultural land, 64% desert,
waste, or urban, 9% forested
Land boundaries: 285 mi.
WATER
Limits of territorial waters (claimed): no specific
claims (fishing, 6 n. mi.)
Coastline: 140 mi.
Railroads: 238 mi.; 184 mi. 486", 51 mi. 3''5%";
all single track
Highways: 5,160 mi.; 3,850 mi. paved, 310 mi.
gravel and crushed stone, 404 mi. improved earth, 596
mi. unimproved earth
Pipelines: crude oil, 45 mi.
Ports: 3 major (Beirut, Tripoli, Sayda), 5 minor
Civil air: 30 major transport aircraft
Airfields: 5 total, 3 usable; 3 with permanent-
surface runways; 3 with runways 8,000-11,999 ft.
Telecommunications: excellent international
telecommunication facilities include satellite ground
station; good domestic telephone and_ telegraph
service; 227,000 telephones; 1.3 million radio and
375,000 TV receivers; 7 TV, 2 FM, and 1 AM
radiobroadcast stations; 1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 772,000; 472,000
fit for military service; average of about 30,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
December 1975, $141,225,650; 16% of total budget','11f82961835deead1b791dfdf738bdd18cac4710b929b378a98b06ededebfcc9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97f71e4d218f314c9f960bc59e8dd87bfd98ad9bb4d7e497cef1c0a292811fd9',1976,'LS','Lesotho','communications',283,'LAND
11,700 sq. mi.; 15% cultivable; largely mountain-
ous
Land boundaries: 500 mi.
Railroads: 1 mi.; owned, operated, and included in
the statistics of the Republic of South Africa
Highways: approx. 1,370 mi.; 120 mi. paved; 580
mi. crushed stone, gravel, or stablized soil: 670 mi.
improved or unimproved earth
Civil air: no major transport aircraft
Airfields: 27 total, 20 usable: 3 with runways
4,000-7,999 ft., 1 with permanent surface runway
Telecommunications: system a modest one
consisting of a few landlines, a small radio-relay
system, and minor radiocommunication stations;
Maseru is the center; 3,425 telephones; 11,000 radio
receivers; 2 AM, no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 214,000: fit for
military service 116,000
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
ii ht _STT~S
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','7204ec9ba4ad7dc8fe85507e57563393e1c085dd7157a194872994bb75e82259','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74fbf70fe9b71ebadccef3011e8c2c5458ce0b603bd6d4af77b82eb7c9fbfea3',1976,'LR','Liberia','communications',287,'LIBERI
Monrovia ~
Atlantic Ocean
(See reference map Vi}
LAND
43,000 sq. mi.; 20% agricultural, 30% jungle and
swamps, 40% forested, 10% unclassified
Land boundaries: 830 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 3860 mi.
Railroads: 312 mi.; 220 mi. standard gage, 90 mi.
nartow gage (3’6’''): all lines single track; rail systems
owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 4,950 mi.: 340 mi. bituminous treated;
remainder improved and unimproved laterite, gravel,
and/or earth
Inland waterways: 230 mi. navigable
Ports: 3 major (Monrovia, Buchanan, Greenville-
Sino Harbor), 4 minor
Civil air: 3 major transport aircraft
Airfields: 80 total, 78 usable; 2 with permanent-
surface runways; | with runway 8,000-11,999 ft.. 6
with runways 4,000-7,999 ft.; | seaplane station
Telecommunications: telephone and telegraph
limited; main center is Monrovia; 3,400 telephones;
261,000 radio and 8,500 TV receivers; 5 AM, no FM,
5 TY stations; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 407,000; 217,000
fit for military service; no conscription
Military budget: for year ending 31 December
1975, $4,664,000; 3.9% of total budget','ab61b7899853fd32ee78a7edce1ccdd13e0087df5206b47a07b05ba0776a4b3c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc15d7d332685902f7864ff2d38d3c4d54d3fbc5905ff2aadd1842aea6d93a41',1976,'LY','Libya','communications',291,'LAND
679,000 sq. mi.; 6% agricultural, 1% forested, 93%
desert, waste, or urban
Land boundaries: 2.700 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(except for Gulf of Sidra where sovereignty is claimed
und northern limit of jurisdiction fixed at 32°30''/N.
and the unilaterally proclaimed 100. n. mi. zone
around Tripoli)
Coastline: 1,100 mi.
Railroads: none
Highways: 10,050 mi.; 4,780 mi. bituminous or
bituminous treated, 5,270 mi. improved and
unimproved earth and gravel
Pipelines: crude oil 1,520 mi.; natural gas 175 mi.;
refined products 140 mi.; liquid petroleum gas 135 mi.
Ports: 8 major (Tobruk, Tripoli, Banghazi), 6 minor
Civil air: 12 major transport aircraft; an additional
25 major transports are operated by external carriers
engaged in charter work for several oil companies
Airfields: 86 total, 79 usable; 13 with permanent-
surface runways, | with runway over 12,000 ft., 10
with runways 8,000-11,999 ft., 35 with runways 4,000-
7,999 ft.; 2 seaplane stations
$3,358 million (1973); over 99%
Approved For Release 2005/04/22 :
Telecommunications: system is just within top
one-third of African systems; consists of radio-relay
and tropospheric-scatter links, open-wire lines, and
radiocommunication stations; principal centers are
Tripoli and Banghazi; 49,800 telephones; 225,000
radio and 6,000 TV receivers; 7 AM, 1 FM, and 2 TV
stations; 8 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 500,000; 292,000
fit for military service; about 22,000 reach military
age (17) annually; conscription now being imple-
mented
Military budget: estimated for period 1 April - 31
December 1973, $88,800,000; 4.1% of announced
total budget for nine-month period','036c662c86895cbab0e9bc7aa52344e05b61bcc6a73a1d599a2cbc5b4bd0f734','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f797e615a3410a26321f0e32cae1c0916b8183b26ad4f483227ec91d62bb3bc5',1976,'LI','Liechtenstein','communications',295,'MN el
WET
> GERMANY =~
—S AUSTRIA.
{Sea reference map 1V)
LAND
65 sq. mi.
Land boundaries: 47 mi.
Railroads: 9.94 mi. 4''8%" gage, electrified;
owned, operated, and included in statistics of Austrian
Federal Railways
Highways: no information on total mileage
Civil air: 2 major transport aircraft registered in','cad22417e3baaf90660971afe2138249f3c2e6106dbb1a5694342457b92554e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e83516563e37134c4efcb0182dabe147afe4c937c95ee2ad8b1f27750b9d9467',1976,'CH','Switzerland','communications',299,'Airfields: none
Telecommunications: automatic telephone system
serving about 14,800 telephones; no broadcast
facilities; 5,500 radio and 4,700 TV _ receivers
(programs from Switzerland)
122
Approved For Release 2005/04/22
DEFENSE FORCES
Defense is responsibility of Switzerland
a
{See reference map iV)
LAND
16,000 sq. mi; 10% arable, 43% meadows and
pastures, 90% waste or urban, 24% forested, 3%
inland water
Land boundaries: 1,171 mi.
Railroads: 3,186 mi.; 1,809 government owned
(SBB), 1,763 mi. 4''8%"'' page. 46 mi 3''3%"'' gage. 837
mi. double track, 972 mi. Single track, 99% electrified:
1,377 mi. non-government owned, 444 mi. 4''8Q""
Sage, 886 mi. 3''33%4" &age, 47 mi. 2''71%" Bage, 100%
electrified
Highways; 37,158 mi., all paved
Pipelines: crude oil, 195 mi.; natural Bas, 650 mi.
Inland waterways: 41 mi.; Rhine River-Basel to
Rheinfelden, Schaffhausen to Constanz: in addition,
00010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SWITZERLAND/SYRIA
there are 12 navigable lakes ranging in size from Lake
Geneva to Hallwilersee
Ports: 1 major (Basel), 2 minor
Civil air: 79 major transport aircraft (including 4
leased from a foreign country)
Airfields: 91 total, 75 usable; 87 with permanent-
surface runways; 2 with runways over 12,000 ft., 8
with runways 8,000-11,999 ft., 11 with runways 4,000-
7,999 ft. |
Telecommunications: excellent domestic, interna-
tional, and broadcast services; 3.90 million
telephones; communications satellite station; 2.06
million radio and 1.75 million TV receivers; 7 AM, 94
FM, and 811 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,539,000;
1,331,000 fit for military service; 47,000 reach military
age (20) annually
Military budget: for fiscal year ending 31
December 1975, $1,148 million; 19% of central
government budget
(See reference map V)
LAND
72,000 sq. mi. including 500 sq. mi. of Israeli-
occupied territory; 48% arable, 29% grazing, 2%
forest, 21% desert
Land boundaries:
occupied area 1,340 mi.)
WATER
Limits of territorial waters (claimed): 12 n. mi.
(plus 6 n. mi. “‘necessary supervision zone’’)
Coastline: 120 mi.
Railroads: 959 mi.; 769 mi. standard gage, 190 mi.
narrow gage (3''5%"’)
Highways: 7,150 mi.; 4,300 mi. paved, 810 mi.
gravel or crushed stone, 1,540 mi. improved earth, 500
mi. unimproved earth
Inland waterways: 420 mi.; of little importance
Pipelines: crude oil, 810 mi.; refined products, 320
mi.; natural gas 140 mi.
Ports: 3 major (Tartus, Latakia, Baniyas), 2 minor
Civil air: 5 major transport aircraft
Airfields: 37 total, 32 usable; 22 with permanent-
surface runways; 2] with runways 8,000-11,999 ft., 2
with runways 4,000-7,999 ft.
Telecommunications: good international and
domestic service; 143,300 telephones; 1 million radio
and 137,000 TV receivers; 5 TV and 5 AM stations
DEFENSE FORCES
Military manpower: males 15-49, 1,703,000;
958,000 fit for military service; about 89,000 reach
military age (19) annually
Military budget: for fiscal year ending 31
December 1974, $394 million; 23% of total budget
TANZANIA
LAND
362,800 sq. mi. (including islands of Zanzibar and
Pemba, 1,020 sq. mi.); 6% inland water, 15%
202
Indian
Ocean
4
\\ MOZAMBIQUE
(See reference map Vl)
cultivated, 31% grassland, 48% bush forest,
woodland, on mainland, 60% arable, of which 40%
cultivated on islands of Zanzibar and Pemba
Land boundaries: 2,413 mi.
WATER
Limits of territorial waters (claimed): 50 n. mi.
Coastline: 885 (this includes Mafia Island, 70;
Pemba Island, 110; and Zanzibar, 132)
Railroads: 2,222 mi.; 600 mi. 3''6" gage; 1,622 mi.,
meter gage, 4 mi. double track; Tanzania portion of
Tan-Zam Railroad completed
Highways: total 30,000 mi., including 390 mi. on
Zanzibar Island and 277 mi. on Pemba and Mafia
Islands; about 1,400 mi. bituminous treated, (370 mi.
on Zanzibar and Pemba), 28,600 mi. gravel, crushed
stone, or unimproved earth
Pipelines: refined products 610 mi.
Inland waterways: 730 mi. of navigable streams;
several thousand mi. navigable on Lakes Tanganyika,
Victoria, and Nyasa
Ports: 8 major (Dar es Salaam, Mtwara, Tanga)
Civil air: 9 major transport aircraft
Airfields: 107 total, 100 usable; 9 with permanent-
surface runways; 1 with runway 8,000 to 11,999 ft., 42
with runways 4,000-7,999 ft.
Telecommunications: telephone and telegraph
good in main centers, only fair outside main towns;
40,150 telephones; 231,000 radio receivers; 4 AM, no
FM or TV stations; 4 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 3,459,000;
1,919,000 fit for military service
Military budget: for fiscal year ending 30 June
1976, $156 million, 17% of total budget
203
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','609984154d5eb6affb6fc710b2f8efd52f5aa8b41c2fffad309654a8cfd09b76','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76101e0dafcac6cb8d4944f537afbfc398ece3f13d87cf898b70b2c16621242c',1976,'LU','Luxembourg','communications',300,'(See reference map /V}
LAND
1,000 sq. mi.; 25% arable, 27% meadows and
pasture, 15% waste or urban, 33% forested, negligible
amount of inland water
Land boundaries: 221 mi.
Railroads: 169 mi. standard gage; 100 mi. double
track; 85 mi. electrified
Highways: 3,070 mi. all paved; about 50 mi.
limited access divided highway completed or under
construction
Pipelines: refined products, 30 mi.
Inland waterways: 23 mi.; Moselle River
Port: (river) Mertert
Civil air: 10 major transport aircraft (includes 3
registered in Iceland)
Airfields: 1 total, 1 usable with permanent-surface
runway 8,000-11,999 ft.
Telecommunications: adequate and efficient
system; 146,100 telephones; 200,000 radiobroadcast
receivers; 90,000 TV receivers; 2 AM, 1 FM, 2 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 82,000; 69,000
fit for military service; about 3,000 reach military age
(19) annually
Military budget: for fiscal year ending 31
December 1974, $17.5 million; 3.3% of central
government budget','800487ac609236ec7ea4f988ddcf17f0cc1850ecdf8e465c6e20268e71689eed','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c1375d763bcc2ef2e4bf5b01f20db7af419d30478617c9ed215be47d40e3f64',1976,'MO','Macao','communications',304,'LAND
6 sq. mi.; 10% agricultural, 90% urban
Land boundaries: 220 yds.
WATER
Limits of territorial waters (claimed): 6 n. mi.;
fishing, 12 n. mi.
Coastline: 25 mi.
123
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MACAO/MADAGASCAR
EJHONG KONG','e3f3a73a2b373bb5cf3c4049bccba86b93828ccdbca8370baceea00528235ce9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae27565970f897cbc0701a42cc818a0a318b90931445180a7dfcf09e74a173cc',1976,'PH','Philippines','communications',305,'(See reference map Vil)
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
Telecommunications: fairly modern facilities
provide adequate services for domestic and
international requirements; broadcast coverage is
provided by AM and FM radiobroadcast facilities and
a wired broadcast network; 8,459 telephones: 65,000
radio receivers; 2 AM and 2 FM radio stations; no TV
stations; no submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 60,000; 35,000
fit for military service
Defense is responsibility of Portugal
Philippine Sea
Quezén
City SY
“e
S PHILIPPINES
Sea 4 /
x
: te:
0
Kc ee
= carers A
\\ oF; A
(See reference map Vil)
LAND
116,000 sq. mi.; 53% forested, 30% arable land, 5%
permanent pasture, 12% other
WATER
Limits of territorial waters (claimed): 0-300 n. mi.
(under an archipelago theory, waters within straight
lines joining appropriate points of outermost islands
are considered internal waters; waters between these
baselines and the limits described in the Treaty of
Paris, December 10, 1898, the U.S.-Spain Treaty of
November 7, 1900, and the U.S.-U.K. Treaty of
January 2, 1930 are considered to be the territorial sea)
Coastline; about 14,000 mi.
Railroads: 2,177 mi.; 2 common-carrier systems
(3''6" gage) totaling about 727 mi.; 19 industrial
systems with 4 different gages totaling 1,450 mi.;
34% government owned
Highways: 61,600 mi. (1974); 12,610 mi. paved;
29,725 mi. gravel, crushed stone, or stabilized soil
surface; 19,265 mi. improved earth
Inland waterways: 2,000 mi.; limited to shallow-
draft (less than 5 ft.) vessels
Pipelines: refined products, 157 mi.
Ports: 11 major, 100 minor
Civil air: 52 major transport aircraft
Airfields: 334 total, 312 usable; 46 with
permanent-surface runways; 7 with runways 8,000-
11,999 ft., 25 with runways 4,000-7,999 ft.
DEFENSE FORCES
Military manpower: males 15-49, 9,318,000;
6,691,000 fit for military service; about 400,000 reach
military age (20) annually
Supply: limited small arms ammunition, small
patrol craft, and helicopter production; other materiel
obtained almost exclusively from U.S.; naval ships
and equipment from Australia, Japan, Singapore,
U.S., and Italy; aircraft and helicopters from West
Germany and U.S.
Military budget: for fiscal year ending 30 June
1975, $403 million; about 19% of total budget','d2d7665d9b499b8a1f018543990d6417ce1379320a728b601f9a268b95d2cda9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63bfa42f562819f5f3edae4171008ee3b3faa86c690cede52a496814d988e4d4',1976,'MG','Madagascar','communications',309,'LAND
230,000 sq. mi.; 5% cultivated, 58% pastureland,
21% forested, 8% wasteland, 2% rivers and lakes, 6%
other
WATER
Limits of territorial waters (claimed): 50 n. mi.
Coastline: 3,000 mi.
Railroads: 549 mi. of meter gage
Highways: 5,300 mi.; 1,875 mi. paved, 2,225 mi.
crushed stone, gravel, or stabilized soil; 1,200 mi.
improved and unimproved earth: remainder are tracks
Inland waterways: 600 mi. perennially navigable;
Lac Alaotra (200 sq. mi.)
Ports: 4 major (Tamatave, Diego Suarez, Majunga,
Tulear)
Civil air: 9 major transport aircraft
Airfields: 249 total, 129 usable: 28 with
permanent-surface runways; 3 with runways 8,000-
11,999 ft., 46 with runways 4,000-7,999 ft.
Telecommunications: system above African
average; includes open-wire lines, some radio-relay
and coaxial links and a communication satellite
ground station; 29,300 telephones; 605,000 radio and
7,100 TV receivers; 1 AM, no FM, and 1 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,683,000;
993,000 fit for military service; average number
reaching military age (20) annually about 77,000
Military budget: for fiscal year ending 31
December 1974, $25,536,864: about 6.3% of total
budget
(See reference map V1}
LAND
156 sq. mi.; 54% arable land, nearly all of it is
under cultivation, 17% wood and forest land, 29%
other (mainly reefs and other surfaces unsuited for
agriculture); 40 granitic and 43 coral islands
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing 12 n. mi.)
Coastline: 305 mi. (Mahe Island 58 mi.)','df03d3b0012f37648b705b4d8b092d30f51e2bce3bed6e591deec17d470aa9c0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('105048a1a175d7d72293cae4c4bbb03c216753d9f66120bdb70b287f4e4f1135',1976,'MW','Malawi','communications',313,'LAND
36,700 sq. mi.; about 31% of land area arable (of
which less than half is cultivated), nearly 25%
forested, 6% meadow and pasture, 38% other
126
Indian
Ocean
ae apo
aNODESIA
(See reference map Vi}
Land boundaries: 1,790 mi.
Railroads: 352 mi. (3''6" gage)
Highways: 6,710 mi; 540 mi. paved; 4,040 mi.
crushed stone, gravel, or stabilized soil; 2,180 mi.
unimproved earth
Inland waterways: Lake Nyasa (Lake Malawi),
800 route mi. and Shire River, 90 mi.
Ports: 3 lake
Civil air: 6 major transport aircraft
Airfields: 46 total, 45 usable; 1 with permanent-
surface runway; 7 with runways 4,000-7,999 ft.
Telecommunications: the system is barely above
average for African countries and consists of thinly
spread open-wire lines, radio-relay links, and
radiocommunication stations, principal centers are
Blantyre, Zomba, Lilongwe, and Muzuzu; 16,800
telephones; 125,000 radio receivers; 5 AM, 4 FM and
no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,041,000; about
528,000 fit for military service','dc352114b66aa73a3afaa6c1609bd436f30a5e06e90ec13477f8a8759ceab975','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('569b67bbd05f74117040837e63e1c81f0fc149f19cd12293ff1051dbb8214f12',1976,'MY','Malaysia','communications',317,'aa
SOUTH
VIETNAM
South China
Sea
NOTE: Malaysia, which came into being on 16
September 1963, consists of Peninsular Malaysia,
which includes 11 states of the former Federation
of Malaya, plus East Malaysia, which includes
the 2 former colonies of North Borneo (renamed
Sabah) and Sarawak
LAND
Peninsular Malaysia: 50,700 sq. mi.; 20%
cultivated, 26% forest reserves, 54% other
Sabah: 29,400 sq. mi.; 13% cultivated, 34% forest
reserves, 53% other
Sarawak: 48,300 sq. mi.; 21% cultivated, 24%
forest reserves, 55% other
Land boundaries: Peninsular Malaysia 315 mi.,
East Malaysia 1,110 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: Peninsular Malaysia, 1,285 mi., East
Malaysia 1,620 mi.
Railroads:
Peninsular Malaysia: 1,035 mi. 3''3%"'' gage; 8 mi.
double track; government-owned
East Malaysia: 96 mi. meter gage in Sabah
Highways:
Peninsular Malaysia: 11,247 mi.; 9,809 mi. hard
surfaced (mostly bituminous surface treatment), 975
mi. crushed stone/gravel, 463 mi. improved or
unimproved earth
East Malaysia: about 2,823 mi. (1,022 in Sarawak,
1,801 in Sabah); 509 mi. hard surfaced (mostly
bituminous surface treatment), 1,853 mi. gravel or
crushed stone, 767 mi. earth
Inland waterways:
Peninsular Malaysia: 1,985 mi.
East Malaysia: 2,540 mi. (975 mi. in Sabah, 1,565
mi. in Sarawak)
Ports:
Peninsular Malaysia: 3 major, 10 minor
East Malaysia: 4 major, 7 minor (3 major, 3 minor
in Sabah; 1 major, 4 minor in Sarawak)
Civil air; 27 major transport aircraft (including 1
Boeing 707 leased from U.K.)
Pipelines; crude oil, 90 mi.; refined products, 35
mi.
Airfields:
Peninsular Malaysia: 73 total, 73 usable; 16 with
permanent-surface runways; 2 with runways 8,000-
11,999 ft., 12 with runways 4,000-7,999 ft.
Sabah: 33 total, 33 usable; 5 with permanent-
surface runways; 1 with runway 8,000 to 11,999 ft.; 4
with runways 4,000-7,999 ft.
Sarawak: 45 total, 45 usable; 5 with permanent-
surface runways; 4 with runways 4,000-7,999 ft.
Telecommunications:
Peninsular Malaysia: good intercity service
provided mainly by microwave relay; international
service good; good coverage by radio and television
broadcasts; 217,000 telephones; 425,000 radio and
129
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MALAYSIA/MALDIVES
355,000 TV receivers; 30 AM stations; no FM, 15 TV
stations; submarine cables extend to India, Ceylon,
and Singapore; connected to SEACOM submarine
cable terminal at Singapore by microwave relay; 1
ground satellite station
Sabah: adequate intercity radio-relay network
extends to Sarawak via Brunei; 18,500 telephones;
35,274 radio receivers; 3,014 TV receivers; 4 AM, 1
FM, 5 TV stations; SEACOM submarine cable links
to Hong Kong and Singapore
Sarawak: adequate intercity radio-relay network
extends to Sabah via Brunei; 22,000 telephones;
104,289 radio and 500 TV receivers; 1 AM, no FM, no
TV stations
DEFENSE FORCES
Military manpower:
Peninsular Malaysia: males 15-49, 2,299,000;
1,456,000 fit for military service
Sabah: males 15-49, 177,000; 113,000 fit for
military service
Sarawak: males 15-49, 252,000; 159,000 fit for
military service; conscription age for Malaysia is 21 —
an age reached by about 122,000 annually
External defense dependent on loose Five Power
Defense Agreement (FPDA) which replaced Anglo-
Malayan Defense Agreement of 1957 as amended in
1963
Military budget: for fiscal year ending 31
December 1975, $442.6 million; about 15% of central
government budget
Surmnatra
“pal mbanggy fol Bagj
Indonesi
= Surabaya a oe Ti
java a Por .Timor +
Jogha Be a 0c8? 3 no
is)','8c9643a6f5b43d5bbc1979af5ee19ff187dcb93c10b548c782f7c522e7fa4e67','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c0d3200aa1536fba2c6a1a58e6d2b3d0eceac60fe85a35b7a9dedd2cc7037f4',1976,'MV','Maldives','communications',321,'Arabian
Sea
. / SRI
* taecadive ~ LANKA
Sea
MALDIVES :.
Indian Ocean
{See reference map Vit)
LAND
115 sq. mi.; 2,000 islands grouped into 12 atolls,
about 220 islands inhabited
WATER
Limits of territorial waters (claimed): the land
and sea between latitudes 7°9‘''N. and 0°45’S. and
130
between longitudes 72°30''E. and 73°48''E; these
coordinates form a rectangle of approximately 37,000
sq. n. mi.; territorial sea ranges from 2.75 to 55 n. mi.
Coastline: 400 mi. (approx. )
Railroads: none
Highways: none
Ports: 2 minor
Civil air: 2 major transport aircraft
Airfields: 2 total], 2 usable; 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 1
with runway 4,000-7,999 ft.
Telecommunications: minimal domestic and
international telecommunication facilities; 300
telephones; 2,400 radio sets; 1 AM station','fee0f8239a3a4bb6bc18a531ad0c6fabc82a1680c87c68b2dcd60fb474247859','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d15266476c99a783ee597a0123b4f61e00e3fb61ca0b0b4483ad1a3d86732f7c',1976,'ML','Mali','communications',325,'(See reference map Vi)
LAND
465,000 sq. mi.; only about a fourth of area arable,
forests negligible, rest sparse pasture or desert
Land boundaries: 4,635 mi.
Railroads: 400 mi. meter gage
Highways: approximately 8,200 mi.; 1,010 mi.
bituminous, 1,050 mi. improved earth, 6,140 mi.
unimproved earth
Inland waterways: 1,141 mi. navigable
Civil air: 4 major transport aircraft
Airfields: 42 total, 38 usable; 7 with permanent-
surface runways; 2 with runway 8,000-11,999 ft., 11
with runways 4,000-7,999 ft.
Telecommunications: system poor and provides
only minimum service to government, business, and
public; open-wire and radiocommunication used for
long distance telecommunications; radio sometimes
only link to outlying points; 7,800 telephones; 75,000
radio receivers; 2 AM, no FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,304,000;
732,000 fit for military service; no conscription
Military budget: for fiscal year ending 31
December 1973, $9,954,042; about 16.7% of total
budget
MALTA |
Mediterreneen Sea
Fa a reference mi ‘)
LAND
121 sq. mi.; 45% agricultural, negligible amount
forested, remainder urban, waste, or other (1965)
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing 12 n. mi.)
Coastline: 87 mi.
Highways: 760 mi., 650 mi. paved (asphalt), 80 mi.
crushed stone or gravel, 30 mi. improved and
unimproved earth
Ports: 1 major (Valletta), 2 minor
Civil air: 2 major transport aircraft (both leased)
Airfields: 4 total, 2 usable; 2 with permanent-
surface runways; 2 with runways 4,000-7,999 ft.; 1
seaplane station
Telecommunications: modern automatic tele-
phone system centered in Valletta; 48,800 telephones;
140,000 radio and 75,000 television receivers; 38AM,3
FM, and 1 TV stations; 8 submarine cables, including
1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 89,000; 67,000
fit for military service
Supply: has received 2 patrol boats, small arms, and
mortars from Libya; vehicles and engineer equipment
from Italy
Military budget: for fiscal year ending 31 March
1976, $9,079,000; about 4.5% of central government
budget
Approved For Release 2005/04/22 :','52073a4fcfd1f4caed3cbe6d54a3ed930e5ed3cf68bd698d0592351e2e155ad6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd30341d647e738f22db4e1be663ac3e6108dc07f936072881d716f9c6b1684c',1976,'MR','Mauritania','communications',330,'Nouakchott
Atlantic
Ocean
(See reference map Vij
LAND
419,000 sq. mi. ; less than 1% suitable for crops,
10% pasture, 90% desert
Land boundaries: 3,180 mi.
WATER
Limits of territorial waters (claimed): 30 n. mi.
(fishing, 6 n. mi. exclusive rights, 6 n. mi. contiguous
zone)
Coastline: 490 mi.
Railroads: 400 mi. standard gage, single track,
privately owned
Highways: 3,800 mi.; 350 mi. paved; 380 mi.
gravel, crushed stone, or otherwise improved; 3,070
mi, unimproved
Inland waterways: 500 mi.
Ports: 1 major (Nouakchott), 2 minor
Civil air: 7 major transport aircraft
Airfields: 30 total, 30 usable; 9 with permanent-
surface runways; 1 with runway 8,000-11,999 ft.; 16
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: telephone poor, telegraph
fair: 1,300 telephones; 81,500 radio receivers; 1 AM,
no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 306,000; 146,000
fit for military service; conscription law not
implemented
Supply: primarily dependent on France
Military budget: for fiscal year ending 31
December 1975 (revised), $17,054,253; 16.1% of total
budget','58a92441f977702f96cdef4fa09fd34a6471bacac32235e30f0eb7b8b51ea63b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('293c339ce93470ce903cca4ad5c3ff17b71a3a90c81a5c2237791fcd493aa570',1976,'MU','Mauritius','communications',334,'LAND
720 sq. mi. (excluding dependencies); 50%
agricultural, intensely cultivated; 39% forests,
woodlands, mountains, river, and natural reserves; 3%
built-up areas; 5% water bodies, 2% roads and tracks,
1% permanent wastelands
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 110 mi.
135
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
REUNION
Indian Ocean
{See raference map Vi}
Highways: 1,100 mi.; 990 mi. paved, 110 mi. earth
Civil air: no major transport aircraft
Ports: 1 major (Port Louis), 2 minor
Airfields: 6 total, 5 usable; 1 with permanent-
surface runway; | with runway 8,000-11,999 ft.
Telecommunications: 22,600 telephones; radio
telegraph service with Reunion, Malagasy Republic,
Seychelles, Zanzibar, and other places in Africa; 1
AM, no FM, and 4 TV stations; 160,000 radio and
25,300 TV sets; submarine cables extend to Republic
of South Africa and Seychelles Islands
DEFENSE FORCES
Military manpower: males 15-49, 206,000; 103,000
fit for military service
Military budget: for fiscal year ending 30 June
1973, $3,981,038; 6.5% of total budget
* 6
REUNION
Ocean
(See reference map VI)
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 125 mi.
Railroads: none
Highways: 1,415 mi.,; 1,155 mi. paved, 260 mi.
gravel, crushed stone, or stabilized earth
Ports: 1 major (Port des Galets)
Civil air: no major transport aircraft
Airfields: 6 total, 6 usable; 1 with permanent-
surface runway; 1 with runway 8,000-11,999 ft., 2
with runways 4,000-7,999 ft.
Telecommunications: adequate system for size of
island of fairly modern open-wire lines and
radiocommunication stations; principal center Saint-
Denis; external radiocommunications to Comoro
Islands, France, Malagasy, and Mauritius; 22,200
telephones; 90,000 radio and 30,200 TV receivers; 2
AM, no FM, and 8 TV stations; 1 satellite ground
station
DEFENSE FORCES
Military manpower: military age males included
with France
RHODESIA','3625bbd77a44c36c2c8ac4d953431b4462053bc9126ac7156b0af75984ad53ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('449363f1db62e48b3186ee57935f606bb7e1ccaf9badf871b4bddf1bd083d2bf',1976,'US','United States','communications',338,'(S08 valine mep H)
LAND
764,000 sq. mi.; 12% cropland, 40% pasture, 22.%
forested, 26% other (including waste, urban areas and
public lands)
Land boundaries: 2,620 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 5,800 mi.
Approved For Release 2005/04/22
Railroads: 12,300 mi.; 11,610 mi. 4’8%4" gage; 690
mi. 3''0" gage; 64 mi. electrified: 12,233 mi.
government owned, 67 mi. privately owned
Inland waterways: 1,800 mi. navigable rivers and
coastal canals
Pipelines: crude oil, 2,410 mi.; refined products,
2,090 mi.; natural gas, 3,470 mi.
138
Ports: 9 major, 20 minor
Civil air: 182 major transport aircraft
Airfields: 1,497 total, 1,467 usable; 116 with
permanent-surface runways; 2 with runways over
12,000 ft., 22 with runways 8,000- 11,999 ft., 242 with
runways 4,000-7,999 ft.; 9 seaplane stations
Telecommunications: highly developed telecom
system with extensive radio relay links: connection
into Central American microwave net; communica-
tion satellite ground station; 2.6 million telephones,
about 6:5 million radio and 4.8 million TV receivers,
600 AM, 100 FM, and 115 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 12,821,000,
9,758,000 fit for military service: average number
reaching military age (18) annually, 675,000
Military budget: for year ending 31 December
1975, $581.0 million; about 4.6% of direct federal
budget (includes merchant marine and military
industry)
This “ Factsheet’ on the U.S. is provided solely as a
service to those wishing to make rough comparisons of
foreign country data with a U.S. “yardstick.”
Information is from U.S. open sources and
publications and in no sense represents estimates by
the U.S. intelligence community.
LAND
3,615,211 sq. mi. (contiguous U.S. plus Alaska and
Hawaii); 19% cultivated, 27% grazing and pasture,
32% forested, 22% waste, urban, and other
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Railroads: 202,775 mi. (1972)
Highways: 3,787,000 mi.
Inland waterways: 25,260 mi. of navigable inland
channels, exclusive of the Great Lakes; freight carried
951 million short tons (1970)
Pipelines: petroleum, 174,000 mi. (1972)
Ports; 25 major
Merchant marine: 600 ships (1,000 GRT or over)
totaling 9,982,730 GRT, 14,722,666 DWT; includes 3
passenger, 5 short-sea passenger, 163 cargo, 119
container, 14 roll-on/roll-off cargo, 934 tanker, 1
liquefied gas, 17 bulk, 2 combination ore/oil, 23
LASH Seebee and barge carriers, 19 specialized
carriers; in addition there are 178 ships in reserve fleet
Civil air: 5,214 major transport aircraft (1973)
Airfields: 12,405 (1972)
Telecommunications: 4,398 AM, 3,151 FM, 940
TV broadcast stations (1974); 147,000,000 telephones
(1975), 65 telephones per 100 population (1975); 360
million radio and 110 million TV receivers
DEFENSE FORCES
Personnel: army 1,148,000, navy and marines
1,065,000, air force 942,000 (1973)
Military budget: $80.6 billion (1974 est.)
231
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051400080Q81Q0
Arctic *~-
urmansk Cee)
a
we. Cary ‘
Riga Leningrad “arkhangel''sk ee \\
JX
e Minsk we
xtloscow
eKiyev
Ocean
=
H-8and Asia
sos
TS =
_ Narth Pole
qtakutsk
U.S. S.R.
hi
oKuybyshev Sverdlovsk
Volgograd
ai Omsk
e Novosibirsk
Caspian
Yerevan Sea Aral
bake UU Sea
Bal
ne
@ashkent e
Wu-lu-mu-ch''i
(Urumehi)
*o-shih
(Kashgar)
on, fndian claim
&
Chinese ling
of cantrot
Saudi
Arabia
Maldives 4
indian
1200 Miles
1200 Kilometers
NAMES ANO BOUNDARY REPRESENTATION
ARE NOT NECESSARILY AUTHORITATIVE
602853 1-76 (540317)
Medea, ¥ dla Lumpur Sara
a :
S “ysin
papore
ae)
By
Ha-erh-pin,
(Harbin)
Ch''ing-tao
(Tsingta
Lan-chou » {Tsingtao}
efsi-an
China &0
La-sa
‘Shang-hai
eWu-han
aipet
Kuang-chgu Taiwe
e(Cantga) eat
Macao ong Kong
(LK
@Ch''ang-tu
oK''un-ming
Luzon
Brunei Z Papua
(U.K New','8f0ca51cac0236c531cd319c17cdc5360245ceaeeabb198861a6a1073c0ccfa6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80f3b5a59b59fca9893ca7441661871d7b8a8f1823512ab352149338f40f52f0',1976,'MC','Monaco','communications',342,'& °
o
Mediterranean Sea
(See reference map 1}
LAND
0.6 sq. mi.
Land boundaries: 2.3 mi,
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2.6 mi.
Railroads: 1 mi (see France)
Highways: none; city streets
Ports: | minor
Civil air: no major aircraft
Airfields: none
Telecommunications: served by the French
communications system; automatic telephone system
with about 21,300 telephones; 2AM, 1 FM, and1 TV
station; 12,000 radio and 16,000 TV receivers
DEFENSE FORCES
France responsible for defense','038018e51c7ff501e8e64849876dbc7f3090c9d9824b3955632c96b3cf30c73a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62d4252f35ecc7e14da660277e77906cc8bbcb0866d2b42896e820ecfda7ff5d',1976,'MN','Mongolia','communications',346,'pas
(See reference map Vi}
LAND
604,100 sq. mi.; almost 90% of Jand area is pasture
or desert wasteland, varying in usefulness, less than
1% arable, 10% forested
Land boundaries: 4,975 mi.
Railroads: 909 route mi.; all broad gage (5''0"'')
(1974)
Inland waterways: 385 miles of principal routes
(1975)
Freight carried: rail — 5,1 million short tons, 1,046
million short ton mi. (1974); highway—about 16.0
million short tons (1973); 1,120 million short ton/mi.
(1974)
DEFENSE FORCES
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 3]
December 1975, 268 million tugriks, 10% of total
budget
140','5d04010b8a1ac38307b429cef3ca1689da89aef4193be1b72ca7171421fd75eb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7cb75d6851a9d33135366296dac850953af19555afcdfbd5fb291ed32b3fc7c',1976,'MA','Morocco','communications',350,'PORTUGS
Atlantic
te
‘ae reference map Vif
LAND
158,100 sq. mi.; about 32% arable and grazing
land, 17% forest and esparto, 51% desert, waste, and
urban
Land boundaries: 1,240 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 70 n. mi.)
Coastline: 1,140 mi.
Railroads: 1,091 mi. standard gage, 93 mi. double
track; 493 mi. electrified
Highways: 32,180 mi.; 11,203 mi. bituminous,
3,244 mi. gravel, crushed stone, and improved earth,
17,733 mi. unimproved earth
Pipelines: crude oil, 85 mi.; refined products, 305
mi.; natural gas, 60 mi.
Ports: 8 major (including Spanish-controlled Ceuta
and Melilla), 10 minor
Civil air: 12 major transport aircraft
Airfields: 83 total, 83 usable; 24 with permanent-
surface runways; 2 with runways over 12,000 ft., 11
with runways 8,000-11,999 ft., 36 with runways 4,000-
7,999 ft.; 4 seaplane stations
Telecommunications: superior system by African
standards composed of open-wire lines, coaxial,
multiconductor and submarine cables and radio-relay
links; principal centers Casablanca and Rabat,
secondary centers Fes, Marrakech, Oujda, Sebaa
Aioun, Tangier and Tetouan; 181,000 telephones; 1.5
million radio and 336,000 TV receivers; 24 Moroccan
AM, 1 Voice of America AM, 8 FM, 17 TV stations;
11 submarine cables; 1 satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 3,779,000;
2,242,000 fit for military service; about 185,000 reach
military age (18) annually; limited conscription
Military budget: for fiscal year ending 31
December 1975, $339,248,800; 8.7% of total budget
141
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
genta 8
“guthortative:
502850 1-76
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-010514DD08@@Q08H-America
°
Jamaica Haiti
ent
/ Dom. Puerto i
Rep. Rico "A.
(U.S) 3
Honduras &
Caribbean Sea ¢ Barbados
i¢aragua UR aS ae Grenada North
i Barranquilla oe * 28 53 Trinidad and Tobago Atlant ic
Canal Zone Reais
HS, 3
: Ocean
Venezuela
Georgetown
Medellin ap atarmaribe
bogota','c7a1c16bbc9608b14a71c7a6d31316986dc13e5c91e8a803c0e33f5a97588cc9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abb9fff150093ae1313209225c276e042acd9e890ee3de2e7cae4099b275e2e6',1976,'MZ','Mozambique','communications',354,'=
>
a tae
: %
2
Indian Qcean
{See reference map Vi}
LAND
803,769 sq. mi.; 80% arable, of which 1%
cultivated, 56% woodland and forest, 14% wasteland
and inland water
Land boundaries: 2,875 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,535 mi.','19ed24376e442ee302e31e58e1806f0fea9431fb90bfbc4a13367117a9d42f4d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffcf9e47c31b649dd715414ff6b09f850a3d0114f8963fae596f55435b794815',1976,'DE','Germany','communications',359,'Railroads: 1,965 mi.; 1,877 mi. 3''6" gage (6 mi.
double track), 88 mi. 2''54" gage
Highways: 20,000 mi.; 1,740 mi. paved; 18,260
other (mostly earth)
Inland waterways: approx. 2,330 mi. of navigable
routes
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MOZAMBIQUE/NAURU
Pipelines: crude oil, 190 mi.
Ports: 3 major (Lourenco Marques, Beira, Nacala),
2 significant minor
Civil air: 13 major transport aircraft
Airfields: 332 total, 327 usable; 28 with
permanent-surface runways; 5 with runways 8,000-
11,999 ft.; 39 with runways 4,000-7,999 ft.
DEFENSE FORCES
Military manpower: males 15-49, 2,204,000;
1,108,000 fit for military service
Railroads: 5,465 mi.; 277 mi. meter gage, 4,808
mi. broad gage, 380 mi. narrow gage, 635 mi.
double track; 178 mi. electrified; government owned
Highways: 43,500 mi.; 11,922 mi. paved, 8,040 mi.
gravel, 1,146 mi. improved earth; 22,392 mi. unim-
proved earth
Inland waterways: 1,150 mi.
Pipelines: crude oil, 143 mi.; natural gas, 1,200 mi.
Ports: 1 major, 5 minor
Civil air: 20 major transport aircraft
Airfields: 112 total, 109 usable; 65 with
permanent-surface runways; 1 with runway over
12,000 ft., 25 with runways 8,000-11,999 ft., 50 with
runways 4,000-7,999 ft.
Telecommunications: excellent international
radiocommunication service over CENTO links:
domestic wire and radiocommunication and
broadcast service very good; 195,325 (est.) telephones;
1,015,000 radio and 125,000 TV sets; 20 AM, no FM,
3 TV stations, and 3 repeaters; 1 ground satellite
station
DEFENSE
Military manpower: males 15-49, 17,093,000;
9,494,000 fit for military service; 833,000 reach
military age (17) annually
Military budget: for fiscal year ending 30 June
1975 $607 million; about 31% of total budget
Railroads: none
Highways: 3,815 mi.; 36 mi. paved, 19 mi. gravel,
1,367 mi. improved earth, 2,393 mi. unimproved;
2,485 mi. secondary roads; most roads improved or
unimproved earth
Inland waterways: Lake Kivu navigable by
steamers and barges
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
eae
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
RWANDA/ST. CHRISTOPHER-NEVIS-ANG UILLA
Civil air: 1 major transport aircraft
Airfields: 10 total, 9 usable; 2 with permanent-
surface runways; 2 with runways 4,000-7,999 ft., 1
with runway 8,000-11,999 ft.
Telecommunications: telephone and_ telegraph
limited; main center is Kigali; 2,480 telephones;
60,000 radio receivers; 2 AM, no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 956,000; 462,000
fit for military service; no conscription; 40,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
December 1974, $6,522,000; 17.3% of total budget
ST, CHRISTOPHER-NEVIS-
Railroads: 350 mi., 4’8''4"" gage
Highways: 9,300 mi.; 5,600 mi. bituminous, 3,700
mi. gravel and improved carth, undetermined mileage
of earth roads and tracks
Pipelines: crude oil, 1,500 mi.; refined products,
240 mi.; natural gas, 61 mi.
Ports: 3 major (Jidda, Ad Damman, Ras Tanura), 6
minor
Civil air: 17 major transport aircraft
Airfields: 101 total, 79 usable; 23 with permanent-
surface runways; 14 with runways 8,000-11,999 ft., 40
with runways 4,000-7,999 ft., 2 with runways over
12,000 ft.
Telecommunications: excellent international tele-
communications; fair domestic service; 84,100
telephones; 255,000 radio and 150,000 TV receivers;
11 TV, 1 FM, and 4 AM stations; 2 submarine cables;
2 satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 1,453,000;
804,000 fit for military service; about 64,000 reach
military age (18) annually
Military budget: for fiscal year ending 12 July
1975, $2,536 million; about 22% of total budget
Railroads: 3,218 mi.; 2,419 mi. 3''6” gage, 78 mi.
3/334” gage, 85 mi. 204" gage, 636 mi. 1''11%” gage;
532 mi. of 3''6" gage electrified
Highways: 87,800 mi.; 1,200 mi. bituminous,
11,300 mi. gravel or crushed stone, 75,300 mi. earth
Inland waterways: comprising the Zaire, its
tributaries, and unconnected lakes, the waterway
system affords over 9,320 mi. of navigable routes
Ports: 2 major (Matadi, Boma), 1 minor
Pipelines: refined products, 460 mi.
Civil air; 87 major transport aircraft
Airfields: 385 total, 294 usable; 20 with
permanent-surface runways; 1 with runway over
12,000 ft., 2 with runways 8,000-11,999 ft., 54 with
runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: limited, barely adequate
telephone service, telegraph service good; 25,000
telephones; 100,000 radio receivers; 7,100 TV
receivers; 12 AM, 1 FM, and 2 TV stations; 1 satellite
ground station
DEFENSE FORCES
Military manpower: males 15-49, 5,963,000;
2,986,000 fit for military service
Military budget: for fiscal year ending 31
December 1974, $147,033,460; about 16.5% of total
budget','e265384613814ea9b5ae7773e50796c86d20ac61615e491c152a9a6b824ede3b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e982c897b95ee9455b4d6e447cb8457f2c0a3aa36f716b9595272e8a74c4622d',1976,'NR','Nauru','communications',360,'NAURUe
Pacifie Ocean
(See reference map Vill)
LAND
8.2 sq. mi.; insignificant arable land, no urban
areas, extensive phosphate mines
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline; 15 mi.
Railroads: none
Highways: about 17 mi.; 13 mi. paved, 4 mi.
improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 3 major transport aircraft
Airfields: 1, coral-surfaced, 5,270 ft.
Telecommunications: adequate intraisland and
international radiocommunications provided via
Australian facilities; 540 telephones; 3,575 radio
receivers, 1 AM, but no TV or FM radiobroadcasting
facilities
DEFENSE FORCES
Military manpower: males 15-49, about 1,800; fit
for military service, about 1,000; average number
reaching military age (18) annually, 1975-79, less than
100
No formal defense structure and no regular armed
forces
143
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','3e6a978c558c1d425a76c833e97572f189a7a2589cf81504f78ba3a0182fff21','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7696d040696be0b8c385212fbd196fe9958c7ec08df39a081b4256469256035',1976,'NP','Nepal','communications',364,'Bay
of Bengal
(See reference map Vil}
LAND
54,600 sq. mi.; 16% agricultural area, 14%
permanent meadows and pastures, 38% alpine land
(unarable), waste, or urban; 32% forested
Land boundaries: 1,720 mi.
Railroads: 105 mi., all narrow gage (2''6"); mostly
government owned; all in Terai close to Indian
border; only 83 mi. sector from border to Bizalpura
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NEPAL/NETHERLANDS
presently in use; a 28 mi. segment has been
abandoned and 44 mi. utilized to transport rock from
quarry near Dharau to Kosi Dam near Rajbiras
Highways: 1,686 mi; 510 mi. paved, 270 mi.
gravel or crushed stone, 906 mi. improved and
unimproved earth, 200 mi. of seasonally motorable
tracks
Civil air: 5 major transport aircraft
Airfields: 57 total, 56 usable; 5 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 6
with runways 4,000-7,999 ft.
Telecommunications: poor telephone and tele-
graph service; good radiocommunication and
broadcast service; international radiocommunication
service is poor; 9,162 telephones, 76,000 radio and no
TV sets, 3 AM, no FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 3,073,000;
1,550,000 fit for military service; 140,000 reach
military age (17) annually
Military budget: for fiscal year ending 15 July
1975, $9.7 million; 5.6% of total budget','d01ad51946d00b7c3b0ace22fc506619ff3a68fa26a2ff965aeca7c2cc9c8e39','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cddc03ea20e7977c8e0cc2199f011be9776f5798a6d2c36439998827193daa49',1976,'NC','New Caledonia','communications',368,'Coral Sea x,
NEWS"
CALEDONIA Pacific
Ocean
Tasman Sea
ro Yew
ip ZEALAND
(See reference map Vill}
LAND
8,500 sq. mi; 6% cultivable, 22% pasture land,
15% forests, 57% waste or other
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 3 n. mi.)
Coastline: 1,400 mi.','2917f5c4730e803ef90bd343da341646fd98b2436bd440a08eb1310bd9140a7c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f68d72593ba00db010608892f3d3861270d6bb6590b7d0f4249038780ee94e17',1976,'NZ','New Zealand','communications',370,'LAND
108,736 sq. mi.; 3% cultivated, 50% pasture; 10%
parks and reserves; 20% waste, water, etc., 1% urban,
16% forested; 4 principal islands, 2 minor inhabited
islands, several minor uninhabited islands
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: about 9,400 mi.
Railroads: 2,982 mi.; all 3''6’’ gage; 170 mi. double
track; 70 mi. electrified; over 99% government owned
Highways: 57,400 mi. (1974); 27,925 mi. paved,
29,475 mi. gravel or crushed stone
Inland waterways: 1,000 mi.; of little importance
to transportation
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NEW ZEALAND/NICARAGUA
Pipelines: natural gas, 488 mi.
Ports: 3 major
Civil air: 57 major transport aircraft
Airfields: 182 total, 177 usable; 22 with
permanent-surface runways; 2 with runways 8,000-
11,999 ft., 48 with runways 4,000-7,999 ft.; 4 seaplane
stations
Telecommunications: excellent international and
domestic systems; 1,410,532 telephones; 2,700,000
radio and 760,847 TV sets; 60 AM stations in 31 cities,
no FM, and 4 TV stations, and 120 repeaters;
submarine cables extend to Australia and Fiji Islands,
1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 723,000; 610,000
fit for military service; average number reaching
military age (20) annually about 25,000
Military budget: proposed for fiscal year ending 31
March 1976, $238.3 million; about 4% of central
government budget','2f865bae0499c70c43b3d3b3521ab2b901b99a25d210ffb6e41ee671843164a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39fb75d84c7dcb11bf20a54a94503c7b6e626e7d660495f6ab2e1701b6897369',1976,'NI','Nicaragua','communications',374,'Managua
Pacitic Ocean
(See reference map tl}
LAND
57,100 sq. mi.; 7% arable, 7% prairie and pasture,
50% forest, 36% urban, waste, or other
Land boundaries: 760 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 200 n. mi.; continental shelf, including
sovereignty over superjacent waters)
Coastline: 565 mi.
Railroads: 220 mi.; 200 mi. of 3''6” gage,
government owned; 20 mi. narrow gage, privately
owned
Highways: 8,050 mi; 850 mi. paved, 3,200 mi.
otherwise improved, 4,000 mi. unimproved
Inland waterways: 1,380 mi., including 2 large
lakes
Pipelines: crude oil, 45 mi.
Ports: 4 major (Carinto, Puerto Cabezas, Puerto
Somaza, San Juan del Sur), 6 minor
Civil air: 10 major transport aircraft
Airfields: 421 total, 414 usable; 6 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 8
with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: low-capacity wire and
radio-relay network; connection into Central
American microwave net; satellite ground station;
18,500 telephones; est. 700,000 radio and 75,000 TV.
receivers; 75 AM, 30 FM, and 7 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 516,000; 316,000
fit for military service; 23,000 reach military age (18)
annually
Military budget: for fiscal year ending 31
December 1975, $19.7 million for the Ministry of
Defense, including civil functions (e.g., police and
civil air); 7.4% of central government budget','9907a854de5237ec20e4a9c8b075e04c3cdcc785ae615686427beced8c1b8671','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9d5ff8c90b5c4fdf241d37d2b6fae1702242681b211bec64605d4b53895d1d4',1976,'NE','Niger','communications',378,'Niamey
*
ENIN
Gulf of Guinea
(See reference mep Vi}
LAND
489,000 sq. mi.; about 3% cultivated, perhaps 20%
somewhat arable, remainder desert
Land boundaries: 3,570 mi.
Railroads: none
Highways: approx. 4,640 mi.; 580 mi. bituminous,
1,640 mi. gravel, 2,420 mi. unimproved earth
Inland waterways: Niger River navigable 185 miles
from Niamey to Gaya on the Dahomey frontier from
mid-December through March
Ports: Niger landlocked; outlet to sea is Cotonou,
Dahomey
Civil air: 5 major transport aircraft
Airfields: 63 total, 60 usable; 5 with permanent-
surface runways; 1 with runway 8,000-11,999 ft.,
17 with runways 4,000-7,999 ft.
Telecommunications: principal telecommunica-
tion center Niamey; telephone poor, telegraph fair,
3,300 telephones; 100,000 radio and 500 TV receivers;
4 AM, no FM, and 1 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,042,000;
556,000 fit for military service; about 43,000 reach
military age (18) annually','83c9fca6cad582857ad60e0f53acaf606237b9054a19d3be4e75cc26ffbadc74','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59f20cfa4b8520be605a055420a20a389f0c000592e69fe2c7c1a94e90862ceb',1976,'NG','Nigeria','communications',382,'Lagos
ne Gulf
OF Guinea
LAND
357,000 sq. mi.; 24% arable (13% of total land area
under cultivation), 35% forested, 41% desert, waste,
urban, or other
Land boundaries: 2,507 mi.
WATER
Limits of territorial waters (claimed): 30 n. mi.
Coastline: 530 mi.
153
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Railroads: 2,180 route mi.; 3’6" gage
Highways: 55,425 mi.; 9,500 mi. paved (mostly
bituminous surface treatment); 45,925 mi. laterite,
gravel, crushed stone, improved earth
Inland waterways: 5,330 mi. consisting of Niger
and Benue rivers and smaller rivers and creeks;
additionally, the newly formed Kainji Lake has
several hundred miles of navigable lake routes
Pipelines: crude oil, 645 mi.; natural gas, 40 mi.;
refined products, 3 mi.
Ports: 2 major (Lagos, Port Harcourt), 10 minor
Civil air: 17 major transport aircraft
Airfields: 91 total, 77 usable; 15 with permanent-
surface runways; 5 with runways 8,000-11,999 ft., 25
with runways 4,000-7,999 ft.; 4 seaplane stations
Telecommunications: composed of radio-relay
links, open-wire lines, and radiocommunication
stations; principal center Lagos, secondary centers
Ibadan and Kaduna; 106,300 telephones; 5 million
radio and 90,000 TV receivers; 25 AM, 6 FM, and 8
TV stations; 2 submarine cables; 1 satellite ground
station
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NIGERIA/NORWAY
DEFENSE FORCES
Military manpower: males 15-49, 14,199,000;
8,233,000 fit for military service; average number
reaching military age (18) annually 740,000
Military budget: for fiscal year ending 31 March
1976, $1,283,400,000; 17.9% of total budget','94c583e4500b5a58fa22219be5a283dc107bd55132f36d2eedd1e7d8620e4716','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fae8a7434d70f1e0666914a8c49756eeb5594ddd57109c7b5c60bdfbc04d9cb2',1976,'NO','Norway','communications',386,'Norwegian:
ee Sea.
(Sea reterance map 1V)
LAND
Norway: 125,000 sq. mi.; Svalbard, 24,000 sq. mi.;
Jan Mayen, 144 sq. mi.; 3% arable, 2% meadows and
pastures, 21% forested, 74% other
Land boundaries: 1,603 mi.
WATER
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.)
Coastline: mainland 2,125 mi.; islands 1,500 mi.
(excludes long fjords and numerous small islands and
minor indentations which total as much as 10,000 mi.
overall)
Railroads: 2,662 mi.; State (NSB) operates 2,636
mi. standard gage, 2,589 mi. single track, 1,516 mi.
electrified, 47 mi. double track; 10 mi. standard gage
electrified privately owned; 16 mi. meter (3''3%"’) gage
electrified privately owned
Highways: 46,000 mi.; 9,000 mi. paved, 37,000 mi.
crushed stone and gravel
Inland waterways: 980 mi.; 5-8 ft. draft vessels
maximum
Pipelines: refined products, 33 mi.
Ports: 9 major, 69 minor
Civil air: 54 major transport aircraft
156
Airfields: 93 total, 93 usable; 48 with permanent-
surface runways; 10 with runways 8,000-11,999 ft., 14
with runways 4,000-7,999 ft.; 20 seaplane stations
Telecommunications: high-quality domestic and
international telephone, telegraph, and telex service;
1.38 million telephones; 2.2 radiobroadcast and 1.02
million TV receivers; 86 AM, 316 FM, and 654 TV
stations; 5 coaxial submarine cables; COMSAT
station
DEFENSE FORCES
Military manpower: males 15-49, 918,000; 755,000
fit for military service; average number reaching
military age (20) annually, 32,000
Arabian Sea
(See reference map Vj
LAND
About 82,000 sq. mi.; negligible amount forested,
remainder desert, waste, or urban
Land boundaries: 860 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing 50 n. mi.)
Coastline: 1,300 mi.
Highways: 1,750 mi. total; 3 mi. bituminous
surface, remainder motorable natural-surface track
Pipelines: crude oil 230 mi.
Ports: 1 major (Qaboos), 6 minor
Civil air: no major transport aircraft
Airfields: 145 total, 189 usable; 5 with permanent-
surface runways; 3 with runways 8,000-11,999 ft., 51
with runways 4,000-7,999 ft.
Telecommunications: fair international and
domestic service; 3,400 telephones; 1 AM station
DEFENSE FORCES
Military manpower: males 15-49, 118,000; 68,000
fit for military service
Military budget: for fiscal year ending December
1974, est. $87,000,000, about 14.9% of total budget
Approved For Release 2005/04/22 :','30918b3859a8dd7d862947dcbb66eba0d1a7f078077a26216ac0410a365cc1dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e6afd82baa902ba458203b41944e33f0880bc5bbd1bf30261c2216c79350b6e',1976,'PK','Pakistan','communications',390,'Arabian Sea
{See reference map Vil)
LAND
310,000 sq. mi. (includes Pakistani part of Jammu-
Kashmir); 40% arable, including 24% cultivated; 23%
unsuitable for cultivation; 84% unreported, probably
mostly waste; 3% forested
Land boundaries: 3,650 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing 50 n. mi.; plus right to establish 100 n. mi.
conservation zones beyond territorial sea)
Coastline: 650 mi.','32788f4968432abe6355fc9d1796dcdd3fec4a0ba717661894f12f06719607b0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae775e430bb780ffdf9c20567020fe1529e8ee8ac42e3d4ba4683f54ca8e06a4',1976,'PA','Panama','communications',394,'Caribbean Sea
Pacific Ocean
{See reference map it)
LAND
29,208 sq. mi. (excluding Canal Zone, 553 sq. mi.);
24% agricultural land (9% fallow, 4% cropland, 11%
pasture), 20% exploitable forest, 56% other forests,
urban, and waste
Land boundaries: 390 mi.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
WATER
Limits of territorial waters (claimed): 200 n. mi.
(continental shelf including sovereignty over super-
jacent waters)
Coastline: 1,545 mi.
Railroads: 305 mi.; 48 mi. 5’0” gage, 107 mi. 3’0”
gage; 150 mi. plantation feeder lines
Highways: 4,450 mi.; 1,400 mi. paved, 1,150 mi.
gravel or crushed stone, 1,900 mi. improved and
unimproved earth; Panama Canal Zone 145 mi.; 140
mi. paved; 5 mi. gravel
Inland waterways: 500 mi. navigable by shallow
draft vessels; 51-mile Panama Canal
159
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PANAMA/PAPUA NEW GUINEA
Pipelines: refined products, 60 mi.
Ports: 2 major (Cristobal/Colon/Coco Solo,
Balboa/Panama City), 10 minor
Civil air; 27 major transport aircraft
Airfields: 121 total, 119 usable; 26 with
permanent-surface runways; 3 with runways 8,000-
11,999 ft.; 18 with runways 4,000-7,999 ft.; 2 seaplane
stations
Telecommunications: domestic and international
telecom facilities well developed, including nearly
nationwide radio-relay system; connection into
central American microwave net; communications
satellite ground station; 127,000 telephones; 575,000
radio and 240,000 TV receivers; 80 AM, 30 FM, and
13 TV stations; 1 coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 366,000; 252,000
fit for military service; no conscription
Military budget: for fiscal year ending 31
December 1972, $18 million; about 11% of central
government budget','f22ff942f42eeeacd69f2eeb1c6fb9c8bc94723957358e1dd9f562c48ddc92f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1571c27f51e2dd35a3f8bf4f40748bdc7f442c0dbbafd7b78553714735a31a6',1976,'PG','Papua New Guinea','communications',398,'Pacific Ocean
”
.
an IN BRITISH
INE ‘s. SOLOMONS
Port eS : mae 8
Moresby _ = <
Caral Sea','2791f341cee15843ced606a45f0108778580ea177f1dc37a7302c08788c5818b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d577242c0f6e0027a61569a35d8a71c206c0e9923914484f6e6025449ae3d79',1976,'PY','Paraguay','communications',399,'LAND
157,000 sq. mi.; 2% under crops, 24% meadow and
pasture, 52% forested, 22% urban, waste, and other
Land boundaries: 2,140 mi.
Railroads: 652 mi.; 273 mi. standard gage, 85 mi.
3''3%" gage, 294 mi. various narrow gage (privately
owned)
162
Highways: 9,900 mi.; 400 mi. bituminous treated,
3,100 mi. otherwise improved, 6,400 mi. unimproved
earth
Inland waterways: 1,970 mi.
Ports: 1 major (Asuncion), 9 minor (all river)
Civil air: 7 major transport aircraft
Airfields: 917 total, 822 usable; 1 with permanent-
surface runway; 2 with runways 8,000-11,999 ft., 22
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: local telecom facilities in
Asuncion good, intercity microwave net: 33,000
telephones; 750,000 radio and 60,000 TV receivers; 25
AM, 8 FM, and 1 TV station; COMSAT station under
construction
DEFENSE FORCES
Military manpower: males 15-49, 614,000: 465,000
fit for military service; average number currently
reaching military age (17) annually, 28,000','b7ff600c1802521e93bad1ed054f3533d5a0d98970ce9e8d7728f57becc0eb59','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20a0050fe61ca02bd56e666d216392f8c6660c04f21801993bd0f11b0e7e4966',1976,'PE','Peru','communications',403,'Pacific
(See reference map tit}
LAND
496,000 sq. mi. (other estimates range as low as
482,000 sq. mi.); 2% cropland, 14% meadows and
pastures, 55% forested, 29% urban, waste, other
Land boundaries: 3,810 mi.
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,500 mi.
Railroads: approx. 1,560 mi.; 1,227 mi. 4’8%"
gage; 41 mi. gage less than 3''0"; 282 mi. 3''0" gage; 9
mi. double track
Highways: 31,500 mi.; 3,100 mi. paved, 6,200 mi.
gravel or crushed stone, 9,200 mi. improved earth,
1,300 mi. unimproved earth
Inland waterways: 5,400 mi. of navigable
tributaries of Amazon River system and 130 mi. Lake
Titicaca
Pipelines: crude oil, 200 mi; natural gas and
natural gas liquids, 40 mi.
Ports: 7 major, 20 minor
Civil air: 34 major transport aircraft
Airfields: 306 total, 306 usable; 22 with
permanent-surface runways; 2 with runways over
12,000 ft., 19 with runways 8,000-11,999 ft., 49 with
runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: fairly adequate for most
requirements; new radio-relay system under
163
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
PERU/ PHILIPPINES
construction; communications satellite ground
station; 335,000 telephones; 2.2 million radio and
500,000 TV receivers; 200 AM, 7 FM, and 31 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 3,355,000;
2,273,000 fit for military service; average number
currently reaching military age (20) annually, 150,000
Military budget: a biennial budget for 1 January
1975 through 31 December 1976, $871 million; about
15.2% of central government biennial budget','95a9de29ec857c8dee93ece5c09b81455ed6dc6c7d90a3ee4448b3140e45d04f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b6ec81cf239cc4cf7a1d6f6c691ea75f143977fab355740f00c44d5374553b4',1976,'PL','Poland','communications',407,'LAND
120,600 sq. mi.; 49% arable, 14% other
agricultural, 27% forested, 10% other
Approved For Release 2005/04/22 :
(See reference map IV}
Land boundaries: 1,920 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 305 mi.
Railroads: 16,530 route mi.; 14,450 mi. standard
gage, 2,080 mi. narrow gage; 4,645 mi. double track;
3,225 mi. electrified; government owned (1975)
Highways: 190,095 mi.; 40,390 mi. paved; 39,480
mi. crushed stone, gravel; 110,225 mi. earth
(improved and unimproved) (1974)
Inland waterways: 3,158 mi. navigable streams
and canals (1975)
Pipelines: 2,200 mi. for natural gas; 875 mi. for
crude oil; 200 rhi. for refined products
Freight carried: rail — 499.3 million short ton,
85.6 billion short ton/mi. (1974); highway 1,550.0
million short tons, 18.5 billion short ton/mi. (1974);
waterway—12.8 million short tons, 1.5 billion short
ton/mi. excl. int. transit traffic (1974)
Ports: 4 major (Gdansk, Gdynia, Szczecin,
Swinoujscie), 6 minor (1975)
DEFENSE FORCES
Military budget announced: for fiscal year ending
31 December 1975, 49.9 billion zlotys; about 8.4% of
total budget and 4.3% of est. GNP
wae
Black Sea','d6425368863a536d38ee8bb8cf2fa6d0508254f1d70d7eaf74ed9be92bfedfb2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1acd3dc15a2a47691e5244c44351ab1d1f6585574df13c1d34731fad05d512e',1976,'PT','Portugal','communications',411,'Atlantic
= sgeieonged erent
(See reference mop IV)
LAND
Metropolitan Portugal: 36,400 sq. mi., including
the Azores and Madeira Islands; 48% arable, 6%
meadow and pasture, 31% forested, 15% waste and
urban, inland water, and other
Land boundaries: 750 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 535 mi. (excludes Azores (440 mi.) and
Madeira (140 mi.))
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Railroads: 2,230 mi.; 472 mi. meter gage (3''3%4"),
1,758 mi. broad gage (5''5%g’’):; 265 mi. double track;
268 mi. electrified
Highways: 18,500 mi.; 11,000 mi. bituminous,
bituminous treatment, concrete and stoneblock; 7,200
mi. gravel and crushed stone; 300 mi. improved earth;
plus an additional 10,500 mi. of unimproved earth
roads (motorable tracks)
Inland waterways: 508 mi. navigable; relatively
unimportant to national economy, used by shallow-
draft craft limited to 330-ton cargo capacity
Pipelines: crude oil, 7 mi.
Ports: 6 major, 34 minor
Civil air: 30 major transport aircraft
Airfields (including Azores and Madeira Islands):
61 total, 54 usable; 31 with permanent-surface
runways; 1 with runway over 12,000 ft., 10 with
runways 8,000-11,999 ft., 10 with runways 4,000-
7,999 ft.; 6 seaplane stations
Telecommunications: facilities are generally
adequate; 1.05 million telephones; 1.8 million radio
and 725,000 television receivers: 38 AM, 34 FM, and
40 TV stations; 2 coaxial submarine cables; COMSAT
station
DEFENSE FORCES
Military manpower: males 15-49, 2,079,000;
1,686,000 fit for military service; average number
reaching age (20) annually, about 75,000
Military budget: proposed for fiscal year ending 31
December 1975, $762.2 million; about 83% of central
government budget
168
é
é
RS Ge <a +!" 5 PORTUGUESE
Ss Hii Timor
i
Aratura Sea ,
Indian
Ocean
(See reference map Vill)
LAND
7,000 sq. mi.; 84% forest, 33% grassland, and 33%
cultivated
Land boundaries: 90 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 400 mi.
Railroads: none
Highways: 463 mi.; 293 mi. gravel or crushed
stone, 170 mi. improved and unimproved earth
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 11 total, 10 usable; 1 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 5
with runways 4,000-7,999 ft.
Telecommunications: domestic and international
radio stations used primarily for administrative and
military purposes; 1 low-power AM radiobroadcast
station; unreliable open-wire lines and 58 small
manual switchboards serve 912 telephones; 13,500
radio sets','7e210913e3f016821ab137bf129f17e8cb50e900b58f088cbabfc04f0754fa51','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2ec0e715c9d03f58f92afed0f99bdfc8d41403b7f734b773cde5b3c13e7d7d8',1976,'QA','Qatar','communications',415,'LAND
About 4,000 sq. mi.; negligible amount forested;
mostly desert, waste, or urban
Land boundaries: 35 mi.
“SAUDI ARABIA
(See reference map V}
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 350 mi.
Railroads: none
Highways: 275 mi. bituminous; 225 mi. gravel
surfaced; undetermined mileage of earth tracks
Pipelines: crude oil, 105 mi.; natural gas, 60 mi.
Ports: 1 major (Ad Dawhah), 1 minor
Airfields: 2 total, 1 usable; 1 with permanent-
surface runway over 12,000 ft.
Civil air: 1 major transport aircraft, registered in
the U.S.
Telecommunications: all international telecom
traffic is by tropospheric scatter through Bahrain; fair
domestic facilities; 16,125 telephones; 35,000 radio
and 28,500 TV receivers; 1 AM and 1 TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 41,000;
about 24,000 fit for military service
Supply: mostly from U.K.
Military budget: for fiscal year ending 24 January
1974, $53,680,900; 18% of total budget
REUNION
LAND
970 sq. mi.; two-thirds of island extremely rugged,
consisting of volcanic mountains; 120,000 acres (less
than one-fifta of the land) under cultivation
170
Indian','98e62723cfb4b3a373c89cef973eb36d99416ff2616236129d847165697d0e94','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ec8152eb9488283a10fd0f1490edde544afde0d696d667ef4dbaaefe7b69f23',1976,'ZM','Zambia','communications',419,'eee Indian Ocean
\\\\ SOUTH AFRICA
{See reference map VI}
LAND
151,000 sq. mi.; 40% arable (of which 6%
cultivated); 60% available for extensive cattle
grazing; European alienated lands (farmed by
modern methods) 39%, African 48%, national land
7%, 6% not alienated
Land boundaries: 1,875 mi.
Railroads: 1,697 mi. narrow gage (3’6''''); 26 mi.
double track
Highways: 48,733 mi.; 4,968 mi. paved, 20,415 mi.
crushed stone, gravel, stabilized soil, or improved
earth; 23,350 mi. unimproved earth
Inland waterways: 175 mi. on Lake Kariba
Airfields: 273 total, 272 usable; 8 with permanent-
surface runways; | with runway over 12,000 ft., 1 with
runway 8,000-11,999 ft., 23 with runways 4,000-7,999
ft.
Civil] air: 10 major transport aircraft
Telecommunications: system is one of the best in
Africa; consists of radio-relay links, open-wire lines,
and radiocommunication stations; principal center
Salisbury, secondary center Bulawayo; 160,300
telephones; 225,000 radio and 58,000 TV receivers: 8
AM, no FM and 2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,420,000;
866,000 fit for military service; average number
reaching military age (18) annually, 63,000
Military budget: for fiscal year ending 30 June
1975, $132,310,192; 17.9% of total budget
MADAGASCAR) ~
mozAMBIQUE.
Indian
Ocean.
(See reference map Vi}
LAND
288,000 sq. mi.; 5% under cultivation, 5% arable,
10% grazing, 13% dense forest, 6% marsh, 61%
scattered trees and grassland
Land boundaries: 3,730 mi.
Railroads: 1,219 mi., government owned, all
narrow gage (3’6’’); 8 mi. double track
Highways: 21,375 mi.; 2,145 mi. paved, 4,690 mi.
crushed stone, gravel, or stabilized soil; 14,540 mi.
improved and unimproved earth
Inland waterways: 1,409 mi. including Zambezi
River, Luapula River, Lake Kariba, Lake Bangweulu,
Lake Tanganyika; principal port on Lake Tanganyika
is Mpulungu
Pipelines: 450 mi. refined
Civil air: 9 major transport aircraft
Airfields: 169 total, 169 usable; 11 with
permanent-surface runways; 1 with runway over
12,000 ft., 2 with runways 8,000-11,999 ft., 22 with
runways 4,000-7,999 ft.
Telecommunications: all services being modern-
ized and increased; presently adequate but must be
expanded to permit growth; high-capacity wire and
radio relay connect centers of Kitwe in northern
mining region and Lusaka along axial north-south
route; 59,300 telephones; 100,000 radio and 21,000
TV receivers, 4 AM, 1 FM, and 2 TV stations; 1
satellite ground station
DEFENSE FORCES
Military manpower: males 15-49,
545,000 fit for military service
Military budget: for fiscal year ending 31
December 1972, $70,000,000; 11.6% of total budget
1,140,000,','407c853662ce93bce575771b6a7f6fb55578b9490fdde20d4dfd252dc3d08784','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f9bd75227db507f9c4903da404049c6679a352801d1f140d3ab0919de3c8b3d',1976,'RO','Romania','communications',423,'LAND
91,700 sq. mi.; 44% arable, 19% other agriculture,
27% forested, 10% other
Land boundary: 1,845 mi.
WATER
Limits of territorial waters (claimed): 112 n. mi.
Coastline: 140 mi.
Railroads: 7,464 mi.; 6,442 mi. standard gage,
1,014 mi. narrow gage, 8 mi. broad gage; 569 mi.
electrified, 850 mi. double track; government owned
(1974)
Highways: 48,000 mi.; 7,600 mi. paved; 16,300 mi.
other improved surfaces, 24,100 mi. earth (1974)
Inland waterways: 1,445 mi. (1975)
Pipelines: crude oil, 1,600 mi.; refined products,
888 mi.; natural gas, 3,100 mi.
Freight carried: rail — 939.5 million short tons,
37.4 billion short ton/mi. (1974); highway — 579.8
million short tons, 5.7 billion short ton/mi.
(1974); waterway — 6.4 million short tons, est. 1.4
billion short ton/mi. (excl. int’]. transit traffic) (1974)
173
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ROMANIA/RWANDA
Ports: 4 major (Constanta, Galati, Braila,
Mangalia), 2 minor (1975)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 31 December 1975, 9.7 billion lei; about 4.1%
of total budget
Turkey
a
‘ou Over
Mediterranean Sea
Israeli~
Port Sudan |
Khartoum,
aoundé *
Brazzaville»,
Bi
era
ambique
Walvis Bay |
(S. AT) W.
2 Syria
Se si
VI Africa
fran
Persian
%
Red »
“Mogadiscio
ombasa SEYCHELLES *,
4 (U.K,) rs Z
,» Dar es Salaam th
fomora is.
xTananarive
Madagascar, Mauritius,
Oo
Reunion
(Fr)
eLourenco
‘J Marques
Cape Town}
Names and boundary representation
are not necessarily authoritative
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
V The Middle East
-','2105636b030e119c1267a407a0d33ef658dbf44ef3c1c3d89637cb8194e65320','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f75652f3037c0d40f601130cff194b70c2986765e5d643c0560cfaa4542412f',1976,'RW','Rwanda','communications',427,'{See reference map Vi)
LAND
10,000 sq. mi.; almost all the arable land, about 4
under cultivation, about % pastureland
Land boundaries: 545 mi.','73512bdb8000af5a01b3b859f336230266d4c98c3e8d8e99b0f3e47487bd8dc6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34254bd78057737de3c148604ce6b380b26f08878d9f9768e457894fcfc8a199',1976,'AI','Anguilla','communications',431,'Atlantic Ocean
Sol 2 ANGUILLA
or ®
ST. CHRISTOPHER “e. =
NEVIS" p-
i woah R
F Q
Caribbean Se 4
# a iy
(See reference map My)
LAND
150 sq. mi.; 40% arable, 10% pasture, 17% forest,
33% wasteland and built-on
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.
Railroads: 36 mi., narrow gage (2’6'''') on St. Kitts
for sugar cane
Highways: 180 mi.: 60 mi. paved, 90 mi. otherwise
improved, 30 mi. unimproved earth
Ports: 3 minor (1 on each island)
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 1 with asphalt runway
7,600 ft.
Telecommunications: good interisland VHF radio
connections and international link via Antigua; about
1,800 telephones; 10,000 radio and 1,600 TV
receivers; 3 AM and 5 TV stations
ST. LUCIA
Atlantic Gcean
tot]
{See reference mao H!}
LAND
238 sq. mi.; 50% arable, 3% pasture, 19% forest, 5%
unused but potentially productive, 23% wasteland
and built-on
WATER
Limits of territorial waters (claimed); 3 n. mi.
Coastline: 98 mi.
Railroads: none
Highways: 415 mi.; 175 mi. paved; 240 mi.
otherwise improved
Ports: 1 major (Castries), 1 minor
CIA-RDP79-01051A000800010001-8
A LL A T''C_ONCZTCZ
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ST. LUCIA/ST. VINCENT
Civil air: 2 major transport aircraft
Airfields: 2 airfields with permanent surface
runways; one with a 9,000 foot runway; one with a
5,700 foot runway; 2 seaplane stations
Telecommunications: fully automatic telephone
system with 6,500 telephones; direct radio link with
Martinique; interisland tropospheric links to Barbados
and Antigua; 25,000 radio and 600 TV receivers; 3
AM, and 1 TV station
ST, VINCENT
na tt
A
{See reference mag II}
LAND
150 sq. mi. (including northern Grenadines); 50%
arable, 3% pasture, 44% forest, 3% wasteland and
built-on
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 52 mi.
Railroads: none
Highways: 1,100 mi.; 400 mi. paved; 600 mi.
otherwise improved; 100 mi. unimproved earth
Ports: 1 major, | minor
Civil air: no major transport aircraft
Airfields: 3 total; 2 usable, 1 with asphalt runway
4,800 ft.
Telecommunications: islandwide fully automatic
telephone system with 4,800 instruments, VHF
interisland links to Barbados and the Grenadines;
10,000 radio and 600 TV receivers; 2 AM stations
177
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','6c4f58e518163f6d9d6c5fd8965683009d7323dbdd41f61fa5d24644b62e585f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3b874e951f80a011e567f8357c28d545257210cb1815ca82b20007b3c67e144',1976,'SM','San Marino','communications',435,'fee 7
Mediterranean Sea
{See reference map lV)
LAND
24 sq. mi.: 74% cultivated, 22% meadows and
pastures, 4% built-on
Land boundaries; 21 mi.
Railroads: none
Highways: about 65 mi.
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system
serving 5,000 telephones; no radiobroadcasting or
television facilitics, 4,400 radio and 3,300 TV receivers
(Italian broadcasts)','e3bfc75bc950b58de4b02de659666d4b6663841180a2030e8f2e44fe4112a7dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e890d1d0d4c0f4d7e7ecd66d797e5e0086ba610aba4df3fb0f2c4c6bfcb9b69a',1976,'SN','Senegal','communications',439,'A-
BISSAU
Atlantic
Ocean
{See reference map V1)
LAND
76,000 sq. mi.; 13% forested, 40% agricultural (12%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 1,665 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing 110 n. mi.; fisheries zone beyond territorial
sea)
Coastline: 330 mi.
Railroads: 640 mi. meter gage; 40 mi. double track
Highways: 8,725 mi.; 1,335 mi. bituminous, 996
mi. gravel, 400 mi. improved earth, 6,000 mi.
unimproved earth
18
Inland waterways: 935 mi.
Ports: 1 major (Dakar),.2 minor
Civil air: 5 major transport aircraft
Airfields: 27 total, 27 usable; 11 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 19
with runways 4,000-7,999 ft.; 3 seaplane stations
Telecommunications: relatively advanced for
Africa; 31,500 telephones; 286,000 radio receivers:
1,675 TV receivers; 3 AM, no FM, and 1 TV stations;
3 submarine cables; satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 965,000; 485,000
fit for military service; 52,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 June
1975, $29,817,536; about 9.8% of total budget','2d304334f00622c3a541bc1d98ccb491efff8f844645da71399c682029c4dca3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9eeca62aee1f4e47bc499dc21f457e5441a222d7a5ea963a6ca523598497b521',1976,'SL','Sierra Leone','communications',443,'Atlantic
Qecean
(See reference map Vi)
LAND
27,900 sq. mi.; 65% arable (6% of total land area
under cultivation), 27% pasture, 4% swampland, 4%
forested ,
Land boundaries: 580 mi.
183
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline:.250 mi.
Railroads: about 60 mi. narrow gage (3''6")
privately owned mineral line operated by the Sierra
Leone Development Company
Highways: 5,130 mi.; 550 mi. bituminous
(including some bituminous treatment), 1,470 mi.
laterite (some gravel), and 3,110 mi. earth
Inland waterways: 500 mi.; 372 mi. navigable
year-round
Ports: 1 major (Freetown), 2 minor
Civil air: no major transport aircraft
Airfields: 15 total, 15 usable; 5 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 4
with runways 4,000-7,999 ft.: 1 seaplane station
Telecommunications: telephone and telegraph are
adequate; 7,850 telephones; 61,000 radio and 6,000
TV receivers; 1 AM, no FM, and 1 TV stations; 3
submarine cables
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SIERRA LEONE/SINGAPORE
DEFENSE FORCES
Military manpower: males 15-49, 640,000; 307,000
fit for military service; no conscription
Military budget: for year ending 30 June 1975,
$9,548,203; 6.97% of total budget','ea03b5c2cc1581998fa535d78ab899dfe9f8fcf033026e6f060495690e87a6a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e316ae787f9fb4123622563888477982c1419d6f08e762e5afc38493871ef8f',1976,'SG','Singapore','communications',447,'{Sea reference map Vil)
LAND
225 sq. mi.; 31% built up area, roads, railroads, and
airfields, 22% agricultural, 47% other
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 120 mi.
Organized labor: 24% of labor force
Railroads: 24 mi. of meter gage
Highways: 1,340 mi. (1974); 1,035 mi. paved, 305
mi. crushed stone or improved earth
Ports: 3 major
Civil air: 19 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 2
with runways 4,000-7,999 ft.
Telecommunications; adequate domestic facilities:
good international service; good radio and television
broadcast coverage; 350,159 telephones; 311,409
radio and 240,314 TV sets; 2 AM, 5 FM, and 2 TV
stations, new seacom submarine cable extends to
Hong Kong via Sabah, Malaysia; 1 ground satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 596,000; 424,000
fit for military service
Military budget: for fiscal year ending 31 March
1976, $335 million; about 18% of total budget','cc01a95fc586991cdc095a183f104780c4f8506e09eb577272ee4b9fe7550312','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ccccb85fd65bebe1dd2d97ca0df68664f872d9e99af227f86ed24f6dbddeb6d',1976,'SO','Somalia','communications',451,'ve bah
legadiscio
Indian
Ocean
{See referance map V1)
LAND
246,000 sq. mi., 13% arable (0.3% cultivated), 32%
grazing, 14% scrub and forest, 41% mainly desert,
urban, or other
Land boundaries: 1,406 mi.
186
WATER
Limits of territorial waters (claimed): 200 n. mi.
Coastline: 1,880 mi.
Railroads: none
Highways: 8,414 mi.; 582 mi. paved; 478 mi.
crushed stone, gravel, or stabilized soil; 7,354 mi.
improved or unimproved earth
Inland waterways: Fiume Giuba navigable 345 mi.
from May to mid-June and August to late November
Ports: 3 major (Mogadiscio, Berbera, Chisiamaio)
Civil air: 5 major transport aircraft
Airfields: 64 total, 44 usable; 3 with permanent-
surface runways; 1 with runway over 12,000 ft.; 4 with
runways 8,000-11,999 ft., 15 with runways 4,000-
7,999 ft.
Telecommunications: telephone poor, telegraph
fair; 4,740 telephones; 67,500 radio receivers; 2 AM,
no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 754,000; 416,000
fit for military service; no conscription
Military budget: for fiscal year ending 31
December 1972, 19,400,000; 25.3% of total budget
machinery, construction','1123495095fd958a9ea7a53a5919433c3af26c306e89b33a517f7a63600ff63f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f61969ae5057e151d1aed7379367205f146874bcccd15a64bb3403f59592622',1976,'ZA','South Africa','communications',455,'AFRICA
{See reference map VI}
LAND
472,000 sq. mi. (includes enclave of Walvis Bay,
434 sq. mi.); 12% cultivable, 2% forested, 86% desert,
waste, or urban
Land boundaries: 1,270 mi.
WATER
Limits of territorial waters (claimed); 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 1,790 mi.
Railroads: 12,318 mi.; 11,879 mi. 3/6" gage of
which 1,323 mi. are multiple track; 2,726 mi.
electrified; 440 mi. 2’0" gage single track
18
Highways: 220,000 mi.; 31,700 mi. paved, 42,650
mi. crushed stone or gravel, 145,650 mi. improved and
unimproved earth
Pipelines: crude oil, 520 mi.; refined products, 450
mi.; natural gas, 200 mi.
Ports: 5 major, 6 minor
Civil air: 64 major transport aircraft
Airfields: 662 total, 531 usable; 57 with
permanent-surface runways; 1 with runway over
12,000 ft., 8 with runways 8,000-11,999 ft., 130 with
runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: the system is the best
developed, most modern, and highest capacity in
Africa and consists of carrier-equipped open-wire
lines, coaxial cables, radio-relay links, and
radiocommunication stations; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg,
Port Elizabeth, and Pretoria; 1.8 million telephones;
2.5 million radio receivers; 13 AM, 60 FM, and no TV
stations; 4 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 5,617,000:
3,437,000 fit for military service; obligation for service
in Citizen Force begins at 18; volunteers for service in
permanent force must be 17
Military budget: for year ending 31 March 1976,
$1,393,502,866; 18% of total budget
SOUTH-WEST AFRICA
Atlantic
Ocean
SOUTH-WEST
Windhoek
+ *
AFRICA
Indian
Ocean
(See reference map Vij
LAND
318,000 sq. mi.; mostly desert except for interior
plateau and area along northern border
Land boundaries: 2,360 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SOUTH-WEST AFRICA
Coastline: 925 mi.
Railroads: 1,454 mi., all 3''6" gage, single track
Highways: 21,000 mi; 2,344 mi. bituminous
treated, 220 mi. gravel and 18,436 mi. earth road and
tracks
Ports: 1 major (Walvis Bay), 1 minor
Civil air: 5 major transport aircraft (registered in
South Africa)
Airfields: 114 total, 93 usable; 11 with permanent-
surface runways; 1 with runway over 12,000 ft.; 3 with
runways 8,000-11,999 ft., 41 with runways 4,000-
7,999 ft.
Telecommunications: system is a meager combina-
tion of open-wire lines, a single short radio-relay link,
and scattered radiocommunication stations; Wind-
hoek is the center; 40,450 telephones; unknown
number of radio receivers; no AM, 1 FM, and no TV
stations
189
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SOUTH-WEST AFRICA/SPAIN
DEFENSE
Military manpower: males 15-49, about 195,000;
about 116,000 fit for military service
Defense is responsibility of Republic of South Africa
Atlantic
CANARY
ISLANDS |
Fyot
(See referance map {V)
LAND
195,000 sq. mi., including Canary (2,900 sq. mi.)
and Balearic Islands (1,940 sq. mi.); 41% arable and
land under permanent crops, 27% meadow and
pasture, 22% forest, 10% urban or other
Land boundaries: 1,180 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 3,085 mi. (includes Balearic Islands, 420
mi., and Canary Islands, 720 mi.)','6b145bba696c20164b058a5c7750fd8a562d81e0941edf7c23aa45d46ba53967','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a46c0af3a23ac6be765afdf30003436e17a76d230bc83356454a7010cde07cd6',1976,'ES','Spain','communications',461,'Railroads: 10,203 mi.; 8,324 mi. (5''6" gage), 1,879
mi. other gages (4’8 4%" to 1''118%''"); 1,310 mi., double
track; 2,612 mi. electrified; all government-owned
except 627 mi. privately-owned
Highways: 86,600 mi.; national — 35,175 mi.
bituminous treatment, 9,400 mi. crushed stone, 4,225
mi. bituminous, stone block and concrete; provincial -
18,200 mi. bituminous treatment, 18,400 crushed
stone, 1,200 mi. bituminous, concrete, and stone block
Inland waterways: about 650 mi.; of minor
importance as transport arteries and contribute little
to economy
Pipelines: crude oil, 240 mi.; refined products, 609
mi.; natural gas, 100 mi.
Ports: 23 major, 150 minor
Civil air: 196 major transport aircraft (including 3
registered but leased from a foreign country)
Airfields (including Balearic and Canary
Islands): 112 total, 84 usable; 47 with permanent-
surface runways; 4 with runways over 12,000 ft., 17
with runways 8,000-11,999 ft., 35 with runways 4,000-
7,999 ft.; 5 seaplane stations
Telecommunications: generally adequate, modern
facilities; 7.39 million telephones; 8.5 million radio
and 6.3 million television receivers; 170 AM, 231 FM,
and 694 TV stations; 7 coaxial submarine cables; 4
communication satellite ground stations
191
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SPAIN/SPANISH SAHARA/SRI LANKA
DEFENSE FORCES
Military manpower: males 15-49, 8,620,000;
* 6,631,000 fit for military service; 280,000 reach
military age (20) annually
Military budget: for fiscal year ending 3]
December 1975, $2,884 million; about 25% of central
government budget
SPANISH SAHARA
Atlantic Ocean
CANARY
ISLANDS |,
5 2
i
SPANISH
SAHARA
(See reference map VI)
LAND
103,000 sq. mi., nearly all desert
Land boundaries: 1,296 mi.
WATER
Limits of territorial waters (claimed); 6 n. mi.
(fishing, 12 n. mi.)
Coastline: 690 mi.
Railroads: none
Highways: 3,790 mi.; 305 bituminous treated,
3,485 mi. unimproved earth roads and tracks
Ports: 2 major (El Aaiun, Villa Cisneros), 2 minor
Civil air: no major transport aircraft
Airfields: 17 total, 17 usable: 3 with permanent-
surface runways; 5 with runways 4,000-7,999 ft.
Telecommunications: telephone and telegraph
poor; 600 telephones; 16,000 radio receivers: 1 AM,
no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 16,000; 8,000 fit
for military service','4c437c016e69214ae3cfd2acd7efffd94a78fc76db19341795a04f0f29009cab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ef44e6158bf0e67011800ec20caeeeb565bee6f1beeb9fff4c9a617a427b14b',1976,'LK','Sri Lanka','communications',463,'(formerly Ceylon)
LAND
25,300 sq. mi.; 25% cultivated; 44% forested; 31%
waste, urban, and other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Arabian
Sea
of Bengal {
SRI
io LANKA
ColamboX
/ndian Ocean
(See reference map Vil)
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi. plus pearling in the Gulf of
Mannar, and right to establish 100 n. mi. conservation
zone)
Coastline: 835 mi.
Railroads: 938 mi.; 851 mi. 5’6” gage, 87 mi. 2''6”
gage; 63 mi. double track; no electrification;
government owned
Highways: 36,900 mi. (1974); 15,200 mi. paved
(mostly bituminous treated), 15,260 mi. crushed stone
or gravel, 9,140 mi. improved earth or unimproved
earth; in addition several thousand mi. of tracks,
mostly unmotorable
Inland waterways: 270 mi.; navigable by shallow-
draft craft
Ports: 3 major, 9 minor
Civil air: 5 major transport (including 1 leased)
Airfields: 14 total, 10 usable; 10 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 6
with runways 4,000-7,999 ft.
Telecommunications: an inadequate telephone
and a less extensive but more efficient telegraph
system serves most areas, with greatest concentration
around Colombo and Kandy; all areas are served by
radio and/or wire broadcast; excellent international
service; 67,753 (est. ) telephones; 525,000 radio sets, no
TV sets; 8 AM stations, 2 FM, and no TV stations;
submarine cables extend to India, Malaysia, Seychelle
Islands, and Aden; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,233,000;
2,426,000 fit for military service; 153,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
December 1975, $39 million, 8.6% of total budget','a11df7fc547d1497bbe27be9a9b9268462c63c7464462f6188b8a7e8fc44ec19','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08a0066bcacb171797b6390d6462a1c2104165c4346713f8c7f788ba878d5b56',1976,'SD','Sudan','communications',467,'LAND
967,000 sq. mi.; 87% arable (3% cultivated), 15%
grazing, 33% desert, waste, or urban, 15% forest
Land boundaries: 4,850 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(plus 6 n. mi. “necessary supervision zone’)
Coastline: 530 mi.
I
Khartoum ,
{See reference map VI}
Railroads: 3,398 mi.; 2,953 mi. 3''6" gage, 445 mi.
2'' gage plantation line
Highways: 6,550 mi.; 190 mi. bituminous-treated,
680 mi. crushed stone or gravel, and 5,680 mi.
improved and unimproved earth roads; in addition,
there are an undetermined number of tracks
Inland waterways: 3,300 mi. navigable
Ports: 1 major (Port Sudan), 7 minor
Civil air: 7 major transport aircraft
Airfields: 74 total, 66 usable; 6 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 28
with runways 4,000-7,999 ft.
Telecommunications: large system by African
standards, but still barely adequate for size of country;
consists of open-wire lines, radio-relay links,
multiconductor cables, radiocommunication stations
and a_ tropospheric-scatter link; principal center
Khartoum, secondary centers Al Fashir and Port
Sudan; 50,950 telephones; 650,000 radio and 100,000
TV receivers; 2 AM, no FM, and 1 TV stations; 5
submarine cables; satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 3,982,000;
2,364,000 fit for military service; average number
reaching military age (18) annually, 170,000
Military budget: for fiscal year ending 30 June
1973, $113.5 million; 20.8% of total budget
SURINAM
2
Caribbean = ;
Sea Atlantic
(Seo reference map ii}
LAND
55,100 sq. mi; negligible amount of arable land,
meadows and pastures, 76% forest, 8% unused but
potentially productive, 16% built-on area, wasteland,
and other
Land boundaries: 970 mi.
195
-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001
January 1976
SURINAM
WATER
Limits of territorial waters (claimed): 3 n. mi.
Coastline: 240 mi.
Railroads: 104 mi.; 54 mi. 3''3%"" gage (government
owned) and 50 mi. narrow gage (industrial lines); all
single track
Highways: 1,550 mi.: 300 mi. paved, 130 mi.
gravel, 370 mi. improved earth, 750 mi. unimproved
earth
Inland waterways: 2,850 mi.; most important
means of transport; oceangoing vessels with drafts
ranging from 14 to 23 ft. can navigate many of the
Principal waterways while native canoes navigate
upper reaches
Ports: 1 major (Paramaribo), 6 minor
Civil air: 1 major transport aircraft
Airfields: 30 total, 29 usable; 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 4
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: international facilities good;
domestic radio-relay system; 13,100 telephones;
110,000 radio and 35,000 TV receivers, 5 AM, 1 FM,
and 8 TV stations
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SURINAM/SWAZILAND
DEFENSE FORCES
Military manpower: males 15-49, 98,000; 54,000
fit for military service
SWAZILAND
{See reference map VI)
LAND
6,700 sq. mi.; most of area suitable for crops or
pasturcland
Land boundaries: 270 mi.
Railroads: 139 mi., 3''6” guage, single track
Highways: 2,100 mi.; 150 mi. paved; 850 mi.
crushed stone, gravel, or stabilized soil: 1,100 mi.
improved or unimproved earth
Civil air: 8 major transport aircraft
Airfields: 33 total, 28 usable: } with runway 4,000-
7,999 ft.
Telecommunications: the system consists of a few
open-wire lines and low-powered radiocommunica-
tion stations; Mbabane is the center: 5,900
telephones; 52,500 radio receivers; 1 AM, no FM or
TV stations
DEFENSE FORCES
Military manpower: males 15-49, 109,000; 64,000
fit for military service','0da1f0c8eccd294c92c08229722173f25b61da72b6f925480449b63a81df7827','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8f09ba123832076120b78941cfadca8f800496ed336dd1ecbc7c58361f9ef49',1976,'SE','Sweden','communications',471,'(See alerene wna WV}
LAND
173,000 sq. mi.; 8% arable, 1% meadows and
pastures, 55% forested, 36% other
Land boundaries: 1,365 mi.
WATER
Limits of territorial waters (claimed): 4 n. mi.
(fishing, 12 n. mi.)
Coastline: 2,000 mi.
Railroads: 7,451 mi; Swedish State Railways
(SJ) — 6,946 mi. standard gage (4''8 %"’). 113 mi. nar-
row gage (3''6" and 2''11''), 4,324 mi. electrified, 715
mi. double tracked; 294 mi. standard gage (48 o''"),
“98 mi. narrow gage (2117), 284 mi. electrified
: are privately owned and operated
Highways: 60,945 mi.; 44,550 mi. are crushed
stone, gravel, or improved earth; and 16,395 mi. are
bitumen, concrete, stone block, or cobblestone
Inland waterways: 1,275 mi. navigable for small
steamers and barges
Ports: 17 major, and 30 significant minor
Civil air: 6] major transports
Airfields: 250 total, 224 usable; 128 with
permanent-surface runways; 6 with runways 8,000-
11,999 ft., 84 with runways 4,000-7,999 ft.
Telecommunications: excellent domestic and
international facilities: 5.21 million telephones; 9
AM, 91 FM, and 233 TV stations; 5 million radio and
9.88 million TV receivers; 10 submarine cables,
including 4 coaxial, COMSAT ground station
DEFENSE FORCES
Military manpower: males 15-49, 1,885,000,
1,679,000 fit for military service; 57,000 reach military
age (19) annually
Military budget: for fiscal year ending 30 June
1976, $2.48 billion; about 11% of central government
budget','50e209602b7bd2295aec88e59c31133fb612a3e7d31cafffc117fe88eda9130a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec105dfd7f4d53f843644a6b2e4bc408d52546d4c533d37ed1ce48fac7c65033',1976,'TH','Thailand','communications',478,'of Bengal
/
‘See reference map Vil}
LAND
198,000 sq. mi.; 24% in farms, 56% forested, 20%
other
Land boundaries: 3,025 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 2,000 mi.
Railroads: 2,382 mi. meter gage; 60 mi. double
track
Highways: 17,900 mi. (1974); 9,180 mi. paved,
2,940 mi. crushed stone or gravel, 5,780 mi. earth and
laterite
Inland waterways: 2,485 mi. principal waterways;
2,300 mi. with navigable depths of 3 ft. or more
throughout the year; numerous minor waterways
navigable by shallow-draft native craft
Ports: 2 major, 16 minor
Civil air: 21 major transport aircraft
Airfields: 164 total, 163 usable; 55 with
permanent-surface runways; 10 with runways 8,000-
11,999 ft., 27 with runways 4,000-7,999 ft.
DEFENSE FORCES
Military manpower: males 15-49, 10,193,000;
6,205,000 fit for military service, about 435,000 reach
military age (18) annually
Military budget: for fiscal year ending 30
September 1975, $411 million; 17% of central
government budget
(Sea reference map Vit}
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 50 n. mi.)
Coastline: 1,650 mi.
Railroads: 800 mi. meter gauge, single track; 400
mi. serviceable and 175 mi. undergoing reconstruc-
tion; remainder out of service or abandoned
Highways: 12,100 mi.; 2,500 mi. bituminous, 4,700
mi. gravel or improved earth, 4,900 mi. unimproved
earth
Inland waterways: about 6,800 mi. navigable;
more than 1,400 mi. navigable at all times by vessels
up to 6 ft. draft
Ports: 6 major, 20 minor
Airfields: 189 total, 153 usable; 62 with
permanent-surface runways, 8 with runways 8,000-
11,999 ft., 18 with runways 4,000-7,999 ft.; 2 seaplane
stations
DEFENSE FORCES
Military manpower: males 15-49, 4,720,000;
3,000,000 fit for military service; 191,000 reach
military age (18) annually','31f902a11a72606adfa3f86a94781dd8c2313e30fcbab4aa3dbba6afa1b84102','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('840003dfd694e6780c706936c3bc18932ccc12141d0b3c6f2ee61474d93ace28',1976,'TG','Togo','communications',482,'Gulf of Guinea
(See reference map Vi}
LAND
22,000 sq. mi; nearly one-half is arable, under 15%
cultivated
Land boundaries: 1,023 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 35 mi.
Railroads: 275 mi, meter 8age, single track
Highways; approx. 4,475 mi.; 415 mi. paved, 120
mi. gravel, 730 mi. improved earth, 3,210 mi.
unimproved
Inland waterways: section of Mono River and
about 30 mi. of coastal lagoons and tidal creeks
Ports: 1 major (Lome), 1 minor
Civil air: 2 major transport aircraft
Airfields: 1] total, 11 usable; 1 with permanent-
surface runway 4,000-7,999 ft.
Telecommunications: Togo has poor system based
on skeletal network of Open-wire lines supplemented
by a few radiocommunication stations; only center is
Lome; 6,100 telephones; 50,000 radio receivers; |
AM, no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 474,000; 244,000
fit for military service; no conscription
Supply: most military materiel obtained from','9101cfd63e625da9ac0c96f3495ec3b3f2f2dd7991062431728bd2b8150e9d03','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c28c7b63070f927307e4871876c527a740e8ad8a5458c8837f4fabc7c312baf9',1976,'TO','Tonga','communications',486,'LAND
385 sq. mi. (150 islands): 77% arable, 3% pasture,
13% forest, 3% inland water, 4% other
206
‘ “2s TONGA
NEWS *Nukifalots
CALEDONIA
Pacific Ocean
|
(See reference map Vil)
WATER
Limits of territorial waters (claimed); 12 n. mi.
Coastline: 260 mi. (est.)
Railroads: none
Highways: 155 mi. (1974); 110 mi. rolled stone; 45
mi. coral base
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 4 total; 4 usable, with grass runways
7,000 ft.; 1 seaplane station; adequate overseas, but
inadequate domestic service
Telecommunications: 1,090 telephones; 10,000
radio sets; no TV sets; | AM station
1 Tonga dol-','ba6e8c0406ca68ed4ede058169e99b34e7c518dcf6d88f051c10eeb43d9bdc30','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5eb5f475a6d05230ca2ecd8bddf367aad4cfde942032fabfc21d554a36fe1e6',1976,'TT','Trinidad and Tobago','communications',490,'Atlantic Ocean
()
Caribbean Sea %.
7
Port
f
vain TRINIDAD
28 AND TOBAGO
{See reference imap I}
LAND
1,980 sq. mi.; 41.9% in farms (of which 25.7%
cropped or fallow, 1.5% pasture, 10.6% forests, 4.1%
unused or built-on), 58.1% outside of farms, including
grassland, forest, built-up area, and wasteland
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 225 mi.
Railroads: none
Highways: 4,200 mi.; 2,500 mi. paved, 1,700 mi.
gravel or otherwise improved
petroleum, tourism, food
Pipelines: crude oil, 270 mi.; refined products, 12
mi.; natural gas, 180 mi.
Ports: 3 major (Port of Spain, Chaguaramar Bay,
Point Tembladora), 6 minor
Civil air: 15 major transport aircraft
208
Airfields: 8 total, 6 usable: 4 with permanent-
surface runways; | with runway 8,000-11,999 ft., 2
with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international
service via tropospheric scatter links to Barbados and
Guyana; good local service; satellite ground station;
68,000 telephones; 300,000 radio and 93,000 TV
receivers; 2 AM, 2 FM, and 3 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 252,000; 178,000
fit for military service
Supply: mostly from U.K.','2e6f205bbed0c17c2711c6b169aca7e1c9834ef4bfc99c8adb981afd28d51264','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('907101de17b798e9f1955ec0ec5230a86aedafc30c6ebe97a2de35289cd426d8',1976,'TN','Tunisia','communications',494,'(See reference map Vi)
LAND
63,400 sq. mi.; 28% arable land and tree crops, 23%
range and esparto grass, 6% forest, 43% desert, waste
or urban
Land boundaries: 875 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(fishing, 12 n. mi. exclusive fisheries zone follows the
50-meter isobath for part of the coast, maximum 65 n.
mi.)
Coastline: 710 mi. (includes offshore islands)
Railroads: 1,273 mi; 309 mi. standard gage
(4''8%''''), double 964 mi. meter gage (3''3%"")
Highways: 14,800 mi.; 4,770 mi. mostly
bituminous treatment, 4,835 mi. gravel and crushed
stone, 1,125 mi. improved earth, 4,070 mi.
unimproved earth
Pipelines: crude oil, 495 mi.; refined products, 6
mi.; natural gas, 45 mi.
Ports: 4 major, 8 minor
Civil air; 9 major transport aircraft
Airfields: 35 total, 30 usable; 11 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 17
with runways 4,000-7,999 ft.; 1 seaplane station
Telecommunications: the system is above the
African average in amount and capacity of facilities
which consist of open-wire lines with multiconductor
cable or radio relay on trunk routes; key centers are
Safaqis, Susah, Bizerte, and Tunis; 96,300 telephones;
401,000 radio and 92,500 TV receivers, 3 AM, 3 FM,
and 7 TV stations; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 1,478,000;
815,000 fit for military service; about 64,000 reach
military age (20) annually
Military budget: for fiscal year ending 31
December 1975, $70,100,000; 5.2% of total budget
0.436 dinar=US$1
TURKEY
LAND
296,000 sq. mi.; 35% cropland, 25% meadows and
pastures, 23% forested, 17% other
Land boundaries: 1,600 mi.
WATER
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi. (fishing, 12 n.
mi.)
Coastline: 4,475 mi.
Railroads: 5,075 mi.; 5,055 mi. 4''84"" gage, 89 mi.
double track: 45 mi. electrified; 20 mi. 2’514" gage
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TURKEY/UGANDA
Highways: 37,282 mi.; 13,049 mi. bituminous,
17,398 mi. gravel or crushed stone, 1,553 mi.
improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oil, 402 mi.; refined products,
1,277 mi.
Ports: 10 major, 35 minor
Civil air; 22 major transport aircraft
Airfields: 119 total, 101 usable; 54 with
permanent-surface runways; 3 with runways over
12,000 ft., 20 with runways 8,000-11,999 ft., 24 with
runways 4,000-7,999 ft.
Telecommunications: excellent international and
fair domestic telecommunication services; 913,000
telephones; 4.5 million radio and 400,000 TV
receivers; 42 AM, 4 FM, and 32 TV stations
DEFENSE FORCES —
Military manpower: males 15-49, 10,144,000;
5,978,000 fit for military service; about 420,000 reach
military age (20) annually
Military budget: proposed for fiscal year ending 28
February 1976, $1,637 million; about 21% of
proposed central government budget','c05499a203983457949c11eeefe89843864431a7e6d4388504e8cce360a57d5c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddf48bbc5f99f8c2764a31dcce8e1f2d59636eeca4812105f7e8a7783aa09ba6',1976,'UG','Uganda','communications',498,'Indian
Ocean
‘
{Sea reference map V1)
LAND
91,000 sq. mi.; 21% inland water and swamp,
including territorial waters of Lake Victoria, about
21% cultivated, 13% national parks, forest, and game
reserves, 45% forest, woodland, and grassland
Land boundaries: 1,665 mi.
Railroads: 760 mi.; all meter gage, single track
Highways: 31,330 mi. total: 1,200 mi. bituminous
surface treatment; 10,130 mi. crushed stone, gravel,
laterite, and improved earth; 20,000 mi. unimproved
earth roads and tracks
Inland waterways: Lake Victoria, Lake Albert,
Lake Kyoga, Lake George, and Lake Edward (6,010
mi.); Kagera River and Victoria Nile (380 mi.)
Civil air: 7 major transport aircraft
Airfields: 54 total, 50 usable; 5 with permanent-
surface runways; 1 with runway over 12,000 ft., 3 with
runways 8,000-11,999 ft., 12 with runways 4,000-
7,999 ft.
Telecommunications: telephone and telegraph
services fair, intercity connections based on 3 or 12
channel carrier systems; 34,200 telephones; 275,000
radio and 68,000 TV receivers: 2 AM, no FM, and 6
TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 2,599,000;
about 1,391,000 fit for military service
Military budget: for fiscal year ending 30 June
1972, $42.7 million; 16.6% of total budget
U.S.S.R.
LAND
8,600,000 sq. mi.; 9.8% cultivated, 37.1% forest
and brush, 2.6% urban, industrial, and transportation,
16.8% pasture and natural hay land, 34.2% desert,
swamp, or waste
Land boundaries: 12,595 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 29,000 mi. (incl. Sakhalin)
Railroads: 91,263 mi.; 90,059 mi. broad gage,
1,204 mi, narrow gage; 68,064 mi. broad gage single
track; 21,995 mi. electrified; does not include
industrial lines (1974)
Highways: 901,763 mi.; 182,129 mi. paved,
213,940 mi. gravel, crushed stone, 505,667 mi.
improved or unimproved earth (1974)
Approved For Release 2005/04/22
Inland waterways: 90,000 mi. navigable, exclusive
of Caspian Sea (1975)
Pipelines: crude oil, 30,000 mi.; refined products,
6,400 mi.; natural gas, 56,000 mi.
Ports: 63 major (most important: Leningrad,
Murmansk, Odessa, Novorossiysk, Ilichevsk, Vladivo-
stok, Nakhodka, Arkhangel’sk, Riga, Tallinn,
Kaliningrad, Liepaja, Ventspils, Nikolayev, Sevas-
topol); 116 selected minor (1975)
Freight carried: rail — 3,834.9 million short tons,
2,121.1 billion short ton/mi. (1978); highways — 21.1
billion short tons, 213.6 billion short ton/mi. (1974);
waterway — 497.2 million short tons, 144.2 billion
short ton/mi. (1974)','6def2322f7a9db367d26e71ebadc564050efda4df917faed33a758adfbcbed16','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('873e7b5e809fbe85294bff7b961e8c8987089d2e18c5196f98c2a01e273f531c',1976,'GB','United Kingdom','communications',505,'UNITED
it KINGDOM
*
Atlantic
Ocean
(See reference map IV)
LAND
94,200 sq. mi.: 30% arable, 50% meadow and
pasture, 12% waste or urban, 7% forested, 1% inland
water
Land boundaries: 224 mi.
WATER
Limits of territorial waters (claimed): 3 n. mi.
(fishing, 12 n. mi.)
Coastline: 7,725 mi.
Railroads: Great Britain—11,400 mi.; 13,325 mi.
standard gage (4''8%4""); 115 mi. narrow gage (various
widths); 2,365 mi. electrified; 7,090 mi. double track,
1,470 mi. multiple track; Northern Ireland — 203 mi.
5/3" gage; 118 mi. double track
Highways: approx. 210,000 mi. and 14,000 route
mi. in Northern Ireland
Inland waterways: 1,100 mi. of commercial routes
Pipelines: crude oil, 580 mi., almost all
insignificant; refined products, 1,807 mi., natural gas
1,100 mi.
Ports: 23 major, 350 minor
Civil air: 520 major transport aircraft
Telecommunications: modern, efficient domestic
and international system; 21.3 million telephones;
41.7 million radio and 18.5 million TV receivers;
excellent countrywide AM, FM, and TV service; 88
215
0800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00
January 1976
UNITED KINGDOM/UPPER VOLTA
AM, 114 FM and 3865 TV Stations; 44 submarine
cables, 4] coaxial; 3 earth satellite stations
DEFENSE FORCES
Military manpower; males 15-49, 12,649,000;
10,720,000 fit for military service; no conscription;
432,000 reach military age (18) annually
Military budget: Proposed for fiscal year ending 3]
March 1976, $10.7 billion; about 16.5% of central
government budget
UPPER VOLTA
Atlantic
Ocean
se
(See reference map Vi}
LAND
106,000 sq. mi.- 50% pastureland, 21% fallow,
10% cultivated, 9% forest and scrub, 10% waste
and other uses
Land boundaries; 2,055 mi.
Railroads: 728 mi., 320 mi. meter gage, single
track; Ouagadougou to Abidjan, Ivory Coast line
Highways: 10,380 mi.; 325 mi. paved, 3,425 mi.
improved, 6,630 mi. unimproved
Civil air: no major transport aircraft
Airfields: 54 total, 53 usable; 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 3
with runways 4,000-7,999 ft.
Telecommunications: all services generally poor;
1,800 telephones; 100,000 radio and 6,000 TV
receivers; 2 AM, no FM, and | TV station
DEFENSE FORCES
Military manpower: males 15-49, 1,381,000;
692,000 fit for military service; no conscription
Supply: dependent on France
Military budget: for fiscal year ending 31
December 1975, $8,383,594; 11.3% of total budget','96e31a78c1fa4b611e3d8d434d7974bcae46765fe0db2b30ffea4f7b631a7802','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e75e063d30990c994640ca2390738bcf9c04741ed78a9d9aab614ee13a6811e',1976,'UY','Uruguay','communications',509,'Atlantic
Ocean
Montevideo
(See reference map {V)
LAND
72,200 sq. mi.; 84% agricultural land (73% pasture,
11% cropland) 16% forest, urban, waste and other
Land boundaries: 840 mi.
WATER
Limits of territorial waters (claimed): 200 n. mi.
(fishing 12 n. mi.)
Coastline: 410 mi.
Railroads: 1,870 mi., all standard gage and
government owned
Highways: 32,200 mi.; 3,700 mi. paved, 4,600 mi.
otherwise surfaced, 9,600 mi. improved earth, 14,300
mi. earth tracks
Inland waterways: 1,070 mi.; used by coastal and
shallow-draft river craft
Freight carried: highways 80% of total cargo
traffic, rail 15%, waterways 5%
Ports: 4 major (Montevideo, Colonia, Fray Bentos,
Paysandu), 6 minor
218
Civil air: 16 major transport aircraft
Airfields: 94 total, 79 usable; 7 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 9
with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: most modern facilities
concentrated in Montevideo; 257,500 telephones; 1.5
million radio and 350,000 TV receivers; 75 AM, 3
FM, and 17 TV 0 stations; 2 submarine cables;
COMSAT station planned
DEFENSE FORCES
Military manpower: males 15-49, 738,000; 594,000
fit for military service; no conscription
Military budget: proposed for fiscal year ending 31
December 1975, $82.2 million; 15.6% of central
government budget
VATICAN CITY
Tyrrhenian
Mediterranean
Sea
(See reference map IV)
LAND
0.169 sq. mi.
Land boundaries: 2 mi.
Railroads: none
Highways: none (city streets)
Civil air; no major transport aircraft
Airfields: none
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Telecommunications: 1 AM and 1 FM radio-
broadcasting station; 2,000-line automatic telephone
exchange
DEFENSE FORCES
Defense is responsibility of Italy
VENEZUELA
Atlantic
{See reference map uty
LAND
352,000 sq. mi.; 4% cropland, 18% pasture, 21%
forest, 57% urban, waste, and other
Land boundaries: 2,598 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 1,740 mi.
Railroads: 233 mi. 4''814"" gage; all single track;
107 mi. government owned, 126 mi. privately owned
Highways: 40,000 mi.. 12,000 mi. paved, 11,000
mi. gravel, 6,000 mi. improved earth, 11,000
mi. unimproved (including trails)
Inland waterways: 4,450 mi.; Orinoco River and
Lake Maracaibo accept oceangoing vessels
Pipelines: crude oil, 3,800 mi.: refined products,
250 mi.; natural gas, 1,550 mi.
Ports: 6 major, 17 minor
Civil air: 63 major transport aircraft
Airfields: 29] total, 260 usable; 98 with
permanent-surface runways; 8 with runways 8,000-
11,999 ft., 75 with runways 4,000-7,999 ft.: 2 seaplane
stations
Telecommunications: modern expanding telecom
system; satellite ground station; 549,000 telephones;
3.2 million radio and 1.3 million TV receivers; 157
AM, 50 FM, and 43 Ty stations: 3 submarine cables,
including 1 coaxial
DEFENSE FORCES
Military manpower: males
1,810,000 fit for military service:
military age (18) annually
15-49, 2,568,000;
126,000 reach
VIETNAM, NORTH
LAND
61,300 sq. mi.; 14% cultivated, 50% forested, 36%
urban inland water, and other
Land boundaries: 1,850 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
VIETNAM, NORTH/VIETNAM, SOUTH
f- Thailand.
(See reference map Vit}
Coastline: 490 mi. (excluding islands)
Highways: 13,500 mi., including 900 mi.
bituminous surface-treated, 2,100 mi. gravel, 10,000
mi. improved earth, 500 mi. unimproved earth
Inland waterways: 4,200 mi.; 1,800 mi. navigable
perennially by craft drawing 6 ft.
Ports: 3 major, 8 minor
Airfields: 16 total; 11 with permanent-surface
runways; 2 with runway 8,000-11,999 ft., 12 with
runways 4,000-7,999 ft.
DEFENSE FORCES
Supply: dependent chiefly on U.S.S.R. and China
for virtually all equipment, smaller amounts from
other Communist countries; produces negligible
quantities of infantry weapons, ammunition, and
explosive devices
Military budget: no recent data available; for fiscal
year ending 31 December 1962, estimated defense
expenditures 382 million dongs; about one-fifth of
total budget (estimated value $103 million); military
aid from U.S.$.R. and China now so extensive that
actual allocation of North Vietnam''s domestic
resources to defense would not be indicative of total
military effort
NOTE: VN figures preliminary
VIETNAM, SOUTH
LAND
66,000 sq. mi.,; 25% arable (15% cultivated), 33%
forested, 42% other
Land boundaries: 1,025 mi.
221
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
_ VIETNAM, SOUTH
“ Chine See
''{ SOUTH
) VIETNAM
Gulf of','083bed048e9f3208fba0e4819b076d06bd3cf731894f310ac09ef4c910db0f11','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caa34c333eecec9e114b88fa59eb96c533b2791da2448157e68d87bf5e426e68',1976,'WF','Wallis and Futuna','communications',513,'WALLIS
AND FUTUNA
Pacific Ocean
RS NEW.
ae! ZEALAND
os
{See reference map Vill)
LAND
About 80 sq. mi.
WATER
Limits of territorial waters: 12 n. mi.
Coastline: about 80 mi.
Highways: 62 mi. of improved road on Uvea Island
(1972)
Ports: 2 minor
Airfields: 2 total, all usable; 1 4,000-7,999 ft., 1
seaplane station
Telecommunications: 43 telephones
DEFENSE
No formal defense structure; no regular Armed
Forces
WESTERN SAMOA
WESTERN
®e SOMOA
(See reference map Vi)
LAND
1,100 sq. mi.; comprised of 2 large islands of Savai i
and Upolu and several smaller islands, including
Manono and Apolima; 65% forested, 24% cultivated,
11% industry, waste, or urban
223
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
WESTERN SAMOA/YEMEN (ADEN)
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 250 mi.','41c6bb2a4eae2beb1c97af4684fd0ffdf4b3799b7791083f68123eb2d8b59141','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cf0a26829d6bcb5ca13e8262bb0374faa48d7a48425e8ab3c26342abca10f94',1976,'WS','Samoa','communications',519,'Railroads: none
Highways: 487 mi.; 233 mi. bituminous, remainder
mostly gravel, crushed stone, or earth
Inland waterways: none
Ports: | principal (Apia), 1 minor
Civil air: 2 major transport aircraft
Airfields: 4 total, all usable; 1 with runway 4,000-
7,999 ft.
Telecommunications: 2,270 telephones; 10,100
radio receivers; 1 AM station
YEMEN (ADEN)
Arabian :
= ‘Sea :
(See reference map V}
LAND
111,000 sq. mi. (border with Saudi Arabia
undefined); only about 1% arable (of which less than
25% cultivated)
Land boundaries: 1,120 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(300 meters plus exploitability, plus 6 n. mi.
“necessary supervision zone’ )
Coastline: 860 mi.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Se
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
YEMEN (ADEN)/YEMEN (SANA)','6fc2eeb24789d4ae17780d79fdd0b72ea2f05b3086f5aa2a38ba8d4e4a1dca8a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0d7b0949495daaf2eb0d1b8010b21fb8d0f616aa0caadbc221f21a2c4b765d3',1976,'YE','Yemen','communications',523,'Railroads: none
Highways: 3,300 mi.; 200 mi. bituminous treated,
180 mi. crushed stone and gravel, 2,920 motorable
track
Ports: 1 major (Aden)
Pipelines: refined products, 20 mi.
Civil air: 6 major transport aircraft
Airfields: 95 total, 57 usable; 2 with permanent-
surface runways; 4 with runways 8,000-11,999 ft., 31
with runways 4,000-7,999 ft., 1 seaplane station
Telecommunications: small system of open-wire
line, multiconductor cable, and radiocommunications
stations; only center Aden; 9,900 telephones; 250,000
radio and 30,000 TV receivers; 3 TV and 1 AM
stations; 4 submarine cables (2 operational)
DEFENSE FORCES
Military manpower: males 15-49, 389,000; 215,000
fit for military service
Military budget: for fiscal year ending 31 March
1971, $15,816,000; about 34.4% of total budget
YEMEN (SANA)
LAND
About 75,000 sq. mi. (parts of border with Saudi
Arabia and Southern Yemen undefined); 20%
agricultural, 1% forested, 79% desert, waste, or urban
Land boundaries: 950 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
(plus 6 n. mi, “necessary supervision zone’)
Coastline: 325 mi.
Railroads: none
Highways: 2,160 mi.; 290 mi. bituminous; 270 mi.
crushed stone and gravel; 1,600 mi. earth, sand, and
light gravel
Ports: 1 major (Al Hudaydah), 2 minor
Civil air: 9 major transport aircraft
Airfields: 26 total, 18 usable; 6 with permanent-
surface runways; 1 with runway over 12,000 ft., 4 with
runways 8,000-11,999 ft., 6 with runways 4,000-7,999
ft.
Telecommunications; systems among mideast''’s
worst; consists of meager open-wire lines and low-
power radiocommunication stations; principal center
Sana, secondary centers Al Hudaydah and Taizz:
4,600 telephones; 86,000 radio receivers; 1 AM radio-
broadcast station
DEFENSE FORCES
Military manpower: males 15-49, 1,550,000;
857,000 fit for military service; about 72,000 reach
military age (18) annually; universal military
conscription law (10 January 1963) makes military
service obligatory for all Yemeni males 18-30
Military budget: for fiscal year ending June 1974,
$29.7 million: 41% of total budget
YUGOSLAVIA
Senses = =
Belgrade,
lies
YUGOSLAVIA (ie
\\ Se, e :
A
ALB ARIA.
(See reference map tt}
LAND
98,800 sq. mi.: 32% arable, 25% meadows and
pastures, 34% forested, 9% other
Land boundaries: 1,865 mi.
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
YUGOSLAVIA
WATER
Limits of territorial waters (claimed): 10 n. mi.
(fishing, 12 n. mi.)
Coastline: 945 mi. (mainland), plus 1,500 mi.
(offshore islands)
Railroads: 6,411 route mi.; 5,811 mi. standard
gage, 600 mi. narrow gage; 494 mi. double track;
1,243 mi. electrified (1973)
Highways: 61,119 mi.; 341 mi. concrete, 20,956
mi. bituminous, 684 mi. stone block, 23,312 mi.
gravel, 15,825 mi. earth (1973)
Inland waterways: 1,231 mi. (1975)
Freight carried: rail—89.7 million short tons, 15.8
billion short ton/mi. (1974), highway—88.7 million
short tons, 6.71 billion short ton/mi. (1974);
waterway—est 21.4 million short tons, est. 3.7 billion
short ton/mi. (incl. int''l. transit traffic) (1974)
Pipelines: crude oil, 200 mi.; natural gas, 8320 mi-
Ports: 9 major (most important: Rijeka, Split,
Koper, Bar), 24 minor (1975)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 31 December 1975, 29 billion dinars; about
8.5% of estimated national income
ZAIRE
Atlantic
Ocean
(See reference map V)
LAND
905,000 sq. mi.; 22% agricultural land (1%
cultivated), 45% forested, 33% other
Land boundaries: 6,153 mi.
WATER
Limits of territorial waters (claimed): 12 n. mi.
Coastline: 23 mi.','a7efa2974d7a8aebef7fe0704602e2739dd8c0a5e1f4845c1609efe20bb68b03','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcdcbd3b718c819007275aa7aa682658434a9053df66b076af3144b32cbdc5a9',1976,'OM','Oman','communications',525,'Arabian Sea
wer,
~~ Socatra
Ethiopia c ae ae ay 500 Miles
500 Kilometers
Addis Ababa*
NAMES AND BOUNDARY REPRESENTATION ndian cean
ARE NOT NECESSARILY AUTHORITATIVE
502851 1-76
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Iv Europe
400 Miles
400 Kilometers
- Jan Mayen
(Nor.
ae
Murmansk
pang Norwegian
=
g Reykjavik es Arkangel''sk
es Seu oo
Faeroe Is.
¥en)
4
North %
a
gdinburgh North
Leningrad
Moscow
Atlantic
;, Repali
of Germany
Munich,
“Romania
| France
Lyone Bucharest, Black Sea
Bordeaux
pat a if
Marseille
a
Istan, ee Ankara
*
Corsica
oi
Barcelona
Qa
AG) Sardinia
© Balearic is.
Turkey
Lisbon
i
aMiaita
Mediterranean','5907240723d025e19913b12592f9ca05659a5a61a7bfc980a9f5338fd5fbe387','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

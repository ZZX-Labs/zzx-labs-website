SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4f626ce9e26f4e9c448410774bb226449877d7a81a3b9e07c32307612a88abb',1976,'','','raw',1,'January 1976
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
National Basic Intelligence
FACTBOOK
DIA and DOS review(s) completed.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
FOREWORD
The National Basic Intelligence Factbook, a compilation
of basic data on political entities worldwide, is coordinated and
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central Intelligence Agency,
Washington, D.C. 20505.
The publication is prepared for the use of U.S. Government
officials. The format, coverage and contents of the publication
are designed to meet the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to:
Document Expediting ( DOCEX) Project
Exchange and Gifts Division
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX
Project subscription service may purchase reproductions of spe-
cific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
National Basic Intelligence
FACTBOOK
January 1976
Supersedes the July 1975 issuance of
this Factbook, copies of which should
be destroyed.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TABLE OF CONTENTS
Entries in all capital letters refer to
basic data sheets included in this factbook
Page
Abbreviations for International Organizations . . . . «cr n rn ix
United Nations (U.N.): Structure and Related Agencies . . . . . . +. + +. + xi
—A—
Abu Dhabi (see UNITED ARAB EMIRATES)
AFGHANISTAN .. .. . 4 4 s ooo omo mo eo o hom ot e n t n 1
''Ajman (see UNITED ARAB EMIRATES)
ALBANIA uos mue comes E mom Ro xe SUE Y cum Womlm oe A 2
ALGERIA us cock ar Rec DURS as E Pese ee bene i 3
ANDORRA . s r enoa k K a e o omo o Ro mor nor s n n t n 4
ANGOLA ooo RU ALD eO Bo Vo opo SP a ee a 5
Anguilla (see ST. CHRISTOPHER-NEVIS)
ANTIGUA: u g konoa a aa a e ra e RR aor 6
ARGENTINA . . . . . sooo kom os moe oh 9 ro n ro rn tn tg ng 7
AUSTRALIA . . . «ooo omo momo or ro m t n t n 8
AUSTRIA i. eio wor a GU (Ry ROAD es A ng 10
Azores (see PORTUGAL)
—B—
BAHAMAS, The ....... et 11
BAHRAIN . .. ec eee oy oo o moro mor n n t t n n 12
Balearic islands (see SPAIN)
BANGLADESH . .. .. «4 s oo ooo om oho homo mo n n n t rr n n! n 13
BARBADOS . ........5 pe a dog eia o n n n on TEL OW ode OP os 14
BELGIUM. Luo ho uoo a ARES Eo e WIR a Re HR TO e & Rees 15
BELIZE? s: ogg bue eR A te cede kae a ds A 17
Benin (see DAHOMEY)
BERMUDA aa a peni ore PUD soy dord momo mon e ho e n t n ng. 18
BHUTAN . 2. we ee 19
BOLIVIA o-c oa e ao e o om oh e mo n ho n ro n or n t ng 20
BOTSWANA . . sa . .. 4 oe ho o homo m oro e rom n n n t n n 21
BRAZIL. osos ok ve EDAD GU Bc ce cde ROO e ON DA GP Ser em Y dece 22
British Honduras (see BELIZE)
BRITISH SOLOMON ISLANDS... .. s n n on ee 24
BRUNEI: 2 e exc xeeeR a xc ae es ela Ee dede el RS 25
BULGARIA ww er oi n a g D o a 26
BURMA. . 4 3 e a a aa mo EO a A 27
NIB a a a a a N e ODE 28
==
Cabinda (see ANGOLA)
CAMBODIA .. . aaa aa a homo moe ros ro t t tr n t ng 29
CAMEROON . . . . 4 eoo oro oho mo o mor m ro s t n n t t n 30
CANADÁ" 4-3 a eI B i a Qe Ww ode E Rue del a caput S te 31
Canary Islands (see SPAIN)
CAPE VERDE ISLANDS ..... e o o Rr n t ttr rr 33
CENTRAL AFRICAN REPUBLIC +... +... +... n n . +. +. ts 34
Ceylon (see SRI LANKA)
GHAD ie oe oh ec Bo a eMe Braap ar as Sie 35
CHILE a irn enc eee oe ae n Ey hone. A ee ee Ee 36
CHINA, PEOPLES REPUBLIC OF... o . o t t o. + toto 38
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Page
—Cc-—
CHINA, REPUBLIC OF ................ ll. 39
COLOMBIA: onu a ta e uec REI a eps 40
COMORO ISLANDS .................2.2.2.-.^.2^... 42
CONGO (Brazzaville) . .....................-.2.. 43
Congo (Kinshasa) (see ZAIRE)
COOK ISLANDS: A ri uosognoko xe e E Run 4 Wu 44
COSTA-RIGA- 1-3: 4 et ueque da ED eco UE RD 45
CUBA el ru sU ARP CR ees, Ge ee elut ds Rent 46
mi MM "PTT 47
CZECHOSLOVAKIA . ....... l.l 2l ln 49
—D—
DAHOMEY zo eeu hi I Aaah ae ed a o e ed 50
DENMARK" uv alse hc eu we ie oe rue uua Bal 52
DOMINICA aaua aaa a Lll aa 53
DOMINICAN REPUBLIC O... ........... a a 54
Dubai (see UNITED ARAB EMIRATES)
=
ECUADOR sono ede Ph ioe Bad Ayo PURSE USE eee 55
cdm Utes tee ten ep eke AP tk Mat do act la de A 57
ELSALVADOR. fs xu Dcus aa RE RU Uu 58
EQUATORIAL GUINEA . .. ........... l.l. ln 59
ETHIOPIA: ns o hoe aut te on Rea e tut om oe ae a p p dv pU 60
=e
FAEROE ISLANDS .............0..0.0 0.0004 bay 62
FALKLAND ISLANDS (MALVINAS) ........2.......048., 63
Fernando Po (see EQUATORIAL GUINEA)
Fld 5 ostio m x Ue cp Gye tee Moda oath as erts d 64
EINEAND^ ¿aaa a a a metn Qs ich 65
FRANCES a a he, d soe add II ls de tee A 66
FRENCH GUIANA . ...... l.l. ln 68
FRENCH POLYNESIA .. .......... ll. llle 69
FRENCH TERRITORY OF THE AFARS ANDISSAS ........... 70
Fujairah (see UNITED ARAB EMIRATES)
—G—
GABON? 0 aa AA a ted dd a 71
GAMBIA. | oie te, a a p a Ue a be e 72
GERMANY, EAST ....... 2.2.0.0. ll. 73
GERMANY, WEST ....................... sn 74
GHANA cx ay Bee OR Se Bea ee, OR wh, E NE Eu 76
GIBRALTAR? "olv as “ii tele Boa X xt x Occ pier © mo aso des 77
GILBERT AND ELLICE ISLANDS... ........ l.l. lll 78
GREECE n X. wie tu Iu So meni Mau dex m nom eorr ode 79
GREENLAND + 0 ot tada a s sub ew et ae oe AE a mn da 81
GRENADA» c ino Ey Oi NUS ue tse ee ey eB nhe 81
GUADELOUPE ..........0.0...0..0.0.0- 00500044 G 82
GUATEMALA. 5... 22 no xo eus ee ee Ru ek 83
GUINEA: imr Lu ARI duae Se eh ce m lr AD te es eS 85
GUINEA-BISSAU . ..... ee aa 86
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA: o me ons ctus hie chee EON OR Orne CP dado i d dean 87
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
—H— Page
HAITI Loa ll BOG Rex E de A Cr x Wee oe 88
HONDURAS . ......e rogo mr tn rrt 89
HONG KONG... 91
HUNGARY . . . «sso o oo mom o mor e t tr t t t t n 92
ICELAND «sooo o ommo m otn trt tt rt 93
INDIA i cou o dom a O A 95
INDONESIA . . . . ooo oe o m o ot or t t t t n 96
IRAN: ee woes wey eom sme mou e ee ee a UNUS 97
IBAQ: i uo ecce our de rte Se S Rem. m acces Vnd ON e i 99
IRELAND «2.6 so 4 o9 o RU E moy RR Rom a SR om mot on 100
ISRAEL didnt Ste ROC wt X de es Sh 101
ITALY E a dodude—e oy ae Bee a A 103
IVORY COAST . . . 4 e e t e tr t t t t n n 105
e
JAMAICA . . . 2 s sooo emo oto or t t t t t n 106
JABANN Could us en ky dees P dte Es T Roe qon ce 107
JORDAN! almi eee o eS cee e and de Roe Es IE de NO 109
—K=-
KENYA: oes a a oe Bee A eee e px 110
KOREA, NORTH ...... ee tee ttt 111
KOREA, SOUTH +... «xxx RR ee A 112
KUWAIT uo ele Gee NS Eee qoe ES xe tt de e qr Ro domos 114
p
EROS uir anc ee a ee E Re EUM moy aes 115
LEBANON . .. . oom Ro Ro Romo on rn mr t t nt 116
UESOTHO- zd woo Re XO Em ROR a endende ee See p 117
LIBERIA . . . ooo ooo Root mor ts ttr t t n 119
LIBYA zx. tom uem Ae m EU ROM a u TU PU 120
LIECHTENSTEIN . . oe 121
LUXEMBOURG . .. ... eR mor t n t tr trt 122
—M—
ACAO X lo EE woe A ee AO 123
MADAGASCAR ..... eee o e moe tt t ttt ttr 124
MALAWI . .. oom Rn 126
MALAYSIA. ww . 2 soo oot o mom t tt ttt tt 127
MALDIVES . .. . ooo m om om mtt ttt ttt 130
MALL E As ee Boao eR REN cue Re dos Ta el Ae e 131
MALTA .. .. ooo omo ror eot or t t n t t t n 132
MARTINIQUE . . «s soo o ok o o tm orm t t t t t t n 193
MAURITANIA —.. . 4 s sooo oo o rom mos tot t tn t t t t n 134
MAURITIUS sso . 2 o oe oe oe oth mmt ttr tt 135
MEXICO: eo eode alla GMA Beh abad eode ey en Re ae cruces 137
MONACO «raea eami E rom ro t n t t tf tg ng. 138
MONGOLIA .. .. oo o Rmo E E eo a e A 139
MOROCCO ... 2. ee o momo n t t tn t t t ng 140
MOZAMBIQUE . . . «soo oo ts 142
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Page
-—N—
NAURU: 0 (TUE 143
NEPAL, a dd E ek ek E 144
NETHERLANDS cocos ca e oko xu a a a LL 145
NETHERLANDS ANTILLES laaa . 2 o LL ll 146
NEW CALEDONIA .. 2.2... 2... 2.2... Lo Lv Ll ll 148
NEW HEBRIDES: ccc naras Rupe Ron bene ow eos hg uei a E 149
NEW ZEALAND — op yb eck pod Roos wor S oy s 149
NICARAGUA a sists ay Gio Se Lu Roto WEE X Yos coe S 151
NIGER eua criteri DAL Oc. din Mode May a Re EU oe, Re ay 152
pnr P DM AR RM 153
Northern Rhodesia (see ZAMBIA)
NORWAY «soo dado ede o e Row edu. dedi e Stu ayo 155
—0—
OMAN; 00 pai A a eed BELLE eie eit 156
apa
PAKISTAN: sit a T A ds as en os 157
PANAMA" A ep a de 158
PAPUA NEW GUINEA... 160
PARAGUAY M sla ar isch i as aa a ele, Gay ge oso E N 161
Pemba (see TANZANIA)
PERU: an Sees Be eode OE tet a defe a aaa Aas a 162
PHILIPPINES" dos Sait go await nibo me dodi Yos E ocu 164
POLAND. Zu aed LI ul esa te ke ee a bo hu o Ee 165
PORTUGAL: opo Puer SANO bath a acra Dem rr e ue ee 166
Portuguese Guinea (see GUINEA-BISSAU)
PORTUGUESE TIMOR ....... l.l... v v vu 168
LOs
QATAR prie a qa ir ao ay im bes pe Eu i 169
—R—
Ras al Khaimah (see UNITED ARAB EMIRATES)
DEUNION: e bat ao e a A RR Ae Li 170
A AN O Mee Rut da 171
Rio Muni (see EQUATORIAL GUINEA)
ROMANIA: TE P de 2 a a Ba Bley atts gins kings SB 172
RWANDA.: ¡a A due to o s ae a 174
cc.
ST. CHRISTOPHER-NEVIS-ANGUILLA +... 175
A A AN gage oN 176
A S sudes ante ore wem A Nen duce UR endo us ete 177
SAN MARINO ¿iia um va a Git Soy oom uox Peter ba A e Ls s 178
SAO TOME and PRINCIPE... 179
SAUDI ARABIA iunio te, vd scorsi dee o eror ig Cu 180
SENEGAL +... fo Aes the Ri QR 181
SEYCHELLES S sobres ri ato, escena dior Dr e e ewe lett e 182
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE pee duis UR pont ES e C Pete P Eos 183
SINGAPORE 4 A owe eon NOR Cd b DER 185
SOMALIA. a Vus ttu ae Mese e AAN tom tay un 186
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22
January 1976
—$—
SOUTH AFRICA . «t n t n
Southern Rhodesia (see RHODESIA)
SOUTH-WEST AFRICA . . + + + + ++
SUDAN ..-- ee ert
SURINAM ..--- o n n t t t t t1
SWEDEN +... o n
SWITZERLAND ... ccrto cn
SYRIA 6 Roy Rue Root ox es
Iq
Tanganyika (see TANZANIA)
TONGA ... nt t t t t tt t s
TRINIDAD AND TOBAGO . +. + + + ++
UGANDA .... rt t ttt
Umm al Qaiwain (see UNITED ARAB EMIRATES)
USSA oaol rt ttt ttl
UNITED ARAB EMIRATES: Abu Dhabi,
Ras al Khaimah, Sharjah, Umm al Qaiwain
United Arab Republic (see EGYPT)
UNITED KINGDOM . + + see
UNITED STATES .. eo tt
UPPER VOLTA +... +... toto
URUGUAY .. s o n t t t n t t t
—N—
VENEZUELA +... 6 t ol 0 t n 7
VIETNAM, NORTH . . +s ec?
VIETNAM, SOUTH . . 55000 +
—W—
WALLIS and FUTUNA. «ee 2 «+:
Walvis Bay (see SOUTH AFRICA)
WESTERN SAMOA ssor
zye
: CIA-RDP79-01051A000800010001-8
Page
223
223
224
225
226
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
vii
viii
Approved For Release 2005/04/22 :
VIII
CIA-RDP79-01051A000800010001-8
January 1976
Page
MAPS','060651570911116c559a0f070a50d2253373cefb9d46355cdd38a9f44e389e05','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91adcf31b6b491a932c64636faf3de73b48db17da49c17a2e23e73b9c7119a37',1976,'CA','Canada','raw',2,'MIDDLE AMERICA
SOUTH AMERICA
EUROPE
THE MIDDLE EAST
AFRICA
U.S.S.R. and ASIA
OCEANIA
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
AAPSO
ADB
AFDB
ANZUS
ASEAN
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECOWAS
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
IADB
IDB
IEA
IHO
IPU
IRC
LAFTA
LICROSS
NATO
Afro-Asian People''s Solidarity Organization
Asian Development Bank
African Development Bank
ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
Association of Southeast Asian Nations
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market
Caribbean Free Trade Association
West African Economic Community
Council for Economic Mutual Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Economic Community of West African States
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Space Vehicle Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey,
Niger, Upper Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Inter-American Defense Board
Inter-American Development Bank
International Energy Agency (Associated with OECD)
International Hydrographic Organization
inter-Parliamentary Union
International Red Cross
Latin American Free Trade Association
League of Red Cross Societies
North Atlantic Treaty Organization
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
OAPEC
OAS
OAU
OCAM
ODECA
OECD
OPEC
UDEAC
UEAC
WEU
WCL
WFTU
WPC
Organization of Arab Petroleum Exporting Countries
Organization of American States
Organization of African Unity
Afro-Malagasy and Mauritian Common Organization
Organization of Central American States
Organization for Economic Cooperation and Development
Organization of Petroleum Exporting Countries
Economic and Customs Union of Central Africa
Union of Central African States
Western European Union
World Confederation of Labor
World Federation of Trade Unions
World Peace Council
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc Security Council
GA General Assembly
ECOSOC Economic and Social Council
TC Trusteeship Council
ICJ International Court of Justice
Secretariat
Operating Bodies:
UNCTAD U.N. Conference for Trade and Development
TDB Trade and Development Board
UNICEF U.N. Children’s Fund
Regional Economic Commissions:
ECA Economic Commission for Africa
ECAFE Economic Commission for Asia and the Far East (see ESCAP)
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development
(World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural
Organization
UPU Universal Postal Union
UNCTAD U.N. Conference on Trade and Development
WHO World Health Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
Committees:
Seabeds Committee United Nations Committee on the Peaceful Uses ofthe
Seabed and Ocean Floor beyond the Limits of National
Jurisdiction
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Political, sociological, and economic data, including monetary
conversion rates, generally reflect information through mid-October
1975, except for population estimates, which have been projected to 1
January 1976. Military manpower estimates are as of 1 January 1975
except for average number of males reaching military age, which are
projected averages for the 5-year period 1975-79. Military and com-
munications data are as of 30 October 1975 unless otherwise in-
dicated.
Most of the land utilization estimates are rough approximations,
and most of the statistical data are rounded (thousands and millions).
Figures for "arable" may reflect only the area actually under crops
rather than the potential cultivable. Fishing limits are included only
when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The
difference between the two is in the addition or subtraction of the
value of return on foreign investment. GDP equals GNP plus income
earned in the country but sent abroad, minus income earned abroad
but sent into the country. GDP thus tends to exceed GNP in debtor
countries, and the reverse is true in creditor countries.
Major ports are the largest maritime ports of the country, relative
to other ports of the same country, on the basis of estimated port
Capacity, alongside berthing accommodations, and commercial or
naval importance. Minor ports are the remaining ports of a country
which have, relative to the major ports, significantly lower estimated
port capacity, fewer alongside berthing accommodations, are of less
commercial or naval importance, Major transport aircraft are those
weighing over 20,000 pounds. Military budgets are in U.S. dollar
equivalents. The dollar sign refers to U.S. dollars unless otherwise
stated. The abbreviation FY stands tor U.S. fiscal year; all years are
calendar years unless otherwise indicated.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','953dd9dec146263be1390524f420b0b2759698d8f9b6b122e404c88ff605e548','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87ce4e471ebb6cf7e4a499c4bb4e8b683261b4f2a5f357dfe3a6e9cdf4e06c89',1976,'AF','Afghanistan','raw',3,'Arabian Ses
(Seo reference map VII)
LAND
250,000 sq. mi.; 2296 arable (1256 cultivated, 10%
pasture), 75% desert, waste or urban, 3% forested
(1970)
Land boundaries: 3,425 mi.','7377812681d8d546272a5eb4849b099d8462a0c59efdf4cbc89bc920662d4d66','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9eace3e0beb0b2fd2c01d20f5cbf6cb46b844b17709982462baff78e7e11b20b',1976,'','','raw',1,'January 1976
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
National Basic Intelligence
FACTBOOK
DIA and DOS review(s) completed.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
FOREWORD
The National Basic Intelligence Factbook, a compilation
of basic data on political entities worldwide, is coordinated and
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central Intelligence Agency,
Washington, D.C. 20505.
The publication is prepared for the use of U.S. Government
officials. The format, coverage and contents of the publication
are designed to mect the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gifts Division
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX
Project subscription service may purchase reproductions of spe-
cific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
National Basic Intelligence
FACTBOOK
January 1976
Supersedes the July 1975 issuance of
this Factbook, copies of which should
be destroyed.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TABLE OF CONTENTS
Entries in all capital letters refer to
basic data sheets included in this factbook
Page
Abbreviations for International Organizations . . - . 2 16. ee ee ees ix
United Nations (U.N.): Structure and Related Agencies .....-.-+--:- xi
A=
Abu Dhabi (see UNITED ARAB EMIRATES)
AFGHANISTAN . 2. wee ee 1
‘Ajman (see UNITED ARAB EMIRATES)
ALBANIA . ww ee ee 2
ALGERIA. . «0c 806 6 G Be ee OE a RR ee ee 3
ANDORRA . 2... ee ee 4
ANGOLA. niche ies we eR SRS, HE OO a 5
Anguilla (see ST. CHRISTOPHER-NEVIS)
ANTIGUA . 0... ee et 6
ARGENTINA . 2.0. ee ee 7
AUSTRALIA 2.0. ce 8
AUSTRIA «oc bee ee ca ee ee ee 10
Azores (see PORTUGAL)
—B-—
BAHAMAS, The ... 1. eee 11
BAHRAIN ... 0.2 0 ee ee ee ee 12
Balearic Islands (see SPAIN)
BANGLADESH ... 2... ee eee 13
BARBADOS ..... 2.0.2.0 2 ee tee te Pig Mid. ad te te 14
BELGIUM . 2... ee ee 15
BELIZE” is 8h ates Bek a Bia BR ee atm: App Bue See ee? Gee 17
Benin (see DAHOMEY)
BERMUDA... 1. ee ee 18
BHUTAN 6.00 ec eee hw ee a ee a a eS 19
BOLIVIA ece % SE oe eee woe ee Bet aa MY ee oe 20
BOTSWANA .. 0. 0 ee 21
BRAZIL. .. «6 2. ee oe ee ee ee es 22
British Honduras (see BELIZE)
BRITISH SOLOMON ISLANDS... . ee ee 24
BRUNE] . 2... eee ee 25
BULGARIA... ee ee te ee ee 26
BURMA: 2 (Soc c mele eee fea ek See Bad Gee Er ae BES Se er ae 27
BURUNDI . 2... ee ee ee 28
— Ci
Cabinda (see ANGOLA)
CAMBODIA...) ee ee 29
CAMEROON ... 2. ee ee ne ns 30
CANADA... we ce ee ee es 31
Canary Islands (see SPAIN)
CAPE VERDE ISLANDS ..... 2 ee ee ee 33
CENTRAL AFRICAN REPUBLIC .....-- ee eee ee ee es 34
Ceylon (see SRI LANKA)
CHAD 220s dw eee Gh & GO ae ee we ee ti oe ge ES 35
COIS i oil. 4 wey at te Meee, Sage gee Mites hr WU aoe A a a! Gee a ae 36
CHINA, PEOPLE’S REPUBLIC OF ... . 2. eee et ee es 38
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Page
EG
CHINA, REPUBLIC OF ..........0......0-. 000004 39
COLOMBIA. cs ee dk he se es SE a we ee Sw nel Ged 40
COMORO ISLANDS ..........0. 0.000 ee ee ee ee 42
CONGO (Brazzaville) . 2... ee 43
Congo (Kinshasa) (see ZAIRE)
COOK ISLANDS ..........0.0..... 0.2000. Dad 44
COSTA RICA . 2... 1. 45
CUBR: wi ate ak ate enki ch Ae reg ea MLA pete es 46
GYPRUS'': 0d dee: Ga ge oO A ee 2 dada cigs ie Ub thu a Bd 47
CZECHOSLOVAKIA... 2... 49
—D—
DAMOMEY > 22 Aen adkleo Re ee hw Boe oe ee ae Bo el ea a 50
DENMARK? fsis. Si Siig, alt Bee aed a ee w to Ogee Ne 52
DOMINICA. iis? ls. fa eed en BO ey Eke alee Oo 53
DOMINICAN REPUBLIC ..........0...0..02. 00000. 54
Dubai (see UNITED ARAB EMIRATES)
Fl
ECUADOR ® <6 5 ee te hs ae dg BAO ee eA bd eee be 55
EGYPT of tic 2 Aemie® eine ae Beck, oy td oh tw oven ES WO AS tok: wind tS We a 57
EL;SALVADOR: | a. tecco hoe ec eas Bu ce ee a eee Deo 58
EQUATORIAL GUINEA ........0..2020.20.2..0-. 004 a 59
ETHIORIAS 2. oo cee eb ee A ed a eid hn de ons be oo ie cee 60
—e=
FAEROE ISLANDS ..............0.. 00000 bua 62
FALKLAND ISLANDS (MALVINAS) .................. 63
Fernando Po (see EQUATORIAL GUINEA)
Ell: fg kane oe Paste s BES! ot Honey ane cB Don St ANS Sete AL es 64
FINEAND). i: pas 44 Bele ce Avene gm es we BP oe yl ele 65
FRANCE: .xn3 te ore tat in ote og ea aA Se coe J a ed 66
FRENCH GUIANA .. 2... 2... ee 68
FRENCH POLYNESIA ..... 2... ee 69
FRENCH TERRITORY OF THE AFARS AND ISSAS ........... 70
Fujairah (see UNITED ARAB EMIRATES)
—G
GABON? 24) cs 3-58, tac cited hotbed, ee ae eacks weak yee, ca eet te ayant ry 71
GAMBIA. ww wk 72
GERMANY, EAST .........0.0.000 000. eee 73
GERMANY, WEST ..........0..00. 0000 cee eee 74
GHANA) ities eS ES oy ir eee Gee tee alah, Sy eit ew oe ee 76
GIBRALTAR .. 2. 2... ee 77
GILBERT AND ELLICE ISLANDS .................., 78
GREECE!) cob de etn eagle et Sine dots Ae ae Sh en oe: 79
GREENLAND oe ee be ee ee ee ae ee ek 81
GRENADA? 3 3. 8 vg a ek a a i oR Ok ea ee ee 81
GUADELOUPE ...........0..0..0.- 0000-04 82
GUATEMALA . ook eh a ae a eee, 83
GUINEA fie ht. ee ee A Bae laces ae bo Beate aie BS 85
GUINEA-BISSAU .. 2... ...0.0.002.0. 00000 bee eee, 86
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA® Oo. ese nee gh ae te a at wae Ra Bok Sedan te fo ey 87
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
es a Page
HAIT «e-PRO ec SO, Bk A gis 88
HONDURAS .....- 0 et ee 89
HONG KONG) .-6 ees ee a ee ee 91
HUNGARY .. 0-00 ee 92
IGELAND: <6 2a 6.3092 Be wt 4 BCE See OR ERS SOBs 93
TOUS mcs oe a sn ee ae es BS ee SS a SS 95
INDONESIA: <4 43 Gok oe eh tee ee Ele Oe PS 96
DAN. 9 Ficccgs tema am Op ee Oh ee eee hg ree 97
FARO! ac. ak ee wea Ae Oe we eae ee as ee ee ee 99
IREVAND® <2.4).2.¢-a boo. ea ala wea BS Ee SA 100
ISRAEL a ee eee aoe ee ere, Dee Be, ah es & aS, 18S 101
ITAULN: cece koe ates ek ee ree be ee Set A a 103
IVORY COAST . 2... ee ee 105
ij
JAMAICR: . 3. ie og Ro RES i BO ee EO OLE FE eS 106
IRDAING os. nag: Poe eee eect ho Jee NR Re Boy ote Pe Pee 107
JORDAN: ce. te care Sc or Re ee ee Bes i ees 109
= Kes
KENYA] foc 20 & gia a aR Sh eee re es 110
KOREA; NORTH .o- sos ect ee i or ee OP es 111
KOREA: SOUTH. 4-6. hai re ak Se Gr Se a es 112
KUWAIT. oc. coe. Soca le er a re Se ee I RO 114
=
PROS: occ A OR Ee We EO ee re Se A EEE 115
LEBANON ..... 0 ee ee 116
CESOTIHO: 4 eae ee oe oe, ee Se Sale eS 117
LIBERIA Sos Se te ed ok A I OS Ge 119
LIBYA: see dg oleceend | de aoe aoe eee Re Tp a ai) a Steg 120
LIECHTENSTEIN: a ccs oe ee ee 121
LUXEMBOURG ..... 2. eee ee eee ts 122
—M—
MACAO: ese ho SOR oe ee ee a ae 123
MADAGASCAR... oo 404 alee we Fe OR ee ee es 124
MALAWI ...-- ee eee tt th hrs 126
MALAYSIA... we ns 127
MALDIVES .. 2. ee ee et ee ets 130
MAUL oo cucece es Bets GAR Go ac Agen Sheet Ro ome os 131
MALTA. «G20 oe ac ee Ew ee Be Ba te ee ee 132
MARTINIQUE .. 2. ee ee ee 133
MAURITANIA 2. we es 134
MAURITIUS . 2... eee ee ns 135
MEXICO... ss ne ae ee RY eh aes BD ee 137
MONACO .... 2 eee et 138
MONGOLIA .. 2. ns 139
MOROCCO ..... 2 eee ee es 140
MOZAMBIQUE ..... ee ee tt ts 142
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Page
—_N—
AU, eee a tS oScte, be y Ohs gte Peo e b le poe he bh oan oo 143
NBT ade tee cicagtet Soule oi? og, Ail te red van Moe Ae he ph ota A a 4 cote 144
NETHERLANDS ...........0 0.0000 vp euee.l... 145
NETHERLANDS ANTILLES ............,.,.,..,...., 146
NEWSGALEDONIA cee. le de a an 148
NEW HEBRIDES nic oe ee a a ee we 149
NEWSZEALAND: © 53 x3 cork 3 84d alge bute ace Salar d)e/ aie als Boneh 149
NICARAGUA: coi o east, ek serie at gout 4 ata 5h GO ad ne he 151
NIGER. aei-trate Snctas dee we Gas ee Goan Ot Sawa le et es 152
DISARRAY Soe i Saka hte tee mat apdy Tet ae th Pate het mel alge 153
Northern Rhodesia (see ZAMBIA)
NORA Sire sa oes arch wd 05.4) Muna a eka eg de gon heararac ok ee 155
=oO—
OMAN, «aha SoS ae i oe ae echt A oe he 156
=P
RAIRISTAN 92. 40 5 nae sae gue Tehie Oe tates. hg oe leo fe Geatdon Bot 157
ANAM dl loc Sires 28 Ge. ofp ten, im, “amiga Bs Re BE MPa ek ee se ke 158
PAPUA NEW GUINEA .................,......, 160
PARAGUAY: “oy fede core Xf S: wits ve ok Spo ohids eee eo-b ei bets ite hae be 161
Pemba (see TANZANIA)
RERWT Sts Soe ee PSA ee, hap neta ay a, ye Ee iet cory or ie WSs! be 162
PII PP INES 5c. save! i hugety “ae iphak pee iors teh geal te atacand oot, 2d an Te 164
POLAND? 6. se dedi hy Eth BG, teen ele, ot tine isk hee ere, oe 165
PORTO AL sie cn dus tas ily ea at on ot dees ie Boat DIS BEA NG Ot 166
Portuguese Guinea (see GUINEA-BISSAU)
PORTUGUESE TIMOR ...............,.0...,.... 168
—Q—
ROTARY: “pestered BE BN Ot Melee de oe] Bate Ne Si a et 2 ot ah pe os 169
—R—
Ras al Khaimah (see UNITED ARAB EMIRATES)
PEUINION: sop siogsia arity al al Deine, ops aps go er Sek Be Boh Se gly 170
ODE SIA: tk, Bett i At ot MEia 3D Heke etal 4 Cie Nala eas BiG ©. 171
Rio Muni (see EQUATORIAL GUINEA)
PROINA INIA sock Yelle stip nan des tetnose greeny 10 ch oats oehncy sas fh Jeo gh ds''atery boning 172
a5, Sle Me a eo ae a A 174
ae <r
ST. CHRISTOPHER-NEVIS-ANGUILLA ............,.... 175
CNAs tu rit Been tcd, SOc eal Bn Gece Me Ba ead eae kgek Ne 176
SL VINGENT 15 a ecg ewer ewe oaast Singh nt ant We he yaa of pe a 177
SAAN MAINO sce ata ae 2 Ae ilk Rica 02d det psigh-ah agentes Shee tee oho 178
SAO TOME and PRINCIPE .........,..,.,.,.,...,.07 179
SRUDICARABIA, x54: Goa optics Vue og apd So hg a eeu a. latinas hae a 180
SENEGAL oP daw hie a we ar koe ae ce AaB we 181
SEYCHELLES: cick gh aoe By. eb aoe evoke a ae ee ce 182
Sharjah (see UNITED ARAB EMIRATES)
DIERRA LEONE eye ga. bee ate ek Ly dec hey deen 183
SINGARORE'' 2. due highs 5) tee ag Ny gate ay re sags 185
MALIA iS pod cep isthe Wea, ail en eA Wh Se gna gears Oe oe Gc 186
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22
January 1976
+Ss
SUDAN: o.sc80s God Se eo ee ts
SURINAM ..--- 0 ttt ttt
SWEDEN ..- eee ett ttt
SWITZERLAND ..- eee ttt
SYRIA... tt
ee,
Tanganyika (see TANZANIA)
TONGA® 2 o-Ps
TRINIDAD AND TOBAGO... +--+:
TUNISIA . 0 et
TURKEY... - ett
eves
UGANDA ..-- eee tt tte
Umm al Qaiwain (see UNITED ARAB EMIRATES)
U.S.S
UNITED STATES .-- - ee ttt?
UPPER VOLTA .---- sett
URUGUAY... - eet tt
_y—
VENEZUELA ..-- +e ett st
VIETNAM, NORTH ..-- +s st
VIETNAM, SOUTH... - ess ct
_w—
WALLIS and FUTUNA . «ee et ts
Walvis Bay (see SOUTH AFRICA)
WESTERN SAMOA .- ee et ttt
ays:
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
S.R.
NITED ARAB EMIRATES: Abu Dhabi, ‘Ajma
Ras al Khaimah, Sharjah, Umm al Qaiwain
: CIA-RDP79-01051A000800010001-8
Page
187
188
190
192
192
194
195
197
198
199
201
202
204
205
206
207
208
209
vii
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
—~Z— Page
ZAIRE...
S| Coe cheese Cae coe ee ee re 228
229
MAPS
| CANADA
1} MIDDLE AMERICA
11! SOUTH AMERICA
IV. EUROPE
V_ THE MIDDLE EAST
Vi AFRICA
VII U.S.S.R. and ASIA
Vil OCEANIA
viii
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
AAPSO
ADB
AFDB
ANZUS
ASEAN
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECOWAS
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
IADB
IDB
IEA
IHO
IPU
IRC
LAFTA
LICROSS
NATO
Afro-Asian People’s Solidarity Organization
Asian Development Bank
African Development Bank
ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
Association of Southeast Asian Nations
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market
Caribbean Free Trade Association
West African Economic Community
Council for Economic Mutual Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Economic Community of West African States
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Space Vehicle Launcher Development Organization
European Monetary Agreement
Political-Economic Association of lvory Coast, Dahomey,
Niger, Upper Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Inter-American Defense Board
Inter-American Development Bank
International Energy Agency (Associated with OECD)
International Hydrographic Organization
Inter-Parliamentary Union
International Red Cross
Latin American Free Trade Association
League of Red Cross Societies
North Atlantic Treaty Organization
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
OAPEC
OAS
OAU
OCAM
ODECA
OECD
OPEC
UDEAC
UEAC
WEU
WCL
WFTU
WPC
Organization of Arab Petroleum Exporting Countries
Organization of American States
Organization of African Unity
Afro-Malagasy and Mauritian Common Organization
Organization of Central American States
Organization for Economic Cooperation and Development
Organization of Petroleum Exporting Countries
Economic and Customs Union of Central Africa
Union of Central African States
Western European Union
World Confederation of Labor
World Federation of Trade Unions
World Peace Council
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc Security Council
GA General Assembly
ECOSOC Economic and Social Council
TC Trusteeship Council
IGJ International Court of Justice
Secretariat
Operating Bodies:
UNCTAD U.N. Conference for Trade and Development
TDB Trade and Development Board
UNICEF U.N. Children’s Fund
Regional Economic Commissions:
ECA Economic Commission for Africa
ECAFE Economic Commission for Asia and the Far East (see ESCAP)
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development
(World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU international Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural
Organization
UPU Universal Postal Union
UNCTAD U.N. Conference on Trade and Development
WHO World Health Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
Committees:
Seabeds Committee United Nations Committee on the Peaceful Uses of the
Seabed and Ocean Floor beyond the Limits of National
Jurisdiction
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
xi
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Political, sociological, and economic data, including monetary
conversion rates, generally reflect information through mid-October
1975, except for population estimates, which have been projected to 1
January 1976. Military manpower estimates are as of 1 January 1975
except for average number of males reaching military age, which are
projected averages for the 5-year period 1975-79. Military and com-
munications data are as of 30 October 1975 unless otherwise in-
dicated.
Most of the land utilization estimates are rough approximations,
and most of the statistical data are rounded (thousands and millions).
Figures for “arable” may reflect only the area actually under crops
rather than the potential cultivable. Fishing limits are included only
when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The
difference between the two is in the addition or subtraction of the
value of return on foreign investment. GDP equals GNP plus income
earned in the country but sent abroad, minus income earned abroad
but sent into the country. GDP thus tends to exceed GNP in debtor
countries, and the reverse is true in creditor countries.
Major ports are the largest maritime ports of the country, relative
to other ports of the same country, on the basis of estimated port
capacity, alongside berthing accommodations, and commercial or
naval importance. Minor Ports are the remaining ports of a country
which have, relative to the major ports, significantly lower estimated
port capacity, fewer alongside berthing accommodations, are of less
commercial or naval importance, Major transport aircraft are those
weighing over 20,000 pounds. Military budgets are in U.S. dollar
equivalents. The dollar sign refers to U.S. dollars unless otherwise
stated. The abbreviation FY stands for U.S. fiscal year; all years are
calendar years unless otherwise indicated.
xii
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976','e6f3a4a99ce71f76c5f8e4148990aebf5213acabe92e8553586a3a4b73712974','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db6142277dd3c6dbe447d954901537a42bbf28cf80c6b6e97b03abf705eb85c9',1976,'AF','Afghanistan','raw',2,'Arabian Sea
(See reference map Vil)
LAND
250,000 sq. mi.; 22% arable (12% cultivated, 10%
pasture), 75% desert, waste or urban, 3% forested
(1970)
Land boundaries: 3,425 mi.','d666778789c59cd9ab16ff558159f5ffdd0cf0fc36f86788c23aca17fd6b131d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

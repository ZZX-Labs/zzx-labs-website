SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3244237783165f25fee6d26828428b884c853f404fee3d057302b0965fd718ff',1976,'AF','Afghanistan','people-and-society',4,'Population: 19,367,000, average annual growth
rate 2.3% (7/72-7/73)
Nationality: noun—Afghan(s); adjective—Afghan
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9%
Uzbeks, 9% Hazaras, minor ethnic groups include
Chahar, Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim,
1% other
Language: 50% Pushtu, 35% Afghan Persian
(Dari), 11% Turkic languages (primarily Uzbek and
Turkmen), 10% 80 minor languages (primarily
Baluchi and Pashai); much bilingualism
Literacy: under 10%
Labor force: about 4.3 million (1966 official est.);
75%-80% agriculture and animal husbandry, 20%-
25% commerce, small industry, services; massive
shortage of skilled labor
Organized labor: none','2530bf5831122af5678697ae050fd809e99b5bcf88b700e935819a74bb3b0312','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bde74f3b92b740672c43ecd1728117421a49af699677eb6202fdf05aa69b4dd0',1976,'AL','Albania','people-and-society',9,'Population: 2,439,000, average annual growth rate
2.4% (current)
Nationality:
Albanian
noun—Albanian(s); adjective—
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
Ey
Religion: 70% Muslim, 20% Albanian Orthodox.
10% Roman Catholic (observances prohibited;
Albania claims to be the world''s first atheist state)
Language: Albanian, Greck
Literacy: about 7056; no reliable current statistics
available, but probably greatly improved
Labor force: 911,000 (1969); 60.5% agriculture.
17.996 industry, 21.6% other nonagricultural
COVERNMENT
Legal name: Peoples Republic of Albania
Type: Communist state
Capital: Tirane
Political subdivisons: 27 rethet (districts),
including capital, 200 localities, 2,600 villages
Legal system: based on Soviet law; constitution
adopted 1950; judicial review of legislative acts only
in the Presidium of the People’s Assembly, which is
not a true court; legal education at State University of
Tirane; has not accepted compulsory IC] jurisdiction
Branches: People''s Assembly, Council of Ministers,
judiciary
Government leaders: Chairman of Council of
Ministers, Mehmet Shehu; President, Presidium af the
People’s Assembly, Haxhi Lleshi
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held
every 4 years; last elections 6 October 1974; 99.9% of
vlectorate voted
Political parties and leaders: Albanian Workers
Party only; First Secretary, Enver Hoxha
Communists: 87,000 party members (1971)
Member of; CEMA, IAEA, IPU, ITU. Seabeds
Committee, U.N., UNESCO, UPU. WETU, WHO,
WMO, has not participated in CEMA since rift with
U.S.S.R. in 1961; officially withdrew from Warsaw
Pact 13 September 1968
Population: 17,062,000, average annual growth
rate 3.2% (7/73-7/74)
Nationality: noun—Algerian(s); adjective—
Algerian
Ethnic divisions: 99% Arab-Berbers, less than 1%
Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 2.8 million, 47% agriculture, 8%
industry, 24% other (military, police, civil service,
transportation workers, teachers, merchants,
construction workers); 40% of urban labor unem-
ployed
Organized labor: 17% of labor force claimed;
Ceneral Union of Algerian Workers (UGTA) is the
only labor organization and is subordinate to the
National Liberation Front','c7fe4dc536f2c62f27bfe3a21ed7876e4f44533bda9bdb0dd71aa02bf303ed29','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57d6454d799bae99110b702909f60ded2fd71b68b0c3da84fe2da1fbf43108e5',1976,'AD','Andorra','people-and-society',15,'Population: 19,000 (official estimate for 1 July
1969)
Nationality:
Andorran
Ethnic divisions: Catalan stock; 30% Audorrans,
61% Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French
and Castilian
Labor force: unorganized; largely shepherds and
farmers
COVERNMENT
Legal name: The Valleys of Andorra
Type: unique coprincipality under formal
sovereignty of President of France and Spanish Bishop
of Seo de Urgel, who are represented locally by
officials called veguers
Capital: Andorra
Political subdivisions: 6 districts — Andorra la
Vella, Sant Julia de Loria, Encamp, Canillo, La
Massana, and Ordino
noun—Andorran(s); adjective—
Legal system: based on French and Spanish civil
codes; Plan of Reform adopted 1866 serves as
constitution; no judicial review of legislative acts; has
not accepted compulsory ICJ jurisdiction
Branches: legislature (General Council) of 24
members with one-half elected every 2 years for 4-year
term; executive — syndic and a deputy sub-syndic
chosen by General Council for S-year terms; judiciary
chosen by coprinces who appoint 2 civil judges, a
judge of appeals, and 2 Batles (court prosecutors)
Suffrage: males of 21 or over who are third
generation Andorrans vote for General Council
members; same right granted to women in April 1970
Elections: half of General Council chosen every 2
years, last election December 1973
Political parties and leaders: no political parties
but only partisans for particular independent
candidates for the General Council, on the basis of
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ANDORRA/ ANGOLA
competence, personality and orientation toward Spain
or France; various small pressure groups developed in
1972 f
Communists: negligible','b25c538aa04ade2f3504e84e589b377554eb3505d21466b2ae88e37828ffccd0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efc08221cb0665554d19b89b532b9ecfd4327d1477508bf3485e01c27578ec5c',1976,'AO','Angola','people-and-society',18,'Population: Angola, 6,052,000 (docs not take into
account recent emigration from Angola), average
annual growth rate 1.6% (12/60-12/70); Cabinda,
95,000 (official estimate for 1 July 1972)
Nationality: noun—Angolan(s); adjective—
Angolan
Ethnic divisions: 93% African, 5% Europeans, 1%
mestizos
Religion: about 84%
Catholic, 4% Protestant
Language: Portuguese (official), many native
animist, 12% Roman
dialects
Atlantic
Ücean
(See reference map VI)
Literacy: 10%-15%
Labor force: 2.6 million economically active
(1964); 531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)','e0d10b8f2f110cab23cb0375b5448086ec22f0cae33da063d154cd41aa6e3216','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97acc97326513a989913451728b3cc30f6a883f41217cf749a47adb0304a8b9d',1976,'PR','Puerto Rico','people-and-society',22,'Population: 72,000, average annual growth rate
1.4% (7/73-7/74)
Nationality:
Antiguan
noun—Antiguan(s); adjective—
6
Approved For Release 2005/04/22 :
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other
Protestant sects and some Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000','4e73d0e93239b15443055800f3e2a2cd36025b1a35a1c4795ddbf96c26078df1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6d2623c129b5a5afa694f36f3b14fd1e1e7c70a2c2451e5d2317e4303aedfb1',1976,'AR','Argentina','people-and-society',26,'Population: 95,551,000, average annual growth
rate 1.3% (current)
Nationality: noun—Argentine(s); adjective—
Argentine
Ethnic divisions: approximately 85% white, 15%
mestizo, Indian, or other nonwhite groups
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Religion: 90% nominally Roman Catholic (less
than 20% practicing), 2% Protestant, 2% Jewish, 6%
other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 9.5 million; 19% agriculture, 9596
manufacturing, 20% services, 11% commerce, 6%
transport and communications, 19% other
Organized labor: 25% of labor foree (est. )','bc3659c6fe71c85fff0e5030e75e4bc36bf5b84f5cf60bd7e9d28587b4d02cef','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75a458bffec2304d5af043fb8b5439a941cf84c7e8567e3b617f045cccff8bcc',1976,'AU','Australia','people-and-society',30,'Population: 13,721,000, average annual growth
rate 1.8% (7/66-7/74)
Nationality; noun—Australian(s):
Australian
Ethnic divisions: 99% Caucasian, 1% Asian and
aborigine
Religion: 98% Christian, 2% animist and others
adjective—
10001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008000
E € €———Á7ÁÀ
January 1976
Appro
pproved For Release 2005/04/22 : CIA-RDP79-01051A00080001000
1-8
Language: English
Literacy: 98.5%
Labor force: 4.76 million; 14% agriculture, 32%
industry, 37% services, 15% commerce, 2% other
Organized labor: 44% of labor force
Population: 2,714,000, average annual growth rate
2.8% (7/66-7/73)
Nationality: noun—Papua New Guinean(s);
adjective—Papua New Guinean
160
Ethnic divisions: predominantly Melanesian and
Papuan, some Negrito, Micronesian, and Polynesian
types
Religion: over one-half of population nominally
Christian (490,000 Catholic, 320,000 Lutheran, other
Protestant sects); remainder animist
Language: 700 indigenous languages; pidgin
English and 2 or 3 native languages are linguae
francae for over one-half of population; English
spoken by 1% to 2% of population
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly
subsistence farmers','cba2a18e1b323090e9db1c18d0e76e06b5c1d08121f8ec516590574804b4e378','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a640fee0363bf4eeec102a7a8f98b6a7fe2fbbcfb0d968f24d173be4bed53d59',1976,'AT','Austria','people-and-society',36,'Population: 7,541,000, average annual growth rate
0.0% (1/74-1/75)
Nationality:
Austrian
Ethnic divisions: 98.1% German, 0.7% Croatian,
0.3% Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8%
uone or other
noun—Austriau(s): adjective—
Language: German
Literacy; 98%
Labor force; 2.656.922 (1974); 18% agriculture
and forestry, 49% industry and crafts, 18% trade and
communications, 7% professions, 6*; public service,
2% other; 2.4%, registered unemployed: an estimated
200,000 Austrians are employed in other European
countries; foreign laborers in Austria number more
than 200,000 (1972); unemployment 2.0% (August
1975)
Organized labor: about 2/3 of wage and salary
workers (1971)
COVERNMENT
Legal name: Republic of Austria
10
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states ( Laender) including
the capital
Legal system: civil law system with Roman lay
origin; constitution adopted 1920. repromulgated in
5945; judicial review of legislative acts by a
Constitutional Court: Separate administrative and
civil/penal Supreme courts; legal education at
Universities of Vienna, Graz, Lansbruck, Salzburg,
and Linz: has not accepted compulsory ICJ
jurisdiction
Branches: bicameral Parliament, directly elected
President whose functions are largely representational,
independent federal indiciary
Government leaders: President Rudolf Kirch-
schlaeger, Chancellor Bruno Kreisky leads a one-party
Socialist government
Suffrage: universal over age 19: compulsory for
presidential elections
Elections: presidential, every 6 vears (next 1980).
parliamentary, every 4 years (next October)
Political parties and leaders: Socialist Party of
Austria (SPOe), Bruno Kreisky, Chairman: Austrian
Peoples Party (OeVP), Josef Taus, Chairman: Liberal
Party (FPO6e), Friedrich Peter, Chairman: Communist
Party, Franz Muhri, Chairman
Voting strength (1975 election): 50.65 SPOe,
42.79€ OeVP. 5.3% FPOe, 1.2% Communist
Communists; membership 25,000 est: activists
7.000-8,000
Other politica] or Pressure groups: Federal
Chamber of Commerce and Industry; Austrian Trade
Union Federation (primarily socialist); three
composite leagues of the Austrian. Peoples Party
(OeVP) representing business, labor, and farmers: the
OcVP-oriented League of Austrian Industrialists:
Roman Catholic Church, including its chief lay
organization, Catholic Action
Member of: ADB. Council of Europe, DAC, ECE,
EFTA, EMA. ESRO (observer), FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFA, IFC, ILO, IMF, ITU,
OECD, Seabeds Committee, U N., UNESCO, UPU,
WCL, WFTU, WHO, WMO
Population: 203,000, average annual growth rate
2.1% (7/73-7/74)
Nationality: noun—Bahamian (sing., pl.); adjec-
tive—Bahamian
Ethnic divisions: 80% Negro, 10% white, 10%
mixed
Religion: Baptists 29%, Church of England 23%,
Roman Catholic 23%, smaller groups of other
Protestant, Greek Orthodox, and Jews
Language: English
Labor force: 69,000 (1970); 2596 organized','99686e662d389d7bd9a7750c40303c1f80972de2ac52f8a428f20aa1ce6d5186','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8321ae8a5af79af056f11fd023fe43b21844b47ff3572cd6e836ba8ad6fb0aac',1976,'BH','Bahrain','people-and-society',40,'Population: 243,000, average annual growth rate
2.8% (2/65-4/71)
Nationality: noun— Bahraini(s): adjective—
Bahraini
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani,
and Indian, 3% other
Religion: Muslim
Language: Arabic, English also widely spoken
Literacy: about 40% (1970)
Labor force: 60,301 (1971)','d08a667fab6bb0a9bdd493f1c66c7b5fce8e6ccf48edb981f1f4e20b79980f3e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2004424c552b11df3c503e19e4d7e720a56b050a78afe8264ec7afd12d279417',1976,'BD','Bangladesh','people-and-society',45,'Population: 74,775,000, average annual growth
rate 2.8% (current)
Nationality:
Ethnic divisions: predominantly Bengali; fewer
than 1 million “Biharis” and fewer than 1 million
tribals
Religion: about 83% Muslim, 16% Hindu; less
than 1% Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 26 million; extensive un-
deremployment; over 80% of labor force is in
agriculture','5806211b4280383cc668be4f01d1930e2a9724536344fb8c972e359b17d08606','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0ccfbea9abac208b62f3ef71bee129fbc07294807590370984c8030fc47fc3f',1976,'BB','Barbados','people-and-society',49,'Population: 239,000 (official estimate for 1 July
1973)
Nationality: noun—Barbadian(s); adjective—
Barbadian
Ethnic divisions: 80% African, 17% mixed, 4%
European
Religion: Anglican, Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1978 est.) wage and salary
earners
Organized labor: 32%','ae2778f5c595bfc9589efa235d13b7323270761d8a47e59a60a50a7f10a17e59','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('139e95189c3c0f1e0dec0771b53ced420abff1c3808f9bef3d2a0f4181e042a8',1976,'BE','Belgium','people-and-society',53,'Population: 9.801,000, average annual growth rate
0.1% (current)
Nationality: noun—Belgian(s); adjective—Belgian
Ethnic divisions: 55% Flemings, 33% Walloons,
{2% mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in
small area of castern Belgium; divided along ethnic
lines
Literacy: 97%
Labor force: 4.0 million: approximately 95% is
found in the following sectors: 32% manufacturing,
24% services, 1696 commerce, banking, and insurance,
8% construction, 7.5% transportation and communi-
cation, 4% agriculture, forestry, and fishing, 1.2%
mining, 0.8% public utilities and sanitary services
(1972); 7.0% unemployed, September 1975
Organized labor: 48% of labor force (1969)','18f587258955779df827bfaa756bfa8d9dd00754c0acfdd177ec59f6055ac1d4','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('950b45cd9c9f20a6ab2c451c2771a874426d46c549bc743198e94d7eec0735d2',1976,'BZ','Belize','people-and-society',58,'Population: 140,000, average annual growth rate
9.9% (4/60-4/70)
Nationality:
Belizean
Ethnic divisions: 51% Negro. 22% mestizo, 19%
Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican,
Seventh-day Adventist, Methodist, Baptist, Jehovab''s
Witnesses, Mennonite
noun—Belizcanís); adjective—
Language: English, Spanish, Maya, and Carib
Literacy: 70% -80%
Labor force: 34,500; 39% agriculture, 14%
manufacturing, 8% commerce, 12% construction and
transport, 20% services, 7% other; shortage of skilled
labor and all types of technical personnel, over 15%
are unemployed
Organized labor; 896 of labor force','178a8a8ac70b04dd0af8d62514f9897f1f37a8b775d30cf1f21d6784e59c888b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('221e89699ae794549373453556938e9a169f8d91c46a863f80ca24710b235585',1976,'BM','Bermuda','people-and-society',62,'Population: 57,000, average annual growth rate
1.6% (1/68-1/74)
Nationality; noun—Bermudan(s);
Bermudan
Ethnic divisions; approximately 63% African, 37%
white
Religion: 47.55; Church of England, 38.2% other
Protestant, 10.2% Catholic, 4.1% other
Language: English
Literacy: virtually 100%
Labor force; 24,855 (1974)
adjective —
- 000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BERMUDA/BHUTAN','eca65e4d5c37d6873364fe3d523feab6b49c3cc3f29fb6b4e29cfd7a663e488d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ebe43b25c3cac1b06cd85c37953c1f7172aea1b5933767fe3568bdde320ad9b',1976,'BT','Bhutan','people-and-society',66,'Population: 1,187,000, average annual growth rate
2.5% (current)
Nationality: noun—Bhutanese
adjective—Bhutanese
Ethnic divisions: 60% Bhotias, 25% ethnic
Nepalese, 15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25% Bud-
dhist-influenced Hinduism
Language: Bhotias speak various Tibetan dialects,
most widely spoken dialect is Dzongkha, the official `
language; Nepalese speak various Nepalese dialects
(sing., pl)
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1%
industry; massive lack of skilled labor','6d0a9b5a0ef09d600ac02880bf5500911fb54084667bb2f7b8f4378ae473e13a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0e22424955adf95d0ef6c3fc92ff441fcc1a4a46721b092e14432df315122d0',1976,'IN','India','people-and-society',70,'Population: 5,480,000, average annual growth rate
2.6% (current)
20
Pacific
Ocean
(See reference mag IIl)
Nationality: noun—Bolivian(s); adjective—
Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35%
mestizo, 5%-15% white
Religion: predominantly Roman Catholic: active
protestant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.5 million (1972); 69.1% agriculture,
3.3% mining, 9.6% services and utilities, 8%
manufacturing, 10% other
Organized labor: 150,000-200,000, concentrated in
mining, industry, construction, and transportation
Population: 607,959,000 (including Sikkim and the
Indian-held part of disputed Jammu-Kashmir),
average annual growth rate 2.596 (current)
Nationality: noun—Indian(s); adjective—Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian,
3% Mongoloid and other
Religion: 88.59; Hindu, 10.7% Muslim, 1.8% Sikh,
2.6% Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or
more persons each; numerous other languages and
dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of
30% of the people; English enjoys "associate" status
but is the most important language for national,
political, and commercial communication; Hindu-
stani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29%
(1971 census)
Labor force: about 184 million, 70% agriculture,
more than 10% unemployed and underemployed;
shortage of skilled labor is significant and
unemployment is rising
Organized labor: about 2.5% of total labor force','75549a97728988e06bb039db94b8c44e2a9580917e795f2a8f7a8fa444d17893','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6daeab0aee15589902ffc0471e6787440b6c0efec6c470d3a8265dba1274b7f',1976,'BW','Botswana','people-and-society',72,'Population: 685,000, average annual growth rate
2.4% (current)
21
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BOTSWANA/BRAZH.
Nationality: noun—Botswana (sing., pl); adiec-
tive— Botswana
Ethnic divisions: 94% ‘Tswana, 5% Bushmen. 1%
Maropean
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in
Tswana: less than 1% secondary school graduates
Labor force: 585,000; most are engaged in cattle
raising and subsistence agriculture; about 51.000 in
internal cash economy, another 60,000 spend at Irast
6 to 9 months per vear as wage carners in South Africa
(1971)
Organized labor: cight trade unions organized with
a total membership of approximately 9,000 (1972 est )','41ce8d530dd79c942ef714032b7eea4c5ff124cc0f1557de284c5150d17b1832','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72ce04e9633fbf82f49b43e9ec2439e4e65975754c61b58384659bf23ebe0b2a',1976,'BR','Brazil','people-and-society',76,'Population: 108,720,000, average annual growth
rate 2.895 (current)
Nationality: noun—Brazilian(s); adjective—
Brazilian
Ethnic divisions: 60% white, 8096 mixed, 8%
Negro, and 2% Indian (1960 est.)
Religion: 9396 Roman Catholic (nominal)
Language: Portuguese
Literacy: 67% of the population 15 years or older
(1970)
Labor force: about 30 million in 1970 (est.); 44.296
agriculture, livestock, forestry, and fishing, 17.896
industry, 15.396
communication, 8.9% commerce, 4.896 social
activities, 3.9% public administration, 5,1% other
services, transportation, and
Organized labor: about 50% of labor force; only
about 1.5 million pay dues
Population: 193,000, average annual growth rate
3,0% (7/67-7/74)
Nationality: noun—British Solomon Islander(s);
adjective—British Solomon Islander
24
A
u
LÍNEAS, $50 00 ss
ae Ne BRITISH SOLOMON
Fox ISLANDS
VS
wae
Coral Sea
Pacific
Ocean
(See reference map VÍ)
Ethnic divisions: 93.0% Melanesians, 4.0%
Polynesians, 1.5% Micronesians, 0.3% Chinese, 0.8%
Europeans, 0.4% others
Religion: almost all at least nominally Christian:
Roman Catholic, Anglican, and Methodist churches
dominant
Literacy: 60%
Population: 157,000, average annual growth rate
3.3% (8/71-7/78)
Nationality:
Bruneian
Ethnic divisions: 52% Malays, 28% Chinese, 15%
indigenous tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8%
Christian; 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
noun—Bruneian(s), adjective—
Approved For Release 2005/04/22
Literacy: 45%
Labor force: 82,155; 30.5% agriculture; 32.8%
industry, manufacturing, and construction; 33.8%
trade, transport, services; 2.996 other
Organized labor: 8.4% of labor force','d646eaab22579bac1568986589473ddfe5bf403f240d95fbe5c60ef9e5317f00','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fffb5e2e2f349f3ab6133d11608dbacb4101595ece3d819b9426710355ea1622',1976,'BG','Bulgaria','people-and-society',80,'Population: 8,773,000, average annual growth rate
0.7% (current)
Nationality:
Bulgarian
Ethnic divisions: 85.3% Bulgarians, 8.59; Turks,
2.6% Gypsies, 25% Macedonians, 0.3% Armenians,
0.2% Russians, 0.6% other
Religion: regime promotes atheism: religious
background of population is 85% Bulgarian
noun—Bulgarian(s); adjective—
26
Orthodox, 13% Muslim, 0.8% Jewish, 0.7% Roman
Catholic, 0.5% Protestant, Gregorian-Armenian and
other
Language: Bulgarian; secondary languages closely
correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.6 million (july 1973); 32%
agriculture, 33% industry, 35% other
COVERNMENT
Legal name: Peoples Republic of Bulgaria
Type: Communist state
Capital: Sofiya
Political subdivisions: 28 okrugs (districts),
including capital city of Sofia
Legal system: based on civil law system, with
Soviet law influence; new constitution adopted in
1971; judicial review of legislative acts in the State
Council; legal education at University of Sofiya; has
accepted compulsory [CJ jurisdiction
Branches: legislative (National Assemblv), Council
of Ministers, judiciary
Government leaders: Todor Zhivkov, Chairman,
State Council (President and chief of state); Stanko
Todorov, Chairman, Council of Ministers (premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 5 years for
National Assembly; last elections held on 27 June
1971; 99.8% of the electorate voted
Political parties and leaders: Bulgarian Com-
munist Party, Todor Zhivkov, First Secretary;
Bulgarian National Agrarian Union, a puppet party,
Petur Tanchev, secretary
Communists: 700,000 party members (April 1971)
Mass organizations and front groups: Fatherland
Front, Dimitrov Communist Youth League, Central
Council of Trade Unions, National Committee for
Defense of Peace, Union of Fighters Against Fascism
and Capitalism, Committee of Bulgarian Women,
All-National Committee for Bulgarian-Soviet
Vriendship
Member of: CEMA, FAO, IAEA, ICAO, ILO,
IMCO, IPU, ITU, Seabeds Committee, U.N.,
UNESCO, UPU, WFTU, WHO, WMO, Warsaw
Pact, International Organization of Journalists,
International Medical Association, International
Radio and Television Organization
Population: 30,782,000, average annual growth
rate 2.3% (7/70-7/73)
Nationality: noun—Burman(s); adjective—Bur-
mese
Ethnic divisions: 72% Burman, 7% Karen, 6%
Shan, 2% Kachin, 2% Chin, 2% Chinese, 3% Indian,
6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese, minority ethnic groups have
their own languages
Literacy: 70% (official claim)
Labor force: 10 million; 67% agriculture, 18%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old labor
organizations have becn disbanded, and government
is forming one central labor organization','b20365797dce6832b0c72636ac89a777b3c72bdc08678ea86acf27caf86ce04d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1335f614eaccd724da69ce33a9bcc52422854135bef4a28d17c9aa025a5fa6d2',1976,'BI','Burundi','people-and-society',84,'Population: 3,823,000, average annual growth rate
2.4% (7/70-7/73)
Nationality: noun— Burundian(s);
Burundian
Ethnic divisions: Africans — 86% Hutu (Bantu),
13% Tutsi (Hamitic), 1% Twa (Pigmy); non- Africans
include (late 1968) 3,000 Europeans, 1,000 Asians
Religion: over 60% Christian (50% Catholic, 10%
Protestant); rest mostly animist plus small number of
Muslims
adjective—
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili,
and 6% in French
Labor force: 1,865,471 (1970 est.)
Organized labor: sole group is the Union of
Burundi Workers (UTB), membership about 30,000,
affiliated with government party','2a955bfc981c5dae9013332c883c4ee779201795620b2f2e739c4a5c44c7ba05','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('664e5b3ee998fc87bc6f94e557acb3ddf847718630e24cd81dbc8081162bf6a6',1976,'KH','Cambodia','people-and-society',88,'Population: 7,718,000, average annual growth rate
2.2% (7/68-7/69)
Nationality: noun—Cambodian(s) or Khmer
(sing., pl.); adjective—Cambodian or Khmer
Ethnic divisions: 89% Khmer (Cambodian), 3%
Vietnamese, 5% Chinese, 3% other minoritics
Religion: 95% Theravada Buddhism, 5% various
other
Language: Cambodian
29
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
CAMBODIA/CAMEROON
Literacy: 5596 (est.)
COVERNMENT
Type: authoritarian government controlled by the
Khmer Communist Party
Capital: Phnom Penh
Legal system: no post-war data available although
system of "people''s tribunals” reported
Government leader: nominal "head of state" is
Prince Sihanouk; Communist leaders exercise real
power
Political parties and leaders: political life
dominated by Khmer Communist Party and panoply
of mass front organizations
Communists: party strength about 10,000
Other political or pressure groups: none
Member of: replaced former government in United
Nations General Assembly in October 1975','456204feed4239eff732bc3b3d4784127716fd800a54d83356a8d5ef6d20173b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed09934f20ed079f82b239fc9c209a5615d7db42b683bda3e330871084fa234e',1976,'GN','Guinea','people-and-society',90,'Population: 6,464,000, average annual growth rate
2.1% (current)
Nationality: noun—Cameroonian(s); adjective—
Cameroonian
Ethnic divisions: about 200 tribes of widely
differing background; 31% Cameroon Highlanders,
19% Equatorial Bantu, 8% Northwestern Bantu, 10%
Fulani, 7% Eastern Nigritic, 11% Kirdi, 13% other
African, less than 1% non-African
Religion: about one-half animist, one-third
Christian; rest Muslim
Language: English and French official, 24 major
African language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in
subsistence agriculture and herding; 200,000 wage
earners (maximum) including 22,000 government
employees, 63,000 paid agricultural workers, 49,000 in
manufacturing
Organized labor: under 45% of wage labor force
Population: 22,963,000, average annual growth
rate 1.3% (7/69-7/74)
Nationality: noun--Canadian(s);
Canadian
Ethnic divisions; 449; British Isles origin, 30%
French origin, 26% other
Religion: 485; Protestant, 47% Catholic, 5% other
Language: English and French official
Labor force: 84 million; 29%
manufacturing, 16% trade, 8% transportation and
utilities, 6% agriculture, 6% construction, 8%
7.2% unemployed
Organized labor: 27% of labor force
Population: 4,474,000, average annual growth rate
2.5% (current)
Nationality:
Guinean
Ethnic divisions: 99% African (8 major tribes —
Fulani, Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less
than 1%
Language: French official; each tribe has own
language
Literacy: 5% to 10%; French only significant
written language
Labor force: 1.8 million, of whom less than 10%
are wage earners; most of population engages in
subsistence agriculture
Organized labor: virtually 100% of wage labor
force loosely affiliated with the National Confedera-
tion of Guinean Workers, which is closely tied to the
PDG
Population: 4,351,000, average annual growth rate
2.2% (7/67-7/69)
Nationality: noun—Senegalese (sing. & pl);
adjective—Senegalese
Ethnic divisions: 36% Wolof, 17.5% Fulani, 16.5%
Serer, 9% Tukulor, 9% Dyola, 6.5% Malinke, 4.5%
other African, 1% Europcans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian
(mostly Roman Catholic)
Language: French official, but regular use limited
to literate minority; most Senegalese speak own tribal
language; use of Wolof vernacular spreading — now
spoken to some degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence
agricultural workers; about 125,000 wage earners
Organized labor: majority of wage-labor force
represented by unions; however, dues-paying
membership very limited','af605fc62994785c34d7299d90982f53a448224552ca623a9bba250ef7b4d222','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61a3c77112d3d45809e90ac504185c61ef9b8cf28ed9d46a343ee802266e7002',1976,'CA','Canada','people-and-society',95,'Population: 291,000 (official estimate for 1 July
1974)
Nationality: adjective—Cape Verdian
Ethnic divisions: about 28% African; 70%
mulatto; 2% European
Religion: Catholicism, fused with local supersti-
tions
Language: Portuguese and crioula, a blend of
Portuguese and West African words
Literacy: 14%
Labor force: bulk of population engaged in
subsistence agriculture','4482ae7c824cc009ea28f7c69234f0cb847c4db47be8f41e83322dc9e1d04547','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('973dbc410a28c45a5b5f812a152b3daf6ec18ab216f393063208da752023ec1e',1976,'CF','Central African Republic','people-and-society',97,'Population: 1,806,000, average annual growth rate
2.2% (7/67-7/71)
Nationality: noun—Central African(s); adjective—
Central African
Ethnie divisions: approximately 80 ethnic groups,
the majority of which have related ethnic and
linguistic characteristics; Banda (32%) and Baya-
Mandjia (29%) are largest single groups; 6,500
Europeans, of whom 6,000 are French and majority of
the rest Portuguese
Religion: 40% Protestant, 28% Catholic. 27%
animist, 5% Muslim; animistic beliefs and practices
strongly influence the Christian majority
Language: French official; Sangho, the lingua
franca and unofficial national language
Literacy: estimated at 5%-10%
Labor force: about half the population economi-
cally active, 80% of whom are in agriculture;
approximately 64,000 salaried workers
Organized labor: 1% of labor force','6649f9f231c1e4aab3d9d0782f506c434df9f33db00a1c29c5b6dd22c3c58a7d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13f489278bdef7828d2638cae94903c10b1cfa989756cf94ce02e9f1870b45d1',1976,'TD','Chad','people-and-society',101,'Population: 4,072,000, average annual growth rate
2.1% (7/72-7/74)
Nationality: noun—Chadian(s); adjective—
Chadian
Ethnic divisions: over 240 tribes representing 12
major ethnic groups — Muslims (Arabs, Toubou,
Fulani, Kotoko, Hausa, Kanembou, Baguirmi,
Boulala, and Wadai) in the north and center and non-
Muslims (Sara, Mayo-Kebbi, and Chari) in the south;
some 150,000 nonindigenous, 5,000 of them French
Religion: about half Muslim, 5% Christian,
remainder animist
Language: French official; Chadian Arabic is
lingua franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in
economically active group, of which 9076 arc engaged
in unpaid subsistence farming, herding, and fishing;
47,000 wage earners in industry and civil service
Organized labor: about 20% of wage labor force','1b231dacdf09ea3865d20e6b2800624e4c9b47d93d3b5a83207dcab22c5736de','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb2a00019b410caaf7fe36748fecf4e75d8d72f6042ce607ededdf238b268701',1976,'CL','Chile','people-and-society',105,'Population: 10,675,000, average annual growth
rate 1.7% (7/73-7/74)
Nationality: noun—Chilcan(s); adjective— Chile-
an
Ethnic divisions: 959; European stock and mixed
European with some Indian admixture, 3% Indian,
2% other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 89%
Labor force: 3.3 million (1973); 19% agricultural,
28% industry and construction, 29% services, 14%
commerce, 5% mining. 5% other (1973)
Organized labor: 25% of labor force (1973)
Population: 953,107,000, average annual growth
rate 2.4% (current)
Nationality: noun—Chinese (sing., pl); adjec-
tive—Chinese
Ethnic divisions: 94% Han Chinese; 6% Chuang,
Uighur, Hui, Yi, Tibetan, Miao, Manchu, Mongol,
Pu-T, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have heen
pragmatie and eclectic, not seriously religious; most
important clements of religion are Confucianism,
Taoism, Buddhism, ancestor worship; about 295-39;
Muslim, 1% Christian
38
Approved For Release 2005/04/22
Language: Chinese (Mandarin mainly; also
Cantonese, Wu, Fukienese, Amoy, Hsiang, Kan,
Hakka dialects), and minority languages (see ethnic
divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85%
agriculture, 15% other; shortage of skilled labor
(managerial, technical, mechanics, ete. ): surplus of
unskilled labor','522eeb6a0e493d89393fbc6468ef97ab8578e1bcca3dee382aaa461e8f17a5c2','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c4cb57e39ea338cc72c64f929c07ee3e7b4bece72a206dc6193eef780734fb6',1976,'CN','China','people-and-society',109,'Population: 15,982,000 (excluding the population
of Quemoy and Matsu Islands and foreigners),
average annual growth rate 1.8% (1/74-1/75)
Nationality: noun—Chinese (sing., pl) adjec-
tive—Chinese
Ethnic divisions: 84% Taiwanese, 14% mainland
Chinese, 296 aborigines
Religion: 93% mixture of Buddhism, Confucian-
ism, and Taoism; 4.5% Christian; 2.5% other
Language: Chinese Mandarin (official language),
also Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 4.9 million; 33% primary industry
(agriculture), 32.1% secondary industry (including
manufacturing, mining, construction), 34.9% tertiary
industry (including commerce and services) 1972
Organized labor: about 12% of 1972 labor force
(government controlled)','340ae3b7f0e38f0f0e411a33fac013cfeb6671197901a255b7aadd1d16a73682','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39e41556ed70c021059bc76c2dfb67dea581c47bf34dd797c482d5d4d539e91b',1976,'CO','Colombia','people-and-society',113,'Population: 22,549,000, average annual growth
rate 3.1% (current)
Nationality: noun—Colombian(s);
Colombian
adjective—
Ethnic divisions: 589; mestizo, 20% caucasian,
14% mulatto, 4% Negro, 3% mixed Negro-Indian, 1%
Indian
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture,
13% manufacturing, 18% services, 9% commerce,
1396 other (1964)
Organized labor: 13% of labor force (1968)
Population: 310,000, average annual growth rate
2.5% (current)
Nationality:
Comoran
noun—Comoran(s); adjective—
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor Force: mainly agricultural','4d5f79aa88bebcd5375770a104ec16aeb5a9e349de5f4b03c580b391dffc3a8d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('590d898a33e8a4d8f4314f9739f592ed9336c23f2290fbed1c15981a73b51e9d',1976,'CG','Congo','people-and-society',117,'Population: 1,364,000, average annual growth rate
2.6% (current)
Nationality: noun—Congolese (sing., pl.); adjec-
tive—Congolese or Congo
Ethnic divisions: about 15 ethnic groups divided
into some 75 tribes, almost all Bantu; most important
ethnic groups are Kongo (48%) in south, Teke (17%)
in center, M’ Bochi (12%) and Sangha (20% ) in north;
about 8,500 Europeans, mostly French
Religion: about half animist, half nominally
Christian, less than 1% Muslim
Language: French official, many African lan-
guages with Lingala and Kikongo most widely used
Literacy: about 20%
Labor force: about 4076 of population economi-
cally active, most engaged in subsistence agriculture;
79,100 wage earners; 40,000-60,000 unemployed
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Organized labor: 16% of total labor force (1965
est.)','dc7a0bd86653bab64295dd844affcf7e82b4a7b8e63b302a7c4272c6c1760f9a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba35dc360ae4e1e190f0c4861ac8e0fd879f3d4e5699e1b73d63a3d7c50bfa0a',1976,'CK','Cook Islands','people-and-society',121,'Population: 19,000, officia] estimate for 30 June
1974
Nationality; noun— Cook Islander(s); adjective —
Cook Islander
Ethnic divisions: 81.3% Polynesian (full blood),
7.7% Polynesian and European, 7.7% Polynesian and
other, 2.4% European, 0.9% other
Religion: Christian, majority of populace members
of Cook Islands Christian Church','340cc055aec4790c1b5bb2fa36753cd857d6800dc0904c498290ce3efb07742b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('842a6559d4c23923add945c189641b9c1acd10f3dc40ccb0c4421fcf463fe672',1976,'CR','Costa Rica','people-and-society',125,'Population: 1,997,000, average annual growth rate
2.6% (1/78-1/74)
Nationality: noun—Costa Rican(s); adjective—
Costa Rican
Ethnic divisions: 98% white (including mestizo),
2% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 85%
Labor force: 585,000 (1973); 36% agriculture; 12%
manufacturing; 11% commerce; 6% construction; 5%
Approved For Release 2005/04/22
transportation, utilities; 20% service (government,
education, social); 2% finance; 8% other
Organized labor: about 11.5% of labor force
Population: 9,337,000, average annual growth rate
1.8% (current)
Nationality: noun—Cubanís); adjective—Cuban
Ethnic divisions: 51% mulatto, 37% white, 11%
Negro, 1% Chinese
Religion; at least 85% nominally Roman Catholic
before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.36 million; 34% agriculture, 17%
industry, 6% construction, 6% transportation, 29%
services, 8% unemployed and underemployed
Organized labor: 46% of total force','1490859a0f35efbdbc18b7c042e318f275e4861c6d38d248f180c32e61fe8e7f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3661b4fb151270db698dca259becf18ea9d55485d7535efd041a959d004df2c3',1976,'CY','Cyprus','people-and-society',129,'Population: 652,000, average annual growth rate
1.1% (7/78-7/74)
Nationality: noun—Cypriot(s); adjective—Cypriot
Ethnic divisions: 78% Greck; 18% Turkish: 4%
British, Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4%
Masonite Armenian Apostolic and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Labor force: 267,000 (1970 est.), 389; agriculture,
23% industry, 9% commerce, 2% mining, 28% other;
3,130 registered unemployed (December 1968)
Organized labor: 24% of labor force
Population: 14,866,000, average annual growth
rate 0.8% (current)
Nationality: noun—Czechoslovak(s); adjective—
Czechoslovak
Ethnic divisions: 64.3% Czechs, 30.0% Slovaks,
4.0% Magyars, 0.6% Germans, 0.5% Poles, 0.4%
Ukrainians, 0.2% others (Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant,
2% Orthodox, 1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.1 million; 18% agriculture, 37%
industry, 11% services, 34% construction, com-
munications and others
Population: 3,148,000, average annual growth rate
2.8% (8/72-8/74)
Nationality: noun—Dahomeanís); adjective—
Dahomean
Ethnic divisions: 99% Africans (42 ethnic groups,
most important being Fon, Adja, Yoruba, Bariba),
5,500 Europeans
Religion; 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most
common vernaculars in south, at least 6 major tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in
agriculture; 15% civil service, artisans, and industry
Organized labor: approximately 75% of wage
earners, divided among two major and several minor
unions','4911626d916c42d0b8396d6494764017bb0a056883329dcc46e7b2e6a2e995f7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4152e33bfaf9a63f4e75df3c986881242297f1ad4c2a82b4ffafd6a4951dd555',1976,'DK','Denmark','people-and-society',133,'Population: 5,075,000, average annual growth rate
0.4% (current)
Nationality: noun—Dane(s): adjective—Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other
Protestant and Roman Catholic, 19; other
Language: Danish; small German-speaking
minority
Literacy: 9995
Labor force: 2.5 million; 9.5% agriculture, forestry,
fishing, 26.6% manufacturing, 8.3% construction,
15.7% commerce, 6.8% transportation, 5.6% services,
25.7% government, 1.8% other; 6.3% of registered
labor force unemployed (September 1974)
Organized labor: 65% of labor force
Population: 2,000 (preliminary total from the
census of 3 December 1972)
The possession of the Falkland Islands has been dis-
puted by the U.K. and Argentina (which refers to them
as the Malvinas) since 1833.
Approved For Release 2005/04/22
Nationality: noun—Falkland Islander(s); adjec-
tive—Falkland Island
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est); over 95% (est) in
agriculture, mostly shepherding
Population: 56,076,000, average annual growth
rate 0.0% (current)
Nationality: noun—Briton(s), British (collective
pl.); adjective—British
Ethnic divisions: 83% English, 9% Scottish, 5%
Welsh, 3% Irish
Religion: 27.0 million Church of England, 5.3
million Roman Catholic, 2.0 million Presbyterians,
760,000 Methodist, 450,000 Jews (registered)
Language: English, Welsh (about 26% of
population of Wales), Scottish form of Gaelic (about
100,000 in Scotland)
Literacy: 98% to 99%
Labor force: 25 million: 3% agriculture, 2%
mining, 35% manufacturing, 6% government, 8%
transportation and utilities, 6% construction, 11%
in Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
el
Approved
p For Release 2005/04/22 : CIA-RDP79-01051A000800010
001-8
January 1976
distributive trades, 23% services, 3% other; 3%
unemployed
Organized labor: 40% of labor force','ed193f152f268ff48f16cf8b1c2456306155dba5b574e780d6ff8cb89bb8d951','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3215b2b5f1308aab3f9ac41d3634f40b5d9bc72f11b49da6cb19ae342933bd9',1976,'DM','Dominica','people-and-society',137,'Population: 77,000, average annual growth rate
1.6% (4/60-4/70)
Nationality: noun— Dominican(s); adjective—
Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England,
Methodist
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture
Organized labor: 25% of the labor force','fbcd5d281f9ed01a73a28bfc8f0faa18f75951b820954e5bcb0639b7a7c4a0b9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12e5ad99ba2c996346476a109423747b26e04b63b810fdbf31337edc0d369477',1976,'DO','Dominican Republic','people-and-society',141,'Population: 4,766,000, average annual growth rate
2.9% (7/73-7/74)
Approved For Release 2005/04/22
tia
Devan
DOMINICAN
: M s Lig
Sia 58
(See reference map Ht)
Nationality: noun—Dominican(s); adjective—
Dominican
Ethnic divisions: 73% mulatto, 16% white, 11%
Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 million; 73% agriculture, 8%
industry, 19% services and other
Organized labor: 12% of labor force','137ec6ad418f4cbc88c3cb88dfb2bc79cde96642db1fff47f2400018974051b9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddf550cde2e75bd0f840064b30c9c0e2de5239b12020afc6f1675b5025f98ffb',1976,'EC','Ecuador','people-and-society',145,'Population: 6,804,000 (excluding nomadic Indian
tribes), average annual growth rate 2.9% (11/62-6/74)
Nationality: noun—Ecuadorean(s); adjective—
Ecuadorean
55
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Ethnic divisions: 40% mestizo, 40% Indian, 109;
white, 5% Negro, 5% Oriental and other
Religion: 959 Roman Catholic (majority
nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture,
13% manufacturing, 4% construction, 7% commerce,
4% public administration, 16% other services and
activities
Organized labor: less than 15% of labor force
Population: 37,714,000, average annual growth
rate 2.3% (current)
Nationality: noun—Egyptian(s); adjective—
Egyptian or United Arab Republic
Ethnic divisions: 90% Eastern Hamitic stock; 10%
Greek, Italian, Syro- Lebanese
Religion: (official estimate) 9476 Muslim, 6% Copt
and other
Language: Arabic official, English and French
widely understood by educated classes
Literacy: around 40%
Labor force: 8 to 12 million; 4596 to 5096
agriculture, 10% industry, 10% trade and finance,
30% services and other; shortage of skilled labor
Organized labor: 1 to 3 million','1aaa29747ed10608e3c912d3dc8e0fa1dac10f0ad945c982639c87f4aa624b64','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23ff12cac998158e143f565a0f549e0ccf9345a633693fee1a7a1a14d8177914',1976,'SV','El Salvador','people-and-society',149,'Population: 4,161,000, average annual growth rate
3.0% (7/73-7/74)
Nationality: noun—Salvadoranís);
Salvadoran
Ethnic divisions: 84%-88% mestizo; Indian and
white minorities, 6%-8% each
Religion: predominantly Roman Catholic,
probably 97%-98%
Language: Spanish
adjective—
Literacy: 50% of population 10 years of age and
over (1973 est.)
Labor force: 1,395,000 (est. 1973); 57% agricul-
ture, 14% services, 14% manufacturing, 6%
commerce, 9% other; shortage of skilled labor and
large pool of unskilled labor, but manpower training
programs improving situation
Organized labor: 3.5% of total labor force; 6.6% of
nonagricultural labor force (1972 est.)','53059bcd8ddfa1e48cf222d85e5b5f71947a933d0d41a7b1be4ac335d1e47cc1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6505d59f4b2f9aad2af015d8f3e27d578df0b09c20245bb61524c479b434ab77',1976,'GQ','Equatorial Guinea','people-and-society',153,'Population: 321,000, average annual growth rate
1.8% (7/68-7/69); Rio Muni, 227,000, average
annual growth rate 1.596 (7/68-7/69); Fernando Po,
59
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
EQUATORIAL GUINEA/ETHIOPIA
94,000, average annual growth rate 2.6% (7/68-7/69)
Nationality: noun—Equatorial Guinean(s); adjec-
tive—Equatorial Guinean
Ethnic divisions: indigenous population of
Province Francisco Macias Nguema primarily Bubi,
some Fernandinos; of Rio Muni primarily Fang; less
than 1,000 Europeans, primarily Spanish
Religion: natives all nominally Christian. and
predominantly Roman Catholic; some pagan
practices retained
Language: Spanish official language of govern-
ment and business; also pidgin English, Fang
Literacy: 12% (est.)
Labor force: most Equatorial Guineans involved in
subsistence agriculture','a80c30524774c473507530917cda03991b455677b1d372672358ff8bb6568c4f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca97df103af706e1ba8a15347300b99325b226f20b951f86e6db306636ff9178',1976,'ET','Ethiopia','people-and-society',157,'Population: 28,302,000, average annual growth
rate 2.6% (7/73-7/74)
Nationality: noun—Ethiopian(s);
Ethiopian
Ethnic divisions: Galla 40%, Amhara and Tigrai
32%, Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%,
Gurage 2%, other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45%
Muslims, 15%-20% animist, 5% other
Language: Amharic official; many local languages
and dialects; English major foreign language taught
in schools
Literacy: about 5%
Labor force: 90% agriculture and animal
husbandry; 10% government, military, and quasi-
Population: 40,000, average annual growth rate
0.9% (4/66-11/70)
Nationality: noun—Faeroese (sing., pl); adjec-
tive—Faeroese
Ethnic divisions; homogeneous white population
Religion; Evangelical Lutheran
62
Languages: Faeroese (derived from Old Norse),
Danish
Literacy: 99%
Labor force; 15,000; largely engaged in fishing,
manufacturing, transportation, and commerce','f8302ff60247a7885f4050e94b5ff04d83c720d98c316f4847b26094b90fc7f3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae5597d5a6f28fe32a12d7dd0c4c4a18adff2e220eefcba308113e01c5ed5b54',1976,'FJ','Fiji','people-and-society',161,'Population: 575,000, average annual growth rate
1.8% (7/71-7/74)
Nationality: noun—Fijian(s); adjective—Fijian
Ethnic divisions: 42% Fijian, 50% Indian, 8%
European, Chinese and others
Religion: Fijians mainly Christian, Indians are
Hindu with a Muslim minority
Language: English and Fijian (official), Hindu-
stani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no
breakdown on remainder
Organized labor: about 50% of labor force
organized into 22 unions; unions organized along lines
of work, breakdown by ethnic origin causes further
fragmentation','19ba8500681130e48bc10b2c86f1957c63dbd6ee24eefde36324e249b87609d7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('137a15baca4712f47b61bbb27441099f1d43e8a9107cf8698dc45cd531deebe0',1976,'FI','Finland','people-and-society',165,'Population: 4,715,000, average annual growth rate
0.4% (7/74-7/75)
Nationality: noun—Finn(s), adjective—Finnish
Ethnic divisions: homogeneous white population,
small Lappish minority
Religion: 939; Evangelical Lutheran, 1% Greek
Orthodox, 1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp-
and Russian-speaking minorities
Literacy: 9996
Labor force: 2.2 million; 16.6% agriculture,
forestry, and fishing, 26.4% mining and manufactur-
ing, 8.4% construction, 15.4% commerce, 6.8%
transportation and communications, 4.0% banking
and finance, 20.1% services; 1.8% unemployed
Organized labor: 60% of labor force','97766d2eacc4838a2eb944641524ca0ce69d096203aeb514a221d550e8c45fcf','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a76831d7903cca214b08742616b9d67fa0adbf127d649a1b6b33d7a46e760c4',1976,'FR','France','people-and-society',169,'Population: 53,095,000, average annual growth
rate 0.8% (1/70-1/75)
Nationality: noun— Frenchman (men); adjective—
French
Ethnic divisions: 45% Celtic; remainder Latin,
Germanic, Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish,
1% Muslim (North African workers), 13% unaffiliated
Language: French (100% of population); rapidly `
declining regional patois — Provencal, Breton,
Germanic, Corsican, Catalan, Basque, Flemish
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
anal Ó——Á—ÀMÓ—
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Literacy: 97%
Labor force: 21,900,000 (est. in October 1974);
47% services, 39% industry, 12% agriculture, 2%
unemployed
Organized labor: 17% of labor force, 23.4% of
salaried labor force','6f7c82ff621aaf299a97939ef3b693f069423a320977819d2584e2e09e38d2fc','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('047a751369752d3e07c27404864dc32d58e15301c0345f17138f22c48075e04a',1976,'GF','French Guiana','people-and-society',173,'Population: 55,000, average annual growth rate
2.4% (7/68-7/73)
Nationality: noun— French Guianese (sing., pl.);
adjective— French Guiana
Ethnic divisions: 95% Negro or mulatto, 5%
caucasian, 10,000 East Indian, Chinese
68
Approved For Release 2005/04/22 :
B
Atlantic Ücean
FRENCH
GUIANA
(See reference map fit}
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%,
construction 21%, agriculture 18%, industry 8%,
transportation 495; information on unemployment
unavailable
Organized labor: 7% of labor force','609a372c34f77e289f8736bf938d52a33150cbd00dfc01a7c309485acf2a4f2e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ede50ebb413d88fc9aee1cfd570f8df06ec03b00cc8dee03a7faf1f8264401de',1976,'PF','French Polynesia','people-and-society',177,'Population: 120,000 official estimate for 1 July
1973
Nationality; noun—French Polynesian(s); adjec-
tive— French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chinese,
6% local French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 3276
Catholic
Population: 125,000 (official estimate for 1 July
1967)
Nationality: noun—Afar(s), Issa(s); adjective—
Afars, Issas
Ethnic divisions: (approximate figures) 59,350
Somalis, mostly Issas (large number of the Somalis are
70
temporary immigrants from Somalia, not citizens of
territory), 53,650 Afars, 6,000 Arabs, 7,000 French
(inclusive of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely
used
Literacy: about 5%
Labor force: a small number of semiskilled laborers
at port
Organized labor: some 3,000 railway workers
organized
Organized labor: unorganized
148
Population: 97,000, average annual growth rate
2.6% (7/68-7/74)
Nationality: noun—New Hebridean(s); adjec-
tive—New Hebrides
Ethnic divisions: 92% indigenous Melanesian, 3%
European, remainder Vietnamese, Chinese, and
various Pacific Islanders
Religion: most at least nominally Christian
Literacy: probably 1096-2096','ea632e2f39e5a2be38bc4cfcb08c5c53f0a6e54da3f74bbc4403b741c2c40ac1','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8023c58468e397a3d7540662c97f39128c770d93cd0def474fe1a834cc96b0b5',1976,'GA','Gabon','people-and-society',181,'Population: 548,000, average annual growth rate
1.7% (7/66-7/70)
Nationality: noun—Gabonese (sing., pl); Gabo-
nese
Ethnic divisions: about 40 Bantu tribes, including
4 major tribal groupings (Fang, Eshira, Mbede,
Okande); about 21,000 expatriate Africans and
Europeans, including 14,000 French
Religion: 55% to 75% Christian, less than 1%
Muslim, remainder animist
Language: French official language and medium
of instruction in schools; Fang is a major vernacular
language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are
wage carers in the modern sector
Organized labor: less than 30% of wage labor force','c6358de02ad1a2d7f3547294fcd13d70405d6ff4334850b0d17094d28cfb13d8','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('942ee2c3593555e5410914c94afdf7582d9b6882fa25b90c343b5b39f8534815',1976,'GM','Gambia','people-and-society',185,'Population: 529,000, average annual growth rate
2.5% (7/68-7/74)
Nationality:
Gambian
Ethnic divisions: over 99% Africans (Malinke
40.8%, Fulani 18.5%, Wolof 12.9%, remainder made
up of several smaller groups), fewer than 1%
Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Malinke and Wolof
most widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in
subsistence farming; about 15,000 are wage earners
(government, trade, services)
Organized labor: 25% to 30% of wage labor force
at most
Population: 16,866,000 (including East Berlin),
average annual growth rate — 0.2% (current)
Nationality: noun—Germanís); adjective—Ger-
man
Ethnic divisions: 99.7% German, 3% Slavic and
other
Religion: 53% Protestant, 8% Roman Catholic,
39% unaffiliated or other, less than 5% of Protestants
and about 25% of Roman Catholics actively
participate
Language: German, small Sorb (West Slavic)
minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7%
handicrafts; 6.8% construction, 11.9% agriculture;
6.8% transport and communications; 10.1%
commerce; 16.8% services; 2.5% other
Organized labor: 87.7% of total labor force
Population: 62,989,000 (including West Berlin),
average annual growth rate 0.2% (current)
Nationality: noun—German(s); adjective—Cer-
man
Ethnic divisions: 99% Germanic, 195 other
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GERMANY, WEST
p" nien "x iV
Religion: 49% Protestant, 44.6% Roman Catholic,
6.4% other
Language: German
Literacy: 99%
Labor force: 26.7 million; 44.1% in manufacturing
and construction, 15.2% services, 12.8% commerce,
8.2% government, 7.2% agriculture, 5.4% com-
munication and transportation, 1% mining; 2.6%
average unemployed as of 1974, excluding self
employed
Organized labor: 31% of total labor force; 37.5% of
wage and salary earners','30b8c1126ed316b9a49a87d1ba9497a779d4c51960e77a39c75c1e220d72d3ee','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3299e25296bfca871d0498ce55eb9d6e9db1c2e40bd9537e425c70da9cdee068',1976,'GH','Ghana','people-and-society',189,'Population: 10,017,000, average annual growth
rate 2.8% (7/72-7/74)
Nationality: noun—Ghanaian(s); adjective—
Ghanaian
Ethnic divisions: 99.8% Negroid African (major
tribes Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12%
Muslim
Language: English official; African languages
include Akan 44%, Mole-Dagbani 16%, Ewe 13%,
and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and
fishing, 16.8% industry, 15.2% sales and clerical, 4.1%
services, transportation, and communications, 2.9%
professional; 400,000 unemployed
Organized labor: 350,000 or approximately 10% of
labor force','6ebd41a89fb936f64e787e7bd5a448c5010d2dba142230299d91602858349b0e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42b56352794275b6222e2dfd5f0b66e6350d1edadc4c391a94de7172f9bca991',1976,'GI','Gibraltar','people-and-society',193,'Population: 30,000 (official estimate for 1 July
1973)
Nationality: noun—Gibraltarian(s); adjective—
Ethnic divisions: mostly Italian, English, Maltese,
Portuguese and Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary
languages; Italian, Portuguese, and Russian also
spoken, English used in the schools and for all official
purposes
TT
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
0001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00080001
January 1976
CIBRALTAR/GILBERT AND ELLICE ISLANDS
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-
Gibraltarian laborers
Organized labor: over 6,000','7b5264fec3a134ad5326a341a475558709e487a3f9b28d45dda6226c4879e160','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dfa5eaf0ef757174f235055efb39fcb9e76ec01a2156735a49b27222f489924',1976,'NL','Netherlands','people-and-society',198,'Population: 67,000, average annual growth rate
2.5% (7/68-7/73)
Nationality: noun—Gilbertese, Ellis Islander(s) or
Gilbert and Ellis Islander(s); adjective —Gilbertese,
Ellis Islander, or Gilbert and Ellis Islander
Ethnic divisions: 83.9% Micronesian, 13.9%
Polynesian, 0.9% European, 0.1% Chinese, 1.2%
mixed and other races
Religion: mainly Christian; 55% Protestants, 42%
Catholics
Literacy: less than 50%
Population: 13,715,000, average annual growth
rate 0.9% (current)
Nationality: noun—Netherlander(s); adjective—
Ethnic divisions: 99% Dutch, 1% Indonesian and
other
Religion: 41% Protestant, 40% Roman Catholic,
1996 unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9%
construction, 7% transportation and communications,
4% other; 4.8% unemployment (August 1975)
Organized labor: 33% of labor force
Population: 241,000, average annual growth rate
1.5% (1/74-1/75)
Nationality: noun— Netherlands Antillean(s);
adjective—Netherlands Antillean
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NETHERLANDS ANTILLES
Atlantic Ocean
REX "
po cy ''
, Garibbean NETHERLANDS . *
mecs < ANTILLES
E
‘Sea reference map If,
Ethnic divisions: 85% largely ined Neuro stock
except on Aruba where 12% Negro and approx. 55%
mixed Carib Indian and European; rest European
with some Chinese, especially on Aruba
Religion: predominantly Roman Catholic; sizable
Protestant, smaller Jewish minorities
Language: officially Dutch; predominantly
English; colloquial "papiamento," a Spanish-
Portuguese-Dutch-English mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 21% industry,
21% unemployed, 8% construction, 41% government
and services, 8% other
Organized labor; approx. 15% of labor force','27569042ddbd592bc2c0a9b06df2939a2bb817bc72bc82e73ac553aaf3590c67','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cfa4de6cf79a5a1ab69b1d914ef1bfabc22cc3650768715d47818f220c7847b',1976,'GR','Greece','people-and-society',201,'Population: 9,026,000, average annual growth rate
0.5% (7/70-7/74)
Nationality: noun—Greek(s); adjective—Greek
Ethnic divisions: 96% Greek, 2% Turkish, 1%
Albanian, 1% other
Religion: 97% Greek Orthodox, 2.5% Muslim,
0.596 other
Language: Greek; English and French widely
understood
Literacy: males about 92%; females about 7396;
total about 82%
Labor force: 3,866,000 (1969 est.); 5096 agricul-
ture, 15% industry, 9% trade, 26% other; unemploy-
ment and underemployment, 20% total in all fields;
shortage of skilled labor in nonagricultural sectors
aggravated by large-scale emigration
Organized labor: 10% of labor force','5e3eaecc2a3374a27a59d0878b8ecb48cc2da60d5ba7dba91c36a3a26c71b313','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c10045636231ddc4582347f2372404971c8b91580f18a7d4ac910731eb08848c',1976,'GL','Greenland','people-and-society',205,'Population: 51,000, average annual growth rate
1.6% (1/72-1/74)
Nationality: noun—Greenlander(s); adjective—
Ethnic divisions: 86% Greenlander (Eskimos and
Greenland-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and
sheep breeding','f4b47925b0a7d62d1814e9c4d558d9e37051b32424838d1d16a3aa27f2130eee','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('818cbcebeaa0344f5d701f446cd78272b030cbcaf026e7594ef23c85abe3fc04',1976,'GD','Grenada','people-and-society',209,'Population: 98,000, average annual growth rate
0.6% (4/60-4/70)
Nationality: noun—Grenadian(s); adjective—
Grenadian
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant
sects; Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30%
unemployed or underemployed
Organized labor: 33% of labor force','2b122fda2aa84a037debc865f24207275ad38a6d03c36393a5fde62ae4687eea','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6081a9c43d6f9ea26e6b2c6df0c4de5250126b72f7d236af2b20289b6e2de4b9',1976,'GP','Guadeloupe','people-and-society',213,'Population: 355,000, average annual growth rate
1.5% (7/72-7/78)
Nationality: noun—Guadeloupian(s); adjective—
Ethnic divisions: 90% Negro or Mulatto, less than
5% East Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and
pagan African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25%
unemployed
Organized labor: 11% of labor force','2c7faa47ae24755453d19841765834c38ba2e75f7b9f305f9294130c65a1919d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edf7af881bd20d885aee63da4a8fa42cb45c18ec31a0b183630f9d570c036d35',1976,'GT','Guatemala','people-and-society',219,'Population: 5,934,000, average annual growth rate
2.8% (7/72-7/73)
Nationality: noun—Guatemalan(s) adjective—
Guatemalan
Ethnic divisions: 41.4% Indian, 58.6% Ladino
(mestizo and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the
population speaks an Indian language as a primary
tongue
Literacy: about 30%
Labor force (1974): 1.75 million; 6596 agriculture,
11.3% manufacturing; 11.2% services, 6.4% to
commerce, 2.6% construction, 2.4% transport, 0.2%
mining, 0.2% electrical, 0.8% other. Unemployment
estimates vary from 3 to 25%
Organized labor: 4% of labor force (1974)','860bce3285140c431575c7c7d5021101dce74c7fd64e46e90278bf28bd8f9aab','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('482740fa57352f3fcfb02e797aeaa3ec53ad1c1af8693d3b1220587f56188998',1976,'GW','Guinea-Bissau','people-and-society',223,'Population: 509,000, average annual growth rate
1.896 (current)
Nationality:
Guinean
Ethnic divisions: about 99% African (Balanta 80%,
Fulani 20%, Mandyako 14%, Malinke 13%, and 23%
other tribes); Jess than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese and numerous African
languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in
subsistence agriculture','2b8ee03e4fdcc921df3dde33c34cb0fdffe406e4eaebb27788551e39752e6114','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6718ca2194475a5c8d58e5596de775cc6a9d0913c2ba157a89632eea069baa8e',1976,'GY','Guyana','people-and-society',227,'Population: 800,000, average annual growth rate
2.2% (current)
Nationality; noun—Guyanese (sing., pl.); adjec-
tive—Guyanese
Ethnic divisions: 51% East Indians, 43% Negro
and Negro mixed, 4% Amerindian, 2% white and
Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim,
1% other
Language: English
Literacy: 86%
Labor force: 201,000; about 25% agriculture, 14%
manufacturing, 16% services, 11% commerce, 396
mining and quarrying, 10% other; 21% unemployed
Organized labor: 34% of labor force
Population: 4,615,000, average annual growth rate
1.7% (8/73-8/74)
Nationality: noun—Haitian(s); adjective—Haitian
Ethnie divisions: over 90% Negro, nearly 10%
mulatto, few whites
Religion: 10% Protestant, 75% to 80% Roman
Catholic (of which an overwhelming majority also
practice Voodoo)
Language: French (official) spoken by only 10% of
population; all speak Creole
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
E es
January 1976
Approved Fo
r Release 2005/04/22 : CIA-RDP79-01051A0008
- 00010001-8
HAITI/ HONDURAS
Literacy: 10% to 1296
Labor force: 2.6 million (est. January 1968); 86%
agriculture, 12% industry, 2% unemployed; shortage
of skilled labor; unskilled labor abundant
Organized labor: less than 1% of labor force','68fda7e14714db7b2a53281fa4fd107bf652baa40a260f8cf503ef52a160b7bd','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('686cc7e5b37a952589ba09e97c91f6221aa5c626cf82fd5714161096f142ecf3',1976,'HN','Honduras','people-and-society',231,'Population: 2,786,000, average annual growth rate
9.1% (4/61-3/74)
89
-8
- 1A000800010001
ed For Release 2005/04/22 : CIA-RDP79-0105
Approv
Caribbean
Sea
(See reference map ty
Nationality; nou n—Honduran(s), adjective...
Honduran
Ethnic divisions: 90% mestizo, 7% Indian, 2%
Negro, and 1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy; 57.4% of Persons 10 years of age and over
(est. 1970)
Labor force, approx. 900,000 (est. mid-19
agriculture, 12% Services, 8% manufacturing, 5%
commerce, 6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-
972)','55c0809ef35b01b090b966b1d200fafca65ac29cdeda9b61326816dd756114ac','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('072283b5bbb999923a280cb112e5f7636c5215d5daf3010a76a611647d26c87f',1976,'HK','Hong Kong','people-and-society',235,'Population: 4,354,000, average annual growth rate
1.6% (7/71-7/74)
Nationality: adjective—Hong Kong
Approved For Release 2005/04/22
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of
local religions
Language: Chinese, English
Literacy: 75%
Labor force (1971 est): 1.58 million; 4396
manufacturing, 20% services, 11% construction,
mining, quarrying and utilities, 18% commerce, 4%
agriculture, forestry, fisheries, and hunting, 7%
communications, 2% other; underemployment is a
serious problem
Organized labor: 12% of 1969 labor force','553fafa1f734f05aaad555aba07ae5a24bafd5904cd0d07bf64dd7219da5908d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c2731f99e09f4c9ffb3c158d9a5fbdfe404b359b9b0cfb3321ef51d80e2c4d5',1976,'HU','Hungary','people-and-society',239,'Population: 10,572,000, average annual growth
rate 0.6% (current)
Nationality; noun—Hungarian(s);
Hungarian
Ethnic divisions: 93.3% Magyar, 2.5% German,
2.4% Gypsy, 0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0% Calvinist,
3.0% Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy; 97%
Labor force: 5,073,600 (1 January 1974); 23%
agriculture, 44% industry and building, 16% trade
and transport, 17% other nonagricultural','a824ecf30d904378713f348095a573881ed5373197e71af0e6b8937fa21e52a0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d67412c76a9c373f3463df40554fb614fd8af974aaaad324de5a20b6c1284b1',1976,'IS','Iceland','people-and-society',243,'Population: 220,000, average annual growth rate
1.3% (12/69-12/74)
Nationality: noun—Icelander(s); adjective—
Icelandic
Ethnie divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other
Protestant and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 85,000; 22.6% agriculture and
fishing; 25.6% mining and manufacturing; 10.7%
construction; 12.8% commerce; 7.8% transportation
and communications; 15.2% services; and 5.7% other:
unemployment is insignificant
Organized labor: 60% of labor force','6e7d6b8d8f95268fbfbf0c507dc3c77304df0fdbc5954ed5f951de6818a1ad08','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa88de7f2284e26789cca94eb696d983f2a7fbd623a8d488e8c4bca84eb72c74',1976,'ID','Indonesia','people-and-society',247,'Population: 132,598,000 (including West Irian),
average annual growth rate 2.6% (current)
Nationality: noun— Indonesianís) adjective—
Indonesian
Ethnic divisions: 45% Javanese, 14% Sundanese,
7.5% Madurese, 7.5% Coastal Malays, 26% other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
INDONESIA/IRAN
Religion: 90% Muslim, 4%
Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay)
official; English, and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 44 million; 70% agriculture, 15%
industry, 1596 miscellaneous and unemployed
Organized labor: 10% of labor force
Population: 33,683,000, average annual growth
rate 3.0% (7/10- 7/73)
Nationality: noun—lIranian(s); adjective—Iranian
Ethnic divisions: 63% Ethnic Persians, 3% Kurds,
13% other Iranian, 18% Turkic. 3% Arab and other
Semitic, 1% other
Religion: 93% Shia Muslim; 5% Sunni Muslim;
2% “oroastrians, Jews, Christians and Baha’ is
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 37% of those 7 years of age and
older (1972 est.)
Labor force: 9.8 million est. 1975; 41% agriculture,
20% manufacturing; shortage of skilled labor
substantial','cf9f4591212ca2094704e9355c774038726eec99989e3bd6e581aafac0dc9776','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28e62158bcde2be541103a63d4a9b8ca0e4a1a6ef56d055ee20cdb124b3fc063',1976,'IQ','Iraq','people-and-society',251,'Population: 11,210,000, average annual growth
rate 3,4% (10/73-10/74)
Nationality: noun—lraqi(s); adjective—Iraqi
Ethnic divisions: 70.9% Arabs, 18.396 Kurds, 0.7%
Assyrians, 2.4% Turkomans, 7.7% other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks
Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million, 70% agriculture, 6.5%
industry, 6.7% government, 16.8% other; rural
underemployment high, but not scrious because low
subsistence levels make it casy to care for
unemployed; severe shortage of technically trained
personnel
Organized labor: 11% of labor force','598c2a00def862172e65176e48a09df3e9f4a0f87ff65cd840353019ec9aa735','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a162702a1b9d9195e1ff11f687347b93f6d596f78c1f2d71a060f7a7fd0da5d9',1976,'IE','Ireland','people-and-society',255,'Population: 3,121,000, average annual growth rate
0.7% (7/64-7/74)
Nationality: noun—Irishman(men), Irish (collec-
tive pl.); adjective—lIrish
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 29;
other
Language: English and Gaelic official; English is
generally spoken
Literacy: 98% -99%
Labor force: about 1,134,000 (1971); 26%
agriculture, forestry, fishing; 19% manufacturing;
15% commerce; 7% construction; 5% transportation;
4% government; 24% other; 8.9% unemployment
(September 1975)
Organized labor: 36% of labor force','2ee3bc93a079e27681a2a8adcf566582e09ab899847a03e1924a8ee131735adb','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('760883f909c462853c11b2f0587ae0eb2a5a08be60f4d444461dab4f5c157be1',1976,'IL','Israel','people-and-society',259,'Population: 3,408,000 (excluding West Bank and
East Jerusalem), average annual growth rate 2.2%
(7/74-7/75)
Nationality: noun—lIsraeli(s), adjective—Israel
Ethnic divisions: 8595 Jews, 159; non-Jews (mostly
Arabs) l
Religion: 89% Judaism, 8% Islam, 3% other
Language: Hebrew official; Arabic used officially
for Arab minority; English most commonly used
foreign language
Literacy: 88% Jews, 48% Arabs
Labor force: 1,122,900; 6.5% agriculture, forestry
and fishing; 25.3% manufacturing (mining, industry);
0.9% electricity and water; 8.1% construction and
public works; 12.2% commerce; 7.7% transport,
storage, and communications: 6.5% finance and
business; 26.1% public services; 6.7% personal and
other services (1974)
Organized labor: 90% of labor force','73cfd29a752886fab998d9ac2c905c60e04bd6285bcf971227d25f0f80c9c2d5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d66c7638b77c793898300e9972faafa314b42fb123d22f9f7582515f76877fe8',1976,'IT','Italy','people-and-society',263,'Population: 56,044,000, average annual growth
rate 0.796 (1/65-1/75)
Nationality: noun—Italian(s); adjective—Italian
Ethnic divisions; primarily Italian but population
includes small clusters of German-, French-, and
Slovene-Italians in the north and of Albanian-Italians
in the south
Religion: almost 100% nominally Roman Catholic
(de facto state rcligion)
Language: Italian; parts of Trentino-Alto Adige
Region (e.g., Bolzano) are predominantly German
speaking; significant French-speaking minority in
Valle d''Aosta Region; Slovene-speaking minority in
the Trieste-Gorizia area
Literacy: 556-776 of population illiterate (1972);
illiteracy varies widely by region
Labor force: 19,549,000 (January 1975); 15.0%
agriculture, 42.9% industry, 39.0% other, 3.4%
unemployed (July 1975); underemployment, par-
ticularly in southern Italy, remains widespread; 1.5
million Italians employed in other Western European
countries
Organized labor: 20% (est.) of labor force
Population: 4,950,000 (resident African population
only), average annual growth rate 2.6% (current)
Nationality: noun—lvorian(s); adjective— Ivorian
Approved For Release 2005/04/22 :
Ethnic divisions: 7 major indigenous ethnic
groups; no single tribe more than 20% of population;
most important are Agni, Baoule, Krou, Senoufou,
Mandingo; approx. 1 million foreign Africans, mostly
Voltaics; about 33,000 non-Africans (25,000 French)
Religion: 66% 22% Muslim, 12%
Christian
Language: French official, over 60 native dialects,
Dioula most widely spoken
Literacy: about 20%
Labor force: over 85% of population engaged in
agriculture, forestry, livestock raising; about 11% of
labor force are wage earners, nearly half in agricul-7
ture, remainder in government, industry, commerce,
and professions
Organized labor: 20% of wage labor force','cf6570ab2e4c4ff21429a03b9a33afa28e051d624e3d46cc03a4640e7a3f7243','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94067d05697b606ee2def3064754bfc333a4050272053ed694af3b543384bcbf',1976,'JM','Jamaica','people-and-society',267,'Population: 2,073,000, average annual growth rate
1.9% (7/71-7/73)
Nationality:
Jamaican
Ethnic divisions: African 76.3%, Afro-Europcan
15.1%, Chinese and Afro-Chinese 1.2%, East Indian
and Afro-East Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman
Catholic, some spiritualist cults
noun—Jamaican(s); adjective—
Language: English
Literacy: government claims 82%, but probably
only about onc-half of that number are functionally
literate
Labor force: 810,700 (1973); 26% in agriculture,
forestry, fishing and mining, 10% manufacturing, 8%
public administration, 5% construction, 10%
commerce, 3% transportation and utilities, 15%
services, 22% unemployed (seasonal unemployment in
agriculture can push the unemployment figure to
25%); shortage of technical and managerial personnel
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
JAMAICA/JAPAN
Organized labor: about 25% of labor force (1966)','f972e94caea582a27cfb3958ac5b30fcb1faa0aff723959d3e74f1acdd8477e5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2afafeae119a278ca776610006e0b0040607e86119985d025a7589ca8029886f',1976,'JP','Japan','people-and-society',271,'Population: 111,580,000 (including Ryukyus),
average annual growth rate 1.1% (7/64-7/74)
107
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
ATH
akye
Pacific
y Ld
Q Philippine
Sea
(See reference map Vil)
Nationality: noun—Japanese (sing., pl.); adjec-
tive—Japanese
Ethnic divisions: 99.2% Japanese, .8% other
(mostly Korean)
Religion: most Japanese observe both Shinto and
Buddhist rites: about 16% belong to other faiths,
including 0.8% Christian
Language: Japanese
Literacy: 97.8% of those 15 years old and ahove
(1960 data)
Labor force (1974 figures): 52.4 million;
10.7% agriculture, forestry, and fishing; 37.5%
manufacturing, mining, and construction; 39.5%
trade and services; 7% transportation; 3.4%
government; 1.7% unemployed; shortage of skilled
labor 1.5 million; unskilled .5 million (est.)
Organized labor: 20% of labor force','86d6f6f1e23c290f653d30e6ec9f4aacf8afa8594eeef2098b5085d5dec20743','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('650f876df46942b5992a49cef83886fb493eae4dfd9ea6431677ee7010d0e586',1976,'JO','Jordan','people-and-society',275,'Population: 2,745,000 (including West Bank and
East Jerusalem), average annual growth rate
3.2% (7/73-7/74)
Nationality: noun—Jordanian(s); adjective—
Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, 1%
Armenian
Religion: 95% Sunni Muslim, 5% Christian
Language: Arabic official, English widely
understood among upper and middle classes
Literacy: about 50% in East Jordan; somewhat less
than 60% in West Jordan
Labor force: 564,000; 33% unemployed
Organized labor: 5% of labor force','c69b090b0ee4ef0307624e91ee57e84d681682f83211e932ccb14c3af7e3b860','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e476923769af65afdd59d83690bca9f54ce76ada4857c907055f28d680fe21aa',1976,'KE','Kenya','people-and-society',279,'Population: 13,587,000, average annual growth
rate 3.4% (7/73-7/74)
Nationality: noun—Kenyan(s); adjective—Kenyan
Ethnic divisions: 97% native African (including
Bantu, Nilotic, Hamitic and Nilo-Hamitic) 2%
Asian; 1% European, Arab and others
Religion: 56% Christian, 36% animist, 7% Muslim,
1% Hindu
Language: English and Swahili official: each tribe
has own language
Literacy: 27%
Labor force: 2.5 million; about 977,000, (39%) in
monetary economy (1967)
Organized labor: about 215,000
Population: 16,762,000, average annual growth
rate 3.196 (current)
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious
uctivities now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 48% agriculture, 52%
non-agricultural; shortage of skilled and unskilled
labor
Population: 34,463,000, average annual growth
rate 2.0% (current)
Nationality: noun—Koreanís); adjective— Korean
Ethnic divisions: homogeneous; small Chinese
minority (approx. 20,000)
Religion: strong Confucian tradition; pervasive
folk religion (Shamanism); vigorous Christian
minority (5.596 of population); Buddhism (including
estimated 20,000 members of Soka Gakkai)
Chondokyo (religion of the heavenly way), eclectic
religion with nationalist overtones founded in 19th
century, claims about 1.5 million adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.5 million (1972); 48%
agriculture, fishing, forestry; 15% services; 13%
mining and manufacturing; 12% commerce; 12%
other
Organized labor: about 10% of nonagricultural
labor force','ccfb14fa8815e4d22f0048cd22711d3b2f1ed44b920cf39d403c57c6531425de','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c005d5885e9ec193d6f78af760aa838eeb2f6da4acb8eea933487ef3d90362',1976,'KW','Kuwait','people-and-society',283,'Population: 1,032,000, average annual growth rate
6.176 (4/70-4/75)
114
Approved For Release 2005/04/22
Nationality: adjective—Ku-
waiti
Ethnic divisions: 85% Arabs, 13%
Indians, and Pakistani
Religion: 99% Muslim, 1% Christian, Hindu,
Parsi, other
noun—Kuwaiti(s);
Iranians,
Language: Arabic; English commonly used foreign
language
Literacy: about 60%
Labor force: 238,000 (1970); 41% manufacturing,
25% services, 22% government and professions, 9%
commerce
Organized labor: labor unions, first authorized in
1964, formed in oil industry and among government
personnel
Population: 3,375,000, average annual growth rate
2.4% (7/73-7/74)
Nationality: noun—Lao (sing., pl); adjective—
Lao or Laotian
Ethnic divisions: 47% Lao; 14% Tribal Tai; 25%
Phoutheung (Kha); 14% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant
foreign language
Literacy; about 12%
Labor force: about 1,268,000; 80%-90% agri-
culture; 159,286 engaged in manufacturing and
services; 28,400 (22,400 civil and 6,000 police)
government employees in FY72
Organized labor: only labor organization is
subordinate to the Communist Party','a066658fe55dcbe52de72a9c90878abbde174c657277ae2de6fd5999a17dc8b6','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bedb083950e381f11c443396f618fc2a08878ce69e411bc1cf21c69c1426155',1976,'LB','Lebanon','people-and-society',287,'Population: 2,486,000, average annual growth rate
3.196 (current)
Nationality: noun—Lebanese (sing. and pl.);
adjective— Lebanese
Ethnic divisions: 93% Arab, 6% Armenian, 1%
other
Religion: 55% Christian, 44% Muslim and Druze,
1% other (official estimates); Muslims, in fact,
constitute a majority
Language: Arabic (official);
spoken
Literacy: 86%
Labor force: about 1 million economically active:
49% agriculture, 11% industry, 14% commerce, 26%
other; moderate unemployment
French is widely
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LEBANON/LESOTHO
Organized labor: about 65,000','20f93c495d07f57c2a443a4e8d69cc34d5e75ad450d867e178ddb4d50c943bf9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ddd0b3817393c03151bafbec02d82ebb9290362974a9a95d7439ad147f9c9f5',1976,'LS','Lesotho','people-and-society',291,'Population: 1,050,000, average annual growth rate
2.2% (7/''73-7/74)
Nationality:
Basothan
Ethnic divisions: 99.7% Sotho, 1,600 Europeans,
800 Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular;
English is second language for literates
noun—Basothan(s); adjective—
117
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Indian Ücean
(See reference mag VI)
Literacy: 40%
Labor force: 87.4% of resident population engaged
in subsistence agriculture; 150,000 to 250,000 spend 6
months to many years as wage earners in South Africa
Organized labor: negligible','031e63b94db0654214a7eac62aa42fe1eb7c1952bacb3bdfc06c3082fe8c7d17','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3bbefe966bd9cd61b277a9edaf507dab8e222d06e1a0d4f6232250d4036ef3d',1976,'LR','Liberia','people-and-society',295,'Population: 1,787,000, average annual growth rate
2.9% (current)
Nationality: noun—Liberian(s); adjective—
Liberian
Ethnic divisions: 5% descendants of immigrant
Negrocs, 95% indigenous Negroid African tribes
including Kpelle, Bassa, Kru, Grebo, Gola, Kissi,
Krahn, and Mandingo
Religion: probably more Muslims than Christians;
70%-80% animist
Language: English official; 28 tribal languages or
dialects, pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 600,000, of which 120,000 are in
monetary economy, about 2,000 non-African
foreigners hold about 95% of the top level
management and engineering jobs
Organized labor: 2% of labor force','41150cdc84d12347620438b77bea89fe415a72d4b9f101e758a0f56c23647e63','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64cbdc507f363f5bef156d336b2741bd1e2ae47532682605011c88957ffeab65',1976,'LY','Libya','people-and-society',299,'Population: 2,462,000, average annual growth rate
3.7% (7/73-7/74)
120
Approved For Release 2005/04/22
(See reference map Vi}
Nationality: noun—Libyan(s); adjective—Libyan
Ethnic divisions: 97% Berber and Arab with some
Negro stock; some Greeks, Maltese, Jews, Italians,
Egyptians
Religion: 97% Muslim
Language: Arabic; Italian and English widely
understood in major cities
Literacy: 35%
Labor force: 485,000; between ages 15-64,
405,000-430,000; 61% of labor force in agriculture
(1964)','25dd9854e9d4513dc93070abda8ae310a742f1b1a79897751df746bc12f0d829','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fadbbc41f6e7a115733be9b15c0ced1667f584a8c3b839ba260214026bc958b5',1976,'LI','Liechtenstein','people-and-society',303,'Population: 24,000, average annual growth rate
2.5% (12/60-12/70)
Nationality: noun—Liechtensteiner(s); adjective—
Ethnic divisions: 95% Germanic, 5% Italian and
other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 9896
Labor force: 7,000, 3,500 foreign workers (mostly
from Austria and Italy); 59% industry, 20% trade and
commerce, 13% professional and other, 8%
agriculture','1ae096b00e59ddb93c2f35fef98b07dbf53a167c32ac1630e11ed172a4967a14','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6634aa993988daef04885385883e08b6df47fec88e48e0fead0f46a27ad8a854',1976,'LU','Luxembourg','people-and-society',308,'Population: 359,000, average annual growth rate
0.896 (7/66-7/74)
Nationality: noun ——Luxembourger(s); adjective—
Ethnic divisions: 8396 Luxembourger, including an
estimated 59; of Italian descent; remainder French,
German, Belgian, etc.
Religion: 97% Roman Catholic, remaining 3%
Protestant and Jewish
Language: Luxembourgish, German, French; most
educated Luxembourgers also speak English
Literacy: 98%
Labor force: (1974) 158,000; 10% agriculture
(including forestry and fishing), 48% industry, 42%
services; 30% of labor force is foreign, comprising
workers from neighboring areas of Belgium, France,
and West Germany, as well as Italy and Portugal,
unemployment 0.1% August 1975
Organized labor: 45% of labor force','64c4b2294c2b7b987a6cf7e0d46dbea6744863f1497fe63276a609b38f214ef8','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('642e2e1375509be492f937403961b5789cc6705a999bf454d35d1b3079438244',1976,'PH','Philippines','people-and-society',313,'Population: 251,000 (official estimate for 1 July
1972)
Nationality:
Macaon
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics,
about one-half are Chinese
noun—Macaon(s); adjective—
Language: Chinese 98%, Portuguese 2%
Literacy: almost 100% among Portuguese and
Macanese; no data on Chinese population
Labor force: 596 agriculture, 3096 manufacturing,
3% construction, 1% utilities, 27% commerce, 8%
transportation and communications, 26% services
(1960 data)
Population: 43,531,000, average annual growth
rate 3.2% (current)
Nationality: noun—Filipino(s); adjective—Philip-
pine
Ethnic divisions: 91.5% Christian Malay, 4%
Muslim Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant,
4% Muslim, 3% Buddhist and other
164
Language: Tagalog (renamed Pilipino) is the
national language of the Philippine Republic; English
is the language of school instruction and government
business
Literacy: about 8396
Labor force: 11 million; 60% agriculture, forestry,
fishing, 12% manufacturing, 10.5% commerce, 10.5%
government and services (business, recreation,
domestic, personal), 3.5% transport, storage,
communication, 3% construction; 0.5% other','3f5315743294ddadd7a91a02ea50f919aee9ad32f678905b791b0b8de34c6cc5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62624ef075012d5a051ee80cbc3b90979e7f07bfba2edea7cb7723e6600038a2',1976,'MG','Madagascar','people-and-society',317,'Population: 7,639,000, average annual growth rate
2.3% (7/69-7/70)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Tananarive
*
(MADAGASCAR: 9
(See reference map VIJ
Nationality: noun—Malagasy (sing. and pl);
adjective—Malagasy
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting
of Merina (1,643,000) and related Betsileo (760,000),
on the one hand, and coastal tribes with mixed
Negroid, Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include Betsimisaraka
941,000, Tsimihety 442,000, Sakalava 375,000,
Antaisaka 415,000; there are also 38,000 French,
66,000 other
Religion: more than half animist; about 41%
Christian, 7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are
nonsalaried family workers engaged in subsistence
agriculture; of 175,000 wage and salary earners, 26%
agriculture, 17% domestic service, 15% industry, 14%
commerce, 11% construction, 9% services, 6%
transportation, 2% miscellaneous
Organized labor: 4% of labor force','7ac44289a65a63c2af90e8c0d24081ffd116017afea288b22dcec5562f8e7808','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a28c2f47c9c8211597a38391c265234f91f5b2dda331465f766628c33c1be9c',1976,'MW','Malawi','people-and-society',321,'Population: 5,084,000, average annual growth rate
2.5% (7/72-7/74)
Nationality: noun—Malawian(s);
Malawian
Ethnic divisions: over 99% native African, less than
1% European and Asian
Religion: majority animist; rest Christian and
Muslim
adjective—
Language: English and Chichewa official; Lomwe
is second African language
Literacy: 6% of population over 21 years old
Labor force: 225,000 wage earners employed in
Malawi (1974); 6,000 Europeans permanently
employed; 300,000 Malawians live and work in
Rhodesia, South Africa, and Zambia; 3095 agriculture,
11% construction, 10% commerce, 13% manufac-
turing, 10% administration, 26% miscellaneous
services
Organized labor: small minority of wage earners
are unionized','46b16c59a9f82be21b0b21ec179cc7ba339df15684b055dfe37903ac159e57b8','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a2fd2fa79a13138fe5ec0d5c8671594332fe4278881c19800df812ffd74c665',1976,'MY','Malaysia','people-and-society',325,'Population: 12,227,000, average annual growth
rate 3.0% (7/70-7/74)
Peninsular Malaysia: 10,213,000, average annual
growth rate 2.8% (7/70-7/74)
Sabah: 860,000, average annual growth rate 4.9%
(1/10-1/14)
Sarawak: 1,154,000, average annual growth rate
3.2% (7/70-7/74)
127
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Nationality:
Malaysian
Ethnic divisions:
Malaysia: 44% Malay, 36% Chinese, 8% tribal,
10% Indian and Pakistani, 2% other
Peninsular Malaysia: 50.19; Malay, 36.9%
Chinese, 11% Indian and Pakistani, 2% other
Sabah: 23.1% Chinese, 67.3% indigenous tribes,
9.6% other
Sarawak: 31.5% Chinese, 50% indigenous tribes,
17.5% Malay, 1% other
Religion:
Peninsular Malaysia: Malays nearly all Muslim,
Chinese predominantly Buddhists, Indians predomi-
nantly Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and
Confucianist, 16% Christian, 35% tribal religion, 2%
other
Language:
Peninsular Malaysia: Malay (official): English,
Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among
Chinese
Sarawak: English, Malay, Mandarin, numerous
tribal languages
noun—Malaysian(s); adjective—
Literacy:
Peninsular Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 3.45 million (1967)
Peninsular Malaysia: 2.9 million: 55% agriculture,
forestry, and fishing, 11% manufacturing and
construction, 34% trade, transport, and services
Sabah: 213,000 (1967); 80% agriculture, forestry,
and fishing, 6% manufacturing and construction, 13%
trade and transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry,
and fishing, 6% manufacturing and construction, 13%
trade, transportation, and services, 1% other
Organized labor: 370,000 (official 1967 est.) about
10.5% of total labor force; 28% of wage labor force;
unemployment about 89; of total labor force, but
higher in urban areas','0deac65fefb0bbb77a7c6552a3b5f0851da35e9b9c90ad1382672305e370c70c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61c98bf3c37708e7c1f5a41c0088acac4156cb10d78494ea638c9a74ae049a96',1976,'MV','Maldives','people-and-society',329,'Population: 182,000, average annual growth rate
2.1% (current)
Nationality: noun—Maldivian(s); adjective—
Maldivian
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the
male population','5b53f10141adfe315f2acd0b0f6eed13374d7cda691319dd56f52f073513cbcd','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93db4eca718f9cb7277aec49a6a83d8e02df5e96c2f0e7af3250ed33f0976617',1976,'ML','Mali','people-and-society',333,'Population: 5,686,000, average annual growth rate
2.3% (7/12-1/13)
Nationality: noun—Malian(s); adjective—Malian
Ethnic divisions: 99% native African including
tribes of both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African
languages, of which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried,
50,000 of whom are employed by the government;
most of population engaged in agriculture and animal
husbandry
Organized labor: UNTM, which claimed all
eligible employees, dissolved; thirteen national unions
currently directed by a government controlled
Coordination Committee of Mali Trade Unions
(CCSM)
Population: 320,000 (official estimate for 31 March
1975)
Nationality: noun—Maltese (sing. and pl);
adjective—Maltese
Ethnic divisions: mixture of Arab, Sicilian,
Norman, Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education
introduced in 1946
Labor force: 107,500; 29% services, 23%
government, 24% manufacturing, 6% agriculture, 4%
construction, 4% transportation and communications,
5% utilities and drydocks; 5% unemployed
Organized labor: approximately 35% of labor force','db27587b86f9f23225fd6120ad8dba0e78643e50637cab94197128f3eab4655c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46184243c2953c04f5a15b1bf64c330d8f333a951b5f284058ed2036d4f90427',1976,'MQ','Martinique','people-and-society',336,'Population: 347,000, average annual growth rate
0.5% (7/70-7/73)
Nationality: noun—Martiniquais (sing. and pl);
adjective—M artiniquais
Ethnic divisions: 90% African and African-
Caucasian-Indian mixture, less than 5% East Indian
Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and
pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public
services, 11% construction and public works, 10%
commerce and banking, 10% services, 9% industry,
17% other
Organized labor: 11% of labor force','946fdb67f62bd92e9fd013ecc624030c34b310275a61fbe1ce63f70df1505131','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0344e631f6f2ab5e4a7fddba1eda41429c21192a604a129e49bc7597cdfb86b2',1976,'MR','Mauritania','people-and-society',338,'Population: 1,339,000, average annual growth rate
2.5% (7/68-7/74)
Nationality: noun—Mauritanianís); adjective—
Mauritanian
Ethnic divisions: 80% Moor, 20% Negro
Religion: nearly 100% Muslim
Language: Hassaniya Arabic is the national
language spoken by some 80% of the population,
French is the working language for government and
commerce
Literacy: about 10%
s Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MAURITANIA/MAURITIUS
Labor force: about 18,000 wage earners (1973);
remainder of population in farming and herding
Organized labor: 18,000 union members claimed
by single union, Mauritanian Workers Union','53fcca8b6c3bd46e4ab773c47cadb5c0924c562f92af25c24bfc54af98819824','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01e87aac2d662ded638c05485bbdba52eac9f2d4f480a1676232e38af5087815',1976,'MU','Mauritius','people-and-society',342,'Population: 890,000, average annual growth rate
1.196 (1/73-1/74)
Nationality: noun—Mauritian(s);
Mauritian
Ethnic divisions: Indians 67%, Creoles 29%,
Chinese 3.5%, English and French 0.5%
Religion: 51% Hindu, 33% Christian (mostly
Catholic with a few Anglican Protestants), 16%
Muslim
Language: English official language; Hindi,
Chinese, French Creole
Literacy: estimated 60% for those over 21, and 90%
for those of school age
Labor force: 175,000; 50% agriculture, 6%
industry; 20% government services; 14% are
unemployed, under-employed, or self-employed, 10%
other
Organized labor: about 35% of labor force
Population: 499,000, average annual growth rate
2.1% (7/70-7/73)
Nationality: noun—Reunionais (sing. & pl);
adjective—Reunionais
Ethnic divisions: most of the population is of
thoroughly intermixed ancestry of French, African,
Malagasy, Chinese, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high
seasonal unemployment
Population: 6,417,000, average annual growth rate
3.5% (1/70-1/75)
Nationality:
Rhodesian
Ethnic divisions: 95.1% African, 4.4% European,
less than 0.5% Coloreds and Asians
Religion: 51% syncretic (part Christian, part
animist), 24% Christian, 24% animist, a few Muslim
Language: English official, Chishona and
Sindebele also widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including
some migrants from Zambia and Malawi), 108,000
Europeans, Asians, and coloreds (people of mixed
heritage); 35% agriculture, 25% mining, manufactur-
ing, construction, 4096 transport and services
Organized labor: about one-third of European
wage earners are unionized, but only a small minority
of Africans (1966)','12060078ec34f6c497d4c6d7af84a8e3ea12c282e3854fa999efd555791f023e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bbccf56dbc06afb1e079514c136a73819ab027a35bf40d79d66677e52bda4fa',1976,'MX','Mexico','people-and-society',345,'Population: 61,009,000, average annual growth
rate 3.3% (current)
Nationality: noun—Mexican(s); adjective—
Mexican
Ethnic divisions: 60% mestizo, 30% Indian or
predominantly Indian, 9% white or predominantly
white, 1% other
Religion: 97% nominally Roman Catholic, 3%
other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force (1973): 15.7 million (defined as those
12 years of age and older); 39.5% agriculture, 16.7%
manufacturing, 16.6% services, 16.8% construction,
utilities, commerce, and transport, 3% government,
7.4% unspecified activitics
Organized labor: 20% of total labor force','dce183979def00423fd3df2178533fdca79af84d60a6e7491113ccc9e18baf50','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('181fe2542e6a4f661612247feff1199b122461e1f0243effd279c955c6a649aa',1976,'MC','Monaco','people-and-society',349,'Population: 24,000 (official estimate for 31
December 1973)
Nationality: noun—Monacan(s) or Monegasque(s);
adjective—Monacan or Monegasque
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state
religion
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MONACO/MONGOLIA
Language: French
Literacy: almost complete','f82626090892ede63455414b9147b041aee8da69e3c1d000b861599f3db9d60e','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b6eb632c538cbcf623bb2b49043fe4cefa4b9a581483cca21c82fdbfd381b88',1976,'MN','Mongolia','people-and-society',353,'Population: 1,466,000, average annual growth rate
3.1% (current)
Nationality: noun—Mongolian(s); adjective—
Mongolian
Ethnic divisions: 90% Mongol, 4% Kazakh, 2%
Chinese, 2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about
4% Muslim, limited religious activity because of
Communist regime
Languages: Khalkha Mongol used by over 90% of
population; minor languages include Turkic, Russian,
and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the
population is in the labor force, including a large
percentage of Mongolian women; shortage of skilled
labor (no reliable information available)','5e8a489ceaa53212a330bc16c6ced733ee90398cb42e392588d6aca8c7c3becf','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff40b208e2632f88d60208ef69903fa81fa0afc345c13fde376f440fcb5718a0',1976,'MA','Morocco','people-and-society',357,'Population: 17,687,000, average annual growth
rate 3.2% (7/71-7/74)
Nationality: noun—Moroccanís);
Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish,
0.7% non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2%
Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, government,
diplomacy, and postprimary education
Literacy: 20%
Labor force: 6.8 million (1971 est.) 50%
agriculture, 15% industry, 26% services, 9% other
Organized labor: about 5% of the labor force,
mainly in the Union of Moroccan Workers (UMT)','0c322d9f871b808c5bf08661e52a3d56a79168008b9a875fe49427b72a640c2b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ab3a710eaae5518ec0c7a90817042d9f4ad54f96c20d9dbc8f1c2798ebbff6e',1976,'MZ','Mozambique','people-and-society',361,'Population: 9,116,000, average annual growth rate
2.0% (7/71-7/72)
Nationality: noun—Mozambican(s); adjective—
Ethnic divisions: 97% African, 3% European,
Asian, and Mulatto
Religion: 65.6% animist, 21.5% Christian, 10.5%
Muslim, 2.4% other
Language: Portuguese (official); many tribal
dialects
Literacy: 776-1096 (est.)
Labor force: (1963 est.) 610,000; 50,000 non-
African wage earners, 560,000 African wage eamers in
Mozambique; 290,000 additional African wage
earners temporarily working in Rhodesia and South
Africa; unemployment serious problem; most native
Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970);
7596 are white','4c3b3351de7c26641e9dbe32040a64942fb59aa6fec5f72f64a4103b2de3d3bb','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1174888495ab39331b1c4eab551983d3a8c10d45332ac3babacd697008c40aa',1976,'NR','Nauru','people-and-society',367,'Population: 7,000 (official estimate for 30 June
1969)
Nationality:
Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
Religion: Christian (% Protestant, % Catholic)
Language: Nauruan, a distinct Pacific Island
tongue; English, the language of school instruction,
spoken and understood by nearly all
Literacy: nearly universal','4cfc12b093e2be37922a9e18340995c55dddef0c629edcbd080b021a23d25685','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('299722400fe14823367eae152bf956f0727b9f5a95c7914e7902b82753c2e5de',1976,'NP','Nepal','people-and-society',371,'Population: 12,731,000, average annual growth
rate 2.2% (6/71-6/74)
Nationality: noun—Nepalese (sing. and pl.); ad-
jective—Nepalese
Ethnic divisions: two main categories, Indo-
Nepalese (about 80%) and Tibeto-Nepalese (about
20%), representing considerable intermixture of Indo-
Aryan and Mongolian racial strains; country divided
among many quasi-tribal communities
Religion: only official Hindu Kingdom in world,
although no sharp distinction between many Hindu
and Buddhist groups; small groups of Muslims and
Christians
Language: 20 mutually unintelligible languages
divided into numerous dialects; Nepali official
language and lingua franca for much of the country;
same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5%
industry; great lack of skilled labor','a158e5017fc1a91a9d8d4657c629d2ffb96b7ffc50d5f673ec1a6e5bbfddc3c0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0df000337c624be5d427ac2519beaf9f049509706e1a1cebb005c1b82ccd4167',1976,'NC','New Caledonia','people-and-society',375,'Population: 186,000, average annual growth rate
3.8% (7/61-7/12)
Nationality: noun—New Caledonian(s); adjec-
tive—New Caledonian
Ethnic divisions: Melanesian-Polynesian admix-
ture, over 28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and
Tonkinese laborers were imported for plantations and
mines in pre- World War II period; immigrant labor
now coming from Wallis Islands, New Hebrides, and','6f75de0c91faefc06ed0940b1747ec04aecee64e326f7059b16ef0f440b9576d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30bb1080bebe6dafec9288f3ea0eb79285812bbff15c1ccbe2d6c07399b7d36b',1976,'NZ','New Zealand','people-and-society',377,'Population: 3,164,000, average annual growth rate
2.2% (1/74-1/75)
149
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
P
e re
Pacific
Ocean
Coral Sea
$
- NEW hb
E m Wellington
(See reference map VHI)
Nationality: noun—New Zealander(s); adjective—
Ethnic divisions: 93% European, 7% Maori
Religion: 90% Christian, 9% none or unspecified;
1% Hindu, Confucian, and other
Literacy: 9896
Labor force: 1,176,600; 13% agriculture, 3396
manufacturing and construction, 9% transportation
and communications, 24% commerce and finance,
21% administrative and professional (1974 figures)
Organized labor: 52% of labor force','f2095ff68108e35ec6be8306594d964450ef81e65d468d677225d1ae986bffdb','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ffcb00fbf7cde347b350d58b8161004afeab36a0fa80d542d4c7ed8535ea601',1976,'NI','Nicaragua','people-and-society',381,'Population: 2,188,000, average annual growth rate
3,3% (7/70-7/74)
Nationality: noun—Nicaraguan(s); adjective—
Nicaraguan
Ethnic divisions; 69% mestizo, 17% white, 9%
Negro, 5% Indian
Religion: 95% Roman Catholic
Language: Spanish (official); small English-
speaking minority on Atlantic coast
Literacy: 5096 of population 10 years of age and
over
Labor force: 620,000 (1974 est.); 50% agriculture,
12% manufacturing, 14% services, 24% other;
shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 5% of labor force','8fe716fa346a93526b1b9d6e0efd04d27db016c2b900d561aeaf3a52a37bff4c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71194c96fe8ea09164b4d070f089f447eefe1958d020cdc6dd80cfa66c075ea3',1976,'NE','Niger','people-and-society',385,'Population: 4,662,000, average annual growth rate
2.7% (7/70-7/74)
Nationality: noun—Nigerois (sing. and pl.);
adjective-—Niger
Ethnic divisions: main Negroid groups 75% (of
which, Hausa 50%, Djerma and Songhai 21%);
Caucasian elements include Tuareg, Toubous, and
Tamacheks; mixed group includes Fulani
Religion: 80% Muslim, remainder largely animists
and a very few Christians
Language: French official, many African lan-
guages; Hausa used for trade
Literacy: about 5%
Labor force: 26,000 wage earners; bulk of
population engaged in subsistence agriculture and
animal husbandry
Organized labor: negligible','46c079088dfdd3b9f87eae21654725513048ce4414177e90cfa35cf52f1e4b33','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4277f05df4c0c5a96cae7d793172ab2e6420aed0c7e82a726c1cd8644fbae10',1976,'NG','Nigeria','people-and-society',389,'Population: 63,825,000, average annual growth
rate 2.996 (current)
Nationality: noun—Nigerian(s); adjective—
Nigerian
Ethnic divisions: 250 tribal groups, of which most
important are Hausa-Fulani (north), Ibo and Yoruba
(south); these 3 tribes total over 60% of population;
about 27,000 non-Africans
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and
Ibo also widely used
Labor force: approx. 22.5 million; about 41% of
total population; roughly 1.3 million wage earners, of
whom 560,000 work in modern enterprises
Organized labor: about 530,000 wage earners,
approx. 2.4% of total labor force, belong to some 700
unions','5d1bdf5675366a37742394b4b65af99bcd557418e58204bc62b278281dbb8911','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bdf99ba1e58f059211727584911ee27f3104c53b9ddd177cfb8b75f2c31d492',1976,'NO','Norway','people-and-society',393,'Population: 4,022,000, average annual growth rate
0.6% (1/74-1/75)
Nationality: noun—Norwegian(s); adjective—
Norwegian
Ethnic divisions: homogeneous white population,
small Lappish minority
Religion: 96% Evangelical Lutheran, 4% other
Protestant and Roman Catholic, 1% other
Language: Norwegian, small Lapp and Finnish-
speaking minorities
Literacy: 99%
Labor force: 1.7 million; 11.4% agriculture,
forestry, fishing, 25.3% mining and manufacturing,
8.1% construction, 16.3% commerce, 9.9% transporta-
Approved For Release 2005/04/22
tion and communication, 28.5% services; 1.0%
unemployed
Organized labor: 60% of labor force','2ef77984d492e8d51fbb8a8f16319a12a913e83c1c787d2ae60012592a75e088','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06f797764742ce51d98e907a43e859808612761714c7898a7e2df67ec2a76aea',1976,'OM','Oman','people-and-society',397,'Population: 505,000, average annual growth rate
2.9% (current)
Nationality: noun—Omani(s); adjective—Omani
Ethnic divisions: almost entirely Arab with small
groups of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','b8df90702b236cb32ccd7019150b93688fc0a117326c064e0ca5e14520528ec7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e181c99f6d35b30e8afad4f9043be7463f4d01c845c138502f05d3f9fcf6d0d0',1976,'PK','Pakistan','people-and-society',401,'Population: 71,461,000 (excluding Junagardh,
Manavadar, Gilgit, Baltistan, and the disputed area
of Jammu-Kashmir), average annual growth rate
3,2% (current)
Nationality: noun—Pakistani(s); adjective—
Pakistani
Religion: 9796 Muslim, 3% other
Language: official, Urdu; total spoken languages
—7% Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu,
9% other; English is lingua franca
Literacy: about 14%
Labor force: 12.7 million (est. 1961); 60%
agriculture, 16% industry, 7% commerce, 15% service,
2% unemployed
Organized labor: 5% of labor force','2fecc6256cd8680d5e4b0c9f89db88fd25af9232cc41cad0bcef24997ee4c021','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1234ae17fd2fa6c72a29d37a123da9f181fd5a153c9bbfb402bab20454de4815',1976,'PA','Panama','people-and-society',405,'Population: 1,693,000, average annual growth rate
3.1% (7/73-7/74)
Nationality: noun—Panamanian(s); adjective—
Panamanian
Ethnic divisions: 70% mestizo, 14% Negro, 9%
white, 7% Indian and other
Religion: over 90% Roman Catholic, remainder
mainly Protestant
Language: Spanish; about 14% speak English as
native tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and
over
Labor force: 482,200 (1972 est.); 89.5% commerce,
finance and services; 33.9% agriculture, hunting and
fishing; 9.7% manufacturing and mining; 6.8%
construction; 5% Canal Zone; 3.9% transportation
and communications; 1.2% utilities; national average
of 6.8% unemployed; shortage of skilled labor but an
oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)','d6244a4afabd355055900ebd3674accaa3a1980a837d474435379d3736e0d89a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f30d3b9e0c484a01fd86539a7394b9b416514ae14c3a07036d1be2747750f29',1976,'PY','Paraguay','people-and-society',409,'Population: 2,582,000, average annual growth rate
2.7% (10/62-7/72)
Nationality: noun—Paraguayan(s); adjective—
Paraguayan
Atlantic Ocean
{See reference map IH]
Ethnic divisions: 95% mestizo, 5% white and
Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10,
but probably much lower (40%)
Labor force: 800,000 (1971 est.); 55% agriculture,
forestry, fishing; 8% transport and other services; 19%
manufacturing and construction; 13% commerce and
professions; 596 miscellaneous (est. 1962)
Organized labor: about 596 of labor force','654acddf9d53cb84bdcc3b6e2158b3cc17eb9e559e3faafab72fed2597657a07','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5fb08d5bfd6a7571a36a0dbe2df74b2ed3d32f5aec0aae401641876d6a1d5ea',1976,'PE','Peru','people-and-society',413,'Population; 15,037,000 (excluding Indian jungle
population which was estimated at 101,000 in 1961),
average annual growth rate 2.9% (7/61-6/72)
Nationality: noun— Peruvian; adjective— Peruvian
Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white; 1% Negro, Japanese, Chinese
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 4.4 million (1973); 46% agriculture,
17% services, 14% manufacturing, 9% trade, 4%
construction, 4% transportation, 2% mining, 4% other
Organized labor: 25% of labor force','94666ee7c680a204e4b01a23cc1e2952b120002b9a79bb639b7290f0dda437b0','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffb71b00ff1a64a9fcc0fd77c9d861abd60c276a4734f03ca2f7831a8e0f37dc',1976,'PL','Poland','people-and-society',417,'Population: 34,200,000, average annual growth
rate 1.1% (current)
Nationality: noun—Pole(s); adjective-—Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians,
0.5% Belorussians, less than 0.05% Jews, 0.2% other
Religion: 959; Roman Catholic (about 7596
practicing), 5% Uniate, Greek Orthodox, Protestant,
and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26%
industry, 3696 other non-agricultural','07f59f84348caa33418e5aedbb7e09210c29342b3d6c1616c325383fd296db19','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abedd50d10cf14160cc65be96b6377ae3bc654334229611cc9b93d4cf02ed085',1976,'PT','Portugal','people-and-society',421,'Population: metropolitan Portugal (including the
Azores and Madeira Islands), 8,782,000 (official
estimate for 1 July 1974)
Nationality: noun—Portuguese (sing. & pl.
adjective— Portuguese
Ethnic divisions: homogeneous Mediterranean
stock in mainland, Azores, Madeira Islands
Religion: 97% Roman Catholic, 1% Protestant
sects, 2% other
Language: Portuguese
Literacy: 65% (a figure considered high by some
sources)
Labor force: 3 million; 25% agriculture, 31%
industry, 24% services; 8% military, 12% other;
government estimates that over 400, 100 persons or 5%
of labor force are unemployed
Organized labor: about one-third of labor force is
organized in trade unions; legislation promulgated
May 1975 unites consenting unions under one
confederation, the Communist-dominated Intersyndi-
cal
Population: 703,000, average annual growth rate
2.9% (12/70-7/72)
Nationality: noun— Portuguese Timoran(s);
adjective—Portuguese Timoran
Ethnic divisions: 95% indigenous Timorese
belonging to the Malay racial group; 9 ethnic
divisions, each speaking a distinct dialect of Malay
structure; approx. 4,600 Chinese and 10,000 halfcastes
Religion: 179; Christian (almost equally divided
between Catholic and Protestant), remainder practice
animism
Language: an estimated 9-15 dialects, of Malay
origin but mutually unintelligible; 75% of the
population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but is very
low; in 1971 total school enrollment was 35,000 out of
total school-age population of 80,000; 5% of natives
can speak Portuguese
Labor force: 90% engaged in primitive village
subsistence economy, 10% engaged as town laborers
and domestics','861b497ed66e9912a3e5a64e4d89314435f933d23c5f2728e2f3e72298629327','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d50fa6d2f39a4ba287224b589571e8010a017842a418f94514c86ddc7e2122b0',1976,'QA','Qatar','people-and-society',425,'Population: 195,000, average annual growth rate
10.8% (7/64-7/69)
Nationality; noun—Qatari(s); adjective— Qatari
Ethnic divisions: 56% Arab; 23% Iranian; 14%
Pakistani; 7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: 48,000 (1969)','1290946023ae76561bde45746ab495e9a5292a7dab5818d914a035236634575d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e4d8dfb30aa5c37d8ee148260f4a17f2a8d80249d09d53d8bc512ce931f9c7a',1976,'RO','Romania','people-and-society',429,'Population: 21,349,000, average annual growth
rate 1.0% (current)
Nationality: noun—Romanian(s); adjective—
Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian,
2% German, 3% other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
E
Black Sea
(See reference map IV]
Religion: 14 million Romanian Orthodox, 1 million
Roman Catholic, 1 million Protestants, 100,000 Jews,
30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.1 million (1974); 40% agriculture,
30% industry, 30% other nonagricultural','44bf657dd67bd83639b0cb2e433b0063bcaeac715b83e2658ab511708aa9aed7','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('152c8eb61a839953eaa4e2fc9d941028bee904defe63412722d215e8c312acd8',1976,'RW','Rwanda','people-and-society',433,'Population: 4,302,000, average annual growth rate
2.9% (7/73-7/74)
Nationality: noun—Rwandan(s); adjective—
Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa
(Pygmoid)
Religion: 45%
Muslim, rest animist
Language: Kinyarwanda and French official;
Kiswahili used in commercial centers
Catholic, 9% Protestant, 1%
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','b1cc8681fbf280d3b5920d235f986e4edf2da0043b00f795d135b3ca8c1a89fc','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f57b3b0ff7173d5622d1774d38a8c1d365ce10b06c15c5db0ddf996e674807f6',1976,'AI','Anguilla','people-and-society',437,'Population: 69,000, average annual growth rate
1.2% (4/60-4/70)
Ethnic divisions: mainly of African Negro descent
Nationality: noun—Kittsian(s), Nevisian(s),
Anguillan(s); adjective—Kittsian, Nevisian, An-
guillan
Religion: Church of England, other Protestant
sects, Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (1960 est.)
Organized labor: 6,700
Approved For Release 2005/04/22
Population: 109,000, average annual growth rate
1.5% (4/60-4/70)
Nationality: noun— St. Lucian(s); adjective— St.
Lucian
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
176
Approved For Release 2005/04/22 :
Labor force: 38,000 (1969); 50% agriculture;
unemployment 30%-35% (1975)
Organized labor: 20% of labor force
Population: 95,000, average annual growth rate
1.1% (4/60-4/70)
Nationality: noun—St. Vincentian(s) or Vin-
centian(s); adjective—St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian
and Carib Indian
Religion: Church of England, Methodist, Roman
Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est); about 60%
unemployed
Organized labor: 10% of labor force','41f23c1fbf8fa2ff6fc4123de437ca46f1d1a098d2bd0ac9e91f80657440fe0c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cb8000e26b4258a5a981c09e842bfad09e5903cab89d335241d4a7fd53774ef',1976,'SM','San Marino','people-and-society',441,'Population: 19,000 (official estimate for 30 June
1974)
Nationality: noun—Sanmuarinese (sing. & pl.);
adjective—Sanmarinese
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation
of Sanmarinese Workers (affiliated with ICFTU) has
about 1,800 members; Communist-dominated
Camera del Lavoro, about 1,000 members
COVERNMENT
Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in
1862 the Kingdom of Italy concluded a treaty
guarantecing the independence of San Marino;
although legally sovereign, San Marino is vulnerable
to pressure from the Italian Government
Capital: San Marino
Political subdivisions: San Marino is divided into 9
sections: Guaita, Fratta, Serravalle, Domagnano,
Acquaviva, Fiorentino, Montegiardino, Faetano,
Chiesanuova
Legal system: based on civil law system with
Italian. law influences; electoral law of 1926 serves
some of the functions of a constitution; has not
accepted compulsory IC] jurisdiction
Branches: the Grand and General Council is the
legislative body elected by popular vote; its 60
members serve 9-year terms; Council in turn elects
178
two Captains-Regent who exercise executive power for
term of 6 months, the Council of State whose
members head government administrative depart-
ments and the Council of Twelve, the supreme
judicial body; actual executive power is wielded by
the Secretary of State for Foreign Affairs and the
Secretary of State for Internal Affairs
Government leaders: Secretary of State for Foreign
Affairs Gian Luigi Berti (Christian Democratic party);
Secretary of State for Internal Affairs Giuseppe
Lonferini (Christian Democratic party); Secretary for
finance, budget, and planning Remy Giacomini
(Socialist)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General
Council required at least every 5 years; next elections
1979
Political parties and leaders: Christian Demo-
cratic party (DCS), Gian Luigi Berti; Social
Democratic Party (PSDSM), Alvaro Casali; Socialist
Party (PSS), Remy Giacomini; Communist Party
(PCS), Umberto Barulli; People''s Democratic Party
(PDP), leader unknown; Committee for the Defense
of the Republic (CDR), leader unknown
Voting strength (1974 election): 39.6% DCS,
23.7% PCS, 15.4% PSDIS, 13.9% PSS, 1.9% PDP,
2.9% CDR
Communists: approx. 300 members (number of
sympathizers cannot be determined); PSS, in
government with Christian Democrats since March
1978, formed a government with the PCS from the
end of World War II to 1957
Other political parties or pressure groups:
political parties influenced by policies of their
counterparts in Italy, the two Socialist parties are not
united
Member of: ICJ, International Institute for
Unification of Private Law, International Relief
Union, IRC, UPU, WFTU','8d9a54411c12d3136d8d7b15b32bdb3e60a766317191ca4937d8cbd3fd855b5f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bc250b27b39d8f762e8ac72a0197621a33bb86266547ef6bd1127c94048b59e',1976,'ST','Sao Tome and Principe','people-and-society',444,'Population: 75,000 (official estimate for 1 July
1972)
Nationality: noun—Sao Tomean(s); adjective—
Sao Tomean
Ethnic divisions: native Sao Tomeans, migrant
Cape Verdians, Portuguese
Religion: Roman Catholic
Language: Portuguese official
Literacy: estimated at 596-1096
Labor force: most of population engaged in
subsistence agriculture and fishing; nearly half the
island''s work force, about 10,000 people, are
unemployed, the other half work on cocoa plantations','4ce62c910351e8d9781ef41cd670e5f72e5d511ba6938d9690925039fb684bf9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf78bb42c12bb947e945721126079ac92d766899f98bcdc0f9d2b6b404eeadfb',1976,'SA','Saudi Arabia','people-and-society',448,'Population: 6,170,000, average annual growth rate
2.895 (current)
Nationality: noun—Saudi(s): adjective—Saudi
Arabian or Saudi
Ethnic divisions: 90% Arab. 10% Afro-Asian (est. )
180
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 25% of population; 40%
agriculture and herding, 12% construction, 12%
service, 12% government, 11% commerce, 18% other','e04defa2cafb0d96f37c7ab9d04ca3e9edfb433e89086cfa0ce4b030dbeba8c9','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea630f8563fb16f7e3c5537ace2465393640e39cbfba322e02952a608d46fd90',1976,'SC','Seychelles','people-and-society',452,'Population: 59,000, average annual growth rate
2.3% (7/68-7/73)
Nationality: noun—Seychellois (sing. € pl);
adjective— Seychelles
Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans)
Religion: 90% Roman Catholic
: Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SEYCHELLES/SIERRA LEONE
Language: English official; Creole most widely
spoken
Literacy: limited
Labor force: 22,000 agriculture
Organized labor: 3 major trade unions','7c546df1cc0627c895a08cd2a7be8a21a60f2255b427953496800098e0f04db2','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ebaa1903d18ebf59e8ab24bbb581aae3cab3c7001eca78080e1c3a48b158da9',1976,'SL','Sierra Leone','people-and-society',456,'Population: 2,768,000, average annual growth rate
1.5% (7/73-7/74)
Nationality: noun—Sierra Leonean(s); adjective—
Sierra Leonean
Ethnic divisions: over 99% native African, rest
European and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited
to literate minority; principal vernaculars are Mende
in south and Temne in north; “Krio,” the language of
the resettled ex-slave population of the Freetown area,
is used as a lingua franca
Literacy: about 10%
Labor force: about 1.5 million; most of population
engages in subsistence agriculture; only small
minority, some 70,000, earn wages
Organized labor: 35% of wage earners','bca888d0f772cfa29f785655d758db5dc15a563134d39361ba4484f904d2f4c5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8952b18c07de821150ae3577ea652dd922d9c6794d229e37a7e9ce63811f5bc0',1976,'SG','Singapore','people-and-society',460,'Population: 2,271,000, average annual growth rate
1.6% (7/73-7/74)
Nationality: noun—Singaporan(s);
Singaporan
Ethnic divisions: 76.2% Chinese, 15% Malay, 7%
Indians and Pakistani, 1.8% other
Religion: majority of Chinese are Buddhists or
atheists; Malays nearly all Muslim; minorities include
Christians, Hindus, Sikhs, Taoists, Confucianists
adjective—
Language: national language is Malay; Chinese,
Malay, Tamil, and English are official languages
Literacy: 70% (1970)
Labor force: 474,718; 0.5% agriculture, forestry,
and fishing, 0.4% mining and quarrying, 32.2%
manufacturing, 30.4% services, 5.2% construction,
21.5% commerce, 9.8% transport, storage, and','fa45e1b3b769fbed7934b4b8d73eda9295a1c5ce87fcf4059ec68910dff8ac1d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d426b52d270ab7d5297f5bdef4883c062bba65c9e3922487378f739d8882867b',1976,'SO','Somalia','people-and-society',464,'Population: 3,190,000, average annual growth rate
2.3% (7/65-7/72)
Nationality: noun—Somali(s); adjective—Somali
Ethnic divisions; 85% Hamitic, rest mainly Bantu;
30,000 Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form recently instituted
by government); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are
skilled laborers; 70% pastoral nomads, 30%
agriculturists, government employees, traders,
fishermen, handicraftsmen, other
Organized labor: law providing for government-
controlled labor union promulgated in June 1971, but
union so far not established','b54c04b3806ff10853bcb1d10ddba46a1566022166e2fcc7384aa9c4cd706f2a','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5aaf4863ae781e0c3e5c71566cb6c31d39e8413cfc858c07286da530b7be41c8',1976,'ZA','South Africa','people-and-society',468,'Population: 25,909,000, average annual growth
rate 2.6% (7/70-7/74)
Nationality: noun—South African(s); adjective—
South African
Ethnic divisions: 17.8% white, 69.9% African,
9.4% Colored, 2.9% Asian
Religion: primarily Christian except Asian and
African; 60% of Africans are animists
Language: Afrikaans and English official, Africans
have many vernacular languages
Literacy: almost all white population literate;
government estimates 35% of Africans literate
Labor force: 8.7 million (total of economically
active, 1970); 53% agriculture, 8% manufacturing,
7% mining, 5% commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is
unionized (mostly white workers); nonwhites have no
bargaining power
Population: 902,000, average annual growth rate
3.0% (7/68-7/74)
Nationality: noun—South West African(s);
adjective—South West African
Ethnic divisions: 14% white, 81% Africans, 5%
Colored (mulattoes); almost half the Africans belong
to Ovambo tribe; Damara tribe has almost 45,000
members; Herero, Okavango, Nama tribes have about
30,000 members each
Religion: whites predominantly Christian,
nonwhites either animist or Christian
Language: Afrikaans principal language of about
70% of white population, German of 22% and English
of 8%; several African languages
Literacy: high for white population; low for
nonwhite
Labor force: 203,300 (total of economically active,
1970), 68% agriculture, 15% railroads, 13% mining,
4% fishing
Organized labor: no trade unions, although some
white wage earners belong to South African unions
Population: 35,783,000 (including the Balearic and
Canary Islands; also including Alhucemas, Ceuta,
Chafarinas, Melilla, and Penon de Velez de la
Gomera), average annual growth rate 1.195 (current)
Nationality: noun—Spaniard(s); adjective—
Spanish
Ethnic divisions: homogeneous composite of
Mediterranean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great
majority; but 17% speak Catalan, 7% Galician, and
2% Basque
Literacy: about 90%
Labor force (1973): 12.7 million; 25% agriculture,
36% industry, 39% services; registered unemployment
is 2.1% of labor force, in reality about 4%
Organized labor: 90% of labor force in compulsory
government-controlled syndicates
190','fa86a3bc4f80828f801da6c546b62ad9d821d1fb74aae1dc01686b36816b6b4d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd0297bcfd363f97d6233d24660fd96b7a29294f8ed2d4e97e9984e720e0d2d6',1976,'ES','Spain','people-and-society',474,'Population: 108,000 (official estimate for 1 July
1974)
Nationality; noun— Spanish Saharan(s); adjec-
tive—Spanish Saharan
Ethnic divisions: 71.5% Arab, Berber, and Negro
nomads; 28.5% Spanish
Religion: 72% Muslim, 28% Catholic
Language: Spanish (official), local Arabic or
Hassania
Literacy: among Spanish, probably nearly 100%;
among nomads, perhaps 5%
Labor force: 12,000; 50% agriculture, 50% other
Organized labor: none','001615ecc3c1b5e3383a972a0cfc09352983bbeb04967c15a555a89a2633b1b5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6dfe3f146c6a63aa17394ade3d84a4498c6ad4a76ebfe22a665a353a0373a01',1976,'LK','Sri Lanka','people-and-society',476,'Population: 13,895,000, average annual growth
rate 1.9% (7/70-7/78)
Nationality: noun—Ceylonese (sing. and pl.)
adjective—Ceylonese
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6%
Moor, 2% other
Religion: 64% Buddhist, 20%
Christian, 6% Muslim, 1% other
Language: Sinhala official, spoken by about 70%
of population; Tamil spoken by about 22%; English
commonly used in government and spoken by about
10% of the population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed;
employed persons — 53.4% agriculture, 14.8% mining
and manufacturing, 12.4% trade and transport, 19.4%
services and other
Organized labor: 48% of labor force, over 50% of
which employed on tea, rubber, and coconut estates','7c9c37a6a0132fb75cf7fb576f5c90e3dc1ea8b78b51b5920aabc76e7890cf43','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('019ed2d0c7902eb9bff477576a7c8cb6efd98de86c52e4a36cac12fd7a3b662a',1976,'SD','Sudan','people-and-society',480,'Population: 17,980,000, average annual growth
rate 2.5% (7/73-7/74)
Nationality: noun—Sudanese (sing. and pl.);
adjective— Sudanese
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro,
2% foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23%
pagan, 4% Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse
dialects of Nilotic, Nilo-Hamitic, and Sudanic
languages, English; program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15%
industry, commerce, services, etc.; labor shortages
exist for almost all categories of employment
Population: 421,000, average annual growth rate
2.8% (1/64-1/72)
Nationality:
Surinam
Ethnic divisions: 315; Creole (Negro and mixed),
37% Hindustani (East Indian), 15.3% Javanese,
10.3% Bush Negro, 2.6% Amerindian, 1.7% Chinese,
1.0% Europeans, 1.7% other and unknown
Religion: Muslim, Hindu, Moravian, Roman
Catholic, other — in order of size (% figures
unknown)
Language: Dutch officia]; English widely spoken:
Taki-Taki (Surinam Creole) is native language of
Creoles and lingua franca; Hindi; Javanese
Literacy: 70% to 75%
Labor force: 130,000 (1973)
Organized labor; approx. 33% of labor force
Population: 502,000, average annual growth rate
3.2% (current)
Nationality: noun—Swazi(s); adjective—Swazi
Ethnic divisions: 96% African, 3% European, 1%
mulatto
Religion: 43% animist, 57% Christian
Language: English and Swati are official
languages; government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in
subsistence agriculture; 55-60,000 wage earners, many
only intermittently, with 31% agriculture, 11%
government, 11% manufacturing, 12% mining and
forestry, 35% other (1968 est.); 7,900 employed in
South African mines (1969)
Organized labor: about 15% of wage earners are
unionized','8961648d02db45223caaf771018a2b7bc53a77618b834abde5f0e5cd4dc7db4c','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9be8f82f1b193ee907cbc59e274a43d3526692474a28e644b94e4dd198866db5',1976,'SE','Sweden','people-and-society',484,'Population: 8,212,000, average annual growth rate
0.4% (current)
Nationality: noun—Swede(s); adjective—Swedish
Ethnic divisions: homogeneous white population:
small Lappish minority
198
Religion: 92% Evangelical Lutheran, 7% other
Protestant, Roman Catholic, Eastern Orthodox, 1%
other
Language: Swedish, small Lapp- and Finnish-
speaking minorities
Literacy: 99%
Labor force: 4.0 million; 6.4% agriculture, forestry,
fishing; 29.2% mining and manufacturing; 7.2%
construction; 13.6% commerce; 6.5% transportation
and communications; 29.8% services including
government; 5% banking, 2.7 unemployed
Organized labor: 80% of labor force','2eff53f125d740c53ce2149a86d9b77f3978abfc084d9fc77829f494a4447b91','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fbf3734d58929407bc81a7cfc71c5e9a9cf2f1fe9b43838d0e3f57d9c6cf473',1976,'CH','Switzerland','people-and-society',487,'Population: 6,500,000, average annual growth rate
0.4% (7/74-7/75)
Nationality: noun—Swiss (sing. & pl); adjective—
Swiss
Ethnic divisions: total population — 69% German,
19% French, 10% Italian, 1% Romansch, 1% other;
Swiss nationals — 74% German, 20% French, 4%
Italian, 1% Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
199
Appr
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001
-8
00010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008
Language: Swiss nationals — 749; German, 20%
French, 49; Italian, 1% Romansch, 1% other;
population — 69% German, 19% French, 10%
Italian, 1% Romansch, 1% other
Literacy: 98%
Labor force: 3.0 million, about one-fifth
workers, mostly Italian; 16% agriculture and forestry,
47% industry and crafts, 20% trade and trans-
portation, 5% professions, 2% in public service.
10% domestic and other; approximately 0.4%
unemployed in August 1975
Organized labor: 20% of labor force
Population: 7,475,000, average annual growth rate
3.3% (7/73-7/74)
1,365 (1967) (excluding
Nationality: noun—Syrian(s); adjective—Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds,
Armenians, and other
Religion: 70.5% Sunni Muslim, 16.3% other
Muslim sects, 13.2% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and
English widely understood
Literacy: about 40%
Labor force: 2 million; 67% agriculture, 12%
industry (including construction), 21% miscellaneous
services; majority unskilled; shortage of skilled labor
Organized labor: 596 of labor force
Population: 15,363,000, average annual growth
rate 2.7% (7/73-7/74)
Nationality: noun—Tanzanian(s), adjective—
Tanzanian
Ethnic divisions: 99% native Africans consisting of
well over 100 tribes; 1% Asian, European, and Arab
Religion: Tanganyika — 40% animist, 30%
Christian, 30% Muslim; Zanzibar — almost all
Muslim
Language: Swahili and English official, English
primary language of commerce, administration and
higher education; Swahili widely understood and
generally used for communication between ethnic
groups; first language of most people is one of the
local languages
Literacy: 15%-20%
Labor force: under 400,000 in paid employment,
over 90% in agriculture
Organized labor: 15% of labor force','13b418c98ef0c05e527c0df71962d3bc8f168ac63f6c9e8b31ec2cc2f46b416d','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41d7a08735b67bf2b05322e30f560202db874f82bdec2c3733045d572ad0a951',1976,'TH','Thailand','people-and-society',491,'Population: 42,955,000, average annual growth
rate 3.1% (7/73-7/74)
Nationality: noun— Thai (sing. € pl.); adjective —
Thai
Ethnic divisions: 75% Thai, 14% Chinese, 11%
minorities
Religion: 95.5%
Christian
Language: Thai; English secondary language of
elite
Literacy: 70%
Labor force: 78% agriculture, 1595 services, 7%
industry
COVERNMENT
Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions:
provinces
Buddhist, 49; Muslim, 0.59;
7l centrally. controlled
Legal system: based on civil law system, with
influences of common law; new constitution
promulgated 7 October 1974; legal education at
Thammasat University; has not accepted compulsory
IC] jurisdiction
Branches: King is head of state with nominal
powers; Prime Minister heads a 3l-man cabinet;
National Assembly bicameral, senate appointed,
204
Approved For Release 2005/04/22
house elected; judiciary relatively independent except
in important political subversive cases
Government leaders; King Phumiphon Adundet;
Khukrit Pramot, Prime Minister; Praman Adireksan,
Deputy Prime Minister
Suffrage: universal
Elections: 26 January 1975
Political parties and leaders: 22 political parties
won seats in 269-seat National Assembly; key parties
include Social Action, Democrat, Thai Nation, Social
Justice, Social Agrarian, Social Nationalist, Socialist
Party of Thailand, and New Force
Communists: strength of illegal Communist Party
is about 1,000; Thai Communist insurgents
throughout Thailand total about 8,000
Other political or pressure groups: National
Student Center of Thailand (NSCT); labor
associations, People for Democracy, Federation of
Independent Students
Member of: ADB, ASEAN, ASPAC, Colombo
Plan, ESCAP, FAO, IAEA, IBRD, ICAO, IDA, IFC,
IHO, ILO, IMF, IPU, ITU, Seabeds Committee,
SEAMES, UN, UNESCO, UPU, WCL, WHO,
WMO
Population: 21,114,000, average annual growth
rate 2.6% (7/65-7/71)
Nationality: noun—South Vietnamese (sing. &
pl.; adjective—South Vietnamese
Ethnic divisions: 87.7% Vietnamese, 69; Chinese,
3.2% mountain tribesmen, 2.9% Khmer, 0.2% Cham
Religion: 70% Buddhist (at least 5% Hoa Hao), 5%
Cao Dai, and 10% Catholic; others include animist,
and small numbers of Protestant, Muslim and Hindu;
most Buddhists are of Mahayana school or practice
combination of Buddhism, Taoism, and Confucian-
ism
Language: Vietnamese, French, Chinese, English,
Khmer, tribal languages (Mon-Khmer and Malayo-
Polynesian), Cham (Malayo-Polynesian dialect)
Labor force: civilian work force 5.8 million (not
including armed forces); 67% agriculture, fishing, and
forestry; 5% industry and commerce; 1% domestic
and personal services; 5% government; 22%
unemployed
Organized labor: 500,000','ee0e40a0cb4185c5d2a319ef3f4f708669694a377222856938ace1084f5c2557','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('374cd64f3bcb634c4d0be3b2ada6cf188f6ca8a92bc8bdd827b549bf5a54dc96',1976,'TG','Togo','people-and-society',494,'Population: 2,255,000, average annual growth rate
9.6% (1/73-7/74)
Appro
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001
-8
Nationality: noun—Togolese (sing. & pl):
adjective—Togolese
Fthnic divisions: some 40 tribes; largest and most
important are Ewe in south and Cabrais in north;
under 1% European and Syrian- Lebanese
Religion: about 20% Christian, 5% Muslim, 75%
animist
Language: French, both official and language of
commerce; major African languages are Ewe and
Mina in south and Dagoma, Tim, and Cabrais in
north
Literacy: 5% to 10%
Labor force: over 90% of population engaged in
subsistence agriculture; about 30,000 wage earners,
evenly divided between public and private sectors
Organized labor: less than half of wage earners
divided among 2 major and several minor unions','a0e566eb6ae971124a1eb287d7e1ddc0115b93d8dc423109b3a9b4c81d8b14ac','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51e0bc81b3d0df8718dd5f903d5bf8bcd05c7cdfcdb90a4b29a181eb0dc2b2ce',1976,'TO','Tonga','people-and-society',498,'Population: 101,000, average annual growth rate
2.995 (7/67-7/73)
Nationality; noun—Tongan(s): adjective—Tongan
Ethnic divisions; Polynesian, about 300 Europeans
Religion: Christian: Free Wesleyan Church claims
over 30,000 adherents
Language: Tongan, English
Literacy: 90% -95 % ; compulsory education for
children between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','c37e430a4b0f8e5cdeebab123271715b07cf08cc900191cc3d2745e08ff171f5','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('365bdbc5badcb1750ab6ee44bbb42744a2cfef5927dce252d46e096a3280366b',1976,'TT','Trinidad and Tobago','people-and-society',502,'Population: 1,020,000, average annual growth rate
1.3% (4/60-4/70)
Nationality: noun—Trinidadian(s),
ian(s); adjective—Trinidadian
Ethnic divisions: 43% Negro, 40% East Indian,
14% mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman
Catholic, 23% Hindu, 6% Muslim, 13% unknown
Language: English
Literacy: 89%
Labor force: about 376,000 (1973 est.), about
15.4% agriculture, 18.7% mining, quarrying, and
manufacturing, 16.7% commerce; 16.2% construction
and utilities; 7.4% transportation and com-
munications; 21.8% services, 3.8% other
Organized labor: 30% of labor force','74003188868b627fd0f1b9444119c03d23164afb4dc9f89fb1af6c66e55f7849','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c1583ff744dfe965973c5f84aa146ca618dceaf2a18b62ffe25ed82958b8fcf',1976,'TN','Tunisia','people-and-society',506,'Population: 5,847,000, average annual growth rate
2.4% (7/70-7/74)
Nationality:
Tunisian
Ethnic divisions: 98% Arab, 1% European, less
than 1% Jewish
Religion: 95% Muslim, 4% Christian, 1% Jewish
Language: Arabic (official), Arabic and French
(commerce)
noun—Tunisian(s); adjective—
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TUNISIA/TURKEY
Literacy: about 32%
Labor force: 1.4 million; 45% agriculture, 19%
manufacturing and construction, 5% trade and
finance, 3% transportation, communications, and
utilities, 2% mining; 25% underemployed; shortage of
skilled labor
Organized labor: 10% of labor force; General
Union of Tunisian Workers (UGTT), subordinate to
Destourian Socialist Party
Population: 40,574,000, average annual growth
rate 2.6% (current)
200
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TURKEY
Black Saa
= os
X Ankara
TURKEY
¡See reference map Vj
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other
(mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million: 68% agriculture, 16%
industry, 16% service; substantial shortage of skilled
labor; ample unskilled labor
Organized labor: 10% of labor force','e2ee1700cfb91ee406fd7ea720ea36a6de42dc32442cfa69fa18194d566d629f','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ce4afd4540458da20eaa40601ab9c363373275eaf6a7feb3331dbb8e552f606',1976,'UG','Uganda','people-and-society',510,'Population: 11,746,000, average annual growth
rate 3.4% (current)
Nationality: noun—Ugandan(s); adjective—
Ugandan
Ethnic divisions: 99% African, 1% European,
Asian, Arab
Religion: about 60% nominally Christian, 5%-10%
Muslim, rest animist
Language: English official; Luganda and Swahili
widely used; other Bantu and Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which
about 250,000 in paid labor, remaining in subsistence
activities
Organized labor: 125,000 union members
Population: 255,675,000, average annual growth
rate 1% (current)
Nationality: noun—Soviet(s): adjective— Soviet
212
(See reference map Vil)
Ethnic divisions: 74% Slavic, 26% among some 170
ethnic groups
Religion: 70% athcist, 18% Russian Orthodox, 9%
Muslim, 3% other
Language: more than 200 languages and dialects
{at least 18 with more than 1 million speakers); 76%
Slavic group, 8% other Indo-European, 11% Altaic,
3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 133 million (1975), 26%
agriculture, 74% industry and other non-agricultural
fields, unemployed not reported, shortage of skilled
labor reported','5ebd808c73487a9b3c13dec66e4270ac7b3d541fceb8a2fa455b2a619ae737da','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('661608e5d4e202ed5bc64453f20a6a427a91e6da4b374ad604d1610e7f10748c',1976,'AE','United Arab Emirates','people-and-society',513,'Population: 179,000 (census of 15 March - 16 April
1968)
Ethnic divisions: Arabs 72%; others include
Iranians, Pakistanis, and Indians
Religion: Muslim 96%, Christian, Hindu and other
4%
Language: Arabic
Literacy: 25% est. (1975)
Labor force: 135,000 (1978)','49e05394112c0afff8036f4e59a27cf888818445eda782870815f8ac9dde57b6','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('205bef5406e8878013f72a129410a8f499f605598af1d43fc9f5c2d25711f826',1976,'GB','United Kingdom','people-and-society',518,'Population: 6,051,000, average annual growth rate
2.2% (7/71-7/72)
Nationality; noun—Upper Voltan(s); adjective—
Upper Voltan
Ethnic divisions: more than 50 tribes; principal
tribe is Mossi (about 2.5 million); other important
groups are Curunsi, Senufo, Lobi, Bobo, Mande, and
Fulani
Religion: majority of population animist, about
209; Muslim, 59; Christian (mainly Catholic)
Language: French official; tribal languages belong
to Sudanic family, spoken by 50% of the population
Literacy: 595.105;
Labor force: about 95% of the economically active
population engaged in animal husbandry, subsistence
farming, and related agricultural Pursuits: about
30,000 are Wage earners; about 20% of male labor
force migrates annually to neighboring countries for
seasonal employment
Organized labor; 3 primary and several small
specialized unions','3de739aa67d0e24e7415f290c5eeedfba7c7c8c72121efa701c7c393935aa47b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b004146264cd525ea7074e7a558434cbaff079040bfb7f2fb66c3e2b51e18b33',1976,'UY','Uruguay','people-and-society',521,'Population: 3,083,000, average annual growth rate
1.2% (7/73-7/74)
Nationality: noun—Uruguayan(s); adjective—
Uruguayan
Ethnic divisions: 85%-90% white, 5% Negro, 5%-
10% mestizo
Religion: 66% Roman Catholic (less than half
adult population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those
employed in important sectors — 25% government;
34% industry; 10% service; 23% other; 8%
agriculture, forestry, fishing and mining; no shortage
of skilled labor
Organized labor: about 25% of labor force
Population: 1,000 (official estimate for 1 July 1974)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: ltalian, Latin, and various modern
languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees
divided into 3 categories — executives, officeworkers,
and salaried employees
Organized labor: none
Population: 12,182,000 (excluding Indian jungle
population estimated at 32,000 in 1961), average
annual growth rate 3.1% (7/73-7/74)
Nationality: noun—Venezuelan(s); adjective—
Venezuelan
Ethnic divisions: 67% mestizo, 21% white, 10%
Negro, 2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Labor force: 3 million (1974); 2496 agriculture, 676
construction, 17% manufacturing, 6% transportation,
1896 commerce, 25% services, 4% petroleum, utilities,
and other
Organized labor: 45% of labor force
Population: 24,533,000, average annual growth
rate 2.2% (current)
Nationality; noun—North Vietnamese (sing. &
pl. adjective—North Vietnamese
Ethnic divisions: 8596-9076 predominantly
Vietnamese; ethnic minorities include Muong, Thai,
Meo, and Man
Religion:
Catholicism
Language: closely corresponds to the breakdown of
ethnic groups
Literacy: claimed to be 95% (1964)
Labor foree: (1 January 1970) 9.6 million, not
including military; about 70% agriculture and 10%
industry','30a9e8de087897c026b915302ff9450c3bf2afdb4aa213b680b7765e67ef167b','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95ebe15d914bc01a519c505145aa50085b7efc305c9f854a3de0d550a8d1c08f',1976,'WF','Wallis and Futuna','people-and-society',526,'Population: 9,000, official estimate for 1 July 1973
Nationality: noun—Wallisian(s), Futunan(s), or
Wallis and Futuna Islander; adjective—Wallisian,
Futunan, or Wallis and Futuna Islanders
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic
Population: 160,000, average annual growth rate
2.396 (7/64-7/74)
Nationality: noun—Western Samoan(s); adjec-
tive— Western Samoa
Ethnie divisions: Polynesians, about 12,000
Euronesians (persons of European and Polynesian
blood), 700 Europeans
Religion: 99.7% Christian (about half of
population associated with the London Missionary
Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all
children from 7-15 years)
Labor force: agriculture 19,148: mining and
manufacturing 1,716 (L961)
Organized labor: unorganized','5674f6ca89b32d90f492e051139ef7f3467d4e2f65c80cfe388a5cb46b57edf3','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06ed022cc317fe0b5b913e9457a5b4b54cdecf2d3225766b58477a6d7e36432a',1976,'WS','Samoa','people-and-society',532,'Population: 1.663,000,? average annual growth
rate 2.7% (1/13-7/74)
Nationality: noun—Yemeni(s); adjective— Yemeni
Ethnic divisions: almost all Arabs; a few Indians,
Somalis, and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%, Aden 35%
(est. )','5bd82440d52c8610a3624216e1437493fa5671bf0f78ad8c960cd82bb45a55ce','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7d7de134dfd49f3c9acf3e311655f574ea4955fc9082e5a9d9da60320a2daba',1976,'YE','Yemen','people-and-society',536,'Population: 6,622,000, average annual growth rate
2.696 (7/71-7/72)
01-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008000100
January 1976
YEMEN (SANA)/YUGOSLAVIA
Nationality; noun— Yemeni(s); adjective Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab
(mixed)
Religion: 1009; Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force:
herding
Population: 21,447,000, average annual growth
rate 0.9% (current)
Nationality: noun—Yugoslav(s); adjective—
Yugoslav
Ethnic divisions: 39.796 Serb, 22.196 Croat, 8.496
Muslims, 8.2% Slovene, 5.8% Macedonian, 2.5%
Montenegrin, 6.4% Albanian, 2.3% Hungarian, 4.6%
other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman
Catholic, 12% Muslim, 3% other, 12% none (1953
census)
Language: Serbo-Croatian, Slovene, Macedonian,
Albanian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 13.5 million (1970); 49.6%
agriculture, 16% mining and manufacturing, 34.4%
other nonagricultural activities; reported unemploy-
ment averaged 8% of registered labor force (social
sector) in 1967
Population: 25,248,000, average annual growth
rate 2.8% (7/73-7/74)
Nationality: noun—Zairian(s); adjective—Zairian
Ethnic divisions: over 200 African ethnic groups,
the majority are Bantu; four largest tribes — Mongo,
Luba, Kongo (all Bantu), and the Mangbetu-Azande
(Hamitic) make up about 4596 of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili,
Kikongo, and Chiluba are all classified as official
languages
Literacy: 5% fluent in French, about 35% have an
acquaintance with French
Labor force: about 8 million, but only about 1396
in wage structure','4a139466bdea1aae221f03a4e4c8f5dbf63f2f55bb9661be8d9925346792d568','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('686a715a0a261732a64cd01d19be5a1b95761a0ee2228e9cbbc8a7ca0ad0d1df',1976,'ZM','Zambia','people-and-society',538,'Population: 4,931,000, average annual growth rate
2.5% (7/73-7/74)
Nationality: noun—Zambian(s); adjective—
Zambian
Ethnic divisions: 98.7% African, 1.1% Europcan,
.2% other
Religion: 82% animist, about 17% Christian, and
under 1% Hindu and Muslim
Language: English official; wide variety of
indigenous languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000
Africans, 27,000 non-Africans; 15% mining, 9%
agriculture, 9% domestic service, 19% construction,
9% commerce, 10% manufacturing, 23% government
and miscellaneous services, 6% transport
Organized labor: 100,000 wage earners, primarily
in industrial sector, are unionized (early 1968)','13956c34b8fc5372062f4ed1c21862cf0a5e05059169685d4884776e535c49d8','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3a4d11716c2a0105711a5a6a64f322af16986fcdbd3972328d56abae8d500d6',1976,'US','United States','people-and-society',542,'Population: 214,524,000, average annual growth
rate 0.8% (current)
Ethnic divisions: 87.2% white, 11.8% negro, 1.4%
other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Religion: total membership in religious bodies,
131,484,000; Protestant 71,649,000, Roman Catholic
48,460,000, Jewish 6,115,000, other religions
3,841,361
Language: English, predominantly
Literacy: almost complete
Labor force: 92 million (1974)
Organized labor: 23.4% of total (1972)','d035ccbf33373652116da5bcfc343005a8b689016af030862aaa4d0baf72c922','internet-archive','igj_20260313','txt','6e306dcf272636ffab7d631f006ac851243ca0b74868de76e224d3d34959f05d','https://archive.org/download/igj_20260313/IGJ_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a31fb7d1746444dfe95f49872f817ade11a1a14a7387ac13e55feab31c0ac6e',1976,'AF','Afghanistan','people-and-society',3,'Population: 19,367,000, average annual growth
rate 2.3% (7/72-7/73)
Nationality: noun—Afghan(s); adjective—Afghan
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9%
Uzbeks, 9% Hazaras, minor ethnic groups include
Chahar, Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim,
1% other
Language: 50% Pushtu, 35% Afghan Persian
(Dari), 11% Turkic languages (primarily Uzbek and
Turkmen), 10% 30 minor languages (primarily
Baluchi and Pashai); much bilingualism
Literacy: under 10%
Labor force: about 4.3 million (1966 official est. );
75%-80% agriculture and animal husbandry, 20%-
95% commerce, small industry, services; massive
shortage of skilled labor
Organized labor: none','a648362d5df315b166d6440019aff7cb1fb0d640c428bbd274fa7c78dca91b92','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fbb01d76efdba196ac0eb4c334de63b93c24fc4f45e093104f41e2ca0788b46',1976,'AL','Albania','people-and-society',8,'Population: 2,439,000, average annual growth rate
2.4% (current)
Nationality:
Albanian
noun—Albanian(s); adjective—
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
NO
Religion: 70% Muslim, 20% Albanian Orthodox.
10% Roman Catholic (observances prohibited;
Albania claims to be the world’s first atheist state)
Language: Albanian, Greck
Literacy: about 70%; no reliable current statistics
available, but probably greutly improved
Labor force: 911,000 (1969): 60.5% agriculture.
17.9% industry, 21.6% other nonagricultural
Population: 17,062,000, average annual growth
rate 3.2% (7/73-7/74)
Nationality: noun—Algerian(s); adjective—
Algerian
Ethnic divisions: 99% Arab-Berbers, less than 1%
Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 2.8 million; 47% agriculture, 8%
industry, 24% other (military, police, civil service,
transportation workers, teachers, merchants,
construction workers); 40% of urban labor unem-
ployed
Organized labor: 17% of labor force claimed,
General Union of Algerian Workers (UGTA) is the
only labor organization and is subordinate to the
National Liberation Front','64c97fc74a13ecec53ebebab543f16d26811f48b70dc08b4750b7fed0a48715f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fe11e14e1be54c8e1a8aa828df38beaa73fda8e065b753ba81ac617d861cfff',1976,'AD','Andorra','people-and-society',15,'Population: 19,000 (official estimate for 1 July
1969)
Nationality:
Andorran
Ethnic divisions: Catalan stock: 30% Andorrans,
61% Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French
and Castilian
Labor force: unorganized: largely shepherds and
farmers','f747fb32a9a2b3a67c8e19204fdece15e0e0ff05375be528d0b926740b2d9148','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c697e97c4a928f4671fdfedd084df90804f9fef081847e15a66cc1dbffb2bfaf',1976,'AO','Angola','people-and-society',19,'Population: Angola, 6,052,000 (docs not take into
account recent emigration from Angola), average
annual growth rate 1.6% (12/60-12/70); Cabinda,
95,000 (official estimate for 1 July 1972)
Nationality: noun—Angolan(s); adjective—
Angolan
Ethnie divisions: 93% African, 5% Europeans, 1%
mestizos
Religion: about 84% animist, 12%
Catholic, 4% Protestant
Language: Portuguese (official), many native
dialects
Roman
Cabindege=
Atlantic
Ocean
(Sea reference map Vi)
Literacy: 10%-15%
Labor force: 2.6 million economically active
(1964); 531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)','561ee245e39923811da32a30ea514886a1007cac8870fe99e9a4db41a0c0533f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60849089d672bb9c942fe1dbf87df4bc7d3f570e377f1b034c58a79bbe86e635',1976,'PR','Puerto Rico','people-and-society',23,'Population: 72,000, average annual growth rate
1.4% (7/78-7/74)
Nationality:
Antiguan
noun—Antiguan(s); adjective—
Approved For Release 2005/04/22
Ethnic divisions: ulmost entirely African Negro
Religion: Church of England (predominant), other
Protestant sects and some Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000','bbe8c985506685877f101b34eb92d5e93d12e750432fa8ccd4809fed93480018','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57766bd51f5ade8c26b923ccb0efa7d253d8e84be9cefc8a720c9571f947a5a6',1976,'AR','Argentina','people-and-society',27,'Population: 95,551,000, average annual growth
rate 1.3% (current)
Nationality: noun—Argentine(s), adjective—
Argentine
Ethnic divisions: approximately 85% white, 15%
mestizo, Indian, or other nonwhite groups
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Religion: 90% nominally Roman Catholic (less
than 20% practicing), 2% Protestant, 2% Jewish, 6%
other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 9.5 million; 19% agriculture, 25%
manufacturing, 90% services, 11% commerce, 6%
transport and communications, 19% other
Organized labor: 25% of labor force (est.)','01aab485451055e3adafad37c9c38437a5067a5d04f1a2780236a50ba8c94fb5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a3106ee98c37ece25569544c3c20d5cbc1741a477535ac00eee834d107f73be',1976,'AU','Australia','people-and-society',31,'Population: 13,721,000, average annual growth
rate 1.8% (7/66-7/74)
Nationality: noun—Australian(s): adjective—
Australian
Ethnic divisions: 99% Caucasian, 1% Asian and
aborigine
Religion: 98% Christian, 2% animist and others
10001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008000
ee
January 1976
Appro
pproved For Release 2005/04/22 : CIA-RDP79-01051A00080001000
1-8
Language: English
Literacy: 98.5%
Labor force: 4.76 million; 14% agriculture, 32%
industry, 37% services, 15% commerce, 2% other
Organized labor: 44% of labor foree
Population: 2,714,000, average annual growth rate
2.3% (7/66-7/73)
Nationality: noun—Papua New Guinean(s);
adjective—Papua New Guinean
160
Ethnic divisions: predominantly Melanesian and
Papuan, some Negrito, Micronesian, and Polynesian
types
Religion: over one-half of population nominally
Christian (490,000 Catholic, 320,000 Lutheran, other
Protestant sects); remainder animist
Language: 700 indigenous languages; pidgin
English and 2 or 3 native languages are linguae
francae for over one-half of population; English
spoken by 1% to 2% of population
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly
subsistence farmers','d24b017d8a48ae07165eabf29ffdae7daa03a392ba61667ee931f2bf7bd99fc6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de05655048163e154602d7370c551e049e31f977b436e0872f4e0f37aa2d076d',1976,'AT','Austria','people-and-society',37,'Population: 7,541,000, average annual growth rate
0.0% (1/74-1/75)
Nationality:
Austrian
Ethnic divisions; 98.1% Gernan, 0.7% Croatian,
0.3% Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8%
none or other
noun—Austrian(s); adjective—
Language: German
Literacy: 98%
Labor force: 2.656.922 (1974): 18% agriculture
and forestry, 49% industry and crafts, 18% trade and
communications, 7% professions, 6% public service,
2% other; 2.4% registered unemployed; an estimated
200,000 Austrians are employed in other European
countries; foreign laborers in Austria number More
than 200,000 (1972). unemployment 2.0% (August
1975)
Organized labor: about 2/3 of age and salary
workers (1971)
Population: 203,000, average annual growth rate
2.1% (7/78-7/74)
Nationality: noun—Bahamian (sing., pl.); adjec-
tive—Bahamian
Ethnic divisions: 80% Negro, 10% white, 10%
mixed
Religion: Baptists 29%, Church of England 23%,
Roman Catholic 23%, smaller groups of other
Protestant, Greek Orthodox, and Jews
Language: English
Labor force: 69,000 (1970); 25% organized','e211e6f4a95a8cb7cf3eb3beefa45fe87b65a40123161ac5422f778d53ab222c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2ff54963aa301c6a7d5446583d420bf9d35dfbe159aeeac8d5f8c814dc07683',1976,'BH','Bahrain','people-and-society',41,'Population: 243,000, average annual growth rate
2.8% (2/65-4/71)
Nationality: noun—Buahraini(s): adjective—
Bahraini
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani,
and Indian, 3% other
Religion: Muslim
Language: Arabic, English also widely spoken
Literacy: about 40% (1970)
Labor force: 60,301 (1971)','af085e90b0ff01708b6e4cbf033ba9c76486481c5d3a273697183e9db91470b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd7c1915c8c2111606d9d731c3eeef96d1032e181d135eb861da5cb4f9a2b51b',1976,'BD','Bangladesh','people-and-society',46,'Population: 74,775,000, average annual growth
rate 2.8% (current)
Nationality:
Ethnic divisions: predominantly Bengali; fewer
than 1 million “Biharis” and fewer than 1 million
tribals
Religion: about 83% Muslim, 16% Hindu; less
than 1% Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 26 million; extensive un-
deremployment; over 80% of labor force is in
agriculture','5806211b4280383cc668be4f01d1930e2a9724536344fb8c972e359b17d08606','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe4b1956617b23d36534453807bae4a06ff7a364830929254a8595bf4d81744a',1976,'BB','Barbados','people-and-society',50,'Population: 239,000 (official estimate for 1 July
1973)
Nationality: noun—Barbadian(s); adjective—
Barbadian
Ethnic divisions: 80% African, 17% mixed, 4%
European
Religion: Anglican, Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1973 est.) wage and salary
earners
Organized labor: 32%','72a5ad5897a3c00957b8140d2ac39efbf41d0356313b17f0f130103c5e1f82e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f3512fec6f55a866322b07ae2bf8bcfccf19f761ff808b62905481e79a7c56c',1976,'BE','Belgium','people-and-society',54,'Population: 9,801,000, average annual growth rate
0.1% (current)
Nationality: noun—Belgian(s); adjective—Belgian
Ethnic divisions: 55% Flemings, 83% Walloons,
{2% mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in
small area of eastern Belgium: divided along ethnic
lines
Literacy: 97%
Labor force: 4.0 million: approximately 95%. is
found in the following sectors: 32% manufacturing,
24% services, 16% commerce, banking, and insurance,
8% construction, 7.5% transportation and communi-
cation, 4% agriculture, forestry, and fishing, 1.2%
mining, 0.8% public utilities and sanitary services
(1972): 7.0% unemployed, September 1975
Organized labor: 48% of labor force (1969)','1c1451aba0209dc5f4f49a7c0e0ebc1d5db5b68046688c90516fdf608d5bd31e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87e790b30cb24a94b00ee430533b7d797301776602a28f73968da7e991afb352',1976,'BZ','Belize','people-and-society',59,'Population: 140,000, average annual growth rate
2.9% (4/60-4/70)
Nationality:
Belizean
Ethnic divisions: 51% Negro, 22% mestizo, 19%
Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican,
Seventh-day Adventist, Mcthodist, Baptist, Jehovah''s
Witnesses, Mennonite
Language: English, Spanish, Maya, and Carib
Literacy: 70% -80%
Labor force: 34,500; 39%
manufacturing, 8% commerce, 12% construction and
transport, 20% services, 7% other; shortage of skilled
labor and all types of technical personnel, over 15%
are unemployed
Organized labor: 8% of labor force','7a59f3d3b8e299749a60b6a1abe93a14645d9bc008ab8cc9d8e8e28278f532b1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86d27ed9bf372e92b00ce957a03f1db0950d86f23b1d3d51c304241d7da299f9',1976,'BM','Bermuda','people-and-society',63,'Population: 57,000, average annual growth rate
1.6% (1/68-1/74)
Nationality;
Bermudan
Ethnic divisions: approximately 63% African, 37%
white
Religion: 47.5%; Church of England, 38.2% other
Protestant, 10.2% Catholic, 4.1% other
Language: English
Literacy; virtually 100%
Labor force: 24,855 (1974)
noun—Berm udan(s): adjective—
- 00800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BERMUDA/BHUTAN','f553caf86159f228acfc0c902d7c6d36503164af1ce8553e50ec66147b9010ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a523851b3b0c9d8cc5419080bf0d13b608a8d6ffebe0313f8ce4aa91ca8fdadf',1976,'BT','Bhutan','people-and-society',67,'Population: 1,187,000, average annual growth rate
2.5% (current)
Nationality: noun—Bhutanese (sing., pl.);
adjective—Bhutanese
Ethnic divisions: 60% Bhotias, 25% ethnic
Nepalese, 15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25% Bud-
dhist-influenced Hinduism
Language: Bhotias speak various Tibetan dialects,
most widely spoken dialect is Dzongkha, the official °
language; Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1%
industry; massive lack of skilled labor','02230c3ea7567d85165a626bfcb34434a2b03bb4138c47d41d4ce6a865549483','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36f8054fc1989b24b927cd694a4723669216a76e1d643a56e47bf46480a83951',1976,'IN','India','people-and-society',71,'Population: 5,480,000, average annual growth rate
2.6% (current)
20
Pacific
Ocean
CHI
{See reference map fil)
Nationality: noun—Bolivian(s); adjective—
Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35%
mestizo, 5%-15% white
Religion: predominantly Roman Catholic: active
protestant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.5 million (1972): 69.1% agriculture,
3.3% mining, 9.6% services and_ utilities, 8%
manufacturing, 10% other
Organized labor: 150,000-200,000, concentrated in
mining, industry, construction, and transportation
Population: 607,959,000 (including Sikkim and the
Indian-held part of disputed Jammu-Kashmir),
average annual growth rate 2.5% (current)
Nationality: noun—Indian(s); adjective—Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian,
3% Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh,
2.6% Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or
more persons each; numcrous other languages and
dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of
30% of the people; English enjoys “‘associate’’ status
but is the most important language for national,
political, and commercial communication; Hindu-
stani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29%
(1971 census)
Labor force: about 184 million; 70% agriculture,
more than 10% unemployed and underemployed;
shortage of skilled labor is significant and
unemployment is rising
Organized labor: about 2.5% of total labor force','0ae4554f5e04827890fdea0dc48ea45bdaf38ae82b9ef497156958e5d3867094','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4bf005cd023e52ff11707a2d9038afe0fc137a86ecc9308a23ea1ac79400e42',1976,'BW','Botswana','people-and-society',73,'Population: 685,000, average annual growth rate
2.4% (current)
21
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
BOTSWANA/ BRAZIL
Nationality: noun—Botswana (sing., pl.); adjec-
tive—Botswana
Ethnic divisions: 94% ‘Tswana, 5% Bushmen. 1%
Muropean
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English: about 326 in
Tswana; less than 1% secondary school graduates
Labor force: 385,000; most are engaged in cattle
raising and subsistence agriculture: about 51.000 in
internal cash econamy, another 60,000 spend at least
6 fo 9 months per vear as wage carners in South Africa
(1971)
Organized labor: cight trade unions organized with
a total membership of approximately 9,000 (1972 est.)
OVERNMENT
Legal name: Republic of Botswana
Uype: parliamentary republic: independent
inember of commonwealth since 1966
Capital: Gaborone
Political subdivisions: 12 administrative districts
Legal system: based on Reman-Dutch law and
iocal customary law: constitution came into effect
limited to matters of
interpretation; legal education at University of
i966; judicial review
Botswana, Lesotho and Swaziland (21% years) and
University of Edinburgh (2 years): has not accepted
compulsory IC] jurisdiction
Branches: cxecutive — President appoints and
presides over the cabinet which is responsible to
Logislative Assembly; legislative — Legislative
Assembly with 32 popularly elected members and 4
members elected by the 31 representatives, House of
Chiefs with deliberative powers only: judicial — local
courts administer customary law, High Court and
subordinate courts have criminal jurisdiction over all
residents, Court of Appeal has appellate jurisdiction
{-overnment leader: President Seretse Khama
Suffrage: universal, age 21 and over
Elections: general elections held 26 October 1974
Political parties and leaders: Botswana Demo-
cratic Party (BDP). Seretse Khama: Bechuanaland
People’s Party (BPP), Philip Matante; Botswana
Independence Party (BIP), Motsamai Mpho.
Botswana National Front (BNF). Kenneth Koma
Voting strength: (October 1974 election) BDP (27
seats); BPP (2 seats): BNF (2 seats): BIP (1 seat)
Communists: no known Cominunist organization:
Koma of BNF has long history of Communist contacts
Member of: AFDB. Commonwealth. FAO, CATT
(de facto), IBRD, IDA, IMF. ITU. OAU,ULN., GPU
WMO
to
hws','af775a1b53a1096e44e16cd99f69a5b8bc588ac2782aca9cfe0c828dc1fef52f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec8d88874e2e29cdcd0937b539fbcca227ddb695d51df9ddcf8cf70921a7a8c9',1976,'BR','Brazil','people-and-society',76,'Population: 108,720,000, average annual growth
rate 2.8% (current)
Nationality; noun—Brazilian(s); adjective—
Brazilian
Ethnic divisions: 60% white, 30% mixed, 8%
Negro, and 2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 67% of the population 15 years or older
(1970)
Labor force: about 30 million in 1970 (est. ); 44.2%
agriculture, livestock, forestry, and fishing, 17.8%
industry, 15.3% services, transportation, and
communication, 8.9% commerce, 4.8% social
activities, 3.9% public administration, 5.1% other
Organized labor: about 50% of labor force; only
about 1.5 million pay dues
Population: 193,000, average annual growth rate
3.0% (7/67-7/74)
Nationality: noun—British Solomon Islander(s):
adjective—British Solomon Islander
a
~ BRITISH SOLOMON
x ~«, iuanos
=)
&
Coral Séa
Pacific
Ocean
(See seference mag VIN)
Ethnic divisions: 93.0% Melanesians, 4.0%
Polynesians, 1.5% Micronesians, 0.3% Chinese, 0.8%
Europeans, 0.4% others
Religion: almost all at least nominally Christian;
Roman Catholic, Anglican, and Methodist churches
dominant
Literacy: 60%
Population: 157,000, average annual growth rate
8.3% (8/71-7/73)
Nationality:
Bruneian
Ethnic divisions: 52% Malays, 28% Chinese, 15%
indigenous tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8%
Christian: 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
noun—Bruneian(s); adjective—
Approved For Release 2005/04/22
Literacy: 45%
Labor force: 32,155; 30.5% agriculture, 32.8%
industry, manufacturing, and construction; 33.8%
trade, transport, services; 2.9% other
Organized labor: 8.4% of labor force','868859ea179ec23a947a9cc5f0dc69bff1c70806a201d3be17c3955116f26a19','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e83b56b66e11f169e51b1b6ed054bc229573a20fe539a6c6a8948fa8cd009bb',1976,'BG','Bulgaria','people-and-society',80,'Population: 8,773,000, average annual growth rate
0.7% (current)
Nationality:
Bulgarian
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks,
2.6% Gypsies, 2.55 Macedonians, 0.3% Armenians,
0.2% Russians, 0.6% other
Religion: regime promotes atheism. religious
background of population is 85% Bulgarian
noun—Bulgarian(s); adjective—
26
Orthodox, 13% Muslim, 0.8% Jewish, 0.7% Roman
Catholic, 0.5% Protestant, Gregorian-Armenian and
other
Language: Bulgarian; secondary languages closely
correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 4.6 million (July 1973); 32%
agriculture, 33% industry, 35% other
Population: 30,782,000, average annual growth
rate 2.3% (7/70-7/73)
Nationality: noun—Burman(s); adjective—Bur-
mese
Ethnic divisions: 72% Burman, 7% Karen, 6%
Shan, 2% Kachin, 2% Chin, 2% Chinese, 3% Indian,
6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have
their own languages
Literacy: 70% (official claim)
Labor force: 10 million; 67% agriculture, 13%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old labor
organizations have becn disbanded, and government
is forming one central labor organization','53fa610afc74ad41507b4b20764c56e7b7e877689c6b19f72fb4e83f1363ab86','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bd482d823369a7dc196cff53fc9fee957db22005e572d3c1d2ac5732c95ea3e',1976,'BI','Burundi','people-and-society',84,'Population: 3,823,000, average annual growth rate
2.4% (7/70-7/73)
Nationality: noun—Burundian(s):
Burundian
Ethnic divisions: Africans — 86% Hutu (Bantu),
13% Tutsi (Hamitic), 1% Twa (Pigmy); non-Africans
include (late 1968) 3,000 Europeans, 1,000 Asians
Religion: over 60% Christian (50% Catholic, 10%
Protestant); rest mostly animist plus small number of
Muslims
Language: Kirundi and French official
Literacy: about 55% in Kirundi, 10% in Swahili,
and 6% in French
Labor force: 1,865,471 (1970 est.)
Organized labor: sole group is the Union of
Burundi Workers (UTB), membership about 30,000,
affiliated with government party','8b42c2cd16227e5f10875a283b2db0f43eadb4107d45de0a5a65685c4b19aa1d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40c3e7fddb0fa8e004ff69863eaa96fd7d17642dd46a8e1c0c43e49c0d5247a5',1976,'KH','Cambodia','people-and-society',88,'Population: 7,718,000, average annual growth rate
2.2% (7/68-7/69)
Nationality: noun—Cambodian(s) or Khmer
(sing., pl.); adjective—Cambodian or Khmer
Ethnic divisions: 89% Khmer (Cambodian), 3%
Vietnamese, 5% Chinese, 3% other minoritics
Religion: 95% Theravada Buddhism, 5% various
other
Language: Cambodian
29
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
january 1976
CAMBODIA/CAMEROON
Literacy: 55% (est.)','5bf6d164c2a1f4e27b21ceaa74f8eac53de1c6480259026623f4f353b7bc7c8b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6b036443a89e0a7bd726794dff2e01315eb8074c78ef765c946ceac8a6d1588',1976,'GN','Guinea','people-and-society',91,'Population: 6,464,000, average annual growth rate
2.1% (current)
Nationality: noun—Cameroonian(s); adjective—
Cameroonian
Ethnic divisions: about 200 tribes of widely
differing background; 31% Cameroon Highlanders,
19% Equatorial Bantu, 8% Northwestern Bantu, 10%
Fulani, 7% Eastern Nigritic, 11% Kirdi, 13% other
African, less than 1% non-African
Religion: about one-half animist, one-third
Christian; rest Muslim
Language: English and French official, 24 major
African language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in
subsistence agriculture and herding; 200,000 wage
earners (maximum) including 22,000 government
employees, 63,000 paid agricultural workers, 49,000 in
manufacturing
Organized labor: under 45% of wage labor force
Population: 321,000, average annual growth rate
1.8% (7/68-7/69); Rio Muni, 227,000, average
annual growth rate 1.5% (7/68-7/69), Fernando Po,
59
CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
EQUATORIAL GUINEA/ETHIOPIA
94,000, average annual growth rate 2.6% (7/68-7/69)
Nationality: noun—Equatorial Guinean(s); adjec-
tive—Equatorial Guinean
Ethnic divisions: indigenous population of
Province Francisco Macias Nguema primarily Bubi,
some Fernandinos; of Rio Muni primarily Fang; less
than 1,000 Europeans, primarily Spanish
Religion: natives all nominally Christian and
predominantly Roman Catholic: some pagan
practices retained
Language: Spanish official language of govern-
ment and business; also pidgin English, Fang
Literacy: 12% (est.)
Labor force: most Equatorial Guineans involved in
subsistence agriculture
Population: 4,474,000, average annual growth rate
2.5% (current)
Nationality:
Guinean
Ethnic divisions: 99% African (3 major tribes —
Fulani, Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less
than 1%
Language: French official; each tribe has own
language
Literacy: 5% to 10%; French only significant
written language
Labor force: 1.8 million, of whom less than 10%
are wage earners; most of population engages in
subsistence agriculture
Organized labor: virtually 100% of wage labor
force loosely affiliated with the National Confedera-
tion of Guinean Workers, which is closely tied to the
PDG
Population: 75,000 (official estimate for 1 July
1972)
Nationality: noun—Sao Tomean(s); adjective—
Sao Tomean
Ethnic divisions: native Sao Tomeans, migrant
Cape Verdians, Portuguese
Religion; Roman Catholic
Language: Portuguese official
Literacy: estimated at 5%-10%
Labor force: most of population engaged in
subsistence agriculture and fishing; nearly half the
island’s work force, about 10,000 people, are
unemployed, the other half work on cocoa plantations
Population: 6,170,000, average annual growth rate
2.8% (current)
Nationality: noun—Saudi(s): adjective—Saudi
Arabian or Saudi
Ethnic divisions: 90% Arab. 10% Afro-Asian (est. )
180
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 25% of population; 40%
agriculture and herding, 12% construction, 12%
service, 12% government, 11% commerce, 13% other','252782e8ab0e3199f7a9819aa3887836e08cc1ca56ba700890f8d5f0e4ac709d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c41dfbed2e992cb9c97347d4a2550f022ae61c861e753c81b0e81dd09a6598c',1976,'CA','Canada','people-and-society',94,'Population: 22,963,000, average annual growth
rate 1.3% (7/69-7/74)
Nationality; noun—Canadian(s):
Canadian
Ethnic divisions: 44% British Isles origin, 30%
French origin, 26% other
Religion: 48% Protestant, 47% Catholic, 5% other
Language: English and French official
Labor force: 84 million, 29%
Manufacturing, 16% trade, 8% transportation and
utilities, 6% agriculture, 69% construction, 8%
7.2% unemployed
Organized labor: 27% of labor force
Population: 291,000 (official estimate for 1 July
1974)
Nationality: adjective—Cape Verdian
Ethnic divisions: about 28% African, 70%
mulatto; 2% European
Religion: Catholicism, fused with local supersti-
tions
Language: Portuguese and crioula, a blend of
Portuguese and West African words
Literacy: 14%
Labor force: bulk of population engaged in
subsistence agriculture','3e7f4a6b3f7ff1b4bc6f316b83e410227319e49351b1b3cd1c01369a19f7c32f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be4dc43512e30b99ff5cb799d39c2b084319255d0d8956f7dcc03a15bb382243',1976,'CF','Central African Republic','people-and-society',98,'Population: 1,806,000, average annual growth rate
2.2% (7/67-7/71)
Nationality: noun—Central African(s): adjective—
Central African
Ethnic divisions: approximately 80 ethnic groups,
the majority of which have related ethnic and
linguistic characteristics; Banda (32%) and Baya-
Mandjia (29%) are largest single groups; 6,500
Kuropeans, of whom 6,000 are French and majority of
the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 27%
animist, 5% Muslim; animistic beliefs and practices
strongly influence the Christian majority
Language: French official; Sangho, the lingua
franca and unofficial national language
Literacy: estimated at 5%-10%
Labor force: about half the population economi-
cally active, 80% of whom are in agriculture;
approximately 64,000 salaried workers
Organized labor; 1% of labor force','37ce4933f4b0526d1f186a6f1e00be8a2747ff083719e325181d84bc2ef29361','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efdba15decb72ae7162a32408a5c6810f38968fe0b04cf573c76be28f322d9a8',1976,'TD','Chad','people-and-society',102,'Population: 4,072,000, average annual growth rate
2.1% (7/72-7/74)
Nationality: noun—Chadian(s); adjective—
Chadian
Ethnic divisions: over 240 tribes representing 12
major cthnic groups — Muslims (Arabs, Toubou,
Fulani, Kotoko, Hausa, Kanembou, Baguirmi,
Boulala, and Wadai) in the north and center and non-
Muslims (Sara, Mayo-Kebbi, and Chari) in the south;
some 150,000 nonindigenous, 5,000 of them French
Religion: about half Muslim, 5% Christian,
remainder animist
Language: French official; Chadian Arabic is
lingua franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in
economically active group, of which 90% are engaged
in unpaid subsistence farming, herding, and fishing;
47,000 wage earners in industry and civil service
Organized labor: about 20% of wage labor force
Population: 10,675,000, average annual growth
rate 1.7% (7/73-7/74)
Nationality: noun—Chilean(s); adjective— Chile-
an
Ethnic divisions: 95% European stock and mixed
European with some Indian admixture, 3% Indian,
2% other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 89%
Labor force: 3.3 million (1973); 19% agricultural,
28% industry and construction, 29% services, 14%
commerce, 5% mining, 5% other (1973)
Organized labor: 25% of labor force (1973)','64ac51b7c29a0edb9831b381722808415cb6dd8b9296f91336e8727e63cf0bca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8852b306f5e1c60e05b616142aee7121073b108b3e1a5b53fee275fdbfa91497',1976,'CL','Chile','people-and-society',108,'Population: 953,107,000, average annual growth
tate 2.4% (current)
Nationality: noun—Chinese (sing., pl.); adjec-
tive—Chinese
Ethnic divisions: 94% Han Chinese: 6% Chuang,
Uighur, Hui, Yi, Tibetan, Miao, Manchu, Mongol,
Pu-T, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have heen
pragmatic and eclectic, not seriously religious; most
important clements of religion are Confucianism,
Taoism, Buddhism, ancestor worship: about 2%-3%
Muslim, 1% Christian
38
Approved For Release 2005/04/22
Language: Chinese (Mandarin mainly; also
Cantonese, Wu, Fukienese, Amoy, Hsiang, Kan,
Hakka dialects), and minority languages (see ethnic
divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85%
agriculture, 15% other; shortage of skilled labor
(managerial, technical, mechanics, etc.): surplus of
unskilled labor','d530b81fa660af613470f0c1092ffc8031ad61fb136b20c7d6364af08c95ff93','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df9a1ce51f2a1e3b6b291d9a2a49d191e3eae79bcd036f3a32dff07758269cc9',1976,'CN','China','people-and-society',110,'Population: 15,982,000 (excluding the population
of Quemoy and Matsu Islands and foreigners),
average annual growth rate 1.8% (1/74-1/75)
Nationality: noun—Chinese (sing., pl.); adjec-
tive—Chinese
Ethnic divisions: 84% Taiwanese, 14% mainland
Chinese, 2% aborigines
Religion: 93% mixture of Buddhism, Confucian-
ism, and Taoism; 4.5% Christian, 2.5% other
Language: Chinese Mandarin (official language),
also Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 4.9 million; 33% primary industry
(agriculture), 32.1% secondary industry (including
manufacturing, mining, construction), 34.9% tertiary
industry (including commerce and services) 1972
Organized labor: about 12% of 1972 labor force
(government controlled)','8fa95f2f87c6ffedf802f4f832ae1092fe8002a2fa852d0f2cdfa5a077155649','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04cd6627f949023e5fa66d7cc1550dbda422d41f309933bfb69691a35e943d27',1976,'CO','Colombia','people-and-society',114,'Population: 22,549,000, average annual growth
rate 3.1% (current)
Nationality: noun—Colombian(s);
Colombian
adjective—
Ethnic divisions: 58% mestizo, 20% caucasian,
14% mulatto, 4% Negro, 3% mixed Negro-Indian, 1%
Indian
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture,
13% manufacturing, 18% services, 9% commerce,
18% other (1964)
Organized labor: 13% of labor force (1968)
Population: 310,000, average annual growth rate
2.5% (current)
Nationality:
€omoran
noun—Comoran(s); adjective—
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor Force: mainly agricultural
Population: 1,364,000, average annual growth rate
2.6% (current)
Nationality: noun—Congolese (sing., pl.); adjec-
tive—Congolese or Congo
Ethnic divisions: about 15 ethnic groups divided
into some 75 tribes, almost all Bantu; most important
ethnic groups are Kongo (48%) in south, Teke (17%)
in center, M’ Bochi (12%) and Sangha (20% ) in north;
about 8,500 Europeans, mostly French
Religion: about half animist, half nominally
Christian, less than 1% Muslim
Language: French official, many African lan-
guages with Lingala and Kikongo most widely used
Literacy: about 20%
Labor force: about 40% of population economi-
cally active, most engaged in subsistence agriculture;
79,100 wage earners; 40,000-60,000 unemployed
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Organized labor: 16% of total labor force (1965
est.)','212a1f8fca4d7073f9fe298bf1a642a6fe348632203917aa8c3755a92679ddd3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9be266e9bf7a005a94630e0f5227e5e3b7a81d8bf9876f7ba100ebaa2c9d202a',1976,'CK','Cook Islands','people-and-society',118,'Population: 19,000, official] estimate for 30 June
1974
Nationality; noun—Cook Islander(s): adjective—
Cook Islander
Ethnic divisions: 81.3% Polynesian (full blood),
7.7% Polynesian and European, 7.7% Polynesian and
other, 2.4% European, 0.9% other
Religion: Christian, majority of populace members
of Cook Islands Christian Church','f1e065df116a48c151034939a3e8792b383829ff643b2a53e037ce7f771dc6b9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4580d7e41f98b6b8de2dbe8159036df599b7e65686414f9c9a31432c3453b4fe',1976,'CR','Costa Rica','people-and-society',122,'Population: 1,997,000, average annual growth rate
2.6% (7/73-7/74)
Nationality; noun—Costa Rican(s); adjective—
Costa Rican
Ethnic divisions: 98% white (including mestizo),
2% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 85%
Labor force: 585,000 (1973); 836% agriculture; 12%
manufacturing; 11% commerce, 6% construction; 5%
Approved For Release 2005/04/22
transportation, utilities; 20% service (government,
education, social); 2% finance, 8% other
Organized labor: about 11.5% of labor force
Population: 9,337,000, average annual growth rate
1.8% (current)
Nationality: noun—Cuban(s): adjective—Cuban
Ethnic divisions: 51% mulatto, 37% white, 11%
Negro, 1% Chinese
Religion: at least 85% nominally Roman Catholic
before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.36 million; 34% agriculture, 17%
industry, 6% construction, 6% transportation, 29%
services, 8% unemployed and underemployed
Organized labor: 46% of total force','8a521311e54811bce41c63a1a235a4e0e75baffc423b65a0108bed8b4f6717ae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c712fa5d61cb79284ea777822e4306676ee2c6a8056cb5944a048c1652fd92cb',1976,'CY','Cyprus','people-and-society',126,'Population: 652,000, average annual growth rate
1.19% (7/78-7/74)
Nationality: noun—Cypriot(s): adjective-——Cypriot
Ethnic divisions: 78% Greck; 18% Turkish: 4%
British, Armenian, and other
Religion: 78% Greck Orthodox, 18% Muslim, 4%
Masonite Armenian Apostolic and other
Language: Greck, Turkish, English
Literacy: about $2% of population 7 years or older
Labor force: 267,000 (1970 est.), 38% agriculture,
23% industry, 9% commerce, 2% mining, 28% other;
3,130 registered unemployed (December 1968)
Organized labor: 24% of labor force
Population: 14,866,000, average annual growth
rate 0.8% (current)
Nationality: noun—Czechoslovak(s); adjective—
Czechoslovak
Ethnic divisions: 64.3% Czechs, 30.0% Slovaks,
4.0% Magyars, 0.6% Germans, 0.5% Poles, 0.4%
Ukrainians, 0.2% others (Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant,
2% Orthodox, 1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.1 million; 18% agriculture, 37%
industry, 11% services, 34% construction, com-
munications and others
Population: 3,148,000, average annual growth rate
2.8% (8/72-8/74)
Nationality: noun—Dahomean(s); adjective—
Dahomean
Ethnic divisions: 99% Africans (42 ethnic groups,
most important being Fon, Adja, Yoruba, Bariba),
5,500 Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most
common vernaculars in south, at least 6 major tribal
languages in north
Literacy; about 20%
Labor force: 85% of labor force engaged in
agriculture; 15% civil service, artisans, and industry
Organized labor: approximately 75% of wage
earners, divided among two major and several minor
unions','b0bbb9600e74b3fa0d151f150423df50de0e57cec4e76fb87e70d33e40d80f9d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('062deda6ca9b2ffd7a35b3b7a6e12b455f3d516a95ba177fd8fb5c231bf9b062',1976,'DK','Denmark','people-and-society',130,'Population: 5,075,000, average annual growth rate
0.4% (current)
Nationality: noun—Dane(s); adjective—Danish
Ethnie divisions: homogeneous white population
Religion: 96% Evangelical I.utheran, 3% other
Protestant and Roman Catholic, 1% other
Language: Danish; small German-speaking
minority
Literacy: 99%
Labor force: 2.5 million; 9.5% agriculture, forestry,
fishing, 26.6% manufacturing, 8.3% construction,
15.7% commerce, 6.8% transportation, 5.6% services,
25.7% government, 1.8% other; 6.3% of registered
labor force unemployed (September 1974)
Organized labor: 65% of labor force
Population: 2,000 (preliminary total from the
census of 3 December 1972)
The possession of the Falkland Islands has been dis-
puted by the U.K. and Argentina (which refers to them
as the Malvinas) since 1833.
Approved For Release 2005/04/22
Nationality: noun—Falkland Islander(s); adjec-
tive—Falkland Island
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); over 95% (est.) in
agriculture, mostly sheepherding','bd8eb1552b4bd224527755c1cfbaede8842b2a6741de7d1f63dbf575b01db956','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01e4e75ad9838c34b788ea4072604cbff022efd18ba0e6388ec80073cb8b82a8',1976,'DM','Dominica','people-and-society',134,'Population: 77,000, average annual growth rate
1.6% (4/60-4/70)
Nationality: noun—Dominican(s); adjective—
Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England,
Methodist
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture
Organized labor: 25% of the labor force','1c7784f49ebe494f9722eb09e6ba5d0a04eff93cf869eddc4e3dd0e435fe8eb2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('161417935c7f648daa580b27a22167c340567f5946537f04f14b3019bed17664',1976,'DO','Dominican Republic','people-and-society',138,'Population: 4,766,000, average annual growth rate
2.9% (7/73-7/74)
Approved For Release 2005/04/22
{See reference map tl)
Nationality: noun—Dominican(s); adjective—
Dominican
Ethnic divisions: 73% mulatto, 16% white, 11%
Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 million; 73% agriculture, 8%
industry, 19% services and other
Organized labor: 12% of labor force','4a7d7cfab949a0e28389b7e35748be7b60a0ed829ae31d4b3a6e9362c26d5fe8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9378f32fd014735b52bddf7f8b07940e2e37b07ad33e01e006467bdeb0c6031f',1976,'EC','Ecuador','people-and-society',142,'Population: 6,804,000 (excluding nomadic Indian
tribes), average annual growth rate 2.9% (11/62-6/74)
Nationality: noun—Ecuadorean(s); adjective—
Ecuadorean
55
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Ethnic divisions: 40% mestizo, 40% Indian, 10%
white, 5% Negro, 5% Oriental and other
Religion: 95% Roman Catholic (majority
nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture,
13% manufacturing, 4% construction, 7% commerce,
4% public administration, 16% other services and
activities
Organized labor: less than 15% of labor force
Population: 37,714,000, average annual growth
rate 2.3% (current)
Nationality: noun—Egyptian(s); adjective—
Egyptian or United Arab Republic
Ethnic divisions: 90% Eastern Hamitic stock; 10%
Greek, Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt
and other
Language: Arabic official, English and French
widely understood by educated classes
Literacy: around 40%
Labor force: 8 to 12 million; 45% to 50%
agriculture, 10% industry, 10% trade and finance,
30% services and other; shortage of skilled labor
Organized labor: 1 to 8 million','f6991abf4bd6d47f72288eca6d17d3b66076b38033fea6e9ff85b13f5d0555a1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2994b7a88fa799ce43dab9df0260fdff0c2999660bb2e92b755b08f7ceb3c49',1976,'SV','El Salvador','people-and-society',146,'Population: 4,161,000, average annual growth rate
3.0% (7/73-7/74)
Nationality: noun—Salvadoran(s); adjective—
Salvadoran
Ethnic divisions: 84%-88% mestizo; Indian and
white minorities, 6%-8% each
Religion: predominantly Roman Catholic,
probably 97%-98%
Language: Spanish
Literacy: 50% of population 10 years of age and
over (1973 est.)
Labor force: 1,395,000 (est. 1973); 57% agricul-
ture, 14% services, 14% manufacturing, 6%
commerce, 9% other; shortage of skilled Jabor and
large pool of unskilled labor, but manpower training
programs improving situation
Organized labor: 3.5% of total labor force; 6.6% of
nonagricultural labor force (1972 est.)','f6985cbf9286c7c972547525648f2a1a360457e5ca9ed6d899a4986d5d4f7746','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58782e0ca80483594f80c8325b66706a1a87fe46c6f82d6f3b3f271d912e16e6',1976,'ET','Ethiopia','people-and-society',150,'Population: 98,302,000, average annual growth
rate 2.6% (7/73-7/74)
Nationality: noun—Ethiopian(s);
Ethiopian
Ethnic divisions: Galla 40%, Amhara and Tigrai
39%, Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%,
Gurage 2%, other 1%
Religion: 35%-40% Ethiopian Orthodox, 40% -45%
Muslims, 15%-20% animist, 5% other
Language: Amharic official; many local languages
and dialects; English major foreign language taught
in schools
Literacy: about 5%
Labor force: 90% agriculture and animal
husbandry; 10% government, military, and quasi-
Population: 40,000, average annual growth rate
0.9% (4/66-11/70)
Nationality: noun—Faeroese (sing., pl.): adjec-
tive—Faeroese
Ethnic divisions; homogeneous white population
Religion: Evangelical Lutheran
62
Languages: Faeroese (derived from Old Norse),
Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing,
manufacturing, transportation, and commerce','11b77cf35b01522dd03433f20698be7b1568fdf85714a37aa9a4a62c418e646f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7ff6722e5d526bbd4156510e7269f2dd06172d5c981383be2506da6c5fac2ff',1976,'FJ','Fiji','people-and-society',154,'Population: 575,000, average annual growth rate
1.8% (7/71-7/74)
Nationality: noun—Fijian(s): adjective—Fijian
Ethnic divisions: 42% Fijian, 50% Indian, 8%
European, Chinese and others
Religion: Fijians mainly Christian, Indians are
Hindu with a Muslim minority
Language: English and Fijian (official), Hindu-
stani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no
breakdown on remainder
Organized labor: about 50% of labor force
organized into 22 unions; unions organized along lines
of work, breakdown by ethnic origin causes further
fragmentation','7097a2cf530f5bcc73f5cdad393aea6027e6054012fd8f0648ffe2a5b4d21a8d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('694602dc5ac7f944fff13918cef77d30ec2ef044b61869fa7e475ef8492b1ac4',1976,'FI','Finland','people-and-society',158,'Population: 4,715,000, average annual growth rate
0.4% (7/74-7/75)
Nationality: noun—Finn(s); adjective—Finnish
Ethnic divisions: homogeneous white population,
small Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek
Orthodox, 1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp-
and Russian-speaking minorities
Literacy: 99%
Labor force: 2.2 million; 16.6% agriculture,
forestry, and fishing, 26.4% mining and manufactur-
ing, 8.4% construction, 15.4% commerce, 6.8%
transportation and communications, 4.0% banking
and finance, 20.1% services; 1.8% unemployed
Organized labor: 60% of labor force','bedcb5e1fc736ee3492e4ca0a3addd42349f433b09a86719a8f1260e224f9132','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('652bbee97ea0b9e9ee200f3cc336251d2a7abf6d5d9d6c07bcd2389d762f3ce4',1976,'FR','France','people-and-society',162,'Population: 53,095,000, average annual growth
rate 0.8% (1/70-1/75)
Nationality: noun—Frenchman (men); adjective—
French
Ethnic divisions: 45% Celtic; remainder Latin,
Germanic, Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish,
1% Muslim (North African workers), 13% unaffiliated
Language: French (100% of population); rapidly |
declining regional patois — Provencal, Breton,
Germanic, Corsican, Catalan, Basque, Flemish
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
St
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Literacy: 97%
Labor force: 21,900,000 (est. in October 1974);
47% services, 39% industry, 12% agriculture, 2%
unemployed
Organized labor: 17% of labor force, 23.4% of
salaried labor force','1ceb0746c6b681d553d81f22ec940fd31ec39c81da6bb30e31a4991ba45060ed','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb8aee8cbd885a4cc380749cec378c47f56d5761e76c81e42251d000f7163d9f',1976,'GF','French Guiana','people-and-society',166,'Population: 55,000, average annual growth rate
2.4% (7/68-7/73)
Nationality: noun—French Guianese (sing., pl.):
adjective—French Guiana
Ethnic divisions: 95% Negro or mulatto, 5%
caucasian, 10,000 East Indian, Chinese
68
Approved For Release 2005/04/22 :
722
‘ Adlantic Ocgan
FRENCH
< GUI
(See reference map fit}
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%,
construction 21%, agriculture 18%, industry 8%,
transportation 4%; information on unemployment
unavailable
Organized labor: 7% of labor force','b4cf2c798090a3c9c137aabf2a4e3ffe4488db63b29ab3a3c5e2a89992209135','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a724ce76476b20ee228471e8618acd97d13d26f7a650e4ea5e81534ce864f0b1',1976,'PF','French Polynesia','people-and-society',170,'Population: 120,000 official estimate for 1 July
1973
Nationality: noun—French Polynesian(s), adjec-
tive—French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chinese,
6% local French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32%
Catholic
Population: 125,000 (official estimate for 1 July
1967)
Nationality: noun—Afar(s), Issa(s); adjective—
Afars, Issas
Ethnic divisions: (approximate figures) 59,350
Somalis, mostly Issas (large number of the Somalis are
70
temporary immigrants from Somalia, not citizens of
territory), 53,650 Afars, 6,000 Arabs, 7,000 French
(inclusive of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely
used
Literacy: about 5%
Labor force: a small number of semiskilled laborers
at port
Organized labor: some 3,000 railway workers
organized
Organized labor: unorganized
148
Population: 97,000, average annual growth rate
2.6% (7/68-7/74)
Nationality: moun—New Hebridean(s); adjec-
tive—New Hebrides
Ethnie divisions: 92% indigenous Melanesian, 3%
European, remainder Vietnamese, Chinese, and
various Pacific Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%','fa6ccdf09f4136f0cbc8a207eb8f4169d70f0136493a1fee5a2f239971ca457a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5183d7f93875d3f509936879d034aa7a0e6bfc55c2cd258b3ff59fdc65490408',1976,'GA','Gabon','people-and-society',174,'Population: 548,000, average annual growth rate
1.7% (7/66-7/70)
Nationality: noun—Gabonese (sing., pl.); Gabo-
nese
Ethnic divisions: about 40 Bantu tribes, including
4 major tribal groupings (Fang, Eshira, Mbede,
Okande); about 21,000 expatriate Africans and
Europeans, including 14,000 French
Religion: 55% to 75% Christian, less than 1%
Muslim, remainder animist
Language: French official language and medium
of instruction in schools; Fang is a major vernacular
language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are
wage carners in the modern sector
Organized labor: less than 30% of wage labor force','575fe0284eddbbfa2b0fbdd72a9e5ba98aab86ccd72574724558b77c44139049','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee4cb96d47bb2e96edaf339c9a6351db26f62326d57b1ab0ac93460258d297fe',1976,'GM','Gambia','people-and-society',178,'Population: 529,000, average annual growth rate
2.5% (7/68-7/74)
Nationality:
Gambian
Ethnic divisions: over 99% Africans (Malinke
40.8%, Fulani 13.5%, Wolof 12.9%, remainder made
up of several smaller groups), fewer than 1%
Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Malinke and Wolof
most widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in
subsistence farming; about 15,000 are wage earners
(government, trade, services)
Organized labor: 25% to 30% of wage labor force
at most
Population: 16,866,000 (including East Berlin),
average annual growth rate —0,2% (current)
Nationality: noun—German(s); adjective—Ger-
man
Ethnic divisions: 99.7% German, 3% Slavic and
other
Religion: 53% Protestant, 8% Roman Catholic,
39% unaffiliated or other; less than 5% of Protestants
and about 25% of Roman Catholics actively
participate
Language: German, small Sorb (West Slavic)
minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7%
handicrafts; 6.8% construction, 11.9% agriculture;
6.8% transport and communications; 10.1%
commerce; 16.8% services; 2.5% other
Organized labor: 87.7% of total labor force
Population: 62,989,000 (including West Berlin),
average annual growth rate 0.2% (current)
Nationality; noun—German(s); adjective—Cer-
man
Ethnic divisions: 99% Germanic, 1% other
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
GERMANY, WEST
(See reference map 1V}
Religion: 49% Protestant, 44.6% Roman Catholic,
6.4% other
Language: German
Literacy: 99%
Labor force: 26.7 million; 44.1% in manufacturing
and construction, 15.2% services, 12.8% commerce,
8.2% government, 7.2% agriculture, 5.4% com-
munication and transportation, 1% mining; 2.6%
average unemployed as of 1974, excluding self
employed
Organized labor: 31% of total labor force; 37.5% of
wage and salary earners','f95c700d1b653c5c220e1735677464210eb880bd7b1de1a0e76c358ffc52e729','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('257070396ea983b94204f4776515c47336146d1835155d38622a0d35bddf3902',1976,'GH','Ghana','people-and-society',182,'Population: 10,017,000, average annual growth
rate 2.8% (7/72-7/74)
Nationality: noun—Ghanaian(s); adjective—
Ghanaian
Ethnic divisions: 99.8% Negroid African (major
tribes Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12%
Muslim
Language: English official; African languages
include Akan 44%, Mole-Dagbani 16%, Ewe 13%,
and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and
fishing, 16.8% industry, 15.2% sales and clerical, 4.1%
services, transportation, and communications, 2.9%
professional; 400,000 unemployed
Organized labor: 350,000 or approximately 10% of
labor force','6ebd41a89fb936f64e787e7bd5a448c5010d2dba142230299d91602858349b0e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e22a686f0c2ddad31dadaa547425ca458c8cfe55b649bb946c6083ee37b49b5d',1976,'GI','Gibraltar','people-and-society',186,'Population: 30,000 (official estimate for 1 July
1973)
Nationality: noun—Gibraltarian(s); adjective—
Ethnic divisions: mostly Italian, English, Maltese,
Portuguese and Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary
languages; Italian, Portuguese, and Russian also
spoken; English used in the schools and for all official
purposes
77
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
0001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A00080001
January 1976
CIBRALTAR/GILBERT AND ELLICE ISLANDS
Literacy: illiteracy is negligible
Labor force: approx.
Gibraltarian laborers
14,800, including non-
Organized labor: over 6,000','64d652eeb710d779645a9774abc9af6108daa01cc9185df9e56fae23dfbaadec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7e0f78ba1262925a5317aa9829a7c2176cf9e3cf0ae6fe9cb6197798a53e788',1976,'NL','Netherlands','people-and-society',191,'Population: 67,000, average annual growth rate
2.5% (7/63-7/73)
Nationality: noun—Gilbertese, Ellis Islander(s) or
Gilbert and Ellis Islander(s); adjective—Gilbertese,
Ellis Islander, or Gilbert and Ellis Islander
Ethnie divisions: 83.9% Micronesian, 13.9%
Polynesian, 0.9% European, 0.1% Chinese, 1.2%
mixed and other races
Religion: mainly Christian; 55% Protestants, 42%
Catholics
Literacy: less than 50%
Population: 18,715,000, average annual growth
rate 0.9% (current)
Nationality: noun—Netherlander(s); adjective—
Ethnic divisions: 99% Dutch, 1% Indonesian and
other
Religion: 41% Protestant, 40% Roman Catholic,
19% unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9%
construction, 7% transportation and communications,
4% other; 4.8% unemployment (August 1975)
Organized labor: 33% of labor force
Population: 241,000, average annual growth rate
1.5% (1/74-1/75)
Nationality: noun—Netherlands Antillean(s);
adjective—Netherlands Antillean
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
NETHERLANDS ANTILLES
Atlantic Ocean
.
e
6
“NETHERLANDS. °
© Caribbean
2 ANTILLES
ea.
.
‘See reference map fH)
Ethnic divisions: 85% largely faixed Negro stock
except on Aruba where 12% Negro and approx. 55%
mixed Carib Indian and European; rest European
with some Chinese, especially on Aruba
Religion: predominantly Roman Catholic; sizable
Protestant, smaller Jewish minorities
Language: officially Dutch; predominantly
English; colloquial ‘‘papiamento,’’ a Spanish-
Portuguese-Dutch-English mixture
Literacy: 75%-80%
Labor force: 66,000; 1% agriculture, 21% industry,
21% unemployed, 8% construction, 41% government
and services, 8% other
Organized labor: approx. 15% of labor force','fd9ff1134bceddb59a51dedd642bf7e85570241f6ac04d220bb4005f2bdab383','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f368318016a9b23b0c67f05b3b967fff7eedff7704488b3eab87dd7d23e73ceb',1976,'GR','Greece','people-and-society',194,'Population: 9,026,000, average annual growth rate
0.5% (7/70-7/74)
Nationality: noun—Greek(s); adjective—Greek
Ethnic divisions: 96% Greek, 2% Turkish, 1%
Albanian, 1% other
Religion: 97% Greek Orthodox, 2.5% Muslim,
0.5% other
Language: Greek; English and French widely
understood
Literacy: males about 92%; females about 73%;
total about 82%
Labor force: 3,866,000 (1969 est.); 50% agricul-
ture, 15% industry, 9% trade, 26% other; unemploy-
ment and underemployment, 20% total in all fields;
shortage of skilled labor in nonagricultural sectors
aggravated by large-scale emigration
Organized labor: 10% of labor force','5517005e281a1180838fc15a60c2ca1e0daec9aa59af3cb3e167c47e0131f445','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('518f888ac509da4531c75b3443112500bbc392f34c9a1eb8aae465daf6322766',1976,'GL','Greenland','people-and-society',198,'Population: 51,000, average annual growth rate
1.6% (1/72-1/74)
Nationality: noun—Greenlander(s); adjective—
Ethnic divisions: 86% Greenlander (Eskimos and
Greenland-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and
sheep breeding','f4b47925b0a7d62d1814e9c4d558d9e37051b32424838d1d16a3aa27f2130eee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7840cbe7be1a4d46fb20dbf5160788638cf25e6a39e241eeb7554147a6a7c14a',1976,'GD','Grenada','people-and-society',202,'Population: 98,000, average annual growth rate
0.6% (4/60-4/70)
Nationality: noun—Grenadian(s); adjective—
Grenadian
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant
sects; Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 27,314 (1960): 40% agriculture, 30%
unemployed or underemployed
Organized labor: 33% of labor force','981f9f74c4cd6b931dce924a2ea1b982201471575fc1eec0c6ecbdf1ef13860d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('079fa88a399063b10ab484454130f6070451c9dbef9b4b5748b2f3f3705495b7',1976,'GP','Guadeloupe','people-and-society',206,'Population: 355,000, average annual growth rate
1.5% (7/72-7/78)
Nationality: noun—Guadeloupian(s); adjective—
Ethnic divisions: 90% Negro or Mulatto, less than
5% East Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and
pagan African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25%
unemployed
Organized labor: 11% of labor force','2c7faa47ae24755453d19841765834c38ba2e75f7b9f305f9294130c65a1919d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55021019c35d15fe4d55f8d494a92a59d5a7dde77132aa9efa954d3fbb3c8f56',1976,'MX','Mexico','people-and-society',212,'Population: 5,934,000, average annual growth rate
2.8% (7/72-7/73)
Nationality: noun—Guatemalan(s); adjective—
Guatemalan
Ethnic divisions: 41.4% Indian, 58.6% Ladino
(mestizo and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the
population speaks an Indian language as a primary
tongue
Literacy: about 30%
Labor force (1974): 1.75 million; 65% agriculture,
11.3% manufacturing; 11.2% services, 6.4% to
commerce, 2.6% construction, 2.4% transport, 0.2%
mining, 0.2% electrical, 0.8% other. Unemployment
estimates vary from 3 to 25%
Organized labor: 4% of labor force (1974)','91a85937d9e9f1807a9a62000189b0bc6efaa5138d8f54c36804f15ab964c00d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fd955bc364637d0934c42b2ab4d9dd3b427514d0f34f44df80e86a83161155d',1976,'GW','Guinea-Bissau','people-and-society',216,'Population: 509,000, average annual growth rate
1.8% (current)
Nationality:
Guinean
Ethnic divisions: about 99% African (Balanta 30%,
Fulani 20%, Mandyako 14%, Malinke 13%, and 23%
other tribes); less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portugucse and numerous African
languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in
subsistence agriculture','ce888e8853ab0e7f1ddd9f5d0891eb6e3a77d19da5606343c904260b43b08207','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06629e72dc2325ad8ae6575848abba61d624a6424bbe2dcb78598d57573adcec',1976,'GY','Guyana','people-and-society',220,'Population: 800,000, average annual growth rate
2.2% (current)
Nationality; noun—Guyanese (sing., pl.); adjec-
tive—Guyanese
Ethnic divisions: 51% East Indians, 43% Negro
and Negro mixed, 4% Amerindian, 2% white and
Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim,
1% other
Language: English
Literacy: 86%
Labor force: 201,000; about 25% agriculture, 14%
manufacturing, 16% services, 11% commerce, 3%
mining and quarrying, 10% other; 21% unemployed
Organized labor: 34% of labor force
Population: 4,615,000, average annual growth rate
1.7% (8/73-8/74)
Nationality: noun—Haitian(s); adjective—Haitian
Ethnic divisions: over 90% Negro, nearly 10%
mulatto, few whites
Religion: 10% Protestant, 75% to 80% Roman
Catholic (of which an overwhelming majority also
practice Voodoo)
Language: French (official) spoken by only 10% of
population; all speak Creole
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
eee es
January 1976
Approved For
Release 2005/04/22 : CIA-RDP79-01051A000800
010001-8
HAITI/ HONDURAS
Literacy: 10% to 12%
Labor force: 2.6 million (est. January 1968); 86%
agriculture, 12% industry, 2% unemployed; shortage
of skilled labor; unskilled labor abundant
Organized labor: less than 1% of labor force','95196a20d699901d9a7c35bee9581250431ac1848db702f45b44b22f9a0bf4f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5b642b533128da900225295ba90d1eab09e94787a4a9b3cdbea4091402219b3',1976,'HN','Honduras','people-and-society',224,'Population: 2,786,000, average annual growth rate
2.7% (4/61-3/74)
89
-8
- 1A000800010001
ed For Release 2005/04/22 : CIA-RDP79-0105
Approv
January 1976
Caribbean
(See reference map tl}
Nationality; noun—Honduran(s).
Honduran
Ethnic divisions: 90% mestizo, 7% Indian, 2%
Negro, and 1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 57,47 of persons 10 years of age and over
(est, 1970)
Labor force; 8pprox. 900,000 (est. mid-1972). 66%
agriculture, 12% Services, 8% manufacturing, 5%
commerce, 6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-
972)
adjective—','863a15739dafc12571a285eab11351f4accdea5a5da745f4aafdb9358725ecb5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9702ac04bca3d99df4337686cac9641ab52beb28d281857e8fda68f14e1000e',1976,'HK','Hong Kong','people-and-society',228,'Population: 4,354,000, average annual growth rate
1.6% (7/T71-7/74)
Nationality: adjective—Hong Kong
Approved For Release 2005/04/22
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of
local religions
Language: Chinese, English
Literacy: 75%
Labor force (1971 est.): 1.58 million; 43%
manufacturing, 20% services, 11% construction,
mining, quarrying and utilities, 13% commerce, 4%
agriculture, forestry, fisheries, and hunting, 7%
communications, 2% other; underemployment is 4
serious problem
Organized labor: 12% of 1969 labor force','5022c774d63323c2969dce46962dd4842b7a0db75e1dd0ecbeae8d878e5aa882','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b36f9b516d0547b5af180b04e57706e6a95fbd7f7f770c4388d2facb3ba861e',1976,'HU','Hungary','people-and-society',232,'Population: 10,572,000, average annual growth
rate 0.6% (current)
Nationality: noun—Hungarian(s):
Hungarian
Ethnie divisions: 93.3% Magyar, 2.5% German,
2.4% Gypsy, 0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0%
5.0% Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy; 97%
Labor force: 5,073,600 (1 January 1974); 23%
agriculture, 44% industry and building, 16% trade
and transport, 17% other nonagricultural','4cfd4dbbc1927dfc52de0684deb719ea852ef2e88884f8c3798237ca6f000658','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af7116bb471b0d00f48363c97286c62643bd7e28514baba5478aeff5efce281e',1976,'IS','Iceland','people-and-society',236,'Population: 220,000, average annual growth rate
1.3% (12/69-12/74)
Nationality: noun—lIcelander(s); adjective—
Icelandic
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other
Protestant and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 85,000; 22.6% agriculture and
fishing; 25.6% mining and manufacturing; 10.7%
construction; 12.8% commerce; 7.8% transportation
and communications; 15.2% services; and 5.7% other:
unemployment is insignificant
Organized labor: 60% of labor force','563af13c6f34798f48edcc46e3e19ab936f70b686667e3f84fd240c39e7be67f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad21041865a97d9752ce57e406df13c71102d306b04d40826bfd2e162600b299',1976,'ID','Indonesia','people-and-society',240,'Population: 132,598,000 (including West Irian),
average annual growth rate 2.6% (current)
Nationality: noun—TIndonesian(s); adjective—
Indonesian
Ethnic divisions: 45% Javanese, 14% Sundanese,
7.5% Madurese, 7.5% Coastal Malays, 26% other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
INDONESIA/IRAN
Religion: 90% Muslim, 4%
Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay)
official; English, and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 44 million; 70% agriculture, 15%
industry, 15% miscellaneous and unemployed
Organized labor: 10% of labor force
Population: 33,683,000, average annual growth
rate 3.0% (7/70-7/73)
Nationality: noun—lIranian(s); adjective—Iranian
Ethnic divisions: 63% Ethnic Persians, 3% Kurds,
13% other Iranian, 18% Turkic, 3% Arab and other
Semitic, 1% other
Religion: 93% Shia Muslim; 5% Sunni Muslim:
2% Zoroastrians, Jews, Christians and Baha is
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 37% of those 7 years of age and
older (1972 est.)
Labor force: 9.8 million est. 1975; 41% agriculture,
20% manufacturing; shortage of skilled labor
substantial','54cedc906d80575abb7a71af4d825a76a53292a904d8d5f91e29f5b1f4c38387','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52d1e58b343336dcacfbabd7057bc30dc7e85a2ba6e5ea7b7031a459b8589d4b',1976,'IQ','Iraq','people-and-society',244,'Population: 11,210,000, average annual growth
rate 3.4% (10/73-10/74)
Nationality: noun—Iraqi(s); adjective—Iraqi
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7%
Assyrians, 2.4% Turkomans, 7.7% other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks
Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5%
industry, 6.7% government, 16.8% other; rural
underemployment high, but not serious because low
subsistence levels make it casy to care for
unemployed; severe shortage of technically trained
personnel
Organized labor: 11% of labor force','00769d7112e9965ffc1b879843735b529256ffb2944dc76e7ae8146de0e504b0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e62bd6353384ad241b815519fa7daec76453c9625217d05b3d49871805c357b4',1976,'IE','Ireland','people-and-society',248,'Population: 3,121,000, average annual growth rate
0.7% (7/64-7/74)
Nationality: noun—Irishman(men), Irish (collec-
tive pl.); adjective—Irish
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2%
other
Language: English and Gaelic official; English is
generally spoken
Literacy: 98% -99%
Labor force: about 1,134,000 (1971); 26%
agriculture, forestry, fishing; 19% manufacturing;
15% commerce; 7% construction; 5% transportation:
4% government; 24% other; 8.9% unemployment
(September 1975)
Organized labor: 36% of labor force','a8eac43b623f37ff7a94e9a11e814de74c7690db75f9df18a75a29b8c4bea8f2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72284ec04621f2e4d3f2d2dde63fd1a4eee62a45627fc1fe5e5ab0e166674240',1976,'IL','Israel','people-and-society',252,'Population: 3,408,000 (excluding West Bank and
Kast Jerusalem), average annual growth rate 2.2%
(7/74-7/75)
Nationality: noun—lIsraeli(s); adjective—Israel
Ethnic divisions: 85% Jews, 15% non-Jews (mostly
Arabs) ,
Religion: 89% Judaism, 8% Islam, 3% other
Language: Hebrew official: Arabic used officially
for Arab minority; English most commonly used
foreign language
Literacy: 88% Jews, 48% Arabs
Labor force: 1,122,900: 6.5% agriculture, forestry
and fishing; 25.3% manufacturing (mining, industry);
0.9% electricity and water; 8.1% construction and
public works; 12.2% commerce; 7.7% transport,
storage, and communications; 6.5% finance and
business; 26.1% public services: 6.7% personal and
other services (1974)
Organized labor: 90% of labor force','5f64fd50187f4a9f6bf1ea24206f13971835162c07c235f2eb56333ebf2a1f7a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23143a54430738349d10b7ff5018cdc3be4ae8bab2a232f0b172abcb7fa3b696',1976,'IT','Italy','people-and-society',256,'Population: 56,044,000, average annual growth
rate 0.7% (1/65-1/75)
Nationality: noun—Italian(s); adjective—lItalian
Ethnic divisions: primarily Italian but population
includes small clusters of German-, French-, and
Slovene-Italians in the north and of Albanian-Italians
in the south
Religion: almost 100% nominally Roman Catholic
(de facto state religion)
Language: Italian; parts of Trentino-Alto Adige
Region (e.g., Bolzano) are predominantly German
speaking; significant French-speaking minority in
Valle d’Aosta Region; Slovene-speaking minority in
the Trieste-Gorizia area
Literacy: 5%-7% of population illiterate (1972);
illiteracy varies widely by region
Labor force: 19,549,000 (January 1975); 15.0%
agriculture, 42.9% industry, 39.0% other, 3.4%
unemployed (July 1975); underemployment, par-
ticularly in southern Italy, remains widespread; 1.5
million Italians employed in other Western European
countries
Organized labor: 20% (est.) of labor force
Population: 4,950,000 (resident African population
only), average annual growth rate 2.6% (current)
Nationality: noun—Ivorian(s); adjective— Ivorian
Approved For Release 2005/04/22
Ethnic divisions: 7 major indigenous ethnic
groups; no single tribe more than 20% of population;
most important are Agni, Baoule, Krou, Senoufou,
Mandingo; approx. | million foreign Africans, mostly
Voltaics; about 33,000 non-Africans (25,000 French)
Religion: 66% Muslim, 12%
Christian
Language: French official, over 60 native dialects,
Dioula most widely spoken
Literacy: about 20%
Labor force: over 85% of population engaged in
agriculture, forestry, livestock raising; about 11% of
labor force are wage earners, nearly half in agricul-7
ture, remainder in government, industry, commerce,
animist, 22%
and professions
Organized labor: 20% of wage labor force','2aa44cbfd54acf2c950768628973dbf2b47e202bda96d652e90b4ce6432e2fd4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe19a32bc03fc93d68b6853dcdf0506a3bb7d38d683615338a5f4e646a96513b',1976,'CU','Cuba','people-and-society',260,'Population: 2,073,000, average annual growth rate
1.9% (7/71-7/73)
Nationality:
Jamaican
Ethnic divisions: African 76.3%, Afro-European
15.1%, Chinese and Afro-Chinese 1.2%, East Indian
and Afro-East Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman
Catholic, some spiritualist cults
noun—Jamaican(s); adjective—
Language: English
Literacy: government claims 82%, but probably
only about one-half of that number are functionally
literate
Labor force: 810,700 (1973); 26% in agriculture,
forestry, fishing and mining, 10% manufacturing, 8%
public administration, 5% construction, 10%
commerce, 3% transportation and utilities, 15%
services, 22% unemployed (seasonal unemployment in
agriculture can push the unemployment figure to
25%): shortage of technical and managerial personnel
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
JAMAICA/JAPAN
Organized labor: about 25% of labor force (1966)','d75448b75fd52fcb5ee78b82cfe2422d8b9b064dd351fe5759828bd818027ccc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5cbb0b00d472ab336556c474530dd143d1d71f3cdbe0a4051acfd112e9b227c',1976,'JP','Japan','people-and-society',264,'Population: 111,580,000 (including Ryukyus),
average annual growth rate 1.1% (7/64-7/74)
107
: CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Pacific
Philippine
Sea
(See reference map Vii)
Nationality: noun—Japanese (sing., pl.); adjec-
tive—Japanese
Ethnic divisions: 99.2% Japanese, .8% other
(mostly Korean)
Religion: most Japanese observe both Shinto and
Buddhist rites: about 16% belong to other faiths,
including 0.8% Christian
Language: Japanese
Literacy: 97.8% of those 15 years old and above
(1960 data)
Labor force (1974 figures): 52.4 million;
10.7% agriculture, forestry, and fishing; 37.5%
manufacturing, mining, and construction; 39.5%
trade and services; 7% transportation; 3.4%
government; 1.7% unemployed; shortage of skilled
labor 1.5 million; unskilled .5 million (est. )
Organized labor: 20% of labor force
Population: 16,762,000, average annual growth
rate 3.1% (current)
Nationality: noun—Korean(s); udjective—Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism, religious
activities now almost nonexistent
Language: Korean
Literacy: 90% (est. )
Labor force: 6.1 million; 48% agriculture, 52%
non-agricultural; shortage of skilled and unskilled
labor
Population: 34,463,000, average annual growth
rate 2.0% (current)
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: homogeneous; small Chinese
minority (approx. 20,000)
Religion: strong Confucian tradition; pervasive
folk religion (Shamanism); vigorous Christian
minority (5.5% of population); Buddhism (including
estimated 20,000 members of Soka Gakkai);
Chondokyo (religion of the heavenly way), eclectic
religion with nationalist overtones founded in 19th
century, claims about 1.5 million adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.5 million (1972); 48%
agriculture, fishing, forestry; 15% services; 13%
mining and manufacturing; 12% commerce; 12%
other
Organized labor: about 10% of nonagricultural
labor force','4e6c61f935a69bbb3871051f6ca7bbcc6b0a5b1a748964428eeee202d941ecf3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c562e9fdcd47eafbb08b7e6543d2eea6e4a67db3bdfc1d4e6843adb95fc98626',1976,'JO','Jordan','people-and-society',268,'Population: 2,745,000 (including West Bank and
East Jerusalem), average annual growth rate
3.2% (7/73-7/74)
Nationality: noun—Jordanian(s); adjective—
Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, 1%
Armenian
Religion: 95% Sunni Muslim, 5% Christian
Language: Arabic official, English widely
understood among upper and middle classes
Literacy: about 50% in East Jordan; somewhat less
than 60% in West Jordan
Labor force: 564,000; 33% unemployed
Organized labor: 5% of labor force','c69b090b0ee4ef0307624e91ee57e84d681682f83211e932ccb14c3af7e3b860','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5bcb0696849bc40fa1af96198467b2d857d301cbbcb3794d971034051d71c8e',1976,'KE','Kenya','people-and-society',272,'Population: 13,587,000, average annual growth
rate 8.4% (7/73-7/74)
Nationality: noun—Kenyan(s); adjective—Kenyan
Ethnic divisions: 97% native African (including
Bantu, Nilotic, Hamitie and Nilo-Hamitic); 2%
Asian; 1% European, Arab and others
Religion: 56% Christian, 36% animist, 7% Muslim,
1% Hindu
Language: English and Swahili official: each tribe
has own language
Literacy: 27%
Labor force: 2.5 million; about 977,000, (39%) in
monetary economy (1967)
Organized labor: about 215,000','8022da8896e5c455de36720f8ff54fa663c2983ec7c1c6f91846535929fbcc1f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dce4f1ea981ffd298e70c0751f313bf3c2016166033c9121117e954a107c942',1976,'KW','Kuwait','people-and-society',276,'Population: 1,032,000, average annual growth rate
6.1% (4/70-4/75)
114
Approved For Release 2005/04/22
Nationality: noun—Kuwaiti(s); adjective—Ku-
waiti
Ethnic divisions: 85% Arabs, 13%
Indians, and Pakistani
Religion: 99% Muslim, 1% Christian, Hindu,
Parsi, other
Iranians,
Language: Arabic; English commonly used foreign
language
Literacy: about 60%
Labor force: 238,000 (1970): 41% manufacturing,
25% services, 22% government and professions, 9%
commerce
Organized labor: labor unions, first authorized in
1964, formed in oil industry and among government
personnel
Population: 3,375,000, average annual growth rate
2.4% (7/78-7/74)
Nationality: noun—Lao (sing., pl.); adjective—
Lao or Laotian ;
Ethnic divisions: 47% Lao; 14% Tribal Tai; 25%
Phoutheung (Kha); 14% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant
foreign language
Literacy: about 12%
Labor force: about 1,268,000; 80%-90% agri-
culture; 159,286 engaged in manufacturing and
services; 28,400 (22,400 civil and 6,000 police)
government employees in FY72
Organized labor: only labor organization is
subordinate to the Communist Party','595fee5a9aaa5d14be4d34c1e741879c316584fc180ff8d1efbbdce6d24749aa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('108ae09414cf567037cc3522f5299dff2f955acece0a765f778d1f2b6baa1bb1',1976,'LB','Lebanon','people-and-society',280,'Population: 2,486,000, average annual growth rate
3.1% (current)
Nationality: noun—Lebanese (sing. and_ pl.):
adjective-—Lebanese
Ethnic divisions: 93% Arab, 6% Armenian, 1%
other
Religion: 55% Christian, 44% Muslim and Druze,
1% other (official estimates); Muslims, in fact,
constitute a majority
Language: Arabic (official);
spoken
Literacy: 86%
Labor force: about 1 million economically active:
49% agriculture, 11% industry, 14% commerce, 26%
other; moderate unemployment
French is widely
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
LEBANON/LESOTHO
Organized labor: about 65,000','4d2a0d718c150311db6006aed147c6c08a1ab1f8d930230ab5713a79771bacb4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c284c0f053f480522f86985d6825c19724119187250c56ea5f5f36eb6711490c',1976,'LS','Lesotho','people-and-society',284,'Population: 1,050,000, average annual growth rate
2.2% (7/73-7/74)
Nationality:
Basothan
Ethnic divisions: 99.7% Sotho, 1,600 Europeans,
800 Asians
Religion: 70% or more Christian, rest animist
noun—Basothan(s); adjective—
Language: all Africans speak Sesotho vernacular;
English is second language for literates
117
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
‘ndian Qcean
(See reference mag V1)
Literacy: 40%
Labor force: 87.4% of resident population engaged
in subsistence agriculture; 150,000 to 250,000 spend 6
months to many years as wage earners in South Africa
Organized labor: negligible','57351d873e26c5b74ee359beef64e30fa3d4a9bf95e1a401387eb60941bd6829','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eeb42cbf3e37c401403c4219842e18c6d2c92cd25186235687138135676d69b4',1976,'LR','Liberia','people-and-society',288,'Population: 1,787,000, average annual growth rate
2.9% (current)
Nationality: noun—Liberian(s); adjective—
Liberian
Ethnic divisions: 5% descendants of immigrant
Negrocs, 95% indigenous Negroid African tribes
including Kpelle, Bassa, Kru, Grebo, Gola, Kissi,
Krahn, and Mandingo
Religion: probably more Muslims than Christians;
70%-80% animist
Language: English official; 28 tribal languages or
dialects, pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 600,000, of which 120,000 arc in
monetary economy, about 2,000 non-African
foreigners hold about 95% of the top level
management and engineering jobs
Organized labor: 2% of labor force','ff9391b252021748b0b329248c50166155acd23d9d2543913755eefd63daeab8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44fead26cea827ca4dc98a9947ce37b222554bdd281e7f206128a85a9795ec5c',1976,'LY','Libya','people-and-society',292,'Population: 2,462,000, average annual growth rate
3.7% (7/73-7/74)
120
Approved For Release 2005/04/22 :
{See reference map vi}
Nationality: noun—Libyan(s); adjective—Libyan
Ethnic divisions: 97% Berber and Arab with some
Negro stock; some Greeks, Maltese, Jews, Italians,
Egyptians
Religion: 97% Muslim
Language: Arabic; Italian and English widely
understood in major cities
Literacy: 35%
Labor force: 485,000; between ages 15-64,
405,000-430,000; 61% of labor force in agriculture
(1964)','8edc48cf7c4f0d8d2aceb916c3ee8a5226fb3a6532d886216e42d706faa09243','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14d2a6bb643061970d06e7e577858e3c5de615c07567799557820caa1a0aea53',1976,'LI','Liechtenstein','people-and-society',296,'Population: 24,000, average annual growth rate
2.5% (12,/60-12/70)
Nationality: noun—Liechtensteiner(s); adjective—
Ethnic divisions: 95% Germanic, 5% Italian and
other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly
from Austria and Italy); 59% industry, 20% trade and
commerce, 13% professional and other, 8%
agriculture','eb2dec20b3de1b68c3774b87f6e0fca6e6b2f393c25c78c3ba5b13a7eebde988','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd29d07e49a7d8ab496974673a26a742fe0c2806589f8fd97eb6cadf1de8e166',1976,'LU','Luxembourg','people-and-society',301,'Population: 359,000, average annual growth rate
0.8% (7/66-7/74)
Nationality: noun—Luxembourger(s); adjective—
Ethnic divisions: 83% Luxembourger, including an
estimated 5% of Italian descent; remainder French,
German, Belgian, etc.
Religion: 97% Roman Catholic, remaining 3%
Protestant and Jewish
Language: Luxembourgish, German, French; most
educated Luxembourgers also speak English
Literacy: 98%
Labor force: (1974) 158,000; 10% agriculture
(including forestry and fishing), 48% industry, 42%
services; 830% of labor force is foreign, comprising
workers from neighboring areas of Belgium, France,
and West Germany, as well as Italy and Portugal,
unemployment 0.1% August 1975
Organized labor: 45% of labor force','1d2ddddceb51972241108980c3ee66191d47633d03720cbe5734b43c620b69a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2883fd0c4dd146564dee8092db49bc4a0dd873dca99553292dff4981016e4468',1976,'PH','Philippines','people-and-society',306,'Population: 251,000 (official estimate for 1 July
1972)
Nationality:
Macaon
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics,
about one-half are Chinese
Language: Chinese 98%, Portuguese 2%
Literacy: almost 100% among Portuguese and
Macanese; no data on Chinese population
Labor force: 5% agriculture, 30% manufacturing,
3% construction, 1% utilities, 27% commerce, 8%
transportation and communications, 26% services
(1960 data)
Population: 43,531,000, average annual growth
rate 3.2% (current)
Nationality: noun—Filipino(s); adjective—Philip-
pine
Ethnic divisions: 91.5% Christian Malay, 4%
Muslim Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant,
4% Muslim, 3% Buddhist and other
16
Language: Tagalog (renamed Pilipino) is the
national language of the Philippine Republic; English
is the language of school instruction and government
business
Literacy: about 83%
Labor force: 11 million; 60% agriculture, forestry,
fishing, 12% manufacturing, 10.5% commerce, 10.5%
government and services (business, recreation,
domestic, personal), 3.5% transport, storage,
communication, 3% construction; 0.5% other','f90f0aaf9dfd63bbe8fe0669381937e761b644659b71a12ae5202ab1a38f7bc5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9203e377034ae0f0045f09959d4b836f5186db57b9ffe02d764dd13b86287da5',1976,'MG','Madagascar','people-and-society',310,'Population: 7,639,000, average annual growth rate
2.3% (7/69-7/70)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
\\ TANZANIA J
Tananarive
x
MADAGASCAR ©
SSOUTH AERICA
(See reference map VI}
Nationality: noun—Malagasy (sing. and _pl.);
adjective—Malagasy
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting
of Merina (1,643,000) and related Betsileo (760,000),
on the one hand, and coastal tribes with mixed
Negroid, Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include Betsimisaraka
941,000, Tsimihety 442,000, Sakalava 375,000,
Antaisaka 415,000; there are also 38,000 French,
66,000 other
Religion: more than half animist; about 41%
Christian, 7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are
nonsalaried family workers engaged in subsistence
agriculture; of 175,000 wage and salary earners, 26%
agriculture, 17% domestic service, 15% industry, 14%
commerce, 11% construction, 9% services, 6%
transportation, 2% miscellaneous
Organized labor: 4% of labor force
Population: 59,000, average annual growth rate
2.3% (7/68-7/73)
Nationality: noun—Seychellois (sing. & pl.);
adjective—Seychelles
Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans)
Religion: 90% Roman Catholic
. Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
SEYCHELLES/SIERRA LEONE
Language: English official; Creole most widely
spoken
Literacy: limited
Labor force: 22,000 agriculture
Organized labor: 3 major trade unions','f3093077c0b438801b3f9ff1cb0c4640f733fc28e785917b836ebf10dbfe497f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cac3590fba529015664746ad86bbf7957384e0d8048d72b84c00091525fc12c3',1976,'MW','Malawi','people-and-society',314,'Population: 5,084,000, average annual growth rate
2.5% (7/72-7/74)
Nationality: noun—Malawian(s);
Malawian
Ethnic divisions: over 99% native African, less than
1% European and Asian
Religion: majority animist; rest Christian and
Muslim
Language: English and Chichewa official; Lomwe
is second African language
Literacy: 6% of population over 21 years old
Labor force: 225,000 wage earners employed in
Malawi (1974); 6,000 Europeans permanently
employed; 300,000 Malawians live and work in
Rhodesia, South Africa, and Zambia: 30% agriculture,
11% construction, 10% commerce, 13% manufac-
turing, 10% administration, 26% miscellaneous
services
adjective—
Organized labor: small minority of wage earners
are unionized','1d2dad8fc35e50ccf3d61c57b99a0ff7e6430cbcd58abd4780188ca3d9944bba','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f4ed5ef5b63f1063512b2a991d6a26564c45e8b3ac9fe77462655d22c32c4d2',1976,'MY','Malaysia','people-and-society',318,'Population: 12,227,000, average annual growth
rate 3.0% (7/70-7/74)
Peninsular Malaysia: 10,213,000, average annual
growth rate 2.8% (7/70-7/74)
Sabah: 860,000, average annual growth rate 4.9%
(7/70-7/74)
Sarawak: 1,154,000, average annual growth rate
3.2% (7/70-7/74)
127
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Nationality:
Malaysian
Ethnic divisions:
Malaysia: 44% Malay, 36% Chinese, 8% tribal,
10% Indian and Pakistani, 2% other
Peninsular Malaysia: 50.1% Malay, 36.9%
Chinese, 11% Indian and Pakistani, 2% other
Sabah: 23.1% Chinese, 67.3% indigenous tribes,
9.6% other
Sarawak: 31.5% Chinese, 50% indigenous tribes,
17.5% Malay, 1% other
Religion:
Peninsular Malaysia: Malays nearly all Muslim,
Chinese predominantly Buddhists, Indians predomi-
nantly Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and
Confucianist, 16% Christian, 35% tribal religion, 2%
other
Language:
Peninsular Malaysia: Malay (official); English,
Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among
Chinese
Sarawak: English, Malay, Mandarin, numerous
tribal languages
Literacy:
Peninsular Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 3.45 million (1967)
Peninsular Malaysia: 2.9 million; 55% agriculture,
forestry, and fishing, 11% manufacturing and
construction, 34% trade, transport, and services
Sabah: 213,000 (1967); 80% agriculture, forestry,
and fishing, 6% manufacturing and construction, 13%
trade and transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry,
and fishing, 6% manufacturing and construction, 138%
trade, transportation, and services, 1% other
Organized labor: 370,000 (official 1967 est.) about
10.5% of total labor force; 28% of wage labor force;
unemployment about 8% of total labor force, but
higher in urban areas','ecc7f2b85804c1586e33486c80e15d420dfcb0222fe2004191a1b594b5d613ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d212ce7c4c2eee88caf692574271a2f0198acef2b55a0a395d98014f8c97ddea',1976,'MV','Maldives','people-and-society',322,'Population: 132,000, average annual growth rate
2.1% (current)
Nationality: noun—Maldivian(s); adjective—
Maldivian
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the
male population','e162e41ee33009aff5c4629416c362871ad95617ec5638a15390d75b7dd456ae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('752c1373057337bfd6c3dcdcf4448d8e747d4a300e9b27fc16bbcd2e517748d4',1976,'ML','Mali','people-and-society',326,'Population: 5,686,000, average annual growth rate
2.3% (7/72-7/73)
Nationality; noun—Malian(s); adjective—Malian
Ethnic divisions: 99% native African including
tribes of both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African
languages, of which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried,
50,000 of whom are employed by the government;
most of population engaged in agriculture and animal
husbandry
Organized labor: UNTM, which claimed all
eligible employees, dissolved; thirteen national unions
currently directed by a government controlled
Coordination Committee of Mali Trade Unions
(CCSM)
Population: 320,000 (official estimate for 31 March
1975)
Nationality: noun—Maltese (sing. and pl.);
adjective— Maltese
Ethnic divisions: mixture of Arab, Sicilian,
Norman, Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education
introduced in 1946
Labor force: 107,500; 29% services, 23%
government, 24% manufacturing, 6% agriculture, 4%
construction, 4% transportation and communications,
5% utilities and drydocks; 5% unemployed
Organized labor: approximately 35% of labor force','e96612448dff209c1ed06a2cf1af79bb26016ca623b768b47cd98da2868653d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b14ee0333710bae50d279459b108c4707e197160cb1ccbdc0da2d758f1346392',1976,'MQ','Martinique','people-and-society',329,'Population: 347,000, average annual growth rate
0.5% (7/70-7/78)
Nationality: noun—Martiniquais (sing. and pl.);
adjective—Martiniquais
Ethnic divisions: 90% African and African-
Caucasian-Indian mixture, less than 5% East Indian
Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and
pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public
services, 11% construction and public works, 10%
commerce and banking, 10% services, 9% industry,
17% other
Organized labor: 11% of labor force','a39485be766ad268dcc220787a1def432b9cfbf3edc0bd2023d1ca9e9242c215','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a73f39806ef939d0a66f9b2129f39bbf8a855541b555b2df25ede03361b5917b',1976,'MR','Mauritania','people-and-society',331,'Population: 1,339,000, average annual growth rate
2.5% (7/68-7/74)
Nationality: noun—Mauritanian(s); adjective—
Mauritanian
Ethnic divisions: 80% Moor, 20% Negro
Religion: nearly 100% Muslim
Language: Hassaniya Arabic is the national
language spoken by some 80% of the population,
French is the working language for government and
commerce
Literacy: about 10%
- Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MAURITANIA/MAURITIUS
Labor force: about 18,000 wage earners (1973),
remainder of population in farming and herding
Organized labor: 18,000 union members claimed
by single union, Mauritanian Workers’ Union','dbff7ea4f70a3caea14c477e855a028a99ba73ec0597c27a4ad556fee160028c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5642dd272587fe5171f2fa5f4b52f93e1f60d62aef2a7a86a341a7ad821872ca',1976,'MU','Mauritius','people-and-society',335,'Population: 890,000, average annual growth rate
1.1% (1/78-1/74)
Nationality: noun—Mauritian(s); adjective—
Mauritian
Ethnic divisions: Indians 67%, Creoles 29%,
Chinese 3.5%, English and French 0.5%
Religion: 51% Hindu, 33% Christian (mostly
Catholic with a few Anglican Protestants), 16%
Muslim
Language: English official language; Hindi,
Chinese, French Creole
Literacy: estimated 60% for those over 21, and 90%
for those of school age
Labor force: 175,000; 50% agriculture, 6%
industry; 20% government services; 14% are
unemployed, under-employed, or self-employed, 10%
other
Organized labor: about 35% of labor force
Population: 499,000, average annual growth rate
2.1% (7/70-7/73)
Nationality: noun—Reunionais (sing. & pl.);
adjective-—Reunionais
Ethnic divisions: most of the population is of
thoroughly intermixed ancestry of French, African,
Malagasy, Chinese, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high
seasonal unemployment','46c61b7b251b7ef3cf2ba3213e5264fc350c74a29a1245a4e64404298d09361b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c819abd7a2d3c4313b1d508f9d4076f93eef5fcfe24d6fd88fb0ce203f7dba5c',1976,'US','United States','people-and-society',339,'Population: 61,009,000, average annual growth
rate 3.3% (current)
Nationality: noun—Mexican(s); adjective—
Mexican
Ethnic divisions: 60% mestizo, 30% Indian or
predominantly Indian, 9% white or predominantly
white, 1% other
Religion: 97% nominally Roman Catholic, 3%
other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force (1973): 15.7 million (defined as those
12 years of age and older); 89.5% agriculture, 16.7%
manufacturing, 16.6% services, 16.8% construction,
utilities, commerce, and transport, 3% government,
7.4% unspecified activitics
Organized labor: 20% of total labor force
Population: 214,524,000, average annual growth
rate 0.8% (current)
Ethnic divisions: 87.2% white, 11.3% negro, 1.4%
other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Religion: total membership in religious bodies,
131,434,000; Protestant 71,649,000, Roman Catholic
48,460,000, Jewish 6,115,000, other religions
3,841,361
Language: English, predominantly
Literacy: almost complete
Labor force: 92 million (1974)
Organized labor: 23.4% of total (1972)','3d0003f3448e34cde613a57a0afac42f65c08ceaffc10dd686f7132fc0902bdb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('936150ae0dbd62f1d7d740429a0d6b4c248afe087c8e8390d71d502579009bf6',1976,'MC','Monaco','people-and-society',343,'Population: 24,000 (official estimate for 31
December 1973)
Nationality: noun—Monacan(s) or Monegasque(s):
adjective—Monacan or Monegasque
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state
religion
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
MONACO/MONGOLIA
Language: French
Literacy: almost complete','900c2b418ac3d5be21afcbf2e5debdbefc41b1e5df8157a7fe2eeb78c046d8b7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('469c25b23fefdb463df14bf3412d6a6ea4f247c858b38e3fdbe898702d4f5114',1976,'MN','Mongolia','people-and-society',347,'Population: 1,466,000, average annual growth rate
3.1% (current)
Nationality: noun—Mongolian(s); adjective—
Mongolian
Ethnic divisions: 90% Mongol, 4% Kazakh, 2%
Chinese, 2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about
4% Muslim, limited religious activity because of
Communist regime
Languages: Khalkha Mongol used by over 90% of
population, minor languages include Turkic, Russian,
and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the
population is in the labor force, including a large
percentage of Mongolian women; shortage of skilled
labor (no reliable information available)','0cf2baa1394b5f393126f68f16b88b2dc5c6b2334d6dfd06413fdb681d5ad291','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c465522fe732057763008a16d74e3b6dfb155aee7eaf2aa0eafc6104834def8',1976,'MA','Morocco','people-and-society',351,'Population: 17,687,000, average annual growth
rate 3.2% (7/71-7/74)
Nationality: noun—Moroccan(s); adjective—
Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish,
0.7% non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2%
Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, government,
diplomacy, and postprimary education
Literacy; 20%
Labor force: 6.3 million (1971 est.) 50%
agriculture, 15% industry, 26% services, 9% other
Organized labor: about 5% of the labor force,
mainly in the Union of Moroccan Workers (UMT)','fa97cf17e37554b921ce4ff5177c728ee491bbeffc04ba98888f6013a2f94f8f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc7a15520312ab7edb8e75df5e97c1a0282e9943e7b16f66dbc60cd7b58b1fb9',1976,'MZ','Mozambique','people-and-society',355,'Population: 9,116,000, average annual growth rate
2.0% (7/71-7/72)
Nationality: noun—Mozambican(s); adjective—
Ethnic divisions: 97% African, 3% European,
Asian, and Mulatto
Religion: 65.6% animist, 21.5% Christian, 10.5%
Muslim, 2.4% other
Language: Portuguese (official); many tribal
dialects
Literacy: 7%-10% (est.)
Labor force: (1963 est.) 610,000; 50,000 non-
African wage earners, 560,000 African wage earners in
Mozambique; 290,000 additional African wage
earners temporarily working in Rhodesia and South
Africa; unemployment serious problem; most native
Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970);
75% are white','ea131241ad7d58d913570e71fbb46982d93dd492018355e9a7727c29e8466f00','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0c70ca6bf2aced366e565a5e22490304d1290c231ef05970f02308df5f7a047',1976,'NR','Nauru','people-and-society',361,'Population: 7,000 (official estimate for 30 June
1969)
Nationality:
Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
Religion: Christian (% Protestant, % Catholic)
Language: Nauruan, a distinct Pacific Island
tongue; English, the language of school instruction,
spoken and understood by nearly all
Literacy: nearly universal','4cfc12b093e2be37922a9e18340995c55dddef0c629edcbd080b021a23d25685','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79bbea97900f857d15db6bd3a3f0ef7ce441143150dbfa5d5006940f4c5bc19c',1976,'NP','Nepal','people-and-society',365,'Population: 12,731,000, average annual growth
rate 2.2% (6/71-6/74)
Nationality: noun—Nepalese (sing. and pl.); ad-
jective—Nepalese
Ethnic divisions: two main categories, Indo-
Nepalese (about 80%) and Tibeto-Nepalese (about
20% ), representing considerable intermixture of Indo-
Aryan and Mongolian racial strains; country divided
among many quasi-tribal communities
Religion: only official Hindu Kingdom in world,
although no sharp distinction between many Hindu
and Buddhist groups; small groups of Muslims and
Christians
Language: 20 mutually unintelligible languages
divided into numerous dialects; Nepali official
language and lingua franca for much of the country;
same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5%
industry; great lack of skilled labor','84e7c9ca461057ac30eb5880aa0a9bf648afd97be1876d63833926abeae1244e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b2d4f41498fb6ef1ad9707cb042182fa6d7206f41f53dbb965d9cd4a0a85e8c',1976,'NC','New Caledonia','people-and-society',369,'Population: 136,000, average annual growth rate
3.8% (7/61-7/72)
Nationality: noun—New Caledonian(s); adjec-
tive—New Caledonian
Ethnic divisions: Melanesian-Polynesian admix-
ture, over 28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and
Tonkinese laborers were imported for plantations and
mines in pre-World War II period; immigrant labor
now coming from Wallis Islands, New Hebrides, and','44908ea64153c19679ecf23babae01090440d6c33add2835e76c6824fd875b5b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7b51c90c1d7589d9129dd778852543ba962457757514d4fb0f0580337ff199b',1976,'NZ','New Zealand','people-and-society',371,'Population: 3,164,000, average annual growth rate
2.2% (1/74-1/75)
149
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
.
a
. Pacific
“ Ocean
Coral Sea
Tasman
Sea
a yy
ZEALAND
vB Wellington
(See reference map Vili)
Nationality: noun—New Zealander(s); adjective—
Ethnic divisions: 93% European, 7% Maori
Religion: 90% Christian, 9% none or unspecified;
1% Hindu, Confucian, and other
Literacy: 98%
Labor force: 1,176,600; 13% agriculture, 33%
manufacturing and construction, 9% transportation
and communications, 24% commerce and finance,
21% administrative and professional (1974 figures)
Organized labor: 52% of labor force','c6330650e946fa413d5d890d00c327cda7a8c9209938daa27e939fd55e0d47c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f086256a06edaabc60ff226eb5da02756c72acba5c637b3771717efd8a3cd3db',1976,'NI','Nicaragua','people-and-society',375,'Population: 2,188,000, average annual growth rate
3.8% (7/70-7/74)
Nationality: noun—Nicaraguan(s); adjective—
Nicaraguan
Ethnic divisions: 69% mestizo, 17% white, 9%
Negro, 5% Indian
Religion: 95% Roman Catholic
Language: Spanish (official); small English-
speaking minority on Atlantic coast
Literacy: 50% of population 10 years of age and
over
Labor force: 620,000 (1974 est.); 50% agriculture,
12% manufacturing, 14% services, 24% other;
shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 5% of labor force','80ca0c08694d6873e955738823a37f9c30e9678269adeb43d83b19632ff403ab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c63fd14530af1b6c1b3eb174a052349fa41d2797c2028447cec97ab4c5a2c8a',1976,'NE','Niger','people-and-society',379,'Population: 4,662,000, average annual growth rate
2.7% (7/70-7/74)
Nationality: noun—Nigerois (sing. and_pl.);
adjective—Niger
Ethnic divisions: main Negroid groups 75% (of
which, Hausa 50%, Djerma and Songhai 21%);
Caucasian elements include Tuareg, Toubous, and
Tamacheks; mixed group includes Fulani
Religion: 80% Muslim, remainder largely animists
and a very few Christians
Language: French official, many African lan-
guages; Hausa used for trade
Literacy: about 5%
Labor force: 26,000 wage earners; bulk of
population engaged in subsistence agriculture and
animal husbandry
Organized labor: negligible','3bd984a6f12a003d9f781bd3ecc2d965e9e383decbd545eb9b9ea84a1c44d864','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc3853f70700ba8c23517df4dafa5efab3b019faabd3c6678cd72a98da1807e7',1976,'NG','Nigeria','people-and-society',383,'Population: 63,825,000, average annual growth
rate 2.9% (current)
Nationality: noun—Nigerian(s);
Nigerian
Ethnic divisions: 250 tribal groups, of which most
important are Hausa-Fulani (north), [bo and Yoruba
(south); these 3 tribes total over 60% of population;
about 27,000 non-Africans
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official, Hausa, Yoruba, and
Ibo also widely used
Labor force: approx. 22.5 million; about 41% of
total population; roughly 1.3 million wage earners, of
whom 560,000 work in modern enterprises
Organized labor: about 530,000 wage earners,
approx. 2.4% of total labor force, belong to some 700
unions','9fa2831f9859e3aec27101c2558dd6543f6d643e62987f609fc8c2b1b9fd4799','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6bf99674a595eb6918cf688599fccd555ce10428fd33d1f7cf4e7c1dd93f7aa',1976,'NO','Norway','people-and-society',387,'Population: 4,022,000, average annual growth rate
0.6% (1/74-1/75)
Nationality: noun—Norwegian(s); adjective—
Norwegian
Ethnic divisions: homogeneous white population,
small Lappish minority
Religion: 96% Evangelical Lutheran, 4% other
Protestant and Roman Catholic, 1% other
Language: Norwegian, small Lapp and Finnish-
speaking minorities
Literacy: 99%
Labor force: 1.7 million; 11.4% agriculture,
forestry, fishing, 25.3% mining and manufacturing,
8.1% construction, 16.3% commerce, 9.9% transporta-
Approved For Release 2005/04/22 :
tion and communication, 28.5% services; 1.0%
unemployed
Organized labor: 60% of labor force
Population: 505,000, average annual growth rate
2.9% (current)
Nationality: noun—Omani(s); adjective—Omani
Ethnic divisions: almost entirely Arab with small
groups of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','2bc06cc1142dace274f9b478691bba160db8c08563113f56b115a62e10d168b6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b514639b65210e82249e4368952e429ef5623e5654ec1ce2f1a1ab1fb768eb9',1976,'PK','Pakistan','people-and-society',391,'Population: 71,461,000 (excluding Junagardh,
Manavadar, Gilgit, Baltistan, and the disputed area
of Jammu-Kashmir), average annual growth rate
3.2% (current)
Nationality: noun—Pakistani(s); adjective—
Pakistani
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages
—7% Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu,
9% other; English is lingua franca
Literacy: about 14%
Labor force: 12.7 million (est. 1961); 60%
agriculture, 16% industry, 7% commerce, 15% service,
2% unemployed
Organized labor: 5% of labor force','5ebe44eb5c272af149320725997a0cc1f3c62549801e4c79f1eff8a0dd326b28','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc45b0d7389a24a69d85b6949a8a804f3fe5a05736bd8f1182e8154924fb72d2',1976,'PA','Panama','people-and-society',395,'Population: 1,693,000, average annual growth rate
3.1% (7/73-7/74)
Nationality: noun—Panamanian(s); adjective—
Panamanian
Ethnic divisions: 70% mestizo, 14% Negro, 9%
white, 7% Indian and other
Religion: over 90% Roman Catholic, remainder
mainly Protestant
Language: Spanish; about 14% speak English as
native tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and
over
Labor force: 482,200 (1972 est.); 39.5% commerce,
finance and services; 33.9% agriculture, hunting and
fishing; 9.7% manufacturing and mining; 6.8%
construction; 5% Canal Zone; 3.9% transportation
and communications; 1.2% utilities; national average
of 6.8% unemployed; shortage of skilled labor but an
oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)','d2b8321d7284bc8239c079caa65dcd0decd2e8ee6f8270f031ac865c6b4bdc9a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59ad2cb5c858525de8efcd54002dca1fc5dabf1e35a9c875ed1e0860dc0c8da3',1976,'PY','Paraguay','people-and-society',400,'Population: 2,582,000, average annual growth rate
2.7% (10/62-7/72)
Nationality: noun—Paraguayan(s); adjective—
Paraguayan
Atlantic Ocean
{See reference map tl}
Ethnic divisions: 95% mestizo, 5% white and
Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10,
but probably much lower (40% )
Labor force: 800,000 (1971 est.); 55% agriculture,
forestry, fishing; 8% transport and other services; 19%
manufacturing and construction; 13% commerce and
professions; 5% miscellaneous (est. 1962)
Organized labor: about 5% of labor force','59a0b943dac4d2a657096b02945378ffc61c158f2585a5ff9da1865f58b473e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('505b2a5e639f88d0ba6b599befe7bafeca374d905c8cb00df849aa7f13bcde6e',1976,'PE','Peru','people-and-society',404,'Population: 15,037,000 (excluding Indian jungle
population which was estimated at 101,000 in 1961),
average annual growth rate 2.9% (7/61-6/72)
Nationality: noun—Peruvian; adjective—Peruvian
Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white: 1% Negro, Japanese, Chinese
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 4.4 million (1973); 46% agriculture,
17% services, 14% manufacturing, 9% trade, 4%
construction, 4% transportation, 2% mining, 4% other
Organized labor: 25% of labor force','fb22de2d5fcfa2cb5e30bbc4c619b9bc973fbb9444d58c87f7f98c623ed8d308','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97adeab6eff753b7333e304d607a6b9eae8f80aedfbf16f9c2c2717e838db27d',1976,'PL','Poland','people-and-society',408,'Population: 34,200,000, average annual growth
rate 1.1% (current)
Nationality: noun—Pole(s); adjective—Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians,
0.5% Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75%
practicing), 5% Uniate, Greek Orthodox, Protestant,
and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26%
industry, 36% other non-agricultural','4ecc5eac0e46d77a64f0ca9589ba85a739ce5054bf749d81f05db3e935dcd891','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39f4c83f0aa449b637d864fb83cf0e00bfb01f4e8557e173bb6f0b7d7a1bb770',1976,'PT','Portugal','people-and-society',412,'Population: metropolitan Portugal (including the
Azores and Madeira Islands), 8,782,000 (official
estimate for 1 July 1974)
Nationality: noun—Portuguese (sing. & pl.);
adjective—Portuguese
Ethnic divisions: homogeneous Mediterranean
stock in mainland, Azores, Madeira Islands
Religion: 97% Roman Catholic, 1% Protestant
sects, 2% other
Language: Portuguese
Literacy: 65% (a figure considered high by some
sources)
Labor force: 3 million; 25% agriculture, 31%
industry, 24% services; 8% military, 12% other;
government estimates that over 400,100 persons or 5%
of labor force are unemployed
Organized labor: about one-third of labor force is
organized in trade unions; legislation promulgated
May 1975 unites consenting unions under one
confederation, the Communist-dominated Intersyndi-
cal
Population: 703,000, average annual growth rate
2.9% (12/70-7/72)
Nationality: noun—Portuguese Timoran(s);
adjective—Portuguese Timoran
Ethnic divisions: 95% indigenous Timorese
belonging to the Malay racial group; 9 ethnic
divisions, each speaking a distinct dialect of Malay
structure; approx. 4,600 Chinese and 10,000 halfcastes
Religion: 17% Christian (almost equally divided
between Catholic and Protestant), remainder practice
animism
Language: an estimated 9-15 dialects, of Malay
origin but mutually unintelligible; 75% of the
population speaks the Tetum dialect
Literacy: rate of literacy is unknown, but is very
low; in 1971 total school enrollment was 35,000 out of
total school-age population of 80,000; 5% of natives
can speak Portuguese
Labor force: 90% engaged in primitive village
subsistence economy, 10% engaged as town laborers
and domestics','f24cd46ccbdd4e8d18f00d03b423393a54df022a9fbddd4fd1333f7c919578a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ddcb4711c4ca4ca0bb63075021d80ec7752b6fce800e164fb1848b25dc829f4',1976,'QA','Qatar','people-and-society',416,'Population: 195,000, average annual growth rate
10.8% (7/64-7/69)
Nationality: noun—Qatari(s); adjective— Qatari
Ethnic divisions: 56% Arab; 23% Iranian; 14%
Pakistani; 7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: 48,000 (1969)','44d10a05fbfba9a5d6bc85b2103100a794c07354e7cb78d12ec90aca2c34c459','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f423d51f17117599add408e347ba247d4778df52b1fd40a7b4884068b3857b7',1976,'ZM','Zambia','people-and-society',420,'Population: 6,417,000, average annual growth rate
3.5% (1/70-1/75)
Nationality:
Rhodesian
Ethnic divisions: 95.1% African, 4.4% European,
less than 0.5% Coloreds and Asians
Religion: 51% syncretic (part Christian, part
animist), 24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and
Sindebele also widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including
some migrants from Zambia and Malawi), 108,000
Europeans, Asians, and coloreds (people of mixed
heritage); 35% agriculture, 25% mining, manufactur-
ing, construction, 40% transport and services
Organized labor: about one-third of European
wage earners are unionized, but only a small minority
of Africans (1966)
Population: 4,931,000, average annual growth rate
2.5% (7/73-7/74)
Nationality:
Zambian
Ethnic divisions: 98.7% African, 1.1% European,
.2% other
Religion: 82% animist, about 17% Christian, and
under 1% Hindu and Muslim
Language: English official; wide variety of
indigenous languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000
Africans, 27,000 non-Africans; 15% mining, 9%
agriculture, 9% domestic service, 19% construction,
9% commerce, 10% manufacturing, 23% government
and miscellaneous services, 6% transport
Organized labor: 100,000 wage earners, primarily
in industrial sector, are unionized (early 1968)','13a9bb46a629cdc4813cbd41ec6e032162873cabe9edf86eb38ed96a07b37c60','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('293614efe644445245cd9cf19f1b534fef150e06126cdbfb2d55a27e5910280b',1976,'RO','Romania','people-and-society',424,'Population: 21,349,000, average annual growth
rate 1.0% (current)
Nationality: noun—Romanian(s); adjective—
Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian,
2% German, 3% other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
Black Sea
(See reference map IV)
Religion: 14 million Romanian Orthodox, 1 million
Roman Catholic, 1 million Protestants, 100,000 Jews,
30,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.1 million (1974); 40% agriculture,
30% industry, 30% other nonagricultural','74944b1acc11566bea8309cc708e67088ea76868b9aed6ad730c6b83a076a9f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdb224bb1c7a1972bc6a0e1cb8953222c960e7750195f71138e45f3f9c2ae9ef',1976,'RW','Rwanda','people-and-society',428,'Population: 4,302,000, average annual growth rate
2.9% (7/73-7/74)
Nationality: noun—Rwandan(s); adjective—
Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa
(Pygmoid)
Religion: 45%
Muslim, rest animist
Language: Kinyarwanda and French official,
Kiswahili used in commercial centers
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','092b653c55768df9a12f5e0b8db00fdd83211cb0691a7a62966cc4149e31e850','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0258b06289f11fa0e13516653f3ccf3278e23ae1c27e2d85765c2fa04f26f224',1976,'AI','Anguilla','people-and-society',432,'Population: 69,000, average annual growth rate
1,2% (4/60-4/70)
Ethnic divisions: mainly of African Negro descent
Nationality: noun—Kittsian(s), Nevisian(s),
Anguillan(s); adjective—Kittsian, Nevisian, An-
guillan
Religion: Church of England, other Protestant
sects, Roman Catholic
Language: English
Literacy: about 80%
Laber force: 19,616 (1960 est.)
Organized labor: 6,700
Approved For Release 2005/04/22
Population: 109,000, average annual growth rate
1.5% (4/60-4/70)
Nationality: noun—St. Lucian(s); adjective— St.
Lucian
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
176
Approved For Release 2005/04/22 :
Labor force: 38,000 (1969); 50% agriculture;
unemployment 30%-35% (1975)
Organized labor: 20% of labor force
Population: 95,000, average annual growth rate
1.1% (4/60-4/70)
Nationality: noun—St. Vincentian(s) or Vin-
centian(s); adjective—St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian
and Carib Indian
Religion: Church of England, Methodist, Roman
Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60%
unemployed
Organized labor: 10% of labor force','e05c6250f0a90513b5540054d94ccb5ca069f57816448aae6c15c28767079f19','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dba97000109009d0cd17dcf52b3ad1adcb9df096e5747f45b540e2308c701a96',1976,'SM','San Marino','people-and-society',436,'Population: 19,000 (official estimate for 30 June
1974)
Nationality: noun
adjective—Sanmarinese
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation
of Sanmarinese Workers (affiliated with ICFTU) has
about 1,800 members: Communist-dominated
Camera del Lavoro, about 1,000 members','cb1bbc0969bd1984a3cee33fcd896e1ec50d70ab5468a8d10f66db5f78720ab7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54e7399abf4f42a38bbc8abf27d0df2ee605b28ee33843ded36ec2892e048ae3',1976,'SN','Senegal','people-and-society',440,'Population: 4,351,000, average annual growth rate
2.2% (7/67-7/69)
Nationality: noun—Senegalese (sing. & pl.);
adjective—Senegalese
Ethnic divisions: 36% Wolof, 17.5% Fulani, 16.5%
Serer, 9% Tukulor, 9% Dyola, 6.5% Malinke, 4.5%
other African, 1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian
(mostly Roman Catholic)
Language: French official, but regular use limited
to literate minority; most Senegalese speak own tribal
language; use of Wolof vernacular spreading — now
spoken to some degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence
agricultural workers; about 125,000 wage earners
Organized labor: majority of wage-labor force
represented by unions; however, dues-paying
membership very limited','098f656b3cee44eacc60ca08e5c0525b5abfed0647e38ee8b507b9849577cefe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2b6ab8bf61777e5fd2d55ad8fd4a0760a9e7034ba1a836bab828cc9b6765d6f',1976,'SL','Sierra Leone','people-and-society',444,'Population: 2,768,000, average annual growth rate
1.5% (7/73-7/74)
Nationality: noun—Sierra Leonean(s); adjective—
Sierra Leonean
Ethnic divisions: over 99% native African, rest
European and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited
to literate minority; principal vernaculars are Mende
in south and Temne in north; “Krio,” the language of
the resettled ex-slave population of the Freetown area,
is used as a lingua franca
Literacy: about 10%
Labor force: about 1.5 million; most of population
engages in subsistence agriculture; only small
minority, some 70,000, earn wages
Organized labor: 35% of wage earners','bca888d0f772cfa29f785655d758db5dc15a563134d39361ba4484f904d2f4c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81e97080b7f1297eef42bea098e7d852dccf67e2789aaf003265e613a6e44e42',1976,'SG','Singapore','people-and-society',448,'Population: 2,271,000, average annual growth rate
1.6% (7/73-7/74)
Nationality: noun—Singaporan(s); adjective—
Singaporan
Ethnic divisions: 76.2% Chinese, 15% Malay, 7%
Indians and Pakistani, 1.8% other
Religion: majority of Chinese are Buddhists or
atheists; Malays nearly all Muslim; minorities include
Christians, Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay, Chinese,
Malay, Tamil, and English are official languages
Literacy: 70% (1970)
Labor force: 474,718; 0.5% agriculture, forestry,
and fishing, 0.4% mining and quarrying, 32.2%
manufacturing, 30.4% services, 5.2% construction,
21.5% commerce, 9.8% transport, storage, and','3bbdad6b1fa459205edcf5916d445fc927ab37e17281a46aa3cbd574879b8da5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73000b0dd0ee68c44c719e00f5c5db1a9b401aade0a76aeda50bffc15d47b519',1976,'SO','Somalia','people-and-society',452,'Population: 3,190,000, average annual growth rate
2.3% (7/65-7/72)
Nationality: noun—Somaili(s); adjective—Somali
Ethnic divisions: 85% Hamitic, rest mainly Bantu;
30,000 Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form recently instituted
by government); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are
skilled laborers; 70% pastoral nomads, 30%
agriculturists, government employees, traders,
fishermen, handicraftsmen, other
Organized labor: law providing for government-
controlled labor union promulgated in June 1971, but
union so far not established','c114310315fb120cab6fccd0bd768d329269276c47e8444fdeffc002c60576f8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d369c75c891a290c7bd0f163ced7b362c968f3e88f7f84f5a58d53947bdd08bf',1976,'ZA','South Africa','people-and-society',456,'Population: 25,909,000, average annual growth
rate 2.6% (7/70-7/74)
Nationality: noun—South African(s); adjective—
South African
Ethnic divisions: 17.8% white, 69.9% African,
9.4% Colored, 2.9% Asian
Religion: primarily Christian except Asian and
African; 60% of Africans are animists
Language: Afrikaans and English official, Africans
have many vernacular languages
Literacy: almost all white population literate;
government estimates 35% of Africans literate
Labor force: 8.7 million (total of economically
active, 1970); 53% agriculture, 8% manufacturing,
7% mining, 5% commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is
unionized (mostly white workers); nonwhites have no
bargaining power
Population: 902,000, average annual growth rate
3.0% (7/68-7/74)
Nationality: noun—South West African(s);
adjective—South West African
Ethnic divisions: 14% white, 81% Africans, 5%
Colored (mulattoes); almost half the Africans belong
to Ovambo tribe; Damara tribe has almost 45,000
members; Herero, Okavango, Nama tribes have about
30,000 members each
Religion: whites predominantly Christian,
nonwhites either animist or Christian
Language: Afrikaans principal language of about
70% of white population, German of 22% and English
of 8%; several African languages
Literacy: high for white population; low for
nonwhite
Labor force: 203,300 (total of economically active,
1970); 68% agriculture, 15% railroads, 18% mining,
4% fishing
Organized labor: no trade unions, although some
white wage earners belong to South African unions
Population: 35,783,000 (including the Balearic and
Canary Islands; also including Alhucemas, Ceuta,
Chafarinas, Melilla, and Penon de Velez de la
Gomera), average annual growth rate 1.1% (current)
Nationality: noun—Spaniard(s); adjective—
Spanish
Ethnic divisions: homogeneous composite of
Mediterranean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great
majority; but 17% speak Catalan, 7% Galician, and
2% Basque
Literacy: about 90%
Labor force (1973): 12.7 million; 25% agriculture,
36% industry, 39% services; registered unemployment
is 2.1% of labor force, in reality about 4%
Organized labor: 90% of labor force in compulsory
government-controlled syndicates
19','721ec5c5d6612cfa7515d82854cd3b9f09889f334f1a175f246f0dd58319f47c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e57898649c7d8533935fdf3d115b8159020a4894ee34b2dab45d45ad047fca32',1976,'ES','Spain','people-and-society',462,'Population: 108,000 (official estimate for 1 July
1974)
Nationality; noun—Spanish Saharan(s); adjec-
tive—Spanish Saharan
Ethnic divisions: 71.5% Arab, Berber, and Negro
nomads; 28.5% Spanish
Religion: 72% Muslim, 28% Catholic
Language: Spanish (official), local Arabic or
Hassania
Literacy: among Spanish, probably nearly 100%:
among nomads, perhaps 5%
Labor force: 12,000: 50% agriculture, 50% other
Organized labor: none','a7e1eed96198d683de788ac733ebe67afd0b6d3f5f833d3ae2c7cb8dee0c07b8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fb70637f500b4cc937c786e3a31a7aa2f315e6c785681a48beefcd6d6ec8544',1976,'LK','Sri Lanka','people-and-society',464,'Population: 13,895,000, average annual growth
rate 1.9% (7/70-7/78)
Nationality: noun—Ceylonese (sing. and_pl.);
adjective—Ceylonese
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6%
Moor, 2% other
Religion: 64% Buddhist, 20%
Christian, 6% Muslim, 1% other
Language: Sinhala official, spoken by about 70%
of population; Tamil spoken by about 22%; English
commonly used in government and spoken by about
10% of the population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed;
employed persons — 53.4% agriculture, 14.8% mining
and manufacturing, 12.4% trade and transport, 19.4%
services and other
Organized labor: 43% of labor force, over 50% of
which employed on tea, rubber, and coconut estates','c31b2e6dafb4042da8b1b1259c334fa752b09be416080a27d571ef548e6ecfe4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3bf8a9a0709c2b941ef00aad8404535622abe3d6ff620bb902899129c237d58',1976,'SD','Sudan','people-and-society',468,'Population: 17,980,000, average annual growth
rate 2.5% (7/73-7/74)
Nationality: noun—Sudanese (sing. and_pl.);
adjective—Sudanese
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro,
2% foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23%
pagan, 4% Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse
dialects of Nilotic, Nilo-Hamitic, and Sudanic
languages, English; program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15%
industry, commerce, services, etc.; labor shortages
exist for almost all categories of employment
Population: 421,000, average annual growth rate
2.3% (1/64-1/72)
Nationality: noun—Surinamer(s);
Surinam
Ethnic divisions: 31% Creole (Negro and mixed),
37% Hindustani (East Indian), 15.3% Javanese,
10.3% Bush Negro, 2.6% Amerindian, 1.7% Chinese,
1.0% Europeans, 1.7% other and unknown
Religion: Muslim, Hindu, Moravian, Roman
Catholic, other — in order of size (% figures
unknown)
Language: Dutch official; English widely spoken;
Taki-Taki (Surinam Creole) is native language of
Creoles and lingua franca: Hindi; Javanese
Literacy: 70% to 75%
Labor force: 130,000 (1973)
Organized labor: approx. 33% of labor force
Population: 502,000, average annual growth rate
3.2% (current)
Nationality: noun—Swazi(s); adjective—Swazi
Ethnic divisions: 96% African, 3% European, 1%
mulatto
Religion: 43% animist, 57% Christian
Language: English and Swati are official
languages; government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in
subsistence agriculture; 55-60,000 wage earners, many
only intermittently, with 31% agriculture, 11%
government, 11% manufacturing, 12% mining and
forestry, 35% other (1968 est.); 7,900 employed in
South African mines (1969)
Organized labor: about 15% of wage earners are
unionized','de1b77a7e90ba7cd485fe1f1c875b2242a83a60b4cdec992088ae48b28bfc011','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9be2a4386ee4fc38f5605a8e186b25a202eaf5d8b093573cff4930300bddc2e',1976,'SE','Sweden','people-and-society',472,'Population: 8,212,000, average annual growth rate
0.4% (current)
Nationality: noun—Swede(s); adjective—Swedish
Ethnic divisions: homogeneous white population;
small Lappish minority
198
Religion: 92% Evangelical Lutheran, 7% other
Protestant, Roman Catholic, Eastern Orthodox, 1%
other
Language: Swedish, small Lapp- and Finnish-
speaking minorities
Literacy: 99%
Labor force: 4.0 million; 6.4% agriculture, forestry,
fishing; 29.2% mining and manufacturing; 7.2%
construction; 13.6% commerce; 6.5% transportation
and communications; 29.8% services including
government; 5% banking, 2.7 unemployed
Organized labor: 80% of labor force','10b86cb4502255e9bee567773dbc2d45f16cf7ef5ab8a8c17ddb135807271eb8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fe18bffea4984285cb0d8beec80ee5c219a0a285775e6fc7452c5518f9d3048',1976,'CH','Switzerland','people-and-society',475,'Population: 6,500,000, average annual growth rate
0.4% (1/74-7/75)
Nationality: noun—Swiss (sing. & pl.); adjective—
Swiss
Ethnic divisions: total population — 69% German,
19% French, 10% Italian, 1% Romansch, 1% other;
Swiss nationals — 74% German, 20% French, 4%
Italian, 1% Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
199
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
00010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008
Language: Swiss nationals — 74% ©
French, 4% Italian, 1% Romansch, 1% other; total
population — 69% German, 19%
Italian, 1% Romansch, 1% other
Literacy: 98%
Labor force: 3.0 million, about one-fifth foreign
workers, mostly Italian; 16% agriculture and forestry,
A7% industry and crafts, 20% trade and
portation, 5% professions, 2% in public service.
10% domestic and other. approximately 0.4%
unemployed in August 1975
Organized labor: 20% of labor force
Population: 7,475,000, average annual growth rate
3.8% (7/78-7/74)
1,865 (1967) (excluding
Nationality: noun—Syrian(s); adjective—Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds,
Armenians, and other
Religion: 70.5% Sunni Muslim, 16.3% other
Muslim sects, 13.2% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and
English widely understood
Literacy: about 40%
Labor force: 2 million; 67% agriculture, 12%
industry (including construction), 21% miscellaneous
services; majority unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 15,363,000, average annual growth
rate 2.7% (7/73-7/74)
Nationality: noun—Tanzanian(s); adjective—
Tanzanian
Ethnic divisions: 99% native Africans consisting of
well over 100 tribes; 1% Asian, European, and Arab
Religion: Tanganyika — 40% animist, 30%
Christian, 30% Muslim; Zanzibar — almost all
Muslim
Language: Swahili and English official, English
primary language of commerce, administration and
higher education; Swahili widely understood and
generally used for communication between ethnic
groups; first language of most people is one of the
local languages
Literacy: 15%-20%
Labor force: under 400,000 in paid employment,
over 90% in agriculture
Organized labor: 15% of labor force','12bb0c8f260b0dc3d5ae36d32dcc5c576147cf382d21b53ddb45cf756f08841b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ddc3ae7755c238ec16acff51c2418354f81c38d184ad4ba9e59d81bef06069a',1976,'TH','Thailand','people-and-society',479,'Population: 42,955,000, average annual growth
tate 3.1% (7/73-7/74)
Nationality: noun—Thai (sing. & pl.); adjective—
Thai
Ethnic divisions: 75% Thai, 14% Chinese, 11%
minorities
Religion: 95.5%
Christian
Language: Thai; English secondary language of
elite
Literacy: 70%
Labor force: 78% agriculture, 15% services, 7%
industry
Population: 21,114,000, average annual growth
tate 2.6% (7/65-7/71)
Nationality: noun—South Vietnamese (sing. &
pl.); adjective—South Vietnamese
Ethnic divisions: 87.7% Vietnamese, 6% Chinese,
3.2% mountain tribesmen, 2.9% Khmer, 0.2% Cham
Religion: 70% Buddhist (at least 5% Hoa Hao), 5%
Cao Dai, and 10% Catholic; others include animist,
and small numbers of Protestant, Muslim and Hindu;
most Buddhists are of Mahayana school or practice
combination of Buddhism, Taoism, and Confucian-
ism
Language: Vietnamese, French, Chinese, English,
Khmer, tribal languages (Mon-Khmer and Malayo-
Polynesian), Cham (Malayo-Polynesian dialect)
Labor force: civilian work force 5.8 million (not
including armed forces); 67% agriculture, fishing, and
forestry; 5% industry and commerce; 1% domestic
and personal services; 5% government; 22%
unemployed
Organized labor: 500,000','503ef5c3b306dfc558a5fb8f79ed7f79992826e66017b75d2b105e5314df51e2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8385de0a153ad3591818b833511c45b1dab299203ff0d8bfd506467ff917d87e',1976,'TG','Togo','people-and-society',483,'Population: 9,255,000, average annual growth rate
9.6% (7/73-7/T4)
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Nationality: noun—Togolese (sing- & pi.)
adjective—Togolese
Ethnic divisions: some 40 tribes; largest and most
important are Ewe in south and Cabrais in north;
under 1% European and Syrian- Lebanese
Religion: about 20% Christian, 5% Muslim, 75%
animist
Language: French, both official and language of
commerce; major African languages are Ewe and
Mina in south and Dagoma, Tim, and Cabrais in
north
Literacy: 5% to 10%
Labor force: over 90% of population engaged in
subsistence agriculture; about 30,000 wage carners,
evenly divided between public and private sectors
Organized labor: less than half of wage earncrs
divided among 2 major and several minor unions','762301730b94f4abcec4c0e796af2f1c015ccbec3406b622e8219ae9c0eef2ab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7461b689998f1868863c36c2d358e930827ecb05c56f70900658f1ed6e63e5cf',1976,'TO','Tonga','people-and-society',487,'Population: 101,000, average annual growth rate
2.9% (7/67-7/73)
Nationality; noun—Tongan(s). adjective—Tongan
Ethnic divisions; Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims
over 30,000 adherents
Language: Tongan, English
Literacy; 90% -95% : compulsory education for
children between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','85323cef556b9249e6b19af8e30f915b3b4d2abafac0c3be8e862e78d6513cdc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3657347d135eb30d849e1b228b5b6cd073ee561d3dbcce542483eae8bb75b638',1976,'TT','Trinidad and Tobago','people-and-society',491,'Population: 1,020,000, average annual growth rate
1.3% (4/60-4/70)
Nationality: noun—Trinidadian(s), Tobagon-
ian(s); adjective—Trinidadian
Ethnie divisions: 43% Negro, 40% East Indian,
14% mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman
Catholic, 23% Hindu, 6% Muslim, 13% unknown
Language: English
Literacy: 89%
Labor force: about 376,000 (1973 est.), about
15.4% agriculture, 18.7% mining, quarrying, and
manufacturing, 16.7% commerce, 16.2% construction
and utilities; 7.4% transportation and com-
munications; 21.8% services, 3.8% other
Organized labor: 30% of labor force','905e9b3f01b4413cf4f24c02b8fd299238cd1bf25cc169f90cf9c3fa969b7a0a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08d94fb2d6fbe7cb2e5cbf1c7f834aa9576d27b6612dbe37c8ed66eee4fa51ca',1976,'TN','Tunisia','people-and-society',495,'Population: 5,847,000, average annual growth rate
2.4% (7/70-7/74)
Nationality:
Tunisian
Ethnic divisions: 98% Arab, 1% European, less
than 1% Jewish
Religion: 95% Muslim, 4% Christian, 1% Jewish
Language: Arabic (official), Arabic and French
(commerce)
noun—Tunisian(s); adjective—
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TUNISIA/TURKEY
Literacy: about 32%
Labor force: 1.4 million, 45% agriculture, 19%
manufacturing and construction, 5% trade and
finance, 3% transportation, communications, and
utilities, 2% mining; 25% underemployed; shortage of
skilled labor
Organized labor: 10% of labor force; General
Union of Tunisian Workers (UGTT), subordinate to
Destourian Socialist Party
Population: 40,574,000, average annual growth
rate 2.6% (current)
209
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
January 1976
TURKEY
bd :
Mediterranean Sea 2 8
Aaa i)
ee v
{See reference map Yj
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other
(mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million: 68% agriculture, 16%
industry, 16% service; substantial shortage of skilled
labor; ample unskilled labor
Organized labor: 10% of labor force','d9b737afd1e88ca929e412274ccc8ce1fff1696edc20b7ce864c531320f3c269','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8923ad0f1819bf9bcd414a23f6cfe97bfc91daecca6429489b755c66e7e6f630',1976,'UG','Uganda','people-and-society',499,'Population: 11,746,000, average annual growth
rate 3.4% (current)
Nationality: noun—Ugandan(s); adjective—
Ugandan
Ethnic divisions: 99% African, 1% European,
Asian, Arab
Religion: about 60% nominally Christian, 5%-10%
Muslim, rest animist
Language: English official, Luganda and Swahili
widely used; other Bantu and Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which
about 250,000 in paid labor, remaining in subsistence
activities
Organized labor: 125,000 union members
Population: 255,675,000, average annual growth
rate 1% (current)
Nationality: noun—Soviet(s): adjective—Soviet
212
See seference map Vit)
Ethnic divisions: 74% Slavic, 26% among some 170
ethnic groups
Religion: 70% atheist, 18% Russian Orthodox, 9%
Muslim, 3% other
Language: more than 200 languages and dialects
(at least 18 with more than 1 million speakers); 76%
Slavic group, 8% other Indo-European, 11% Altaic,
3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 133 million (1975), 26%
agriculture, 74% industry and other non-agricultural
fields, unemployed not reported, shortage of skilled
labor reported','26a40ec7215f7f7256af12cb6f1b71a4372e743f5718360a5f77bf0ea485c663','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6650ea6006fb38e4128a7a2f791a4224df76beba8059ae37541dd874cac3ac89',1976,'AE','United Arab Emirates','people-and-society',502,'Population: 179,000 (census of 15 March - 16 April
1968)
Ethnic divisions: Arabs 72%; others include
Iranians, Pakistanis, and Indians
Religion: Muslim 96%, Christian, Hindu and other
4%
Language: Arabic
Literacy: 25% est. (1975)
Labor force: 135,000 (1973)','bd0aff8265593a4224ae17f40bb7a1e1b231bbb4b637406abc699488b4c1bcff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cefbad5f7a7a047dad581504afa7c876627c92a67e57e357d1d60d1ebbc4de3e',1976,'GB','United Kingdom','people-and-society',506,'Population: 56,076,000, average annual growth
rate 0.0% (current)
Nationality; noun—Briton(s), British (collective
pl.); adjective—British
Ethnic divisions: 83% English, 9% Scottish, 5%
Welsh, 3% Irish
Religion: 27.0 million Church of England, 5.3
million Roman Catholic, 2.0 million Presbyterians,
760,000 Methodist, 450,000 Jews (registered)
Language: English, Welsh (about 26% of
population of Wales), Scottish form of Gaelic (about
100,000 in Scotland)
Literacy: 98% to 99%
Labor force: 25 million: 3% agriculture, 2%
mining, 35% manufacturing, 6% government, 8%
transportation and utilities, 6% construction, 11%
“ Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010001-8
Approved
p For Release 2005/04/22 : CIA-RDP79-01051A000800010
001-8
January 1976
distributive trades, 23% services,
unemployed
Organized labor: 40% of labor force
Population: 6,051,000, average annual growth rate
2.2% (7/71-7/72)
Nationality; noun—Upper Voltan(s): adjective—
Upper Voltan
Ethnic divisions: more than 50 tribes; principal
tribe is Mossi (about 2.5 million); other important
8roups are Gurunsi, Senufo, Lobi, Bobo, Mande, and
Fulani
Religion: majority of population animist, about
20% Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong
to Sudanic family, spoken by 50% of the population
Literacy; 5%-10%
Labor force: about 95% of the economically active
population engaged in animal husbandry, subsistence
farming, and related agricultural Pursuits; about
30,000 are wage earners; about 20% of male labor
force migrates annually to neighboring countries for
Organized labor: 3 Primary and several small
specialized unions','dc452bb12cfe2a947ff3cb7c5b1e21db440856383f71e06d1a1cee96fce7f612','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b8d00adc7453a3eb983832f783ec19db3c01b02123402a9fe312cef83c99b53',1976,'UY','Uruguay','people-and-society',510,'Population: 3,083,000, average annual growth rate
1.2% (7/73-7/74)
Nationality; noun—Uruguayan(s); adjective—
Uruguayan
Ethnic divisions: 85%-90% white, 5% Negro, 5%-
10% mestizo
Religion: 66% Roman Catholic (less than half
adult population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1968 census); of those
employed in important sectors — 25% government;
84% industry; 10% service; 23% other; 8%
agriculture, forestry, fishing and mining; no shortage
of skilled labor
Organized labor: about 25% of labor force
Population: 1,000 (official estimate for 1 July 1974)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern
languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees
divided into 3 categories — executives, officeworkers,
and salaried employees
Organized labor: none
Population: 12,182,000 (excluding Indian jungle
population estimated at 32,000 in 1961), average
annual growth rate 3.1% (7/73-7/74)
Nationality: noun—Venezuelan(s); adjective—
Venezuelan
Ethnic divisions: 67% mestizo, 21% white, 10%
Negro, 2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Labor force: 3 million (1974); 24% agriculture, 6%
construction, 17% manufacturing, 6% transportation,
18% commerce, 25% services, 4% petroleum, utilities,
and other
Organized labor: 45% of labor force
Population: 24,533,000, average annual growth
rate 2.2% (current)
Nationality: noun—North Vietnamese (sing. &
pl.); adjective—North Vietnamese
Ethnic divisions: 85%-90% predominantly
Vietnamese; ethnic minorities include Muong, Thai,
Meco, and Man
Religion: Confucianism, Buddhism, Taoism,
Catholicism
Language: closely corresponds to the breakdown of
ethnic groups
Literacy: claimed to be 95% (1964)
Labor force: (1 January 1970) 9.6 million, not
including military; about 70% agriculture and 10%
industry','c48f6a78605816ffcf84699dfaffdc88571cec65469681c8ad0909252aaafddb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('309e5b77bec0bcc0c63f4a229b4aca6dc2e9ad09985a824e8f4994cb3aebcee3',1976,'WF','Wallis and Futuna','people-and-society',514,'Population: 9,000, official estimate for 1 July 1973
Nationality: noun—Wallisian(s), Futunan(s), or
Wallis and Futuna Islander; adjective—Wallisian,
Futunan, or Wallis and Futuna Islanders
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic
Population: 160,000, average annual growth rate
2.3% (7/64-7/74)
Nationality: noun—Western Samoun(s); adjec-
tive—Western Samoa
Ethnic divisions: Polynesians, about 12,000
Kuronesians (persons of European and Polynesian
blood), 700 Europeans
Religion: 99.7% Christian (about half of
population associated with the London Missionary
Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all
children from 7-15 years)
Labor force: agriculture 19,148; mining and
manufacturing 1,716 (1961)
Organized labor: unorganized','7c3aed7f94a4e7c7f42e0d99923ec4b42aee0c564e6501c27ad9b6e2594284e5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bba493ccbd6318a8ca3131f92e9923a1dfffd65efd814735301bb29a4cf1edb',1976,'WS','Samoa','people-and-society',520,'Population: 1,663,000,7 average annual growth
rate 2.7% (7/73-7/74)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: almost all Arabs; a few Indians,
Somalis, and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%, Aden 35%
(est. )','ffef1b632977fcf67824d078a3ac7eb90f101897b2652b11789e0909329fe00d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4813aa729f18f04490a02929395f695a04bad73e6ba29cac1329510da6b9f526',1976,'YE','Yemen','people-and-society',524,'Population: 6,622,000, average annual growth rate
2.6% (7/71-1/72)
01-8
Approved For Release 2005/04/22 : CIA-RDP79-01051A0008000100
January 1976
YEMEN (SANA)/YUGOSLAVIA
Nationality; noun—Yemeni(s): adjective—Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab
(mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force:
herding
Population: 21,447,000, average annual growth
rate 0.9% (current)
Nationality: noun—Yugoslav(s); adjective—
Yugoslav
Ethnic divisions: 39.7% Serb, 22.1% Croat, 8.4%
Muslims, 8.2% Slovene, 5.8% Macedonian, 2.5%
Montenegrin, 6.4% Albanian, 2.3% Hungarian, 4.6%
other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman
Catholic, 12% Muslim, 3% other, 12% none (1953
census)
Language: Serbo-Croatian, Slovene, Macedonian,
Albanian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 18.5 million (1970); 49.6%
agriculture, 16% mining and manufacturing, 34.4%
other nonagricultural activities; reported unemploy-
ment averaged 8% of registered labor force (social
sector) in 1967
Population: 25,248,000, average annual growth
rate 2.8% (7/78-7/74)
Nationality: noun—Zairian(s); adjective—Zairian
Ethnic divisions: over 200 African ethnic groups,
the majority are Bantu; four largest tribes — Mongo,
Luba, Kongo (all Bantu), and the Mangbetu-Azande
(Hamitic) make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili,
Kikongo, and Chiluba are all classified as official
languages
Literacy: 5% fluent in French, about 35% have an
acquaintance with French
Labor force: about 8 million, but only about 13%
in wage structure','f1d8aad51170243f1155ec318d7bc6409ba24a9848ad6654f62451f49a05d286','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010001-8','txt','25e0ad1878a37508d5d7b9af4ef3323b1e6cd9414bb0044f8c169eea2df77de2','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010001-8/cia-rdp79-01051a000800010001-8_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('469010e8dbf1c622cb6d7db99a4aa53d228abbed81c94162c635fffeab45ffb2',1978,'HK','Hong Kong','military-and-security',242,'LAND
1,036 km?; 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country)
Land boundaries: 24 km
91
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','308f28c5f82640ea5a0b4079aa7f538ef5df9746a1a9fa9c29c9380ef5dbd061','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e30ae5a57dcab14e12e0b95b89be8ff4fb36fc5c3268d21d14c907bce2a597d',1978,'PH','Philippines','military-and-security',243,'(See reference map Vil)
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 733 km','84f908f4a6a8a23b85c04461f029664693df30cd6b62c92cb6f321174b788913','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b30408ac20a02945fe8ebf3259017d54eaaeb84c91ef32e65d7341f3be646b9a',1978,'PH','Philippines','military-and-security',244,'(See reference map VI}
LAND
1,036 km’, 14% arable, 10% forested, 76% other (mainly
grass, shrub, steep hill country)
Land boundaries: 24 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 733 km','1b4ccae201f909601f4f43211092ba973046c4e49d25e65348cecacc2aaa07b3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

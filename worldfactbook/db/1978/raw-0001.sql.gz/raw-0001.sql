SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e8f7c3885d6162d0bbecfb32967e0beccd035e6a02c152be99e9715ea87eb3c',1978,'','','raw',1,'January’‘LYFs or Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
National Basic Intelligence
FACTBOOK
DIA and DOS review(s) completed.
GC BIF 78-001
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009080.40004-28
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
FOREWORD
The National Basic Intelligence Factbook, a compilation
of basic data on political entitics worldwide, is coordinated and
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central Intelligence Agency,
Washington, D.C. 20505.
The publication is prepared for the use of U.S. Government
officials. The format, coverage and contents of the publication
are designed to meet the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gifts Division
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX
Project subscription service may purchase reproductions of spe-
cific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users may also purchase hard copies of
this publication from:
Superintendent of Documents
U.S. Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-00088-8
‘Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
National Basic Intelligence
FACTBOOK
January 1978
the July 1977 issuance of this
des
ee which should be destroyed.
Factbook, copies of
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Rel ;
uidaniets elease 2005/04/22 : CIA-RDP79-01051A000900010004-4
TABLE OF CONTENTS
Entries in all capital letters refer to
basic data sheets included in this Factbook
Abbreviations for International Organizations ......----+- cae cunuanenesneceeeee cess gese base 10008 x
United Nations (U.N.): Structure and Related Aeencies cccacenaveqeececanesesesesegeeegenegey? xii
py eae
Abu Dhabi (see UNITED ARAB eer
AFGHANISTAN ... ccceauaacavevesenceesesseceseeese se 2211 EMS g0 0000000000700 1
‘Ajman ages UNITED. “ARAB EMIRATES)
ALBANIA .. cecucceceneceucceseqeseeesenne® 2
Anguilla ee ST. SCHRISTOREE NEY
Azores (ee PORTUGAL)
—B—
Balearic Genie bag SPAIN)
SHUTAN: scuarnt eee ee ee ee 21
British iaadueds "68: BELIZE)
BRITISH scarey ISLANDS besten a8 fete nated ea cies eee ee 26
a gee
Cabinda (see ANGOLA)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
04-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009000100
ean Gaon Page
Ce eee Sea accosted ee 33
Canary Islands (see cones
CENTRAL AFRICAN. EMPIRE... SAHRA SSS Mh Oise be did eventoved lec g cece 35
Ceylon hs SRI ana
CHINA, PEOPLES "REPUBLIC. OF. HEAL A eer sven nas tiahasaievaancuntarbiingcivemnaden: — a0
CHINA, REPUBLIC OF Rr ten 41
CONGO (Brazzaville) Spe ee RRR aa See easel bitin Se 45
Congo es (see ZAIRE)
—D—
Dahomey (see BENIN)
DENMARK ........ Hitter 53
DJIBOUTI (formeriy ecch: Tesory of the Ake. ‘and. ‘Tae a ao ielvtnasurececcesbteecsvenes 54
DOMINICAN - REPUBLIC Lie Gate Rca NTS a epi atecSea wlel c a, ~
Dubai (see UNITED ARAB EMIRATES)
=e cae
Sieg eetiairnen a amr cute ee 58
Ellice Islands (see oe
EQUATORIAL GUINEA . Tr ETO EERE DAS treba one ee Teh oa tlh hie) oe 61
nes
FALKLAND ISLANDS (MALVINAS) SEE SORES asi ebb reee csieeed fuhidiateet. kg
FAROE ISLANDS .. Teter ett Of
Fernando Po os » EQUATORIAL GUINEA)
FRENCH POLYNESIA Snasiei ere Wetec eset 7]
French Territory of the Afars oie bas. lees: DJIBOUTI)
Fujairah (see UNITED ARAB EMIRATES)
004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010
January 1978
1978
Approved For Release 2005/04/22
EAC','4ef1af41f9d444e46a0aefc93876b30d018498acf0af01d0d23dd2abfd87d7bc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4489404915c50524764c5b5e4c99fd526db9e4a276077cb29af2362a8bc555ec',1978,'GA','Gabon','raw',2,'GERMAN DEMOCRATIC "REPUBLIC | ceeuuuaenecaananacens1engeee sl segegeeet0S 004008 0000220202000 00 21008
GERMANY, FEDERAL REPUBLIC OF','9c93802e0b946b01eab3ebfa71e958d228c4ff7245fee09a106d6a80069d18b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39ddb3d9740bf15ea1c2f70ab9bdaad14f70d5d3139dab7ca4c45ae5c175854c',1978,'KE','Kenya','raw',3,'KOREA, NORTH
KOREA, SOUTH
KUWAIT eeereereees
Portugese ee « “GUINEA- BISSAU)
: CIA-RDP79-01051A000900010004-4
Page
72
73
74
75
77
78
79
80
81
82
83
84
86
87
88
89
90
91
93
94
95
97
98
100
101
102
104
105
107
108
109
WW
112
113
114
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : January 1978
= Page
ae nee
Madeira Islands (see PORTUGAL) _
Malagasy Se ea Neosat
—N—
NAMIBIA ip aes South-West Africa) ... Ti ttetseeeeeeerettesesesetcenetesserctsecseeen 143
NETHERLANDS ANTILLES TROD SIO AES TAGGED SAN ciao eataieeste vend Cuahieusdancden” «PQ
Northern Rhodesia sees ZAMBIA)
= py:
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22
—pP—
PARAGUAY ween
Pemba ck TANZANIA)
PERU .
POLAND .
PORTUGAL .
: CIA-RDP79-01051A000900010004-4
Page
162
163
164
166
167
168
Portuguese Guinea wane GUINEA-BISSAU)
Portuguese Timor (see INDONESIA)
=2@s
SRE
Ras al Khaimah (see UNITED ARAB EMIRATES)
Rio Muni (see EQUATORIAL GUINEA)','530e10aa5c27e5551b617ee37927ee45166bd238e0ecf6ad18563fe535eae216','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2682258c65609357f383b54bc9902e181dd8e0ef4d86ded50c2e07fab7585ccd',1978,'RO','Romania','raw',4,'a=
ST. CHRISTOPHER-NEVIS- ANGUILLA
ST. LUCIA
ST. VINCENT .
SAN MARINO .
SAO TOME anid “PRINCIPE ccccauaeccusnanaeencessseseseseeestas Gees eeoGeW eg #E00 20000 EEEL AA OSG ET 20020
SENEGAL...
SEYCHELLES ..
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE ou. eseccccssesecrensesecrenneserenees
SINGAPORE ..
SOMALIA...
SOUTH AFRICA .
Southern Risdesia: es "RHODESIA)
South-West Africa = NAMIBIA)
SPAIN .
Spanish ‘Sahara “tee. “WESTERN. SAHARA)
SRI LANKA oie’ cheese
SUDAN .','3baed01664999dca1a8ae423126d26afd7295ac133bfd55cd032c4fc0100d7aa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89a3a9c05ebed5ccb606556b08de7e2b742f522f1bcee34919b08112825ec813',1978,'SE','Sweden','raw',5,'Approved For Release 2005/04/22
170
171
172
173
175
176
177
178
178
180
181
182
183
184
186
187
188
190
192
194
195
197
198
199
201
: CIA-RDP79-01051A000900010004-4
viii
Approved For Release 2005/04/22 :
Approved For Release 2005/04/22 :
a ae
Tanganyika (see TANZANIA)
TANZANIA oo.
Tasmania (see AUSTRALIA)
OAM AINIDS sib esp apctis aaea ada alaardag bv aii aces agua
TOGO.
Transkei (see SOUTH. AFRICA)
TRINIDAD AND TOBAGO stesbactieesasdca
TUNISIA occcccccsecesesesesserereee,
TURKEY ..
TUVALU (tecrneely: Ellice ‘lavids) ss daananeusdsesasigvancastadiedesvantdaasos
—y—
UGANDA ...........
Umm al Qaiwain leoe UNITED. ARAB. EMIRATES)
U.S.S.R.
UNITED ‘ARAB EMIRATES: abe ‘Dhabi, “Aiman, ‘Dubai, | jairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain ocr
United Arab Republic (see EGYPT)
UNITED KINGDOM ooo. cceccccsescseseee.
UNITED STATES ooocccscscccceee
UPPER VOLTA woo ccccecesees
ROMAN Secs etrshiatslees iO See hes cbalincsh dhaceate feizcta ade.
—V—
VATICAN CITY
VENEZUELA....
VIETNAM .
—w—
WALLIS and FUTUNA é
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA Nhe Spanish Sahara) occ.
WESTERN SAMOA .
oat an
YEMEN (Aden) .0....ccccsces saaedhedy ah onde conesieeteveds svete lees
YEMEN (Sana) tite tesa veseeeeeenseteseseuesesauseessentsereneuassn sess
YUGOSLAVIA sbee eee aeevcenecnseussasceaeseseasesseseceseteeeses
=7=.
Zanzibar (see TANZANIA)
CIA-RDP79-01051A000900010004-4
CIA-RDP79-01051A000900010004-4
January 1978
228
229
January 1978 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
MAPS
Additional copies may be obtained from CIA Map Library
| CANADA
li MIDDLE AMERICA
Ill SOUTH AMERICA
IV EUROPE
Vv THE MIDDLE EAST
VI AFRICA
Vil U.S.S.R. and ASIA
Vill OCEANIA
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 as
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
AAPSO Afro-Asian People’s Solidarity Organization
ADB Asian Development Bank
AFDB African Development Bank
ANZUS ANZUS Council; treaty signed by Australia, New Zealand, and the','2280be12b4b98afb263ad04079b61a9d6c9638a3d3987cbb8bd7ff2fb36e7f9f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4e47ec3ddcfa1d6694b99ee541333a956555ca636c434c8be3fc31967f5dee5',1978,'US','United States','raw',6,'ASEAN Association of Southeast Asian Nations
ASPAC Asian and Pacific Council
BENELUX Belgium, Netherlands, Luxembourg Economic Union
BLEU Belgium-Luxembourg Economic Union
CACM Central American Common Market
CARICOM Caribbean Common Market
CARIFTA Caribbean Free Trade Association
CEAO West African Economic Community
CEMA Council for Economic Mutual Assistance
CENTO Central Treaty Organization
Colombo Plan
Bets: Council of Europe
DAC Development Assistance Committee (OECD)
EAMA African States associated with the EEC
EC European Communities (EEC, ECSC, EURATOM)
ECOWAS Economic Community of West African States
ECSC European Coal and Steel Community
EEC European Economic Community (Common Market)
EFTA European Free Trade Association
EIB European Investment Bank
ELDO European Space Vehicle Launcher Development Organization
EMA European Monetary Agreement
ENTENTE Political-Economic Association of Ivory Coast, Dahomey, Niger, Upper
Volta, and Togo
ESRO European Space Research Organization
EURATOM European Atomic Energy Community
G-77 Group of 77
IADB Inter-American Defense Board
ICES International Cooperation in Ocean Exploration
IDB Inter-American Development Bank
IEA International Energy Agency (Associated with OECD)
[HO international Hydrographic Organization
IPU Inter-Parliamentary Union
IRC International Red Cross
LAFTA Latin American Free Trade Association
LICROSS league of Red Cross Societies
NAM Non-Aligned Movement
NATO North Atlantic Treaty Organization
OAS Organization of American States
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
OAU
OCAM
ODECA
OECD
SELA
UDEAC
UEAC
WEU
WPC
AIOEC
ANRPC
APC
ASSIMER
CIPEC
IATP
IBA
ICAC
IcCCO
ICO
1looc
ISO
ITC
Iwc
IwCc
OAPEC
OPEC
UPEB
WSG
Organization of African Unity
Afro-Malagasy and Mauritian Common Organization
Organization of Central American States
Organization for Economic Cooperation and Development
Latin American Economic System
Economic and Customs Union of Central Africa
Union of Central African States
Western European Union
World Peace Council
COMMODITY ORGANIZATIONS
Association of lron Ore Exporting Countries
Association of Natural Rubber Producing Countries
African Peanut (Groundnut) Council
International Mercury Producers Association
Intergovernmental Council of Copper Exporting Countries
International Association of Tungsten Producers
International Bauxite Association
International Cotton Advisory Committee
International Cocoa Council
International Coffee Organization
International Lead and Zinc Study Group
International Olive Oil Council
International Sugar Organization
International Tin Council
International Whaling Commission
International Wheat Council
Organization of Arab Petroleum Exporting Countries
Organization of Petroleum Exporting Countries
Union of Banana Exporting Countries
International Wool Study Group
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
xi
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc Security Council
GA General Assembly
ECOSOC Economic and Social Council
TC Trusteeship Council
ICJ International Court of Justice
ae Secretariat
Operating Bodies:
UNCTAD U.N. Conference on Trade and Development
TDB Trade and Development Board
UNDP U.N. Development Program
UNICEF U.N. Children’s Fund
UNIDO U.N. Industrial Development Organization
Regional Economic Commissions:
ECA Economic Commission for Africa
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
ECWA Economic Commission for Western Asia
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development (World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFAD International Fund for Agricultural Development
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural Organization
UPU Universal Postal Union
WFC World Food Council
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
xii
el OO
Approved For Releas
e 20 :
january 1978 05/04/22 : CIA-RDP79-01051A000900010004-4
Political, sociological, and economic data, including monetary conversion rates, generally
reflect information through mid-October 1977, except for population estimates, which have
been projected to 1 January 1978. Military manpower estimates are as of 1 January 1977
except for average number of males reaching military age, which are projected averages for
the 5-year period 1977-81. Military and communications data are as of 31 October 1977
unless otherwise indicated.
Most of the land utilization estimates are rough approximations, and most of the
statistical data are rounded (thousands and millions). Figures for ‘arable’ may reflect only
the area actually under crops rather than the potential cultivable. Fishing limits are included
only when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The difference between the two is
in the addition or subtraction of the value of return on foreign investment. GDP equals GNP
plus income earned in the country but sent abroad, minus income earned abroad but sent into
the country. GDP thus tends to exceed GNP in debtor countries, and the reverse is true in
creditor countries.
Mgjor ports are the largest maritime ports of the country, relative to other ports of the
same country, on the basis of estimated port capacity, alongside berthing accommodations,
and commercial or naval importance. Minor ports are the remaining ports of a country which
have, relative to the major ports, significantly lower estimated capacity, fewer alongside
berthing accommodations, are of less commercial or naval importance. Major transport
aircraft are those weighing over 20,000 pounds. Military budgets are in U.S. dollar
equivalents. The dollar sign refers to U.S, dollars unless otherwise stated. The abbreviation FY
stands for U.S. fiscal year; all years are calendar years unless otherwise indicated.
Approximate Metric Conversions
Symbol When You Know Multiply by To Find Symbol Symbol When You Know Multiply by To Find Symbol
LENGTH LENGTH
mm millimeters 0.04 inches in in inches 2.5 centimeters cm
cm centimeters 0.4 inches in ft feet 30 centimeters cm
m meters 3.3 feet ft yd yards 0.9 meters m
m meters Ww yards yd mi miles 1.6 kilometers km
km kilometers 0.6 miles mi AREA
AREA in? square inches 65 square centimeters cm’
em? — square centimeters 0.16 square inches in? ft? square feet 0.09 square meters m?
m? square meters 1.2 square yards yd? yd? square yards 0.8 square meters m?
km? square kilometers 0.4 square miles mi? mi? square miles 2.6 square kilometers km?
ho hectares (10,000 m) 2.5 acres acres 0.4 hectares ha
MASS. (weight) MASS. (weight)
or
g gram 0.035 ounces oz ounces 28 grams 9
kg kilograms 2.2 pounds lb Ib pounds 0.45 kilograms kg
t tonnes (1000 kg) 1 short tons short tons 09 tonnes t
VOLUME (2000 fe)
ml milliliters 0.03 fluid ounces fl oz me ae
'' liters 21 pints pt tsp teaspoons 5 milliliters ml
\\ liters 1.06 quarts at Tbsp tablespoons 15 milliliters mi
I liters 0.26 gallons gal fl oz fluid ounces 30 milliliters mil
mm cubic meters 35 cubic feet i? c cups 0.24 liters |
m cubic meters 1.3 cubic yards yd? pt pints 0.47 _ liters |
at quarts 0.95 liters |
gal gallons 3.8 liters \\
i? cubic feet 0.03 cubic meters mom
0.76 cubic meters m?
yd _cubic yards
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','bc425deeabc15aa5f63bba6bcf95ab9a45ad8341320c64754d2e7ec4141da17f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac25c913c2100cfb83838c79f97f569c21c6a2ef9379caf59cdfbda53fab7b5a',1978,'AF','Afghanistan','raw',7,'Kabul x
ANISTAN
(See reference map Vil}
LAND
647,500 km?; 22% arable (12% cultivated, 10% pasture),
75% desert, waste or urban, 3% forested
Land boundaries: 5,510 km','d3908736e6ea054980f6412aea04137a9813bef106e24e64af3a5ad7e486d76b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3ab3a8c7557bf95a6c4ccca74d83b693031a24d518c97b68c493b8205ff3105',1978,'','','raw',1,'July phy MBor Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
si
= National Basic Intelligence
DIA and DOS review(s) completed. FACT BOO K
mee g:
Br
F 78-002
Approved For Release 2005/04/22 : CIA-RDP79-010514000900010f)96 78
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
FOREWORD
The National Basic Intelligence Factbook, a compilation of
basic data on political entities worldwide, is coordinated and
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central Intelligence Agency,
Washington, D.C. 20505.
The publication is prepared for the use of U.S. Government
officials. The format, coverage and contents of the publication
are designed to meet the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gifts Division
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX
Project subscription service may purchase reproductions of
specific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users may also purchase hard copies
of this publication from:
Superintendent of Documents
U.S. Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-00095-1
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
1 July 1978
To: National Basic Intelligence FACTBOOK Addressees
The form provided below is an effort to maintain a current
dissemination list for the FACTBOOK. Please verify mailing
address and number of copies required, The completed form,
indicating any changes to your requirements, should be returned
to the FACTBOOK Editor as soon as possible.
eee cate ne ee ee ae ce eee Oe Se ee ae cS eS A OY Sw mS ke ee OS me ED A cD ND OD SO SOE A DD DO EO OS ND SD Ne Sm
To: FACTBOOK Editor
Geographic and Cartographic Research
Central Intelligence Agency
Washington, D.C. 20505
Change mailing address from:
rer nn nnn
to:
i NE RT
Change number of copies required from: to:
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
National Basic Intelligence
FACTBOOK
July 1978
Supersedes the January 1978 issuance of this
Factbook, copies of which should be destroyed.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
TABLE OF CONTENTS
Entries in all capital letters refer to
basic data sheets included in this Factbook:
Abbreviations for International Organizations .........0000...c ees
United Nations (U.N.): Structure and Related Agencies ........0.....
—A—
Abu Dhabi (see UNITED ARAB EMIRATES)
AFGHANISTAN) se: sefie ccecesecedonet cee: be geecteesustin dg Manatee ernie ieee
‘Ajman (see UNITED ARAB EMIRATES)
ALBANIA: sete Shi aceieeteinseereeas atts rise Oe A UR ase ats en ree
ALGERIA. A veciectieth dott gat eecan dried Gide ee Aster rane eds ucdast hemi eaeneee teak
ANDORRA ooo... cecccccccccececcereeteeee sree ne ests eteer enna snntee enna ee rte nieenneeresaseeaeesneeey
ANGOLA? acticin iekenaas Beratigid Laieets nancial Lani ema peas tities
Anguilla (see ST. CHRISTOPHER-NEVIS)
ANTIGUAS cosescccciiisoe sd ehicandleltassa dalled Bian dee adostel ae da dee oid Tonto tse hetaeed Ea
ARGENTINA So. 2.ccn ate fed Sea tieernonimaty Ghai mere eit gael ates mula eet
AUSTRALIA sci etiee cae cee Oe Ree nas AS Se its ca age ed ee
AUSTRIA, oiceee Siete henton ue ed lin ee Seiad Meeagae mein
Azores (see PORTUGAL)
ey
BAHAMAS; THE® 223. j2::i tian ned hte ntenet lathes Gut eee adie
BAHRAIN: ccc: oietenciee es cues fe atin Astrea Alert enennd aioe tae ica tanantet sire
Balearic Islands (see SPAIN)
BANGLADESH © ois. cccavseteete gk he taceie ea degen ct ee eae cg pa oanes gs Hess ee
BHUTAN soe c cde iacs 8 ibaa eetecidatiuntianee ela behets dat patel ee UE Spader Teas
BOLIVIAS ses ctr dete vedi oestivertehem eae aig Aes hee tes alae Patpeg ted
BRAZIL: 2.ce5: Sieg ets seeeualces ed av daaash aan engine Mike outcome dadaentgt Lace bel ood ie oa atewe ab leenanies
British Honduras (see BELIZE)
British Solomon Islands (see SOLOMON ISLANDS)
BRUNED 3. :00ck Sec orne tcl al alo hie, naan ae ne
BURMAS® occ ehcdsictcatehis Hinlekve ten lons aeasloiato ei hana iacaees Be tha thoc der din septa gavestess
a oe
Cabinda (see ANGOLA)
CAMBODIA » Soibund tocar at edge A ody a ites Gants
CAMEROON: iesceencnis les et lane PAS ee ea eons ee ty e age
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
iii
iv
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
a; Page
CANADA oon. : 3]
Canary Islands (see SPAIN)
CAPE VERDE 2 eta atesterrith ih Matec cachatua Letgseshiias shale bbulesime hin . 33
CENTRAL AFRICAN EMPIRE 2c ccccccec eee ee eee cee er bebe bebe 34
Ceylon (see SRI LANKA)
CHAD isco ieee wet Se aig ae edhe es fT tah ta atalr cna vain eee tien bey tusdtueg vata Magy uetaste seat otes 35
CLE os dey ocestengg eeseantad oyu eeacee oes ; 36
CHINA, PEOPLE’S REPUBLIC OF... 38
CHINA, REPUBLIC OF ............. Lips velar 05 Masha ny detent imetiaer vont ubades tte ait ake 39
COLOMBIA ooo cece cece cee beet ee bn : 4)
COMOROS 02000. no Peigaglle ais tantigt dow ae foatitcana a ae antes beat pean Gee uinih tueas saddles 42
CONGO (Brazzaville) ccc ee cece eee 43
Congo (Kinshasa) (see ZAIRE)
COOK ISLANDS oo. dahaiatabenen mess Dedasaeel nar lomtiee nek : 44
COSTA: RIGA? ocess2iccte cvsitestbe nica ciss.onl Gutessecepiadlbviadvsesvacbeaetcid aun nie dosoueese to! : 45
CUBA 2 sx8 facsreteton sinameaianich Adtedtenedes headesls nearer 46
CYPRUS = *./rcoste et rat scap de ei hanseats ag eheauretaeatbiaseeunedmseet 47
CZECHOSLOVAKIA ooo ieee eee eee eel 49
= p=
Dahomey (see BENIN)
DENMARK once. sr 2el ufiins Cease ab nhea ona 5]
DJIBOUTI (formerly French Territory of the Afars and Issas) ..0............... 52
DOMINICA oe, Sodeanteacais ce tega shane ie od . 53
DOMINICAN REPUBLIC occ e cee eee eeeeoe eb r 54
Dubai (see UNITED ARAB EMIRATES)
a ee
ECUADOR sb hSudeediaondabiness Sener er 55
EGYPT os caiyen tts vabt ronaceane Oy Sebastes a. eign cs ag inelyamnie courte. ok! 56
Ellice Islands (see TUVALU)
ELS SALVADOR oo chee Beata ss deans Sadiets a Taaheavn Sota tetataee ide xe vba doled cares apsene ob add en ceoae . 58
EQUATORIAL GUINEA ooo... 59
ETHIOPIA oo. hit werbinlae eaten Bscatabiten ssthode ieee he maetanotutaie scwcenkhy seca win haus ae 60
a ar
FALKLAND ISLANDS (MALVINAS) 62
FAROE ISLANDS 200. edie 62
Fernando Po (see EQUATORIAL GUINEA)
HUD: rgeen ality oN Ate lanih arte elated sla a beetle S ete ar a eat ha Ot oats ame oy 63
1 |B ee 65
FRAN GES sess siizcuct deocthicasend ne vbass Sig iiest ch nutogb sete depiooesitssdl tes tan bac vsti Sean delas theo, bal, Roche 66
FRENCH GUIANA ooo... pp sans Aaeseetrse settee, dtc. cera lhe Seiad oo conepaeteet 68
FRENCH POLYNESIA ooo. xing de luheahyhdubucussey, 269
French Territory of the Afars and Issas (see DJIBOUTI)
Fujairah (see UNITED ARAB EMIRATES)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
“CG Page
GABON? suststsntiretiadeodesanGancian We sthitetast teeta, ich tothe Soh wi cae ee em 70
GAMBIA,» THE 2. ssse) antes oxeiedee dog. ly der et in iaadatecas dt yeavaniin tovcbvlucahas lucdeags tudktgiDs Leatiectenphe ike 71
GERMAN DEMOCRATIC REPUBLIC ooo... cect ec cette cre cretrerterteeitent: 72
GERMANY, FEDERAL REPUBLIC OF ooo... cece ee ceteevtttereerierienes 73
GHANAS fiche ke aiitnmah Mimi a eet daca MEME Dae canter ana eatten winroNi Sastntee aaah caniiah fat tn 75
GIBRALTAR. s2rsciede red. cis cede ca ane ot her aed anya eetien of nea a Seiplan yan ends hed bea ewes 76
GILBERT ISLANDS: gc oes scene. acsnossrepaetdudayt Mp iabaeh aeaeie rele about sSrulsadbanceonsiiSi sale emiare. 77
GREECE cles rotnssnatobaticnay Re ies Wed tae Eebe hee ain Sees cebu tal tet rung ghecuaecakt oatbersc emt teiatit 78
GREENLAND ©: <p ocoxsjuteeraetsi cd ov larexs non tea whes vatcods dacs vaestvicn ecccker devout desea weer ee aloe Alo es 79
GRENADA 8 aiventece iia cot ede add A da eee Gamera mevhetlais sit liasunt ovetattlab nies (ian cltarie he 80
GUADELOUPE i had ed es tllihy aiathd ah lien foe hut ca tata tit dent cet My i lai 81
GUATEMALAS 8 ie coht cent RSet Ra Noa Ma eels tals Mee date ddan AM corel ds ooh ate esata betas 82
GUINEAS iss co ssennste, oc8edeeg Sone aehsealesek ahaa ct oan ours of tacaseandal Aides baoyndae dd obliga bebe lid gaadiamleleleng 83
GUINEA=BISSAU © bes assadeact cet mieta se etsteenss satetasniscislediald vllansoaal eheuse sae oeora tele Swtlutgiaant 84
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA © isd a2 Bowe sists cpetivanedasashi tude Rader eter aadad Sd Pdlace bed aude ouboeceeamewn tea Sen ss 85
—H—
TAIT Ns Bisse A tein Ag8k it Back weet cps cHAE8 a atest la a ea A a Se eh ar i Pon och echo gce adnan Rl hd 87
HONDURAS et scestesn, erent oe ey Ri as ace ay Bele mht ace fan osy babi arn ol Ad, Uh et whtwine Dunnett 88
HONGKONG § ne soocctis ie faicake ace anced ecaonaette na ea tented alder netestn havdern vaes nudoncliaeeay 89
HUNGARY iscsi geile ve Megat teins dined Lid le tahegthatasieds cated eyed aw se siaantin psd oaahede th seataearedee, 90
IG ELAN DD rece h iodteianc eh ct acetal tocart atutineted one ahwd cs hos ate Rarihs salons Masta uad be lstnatteeaddsxe ston aa loess 92
UINUDIAG ss ts Seat i elseadade sev eite Maaartas neler atiat Me Maou’ Rela nth dak lente de (tell cindy had Mla tat) 93
INDONESIA se ctigesc ik Ae ke Bite h eek aren ta cactl alt cdilnc UNS dis Son ine ered aes Beebe 94
VRAIN 2c etecrteta eee teats haan nes beige tbe ratee satan Mennnalnles stocttenasdiesentegeat anlar septate oath eae bar dahl 26 96
DRAG) oo oisea i 335 2 ict seated be Seah abs aera g esOeAS ga ay gen daa Vacera dncasal sasoah va dresses vacaiedce Muh ete hi 97
RELA IND ssn ierssodpsenshients degmat gute (tee Wee vosteutn rest eM cudacldilsl so citnaan atdlec satin tes 98
ISRA EUS ci 2h fli Pete oa Bike dieec td bens aici Beene Patent les Soa Ut bs Binge tied day eMac un dts fennel ghia 100
UTA dessa Ue soda read srt ait ge ania latte tear lial’ devatdealea sens) tack Sgataratesncdaltpabas 101
IVORY (COAST. 4s5: cee ait eine ciate Pastor afdeinctta wide dea meeshenedd ste yserathd 2 WA bal oe uel tise 103
JAMAICA” gies, cote ain eg Agia eA a aad eas eid peepee eee 104
DAPANG 2 coesncrodinstes Mateneteg inapact con kyuth eeu tiea leah eeoah ca Secs Nah omaeda dial lat envehs decachewuls 105
JORDAN) cissessvceawaiee tittle enc teenth RR cei iil ot del on Spurl Ansa eaevbeidaaees vous suerwnieaaoiel fase 107
Ke
KENYA ecsgtiics cece ord Cis ias Mermadavatatna ttn ttheind Hielad cot ata dags Raa whe eee 8, 108
KOREA; (NORTH ssictrnessctenthacsdeattecthetencditgtatedl caedues Svat ds cudlpgeueldR add dni wiateas 109
KOREA; SOUTH secsuiteteyepe ce degtead detegereesteected atin ia Uline cnecbdinedey Mebu di casstetuiscy ats 110
RWWA IT 0s pre Sears RS i ack es ast Pa saved aatalessh Racin us teats else lan 0h cce gai he UA A 112
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Spe Page
LAOS? cesarean: pctagi ane Bhs. tases Se Bie Tee Pitetag fanl senugfontaaadennsngy oa 113
LEBANON: csesisesasticel saat ade edt ; sepeaaices this Bo eee ... 114
LESOTHO pohcdebed dc chien : ; stones iphredeibisastess £16
LIBERIA ..... ..... ie Dhar eee woe Sbegtaneuacean etudeeann AMS,
LIBYA ace ust eeaes aunts emdancecee tee Loplahs seas ute tigen at ite Budock aston sac AiG entpaoctonets 118
LIECHTENSTEIN 2.00. me ; ; eee nui IY
LUXEMBOURG ooo ect (Sete hie towtdten® N20
= Nh
MACAO __............ 7 ee . ee wits auvekdcevnss Sb2i
MADAGASCAR oo. eee : Naghinrahenantte nidetenmamtesaetes, 122
Madeira Islands (see PORTUGAL)
Malagasy Republic (see MADAGASCAR)
MALAWI dena ae niiee gastos ssganthionnspdiaeacteege eguadeyeane, 22M!
MALAYSIA ........ le eat Sai omens as come ace tamer Rei e nace satpats Seaeeriones tiga meg boreateek . 125
MALDIVES oo. viata Ria feted Mitegh be aiss an scten erie Magassstenh LS
MALD ce ccee nd eitetinnas sek beats: sates a totes ere: “ uniteahate teeessenmesesnmpte meee? 129
MARTINIQUE ....0....00.00 |. naga tats ites leeks actbadaptitoneaduansa erties. © Idi
MAURITANIA ........ Pea eT ee a, i ltamdueeemr ety 1382
MAURITIUS ............... i sid abe cles sie oxiertoees pie sdy 2a tas tee te deeates soph oeyongenee ohesee ays 133
MONACO Lo. sudldevgdhidsaded anil dg asaeaeneaQimat ated Gate pingehh tancsengeen iy tas eect « SO:
MONGOLIA... da ente non aeretne aa Machine hans Soeettatpdaesons Smieees MBit a haraatbicenwasss ame aycatne 137
MOROCCO _........ vita “gelain norman Tegan: Ey ne cisee’ gar nena aacsctotee sonra ac cet weasumieaettco sts ee SGIO
MOZAMBIQUE _..0.0. ee Bicergsdtuhestete tira linn, come sun asnauearsueradee, -OLSP
—N—
NAMIBIA (formerly South-West Africa) 0.000.000.0000... Ge eae Gatatratan, *haO
WAU ce ceciieutet ota Sundeast dlebttattguadiotenn Madinah anes lusiuedeakeee miata, IA2
NEPAL) 20. 25c0 Wis tsGecats tert: Reto: ete stuathdaiieisahs Hn cendse me Seecoee oes LAL
NETHERLANDS |... 000 nis sagesganuguae tats aichy sashes hhagsisiateaieraien Vad
NETHERLANDS ANTILLES 2.0000 Leeched cass AS:
NEW CALEDONIA | one nso rately bAZ
NEW HEBRIDES shehes stash is cane gets coeeman’ Soutuntgbieta ts tridembantenotrat. 148
NEW ZEALAND udp teaeangs peters agiaade nawgi tee atsueseveumier amuse — LAG
NICARAGUA ooo cece e eee enentnnerie sotuetniuiaueeceaeny enetseantee, CLAY:
NIGER? oii ecg seein uedtaawe nn ctdvedthin staring ids baie sideshenineris emigauntGdeusdrnsiarieieate MDT
Northern Rhodesia (see ZAMBIA)
NORWAY vsicscsocseasieos Set Ate eta cas tad ues Secrets pelea ones aaa tects otaae 153
OMAN oo. engl iPM aheotens Lihaoittawiaugteanas hav tints tetenee. VS:
PAKISTAN ......0.........
PANAMA > sedis uct cosseasi feels emererdeninyeint aie tong Eetesees
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
(ee
July 1978
A
pproved For Release 2005/04/22 :
CIA-
A-RDP79-01051A000900010006-2
—P— Page
PAPUA NEW BCT a aa eee 159
A HE 160
Pemba (see TANZANIA)
DER can Pn ene 161
PHILIPPINES cassis oe ees RO te 162
ee ee 164
PORTUGAL cece a dca tence T 165
Portuguese Guinea (see GUINEA-BISSAU)
Portuguese Timor (see INDONESIA)
—Q—
Lake, ceca eee EE “sehen vgs saa as f, nahn 167
—R—
Ras al Khaimah (see UNITED ARAB EMIRATES)
en ect . 168
RHODESIA 2 Rr eee oho ekteasemengeutenye eet 169
Rio Muni (see EQUATORIAL GUINEA)
eect Cen pane ae _.. 170
i ee ceive guaran aes Ww
_S—
ST. CHRISTOPHER-NEVIS-ANGUIL-A LEAS ivan nse e Os 172
ache oe aaa = uandiepaetee ett As ae! ED
ST. BLAH petigon te EO aataant adenine” 174
SAN Ct te a Dig iek eee oo. WS
sAQ TOME and re ee ae ney ee .. VW76
SAUDI REAR tear ee » ete cota dag eebgee Ee a ane \\77
ee en 178
ee a ee aaiyioete 180
Sharjah (see UNITED ARAB EMIRATES)
SIERRA PONE euene ee EN cs
ceneeeesenennnaee? wit ES ES 181
SIGAPORE cictiee en gale on RR a al _ 182
SOLOMON ISLANDS (formerly British Solomon \\elands) sae wae 183
ee eee ere 184
SOUTH eee 185
Southern Rhodesia (see RHODESIA)
South-West Africa (see NAMIBIA)
BAIN cadence eauiA wie Midian site sits OLE 187
Spanish Sahara (see WESTERN SAHARA)
SRI LANKA (formerly ee eat es alee 189
SUDAN A sana even me. ees 191
Ue ee 192
ee 193
SMAZLAN 195
SWITZERLAND ee a i aaah ee 196
ne ae 197
Approved Fo
rR
elease 2005/04/22 : CIA-RDP79-01051A0
- 00900010006-2
|
: CIA
Approved For Release 2005/04/22
-RDP79-01051A000900010006-2
—T— Page
Tanganyika (see TANZANIA)
a on ‘SiRi) 199
Tasmania (see AUSTRALIA)
009 ics MAisesagen 200
ne ee ee 20]
re ta Si fiégy 202
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO ia ee 203
ee ee ee 205
VA ltl egg 206
TUVALU (formerly Ellice i ec 207
—U—
Di tee cae Sef taal 208
Umm al Qaiwain (see UNITED ARAB EMIRATES)
i i ene a cee. 209
UNITED ARAB EMIRATES, Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al i ae tas 210
United Arab Republic (see EGYPT)
UNITED SATS tnt 211
UNITED ee ee a 227
UPPER oe ean 213
Se ee 214
—y_
VATICAN CITY ete 215
PEP nome 216
i 218
—w
WALLIS and SOUTH afgiGi 219
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish ic 219
WESTERN SAMOA 0 EE IE cee te 220
—yY
YEMEN Si ttt 221
YEMEN ee ee ee 222
YUGOSLAVIA ODER ian 223
—zZ—
ttc 225
ee 226
Vili
July 1978
10006-2
-01051A0009000
d For Release 2005/04/22 : CIA-RDP79-0
Approve
Approved F :
pp or Release 2005/04/22 : CIA-RDP79-01051A000900010008.2''"”*
MAPS
Additional copies may be obtained from CIA Map Library
| CANADA
1) MIDDLE AMERICA
ill SOUTH AMERICA
IV. EUROPE
Vv THE MIDDLE EAST
Vi AFRICA
VIL U.LS.S.R. and ASIA
Vill OCEANIA
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
ix
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
AAPSO
ADB
AFDB
ANZUS
ASEAN
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECOWAS
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
G-77
IADB
ICES
IDB
IEA
IHO
IPU
IRC
LAFTA
LICROSS
NAM
NATO
OAS
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
Afro-Asian People’s Solidarity Organization
Asian Development Bank
African Development Bank
ANZUS Council; treaty signed by Australia, New Zealand, and the','166421671d36cc1ffd3696c16b94291150aaa09aa214966d1ae6f082f87d1872','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1450bc818d89ab282d4343412ecdd3ba9c7c15a1dfb0608dae3c05bac73d7564',1978,'US','United States','raw',2,'Association of Southeast Asian Nations
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market
Caribbean Free Trade Association
West African Economic Community
Council for Economic Mutual Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Economic Community of West African States
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Space Vehicle Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey, Niger, Upper
Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Group of 77
Inter-American Defense Board
International Cooperation in Ocean Exploration
Inter-American Development Bank
International Energy Agency (Associated with OECD)
International Hydrographic Organization
Inter-Parliamentary Union
International Red Cross
Latin American Free Trade Association
League of Red Cross Societies
Non-Aligned Movement
North Atlantic Treaty Organization
Organization of American States
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
July 1978 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
OAU
OCAM
ODECA
OECD
SELA
UDEAC
UEAC
WEU
wPeCc
AIOEC
ANRPC
APC
ASSIMER
CIPEC
IATP
IBA
ICAC
IcCCO
ICO
1IOOC
ISO
ITC
IWC
wc
OAPEC
OPEC
UPEB
WSG
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
Organization of African Unity
Afro-Malagasy and Mauritian Common Organization
Organization of Central American States
Organization for Economic Cooperation and Development
Latin American Economic System
Economic and Customs Union of Central Africa
Union of Central African States
Western European Union
World Peace Council
COMMODITY ORGANIZATIONS
Association of Iron Ore Exporting Countries
Association of Natural Rubber Producing Countries
African Peanut (Groundnut) Council
International Mercury Producers Association
Intergovernmental Council of Copper Exporting Countries
International Association of Tungsten Producers
International Bauxite Association
International Cotton Advisory Committee
International Cocoa Council
International Coffee Organization
International Lead and Zinc Study Group
International Olive Oil Council
International Sugar Organization
International Tin Council
International Whaling Commission
International Wheat Council
Organization of Arab Petroleum Exporting Countries
Organization of Petroleum Exporting Countries
Union of Banana Exporting Countries
International Wool Study Group
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
xi
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
UNITED NATIONS (U.N.):; STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc Security Council
GA General Assembly
ECOSOC Economic and Social Council
TC Trusteeship Council
ICJ International Court of Justice
es ates Secretariat
Operating Bodies:
UNCTAD U.N. Conference on Trade and Development
TDB Trade and Development Board
UNDP U.N. Development Program
UNICEF U.N. Children’s Fund
UNIDO U.N. Industrial Development Organization
Regional Economic Commissions:
ECA Economic Commission for Africa
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America
ECWA Economic Commission for Western Asia
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization
GATT General Agreement on Tariffs and Trade
IBRD international Bank for Reconstruction and Development (World Bank)
ICAO International Civil Aviation Organization
IDA International Development Association (IBRD Affiliate)
IFAD International Fund for Agricultural Development
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural Organization
UPU Universal Postal Union
WFC World Food Council
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
= Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
July 1978 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Political, sociological, and economic data, including monetary conversion rates, generally
reflect information through mid-April 1978, except for population estimates, which have been
projected to 1 July 1978. Military manpower estimates are as of 1 July 1978 except for
average number of males reaching military age, which are projected averages for the 5-year
period 1978-82. Military and communications data are as of 30 April 1978 unless otherwise
indicated.
Most of the land utilization estimates are rough approximations, and most of the
statistical data are rounded (thousands and millions). Figures for “arable” may reflect only
the area actually under crops rather than the potential cultivable. Fishing limits are included
only when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The difference between the two is
in the addition or subtraction of the value of return on foreign investment. GDP equals GNP
plus income earned in the country but sent abroad, minus income earned abroad but sent into
the country. GDP thus tends to exceed GNP in debtor countries, and the reverse is true in
creditor countries.
Major ports are the largest maritime ports of the country, relative to other ports of the
same country, on the basis of estimated port capacity, alongside berthing accommodations,
and commercial or naval importance. Minor ports are the remaining ports of a country which
have, relative to the major ports, significantly lower estimated capacity, fewer alongside
berthing accommodations, are of less commercial or naval importance. Major transport
aircraft are those weighing over 20,000 pounds. Military budgets are in U.S. dollar
equivalents. The dollar sign refers to U.S. dollars unless otherwise stated. The abbreviation FY
stands for U.S. fiscal year; all years are calendar years unless otherwise indicated.
Approximate Metric Conversions
Symbol When You Know Multiply by To Find Symbol Symbol When You Know Multiply by To Find Symbol
LENGTH LENGTH
mm millimeters 0.04 inches in in inches 2.5 centimeters em
cm centimeters 0.4 inches in ft feet 30 centimeters cm
m meters 3.3 feet tt yd yards 09 meters m
m meters Ww yards yd mi miles 1.6 kilometers km
km kilometers 0.6 miles mi AREA
AREA 7 2 in? square inches 6.5 squate centimeters em?
cm? square centimeters 0.16 square inches in? i square feet 0.09 square meters mm
m? square meters 1.2 square yards yd? yd? squore yards 0.8 square meters m
km? — square kilometers 0.4 square miles mi? mi? square miles 2.6 square kilometers km?
ha hectares (10,000 m’} 2.5 acres acres 0.4 hectares ha
MASS (weight) MASS (weight)
ga gram 0.035 ounces oz oz ounces 28 grams
kg kilograms 2.2 pounds tb tb pounds 0.45 kilograms kg
t tonnes (1000 kg) WwW short tons short tons 09 tonnes t
VOLUME (2000 to)
VOLUME
ml milliliters 0.03 fluid ounces fl oz
1 liters 2.1 pints pt tsp teaspoons 5 milliliters ml
| liters 1.06 quarts at Tbsp tablespoons 15 milliliters ml
| liters 0.26 gallons gol fl oz fluid ounces 30 milliliters ml
m? cubic meters 35 cubic feet i? c cups 0.24 liters |
m? cubic meters 1.3 cubic yards yd pt pints 0.47 liters |
qt quarts 0.95 liters i
gal gallons 3.8 liters |
fr cubic feet 0.03 cubic meters m
yd? cubic yards 0.76 cubic meters m?>
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978','4abf7251a9b1f82e6e395be82d009b09436037d1c4077377f4472f2bb29557ac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('556bfbadc98e465725a3a45ea48ff65a140b5349a373fc3331845d2a4285258d',1978,'AF','Afghanistan','raw',3,'Arabian Sea
{See reference map Vil)
LAND .
647,500 km?; 22% arable (12% cultivated, 10% pasture),
75% desert, waste, or urban, 3% forested
Land boundaries: 5,510 km','c3055bc0e6cbbc80d327d50e69e43f3c379823cb22b2bda23ae77107fdf888f4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aefb520e3c63d68a01e54bc4600cfd89f9b23e03906e9a265af711864d717ce4',1978,'AF','Afghanistan','people-and-society',8,'Population: 17,642,000 (January 1978), average annual
growth rate 2.3% (7-75 to 7-77)
Nationality: noun—Afghan(s); adjective—Afghan
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9% Uzbeks,
9% Hazaras; minor ethnic groups include Chahar Aimaks,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbek and Turkmen), 10%
thirty minor languages (primarily Baluchi and Pashai);
much bilingualism
Literacy: under 10%
Labor force: about 5.75 million (FY77 est.); 75%-80%
agriculture and animal husbandry, 20%-25% commerce,
small industry, services; massive shortage of skilled labor
Organized labor: none','ffe1f7fb3e0affad56b822855eb9bf45678e8ac93f8dcd3e6d16ed84075defb5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b082df63dd5aa376dbad3770a341148b2f9853989810bb9eb8d5b96840ce9273',1978,'AL','Albania','people-and-society',13,'Population: 2,560,000 (January 1978), average annual
growth rate 2.4% (current)
Nationality: noun—Albanian(s); adjective—Albanian
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10%
Roman Catholic (observances prohibited; Albania claims to
be the world’s first atheist state)
(See referance map (¥)
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics avail-
able, but probably greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9%
industry, 21.6% other nonagricultural','2661cc67c99ea44a5fd34e17effd71029ee69b70bb92ff9e121646eb74c05f33','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31c25403c97af4eea9af7c01b44bdfc1240848b1302360ff11bb0ec06a0932cd',1978,'DZ','Algeria','people-and-society',17,'Population: 18,120,000 (January 1978), average annual
growth rate 3.1% (7-74 to 7-76)
Nationality: noun—Algerian(s); adjective—Algerian
Ethnic divisions: 99% Arab-Berbers, less than 1%
Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 3.3 million; 50% agriculture, 20% industry,
25% other (military, police, civil service, transportation
workers, teachers, merchants, construction workers); at least
20% of urban labor unemployed
Organized labor: 17% of labor force claimed; General
Union of Algerian Workers (UGTA) is the only labor
organization and is subordinate to the National Liberation
Front','3f9a78f08a06be02f75703a7f313194b948f861d041feee6ded612f4b41fcefc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f20a264d6c8033231e53f1094761a3132577f79c42a22c513c152fb4aae78a6c',1978,'AD','Andorra','people-and-society',21,'Population: 29,000 (official estimate for 1 July 1976)
Nationality: noun—Andorran(s); adjective—Andorran
Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French and
Castilian
Labor force: unorganized; largely shepherds and farmers','f7084cd572659294510a16ea22b2d2048e5e091e984b273f87334ad62f851d4f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac56aa164d40261a296578c3d1fe86271c2b55610389c059ab672f0b12e4fc48',1978,'AO','Angola','people-and-society',25,'Population: Angola (including Cabinda), 6,346,000 (Janu-
ary 1978), does not take into account emigration from
Angola, average annual growth rate 1.6% (12-60 to 12-70),
Cabinda, 101,000 (January 1978), average annual growth
rate 3.38% (12-60 to 12-70)
Nationality: noun—Angolan(s); adjective—Angolan
Ethnic divisions: 98% African, 5% European, 1% mestizo
Religion: about 84% animist, 12% Roman Catholic, 4%
Protestant
Language: Portuguese (official), many native dialects
Literacy: 10%-15%
Labor force: 2.6 million economically active (1964);
531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Population: 72,000 (January 1978), average annual
growth rate 1.2% (7-70 to 7-76)
Nationality: noun—Antiguan(s); adjective—Antiguan
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other
Protestant sects and some Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000, 20% unemployment
6 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ANTIGUA/ARGENTINA','8b60fa2d910557baf1a167a542256aeba4dbe4f8097ea1624b821e63567aea58','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a12111c6895f2c55f449d62f350e701c90fc917859ebc0e257eaedd6f2add869',1978,'AR','Argentina','people-and-society',29,'Population: 26,224,000 (January 1978), average annual
growth rate 1.3% (current)
Nationality: noun—Argentine(s); adjective—Argentine
Ethnic divisions: approximately 85% white, 15% mestizo,
Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20%
practicing), 2% Protestant, 2% Jewish, 6% other
Language: Spanish
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Literacy: 85% (90% in Buenos Aires)
Labor force: 10 million; 19% agriculture, 25% manufac-
turing, 20% services, 11% commerce, 6% transport and
communications, 19% other; 4%-5% estimated unem-
ployment
Organized labor: 25% of labor force (est.)','eb14cf00e124e85ed6f808d689ad8f4f6f57ab5736c862361d9d7e371e672416','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('246f45a90e8e6fea7f09e06a2eb4d497470f9a720ca5c3ff9e5c37be5d60a5ed',1978,'NZ','New Zealand','people-and-society',33,'Population: 13,973,000 (January 1978), average annual
growth rate 1.6% (current)
Nationality: noun—Australian(s); adjective—Australian
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Ethnic divisions: 99% Caucasian, 1% Asian and aborigine
Religion: 98% Christian
Language: English
Literacy: 98.5%
Labor force: 6 million; 14% agriculture, 32% industry,
37% services, 15% commerce, 2% other; 5% unemployment
Organized labor: 44% of labor force
Population: 3,168,000 (January 1978), average annual
growth rate 0.6% (1-76 to 1-77)
Nationality: noun—New Zealander(s); adjective—New
Zealand
Ethnic divisions: 93% European, 7% Maori
Religion: 90% Christian, 9% none or unspecified, 1%
Hindu, Confucian, and other
Literacy: 98%
Labor force: 1,207,700; 13% agriculture, 33% manufac-
turing and construction, 9% transportation and communica-
tions, 24% commerce and finance, 21% administrative and
professional; unemployment 5.7% (1976)
Organized labor: 52% of labor force','684c7523fdcdaf743e92c979986e908463e8f6be8d7946df2aba32a01b392dbe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af5a4a27cd34aef7344381d4c8f2a3d6fb32cedf38c1e89be6e8d723b11d055f',1978,'AT','Austria','people-and-society',37,'Population: 7,522,000 (January 1978), average annual
growth rate 0.1% (6-76 to 6-77)
Nationality: noun—Austrian(s); adjective—Austrian
Ethnic divisions: 98.1% German, 0.7% Croatian, 0.3%
Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8% none or
other
Language: German
Literacy: 98%
Labor force: 2,784,685 (1977); 18% agriculture and
forestry, 49% industry and crafts, 18% trade and communi-
cations, 7% professions, 6% public service, 2% other; 2.4%
registered unemployed; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in
Austria number more than 200,000 (1972); unemployment
1.2% (September 1977)
Organized labor: about two-thirds of wage and salary
workers (1971)
Population: 221,000 (January 1978), average annual
growth rate 3.0% (7-73 to 7-76)
Nationality: noun—Bahamian (sing., pl.); adjective—
Bahamian
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: Baptists 29%, Church of England 23%, Roman
Catholic 23%, smaller groups of other Protestant, Greek
Orthodox, and Jews
Language: English
Labor force: 84,228 (1976), 25% organized; 21% unem-
ployment (1975)','2b52db7c2cd16a1f6464c98da31ee9df6a5503601fff1696275194fcb1b68a23','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a17f5af43ed2777853c9d409cabd826c6a28da62cb01415167c956d2cd700737',1978,'BH','Bahrain','people-and-society',41,'Population: 278,000 (January 1978), average annual
growth rate 3.8% (2-65 to 7-75)
Nationality: noun—Bahraini(s); adjective—Bahraini
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani, and
Indian, 3% other; native Bahrainis are a minority
Religion: Muslim
Language: Arabic, English also widely spoken
Literacy: about 40% (1970)
Labor force: 78,507 (1976)','62a11ad30e5b9403fd97daf5e34a8688cbffed505accbf02c9aa952cafd662b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a722f5ac7373a851d755387136d35ca8f21db610cd6e7a3584ddb08dcd910ce',1978,'BD','Bangladesh','people-and-society',45,'Population: 78,750,000 (January 1978), average annual
growth rate 2.8% (current)
Nationality: noun—Bangladeshi(s); adjective—Bangla-
desh
Ethnic divisions: predominantly Bengali; fewer than 1
million “Biharis” and fewer than 1 million tribals
Religion: about 83% Muslim, 16% Hindu; less than 1%
Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 26 million; extensive underemploy-
ment; over 80% of labor force is in agriculture','5f5ceb8ff2211f2fe4df3d4645cbc5f1387469cd06bfb1998131191af0b84676','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e16dd6a06498ea9d86722b6ae6c631fb32f6a1764472c96dc8bb7c72dcae703',1978,'BB','Barbados','people-and-society',49,'Population: 249,000 (January 1978), average annual
growth rate 0.7% (7-70 to 7-76)
Nationality: noun—Barbadian(s); adjective—Barbadian
Ethnic divisions: 80% African, 17% mixed, 4% European
Religion: Anglican (70%), Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1973 est.) wage and salary earners;
unemployment 20%-25% (1976)
Organized labor: 32%','499d168baea0f192c91b7c44407b84dbc01c3fe0d982b360af37cf19c896b544','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('544c259c084e32a313eb19346349e822e9aa13714a11fa6c5a3c884d33a258b8',1978,'BE','Belgium','people-and-society',53,'Population: 9,831,000 (January 1978), average annual
growth rate 0.1% (current)
Nationality: noun—Belgian(s); adjective—Belgian
Ethnic divisions: 55% Flemings, 33% Walloons, 12%
mixed or other
Religion: 97% Roman Catholic, 8% none or other
Language: French, Flemish (Dutch), German, in small
area of eastern Belgium; divided along ethnic lines
Literacy: 97%
Labor force: 4.0 million; approximately 95% is found in
the following sectors: 32% manufacturing, 24% services, 16%
commerce, banking, and insurance, 8% construction, 7.5%
transportation and communication, 4% agriculture, forestry,
and fishing, 1.2% mining, 0.8% public utilities and sanitary
services (1972); 9.7% of insured workers and 6.5% of the
total work force unemployed, September 1977
Organized labor: 48% of labor force (1969)
1 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','d4ec7bbf1d377eb25fbae25dc2349c42d522fed4bcc4f5fdef04d36e356529f0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2310d47b543190f1d922f87155f113a7d6121e14073665978043c48a74de28a',1978,'BZ','Belize','people-and-society',57,'Population: 149,000 (January 1978), average annual
growth rate 2.9% (current)
Nationality: noun—Belizean(s); adjective—Belizean
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerin-
dian, 8% other
Religion: 50% Roman Catholic; Anglican, Seventh-day
Adventist, Methodist, Baptist, Jehovah’s Witnesses, Men-
nonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,500; 39% agriculture, 14% manufactur-
ing, 8% commerce, 12% construction and transport, 20%
services, 7% other; shortage of skilled labor and all types of
technical personnel; over 15% are unemployed
Organized labor: 8% of labor force','1724955e3abe8363d38dcb562fd89ed720d7d7a99081344c72b3a0aead51ac8f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1aea21d3e1515dd0d10fc404f1f97dfad5a6861e9018ad447faa09332a04c8b',1978,'BJ','Benin','people-and-society',61,'Population: 3,330,000 (January 1978), average annual
growth rate 2.7% (7-70 to 7-76)
Nationality: noun—Beninese (sing. & pl.); adjective—
Beninese
Ethnic divisions: 99% Africans (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba), 5,500
Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most
common vernaculars in south, at least 6 major tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture;
15% civil service, artisans, and industry
Organized labor: approximately 75% of wage earners,
divided among two major and several minor unions
Population: 4,925,000 (January 1978), average annual
growth rate 2.8% (7-75 to 7-76)
Nationality: noun—Nigerien (sing. and pl.); adjective—','3d68bc7e29c30300b570b7ec4f368cadf17d5716b652dad66233f4811dc3b54e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ac638c90182185a5582f46d00d8d284721d00d0aacbc320b130a78afec3abff',1978,'BM','Bermuda','people-and-society',65,'Population: 58,000 (January 1978), average annual
growth rate 1.5% (7-70 to 7-75)
Nationality: noun—Bermudan(s); adjective—Bermudan
Ethnic divisions: approximately 63% African, 37% white
Religion: 47.5% Church of England, 38.2% other Protes-
tant, 10.2% Catholic, 4.1% other
Language: English
Literacy: virtually 100%
Labor force: 25,200 (1975)','ac47e3ef4188618a1543ec30e0cfa4afd29605cce0a5899b3716d4e4f283a396','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10dd992d1cc20b21d1779fa2104616be945c4ce548a523a92695f61d682be128',1978,'BT','Bhutan','people-and-society',69,'Population: 1,247,000 (January 1978), average annual
growth rate 2.5% (current)
Nationality: noun—Bhutanese (sing., pl.); adjective—
Bhutanese
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese, 15%
indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25%
influenced Hinduism
Buddhist-
Language: Bhotias speak various Tibetan dialects, most
widely spoken dialect is Dzongkha, the official sBREUAECS
Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry;
massive lack of skilled labor
Population: 4,845,000 (January 1978), average annual
growth rate 2.7% (current)
Nationality: noun—Bolivian(s); adjective—Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic; active Protes-
tant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.5 million (1972); 69.1% agriculture, 3.3%
mining, 9.6% services and utilities, 8% manufacturing, 10%
other
Organized labor: 150,000-200,000, concentrated in min-
ing, industry, construction, and transportation','9bdbad1acf64b2558a52f0c531060b2667afd32560f16d5245afb464a34435a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d4b37fb72a59c4bf53c82ce3cbed1025f9d7bedd4e46f6cc9dde3cafd1fbf49',1978,'BW','Botswana','people-and-society',73,'Population: 740,000 (January 1978), average annual
growth rate 2.6% (current)
Nationality: noun—Botswana (sing.), Batswana (pl.);
adjective—Botswana
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% Euro-
pean
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 32% in Tswana; less
than 1% secondary school graduates
Labor force: 385,000; most are engaged in cattle raising
and subsistence agriculture; about 51,000 in internal cash
economy, another 60,000 spend at least 6 to 9 months per
year as wage earners in South Africa (1971)
Organized labor: eight trade unions organized with a
total membership of approximately 9,000 (1972 est.)','71c8e50d429838b8486e9565510ec36df964ca2d9a4b774a0b2f0e681957ab31','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2478042f9eda732ff95db99542850c71405528a5102d25e28c38cd25cb1e7028',1978,'BR','Brazil','people-and-society',77,'Population: 113,859,000 (January 1978), average annual
growth rate 2.8% (current)
Nationality: noun—Brazilian(s); adjective—Brazilian
Ethnic divisions: 60% white, 30% mixed, 8% Negro, and
2% Indian (1960 est.)
Religion: 98% Roman Catholic (nominal)
Language: Portuguese
Literacy: 67% of the population 15 years or older (1970)
Labor force: about 30 million in 1970 (est.); 44.2%
agriculture, livestock, forestry, and fishing, 17.8% industry,
24 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
15.3% services, transportation, and communication, 8.9%
commerce, 4.8% social activities, 3.9% public administration,
5.1% other
Organized labor: about 50% of labor force; only about 1.5
million pay dues
Population: 210,000 (January 1978), average annual
growth rate 3.4% (2-70 to 2-76)
Nationality: noun—British Solomon Islander(s); adjec-
tive—British Solomon Islander
Ethnie divisions: 93.0% Melanesians, 4.0% Polynesians,
1.5% Micronesians, 0.3% Chinese, 0.8% Europeans, 0.4%
others
Religion: almost all at least nominally Christian; Roman
Catholic, Anglican, and Methodist churches dominant
Literacy: 60%
Population: 804,000 (January 1978), average annual
growth rate 1.8% (4-70 to 7-76)
Nationality: noun—Guyanese (sing., pl.); adjective—
Guyanese
Ethnic divisions: 51% East Indians, 48% Negro and
Negro mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1%
other
Language: English
Literacy: 86%
Labor force: 201,000; about 25% agriculture, 14%
manufacturing, 16% services, 11% commerce, 3% mining
and quarrying, 10% other; 21% unemployed
Organized labor: 34% of labor force','f1c6f93a0dd3f5e2ac92263eb9b4b2f52cdbe6c6e2b1dc5191e71f49f5ecf2d8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f749950d7a7b1f313b86ede09b296f54b33147077622e53cbf6b1ce6bc06fdb5',1978,'ID','Indonesia','people-and-society',81,'Population: 177,000 official estimate for 1 July 1976
Nationality: noun—Bruneian(s); adjective—Bruneian
“Ethnic divisions: 52% Malays, 28% Chinese, 15%
indigenous tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8%
Christian; 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
Literacy: 45%
Labor force: 32,155; 30.5% agriculture; 32.8% industry,
manufacturing, and construction, 33.8% trade, transport,
services; 2.9% other
Organized labor: 8.4% of labor force
Population: 139,075,000, including East Timor and West
Irian (January 1978), average annual growth rate 2.4%
(current)
Nationality: noun—Indonesian(s); adjective—Indonesian
Ethnic divisions: 45% Javanese, 14% Sundanese, 7.5%
Madurese, 7.5% coastal Malays, 26% other
Religion: 85% Muslim, 9% Christian, 2% Buddhist, 2%
Hindu, 2% other
Language: Indonesian (modified form of Malay) official;
English, and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 44 million; 70% agriculture, 15% industry,
15% miscellaneous and unemployed
Organized labor: 10% of labor force
Population: 34,769,000 (January 1978), average annual
growth rate 3.0% (current)
Nationality: noun—Iranian(s); adjective—Iranian
Ethnic divisions: 63% ethnic Persians, 3% Kurds, 13%
other Iranian, 18% Turkic, 3% Arab and other Semitic, 1%
other
Religion: 93% Shia Muslim; 5% Sunni Muslim; 2%
Zoroastrians, Jews, Christians and Baha''is
Language: Farsi (Persian), Turkish dialects, Kurdish,
Arabic
Literacy: about 37% of those 7 years of age and older
(1976 est.)
Labor force: 10.1 million est. 1976; 36% agriculture, 21%
manufacturing; shortage of skilled labor substantial
ae Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
IRAN','9b37abeb8638fc7e6953efa22448cec9fd5becd1c67e0589d31d08941a2598c6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('351f2920c6c168f95768d1bc82b73f27efc3d77bb0cc707419d43e1efabc95ad',1978,'BG','Bulgaria','people-and-society',85,'Population: 8,848,000 (January 1978), average annual
growth rate 0.7% (current)
Nationality: noun—Bulgarian(s); adjective—Bulgarian
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsies, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians,
0.6% other
Religion: regime promotes atheism; religious background
of population is 85% Bulgarian Orthodox, 13% Muslim, 0.8%
Jewish, 0.7% Roman Catholic, 0.5% Protestant, Gregorian-
Armenian and other
Language: Bulgarian; secondary languages closely corre-
spond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 5.0 million (1974); 32% agriculture, 33%
industry, 35% other
Population: 31,859,000 (January 1978), average annual
growth rate 2.2% (7-75 to 7-76)
Nationality: noun—Burman(s); adjective—Burmese
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2%
Kachin, 2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their
own languages
Literacy: 70% (official claim)
Labor force: 12.2 million (1976); 67% agriculture, 13%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old labor organiza-
tions have been disbanded, and government is forming one
central labor organization','a68efd855fe519ce0aa9ff73e61c5b3ad113ec6d52231ffbf6e1254414c93092','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caf173a10859994ccc8f8577eb4b3809038ccb620b85c629b409a14aa4645fbf',1978,'BI','Burundi','people-and-society',89,'Population: 3,988,000 (January 1978), average annual
growth rate 2.4% (7-70 to 7-75)
Nationality: noun—Burundian(s); adjective—Burundian
Ethnic divisions: Africans—85% Hutu (Bantu), 14% Tutsi
(Hamitic), 1% Twa (Pigmy); other Africans include perhaps
50,000 Zairians and 40,000 Rwandans; non-Africans include
about 3,000 Europeans and 1,000 South Asians
Religion: about 60% Christian (53% Catholic, 7%
Protestant); rest mostly animist plus perhaps 2% Muslims
Language: Kirundi and French official plus Swahili
(along Lake Tanganyika and in the Bujumbura area)
Literacy: about 15% in Kirundi, 3% in French, no
serviceable estimate for Kiswahili
Labor force: about 2 million (1976 est.)
Organized labor: sole group is the Union of Burundi
Workers (UTB); by charter, membership is extended to all
Burundi workers (informally); figures denoting ‘active
membership” have been unobtainable','4c944126fa832eda77a5f95a78c651fcb4de46e6644cecfd98d83df4dfe53962','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f84621fa85e9b88570614fce953126f7935c9fc7d2bf89039bc84f205cf6919',1978,'KH','Cambodia','people-and-society',93,'Population: 8,060,000 (January 1978), average annual
growth rate 2.2% (7-68 to 7-69)
Nationality: noun—Cambodian(s) or Khmer (sing., pl.);
adjective—Cambodian or Khmer
Ethnic divisions: 90% Khmer (Cambodian), 5% Chinese,
5% other minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian
Literacy: 55% (est.)','dd9dfa691aea2fbb1d780b103ac9b5f3928bc5d180dc96012a791d3e2152b97f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c2ccc1e8cf1f8d97b70051736e02d3a36a609e900a2756b9c73598fa56bf33d',1978,'CM','Cameroon','people-and-society',97,'Population: 6,722,000 (January 1978), average annual
growth rate 2.1% (current)
Nationality: noun—Cameroonian(s); adjective—Came-
roonian
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial
Bantu, 8% Northwestern Bantu, 10% Fulani, 7% Eastern
Nigritic, 11% Kirdi, 18% other African, less than 1%
non-African
Religion: about one-half animist, one-third Christian; rest
Muslim
Language: English and French official, 24 major African
language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence
agriculture and herding; 200,000 wage earners (maximum)
including 22,000 government employees, 63,000 paid
agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force','a9e6f8ab29e0b52dd5735130d884478b3a341dd666f82a6e386781edac5458e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18341a8939d257a088f9834b0374c7b64b518f4422f9f19997c0178b8ffec589',1978,'CA','Canada','people-and-society',101,'Population: 23,623,000 (January 1978), average annual
growth rate 1.4% (current)
Nationality: noun—Canadian(s); adjective—Canadian
Ethnic divisions: 44% British Isles origin, 30% French
origin, 26% other
Religion: 48% Protestant, 47% Catholic, 5% other
Language: English and French official
Labor force: 10.3 million; 29% service, 22% manufactur-
ing, 16% trade, 8% transportation and utilities, 6% agricul-
ture, 6% construction, 8% other; 7.2% unemployed
Organized labor: 30% of labor force','b20ce8d759fff33f54bc68f9ee312a6387ead5b6e3b5d1fa3dddc4631425735a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('685bb4f9488bdb0cb6532b5114f737d04a2df01f9fb7d85d3fe3a20948ecdf89',1978,'GN','Guinea','people-and-society',105,'Population: 312,000 (January 1978), average annual
growth rate 1.9% (12-70 to 7-76)
Nationality: adjective—Cape Verdian
Ethnic divisions: about 28% African; 70% mulatto; 2%
European
Religion: Catholicism, fused with local superstitions
Language: Portuguese and crioula, a blend of Portuguese
and West African words
Literacy: 14%
Labor force: bulk of population engaged in subsistence
agriculture
Population: 1,891,000 (January 1978), average annual
growth rate 2.3% current
Nationality: noun—Central African(s); adjective—Cen-
tral African
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and_ linguistic
characteristics, Banda (82%) and Baya-Mandjia (29%) are
largest single groups; 6,500 Europeans, of whom 6,000 are
French and majority of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 27% animist, 5%
Muslim; animistic beliefs and practices strongly influence
the Christian majority
Language: French official; Sangho, lingua franca and
national language
Literacy: estimated at 5%-10%
Labor force: about half the population economically
active, 80% of whom are in agriculture; approximately
64,000 salaried workers
Organized labor: 1% of labor force
Population: 333,000, (January 1978), this estimate does
not take into account emigration from Equatorial Guinea
during the last several years, average annual growth rate
1.8% (7-68 to 7-69); Rio Muni, 234,000, average annual
growth rate 1.5% (7-68 to 7-69); Fernando Po, 99,000,
average annual growth rate 2.6% (7-68 to 7-69)
Nationality: noun—Equatorial Guinean(s); adjective—
Equatorial Guinean
Ethnic divisions: indigenous population of Province
Francisco Macias Nguema primarily Bubi, some Fernan-
dinos; of Rio Muni primarily Fang; less than 1,000
Europeans, primarily Spanish
Religion: natives all nominally Christian and predomi-
nantly Roman Catholic; some pagan practices retained
Language: Spanish official language of government and
business; also pidgin English, Fang
Literacy: 12% (est.)
Labor force: most Equatorial Guineans involved in
subsistence agriculture
61
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
EQUATORIAL GUINEA/ETHIOPIA
Population: 10,790,000 (January 1978), average annual
growth rate 3.1% (7-71 to 7-76)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Nationality: noun—Ghanaian(s); adjective—Ghanaian
Ethnic divisions: 99.8% Negroid African (major tribes
Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12% Muslim
Language: English official; African languages include
Akan 44%, Mole-Dagbani 16%, Ewe 13%, and Ga-Adangbe
8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and fishing,
16.8% industry, 15.2% sales and clerical, 4.1% services,
transportation, and communications, 2.9% professional;
400,000 unemployed
Organized labor: 350,000 or approximately 10% of labor
force
Population: 5,822,000 (January 1978), average annual
growth rate 2.6% (current)
Nationality: noun—Guinean(s); adjective—Guinean
Ethnic divisions: 99% African (3 major tribes—Fulani,
Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less than
1%
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written
language
Labor force: 1.8 million, of whom less than 10% are wage
earners; most of population engages in subsistence agricul-
ture
Organized labor: virtually 100% of wage labor force
loosely affiliated with the National Confederation of
Guinean Workers, which is closely tied to the PDC
Population: 7,278,000, resident African population only,
(January 1978), average annual growth rate 3.3% (current)
Nationality: noun—Ivorian(s); adjective—Ivorian
Ethnic divisions: 7 major indigenous ethnic groups; no
single tribe more than 20% of population; most important
are Agni, Baoule, Krou, Senoufou, Mandingo; approximately
2 million foreign Africans, mostly Upper Voltans; about 75-
90 non-Africans (50-60 French) and 25,000-30,000
Lebanese)
Religion: 66% animist, 22% Muslim, 12% Christian
Language: French official, over 60 native dialects. Dioula
most widely spoken
Literacy: about 65% at primary school level
Labor force: over 85% of population engaged in
agriculture, forestry, livestock raising; about 11% of labor
force are wage earners, nearly half in agriculture, remainder
in government, industry, commerce, and_ professions
Organized labor: 20% of wage labor force','407626ec1c304c5297aa2bccc12df4ea739465e540e58c29c800695b6dc9bdaf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4fa94ddc1ca154a3e7caf546c5e80545ddddad560dc8677834396dde3503a3c',1978,'TD','Chad','people-and-society',109,'Population: 4,245,000 (January 1978), average annual
growth rate 2.1% (7-72 to 7-76)
Nationality: noun—Chadian(s); adjective—Chadian
Ethnic divisions: over 240 tribes representing 12 major
ethnic groups—Muslims (Arabs, Toubou, Fulani, Kotoko,
Hausa, Kanembou, Baguirmi, Boulala, and Wadai) in the
north and center and non-Muslims (Sara, Mayo-Kebbi, and
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Chari) in the south; some 150,000 nonindigenous, 5,000 of
them French
Religion: about half Muslim, 5% Christian, remainder
animist
Language: French official; Chadian Arabic is lingua
franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically
active group, of which 90% are engaged in unpaid
subsistence farming, herding, and fishing; 47,000 wage
earners in industry and civil service
Organized labor: about 20% of wage labor force
Population: 10,742,000 (January 1978), average annual
growth rate 1.9% (current)
Nationality: noun—Chilean(s); adjective—Chilean
Ethnic divisions: 95% European stock and mixed
European with some Indian admixture, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 89%
Labor force: 3.5 million economically active (1976).
19.8% agricultural, 26.1% industry and construction, 28.7%
services, 13.2% commerce, 2.8% mining, 6.3% transporta-
tion, 9.4% other (1976)
Organized labor: 25% of labor force (1973)','4f20e4dc8fc7b28fdb08162c86a3414ba7fea1b3f2d7ab17702daa8b58026a04','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('835372cb592db887cad8783ad6ee4d95da18d1402a414f10c722e560e947b96b',1978,'CN','China','people-and-society',116,'Population: 973,334,000 (January 1978), average annual
growth rate 1.4% (current)
Nationality:
Chinese
noun—Chinese (sing., pl.); adjective—
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur,
Hui, Yi, Tibetan, Miao, Manchu, Mongol, Pu-I, Korean, and
numerous lesser nationalities
Religion: most people, even before 1949, have been
pragmatic and eclectic, not seriously religious; most impor-
tant elements of religion are Confucianism, Taoism,
Buddhism, ancestor worship; about 2%-3% Muslim, 1%
Christian
Language: Chinese (Mandarin mainly; also Cantonese,
Wu, Fukienese, Amoy, Hsiang, Kan, Hakka dialects), and
minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85% agriculture,
15% other; shortage of skilled labor (managerial, technical,
mechanics, etc.); surplus of unskilled labor
Population: 36,921,000 (January 1978), average annual
growth rate 2.0% (current)
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: homogeneous; small Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition; pervasive folk
religion (Shamanism); vigorous Christian minority (16.6
Christian population); Buddhism (including estimated
20,000 members of Soka Gakkai); Chondokyo (religion of
the heavenly way), eclectic religion with nationalist over-
tones founded in 19th century, claims about 1.5 million
adherents
Language: Korean
Literacy: about 90%
Labor force: about 10.5 million (1972); 48% agriculture,
fishing, forestry; 15% services; 18% mining and manufactur-
ing; 12% commerce; 12% other
Organized labor: about 10% of nonagricultural labor
force
Population: 45,690,000 (January 1978), average annual
growth rate 2.9% (current)
Nationality: noun—Filipino(s); adjective—Philippine
Ethnic divisions: 91.5% Christian Malay, 4% Muslim
Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4%
Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national
language of the Philippine Republic; English is the language
of school instruction and government business
Literacy: about 83%
Labor force: 11 million; 60% agriculture, forestry, fishing,
12% manufacturing, 10.5% commerce, 10.5% government
and services (business, recreation, domestic, personal), 3.5%
transport, storage, communication, 3% construction; 0.5%
other','a4f593c3a08501e9d33d58b2867ce86ea3172e2003f9b23b0cfb021e6568ce0d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('978b66bd566c6eac66c111c934739e94dd10664541468be00c0eac8cb782784f',1978,'PH','Philippines','people-and-society',120,'Population: 16,835,000, excluding the population of
Quemoy and Matsu Islands and foreigners (January 1978),
average annual growth rate 2.0% (1-74 to 1-77)
Nationality: noun—Chinese (sing., pl.); adjective—
Chinese
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese,
2% aborigines
Religion: 93% mixture of Buddhism, Confucianism, and
Taoism; 4.5% Christian; 2.5% other
Language: Chinese Mandarin (official language), also
Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 5.7 million; 30% primary industry (agricul-
ture), 36% secondary industry (including manufacturing,
mining, construction), 33% tertiary industry (including
commerce and services) 1975; 1.5% unemployment (1976)
Organized labor: about 12% of 1972 labor
(government controlled)
force
Population: 4,563,000 (January 1978), average annual
growth rate 1.9% (1-71 to 1-77)
Nationality: adjective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local
religions
Language: Chinese, English
Literacy: 75%
Labor force (1971 est.): 1.58 million; 43% manufacturing,
20% services, 11% construction, mining, quarrying and
utilities, 13% commerce, 4% agriculture, forestry, fisheries,
and hunting, 7% communications, 2% other; underemploy-
ment is a serious problem
Organized labor: 12% of 1969 labor force
{See reference mag Vi}
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about
one-half are Chinese
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% among Portuguese and Macanese:
no data on Chinese population
Labor force: 5% agriculture, 30% manufacturing, 3%
construction, 1% utilities, 27% commerce, 8% transportation
and communications, 26% services (1960 data)','fa4c4d39b4c469bb247cb88f78687d1b150d6ebde458270755d4322ddafbe7bc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55719428baceab7cdf473b1a6b13cce2151247acd6ca9235e7313c12c5e1eb47',1978,'CO','Colombia','people-and-society',124,'Population: 25,473,000 (January 1978), average annual
growth rate 3.0% (7-72 to 7-76)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Nationality: noun—Colombian(s); adjective—Colombian
Ethnic divisions: 58% mestizo, 20% caucasian, 14%
mulatto, 4% Negro, 3% mixed Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture, 13%
manufacturing, 18% services, 9% commerce, 13% other
(1964); 10%-13% unemployment (1975)
Organized labor: 13% of labor force (1968)','47d903ee3e9a1f38fd616740a0e57e53354038faa76a12a770ab3d610d334f80','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08fe80eb726cd573ee123ce427548784d6d9ec244e3873ce8d5355d460cb7bbf',1978,'KM','Comoros','people-and-society',128,'Population: 326,000 (January 1978), average annual
growth rate 2.5% (current)
Nationality: noun—Comoran(s); adjective—Comoran
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor force: mainly agricultural
Antananarivo
*
MADAGASCAR =
Indian Ocean
{See reference map Vf}
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting of
Merina (1,643,000) and related Betsileo (760,000), on the one
hand, and coastal tribes with mixed Negroid, Malayo-Indo-
nesian, and Arab ancestry on the other; coastal tribes include
Betsimisaraka 941,000, Tsimihety 442,000, Sakalava
375,000, Antaisaka 415,000; there are also 10-12,000
European French, 5,000 Indians of French nationality, and
5,000 Creoles
Religion: more than half animist; about 41% Christian,
7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are
nonsalaried family workers engaged in subsistence agricul-
ture; of 175,000 wage and salary earners, 26% agriculture,
17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscel-
laneous
Organized labor: 4% of labor force
Population: 61,000, average annual growth rate 2.1%
(7-70 to 7-76)
Nationality: noun—Seychellois (sing. & pl.); adjective—','a80438eb4f8de158341f78b3a02b66b53dc59ce466be3d9d05d85003527439f7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0041fbeca257f5766ca23cbcfe3d331c08e397762645c88a45646fa52a8e0d0',1978,'CG','Congo','people-and-society',132,'Population: 1,450,000 (January 1978), average annual
growth rate 2.8% (2-74 to 7-76)
Nationality: noun—Congolese (sing., pl.); adjective—
Congolese or Congo
Ethnic divisions: about 15 ethnic groups divided into
some 75 tribes, almost all Bantu; most important ethnic
groups are Kongo (48%) in south, Teke (17%) in center,
M’Bochi (12%) and Sangha (20%) in north; about 8,500
Europeans, mostly French
Religion: about half animist, half nominally Christian, less
than 1% Muslim
Language: French official, many African languages with
Lingala and Kikongo most widely used
Literacy: about 20%
Labor force: about 40% of population economically
active, most engaged in subsistence agriculture; 79,100 wage
earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965 est.)','a0b7be1fcfcf104639665fa280cdf1e00429565a14c4bc79681f49ed1cc8ebe8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a437dbcd148343ab0b03c0d21349ff09daa582d3d423cb87880ffe93f0a1c05',1978,'CK','Cook Islands','people-and-society',136,'Population: 18,000 (preliminary total from the census of 1
December 1976)
Nationality: noun—Cook Islander(s); adjective—Cook
Islander
Ethnic divisions: 81.3% Polynesian (full blood), 7.7%
Polynesian and European, 7.7% Polynesian and other, 2.4%
European, 0.9% other
Religion: Christian, majority of populace members of
Cook Islands Christian Church
7 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
COOK ISLANDS/COSTA RICA','e7ce10773dabd98ca072efacf3a3d42d830b54aceb53d6bf27cdc1bcdecd4968','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('057aaa2d33f2a3b296944796dae7f651a72e4f9a2b1d31ba73dfebb935f7886e',1978,'CR','Costa Rica','people-and-society',140,'Population: 2,079,000 (January 1978), average annual
growth rate 2.2% (7-75 to 7-76)
Nationality; noun—Costa Rican(s); adjective—Costa
Rican
Ethnic divisions: 98% white (including mestizo), 2%
Negro
Religion: 95% Roman Catholic
Language: 41% Spanish
Literacy: about 90%
Labor force: 657,709 (1976); 32.6% agriculture; 13.8%
manufacturing; 15.3% commerce; 6.1% construction; 5.2%
transportation, utilities; 20.3% service (government, educa-
tion, social); 0.5% other; 6.2% unemployment (1976)
Organized labor: about 11.5% of labor force','62b7c69b24fb27b2ef0cb3f0fe00e94bb4df849afc2f652172b2ec7d2d7871d3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7918fad8fd712a33bc6ce0da70c1b8d5a5508139d885033bd56e3f1952ef8d33',1978,'CU','Cuba','people-and-society',144,'Population: 9,720,000 (January 1978), average annual
growth rate 1.6% (current)
Nationality: noun—Cuban(s); adjective—Cuban
Ethnie divisions: 51% mulatto, 37% white, 11% Negro,
1% Chinese
48 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Atlanti¢
of Mexico Ocean
Ooty
* THE
Havan: \\ BAHAMAS
DS Po ~
CUBA :
HA
JAMAICA 3
Caribhean Sea
(See reference map Il)
Religion: at least 85% nominally Roman Catholic before
Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.36 million; 34% agriculture, 17% industry,
6% construction, 6% transportation, 29% services, 8%
unemployed and underemployed
Organized labor: 46% of total force','08497dfd8f57d440fe1d684d0bb56bf8b88622e85c701185320d0eb7988335d3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86cfaa66bca982054bb138bb032d8e4c80f11c4b7083084e214cf41c142dec43',1978,'CY','Cyprus','people-and-society',148,'Population: 640,000 (January 1978), average annual
growth rate 0.1% (2-76 to 7-77)
Nationality: noun—Cypriot(s); adjective—Cypriot
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Mason-
ite Armenian Apostolic and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Greek Sector labor force: 207,700 (1975), 22% agricul-
ture, forestry, fishing, 12% manufacturing, 4% construction,
1% mining and quarrying, 13% services, 10% trade and
finance, 3% transport and communications, 5% public
administration, 30% other; unemployment 7% (1976)
Turkish Sector labor force: 179,400 (145,900 employed,
33,500 unemployed); 31% agriculture, 18% services, 17%
manufacturing, 12% wholesale and retail trade, 22% other
(1975)
Population: 15,109,000 (January 1978), average annual
growth rate 0.8% (current)
Nationality: noun—Czechoslovak(s); adjective—Czecho-
slovak
Ethnic divisions: 64.3% Czechs, 30.0% Slovaks, 4.0%
Magyars, 0.6% Germans, 0.5% Poles, 0.4% Ukrainians, 0.2%
others (Jews, Gypsies)
51
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CZECHOSLOVAKIA
ey; ae
(See reference map !V)
Religion: 77% Roman Catholic, 20% Protestant, 2%
Orthodox, 1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.4 million; 14% agriculture, 38.6% industry,
11% services, 86.4% construction, communications and
others','0900fe5694f55dbb4c8c669ee08cdc9bfa6230a6854aa945b71ccdbb8104d8a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('251fb143483eb23f78a7cc6956d3471fb0c442d576de43aff064e86d340b15b6',1978,'DK','Denmark','people-and-society',152,'Population: 5,096,000 (January 1978), average annual
growth rate 0.3% (current)
Nationality: noun—Dane(s); adjective—Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 1% other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2.5 million; 9.5% agriculture, forestry,
fishing, 26.6% manufacturing, 8.3% construction, 15.7%
commerce, 6.8% transportation, 5.6% services, 25.7% gov-
ernment, 1.8% other; 7.6% of registered labor force
unemployed (January 1976)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Organized labor: 65% of labor force','cd26593d7754921e09c600e157c2d5beddfa83907a773d07012620f4a198b8b2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4ce32e10ddad12cfdcaabceabfd0d9ddcd42354ff79644c5f02fc87998fd47c',1978,'DJ','Djibouti','people-and-society',156,'Population: 180,000 (official estimate for 1972)
Nationality: noun—Afar(s), Issa(s); adjective—Afar, Issa
Ethnic divisions: (approximate figures) 96,300 Somalis,
mostly Issas (large number of the Somalis are temporary
immigrants from Somalia, not citizens of territory), 90,500
Afars, 6,000 Arabs, 7,000 French (inclusive of French
military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at
port
Organized labor: some 3,000 railway workers organized','5a7c687579b4d7e5e71bb715c3bdce126e66e784495878b56d7a3c8cd23579a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd4f9f257f5c39c735787c3e1a1609ca294d646d44470452f5edc894b06238ab',1978,'DM','Dominica','people-and-society',160,'Population; 80,000 (January 1978), average annual
growth rate 1.6% (4-60 to 4-70)
Nationality: noun—Dominican(s), adjective—Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture
Organized labor: 25% of the labor force','b2d179d68510670b26b54f8856015353d1ab9dab0c8689d5dad2540855a42093','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7727abd2e19fb3f64a813582ac7891ed9edc7e49fed5a8a11df9e2077eee9b8',1978,'JM','Jamaica','people-and-society',164,'Population: 5,051,000 (January 1978), average annual
growth rate 2.9% (current)
Nationality: noun—Dominican(s); adjective—Dominican
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 million; 73% agriculture, 8% industry,
19% services and other
Organized labor: 12% of labor force
Population: 2,130,000 (January 1978), average annual
growth rate 1.7% (1-70 to 1-76)
Nationality: noun—Jamaican(s); adjective—Jamaican
Ethnic divisions: African 76.3%, Afro-European 15.1%,
Chinese and Afro-Chinese 1.2%, East Indian and Afro-East
Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman Catho-
lic, some spiritualist cults
Language: English
Literacy: government claims 82%, but probably only
about one-half of that number are functionally literate
Labor force: 810,700 (1973); 26% in agriculture, forestry,
fishing and mining, 10% manufacturing, 8% public adminis-
tration, 5% construction, 10% commerce, 3% transportation
and utilities, 13% services; 25% unemployed; shortage of
technical and managerial personnel
Organized labor: about 25% of labor force (1966)','4dc3d89a24763cc8fb8436eee8a49ed07f495fb4bc5f41096c45d7cbf27959f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d336e5699a17e5c257a03ea1d7117e0309ad1fc8d272bc14c7fe7b323a14fde8',1978,'EC','Ecuador','people-and-society',168,'Population: 7,686,000, excluding nomadic Indian tribes,
(January 1978), average annual growth rate 3.4% (7-74 to 7-
76)
Nationality: noun—Ecuadorean(s); adjective—Ecuador-
ean
Ethnic divisions: 40% mestizo, 40% Indian, 10% white,
5% Negro, 5% Oriental and other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture, 13%
manufacturing, 4% construction, 7% commerce, 4% public
administration, 16% other services and activities
Organized labor: less than 15% of labor force
57
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ECUADOR/EGYPT','7915f171460a76c5f2c7fe5ffd57dd9bd92d2d75a4af5a9dc7a841b75fea74c1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('938f370fd3793a6632155d761b2452b475185bde931afff6e17efa99b9c20e15',1978,'EG','Egypt','people-and-society',172,'Population: 39,396,000 (January 1978), average annual
growth rate 2.3% (current)
Nationality: noun—Egyptian(s); adjective—Egyptian or
Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek,
Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt and
other
Language: Arabic official, English and French widely
understood by educated classes
Literacy: around 40%
Labor force: 8 to 12 million; 45% to 50% agriculture, 10%
industry, 10% trade and finance, 30% services and other;
shortage of skilled labor
Organized labor: 1 to 3 million','30a2df8d71080b1c51faa23e2aca07d48884cb9bfdee760addd1d092e609705f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24acd29683da15da9b9aacdf2b62b962a19a9d1a9868246ef96b02f34d576322',1978,'SV','El Salvador','people-and-society',176,'Population: 4,310,000 (January 1978), average annual
growth rate 3.0% (7-74 to 7-76)
is Approved For Release 2005/04/22
Nationality: noun—Salvadoran(s): adjective—Salvadoran
Ethnic divisions: 84%-88% mestizo; Indian and white
minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably
97%-98%
Language: Spanish
Literacy: 50% literacy in urban areas, 30% in rural areas
Labor force: 1,500,000 (est. 1977); 57% agriculture, 14%
services, 14% manufacturing, 6% commerce, 9% other;
shortage of skilled labor and large pool of unskilled labor,
but manpower training Programs improving situation
Organized labor: 5% of total labor force; 10% of
nonagricultural labor force (1977)','624930809dfc76cbac4c0c8661f300fbb0f1196ecd2b06eeab341226c16bcc2d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('271c5fe15b31a37ca5b863be73b89e61c148859b4ef12b35c2753b9122bec180',1978,'ET','Ethiopia','people-and-society',180,'Population: 29,789,000 (January 1978), average annual
growth rate 2.6% (7-75 to 7-76)
Nationality: noun—Ethiopian(s); adjective—Ethiopian
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%,
Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%, Gurage 2%,
other 1%
va Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Mus-
lims, 15%-20% animist, 5% other
Language: Amharic official; many local languages and
dialects; English major foreign language taught in schools
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10%
government, military, and quasi-government
Organized labor: All Ethiopian Trade Union formed
January 1977 to represent 273,000 registered trade union
members','10c6c970290b753b4312567bc5bcc9cbbc666a665b8b299d1ce9ddd88cec609e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1d3c58f09c875cd25e039efac501052327c0b8defb6615cf06d171ff4e39982',1978,'DE','Germany','people-and-society',185,'Population: 2,000 (official estimate for 1 July 1974)
Nationality: noun—Falkland Islander(s); adjective—Falk-
land Island
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in agriculture,
mostly sheepherding','c2a81fd8b721866fef069fcc028ff06f3480fcab6cf042c6e752614bbf033384','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18d1b93acc1e1a778c5e9b6b4d09ab3cda638d0c07e9f01c149f8f73714ef48d',1978,'FO','Faroe Islands','people-and-society',188,'Population: 42,000 (January 1978), average annual
growth rate 1.3% (1-71 to 1-76)
Nationality: noun—Faroese (sing., pl.); adjective—
Faroese
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufac-
turing, transportation, and commerce','0742750e9854cfc51acab11435b666b9d394cad44125eec5f22037671d6bf094','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('145c66bb9dbfccfcb6b9863f3e6748fda69c1e40434ceac0d4f7d96c32718ecc',1978,'FJ','Fiji','people-and-society',192,'Population: 597,000 (January 1978), average annual
growth rate 1.9% (7-75 to 7-76)
Nationality: noun—Fijian(s); adjective—Fijian
Ethnic divisions: 42% Fijian, 50% Indian, 8% European,
Chinese and others
Religion: Fijians mainly Christian, Indians are Hindu
with a Muslim minority
Language: English and Fijian (official), Hindustani
spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50%
breakdown on remainder
in agriculture, no
Organized labor: about.50% of labor force organized into
22 unions; unions organized along lines of work, breakdown
by ethnic origin causes further fragmentation','bb9ba42158e68f8eec9d91c9caf932b975dd185b21c898cdd61bf937d1a6d2df','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47e8095aaaaa35fa2c37211d65abd66fec6b97a20f6daf9808accca09746d690',1978,'FI','Finland','people-and-society',196,'Population: 4,746,000 (January 1978), average annual
growth rate 0.3% (1-76 to 1-77)
Nationality: noun—Finn(s); adjective—Finnish
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek Orthodox,
1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and
Russian-speaking minorities
Literacy: 99%
Labor force: 2.2 million; 16.6% agriculture, forestry, and
fishing, 26.4% mining and manufacturing, 8.4% construc-
tion, 15.4% commerce, 6.8% transportation and communica-
tions, 4.0% banking and finance, 20.1% services; 3.3%
unemployed
Organized labor: 60% of labor force
Population: 53,352,000 (January 1978), average annual
growth rate 0.6% (current)
(men); adjective—
Nationality: —noun—Frenchman
French
Ethnic divisions: 45% Celtic; remainder Latin, Germanic,
Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1%
Muslim (North African workers), 13% unaffiliated
Language: French (100% of population); rapidly declin-
ing regional patois—Provencal, Breton, Germanic, Corsican,
Catalan, Basque, Flemish
Literacy: 97%
Labor force: 22 million (est. in mid-1976): 47% services,
38% industry, 11% agriculture, 4% unemployed
Organized labor: approximately 17% of labor force, 23%
of salaried labor force
ee Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','26210c7b2c5ab3a8061b3e1cc8053a24c4a5a1932d17629dee3bd3a9ea202bac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5389a6296270a99ff345f7f327cb4ebbd723a085781a7ba2c3ce099cb1114d4',1978,'GF','French Guiana','people-and-society',203,'Population: 61,000 (January 1978), annual growth rate
3.1% (10-67 to 10-74)
Nationality: noun—French Guianese (sing., pl.); adjec-
tive—French Guiana
Ethnic divisions: 95% Negro or mulatto, 5% caucasian,
10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construc-
tion 21%, agriculture 18%, industry 8%, transportation 4%;
information on unemployment unavailable
Organized labor: 7% of labor force
Population: 142,000 (January 1978), annual growth rate
2.6% (2-71 to 1-76)
Nationality: noun—French Polynesian(s); adjective—
French Polynesian
{See reference map Vill)
Ethnic divisions: 78% Polynesian, 12% Chinese, 6% local
French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32% Catholic
Population: 566,000 (January 1978), average annual
growth rate 1.7% (7-66 to 7-70)
Nationality: §noun—Gabonese (sing., pl.); adjective—
Gabonese
Ethnic divisions: about 40 Bantu tribes, including 4 major
tribal groupings (Fang, Eshira, Mbede, Okande); about
100,000 expatriate Africans and Europeans, including
30,000 French
Religion: 55% to 75% Christian, less than 1% Muslim,
remainder animist
Language: French official language and medium of
instruction in schools; Fang is a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are wage
earners in the modern sector
Organized labor: less than 30% of wage labor force
Population: 559,000 (January 1978), average annual
growth rate 2.5% (7-70 to 7-76)
Nationality: noun—Gambian(s); adjective—Gambian
Ethnic divisions: over 99% Africans (Malinke 40.8%,
Fulani 13.5%, Wolof 12.9%, remainder made up of several
smaller groups), fewer than 1% Europeans and Lebanese
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
BISSAU-
Atlentic Ocean
(See reference map Vi}
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Malinke and Wolof most
widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in subsis-
tence farming; about 15,000 are wage earners (government,
trade, services)
Organized labor: 25% to 30% of wage labor force at most
Population: 16,736,000, including East Berlin (January
1978), average annual growth rate —0.2% (current)
Nationality: noun—German(s); adjective—German
Ethnic divisions: 99.7% German, .3% Slavic and other
Religion: 58% Protestant, 8% Roman Catholic, 39%
unaffiliated or other; less than 5% of Protestants and about
25% of Roman Catholics actively participate
Language: German, small Sorb (West Slavic) minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7% handi-
crafts; 6.8% construction; 11.9% agriculture; 6.8% transport
and communications; 10.1% commerce; 16:8% services; 2.5%
other
Organized labor: 87.7% of total labor force
Population: 61,520,000, including West Berlin (January
1978), average annual growth rate 0.1% (current)
Nationality: noun—German(s); adjective—German
75
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GERMANY, FEDERAL REPUBLIC OF
Ethnic divisions: 99% Germanic, 1% other
Religion: 48.9% Protestant, 44.7% Roman Catholic, 7.7%
other (as of 1975)
Language: German
Literacy: 99%
Labor force: 26.7 million; 42.9% in manufacturing and
construction, 18.0% services, 12% commerce, 9.9% govern-
ment, 6.3% agriculture, 5.9% communication and transpor-
tation, 1% mining; 4.2% average unemployed as of 1977,
excluding self employed
Organized labor: 32.6% of total labor force; 41.4% of
wage and salary earners','d24b085f69f04a58c98de799e532f40912704298f41d8b824eb56012879c7e0f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b25a0bb0edfb11cad7bd7f3eb7016dd3c6b719dd708bb98fe68f25b299c44764',1978,'GI','Gibraltar','people-and-society',207,'Population: 30,000 (official estimate for 1 July 1976)
Nationality: noun—Gibraltarian; adjective—Gibraltar
Ethnic divisions: mostly Italian, English, Maltese, Portu-
guese and Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages;
Italian, Portuguese, and Russian also spoken; English used in
the schools and for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian
laborers
Organized labor: over 6,000
Population: 52,000 (preliminary total from census of 8
December 1973)
Nationality: noun—Gilbertese or Gilbert Islander‘(s);
adjective—Gilbertese, or Gilbert Islander
Ethnic divisions: Micronesian
Religion: Catholic
Literacy: less than 50%','acc6abbe48e389cbb22d647a4a53170a3c712a759deda7ab6bed79fec8985cb5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('162a39e834eea99884743f9002ad0713557051052e1e28aec02b7f5145b19578',1978,'GR','Greece','people-and-society',211,'Population: 9,251,000 (January 1978), average annual
growth rate 0.6% (7-66 to 7-76)
Nationality: noun—Greek(s): adjective-—Greek
Ethnic divisions: 96% Greek, 2% Turkish, 2% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total
about 82%
Labor force: 3,400,000 (1975 est.); 40.5% agriculture,
25.6% industry, 33.7% services; unemployment 3%, but there
is substantial underemployment in agriculture
Organized labor: 20% of labor force est.','9ad4b52b515c3101437331c355d97c5fcd003fdb72f61363a45d1b0b2962026a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dde46022d949754728e3586fad1a4f784fb2815ce6214f7cc27aafa5f7a418a',1978,'GL','Greenland','people-and-society',215,'Population: 51,000 (January 1978),
growth rate 1.3% (1-71 to 1-76)
average annual
81
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GREENLAND/GRENADA
Nationality: noun—Greenlander(s); adjective—Green-
land
Ethnic divisions: 86% Greenlander (Eskimos and Green-
land-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000. largely engaged in fishing and sheep
breeding','c238fbe87de67b0b8c0dda4f7a0f1d7f468e40632b050620d10c03efd15e0212','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('279d24c5483184878b849842255e0121a459c08eb83c4a2aa612df05955c5e0d',1978,'GD','Grenada','people-and-society',219,'Population: 108,000 (January 1978), average annual
growth rate 1.0% (7-60 to 7-75)
Nationality: noun—Grenadian(s); adjective—Grenadian
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects:
Roman Catholic
Language: English; some French patois
re Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GRENADA/GUADELOUPE
Literacy: unknown
Labor 27,314 (1960); 40%
unemployed or underemployed
force: agriculture, 30%
Organized labor: 33% of labor force','681ae93b811d9b68554b5257a164a616ec75c92855e4e7f89ca9e70ce5f1d7cc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9558961147b7885684f2fb6ab0b694bea1d85ac75e4aa799c471411403bed4d6',1978,'GP','Guadeloupe','people-and-society',223,'Population: 330,000 (January 1978), average annual
growth rate 0.5% (10-67 to 10-74)
Nationality: noun—Guadeloupian(s); adjective—Guade-
loupe
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force
83
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GUADELOUPE/GUATEMALA','fda327f48db1ceb0865065d49c2b30991c1efa5b999ea0b4063c36e7405fb273','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d09b8defb9e2e4836a1e6f084b534e047434937b7960e6b229cf1c44cfc2e15',1978,'GT','Guatemala','people-and-society',227,'Population: 6,531,000 (January 1978), average annual
growth rate 2.9% (7-70 to 7-76)
Nationality: noun—Guatemalan(s); adjective—Guatema-
lan
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo
and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks
an Indian language as a primary tongue
Literacy: about 30%
84 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Labor force (1974): 1.8 million; 52.5% agriculture, 10.1%
manufacturing, 21.7% services, 7.9% commerce, 3.9%
construction, 2.1% transport, 0.7% mining, 1.2% electrical,
0.8% other. Unemployment estimates vary from 3% to 25%
Organized labor: 6.4% of labor force (1975)','6f0ac1c6b8b8e19944e22205147523a2fa25dcb5b6321778e1c95d3a44dac64d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0e5d93b993a08d76574e24b7d93a44488c9eaf2bb56427db1e87df68e87626d',1978,'GW','Guinea-Bissau','people-and-society',231,'Population: 527,000 (January 1978), average annual
growth rate 1.8% (current)
Nationality: noun—Guinean(s); adjective—Guinean
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes);
less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese and numerous African languages
Literacy: 3% to 5%
Approved For Release 2005/04/22
: CIA-RDP79-01051A000900010004-4
Labor force: bulk of population engaged in subsistence
agriculture','fc5065294c4350f76a6a800a9d27b14ecf7e0332fff71e2142e581bfb936b79a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea51dc6450a1093fd13cc4d09645e17d68294127c60f584c36a2f69dab923073',1978,'HT','Haiti','people-and-society',235,'Population: 4,777,000 (January 1978), average annual
growth rate 1.8% (current)
Nationality: noun—Haitian(s); adjective—Haitian
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Atlantic Ocean
(See reference map It}
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of
which an overwhelming majority also practice Voodoo)
Language: French (official) spoken by only 10% of
population; all speak Creole
Literacy: 10% to 12%
Labor force: 2.6 million (est. January 1968); 86%
agriculture, 12% industry, 2% unemployed; shortage of
skilled labor; unskilled labor abundant
Organized labor: less than 1% of labor force','dc1c8165a8cccc6669592ef493eb633f70bca857e94aca5326d0b5adf468d8c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51ed95d4c083a1ae0744e4ef8402fabd3b95c1f7fd9abbc7bcbc311d4f9bfeb5',1978,'HN','Honduras','people-and-society',239,'Population: 2,954,000 (January 1978), average annual
growth rate 2.9% (7-75 to 7-76)
Nationality: noun—Honduran(s); adjective—Honduran
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 47% of persons 10 years of age and over (est.
1970)
Labor force: approx. 900,000 (est. mid-1972); 66%
agriculture, 12% services, 8% manufacturing, 5% commerce,
6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-1972)
90 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
HONDURAS/HONG KONG','5da9c7b51b69381a5d16b402d11ae59c63668a06ab3e9f19bb539e1b79e6007b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a967135bcb730544467b137879156b3d29a33f01c66d4a2a316eda3f33f579d',1978,'HU','Hungary','people-and-society',245,'Population: 10,695,000 (January 1978), average annual
growth rate 0.5% (current)
Nationality: noun—Hungarian(s), adjective—Hungarian
Ethnic divisions: 92.4% Magyar, 2.5% German, 3.3%
Gypsy, 0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0% Calvinist, 5.0%
Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97% .
Labor force: 5,085,500 (1 January 1976); 23% agriculture,
44% industry and building, 16% trade and transport, 17%
other nonagricultural','30c4a49c2473d0a978f7400956c2c9c05478a7421f39dc8fee27c4a05266cd05','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82b3809133d451ef1961780f473b09fd353d972e62af2ec616f0d100bacface4',1978,'IS','Iceland','people-and-society',249,'Population: 223,000 (January 1978), average annual
growth rate 0.8% (1-76 to 1-77)
Nationality: noun—Icelander(s); adjective—Icelandic
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 85,000; 22.6% agriculture and fishing; 25.6%
mining and manufacturing; 10.7% construction; 12.8%
commerce; 7.8% transportation and communications; 15.2%
services; and 5.7% other; unemployment 0.6%
Organized labor: 60% of labor force','9baea812a3cad4713fe4c43a7746ce03adc7d92ed0902506758bb3823cbecfe6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1baff5410fe322586a734e2ae533c4c31de100cb9cb1302ad7e1ae6b62c5a68e',1978,'IN','India','people-and-society',252,'Population: 649,354,000, including Sikkim and the
Indian-held part of disputed Jammu-Kashmir (January
1978), average annual growth rate 2.2% (current)
Nationality: noun—Indian(s); adjective—Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3%
Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6%
Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or more
persons each; numerous other languages and dialects, for the
most part mutually unintelligible; Hindi is the national
language and primary tongue of 30% of the people; English
enjoys “associate” status but is the most important language
for national, political, and commercial communication;
Hindustani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29% (1971
census)
Labor force: about 197 million; 70% agriculture, more
than 10% unemployed and underemployed; shortage of
skilled labor is significant and unemployment is rising
Organized labor: about 2.5% of total labor force','59116baf4c489c71ee560ba1a67da3e8f30630ea5f05a586cba3530f9bb6c8a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('103bdef4b02862bbe248223c9d9c151c3de98d07fe1d24fb1d123c0be77ff08c',1978,'IQ','Iraq','people-and-society',257,'Population: 11,977,000 (January 1978), average annual
growth rate 3.4% (10-70 to 10-76)
Nationality: noun—Iraqi(s); adjective—Iraqi
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7%
Assyrians, 2.4% Turkomans, 7.7% other
Religion: 90% Muslim (50% Shiah Muslim, 40% Sunni
Muslim), 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5% industry,
6.7% government, 16.8% other; rural underemployment
high, but not serious because low subsistence levels make it
easy to care for unemployed; severe shortage of technically
trained personnel
Organized labor: 11% of labor force','7e405e2688e57620ffacd9f101fb2c80fb804b1e696689cabf2d8d8c08c51559','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b084253b22f5e17e25d593064960a39e0481025cb9d667cdcf055874cdf82b4c',1978,'IE','Ireland','people-and-society',261,'Population: 3,199,000 (January 1978), average annual
growth rate 0.8% (7-61 to 7-76)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Nationality: noun—Irishman(men), Irish (collective pl.);
adjective—Irish
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2% other
Language: English and Gaelic official; English is gen-
erally spoken
Literacy: 98%-99%
Labor force: about 1,134,000 (1971); 26% agriculture,
forestry, fishing, 19% manufacturing; 15% commerce; 7%
construction; 5% transportation; 4% government; 24% other;
9.8% unemployment (February 1976)
Organized labor: 36% of labor force','4e053d1fd017de125c0022de89c1e48d7959ea931c80708978b6ce1ce184e906','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('455b7402f42d3dff1b15e46b2acd9058b192422171aad28676d30e322d89642f',1978,'IL','Israel','people-and-society',265,'Population: 3,631,000, excluding East Jerusalem and the
other occupied territories (January 1978), average annual
growth rate 2.5% (1-76 to 1-77)
Nationality: noun—Israeli(s); adjective—Israel
Ethnic divisions: 85% Jews, 15% non-Jews (mostly Arabs)
Religion: 85% Judaism, 11% Islam, 4% Christian and
other ;
Language: Hebrew official: Arabic used officially for
Arab minority; English most commonly used foreign
language
Literacy: 88% Jews, 48% Arabs
Labor force: 1,133,000; 6.5% agriculture, forestry and
fishing; 25.3% manufacturing (mining, industry); 0.9%
electricity and water; 8.1% construction and public works;
12.2% commerce; 7.7% transport, storage, and communica-
tions; 6.5% finance and business; 26.1% public services; 6.7%
personal and other services (1974)
oe Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Organized labor: 90% of labor force
Population: 56,722,000 (January 1978), average annual
growth rate 0.7% (1-67 to 1-77)
Nationality; noun—lItalian(s); adjective—Italian
Ethnic divisions: primarily Italian but population in-
cludes small clusters of German-, French-, and Slovene-Ital-
ians in the north and of Albanian-Italians in the south
Religion: almost 100% nominally Roman Catholic (de
facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region
(e.g., Bolzano) are predominantly German speaking; signifi-
cant French-speaking minority in Valle d’Aosta Region;
Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5%-7% of population illiterate (1972), illiteracy
varies widely by region
Labor force: 19,549,000 (January 1975); 15.0% agricul-
ture, 42.9% industry, 39.0% other; 7.8% unemployment
(1977); 1.5 million Italians employed in other Western
European countries
Organized labor: 20% (est.) of labor force','6a63bcb603423f2113fd5507e8ca6dff2461584e71be7db4c4d2b63c1e322145','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fe872e0ebe221aa09b8b75ad8863a570f61e9e7941a34d8676ca1a3a84d6d7c',1978,'JP','Japan','people-and-society',269,'Population: 114,595,000, including Ryukyus (January
1978), average annual growth rate 1.1% (current)
Nationality: noun—Japanese (sing., pl.); adjective—
Japanese
Ethnic divisions: 99.2% Japanese, 0.8% other (mostly
Korean)
Pacific
Ocean
Philippine
Sea
{See reference mag Vil)
Religion: most Japanese observe both Shinto and Buddhist
rites; about 16% belong to other faiths, including 0.8%
Christian
Language: Japanese
Literacy: 97.8% of those 15 years old and above (1960
data}
Labor force (1976 figures): 52.8 million: 11% agriculture,
forestry, and fishing; 34% manufacturing, mining, and
construction; 48% trade and services; 5% government; 2.0%
unemployed
Organized labor: 33.7% of labor force
Population: 16,259,000 (January 1978), average annual
zrowth rate 2.8% (7-72 to 7-76)
Nationality: noun——Tanzanian(s); adjective—Tanzanian
Ethnic divisions: 99% native Africans consisting of well
over 100 tribes; 1% Asian, European, and Arab
Religion: Tanganyika—40% Animist, 30% Christian, 30%
Muslim; Zanzibar—almost all Muslim
Language: Swahili and English official, English primary
language of commerce, administration and higher educa-
tion; Swahili widely understood and generally used for
communication between ethnic groups; first language of
most people is one of the local languages
Literacy: 15%-20%
Labor force: under 400,000 in paid employment, over
90% in agriculture
Organized labor: 15% of labor force','58b74867b0b2b427ce80ee9c4141157aac9b7d8c9e050c69451d8a99a10448c7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87207223e95d1c6ebda9db08a9970fc27ff55f0dd00dba24068e7b3f2a5aa446',1978,'JO','Jordan','people-and-society',273,'Population: 2,899,000, including West Bank and East
Jerusalem (January 1978), average annual growth rate 2.8%
(current); East Bank, 2,129,000, average annual growth rate
3.2% (current), West Bank, including East Jerusalem,
770,000, average annual growth rate 1.9% (current)
Nationality: noun—Jordanian(s); adjective—Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 90%-92% Sunni Muslim, 8%-10% Christian
Language: Arabic official, English widely understood
among upper and middle classes
Literacy: about 50%-55% in East Jordan; somewhat less
than 60% in West Jordan
Labor force: 638,000; less than 5% unemployed
Organized labor: 9.8% of labor force','792ad95096993f4c78918e50fd47a57606bd07b68ad186b7903a54477deeefd0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('444740775b8544819066139ecfa9188dac30eec7814bf78cab4be139c14bdeb9',1978,'KE','Kenya','people-and-society',277,'Population: 14,578,000 (January 1978), average annual
growth rate 3.5% (7-71 to 7-76)
Nationality: noun—Kenyan(s); adjective—Kenyan
Ethnic divisions: 97% native African (including Bantu,
Nilotic, Hamitic and Nilo-Hamitic),; 2% Asian; 1% Europe-
an, Arab and others
Religion: 56% Christian, 36% animist, 7% Muslim, 1%
Hindu
Language: English and Swahili official; each tribe has
own language
Literacy: 27%
Labor force: 2.5 million; about 977,000, (89%) in
monetary economy (1967)
Organized labor: about 215,000
Population: 17,847,000 (January 1978), average annual
growth rate 3.2% (current)
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities
now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 48% agriculture, 52% non-agri-
cultural; shortage of skilled and unskilled labor
Population: 55,000 (January 1978), average annual
growth rate 0.9% (current)
Ethnic divisions: mainly of African Negro descent
Nationality: noun—Kittsian(s), Nevisian(s), Anguillan(s);
adjective—Kittsian, Nevisian, Anguillan
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
176
Literacy: about 80%
Labor force: 19,616 (1960 est.)
Organized labor: 6,700
Population: 114,000 (January 1978), average annual
growth rate 1.6% (4-60 to 4-70)
Nationality: noun—St. Lucian(s); adjective—st. Lucian
Ethnic divisions: mainly of African Negro descent
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 38,000 (1969); 50% agriculture; 30%-35%
unemployment (1975)
Organized labor: 20% of labor force
Population: 104,000 (January 1978), average annual
growth rate 1.5% (4-60 to 7-75)
Nationality: noun—St. Vincentian(s) or Vincentian(s);
adjectives—St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian and
Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60% unemployed
Organized labor: 10% of labor force','f3244deb1cc8eea91219731fa938407c1a3d41ce5b2909d5316668bc38a1467d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f072e26fa7d2c4d09dba32df3e1402bf353d3a4c433fbf6e464e2df2ec20e289',1978,'KW','Kuwait','people-and-society',281,'Population: 1,119,000 (January 1978), average annual
growth rate 5.6% (7-70 to 7-76)
Nationality: noun—Kuwaiti(s); adjective—Kuwaiti
Ethnic divisions: 85% Arabs, 13% Iranians, Indians, and
Pakistani; native Kuwaitis are a minority
Religion: 99% Muslim, 1% Christian, Hindu, Parsi, other
114 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
KUWAIT/LAOS
Language: Arabic; English commonly used foreign
language
Literacy: about 60%
Labor force: 340,000 (1976 est.); 26% manufacturing,
25% services, 85% government and professions, 9% com-
merce, 5% oil industry; two-thirds of labor force is
non-Kuwaiti
Organized labor: labor unions, first authorized in 1964,
formed in oil industry and among government personnel
Population: 3,538,000 (January 1978), average annual
growth rate 2.4% (7-73 to 7-74)
Nationality: noun—Lao (sing., Lao or Laotian); adjec-
tive—Lao or Laotian
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
LAOS
(See reference map Vil)
Ethnic divisions: 47% Lao; 14% Tribal Tai; 25%
Phoutheung (Kha); 14% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant foreign
language
Literacy: about 12%
Labor force: about 1-1.5 million; 80%-90% agriculture;
Organized labor: only labor organization is subordinate to
the Communist Party','cbef66f004c027db8a364f3b7487c2a8d2531ea29f0602ba6a26777d9b7e1a0f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88222440cd048648bea5c4e80a05722a9a38433097f5e0498b747e99678f3fd6',1978,'LB','Lebanon','people-and-society',285,'Population: 2,510,000 (January 1978), average annual
growth rate 2.3% (current)
Nationality: noun—Lebanese (sing. and pl.); adjective—
Lebanese
Ethnic divisions: 98% Arab, 6% Armenian, 1% other
Religion: 55% Christian, 44% Muslim and Druze, 1%
other (official estimates); Muslims, in fact, constitute a
majority
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically active; 49%
agriculture, 11% industry, 14% commerce, 26% other;
moderate unemployment
Organized labor: about 65,000','9bbeaf735d26f2879bbff2b91e9d9956ed8d0bd5074a789277af3c46cf345a6d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1c9d8f1e196c11e94a7aa6e5db69e15a797d5e56960d3987433c9ad2d6f7f8f',1978,'LS','Lesotho','people-and-society',289,'Population: 1,098,000 (January 1978), average annual
growth rate 2.2% (7-72 to 7-75)
Nationality: noun—Mosotho (sing.), Basotho (pl.); adjec-
tive—Basothan
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800
Asians
Religion: 70% or more Christian, rest animist
s Language: all Africans speak Sesotho vernacular: English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend 6 months
to many years as wage earners in South Africa
Organized labor: negligible','e483f5e25b9d6ecf4a31a20ac41c48803c45e325ea02ac4a85ff1851ee1e8158','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8967b84a7dd9013e9cf7f8fd4eb80fb0802a17dc62815b4c2b145d83c0fba76',1978,'LR','Liberia','people-and-society',293,'Population: 1,682,000 (January 1978), average annual
growth rate 2.9% (current)
Nationality: noun—Liberian(s); adjective—Liberian
Ethnic divisions: 5% descendants of immigrant Negroes;
95% indigenous Negroid African tribes including Kpelle,
Bassa, Kru, Grebo, Gola, Kissi, Krahn, and Mandingo
Religion: probably more Muslims than Christians;
70%-80% animist
Language: English official; 28 tribal languages or dialects,
pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 600,000, of which 120,000 are in monetary
economy; about 2,000 non-African foreigners hold about
95% of the top level management and engineering jobs
Organized labor: 2% of labor force
119
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
LIBERIA/LIBYA','cf6f22ad74c0a98c87747113432edb93961b1c8b31b7505b66a207dfd29be7c6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('790be34db9cac8f21cb7ccc4be13c8f220fdf8cd3c36da4e05338dc0b0236e1a',1978,'LY','Libya','people-and-society',297,'Population: 2,708,000 (January 1978), average annual
growth rate 4.2% (7-74 to 7-76)
Nationality: noun—Libyan(s); adjective—Libyan
Ethnic divisions: 97% Berber and Arab with some Negro
stock; some Greeks, Maltese, Jews, Italians, Egyptians
Religion: 97% Muslim
Language: Arabic; Italian and English widely understood
in major cities
Literacy: 35%
Labor force: 900,000 of which about 350,000 are resident
foreigners (est. 1977)','75999d15b74d774e0c5c8d59ebbfed9da7adbd81fe01ebad7a6cd9f4534b6c63','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8940030f22dac9b6422186cb3ab00d9a5c7ab7d408655ede1c1d3221d605f25',1978,'LI','Liechtenstein','people-and-society',301,'Population: 25,000 (January 1978), average annual
growth rate 2.5% (12-60 to 12-70)
Nationality:
Ethnic divisions: 95% Germanic, 5% Italian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and commerce,
13% professional and other, 8% agriculture','84cd3782795e26494e48be6d4281f28121039eb26a8df78777169cb3ddaeed3e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72d04ec743d562083ee9860d43e1a47d0cc9bfebd754496445ca97e46f2d3285',1978,'LU','Luxembourg','people-and-society',306,'Population: 362,000 (January 1978), average annual
growth rate 0.7% (7-66 to 7-76)
Nationality: noun—Luxembourger(s); adjective—Luxem-
bourg
Ethnic divisions: 83% Luxembourger, including an
estimated 5% of Italian descent; remainder French, German,
Belgian, etc.
Religion: 97% Roman Catholic, remaining 3% Protestant
and Jewish
Language: Luxembourgish, German, French; most edu-
cated Luxembourgers also speak English
Literacy: 98%
Labor force: (1974) 158,000; 10% agriculture (including
forestry and fishing), 48% industry, 42% services; 30% of
labor force is foreign, comprising workers from neighboring
areas of Belgium, France, and West Germany, as well as
Italy and Portugal, unemployment 0.6% August 1977
Organized labor: 45% of labor force','6132798607ddb22ad1d1fb8597a893af0851ad6bdfbe3c9162f2d038bcdde0c7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('109428a7138a3dd81c206be4036ca91ab77f8ae76bb6ed1847df3917908121ae',1978,'MO','Macao','people-and-society',310,'Population: 251,000 (official estimate for 1 July 1972)
Nationality: noun—Macaon(s); adjective—Macaon','1c22e832be436b173c0ae9a374abff4db361d38fe5f9c98c36ac166548656c46','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('274e25f219a0771e303ecbee010a742203510241befb305dc5009878642ad38c',1978,'MG','Madagascar','people-and-society',312,'Population: 7,990,000 (January 1978), average annual
growth rate 2.3% (7-69 to 7-70)
Nationality: noun—Malagasy (sing. and pl.); adjective—
Malagasy
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4','b756088eaf21bdc3edcc156f83ae270d81ff9f3c85e7ac426c88be5d9618a3ef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2222763383ca35c9f2a689b26201043a57e5ec338cb50793e938f987e3c9de03',1978,'MW','Malawi','people-and-society',314,'Population: 5,378,000 (January 1978), average annual
growth rate 2.6% (7-75 to 7-76)
Nationality: noun—Malawian(s); adjective—Malawian
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is
second African language
Literacy: 15% of population
Labor force: 225,000 wage earners employed in Malawi
(1974); 30% agriculture, 11% construction, 10% commerce,
13% manufacturing, 10% administration, 26% miscellaneous
services; 6,000 Europeans permanently employed
Organized labor: small minority of wage earners are
unionized','134db57014c3fa85c73f79f7b46ea046f9ec077c50ec19bf8aaf4fe7ee6383ce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ebe7c33577e743bfb0d60ccd3e03737b5ead6462d40411c215b20934382deee',1978,'MY','Malaysia','people-and-society',318,'Population: 12,736,000 (January 1978), average annual
growth rate 2.7% (7-70 to 7-75)
Peninsular Malaysia: 10,676,000,
growth rate 2.6% (7-70 to 7-75)
Sabah: 888,000, average annual growth rate 4.2% (7-70
to 7-75)
Sarawak: 1,172,000, average annual growth rate 2.5%
(7-70 to 7-75)
average annual
Nationality: noun—Malaysian(s); adjective—Malaysian
Ethnic divisions:
Malaysia: 50% Malay, 35% Chinese, 10% Indian
Peninsular Malaysia: 53% Malay, 35% Chinese, 11%
Indian and Pakistani, 1% other
Sabah: 21% Chinese, 69% indigenous tribes, 10% other
Sarawak: 30% Chinese, 50% indigenous tribes, 19%
Malay, 1% other
Religion:
Peninsular Malaysia: Malays nearly all Muslim,
Chinese predominantly Buddhists, Indians predominantly
Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak; 23% Muslim, 24% Buddhist and Confucianist,
16% Christian, 35% tribal religion, 2% other
Language:
Peninsular Malaysia: Malay (official); English, Chinese
dialects, Tamil
Sabah: English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal
languages
Literacy:
Peninsular Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 4.2 million (1975)
Peninsular Malaysia: 3.6 million; 46.2% agriculture,
forestry, and fishing, 10.9% manufacturing and construction,
31.9% trade, transport, and services (1975)
Sabah: 213,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 18% trade and
transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 13% trade,
transportation, and services, 1% other
Organized labor: 500,000 (1975 est.), about 15% of total
labor force; unemployment about 7% of total labor force, but
higher in urban areas','4523c549cef58d7a2ddbc1c0fc0a1beec01c2798c6188fa0784c75e7ff123b84','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55959baaa4d87a8aced70e685a98c0ce9755b094762e4d6c5d2ff3b35590dcba',1978,'MV','Maldives','people-and-society',324,'Population: 137,000 (January 1978), average annual
growth rate 2.1% (current)
130 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MALDIVES /MALI
Nationality: noun—Maldivian(s); adjective—Maldivian
Ethnic divisions: admixtures of Sinhalese, Dravidian,
Arab, and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male
population','ba755cddabf4dd383488a9a0dde09434c872e14b0d6591f34c8693fd5481a434','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d26ab580d77b1b258df0f0f7ca913313682ae45008e89d9dc0592e3e7e197a4a',1978,'ML','Mali','people-and-society',328,'Population: 6,205,000 (January 1978), average annual
growth rate 2.6% (current)
Nationality: noun—Malian(s); adjective—Malian
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African languages, of
which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried, 50,000 of
whom are employed by the government; most of population
engaged in agriculture and animal husbandry
Organized labor: Union National des Travailleurs Maliens
(UNTM) is umbrella organization over thirteen national
unions
Population: 322,000 (official estimate for 31 March 1977)
Nationality: noun Maltese (sing. and pl.); adjec-
tive Maltese
Ethnic divisions: mixture of Arab, Sicilian, Norman.
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in
1946
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MALTA/MARTINIQUE
Labor force: 102,000; 29% services, 23% government, 24%
manufacturing, 6% agriculture, 4% construction, 4% trans-
portation and communications, 5% utilities and drydocks;
5% unemployed
Organized labor: approximately 40% of labor force','85f6484cba341f74117a45e6df322dcbd5a8fde4d609bf071aaebf43c370e41c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6859c03813e34923cded4fbd027b023accae4750ab93d0127a550de3996ff33a',1978,'MQ','Martinique','people-and-society',333,'Population: 327,000 (January 1978), average annual
growth rate 0.2% (10-67 to 10-74)
Nationality: noun Martiniquais
adjective Martiniquais
Ethnic divisions: 90% African and African-Caucasian-
Indian mixture, less than 5% East Indian Lebanese, Chinese,
5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
(sing. and pl.);
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 133
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MARTINIQUE/MAURITANIA
DOMINICAN Atlantic Ocean
yO Age REPUBLIC
Caribhean Sea
i)
MARTINIQUE %
{See reference map it}
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public
services, 11% construction and public works, 10% commerce
and banking, 10% services, 9% industry, 17% other
Organized labor: 11% of labor force','26a46d01265de399cb3573d56466cbf9bf44c2044669f7b6948b83f4e56ec2cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba711f50f449b4f294421bd6796dec321a8500aa238e7352f8aa44146d06e8a3',1978,'MR','Mauritania','people-and-society',337,'Population: 1,522,000 (January 1978), average annual
growth rate 2.7% (7-72 to 7-75)
Nationality: noun—Mauritanian(s); adjective— Mauri-
tanian
134 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Atlantic MAURITANIA
Nouakchoit
Gcean
(See reference map Vi)
Ethnic divisions: nearly one third Moor, at least one third
Negro, one third mix Moor/Negro
Religion: nearly 100% Muslim
Language: Hassaniya Arabic is the national language
spoken by some 80% of the population, French is the
working language for government and commerce
Literacy: about 10%
Labor force: about 35,000 wage earners (1976); remain-
der of population in farming and herding; considerable
unemployment
Organized labor: 18,000 union members claimed by
single union, Mauritanian Workers’ Union','8e55f05b028083fb3038aa8290570f712bf69aabdfdcb69da8500acee021b276','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a80cb20cf490e36be4068fbeca3100362d7629965fb037084786405e3dd7a8a1',1978,'MU','Mauritius','people-and-society',341,'Population: 917,000 (January 1978), average annual
growth rate 1.8% (1-72 to 1-76)
Nationality: noun—Mauritian(s); adjective—Mauritian
Ethnic divisions: 67% Indians, 29% Creoles, 3.5%
Chinese, 0.5% English and French
Religion: 51% Hindu, 33% Christian (mostly Catholic
with a few Anglican Protestants), 16% Muslim
Language: English official language; Hindi, Chinese,
French Creole
Literacy: estimated 60% for those over 21, and 90% for
those of school age
Labor force: 175,000; 50% agriculture, 6% industry; 20%
government services; 14% are unemployed, underemployed,
or self-employed, 10% other
Organized labor: about 35% of labor force
Population: 504,000 (January 1978), average annual
growth rate 1.7% (7-70 to 7-74)
Nationality: noun—Reunionnais (sing. & pl.); adjective—
Reunionnais
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese,
Pakistani, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal
unemployment','a3bb0d7df338781cf1523e98f5006d9723bfc24fffdab1e4520743b37cad9108','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afd7ff42413b7304123f917625d8cf4cc758a4cf2c5097465d56395c242a71ba',1978,'MX','Mexico','people-and-society',345,'Population: 65,487,000 (January 1978), average annual
growth rate 3.3% (current)
Nationality: noun—Mexican(s); adjective—Mexican
Ethnic divisions: 60% mestizo, 30% Indian or predomi-
nantly Indian, 9% white or predominantly white, 1% other
Religion: 97% nominally Roman Catholic, 3% other
Language: Spanish
Literacy: 65% estimated, 84% claimed officially
Labor force (1973): 16.5 million (1977) (defined as those
12 years of age and older); 39.5% agriculture, 16.7%
manufacturing, 16.6% services, 16.8% construction, utilities,
commerce, and transport, 3% government, 7.4% unspecified
activities; 9% unemployed, 40% underemployed
Organized labor: 20% of total labor force','fd94d7ecd91094890b2e1fecce0b605c9c30e6d9835775e0adbd65bb646960c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08dc33ed7f7908c7331433edd7a96522407e6f3bda330cf9b24300b596674c5e',1978,'MC','Monaco','people-and-society',349,'Population: 25,000 (official estimate for 1 July 1976)
Nationality: noun—Monacan(s) or Monegasque(s); adjec-
tive—Monacan or Monegasque
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state religion
Language: French
Literacy: almost complete','f7f3fde77e2e142ae67c13d0a18f8c3b8f6cf22d7fd5577b014c9229c3fe22b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1af0a5743ed94c98f16d97cab0b7ce213bf25dafb7cc9f31a8d8d9289150a0e',1978,'MN','Mongolia','people-and-society',353,'Population: 1,561,000 (January 1978), average annual
growth rate 3.2% (current)
Nationality: noun—Mongolian(s); adjective—Mongolian
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese,
2% Russian, 2% other
139
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MONGOLIA/MOROCCO
Religion: predominantly Tibetan Buddhist, about 4%
Muslim, limited religious activity because of Communist
regime
Languages: Khalkha Mongol used by over 90% of
population; minor languages include Turkic, Russian, and
Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the
population is in the labor force, including a large percentage
of Mongolian women; shortage of skilled labor (no reliable
information available)','bbb0f4faff2162db7d850c317eabfb706e6839c6fd35442e5e35f6b1d3cb9e1c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebcbb860941f9ce4f623bfa0c16848e3ffa99db148475d5df941b590844e5bed',1978,'MA','Morocco','people-and-society',357,'Population: 18,644,000 (January 1978), average annual
growth rate 3.0% (7-75 to 7-76)
Nationality: noun—Moroccan(s); adjective—Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish, 0.7%
non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Jewish
rae Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Language: Arabic (official); several Berber dialects;
French is language of much business, government, diploma-
cy, and postprimary education
Literacy: 20%
Labor force: 5 million (1971 est.); 50% agriculture, 15%
industry, 26% services, 9% other; 10-20% unemployment
Organized labor: about 5% of the labor force, mainly in
the Union of Moroccan Workers (UMT)','f77535c46912cb61844a8a00b338d015ba5da9ed8d336a371afdeb0f8c8ca501','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9d842bc6621fe1cd2f914797ba7f3171a0a27ceeeb5d3d6a3ace524605eb4e2',1978,'MZ','Mozambique','people-and-society',361,'Population: 9,798,000 (January 1978), average annual
growth rate 2.5% (7-71 to 7-76)
Nationality: noun—Mozambican(s); adjective—Mozam-
bique
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: 65.6% animist, 21.5% Christian, 10.5% Muslim,
2.4% other
Language: Portuguese (official); many tribal dialects
Literacy: 7%-10% (est.)
Labor force: (1963 est.) 610,000; 50,000 non-African
wage earners, 560,000 African wage earners in Mozam-
bique; 290,000 additional African wage earners temporarily
working in Rhodesia and South Africa; unemployment
serious problem; most native Africans provide unskilled
labor or remain in subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970); 75% are
white','d990147a40fc2cef462521fcb6bfb6b0d7b2ca073e2fbfee26716b848489f992','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c59d6ff6f4379fd92fd533c14e1ee416fe0978c1745a925b6aeaf6416c96f0f',1978,'NA','Namibia','people-and-society',365,'Population: 951,000 (January 1978), average annual
growth rate 3.0% (7-69 to 7-75)
Nationality: noun—Namibian(s); adjective—Namibian
Ethnic divisions: 12% white, 6% mulatto, 82% African;
over half the Africans belong to Ovambo tribe
Religion: whites predominantly Christian, nonwhites
either animist or Christian
Language: Afrikaans principal language of about 70% of
white population, German of 22% and English of 8%; several
African languages
Literacy: high for white population; low for nonwhite
Labor force: 203,300 (total of economically active, 1970);
68% agriculture, 15% railroads, 18% mining, 4% fishing
Organized labor: no trade unions, although some white
wage earners belong to South African unions','b7a7454ef7d9140edb5ea3582383e272478d7baec605d3974672183ddd8972de','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c2bc851d2beda9749689ca788bcc0872d93b33ff3da8c22d295f9d34869f466',1978,'NR','Nauru','people-and-society',369,'Population: 7,000 (official estimate for 30 June 1969)
Nationality: noun—Nauruan(s); adjective—Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
(two-thirds
Religion: Christian one-third
Catholic)
Language: Nauruan, a distinct Pacific Island tongue;
English, the language of school instruction, spoken and
understood by nearly all
Protestant,
Literacy: nearly universal','3a191c36135b7c06e736766f92cfb01d067a5fdd42b4ba6ab5c7536029f305ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1043a030c31296a71556cf403bffcd6379049c920b6900141ae3855d449286f4',1978,'NP','Nepal','people-and-society',373,'Population: 13,348,000 (January 1978), average annual
growth rate 2.2% (6-71 to 6-76)
Nationality: noun—Nepalese (sing. and pl.); adjective—
Nepalese
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%), representing
considerable intermixture of Indo-Aryan and Mongolian
racial strains; country divided among many quasi-tribal
communities
Religion: only official Hindu Kingdom in world, although
no sharp distinction between many Hindu and Buddhist
groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided
into numerous dialects; Nepali official language and lingua
franca for much of the country; same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5% industry;
great lack of skilled labor','00253b00a5d97371572f4948feffd25c60293afe2ec658a4eb1bb73481183f4d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e1aa6967af0ec5cf547848a8c454415013dffdb9c57c6e581fd582b1d70a642',1978,'NL','Netherlands','people-and-society',377,'Population: 13,891,000 (January 1978), average annual
growth rate 0.6% (current)
Nationality: noun— Netherlander(s); adjective—Nether-
lands
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 41% Protestant, 40% Roman Catholic, 19%
unaffiliated
Language: Dutch
Literacy: 98%
04-4
a Approved For Release 2005/04/22 : CIA-RDP79-01051A0009000100
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Labor force: 4.7 million; 30% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9% construction,
7% transportation and communications, 4% other; 5.1%
unemployment (August 1977)
Organized labor: 33% of labor force
Population: 246,000 (January 1978), average annual
growth rate 1.2% (1-75 to 1-76)
Nationality: noun—Netherlands Antillean(s); adjective—
Netherlands Antillean
Ethnic divisions: racial mixture with African, Caribbean
Indian, European, Latin, and oriental influences; negroid
characteristics are dominant on Curacao, Indian on Aruba
Religion: predominantly Roman Catholic; sizable Protes-
tant, smaller Jewish minorities
Language: officially Dutch; “Papiamento,” a Spanish-
Portuguese-Dutch-English dialect predominates; English
widely spoken
Literacy: 95%
Labor force: 76,000 (1972); 2% agriculture, 20% industry,
10% construction, 65% government and services, 3% other
Organized labor: 60%-70% of labor force','4bd627261f95a89f759a3fa9656ff3dc04aff84b2d16a9f6ec68db072bbc4ec6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0a8616282b5c3790a1ae4fc05a2437c5476eb6397d7474fa3737f6eca034c78',1978,'NC','New Caledonia','people-and-society',381,'Population: 140,000 (January 1978), average annual
growth rate 3.1% (current)
Nationality: noun—New Caledonian(s);, adjective—New
Caledonian
Ethnic divisions: Melanesian-Polynesian admixture, over
28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese
laborers were imported for plantations and mines in
pre-World War II period; immigrant labor now coming
from Wallis Islands, New Hebrides, and F rench Polynesia
Organized labor: unorganized
Population: 101,000 (January 1978), average annual
growth rate 2.5% (7-68 to 7-76)
Nationality: noun—New Hebridean(s); adjective—New
Hebrides
Ethnic divisions: 92% indigenous Melanesian, 3% Euro-
pean, remainder Vietnamese, Chinese, and various Pacific
Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%','87f26843b9eccba5708091b13698920aa557569ab0b95d626a4145b277c95945','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a3d45f129d7b71d9ad69194672709672b46f189766fc72f09e2491692e5ae80',1978,'NI','Nicaragua','people-and-society',386,'Population: 2,346,000 (January 1978), average annual
growth rate 3.3% (7-70 to 7-76)
Nationality: | noun—Nicaraguan(s); adjective—Nica-
raguan
Ethnic divisions: 69% mestizo, 17% white, 9% Negro, 5%
Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English speaking minority
on Atlantic coast
152 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Literacy: 52% of population 10 years of age and over
Labor force: 713,000 (1976 est.); 50% agriculture, 12%
manufacturing, 14% services, 24% other; shortage of skilled
labor, but underemployment of unskilled labor except
during harvest
Organized labor: about 5.6% of labor force','91b91720c7efcc6db00e77ae64fa27d1b7d089bd57efb128562b24dfca704080','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9f69a3fe2246cedcb026bdbe8ea68c9d695426ce434dd3d2d31fe3aba88b10a',1978,'NE','Niger','people-and-society',390,'Ethnic divisions: main Negroid groups 75% (of which,
Hausa 50%, Djerma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks, mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Language: French official, many African languages;
Hausa used for trade
Literacy: about 6%
Labor force: 26,000 wage earners; bulk of population
engaged in subsistence agriculture and animal husbandry
Organized labor: negligible','fa5999565c6ab695dc855e8db7431268ef9410ea063f49781884dd4730cd00f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14a3931de0ac8291b2bfe6a17a3d104eba67a2042cc0f56820da3d2fa98a185d',1978,'NG','Nigeria','people-and-society',395,'Population: 67,520,000 (January 1978), average annual
growth rate 2.9% (current)
Nationality: noun—Nigerian(s); adjective—Nigerian
Ethnic divisions: of the more than 250 tribal groups, the
Hausa and Fulani of the north, the Yoruba of the south, and
the Ibos of the east comprise 60% of the population; about
27,000 non-Africans
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and Ibo also
widely used
Labor force: approx. 22.5 million; about 41% of total
population; roughly 1.3 million wage earners, of whom
560,000 work in modern enterprises
Organized labor: about 530,000 wage earners, approx.
2.4% of total labor force, belong to some 700 unions','ee313e26016a91b7bb29c0275fcc0d05a09fe291abea8278d432110df55478bd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb0a1cba6782af2fdca17fa14fabb33f1f22ff2b2908b31fa591a11d69c56c45',1978,'NO','Norway','people-and-society',399,'Population: 4,054,000 (January 1978), average annual
growth rate 0.5% (1-76 to 1-77)
Nationality: noun—Norwegian(s); adjective—Norwegian
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant
and Roman Catholic, 1% other
Language: Norwegian, small Lapp and Finnish-speaking
minorities
Literacy: 99%
Labor force: 1.7 million; 11.4% agriculture, forestry,
fishing, 25.3% mining and manufacturing, 8.1% construc-
tion, 16.3% commerce, 9.9% transportion and communica-
tion, 28.5% services; 1.4% unemployed
Organized labor: 60% of labor force
Population: 541,000 (January 1978), average annual
growth rate 3.2% (current)
Nationality: noun—Omani(s); adjective—Omani
Ethnic divisions: almost entirely Arab with small.groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','5abebaac4cc07bfb88ef93db78536ff1a8dffafeb80bc6f6fecf79c42dabfd4c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb1a8e53373bdffeb0a2d2a513c2d35b26079f27808aaa725238b5630f18af29',1978,'PK','Pakistan','people-and-society',403,'Population: 75,657,000, excluding Junagadh, Manavadar,
Gilgit, Baltistan, and the disputed area of Jammu-Kashmir,
(January 1978), average annual growth rate 3.0% (7-75 to
7-76)
Nationality: noun—Pakistani(s); adjective—Pakistani
Religion: 97% Muslim, 3% other
Language: official, Urdu, total spoken languages—7%
Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu, 9% other;
English is lingua franca
Literacy: about 17%
Labor force: 20 million (est. 1974); 60% agriculture, 16%
industry, 7% commerce, 15% service, 2% unemployed
Organized labor: 5% of labor force','1329414e303f81fdf50d402714f95f0116e230d5d1b2c2eb91f80c454f4c3789','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fb3f73c6e95d3b7b87c9b3fdbc93d8dcf2ab69f24e9d546b5813c4a913d2001',1978,'PA','Panama','people-and-society',407,'Population: 1,798,000 (January 1978), average annual
growth rate 3.1% (7-75 to 7-76)
Nationality: | noun—Panamanian(s); adjective—Pana-
manian
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7%
Indian and other
Religion: over 90% Roman Catholic, remainder mainly
Protestant
Language: Spanish; about 14% speak English as native
tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and over
Labor force: 482,200 (1972 est.); 39.5% commerce,
finance and services; 33.9% agriculture, hunting and fishing;
9.7% manufacturing and mining; 6.8% construction; 5%
Canal Zone; 3.9% transportation and communications; 1.2%
utilities; unemployment estimated at 10% to 13%; shortage
of skilled labor but an oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)','16388660400ea44c39725cc1c2b9b15fd215973fb11f8554203640b1a5476add','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a54a0fc889495c872830c0960da51b6ac441ee154759b99bc2fb3c131fd38041',1978,'PG','Papua New Guinea','people-and-society',411,'Population: 2,941,000 (January 1978), average annual
growth rate 2.6% (7-66 to 7-76)
Nationality: noun—Papua New Guinean(s); adjective—
Papua New Guinean
Ethnic divisions: predominantly Melanesian and Papuan,
some Negrito, Micronesian, and Polynesian types
Religion: over one-half of population nominally Christian
(490,000 Catholic, 320,000 Lutheran, other Protestant sects);
remainder animist
Language: 700 indigenous languages; pidgin English and
2 or 3 native languages are linguae francae for over one-half
of population; English spoken by 1% to 2% of population
Literacy: 15%; in English, 0.1%
Labor force: no available figures: mostly subsistence
farmers','99aad5042e3ee582b42e138bc429caf0c7d1c7eae62f08010ce8e67016b4a01b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07f4c579ca22f40d90d98ec8a4eec20a3ed5689f470e4b283a76466a4f9d9f70',1978,'PY','Paraguay','people-and-society',415,'Population: 2,846,000 (January 1978), average annual
growth rate 2.9% (current)
Nationality: noun—Paraguayan(s); adjective—Para-
guayan
Ethnic divisions: 95% mestizo, 5% white and Indian
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
{See reference map Ai
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 800,000 (1971 est.); 55% agriculture,
forestry, fishing; 8% transport and other services; 19%
manufacturing and construction, 13% commerce and profes-
sions; 5% miscellaneous (est. 1962)
Organized labor: about 5% of labor force','2ebbab1052ef90128af6b39a2b935b22e58c1168e7986ea41c73c993f56ecb1c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37a5f582934e3f1a869e308a3043da7f130a77ad1bb35c2c510e3abaf0ac2ef7',1978,'PE','Peru','people-and-society',419,'Population: 16,832,000 (January 1978), average annual
growth rate 3.0% (7-75 to 7-76)
Nationality: noun—Peruvian; adjective—Peruvian
Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white: 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
ai Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
i Te TTST''S
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 5.0 million (1975); 42.1% agriculture, 17%
services, 14% manufacturing, 9% trade, 4% construction, 4%
transportation, 2% mining, 4% other
Organized labor: 37.1% of labor force','ef269d34d7a83a38b9d3cfa001af4d8ba9e08acec3cd59dc604f048262c76d68','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13725305049a741869b695db4730de68eb1a191db6eccbc2b3909bf7db86ae4f',1978,'PL','Poland','people-and-society',423,'Population: 34,878,000 (January 1978), average annual
growth rate 1.0% (current)
Nationality: noun—Pole(s); adjective—Polish
Ethnie divisions: 98.7% Polish, 0.6% Ukrainians, 0.5%
Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75% practicing),
5% Uniate, Greek Orthodox, Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26% industry,
36% other non-agricultural','86b32f9780cf929eaed61b7e7c3553a0a95a52ec383f6bd868a9951fa5505cb2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8aede542a7383ec35aebd74574231a71df1cd5ec8325acef841f65bb6822cd28',1978,'PT','Portugal','people-and-society',427,'Population: metropolitan Portugal (including the Azores
and Madeira Islands), 9,830,000 (January 1978), average
annual growth rate 0.9% (7-68 to 7-75)
i Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Nationality: noun—Portuguese (sing. & pl.); adjective—
Portuguese
Ethnic divisions: homogeneous Mediterranean stock in
mainland, Azores, Madeira Islands; citizens of black African
descent who immigrated to mainland during decolonization
number less than 100,000
Religion: 97% Roman Catholic, 1% Protestant sects, 2%
other
Language: Portuguese
Literacy: 65% (1973)
Labor force: (1975) 3.1 million; 28% agriculture, 36%
industry, 36% services; drastic rise in unemployment—now
more than 15%—due largely to influx of refugees from
former colonies, returning migrant workers, and military
cutbacks
Organized labor: the Communist-dominated General
Confederation of Portuguese Workers—National Intersindi-
cal (GCTP-IN) claims to represent 85% of the labor force;
the Socialists and Social Democrats are hoping to improve
their standing with organized labor and eventually challenge
domination of most unions by the Communists','4bd89569106500146ee6d81eb1a1782fd4cd627d90a35de122564837440d3478','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f08c31c986cca97fcd07a624bafbe7f51844f3a86931f95d914aac4d761f953a',1978,'QA','Qatar','people-and-society',431,'Population: 165,000 (January 1978), average annual
growth rate 3.3% (current)
Nationality: noun—Qatari(s); adjective—Qatari
Ethnic divisions: 56% Arab; 23% Iranian; 14% Pakistani;
7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: primarily foreign','077778a504663cba05828f6b827e6180fe09852727893a294acb34ccf91c2251','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7fce46009e2c659139072a35ee8f563d73f1345d8ada841426fc7fcb8ddf6bb',1978,'FR','France','people-and-society',434,'Population: 6,876,000 (January 1978), average annual
growth rate 3.5% (7-75 to 7-76)
Nationality: noun—Rhodesian(s); adjective—Rhodesian
Ethnic divisions: 96% African, less than 4% European,
less than 0.5% coloreds and Asians
Religion: 51% syncretic (part Christian, part animist),
24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and Sindebele also
widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including some
migrants from Zambia and Malawi), 108,000 Europeans,
Asians, and coloreds (people of mixed heritage); 35%
agriculture, 25% mining, manufacturing, construction, 40%
transport and services
172 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
RHODESIA/ROMANIA
Organized labor: about one-third of European wage
earners are unionized, but only a small minority of Africans
(1966)','7bc1e3346a77e09f632441ca3840fd9deba305a295fd0f2437f071a5dd959b59','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5fe9f226320c0228201f9290f21265d4823221ae4fd00f6fcfdcc86998a0b06',1978,'RO','Romania','people-and-society',436,'Population: 21,760,000 (January 1978), average annual
growth rate 0.9% (current)
Nationality: noun—Romanian(s); adjective—Romanian
Kthnic divisions: 87% Romanian, 8% Hungarian, 2%
German, 3% other
Religion: 14 million Romanian Orthodox, 1 million
Roman Catholic, 1 million Protestants, 60,000 Jews, 30,000
Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.2 million (1975); 38% agriculture, 31%
industry, 31% other nonagricultural','1b61106d90a256e8e40b34edab2cf37cffcbceb2004ef58e2932b21dc12282a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2fdcf03e67deaa797683a88ec799ed11805973b2dfbfee5083c2e169fb1d06e',1978,'RW','Rwanda','people-and-society',440,'Population: 4,457,000 (January 1978), average annual
growth rate 2.6% (7-70 to 7-76)
Nationality: noun Rwandan(s); adjective—Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa
(Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Language: Kinyarwanda and French official; Kiswahili
used in commercial centers
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','778f0e0b1f4d8fea82a09937570b5577574446a58eea443687aec5c0b3f3cbdf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03100cf14b6ae2c6b3cd6016c9d06579fa80a66c4d1c4b3856eee7c91bdede74',1978,'SM','San Marino','people-and-society',444,'Population: 20,000 (official estimate for 80 June 1975)
Nationality: noun—Sanmarinese (sing. & pl.); adjective—
Sanmarinese
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of
Sanmarinese Workers (affiliated with ICFTU) has about
1,800 members; Communist-dominated Camera del Lavoro,
about 1,000 members','4520805e461b4385decb63af765c685827bade181f5e923bae07403655307bc9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bb2c1740bd08074a19bc754cc5afd36dffa922d736d5ba306de7985a076e198',1978,'ST','Sao Tome and Principe','people-and-society',448,'Population: 75,000 (official estimate for 1 July 1972)
Nationality: noun—Sao Tomean(s): adjective—Sao
Tomean
Ethnic divisions: native Sao Tomeans, migrant Cape
Verdians, Portuguese
Religion: Roman Catholic, Evangelical Protestant, Sev-
enth Day Adventist
Language: Portuguese official
Literacy: estimated at 5%-10%
Labor force: most of population engaged in subsistence
agriculture and fishing; nearly half the island’s work force,
about 10,000 people, are unemployed, the other half work
on cocoa plantations','61a201e4b0bc7beae450425c633fbb38d8ab679aeb6b4e85c3debd8f68c242af','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eacb9b32bec0544fba1f72863be77c4ec84d5c4515b5d3939ba3e3cf267f089f',1978,'SA','Saudi Arabia','people-and-society',452,'Population: 7,746,000 (January 1978), average annual
growth rate 3.1% (current)
Nationality: noun—Saudi(s); adjective—Saudi Arabian or
Saudi
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Literacy: 15% (est.)
Labor force: about 30% of population; 40% agriculture
and herding, 12% construction, 12% service, 12% govern-
ment, 11% commerce, 13% other','4af43a4989fa003c75965918ed52eaa6954eef9c01dd214724531b19f1bfe0b6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e4d4e394d06c2c8961a269c497172f7a0c1f838be5536334253c35f6f0829d7',1978,'SN','Senegal','people-and-society',456,'Population: 5,301,000 (January 1978), average annual
growth rate 2.5% (current)
Nationality: noun—Senegalese (sing. & pl.); adjective—
Senegalese
Ethnic divisions: 836% Wolof, 17.5 Fulani, 16.5 Serer, 9%
Tukulor, 9% Dyola, 6.5% Malinke, 4.5% other African, 1%
Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly
Roman Catholic)
Language: French official, but regular use limited to
literate minority; most Senegalese speak own tribal lan-
guage; use of Wolof vernacular spreading—now spoken to
some degree by nearly half the population
Literacy: 5%-10% {est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricultur-
al workers; about 170,000 wage earners
Organized labor: majority of wage-labor force repre-
sented by unions; however, dues-paying membership very
limited, three labor central unions, major central is CNTS,
an affiliate of governing party','ecc07e145ebc4cd1eb53ccc0aed747e5b22ad0ac88e23c61312a8a8b0dd79487','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c1ed0cb3a620506c9bd44831055f9860d0e71a7cd79fe09c95f1650c25cd5fd',1978,'SC','Seychelles','people-and-society',460,'Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans)
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
183
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SEYCHELLES /SIERRA LEONE
Literacy: limited
Labor force: 22,000 agriculture
Organized labor: 3 major trade unions','636e086affb66f7ffaff816da24375ab118d046238e921654b0efebac910d638','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c18ab41068e49a3e17e25b8a16dcad32c1474d223cee5838774934993498ea4a',1978,'SL','Sierra Leone','people-and-society',464,'Population: 3,219,000 (January 1978), average annual
growth rate 2.3% (12-74 to 7-76)
Nationality: noun-—Sierra Leonean, adjective—Sierra
Leonean
Ethnic divisions: over 99% native African, rest European
and Asian; 13 tribes
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GUINEA-(,
BISSAU
Atlantic
Ocean
(See reference map V1}
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to
literate minority; principal vernaculars are Mende in south
and Temne in north; “Krio,” the language of the resettled
ex-slave population of the Freetown area, is used as a lingua
franca
Literacy: about 10%
Labor force: about 1.5 million, most of population
engages in subsistence agriculture; only small minority, some
70,000, earn wages
Organized labor: 35% of wage earners','a9553d5831d4f79bef7d297b12cc9141b0bff680a3263fef416439ced30e9995','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67614394ef41ca1905ff46df7b685e2cc175b1a30c8867f2414aaef3b65c29d6',1978,'SG','Singapore','people-and-society',467,'Population: 3,323,000 (January 1978), average annual
growth rate 1.3% (7-76 to 7-77)
Nationality: noun—Singaporean(s), adjective—Singapore
Ethnic divisions: 76.2% Chinese, 15% Malay, 7% Indians
and Pakistani, 1.8% other
Religion: majority of Chinese are Buddhists or atheists;
Malays nearly all Muslim; minorities include Christians,
Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay,
Tamil, and English are official languages
Literacy: 70% (1970)
Labor force: 474,718; 0.5% agriculture, forestry, and
fishing, 0.4% mining and quarrying, 32.2% manufacturing,
30.4% services, 5.2% construction, 21.5% commerce, 9.8%
transport, storage, and communications
Organized labor: 24% of labor force
138 Approved For Release 2005/04/22 :','e151147abdc4a9d9612c3cefb6ee23afe8abe48be3358a4d708d3a8a05d7bfae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e48e6849e40bef1750be327f422189abed9c1dfa5449345ff6f237b58305bf5',1978,'SO','Somalia','people-and-society',470,'Population: 3,342,000 (January 1978), average annual
growth rate 2.3% (7-65 to 7-72)
Nationality: noun—Somali(s); adjective—Somali
Ethnic divisions: 85% Hamitic, rest mainly Bantu; 30,000
Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form instituted by government
in 1976); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled
laborers; 70% pastoral nomads, 30% agriculturists, govern-
ment employees, traders, fishermen, handicraftsmen, other
Organized labor: general Federation of Somali Trade
Unions, a government-controlled organization, established in
1977','eaf0197a0d51158279a6047a112f94a3a9d12bc969d195be013d630b23f04b31','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94d7fa4f0435a39624d4f6d44ef0343642a8427b8c65f712068b7893465dee4b',1978,'ZA','South Africa','people-and-society',474,'Population: 27,188,000, including Transkei (January
1978), average annual growth rate 2.7% (7-61 to 7-76)
Nationality: noun—South African(s); adjective—South
African
Ethnic divisions: 17.8% white, 69.9% African, 9.4%
Colored, 2.9% Asian
Religion: primarily Christian except Asian and African:
60% of Africans are animists
Language: Afrikaans and English official, Africans have
many vernacular languages
Literacy: almost all white population literate; government
estimates 50% of Africans literate
Labor force: 8.7 million (total of economically active,
1970); 53% agriculture, 8% manufacturing, 7% mining, 5%
commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is
unionized (mostly white workers); nonwhites have no
bargaining power
Organized labor: no trade union, although some White
and Colored wage earners belong to South African unions','99d78b22e13e03affee36ec284e33ada05a567d03030eb8365bf630906684ee9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b181514e80826502ab1d6f42a21f38d5c60858c63bcb7dd572c1aab892634015',1978,'ES','Spain','people-and-society',477,'Population: 2,185,000 (January 1978), average annual
growth rate 2.8% (5-70 to 7-76)
Nationality: noun—Transkeian(s); adjective—Transkeian
98.9% African, 0.6% white, 0.5%
colored (mulatto); Africans belong to Xhosa ethnic group
Ethnic divisions:
Religion: whites and coloreds predominantly Christian;
Africans either animist or Christian
Language: whites, coloreds, and educated minority of
Africans speak Afrikaans or English; bulk of Africans speak
Xhosa
Literacy: high for whites and coloreds; low for Africans
Labor force: roughly 400,000 of whom only 50,000 are
regularly employed in Transkei; bulk are migrant workers in
Population: 36,542,000, including the Balearic and
Canary Islands; also including Alhucemas, Ceuta, Chafar-
inas, Melilla, and Penon de Velez de la Gomera (January
1978), average annual growth rate 1.1% (current)
Nationality: noun—Spaniard(s); adjective—Spanish
Ethnic divisions: homogeneous composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority;
but 17% speak Catalan, 7% Galician, and 2% Basque
Literacy: about 97%
Labor force (1975): 13.3 million; 22% agriculture, 38%
industry, 40% services; unemployment now estimated at 8%
of labor force
Organized labor: labor unions legalized April 1977
experiencing surge in membership; probably represent about
10% of the labor force','3b1f83ea352b5264831ea09fb65b057f16ccfecb4565f83fcb385329e35bdaa9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d01bdd543e8a7291da409c0412dfe86bfbaae7a678d1f48679440bb4be439dcd',1978,'LK','Sri Lanka','people-and-society',482,'Population: 14,112,000 (January 1978), average annual
growth rate 1.8% (7-66 to 7-76)
Nationality: noun—Sri Lankan(s); adjective—Sri Lankan
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor,
2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6%
Muslim, 1% other
Language: Sinhala official, spoken by about 70% of
population; Tamil spoken by about 22%; English commonly
used in government and spoken by about 10% of the
population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed
persons—53.4% agriculture, 14.8% mining and manufactur-
ing, 12.4% trade and transport, 19.4% services and other;
extensive underemployment
Organized labor: 43% of labor force, over 50% of which
employed on tea, rubber, and coconut estates','8ac29bfc684b0dd4b07ae6a4402ebfaffe63e4f88a3a5641dd1b93e21baf49e5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60a3f7007e615192318f230fc276b47235c458b552d722b1bf4729e90b3ea092',1978,'SD','Sudan','people-and-society',486,'Population: 16,740,000 (January 1978), average annual
growth rate 2.5% (7-75 to 7-76)
Nationality: noun—Sudanese (sing. and pl.); adjective—
Sudanese
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23% pagan, 4%
Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects
of Nilotic, Nilo-Hamitic, and Sudanic languages, English;
program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry,
commerce, services, etc.; labor shortages exist for almost all
categories of employment
Population: 429,000 (January 1978), average annual
growth rate 1.9% (1-70 to 1-75)
Nationality: noun—Surinamer(s); adjective—Surinamese
Ethnic divisions: 31% Creole (Negro and mixed), 37%
Hindustani (East Indian), 15.3% Javanese, 10.3% Bush
Negro, 2.6% Amerindian, 1.7% Chinese, 1.0% Europeans,
1.7% other and unknown
Religion: Hindu, Muslim, Roman Catholic, Moravian,
other
Language: Dutch official; English widely spoken; Sranan
Tongo (Surinamese, sometimes called Taki-Taki) is native
language of Creoles and much of the younger population,
and is lingua franca among others; Hindi: Javanese
Literacy: 80%
Labor force: 118,000
Organized labor: approx. 33% of labor force
Population: 518,000 (January 1978), average annual
growth rate 2.8% (5-66 to 8-76)
Nationality: noun—Swazi(s); adjective—Swazi
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages;
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsist-
ence agriculture; 55,000-60,000 wage earners, many only
intermittently, with 31% agriculture, 11% government, 11%
manufacturing, 12% mining and forestry, 35% other (1968
est.); 22,000 employed in South African mines (1976)
Organized labor: about 15% of wage earners are
unionized','3e9cb1dc8b40d03ecb34fc3b9a4ba730850e2951804803ca88157e8eb0c44440','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58ec71988b2de342600d0acd6c9108302cf332e89249528fd8d6d16a2e860e02',1978,'SE','Sweden','people-and-society',490,'Population: 8,254,000 (January 1978), average annual
growth rate 0.2% (current)
Nationality: noun—Swede(s); adjective—Swedish
Ethnic divisions: homogeneous white population; small
Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant,
Roman Catholic, Eastern Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking
minorities
Literacy: 99%
Labor force: 4.0 million; 6.4% agriculture, forestry,
fishing; 29.2% mining and manufacturing; 7.2% construc-
tion; 13.6% commerce; 6.5% transportation and communica-
tions; 29.8% services including government; 5% banking,
83,000 or 2% unemployed September 1977
Organized labor: 80% of labor force','215da93d3a3a191f44d687d86711c9b9b0a38b607b31d6ef35e782e19d0af605','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3561b07ba089b7faabf7d4ae0a9fedf7d81f062c82dac201999fff79ce142418',1978,'CH','Switzerland','people-and-society',493,'Population: 6,307,000 (January 1978), average annual
growth rate 0.1% (1-72 to 1-77)
Nationality: noun—Swiss (sing. & pl.); adjective—Swiss
Ethnic divisions: total population—69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals—74% German, 20% French, 4% Italian, 1%
Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals—74% German, 20% French,
4% Italian, 1% Romansch, 1% other; total population—69%
German, 19% French, 10% Italian, 1% Romansch, 1% other
Literacy: 98%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 199
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Labor force: 3.0 million, about one-fifth foreign workers,
mostly Italian; 16% agriculture and forestry, 47% industry
and crafts, 20% trade and transportation, 5% professions, 2%
in public service, 10% domestic and other; approximately
0.4% unemployed in August 1975
Organized labor: 20% of labor force
Population: 7,973,000 (January 1978), average annual
growth rate 3.3% (7-75 to 7-76)
Nationality: noun—Syrian(s); adjective—Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians,
and other
Religion: 70.5% Sunni Muslim, 16.3% other Muslim sects,
13.2% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and
English widely understood
Literacy: about 40%
Labor force: 2 million; 67% agriculture, 12% industry
(including construction), 21% miscellaneous services; major-
ity unskilled; shortage of skilled labor
Organized labor: 5% of labor force','3c69e32ca1fb266c34b32f6bb4ded4a4d9f7497076e5c96d9fae60a0d91db0ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f6b6f2930e9ea9991faccb4db6b65001be3a135d7909f96a5e95e63484ac7a2',1978,'TH','Thailand','people-and-society',497,'Population: 44,790,000 (January 1978), average annual
growth rate 2.8% (7-70 to 7-76)
203
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Bay
of Bengal
. Gulf of
Indian Ocean Thailend
(See reference map Vil}
Nationality: noun—Thai (sing. & pl.); adjective—Thai
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 78% agriculture, 15% services, 7% industry','7cf30fd77d2b7fb572037bb61afbf05244f223f2d166eb2819582b5ddbea3d94','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b74d4818b962ffea764055ec16c49367367010c3be5efeb13ae50394ef1620f',1978,'TG','Togo','people-and-society',501,'Population: 2,371,000 (January 1978), average annual
growth rate 2.5% (7-74 to 7-76)
Nationality: noun—Togolese (sing. & pl.); adjective—
Togolese
Ethnic divisions: 37 tribes; largest and most important
are Ewe in south and Cabrais in north; under 1% European
and Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of com-
merce; major African languages are Ewe and Mina in the
south and Dagomba and Kabie in the north
Literacy: 54.9% of school age (7-14) currently in school
Labor force: over 90% of population engaged in
subsistence agriculture; about 30,000 wage earners, evenly
divided between public and private sectors
Organized labor: | national union, the CNTT organized
in 1972','1bfde387be125501fe65bf06ff4a14136f0bc9b6653a89f28e3c87f798b48d1e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e033c4b93ff35555206b29b873b24fc5cfa1fbf6320c177255f63e1c05b5728',1978,'TO','Tonga','people-and-society',505,'Population: 92,000 (January 1978), average annual
growth rate 1.5% (11-66 to 12-76)
Nationality: noun—Tongan(s); adjective—Tongan
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children
between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','c29208d7943059c76f0bcbd3bd51858af485b55990cc6ba9c564baa28885b39d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dac550af48dfa5323df16cf41827a26cfd62ea3f78a1e3ccd850d90e94f65c8b',1978,'TT','Trinidad and Tobago','people-and-society',509,'Population: 1,038,000 (January 1978), average annual
growth rate 1.3% (4-60 to 4-70)
Nationality: noun—Trinidadian(s), Tobagonian(s); adjec-
tive—Trinidadian
Ethnic divisions: 43% Negro, 40% East Indian, 14%
mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23.0%
Hindu, 6.0% Muslim, 13.0% unknown
Language: English
Literacy: 95%
Labor force: 393,800 (July 1975), 13.5% agriculture,
20.0% mining, quarrying, and manufacturing, 17.4% com-
merce; 15.7% construction and utilities; 7.5% transportation
and communications; 28.0% services, 2.9% other
Organized labor: 30% of labor force','5192d5a6c12dad292b2fec1be3e220d161498f00ee5666b47258f00295cdf14c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e74be49f1458f0b0e770d6de2d26c717c2eb7cf7d1d35135832fde6b2b84d20',1978,'TN','Tunisia','people-and-society',513,'Population: 5,936,000 (January 1978), average annual
growth rate 2.3% (7-75 to 7-76)
Nationality: noun—Tunisian(s); adjective—Tunisian
Ethnic divisions: 98% Arab, 1% European, less than 1%
Jewish
Religion: 95% Muslim, 4% Christian, 1% Jewish
Language: Arabic (official), Arabic and French
(commerce)
Literacy: about 32%
Labor force: 1.4 million; 45% agriculture, 19% manufac-
turing and construction, 5% trade and finance, 3%
transportation, communications, and utilities, 2% mining;
10%-20% unemployed; shortage of skilled labor
Organized labor: 10% of labor force; General Union of
Tunisian Workers (UGTT), quasi-independent of Destourian
Socialist Party
Population: 42,518,000 (January 1978), average annual
growth rate 2.6% (current)
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry,
16% service; substantial shortage of skilled labor; ample
unskilled labor
Organized labor: 10% of labor force
209
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
TURKEY/TUVALU','ee17d27c4b2bab441e412e6b2bc55e5859d4fa93485f65d3d1477bc58f289db5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d568e7be22f7b77f87e849f4ad727ee7643eb2ef71826cc9a18d8606755c28c',1978,'TV','Tuvalu','people-and-society',517,'Population: 6,000 (preliminary total from census of 8
December 1973)
Ethnic divisions: Polynesian
Religion: Protestant
Literacy: less than 50%
Population: 12,566,000 (January 1978), average annual
growth rate 3.5% (current)
Nationality: noun—Ugandan(s); adjective—Ugandan
Ethnic divisions: 99% African, 1% European, Asian, Arab
Religion: about 60% nominally Christian, 5%-10% Mus-
lim, rest animist
Language: English official; Luganda and Swahili widely
used; other Bantu and Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which about
250,000 in paid labor, remaining in subsistence activities
Organized labor: 125,000 union members
Population: 260,178,000 (January 1978), average annual
growth rate 0.9% (current)
Nationality: noun—Soviet(s); adjective—Soviet
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic
groups
Religion: 70% atheist, 18% Russian Orthodox, 9% Muslim,
3% other
Language: more than 200 languages and dialects (at least
18 with more than 1 million speakers); 76% Slavic group, 8%
other Indo-European, 11% Altaic, 3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 137 million (mid-year 1977), 25%
agriculture, 75% industry and other non-agricultural fields,
unemployed not reported, shortage of skilled labor reported
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
U.S.S.R','63ea7cd2a64225e84fded26de99fb9372858bc11b5196420701fab1bed6a2849','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('143f99475762dde758260ca1d71a84c7946bc1ff513b4e0b614457c039203087',1978,'AE','United Arab Emirates','people-and-society',521,'Population: 656,000 (preliminary total from the census of
29 August 1975)
Ethnic divisions: Arabs 42%, South Asians 50% (fluctuat-
ing), other expatriates (includes Westerners and East Asians
8%
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 25% est. (1975)
Labor force: 203,000 (1975 est.); 85% in industry; 2%
U.A.E. Arabs, 7% non-U.A.E. Arabs, 91% Indians, Pakistanis,
[ranians','74b149367e5aa9058292c7567c5b759481c4777593651e455c671a289a76b465','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5a6943f71314935ece4b97339e680a26a37e7c391ae3126c12f3c95b4868963',1978,'GB','United Kingdom','people-and-society',525,'Population: 55,925,000 (January 1978) average annual
growth rate —0.1% (current)
Nationality: noun—Briton(s), British (collective pl.);
adjective—British
Ethnic divisions: 83% English, 9% Scottish, 5% Welsh, 3%
Irish
Religion: 27.0 million Church of England, 5.3 million
Roman Catholic, 2.0 million Presbyterians, 760,000 Method-
ist, 450,000 Jews (registered)
Language: English, Welsh (about 26% of population of
Wales), Scottish form of Gaelic (about 60,000 in Scotland)
Literacy: 98% to 99%
Labor force: (1974) 25.6 million; 1.6% agriculture, 1.4%
mining, 30.7% manufacturing, 6.2% government, 7.2%
transportation and utilities, 5.2% construction, 10.6% dis-
tributive trades, 25.3% all services, 9.7% other, 2.1%
unemployed
Organized labor: 40% of labor force
Population: 6,446,000 (January 1978), average annual
growth rate 2.3% (current)
Nationality: noun—Upper Voltan(s); adjective—-Upper
Voltan
Ethnic divisions: more than 50 tribes; principal tribe is
Mossi (about 2.5 million); other important groups are
Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to
Sudanic family, spoken by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active
population engaged in animal husbandry, subsistence
farming, and related agricultural pursuits; about 30,000 are
wage earners; about 20% of male labor force migrates
annually to neighboring countries for seasonal employment
Organized labor: 4 principal trade union groups','5ee293b71fb361c41c0ac2cc66866c0bbc4fc77dfdc953bb929c627f201d3fb2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df35d78b62346773adb6b88423946973428ce460781967490e383faf9c0a6c7c',1978,'UY','Uruguay','people-and-society',529,'Population: 2,803,000 (January 1978), average annual
growth rate 0.5% (10-63 to 5-75)
Nationality: noun—Uruguayan(s); adjective—Uruguayan
Ethnic divisions: 85%-90% white, 5% Negro, 5%-10%
mestizo
Religion: 66% Roman Catholic (less than half adult
population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed
in important sectors—25% government; 34% industry; 10%
service, 23% other; 8% agriculture, forestry, fishing and
mining; no shortage of skilled labor
Organized labor: about 25% of labor force
Population: 1,000 (official estimate for 1 July 1976)
Ethnic divisions: primarily Italians but also many other
nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees
divided into 3 categories—executives, officeworkers, and
salaried employees
Organized labor: none
Population: 12,929,000, excluding Indian jungle popula-
tion, (January 1978), average annual growth rate 3.0%
(current)
Nationality: noun—Venezuelan(s); adjective—Vene-
zuelan
Ethnic divisions: 67% mestizo, 21% white, 10% Negro,
2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Labor force: 3.7 million (1975); 24% agriculture, 6%
construction, 17% manufacturing, 6% transportation, 18%
commerce, 25% services, 4% petroleum, utilities, and other
Organized labor: 45% of labor force
Population: 50,569,000 (January 1978), average annual
growth rate 2.5% (current); Vietnam, North, 25,841,000,
average annual growth rate 2.5% (current); Vietnam, South,
24,728,000, average annual growth rate 2.5% (current)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Nationality: noun—Vietnamese (sing. & pl.); adjective—
Vietnamese
Ethnic divisions: 85%-90% predominantly Vietnamese;
3% Chinese; ethnic minorities include Muong, Thai, Meo,
Khmer, Man, Cham, and mountain tribesman
Religion: Buddhism, Confucianism, Taoism, Catholicism,
Animism, Islam, and Protestantism
Language: Vietnamese, French, Chinese, English, Khmer,
tribal: languages (Mon-Khmer and Malayo-Polynesian)
Labor force: approximately 15 million, not including
military; about 70% agriculture and 8% industry','2557d9923d2c83fbe7bfe651dd3a570de5283d7dc05d03ea7bfad1844af96971','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d768cc3c2b54579bac2f2f8751038634f10922b551638c79a9583855585e6b46',1978,'WF','Wallis and Futuna','people-and-society',533,'Population: 9,000 (official estimate for | July 1973)
Nationality: noun—Wallisian(s), Futunan(s), or Wallis
and Futuna Islander; adjective—Wallisian, Futunan, or
Wallis and Futuna Islanders
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','88b20bba163558704297acdd37ba9c0657905f1157ac68a8fd6fddff175a677a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45e9abfd8761223735693fe2f3064962c17ba946ad2f7820951989106c10961b',1978,'EH','Western Sahara','people-and-society',537,'Population: 128,000 (official estimate for 1 July 1976)
Nationality: noun—Saharan(s); adjective—Saharan
Ethnic divisions: Arab, Berber, and Negro nomads
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Religion: Muslim
Language: local Arabic or Hassania
Literacy: among Spanish, probably nearly 100%; among
nomads, perhaps 5%
Labor force: 12,000; 50% agriculture, 50% other
Organized labor: none
Population: 152,000 (January 1978), average annual
growth rate 0.6% (11-71 to 11-76)
Nationality: noun—Western Samoan(s); adjective—West-
ern Samoa
Ethnic divisions: Polynesians, about 12,000 Euronesians
(persons of European and Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of population
associated with the London Missionary Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all children
from 7-15 years)
Labor force: agriculture 19,148; mining and manufactur-
ing 1,716 (1961)
Organized labor: unorganized
Population: 1,831,000, excluding the islands of Perim and
Kamaran for which no data are available (January 1978),
average annual growth rate 3.1% (5-73 to 7-76)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: almost all Arabs; a few Indians, Somalis,
and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 5,721,000 (January 1978), average annual
growth rate 3.0% (current)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding
Population: 21,855,000 (January 1978), average annual
growth rate 0.9% (current)
Nationality: noun—Yugoslav(s); adjective—Yugoslav
Ethnic divisions: 39.7% Serb, 22.1% Croat, 8.4% Muslims,
8.2% Slovene, 5.8% Macedonian, 2.5% Montenegrin, 6.4%
Albanian, 2.3% Hungarian, 4.6% other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic,
12% Muslim, 3% other, 12% none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Alba-
nian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 13.5 million (1970); 49.6% agriculture, 16%
mining and manufacturing, 34.4% other nonagricultural
activities; reported unemployment averaged 8% of regis-
tered labor force (social sector) in 1967
Population: 26,724,000 (January 1978), average annual
growth rate 2.8% (7-70 to 7-76)
Nationality: noun—Zairian(s); adjective—Zairian
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes—Mongo, Luba,
Kongo (all Bantu), and the Mangbetu-Azande (Hamitic)
make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo,
and Chiluba are all classified as official languages
Literacy: 5% fluent in French, about 35% have a
acquaintance with French ;
Labor force: about 8 million, but only about 13% in wage
structure','b294f791c69696fc792af6f360903b52dc88b63b9994ae1f995e3aef3bdc8827','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3eec1e352b7d2a38853658a8ea75a964dc5a5e6cb97a6727f120cd3b0184923',1978,'ZM','Zambia','people-and-society',541,'Population: 5,383,000 (January 1978), average annual
growth rate 3.2% (7-75 to 7-76)
Nationality: noun—Zambian(s); adjective—Zambian
Ethnic divisions: 98.7% African, 1.1% European, 0.2%
other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans,
27,000 non-Africans; 15% mining, 9% agriculture, 9%
domestic service, 19% construction, 9% commerce, 10%
manufacturing, 23% government and miscellaneous services,
6% transport
Organized labor: 100,000 wage earners, primarily in
industrial sector, are unionized (early 1968)','2864b1da212d9487cf5c75481e0b6655e01ef1145ba1ca9e21c695ad72f2f569','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('118065aec34106a32b332a5da96c7b3a106e1aea911df321fc194d99b1190639',1978,'US','United States','people-and-society',545,'Population: 217,799,000 (January 1978), average annual
growth rate 0.8% (current)
Ethnie divisions: 86.9% white, 11.4% black, 1.7% other
Religion: total membership in religious _ bodies,
131,434,000; Protestant 71,649,000, Roman Catholic
48,460,000, Jewish 6,115,000, other religions 3,841,361
Language: English, predominantly
Literacy: almost complete
Labor force: 91 million (1974)
Organized labor: 24.2% of total (1974)','8647481b82cbca334b09d03ac713ccd292abb90b67bdc3bfbaa80543a0b873e5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e35670b76e51b01e19f472de50b27564b4dabcc979e26861f94dfa5dd0c3b34',1978,'AF','Afghanistan','people-and-society',4,'Population: 14,381,000 (July 1978), average annual
growth rate 2.2% (current)
Nationality: noun—Afghan(s); adjective—Afghan
Ethnic divisions: 50% Pushtuns, 25% Taiiks, 9% Uzbeks,
9% Hazaras; minor ethnic groups include Chahar Aimaks,
Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim, 1% other
Language: 50% Pushtu, 35% Afghan Persian (Dari), 11%
Turkic languages (primarily Uzbek and Turkmen), 10%
thirty minor languages (primarily Baluchi and Pashai); much
bilingualism
Literacy: under 10%
Labor force: about 5.75 million (FY77 est.); 75%-80%
agriculture and animal husbandry, 20%-25% commerce,
small industry, services; massive shortage of skilled labor
Organized labor: none','d8d8d0ce1982beccd593418a45f04d6fa12d16d8d6335c938e3c8419bfc8ee57','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('976a026f1c24fa7bd2ac69dc7de793c2019dc0b0c7a4d73ae0295d322055bb43',1978,'AL','Albania','people-and-society',9,'Population: 2,569,000 (July 1978), average annual growth
rate 2.2% (current)
Nationality: noun—Albanian(s); adjective—Albanian
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox, 10%
Roman Catholic; observances prohibited; Albania claims to
be the world’s first atheist state
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics avail-
able, but probably greatly improved
Labor force: 911,000 (1969); 60.5% agriculture, 17.9%
industry, 21.6% other nonagricultural','af44534d847d7b08a54b364d1fa65b6cf7fd9636aa2f0ce3c8498bba7b47d32b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ba9115a96988c3905594722e72117f33144c8dbecae515a0c62834faaeebaf7',1978,'DZ','Algeria','people-and-society',13,'Population: 17,639,000 (July 1978), average annual
growth rate 3.4% (current)
Nationality: noun—Algerian(s); adjective—Algerian
Ethnic divisions: 99% Arab-Berbers, less than 1%
Europeans
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Approved For Release 2005/04/22
Atlantic
Ocean
o
Mi editerra neg, ny SEI
O98
(See reference map V)
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 4.0 million; 50% agriculture, 20% industry,
25% other (military, police, civil service, transportation
workers, teachers, merchants, construction workers); at least
20% of urban labor unemployed
Organized labor: 25% of labor force claimed; General
Union of Algerian Workers (UGTA) is the only labor
organization and is subordinate to the National Liberation
Front','03d850e03bc121179648fdbee455912ca5e6353a7d33f1a9d4fac49a8c53837b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d02f8e472c89d577779b139cacb464548982d9bd5c1ef48a24ec75d72e801fbc',1978,'AD','Andorra','people-and-society',17,'Population: 29,000 (official estimate for 1 July 1976)
Nationality: noun—Andorran(s);_ adjective—Andorran
Ethnic divisions: Catalan stock; 30% Andorrans, 61%
Spanish, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French and
Castilian
Labor force: unorganized; largely shepherds and farmers','88e27a0c260939e24abf197d7541d81443868342c7fcc96015fe76083b20421f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20df7bb7ceedf2290b053522b47ec6be17fe5022c9fc529cb35614273f99bb49',1978,'AO','Angola','people-and-society',21,'Population: Angola (including Cabinda), 6,449,000 (July
1978), does not take into account emigration from Angola,
average annual growth rate 2.4% (current); Cabinda,
103,000 (July 1978); average annual growth rate 3.3% (12-60
to 12-70)
Nationality: noun—Angolan(s); adiective—Angolan
Ethnic divisions: 93% African, 5% European, 1% mestizo
Approved For Release 2005/04/22
Atlantic
Ocean
{See reference map VI}
Religion: about 84% animist, 12% Roman Catholic, 4%
Protestant
Language: Portuguese (official), many native dialects
Literacy: 10-15%
Labor force: 2.6 million economically active (1964);
531,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)','b20ca78878c301d13be9ebbd59bd21469cdf28637a57971a79fe45f5d06bfc88','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b8de1396d9e225b6db1c847308eb7e0772ad20b668dfd7e788db678ac39d421',1978,'PR','Puerto Rico','people-and-society',25,'Population: 73,000 (July 1978), average annual growth
rate 1.3% (7-70 to 7-77)
Nationality: noun—Antiguan(s); adjective—Antiguan
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other
Protestant sects, and some Roman Catholic
Language: English
Literacy: about 80%
Organized lakor: 18,000, 20% unemployment','4acf792ed39b4a8d36245851d990d3c88efceba1634dd7a3f1f042213e32d29a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a14901305a03c90c3bcecc48b3030969b4aaa2d58c89d9b6428027d2ac856cef',1978,'AR','Argentina','people-and-society',29,'Population: 26,487,000 (July 1978), average annual
growth rate 1.3% (current)
Nationality: noun—Areentine(s); adjective—Argentine
Ethnic divisions: approximately 85% white, 15% mestizo,
Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic (less than 20%
practicing), 2% Protestant, 2% Jewish, 6% other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
Labor force: 10 million; 19% agriculture, 25% manufac-
turing, 20% services, 11% commerce, 6% transport and
communications, 19% other; 4-5% estimated unemployment
Organized labor: 25% of labor force (est.)','8ae36286c9b05ed718283f2fdef658882755cbbc2dc61273ab1f2e1d88010b0e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07758c829c9799f164097a4d0d14bdb3c9594b71fba8d625d610eaa0b2d805c6',1978,'AU','Australia','people-and-society',33,'Population: 14,227,000 (July 1978), average annual
growth rate 1.1% (current)
Nationality: noun—Australian(s); adjective—Australian
Ethnic divisions: 99% Caucasian, 1% Asian and aborigine
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Indian Ocean
NEW ZEALAND SH
(See reference map Viti}
Religion: 98% Christian
Language: English
Literacy: 98.5%
Labor force: 6 million; 14% agriculture, 32% industry,
37% services, 15% commerce, 2% other; 6% unemployment
Organized labor: 44% of labor force','353886fd6bec7007eaf89a2be9c9bb91208e395588f612bd5cb58986df4aa2c9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c74ee60b9209cb85481e1b6830e6e4720c343fb82ad5380762b132c097f73b0',1978,'AT','Austria','people-and-society',38,'Population: 7,517,000 (July 1978), average annual growth
rate 0.0% (1-77 to 1-78)
Nationality: noun—Austrian(s); adjective—Austrian
Ethnic divisions: 98.1% German, 0.7% Croatian, 0.3%
Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8% none or
other
Language: German
Literacy: 98%
10
Labor force: 2,784,635 (1977); 18% agriculture and
forestry, 49% industry and crafts, 18% trade and communi-
cations, 7% professions, 6% public service, 2% other; 2.4%
registered unemployed; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in
Austria number more than 200,000 (1972); unemployment
1.2% (September 1977)
Organized labor: about two-thirds of wage and salary
workers (1971)
Population: 226,000 (July 1978), average annual growth
rate 2.8% (7-76 to 7-77)
Nationality: noun—Bahamian (sing., pl.); adjective—
Bahamian
Ethnic divisions: 80% Negro, 10% white, 10% mixed
Religion: Baptists 29%, Church of England 23%, Roman
Catholic 23%, smaller groups of other Protestant, Greek
Orthodox, and Jews
Language: English
Labor force: 84,228 (1976), 25% organized; 25% unem-
ployment (1977)','55e9c6a7d0518f6a64cefbc7a1d8c02422e1c5a526431aeb9fa9dae0834158a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa0c206eee1e50a3126f076ffc9bc5560ee08b924dae166519ac23b9886268ee',1978,'BH','Bahrain','people-and-society',42,'Population: 284,000 (July 1978), average annual growth
rate 3.5% (7-75 to 7-76)
Nationality: noun—Bahraini(s); adjective—Bahraini
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani, and
Indian, 3% other; native Bahrainis are a minority
Religion: Muslim
Language: Arabic, English also widely spoken
Literacy: about 40% (1970)
Labor force: 78,507 (1976)','03528be74bafec823b6821ed11df332ba8da7fa3c0d38de2f4e2a9ac0232d423','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6ee248a99ac31a476c2931beb2e27ac719df94b1f43bb414d2a4c8de96e195d',1978,'BD','Bangladesh','people-and-society',46,'Population: 85,771,000 (July 1978), average annual
growth rate 2.7% (current)
adjective—Bangla-
Nationality: noun—Bangladeshi(s);
desh
Ethnic divisions: predominantly Bengali; fewer than 1
million “Biharis” and fewer than 1 million tribals
Religion: about 83% Muslim, 16% Hindu; less than 1%
Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 26 million; extensive underemploy-
ment; over 80% of labor force is in agriculture
13
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
10006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009000
July 1978
BANGLADESH /BARBADOS','dabb4f9011749c41cf758c04e30b79d16b96ea2db452ff97404f882a90633c24','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec2476a1693a1eb7a949d8ac615f756b6008766196e5ffe8c5e9fbc0e2036539',1978,'BB','Barbados','people-and-society',50,'Population: 258,000 (July 1978), average annual growth
rate 1.5% (1-76 to 1-77)
Nationality: noun—Barbadian(s);. adjective—Barbadian
Ethnic divisions: 80% African, 17% mixed, 4% European
Religion: Anglican (70%), Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1978 est.) wage and salary earners;
unemployment 20-25% (1976)
Organized labor: 32%','8b4c4494e47c777292a924988191db62c580301053a89644c5cb5e2cd01439ed','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2ec4c4d7a422a42cbfb4cf49b220c42d7d842f8ef679f0e3d336bd8baf46131',1978,'BE','Belgium','people-and-society',54,'Population: 9,835,000 (July 1978), average annual growth
rate 0.0% (current)
Nationality: noun—Belgian(s); adjective—Belgian
Ethnic divisions: 55% Flemings, 33% Walloons, 12%
mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in small
area of eastern Belgium; divided along ethnic lines
Literacy: 97%
Labor force: 4.04 million; approximately 95% is found in
the following sectors: 32% manufacturing, 24% services, 16%
commerce, banking, and insurance, 8% construction, 7.5%
transportation and communication, 3.4% agriculture, for-
estry, and fishing, 1.2% mining, 0.8% public utilities and
sanitary services (1972): 9.7% of insured workers and 7.2% of
the total work force unemployed, March 1978
Organized labor: 48% of labor force (1969)','e20804d345ad702fec44897559e69a7012a874fbbd357dc84eb6f8d732a2c18d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0273fe6ec8b8322f37fb7554caebc0961ecea12aa371a4751a7122dba6792fa0',1978,'MX','Mexico','people-and-society',59,'Population: 152,000 (July 1978), average annual growth
rate 2.9% (current)
Nationality: noun—Belizean(s); adjective—Belizean
Ethnic divisions: 51% Negro, 22% mestizo, 19% Amerin-
dian, 8% other
Religion: 50% Roman Catholic; Anglican, Seventh-day
Adventist, Methodist, Baptist, Jehovah’s Witnesses, Men-
nonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,500; 89% agriculture, 14% manufactur-
ing, 8% commerce, 12% construction and transport, 20%
services, 7% other; shortage of skilled labor and all types of
technical personnel; over 15% are unemployed
Organized labor: 8% of labor force
Population: 6,621,000 (January 1978), average annual
growth rate 2.9% (7-76 to 7-77)
Nationality: noun—Guatemalan(s); adjective-—Guatema-
lan
Ethnic divisions: 41.4% Indian, 58.6% Ladino (mestizo
and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the population speaks
an Indian language as a primary tongue
Literacy: about 30%
Labor force (1974): 1.8 million, 52.5% agriculture, 10.1%
manufacturing, 21.7% services, 7.9% commerce, 8.9%
construction, 2.1% transport, 0.7% mining, 1.2% electrical,
0.8% other. Unemployment estimates vary from 3% to 25%
Organized labor: 6.4% of labor force (1975)
Population: 65,833,000 (July 1978), average annual
growth rate 3.4% (current)
Nationality: noun—Mexican(s); adjective—Mexican
Ethnic divisions: 60% mestizo, 30% Indian or predomi-
nantly Indian, 9% white or predominantly white, 1% other
Religion: 97% nominally Roman Catholic, 3% other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force: 16.5 million (1977) (defined as those 12 years
of age and older); 39.5% agriculture, 16.7% manufacturing,
16.6% services, 16.8% construction, utilities, commerce, and
transport, 3% government, 7.4% unspecified activities; 9%
unemployed, 40% underemployed
Organized labor: 20% of total labor force','7976921c8956ffcadd009c1cd9b83485ccea6174874a451ec85d05248180b11e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7ecbb8b88b7efe6287930486784c5b7929414ee75ba906f81f2b6e7937cd462',1978,'BJ','Benin','people-and-society',63,'Population: 3,376,000 (July 1978), average annual growth
rate 2.7% (7-70 to 7-77)
Nationality: noun—-Beninese (sing. & pl.); adjective—
Beninese
Ethnic divisions: 99% Africans (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba), 5,500
Furopeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most
common vernaculars in south, at least 6 maior tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in agriculture;
15% civil service, artisans, and industry
Organized labor: approximately 75% of wage earners,
divided among two major and several minor unions','14898ca15170bbfb36f40eb534f0b7eb0ba21fcda1e7129eaad43d95b90765c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb0ada76dbd739ad7efd02eba63dd7e7c57f798c74bf0ef37b2ec64b588138e7',1978,'BM','Bermuda','people-and-society',67,'Population: 57,000 (July 1978), average annual growth
rate 1.2% (7-70 to 7-76)
Nationality: noun—Bermudan(s); adjective—Bermudan
Ethnic divisions: approximately 63% African, 37% white
Religion: 47.5% Church of England, 38.2% other Protes-
tant, 10.2% Catholic, 4.1% other
Language: English
Literacy: virtually 100%
Labor force: 25,200 (1975)
19
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
BERMUDA/BHUTAN','b3d20e2fc62ecf81c1f36d2d396f4caa6f77e8810984a0c6e5122c6c95357d25','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad97acb17bbf0af78ff59203b2b6acf55d2f856bc5f164fbdf5955c3296a8bc8',1978,'BT','Bhutan','people-and-society',71,'Population: 1,262,000 July 1978), average annual growth
rate 2.5% (current)
Nationality: noun—Bhutanese (sing., pl.); adjective—
Bhutanese
Ethnic divisions: 60% Bhotias, 25% ethnic Nepalese, 15%
indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25%
influenced Hinduism
Buddhist-
Language: Bhotias speak various Tibetan dialects, most
widely spoken dialect is Dzongkha, the official language;
Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1% industry;
massive lack of skilled labor
Population: 5,081,000 (July 1978), average annual growth
rate 2.6% (current)
(See reference map tt)
Nationality: noun—Bolivian(s); adjective—Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35% mestizo,
5%-15% white
Religion: predominantly Roman Catholic; active Protes-
tant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 35%-40%
Labor force: 2.8 million (1977); 70% agriculture, 3%
mining, 10% services and utilities, 7% manufacturing, 10%
other
Organized labor: 150,000-200,000, concentrated in min-
ing, industry, construction, and transportation','6bb76ee46c4009dd5f52098c832b459927cf115cfefb6aa1a81a3b2dafdb8e49','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('326118ef5d2217a72a56cba4e3839d1b748ab7dc3afdfb1147b16ad74167d430',1978,'BW','Botswana','people-and-society',75,'Population: 750,000 (July 1978), average annual growth
rate 2.6% (current)
Nationality: noun—Botswana (sing.), Batswana (pl.);
adjective—Botswana
Ethnic divisions: 94% Tswana, 5% Bushmen, 1% Euro-
pean
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Literacy: about 22% in English; about 82% in Tswana: less
than 1% secondary school graduates
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
BOTSWANA/BRAZIL
Indian
Ocean
Atlantic
Ocean
(See reference map V1)
Labor force: 385,000; most are engaged in cattle raising
and subsistence agriculture; about 51,000 in internal cash
economy, another 60,000 spend at least 6 to 9 months per
year as wage earners in South Africa (1971)
Organized labor: eight trade unions organized with a total
membership of approximately 9,000 (1972 est.)','606af4ec6a136a875fca4b3fca9c7ade8731e90e7804b178148b230de55334da','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0dfa8870c496dcc7f46467f196fc8aefe4521ae40604c638910f4d9e86c0d895',1978,'BR','Brazil','people-and-society',79,'Population: 115,415,000 (July 1978), average annual
growth rate 2.8% (current)
Nationality: noun—Brazilian(s); adjective—Brazilian
Ethnic divisions: 60% white, 30% mixed, 8% Negro, and
2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 83% of the population 15 years or older (1978)
Labor force: about 30 million in 1970 (est.); 44.2%
agriculture, livestock, forestry, and fishing, 17.8% industry,
15.3% services, transportation, and communication, 8.9%
commerce, 4.8% social activities, 3.9% public administration,
5.1% other
Organized labor: about 50% of labor force; only about 1.5
million pay dues
Population: 177,000 official estimate for 1 July 1976
Nationality; noun—Bruneian(s); adjective—Bruneian
Ethnic divisions: 52% Malays, 28% Chinese, 15%
indigenous tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8%
Christian; 32% other (Buddhist and animist)
Language: Malay and English official, Chinese
Literacy: 45%
que}
NAM .&
f)
South China Sea
BRUNE
(See reference map Vil)
Labor force: 32,155; 30.5% agriculture; 32.8% industry,
manufacturing, and construction; 33.8% trade, transport,
services; 2.9% other
Organized labor: 8.4% of labor force
Population: 813,000 (July 1978), average annual growth
rate 1.3% (current)
Nationality: noun—Guyanese (sing., pl.); adjective—
Guyanese
Ethnic divisions: 51% East Indians, 43% Negro and
Negro mixed, 4% Amerindian, 2% white and Chinese
Religion: 57% Christian, 33% Hindu, 9% Muslim, 1%
other
Language: English
Literacy: 86%
Labor force: 242,000 (1975); 29% agriculture, 31%
manufacturing/mining, 40% services; 21% unemployed
Organized labor: 34% of labor force','7e3ed134b81885e3bd083f51d5d424e505369d8777b68a635020276632224b21','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13b15feb5caf52f32926154da3386c53c0c2207439a78356b5b4245cada50716',1978,'BG','Bulgaria','people-and-society',83,'Population: 8,848,000 (July 1978), average annual growth
rate 0.5% (current)
Nationality: noun—Bulgarian(s); adjective—Bulgarian
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks, 2.6%
Gypsies, 2.5% Macedonians, 0.3% Armenians, 0.2% Russians,
0.6% other
Religion: regime promotes atheism; religious background
of population is 85% Bulgarian Orthodox, 13% Muslim, 0.8%
Jewish, 0.7% Roman Catholic, 0.5% Protestant, Gregorian-
Armenian and other
Language: Bulgarian; secondary languages closely corre-
spond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 5.0 million (1974); 32% agriculture, 33%
industry, 35% other
Population: 32,205,000 (July 1978), average annual
growth rate 2.2% (7-76 to 7-77)
Nationality: noun—Burman(s); adjective—Burmese
Ethnic divisions: 72% Burman, 7% Karen, 6% Shan, 2%
Kachin, 2% Chin, 2% Chinese, 3% Indian, 6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have their
own languages
Literacy: 70% (official claim)
Labor force: 12.2 million (1976); 67% agriculture, 13%
industry, 20% services, commerce, and transportation
Organized labor: no figure available; old labor organiza-
tions have been disbanded, and government is forming one
central labor organization','b72e0876a465c20ec233877ca58a76835644b9119cce6b453cecab9aaf9709a5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf5a17ee0af52466e416b328535bdd2c66a141f86dc2dee3a372d3f5bfc11f2b',1978,'BI','Burundi','people-and-society',87,'Population: 4,212,000 (July 1978), average annual growth
rate 2.4% (current)
Nationality: noun—Burundian(s); adjective—Burundian
Ethnic divisions: Africans—85% Hutu (Bantu), 14% Tutsi
(Hamitic), 1% Twa (Pigmy); other Africans include perhaps
50,000 Zairians and 40,000 Rwandans; non-Africans include
about 3,000 Europeans and 1,000 South Asians
Religion: about 60% Christian (53% Catholic, 7%
Protestant); rest mostly animist plus perhaps 2% Muslims
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
BURUNDI/CAMBODIA
July 1978
Language: Kirundi and French official plus Swahili
(along Lake Tanganyika and in the Bujumbura area)
Literacy: about 15% in Kirundi, 3% in French, no
serviceable estimate for Kiswahili
Labor force: about 2 million (1976 est.)
Organized labor: sole group is the Union of Burundi
Workers (UTB); by charter, membership is extended to all
Burundi workers (informally), figures denoting “active
membership” have been unobtainable','96028827d72c8b7795c3479cb1e09eb0076e1584a5fcea1d5d457720d0784544','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2f19437aa742d2a66422c54b59c9a944305ebdf7fbe6e1a31747e49d05aed9f',1978,'KH','Cambodia','people-and-society',91,'Population: 8,148,000 (July 1978), average annual growth
rate 2.2% (7-68 to 7-69)
Nationality: noun—Cambodian(s) or Khmer (sing., pl.):
adjective—Cambodian or Khmer
Ethnic divisions: 90% Khmer (Cambodian), 5% Chinese,
5% other minorities
Religion: 95% Theravada Buddhism, 5% various other
Language: Cambodian','9b5201fb3aad69cfd8e5d24a031aaf320d5074654223ec38e2de1aac64e51afd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efc5d589f5ea59fdfe27de640b39ef753b2307363af8e7138beab97d1bd2e47a',1978,'CM','Cameroon','people-and-society',95,'Population: 8,008,000 (July 1978), average annual growth
rate 2.0% (current)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
i th TT CSS
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
CAMEROON/CANADA
Nationality: noun—Cameroonian(s); adjective —Came-
roonian
Ethnic divisions: about 200 tribes of widely differing
background; 31% Cameroon Highlanders, 19% Equatorial
Bantu, 8% Northwestern Bantu, 10% Fulani, 7% Eastern
Nigritic, 11% Kirdi, 13% other African, less than 1%
non-African
Religion: about one-half animist, one-third Christian; rest
Muslim
Language: English and French official, 24 major African
language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in subsistence
agriculture and herding; 200,000 wage earners (maximum)
including 22,000 government employees, 63,000 paid
agricultural workers, 49,000 in manufacturing
Organized labor: under 45% of wage labor force','d120eaa3435fe687ed806bb933c7eace447fa45e20f4fb1b15e19d8744d3c749','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3da433f5f7c748b57a0fe05b22b7fb1b1bbf9077b07538ed96a6ca8b55b180c',1978,'CA','Canada','people-and-society',99,'Population: 23,632,000 (July 1978), average annual
growth rate 1.4% (current)
Nationality: noun—Canadian(s); adjective—Canadian
Ethnic divisions: 44% British Isles origin, 30% French
origin, 26% other
Religion: 48% Protestant, 47% Catholic, 5% other
Language: English and French official
Labor force: 10.3 million; 29% service, 22% manufactur-
ing, 16% trade, 8% transportation and utilities, 6% agricul-
ture, 6% construction, 8% other; 8.6% unemployed (March
1978)
Organized labor: 30% of labor force
Population: 315,000 (July 1978), average annual growth
rate 1.9% (12-70 to 7-76)
Nationality: adjective—Cape Verdian
CAPE VERDE
ive]
Yo
Re
GUINEA-
BISSAU
v
Atlantic Ocean
{See reference map IV)
Ethnic divisions: about 28% African; 70% mulatto; 2%
European
Religion: Catholicism, fused with local superstitions
Language: Portuguese and crioula, a blend of Portuguese
and West African words
Literacy: 14%
Labor force: bulk of population engaged in subsistence
agriculture
Population: 1,912,000 (July 1978), average annual growth
rate 2.3% (current)
34
Nationality: noun—Central African(s); adjective—Cen-
tral African
Ethnic divisions: approximately 80 ethnic groups, the
majority of which have related ethnic and_ linguistic
characteristics; Banda (32%) and Baya-Mandjia (29%) are
largest single groups; 6,500 Europeans, of whom 6,000 are
French and majority of the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 27% animist, 5%
Muslim; animistic beliefs and practices strongly influence
the Christian majority
Language: French official; Sangho, lingua franca and
national language
Literacy: estimated at 5%-10%
Labor force: about half the population economically
active, 80% of whom are in agriculture; approximately
64,000 salaried workers
Organized labor: 1% of labor force','eb13b8bff94489daeddad13a903015d8f5a15c95394fae71192e76981eb0338e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc0a64c90b72b5d9017bd84cdeb49e2767de157b0e77664e111395d2361052e6',1978,'TD','Chad','people-and-society',103,'Population: 4,289,000 (July 1978), average annual growth
rate 2.1% (7-72 to 7-76)
Nationality: noun—Chadian(s); adiective—Chadian
Ethnic divisions: over 240 tribes representing 12 major
ethnic groups—Muslims (Arabs, Toubou, Fulani, Kotoko,
Hausa, Kanembou, Baguirmi, Boulala, and Wadai) in the
north and center and non-Muslims (Sara, Mayo-Kebbi, and
Chari) in the south; some 150,000 nonindigenous, 5,000 of
them French
Religion: about half Muslim, 5% Christian, remainder
animist
Language: French official; Chadian Arabic is lingua
franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in economically
active group, of which 90% are engaged in unpaid
subsistence farming, herding, and fishing; 47,000 wage
earners in industry and civil service
Organized labor: about 20% of wage labor force','4dcf9fcb30133c15148b23e18bdfba9d2a476d6119b2ee22419225e359bb9556','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71b23a6597fec373f3916f191b844d0760f88e0d76d7df19f009feab19b4e1a7',1978,'CL','Chile','people-and-society',107,'Population: 10,689,000 (July 1978), average annual
growth rate 1.5% (current)
Nationality: noun—Chilean(s); adjective—Chilean
Ethnic divisions: 95% European stock and mixed
European with some Indian admixture, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 90% (1976)
Labor force: 3.7 million economically active (1977); 30%
agricultural, 29% industry and construction, 7% services,
10% commerce, 7% mining, 9% transportation, 8% other
(1977)
Organized labor: 25% of labor force (1973)
Population: 1,003,855,000 (July 1978), average annual
growth rate 2.0% (current)
38
Nationality: —noun—Chinese
Chinese
Ethnic divisions: 94% Han Chinese; 6% Chuang, Uighur,
Hui, Yi, Tibetan, Miao, Manchu, Mongol, Pu-I, Korean, and
numerous lesser nationalities
(sing., pl.); adjective—
Religion: most people, even before 1949, have been
pragmatic and eclectic, not seriously religious; most impor-
tant elements of religion are Confucianism, Taoism,
Buddhism, ancestor worship; about 2%-3% Muslim, 1%
Christian
Language: Chinese (Mandarin mainly; also Cantonese,
Wu, Fukienese, Amoy, Hsiang, Kan, Hakka dialects), and
minority languages (see ethnic divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85% agriculture,
15% other; shortage of skilled labor (managerial, technical,
mechanics, etc.); surplus of unskilled labor','b12e31655180f3d870451ef1a348539cf9f52206d3ce1fd8d01a1ec04dbdda87','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d94f0214bf9ed7b23d792cd74397d83ea302ffacc6613a01539f01f3c796c027',1978,'CN','China','people-and-society',111,'Population: 16,985,000, excluding the population of
Quemoy and Matsu Islands and foreigners (July 1978),
average annual growth rate 2.0% (1-74 to 1-77)
Nationality: (sing., pl.);
Chinese
noun—Chinese adijective—
39
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CHINA, REPUBLIC OF
Ethnic divisions: 84% Taiwanese, 14% mainland Chinese,
2% aborigines
Religion: 93% mixture of Buddhism, Confucianism, and
Taoism; 4.5% Christian; 2.5% other
Language: Chinese Mandarin (official language), also
Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 6.12 million (1978); 26.2% primary industry
(agriculture), 39% secondary industry (including manufac-
turing, mining, construction), 34.8% tertiary industry (in-
cluding commerce and services) 1977; 2% unemployment
(1976)
Organized labor: about 12% of 1972 labor
(government controlled)
force
Population: 38,869,000 (July 1978), average annual
growth rate 1.7% (current)
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: homogeneous; small Chinese minority
(approx. 20,000)
Religion: strong Confucian tradition; pervasive folk
religion (Shamanism); vigorous Christian minority (16.6%
Christian population); Buddhism (including estimated
20,000 members of Soka Gakkai); Chondokyo (religion of
the heavenly way), eclectic religion with nationalist over-
tones founded in 19th century, claims about 1.5 million
adherents
Language: Korean
Literacy: about 90%
Labor force: about 12.6 million (1976); 45% agriculture,
fishing, forestry; 22% mining and manufacturing; 33%
services and other
Organized labor: about 10% of nonagricultural labor
force','eea88c58ec33a290f7dbd75c648f7f6149c915fd8555fabf890f30840c6ce12c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e11c964d90afdfa0da6768aa15d0d3046d758fbad9953de03a6f2c6734168ed',1978,'CO','Colombia','people-and-society',115,'Population: 25,559,000 (July 1978), average annual
growth rate 2.2% (current)
Nationality: noun——Colombian(s); adjective—Colombian
Ethnic divisions: 58% mestizo, 20% caucasian,
mulatto, 4% Negro, 3% mixed Negro-Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture, 13%
manufacturing, 18% services, 9% commerce, 13% other
(1964); 10%-13% unemployment (1975)
Organized labor: 138% of labor force (1968)
Approved For Rel
ease 2005/04/22 : CIA-RD
: -RDP79-01051A000900
010006-2','171cb5797012f098aea58f5b986d08bb628dc9ca8596af0b2e978c5828147e5a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18ee7ce98a983435bb25a8cca2bcc235dd5899cdbac548d527d22e2b66c4b7c5',1978,'KM','Comoros','people-and-society',119,'Population: 317,000 (July 1978), average annual growth
rate 2.1% (current)
Nationality; noun—Comoran(s). adjective—Comoran
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: Presumably Jow
Labor force: mainly agricultural
Population: 62,000 (July 1978), average annual growth
rate 2.1% (7-70 to 7-76)
Nationality: noun—Seychellois (sing. & pl.); adjective—','de09aca296b37f5482d9f8eda9a1e26fed8d07bf3b5a2be153977c7de6b7ee76','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0affa7cb88ec38e007f66fc6e88453bb0e889733a18f33f1efa21b197cd9f292',1978,'CG','Congo','people-and-society',123,'Population: 1,464,000 (July 1978), average annual growth
rate 2.7% (current)
Nationality: noun—Congolese (sing., pl.);
Congolese or Congo
adiective—
Approved For Release 2005/04/22
Atlantic
Ocean
(See reference map Vi)
Ethnic divisions: about 15 ethnic groups divided into
some 75 tribes, almost all Bantu; most important ethnic
groups are Kongo (48%) in south, Teke (17%) in center,
M’Bochi (12%) and Sangha (20%) in north; about 8,500
Europeans, mostly French
Religion: about half animist, half nominally Christian, less
than 1% Muslim
Language: French official, many African languages with
Lingala and Kikongo most widely used
Literacy: about 20%
Labor force: about 40% of population economically
active, most engaged in subsistence agriculture; 79,100 wage
earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965 est.)','d003b3af1a3c5d76090741cc2701ef25f786f80a9942d6b476c3249f69de7dc7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d64759221b189ddf1db10105dbe634e98c2ef5e06a54a9edeba208a6625e806',1978,'CK','Cook Islands','people-and-society',127,'Population: 18,000 (total from the census of | December
1976)
Nationality: noun—Cook Islander(s); adjective—Cook
Islander
Ethnic divisions: 81.3% Polynesian (full blood), 7.7%
Polynesian and European, 7.7% Polynesian and other, 2.4%
European, 0.9% other
Religion: Christian, majority of populace members of
Cook Islands Christian Church','14caf156f9ab4f414d2a9d48834966ac9bebc4aa8d9daf43af96f0a2d12adf29','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f296db6a2f02df0db9b188bc3296764393ffa7a0d23a80d8bf46b7cf90af5354',1978,'CR','Costa Rica','people-and-society',131,'Population: 2,119,000 (July 1978), average annual growth
rate 2.3% (current)
Nationality: noun—Costa Rican(s); adiective—Costa
Rican
Ethnic divisions: 98% white (including mestizo), 2%
Negro
Caribbean Sea
Pacific Ocean
(See reference map it}
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 90%
Labor force: 657,709 (1976); 32.6% agriculture; 13.8%
manufacturing; 15.3% commerce, 6.1% construction; 5.2%
transportation, utilities; 20.3% service (government, educa-
tion, social), 0.5% other; 6.2% unemployment (1976)
Organized labor: about 11.5% of labor force
Population: 9,797,000 (July 1978), average annual growth
rate 1.6% (current)
Nationality; noun—Cuban(s). adjective—Cuban
Ethnic divisions; 51% mulatto, 37% white, 11% Negro,
1% Chinese
Religion: at least 85% nominally Roman Catholic before
Castro assumed power
Language: Spanish
Literacy: about 96%
: CIA-RDP79-01051A000900010006-2
ae i TT
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
CUBA/CYPRUS
Labor force: 2.7 million in 1976; 33% agriculture, 17%
industry, 9% construction, 7% transportation, 32% services,
2% unemployed','b56541a95528a19293e9d8d82c622de6a79a7309ed2aa2bcb652194768e95577','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fda7d1b4a4a610360dab2e1319e0f4661987ba4635f19d91007298eb1d7d7b7',1978,'CY','Cyprus','people-and-society',135,'Population: 641,000 (July 1978), average annual growth
rate 0.2% (7-76 to 7-77)
Nationality: noun—Cypriot(s); adjective—Cypriot
Ethnic divisions: 78% Greek; 18% Turkish; 4% British,
Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4% Mason-
ite Armenian Apostolic and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Greek Sector labor force: 207,700 (1975), 22% agricul-
ture, forestry, fishing, 12% manufacturing, 4% construction,
1% mining and quarrying, 13% services, 10% trade and
finance, 3% transport and communications, 5% public
administration, 30% other; unemployment 7% (1976)
Turkish Sector labor force: 179,400 (145,900 employed,
33,500 unemployed); 31% agriculture, 18% services, 17%
manufacturing, 12% wholesale and retail trade, 22% other
(1975)
Population: 15,136,000 (July 1978), average annual
growth rate 0.7% (current)
49
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CZECHOSLOVAKIA
Nationality: noun—-Czechoslovak(s); adiective—Czecho-
slovak
Ethnic divisions: 64.3% Czechs, 30.0% Slovaks, 4.0%
Magyars, 0.6% Germans, 0.5% Poles, 0.4% Ukrainians, 0.2%
others (Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant, 2%
Orthodox, 1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Labor force: 7.4 million; 14% agriculture, 38.6% industry,
11% services, 36.4% construction, communications and
others','dd206931149c96760d7168ebb231c3a87adcb803682531c7730b2f489082e6da','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3a50ab8da025bad4a26e849b32e17ec3fabdae0a1331d0c7f61447312fc23f1',1978,'DK','Denmark','people-and-society',139,'Population: 5,106,000 (July 1978), average annual growth
rate 0.3% (current)
Nationality: noun—Dane(s); adjective—Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 1% other
Language: Danish; small German-speaking minority
Literacy: 99%
Labor force: 2.6 million; 9.5% agriculture, forestry,
fishing, 26.6% manufacturing, 8.3% construction, 15.7%
commerce, 6.8% transportation, 5.6% services, 25.7% govern-
ment, 1.8% other; 6.5% (167,000) of registered labor force
unemployed (1977 annual average)
Organized labor: 65% of labor force','512a2d0169ac3b70c49195f115b431481fe0a46d9c0450bc8b147c5ca3ad5ae0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59326a48a4cf051c1bc4875726ab36c6fa289220657385798acd921d36008297',1978,'DJ','Djibouti','people-and-society',143,'Population: 180,000 (official estimate for 1972)
Nationality: noun—Afar(s), Issa(s); adjective—Afar, Issa
Ethnic divisions: (approximate figures) 96,300 Somalis,
mostly Issas (large number of the Somalis are temporary
immigrants from Somalia, not citizens of territory), 90,500
Afars, 6,000 Arabs, 7,000 French (inclusive of French
military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, F rench, Arabic, all widely used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at
port
Organized labor: some 8,000 railway workers organized','931f35f7035592ca784c0915831175a27e08848cbc38af20fee86cf6b3fc61d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ac3ffc99348d64f982b0505355780d02287b8699d668254c967799bb76de9f9',1978,'DM','Dominica','people-and-society',147,'Population: $1,000 (July 1978), average annual growth
rate 1.6% (4-60 to 4-70)
Nationality: noun—Dominican(s); adjective—Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England, Methodist
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture
Organized labor: 25% of the labor force','d279bf44b39067cdb94df02c45bac61bc9b192823c5fe46e283779e784b14522','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('591904433e226ed53fab5dfd9d2e9abe3129d8fecbc95d86d33ba894dcfaa818',1978,'DO','Dominican Republic','people-and-society',151,'Population: 5,393,000 July 1978), average annual growth
rate 2.7% (current)
Nationality: noun—Dominican(s): adiective—Dominican
Ethnic divisions: 73% mulatto, 16% white, 11% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 million; 73% agriculture, 8% industry,
19% services and other
Organized labor: 12% of labor force','8e31b8fd720bf1a120a622492e4393f1b52a013d59e3ca1ccdf1480c201bbc94','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb58d7df03c830ffb9bf3381b63247f5ae89de99156e0aa4d5e2a8aaf4b7bc90',1978,'EC','Ecuador','people-and-society',155,'Population: 7,549,000, excluding nomadic Indian tribes,
(July 1978), average annual growth rate 3.0% (current)
Nationality: noun—Ecuadorean(s); adjective—Ecuador-
ean
Ethnic divisions: 40% mestizo, 40% Indian, 10% white,
5% Negro, 5% Oriental and other
Religion: 95% Roman Catholic (majority nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture, 13%
manufacturing, 4% construction, 7% commerce, 4% public
administration, 16% other services and activities
Organized labor: less than 15% of labor force','903085d74c54aa309d2d129c1b166b1213baaffc754ce2643589d95cda511ec6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f0a62f9d3d08f39d105df826bcb0ee7c20311cdfab508c4882e56994222e0c5',1978,'EG','Egypt','people-and-society',159,'Population: 39,890,000 (July 1978), average annual
growth rate 2.7% (current)
Nationality: noun—Fgyptian(s); adjective—Egyptian or
Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock; 10% Greek,
Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt and
other
Language: Arabic official, English and French widely
understood by educated classes
Literacy: around 40%
Labor force: 8 to 12 million; 45% to 50% agriculture, 10%
industry, 10% trade and finance, 30% services and other;
shortage of skilled labor
Organized labor: 1 to 3 million','2f042b75973cc292ca814683ff0eabe86e3e6d062ccb061b9008cb0c27602032','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fd0aed641e28a7bea29ff69a36d45ec91d2b9d7d65f3002c7f1fe716155f083',1978,'SV','El Salvador','people-and-society',163,'Population: 4,515,000 (July 1978), average annual growth
rate 2.9% (current)
Nationality: noun—Salvadoran(s); adjective—Salvadoran
Ethnic divisions: 84%-88% mestizo; Indian and white
minorities, 6%-8% each
Religion: predominantly Roman Catholic, probably
97%-98%
Language: Spanish
Literacy: 50% literacy in urban areas, 30% in rural areas
58
Labor force: 1,500,000 (est. 1977); 57% agriculture, 14%
services, 14% manufacturing, 6% commerce, 9% other;
shortage of skilled labor and large pool of unskilled labor,
but manpower training programs improving situation
Organized labor: 5% of total labor force; 10% of
nonagricultural labor force (1977)','bf2cd57a5091429ab48a7718847323c2e9574db2b463dd777d6d371d81c162e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fa19874be3a6b9dd919fc1976c1bd4f081860c0e17291351c72c53a370b2e8c',1978,'GQ','Equatorial Guinea','people-and-society',167,'Population: 336,000 (July 1978), this estimate does not
take into account emigration from Equatorial Guinea during
the last several years, average annual growth rate 1.8% (7-68
to 7-69); Rio Muni, 235,000, average annual growth rate
1.5% (7-68 to 7-69); Fernando Po, 101,000, average annual
growth rate 2.6% (7-68 to 7-69)
Nationality: noun—Equatorial Guinean(s); adjective—
Equatorial Guinean
Ethnic divisions: indigenous population of Province
Francisco Macias Nguema primarily Bubi, some Fernan-
dinos; of Rio Muni primarily Fang; less than 1,000
Europeans, primarily Spanish
Religion: natives all nominally Christian and predomi-
nantly Roman Catholic; some pagan practices retained
Language: Spanish official language of government and
business; also pidgin English, Fang
Literacy: 12% (est.)
Labor force: most Equatorial Guineans involved in
subsistence agriculture','453c15712d698212237e3b3038c8816dab2bccd79f880f5b4628a833329e0a42','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc408b9089620cbd53fe16f08e767ccd0a0d42984395d0d2cb7951a32cc7b37c',1978,'ET','Ethiopia','people-and-society',171,'Population: 29,679,000 (July 1978), average annual
growth rate 2.6% (7-76 to 7-77)
Nationality: noun—FEthiopian(s); adjective—Ethiopian
Ethnic divisions: Galla 40%, Amhara and Tigrai 32%,
Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%, Gurage 2%,
other 1%
Religion: 35%-40% Ethiopian Orthodox, 40%-45% Mus-
lims, 15%-20% animist, 5% other
Language: Amharic official; many local languages and
dialects; English major foreign language taught in schools
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Literacy: about 5%
Labor force: 90% agriculture and animal husbandry; 10%
government, military, and quasi-government
Organized labor: All Ethiopian Trade Union formed
January 1977 to represent 273,000 registered trade union
members','50ee3fa605e00cdd7d2d1818f09c32ee66b34a0dc3a3dc5de8d755af1c21e96a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4248928c772787997b9b33c70f17df320091e5da4173199a9c4eeee9ea7b2bc',1978,'DE','Germany','people-and-society',176,'Population: 2,000 (official estimate for 31 December
1977)
Nationality: noun—Falkland Islander(s); adjective—Falk-
land Island
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in agriculture,
mostly sheepherding
Population: 35,286,000 (July 1978), average annual
growth rate 3.0% (current)
Nationality: noun—Iranian(s); adjective—Iranian
Ethnic divisions: 63% ethnic Persians, 3% Kurds, 13%
other Iranian, 18% Turkic, 3% Arab and other Semitic, 1%
other
Religion: 93% Shia Muslim: 5% Sunni Muslim; 2%
Zoroastrians, Jews, Christians and Baha’is
Language: Persian (Farsi), Turkish dialects, Kurdish,
Arabic
Literacy: about 37% of those 7 years of age and older
(1976 est.)
Labor force: 10.1 million est. 1976: 36% agriculture, 21%
manufacturing; shortage of skilled labor substantial
Population: 43,059,000 (July 1978), average annual
growth rate 2.6% (current)
206
(See reference map V}
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry,
16% service; substantial shortage of skilled labor; ample
unskilled labor
Organized labor: 10% of labor force','9c0c20428713b918e16f799229c1ac020bf3294dc0aa271452f83d15f3c48397','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0dbb62bfd7c3d74d82e43c13e6f57f464e9798483126da54689751e63bcb0fe',1978,'FO','Faroe Islands','people-and-society',179,'Population: 42,000 (July 1978), average annual growth
rate 1.4% (1-75 to 1-77)
Nationality:
Faroese
noun—Faroese (sing., pl.); adjective—
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faroese (derived from Old Norse), Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing, manufac-
turing, transportation, and commerce','78f1cedb9ba788b2a585a92f41e543bce26385287743ed9bbf779e0f4a7d5c29','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76ac8b04a496bd7cb9706203cb2880c7a9bce94a4339d92467d81d638567e13e',1978,'FJ','Fiji','people-and-society',183,'Population: 610,000 (July 1978), average annual growth
rate 1.6% (current)
Nationality: noun—Fijian(s); adjective—Fijian
Ethnic divisions: 42% Fijian, 50% Indian, 8% European,
Chinese and _ others
Religion: Fijians mainly Christian, Indians are Hindu
with a Muslim minority
Language: English and Fijian (official), Hindustani
spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50%
breakdown on remainder
Organized labor: about 50% of labor force organized into
22 unions; unions organized along lines of work, breakdown
by ethnic origin causes further fragmentation','616576b6eefaf5bdc349b889923b74e4a6f6c835367630fe6b8e6536babd8fc6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24835fcd060f2556fce54fc9e516acfb1c2043f751bb3dbb8da9e971e160131d',1978,'FI','Finland','people-and-society',187,'Population: 4,748,000 (July 1978), average annual growth
rate 0.2% (7-76 to 7-77)
Nationality: noun—Finn(s); adjective—Finnish
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 98% Evangelical Lutheran, 1% Greek Orthodox,
1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp- and
Russian-speaking minorities
Literacy: 99%
Labor force: 2.2 million; 16.6% agriculture, forestry, and
fishing, 26.4% mining and manufacturing, 8.4% construc-
tion, 15.4% commerce, 6.8% transportation and communica-
tions, 4.0% banking and finance, 20.1% services; 6.1%
(136,000) unemployed 1977 annual coverage
Organized labor: 60% of labor force','121c3cf351b597207f4fd012c04b68490c568e2e2d96eabd0552d583c25d8282','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81042bf22067f5240423013b3a3a66faf228d10a04c7a766a71ddec030460add',1978,'FR','France','people-and-society',191,'Population: 53,446,000 (July 1978), average annual
growth rate 0.6% (current)
(men); adjective—
Nationality: | noun—Frenchman
French
Ethnic divisions: 45% Celtic; remainder Latin, Germanic,
Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish, 1%
Muslim (North African workers), 13% unaffiliated
Language: French (100% of population); rapidly declin-
ing regional patois—Provencal, Breton, Germanic, Corsican,
Catalan, Basque, Flemish
Literacy: 97%
Labor force: 22 million (est. in mid-1976); 47% services,
38% industry, 11% agriculture, 4% unemployed
Organized labor: approximately 17% of labor force, 23%
of salaried labor force
Population: 6,972,000 (July 1978), average annual growth
rate 3.4% (7-72 to 7-77)
Nationality: noun—Rhodesian(s); adjective—Rhodesian
Ethnic divisions: 96% African, less than 4% European,
less than 0.5% coloreds and Asians
Religion: 51% syncretic (part Christian, part animist),
24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and Sindebele also
widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including some
migrants from Zambia and Malawi), 108,000 Europeans,
Asians, and coloreds (people of mixed heritage); 35%
agriculture, 25% mining, manufacturing, construction, 40%
transport and _ services
Organized labor: about one-third of European wage
earners are unionized, but only a small minority of Africans
(1966)','a45df69588ca00e12a8d0439ad0049e53bb32349be71ce96ad28249d912edb2a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf06233d2df379f79001a9aa8e4612613b0bbb18190ae064a86099af6262f050',1978,'GF','French Guiana','people-and-society',195,'Population: 60,000 (July 1978), annual growth rate 2.2%
(10-74 to 11-77)
68
Nationality: noun—French Guianese (sing., pl.); adjec-
tive—French Guiana
Ethnic divisions: 95% Negro or mulatto, 5% caucasian,
10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%, construc-
tion 21%, agriculture 18%, industry 8%, transportation 4%;
information on unemployment unavailable
Organized labor: 7% of labor force','840546a175dce407579a800580a3d3b6fa84865e13ebf5d202bec438b16f5d06','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de39f1c8f4de3f86efeb9f5ec73fcce95f01e2f563ed2c6143dff733e171279c',1978,'PF','French Polynesia','people-and-society',199,'Population: 141,000 (July 1978), annual growth rate 2.3%
(current)
Nationality: noun—French Polynesian(s); adjective—
French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chinese, 6% local
French, 4% metropolitan French
Religion: mainly Christian, 55% Protestant, 32% Catholic','20e3615b37de95046c5f2bcbbdb9909067e4c6b198f405bd13bbf980e37f34f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fbee254839104664da173fd82f1cb4503adee76ec878308336d2ba6bf434b9c',1978,'GA','Gabon','people-and-society',203,'Population: 571,000 (July 1978), average annual growth
rate 1.7% (7-66 to 7-70)
Nationality: noun—Gabonese (sing., pl); adjective—
Gabonese
Ethnic divisions: about 40 Bantu tribes, including 4 major
tribal groupings (Fang, Eshira, Mbede, Okande); about
100,000 expatriate Africans and Europeans, including 30,000
French
Religion: 55% to 75% Christian, less than 1% Muslim,
remainder animist
Language: French official language and medium of
instruction in schools; Fang is a major vernacular language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are wage
earners in the modern sector
Organized labor: less than 30% of wage labor force
70
Population: 568,000 (July 1978), average annual growth
rate 2.7% (7-76 to 7-77)
Nationality: noun—Gambian(s); adjective—Gambian
Ethnic divisions: over 99% Africans (Mandinka 40.8%,
Fulani 13.5%, Wolof 12.9%, remainder made up of several
smaller groups), fewer than 1% Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Mandinka and Wolof most
widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in subsis-
tence farming; about 15,000 are wage earners (government,
trade, services)
Organized labor: 25% to 30% of wage labor force at most
Population: 16,775,000, including East Berlin (July 1978),
average annual growth rate 0.1% (current)
Nationality: noun—German(s); adjective—German
Ethnic divisions: 99.7% German, .3% Slavic and other
Religion: 53% Protestant, 8% Roman Catholic, 39%
unaffiliated or other; less than 5% of Protestants and about
25% of Roman Catholics actively participate
Language: German, small Sorb (West Slavic) minority
Literacy: 99%
72
(See reference map IV}
Labor force: 8.2 million; 34.1% industry; 4.7% handi-
crafts; 6.8% construction; 11.9% agriculture; 6.8% transport
and communications; 10.1% commerce; 16.8% services; 2.5%
other
Organized labor: 87.7% of total labor force
Population: 61,474,000, including West Berlin (July
1978), average annual growth rate 0.1% (current)
Nationality: noun—German(s); adjective—German
Ethnic divisions: 99% Germanic, 1% other
Religion: 48.9% Protestant, 44.7% Roman Catholic, 7.7%
other (as of 1975)
Language: German
Literacy: 99%
73
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GERMANY, FEDERAL REPUBLIC OF
Labor force: 26.7 million; 42.9% in manufacturing and
construction, 18.0% services, 12% commerce, 9.9% govern-
ment, 6.3% agriculture, 5.9% communication and transpor-
tation, 1% mining; 4.2% average unemployed as of 1977,
excluding self employed
Organized labor: 32.6% of total labor force; 41.4% of
wage and salary earners','f1a122b8e9fd6ae86ccf9243dec31fffaaa2f67cebe739ac121e60e7c2388d97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c29550743daa6c344cd46482361566d534680f8af6920102cf7c28b104c391a',1978,'GN','Guinea','people-and-society',207,'Population: 11,366,000 (July 1978), average annual
growth rate 3.3% (current)
Nationality: noun—Ghanaian(s); adjective—Ghanaian
Ethnic divisions: 99.8% Negroid African (major tribes
Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12% Muslim
Language: English official; African languages include
Akan 44%, Mole-Dagbani 16%, Ewe 13%, and Ga-Adangbe
8%
Literacy: about 25% (in English)
Labor force: 3.4 million, 61% agriculture and fishing,
16.8% industry, 15.2% sales and clerical, 4.1% services,
transportation, and communications, 2.9% professional;
400,000 unemployed
Organized labor: 850,000 or approximately 10% of labor
force
Population: 5,898,000 (July 1978), average annual growth
rate 2.6% (current)
Nationality: noun—Guinean(s); adjective—Guinean
Ethnic divisions: 99% African (3 major tribes—Fulani,
Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less than
1%
Language: French official; each tribe has own language
Literacy: 5% to 10%; French only significant written
language
Labor force: 1.8 million, of whom less than 10% are wage
earners; most of population engages in subsistence agricul-
ture
Organized labor: virtually 100% of wage labor force
loosely affiliated with the National Confederation of
Guinean Workers, which is closely tied to the PDG
Atlantic Ocean
(See reference map Vi
Nationality: noun—lIvorian(s); adjective—Ivorian
Ethnic divisions: 7 major indigenous ethnic groups; no
single tribe more than 20% of population; most important
are Agni, Baoule, Krou, Senoufou, Mandingo; approximately
2 million foreign Africans, mostly Upper Voltans; about 75-
90 non-Africans (50-60 French) and 25 ,000-30,000
Lebanese)
22% Muslim, 12% Christian
Language: French official, over 60 native dialects, Dioula
most widely spoken
Literacy: about 65%
Labor force: over 85% of population engaged in
agriculture, forestry, livestock raising; about 11% of labor
force are wage earners, nearly half in agriculture, remainder
in government, industry, commerce, and professions
Organized labor: 20%
Religion: 66% animist,
at primary school level
of wage labor force
Population: 5,380,000 (July 1978), average annual growth
rate 2.6% (current)
Nationality: noun—Senegalese (sing. & pl.); adiective—
Senegalese
Ethnic divisions: 36% Wolof, 17.5 Fulani, 16.5 Serer, 9%
Tukulor, 9% Dyola, 6.5% Malinke, 4.5% other African, 1%
Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian (mostly
Roman Catholic)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978','ca6c3db2dd43149851f0724292ab3d956c4c4f679f1671c35e7f13dcabfadd4c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6141990583a8cc31e6a2792b84b9b8ae9089b9d2c18f062eef2ad2482bf1639f',1978,'GI','Gibraltar','people-and-society',211,'Population: 30,000 (official estimate for 1 July 1977)
Nationality: noun—Gibraltarian; adjective—Gibraltar
Ethnic divisions: mostly Italian, English, Maltese, Portu-
guese and Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary languages;
Italian, Portuguese, and Russian also spoken; English used in
the schools and for all official purposes
76
¥CIBRALTA
Atlantic Ocean
(See reference map 1V)
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-Gibraltarian
laborers
Organized labor: over 6,000
Population: 52,000 (preliminary total from census of 8
December 1973)
Nationality: noun—Gilbertese or Gilbert Islander(s);
adjective—Gilbertese, or Gilbert Islander
Ethnic divisions: Micronesian
Religion: Catholic
Literacy: less than 50%','a7195183e944c881aaaed0ccf1c3929c62c09270be55d5ff77f416ef935a80b1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2b63d780ab7543f6d66297b15360a4dfc7375032670312206102cebea2b6c7f',1978,'GR','Greece','people-and-society',215,'Population: 9,309,000 (July 1978), average annual growth
rate 0.6% (7-66 to 7-76)
Nationality: noun—Greek(s); adjective—Greek
Ethnic divisions: 96% Greek, 2% Turkish, 2% other
Religion: 97% Greek Orthodox, 2.5% Muslim, 0.5% other
Language: Greek; English and French widely understood
Literacy: males about 92%; females about 73%; total
about 82%
Labor force: 3,400,000 (1975 est.); 40.5% agriculture,
25.6% industry, 33.7% services; unemployment 3%, but there
is substantial underemployment in agriculture
Organized labor: 20% of labor force est.
78','000f5e29afd9d5a23c4dda0a160e403f0f59a616c5aa3d0ca27f8aef3e007028','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5db355e5dba153477ab6673ba32997e878fb9431665362af6be712608b58b68',1978,'GL','Greenland','people-and-society',219,'Population: 50,000 (July 1978), average annual growth
rate 0.2% (1-75 to 1-77)
Nationality:
land
Ethnic divisions: 86% Greenlander (Eskimos and Green-
land-born whites), 14% Danes
Religion: Evangelical Lutheran
noun—Greenlander(s); adjective—Green-
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and sheep
breeding','de62d20f7d5e403f22b453201c230e0527e2f23a965f2e21e2076099e8ebbccc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c27dc82306c12256878b2b16b05a09de9d901b9df403066424f0c536f45a7f2',1978,'GD','Grenada','people-and-society',223,'Population: 108,000 (July 1978), average annual growth
rate 1.0% (7-60 to 7-75)
Nationality: noun—Grenadian(s); adjective—Grenadian
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant sects;
Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 27,314 (1960); 40%
unemployed or underemployed
Organized labor: 33% of labor force
agriculture, 30%','f5b22ba18bb9abf14a28e4e1005fa7afe04a9d1fd5e2e3c43ae23e8b8620568b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41480b813a82516f53201cf9dfb4b6a7814cca407d0b6aa75688cdb8956e474c',1978,'GP','Guadeloupe','people-and-society',227,'Population: 331,000 (July 1978), average annual growth
rate 0.5% (10-67 to 10-74)
Nationality: noun—Guadeloupian(s); adjective—Guade-
loupe
Ethnic divisions: 90% Negro or Mulatto, less than 5% East
Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25% unemployed
Organized labor: 11% of labor force','bbc08d8454e4e3fc90574375381ce3ad0961bf926ffe282952ff05d4c7378335','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0da23bf3f4fa361bd77e2b0d0a339c13f6200c464ce03bd238bd4df28fe9bd1e',1978,'GW','Guinea-Bissau','people-and-society',232,'Population: 620,000 (July 1978), average annual growth
rate 1.7% (current)
Nationality: noun—Guinean(s); adjective—Guinean
Ethnic divisions: about 99% African (Balanta 30%, Fulani
20%, Mandyako 14%, Malinke 13%, and 23% other tribes);
less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese and numerous African languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in subsistence
agriculture','d36c35b9992a4bab9a18edb40c0063145916e1111d59386952ab845c8720a471','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91121ab693732faacc2cb4b1e9306455d33e2056e349029cb238fe15674aabab',1978,'HT','Haiti','people-and-society',237,'Population: 5,534,000 (July 1978), average annual growth
rate 2.4% (current)
Nationality: noun—Haitian(s); adjective—Haitian
Ethnic divisions: over 90% Negro, nearly 10% mulatto,
few whites
Religion: 10% Protestant, 75% to 80% Roman Catholic (of
which an overwhelming majority also practice Voodoo)
Language: French (official) spoken by only 10% of
population; all speak Creole
Literacy: 10% to 12%
Approved For Release 2005/04/22
: CIA-RDP79-01051A000900010006-2
Labor force: 2.3 million (est. 1975); 79% agriculture, 14%
services, 7% industry, 5% unemployed; shortage of skilled
labor; unskilled labor abundant
Organized labor: less than 1% of labor force','3510c9abccb5b8842a911fa88abaa01ae034b5aa70fc80d598a8011d5b53e192','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('028d8eeebe442261edcb4ec63d77888e0c1de8faeab98386d1056681740accc8',1978,'HN','Honduras','people-and-society',241,'Population: 3,517,000 July 1978), average annual growth
rate 3.4% (current)
Nationality: noun—Honduran(s); adjective—Honduran
Caribbean
Pacific Ocean
{See reference map tt}
Ethnic divisions: 90% mestizo, 7% Indian, 2% Negro, and
1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 47% of persons 10 years of age and over (est.
1970)
Labor force: approx. 900,000 (est. mid-1972); 66%
agriculture, 12% services, 8% manufacturing, 5% commerce,
6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-1972)','cd63e05d6414695b32d3a653def25b2b3ba5037d1f7b93a60c7b11149035e5cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c129b44fd7de540e0365c1aa2bf30bfbded5079714007dd89e13771c8ac0395a',1978,'PH','Philippines','people-and-society',245,'Population: 4,585,000 (July 1978), average annual growth
rate 1.6% (7-76 to 7-77)
Nationality: adjective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of local
religions
Language: Chinese, English
89
: CIA-RDP79-01051A000900010006-2
10006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009000
July 1978
HONG KONG/HUNGARY
Literacy: 75%
Labor force (1976 Census): 1.87 million; 45.3% manufac-
turing, 18.6% services, 6.0% construction, mining, quarrying
and utilities, 19.4% commerce, 2.6% agriculture, forestry,
fisheries, and hunting, 7.3% communications, 0.7% other;
underemployment is a serious problem
Organized labor: 21% of 1976 labor force
Population: 45,883,000 (July 1978), average annual
growth rate 2.2% (current)
Nationality: noun—Filipino(s); adjective—Philippine
Ethnic divisions: 91.5% Christian Malay, 4% Muslim
Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant, 4%
Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the national
language of the Philippine Republic; English is the language
of school instruction and government business
Literacy: about 83%
Labor force: 11 million; 60% agriculture, forestry, fishing,
12% manufacturing, 10.5% commerce, 10.5% government
and services (business, recreation, domestic, personal), 3.5%
transport, storage, communication, 3% construction; 0.5%
other','f78c836e6b460b76bc4315e67a8d82a206dcfa1570dc3aca26f09c9789168351','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8861406f59278ce0f37fd0aa37f80db990e78d650ad9e3b5602aa82b16cb9de',1978,'HU','Hungary','people-and-society',250,'Population: 10,693,000
growth rate 0.4% (current)
Nationality: noun—Hungarian(s); adjective—Hungarian
Ethnic divisions: 92.4% Magyar, 2.5% German, 3.3%
Gypsy, 0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0%
Lutheran, 7.5% atheist and other
other agricultural, 16%
July 1978), average annual
Calvinist, 5.0%
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5,085,500 (1 January 1976); 23% agriculture,
44% industry and building, 16% trade and transport, 17%
other nonagricultural','2fe4397c22c6576dfcdbf38dcb7e1fad5a38872a8e711d8a60343084220a1531','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4746d72fc887223309b65b2f0c05bfec284d0e894a5ffdac2277a46603a5fdb1',1978,'IS','Iceland','people-and-society',255,'Population: 223,000 (July 1978), average annual growth
rate 0.7% (12-76 to 12-77)
Nationality: noun—lIcelander(s); adiective—Icelandic
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other Protestant
and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
92
Labor force: 90,000; 22.6% agriculture and fishing; 25.6%
mining and manufacturing; 10.7% construction; 12.8%
commerce; 7.8% transportation and communications; 15.2%
services; and 5.7% other; unemployment 300
Organized labor: 60% of labor force','e3736e246c6e5f8eca73baaaa470ebda04284ae598df12cac7aef9059b68df48','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7f7705bd0c7f611119b746cc58f9b9e41975c5bd7eefd7df6518f553e263f85',1978,'IN','India','people-and-society',259,'Population: 660,722,000, including Sikkim and the
Indian-held part of disputed Jammu-Kashmir (July 1978),
average annual growth rate 2.2% (current)
Nationality: noun—Indian(s); adjective—Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian, 3%
Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh, 2.6%
Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or more
persons each; numerous other languages and dialects, for the
most part mutually unintelligible; Hindi is the national
language and primary tongue of 30% of the people; English
enjoys “associate” status but ‘is the most important language
for national, political, and commercial communication;
Hindustani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29% (1971
census)
Labor force: about 197 million; 70% agriculture, more
than 10% unemployed and underemployed; shortage of
skilled labor is significant and unemployment is rising
Organized labor: about 2.5% of total labor force','a6602a053914f1635c909068d91cad104190fca47d888ebee92dcded4d71d22c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20edd417b84f5ab9b9ece377823afa4be5018341b2d912c496dc21650a1d7619',1978,'ID','Indonesia','people-and-society',264,'Population: 140,680,000, including East Timor and West
Irian (July 1978), average annual growth rate 2.4% (current)
Nationality: noun—Indonesian(s); adjective—Indonesian
Ethnic divisions: 45% Javanese, 14% Sundanese, 7.5%
7.5% coastal Malays, 26% other
Religion: 85% Muslim, 9% Christian, 2% Buddhist, 2%
Hindu, 2% other
Language: Indonesian (modified form of Malay) official;
English, and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 44 million; 70% agriculture, 15% industry,
15% miscellaneous and unemployed
Organized labor: 10% of labor force','ab8d52d242d3c7326c2918e2100328fc98cbf813d79f0478402c6c22946a2122','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83470a12a9030f9fbda7e3a442b20ec6802fea7dfa6c2226fbf1502d7640486a',1978,'IQ','Iraq','people-and-society',268,'Population: 12,470,000 (July 1978),
growth rate 3.4% (current)
average annual
Nationality: noun—Iraai(s); adjective—Iraqi
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7%
Assyrians, 2.4% Turkomans, 7.7% other
Religion: 90% Muslin: (50% Shiah Muslim, 40% Sunni
Muslim), 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks Kurdish
Literacy: 20% to 40%
97
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
IRAQ/TRELAND
Labor force: 2.4 million; 70% agriculture, 6.5% industry,
6.7% government, 16.8% other; rural underemployment
high, but not serious because low subsistence levels make it
easy to care for unemployed; severe shortage of technically
trained personnel
Organized labor: 11% of labor force','7eb0357aeeea97a52735c4986433203cfa5c5d6680f0e2afbdeb8db1637d59bc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db8b5d5263344aca8e15e172b529012973fcf4ae3b22e36cdcb5c47b333fd72c',1978,'IE','Ireland','people-and-society',272,'Population: 3,228,000 (July 1978), average annual growth
rate 1.0% (current)
Nationality: noun—Irishman(men), Irish (collective pl.);
adjective—Irish
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2% other
as Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Atlantic
an
Ocean
ase ae
(See reference map IV)
Language: English and Gaelic official; English is gen-
erally spoken
Literacy: 98%-99%
Labor force: about 1,143,000 (1976); 26% agriculture,
forestry, fishing; 19% manufacturing; 15% commerce; 7%
construction; 5% transportation; 4% government; 24% other;
9.8% unemployment (February 1976)
Organized labor: 36% of labor force','ecc44578c49d3b5c8b6672e8c65fcb408d340709fd21b6f9c03ee040f10c007f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('465b7a7da75c68e083897c49ad94d892e15669be5eccf0cee6605565ee8b870d',1978,'IL','Israel','people-and-society',276,'Population: 3,654,000, excluding East Jerusalem and the
other occupied territories (July 1978), average annual
growth rate 2.3% (12-76 to 12-77)
Nationality: noun—Israeli(s); adiective—Israel
Ethnic divisions: 85% Jews, 15% non-Jews (mostly Arabs)
Religion: 85% Judaism, 11% Islam, 4% Christian and
other
Language: Hebrew official; Arabic used officially for
Arab minority; English most commonly used foreign
language
Literacy: 88% Jews, 48% Arabs
Labor force: 1,133,000; 6.5% agriculture, forestry and
fishing; 25.3% manufacturing (mining, industry); 0.9%
electricity and water; 8.1% construction and public works;
12.2% commerce; 7.7% transport, storage, and communica-
tions; 6.5% finance and business; 26.1% public services; 6.7%
personal and other services (1974)
Organized labor: 90% of labor force','366d808ca5c9f55daa3df7d9e4eece6c0ada88fad6f9384ea0454ad326ea4866','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1aeff9e833b424f2b27c26e2ab111408b2d85dfc3519e655a5d7b361ba17f09d',1978,'IT','Italy','people-and-society',280,'Population: 56,711,000 (July 1978), average annual
growth rate 0.5% (current)
Nationality: noun—lItalian(s); adjective—Italian
Ethnic divisions: primarily Italian but population in-
cludes small clusters of German-, French-, and Slovene-Ital-
ians in the north and of Albanian-Italians in the south
101
: CIA-RDP79-01051A000900010006-2
006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010
July 1978
Religion: almost 100% nominally Roman Catholic (de
facto state religion)
Language: Italian; parts of Trentino-Alto Adige Region
(e.g., Bolzano) are predominantly German speaking; signifi-
cant French-speaking minority in Valle d’Aosta Region;
Slovene-speaking minority in the Trieste-Gorizia area
Literacy: 5%-7% of population illiterate (1972); illiteracy
varies widely by region
Labor force: 19,549,000 (January 1975); 15.0% agricul-
ture, 42.9% industry, 39.0% other; 7% unemployment
(1978); 1.5 million Italians employed in other Western
Furopean countries
Organized labor: 20% (est.) of labor force
Population: 7,266,000, resident African population only,
(July 1978), average annual growth rate 2.7% (current)
Approved For Release 2005/04/22
Gulf of','77dac7fccfd8f862c17482540ec9d8a58551b71fb694b34abd7a95a117f48061','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccece738fb3fbb274bf811dd4843c0cfa13a7793d04f2c24f5b6817c8cef805a',1978,'JM','Jamaica','people-and-society',284,'Population: 2,201,000 (July 1978), average annual growth
rate 1.4% (current)
Nationality: noun—Jamaican(s); adjective—Jamaican
Ethnic divisions: African 76.3%, Afro-European 15.1%,
Chinese and Afro-Chinese 1.2%, East Indian and Afro-East
Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman Catho-
lic, some spiritualist cults
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
JAMAICA/JAPAN
Language: English
Literacy: government claims 82%, but probably only
about one-half of that number are functionally literate
Labor force: 672,000 (1975); 29% in agriculture, forestry,
fishing and mining, 12% manufacturing/mining, 8% public
administration, 5% construction, 10% commerce, 3% trans-
portation and utilities, 33% services, 25% unemployed;
shortage of technical and managerial personnel
Organized labor: about 25% of labor force (1966)','ff47fb0032972ac0e3058820686584c1b4d6354b5c58869a6f6c5698617e4cae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fd84a72f3de5923decaa5e5ce0d5d5bf9be01f66a538c730fbb873f966cc2fe',1978,'JP','Japan','people-and-society',288,'Population: 114,983,000, including Ryukyus (July 1978),
average annual growth rate 1.0% (current)
Nationality: noun—Japanese (sing., pl.);
Japanese
Ethnic divisions: 99.2% Japanese, 0.8% other (mostly
Korean)
Religion: most Japanese observe both Shinto and Buddhist
rites; about 16% belong to other faiths, including 0.8%
Christian
Language: Japanese
Literacy: 97.8% of those 15 years old and above (1960
data)
Labor force (1977 figures): 54.5 million; 11% agriculture,
forestry, and fishing; 34% manufacturing, mining, and
construction; 48% trade and services; 5% government; 2.0%
unemployed
Organized labor: 33.7% of labor force','75d59e098def5a0ba70f17040c0483100a076b5fe934ceb6003e28f6147665c7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e69cafe9b8c7d0131438e37243aae4ddc7ca5f91d5c5e700abff5caef630d8db',1978,'JO','Jordan','people-and-society',292,'Population: 2,960,000, including West Bank and East
Jerusalem (July 1978), average annual growth rate 3.2% (7-
70 to 7-76); East Bank, 2,183,000, average annual growth
rate 3.6% (7-70 to 7-76); West Bank, including East
Jerusalem, 777,000, average annual growth rate 1.9% (1-71
to 1-77)
Nationality: noun—Jordanian(s); adjective—Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, 1% Armenian
Religion: 90%-92% Sunni Muslim, 8%-10% Christian
Language: Arabic official, English widely understood
among upper and middle classes
Literacy: about 50%-55% in East Jordan; somewhat less
than 60% in West Jordan
Labor force: 638,000; less than 5% unemployed
Organized labor: 9.8% of labor force','7298a3c34197e6eaa8bc3964dd777700790cd2bd83853fb79dc4c1ca7f510ae0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8f8d6ffaafd7c6f8b9957df21dad2cf239eb4d902c8b7d4592d0b340920ebd8',1978,'KE','Kenya','people-and-society',296,'Population: 14,837,000 (July 1978), average annual
growth rate 3.5% (7-71 to 7-77)
Nationality: noun—Kenyan(s); adjective—Kenyan
Ethnic divisions: 97% native African (including Bantu,
Nilotic, Hamitic and Nilo-Hamitic); 2% Asian; 1% Europe-
an, Arab and others
Religion: 56% Christian, 36% animist, 7% Muslim, 1%
Hindu
Language: English and Swahili official; each tribe has
own language
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
ee
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
KENYA/KOREA, NORTH
Literacy: 27%
Labor force: 2.5 million, about 977,000, (39%) in
monetary economy (1967)
Organized labor: about 215,000
Population: 18,184,000 (July 1978), average annual
growth rate 3.2% (current)
109
-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006
July 1978
KOREA, NORTH/KOREA, SOUTH
Chine Sea
(See reference map Vit}
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; religious activities
now almost nonexistent
Language: Korean
Literacy: 90% (est. )
Labor foree: 6.1 million; 48% agriculture, 52% non-agri-
cultural; shortage of skilled and unskilled labor
Population: 56,000 (July 1978), average annual growth
rate 0.9% (current)
Ethnic divisions: mainly of African Negro descent
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
ai
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ST. CHRISTOPHER-NEVIS-ANGUILLA/ST. LUCIA
Nationality: noun—Kittsian(s), Nevisian(s), Anguillan(s);
adjective—Kittsian, Nevisian, Anguillan
Religion: Church of England, other Protestant sects,
Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (1960 est.)
Organized labor: 6,700
Population: 119,000 (July 1978), average annual growth
rate 1.7% (current)
173
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ST. LUCIA/ST. VINCENT
Nationality: noun—St. Lucian(s); adjective—St. Lucian
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 38,000 (1969); 50% agriculture: 30%-35%
unemployment (1975)
Organized labor: 20% of labor force
Population: 105,000 (July 1978), average annual growth
rate 1.5% (4-60 to 7-75)
Nationality: noun—St. Vincentian(s) or Vincentian(s):
adjectives—St. Vincentian or Vincentian
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian and
Carib Indian
Religion: Church of England, Methodist, Roman Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60% unemployed
Organized labor: 10% of labor force','cc3699ae551d7c1a8152c113588526c20fc09ed6123e5d7547d62c4ee528859b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b707168c23ddd3de8e7d5cd2644eded93ca60bb14621d97a614d2fa6fcd32774',1978,'KW','Kuwait','people-and-society',300,'Population: 1,204,000 (July 1978), average annual growth
rate 5.9% (current)
Nationality: noun—Kuwaiti(s); adjective—Kuwaiti
Ethnic divisions: 85% Arabs, 13% Iranians, Indians, and
Pakistani; native Kuwaitis are a minority
Religion: 99% Muslim, 1% Christian, Hindu, Parsi, other
Language: Arabic; English commonly used foreign
language
112
(See ceference map Vj
Literacy: about 60%
Labor force: 340,000 (1976 est.); 26% manufacturing, 25%
services, 35% government and professions, 9% commerce,
5% oil industry; two-thirds of labor force is non-Kuwaiti
Organized labor: labor unions, first authorized in 1964,
formed in oil industry and among government personnel
Population: 3,545,000 (July 1978), average annual growth
rate 2.4% (current)
Nationality: noun—Lao (sing., Lao or Laotian); adjec-
tive—Lao or Laotian
Ethnic divisions: 48% Lao; 14% Tribal Tai; 25%
Phoutheung (Kha); 13% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant foreign
language
Literacy: about 12%
Labor force: about 1-1.5 million; 80%-90% agriculture
Organized labor: only labor organization is subordinate to
the Communist Party
Bs','be02bf4fea91305c008ad95404e95bc6c54536632a4311fb7a3575ac06179a54','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da9b5b1d7f44a1c19237e7ade185a7a121cb68b04eb5d33eb1fa0a5b8cefd028',1978,'LB','Lebanon','people-and-society',304,'Population: 2,540,000 (July 1978), average annual growth
rate 2.3% (current)
Nationality: noun—Lebanese (sing. and pl.); adjective—
Lebanese
Ethnic divisions: 93% Arab, 6% Armenian, 1% other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Religion: 55% Christian, 44% Muslim and Druze, 1%
other (official estimates); Muslims, in fact, constitute a
majority
Language: Arabic (official); French is widely spoken
Literacy: 86%
Labor force: about 1 million economically active; 49%
agriculture, 11% industry, 14% commerce, 26% other;
moderate unemployment
Organized labor: about 65,000','31a5ed6ba0e0610b261caf7d6369e9bcdb3ee408bb18a188f1b8ccbf5812d08b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33f2caba5d0ff617ad9e9ab75aea26418dcefc2b6019646b387b3ba5afd7ac5f',1978,'LS','Lesotho','people-and-society',308,'Population: 1,277,000 (July 1978), average annual growth
rate 2.2% (current)
Nationality: noun—Mosotho (sing.), Basotho (pl.); adiec-
tive—Basotho
Ethnic divisions: 99.7% Sotho, 1,600 Europeans, 800
Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular; English
is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged in
subsistence agriculture; 150,000 to 250,000 spend 6 months
to many years as wage earners in South Africa
Organized labor: negligible','61fdbc34dd74636a5dc5eb332c621a9b7bc4b5014d5472e567581252493a1a07','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3758fc4643e42a19d4e26c232326130c531329675230bb3c3a022094aa75f4f1',1978,'LR','Liberia','people-and-society',312,'Population: 1,733,000 (January 1978), average annual
growth rate 3.3% (current)
Nationality: noun—Liberian(s); adjective—Liberian
Ethnic divisions: 5% descendants of immigrant Negroes;
95% indigenous Negroid African tribes including Kpelle,
Bassa, Kru, Grebo, Gola, Kissi, Krahn, and Mandingo
Religion: probably more Muslims than Christians;
70%-80% animist
Language: English official; 28 tribal languages or dialects,
pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 600,000, of which 120,000 are in monetary
economy; about 2,000 non-African foreigners hold about
95% of the top level management and engineering jobs
Organized labor: 2% of labor force','48aa6efbf0b9911a2143efd2f5869997483e465c1879ef7f4bd721fd2a4565ce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b7c18afcc6d56d04fd1df37ac7960ccb052c7526f94397a0088b470d0bb3dfb',1978,'LY','Libya','people-and-society',316,'Population: 2,758,000 (July 1978), average annual growth
rate 4.1% (current)
Nationality: noun—Libyan(s); adjective—Libyan
Ethnic divisions: 97% Berber and Arab with some Negro
stock; some Greeks, Maltese, Jews, Italians, Egyptians
Religion: 97% Muslim
Language: Arabic; Italian and English widely understood
in major cities
Literacy: 35%
Labor force: 900,000 of which about 350,000 are resident
foreigners (est. 1977)','c273c8e0395235d30dae880f9d2c8f8cf6bed394d7f15bcebc64067053ce3c83','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e26638f61f9db36d79ae97b880f34e63788290301ba49f39feaff1d6e2355cd3',1978,'LI','Liechtenstein','people-and-society',320,'Population: 22,000 (July 1978), average annual growth
rate 0.5% (current)
Nationality: noun—Liechtensteiner(s); adjective—
Ethnic divisions: 95% Germanic, 5% \\talian and other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
Labor force: 7,000, 3,500 foreign workers (mostly from
Austria and Italy); 59% industry, 20% trade and commerce,
13% professional and other, 8% agriculture','87b727f2afd7814f8e0a04123bd0c2dcbb412188ceebff15c5935d50cce87d85','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3dabc68c29be80185e0d1fe58446cb7f6a21269411520719a9c8ac2891cfe3a',1978,'LU','Luxembourg','people-and-society',324,'Population: 358,000 (July 1978), average annual growth
rate 0.4% (current)
Nationality: noun—Luxembourger(s); adjective—Luxem-
bourg
Ethnic divisions: 83% Luxembourger, including an
estimated 5% of Italian descent; remainder F rench, German,
Belgian, etc.
Religion: 97% Roman Catholic, remaining 3% Protestant
and Jewish
Language: Luxembourgish, German, French; most edu-
cated Luxembourgers also speak English
Literacy: 98%
Labor force: (1974) 158,000; 10% agriculture (including
forestry and fishing), 48% industry, 42% services; 30% of
labor force is foreign, comprising workers from neighboring
areas of Belgium, France, and West Germany, as well as
Italy and Portugal, unemployment 0.6% August 1977
Organized labor: 45% of labor force
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
i hu TCT_"™
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
LUXEMBOURG/MACAO','aab5bc4505a2df1aea939e8e994ac4e07a55ef0bb368eb0fe8ee9d1517467d7a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d73646e1cd6e1276ddf5385cbf75dd7d33b12448563eb35f9f5672f0b6773951',1978,'MO','Macao','people-and-society',328,'Population: 251,000 (official estimate for | July 1972)
Nationality: noun—Macaon(s); adjective—Macaon
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics, about
one-half are Chinese
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% among Portuguese and Macanese;
no data on Chinese population
Labor force: 5% agriculture, 30% manufacturing, 3%
construction, 1% utilities, 27% commerce, 8% transportation
and communications, 26% services (1960 data)','5c22df53ff886c4f478de6822dad9da29d9fce42dc3520194087b82569432b7d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd12cfd27e7557b7b646e881a318182736e40b90300754a272ac4d6465672557',1978,'MG','Madagascar','people-and-society',332,'Population: 8,158,000 (July 1978), average annual growth
rate 2.4% (current)
Nationality: noun—Malagasy (sing. and pl.); adjective—
Malagasy
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Indian Ocean
{See reference map V1}
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting of Mer-
ina (1,643,000) and related Betsileo (760,000), on the one
hand, and coastal tribes with mixed Neeroid, Malayo-Indo-
nesian, and Arab ancestry on the other; coastal tribes include
Betsimisaraka 941,000, Tsimihety 442,000, Sakalava
375,000, Antaisaka 415,000; there are also 10-12,000
European French, 5,000 Indians of French nationality, and
5,000 Creoles
Religion: more than half animist; about 41% Christian,
7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are
nonsalaried family workers engaged in subsistence agricul-
ture; of 175,000 wage and salary earners, 26% agriculture,
17% domestic service, 15% industry, 14% commerce, 11%
construction, 9% services, 6% transportation, 2% miscel-
Janeous
Organized labor: 4% of labor force
Indian
Ocean
(See reference map Vi}
Ethnic divisions: 98.7% African, 1.1% European, 0.2%
other
Religion: 82% animist, about 17% Christian, and under
1% Hindu and Muslim
Language: English official; wide variety of indigenous
languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000 Africans,
27,000 non-Africans; 15% mining, 9% agriculture, 9%
domestic service, 19% construction, 9% commerce, 10%
manufacturing, 23% government and miscellaneous services,
6% transport
Organized labor: 100,000 wage earners, primarily in
industrial sector, are unionized (early 1968)','935b4e0bd620582b04a2da0996918c28aedbdceb1896d670ccc1d01130571e0f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59eaaef0db58c98f7906faea2102df7378126a6828adc4e9b210f87375206892',1978,'MW','Malawi','people-and-society',336,'Population: 5,694,000 (July 1978), average annual growth
rate 2.9% (8-66 to 10-77)
124
SOUTHERN
RHODESIA
(See reference map Vif
Nationality: noun—Malawian(s); adjective—Malawian
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: majority animist; rest Christian and Muslim
Language: English and Chichewa official; Lomwe is
second African language
Literacy: 15% of population
Labor force: 225,000 wage earners employed in Malawi
(1974); 30% agriculture, 11% construction, 10% commerce,
13% manufacturing, 10% administration, 26% miscellaneous
services; 6,000 Europeans permanently employed
Organized labor: small minority of wage earners are
unionized','d08c22e4ae23126465cd5e6995756efd9d4fd7168641d8afc7fb1affef80734d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d6f8246cd711a73869ab091485a6968e078b0ffe8679864932e089dc6c5d6c8',1978,'MY','Malaysia','people-and-society',340,'Population: 12,864,000 (July 1978), average annual
growth rate 2.7% (current)
Peninsular Malaysia: 10,725,000, average annual
growth rate 2.5% (7-70 to 7-76)
Sabah: 948,000, average annual growth rate 4.8% (7-70
to 7-76)
Sarawak: 1,191,000, average annual growth rate 2.6%
(8-70 to 1-75)
Nationality: noun—Malaysian(s), adjective—Malaysian
Ethnic divisions:
Malaysia: 50% Malay, 35% Chinese, 10% Indian
Peninsular Malaysia: 53% Malay, 35% Chinese, 11%
Indian and Pakistani, 1% other
Sabah: 21% Chinese, 69% indigenous tribes, 10% other
125
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Sarawak: 30% Chinese, 50% indigenous tribes, 19%
Malay, 1% other
Religion:
Peninsular Malaysia: Malays nearly all Muslim,
Chinese predominantly Buddhists, Indians predominantly
Hindu
Sabah: 38% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and Confucianist,
16% Christian, 35% tribal religion, 2% other
Language:
Peninsular Malaysia: Malay (official); English, Chinese
dialects, Tamil
Sabah: English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among Chinese
Sarawak: English, Malay, Mandarin, numerous tribal
languages
Literacy:
Peninsular Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 4.2 million (1975)
Peninsular Malaysia: 3.6 million; 46.2% agriculture,
forestry, and fishing, 10.9% manufacturing and construction,
31.9% trade, transport, and services (1975)
Sabah: 213,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 13% trade and
transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture, forestry, and
fishing, 6% manufacturing and construction, 18% trade,
transportation, and services, 1% other
Organized labor: 500,000 (1975 est.), about 15% of total
labor force; unemployment about 7% of total labor force, but
higher in urban areas','f94ea6bfa3fb422eb47e6d498911b2330ad1693bfbacc4a6c5978ea6c1cca8c3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec67d0e3c12d96fdb175e73c0e516696c41e17caf90413736c109ce67d6de1cf',1978,'MV','Maldives','people-and-society',346,'Population: 141,000 (July 1978), average annual growth
rate 2.4% (current)
Nationality: noun—Maldivian(s); adjective—Maldivian
Ethnic divisions: admixtures of Sinhalese, Dravidian,
Arab, and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the male
population
128','4ea2d95bb3add913e7ec6d36d300412878a0c987d5d28384a8aa4ee785e7ebe9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18f44e1b82d61fdf10b32bfb28c1b3e8c384506def1193324c87b8e652618463',1978,'ML','Mali','people-and-society',350,'Population: 6,284,000 July 1978), average annual growth
rate 2.6% (current)
Nationality: noun—Malian(s); adjective—Malian
Ethnic divisions: 99% native African including tribes of
both Berber and Negro descent
Religion: 90% Muslim, 9% aniniist, 1% Christian
Language: French official; several African languages, of
which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried, 50,000 of
whom are employed by the government; most of population
engaged in agriculture and animal husbandry
Organized labor: Union National des Travailleurs Maliens
(UNTM) is umbrella organization over thirteen national
unions
Population: 334,000 (official estimate for 31 August 1977)
Nationality: noun Maltese (sing. and pl.); adjec-
tive Maltese
Ethnic divisions: mixture of Arab, Sicilian, Norman,
Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education introduced in
1946
Labor force: 119,554 (November 1977); 382% services
(except government), 18% government (except job corps),
130
5% job corps, 26% manufacturing, 6% agriculture, 3%
construction, 5% utilities and drydocks; 4% registered
unemployed
Organized labor: approximately 40% of labor force','2c2bec9904db171a312b64e1cec3df86db6ded1ba465901477e5da75fba461b7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a780bef447c5c5e9cce8a22dfc890b64c6189be84855667366454a97fe7df685',1978,'MQ','Martinique','people-and-society',354,'Population: 327,000 (July 1978), average annual growth
rate 0.2% (10-67 to 10-74)
Nationality: noun Martiniquais (sing. and pl.); adjective
Martiniquais .
Ethnic divisions: 90% African and African-Caucasian-
Indian mixture, less than 5% East Indian Lebanese, Chinese,
5% Caucasian
DOMINICAN Atlantic Ocean
G
Caribbean Sea
)
MARTINIQUE 4
(See reference map tt}
Religion: 95% Roman Catholic, 5% Hindu and pagan
African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public
services, 11% construction and public works, 10% commerce
and banking, 10% services, 9% industry, 17% other
Organized labor: 11% of labor force','4ba8c58ebb85210e9b011b6efff8e850077de9b74abade9e0ef9879105f136f0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb8a3521421fc948fc627fc9668612b9dd3b80a45ce5795806534d2f4ba2dc35',1978,'MR','Mauritania','people-and-society',358,'Population: 1,542,000 (July 1978), average annual growth
rate 2.7% (7-72 to 7-75)
Nationality: noun—Mauritanian(s); adjective— Mauri-
tanian
Ethnic divisions: nearly one third Moor, at least one third
Negro, one third mix Moor/Negro
Religion: nearly 100% Muslim
Language: Hassaniya Arabic is the national language
spoken by some 80% of the population, French is the
working language for government and commerce
Literacy: about 10%
Labor force: about 35,000 wage earners (1976); remain-
der of population in farming and herding; considerable
unemployment
Organized labor: 18,000 union members claimed by
single union, Mauritanian Workers’ Union','f5570d5311357794c7b502638344fed12548c324536257f66e70557826864a78','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bdd6342879360918f4591bc08125d4118a8d8bbee3ef2a04e60395c9e5f244f',1978,'MU','Mauritius','people-and-society',362,'Population: 918,000 (July 1978), average annual growth
rate 1.8% (7-75 to 7-76)
Nationality: noun—Mauritian(s); adjective—Mauritian
Ethnic divisions: 67% Indians, 29% 3.5%
Chinese, 0.5% English and French
Creoles,
133
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Religion: 51% Hindu, 33% Christian (mostly Catholic
with a few Anglican Protestants), 16% Muslim
Language: English official language; Hindi, Chinese,
French Creole
Literacy: estimated 60% for those over 21, and 90% for
those of school age
Labor force: 175,000; 50% agriculture, 6% industry; 20%
government services; 14% are unemployed, underemployed,
or self-employed, 10% other
Organized labor: about 35% of labor force
Population: 491,000 (July 1978), average annual growth
rate 1.3% (1-76 to 1-78)
Nationality: noun—Reunionese (sing. & pl.); adjective—
Reunionese
Ethnic divisions: most of the population is of thoroughly
intermixed ancestry of French, African, Malagasy, Chinese,
Pakistani, and Indian origin
168
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers; high seasonal
unemployment','673dbabbc49e51fef784d54732a6e275d16270e48dd7626afee18382d7bcb123','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0cc1e0b52fe71a53edd4886865f5ea9ac86c76b653b0be1ece52eb45ab1b487',1978,'MC','Monaco','people-and-society',366,'Population: 25,000 (official estimate for 1 July 1976)
Nationality: noun—Monacan(s) or Monegasque(s): adjec-
tive—Monacan or Monegasque
waters (claimed): 12 nm
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism jis official state religion
Language: French
Literacy: almost complete','5c76678ab2fa50fb03173e68f2dfd531b856cf91000e1476a094f9fc5a222257','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4419214b959026a2e635ee12ce1e79362f755f236c573e67ed119aee291129a1',1978,'MN','Mongolia','people-and-society',370,'Population: 1,587,000 (July 1978), average annual growth
rate 3.2% (current)
Nationality: noun—Mongolian(s); adjective—Mongolian
Ethnic divisions: 90% Mongol, 4% Kazakh, 2% Chinese,
2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about 4%
Muslim, limited religious activity because of Communist
regime
Languages: Khalkha Mongol used by over 90% of
population; minor languages include Turkic, Russian, and
Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the
population is in the labor force, including a large percentage
of Mongolian women; shortage of skilled labor (no reliable
information available)','762905d13aee805016aae503cd0390a99a656e61add65751ee1af6ff279e77c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce5f91f8ad6a6a29b86eadbb42822a132303e30d5936fb677d1a438b1d3086ed',1978,'MA','Morocco','people-and-society',374,'Population: 18,915,000 (July 1978), average annual
growth rate 3.0% (7-75 to 7-76)
Nationality: noun—Moroccan(s); adjective—-Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish, 0.7%
non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2% Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, government, diplo-
macy, and postprimary education
Literacy: 20%
Labor force: 5 million (1977 est.); 50% agriculture, 15%
industry, 26% services, 9% other; 10-20% unemployment
Organized labor: about 5% of the labor force, mainly in
the Union of Moroccan Workers (UMT)','2d334e4dea9216ae03b07d9be3d2837b84489aaaa5f56557aadce23833a8270e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89d4a3a822c69aef1c7e966dd04543b62f34b7bfc4b8082582f4a344c5ad30f0',1978,'MZ','Mozambique','people-and-society',378,'Population: 9,866,000 (July 1978), average annual growth
rate 2.4% (current)
139
: CIA-RDP79-01051A000900010006-2
6-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A00090001000
July 1978
MOZAMBIQUE/NAMIBIA
Nationality: noun—Mozambican(s): adjective—Mozam-
bique
Ethnic divisions: over 99% native African, less than 1%
European and Asian
Religion: 65.6% animist, 21.5% Christian, 10.5% Muslim,
2.4% other
Language: Portuguese (official); many tribal dialects
Literacy: 7%-10% (est.)
Labor force: (1963 est.) 610,000; 50,000 non- African wage
earners, 560,000 African wage earners in Mozambique.
290,000 additional African wage earners temporarily work-
ing in Rhodesia and South Africa; unemployment serious
problem; most native Africans provide unskilled labor or
remain in subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970); 75% are
white','abb64f17fac28778445a60372dfa8e52374b4fd8262917b68401ef496c7dc8be','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93040fcfe3f9c60cdc54efe8e7b7b40734d20a85f52006b6fba93c97ca3665a2',1978,'NA','Namibia','people-and-society',382,'Population: 964,000 (July 1978), average annual growth
rate 2.9% (current)
Nationality: noun—Namibian(s); adjective—Namibian
Ethnic divisions: 12% white, 6% mulatto, 82% African;
over half the Africans belong to Ovambo tribe
Religion: whites predominantly Christian, nonwhites
either animist or Christian
Language: Afrikaans principal language of about 70% of
white population, German of 22% and English of 8%; several
African languages
Literacy: high for white population; low for nonwhite
Labor force: 203,300 (total of economically active, 1970);
68% agriculture, 15% railroads, 13% mining, 4% fishing
Organized \\abor: no trade unions, although some white
wage earners belong to South African unions','912e7f11b8d51baa41407e517ce3e3e0972a263a8cbfa2f1d4faece9da474d6b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf0a3bdff83f21a6a77317ee6b4a0a7c01bff7b012a4c55e99ce1061ac5f0e21',1978,'NR','Nauru','people-and-society',386,'Population: 7,000 (official estimate for 30 June 1969)
Nationality: noun—Nauruan(s); adjective—Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
Christian (two-thirds Protestant,
no urban areas,
Religion: one-third
Catholic)
Language: Nauruan, a distinct Pacific Island tongue;
English, the language of school instruction, spoken and
understood by nearly all
Literacy: nearly universal','9012c58ab1aa0850763f8e1054e159b3f21df57a9bc5059790e9680fcfe3168b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d113aaa6273871fb6f213968f21e1fffac91536becd187c7a8a811cfb011f14',1978,'NP','Nepal','people-and-society',390,'Population: 13,680,000 (July 1978), average annual
growth rate 2.5% (current)
Nationality: noun—Nepalese (sing. and pl.); adjective—
Nepalese
Ethnic divisions: two main categories, Indo-Nepalese
(about 80%) and Tibeto-Nepalese (about 20%), representing
considerable intermixture of Indo-Aryan and Mongolian
racial strains; country divided among many quasi-tribal
communities
Religion: only official Hindu Kingdom in world, although
no sharp distinction between many Hindu and Buddhist
groups; small groups of Muslims and Christians
Language: 20 mutually unintelligible languages divided
into numerous dialects; Nepali official language and lingua
franca for much of the country; same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5% industry;
great lack of skilled labor','8c170fb45cc6e3318660ae30bcd8d3c2f58d8060f0290b27c60b27ad242d714d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c9056a8f385b3749ddfbd23e1661c7b8cb1a1dd22f8f53684a66e01b706eec3',1978,'NL','Netherlands','people-and-society',394,'Population: 13,929,000 (July 1978), average annual
growth rate 0.6% (current)
Nationality: noun—Netherlander(s); adjective—Nether-
lands
Ethnic divisions: 99% Dutch, 1% Indonesian and other
Religion: 41% Protestant, 40% Roman Catholic, 19%
unaffiliated
Language: Dutch
Literacy: 98%
Labor force: 4.7 million; 30% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9% construction,
7% transportation and communications, 4% other; 5.1%
unemployment, March 1977
Organized labor: 33% of labor force
Population: 247,000 (July 1978), average annual growth
rate 1.2% (1-75 to 1-76)
145
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
06-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009000100
July 1978
NETHERLANDS ANTILLES
Nationality; noun—Netherlands Antillean(s); adjective—
Netherlands Antillean
Ethnic divisions; racial mixture with African, Caribbean
Indian, European, Latin, and oriental influences; negroid
characteristics are dominant on Curacao, Indian on Aruba
Religion: predominantly Roman Catholic; sizable Protes-
tant, smaller Jewish minorities
Language: officially Dutch; Papiamento, a Spanish-
Portuguese-Dutch-English dialect predominates; English
widely spoken
Literacy: 95%
Labor force: 76,000 (1972); 2% agriculture, 20% industry,
10% construction, 65% government and services, 3% other
Organized labor: 60%-70% of labor force','09f6db85b75907d0d0371395524138627b80495b2fb5968f5f55aa77e4423012','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ef6f2ec81ae4089fcd159f69c5ac8afd20f55fb7cd45b9b0da163089696c3f8',1978,'NC','New Caledonia','people-and-society',398,'Population: 139,000 (July 1978), average annual growth
rate 1.6% (current)
Nationality: noun—New Caledonian(s); adiective—New
Caledonian
Ethnic divisions: Melanesian-Polynesian admixture, over
28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and Tonkinese
laborers were imported for plantations and mines in
pre-World War Il period, immigrant labor now coming
from Wallis Islands, New Hebrides, and French Polynesia
Organized labor: unorganized
Population: 101,000 (July 1978), average annual growth
rate 2.2% (7-74 to 7-77)
Nationality: noun—New Hebridean(s); adjective—New
Hebrides
Ethnic divisions: 92% indigenous Melanesian, 3% Euro-
pean, remainder Vietnamese, Chinese, and various Pacific
Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%','2a75e71e052be2a1327cf6bd65f21d4554e52851c86a8c1c8532b4039f1ed845','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c14b1a1d61ca345b0c4d4bf8b6402883929f3c408c6bc333dea43aff5aa817e',1978,'NZ','New Zealand','people-and-society',402,'Population: 3,116,000 (July 1978), average annual growth
rate 0.8% (7-76 to 7-77)
Nationality: noun—New Zealander(s); adjective—New
Zealand
Ethnic divisions: 98% European, 7% Maori
Religion: 90% Christian, 9% none or unspecified; 1%
Hindu, Confucian, and other
Literacy: 98%
Labor force: 1,207,700; 13% agriculture, 33% manufac-
turing and construction, 9% transportation and communica-
tions, 24% commerce and finance, 21% administrative and
professional; unemployment 5.7% (1976)
Organized labor: 52% of labor force','43110309fd5731c9ab4cc7b8e6293b82e68128cf1b57b5a3695bd49ad861bca8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fa009ab42ad096453d6e5692fdc6cd482f4cb72d9bcb1368cf351123e9bb278',1978,'NI','Nicaragua','people-and-society',407,'Population: 2,409,000 (July 1978), average annual growth
rate 3.1% (current)
Nationality: noun——Nicaraguan(s);
guan
Ethnic divisions: 69% mestizo, 17% white, 9% Negro, 5%
Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English speaking minority
on Atlantic coast
Literacy: 52% of population 10 years of age and over
Labor force: 713,000 (1976 est.); 50% agriculture, 12%
manufacturing, 14% services, 24% other; shortage of skilled
labor, but underemployment of unskilled labor except
during harvest
Organized labor: about 5.6% of labor force
COVERNMENT
Legal name: Republic of Nicaragua
Type: republic
Capital: Managua
Political subdivisions:
departments
Legal system: based on Spanish civil law system;
constitution adopted in 1974; legal education at Universidad
Nacional de Nicaragua and Universidad Centroamericana;
accepts compulsory ICJ jurisdiction
National holiday: Independence Day, 15 September
Branches: President (traditionally dominant), bicameral
legislature, judiciary elected by legislature, and Supreme
Electoral Tribunal (4th branch)
Government leader: President Anastasio Somoza
adjective—Nicara-
1 national district and 16
150
Suffrage: universal over age 18 if married or literate,
otherwise 21
Elections: every 6 years; municipal elections every 3 years
Political parties and leaders: Nationalist Liberal Party
(PLN), Anastasio Somoza; Nicaraguan Conservative Party
(PCN), Rene Sandino
Voting strength (1974 elections): PLN, 95% of votes;
PCN, 5% of votes; PCN will, however, occupy 40% of
legislative seats by constitutional provision
Communists: Communist movement split into hard-line
Nicaraguan Socialist Party (PSN) illegal, 60 members:
soft-line Nicaraguan Communist Party (PCN) illegal, 40
members, and small anti-Somoza terrorist organization
Sandinist National Liberation Front (FSLN) activist, 50-150
members; about 1,000 sympathizers
Other political or pressure groups: Democratic Union of
Liberation (UDEL), an opposition front lacking legal status
of a political ‘party, composed of anti-Somoza_ political
movements and labor groups with orientations ranging from
conservative to Christian Democrat to Communist, leader-
ship includes Ramiro Sacasa, Ignacio Zelaya, Domingo
Sanchez; Nicaraguan Development Institute (INDE), a
private sector pressure group with two operative arms:
FUNDE and EDUCREDITO which, respectively, promote
cooperatives and disburse educational loans
Member of: CACM, FAO, G-77, GATT, IADB, IBRD,
ICAC, ICAO, IDA, IDB, IFC, ILO, IMF, INTELSAT, IPU,
ISO, ITU, NAMUCAR (Caribbean Multinational Shipping
Line—Naviera nacional del Caribe), OAS, ODECA, SELA,
U.N., UNESCO, UPEB, UPU, WHO, WMO','3b9745b569edd6530163594ba0b14edbabaeebd0ed0d162b215492b785275a7f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57d5f4381d002dd0a9f64d46ec4e40286b7671ea7d185bc57a76cd7294935cb7',1978,'NE','Niger','people-and-society',411,'Population: 4,995,000 (July 1978), average annual growth
rate 2.8% (7-76 to 7-77)
Nationality: noun—Nigerien (sing. and pl.); adjective—
Ethnic divisions: main Negroid groups 75% (of which,
Hausa 50%, Dierma and Songhai 21%); Caucasian elements
include Tuareg, Toubous, and Tamacheks; mixed group
includes Fulani
Religion: 80% Muslim, remainder largely animists and a
very few Christians
Gulf of Guinea
{See reference map vi}
Language: French official, many African languages;
Hausa used for trade
Literacy: about 6%
Labor force: 26,000 wage earners; bulk of population
engaged in subsistence agriculture and animal husbandry
Organized labor: negligible','09c22b94ee7c327a9ad36a68d1d7e8c7f76980ba133b87ffecc0b88c61f5dbbf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e46a48069163b9ad276042643034d35f1e693af35ad0fda77a96c8b96d6ff42f',1978,'NG','Nigeria','people-and-society',415,'Population: 68,486,000 (July 1978),
growth rate 2.9% (current)
average annual
Nationality: noun—Nigerian(s); adjective—Nigerian
Ethnic divisions: of the more than 250 tribal groups, the
Hausa and Fulani of the north, the Yoruba of the south, and
the Ibos of the east comprise 60% of the population; about
27,000 non-Africans
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official; Hausa, Yoruba, and tbo also
widely used
Labor force: approx. 22.5 million; about 41% of total
population; roughly 1.3. million wage earners, of whom
560,000 work in modern enterprises
Organized labor: between 800,000 and 1 million wage
earners, approx. 2.4% of total labor force, belong to some 70
unions','43df2152e9d968fb9f0b30f88843ea9e32aeaed533339e4508b9032db96cbf05','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec251b8fd09b2f88ce23e3bcd2075ae2a013e77fd55ed695aaf24bfe7b675a4e',1978,'NO','Norway','people-and-society',419,'Population: 4,061,000 (July 1978), average annual growth
rate 0.4% (7-76 to 7-77)
153
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Norwegian
Sea
NORWAY,
{See reference map iV}
Nationality: noun—Norwegian(s); adjective—Norwegian
Ethnic divisions: homogeneous white population, small
Lappish minority
Religion: 96% Evangelical Lutheran, 4% other Protestant
and Roman Catholic, 1% other
Language: Norwegian, small Lapp and Finnish-speaking
minorities
Literacy: 99%
Labor force: 1.9 million; 11.4% agriculture, forestry,
fishing, 25.3% mining and manufacturing, 8.1% construc-
tion, 16.3% commerce, 9.9% transportion and communica-
tion, 28.5% services; 1.4% unemployed (average annual
1977)
Organized labor: 60% of labor force','4b0fc6c9e44fb34bf62d2cdec9517819c9a42e7a58e0041b4d74ee5c236e616e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea84b5142518404642e66a4c5024741e29c3364bd80572cb65b3448fb25484df',1978,'OM','Oman','people-and-society',423,'Population: 550,000 (July 1978), average annual growth
rate 3.2% (current)
Approved For Release 2005/04/22
Arabian Sea
[See reference map V)
Nationality: noun—Omani(s); adjective—Omani
Ethnic divisions: almost entirely Arab with smal] groups
of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','56a6185c63c2af3833c6fe0cd2d97423e5e1c5665c1a5213ee5ce523440904ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e262e7fa5586b43b7983be12f5ba2ca0e82a2b59dabca283ca537864ba88cb7',1978,'PK','Pakistan','people-and-society',427,'Population: 77,786,000, excluding Junagadh, Manavadar,
Gilgit, Baltistan, and the disputed area of Jammu-Kashmir,
(July 1978), average annual growth rate 3.0% (current)
Nationality: noun—Pakistani(s); adjective—Pakistani
Religion: 97% Muslim, 3% other
Language: official, Urdu; total spoken languages—7%
Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu, 9% other;
English is lingua franca
Literacy: about 17%
Labor force: 20 million (est. 1974); 60% agriculture, 16%
industry, 7% commerce, 15% service, 2% unemployed
Organized labor: 5% of labor force','46729273905f431075a60744999d9adcc41af30d9aacf0b495791f702ee34711','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da53ae540bb757144ae5ed2e3e3bdf4b210242a1ac4847ac2895b1990bccc50f',1978,'PA','Panama','people-and-society',431,'Population: 1,812,000 (July 1978), average annual growth
rate 2.7% (current)
Nationality: noun—Panamanian(s); adjective—Pana-
manian
Ethnic divisions: 70% mestizo, 14% Negro, 9% white, 7%
Indian and other
Religion: over 90% Roman Catholic, remainder mainly
Protestant
Language: Spanish; about 14% speak English as native
tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and over
157
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Labor force: 482,200 (1972 est.); 39.5% commerce,
finance and services; 33.9% agriculture, hunting and fishing;
9.7% manufacturing and mining; 6.8% construction; 5%
Canal Zone; 3.9% transportation and communications; 1.2%
utilities; unemployment estimated at 10% to 13%: shortage
of skilled labor but an oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)','d2aeabcbff8020fa4d9930a1de662df58de9eef8d23d865352f515abad6c47c8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cc17a2097161a88d0b1ded467f066bdb1988ef96e9426992c02707e9e10f885',1978,'PG','Papua New Guinea','people-and-society',435,'Population: 2,985,000 (July 1978), average annual growth
rate 2.6% (7-73 to 7-77)
Nationality: noun—-Papua New Guinean(s); adjective—
Papua New Guinean
Ethnic divisions: predominantly Melanesian and Papuan,
some Negrito, Micronesian, and Polynesian types
Religion: over one-half of population nominally Christian
(490,000 Catholic, 320,000 Lutheran, other Protestant sects);
remainder animist
Language: 700 indigenous languages; pidgin English and
2 or 3 native languages are linguae francae for over one-half
of population; English spoken by 1% to 2% of population
Approved For Release 2005/04/22 :
Literacy: 15%; in English, 0.1%
Labor force: no available figures; mostly subsistence
farmers','0126a510b228fc7987e7aee5d440fc07a827b67b7e99b76860f292e7a858f037','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de5fd8c46481963c1e59dd4cb27ddac33c493401c8d7485ecc16ae40b524b7eb',1978,'PY','Paraguay','people-and-society',439,'Population: 3,095,000 (July 1978), average annual growth
rate 3.1% (current)
160
Nationality: noun—Paraguayan(s); _ adjective—Para-
guayan
Ethnic divisions: 95% mestizo, 5% white and Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10, but
probably much lower (40%)
Labor force: 800,000 (1971 est.); 52.6% agriculture,
forestry, fishing; 28.2% services; 19.2% manufacturing and
mining (1970)
Organized labor: about 5% of labor force','d25b45969a1a001f20487330a70b47f81744e0ab11fbc0fb2c3caeb4b8afb89a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9d4d03b6eacf51a009e967b2ced3766ce93c049596f85219168311024b80c1d',1978,'PE','Peru','people-and-society',443,'Population: 16,818,000 (July 1978), average annual
growth rate 2.8% (current)
Nationality: noun—Peruvian, adjective—Peruvian
Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white; 1% Negro, Japanese, Chinese
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 5.0 million (1975); 42.1% agriculture, 17%
services, 14% manufacturing, 9% trade, 4% construction, 4%
transportation, 2% mining, 4% other
Organized labor: 37.1% of labor force','ddb7d30e791738396950ebafeb3101a9bf87a9e7769e142b035bdd52aacdec2a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7924cf66d6b990aa33850fa9a29326e321fb97309c75fe0aa1a86b95e0673d13',1978,'PL','Poland','people-and-society',447,'Population: 35,030,000 (July 1978), average annual
growth rate 1.0% (current)
Nationality: noun—Pole(s); adjective—Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians, 0.5%
Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic (about 75% practicing),
5% Uniate, Greek Orthodox, Protestant, and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26% industry,
36% other non-agricultural','d8a31f1e158051f84cd8419313fe4b9558d632b27aab499b729487d77f0a4a37','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0583a1b32bae9011a544580510a4b2c2f0d4021c61746621be77e72822ea979b',1978,'PT','Portugal','people-and-society',451,'Population: metropolitan Portugal (including the Azores
and Madeira Islands), 9,786,000 (July 1978), average annual
growth rate 0.6% (1-76 to 1-77)
Nationality: noun—Portuguese (sing. & pl.); adjective—
Portuguese
Ethnic divisions: homogeneous Mediterranean stock in
mainland, Azores, Madeira Islands; citizens of black African
descent who immigrated to mainland during decolonization
number less than 100,000
Religion: 97% Roman Catholic, 1% Protestant sects, 2%
other
Language: Portuguese
Literacy: 70%
Labor force: (1976) 3.2 million; 27% agriculture, 36%
industry, 37% services; unemployment—now more than
14%—is largely due to influx of refugees from former
colonies, returning migrant workers, and military cutbacks
Organized labor: the Communist-dominated General
Confederation of Portuguese Workers—National Intersindi-
cal (GCTP-IN) claims to represent 85% of the labor force;
the Socialists and Social Democrats have lost ground over the
last year despite efforts to improve their standing with
organized labor','b0a31707d51260d7ddc15dbb5b38a37dc42b86d46ec03a5b754f6eae8d72453a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a4a8b48e322aba50b7465171d16d0b350ade6f109a1c4301d75e81d51d8678f',1978,'QA','Qatar','people-and-society',455,'Population: 162,000 (July 1978), average annual growth
rate 3.2% (current)
Nationality: noun—Qatari(s); adjective—Qatari
Ethnic divisions: 56% Arab; 23% Iranian; 14% Pakistani;
7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: primarily foreign','a80c9240c70c7763f22b5bc5b3ec322f511e5cc2b9d034be0284846548373fdb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('081c8371fa0a842157d15604d492358efc400045e16705ffe5e30112ef9b3650',1978,'RO','Romania','people-and-society',458,'Population: 21,868,000 (July 1978), average annual
growth rate 0.9% (current)
Nationality: noun—Romanian(s); adjective—Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian, 2%
German, 3% other
Religion: 14 million Romanian Orthodox, 1 million
Roman Catholic, 1 million Protestants, 60,000 Jews, 30,000
Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.2 million (1975); 38% agriculture, 31%
industry, 31% other nonagricultural','30b58ec4b2d22d32a262bca3da37756d9a8567a96ea63500e238cf3198191098','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9afd4172b3c03103829fe21638c17fcd7eda879a7696fc162dc78d8ebc2f1ba',1978,'RW','Rwanda','people-and-society',462,'Population: 4,444,000 (July 1978), average annual growth
rate 2.9% (current)
Nationality: noun Rwandan(s); adiective—Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1%
(Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1% Muslim, rest
animist
Twa
Language: Kinyarwanda and French official; Kiswahili
used in commercial centers
171
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
RWANDA/ST. CHRISTOPHER-NEVIS-AN GUILLA
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','91d5f55a106238d225b1852d8ed034f8ad0f6d9c4f3599630427693364192974','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b06b06c811cfb7046848bc7d8b9d64b05f71c20c031ee91083c6e1f6802ead0',1978,'SM','San Marino','people-and-society',466,'Population: 20,000 (official estimate for 30 June 1976)
Nationality: noun—Sanmarinese (sing. & pl.); adjective—
Sanmarinese
Religion: Roman Catholic
Language: Italian
Literacy: illiteracy relatively insignificant
Labor force: approx. 4,300
Organized labor: General Democratic Federation of
Sanmarinese Workers (affiliated with ICFTU) has about
1,800 members; Communist-dominated Camera del Lavoro,
about 1,000 members','11f7d9e69d5ff3638ce4055771dba9b6a93d7955b1c48a918de0816b24db3e2b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abd0af677a29f570641d139ad883fe59c5a1b6f00ec2589c49241d93fd866088',1978,'ST','Sao Tome and Principe','people-and-society',470,'Population: 75,000 (official estimate for 1 July 1972)
Nationality: noun—Sao Tomean(s): adjective—Sao
Tomean
Ethnic divisions: native Sao Tomeans, migrant Cape
Verdians, Portuguese
Religion: Roman Catholic, Evangelical Protestant,
Seventh Day Adventist
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SAO TOME AND PRINCIPE/SAUDI ARABIA
Language: Portuguese official
Literacy: estimated at 5%-10%
Labor force: most of population engaged in subsistence
agriculture and fishing; nearly half the island’s work force,
about 10,000 people, are unemployed, the other half work
on cocoa plantations','b5ce701576f776fa53ed9e70b0efdad8e7425c3c6c236e89c715a8375b160530','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('febcb133a991cf732d146f20045600178310aca49cb913e67fc9cf794d7c0d92',1978,'SA','Saudi Arabia','people-and-society',474,'Population: 7,862,000 (J uly 1978), average annual growth
rate 3.1% (current)
Nationality: noun—Saudi(s); adjective—Saudi Arabian or
Saudi
Ethnic divisions: 90% Arab, 10% Afro-Asian (est.)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 33% (one-half foreign) of population;
40% agriculture and herding, 12% construction, 12% service,
12% government, 11% commerce, 138% other','9c11cc69372ba5e37be72d7a63fcba2905ce26b07cde3cbad1f7d3eb9b4df846','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c03a488a831b3a0ffdf6d785e3d20c5fb11066b63e3827d25f42893bbc2175e8',1978,'SN','Senegal','people-and-society',478,'Language: French official, but regular use limited to
literate minority; most Senegalese speak own tribal language;
use of Wolof vernacular spreading—now spoken to some
degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence agricul-
tural workers; about 170,000 wage earners
Organized labor: majority of wage-labor force repre-
sented by unions; however, dues-paying membership very
limited, three labor central unions, major central is CNTS,
an affiliate of governing party','4dfd04cd6f6a432e79dbdf966a9b950b50ee45511c0d16441deea330c9879568','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1998450b064f0eb4d3036de8dcd163032c434b48d59c1cf7013abce344a2418c',1978,'SC','Seychelles','people-and-society',482,'Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans)
Religion: 90% Roman Catholic
Language: English official; Creole most widely spoken
Literacy: limited; 90% of school-age population is
attending school
Labor force: 15,000 in monetized sector (excluding self-
employed, domestic servants, and workers on small farms);
33% public sector employment, 20% private sector employ-
ment in agricuture, 20% private sector employment in
construction and catering services
Organized labor: 3 major trade unions','4dfae44dbb17cefafefeb30dbf8b29c27b9329ab1ffb9da9a156209fe0e7d981','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dad6320dd466c48b05e302a2e29c1d052b453853bd23603af72b9c005b58a27',1978,'SL','Sierra Leone','people-and-society',486,'Population: 3,256,000 (July 1978), average annual growth
rate 2.3% (12-74 to 7-76)
Nationality: noun—Sierra Leonean, adjective—Sierra
Leonean
Ethnic divisions: over 99% native African, rest European
and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited to
literate minority; principal vernaculars are Mende in south
and Temne in north; “Krio,” the language of the resettled
ex-slave population of the Freetown area, is used as a lingua
franca
Literacy: about 10%
Labor force: about 1.5 million, most of population
engages in subsistence agriculture; only small minority, some
70,000, earn wages
Organized labor: 35% of wage earners','be7e7cf01d97f54c4f53bffc3d44cfae44ecaca8537770f5e22c9c1c4970468b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61c14c6b2b385dde63187e3e2a798c92ea91ddbc6f49d9e1c4eb517473745e9c',1978,'SG','Singapore','people-and-society',489,'Population: 2,339,000 (July 1978), average annual growth
rate 1.3% (7-76 to 7-77)
Nationality: noun—Singaporean(s), adjective—Singapore
Ethnic divisions: 76.2% Chinese, 15% Malay, 7% Indians
and Pakistani, 1.8% other
Religion: majority of Chinese are Buddhists or atheists;
Malays nearly all Muslim; minorities include Christians,
Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese, Malay,
Tamil, and English are official languages
Literacy: 70% (1970)
Labor force: 474,718; 0.5% agriculture, forestry, and
fishing, 0.4% mining and quarrying, 32.2% manufacturing,
30.4% services, 5.2% construction, 21.5% commerce, 9.8%
transport, storage, and communications
Organized labor: 24% of labor force','9c75ae7120623db18489b3a056f31544cefc3a6cbc688cbdf32b8a7758f760a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1438e2685d509ba8304ca30f212236722cdd8dd1f06541db671bd8b9598259d0',1978,'SB','Solomon Islands','people-and-society',492,'Population: 212,000 (July 1978), average annual growth
rate 3.2% (current)
Nationality: noun—Solomon Islander(s); adjective—Solo-
mon Islander
Ethnic divisions: 93.0% Melanesians, 4.0% Polynesians,
1.5% Micronesians, 0.3% Chinese, 0.8% Europeans, 0.4%
others
Religion: almost all at least nominally Christian; Roman
Catholic, Anglican, and Methodist churches dominant
Literacy: 60%','45b4761aaa5c3254a1250b52c138a7f1d49ea5dfed7f10154b4f71aeb8dee845','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03c1ec1ad28ff3e63d66c3aa60fd0ee1c7c14441ce54a637688766f0ddcdff0e',1978,'SO','Somalia','people-and-society',496,'Population: 3,388,000 (July 1978), average annual growth
rate 2.4% (current)
Nationality: noun—Somali(s); adjective—Somali
Ethnic divisions; 85% Hamitic, rest mainly Bantu; 30,000
Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form instituted by government
in 1976); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are skilled
laborers; 70% pastoral nomads, 30% agriculturists, govern-
ment employees, traders, fishermen, handicraftsmen, other
Organized labor: General Federation of Somali Trade
Unions, a government-controlled organization, established in
1977','c140dfab9842a79a970f31e53238e064d5cf418fe5ad7f3e44c31727e66ab8d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c21a866b695f58c266c26611ec465cb649113479c7d234a6c5d99133f0cfb25',1978,'ZA','South Africa','people-and-society',500,'Population: 27,432,000, including Bophuthatswana and
Transkei (July 1978), average annual growth rate 2.5% (7-75
to 7-76); Bophuthatswana 1,110,000 (July 1978), average
annual growth rate 2.2% (current); Transkei 2,190,000 (July
1978), average annual growth rate 2.2% (current)
Nationality: noun—South African(s); adjective—South
African
Ethnic divisions: 17.8% white, 69.9% African, 9.4%
Colored, 2.9% Asian
Religion: most whites and coloreds and roughly 60% of
Africans are Christian; roughly 60% of Asians are Hindu,
20% are Muslim
Language: Afrikaans and English official, Africans have
many vernacular languages
Literacy: almost all white population literate; government
estimates 50% of Africans literate
Labor force: 8.7 million (total of economically active,
1970); 53% agriculture, 8% manufacturing, 7% mining, 5%
commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is
unionized (mostly white workers); relatively small African
unions have no bargaining power
Population: 2,190,000 (July 1978), average annual growth
rate 2.2% (current)
Nationality: noun—Transkeian(s); adjective—Transkeian
Ethnic divisions: 98.9% African, 0.6% white, 0.5%
colored (mulatto); Africans belong to Xhosa ethnic group
Religion: whites and coloreds predominantly Christian;
Africans either animist or Christian
Language: whites, coloreds, and educated minority of
Africans speak Afrikaans or English; bulk of Africans speak
Xhosa
Literacy: high for whites and coloreds; low for Africans
Labor force: roughly 400,000 of whom only 50,000 are
regularly employed in Transkei; bulk are migrant workers in
Organized labor: no trade union, although some Trans-
keians employed in South Africa belong to South African
unions','778245ad145da0661de5e504e4b9d0bd17f07efd6de86e961524998d320f47e5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbf802201b2270fcb0cc89b1cd59fdbe8ce229ee116790ce1b56e7abb6a8fb8d',1978,'ES','Spain','people-and-society',504,'Population: 36,734,000, including the Balearic and
Canary Islands; also including Alhucemas, Ceuta, Chafar-
inas, Melilla, and Penon de Velez de la Gomera (July 1978),
average annual growth rate 1.1% (current)
Nationality: noun—Spaniard(s); adiective—Spanish
187
: CIA-RDP79-01051A000900010006-2
6-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A00090001000
July 1978
Atlantic
Ocean
CANARY
ISLANDS
.
Fo @O
(See reference map 1V)
Ethnic divisions; homogeneous composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great majority;
but 17% speak Catalan, 7% Galician, and 2% Basque
Literacy: about 97%
Labor force (1975): 13.3 million: 29% agriculture, 38%
industry, 40% services; unemployment now estimated at 8%
of labor force
Organized labor: labor unions legalized April 1977
experiencing surge in membership; probably represent about
20% of the labor force','877d5ccc598b36dfdc0cc93d4fc22fc2f64f876091e20de06589fdb727128829','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fd850f1cea0a59bbd77347e71b814b3422fe750b11066c3c5eb8d972525bc6f',1978,'LK','Sri Lanka','people-and-society',507,'Population: 14,283,000 (July 1978), average annual
growth rate 1.5% (current)
Nationality: noun—Sri Lankan(s); adjective—Sri Lankan
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6% Moor,
2% other
Religion: 64% Buddhist, 20% Hindu, 9% Christian, 6%
Muslim, 1% other
Language: Sinhala official, spoken by about 70% of
population; Tamil spoken by about 22%: English commonly
used in government and spoken by about 10% of the
population
Literacy: 82% (1970 est.)
Labor force: 4 million; 17% unemployed; employed
bersons—53.4% agriculture, 14.8% mining and manufactur-
ing, 12.4% trade and transport, 19.4% services and other;
extensive underemployment
Organized labor: 43% of labor force, over 50% of which
employed on tea, rubber, and coconut estates','5f2ed923f9f8a8f33f23ec2904f61539c1e86a974fdb5522c081bbd6f025642d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a5c66259d89ca64c52890e43ca20c383cfd89a0ca45170bd961f5c19b4327b3',1978,'SD','Sudan','people-and-society',511,'Population: 17,624,000 (July 1978), average annual
growth rate 3.2% (current)
Nationality: noun—Sudanese (sing. and pl.); adjective—
Sudanese
Ethnic divisions: 39% Arab, 6% Beja, 52% Negro, 2%
foreigners, 1% other
Khartoum ,
(See ceference map Vi}
Religion: 73% Sunni Muslims in north, 28% pagan, 4%
Christian (mostly in south)
Language: Arabic, Nubian, Ta Bedawie, diverse dialects
of Nilotic, Nilo-Hamitic, and Sudanic languages, English;
program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15% industry,
commerce, services, etc.; labor shortages exist for almost all
categories of employment
Population: 385,000 (July 1978), average annual growth
rate 1.5% (1-63 to 1-77)
Nationality: noun—Surinamer(s); adjective—Surinamese
Ethnic divisions: 31% Creole (Negro and mixed), 37%
Hindustani (East Indian), 15.3% Javanese, 10.3% Bush
Negro, 2.6% Amerindian, 1.7% Chinese, 1.0% Europeans,
1.7% other and unknown
Religion: Hindu, Muslim, Roman Catholic, Moravian,
other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SURINAM/SWAZILAND
Language: Dutch official; English widely spoken; Sranan
Tongo (Surinamese, sometimes called Taki-Taki) is native
language of Creoles and much of the younger population,
and is lingua franca among others; Hindi; Javanese
Literacy: 80%
Labor force: 118,000
Organized labor: approx. 33% of labor force
Population: 526,000 (July 1978), average annual growth
rate 2.8% (5-66 to 8-76)
193
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SWAZILAND
{See refereace map VI)
Nationality: noun—Swazi(s); adjective—Swazi
Ethnic divisions: 96% African, 3% European, 1% mulatto
Religion: 43% animist, 57% Christian
Language: English and siSwati are official languages,
government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in subsistence
agriculture; 55,000-60,000 wage earners, many only inter-
mittently, with 31% agriculture, 11% government, 11%
manufacturing, 12% mining and forestry, 835% other (1968
est.); 22,000 employed in South African mines (1976)
Organized labor: about 15%
unionized','07fbfcb543c420eebd3de824c4ca066812a11da809bb657d58807d12dc3f0239','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a8b51cfcd8dde571dbe3b1d283ec6c9c62ffea9d6296a5c8886c8d1fe8dd18e',1978,'SE','Sweden','people-and-society',515,'Population: 8,273,000 (July 1978), average annual growth
rate 0.2% (current)
Nationality: noun—Swede(s); adjective—Swedish
Ethnic divisions: homogeneous white population; small
Lappish minority
Religion: 92% Evangelical Lutheran, 7% other Protestant,
Roman Catholic, Eastern Orthodox, 1% other
Language: Swedish, small Lapp- and Finnish-speaking
minorities
Literacy: 99%
Labor force: 4.2 million; 6.4% agriculture, forestry,
fishing; 29.2% mining and manufacturing; 7.2% construc-
tion; 13.6% commerce; 6.5% transportation and communica-
tions; 29.8% services including government; 5% banking;
75,000 or 1.8% unemployed (average annual 1977)
Organized labor: 80% of labor force','5f5d42913f185d5941a4d95fb0f412bc9f9b71ae8d89d08301c15d0f97518f93','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('325ab9786ecd603827d2c482c6b24f5b1a6eb256d6f3ec5c1b10d3a62c4ece39',1978,'CH','Switzerland','people-and-society',519,'Population: 6,293,000 (July 1978), average annual growth
rate —0.1% (1-73 to 1-77)
Nationality: noun—Swiss (sing. & pl.); adjective——Swiss
Ethnic divisions: total population—69% German, 19%
French, 10% Italian, 1% Romansch, 1% other; Swiss
nationals—74% German, 20% French, 4% Italian, 1%
Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals—74% German, 20% French,
4% Italian, 1% Romansch, 1% other: total population—69%
German, 19% French, 10% Italian, 1% Romansch, 1% other
Literacy: 98%
Labor force: 3.0 million, about one-fifth foreign workers,
mostly Italian; 16% agriculture and forestry, 47% industry
and crafts, 20% trade and transportation, 5% professions, 2%
in public service, 10% domestic and other; approximately
0.4% unemployed in August 1975
Organized labor: 20% of labor force
Population: 8,124,000 (July 1978), average annual growth
rate 3.3% (current)
Nationality: noun—Syrian(s); adjective—Syrian
197
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SYRIA
{See reference map V}
Ethnic divisions: 90.3% Arab; 9.7% Kurds, Armenians,
and other
Religion: 70.5% Sunni Muslim, 16.3% other Muslim sects,
13.2% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and
English widely understood
Literacy: about 40%
Labor force: 2 million; 50% agriculture, 19% industry
(including construction), 31% miscellaneous services; major-
ity unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 16,838,000 (July 1978), average annual
growth rate 3.0% (current)
Nationality: noun—Tanzanian(s); adjective—Tanzanian
Ethnic divisions: 99% native Africans consisting of well
over 100 tribes; 1% Asian, European, and Arab
Religion: Tanganyika—40% Animist, 30% Christian, 30%
Muslim; Zanzibar—almost all Muslim
Language: Swahili and English official, English primary
language of commerce, administration and higher education;
Swahili widely understood and generally used for communi-
cation between ethnic groups; first language of most people
is one of the local languages
Literacy: 15%-20%
Labor force: under 400,000 in paid employment, over
90% in agriculture
Organized labor: 15% of labor force','f712d6af5033f514a7670a1855c526f72e351aff5119829e4e0bbc6e241dfe86','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5aab56c6f00fd2d8e40fde0df0b097b86d09dddd7ada7d1f2c4dd5c78ea5fbe',1978,'TH','Thailand','people-and-society',523,'Population: 45,850,000 (July 1978), average annual
growth rate 2.6% (current)
Nationality: noun—Thai (sing. & pl.); adjective—Thai
Ethnic divisions: 75% Thai, 14% Chinese, 11% minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5% Christian
Language: Thai; English secondary language of elite
Literacy: 70%
Labor force: 78% agriculture, 15% services, 7% industry','55a4bea4916d29e3c43bf61756666a0e04b834ff48e444fe5829e65006716d44','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfbd6aa158d09f6be573037ea6d021a018344c1699b11acb38353450b55462e6',1978,'TG','Togo','people-and-society',527,'Population: 2,458,000 (July 1978), average annual growth
rate 2.8% (current)
Nationality: noun—Togolese (sing. & pl.); adjective—
Togolese
Ethnic divisions: 37 tribes; largest and most important are
Ewe in south and Cabrais in north; under 1% European and
Syrian-Lebanese
201
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
TOGO/TONGA
Religion: about 20% Christian, 5% Muslim, 75% animist
Language: French, both official and language of com-
merce; major African languages are Ewe and Mina in the
south and Dagomba and Kabie in the north
Literacy: 54.9% of school age (7-14) currently in school
Labor force: over 90% of population engaged in
subsistence agriculture; about 30,000 wage earners, evenly
divided between public and private sectors
Organized labor: 1 national union, the CNTT organized
in 1972','272f8a2674934e89540115f3de6eb6016b753dd1052c06531e53fd2a35aa8802','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc4e5a1a6477b47801c952bd56368843d671183217a1e0f2d62ff3c49708bb89',1978,'TO','Tonga','people-and-society',531,'Population: 90,000 (July 1978), average annual growth
rate 0.3% (current)
Nationality: noun—Tongan(s); adjective—Tongan
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims over
30,000 adherents
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
TONGA/TRINIDAD AND TOBAGO
ee
ao
fidt: ~~ TONGA
*
Nuku‘alofa
NEWSS”
CALEDONIA
Pacific Ocean
(See reference map Vit)
Language: Tongan, English
Literacy: 90%-95%; compulsory education for children
between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','95ab1e9bece59813993ff592ef9d4981426ccc7167c4f9e90fb6cf09b545c810','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de056c9f53b28aafe063ac5eadc74b75bd0a7d07952fd9bbc5a3a80cd35aed01',1978,'TT','Trinidad and Tobago','people-and-society',535,'Population: 1,045,000 July 1978), average annual growth
rate 1.8% (4-60 to 4-70)
Nationality: noun—Trinidadian(s), Tobagonian(s); adjec-
tive—Trinidadian
203
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Ethnic divisions: 43% Negro, 40% Fast Indian, 14%
mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman Catholic, 23.0%
Hindu, 6.0% Muslim, 13.0% unknown
Language: English
Literacy: 95%
Labor force: 393,800 (July 1975), 13:5% agriculture,
20.0% mining, quarrying, and manufacturing, 17.4% com-
merce; 15.7% construction and utilities; 7.5% transportation
and communications, 23.0% services, 2.9% other
Organized labor: 30% of labor force
Population: 6,242,000 (July 1978), average annual growth
rate 2.7% (current)
Nationality: noun—Tunisian(s); adjective—Tunisian
Ethnic divisions: 98% Arab, 1% European, less than 1%
Jewish
Religion: 95% Muslim, 4% Christian, 1% Jewish
Language: Arabic (official), Arabic and French
(commerce)
Literacy: about 32%
Approved For Release 2005/04/22
Labor force: 1.4 million; 45% agriculture, 19% manufac-
turing and construction, 5% trade and finance, 3%
transportation, communications, and utilities, 2% mining;
10%-20% unemployed; shortage of skilled labor
Organized labor: 25% of labor force; General Union of
Tunisian Workers (UGTT), quasi-independent of Destourian
Socialist Party','2075c7c2a1efe4e0ec597e8075916bc5aac7a84ed093c431a13e4dfeff072399','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9464e544db872b9e94cdf9e60721127389fb39ffed0a93be16a5a538be3fa0a',1978,'TV','Tuvalu','people-and-society',539,'Population: 6,000 (preliminary total from census of 8
December 1973)
Ethnic divisions: Polynesian
Religion: Protestant
Literacy: less than 50%','71c6fec5a487b746bbff47adacd4268d5e738eb3f75fcdfd86e912a45c23f6dc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b93ead6c9f3c2efd8119774f618cc15bd2e17e0e0c461b8c2da65ffadc3d2835',1978,'UG','Uganda','people-and-society',543,'Population: 12,780,000 (July 1978), average annual
growth rate 3.5% (current)
Nationality: noun—Ugandan(s); adiective—Ugandan
Ethnic divisions: 99% African, 1% European, Asian, Arab
Religion: about 60% nominally Christian, 5%-10% Mus-
lim, rest animist
Language: English official; Luganda and Swahili widely
used; other Bantu and Nilotic languages
208
See reference map Vi)
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which about
250,000 in paid labor, remaining in subsistence activities
Organized labor: 125,000 union members
Population: 261,382,000 (uly 1978), average annual
growth rate 0.9% (current)
Nationality: noun—Soviet(s); adiective—Soviet
Ethnic divisions: 74% Slavic, 26% among some 170 ethnic
groups
Religion: 70% atheist, 18% Russian Orthodox, 9% Muslim,
3% other
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
{See reference imap Vit)
Language: more than 200 languages and dialects (at least
18 with more than 1 million speakers); 76% Slavic group, 87%
other Indo-European, 11% Altaic, 3% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 137 million (mid-year 1977), 25%
agriculture, 75% industry and other non-agricultural fields,
unemployed not reported, shortage of skilled labor reported','579083da0f722b39c8754c2e6cb419c659e813100ea136c8eab6567ed3b950d1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c255367e771cf8969f2601dcc8dfcae568b1438b7708f516fcca2ccd92efb7dc',1978,'AE','United Arab Emirates','people-and-society',547,'Population: 656,000 (preliminary total from the census of
29 August 1975)
Ethnic divisions: Arabs 42%, South Asians 50% (fluctuat-
ing), other expatriates (includes Westerners and East Asians
8%
Religion: Muslim 96%, Christian, Hindu and other 4%
Language: Arabic
Literacy: 25% est. (1975)
Labor force: 203,000 (1975 est.); 85% in industry; 2%
U.A.E. Arabs, 7% non-U.A.E. Arabs, 91% Indians, Pakistanis,
Iranians','bbea688f0de19f63bff99cdc3d0a04a90036fa8b9eb45e9ca5d239a65531a3d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f26a43d3cf2ea3a724e4b87f959252555aade9a4b83d32317d519570cd8b6fd',1978,'GB','United Kingdom','people-and-society',551,'Population: 55,894,000 (July 1978) average annual
growth rate —0.1% (current)
Nationality: noun—Briton(s), British (collective — pl.):
adjective—British
Ethnic divisions: 83% English, 9% Scottish, 5% Welsh, 3%
Irish
Religion: 27.0 million Church of England, 5.3 million
Roman Catholic, 2.0 million Presbyterians, 760,000 Method-
ist, 450,000 Jews (registered)
Language: English, Welsh (about 26% of population of
Wales), Scottish form of Gaelic (about 60,000 in Scotland)
Literacy: 98% to 99%
Labor force: (1974) 25.6 million; 1.6% agriculture, 1.4%
mining, 30.7% manufacturing, 6.2% government, 7.2%
transportation and utilities, 5.2% construction, 10.6% dis-
tributive trades, 25.3% all services, 9.7% other; 2.1%
unemployed
Organized labor: 40% of labor force
Population: 6,508,000 (J uly 1978), average annual growth
rate 2.2% (current)
Nationality: noun—Upper Voltan(s); adjective—Upper
Voltan
Ethnic divisions: more than 50 tribes; principal tribe is
Mossi (about 2.5 million); other important groups are
Gurunsi, Senufo, Lobi, Bobo, Mande, and Fulani
Religion: majority of population animist, about 20%
Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong to
Sudanic family, spoken by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active
population engaged in animal husbandry, subsistence farm-
ing, and related agricultural pursuits; about 30,000 are wage
earners; about 20% of male labor force migrates annually to
neighboring countries for seasonal employment
Organized labor: 4 principal trade union groups','6c03f8b72fa018aaa6a0bf2c2c39e4f845be6d0c09721235b4e3ba962f12285f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64085b414efa2859ce95e0dcc731f9796be6f427fa34625a362190cec7f5c293',1978,'UY','Uruguay','people-and-society',555,'Population: 2,893,000 (July 1978), average annual growth
rate 0.6% (current)
Nationality: noun—Uruguayan(s); adjective—Uruguayan
Ethnic divisions: 85%-90% white, 5% Negro, 5%-10%
mestizo
Religion: 66% Roman Catholic (less than half adult
population attends church regularly)
Language: Spanish
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1963 census); of those employed
in important sectors—25% government; 34% industry; 10%
service; 23% other; 8% agriculture, forestry, fishing and
mining; no shortage of skilled labor
Organized labor: about 25% of labor force
Population: 1,000 (official estimate for 1 July 1976)
Ethnic divisions: primarily Italians but also many other
nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern languages
Literacy: virtually complete
215
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
VATICAN CITY/VENEZUELA
Labor force: approx. 700; Vatican City employees
divided into 3 categories—executives, officeworkers, and
salaried employees
Organized labor: none
Population: 14,058,000, excluding Indian jungle -popula-
tion (July 1978), average annual growth rate 3.3% (current)
adjective—Vene-
Nationality: noun—Venezuelan(s);
zuelan
Ethnic divisions: 67% mestizo, 21% white, 10% Negro,
2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
VENEZUELA
Labor force: 3.7 million (1975); 24% agriculture, 6%
construction, 17% manufacturing, 6% transportation, 18%
commerce, 25% services, 4% petroleum, utilities, and other
Organized labor: 45% of labor force
Population: 51,226,000 (July 1978), average annual
growth rate 2.6% (current)
Nationality: noun— Vietnamese (sing. & pl.); adjective—
Vietnamese
Ethnic divisions: 85%-90% predominantly Vietnamese;
3% Chinese; ethnic minorities include Muong, Thai, Meo,
Khmer, Man, Cham, and mountain tribesman
Religion: Buddhism, Confucianism, Taoism, Catholicism,
Animism, Islam, and Protestantism
Language: Vietnamese, French, Chinese, English, Khmer,
tribal languages (Mon-Khmer and Malayo-Polynesian)
Labor force: approximately 15 million, not including
military; about 70% agriculture and 8% industry','e80b3741159e3d3f4b77ca5a59fa3d9aeb296fb7776f912822b1fe37c4e16a60','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a288886b75155119a6a84ba479bb5a7ca95af0162709c6b027ad055f692631e',1978,'WF','Wallis and Futuna','people-and-society',559,'Population: 9,000 (official estimate for 1 July 1973)
Nationality: noun—Wallisian(s), Futunan(s), or Wallis
and Futuna Islander; adjective—Wallisian, Futunan, or
Wallis and Futuna Islanders
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','eee2ded006719b315e3ecd4d0f9059021c8b24cfd43bd59d59294889fe8428ed','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39d4be30a87257bb1cfcea6d32aa60b562a27a01c461abd5612134fba1950326',1978,'EH','Western Sahara','people-and-society',563,'Population: 75,000 (census of 1974)
Nationality: noun—Saharan(s); adjective—Saharan
Ethnic divisions: Arab, Berber, and Negro nomads
Religion: Muslim
Language: Hassaniya Arabic
Literacy: among Spanish, probably nearly 100%: among
nomads, perhaps 5%
Labor force: 12,000; 50% animal husbandry and subsist-
ence farming, 50% other
Organized labor: none
Population: 155,000 (July 1978), average annual growth
rate 1.0% (1-76 to 1-77)
Nationality: noun—Western Samoan(s); adjective—West-
ern Samoa
Ethnic divisions: Polynesians, about 12,000 Euronesians
(persons of European and Polynesian blood), 700 Europeans
Religion: 99.7% Christian (about half of population
associated with the London Missionary Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all children
from 7-15 years)
Labor force: agriculture 19,148; mining and manufactur-
ing 1,716 (1961)
Organized labor: unorganized
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
WESTERN SAMOA/YEMEN (ADEN)
Population: 1,851,000, excluding the islands of Perim and
Kamaran for which no data are available (July 1978),
average annual growth rate 3.0% (5-73 to 7-77)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: almost all Arabs; a few Indians, Somalis,
and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 35% (est.)
Population: 5,031,000 (July 1978), average annual growth
rate 1.9% (current)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab (mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and herding
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
YEMEN (SANA)/YUGOSLAVIA
Population: 21,973,000 (July 1978), average annual
growth rate 0.9% (current)
Nationality: noun—Yugoslav(s); adjective—Yugoslav
Ethnic divisions: 89.7% Serb, 22.1% Croat, 8.4% Muslims,
8.2% Slovene, 5.8% Macedonian, 2.5% Montenegrin, 6.4%
Albanian, 2.3% Hungarian, 4.6% other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman Catholic,
12% Muslim, 3% other, 12% none (1953 census)
Language: Serbo-Croatian, Slovene, Macedonian, Alba-
nian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 9.2 million (1976); 36% agriculture, 20%
mining and manufacturing, 44% other nonagricultural
activities; estimated unemployment averaged 5% of domes-
tic labor force in 1976
Population: 27,080,000 (July 1978), average annual
growth rate 2.9% (current)
Nationality: noun—Zairian(s); adjective—Zairian
Ethnic divisions: over 200 African ethnic groups, the
majority are Bantu; four largest tribes—Mongo, Luba,
Kongo (all Bantu), and the Mangbetu-Azande (Hamitic)
make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili, Kikongo,
and Chiluba are all classified as official languages
Literacy: 5% fluent in French, about 35% have an
acquaintance with French
Labor force: about 8 million, but only about 13% in wage
structure','de09380fcc30589a618642c425093cd4a9c43748bd1db75212bd80b2d8775411','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33d7cf0201340d0e6afa0f07777860434f28748a5db55656fc891354538d08e7',1978,'ZM','Zambia','people-and-society',567,'Population: 5,471,000 (July 1978), average annual growth
rate 3.2% (7-76 to 7-77)
Nationality: noun—Zambian(s): adjective—Zambian
226','dd94a86bb436146f88b5167d372002154734ca09570f3bf5a8f50e1f6e125fda','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9ae806c698f7e0a230abed3ec6e6687934ba09c56072589318b3546270e2782',1978,'US','United States','people-and-society',569,'Population: 218,437,000 (July 1978), average annual
growth rate 0.8% (current)
Ethnic divisions: 86.5% white, 11.7% black, 1.9% other
Religion: total membership in religious bodies,
129,714,000; Protestant 69,743,000, Roman Catholic
48,882,000, Jewish 6,115,000, other religions 4,973,000
(1975)
Language: English, predominantly
Literacy: almost complete
Labor force: 96.9 million, unemployment 7.7% (1976)
Organized labor: 20.1% of total (1976 prelim.)','7ffafac3a931f8f6e73f66d8b56a291978af06c6c8e10231ac6d4f1ff83c27b8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

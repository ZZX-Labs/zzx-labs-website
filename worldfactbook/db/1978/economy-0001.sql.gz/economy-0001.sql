SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0aa704645f6e2d512b61078e52d8df750945d1491afaf1ea83a9258305f2baa',1978,'AF','Afghanistan','economy',10,'GNP: $2.25 billion (FY77), $110 per capita; real growth
rate about 2.5% (1978-77)
Agriculture: agriculture and animal husbandry account
for over 50% of GNP and occupy nearly 85% of the labor
force; main crops—wheat and other grains, cotton, fruits,
nuts; largely self-sufficient; food shortages—wheat, sugar,
tea
Major industries: cottage industries, food processing,
textiles, cement, coal mining
Electric power: 320,000 kW capacity (1976); 580 million
kWh produced (1976), 30 kWh per capita
Exports: $234 million (f.o.b., FY76); fresh and dried
fruits, natural gas, karakul skins, carpets, hides, and wool
Imports: $278 million (f.0.b., FY76); non-metallic miner-
als, sugar, tires and tubes, textiles, tea, used clothing,
tobacco, transportation
Major trade partners: exports—U.S.S.R., India, U.K.,
Pakistan, West Germany, Switzerland, U.S.; imports—Japan,
U.S.S.R., India, West Germany, U.K., U-S.
Aid: economic—U.S.S.R (1954-76), $1,263 million ex-
tended, $672 million drawn; Eastern Europe (1954-76), $39
million extended, $13 million drawn; China (1965-76), $76
million extended, $36 million drawn; U.S. (FY49-76), $498
million committed; international organizations (1946-75),
$152 million; military—U.S.S.R. (1956-76), $651 million
extended, $571 million drawn; Eastern Europe (1955-76),
$31 million extended, $23 million drawn; U.S. (FY53-76), $5
million committed
Budget: current expenditures $158 million, capital
expenditures $163 million for FY76
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
AFGHANISTAN/ ALBANIA
Monetary conversion rate: 45.3 Afghanis=US§1 (offi-
cial); 55 Afghanis=US$1 (March 1976)
Fiscal year: 21 March-20 March','cbf532e504905011d2d649c9ba733ef4c8b58d48afb84027921fd8ed0d8697c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b8243f0bd8b83e9149b05fa7bb79e0b9df7a2b682b8b8d5a8c8bc85810fab77',1978,'AL','Albania','economy',15,'GNP: $748 million in 1970 (at 1970 prices), $350 per
capita
Agriculture: food deficit area; main crops—corn, wheat,
tobacco, sugar beets, cotton; food shortages—wheat; caloric
intake, 2,100 calories per day per capita (1961/62)
Major industries: agricultural processing, textiles and
clothing, lumber, and extractive industries
Shortages: spare parts, machinery and equipment, wheat
Electric power: 500,000 kW capacity (1976); 1.7 billion
kWh produced (1976), 710 kWh per capita
Exports: $746 million (1971-75 est.); 1964 trade—55%
minerals, metals, fuels; 23% foodstuffs (including cigarettes);
17% agricultural materials (except foods); 5% consumer
goods
Imports: $1,238 million (1971-75 est.); 1964 trade—50%
machinery, equipment, and spare parts; 16% minerals,
metals, fuels, construction materials; 16% foodstuffs; 7%
consumer goods; 7% fertilizers, other chemicals, rubber; 4%
agricultural materials (except foodstuffs)
Monetary conversion rate: 5 leks=US$1 (commercial);
12.5 leks=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for consumption year 1 July-30 June','6ae74438c0897a2fd85435896e92fd8dbe937c66f7418228e80a7da88b70a200','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9ecc9924022fb4711bf3b29bd1266b30a0fea2c42e756fefa9caba66bdbdeac',1978,'DZ','Algeria','economy',19,'GNP: $15.3 billion (1976 provisional), $880 per capita,
average annual increase since 1971 (current prices), 25%; in
real terms, 6% growth in 1976
Agriculture: main crops—wheat, barley, grapes, citrus
fruits
Major industries: petroleum, light industries, natural gas,
mining, petrochemical, electrical, and automotive plants
under construction
Electric power: 1,437,000 kW capacity (1976); 4.0 billion
kWh produced (1976), 230 kWh per capita
Exports: $5.2 billion (f.0.b., 1976); 90% hydrocarbons, also
wine, citrus fruit, iron ore, vegetables; U.S. took 36% of
exports in 1976, supplanting France as Algeria’s leading
trade partner
Imports: $5.3 billion (c.if., 1976); major items—capital
goods 35%, semi-finished goods 38%, foodstuffs 25%; from
France 25%, U.S. 9%
Monetary conversion rate: 1 DA=US$0.24
Fiscal year: calendar year','013e332245541283046960e720800cabbad61232385e2a50b405604e19126c94','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63cac6b49156c47198af573f99a234ae3d10b2e03c7a974f150372a05e383f15',1978,'AD','Andorra','economy',23,'Agriculture: sheep raising; small quantities of tobacco,
rye, wheat, barley, oats, and some vegetables (less than 4% of
land is arable)
Major industries: tourism, sheep, timber, tobacco, and
smuggling
Shortages: food
Electric power: 25,000 kW capacity (1976); 100 million
kWh produced (1976), 5,260 kWh per capita; power is
mainly exported to Spain and France
Major trade partners: Spain, France','18c54842c27e950513ab9c6942f730f763546613ae4e07578ac864cc2fe15fd7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91dcdf2140d361428c96c81c70253f8db2e49f69f88154a02fddcf7e7ea83e4d',1978,'AO','Angola','economy',27,'GDP: $3.0 billion (1974 est.), $500 per capita, 6.1% real
growth (1970-72); growth probably negative in 1975-76
Agriculture: cash crops—coffee, sisal, corn, cotton, sugar,
manioc, and tobacco; food crops—cassava, corn, vegetables,
plantains, bananas, and other local foodstuffs; largely
self-sufficient in food
Fishing: catch 183,850 metric tons (1975); exports $53.0
million; imports $5.6 million (1973)
Major industries: mining (oil, iron, diamonds), fish
processing, brewing, tobacco, sugar processing, textiles,
cement, food processing plants, building construction
Electric power: 670,000 kW capacity (1976); 1.3 billion
kWh produced (1976), 220 kWh per capita
Exports: $1.2 billion (f.0.b., 1974); oil, coffee, diamonds,
sisal, fish and fish products, iron ore, timber, corn, and
cotton; exports down sharply in 1975 and 1976
Imports: $614 million (c.i.f., 1974); capital equipment
(machinery and electrical equipment), wines, bulk iron and
ironwork, steel and metals, vehicles and spare parts, textiles
and clothing, medicines; military deliveries partially offset
drop in imports in 1975
Major trade partners: Portugal, West Germany, U.S.,
U.K., Japan; trade with U.S.S.R. and Cuba increasing since
independence
Aid: military aid from U.S.S.R. and Cuba in 1975
Budget: (1975) balanced at about $740 million by former
Portuguese administration; budget not yet published by new
GDP: $51 million (1974 est.), $640 per capita; 2.7% real
growth
Agriculture: main crop, cotton
Major industries: oil refining, tourism
Shortages: electric power
Electric power: 23,000 kW capacity (1976); 46 million
kWh produced (1976), 640 kWh per capita
Exports: $29 million (f.0.b., 1973); petroleum products,
cotton
Imports: $47 million (c.i-f., 1973); crude oil, food, clothing
Major trade partners: 30% U.K., 25% US., 18%
Commonwealth Caribbean countries
Aid: economic—U.S. authorizations (FY46-75), $1.5 mil-
lion in loans
Budget: (projected 1977) revenues, $17 million; expendi-
tures, $21 million
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)','f17d456b01c2dcdac4b1e1e16efc5ec4138a45899711bef440ea19aef472b522','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65848e2750cb05429101b82f061c20573ed41051498d32fb9b9eacea13a42031',1978,'AR','Argentina','economy',31,'GNP: $48 billion (1976), $1,870 per capita; 18%
government consumption, 62% private consumption, 22%
investment, —2% net foreign demand (1975); real GDP
growth rate 1976, —2.9%
Agriculture: main products—cereals, oilseeds, livestock
products; Argentina is a major world exporter of temperate
zone foodstuffs
Fishing: catch 350,000 metric tons (1976 est.); exports $42
million (1976 est.)
Major industries: food processing (especially meatpack-
ing), motor vehicles, consumer durables, textiles, chemicals,
printing, and metallurgy
Crude steel: 2.4 million metric tons produced (1976), 90
kg per capita
Electric power: 9 million kW capacity (1976); 30 billion
kWh produced (1976), 1,170 kWh per capita
Exports: $3.90 billion (f.0.b., 1976); meat, corn, wheat,
wool, hides, oilseeds
Imports: $3.05 billion (c.i.f., 1976); machinery, fuel and
lubricating oils, iron and steel, intermediate industrial
products
Major trade partners (1976): exports—10% Italy, 6%
U.S.S.R., 9% Netherlands, 11% Brazil, 7% U.S.; imports—
18% U.S. 8% Japan, 11% FRG, 12% Brazil
Aid: economic—extensions from U.S. (FY46-76), $1
billion in loans, $17.9 million in grants; from international
organizations (FY46-75), $1.4 billion; from other Western
countries (1960-66), $315.5 million; from Communist
countries (1954-76), $513 million ($89 million drawn);
military—assistance from U.S. (FY46-76), $265 million
Budget: (1977) 3,171 billion pesos=$8 billion at projected
average parity exchange rate of about 400 pesos=US$1
Monetary conversion rate: official, 140 pesos=US$1; free
market, 450 pesos=US$1 (September 1976)
Fiscal year: calendar year','84fd5303a516422c7906557da3fc5f7f2ea958e6da90648c30f7af829206d520','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efa3b817eedb70dc4ac9727597e0b49c05a9da32981ab533a7eddce6e5c1984d',1978,'NZ','New Zealand','economy',35,'GNP: $93.6 billion (1976), $6,830 per capita; 60% private
consumption, 16% government current expenditure, 24%
investment (1975); real average annual growth (1970-75), 3%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
AUSTRALIA/ AUSTRIA
Agriculture: large areas devoted to livestock grazing; 60%
of area used for crops is planted in wheat; major products—
wool, livestock, wheat, fruits, sugarcane; self-sufficient in
food; caloric intake, 3,300 calories per day per capita
Fishing: catch 103,281 metric tons (1975); exports $94.5
million (FY75), imports $86.2 million (FY75)
Major industries: mining, industrial and transportation
equipment, food processing, chemicals
Crude steel: 7.8 million metric tons produced (FY1976),
570 kg per capita
Electric power: 21,850,000 kW capacity (1976); 81.8
billion kWh produced (1976), 5,970 kWh per capita
Exports: $13.2 billion (f.0.b., 1976); principal products
(1975)—44% agricultural products, 14% metalliferous ores,
8% wool, 8% coal
Imports: $12.5 billion (c.i.f., 1976)
Major trade partners: (1975) exports—29% Japan, 10%
U.S., 5% New Zealand, 5% U.K.; imports—20% U.S., 15%
UK, 18% Japan
Aid: economic—Australian aid abroad $2.3 billion
(FY65-75); $430 million (FY75), 55% for Papua New Guinea
Budget: expenditures, A$22.9 billion; receipts A$18.7
billion (CY76)
Monetary conversion rate: 0.92 Australian dollar=US$1
(A$1=US$1.09), February 1977
Fiscal year: 1 July-30 June
GNP: $11.7 billion (1974), $3,870 per capita; real average
annual growth (1969-74) 3.8%
Agriculture: fodder and silage crops about one-half of
area planted in field crops; main products—wool, meat,
dairy products; New Zealand is food surplus country; caloric
intake, 3,500 calories per day per capita (1964)
Fishing: catch 65,525 metric tons (1975)
Major industries: food processing, textile production,
machinery, transport equipment; wood and paper products
Electric power: 5,480,000 kW capacity (1976); 22.9
billion kWh produced (1976), 7,270 kWh per capita
Exports: $2.8 billion (f.0.b., 1976); principal products
(trade year 1975)—27% meat, 17% dairy products, 15% wool
Imports: $3.3 billion (c.i.f., 1976); 29% machinery, 23%
manufactured goods, 11% chemicals (trade year 1975)
Major trade partners: (trade year 1975) exports—22%
U.K., 12% US., 12% Japan, 11% Australia; imports—19%
Australia, 19% U.K., 14% Japan, 18% U.S.
Aid: gross official aid deliveries to LDC and multilateral
agencies FY75, $80.1 million
Budget: expenditures, 3,827 million NZ$, receipts, 3,330
million NZ$ (FY75)
Monetary conversion rate: NZ$1=US$0.9539, February
1977
Fiscal year: 1 April-31 March
NOTE: trade data are for year ending 30 June 1975; trade
year and fiscal year do not correspond','2e4f047345fc5a523093cc273915064ebdf099423e541f1a567b99e5e2e9ef82','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('889fc2970dd1ab42dc692d9d69909e3db9b9a81eed3fa65c1a09737e4446c6f7',1978,'AT','Austria','economy',39,'GNP: $40.6 billion (1976), $5,390 per capita; 59.2%
consumption, 28.1% investment, 11.8% government, 3.5%
stock building; 2.1% net foreign balance (1976 in 1964
prices); 1976 real GNP growth rate, 5.2%
Agriculture: livestock, cereals, potatoes, sugar beets; 84%
self-sufficient; caloric intake 3,230 calories per day per
capita (1969-70)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Major industries: foods, iron and _ steel, machinery,
textiles, chemicals, electrical, paper and pulp
Crude steel: 4.5 million metric tons produced (1976), 600
kg per capita (1976)
Electric power: 11 million kW capacity (1976); 36.6
billion kWh produced (1976), 4,860 kWh per capita
Exports: $8.5 billion (f.0.b., 1976); iron and steel products,
machinery and equipment, lumber, textiles and clothing,
paper products, chemicals
Imports: $11.5 billion (c.if., 1976); machinery and
equipment, chemicals, textiles, coal, petroleum, foodstuffs
Major trade partners: (1976) 33.6% West Germany, 8.6%
Italy, 6.7% Switzerland, 3.6% France, 2.8% US.; 56.8% EC;
11.7% EFTA; 11.9% Communist countries
Aid: economic—authorized—U.S., $1,135 million through
FY76; IBRD, $105 million through FY73, none since FY62;
military—U.S., $120 million (FY52-76); net official eco-
nomic aid delivered to less developed areas and multilateral
agencies—$205 million (FY62-72), $40.2 million (1973) and
$59.3 million (1974)
Budget: expenditures, $12.4 billion; revenues, $9.9 billion;
deficit $2.5 billion (1976)
Monetary conversion rate: 17.94 shillings=US$1, 1976
average
Fiscal year: calendar year
GNP: $496 million (at market prices, 1973), $2,490 per
capita; real growth rate 1976, est. 0%
Agriculture: food importer, main crops—fish, fruits,
vegetables
Major industries: tourism, cement, oil refining, lumber,
salt production
Electric power: 250,000 kw capacity (1976); 680 million
kWh produced (1976), 3,320 kWh per capita
Exports: $2.6 billion (f.0.b., 1976); fuel oil, pharmaceuti-
cals, cement, rum
Imports: $2.9 billion (c.i.f., 1976); crude oil, foodstuffs,
manufactured goods
Major trade partners: exports—U.S. 86%, U.K. 2%,
Canada 2%; imports—U.S. 24%, Libya 20%, Nigeria 16%
(1973)
Aid: economic—authorizations from U.S. (FY36-76), $0.3
million in grants; from international organizations
(FY71-76), $12 million
Budget: (1976) revenues, $134 million; expenditures, $141
million
Monetary conversion rate: 1 Bahamian dollar
(B$1)=US$1
Fiscal year: calendar year','8ab81fe063535f1ba83c5fb9e2ee073a72d5a3b76b91c9d9b4f79f35e4baf788','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99672773abe73360d35ff5aa0292bce6ed2c714e7d6b6ac5764413b5141e7f6c',1978,'BH','Bahrain','economy',43,'GNP: $600 million (1976 est.), annual growth rate 4.1%
(1975-85 projected average), $2,430 per capita, dominated
by oil industry; 1976 average daily crude oil production,
56,000 bbls (oil expected to last 15 years if no new
discoveries are made); 1975 nonassociated natural gas
production, 102 billion ft’; government oil revenues for 1976
are estimated at $395.7 million
Agriculture: produces dates, alfalfa, vegetables; dairy and
poultry farming; fishing; not self-sufficient in food
Major industries: petroleum refining, aluminum smelt-
ing, boatbuilding, shrimp fishing, pearls and sailmaking on a
small scale; major development projects include flourmill,
and ISA town; OAPEC dry dock to be built by 1977
Electric power: 550,000 kW capacity (1976); 1.9 billion
kWh produced (1976), 7,690 kWh per capita
Exports: exports and reexports, $802 million (1976);
non-oil exports (including reexports), $428.7 million (1977
projected); oil exports, $345.6 million (1976)
Imports: $980.6 million (1976)
Major trade partners: Saudi Arabia, U.K., US., Japan,
EC
Aid: received $110 million in bilateral commitments and
committed itself $8.5 million to multilateral agencies in
CY74
Budget: (1976) $483 million, 72% of revenues from oil
Monetary conversion rate: 1 Bahrain dinar =US$2.52
(since January 1973)
Fiscal year: calendar year','a03a4924e8ac28b8cfe4a5da4109b7a8683b8c00060ac7a19604eba69d899635','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6adf5e39e387cdd426e353199ef23958e1833e80d9f0a2e9782f002363cf2beb',1978,'BD','Bangladesh','economy',47,'GNP: $9.87 billion est. (FY76, current prices), $130 per
capita; real annual per capita growth, 7.7% (FY76), —2.6%
(FY75)
Agriculture: large subsistence farming, heavily dependent
on monsoon rainfall; main crops are jute and_ rice;
shortages—grain, cotton, and oilseeds
Fishing: catch 640,000 metric tons (1975)
Major industries: jute manufactures, food processing and
cotton textiles
= Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BANGLADESH/BARBADOS
Electric power: 865,000 kW capacity (1976); 1.5 billion
kWh produced (1976), 20 kWh per capita
Exports: $401 million (1976); raw and manufactured jute,
leather, tea
Imports: $865 million (1976); foodgrains, fuels, raw
cotton, fertilizer, manufactured products
Major trade partners: exports—U.S. 17%, U.K. 7.4%;
imports—U.S. 28.5%, Canada 9.7% (FY76)
Aid: economic—FY76 disbursements, $814 million, of
which U.S. provided 32%
Budget: (FY76) domestic revenues, $542 million; expend-
itures, $1,032 million
Monetary conversion rate: 15.5 taka=US$1 (July 1977)
Fiscal year: 1 July-30 June','52256430995954bcdedc32b861d2155884c2f8ad29d15bfa2e7c6eb392e6f6a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c63c708ce93e4e55b6a9d012a7ed2127162f1cf9ece67018751669d73bd8bd4',1978,'BB','Barbados','economy',51,'GDP: $396 million (1976), $1,660 per capita; real growth
rate 1976, 2.9%
Agriculture: main products—sugar, subsistence foods
Major industries: tourism, sugar milling, light manu-
facturing
Electric power: 107,000 kW capacity (1976); 220 million
kWh produced (1976), 920 kWh per capita
Exports: $208 million (f.0.b., 1976); sugar and sugarcane
byproducts, clothing
Imports: $275 million (c.i.f., 1976); foodstuffs, machinery,
manufactured goods
Major trade partners: exports—28% U.K., 14% U.S., 28%
CARIFTA, 30% other; imports—25% U.K., 21% U.S., 11%
Canada, 13% CARIFTA, 30% other (1973)
Aid: economic—authorization from U.S. (FY67-76), $1.4
million; from international organizations (FY63-76), $31.9
million
Budget: (1976) revenues, $152 million; expenditures, $191
million
Monetary conversion rate: 2 Barbados dollars=US$1
Fiscal year: 1 April-831 March','c17f7cc249c16d09035e4f888ae4f129ecb1c058c08813006a333cdead5da274','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd23b9cc0c54da744780b6497a6e6033ededcb8c1f0ead8234f88c3c1dacba48',1978,'BE','Belgium','economy',55,'GNP: $67.2 billion (1976), $6,850 per capita; 60.6%
consumption, 20.4% investment, 16.9% government, 0.7%
stock building, 1.4% net foreign balance (1975); 2.9% real
growth rate in 1976
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Agriculture: livestock production predominates; main
crops—grains, beets, potatoes; 80% self-sufficient in food;
caloric intake, 3,280 calories per day per capita (1969-70)
Fishing: exports $37 million (1975), imports $178 million
(1975)
Major industries: engineering and metal products,
processed food and beverages, chemicals, basic metals,
textiles, and petroleum
Crude steel: 12.1 million metric tons produced; 1,240 kg
per capita (1976)
Electric power: 10,600,000 kW capacity (1976); 50.9
billion kWh produced (1976), 5,190 kWh per capita
Exports: (Belgium-Luxembourg Economic Union) $32.8
billion (f.0.b., 1976); iron and steel products, finished or
semifinished precious stones, textile products
Imports: (Belgium-Luxembourg Economic Union) $35.4
billion (c.i.f., 1976); nonelectrical machinery, motor vehicles,
textiles, chemicals
Major trade partners: (Belgium-Luxembourg Economic
Union, 1976) 71% EC (23% West Germany, 19% France,
17% Netherlands, 6% U.K., 4% Italy 5% U.S., 2% Saudi
Arabia
Aid: economic—received, U.S., $829 million authorized
(FY46-75), $36.3 million in FY74; IBRD, $57.8 million
(1949-75); military—received, $1,275 million authorized
(FY46-76); net official economic aid to less developed areas
and multilateral agencies, $1,365 million (FY60-70), $263.4
million in 1974
Budget: (1976) revenues, $18.0 billion; expenditures,
$19.4 billion; deficit, $1.4 billion
Monetary conversion rate: (1976 average) Belgian Franc
38.605 = US$1
Fiscal year: calendar year
Budget (1976) expenditures $834 million, revenues $857
million, surplus $23 million
Monetary conversion rate: LF38.605=US$1, 1976 aver-
age; under the BLEU agreement, the Luxembourg franc is
equal to the Belgian franc which circulates freely in','9e646ee51fa61aedd0a18f34624d2f38e010d7f00eff1cca2335cb6cc337c957','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d1ffe758214743fcfd1c06cddaa0abb07867f3cf51a2b156aec201f1abd8e43',1978,'BZ','Belize','economy',59,'GDP: $87 million (1974), $640 per capita; 78% private
consumption, 17% public consumption, 36% domestic
investment, —31% net foreign balance (1968); 3.5% real
growth rate (1971)
Agriculture: main products—sugar, citrus fruits, corn,
molasses, rice, beans, bananas, livestock products; net
importer of food; caloric intake, 2,500 calories per day per
capita
Major industries: timber and forest products, food
processing, furniture, rum, soap
Electric power: 16,000 kW capacity (1976); 32 million
kWh produced (1976), 230 kWh per capita
Exports: $71.3 million (f.0.b., 1975 est.); sugar, molasses,
clothing, lumber, citrus fruits, fish
Imports: $102 million (c.if., 1975 est.); vehicles, building
materials, petroleum, food, textiles, machinery
18 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BELIZE/BENIN
Major trade partners: exports—U.S. 30%, U.K. 24%,
Mexico 22%, Canada 18%; imports—U.S. 34%, U.K. 25%,
Jamaica 7% (1970)
Aid: economic—U.S. authorizations (FY46-76), $7.6 mil-
lion in grants; from international organizations (1946-76),
$2.3 million
Monetary conversion rate: 2 Belize dollars=US$1
Fiscal year: calendar year','9e472a91be7ef43417311f0eba9a1ed996515f3a4d24fd36d91272ab72bc9668','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13c83bc825614c9829a5a53426193244fe3aab839607638ea54efc4b79ee874b',1978,'BJ','Benin','economy',63,'GNP: $372 million (1975), $120 per capita; no real growth
during 1970-1974
Agriculture: major cash crop is oil palms; peanuts, cotton,
coffee, sheanuts, and tobacco also produced commercially;
main food crops—corn, cassava, yams, sorghum and millet;
livestock, fish
19
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BENIN/BERMUDA
Fishing: catch 29,494 metric tons (1975); exports 600
metric tons, imports 4,300 metric tons (1971)
Major industries: palm oil and palm kernel oil processing
Electric power: 11,000 kW capacity (1976); 55 million
kWh produced (1976), 20 kWh per capita
Exports: $94 million (f.0.b., 1974); palm products (34%);
other agricultural products
Imports: $131 million (c.if., 1974); clothing and other
consumer goods, cement, lumber, fuels, foodstuffs, machin-
ery, and transport equipment
Major trade partners: France, EC, franc zone; preferen-
tial tariffs to EC and frane zone countries
Aid: economic (through FY75)—EC, $67.1 million; U.N.,
$12.5 million; other international organizations, $36.2
million; Taiwan, $1 million; U.S. (FY46-76), $18.1 million;
China, $44 million extended (1972)
Budget: 1975 est.—receipts $73 million, expenditures $77
million
Monetary conversion rate: 249.35 Communaute Finan-
ciere Africaine (CFA) francs=US$1 as of February 1977
Fiscal year: calendar year','715b4f2f081f64e9c3e361f3e2aa50849f7e3ea584494db8205025f196a514d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df5caad761a232dd824509b8f623831ea7dc61a627f0a8206e004dcc632cacb6',1978,'BM','Bermuda','economy',67,'GNP: $300-$350 million (at market prices,
$5,000-$6,000 per capita
Agriculture: main products—bananas, vegetables, Easter
lilies, dairy products, citrus fruits
1974),
Major industries: tourism, finance
Electric power: 86,200 kW capacity (1976); 300 million
kWh produced (1976), 5,260 kWh per capita
Exports: $34 million (f.o.b., 1975); mostly reexports of
drugs and bunker fuel
Imports: $162 million (f.0.b., 1975); fuel, foodstuffs,
machinery
Major trade partners: 45% U.S., 22% U.K., 9% Canada
(1974)
Monetary conversion rate: 1 Bermuda dollar=US$1
Fiscal year: 1 April-31 March','804cabbd8fe1e84e1947e2e63ddc5ae6a79c92ae70561b8f2ceeca74d9eaeae2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7902d53a1dd557f7eed134967d21b02860f3a4fd6ac1d0b0f057a0c60a20701c',1978,'BT','Bhutan','economy',71,'GNP: under $100 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 3,000 kW capacity (1976); 8 million kWh
produced (1976), 10 kWh per capita
Exports: about $1 million annually; rice, dolomite, and
handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic—India (FY61-72), $180 million
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 a
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BHUTAN/BOLIVIA
Monetary conversion rate: both ngultrums and Indian
rupees are legal tender; 8.77 ngultrums=8.77 Indian
rupees=US$1 as of October 1975
Fiscal year: 1 April-31 March
GNP: $2.40 billion (1976, in 1976 dollars), $430 per
capita; 69% private consumption, 17% public consumption,
20% gross domestic investment, —6% net foreign balance
(1976); real growth rate (1972-76), average 6.4%, 1976
growth, 6.0%
22 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BOLIVIA/BOTSWANA
Agriculture: main crops—potatoes, corn, rice, sugarcane,
yucca, bananas; imports significant quantities of wheat;
caloric intake, 70% of requirements (1976)
Major industries: mining, smelting, petroleum refining,
food processing, textiles, and clothing
Electric power: 345,000 kW capacity (1976); 1 billion
kWh produced (1976), 180 kWh per capita
Exports: $566 million (f.0.b., 1976 est.); tin, petroleum,
lead, zinc, silver, tungsten, antimony, bismuth, gold, coffee,
sugar, cotton, natural gas
Imports: $562 million (f.0.b., 1976 est.); foodstuffs,
chemicals, capital goods, pharmaceuticals, transportation
Major trade partners: exports—Western Europe, 19% (of
which UK is largest market); Latin America, 38%; U.S., 30%;
Japan, 3.9%; imports—U.S., 24%; Western Europe, 15.4% (of
which West Germany is largest supplier); Japan, 15.7%;
Latin America, 33.6% (1975)
Aid: economic—extensions from U.S. (FY46-76), $335
million in loans, $342 million in grants; from international
organizations (FY46-75), $372 million; from other Western
countries (1960-75), $53.8 million; Communist countries
(1970-74), $59.7 million; military—assistance from U.S.
(FY52-76), $70 million
Budget: $340 million revenues, $421 million expenditures
(1976)
Monetary conversion rate: 20 pesos= US$1
Fiscal year: calendar year','ff8c3c2cff01fe052c404f4bee3dfa49c1037527b40e1a95d14a807410f2cac2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0cb702d084c63f003b03153eea38d58a62762e58469458d978c37464c81c8e1',1978,'BW','Botswana','economy',75,'GDP: $300 million (1975 est.), growth in current prices
about 15% annually
Agriculture: principal crops are corn and sorghum;
livestock raised and exported
Major industries: livestock processing, mining of dia-
monds, copper, nickel, and coal
Electric power: 75,000 kW capacity (1976); 85 million
kWh produced (1976), 120 kWh per capita
Exports: $126 million (1975 est.); cattle, animal products,
minerals
Imports: $209 million (1975); foodstuffs, vehicles, textiles,
petroleum products
Major trade partners: South Africa and U.K.
Budget: (1977) revenue $107 million ($78 million from
domestic taxes and $29 million from borrowing and foreign
aid), current expenditures $70 million, investment expendi-
tures $44 million
Monetary conversion rate: 1 pula=about US$1.20 as of
October 1977
Fiscal year: 1 April-31 March','0dd22dfaf1a2789036df66d0d86147ebe8b11b803b8bd05ba7430aa9299a1e3d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e4cb25953b5da3e227c2f4451b2a707ed5bc3409c0754318e371d940ccba3ce',1978,'BR','Brazil','economy',79,'CNP: $111.7 billion (est. 1976 in 1976 prices), $995 per
capita; 25% gross investment, 80% consumption, —5% net
foreign balance (1976); real growth rate 8.7%
Agriculture: main products—coffee, rice, beef, corn,
milk, sugarcane, soybeans; nearly self-sufficient; caloric
intake, 2,900 calories per day per capita (1962)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Fishing: catch 674,500 metric tons (1975); exports, $46.6
million (f.0.b. 1974), imports, $57.8 million (f.0.b. 1974)
Major industries: textiles and other consumer goods,
chemicals, cement, lumber, steel, motor vehicles, other
metalworking industries
Crude steel: 10.0 million metric tons capacity (1976 est.);
9.1 million metric tons produced (1976), 80 kg per capita
Electric power: 22,800,000 kW capacity (1976); 80 billion
kWh produced (1976), 730 kWh per capita
Exports: $10,126 million (f.0.b., 1976); coffee, manufac-
tures, iron ore, cotton, soybeans, sugar, wood, cocoa, beef,
shoes
Imports: $13,622 million (c.i.f., 1976); machinery, chemi-
cals, pharmaceuticals, petroleum, wheat, copper, aluminum
Major trade partners: exports—16% U.S., 6% Japan, 9%
West Germany, 7% Netherlands, 4% Italy, 4% U.K.;
imports—25% U.S., 9% West Germany, 8% Japan, 3% Italy,
3% U.K. (1976)
Aid: economic—extensions from U.S. (FY46-76), loans
$1.7 billion, grants $690 million; from international organi-
zations (FY46-75), $4.1 billion; from other Western countries
(1960-71), $617.0 million; from Communist countries
(1959-76), $499 million; drawings (1959-76), $160 million
Budget: (1976) revenues $15.6 billion, expenditures $15.5
billion
Monetary conversion rate: 15.15 cruzeiros=US$1 (Octo-
ber 1977, changes frequently)
Fiscal year: calendar year
GDP: $40 million (1973)
Agriculture: largely dominated by coconut production
with subsistence crops of yams, taro, bananas; self-sufficient
in rice
Electric power: 6,000 kW capacity (1976); 13 million
kWh produced (1976), 67 kWh per capita
Exports: $15.5 million (1975); 39% copra, 27% timber,
23% fish
Imports: $29.2 million (1975)
Major trade partners: exports—EEC excluding U.K. 42%,
Japan 29%; imports—Australia 34%, U.K. 14%, Japan 13%
(1975)
Budget: (1971) revenues $9.8 million, expenditures $9.9
million
Monetary conversion rate: 1 Australian dollar=US$1.24
(July 1976)
GNP: $427 million (1976), $530 per capita; real growth
rate 1976, 2.0% est.
Agriculture: main crops—sugarcane, rice, other food
crops; food shortages—wheat flour, cooking oil, processed
meat, dairy products; caloric intake, 2,180 calories per day
per capita (1967)
Fishing: catch 20,123 metric tons (1975); exported 4,445
metric tons valued at $3 million in 1975
Major industries: bauxite mining, alumina production,
sugar and rice milling, timber
Electric power: 175,000 kW capacity (1976); 370 million
kWh _ produced (1976), 460 kWh per capita
Exports: $257 million (f.0.b., 1976); bauxite, sugar,
alumina, rice, shrimp, molasses, timber, diamonds, rum
88 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GUYANA/HAITI
Imports: $371 million (cif, 1976); manufactures, ma-
chinery, food, petroleum
Major trade partners: exports—27.4% U.K., 20.5% US.,
16.3% CARICOM, 2.4% Canada; imports—28% U.S., 23%
U.K., 22% CARICOM, 4% Canada (1976)
Aid: economic—authorizations from U.S. (FY53-76), $55
million in loans, $26 million in grants; commitments from
Communist countries—China (1972-76), $36 million in
loans, and East Germany (1974), $10 million in loans; from
international organizations (FY46-76), $69 million
Budget: revenue, $186 million; expenditure, $312 million
(1976)
Monetary conversion rate: floating with US dollar, 1
US$=G$2.55
Fiscal year: calendar year','44314a89905d72d49101d3cb8466086166e9cf4a9c75c9d1283231921224dfdc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bac6444613e8ff02887c925c2643dc1cad88a7cb3524205d5d5d3a112d40a13d',1978,'ID','Indonesia','economy',83,'GNP: $460 million (1975 est.), $2,970 per capita
Agriculture: main crops—rubber, rice, pepper, must
import most food
Major industry: crude petroleum, liquefied natural gas
Electric power: 84,000 kW capacity (1976); 230 million
kWh produced (1976), 1,440 kWh per capita
Exports: $1,000 million (f.0.b., 1975); 95% crude petro-
leum and liquefied natural gas
Imports: $200 million (cif., 1975); 25% machinery and
transport equipment, 46% manufactured goods, 16% food
Major trade partners: exports of crude petroleum and
liquefied natural gas to Japan; imports from Japan 30%, U.S.
24%, U.K. 15%, Singapore 9%
Budget: (1976) revenues $640 million, expenditures $250
million, surplus $390 million; 20% defense
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Monetary conversion rate: 2.5 Brunei dollars=US$1
Fiscal year: calendar year
GNP: $40.5 billion (1977) about $300 per capita; real
average annual growth (1972-77), 7.1%
Agriculture: subsistence food production, and smallholder
and plantation production for export; main crops—rice,
rubber, copra, other tropical products; food shortage—rice,
wheat
Fishing: catch 1.4 million tons (1976); exports $83 million
(1975), imports $2 million (1975)
Major industries: processing agricultural products and
petroleum, textiles, mining
Electric power: 1,820,000 kW capacity (1976); 5.6 billion
kWh produced (1976), 40 kWh per capita
Exports: total $8,547 million (f.0.b., 1976); petroleum
($6,080 million; 485 million bbls), timber, rubber, coffee, tin,
palm oil, tea, tobacco
Imports: $5,673 million (c.if., 1976); rice, other food-
stuffs, textiles, chemicals, iron and steel products, machin-
ery, transport equipment, consumer durables
Major trade partners: exports (1976)—29% U.S., 41%
Japan, 8% Singapore; imports—19% U.S., 31% Japan, 9%
West Germany
Budget: (1977-78) expenditures $10.2 billion; 49% cur-
rent, 51% development expenditures; planned receipts $10.2
billion
Monetary conversion rate: 415 rupiah=US$1
Fiscal year: 1 April-31 March
GNP: $66.4 billion (1976), $1,950 per capita; 1976 real
GNP growth, 13.8%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Agriculture: wheat, barley, rice, sugar beets, cotton, dates,
raisins, tea, tobacco, sheep, and goats
Major industries: crude oil production (2,147 million bbls
in 1976) and refining, textiles, cement and other building
materials, food processing (particularly sugar refining and
vegetable oil production), metal fabricating
Electric power: 6,250,000 kW capacity (1976); 20 billion
kWh produced (1976), 590 kWh per capita
Exports: $23.1 billion (f.0.b., 1976); 97% petroleum; also
carpets, raw cotton, fruits, and nuts, hide and leather items,
ores
Imports: $13.0 billion (f.0.b., 1976); machinery, iron and
steel products, chemicals, pharmaceuticals, electrical equip-
ment, agricultural products
Major trade partners: exports—U.S., Japan, West Ger-
many, U.S. $.R. and other Communist countries; imports—
U.S., West Germany, Japan, U.K., U.S.S.R.
Budget: (FY77-78) $50.1 billion
Monetary conversion rate: 70.6 rials=US$1
Fiscal year: 21 March-20 March','0d7e3df4dea44898cb4cf1d337da4a7d047e8604940a80a73baaf5ee3d02c389','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('449d8b317bf4eba4d1ebc1423634ba0d21f9bfe48bea1cf5320e9e29dd7c7d65',1978,'BG','Bulgaria','economy',87,'GNP: $19.9 billion, 1976 (at 1975 prices), $2,260 per
capita; 1976 real growth rate, 4.6%
Agriculture: mainly self-sufficient; main crops—grain,
vegetables; caloric intake, 3,000 calories per day per capita
(1969/70)
Fishing: catch 151,000 metric tons (1975)
Major industries: agricultural processing, machinery,
textiles and clothing, mining, ore processing, timber
Shortages: some raw materials, metal products, meat and
dairy products; fodder
Crude steel: 2.4 million metric tons produced (1976), 280
kg per capita
Electric power: 7,068,000 kW capacity (1976); 27.7
billion kWh produced (1976), 3,150 kWh per capita
Exports: $5,383 million (f.0.b., 1976); 42% machinery,
equipment, and transportation equipment; 15% fuels,
minerals, raw materials, metals, and other industrial
material; 2% agricultural raw materials; 31% foodstuffs, raw
materials for food industry, and animals; 10% industrial
consumer goods (1976)
Imports: $5,589 million (f.0.b., 1976); 41% machinery,
equipment, and transportation equipment; 41% fuels,
minerals, raw materials, metals, other materials; 7% agricul-
tural raw materials; 6% foodstuffs and animals: 5% industrial
consumer goods (1976)
Major trade partners: $10,937 million in 1976; 21% with
non-Communist countries, 54% with U.S.S.R., 26% with
other Communist countries
Monetary conversion rate: 0.96 leva=US$1 (January
1977)
Fiscal year: calendar year; economic data reported for
calendar years except for caloric intake, which is reported
for consumption year 1 July-30 June
NOTE: Foreign trade figures were converted at the 1976
rate of 0.97 leva=US$1
GDP: $3.2 billion (FY76, in current prices), $100 per
capita; real growth rate 4.5% (FY76); 2.7% over past decade
Agriculture: accounts for nearly 70% of total employment
and about 27% of GDP; main crops—paddy, sugarcane,
corn, peanuts; almost 100% self-sufficient; most rice grown
in deltaic land
Fishing: catch 500,000 metric tons (1976)
Major industries: agricultural processing; textiles and
footwear; wood and wood products; petroleum refining
Electric power: 450,000 kW capacity (1976); 850 million
kWh produced (1976), 30 kWh per capita
Exports: $173 million (f.0.b., 1976); rice, teak
Imports: $287 million (cif, 1976); machinery and
transportation equipment, textiles, other manufactured
goods
Major trade partners: exports—India, Western Europe,
China, U.K., Japan; imports—Japan, Western Europe, India,
U.K.
Budget: (FY76) $278 million revenues; $436 million
expenditures; $158 million deficit; 30% military, 70%
civilian
Monetary conversion rate: 6.7324 kyat=US$1 (official)
Fiscal year: 1 April-31 March','8d0f6d29d3f013b47d7561c249e84357ac7cf32d8b56dafb7d5a9e8a27264d11','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03d41819de3df53b17499fc90cfc23798c0d4f6ae6b2e52d9e022e770f9ff3c1',1978,'BI','Burundi','economy',91,'GNP: about $450 million (1976), $120 per capita; 2% real
growth (1970-74); real GDP growth in 1976, 7%
Agriculture: major cash crops—coffee, cotton, tea; main
food crops—manioc, yams, corn, sorghums, bananas, haricot
beans; marginally self-sufficient
Industries: light consumer goods such as beverages,
blankets, shoes, soap, assembly of imports
Electric power: 7,500 kW capacity (diesel generator
1976); 25 million kWh produced (1976), 6 kWh per capita
Exports: $58 million (f.0.b., 1976); coffee (88%), tea,
cotton, hides, skins
Imports: $59 million (c.i.f., 1976); textiles, foodstuffs,
transport equipment, petroleum products
Major trade partners: U.S., EEC countries
Aid: $40 million all donors (1975 est.), major donors EC,
IBRD/IDA, U.N.
Budget: FY76—revenue $47 million, current expenditure
$49.6 million
30 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BURUNDI/CAMBODIA
Monetary conversion rate: 90 Burundi francs=US$1
(official)
Fiscal year: calendar year','ef68b89eb64ae30f172cfd9673467b9abff6e7dc23c756733b98588b2da12ed3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cf0c55ee64247898a73b95e73b353b042eae93e882fd3dfb7bc4fe9877d658e',1978,'KH','Cambodia','economy',95,'GNP: less than $500 million (1971), probably less than $70
per capita (1976)
Agriculture: mainly subsistence except for rubber planta-
tions; main crops—rice, rubber, corn; food shortages—rice,
meat, vegetables, dairy products, sugar, flour
Major industries: rice milling, fishing, wood and wood
products
Shortages: fossil fuels
Electric power: 120,000 kW capacity (1976); 260 million
kWh produced (1976), 30 kWh per capita
Exports: probably less than $1 million est. (1976); rubber
Imports: probably less than $20 million (1976); food, fuel,
machinery
Major trade partners: exports—China, Thailand; im-
ports—China, North Korea
Aid: economic—$906.1 million est. (FY53-75); U.S. aid,
$852 million; probably about $90 million from China, $25
million from U.S.S.R., and $17 million from Eastern Europe;
military—U.S., $1,334 million (FY46-76)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CAMBODIA/CAMEROON
Budget: no budget data available since Communists took
over government
Monetary conversion rate: not announced yet by new
Khmer Rouge government
Fiscal year: calendar year','4d44bcba2a19865b46ed26a6bd5c89958071d5e3a7455f39837d3f2f78fe5dfa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba99d78b138449fa7a024a1014c925084e17580e9bbcbe6bb4077ba860870279',1978,'CM','Cameroon','economy',99,'GDP: $2,000 million (mid 1976), per capita about $310;
real growth rate about 3.0% per annum (mid 1970-mid
1976)
Agriculture: commercial and food crops—cocoa, coffee,
timber, cotton, rubber, bananas, peanuts, palm oil and palm
kernels; root starches, livestock, millet, sorghum, and rice
Fishing: imports 7,024 metric tons, $2.2 million; exports
909 metric tons (largely shrimp), $3.5 million (1975)
Major industries: small aluminum plant, food processing
and light consumer goods industries, sawmills
Electric power: 358,000 kW capacity (1976); 1,265
million kWh produced (1976), 190 kWh per capita
Exports: $449 million (f.0.b., 1975); cocoa and coffee
about 55%; other exports include timber, aluminum, cotton,
natural rubber, bananas, peanuts, tobacco, and tea
Imports: $598 million (c.i.f., 1975); consumer goods,
machinery, transport equipment, alumina for refining,
petroleum products, food and beverages
Major trade partners: about 70% of total trade with
France and other EC countries; about 5% of total trade with
US.
Budget: FY76 budget est. balanced at $500 million
Monetary conversion rate: 249.35 Communaute Finan-
ciere Africaine francs=US$1 as of February 1977
Fiscal year: 1 July-30 June','b0bfb9e82f03c7c06578620b754e1fb2a4d22afcb224fb975dfb0ce1d080f968','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2317354efe1d479d8e20099a21b6c55b2b9201f1aabd9837f663b3c3e35d7818',1978,'CA','Canada','economy',103,'GNP: $192.7 billion (1976, in 1976 prices), $8,377 per
capita (1976); 58.0% consumption, 23.3% investment, 20.3%
government (1976); growth rate 4.6% (1970-76, constant
prices)
Agriculture: main products—livestock, grains (principally
wheat), dairy products; food shortages—fresh fruits and
vegetables; caloric intake, 3,180 calories per day per capita
(1966-67)
Fishing: catch 830,000 metric tons; exports 260,000
metric tons (1976)
Major industries: mining, metals, food products, wood
and paper products, transportation equipment, chemicals
Shortages: rubber, rolled steel, fruits,
instruments
precision
Crude steel: 13.1 million metric tons produced (1976)
Electric power: 61 million kW capacity (1976); 297.47
billion kWh produced (1976), 12,460 kWh per capita
Exports: $40,155 million (f.o.b., 1976, source: LF-.S.);
principal items—transportation equipment, wood and wood
products including paper, ferrous and nonferrous ores, crude
petroleum, wheat; Canada is a major food exporter
Imports: $40,564 million (c.if., 1976, source: LF.S.);
principal items—transportation equipment, machinery,
crude petroleum, communication equipment, textiles, steel,
fabricated metals, office machines, fruits and vegetables
Major trade partners: 68% U.S, 10% EC, 5% Japan
(1976)
Aid: economic—(received) U.S., $388 million (FY46-75);
gross official aid to less developed countries and multilateral
agencies, $3,688 million (1960-73), $637 million (1973);
military—U.S., $13 million (FY49-76), none since 1961
Budget: total revenues $31,132 million; current expendi-
tures $36,036 million; gross capital formation $6,466 million;
budget deficit $4,904 million (1976) (National Accounts
Basis)
Monetary conversion rate: there is no designated par
value for the Canadian dollar, which was allowed to float
freely on the exchanges beginning 1 June 1970; since then
the Canadian dollar has moved between US$0.98-1.04 in
value, 1976 average 1C$=US$0.9858
Fiscal year: 1 April-31 March','4c1a966adf90ef357f33d16641cf57ffdcfa5d7480490e6c63c21655becc23ca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fa3e3730fee857a8c320204c2e11f58ea923fb06275942a1912b3f2d9cbe080',1978,'GN','Guinea','economy',107,'GDP: $50 million (1975 est.); $170 per capita income
Agriculture: main crops—corn, beans, manioc, sweet
potatoes; barely self-sufficient in food
Fishing: catch, 4,400 metric tons (1975); largely undevel-
oped but provides major source of export earnings
Major industries: salt mining
Electric power: 6,000 kW capacity (1976); 7 million kWh
produced (1976); 20 kWh per capita
Exports: $2 million (f.0.b., 1973); fish, bananas, salt
Imports: $34 million (c.if., 1973); machinery, textiles
Major trade partners: Portugal, U.K., Japan, African
neighbors
Aid: Portugal, $30 million (1975), for civil service salaries,
food, medicines; U.S., $7.2 million (1946-76), for food and
employment of rural workers; Netherlands, Scandinavian
countries, UNDP
Budget: (est. 1974) $32 million expenditures, $12 million
revenues
Monetary conversion rate: 38,732 escudos=US$1 (June
1977)
Fiscal year: probably calendar year
GDP: $394 million (1976), $220 per capita
Agriculture: commercial—cotton, coffee, peanuts, ses-
ame, wood; main food crops—manioc, corn, peanuts, rice,
potatoes, beef; requires wheat, flour, rice, beef, and sugar
imports
Major industries: sawmills, cotton textile mills, brewery,
diamond mining and splitting
Electric power: 34,000 kW capacity (1976); 82 million
kWh produced (1976), 45 kWh per capita
Exports: $80 million (f.0.b., 1976); cotton, coffee,
diamonds, timber
Imports: $78.8 million (f.0.b., 1976) ; textiles, petroleum
products, machinery and electrical equipment, motor
vehicles and equipment, chemicals and pharmaceuticals
Aid: economic (1946-76) —U.S., $9.6 million; EC, $73.8
million; U.N., $11.5 million; other international organiza-
tions, $23.4 million; Communist countries (1964-75), $7.2
million
Major trade partners: France; preferential tariff applied
to EC countries and franc zone; Yugoslavia, Japan, U.S.
Budget: 1976 budget receipts and grants $65.8 million,
expenditures $83.3 million
Monetary conversion rate: 249.35 Communaute Finan-
ciere Africaine francs=US$1 as of February 1977
Fiscal year: calendar year
GNP: $70 million (1972); $240 per capita
Agriculture: major cash crops—Rio Muni, timber, coffee;
Fernando Po, cocoa; main food products—rice, yams,
cassava, bananas, oil palm nuts, manioc, and livestock
Fishing: catch 4,000 metric tons (1975)
Major industries: fishing, sawmilling
Electric power: 5,000 kW capacity (1976); 17 million
kWh produced (1976), 50 kWh per capita
Exports: $19 million (1973); cocoa, coffee, and wood
Imports: $21 million (1973); foodstuffs, chemicals and
chemical products, textiles
Major trade partner: Spain
Aid: Spain, $14.0 million (1969); Libya, $1 million (1971);
China $24 million (Economic) extended (1971)
Budget: (1973) receipts $9 million, expenditures $12
million
Monetary conversion rate: 64.47 Guinean pesetas=US$1
(official)
GNP: $3.7 billion (1974) at current prices, about $390 per
capita; real growth rate 2% (1970-74)
Agriculture: main crop—cocoa; other crops include root
crops, corn, sorghum and millet, peanuts; not self-sufficient,
but can become so
Fishing: catch 254,515 metric tons (1975)
77
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GHANA/GIBRALTAR
Major industries: mining, lumbering, light manufactur-
ing, fishing, aluminum
Electric power: 1,157,000 kW capacity (1976); 3.6 billion
kWh produced (1976), 350 kWh per capita
Exports: $772 million (f.0.b., 1975); cocoa (about 65%),
wood, gold, diamonds, manganese, bauxite, and aluminum
(aluminum regularly excluded from balance of payments
data)
Imports: $651 million (f.0.b., 1975); textiles and other
manufactured goods, food, fuels, transport equipment
Major trade partners: U.K., EC, and US.
Budget: FY77 (proposed)—revenue $943 million, current
expenditure $960 million, capital expenditure $313 million
Monetary conversion rate: 1 Cedi= US$0.87
Fiscal year: 1 July-30 June
GDP: $820.8 (1976), $180 per capita
Agriculture: cash crops—coffee, bananas, palm products,
peanuts, and pineapples; staple food crops—cassava, rice,
millet, corn, sweet potatoes; livestock raised in some areas
Major industries: alumina, light manufacturing and
processing industries, bauxite mining
Electric power: 101,500 kW capacity (1976); 450 million
kWh produced (1976), 100 kWh per capita
Exports: $240 million (f£.0.b., 1976); alumina, bauxite,
coffee, pineapples, bananas, palm kernels
Imports: $248 million (f.0.b., 1976); petroleum products,
metals, machinery and transport equipment, foodstuffs,
textiles
Major trade partners: Communist countries, Western
Europe (including France), U.S.
Budget: (FY77 est.) current revenue $238 million, current
expenditures $176 million
Monetary conversion rate::22.22 syli=US$1 floating (end
1976)
Fiscal year: 1 October-30 September
GDP: $4.1 billion (1975 est.), $840 capita; average annual
growth rate in constant prices, 3.1% (1970-75)
party; possibly some
Agriculture: commercial—coffee, cocoa, wood, bananas,
pineapples, palm oil; food crops—corn, millet, yams, rice;
other commodities—cotton, rubber, tobacco, fish; self-
sufficient in most foodstuffs, but rice, sugar, and meat
imported
Fishing: catch 63,470 metric tons (1975); exports $12.8
million (1975), imports $33.6 million (1975)
Major industries: food and lumber processing, oil
refinery, automobile assembly plant, textiles, soap, flour
mill, matches, three small shipyards, fertilizer plant, and
battery factory
Electric power: 525,000 kW capacity (1976); 1.2 billion
kWh produced (1976), 170 kWh per capita
Exports: $1.6 billion (f.0.b., 1976); coffee, tropical woods,
cocoa, 70% of total; bananas, pineapples, palm oil
Imports: $1.3 billion (c.i.f., 1976); about 40% consumer
goods, 10% raw materials and fuels, about 50% manufac-
tured goods and semi-finished products
Major trade partners: France and other EC countries
about 65%, U.S. 18%, Communist countries about 1%
Aid: economic—France (1960-69), $312 million; EC
through FY75, $203.2 million; US. (FY61-75), $40.7 million:
others (1960-71), $76 million, including $18.5 million
committed; no Communist aid programs; military— non-
Communist countries (1954-67), $7.3. million
Budget: 1976 est.—revenues $626 million, current expen-
ditures $267 million, investment expenditures $247 million
Monetary conversion rate: about 249.35 Communaute
Financiere Africaine francs=US$1, February 1977
Fiscal year: calendar year','08bda38978d00ab462e6134190ac40abaf8ddf3023f713c6c2cd8fef5fb1628b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05dbc9c23658a584f35b40764f4345742d65093be202c95f7c3ccd575db315ea',1978,'TD','Chad','economy',111,'CDP: $375 million (est. 1974), $90 per capita; estimated
real annual growth rate nearly zero since 1971
37
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CHAD/CHILE
Agriculture: commercial—cotton, gum arabic, livestock,
fish; food crops—peanuts, millet, sorghum, rice, dates,
manioc, wheat; imports food
Fishing: catch 115,000 metric tons (1975)
Major industries: agricultural and livestock processing
plants (cotton textile mill, slaughterhouses, brewery), natron
Electric power: 22,000 kW capacity (1976); 60 million
kWh produced (1976), 20 kWh per capita
Exports: $77 million (f.0.b., 1976); cotton 67%
Imports: $98 million (c.if., 1976); cement, petroleum,
foodstuffs, machinery, textiles, and motor vehicles
Major trade partners: France (about 40% in 1973) and
UDEAC countries; preferential tariffs to EC and franc zone
countries
Aid: major source France, more than $10 million
(1971-73); EDF, more than $15 million (1971-73); U.S.
(FY46-76), $29.4 million; U.S.S.R., $5.0 million (1968-76);
China, $67.6 million (1971-76): military aid (1955-76)—$7.0
million; from France, $4.1 million, remainder from West
Germany and Israel; more than $10 million annually (est.) in
French military aid (1969-71)
Budget: 1976 ordinary budget—$64 million
Monetary conversion rate: 247.01 Communaute Finan-
ciere Africaine francs=US$1 as of June 1977 (floating)
Fiscal year: calendar year','3b4cc080008aa3d4a9397641bb6664b7cfd800f8860b157039ae51c820741ad4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba39f654a9bc9edc140959dff934e40d8f74b08bf354128a069a93bdfdabea20',1978,'CL','Chile','economy',113,'GDP: $9.2 billion (1976 in 1976 prices), $880 per capita;
79.1% private consumption, 11.9% government consump-
tion; 12.1% gross investment, 3.1% net imports and factor
payments abroad (1976 est.); real growth rate, 1976, 5.9%;
1972-76 average annual increase, — 1.6%
Agriculture: main crops—wheat, other cereals, potatoes;
about 65% self-sufficient; 2,650 calories per day per capita
(1971 est.)
Fishing: catch 1.13 million metric tons (1975); exports
$49.1 million (1975)
Major industries: copper, nitrates, foodstuffs, fish proc-
essing, textiles and apparel, iron and steel, pulp and paper
Crude steel: 0.7 million metric tons capacity (1967);
450,000 metric tons produced (1976), 42 kg per capita
Electric power: 2,700,000 kW capacity (1976); 10 billion
kWh produced (1976), 960 kWh per capita
Exports: $2.0 billion (f.0.b., 1976); copper, iron ore, paper
products, nitrates, iodine, and fresh fruit
Imports: $1.6 billion (c.i.f., 1976); foodstuffs, petroleum,
machinery and equipment, chemicals
Major trade partners: exports—41% EC, 11% Japan, 8%
US., 29% LAFTA; imports—17% EC, 29% US., 27%
LAFTA (1975)
Aid: economic—extensions from U.S. (FY46-76), $1,506
million loans, $313 million grants, from international
organizations (FY46-75), $720 million (of which IBRD $266
million, IDB $409 million); from other Western countries
(1960-66), $170.6 million; from Communist countries
(1967-76), $447.7 million; military (FY53-75)—from U.S.,
$62 million in loans, $154 million in grants
Budget: $1.8 billion revenues, $2.4 billion expenditures
(1976)
Monetary conversion rate: 24.7 pesos=US$1 (October
1977), changes frequently
Fiscal year: calendar year','a619f302c58b5cff1ebac9ca3df9c2e144abcf9561e0fa6df0adfb6f00e7da0c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e81ebe9c3844c01d556438bb27356779c6818d2eba268b3e1307cb751770395',1978,'CN','China','economy',118,'GNP: $324 billion (1976), $340 per capita
Agriculture: main crops—rice, wheat, miscellaneous
grains, cotton; caloric intake, 2,000 calories per day per
capita (1976); agriculture mainly subsistence; grain imports
2 million metric tons in 1976
Major industries: iron and steel, coal, machine building,
armaments, textiles
Shortages: complex machinery and equipment, highly
skilled scientists and technicians
Crude steel: 23 million metric tons produced, 24 kg per
capita (1976)
Electric power: 38 million kW capacity (1976); 138
billion kWh produced (1976), 185 kWh per capita
Exports: $7.2 billion (f.0.b., 1976); agricultural products,
minerals and metals, manufactured goods
Imports: $6.0 billion (cif, 1976); grain, chemical
fertilizer, industrial raw materials, machinery and equip-
ment
Major trade partners: Japan, Hong Kong, West Ger-
many, France, Romania, U.S.S.R., Australia, U.S., Canada,
Singapore (1976)
Monetary conversion rate: as of August 1977, about 1.85
yuan=US$1 (arbitrarily established)
Fiscal year: calendar year
Monetary conversion rate: 2.02 won=US$1, non-com-
mercial rate
Fiscal year: calendar year
GNP: $25.1 billion (1976, in 1976 prices), $710 per capita;
real growth 15.5% (1976); real growth 11.2% (1972-76
average)
Agriculture: 40% of the population live on the land, but
agriculture, forestry and fishery constitute 25% of GNP;
main crops—rice, barley; not self-sufficient; food short-
ages—wheat, dairy products, corn
Fishing: catch 2,406,896 metric tons (1976)
Major industries: textiles and clothing, food processing,
chemical fertilizers, chemicals, plywood, steel, electronics
Shortages: base metals, petroleum, lumber and certain
food grains
Electric power: 4,800,000 kW capacity (1976); 23 billion
kWh produced (1976), 650 kWh per capita
Exports: $7.8 billion (f.0.b., 1976); textiles and clothing,
electrical machinery, plywood, footwear, steel, ships
Imports: $8.8 billion (c.if., 1976); oil, ships, steel, wood,
wheat, organic chemicals, machinery
Major trade partners: exports—32% U:S., 23% Japan;
imports—35% Japan, 22% U.S. (1976)
Aid: economic—U.S. (FY46-76), $5.7 billion committed;
Japan (1965-75), $1.8 billion extended; military—U.S. (FY
46-76) $6.8 billion committed
Budget: $5.9 billion (1977)
Monetary conversion rate: rate fixed at 484 won=US$1
since December 1974
Fiscal year: calendar year
GNP: $17.4 billion (1976), $400 per capita; 6.3% real
growth, 1976
Agriculture: main crops—rice, corn, coconut, sugarcane,
bananas, abaca, tobacco
Hee Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
PHILIPPINES /POLAND
Fishing: catch 1.3 million metric tons (1975)
Major industries: mining, agricultural processing, textiles,
chemicals and chemical products
Electric power: 3,500,000 kW capacity (1976); 13.5
billion kWh produced (1976), 310 kWh per capita
Exports: $2,517 million (f.0.b., 1976); coconut products,
sugar, logs and lumber, copper concentrates, bananas,
garments, nickel
Imports: $3,634 million (f.0.b., 1976); petroleum, indus-
trial equipment, wheat
Major trade partners: (1976) exports—34% US., 24%
Japan; imports—27% Japan, 22% US.
Aid: economic—U.S. (FY46-76), $1.8 billion committed;
Japan (CY70-75), $370 million committed; World Bank
Group (FY46-76) $750 million committed; military—U.S.
(FY46-76), $848 million committed
Budget: (CY78) revenues $3.8 billion, expenditures $4.6
billion, deficit $0.8 billion; 11% military, 89% civilian
Monetary conversion rate: 7.4 pesos=US$1, August 1977
Fiseal year: calendar year','747c06570f663c1711b053c8c23b2d294561270fe937333498bdeaeba3eb3d6a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4232d34f22391a584cc3d4d9c46c300af0594d402a308741902b7bbfca201009',1978,'PH','Philippines','economy',122,'GNP: $17.1 billion (1976, in 1976 prices), $1,050 per
capita; real growth, 8.8% (1970-76 average)
Agriculture: most arable land intensely farmed—60%
cultivated land under irrigation; main crops—rice, sweet
potatoes, sugarcane, bananas, pineapples, citrus fruits; food
shortages—wheat, corn, soybeans
Fishing: catch 779,825 metric tons (1975)
Major industries: textiles, clothing, chemicals, plywood,
electronics, sugar milling, food processing, cement, ship
building
Electric power: 5,500,000 kW capacity (1976); 26 billion
kWh produced (1976), 1,580 kWh per capita
Exports: $8,147 million (f.0.b., 1976); 81% textiles, 14%
electrical machinery, 6% plywood and wood products, 7%
machinery and metal products, 7% plastics, 5% sugar
Imports: $7,593 million (c.i.f., 1976); 18% machinery, 9%
electrical machinery, 9% basic metals, 10% crude oil, 10%
chemical products
Major trade partners: exports—37.6% U.S., 18% Japan;
imports—32% Japan, 24% U.S. (1976)
Aid: economic—U.S. (FY46-76), $2.2 billion committed;
IBRD (1964-75), $311 million committed; Japan (1965-74),
$247 million committed; ADB (1968-75), $93 million
committed; military—U.S. (FY46-76), $4.3 billion com-
mitted
Budget: $2.9 billion (FY77)
Monetary conversion rate: NT$38 (New Taiwan)=US$1
Fiscal year: 1 July-30 June
GDP: 6.8 billion ( 1975, in 1975 prices), $1,570 per capita
(est.); average real growth 4.8% (1970-75)
Agriculture: agriculture occupies a minor position in the
economy; main products—rice, vegetables, dairy products;
less than 20% self-sufficient; food shortages—rice, wheat
Major industries: textiles and clothing, tourism, plastics,
electronics, light metal products, food processing
Shortages: industrial raw materials, water, food
Electric power: 2,900,000 kW capacity (1976); 7,300
million kWh produced (1976), 1,630 kWh per capita
Exports: $8.5 billion (f.0.b., 1976), including $1.4 billion
reexports; principal products clothing, plastic articles,
textiles, electrical goods, wigs, footwear, light metal
manutactures
Imports: $8.9 billion (c.if., 1976)
Major trade partners: (1976) exports—35% U.S., 12%
West Germany, 10% U.K.; imports—21% Japan, 18% China,
12% US.
Budget: (76/77) $1.44 billion
Monetary conversion rate: HK$4.884=US$1 (September
1976)
Fiscal year: 1 April-31 March
Agriculture: main crops—rice, vegetables; food short-
ages—rice, vegetables, meat; depends mostly on imports for
food requirements
Major industries: textiles, fireworks
Electric power: 70,000 kW capacity (1976); 175 million
kWh produced (1976), 700 kWh per capita
Exports: $127 million (f.0.b., 1975); textiles and clothing,
foodstuffs
Imports: $147 million (cif, 1975)
Major trade partners: exports—21% France, 14% West
Germany, 10% Hong Kong, 9% Portugal and Portuguese
colonies; imports—71% Hong Kong, 19% China (1975)
Monetary conversion rate: 5.4 patacas= US$1 (December
1975); pataca has been pegged to Hong Kong dollar starting
in 1977
Fiscal year: calendar year','a5be72b148b3b1db2822fe7e1c7762808962689bf06b39aa69b28460868f673c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f973042bd7770cb911348631c4a7dc0758d5ad3870efee9c54f549c86f7b248d',1978,'CO','Colombia','economy',126,'GNP: $16.32 billion, est. (1976, in 1976 prices), $710 per
capita; 76% private consumption, 7% public consumption,
18% gross investment, — 2% net foreign balance (1975); real
growth rate (1976), 7.0%; average real growth rate
(1972-76), 6.5%
43
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
COLOMBIA/COMOROS
Agriculture: main crops—coffee, rice, corn, sugarcane,
plantains, bananas, cotton, tobacco; caloric intake, 2,140
calories per day per capita (1970)
Fishing: catch 66,575 metric tons 1975; exports $10.6
million (1973), imports $10.3 million (1973)
Major industries: textiles, food processing, clothing and
footwear, beverages, chemicals, and metal products
Crude steel: 0.37 million metric tons produced (1975), 16
kg per capita
Electric power: 3,300,000 kW capacity (1976); 13.7
billion kWh produced (1976), 600 kWh per capita
Exports: $2.4 billion (f. 0.b., 1976); coffee, fuel oil, cotton,
tobacco, sugar, textiles, cattle and hides
Imports: $1.7 billion (f.0.b., 1976); transportation equip-
ment, machinery, industrial metals and raw materials,
chemicals and pharmaceuticals, fuels, fertilizers, paper and
paper products, foodstuffs and beverages
Major trade partners: exports—36% U.S.,.16% Germany,
7% Spain; imports—40% U.S., 10% Germany, 8% Japan, 4%
Spain (1973)
Aid: economic—extensions from U.S. (FY46-76), $991
million loans, $325 million grants; from international
organizations (FY46-75), $1.8 billion; from other Western
countries (1960-71), $77.6 million; from Communist coun-
tries (1968-75), $82 million ($2.7 million drawn); military—
assistance from U.S. (FY46-76), $130 million
Budget: (1975) revenues $1.23 billion; expenditures $1.27
billion
Monetary conversion rate: 36.36 pesos=US$1 (October
1977, changes frequently)
Fiscal year: calendar year','dec95390560528004a0b6df1cea75c341fd1949a61ecd3ec6570485d6f3d64ef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0c12524797bfaf070eb7e405af926bcac5e5ae69878de6b60e1c7c59c99ed9f',1978,'KM','Comoros','economy',130,'GDP: about $45 million (1973), $160 per capita; growth
probably negligible through 1974
Agriculture: food crops—rice, manioc, potatoes, fruits,
vegetables; export crops—essential oils for perfumes (mainly
ylang-ylang), vanilla, copra, cloves
Exports: $13 million (1974); perfume oils, vanilla, copra,
cloves
Imports: $37 million (1974); foodstuffs, cement, fuels,
chemicals, textiles
Major trade partners: France, Malagasy Republic, Italy,
Kenya, Tanzania and U.S.
Electric power: 2,400 kW capacity (1976); 3 million kWh
produced (1976); 10 kWh per capita
Aid: French aid in 1971 was about $2.7 million, or about
50% of the island’s entire budget; Arab League, $10 million
in 1976
Budget: 1974—revenues, $10.5 million, current expendi-
tures, $9.4 million, investment expenditures, $1.3 million
Monetary conversion rate: 216 Communaute Financiere
Africaine (CFA) francs=US$1 as of January 1975 (floating
since February 1973)
GDP: $1.7 billion (1976), about $220 per capita; real
growth less than 1% (1970-75)
Agriculture: cash crops—coffee, vanilla, sugar, tobacco,
sisal, rice, cloves, raphia; food crops—rice, cassava, cereals,
potatoes, corn, beans, bananas, coconuts, and peanuts;
animal husbandry widespread: imports some rice, milk, and
cereal
Fishing: catch 56,000 metric tons (1975); exports $16.5
million (1974)
Major industries: agricultural processing (meat canneries,
soap factories, brewery, tanneries, sugar refining), light
consumer goods industries (textiles, glassware), cement
plant, auto assembly plant, paper mill, oil refinery
Electric power: 90,000 kW capacity (1976); 465 million
kWh produced (1976), 60 kWh per capita
Exports: $309 million (f.0.b., est. 1976); 30% coffee, 8%
vanilla, 7% sugar, 6% cloves; agricultural and livestock
products account for about 85% of export earnings
Imports: $360 million (c.if., est. 1976); consumer goods
about 19%, 21% foodstuffs, 41% primary products (crude oil,
fertilizers, metal products), 19% capital goods (1974)
Major trade partners: France (in 1974 accounted for 37%
of exports and 48% of imports), U.S., EC; trade with
Communist countries remains a minute part of total trade
Budget: (FY75) revenues $450 million (including $78
million projected borrowing), expenditures $417 million of
which $300 million current, $117 million development
Monetary conversion rate: 248 Malagasy francs=US$1
Fiscal year: calendar year','67be0be9bb8ec5c588699fce9b66821da988297ff3b58a0f46f80e7a19bbba60','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c4ee17a89d6693fd02d97999f77eed0efe3814e28182a71e56c136a735e720a',1978,'CG','Congo','economy',134,'GDP: about $600 million (1974 est.), $580 per capita; real
growth rate about 5% per year (1971-74)
Agriculture: cash crops—sugarcane, wood, coffee, cocoa,
palm kernels, peanuts, tobacco; food crops—root crops, rice,
corn, bananas, manioc, fish
Fishing: catch 15,674 metric tons (1975)
Major industries: crude oil, sawmills, brewery, cigarettes,
sugar mill, soap
Electric power: 51,200 kW capacity (1976); 120 million
kWh produced (1976), 90 kWh per capita
Exports: $220 million (f.0.b., 1976 est.); oil (58%), lumber,
sugar, tobacco, veneer, and plywood
Imports: $329 million (f.0.b., 1976 est.);_ machinery,
transport equipment, manufactured consumer goods, iron
and steel, foodstuffs, petroleum products
Major trade partners: France and other EC countries
Budget: 1976 est.—revenue $184 million, expenditures
$221 million
Monetary conversion rate: 249.35 Communaute Finan-
ciere Africaine francs=US$1 as of February 1977
Fiscal year: calendar year','b393319356bdabf3140bd0519e78f0e1f119117dd47f7daad5be26b99bccfe36','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66c4db7bea1a032e3813707b7e0acbb0cafb9df562d2381568ce02a0f9890588',1978,'CK','Cook Islands','economy',138,'GDP: $400 per capita (1973)
Agriculture: export crops include copra, citrus fruits,
pineapples, tomatoes, and bananas, with subsistence crops of
yams and taro
Industry: fruit processing
Electric power: 3,000 kW capacity (1976); 10 million
kWh produced (1976), 580 kWh per capita
Exports: $2.7 million (1971); fruit juice, clothing, citrus
fruits
Imports: $5.8 million (1971)
Major trade partners: (1970) exports—98% New Zealand,
imports—76% New Zealand, 7% Japan
Monetary conversion rate: 1 NZ$=US$0.9947 (July
1976)','e8a36a093fd471f410bb94e40ec3f428d5b62d22415b56a9ffd84685462ea8ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8df5c90cad18fe8df427839fc1ca3a03f6fa403d320f2031b8906fd9f570228e',1978,'CR','Costa Rica','economy',142,'GNP: $1.9 billion (1976, in 1976 dollars), $940 per capita;
72% private consumption, 17% public consumption, 23%
gross domestic investment, —12% net foreign balance
(1975); real growth rate 1976, 5.5%; average growth
(1972-76), 6.0%
Agriculture: main products—bananas, coffee, sugarcane,
rice, corn, cocoa, livestock products; caloric intake, 2,610
calories per day per capita (1966)
Fishing: catch 15,695 metric tons (1975); exports, $3.7
million (1974), imports, $0.6 million (1974)
Major industries: food processing, textiles and clothing,
construction materials, fertilizer
Electric power: 380,000 kW capacity (1976); 1.5 billion
kWh produced (1976), 740 kWh per capita
Exports: $587 million (f.0.b., 1976); coffee, bananas, beef,
sugar, cacao
Imports: $773 million (c.i.f., 1976); manufactured prod-
ucts, machinery, transportation equipment, chemicals, fuels,
foodstuffs, fertilizer
Major trade partners: exports—32% U.S., 24% CACM,
13% West Germany; imports—34% U.S., 16% CACM, 6%
West Germany, 10% Japan (1974)
Aid: economic—extensions from U.S. (FY46-75), $138
million loans, $117 million grants; from international
organizations (FY46-75), $349 million; from other Western
countries (1960-71), $7.7 million; military—assistance from
U.S. (FY60-76), $2.0 million; Communist— (economic) from
US.S.R., $17 million (1971)
Monetary conversion rate: 8.57 colones=US$1
Fiscal year: calendar year','2baf72ccbf79a90407980755e1b40de3db7b63a70e2d2ff505b5976642fc896a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6723e17c13cb88daac84cca17dccffe82214000906793c8aeedf853a93a2a7d5',1978,'CU','Cuba','economy',146,'GDP: $7.5 billion (1974 est., in 1974 prices), $820 per
capita; 60% private consumption, 20% public consumption,
20% gross investment; real growth rate 1974, 3%
Agriculture: main crops—sugar, tobacco, coffee, rice,
potatoes, tubers, citrus fruits
Fishing: catch 183,000 metric tons (1976); exports $63
million (1975), imports $24.4 million (1973)
Major industries: sugar milling, petroleum refining, food
and tobacco processing, textiles, chemicals, paper and wood
products, metals
Shortages: spare parts for transportation and industrial
machinery, consumer goods
Crude steel: 0.35 million metric tons capacity (planned);
297,500 metric tons produced (1975); 30 kg per capita
Electric power: 1,600,000 kW capacity (1976); 7 billion
kWh produced (1976), 740 kWh per capita
Exports: $3.2 billion (f.0.b., 1976 est.); sugar, nickel,
tobacco
Imports: $8.7 billion (c.if., 1976 est.); capital goods,
industrial raw materials, food, petroleum
Major trade partners: exports—65% U.S.S.R., 15% other
Communist countries; imports—49% U.S.S.R., 14% other
Communist countries, 6% Spain (1976)
Monetary conversion rate: 1 peso=US$1.21 (nominal)
Fiscal year: calendar year','45a241cb1c13da248196179e412b9fcc719bc25ffe1b43d2d5421ec64d00d3ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a1a5635eb2c6be8701b65a3dafef2dacd9284b34e93d1270c51e992712e8b7c',1978,'CY','Cyprus','economy',150,'GNP: $789.3 million (1976), $1,220 per capita; 1976 real
growth rate 14.6%
Agriculture: main crops—vine products, citrus, potatoes,
other vegetables; food shortages—grain, dairy products,
meat, fish; caloric intake, 2,460 calories per day per capita
(1964-66)
Major industries: mining (cupreous and iron pyrites,
asbestos), manufactures principally for local consumption—
food, beverages, footwear, clothing, cement
Shortages: water, petroleum
Electric power: 278,000 kW capacity (1976); 792 million
kWh produced (1976), 1,220 kWh per capita
Exports: $258 million (f.0.b., 1976, converted at average
trade conversion factor of 1 Cyprus pound=US$2.44);
principal items—asbestos, copper, pyrites, citrus, raisins, and
other agricultural products, potatoes, cement, clothing,
footwear, wine
Turkish Sector exports: $15.7 million (f.0.b., 1976, con-
verted at average conversion factor of 16.053 Turkish
lira=US$1); citrus fruits
Imports: $434 million (c.i.f., 1976, converted at average
trade conversion factor of 1 Cyprus pound=US$2.44),
principal items—manufactured goods, machinery and trans-
port equipment, petroleum products, foods
Turkish Sector imports: $65.9 million (c.if., 1976, con-
verted at average trade conversion factor of 16.053 Turkish
lira=US$1); principal items are foodstuffs, livestock, raw
materials, oil i
Major trade partners: (1976) imports—20% U.K., 10%
Greece, 9% Italy, 7% West Germany, 6% U.S., 5% France;
exports—28% U.K., 17% Lebanon, 6% Syria, 6% Saudi
Arabia, 5% Libya, 5% U.S.S.R., 2% Netherlands, 2% Greece,
1% West Germany
Turkish Sector major trade partners: (1976) imports—
47.4% Turkey, 25% U.K., 6% West Germany, 4% Lebanon;
exports—30% Turkey, 33% U.K., 12% Netherlands
Aid: economic—U.S., $88.4 million authorized (FY46-76),
US., $30 million (1976); IBRD, $80.1 million (FY46-76);
U.N. Technical Assistance, $1.7 million (FY46-72); U.N.
Special Fund, $9.9 million (FY46-72); Greece, $79 million
(1976)
Turkish Sector aid: Turkey, $45 million
Budget: 1977—revenues $166.3 million, expenditures
$180 million, deficit $13.7 million
Turkish Sector budget: revenues $38 million, expendi-
tures $78 million, deficit $40 million
Monetary conversion rate: 1 Cyprus pound=US$2.61
(December 1971 through January 1973), 1 Cyprus
pound =US$2.4560 (trade conversion factor as of July 1977)
Turkish Sector monetary conversion rate: 16.67 Turkish
lira=US$1 (trade conversion factor as of June 1977)
Fiscal year: calendar year
Note: 1974, 1975, and 1976 GNP, import, export, and
budget figures are Government of Cyprus figures which
include 100% of island until August 1974 and 60% of island
thereafter; the Turkish sector of island for last 4 months of
1974 is part of Turkish mainland economy; with the passage
of time, some information on the Turkish sector of the island
has become available.
GNP: $55.1 billion in 1976 (at 1975 prices), $3,690 per
capita; 1976 real growth rate 1.8%
Agriculture: diversified agriculture, main crops—wheat,
rye, potatoes, sugar beets; net food importer—meat, wheat,
vegetable oils, fresh fruits and vegetables; caloric intake,
3,100 calories per day per capita (1967)
Major industries: machinery, food processing, metal-
lurgy, textiles, chemicals
Shortages: ores, crude oil
Crude steel: 14.7 million metric tons produced (1976),
990 kg per capita
Electric power: 14.5 million kW capacity (1976); 62.7
billion kWh produced (1976), 4,200 kWh per capita
Exports: $9,395 million (f.0.b., 1976); 48% machinery,
equipment; 80% fuels, raw materials; 4% foods, food
products, and live animals; 18% consumer goods, excluding
foods (1975)
Imports: $9,705 million (f.0.b., 1976); 87% machinery,
equipment; 42% fuels, raw materials; 9% foods, food
products, and live animals; 7% consumer goods, excluding
foods (1975)
Monetary conversion rate: noncommercial
crowns=US$1, commercial 5.70 crowns=US$1
10.15
Fiscal year: calendar year
Note: foreign trade figures were converted at the rate of
6.77 crowns=US$1','5ad7ae4acbc4ca5f2c255feb93abcdd2ee5f39a1e052ede1d7294e1b53eae7e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1420a7b43f445782e51dcf0bb3d5f45df3500deec6bdcc2bf2597c681033d41c',1978,'DK','Denmark','economy',154,'GNP: $42.8 billion (1976), $8,430 per capita; 53% private
consumption, 22.3% investment, 28.4% government, —3.7%
net foreign sector and stock building (1975); 1976 growth
rate 5%, constant prices
Agriculture: highly intensive, specializes in dairying and
animal husbandry; main crops—cereals, root crops; food
imports—oilseeds, grain, feedstuffs; caloric intake, 3,180
calories per day per capita (1968-69)
53
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
DENMARK/DJIBOUTI
Fishing: catch 1.88 million metric tons, exports $507
million (1976)
Major industries: food processing, machinery and equip-
ment, textiles and clothing, chemical products, electronics,
transport equipment, metal products, brick and mortar,
furniture and other wood products
Crude steel: 723,000 metric tons produced (1976), 140 kg
per capita
Electric power: 6,400,000 kW capacity (1976); 23.9
billion kWh produced (1976), 4,710 kWh per capita
Exports: $9.1 billion (f.0.b., 1976); principal items—meat,
dairy products, industrial machinery and equipment, textiles
and clothing, chemical products, transport equipment, fish,
furs, and furniture
Imports: $12,4 billion (c.if., 1976); principal items—
industrial machinery, transport equipment, petroleum,
textile fibers and yarns, iron and steel products, chemicals,
grain and feedstuffs, wood and paper
Major trade partners: 46.5% EC-nine (18.1% West
Germany, 13.1% U.K.); 14.9% Sweden; 5.4% U.S.; 4.2%
Communist countries (1976)
Aid: economic—U.S., $282 million authorized FY46-76;
IBRD, $85.2 million through 1975, none since 1964; net
official economic aid given to less developed areas and
multilateral agencies, $250.5 million ( 1960-70), $76.5 million
(1971), $98.3 million (1972), $131.6 million (1973), $170.9
million (1974); military—U.S., $640 million (FY49-76)
Budget: (1976) expenditures $13.75 billion, revenues
$11.15. billion
Monetary conversion rate: 6.045 Kroner=US$1 (1976,
average exchange rate)
Fiscal year: 1 April-31 March','df559cbc509b2dba4e40702bbde3f1e627c39aeb56a67fce9620247f4d3e4c2b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cbae32cb3663b045076cbf992f16e2069cfd8b134a400ef4409dfbf13cc7b34',1978,'DJ','Djibouti','economy',158,'Gross territorial product: $65 million (1972)
Agriculture: livestock; desert conditions limit commercial
crops to about 15 acres, including fruits and vegetables
Industry: ship repairs and services of port and railroad
drastically reduced with war in Ethiopia’s Ogaden that cut
the railroad line
Electric power: 23,500 kW capacity (1976); 55 million
kWh produced (1976), 310 kWh per capita
Imports: $74 million (1973); almost all domestically
needed goods—foods, machinery, transport equipment
Exports: $20 million, including transit trade (1973); hides
and skins, and transit of coffee; since railroad line has been
cut, values have plummeted
Monetary conversion rate: 177 Djibouti francs=US$1
Fiscal year: probably same as that for France (calendar
year)','523bd5f4582e0f5d2027e602f0f0d9c18cf2aa06a3c0a3ae3a6e0303fa8f9735','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b26c46c3b6d1c542e9a382203cd9f0321a2cf914333b14dbd93583008efe636b',1978,'DM','Dominica','economy',162,'GDP: $21.0 million (1971 est.), $270 per capita; 8.8%
increase in 1971, including price changes
Agricultural products: bananas, citrus, coconuts, cocoa
Major industries: agricultural processing, tourism
Electric power: 10,000 kW capacity (1976); 7 million
kWh produced (1976), 260 kWh per capita
Exports: $12 million (f.0.b., 1975); bananas, lime juice and
oil, cocoa, reexports
Imports: $22 million (c.if., 1975); machinery and
equipment, foodstuffs, manufactured articles, cement
Major trade partners: 47% U.K., 15% Commonwealth
Caribbean countries, 7% U.S., 6% Canada (1975)
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (May 1975), now floating with pound sterling','faaf7b2cd6539ae1860b0fe1d2334c6333a6842822f9a41b6b94ecc4d10ef3a7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06e21695946d6c74450949509ffd11c33f3a8d33463777b63c6b84ae0c36aec7',1978,'JM','Jamaica','economy',166,'GNP: $3.8 billion (1976), $790 per capita; real growth rate
1976, 2.9%
Agriculture: main crops—sugarcane, coffee, cocoa, to-
bacco, rice, corn; imports rice; caloric intake, 2,200 calories
per day per capita (1966)
Major industries: sugar processing, nickel mining, bauxite
mining, gold mining, textiles, cement
Electric power: 670,000 kW capacity (1976); 1.7 billion
kWh produced (1976), 350 kWh per capita
Exports: $716 million (£.0.b., 1976); sugar, nickel, coffee,
tobacco, cocoa, bauxite
Imports: $878 million (c.if., 1976); foodstuffs, petroleum,
industrial raw materials, capital equipment
Major trade partners: exports—71% U.S. (1975); im-
ports—58% U.S. (1975)
Aid; economic—U.S. authorizations (FY46-76), $250
million in grants, $278 million in loans; from international
organizations (FY 46-76), $310 million; military—assistance
from U.S. (FY53-76), $40 million, mostly grant
Budget: revenues, $584 million; expenditures, $555
million (1976)
Monetary conversion rate: 1 peso=US$1
Fiscal year: calendar year
GNP: $2,970 million (1976), $1,430 per capita, real
growth rate 1976, —6.3%
Agriculture: main crops—sugarcane, citrus fruits, ba-
nanas, pimento, coconuts, coffee, cocoa
Major industries: bauxite mining, textiles, food process-
ing, light manufactures, tourism
Electric power: 758,000 kW capacity (1976); 2.3 billion
kWh produced (1976), 1,110 kWh hr. per capita
Exports: $605 million (f.o.b., 1976); alumina, bauxite,
sugar, bananas, citrus fruits and fruit products, rum, cocoa
Imports: $991 million (c.i.f., 1976); fuels, machinery,
transportation and electrical equipment, food, fertilizer
Major trade partners: exports—U.S. 38%, U.K. 23%,
Norway 11%, Canada 4%; imports—U.S. 37%, U.K. 13%,
Canada 5% (1975)
107
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
JAMAICA/JAPAN
Aid: economic—authorization from U.S. (FY56-76), $48
million in loans, $60 million in grants; from other Western
countries (1960-74), $151 million; from international organi-
zations (FY46-76), $232 million; military—authorizations
from U.S. (FY63-76), $1 million in grants
Budget: FY76-77, prelim.—revenue $974 million, ex-
penditure $1,304 million
Monetary conversion rate: 1 Jamaican dollar=US$1.10;
1 Jamaican dollar=US$0.80 for tourists and some commer-
cial transactions
Fiscal year: 1 April-31 March','df641d4219e9b5841f10f6f1ee4ac4da8796ae3159399dabdebb1649d772ab81','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f138d10f691add586852c5c15f94f9733649918e47a58497da35c1fa5d22363d',1978,'EC','Ecuador','economy',170,'GNP: $5.0 billion (est. 1976), $710 per capita; 60% private
consumption, 10% public consumption, 30% gross invest-
ment; average annual real growth rate 1974-76, 10.1%
Agriculture: main crops—bananas, coffee, cocoa, sugar-
cane, cotton, corn, potatoes, rice; caloric intake, 1,970
calories per day per capita (1970)
Fishing: catch 233,400 metric tons (1975); exports $55
million (1976), imports negligible
Major industries: food processing, textiles, chemicals,
fishing, petroleum
Electric power: 410,000 kW capacity (1976); 1.6 billion
kWh produced (1976), 230 kWh per capita
Exports: $1.3 billion (f.0.b., 1976); petroleum, bananas,
coffee, cocoa, sugar, fish products
Imports: $1.1 billion (f.0.b., 1976); agricultural and
industrial machinery, wheat, petroleum products, chemical
products, transportation and communication equipment
Major trade partners: exports (1975)—47% U.S., 20%
LAFTA, 9% EC; imports (1975)—41% US., 20% EC, 13%
LAFTA
Aid: economic—extensions from U.S. (FY46-75), $155
million loans, $138 million grants; from international
organizations (FY46-75), $439 million; from Communist
countries (1967-76), $19.4 million loans; military—assistance
from U.S. (FY49-76), $81 million
Budget: (1976) revenues, $592 million; expenditures, $636
million
Monetary conversion rate: 25 sucres=US$1
Fiscal year: calendar year','b80f5825014271f3e7559314dc5ed9b759a33f6b232bfe8cd4fd2d1bc4ad69e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ba01da10814f939e8f19190d542d0b89c7144673aed06fde39fe31980df697c',1978,'EG','Egypt','economy',174,'GNP: $14 billion (1976 est.), in current prices, $370 per
capita; average annual growth rate of 6%-7% since 1974
Agriculture: main cash crop—cotton; other crops—rice,
onions, beans, citrus fruit, wheat, corn, barley; not self-suffi-
cient in food, but agriculture a net earner of foreign
exchange
Major industries: textiles, food processing, chemicals,
petroleum, construction, cement
Electric power: 4,871,000 kW capacity (1976); 9.0 billion
kWh _ produced (1976), 240 kWh per capita
Monetary conversion rate: official rate—l Egyptian
pound=US$2.54 (selling rate); 0.394 Egyptian pound=
US$1 (selling rate); parallel market rate—l Egyptian
pound=US$1.43, 0.699 Egyptian pound=US$1
Fiscal year: calendar year, beginning in 1973','ee106f104e23d698b8e4270e231d2ef815acdb069ab47b8e490c0db708235454','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1718137c37a528eceeaeb51aea12c280f31915270ce5219f812f8e3f0d166bb0',1978,'SV','El Salvador','economy',178,'CNP: $2.1 billion est. (1976), $510 per capita; 70% private
consumption, 11% government consumption, 19% domestic
investment; real growth rate, 5.5% (1976 prelim.)
Agriculture: main crops—coffee, cotton, corn, sugar, rice,
beans; caloric intake, 2,000 calories per day per capita
(1963-64)
Fishing: catch 10,550 metric tons (1975); exports $6.0
million (1971), imports $0.8 million (1974)
Major industries: food processing, textiles, clothing,
petroleum products
Electric power: 260,000 kW capacity (1976); 1.1 billion
kWh produced (1976), 270 kWh per capita
Exports: $721 million (f.0.b., 1976); coffee, cotton, sugar
Imports: $705 million (c.if., 1976); machinery, auto-
motive vehicles, petroleum, foodstuffs, fertilizer
Major trade partners: exports—30% U.S., 25% CACM,
45% other (1976); imports—32% US., 24% CACM, 44%
other (1976)
Aid: economic—from U.S. (FY46-76), $104 million loans,
$82 million grants; from international organizations
(FY46-75), $287 million; from other Western countries
(1960-71), $9.8 million; military—assistance from U.S.
(FY53-76), $16 million
Budget: (1977) $428 million
Monetary conversion rate: 2.5 colones=US$1_ (official)
Fiscal year: calendar year','72ecc0cbabc70c26ef6f0f26e14cfcf6fcd038661453db5c9132faff31bb6ff4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c894461927a03c2ba79862f786daf9dbfbe089f014acbd8fa435965c0b663eb7',1978,'ET','Ethiopia','economy',182,'CDP: $2,650 million (1975), $90 per capita; average
annual real growth rate 4% (1967-73), zero (1974 and in
1975)
Agriculture: main crops—coffee, teff, durra, barley,
wheat, corn, sugarcane, cotton, pulses, oilseeds; livestock
Major industries: cement, sugar refining, cotton textiles,
food processing, oil refinery
Electric power: 297,000 kW capacity (1976); 500 million
kWh produced (1976), 20 kWh per capita
Exports: $283 million (£.0.b., 1976); coffee 55%, oilseeds
5%, pulses 10%, hides and skins 9%; $12.6 million to
Communist countries (1976)
Imports: $360 million (c.f, 1976); machinery and
transportation equipment (84%), basic manufactures (25%),
fuels (15%); in 1977 military material bulks large; $17.9
million from Communist countries
Major trade partners: imports—Saudi Arabia, Japan,
Italy, West Germany, Iran, U.K., France, and U.S.;
exports—U.S., Djibouti, Saudi Arabia, Japan, Italy, West','6f89e5f66ca91d7d9e8ce650afc1d605e09dc3a91a9192201b3dbf6160837ed5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2998ceb6dfa2d9fea7e92739725d286b25616ceb8016ad339047ecb67cbc43a2',1978,'DE','Germany','economy',183,'Monetary conversion rate: 2.05 Ethiopian Birr=US$1
Fiscal year: 8 July-7 July
Government budget: Colony—revenues, $1.0 million
(FY68); expenditures, $1.1 million (FY68)
Agriculture: Colony—predominantly sheep farming; de-
pendencies—whaling and sealing
Major industries: Colony—wool processing; depend-
encies—whale and seal processing
Electric power: 1,250 kW capacity (1976); 2.5 million
kWh produced (1976), 1,150 kWh per capita
Exports: Colony—$2.28 million (1969); wool, hides and
skins, and other; dependencies—no exports in 1968 or 1969
Imports; Colony—$1.22 million (1969); food, clothing,
fuels, and machinery; dependencies—$8,368 (1969); mineral
fuels and lubricants, food, and machinery
Major trade partners: nearly all exports to the U.K., also
some to the Netherlands and to Japan; imports from
Curacao, Japan, and the U.K.
Monetary conversion rate: 1 Falkland Island
pound = US$2.60
Aid: economic—from U.S. (FY46-76), $129 million loans,
$236 million grants; from international organizations
(FY46-75), $246 million; from other Western countries
(1960-71), $12.3 million; military—assistance from U.S.
(FY46-75), $41 million
Central government budget (1975 est.): expenditures,
$368 million, revenues, $340 million
Monetary conversion rate: 1 quetzal=US$1 (official)
Fiscal year: calendar year','d5c8f93a703cfe10e7a9c9501c36205102a95c7a06a771f190bae64ee0be8312','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b26c3eca000aa418e064576685ecba0fc736bc073916314d8bdc11e852a978eb',1978,'FO','Faroe Islands','economy',190,'GDP: $146.4 million (1973), about $3,650 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 285,618 metric tons (1975); exports, $65.0
million (1975)
Major industry: fishing
Electric power: 28,500 kW capacity (1976); 88 million
kWh produced (1976), 2,150 kWh per capita
Exports: $80.8 million (f.0.b., 1975); fish and fish products
Imports: $113.3 million (c.if., 1975); machinery and
transport equipment, petroleum and petroleum products,
food products
Major trade partners: 46.6% Denmark, 12.3% Norway,
8.0% U.K., 6.2% U.S. (1975)
Budget: (FY73) expenditures $21.4 million, revenues
$22.7 million
Monetary conversion rate: 6.0450 Danish Kroner=US$1
(1976, average)
Fiscal year: 1 April-31 March','67c51246194f8aeead9964c96fb09f9eac0a6d114f88423281a5d53e62a43818','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c93ec24329c18b8a49008b42953aa3ffceed0d3a71229965484d4b76869fcee1',1978,'FJ','Fiji','economy',194,'GNP: $644 million (1975), $1,180 per capita; 5.8% real
growth rate (1971-75)
Agriculture: main crops—sugar, coconut products, ba-
nanas, rice; major deficiency, grains
Major industries: sugar processing, tourism
Electric power: 90,000 kW capacity (1976); 270 million
kWh produced (1976), 450 kWh per capita
Exports: $183 million (f.o.b., 1975, including reexports);
70% sugar, 11% coconut oil, 9% gold
Imports: $267 million (f.o.b., 1975); 20% manufactured
goods, 19% food, 16% machinery (1974)
Major trade partners: exports—38% U.K., 31% U.S., 11%
Australia; imports—30% Australia, 18% Japan, 11% New
Zealand, 4% U.S. (1974)
Aid: disbursed 1968—Australia $1.5 million, U.S. $0.6
million, U.K. $4.2 million
Budget: (FY75 est.) revenues $102 million, expenditures
$102 million
Monetary conversion rate: Fijian dollar=US$1.0706
(February 1977)
Fiscal year: calendar year','24b91666adfbe485dfd87335409fe1b1a3b98e68787758eaeb83033422913eaa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('639fc5985d4fdafb4d01cbe44e349f4bb204835143bc6301738f91448eb89ac0',1978,'FI','Finland','economy',198,'CNP: $28 billion (1976), $5,920 per capita; 51.6%
consumption, 26.0% investment, 19.9% government, —2%
net exports of goods and services; 1976 growth rate 0.3%,
constant prices
Agriculture: animal husbandry, especially dairying, pre-
dominates; forestry important secondary occupation for
rural population; main crops—cereals, sugar beets, potatoes;
85% self-sufficient; shortages—food and fodder grains;
caloric intake 2,940 calories per day per capita (1970-71)
67
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
FINLAND/FRANCE
Major industries: include metal manufacturing and
shipbuilding, forestry and wood processing (pulp, paper),
copper refining
Shortages: fossil fuels; industrial raw materials, except
wood, and iron ore
Crude steel: 1.6 million metric tons produced (1975), 340
kg per capita
Electric power: 7,660,000 kW capacity (1976); 29.3
billion kWh produced (1976), 6,190 kWh per capita
Exports: 6.3 billion (f.0.b., 1976); timber, paper and pulp,
ships, machinery, iron and steel, clothing and footwear
Imports: $7.4 billion (c.i.f., 1976); foodstuffs, petroleum
and petroleum products, chemicals, transport equipment,
iron and steel, machinery, textile yarn and fabrics
Major trade partners: (1976) 38% EC-nine (138% West
Germany, 11% U.K.); 19% U.S.S.R., 18% Sweden; 5% U.S.
Aid: U.S. $57 million authorized FY46-75; IBRD—$316
million authorized through FY46-75, $20 million in 1975;
Finnish foreign aid programs have amounted to $23 million
1961-69, $15,000 in 1970
Budget: (1976) expenditures $8.0 billion, revenues $7.9
billion
Monetary conversion rate: new markka
3.86=US$1 (1976 trade conversion factor, IMF)
Fiscal year: calendar year
(Fmk)','2051b5de7217b5abe1273d04bc54da76878385c3a625e68bfcc84e6a36ffa327','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f452469baaf92f19c764167b70ce5827647f5f2d82cb37bb449f6216441bf746',1978,'FR','France','economy',200,'GNP: $347 billion (1976), $6,547 per capita; 63.9% private
consumption, 22.9% investment (including government),
13.2% government consumption; 1976 real growth rate,
5.2%; average annual growth rate, 5.2% (1965-75)
Agriculture: Western Europe’s foremost producer; main
products—beef, cereals, sugar beets, potatoes, wine grapes;
self-sufficient for most temperate zone foodstuffs; food
shortages—fats and oils, tropical produce; caloric intake,
3,270 calories per day per capita (1969-70)
Fishing: catch 691,394 metric tons (1976); exports
(includes shellfish, etc.) $122 million, imports $506 million
(1976)
Major industries: steel, machinery and equipment,
textiles and clothing, chemicals, food processing, metallurgy,
aircraft, motor vehicles
Shortages: crude oil, textile fibers, most nonferrous ores,
coking coal, fats and oils
Crude steel: 23.2 million metric tons produced (1976),
440 kg per capita
Electric power: 52,200,000 kW capacity (1976); 206
billion kWh produced (1976), 3,900 kWh per capita
Exports: $57.2 billion (f.0.b., 1976); principal items—
machinery and transportation equipment, foodstuffs, agri-
cultural products, iron and steel products, textiles and
clothing, chemicals
Imports: $64.4 billion (c.i.f., 1976); principal items—
crude petroleum, machinery and equipment, chemicals, iron
and steel products, foodstuffs, agricultural products
Major trade partners: 20% West Germany; 11% Belgium-
Luxembourg; 11% Italy; 7% U.S.; 6% Netherlands; 6% U.K.;
2% Eastern Europe; 2% U.S.S.R.; 4% Franc Zone (1975)
Aid: economic (received) —U.S., $5,363 million author-
ized (FY46-75), $44 million in FY73; military—U.S., $4,549
million authorized (FY46-75); net official economic aid to
less developed areas and multilateral agencies—$8,400
million (FY60-70), $1,125 million in 1971, $457 million in
1974
Budget: (1976) expenditures 346 billion francs, revenues
329 billion francs, deficit 17 billion francs
Monetary conversion rate: 1 franc=US$0.2092 (1976
average)
Fiscal year: calendar year
GDP: $3.0 billion (1976), $460 per capita; real growth
rate, near zero (1977)
Agriculture: main crops—tobacco, corn, sugar, cotton;
livestock; self-sufficient in foodstuffs
Major industries: mining and steel, textiles
Electric power: 1,453,000 kW capacity (1976); 6.9 billion
kWh produced (1976), 1,000 kWh per capita
Exports: $652 million (f.0.b., 1973), including net gold
sales and reexports; tobacco, asbestos, copper, meat, chrome,
gold, nickel, clothing, sugar
Imports: $541 million (c.if., 1973); machinery, petroleum
products, wheat, transport equipment
Major trade partner: South Africa
Aid: no substantial military or economic aid
Budget: FY76—revenues $678 million, expenditures $895
million, deficit $217 million
Monetary conversion rate: 1 Rhodesian dollar = US$1.54,
0.649 Rhodesian dollar=US$1
Fiscal year: 1 July-30 June','7a732482a44ce468a2b89bd965bbe925277b30f3628fe644b4ad5616fa339b1b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c447223a60fe75e202d3cc64e8b7be765e71f5cda867f0c612c8ec3815862d10',1978,'GF','French Guiana','economy',205,'GNP: $40 million (at market prices, 1970), $800 per
capita
70 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
FRENCH GUIANA/FRENCH POLYNESIA
Agriculture: main crops—rice, corn, manioc, cocoa,
bananas, sugarcane
Fishing: catch 933 metric tons (1975); exports $0.6 million
(1974); imports $2.2 million (1971)
Major industries: timber, rum, gold mining, production
of rosewood essence, and space center
Electric power: 29,000 kW capacity (1976); 60 million
kWh produced (1976), 1,111 kWh per capita
Exports: $5 million (f.0.b., 1973); shrimp, timber, rum,
rosewood essence
Imports: $56 million (c.i.f., 1973); food (grains, processed
meat), other consumer goods, producer goods and petroleum
Major trade partners: exports—78% U.S., 11% France,
5% Martinique; imports—49% France, 10% US. 3%
Trinidad and Tobago (1969)
Monetary conversion rate: 4.44 French francs=US$1
Fiscal year: calendar year
GDP: $259 million (1970) $1,960 per capita (1971)
Agriculture: coconut main crop
Major industries: maintenance of French nuclear test
base, tourism
Electric power: 36,000 kW capacity (1976); 105 million
kWh produced (1976), 883 kWh per capita
Exports: $19 million (1973); principal products—coconut
products (79%), mother-of-pearl (14%) (1971)
Imports: $211 million (1973)
Major trade partners: imports—59% France, 14% US.;
exports—86% France
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 :
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
FRENCH POLYNESIA/GABON
Aid: France $16 million (1973)
Monetary conversion rate: 100 CFP=1NZ$ (1971)
GDP: $1,605 million (1975), $2,960 per capita; 36%
growth (1973-75)
Agriculture: commercial—cocoa, coffee, wood, palm oil,
rice; main food crops—bananas, manioc, peanuts, root crops;
imports food
Fishing: catch 6,056 metric tons (1975)
Major industries: petroleum production, sawmills, petro-
leum refinery, natural gas, agricultural processing; mining of
increasing importance; major minerals—manganese, uran-
ium, gold, and iron
Electric power: 106,200 kW capacity (1976); 328 million
kWh produced (1976), 590 kWh per capita
Exports: $896 million (f.0.b., 1975); crude petroleum,
wood and wood products, minerals (manganese, uranium
concentrates, gold)
72 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GABON/THE GAMBIA
Imports: $706 million (c.i.f., 1976); excluding UDEAC
trade; mining, roadbuilding machinery, electrical equip-
ment, transport vehicles, foodstuffs, textiles
Major trade partners: France, U.S., West Germany, and
Curacao; preferential tariffs to EC and france zone
Budget: 1975 est.—receipts $630 million, current expend-
itures $184 million, investment expenditures $446 million
Monetary conversion rate: 249.35 Communaute Finan-
ciere Africaine francs=US$1 as of February 1977
Fiscal year: calendar year
GNP: $115 million (FY76-77 est.), about $200 per capita
Agriculture: main crops—peanuts, rice, palm kernels
Fishing: catch 10,795 metric tons (1975); exports $956,000
(1974)
Major industry: peanut processing
Electric power: 10,000 kW capacity (1976); 16 million
kWh produced (1976), 30 kWh per capita
Exports: $44 million (1977 est.); peanuts and peanut
products 90% to 95%, palm kernels
Imports: $77.6 million (1977 est.); textiles, foodstuffs,
tobacco, machinery, petroleum products
Major trade partners: exports—U.K. and France; im-
ports—U.K. and Japan
Aid: economic—U.K. (1968-71), about $8 million commit-
ment, U.S. (FY56-76), $10.6 million; other international
organizations (FY62-75), $10.8 million
Budget: (FY75 est.) current expenditures $13 million,
receipts $17 million; development expenditures $6.7 million,
development receipts $7.2 million
Monetary conversion rate: 1 Dalasi=US$0.43 (February
1977)
Fiscal year: 1 July-80 June
GNP: $63.0 billion in 1976 (1975 prices), $3,750 per
capita; 1976 growth rate 2.4%
Agriculture: food deficit area; main crops—potatoes, rye,
wheat, barley, oats, industrial crops; shortages in grain,
vegetables, vegetable oil, beef; caloric intake, 3,000 calories
per day per capita (71)
Fish catch: 327,000 metric tons (1975)
Major industries: metal fabrication, chemicals,
industry, brown coal, and shipbuilding
light
Shortages: coking coal, coke, crude oil, rolled steel
products, nonferrous metals
Crude steel: 6.74 million metric tons produced (1976,
preliminary estimate), approx. 400 kg per capita
Electric power: 17,490,000 kW capacity (1976); 89.1
billion kWh produced (1976), 5,290 kWh per capita
Exports: $11,361 million (f.0.b. delivering country, 1976)
Imports: $13,196 million (f.0.b. delivering country, 1976)
Major trade partners: $24,556 million (1976); 67%
Communist countries, 33% non-Communist countries
Monetary conversion rate: 3.48 DME=US$1 for trade
data (1976 rate)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for the consumption year | July-30 June
Approved For Release 2005/04/22 :
GNP: $473 billion (1976), $7,640 per capita (including
West Berlin) (1976); 55% consumption, 21% investment, 21%
government consumption (does not include total govern-
ment spending); net foreign balance 2%; average annual
growth rate 1966-76, 3.5% in constant 1962 prices
Agriculture: main crops—grains, potatoes, sugar beets;
75% self-sufficient; food shortages—fats and oils, pulses,
tropical products; caloric intake, 2,984 calories per day per
capita (1973-74)
Fishing: catch 426,000 metric tons, $171 million (1976);
exports $143 million, imports $388 million (1976)
Major industries: among world’s largest producers of
iron, steel, coal, cement, chemicals, machinery, ships,
vehicles
Shortages: fats and oils, sugar, cotton, wool, rubber,
petroleum, iron ore, bauxite, nonferrous metals, sulfur
Crude steel: 63.6 million metric tons capacity; 42.4
million metric tons produced (1976); 690 kg per capita
Electric power: 75,770,000 kW capacity (1976); 353
billion kWh produced (1976), 5,710 kWh per capita
Exports: $102 billion (f.0.b., 1976); manufactures 90.6%
(machines and machine tools, chemicals, motor vehicles, iron
and steel products), agricultural products 4.0%, fuels 2.7%,
raw materials 2.6%
Imports: $88 billion (cif, 1976); manufactures 58.5%,
fuels 17.7%, agricultural products 13.8%, raw materials
10.0%
Major trade partners: EC 46.9% (France 12.4%, Nether-
lands 11.6%, Belgium-Luxembourg 8.2%, Italy 7.9%); other
Europe 12.7%; OPEC 9.4%; Communist economic 5.9%;
US. 6.7%
Aid: —economic—U-S, $4,041 million authorized
(FY46-76); $16 million authorized (FY75): military—U.S.,
$939 million authorized (FY46-76), none since F Y64; net
official aid flows to less developed countries and multilateral
agencies (1962-74)—$9 304 million, $1,526 million (1974)
Budget: (1976) expenditures $64.2 billion, revenues $54.0
billion, deficit $10.2 billion
Monetary conversion rate: DM 2.51 (West German
marks)=US$1 (1975 average)
Fiscal year: calendar year','88b69b2fdedf28f534729b902338ea5823ba21cf40c6be651efde740b0d9c48b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('792793b8228ed777bd1cedde7487792163bbe9b52825e554b8aa153f94500541',1978,'GI','Gibraltar','economy',209,'Economic activity in Gibraltar centers on commerce and
large British naval and air bases; nearly all trade in the
well-developed port is transit trade and port serves also as
important supply depot for fuel, water, and ships’ wares;
recently built dockyards and machine shops provide
maintenance and repair services to 3,500-4,000 vessels that
call at Gibraltar each year.
U.K. military establishments and civil government employ
nearly half the insured labor force; local industry is confined
to manufacture of tobacco, roasted coffee, ice, mineral
waters, candy, beer, and canned fish; some factories for
manufacture of clothing are being developed; a small
segment of local population makes its livelihood by fishing;
in recent years tourism has increased in importance.
Electric power: 40,000 kW capacity (1976); 80 million
kWh produced (1976), 2,760 kWh per capita
Exports: $25.36 million (f.o.b., 1974-75); principally
rexports of tobacco, petroleum, and wine; 13% to UK.
Imports: $60.72 million (1974-75); 60% from U.K.
Major trade partners: U.K., Morocco, Portugal, Nether-
lands
Budget: (1974-75) revenue, $21.3 million; expenditure
$20.9 million
Monetary conversion rate: 1
US$1.8062 (1976)
GDP: $740 per capita (1974)
Agriculture: copra, subsistence crops of vegetables,
supplemented by domestic fishing
Industry: phosphate production, expected to cease in 1978
Electric power: 16,000 kw capacity (1976); 45 million
kWh produced (1976), 820 kWh per capita
Exports: $8.6 million (1970 est.); 70% phosphate, copra
{mports: $3.1 million (1970 est.); foodstuffs, fuel
Budget: (est.) revenue 5.877 million NZ$, expenditure
4.577 million NZ$
Monetary conversion rate:
March 1976
0.80 Australian$=US$1','f3bb4bc8688676c742726e8a4d3d68f7fde0f9fbece4d3c766080368f33fb6a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('192c91de708c6b1edd89562985d5d0941923afe3f0a3f1faea4bcf4697f03710',1978,'GR','Greece','economy',213,'CNP: $22.3 billion (1976 est.), $2,460 per capita; 69%
consumption, 20% investment, 15% government; 4% change
in stocks; net foreign balance —8%; real growth rate 6%
(1976); typical real growth rate averages 7.5%
Agriculture: subject to droughts; main crops—wheat,
olives, tobacco, cotton, nearly self-sufficient; food short-
ages—livestock products; caloric intake, 2,960 calories per
day per capita (1963)
Major industries: food processing, tobacco, chemicals,
textiles, petroleum refining, aluminum processing
Shortages: petroleum, minerals, feed grains
Crude steel: 899,750 metric tons produced (1976), 100 kg
per capita
Electric power: 4,636,000 kW capacity (1976); 20.4
billion kWh produced (1976), 2,250 kWh per capita
Exports: $2,258 million (f.0.b., 1976); principal items—
tobacco, cotton, fruits, textiles
Imports: $4,900 million (c.if., 1976); principal items—
machinery and automotive equipment, manufactured con-
sumer goods, petroleum and petroleum products, chemicals,
meat and live anisals
Major trade partners: (1976)—41.6% EC, 9.2% CEMA
countries, 8.0% other European countries, 16.6% U.S.
Aid: economic (authorized) —U.S., $1,910 million
(FY46-76); International Finance Corporation, $15 million
through FY73; U.N. Technical Assistance, $4.3 million
through FY72; U.N. Special Fund, $63.1 million through
1972; IBRD, $118.9 million (FY68-73), $25 million in 1972,
Consortium, $40 million in 1966; EC (FY64-72) $69.2
million; U.S.S.R. $7.7 million (1954-76); military—U.S.,
$2,984 million (FY46-73)
Budget: (1977) expenditures $6,500 million, revenues
$6,500 million
Monetary conversion rate: | drachma=US$0.027 (1976
average)
Fiscal year: calendar year','775939c980e0c6321f4ae178e3c4cf2937279a3a6d4cde724e5d6e0f30afd143','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e00ca287b10be1fca8abdbeb69acaa5874c230708630c20ebb357324c11dd42b',1978,'GL','Greenland','economy',217,'GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep grazing;
garden produce
Fishing: catch 44,638 tons (1976); exports $35.6 million
(1975)
Major industries: mining, slaughtering, fishing, sealing
Electric power: 57,500 kW capacity (1976); 117 million
kWh produced (1976), 2,290 kWh per capita
Exports: $88.6 million (f.0.b., 1975); fish and fish
products, nonmetallic minerals
Imports: $129.1 million (c.if., 1975); machinery and
transport equipment, petroleum and petroleum products,
food products
Major trade partners: (1975) Denmark 68%, Finland
7.5%, Spain 5.8%
Monetary conversion rate: 6.0450 Danish Kroner=US$1
(1976, average)
Fiscal year: 1 April-31 March','d3d3af2b8dacf47bc9a9b8cd826906cfc113836e1f598d6c181fd00e86c804ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('810d9bfbdfa66c156e6966fe6a9b2f6e8a0e3b182929a6d66e400ef7e317edb8',1978,'GD','Grenada','economy',221,'GNP: $43 million (in current prices, 1976), $440 per
capita; real growth rate 1976, 13%
Agriculture: main crops—spices, cocoa, bananas
Fishing: 1,800 metric tons (1975)
Electric power: 7,000 kW capacity (1976); 25 million
kWh produced (1976), 2830 kWh per capita
Exports: $13 million (f.o.b., 1976); nutmeg, cocoa beans,
bananas, mace
Imports: $25 million (c.i.f., 1976); food, machinery,
building materials
Major trade partners: exports—33% U.K., 19% West
Germany, 13% Netherlands; imports—27% West Indies,
27% U.K., 9% US.
Monetary conversion rate: 2.70 East Caribbean dollars=
US$1 (July 1976)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4','6b46cc4335db47fb59970e14724882150a879b5d45afd7563dbfd279a32d2dce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d66e72cd27600a2d87f8fdb5808d488448e4553d478e7bfa0430052e335aaff',1978,'GP','Guadeloupe','economy',225,'GDP: $302 million (1971), $880 per capita; real growth
rate (1971) 5.9%
Agriculture: main crops, sugarcane and bananas
Major industries: agricultural processing, sugar milling
and rum distillation
Electric power: 50,000 kW capacity (1976); 200 million
kWh produced (1976), 570 kWh per capita
Exports: $78 million (f.0.b., 1975); sugar, bananas, rum
Imports: $292 million (c.i:f., 1975); foodstuffs, clothing
and other consumer goods, raw materials and supplies, and
petroleum
Major trade partners: exports—71% France, 17% U.S.,
7% Germany, 5% other; imports—70% France, 9% U.S., 3%
Germany, 3% Netherlands Antilles, 3% Netherlands, 12%
other (1968)
Monetary conversion rate: 4.44 French francs=US$1
Fiscal year: calendar year','3927fb2b775e58ed5f32aaaf7c860001a92fdc6a9075bd71bf000f1710bcc569','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0620d526337240a1f3519a5a7f12ee98999d5a2ba799fa0436c400800df540b6',1978,'GT','Guatemala','economy',229,'GDP: $4,200 million (1976 est.), $700 per capita; 82%
private consumption, 6% government consumption, 15%
domestic investment (1975), —8% net foreign balance
(1976); average annual real growth rate (1971-76), 5.3%
Agriculture: main products—coffee, cotton, corn, beans,
sugarcane, bananas, livestock; caloric intake, 2,200 calories
per day per capita (1967)
Approved For Release 2005/04/22 :
Fishing: catch 5,000 metric tons (1975); exports $2.6
million (1978), imports $0.7 million (1973)
Major industries: food processing, textiles and clothing,
furniture, chemicals, nonmetallic minerals, metals
Electric power: 315,000 kW capacity (1976); 1.4 billion
kWh produced (1976), 230 kWh per capita
Exports: $797 million (f.0.b., 1976); coffee, cotton, sugar,
bananas, meat
Imports: $982 million (c.if., 1976); manufactured pro-
ducts, machinery, transportation equipment, chemicals,
fuels
Major trade partners: exports (1974) —34% U.S., 28%
CACM, 11% West Germany, 5% Japan; imports (1974)—
31% US., 17% CACM, 12% Venezuela, 9% Japan, 8% West','87757ed2b73ae5776f180094fb03ca511fa9c0c39f269f73110212fb9b8b2764','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbb40bd9f6beb6548eaf4da697b715263ba4fe79dee6720291e3c7213027a363',1978,'GW','Guinea-Bissau','economy',233,'GDP: $112 million (est. 1975), $230 per capita
Agriculture: main crops—palm oil, root crops, rice,
coconuts, peanuts
Electric power: 11,000 kW capacity (1976); 17 million
kWh produced (1976), 30 kWh per capita
Exports: $6.2 million (f.0.b., 1975); principally peanuts,
coconuts
Imports: $38 million (c.i.f., 1975); manufactured goods,
fuels, transport equipment, rice
Major trade partners: mostly Portugal, also immediate
neighbors
Aid: Portugal, U.S.S.R.
Monetary conversion rate: using Portuguese currency;
38.732, escudos=US$1 (June 1977)
Fiscal year: probably is the calendar year','cd39508cd29a8136132383b01e464218085800537e79494954c4f98c662a1e97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7fb4243a7600f6bc5d5edaa396a43f904f487e120a09cc90acaea6f85e88d67',1978,'HT','Haiti','economy',237,'GNP: $865 million (1975), $190 per capita; real growth
rate 1975, 2%
Agriculture: main crops—coffee, sugarcane, rice, corn,
sorghum, pulses; caloric intake, 1,850 calories per day per
capita
Major industries: sugar refining, textiles, flour milling,
cement manufacturing, bauxite mining, tourism, light
assembly industries
Electric power: 70,000 kW capacity (1976); 135 million
kWh produced (1976), 30 kWh per capita
Exports: $111 million (f.0.b., 1976); coffee, light industrial
products, bauxite, sugar, essential oils, sisal
Imports: $158 million (f.0.b., 1976); consumer durables,
foodstuffs, industrial equipment, petroleum products, con-
struction materials
Major trade partners: exports—71% U.S.; imports—53%
U.S. (1975)
Aid: economic authorizations—from U.S. (FY46-75), $46
million loans, $126 million grants; from international
organizations (FY46-76), $169 million; military authoriza-
tions—from U.S. (FY46-76), $4 million in grants
Budget: (1976) revenue, $133 million; expenditure, $146
million
Monetary conversion rate: 5 gourdes=US$1
Fiscal year: 1 October-30 September','a79955fb8532ab8c5aa66ee0b0f52d3797ca5e1d38b540d69801225c10e18d32','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a460d5fc5c46098323831e10c7e0baf28a18096b4270602e67d149443029564',1978,'HN','Honduras','economy',241,'GDP: $1,171 million (1976), $410 per capita; 79% private
consumption, 10% government consumption, 22% domestic
investment; —11% net foreign balance (1975); real growth
rate, average 1971-75, 2.6%; real growth rate 1976, 6.8%
Agriculture: main crops—bananas, coffee, corn, beans,
cotton, sugarcane, tobacco; caloric intake, 2,200 calories per
day per capita (1970)
Fishing: catch 3,262 metric tons (1975); exports est. $0.8
million (1976); imports $0.8 million (1974)
Major industries: agricultural processing, textiles, cloth-
ing, wood products
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Electric power: 175,000 kW capacity (1976); 450 million
kWh produced (1976), 160 kWh per capita
Exports: $392 million (f.0.b., 1976); bananas, lumber,
coffee, meat, petroleum products
Imports: $553 million (c.i.f. 1976); manufactured prod-
ucts, machinery, transportation equipment, chemicals,
petroleum
Major trade partners: exports—51% US., 12% CACM,
11% West germany; imports—42% U.S., 16% Venezuela,
13% CACM, 7% Japan, 3% West Germany (1975)
Aid: economic—extensions from U.S. (FY46-76), $122
million loans, $96 million grants; from international
organizations (FY46-73), $291 million; from other Western
countries (1960-73), $7.0 million; military—assistance from
U.S. (FY46-75), $20 million
Budget (1977): expenditures, $312 million
Monetary conversion rate: 2 lempiras=US$1 (official)
Fiscal year: calendar year','26877029129e129d977e02cc47356950fb6a2f758082dcea714de245d4d4dfde','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68ef6055f7b5a760598e5fa52e4ea25dc0542f6653132c7f745309c1cc341d3b',1978,'HU','Hungary','economy',247,'GNP: $25.5 billion in 1976 (at 1975 prices), $2,410 per
capita; 1976 growth rate, 1.2%
Agriculture: normally self-sufficient; main crops—corn,
wheat, potatoes, sugar beets, wine grapes; caloric intake
3,140 calories per day per capita (1970)
Major industries: mining, metallurgy, engineering indus-
tries, processed foods, textiles, chemicals (especially pharma-
ceuticals)
Shortages: metallic ores (except bauxite), copper, high
grade coal, forest products, crude oil
Crude steel: 3.65 million metric tons produced (1976),
340 kg per capita
Electric power: 4,660,000 kW capacity (1976); 22 billion
kWh produced (1976), 2,080 kWh per capita
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
HUNGARY/ICELAND
Exports: $4,929 million (f.0.b., 1976); 31% machinery,
18% industrial consumer goods, 28% raw materials and
semimanufactures, 21% food and raw materials for the food
industry, energy sources 2% (distribution for 1976)
Imports: $5,536 million (1976); 22% machinery, 9%
industrial consumer goods, 48% raw materials and semi-
manufactures; 9% food and raw materials for the food
industry, energy sources 12% (distribution for 1976)
Major trade partners: $13,371 million (1976); 66% with
Communist countries, 34% with non-Communist countries
Aid: U.S.S.R.—$338 million extended (1956-66), $10
million extended in 1967, $167 million extended in 1968; to
less developed non-Communist countries—$716 million
(1954-76)
Monetary conversion rate: 41.30 forints=US$1 (commer-
cial); 20.60 forints=US$1 (noncommercial) (1977)
Fiscal year: same as calendar year; economic data
reported for calendar years
NOTE: foreign trade figures were converted at the 1976
rate of 41.56 forints=US$1','6edd15b7910eb9f5b2cfb67df0d49f95a72acef82c3ff80b8acc43364a9c7a13','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d48d7298bc0fe0db01dd9538efd8002ad9bc360eaf1c22e41f75f65265d029f6',1978,'IS','Iceland','economy',251,'GNP: $1,403 million (1976), $6,380 per capita; 65%
consumption, 34% investment, 10% government, 2% change
in stocks; —11% net foreign balance (1975); 1976 growth
rate 1.9%, constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes, turnips;
food shortages—grains, sugar, vegetable and other fibers;
caloric intake, 2,900 calories per day per capita (1964-66)
Fishing: landed 982,100 metric tons; exports $289.9
million (1976)
Major industries: fish processing, aluminum smelting,
diatomite production, hydro-electricity
Shortages: grain, fuel, wood, minerals, vegetable fibers
Electric power: 493,000 kW capacity (1976); 2.5 billion
kWh produced (1976), 11,740 kWh per capita
Exports: $409 million (f.0.b., 1976); fish and fish products,
animal products, aluminum, diatomite
Imports: $470 million (c.i.f., 1976); machinery and
transportation equipment, petroleum, foodstuffs, textiles
Major trade partners: (1975) exports—U.S. 29%, EC 25%,
USS.R. 11%; imports—EC 45%, US. 9%, USSR. 10%
Aid: economic—U-S. authorized (1949-76) $82 million,
$0.8 million in FY72, $0.9 million in FY73; IBRD $30
million through September 1973
Budget: (1975) expenditures $315 million, revenues $292
million
Monetary conversion rate: 182.2 kronur=US$1 (1976);
153.7 kronur=US$1 (1975)
Fiscal year: calendar year','6dba6774e27c5c82edaca33987927186cc036b3c218c79962d1b20d61f85c679','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88b34c66cd2a3d16b0cc1e447945462ba214fe2bc9a0095aa27deca520e712a0',1978,'IN','India','economy',254,'GNP: $82.8 billion (FY76 at 1976 prices), $130 per capita;
real growth 2.0% in 1977, 8.5% in FY76
Agriculture: main crops—rice, other cereals, pulses,
oilseeds, cotton, jute, sugarcane, tobacco, tea, and coffee;
must import foodgrains; caloric intake is low and diet is
deficient in protein
Fishing: catch 2.3 million metric tons (1975); exports
$95.1 million (1974), imports $3.1 million (1974)
Major industries: textiles, food processing, steel, machin-
ery, transportation equipment, cement, jute manufactures
Crude steel: 9.2 million metric tons on ingots (1976)
Electric power: 22,700,000 kW capacity (1976); 93.5
billion kWh produced (1976), 150 kWh per capita
Exports: $5.5 billion (f.0.b., FY77); engineering goods,
textiles and clothing, tea
Imports: $5.6 billion (c.if., FY77); machinery and
transport equipment, petroleum, grains and flour, fertilizers
Major trade partners: U.S., U.K., U.S.S.R. and Eastern
Europe, Japan, Iran
Budget: (FY78) revenue expenditures $10.9 billion,
capital expenditures $6.9 billion
Monetary conversion rate: 8.7 rupees=US$1 (July 1977)
Fiscal year: fiscal year ends 31 March of stated year','908943b82e6ab3eb6872ee822325c5c44bafd5de9e43a8c9f4780321a0a521e2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eca242ef0501d3b1daf3e271b984b1821c07f6471655b114e4f188e72767e791',1978,'IQ','Iraq','economy',259,'GNP: $16 billion (1976 est.), $1,400 per capita
Agriculture: dates, wheat, barley, rice, livestock
Major industry: crude petroleum (third largest producer
in Middle East); 2.3 million b/d (1976); petroleum revenues
for 1976, $8.9 billion
Electric power: 1,564,000 kW capacity (1976); 4.5 billion
kWh produced (1976), 400 kWh per capita
Exports: $9.1 billion (f.0.b., 1976 est.); net receipts from
oil, $8.8 billion; non-oil, $300 million est.
Imports; $6.5 billion (f.0.b., 1976); 26% from Communist
countries (1973)
Major trade partners: exports—U.S. 2%, Italy 22%,
France 19%, Netherlands 6%, U.K. 4%; imports—U.S. 5.6%,
U.K. 8.5%, US.S.R. 8.8%, France 8.4%, Japan 6.7%, Brazil
5.9%, Czechoslovakia 5.5% (1973)
Budget: $9 billion (FY77), actual estimated
Monetary conversion rate: | Iraqi dinar=US$$3.37 (end
of December 1976}
Fiscal year: | January-31 December','f2e8ac713bdb3daead349bebb9bc47444490f6b5fe2fc13c63a478f906b841bb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78c18f03491f184094a81e9b1ea7a9723bab70e92e893118b924a92a7b93582a',1978,'IE','Ireland','economy',263,'GNP: $8.1 billion (1976 at 1976 prices), $2,590 per capita,
63.6% consumption, 24.0% investment, 19.1% government,
0.8% inventories; —7.5% net export of goods and services;
1970-76 (inclusive) real growth rate, average 2.9%
101
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
IRELAND/ISRAEL
Agriculture: 70% of agricultural area used for permanent
hay and pasture; main products—livestock and dairy
products, turnips, barley, potatoes, sugar beets, wheat; 85%
self-sufficient, food shortages—grains, fruits, vegetables;
caloric intake 3,510 calories per day per capita (1970)
Fishing: catch 80,676 metric tons (1976); exports of fish
and fish products $37.3 million (1976), imports of fish and
fish products $15.7 million (1976)
Major industries: food products, brewing, textiles and
clothing, machinery and transportation equipment
Shortages: coal, petroleum, timber and woodpulp, steel
and nonferrous metals, fertilizers, cereals and animal feeds,
textile fibers and textiles
Crude steel: 85,000 metric tons produced in 1975, 30 kg
per capita
Electric power: 2,387,000 kW capacity (1976); 9 billion
kWh produced (1976), 2,930 kWh per capita
Exports: $3,354.5 million (f.0.b., 1976); live animals, meat,
dairy products, machinery, clothing, chemicals
Imports: $4,212.4 million (c.if., 1976); petroleum and
petrol products, chemicals, machinery, cereals
Major trade partners: U.K., 49.2% of total (1976)
Aid: economic—U.S., $146 million authorized (F Y49-76):
IBRD, $122 million authorized (FY64-75); EC Common
Borrowing Facility, $300 million
Budget: (1977 projected) 2,037 million pounds expendi-
tures, 1,799 million pounds revenues, 237 million pounds
deficit, public sector borrowing requirement 593 million
pounds
Monetary conversion rate: | Trish pound=US$1.8061
(1976)
Fiscal year: calendar year','3a1a8caf6e6f0cc1914ab8a40733e1fe0ecade36dc3b443c12a1754a49b91576','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51112cdaeba34010fa197456c34df3fae6aea7f34d06b1b34f2c158f1d406814',1978,'IL','Israel','economy',267,'GNP: $11.8 billion (1976, in 1976 prices), $3,370 per
capita (converted to dollars at 8.05 Israeli pounds=US$1);
1976 growth of real GNP — 1.0%
Agriculture: main products—citrus and other fruits,
vegetables, beef and dairy products, poultry products
Major industries: food processing, diamond cutting and
polishing, textiles and clothing, chemicals, metal products,
transport equipment, electrical equipment, miscellaneous
machinery, rubber and _ plastic products, potash mining
Electric power: 2,200,000 kW capacity (1976); 11 billion
kWh_ produced (1976), 3,140 kWh per capita
Exports: $2.4 billion (f.0.b., 1976); major items—polished
diamonds, citrus and other fruits, textiles and clothing,
processed foods, fertilizer and chemical products; tourism 1s
leading foreign exchange earner
Imports: $5.7 billion (c.i.f., 1976); major items—rough
diamonds, chemicals, machinery, iron and steel, cereals,
textiles, vehicles, ships, and aircraft
Major trade partners: exports—EC, US., U.K., Japan,
Hong Kong, Switzerland; imports—EC, U.S., U.K., Switzer-
land, Japan
Budget: FY ending 31 March 1977—$12 billion (con-
verted at 7.1 Israeli pounds=US$1)
Monetary conversion rate: the Israeli pound was allowed
to float on 31 October 1977 and as of 3 November 1977 it
was roughly 15. Israeli pounds=US$1
Fiscal year: 1 April-31 March
GDP: $171 billion (1976), $3,040 per capita; 65.5%
private consumption, 20.2% gross fixed investment, 138.9%
government, 3.2% inventory change, net foreign balance
— 2.8%; 1973 growth rate 6.3%, 1974 growth rate 3.4%, 1976
growth rate 5.6% (1970 constant prices)
Agriculture: important producer of fruits and vegetables;
main crops—cereals, potatoes, olives; 95% self-sufficient;
food shortages—fats, meat, fish, and eggs; daily caloric
intake, 3,335 calories per capita (1974)
Fishing: catch 376,509 metric tons (1975), $336 million
(1973); exports $46 million (1976), imports $352 million
(1976)
Major industries: machinery and transportation equip-
ment, iron and steel, chemicals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 23.3 million metric tons produced (1976),
418 kg per capita
Electric power: 51,223,000 kW capacity (1976); 163
billion kWh produced (1976), 2,865 kWh per capita
Exports: $37.0 billion (f.0.b., 1976); principal items—
machinery and transport equipment, textiles, foodstuffs,
chemicals, footwear
Imports: $43.4 billion (c.if., 1976); principal items—
machinery and transport equipment, foodstuffs, ferrous and
nonferrous metals, wool, cotton, petroleum
Major trade partners: (1976) 45.5% EC-nine (18% West
Germany, 14% France, 4% Netherlands, 4% U.K., 3%
Belgium-Luxembourg); 7% U.S.; 8% U.S.S.R. and 3% other
Communist countries of Eastern Europe
Aid: economic—U.S., $3,306 million (FY46-76), $78.2
million authorized FY73; IBRD, $398 million authorized
through FY75, none since FY65; International Finance
Corporation, $1 million authorized through FY75, none
since FY60; military—U.S., $2,545 million (FY46-76), $11.6
million authorized in FY73
Monetary conversion rate: Smithsonian rate as of
December 1973, 650.4 lira=US$1; average of Friday closing
rates in 1976—832 lira=US$1
Fiscal year: calendar year','9c37825551854fa89fe8543ea9b059fd687aa7ec6ea26290c0b6f6360ad9286c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67ade60906dae3e2e82ce6a45be836fcc834fe6762e2de02c59da3a833b38495',1978,'JP','Japan','economy',271,'GNP: $555 billion (1976, at 296.5 yen=US$1); $4,920 per
capita (1976); 57% personal consumption, 32% investment,
11% government current expenditure; real growth rate 6.0%
(1976); average annual growth rate (1974-76), 2.4%
Agriculture: land intensively cultivated—rice, sugar,
vegetables, fruits; 72% self-sufficient in food (1974); food
shortages—ieat, wheat, feed grains, edible oil and fats;
caloric intake, 2,502 calories per day per capita (1974)
Fishing: catch 10.5 million metric tons (1975)
Major industries: metallurgical and engineering indus-
tries, electrical and electronic industries, textiles, chemicals
Shortages: fossil fuels, most industrial raw materials
Crude steel: 107 million metric tons produced (1976)
Electric power: 118,000,000 kW capacity (1976); 504.5
billion kWh produced (1976), 4,470 kWh per capita
Exports: $67.3 billion (f.0.b., 1976); 52% machinery and
equipment, 22% metals and metal products, 7% textiles
Imports: $64.9 billion (f.0.b., 1976); 44% fossil fuels, 8%
metals and metal products, 17% foodstuffs, 5% machinery
and equipment
Major trade partners: exports—23% U.S., 14% OPEC, 7%
Communist countries, 11% EC, 4% Australia, 41% other;
imports—34% OPEC, 18% U.S., 7% Australia, 6% EC, 4%
Communist countries, 31% other (1976)
Aid: Japanese official foreign economic aid disbursements
1975, $1,148 million
Budget: revenues $71.5 billion, expenditures $101.8
billion, deficit $30.3 billion (general account for fiscal year
ending March 1978)
Monetary conversion rate: 296.5 yen=US$1 (1976
average rate), floating since February 1973
Fiseal year: 1 April-31 March
Budget: 1977 official plan—revenues $4.4 billion (includ-
ing Arab aid payments), expenditures $4.4 billion
Monetary conversion rate: 3.95 Syrian pounds=US$]
Fiscal year:. calendar year
Mainland:
GDP: $2,300 million at current prices (1975), about $150
per capita; real growth rate, 4% (1970-75)
Agriculture: main crops—cotton, coffee, sisal on main-
land; imports food grains
Fishing: catch 180,746 metric tons (1975); exports valued
at $638,000, imports $1.1 million (1975)
Major industries: primarily agricultural processing
(sugar, beer, cigarettes, sisal twine), diamond mine, oil
refinery, shoes, cement, textiles, wood products
Electric power: 365,000 kW capacity (1976); 913 million
kWh produced (1976), 60 kWh per capita
Exports: $468 million (f.0.b., 1977 projected); coffee,
cotton, sisal, cashew nuts, meat, diamonds, cloves, tobacco,
tea
Imports: $795.6 million (c.if., 1977 projected); manufac-
tured goods, machinery and transport equipment, cotton
piece goods, crude oil, foodstuffs
Major trade partners: exports—China, U.K., Hong Kong,
India, Kenya, U.S.; imports—U.K., China, Kenya, West
Germany, U.S., Japan
Aid: about $160 million in aid was committed in 1976
from EC, China, IMF, U.S.; China has extended $362
million in aid since 1964, primarily for Tan-Zum Railway
Budget: (1977 est.) receipts including grants, $655 million,
expenditures, $833 million
Monetary conversion rate: 8.4 Tanzanian shillings=US$1
Fiscal year: 1 July-30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops—cloves, coconuts
Industries: agricultural processing
Electric power: see Tanzania (above)
Exports: $12.6 million (1968); cloves and clove products,
coconut products
Imports: $5.6 million (1968); mainly foodstuffs and
consumer goods
Major trade partners: imports—China, Japan, and
mainland Tanzania; exports—Singapore, China, Hong Kong,
Indonesia, India, Pakistan
Aid: U.K. principal source of aid until 1964; U.S. $86
million FY58-73; China is currently major source
Exchange rate: 8.4 Tanzanian shillings=US$1
Fiscal year: 1 July-30 June','f7a90556c3e44c56b2542dee89bccd09928e9574cb63088fc81defb061b38123','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcc718cdf7cf63a9aa42bb2ef9ff991677b35cd1f929a60fae63b484160225be',1978,'JO','Jordan','economy',275,'GNP: $1.6 billion (East Bank only), $760 per capita; real
growth rate (1973-76), 14%
Agriculture: main crops—wheat, fruits, vegetables, olive
oil; not self-sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining,
and cement production, light manufacturing
Electric power: 200,000 kW capacity (1976); 500 million
kWh produced (1976), 180 kWh per capita, East Bank only
Exports: $208 million (f.0.b., 1976); fruits and vegetables,
phosphate rock; Communist share 11% of total (1976)
Imports: $1,027 million (c.if., 1976); petroleum products,
textiles, capital goods, motor vehicles, foodstuffs; Communist
share 7% of total (1976)
Aid: economic—U.S., $1,048 million economic assistance
(FY46-76), of which $16 million loans, $932 million grants;
military—$552 million total from U.S. (FY53-76) including
$324 million in MAP grants
Budget: (1977 est.)—expenditures $1,005 million (non-
military, $800 million, military $205 million), development
$412 million; deficit $45 million
Monetary conversion rate: | Jordanian dinar=US$3.03,
freely convertible; 0.3300 Jordanian dinar=US$1
Fiscal year: calendar year','a4e67114c8ac7725e4674af0f91e97a0c8cbed556065215f9a4dd96510a040d8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('506874cbba3e93589f990ae6ece8269d0b56113b62b0fc3d247a8f1c27a644e7',1978,'KE','Kenya','economy',279,'GDP: $3,200 million at current prices (est. 1976), $225 per
capita; 5% real growth 1970-76
Agriculture: main cash crops—coffee, sisal, tea, pyre-
thrum, cotton, livestock; food crops—corn, wheat, rice,
cassava; largely self-sufficient in food
Fishing: 33,800 metric tons (1975)
Major industries: small-scale consumer goods (plastic,
furniture, batteries, textiles, soap, agricultural processing,
cigarettes, flour), oil refining, cement
Electric power: 315,000 kW capacity (1976); 1.0 billion
kWh produced (1976), 70 kWh per capita
Exports: $720 million (f.0.b., 1976 est.); coffee, tea,
livestock products, pyrethrum, soda ash, wattle-bark tanning
extract
Imports: $974 million (cif. 1976 est.); machinery,
transport equipment, crude oil, paper and paper products,
iron and steel products, and textiles
Major trade partners: U.K. and EC, Uganda, Tanzania
111
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
KENYA/KOREA, NORTH
Budget: FY77 current revenues $780 million; current
expenditures $680 million; development expenditures $295
million
Monetary conversion rate: 8.4 Kenya shillings=US$1
Fiscal year: 1 July-30 June
GNP: $9.6 billion (1976 est.), $560 per capita
Agriculture: main crops—corn, rice, vegetables; food
shortages—meat, cooking oils; production of foodstuffs
adequate for domestic needs at low levels of consumption
Major industries: machine building, electric power,
chemicals, mining, metallurgy, textiles, food processing
Shortages: complex machinery and equipment, coking
coal, petroleum
Crude steel: 2.8 million metric tons produced (1976), 106
kg per capita
ne Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
KOREA, NORTH/KOREA, SOUTH
Electric power: 3,900,000 kW capacity (1976); 21 billion
kWh produced (1976), 1,200 kWh per capita
Exports: $560 million; minerals, chemical and metallurgi-
cal products (est. 1976)
Imports: $815 million; machinery and equipment, petro-
leum, foodstuffs, coking coal (1976)
Major trade partners: total trade turnover $1.4 billion;
40% with non-Communist countries, 60% with Communist
countries (1976 est.)
Aid: economic and military aid from the U.S.S.R. and
Aid: external aid amounted to $52 million in 1974 with
Belgium providing about 30% of this amount, the European
Development Fund 15%, and World Bank about 15%; other
donors include France, Canada, Germany, U.S., Yugoslavia,
Kuwait, Abu Dhabi, and PRC
Budget: revenues $71 million; expenditures $53.8 million
(1976 provisional)
Monetary conversion rate: 92.84 Rwanda francs=US$1
(official) since January 1974
Fiscal year: calendar year
GDP: $14.7 million (1970), $210 per capita
Agriculture: main crops—sugar on St. Christopher, cotton
on Nevis
Major industries: sugar processing, salt extraction
Electric power: 15,000 kW capacity (1976); 32 million
kWh produced (1976), 460 kWh per capita
Exports: $6.8 million (f.o.b., 1973); sugar, molasses,
cotton, salt, copra
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ST. CHRISTOPHER-NEVIS-ANGUILLA/ST.LUCIA
Imports: $12.0 million (c.i.f., 1973); foodstuffs, fuel,
manufactures
Major trade partners: exports—50% U.S., 35% U.K.;
imports—21% U.K., 17% Japan, 11% USS. (1978)
Monetary conversion rate: 2.70 Fast Caribbean dol-
lars=US$1 (July 1976)
CDP: $33.2 million (1973 est.), $300 per capita; real
growth rate 1973, negligible
Agriculture: main crops—bananas, copra, sugar, cocoa,
spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 14,000 kW capacity (1976); 40 million
kWh produced (1976), 360 kWh per capita
Exports: $17 million (f.o.b., 1975); sugar, bananas, cocoa
Imports: $49 million (c.i-f,, 1975); foodstuffs, machinery
and equipment, fertilizers, petroleum products
Major trade partners: 51% U.K., 9% Canada, 17% U.S.
(1970)
Monetary conversion ‘rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)
GDP: §20 million (1971 est.), $200 per capita; 6.9%
growth in 1971
Agriculture: main crops—bananas, arrowroot, coconut
Major industries: food processing
Electric power: 6,500 kW capacity (1976); 18 million
kWh produced (1976), 190 kWh per capita
Exports: $4.7 million (f.0.b., 1973); bananas, arrowroot,
copra
Imports: $18.6 million (c.i.f., 1973); fertilizer, flour,
transportation equipment, lumber, textiles
Major trade partners: exports—61% U.K., 80% CARI-
COM, 9% U.S.; imports—29% CARICOM, 28% U.K., 9%
Canada, 9% U.S. (1972)
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)','0bab7977112a089dd7cf1d33d02fd3db9a0808dd1e8e3722d2785ec260e8e97f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cff5978910b54d29770a7324f4e5fdbd412423fe33a62d2a0093a1bfd9456f06',1978,'KW','Kuwait','economy',283,'GNP: $13.9 billion (1976), $13,080 per capita est.
Agriculture: virtually none, dependent on imports for
food; approx. 75% of potable water must be distilled or
imported
Major industries: crude petroleum production average
for 1976, 2.15 million b/d including Neutral Zone, first
quarter 1977, 1.6 million b/d excluding Neutral Zone;
government revenues from taxes and royalties on produc-
tion, refining, and consumption, $8.5 billion, preliminary
est. for 1976; refinery production 90,720,273 bbls (1974),
average b/d refinery throughput equals 248,550 bbls; other
major industries include processing of fertilizers, chemicals;
building materials; flour, and fishing
Electric power: 1,500,000 kW capacity (1976); 4.5 billion
kWh produced (1976), 4,230 kWh per capita
Exports: $9.7 billion (1976 est.), of which petroleum
accounted for about 98%; nonpetroleum exports are mostly
reexports, $727 million (1976 est.)
Imports: $3.18 billion (1976 est.); major suppliers—U.S.,
Japan, U.K., West Germany
Aid: an aid donor, committed bilaterally or through
multilateral agencies nearly $3 billion in economic assistance
in 1975
Budget: (FY76/77) $7.6 billion revenues; State reserves,
$10 billion (1975)
Monetary conversion rate: 1 Kuwaiti dinar = US$3.48
(1976)
Fiscal year: 1 July-30 June
GNP: $220 million, $70 per capita (1972 est.)
Agriculture: main crops—rice (overwhelmingly domi-
nant), corn, vegetables; formerly self-sufficient; food short-
ages (due in part to distribution deficiencies), including rice
Major industries: tin mining, timber, tobacco, textiles,
electric power
Shortages: capital equipment, petroleum, transportation
system, trained personnel
Electric power: 61,000 kW capacity (1976); 270 million
kWh produced (1976), 80 kWh per capita
Exports: $3 million (f.0.b., 1976 est.); electric power,
forest products, tin concentrates; coffee, undeclared exports
of opium and_ tobacco
Imports: $20 million (c.if., est. 1976); rice and other
foodstuffs, petroleum products, machinery, transportation
equipment
Major trade partners: imports from Thailand, U.S.S.R.,
Japan, France, China, Vietnam; exports to Thailand and
Malaysia; trade with Communist countries insignificant;
Laos was once a major transit point in world gold trade,
value of 1973 gold reexports $55 million
Aid: economic—(1975) $26 million of which $25 million,
US.; 1976, U.S.S.R. ($66 million committed), China ($42
million committed); small amounts from Vietnam, France,
Japan, and international agencies
Budget: (1973-74) receipts, 13.3 billion kip; expenditures,
36.0 billion kip; deficit 22.7 billion kip (provisional totals).
45% military, 55% civilian; no data available since
Communists fully took over government in 1975
Monetary conversion rate: as of September 1977, 200
kip=US$1 (selling), 396-495 kip=US$1 (buying) (official)
2,000 liberation kip=US$1 (free market)
Fiscal year: 1 July-30 June','6cc091356694b62fef23450c663d397b37956bbdf8e9439def57aa8fc978e854','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eb93aec0ca38ef860040c8ba9cdfec305400b41fdf966f8140054c988a4d193',1978,'LB','Lebanon','economy',287,'Agriculture: fruits, wheat, corn, barley, potatoes, tobacco,
olives, onions; not self-sufficient in food
Major industries: service industries, food processing,
textiles, cement, oil refining, chemicals, some metal fabricat-
ing, tourism
Electric power: 540,000 kW capacity (1976); 1 billion
kWh produced (1976), 400 kWh per capita
Major trade partners: exports $0.2 billion est. (f.0.b.,
1976); most to Arab countries; imports $0.6 billion est. (c.i.f.,
1976); prior to the Civil War, chiefly from EC, U.K., and
Arab countries; trade deficit covered by large net receipts
from invisibles (particularly tourism and transportation) and
private capital inflow
Budget: (1977) expenditures $415 million, revenues $327
million est.
Monetary conversion rate: 3.127 Lebanese pounds=
US$1 as of August 1977
Fiscal year: calendar year','77cb8356c1838f2037916d387abadc09734ba5b6063b5a0fdaff75351edeb6b3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21a62f6ad8dbc8528369233ceac60e07d78370986dd8dbb09e40baa8cec323fe',1978,'LS','Lesotho','economy',291,'GNP: $196 million (FY72 est.), $200 per capita; growth
rate (in current prices), 13% annually (FY70-72 est.)
Agriculture: exceedingly primitive, mostly subsistence
farming and livestock; principal crops are corn, wheat,
pulses, sorghum, barley
Major industries: none
Electric power: approximately 20 million kWh imported
from South Africa (1976)
Exports: labor to South Africa (remittances $90 million
est. in 1975); $12.6 million (est. f.0.b., 1975), wool, mohair,
wheat, cattle, diamonds, peas, beans, corn, hides, skins
Imports: $95 million (est. c.if., 1975); mainly corn,
building materials, clothing, vehicles, machinery, POL
Major trade partner: South Africa
Aid: economic aid—U.K. $9.4 million (plan FY71-75);
other $17.5 million (plan FY71-75); U.S. $30.2 million
authorized (FY61-76); no military aid
Budget: (FY76) revenues, $63 million; current expendi-
tures, $38 million; development budget, $25 million
Monetary conversion rate: Lesotho uses the South
African rand; 1 SA rand=US$1.15 (as of October 1977)
Fiscal year: 1 April-31 March','8a204b20b5e6c6cd104feaad6765eb78e90d39dd2a34fd704a4f976e68d185a1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24af9fea6728717e7e80cf93d4698b48c93f7c57ac35154ae723cc5777a95e24',1978,'LR','Liberia','economy',295,'GDP: $867 million (1976 est.), $570 per capita; 2.4%
current annual growth rate (1972-76)
Agriculture: rubber, rice, oil palm, cassava, coffee, cocoa;
imports of rice, wheat, and live cattle and beef are necessary
for basic diet
Fishing: catch 23,000 metric tons
Industry: rubber processing, food processing, construction
materials, furniture, palm oil processing, mining (iron ore,
diamonds), 10,000 b/d oil refinery
Electric power: 300,000 kW capacity (1976); 880 million
kWh produced (1976), 580 kWh per capita
Exports: $469 million (£.0.b., 1976 est.); iron ore, rubber,
diamonds, lumber and logs, coffee, cocoa
Imports: $337 million (cif, 1976 est.); machinery,
transportation equipment, petroleum products, manufac-
tured goods, foodstuffs
Major trade partners: U.S., West Germany, Netherlands,
Italy, Belgium
Aid: economic—(FY46-75) U.S., $240.2 million; mili-
tary—(FY53-75) U.S., $15.7 million; other aid ($73.1 million
through FY75), sources include IBRD, U.N., IMF, West
Germany, Republic of China
Budget: (FY77) revenues $167 million, expenditures $167
million; development budget $39 million
Monetary conversion rate: Liberia uses U.S. currency
Fiscal year: 1 July - 30 June','07de3381639418071dff9e958e5a97123139dcdb45c2d8fbaf776b418f9be257','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a90db9382085ed7fe9a8d50a89dfe0628db45515e4c81022b1e6f287a003ce29',1978,'LY','Libya','economy',299,'GNP: $14 billion (1976), at current prices
Agriculture: main crops—wheat, barley, olives, dates,
citrus fruits, peanuts; approaching self-sufficiency in food
Major industries: petroleum, food processing, textiles,
handicrafts
Electric power: 1,135,000 kW capacity (1976); 1.9 billion
kWh produced (1976), 750 kWh per capita
Exports: $9 billion (f.0.b., 1976); over 99% petroleum
Imports: $7.3 billion (c.i.f., 1976)
Major trade partners: imports—Italy, West Germany,
U.S.; exports—Italy, West Germany, U.K., U.S., France
Aid: economic—no Communist country assistance; U.S.
aid extended $212.5 million (FY49-76); international organi-
zations $22 million; military—arms obtained by cash
purchase; chief suppliers France, U.S.S.R., Czechoslovakia;
U.S. suspended since September 1970
Monetary conversion rate: 1 Libyan pound=US$3.38
Fiscal year: 1 January - 31 December (beginning 1974)','747b2243ecc166411a8e4fd54473b025f929b8931a4ddd9eea0cf9dd184747fc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0459f3f3d83e37242aab248478c06fdc836cd367f2a7279cce1814bc22927387',1978,'LI','Liechtenstein','economy',303,'Liechtenstein has a prosperous economy based primarily
on small-scale light industry and some farming. Textiles,
ceramics, precision instruments, pharmaceuticals, and
canned foods are the principal manufactures, intended
almost entirely for export. Industry accounts for 95 percent
of total employment. Livestock raising and dairying are the
main sources of income in the small farm sector. A major
source of income to the government is the sale of postage
stamps to foreign collectors, estimated at $6 million
annually. In addition, low business taxes and easy incorpo-
rated rules have induced between 20,000 and 30,000 holding
companies, so-called letter box companies, to establish
nominal offices in the principality. The average tax paid by
one of these companies is about $400 a year.
The Liechtenstein economy is tied closely to that of
Switzerland in a customs union. No national accounts data
are available.
GNP: $264 million (1976 provisional)
Major trade partners: exports (1972)—$154.7 million;
44% Switzerland, 31% EC, 51% EFTA
Electric power: 23,000 kW capacity (1976); 56 million
kWh produced (1976), 2,040 kWh per capita; power is
exchanged with Switzerland, but net exports average 35
million kWh yearly
Budget: (1976) revenues $93.2 million, expenditures $96.2
million, deficit $3.0 million','670d5be9fe3c384b528bf489be97f7b964b7bd795941ba6bc9f74b4f0614560c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ad66ab4315e675f2144eb7c25854573a31c610f847479097deebe5058f7d5fd',1978,'LU','Luxembourg','economy',308,'GNP: $2.3 billion, $6,390 per capita (1976); average
annual real GNP growth 2.7% (1971-76); 61% private
consumption, 15% public consumption, 27% investment;
—10% net exports, +7% change in stocks
Agriculture: mixed farming; main crops—grains, pota-
toes, fodder beets; food shortages—sugar, bread grains, fats;
caloric intake, 3,150 calories per day per capita (1968-69)
Major industries: iron and_ steel, food processing,
chemicals, metal products and engineering, tires
Crude steel: 4.6 million metric tons produced (1976), 12.8
metric tons per capita
Electric power: 1,350,000 kW capacity (1976), 1,548
million kWh produced (1976), 4,480 kWh per capita
123
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
LUXEMBOURG/MACAO
Exports: see Belgium
Imports: see Belgium
Major trade partners: Luxembourg and Belgium form an
economic and customs union and report their foreign trade
jointly (see Belgium); Luxembourg’s principal exports are
iron and steel products; principal imports are coal and
consumer products; most foreign trade is with Germany,
Belgium, and other EC countries
Aid: foreign aid to Luxembourg is included in aid to
Fiscal year: calendar year','7b2e3eb62009eda8257043a420b11dda2ed5e34ad862e11ee76fd446bf9bf6f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96014210d3a5707afa4248dc4a91ac0e353376fa0750982e4e3143891c91671a',1978,'MW','Malawi','economy',316,'GDP: $760 million (1976 est., in current prices), $150 per
capita; real growth rate 5.5% (1973-75)
Agriculture: cash crops—tobacco, tea, sugar, peanuts,
cotton, tung, maize; subsistence crops—corn, sorghum,
millet, pulses, root crops, fruit, vegetables, rice
Electric power: 85,000 kW capacity (1976); 263 million
kWh produced (1976), 50 kWh per capita
Major industries: agricultural processing (tea, tobacco,
sugar), sawmilling, cement, consumer goods
Exports: $160 million (f.0.b., 1976); tobacco, tea, sugar,
peanuts, cotton
Imports: $224 million (c.i.f., 1976); manufactured goods,
machinery and transport equipment, building and construc-
tion materials, fuel, fertilizer
Major trade partners: exports—U.K., other EC, Rhodesia,
South Africa; imports—South Africa, U.K., Rhodesia, other
EC
Aid: economic—U.K. provides major development sup-
port, about $144 million (1964-74); U.S. aid commitments,
$31.6 million (FY56-76); military—U.K., $2.4 million
(1954-68)
Budget: FY75/76 revenues $165 million; expenditures
$168 million
Monetary conversion rate: 1 Malawi kwacha=US$1.09
Fiscal year: 1 April - 31 March','1cfe6bae80620f609fc6274b876bbf401116057f50b4cd1c68f7ae3002107757','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0efb67d0a3468fa00ff647e2eeeea5c1c163e10db52c1993ff827c74074445a5',1978,'MY','Malaysia','economy',320,'GNP:
Malaysia: $10.9 billion (1976), $880 per capita; average
annual real growth (1970-76), 7.8%; (1976), 11.3%
Agriculture:
Peninsular Malaysia: natural rubber, rice, oil palm;
10%-15% of rice requirements imported
Sabah: mainly subsistence; main crops—rubber, tim-
ber, coconut, rice; food deficit—rice
Sarawak: main crops—rubber, timber, pepper; food
deficit—rice
Fishing: catch 376,690 metric tons (1975)
Major industries:
Peninsular Malaysia: rubber and oil palm processing
and manufacturing, light manufacturing industry, elec-
tronics, tin mining and smelting, logging and processing
timber
Sabah: logging, petroleum production
Sarawak: agriculture processing, petroleum production
and refining, logging
Electric power:
Peninsular Malaysia: 1,475,000 kW capacity (1976);
5.9 billion kWh produced (1976), 570 kWh per capita
Sabah: 108,000 kW capacity (1976); 290 million kWh
produced (1976), 330 kWh per capita
Sarawak: 91,000 kW capacity (1976); 215 million kWh
produced (1976), 180 kWh per capita
Exports: $5.3 billion (f.0.b., 1976); natural rubber, palm
oil, tin, timber, petroleum
Imports: $4.0 billion (c.if., 1976)
Major trade partners: exports—20% Singapore, 16% US.,
20% Japan; imports—21% Japan, 9% U.K., 10% U.S., 8%','767763659e559918fb92ba161326ae85307af6e0365f7f2cecd5bd41942054b9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16289e559eaf530a965faafaacf8394f69cc49f0f7f85d2f9c64617dbe5d87a8',1978,'SG','Singapore','economy',321,'Aid: economic—U.K. (1946-69) $260 million disbursed;
Japan (1966-68) $50 million extended; IBRD (1959-July
1974) $500 million (committed); U.S. (1954-76) $78.5
million; military—(FY62-76) $81 million committed
129
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MALAYSTIA/MALDIVES
Budget: 1977 revenues $2.6 billion; expenditures $3.2
billion; deficit $800 million; 20% military, 80% civilian
Monetary conversion rate: (Malaysia) 2.46 ringgits=
US$1 (August 1977)
Viscal year: calendar year
GNP: $5.84 billion (1976), $2,560 per capita; 10.7%
average annual real growth (1966-76), 7.0% (1976)
Agriculture: occupies a position of minor importance in
the economy, self-sufficient in pork, poultry, and eggs, must
import much of its other food requirements; major crops—
rubber, copra, fruit and vegetables
Fishing: catch 17,560 metric tons (1975), imports—
137,700 metric tons (1975)
Major industries: petroleum refining, oil drilling equip-
ment, rubber processing and rubber products, processed
food and beverages, electronics, ship repair, entrepot trade,
financial services
Electric power: 1,390,000 kW capacity (1976); 4.6 billion
kWh produced (1976), 2,000 kWh per capita
Exports: $6.6 billion (f.0.b., 1976); 40% reexports;
petroleum products, rubber, manufactured goods
Imports: $9.1 billion (c.i.f., 1976); 18% goods reexported;
major retained imports—capital equipment, manufactured
goods, petroleum
Major trade partners: exports—Malaysia, U.S., Japan,
U.K., Indonesia; imports—Japan, Malaysia, US., U.K.
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SINGAPORE/SOMALIA
Aid: U.K.—(1960-September 1969) $254 million dis-
bursed, (1969-73) $120 million extended; IBRD—(1963-74)
$143 million committed, $61 million disbursed; U.S.—
(FY53-76) $23.6 million committed
Budget: (FY77/78) revenues $1.4 billion, expenditures
$2.2 billion, deficit $800 million, 15% military, 859% civilian
Monetary conversion rate: 2.45 Singapore dollars=US$1
(August 1977)
Fiscal year: 1 April-31 March','3da5a264f4651b55508d4d80d7ac6e22902461c9a79a4bd81956b54ed7100b4d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36ca8534c43515e79ffa4588d89b1090774a5cec94ae605e0901d3e7d22e972d',1978,'MV','Maldives','economy',326,'GNP: under $100 per capita
Agriculture: crops—coconut and millet; shortages—rice,
wheat
Fishing: catch 27,900 metric tons (1975)
Major industries: fishing; some coconut processing
Electric power: 4,000 kW capacity (1976); 6 million kWh
produced (1976), 50 kWh per capita
Exports: $2 million (f.o.b. 1973); fish
Imports: $3 million (c.i.f., 1973)
Major trade partners: Sri Lanka, Japan
Aid: U.K. (1960-65), $1.4 million drawn; Sri Lanka (1967),
$1 million committed; Kuwait $5 million; other OPEC
countries, Japan and India (amounts not known)
Fiscal year: calendar year','3185c3b4725625bfbce710a6edbecb622f3a8e2c099746cd4c1ebbdfce81a7ed','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fba13eeb3e685a53a115503912f7c143e209496827b52c14490861fdb849465c',1978,'ML','Mali','economy',330,'GDP: about $590 million (1976), $100 per capita; annual
real growth rate 5.8% (1973-76)
Agriculture: main crops—amillet, sorghum, rice, corn,
peanuts; cash crops—peanuts, cotton, livestock
Fishing: catch 100,000 metric tons (1975)
Major
processing
Electric power: 37,000 kW capacity (1976); 90 million
kWh produced (1976), 20 kWh per capita
Exports: $95 million (f.0.b., 1976); livestock, peanuts,
dried fish, cotton, skins
Imports: $113 million (c.if., 1976); textiles, vehicles,
petroleum products, machinery, and sugar
industries: small local consumer goods and
Major trade partners: mostly with franc zone and
Western Europe; also with U.S.S.R., China
Budget: 1976 balanced at $110 million
Monetary conversion rate: 494.01 Mali francs=US$1,
June 1977
Fiscal year: calendar year
GNP: $524 million (1976), $1,724 per capita; 66% private
consumption, 20% gross investment; 19% government
consumption, —12% net foreign sector; in 1976 real GNP
growth was 7.2% (1970-74 average)
Agriculture: overall, 20% self-sufficient; adequate sup-
plies of vegetables, poultry, milk and pork products;
shortages in beef, grain, animal fodder, and fruits at various
seasons; main products—potatoes, cauliflowers, grapes,
wheat, barley, tomatoes, citrus, cut flowers, green peppers,
hogs, poultry, eggs; 2,680 calories per day per capita
Major industries: ship repair yard, clothing, building
industry, food manufacturing, textiles, tourism
Shortages: most consumer and industrial needs (fuels and
raw materials) must be imported
Electric power: 115,700 kW capacity (1976); 380 million
kWh produced (1976), 1,180 kWh per capita
Exports: $229 million (f.0.b., 1976); clothing, textiles,
ships, printed matter
Imports: $423 million (c.i-f., 1976)
Major trade partners: 70% EC-nine (22% U.K., 15% West
Germany, 13% Italy); 7% U.S. (1976)
Aid: economic—U.S., $66 million (FY49-76), $9.9 million
in 1974, and $9.5 million in 1975; Agreement (loans and
grants) (1964-74), $140 million; U.N. Special Fund, $2.2
million through FY72; U.N. Technical Assistance, $1.4
million through FY72; China, $45 million (1972)
Budget: (1976/77) projects $252 million in expenditures,
$235 million in revenues
Monetary conversion rate: average trade conversion
factor, year 1976: 1 Maltese pound=US$2.35
Fiscal year: 1 April-31 March','65342ec02b31b4c79c97f680055c436b0bf8bd465c79691d8f6967ba08daf68c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a8c01313416dc77e5ebe954eee247cb0f7465105e60e270fc44bc34bc3611eb',1978,'MQ','Martinique','economy',335,'GNP: $769 million (1975 at current prices), $2,220 per
capita
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, particularly
sugar milling and rum distillation; cement, oil refining and
tourism
Electric power: 95,500 kW capacity (1976); 150 million
kWh produced (1976), 420 kWh per capita
Exports: $103 million (f.0.b.,, 1976); bananas, refined
petroleum products, rum, sugar, pineapples
Imports: $324 million (c.i-f., 1976); foodstuffs, clothing
and other consumer goods, raw materials and supplies, and
petroleum
Major trading partners: exports—82% France, 9% Italy,
9% other; imports—70% France, 6% United States, 3%
Netherlands Antilles, 3% Netherlands, 18% other (1968)
Monetary conversion rate: 4.60 French francs=US$1
(1976)
Fiscal year: calendar year','693224e0830cdc5f871df129ad77452c8d52405183ebe03a5bc68010b78b8cba','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6176dce4c3df9c84960d44f04de93f57c4683f150f3506df1852d29fcb905b22',1978,'MR','Mauritania','economy',339,'GDP: about 320 million (1975), $240 per capita, average
annual increase in current prices about 3.2% (1971-73)
Agriculture: most Mauritanians are nomads or subsistence
farmers; main products—livestock, small grains, dates; cash
crops—gum arabic; livestock
Fishing: catch, 34,170 metric tons; exports, 29,891 metric
tons (1975)
Major industries: mining of iron ore and copper, fishing
Electric power: 70,000 kW capacity (1976); 100 million
kWh produced (1976), 70 kWh per capita
Exports: $189 million (f.0.b., 1976); iron ore, fish, copper
Imports: $254 million (cif, 1976); foodstuffs, capital
goods
Major trade partners: (trade figures not complete
because Mauritania has a form of customs union with
Senegal and much local trade unreported) France and other
EC members, U.K., and U.S. are main overseas partners
Budget: 1976 est. $139 million total expenditures, $11
million development expenditure included in $139 million
total, $149 million revenue
Monetary conversion rate: 46.17 Ouguiyas=US$1 as of
June 1977 (floating)
Fiscal year: calendar year','d845c8498249f2ff39ea3e7ef93b36fd01f136d54094894793c14bfe77ef600a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fd3b888b13b809a8053b69fe1eacb292ef1f5aeb49ac91ed9f4cd9e3652e4dd',1978,'MU','Mauritius','economy',343,'GNP: $490 million (1976), $550 per capita; real growth
(1970-76), 6%
Agriculture: sugar crop is major economic asset; about
40% of land area is planted to sugar; most food imported—
tice is the staple food—and since cultivation is already
intense and expansion of cultivable areas is unlikely, heavy
reliance on food imports except sugar and tea will continue
136 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MAURITIUS /MEXICO
Shortage: land
Industries: mainly confined to processing sugarcane, tea;
some small-scale, simple manufactures; tobacco fiber; some
fishing; tourism, diamond cutting, weaving and textiles,
electronics
Electric power: 81,000 kW capacity (1976); 248 million
kWh produced (1976), 280 kWh per capita
Exports: $300 million (f.0.b., est. 1977); mainly sugar, tea,
molasses
Imports: $339 million (c.i.f., est. 1977); foodstuffs 30%,
manufactured goods about 25%
Major trade partners: all EC-nine countries and US.
have preferential treatment, U.K. buys over 50% of
Mauritius’ sugar export at heavily subsidized prices; small
amount of sugar exported to Canada, U.S., and Italy; imports
from U.K. and EC primarily, also from South Africa,
Australia, and Burma; some minor trade with China
Budget: revenues $172 million, current expenditures $168
million, investment expenditure $65 million (1976)
Monetary conversion rate: 6.7 Mauritian rupees= US$1
in August 1976 (floating with pound sterling)
Fiscal year: 1 July-30 June
Agriculture: cash crops—almost entirely sugarcane, small
amounts of vanilla and perfume plants; food crops—tropical
fruit and vegetables, manioc, bananas, corn, market garden
produce, also some tea, tobacco, and coffee; food crop
inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling
plants, cigarette factory, 2 tea plants, fruit juice plant,
canning factory, a slaughterhouse, and a number of small
shops producing handicraft items
Electric power: 75,000 kW capacity (1976); 185 million
kWh produced (1976), 370 kWh per capita
Exports: $62 million (f.0.b., 1975); 90% sugar, 4%
perfume essences, 5% rum and molasses, 1% vanilla and tea
(1974)
Imports: $410 million (c.if., 1975); manufactured goods,
food, beverages, and tobacco, machinery and transportation
equipment, raw materials and petroleum products
Major trade partners: France (in 1970 supplied 62% of
Reunions imports, purchased 76% of its exports); Mauritius
(supplied 12% of imports)
Aid: French economic aid, $43.8 million 1974
Monetary conversion rate: about 224 Communaute
Financiere Africaine francs=US$1 as of January 1976
(floating since February 1973)
Fiseal year: probably calendar year','56acc802dc4df25588e6168962e1e921e00a3cbad0de77e8debe59038811d75a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23e1ec94d95b4716c19dbff868a9a3801cf52f09b383b3ebf3a7701fe9f7129b',1978,'MX','Mexico','economy',347,'GDP: $79.0 billion (1976), $1,350 per capita; 66% private
consumption, 16% public consumption, 13% private invest-
ment, 7% public investment (1976); net foreign balance
—2%; real growth rate 1976, 2.1% est.
Agriculture: main crops—corn, cotton, wheat, coffee,
sugarcane, sorghum, oilseeds, pulses, and vegetables; general
self-sufficiency with minor exceptions in meat and dairy
products; caloric intake, 3,110 calories per day per capita
(1968)
Fishing: catch 515,000 metric tons (1976); exports valued
at $151.3 million, imports at $17.8 million (1975)
Major industries: processing of food, beverages, and
tobacco; chemicals, basic metals and metal products,
petroleum products, mining, textiles and clothing, and
transport equipment
Crude steel: 5.5 million metric tons capacity (1975); 5.5
million metric tons produced (1976)
Electric power: 13,500,000 kW capacity (1976); 46 billion
kWh produced (1976), 740 kWh per capita
Exports: $3,818 million (f.0.b., 1976); cotton, coffee,
nonferrous minerals (including lead and zinc), sugar, shrimp,
petroleum, sulfur, salt, cattle and meat, fresh fruit, tomatoes,
machinery and equipment
Imports: $6,029.6 million (cif., 1976); machinery,
equipment, industrial vehicles, and intermediate goods
Major trade partners: exports—62% U.S., 9% EC, 3%
Japan (1976); imports—62% U.S., 16% EC, 5% Japan
Aid: economic—extensions from U.S. (FY46-76), $119
million in loans; $165 million in grants; from international
organizations (FY46-76), $3,357 million; from other Western
countries (1960-66), $122.7 million; military—assistance
from U.S. (FY46-76), $14 million
Budget: 1977 est. federal, revenues $456 billion pesos,
expenditures $616 billion pesos
Monetary conversion rate: floating
Fiscal year: calendar year','f8483aa8f78a7bb93ab943f828b2fe609aa0287dc4a843b88b2f537d3e8bc228','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5b53343c11b258a5ffc4fa4a7bdf8c46cbc292b3d1b0d8f0a77fcb7ef853453',1978,'MC','Monaco','economy',351,'GNP; 55% tourism; 25%-30% industry (small and primar-
ily tourist oriented), 10%-15% registration fees and sales of
postage stamps; about 4% traceable to the Monte Carlo
casino
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Major industries: chemicals, food processing, precision
instruments, glassmaking, printing
Electric power: 8,000 (standby) kW capacity (1976); 100
million kWh supplied by France (1976)
Trade: full customs integration with France, which
collects and rebates Monacan trade duties
Monetary conversion rate: 1 franc=US$0.2092 (1976
average)','2afd2a1910ab260efc2b0ffe74be01d052adda804cb5ff4be7090606b422d14e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f51bcf9898e0c070a9026adcd075821f2545fe19a435b43a73876b9d4691f6b7',1978,'MN','Mongolia','economy',355,'Agriculture: livestock raising predominates; main crops—
wheat, oats, barley
Industries: processing of animal products; building
materials; mining
Electric power: 302,000 kW capacity (1976); 840 million
kWh produced (1976), 560 kWh per capita
Exports: beef for slaughter meat products, wool, f luorspar,
other minerals
Imports: machinery and equipment, petroleum, clothing,
building materials, sugar, and tea
Major trade partners: nearly all trade with Communist
countries (approx. 85% with U.S.S.R.); total turnover about
$900 million (1976)
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 3.30 tugriks=US$1 (arbitrar-
ily established)
Fiscal year: calendar year','dcae1f7b75e2901df6611d927deb6f939991d5217aef873343a686a8332f89f0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f1b2ba973509fe20b8e79f335cbd9ef9df5bd801b3e9f5337ccd4a5a6ba69e6',1978,'MA','Morocco','economy',359,'GNP: $7.5 billion (1976), about $420 per capita; average
annual real growth 4% during 1970-73, 9% in 1974, under
3% in 1975 and 1976
Agriculture: cereal farming and livestock raising pre-
dominate; main products—wheat, barley, citrus fruit, wine,
vegetables, olives; some fishing
Fishing: catch 210,479 metric tons (1975); exports $64.5
million (1975)
Major sectors: mining and mineral processing (phos-
phates, smaller quantities of iron, manganese, lead, zinc, and
other minerals), food processing, textiles, construction and
tourism
Electric power: 878,000 kW capacity (1976); 3.1 billion
kWh produced (1976), 170 kWh per capita
Exports: $1,261 million (f.0.b., 1976); 55% phosphates,
25% agricultural goods, 20% other
Imports: $2,618 million (cif, 1976); 42% raw material
and semi-finished goods, 24% food, 20% equipment, 14%
consumer goods
Major trade partners: exports—32% France, 8% West
Germany, 8% Italy, 7% Benelux, 2% U.K.; imports—31%
France, 8% U.S., 7% West Germany, 6% Italy (1972)
Monetary conversion rate: 4.51 dirhams=US$1
Fiscal year: calendar year','37f882c5f8431ff8ed9953a5d47b98dcb54c0e3ace8b3eba23aeca2179efb661','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e556cca0dc7967c06a173ee4f71b6f826c87d88d6bb76d1acc67c4a06d756f8',1978,'MZ','Mozambique','economy',363,'GNP: $2.0 billion (1975), about $220 per capita; average
annual growth probably negative in 1975-76
Agriculture: cash crops—raw cotton, cashew nuts, sugar,
tea, copra, sisal; other crops—corn, wheat, peanuts, potatoes,
beans, sorghum, and cassava; self-sufficient in food except
for wheat which must be imported
Major industries: food processing (chiefly sugar, tea,
wheat, flour, cashew kernels); chemicals (vegetable oil,
vileakes, soap, paints); petroleum products; beverages;
textiles; nonmetallic mineral products (cement, glass, asbes-
tos, cement products); tobacco
Electric power: 440,000 kW capacity (1976); 588 million
kWh produced (1976), 60 kWh per capita
Exports: $197 million (f.0.b., 1975); cashew nuts, cotton,
sugar, mineral products, timber products, tea, copra,
petroleum products
142 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MOZAMBIQUE/NAMIBIA
Imports: $410 million (f.0.b., 1975); machinery and
electrical equipment, cotton textiles, vehicles, petroleum
products, wine, iron and steel
Major trade partners: Portugal, South Africa, U.S., U.K,
West Germany
Aid: mainly from PRC, U.S., U.K., Eastern Europe, USSR
Budget: (FY76) expenditures, $310 million, revenues,
$237 million
Monetary conversion rate: 38.732 escudos= US$1 as of
June 1977
Fiscal year: calendar year','f20be7b3d4870ae63ad190ba0351ce74b2434034a924e8af52dc84b6a13e18fe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c4bcb69df4e1b7037526d54a0bb4c7aad076fe108d69289a399d59c24820f6b',1978,'NA','Namibia','economy',367,'Agriculture: livestock raising (cattle and sheep) predomi-
nates, subsistence crops (millet, sorghum, corn, and some
wheat) are raised but most food must be imported
Fishing: catch 86,650 metric tons (1975) (processed
mostly in South African enclave of Walvis Bay)
Major industries: meatpacking, fish processing, copper,
lead, diamond, and uranium mining, dairy products
Electric power: 165,000 kW capacity (1976); 578 million
kWh produced (1976), 630 kWh per capita
Aid: South Africa is only donor
Monetary conversion rate: 1 South African Rand=
US$1.15 (as of October 1977); 0.87 SA Rand=US$1
Fiscal year: 1 April-31 March','a1f4ac238f81f06b5d5304562d5cff86d68f6e53be1d23dc2047707b2d3090e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c40953dd3b95b56794ebeb0f676748823d3a46d0e4a86a37bad2c9e5ca864563',1978,'NR','Nauru','economy',371,'GNP: over $120 million (1975), $17,140 per capita (est.)
Agriculture: negligible; almost completely dependent on
imports for food, water
Major industries: mining of phosphates, about 2 million
tons per year
Electric power: 9,000 kW capacity (1976); 26 million
kWh produced (1976), 3,710 kWh per capita
Exports: $120 million (f.0.b., 1975 est.); consisting entirely
of phosphates
Imports: $5 million (c.if., FY70)
Major trade partners: exports—7 5% Australia and New
Zealand; imports—Australia, U.K., New Zealand, Japan
Monetary conversion — rate: 1 Australian dol-
lar =US$1.2375 (July 1976)
Fiscal year: 1 July-30 June','a7399e88b17bbd265dbdf925eb438c2d135865d327819474981e6514eb80020a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f47ff3990a6e01f80c8372308ffba5263bed0905b66147883214dcc7ec74b0c9',1978,'NP','Nepal','economy',375,'GDP: $1.3 billion (FY77, at current prices), $100 per
capita; 0.7% real growth in FY77
Agriculture: over 90% of population engaged in agricul-
ture; main crops—rice, corn, wheat, sugarcane, oilseeds
Major industries: small rice, jute, sugar, and oilseed mills;
match, cigarette, and brick factories
Electric power: 59,000 kw capacity (1976); 140 million
kWh produced (1976), 10 kWh per capita
Exports: $94 million est. (FY77); rice and other food
products, jute, timber
Imports: $160 million est. (FY77); manufactured con-
sumer goods, fuel, construction materials, food products
Major trade partner: over 80% India
Aid: economic—$59 million disbursements (FY77); prin-
cipal donors: India, U.S., China, international agencies
Budget: (FY77 est.) domestic revenues $123 million,
expenditures $165 million
Monetary conversion rate: 12.5 Nepalese rupees = US$1
(October 1975)
Fiscal year: 15 July-14 July','cae5d0157d16fec920fb09e7f9f8fa4550d6e8e8c01d6bebc15d9f77f9dbf188','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf1eb183e61f35aa64ad22870dd8d7f9e065ba8a3e9a1dbb33d411353306d221',1978,'NL','Netherlands','economy',379,'GNP: $88.1 billion (in 1976 prices), $6,400 per capita;
53% consumption, 18% investment, 16% government, 3%
foreign balance (1976); average growth rate, 3.7% in
constant prices (1970-76)
Agriculture: animal husbandry predominates; main
crops—horticultural crops, grains, potatoes, sugar beets; food
shortages—grains, fats, oils; calorie intake, 3,186 calories per
day per capita (1970-71)
Fishing: catch 256,000 metric tons, $174 million (1976);
exports 204,628 metric tons, imports 131,070 metric tons
(1976)
Major industries: food processing, metal and engineering
products, electrical and electronic machinery and equip-
ment, chemicals, petroleum products, and natural gas
Shortages: crude petroleum, raw cotton, base metals and
ores, pulp, pulpwood, lumber, feedgrains, and oilseeds
Crude steel: 7.7 million metric ton capacity; 5.2 million
metric tons produced (1976), 880 kg per capita
Electric power: 15,550,000 kW capacity (1976); 63 billion
kWh produced (1976), 4,590 kWh per capita
Exports: $40.1 billion (£.0.b., 1976); foodstuffs, machinery,
chemicals, petroleum products, natural gas, textiles
Imports: $40.7 billion (c.i.f., 1976), machinery, transpor-
tation equipment, crude petroleum, foodstuffs, chemicals,
raw cotton, base metals and ores, pulp
Major trade partners: (1976) 63.3% EC, 27.5% West
Germany, 13.7% Belgium-Luxembourg, 6% U.S.
Aid: economic—U.S., $1,028 million authorized
(FY46-76); IBRD, $236 million authorized (FY46-74), none
since 1958; military—U.S., $1,285 million authorized
(FY49-76), none since FY65, net official aid delivered to less
developed areas and multilateral agencies, $3.6 billion
(FY62-75), $600 million (1975)
Budget: (1977) revenues $27.2 billion, expenditures $32.8
billion, deficit $5.5 billion
Monetary conversion rate: 2.6440 guilders=US$1, aver-
age 1976
Fiscal year: calendar year
GNP: $280 million (1975 est.), $1,170 per capita; real
growth rate, —1% (est.)
Agriculture: little production
Major industries: petroleum refining on Curacao and
Aruba; tourism on Curacao, Aruba, and St. Martin, light
manufacturing on Curacao and Aruba
Electric power: 300,000 kW capacity (1976); 1.7 billion
kWh produced (1976), 7,000 kWh per capita
Exports: $2,393 million (f.0.b., 1975); petroleum products,
phosphate
Imports: $2,789 million (c.if., 1975); crude petroleum,
food, manufactures
Major trade partners: exports—64% U.S., 7% EC, 5%
Canada; imports—61% Venezuela, 12% U.S., 6% Nether-
lands (1972)
Budget: (1972) public sector revenues, $177 million;
public sector expenditures, $188 million
Monetary conversion rate: 1.8 Netherlands Antillean
florins (NAF)=US$1, official
Fiscal year: calendar year','d97aa132d854e4cb748dc2f03aaebcf9b4d4385a28923d60fe349e17953c573b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('678acb0448e516d50682aa07d5e8c1ea44eaf6d4d75c9c51db55c7503e644bf4',1978,'NC','New Caledonia','economy',383,'GNP: $193 million, $1,800 per capita (1971 est.)
Agriculture: large areas devoted to cattle grazing; major
products—coffee and vegetables; 60% self-sufficient in beef:
must import grains and vegetables
Industry: mining of nickel
Electric power: 320,000 kW capacity (1976); 1.7-billion
kWh produced (1976), 11,890 kWh per capita
Exports: $289 million (f.0.b., 1975); 99% nickel
Imports: $348 million (c.i.f., 1975): machinery, transport
equipment, food
Major trade partners: (1972) exports—55% France, 24%
Japan, 11% U.S.; imports—52% France, 18% Australia, 12%
rest of EC
Monetary conversion rate: 86 CFP francs=US$1 (1972)
Agriculture: export crops of copra, cocoa, coffee, some
livestock and fish production; subsistence crops of copra,
taro, yams
Electric power: 4,000 kW capacity (1976); 13 million
kWh produced (1976), 1830 kWh per capita
Exports: $27 million (1974), 24% copra, 59% frozen fish
Imports: $44 million (1974)
Monetary conversion rate: 1 pound=US$2.37 (official
currency), 0.74 Australian $=US$1, 86 Colonial Franc
Pacifique (CFP)=US$1 (1972)','52ff9cbf0f156919b849c1f35f3b7fc03ab78b7a0764b7b0465ca8935e6ada0a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0086cc9fbb09c2b1c4e410708b55bea1cfdf0a257f08160ccd8697759044cf33',1978,'NI','Nicaragua','economy',388,'GDP: $1,842 million (1976 est.); 72% private consump-
tion, 9% government consumption, 21% domestic invest-
ment, —2% net foreign balance (1976); real growth rate
1976, 6.3% est.
Agriculture: main crops—cotton, coffee, sugarcane, rice,
corn, beans, cattle; caloric intake, 2,300 calories per day per
capita (1966)
Fishing: catch 18,400 metric tons (1975); exports valued
at $19.4 million (1976)
Major industries: food processing, chemicals, metal
products, textiles and clothing
Electric power: 365,000 kW capacity (1976); 1 billion
kWh produced (1976), 450 kWh per capita
Exports: $526 million (f.0.b., 1976); cotton, coffee,
chemical products, meat, sugar
Imports: $540 million (c.i.f., 1976); food and non-food
agricultural products, chemicals and pharmaceuticals, trans-
portation equipment, machinery, construction materials,
clothing, petroleum
Major trade partners: exports—30% US., 23% CACM,
47% other; imports—31% U.S., 26% CACM, 43% other
(1976)
Aid: economic—extensions from U.S. (FY46-76), $178
million loans, $89 million grants; international organizations
(FY46-73), $266 million; military—from U.S. (FY46-76),
$29 million
Budget: 1976 expenditures $317.6 million and revenues
Monetary conversion rate: 7 cordobas=US$1 (official)
Fiscal year: calendar year','184e689470a44a0b13c0e2108eaebd8b1d672b5fc4d512b0949b9d2ca5f02978','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ddd046fac13d9e269a87d77490a2cf64d36a4ff3250dc903402e2f7a19b1595',1978,'NE','Niger','economy',392,'GDP: $454 million (1975 est.), $100 per capita, annual
growth estimated by U.S. Embassy at 9.8% (1973-76)
Agriculture: livestock;
main food crops—millet, sorghum, niebe beans, vegetables
commercial—peanuts, cotton,
Major industries: cement plant, brick factory, rice mill,
small cotton gins, oil presses, slaughterhouse, and a few other
small light industries; uranium production began in 1971
Electric power: 18,000 kW capacity (1976); 55 million
kWh produced (1976), 10 kWh per capita
154 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
NIGER/NIGERIA
Exports: $85 million (f.0.b., 1975); about 65% uranium,
rest peanuts and related products, livestock, hides, skins;
exports understated because much regional trade not
recorded
Imports: $87 million (c.if., 1975); fuels, machinery,
transport equipment, foodstuffs, consumer goods (largely for
European residents)
Major trade partners: France (over 50%), other EC
countries, Nigeria, UDEAC countries, U.S.; preferential
tariff to EC and franc zone countries
Aid: economic—France (1960 to mid-1967), $68 million;
EC (FY61-78), $100 million; U.S. (FY61-76), $73 million;
West Germany, Israel, Republic of China, and U.N. have
also extended aid; military—of $2.8 million (1954-68)
Budget: projected to balance at about $173 million (1978)
Monetary conversion rate: about 247.01 Communaute
Financiere Africaine=US$1 as of June 1977, floating
Fiscal year: 1 October-30 September','c9a7f8d70d6f5b5742a069d429ecaa4bd8e248df9f4743441523d5aec5af480d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f11f3791fe47756e44aaeba116ad1ac7df17338b836f4aefb3e56ba2d2c35c24',1978,'NG','Nigeria','economy',397,'GDP: $32 billion (est. 1977 current prices), $490 per
capita; 8.8% growth rate (1971-77)
Agriculture: main crops—peanuts, cotton, cocoa, rubber.
yams, cassava, sorghum, palm kernels, millet, corn, rice:
livestock; almost self-sufficient
Fishing: catch 506,825 metric tons (1975); imports $14.5
million (1974)
Major industries: mining—crude oil, natural gas, coal,
tin, columbite; processing industries—oil palm, peanut,
cotton, rubber, petroleum, wood, hides, skins; manufactur-
ing industries—textiles, cement, building materials, food
products, footwear, chemical, printing, ceramics
Electric power: 1,367,000 kW capacity (1976); 3.6 billion
kWh produced (1976), 60 kWh per capita
Exports: $10.6 billion (f.0.b., 1976); oil (95%), cocoa, palm
products, rubber, timber, tin
$8.2 billion (c.i.f.,
transport equipment, manufactured goods, chemicals
Major trade partners: U.K., EC, US.
Budget: FY77-78 proposed—current revenue $12.2 bil-
lion, current expenditures, $5.0 billion; capital expenditures,
$8.8 billion
Monetary conversion rate: | Naira=US$1.53 (official)
Viscal year: 1 April-31 March
Imports: 1976); machinery and','20a746982a89ba5aeb59c208b416090eca1180451c313da0ee63fdb1bac5cb46','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c48e6d24989d78d477bdd0c896d65af4346dc24427911eff9629b52f2ee30fd0',1978,'NO','Norway','economy',401,'GNP: $31.0 billion in 1976, $7,690 per capita; 55% private
consumption; 37% investment; 17% government; net foreign
balance — 9%; 1976 growth rate 6%, in constant prices; 4.8%
average (1970-76)
Agriculture: animal husbandry predominates; main
crops—feed grains, potatoes, fruits, vegetables; 40% self-suf-
ficient; food shortages—food grains, sugar; caloric intake,
2,940 calories per day per capita (1969-70)
Fishing: catch 3.1 million metric tons (1976); value $476
million (1976); exports $467 million (1976)
157
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
NORWAY/OMAN
Major industries: food processing, shipbuilding, wood
pulp, paper products, metals, chemicals
Shortages: most raw materials with the exception of
timber, petroleum, iron, copper, and ilmenite ore, dairy
products and fish
Crude steel: 912,000 metric tons produced (1976), 230 kg
per capita
Electric power: 17,800,000 kW capacity (1976); 83 billion
kWh produced (1976), 20,790 kWh per capita
Exports: $7,941 million (f.0.b., 1976); principal items—
metals, pulp and paper, fish products, ships, chemicals, oil
Imports: $11,094 million (c.i.f., 1976); principal items—
foodstuff, ships, fuels, motor vehicles, iron and _ steel,
chemical compounds, textiles
Major trade partners: 49.1% EC (18.0% U.K., 13.0% West
Germany, 6.2% Denmark); 16.6% Sweden; 5.7% U.S.; 3.5%
Sino-Soviet countries (1976)
Aid: economic—U.S., $302 million authorized (FY46-76);
IBRD, $145 million authorized through 1975, none since
1964; net official economic aid delivered to less developed
areas and multilateral agencies, $134.2 million (1960-69);
$36.8 million (1970); $42.4 million (1971), $63 million
(1972), $87 million (1973), $133 million (1974), $174 million
(1975), $227 million (1976); military—U.S., $944 million
authorized (FY46-76)
Budget: (1977) revenues $8.5 billion, expenditures $11.5
billion
Monetary conversion rate: 1 kroner=US$0.1832 (1976)
Fiscal year: calendar year
GNP; $1.4 billion (1976 est.), $2,710 per capita est.
Agriculture: based on subsistence farming (fruits, dates,
cereals, cattle, camels), fishing, and trade
Major industries: petroleum discovery in 1964; produc-
tion began in 1967; production 1975, 341,370 b/d; pipeline
capacity, 400,000 b/d; revenue for 1975 est. at $1.1 billion
Electric power: 80,000 kW capacity (1976); 240 million
kWh produced (1976), 460 kWh per capita
Exports: $1.6 billion (f.0.b., 1976) mostly petroleum;
non-oil exports (mostly agricultural)
Imports: $0.7 billion (c.i.f., 1976)
Major trade partners: UX., US., other European, Gulf
states, India, Australia, China, Japan
Aid: bilateral assistance pledged, $134 million in 1974,
IBRD $8 million; aid commitment by Oman, $39 million to
multilateral institutions
Budget: (1976 projected) revenues $1.580 billion, expend-
itures $1.727 billion; net foreign reserves (December 1975)
$115 million
Monetary conversion rate: | Riyal Omani=US$2.92 (as
of May 1976)
Fiscal year: calendar year','0fd4b1283d8e5637fafb215fd60ac78d819d42e36ccbe98477bce4c4e06abbc7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc26e720ca66e73fbb1d31b0cc72ce748dc0842714503e36da2749ae59db4ce4',1978,'PK','Pakistan','economy',405,'GNP: $13.6 billion (FY76 est.), $190 per capita; average
annual real growth, 3.5% (1970-77)
Agriculture: extensive irrigation; main crops——wheat,
tice, and cotton; foodgrain shortage, 1.2 million tons
imported in FY76
Fishing: catch 195,039 metric tons (1975)
Major industries: cotton textiles, food processing, tobacco,
engineering, chemicals, natural gas
Electric power: 2,730,000 kW capacity (1976); 12.7
billion kWh produced (1976), 180 kWh per capita
Exports: $1,159 million (f.0.b., 1976); cotton (raw and
manufactured), rice
Imports: $2,128 million (c.i.f., 1976); food, crude oil,
machinery, transport equipment, chemicals
Major trade partners: US., U.K., Japan, West Germany
Budget: expenditures, FY77—current expenditures,
$2,042 million; capital expenditures, $1,407 million
Monetary conversion rate:
February 1973)
Fiscal year: 1 July-30 June','f1b25b3308fbd6b5c23203aab74db22f9df186bba60b893091a700729d4d9f51','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c06426ef5b1cfbe96bae2b98d02d5ae5e6356d67ff503b7823df10d3a600db7c',1978,'PA','Panama','economy',409,'GNP: $2,130 million (1976 est.), $1,240 per capita; 65%
private consumption, 13% government consumption, 28%
gross fixed investment, —5% net foreign balance (1975); real
growth (1976), 0.0%
Agriculture: main crops—bananas, rice, corn, coffee,
sugarcane; self-sufficient in most basic foods; 2,450 calories
per day per capita (1969)
Fishing: catch 80,183 metric tons (1975); exports $18.8
million (1974); imports $2.2 million (1974)
Major industries: food processing, metal products,
construction materials, petroleum products, clothing,
furniture
Electric power (including Canal Zone): 600,000 kW
capacity (1976); 2.5 billion kWh produced (1976), 1,450
kWh per capita
Exports: $227 million (f.0.b., 1976); bananas, petroleum
products, shrimp, sugar, meat, coffee
Imports: $838 million (cif, 1976); manufactures, trans-
portation equipment, crude petroleum, chemicals, foodstuffs
Major trade partners: exports—56% U.S., 12% Canal
Zone, 5% West Germany, 5% Italy; imports—26% U.S., 16%
Ecuador, 9% Venezuela, 7% Colon Free Zone, 16% Saudi
Arabia (1975)
Aid: economic—from U.S. (FY46-76), $324 million loans,
$177 million grants; from international organizations
(FY46-75), $266 million; from other Western countries
(1960-71), $28.9 million; military—assistance from U.S.
(FY46-75), $10 million
Budget: (1977) $455 million
Monetary conversion rate: 1 balboa=US$1 (official)
Fiscal year: calendar year','0bb8b8596f32bdbc5992be2ad7a4d6808ed59d48678ab1140f2b618c36a8f949','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c6d5d6db5c54f298befc35a13e3b0b92fa4b98c3ace04b6cfca948c5a6e0f59',1978,'PG','Papua New Guinea','economy',413,'GNP: $1.5 billion (FY74 est.); real average annual growth
rate (1969-74) 7% est.
Agriculture: main crops—coconuts, coffee, cocoa, tea
Major industries: sawmilling and timber processing,
copper mining (Bougainville)
Electric power: 284,000 kW capacity (1976); 700 million
kWh produced (1976), 250 kWh per capita
Exports: $721 million (f.0.b., FY74); principal products—
copper, coconut products, coffee beans, timber
Imports: $365 million (f.0.b., FY74)
Major trade partners: Australia, U.K., Japan
noe Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
PAPUA NEW GUINEA/PARAGUAY
Aid: economic—Australia, $1,158 million committed
(1976-81); World Bank group (1968-September 1969), $7.5
million committed; U.S. (FY70-74), $32.5 million extended
Budget: (75-76) receipts 400 Australian dollars, expendi-
tures 408 Australian dollars
Monetary conversion rate: Kina $1=A$1
Fiscal year: 1 July-30 June','c9528eef4c9e537b1f9f3f6d894af557f6e8c593aa40eb320b21c90c9d0ade6a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a8a49194663bb88efcd99024f946f3e18aba216a79d339f8f2ea6efc911549d',1978,'PY','Paraguay','economy',417,'GDP: $1.7 billion (1976, at current prices), $650 per
capita, 7.0% public consumption; 73.6% private consump-
tion, 29.4% gross domestic investment, — 10.0% net foreign
balance; real growth rate 1976, 6.5%
Agriculture: main crops—oilseeds, cotton, wheat, manioc,
sweet potatoes, tobacco, corn, rice, sugarcane; self-sufficient
in most foods; caloric intake, 2,580 calories per day per
capita (1963-64); protein intake, 70 grams per day per capita
(20 grams of animal origin)
Major industries: meat packing, oilseed crushing, milling,
brewing, textiles, light consumer goods, cement
Electric power: 280,000 kW capacity (1976); 550 million
kWh produced (1976), 210 kWh per capita
Exports: $181.3 million (f.0.b., 1976); cotton, oilseeds,
meat products, tobacco, timber, coffee, essential oils, tung oil
Imports: $236.3 million (f.0.b., 1976); fuels and lubricants,
machinery and motors, motor vehicles, beverages and
tobacco, foodstuffs
Major trade partners: 21% Argentina, 17% Brazil, 13%
Algeria, 10% U.S.
Aid: economic assistance—extensions from U.S. (FY46-76
and transition quarter), $84 million loans, $78 million grants;
from international organizations (FY46-75), $288.7 million;
from other Western countries (1960-70), $21.9 million;
military—assistance from U.S. (FY57-76), $30 million
Monetary conversion rate: 126 guaranies=US$1 (official
rate, April 1976)
Fiscal year: calendar year','c00f9ca2f2f7a1d2673b55084b3aea1ae5befc5ee63711def823e01260c87801','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0e337b9dff894bfef6b0a78919234dcba9eeeea5df1c753295f8b0fb7f02991',1978,'PE','Peru','economy',421,'GNP: $12.5 billion (1976, in current prices), $790 per
capita; 79% private consumption, 13.2% public consumption,
Approved For Release 2005/04/22 :
16.3% gross investment; —~85% net foreign balance (1976);
real growth rate (1976), 2.8%
Agriculture: main crops—wheat, potatoes, beans, rice,
barley, coffee, cotton, sugarcane; imports—wheat, meat,
lard and oils, rice, corn; caloric intake, 2,200 calories per day
per capita (1967)
Fishing: catch 4.1 million metric tons (1976); exports $195
million (1976)
Major industries: mining of metals, petroleum, fishing,
textiles and clothing, food processing, cement, auto assem-
bly, steel, ship-building, metal fabrication
Electric power: 2,413,000 kW capacity (1976); 8 billion
kWh produced (1976), 510 kWh per capita
Exports: $1,360 million (f.0.b., 1976); fish and fish
products, copper, silver, iron, cotton, sugar, lead, zinc,
petroleum, coffee
Imports: $2,100 million (f.0.b., 1976); foodstuffs, machin-
ery, transport equipment, iron and steel semimanufactures,
chemicals, pharmaceuticals
Major trade partners: exports—24% U.S., 19% Latin
America, 17% EC, 11% Japan, 10% U.S.S.R. (1975);
imports—31% US., 23% EC, 17% Latin America, 12% Japan
(1974)
Aid: economic—extensions from U.S. (FY46-76), $223
million loans, $244 million grants, from international
organizations (FY46-75), $680 million; from other Western
countries (1960-72), $136.1 million; from Communist
countries (1969-76), $282 million; military—assistance from
US. (FY49-75), $184 million; from Communist countries
(1974), $545 million
Budget: (1976) $2.0 billion current revenues, $3.3 billion
total expenditures including debt amortization
Monetary conversion rate: 76 soles=US$1 (27 April
1977); on 11 October, the sol was floated against the dollar,
previously fixed at 80.88 soles=US$1, new rate will probably
stabilize at 100 soles=US$1
Fiscal year: calendar year','f2cf01d01c9ecef7d39d26b7b4db8ac061fb64b56304126dc1b15a9e67cdc6d2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c150364e4c29db1d93b2352d6397d7170c2337396e2f6647448b48e147b611aa',1978,'PL','Poland','economy',425,'GNP: $87.6 billion in 1976, at 1975 prices, $2,550 per
capita; 1976 growth rate, 5.7%
Agriculture: self-sufficient for minimum requirements;
main crops—grain, sugar beets, oilseeds, potatoes, exporter
of livestock products and sugar; importer of grains, 3,200
calories per day per capita (1970)
Fishing: catch 656,200 metric tons (1976)
Major industries: machine building, iron and _ steel,
extractive industries, chemicals, shipbuilding, and food
processing
Crude steel: 15.6 million metric. tons produced (1976),
about 460 kg. per capita
Electric power: 20,475,000 kW capacity (1976); 104.1
billion kWh produced (1976), 3,030 kWh per capita
Exports: $11,057 million (f.0.b., 1976); 41% machinery
and equipment, 38% fuels, raw materials, and semimanufac-
tures, 11% agricultural and food products, 10% light
industrial products
Imports: $13,899 million (f.0.b., 1976); 42% machinery
and equipment; 41% fuels, raw materials, and semimanufac-
tures; 13% agricultural and food products; 4% light industrial
products
Major trade partners: $24,956 million (1976); 52% with
Communist countries, 48% with West
Monetary conversion rate: 3.32 zlotys=US$1 (commer-
cial); 33.20 zlotys=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data are
reported for calendar years except for caloric intake which is
reported for the consumption year, 1 July-30 June','85fd467bac297a56a3ae5d7885d8559b9dec236e43b8c828786783b9e90cf01c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('678c8076b6148500e1073b522263c6fc5b7947056aaeab2991cbdfa268c90023',1978,'PT','Portugal','economy',429,'GNP: $14.4 billion est. (1976); breakdown—18% govern-
ment consumption, 84% private consumption; 10% gross
fixed investment; —12% net exports; average annual real
GNP growth 1970-74, 8%; the Portuguese government puts
the change in real GNP at — 2.7% in 1975 and 5.8% in 1976,
but —7.0% and +3.3% appear more realistic
Agriculture: generally underdeveloped; main crops—
grains, potatoes, olives, grapes for wine; deficit foods—sugar,
grain, meat, fish, oil seeds; caloric intake, 2,730 calories per
day per capita (1969)
Fishing: landed 368,633 metric tons (1976)
Major industries: textiles and footwear; wood pulp,
paper, and cork, metalworking; oil refining; chemicals; fish
canning; wine
Crude steel: 460,000 tons produced (1976), 50 kg per
capita
Electric power: 3,616,000 kW capacity (1976); 9.6 billion
kWh produced (1976), 1,105 kWh per capita
Exports: $1.8 billion (f.0.b.1976); principal items—cotton
textiles, cork and cork products, canned fish, wine, timber
and timber products, resin
169
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
PORTUGAL/QATAR
Imports: $4.2 billion (cif, 1976); principal iterms—
petroleum, cotton, industrial machinery, iron and steel,
chemicals
Major trade partners: 45% EC (12% U.K. 11% W.
Germany, 9% France, 4% Italy): 12% EFTA, 8% US., 4%
Spain, 3% Iraq, 3% Saudi Arabia, 3% Japan, (1976)
Aid: economic—U.S., $254 million (FY49-76); military —
U.S., $365 million (FY49-75)
Budget: 1977—receipts, $2.7 billion; expenditures, $4.2
billion; deficit, $1.5 billion)
Monetary conversion rate: | escudo= US$0.0258 (15
April, 1977)
Fiscal year: calendar year','fc9fe4a1284e76da18fc1f6fe5ceb77f3b0a866509f783e6d5e3aabf22544b2b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33eb2bf2428eae50ad1e452c5c7d98b6d9e203cdccdcc26653f924feb656b804',1978,'QA','Qatar','economy',433,'GNP: $2.0 billion (1976), $12,660 per capita
Agriculture: farming and grazing on small scale; commer-
cial fishing increasing in importance; most food imported;
rice and dates staple diet
Major industries: oil production and refining; crude oil
production from onshore and offshore averaged 520,000 b/d
(August 1976); 100% takeover was announced in October
1976 of the Qatar Petroleum Company, still negotiating with
Qatar Shell about offshore fields; oil revenues accrued $2
billion in 1976, representing 95% of government/royal
family income; major development projects include $7
million harbor at Ad Dawhah, fertilizer plant, 2 desalting
plants, refrigerated storage for fishing, and a cement plant
Electric power: capacity 300,000 kW (1976); 600 million
kWh produced (1976), 3,980 kWh per capita
Exports: crude oil dominates; exports $2.2 billion (1976)
of which petroleum is $2 billion
Imports: $817 million (c.if., 1976)
Aid: aid donor, pledged $450 million 1974, disbursed $200
million
Budget: (1976) budgeted expenditures $986 million
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.26
(through October 1976)
Fiscal year: 1 April-31 March','31131b42e7ff8e01fbe2106b4b62ae0d1789d6114d3706bb9c48930f11a26c51','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c889f144a953d6a3e7366ef6a288322873c451bad7f05ea93bd6735f4981316',1978,'RO','Romania','economy',438,'GNP: $50.0 billion (1976, in 1975 prices), $2,330 per
capita; 1976 real growth rate, 7.1%
Agriculture: net exporter; main crops—corn, wheat,
vilseed; livestock—cattle, hogs, sheep; caloric intake, 118%
of requirements
Fish catch: 143,300 metric tons (1975)
Major industries: machinery, metals, fuels, chemicals,
textiles, food processing, timber processing
Shortages: iron ore, coking coal, metallurgical coke,
cotton fibers, natural rubber
Crude steel: 10.7 million metric tons produced (1976),
500 kg per capita
Electric power: 12,220,000 kW capacity (1976); 58.2
billion kWh produced (1976), 2,720 kWh per capita
Exports: $6.1 billion (f.0.b., 1976); 26% machinery and
equipment; 16% foodstuffs; 16% consumer goods; 24% fuels,
metals, materials; 18% other (1975)
Imports: $6.1 billion (mixture f.0.b. and cif., 1976); 32%
machinery and equipment; 41% fuels, metals, raw materials;
8% foodstuffs; 19% other (1976)
Major trade partners: $12.2 billion in 1976; 56%
non-Communist countries, 44% Communist countries (18%
U.S.S.R.) (1976)
Monetary conversion rate: 4.97 lei=US$1 (commercia)),
12 lei=US$1 (tourist)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for consumption year, 1 July-30 June','1804344cc78adb6715b173175a422a05e52ef029b916f5abacad5be8cc1caff9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c8f1c6ee837e9d08ec64ad109b9266b6370bc821d9892d0cab60f31917db8a1',1978,'RW','Rwanda','economy',442,'GDP: $603 million (1976 provisional), $140 per capita
Agriculture: cash crops—mainly coffee, tea, cotton, some
pyrethrum; main food crops—bananas, cassava; stock
raising; self-sufficiency increasing but country still imports
some foodstuffs
Major industries: mining of cassiterite (tin ore), agricul-
tural processing, and light consumer goods
Electric power: 25,000 kW capacity (1976); 35 million
kWh produced (1976), 10 kWh per capita
Exports: $104 million (f.0.b., 1976); mainly coffee, tea,
pyrethrum, cassiterite
Imports: $108.7 million (c.if., 1976); textiles, foodstuffs,
machines, equipment
Major trade partners: U.S., Belgium, West Germany,','51472f7da462472eaadde3a99545c79452686440b1f4fb144ca8d6c559bd8c42','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dd2fb1b9e085ef82afdcba44004ec3720083e70876bd52f8de0c1fcc212905a',1978,'SM','San Marino','economy',446,'Principal economic activities of San Marino are farming,
livestock raising, light manufacturing, and tourism; the
largest share of government revenue is derived from the sale
of postage stamps throughout the world and from payments
by the Italian government in exchange for Italy’s monopoly
in retailing tobacco, gasoline, and a few other goods; main
problem is finding additional funds to finance badly needed
water and electric power systems expansions
Agriculture: principal crops are wheat (average annual
output about 4,400 metric tons/year) and grapes (average
annual output about 700 metric tons/year); other grains,
fruits, vegetables, and animal feedstuffs are also grown;
livestock population numbers roughly 6,000 cows, oxen, and
sheep; cheese and hides are most important livestock
products
Electric power: obtained from Italy, 1976
Manufacturing: consists mainly of cotton textile produc-
tion at Serravalle, brick and tile production at Dogane,
cement production at Acquaviva, Dogane, and Fiorentino,
and pottery production at Borgo Maggiore; some tanned
179
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SAN MARINO/SAO TOME AND PRINCIPE
hides, paper, candy, baked goods, Moscato wine, and gold
and silver souvenirs are also produced
Foreign transactions: dominated by tourism; in summer
months 20,000 to 30,000 foreigners visit San Marino every
day; a number of hotels and restaurants have been built in
recent years to accommodate them; remittances from
Sanmarinese abroad also represent an important net foreign
inflow; commodity trade consists primarily of exchanging
building stone, lime, wood, chestnuts, wheat, wine, baked
goods, hides, and ceramics for a wide variety of consumer
manufactures','3603b50a628b97e093c2b3ed7e93b69517dc9233ab8a4e9b66fb57b2d0a63d44','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4e1d00e6b53866e8d79713ea97c5d8ebee6926c4f443b4e9bb875a38c5adfca',1978,'ST','Sao Tome and Principe','economy',450,'GNP: $20 million (1975 estimate); per capita income $250
(1975. est.)
Agriculture: cash crops—cocoa, copra, coconut, coffee,
palm oil, bananas
Major industries: food processing on small scale, timber
Electric power: 3,000 kW capacity (1976); 5 million kWh
produced (1976), 70 kWh per capita
Exports: $13 million (f.0.b., 1973); mainly cocoa (70%),
copra (12%), coconut, coffee, palm oil
Imports: $10 million (cif., 1973); communications
equipment, light and heavy vehicles, food products,
beverages, fuels and lubricants
Major trade partners: main partner, Portugal; followed
by Netherlands, West Germany, African neighbors
Aid: Portugal remains principal aid donor; however, the
PRC and UNDP have established substantial programs of
technical assistance and the Romanians and Cubans have
somewhat smaller programs; the U.S. is providing some
training for Sao Tomeans under regional AID programs
oi Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SAO TOME AND PRINCIPE/SAUDI ARABIA
Budget: total expenditures $6.4 million (1970); balance on
ordinary budget $0.7 million (1970)
Monetary conversion rate: 27.40 escudos= US$1 (January
1976)
Fiscal year: probably calendar year','73a85352c872f302d005cc6345ed719f62c9fe34e2e21eb5397935691c8e061b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb3a95472755d0ce2f4649b86d134c3506a134fc2182cda03cf2e7a4fadfe8ee',1978,'SA','Saudi Arabia','economy',454,'GNP: $48 billion (1976 est.), $7,670 per capita; annual
growth in real non-oil GNP approx. 15% (1973/76 average,
non-oil)
Agriculture: dates, grains, livestock; not self-sufficient in
food
Major industries: petroleum production 8.6 million b/d
(1976); payments to Saudi Arabian Government, $31 billion
(1976 est.); cement production and small steel-rolling mill
and oil refinery; several other light industries, including
factories producing detergents, plastic products, furniture,
etc; PETROMIN, a semipublic agency associated with the
Ministry of Petroleum, has recently completed a major
fertilizer plant
Electric power: 1,550,000 kW capacity (1976); 4.5 billion
kWh produced (1976), 720 kWh per capita
Exports: $36.1 billion (c.if., 1976); 99% petroleum and
petroleum products
Imports: $11.6 billion (c.i.f., 1976); manufactured goods,
transportation equipment, construction materials, and pro-
cessed food products
Major trade partners: exports—U.S., Western Europe,
Japan; imports—U.S., Japan, West Germany
Monetary conversion rate: 1 Saudi riyal=US$0.28 as of
February 1976 (linked to SDR, freely convertible)
181
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SAUDI ARABIA/SENEGAL
Fiscal year: follows Islamic year; the 1973-74 Saudi fiscal
year covers the period 30 July 1973 through 1 July 1974','003cf031457efad50420cd7823b9adfe4f091026e89493598d13e4dc664eb752','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85a235b37a1a75630a031af9476877b525ef648ba5dee0501411d549ad957638',1978,'SN','Senegal','economy',458,'GNP: $1.6 billion (1976 est.), $360 per capita; real growth
5.5% in 1976
Agriculture: main crops—peanuts, millet, sorghum, man-
ioc, rice; peanuts primary cash crop; production of food
crops increasing but still insufficient for ‘domestic
requirements
Fishing: catch 361,673 metric tons (1975); exports $30.9
million (1974)
Major industries: fishing, agricultural processing plants,
light manufacturing, mining
Electric power: 135,000 kW capacity (1976); 474 million
kWh produced (1976), 110 kWh per capita
Exports: $462 million (f.0.b., 1975), approx. 35% peanuts
and peanut products; phosphate rock; canned fish
Imports: $584 million (c.i.f., 1975); food, consumer goods,
machinery, transport equipment
Major trade partners: France, EC (other than France),
and franc zone
Aid: economic—France (1966-70), $115 million; China
(1976), $51.8 million; U.S. (FY61-76), $69 million; U.S.S.R.,
$7.6 million; EC (1961-73), $154 million; military—U.S.
(FY61-76), $2.8 million
Budget: 1978—balanced at $629 million
Monetary conversion rate: francs; about 247.01 Com-
munaute Financiere Africaine francs=US$1 as of June 1977,
floating
Fiscal year: 1 July-30 June','3e85d60a228ff94b1e5fe815ec00173d236d650cadf91f7aea0bfe89e15a0161','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c47d21d99b7c29a77e7f775721e14ae2338dfb9505e704a20f43fe0dc625a94e',1978,'SC','Seychelles','economy',462,'GDP: $29 million (1974); $500 per capita; 4.6% growth
rate (1974)
Agriculture: islands depend largely on coconut production
and export of copra; cinnamon, vanilla, and patchouli (used
for perfumes) are other cash crops; food crops—small
quantities of sweet potatoes, cassava, sugarcane, and
bananas; islands not self-sufficient in foodstuffs and the bulk
of the supply must be imported
Major industries: processing of coconut and vanilla,
fishing, small-scale manufacture of consumer goods, coir
rope factory, tea factory
Electric power: 11,000 kW capacity (1976); 5 million
kWh produced (1976), 80 kWh per capita
Exports: $6 million (f.0.b., 1975); cinnamon (bark and oil)
and vanilla account for almost 50% of the total, copra
184 Approved For Release 2005/04/22
accounts for about 40%, the remainder consisting of
patchouli, fish, and guano
Imports: $33 million (c.if., 1975); food, tobacco, and
beverages account for about 40% of imports, manufactured
goods about 25%, machinery and transport equipment,
petroleum products, textiles
Major trade partners: exports—India, U.S.; imports—
U.K., Burma, India, South Africa, Kenya, Australia
Aid: $32 million in aid during 1974-76 from U.K.; US
(FY53-76) $0.8 million .
Budget: (1975) revenues $20.2 million, expenditures $19.9
million
Monetary conversion rate: 5.4 Seychelles rupees=US$1
Fiscal year: calendar year','527dd53bfe3708985ba09974bc83ee07a3ae17e93df93db83b295bffaef5c52d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d483ef66e97dc447230d2465431961fd502c93b3a9266e550c99c6be00adfa88',1978,'SL','Sierra Leone','economy',466,'CDP: $680 million (mid 1975), $240 per capita; growth
rate 1.8% (mid-1971 to mid-1975)
Agriculture: main crops—palm kernels, coffee, cocoa,
rice, yams, millet, ginger, cassava, much of cultivated land
devoted to subsistence farming; food crops insufficient for
domestic consumption
Fishing: catch 67,797 metric tons (1975); imports $2.7
million (1974)
Major industries: mining—diamonds, iron ore, bauxite,
rutile; manufacturing—beverages, textiles, cigarettes, con-
struction goods; 1 oil refinery
Electric power: 75,000 kW capacity (1976); 235 million
kWh produced (1976), 80 kWh per capita
Exports: $126 million (f.0.b., 1975); diamonds, iron ore,
palm kernels, cocoa, coffec
Imports: $160 million (f.o.b., 1975); machinery and
transportation equipment, manufactured goods, foodstuffs,
petroleum products
Major trade partners: U.K., EC, Japan, U.S., Communist
countries
Budget: (FY77 est.) current revenues $88 million, total
expenditures $136 million
Monetary conversion rate: 1 leone=US$0.86 (February
1977)
Fiscal year: 1 July-30 June','ba6c7d01ad3df26be0231d4f4a9d76ccd29e45fa13b91f59c30c53e7829e0ae3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3666c2713326dd17bb1243daaf45c779eb161e2336421ad6f5e8b244cd12a129',1978,'SO','Somalia','economy',472,'GDP: $260 million (1974 est.), $80 per capita
Agriculture: mainly a pastoral country, raising livestock;
crops—bananas, sugarcane, cotton, cereals
Major industries: a few small industries, including a
sugar refinery, tuna and beef canneries, iron rod plant
Electric power: 18,000 kW capacity (1976); 45 million
kWh produced (1976), 10 kWh per capita
Exports: $91 million (f.0.b., 1975), livestock, hides, skins,
bananas
Imports: $162 million (cif, 1975); textiles, cereals,
transport equipment, machinery, construction equipment,
petroleum products; also military materiel in 1977
187
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SOMALIA/SOUTH AFRICA
Major trade partners: Italy and Arab countries; $29
million imports from Communist countries (1973 est.)
Monetary conversion rate: 6.295 Somali shillings=US$1
Fiscal year: 1 January-31 December','240b88b61a2bc026c0f371316ec7ff2acb8e7677978a01b6d8457f9951fce6b0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ab04d571c823a0a8a57eb8a9fc9ca00b0890161a5f11dd66f87408f0bed44d9',1978,'ZA','South Africa','economy',476,'GDP: $33.4 billion (1976), about $1,270 per capita; real
growth rate 1.4% (1976)
Agriculture: main crops—corn, wool, wheat, sugarcane,
tobacco, citrus fruits; dairy products; self-sufficient in
foodstuffs
Fishing: catch 1.3 million metric tons (1975)
Major industries: mining, automobile assembly, metal-
working, machinery, textiles, iron and steel, chemical,
fertilizer, fishing
Electric power: 14,140,000 kW capacity (1976); 80.3
billion kWh produced (1976), 3,060 kWh per capita
Exports: $5.6 billion (f.0.b., 1976, excluding gold); wool,
diamonds, corn, uranium, sugar, fruit, hides, skins, metals,
metallic ores, asbestos, fish products; gold output $2.7 billion
(1976)
Imports: $8.5 billion (cif, 1976); motor vehicles,
machinery, metals, petroleum products, textiles, chemicals
Major trade partners: U.K. and other Commonwealth
nations, U.S., West Germany, Japan
Aid: no military or economic aid
Budget: FY78—revenue $8.8 billion, expenditures $10.1
billion
Monetary conversion rate: 1 SA Rand=US$1.15 as of
October 1977, 0.87 SA Rand=US$1
Fiseal year: 1 April-31 March
NOTE: Foreign trade figures are official South African
data converted at $1.47
Approved For Release 2005/04/22
: CIA-RDP79-01051A000900010004-4
GDP: estimated at $150 million, $86 per capita
190 Approved For Release 2005/04/22
Agriculture: cash crops—tea, phormium tenax, small
amount of coffee; food crops—corn, sorghum, dry beans;
imports over half its foodstuffs from South Africa; two-thirds
of Transkei devoted to grazing—1.2 million cattle, 2.5
million sheep, 1.3 million goats
Major industries: forestry, textiles, tourism
Exports: timber, tea, sacks
Imports: foodstuffs, machines, equipment
Major trade partners: South Africa
Aid: South Africa, almost $500 million since 1970
Budget: $156 million (1976-77), about 70% of which is
provided by the South African government
Monetary conversion rate: 1 South African Rand=
US$1.15
Fiscal year: 1 April-31 March','6380b198efa39c78a1416d4a22140c9aa0094a60651d0502b445b31f42e984b1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a20db01073d0c7f103d48efab3340386b65670953e224ff8dafdc88cb6257fc2',1978,'ES','Spain','economy',480,'GNP: $102.3 billion (1976), $2,840 per capita; 71.5%
private consumption, 10.0% public consumption, 24.1% gross
fixed investment, 1.9% stockbuilding; —7.5% foreign bal-
ance (1975); real growth rate 1.8% (1976); typical growth
rate 6.5% :
Agriculture: main crops—cereals, oranges, grapes for
wine, potatoes, olives, sugar beets; virtually self-sufficient in
good crop years; caloric intake, 2,750 calories per day per
capita (1969-70)
Fishing: landed 1.52 million metric tons valued at $1,152
million in 1976
Major industries: food processing, textiles and apparel
(including footwear), metal manufacturing, chemicals, ship-
building, automobiles
Shortages: crude petroleum
Crude steel: 10.9 million metric tons produced (1976),
300 kg per capita
Electric power: 27,150,000 kW capacity (1976); 94 billion
kWh produced (1976), 2,640 kWh per capita
Exports: $8,730 million (f.0.b., 1976); principal items—
oranges and other fruits, iron and steel products, textiles,
wines, mercury, ships, canned fruits, vegetables, and
footwear
Imports: $17,474 million (c.i.f., 1976); principal items—
machinery and transportation equipment, petroleum and
petroleum products, grains, cotton, iron and steel
Major trade partners: (1976) 32.1% EC, 10.5% U.S. and
Canada, 16.7% rest of OECD, 81% Latin America, 2.9%
CEMA
192
Approved For Release 2005/04/22 :
Aid: economic—U.S., $1.0 billion authorized (FY46-76),
IBRD, $427 million authorized (FY64-73), $50.0 million
authorized (FY73); military—U.S., $922 million authorized
(FY53-76)
Budget: (1977 central government)—budgeted revenues
$12,726 billion, budgeted expenditures $12,726 billion
Monetary conversion rate: | peseta=US80.0149 (1976
average)
Fiseal year: calendar year','0e9caa8833392ee72f25722c46442e67fc791896c9dbe62f6f8b83fd7e4383d5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2462530a9114166ceea04ecd8105e6de64adc832a44b69ef1415e4941e8a3b9',1978,'LK','Sri Lanka','economy',484,'GNP: $2.8 billion in 1976 (1976 prices), $200 per capita;
real growth rate 2.9% (1976), 3.6% (1975)
Agriculture: agriculture accounts for about 32% of GNP;
main crops—rice, rubber, tea, coconuts; 60% self-sufficient
in food; food shortages—rice, wheat, sugar
Fishing: catch 129,123 metric tons (1975)
Major industries: processing of rubber, tea, and other
agricultural commodities; consumer goods manufacture
193
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SRI LANKA/SUDAN
Electric power: 430,000 kW capacity (1976); 1.4 billion
kWh produced (1976), 100 kWh per capita
Exports: $565 million (1976); tea, rubber, coconut
products
Imports: $572 million (1976); food, petroleum, fertilizer
Major trade partners: (1975) exports—16.1% China,
12.1% Pakistan, 10.9% U.K.; imports—15.8% China, 15.2%
Saudi Arabia, 10.7% Japan
Budget: 1976 est. revenue $534 million, expenditure $809
million
Monetary conversion rate: 8.6053 rupees=US$1 (12
September 1977), official rate
Fiscal year: 1 January-81 December (starting 1973)','aa74595aefce000591e9e68a0e29f5ba5cf319dc506dbef7f43da4e5b18e2772','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc0dfb4f98ae19a7bb70328f458f808212b590ca4eb9be2456acd05df233f975',1978,'SD','Sudan','economy',488,'GDP: $3.9 billion at current prices (1976), $210 per capita
at current prices; 4%-5% growth rate (1976)
Agriculture: main crops—sorghum, millet, wheat, sesame,
peanuts, beans, barley; not self-sufficient in food production;
main cash crops—cotton, gum arabic, peanuts, sesame
Major industries: cotton ginning, textiles, brewery,
cement, edible oils, soap, distilling, shoes, pharmaceuticals
Electric power: 225,000 kW capacity (1976); 655 million
kWh produced (1976), 40 kWh per capita
Exports: $587 million (f.0.b., 1976); cotton (51%), gum
arabic, peanuts, sesame; $100 million exports to Communist
countries (FY76)
Imports: $979 million (c.if., 1976); textiles, petroleum
products, vehicles, tea, wheat; $75 million imports from
Communist countries (FY76)
Major trade partners: U.K., West Germany, Italy, India,
China, France, Japan
Monetary conversion rate: 1 Sudanese pound=US$2.87
(official); 0.348 Sudanese pound=US$1
Fiscal year: 1 July-30 June
GNP: $503 million (1976 est.); $1,180 per capita; real
growth rate 1974, 5.7%
Agriculture: main crops—rice, sugarcane, bananas; self-
sufficient in major staple (rice); caloric intake 2,350 calories
per day per capita (1968)
Major industries: bauxite mining, alumina and aluminum
production, lumbering, food processing
Electric power: 320,000 kW capacity (1976); 1.6 billion
kWh produced (1976), 3,760 kWh per capita
Exports: $280 million (f.0.b., 1975): bauxite, alumina,
aluminum, wood and wood products, rice
Imports: $264 million (c.if., 1975); capital equipment,
petroleum, iron and steel, cotton, flour, meat, dairy products
Major trade partners: exports—35% U.S., 34% EC, 18%
other European countries; imports—-34% U.S., 38% EC, 13%
Caribbean countries, 18% Europe (1975)
Aid: economic—extensions from U.S. (FY54-76), $1.0
million in loans, $4.8 million in grants; from Netherlands,
EC, UNDP (1964-74), $180 million; planned from Nether-
lands (1976-85), $1.5 billion
Budget: revenue, $352 million; expenditure, $367 million
(1978 est.)
Monetary conversion rate:
fl.)=US$0.565 (September 1976)
Fiscal year: calendar year
GDP: approximately $200 million (est. FY74), about $420
per capita; growth rate in current prices as much as 11%
(FY71-74)
Agriculture: main crops—maize, cotton, rice, sugar, and
citrus fruits
Major industry: mining
Electric power: 75,000 kW capacity (1976); 125 million
kWh produced (1976), 270 kWh per capita
Exports: $152 million (f.0.b., 1975); sugar, iron ore,
asbestos, wood and forest products, citrus, meat products,
cotton
Imports: $151 million (f.0.b., 1975); motor vehicles,
petroleum products, foodstuffs, and clothing
Major trade partners: South Africa, U.K., U.S.
Aid: economic—U.K. $14.7 million (budgeted, 1971-73),
US. $10.9 million (FY61-76), others approximately $1.3
million; no military aid
Budget: FY77—revenue $86 million, recurrent expendi-
ture $47 million, development expenditure $39 million
197
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SWAZILAND/SWEDEN
Monetary conversion rate: | Lilangeni=US$1.15 (as of
October 1977)
Fiscal year: 1 April-31 March','f3aa14b33a7b81022ad364f2c68f0ddd4d75b6349ab8fbff85795d2346464eb0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6ae0fd686dd266eacf0735ff4c8232ccf8229b8bde680099793e1ecd2edfa5c',1978,'SE','Sweden','economy',492,'GDP: $74.0 billion, $9,000 per capita (1976); 53.4%
consumption, 20.5% investment, 25.5% government; 2.6%
inventory change; — 2.0% net imports of goods and services;
1976 growth rate 1.5% in constant prices
Agriculture: animal husbandry predominates with milk
and dairy products accounting for 40% of farm income;
main crops—grains, sugar beets, potatoes; 80% self-suffi-
cient; food shortages—oils and fats, tropical products; caloric
intake, 2,903 calories per day per capita (1975)
Fishing: catch 193,300 metric tons (1976), exports $28
million, imports $139 million
Major industries; iron and steel, precision equipment
(bearings, radio and telephone parts, armaments), shipbuild-
ing, wood pulp and paper products, processed foods, textiles,
chemicals
Shortages: coal, petroleum, textile fibers, potash, salt
Crude steel: 5.1 million metric tons produced (1976), 625
kg per capita
Electric power: 24,940,000 kW capacity (1976); 82 billion
kWh produced (1976), 9,970 kWh per capita
Exports: $18,440 million (f.0.b., 1976); machinery, motor
vehicles and ships, wood pulp, paper products, iron and steel
products, metal ores and scrap, chemicals
Imports: $19,333 million (c.if., 1976); machinery, motor
vehicles, petroleum and petroleum products, textile yarn
and fabrics, iron and steel, chemicals, food, and live animals
Major trade partners: (1976) 15% West Germany, 12%
UK., 6% U.S., 9% Norway, 8% Denmark; 49% EC-9; 6%
U.S.S.R. and Eastern Europe
Aid: economic—U.S., $109 million authorized (FY46-76);
$77.5 million in 1973; $24.7 million in 1972; net official aid
to less developed countries and multilateral agencies, $662.4
million (1960-70), $159 million in 1971, $198 million in
1972, $275 million in 1973
Budget: 1976—revenues $22.5 billion, expenditures $23.0
billion
Monetary conversion rate: 4.36 kroner=US$1 average
exchange rate 1976
Fiscal year: 1 July-30 June','3563cf2bb9b2cf01c8db6d8d14b5872c210528a23fa09e86b2793d1a8aecb81b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b750d0a292069f83b37a2558743fc19f66e171bc93271f747e5fccd35c4c7afe',1978,'CH','Switzerland','economy',495,'GNP: $58.66 billion provisional (1976, in 1976 prices),
$9,300 per capita; 58.6% consumption, 21.3% investment,
13.3% government, net foreign balance 6.8% (1976); 1970-76
average growth rate 1.8%, constant prices
Agriculture: dairy farming predominates; less than 50%
self-sufficient; food shortages—fish, refined sugar, fats and
oils (other than butter), grains, eggs, fruits, vegetables, meat;
caloric intake, 3,190 calories per day per capita (1969-70)
Major industries: machinery, chemicals, watches, textiles,
precision instruments
Shortages: practically all important raw materials except
hydroelectric energy
Electric power: 11,830,000 kW capacity (1976); 36 billion
kWh produced (1976), 5,670 kWh per capita
Exports: $14.83 billion (f.0.b., 1976); principal items—
machinery and equipment, chemicals, precision instruments,
metal products, textiles, foodstuffs
Imports: $14.78 billion (c.if., 1976); principal items—
machinery and transportation equipment, metals and metal
products, foodstuffs, chemicals, textile fibers and yarns
Major trade partners: 56% EC (22% West Germany, 11%
France, 9% Italy, 6% U.K.); 10% EFTA (5% Austria); 7%
U.S.; 5% Communist countries (1976)
Aid: economic—authorized net official economic aid
delivered to less developed areas and multilateral agencies,
$325 million (1962-74); $103.6 million of official develop-
ment assistance disbursed in 1975, $70.6 million bilateral,
$33 million multilateral
Budget: receipts, $5,717 million, expenditures, $6,346
million, deficit, $629 million (1976)
Monetary conversion rate: 2.4998 Swiss francs=US$1
(average 1976, floating)
Fiscal year: calendar year
GDP: $5.7 billion, est. (1976), $730 per capita; real GDP
growth rate 6%, 1976 est.
Agriculture: main crops—cotton, wheat, barley and
tobacco; sheep and goat raising; self-sufficient in most foods
in years of good weather
Major industries: textiles, petroleum (est. 180,000 b/d
production, refining capacity is 117,000 b/d), food process-
ing, beverages, tobacco
Electric power: 1,150,000 kW capacity (1976); 1.5 billion
kWh produced (1976), 200 kWh per capita
Exports: $1 billion projected (f.o.b., 1976); petroleum,
cotton, fruits and vegetables, grain, wool, and livestock
Imports: $2.3 billion (c.if., 1976); machinery and metal
products, textiles, fuels, foodstuffs
201
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SYRIA/TANZANIA
Major trade partners: exports—Italy, Belgium, West
Germany, U.K.; imports—West Germany, Italy, France,','0261069438b276e39631a9bb66b2c27e7de2486f1bb17df800bd0abf90432726','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9575e87f39f366a4d59a1341c086bab4633f247ae441de42e4727c25efabb4d',1978,'TH','Thailand','economy',499,'GDP: $16.3 billion (1976), $370 per capita; 6.2% real
growth in 1976 (6.1% real growth, 1971-76)
at Approved For Release 2005/04/22
Agriculture: main crops—rice, sugar, corn, rubber,
tapioca
Fishing: catch 1.4 million metric tons (1975); exports,
88,000 metric tons, $77 million (1974)
Major industries: agricultural processing, textiles, wood
and wood products, cement, tin and tungsten ore mining,
world’s second largest tungsten producer and third largest
tin producer
Shortages: fuel sources, including coal, petroleum; scrap
iron, and fertilizer
Electric power: 2,740,000 kW capacity (1976); 9.2 billion
kWh produced (1976), 210 kWh per capita
Exports: $2.9 billion (f.0.b., 1976); rice, sugar, corn,
rubber, tin, tapioca, kenaf
Imports: $3.6 billion (cif, 1976); machinery and
transport equipment, fuels and lubricants, base metals,
chemicals, and fertilizer
Major trade partners: exports—Japan, U.S., Singapore,
Netherlands, Hong Kong, Malaysia; imports—Japan, U.S.,
West Germany, U.K.; about 1% or less trade with
Communist countries
Budget: (FY78) planned receipts $4,050 million; 19.5%
military, 80.5% civilian
Monetary conversion rate: 20.0 baht=US$1
Fiscal year: 1 October-30 September','c350cd01623db4212ee76530634d9b3a4959d99312f2d42b47cbd3ea78c713dc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce770751d0737b3bfa11aa38af5e47c507daebc81992277e7c6a7a3e798a250c',1978,'TG','Togo','economy',503,'GDP: $471 million (1975), about $210 per capita;
estimated real growth 1966-70, 5.3% average annual rate
Agriculture: main cash crops—coffee, cocoa, cotton;
major food crops—yams, cassava, corn, beans, rice, millet,
sorghum, fish; must import some foodstuffs
Major industries: phosphate mining, agricultural process-
ing, handicrafts, textiles, beverages
Electric power: 30,000 kW capacity (1976); 100 million
kWh produced (1976), 40 kWh per capita
Exports: $124 million (f.0.b., 1975); phosphates, cocoa,
coffee, palm kernels, and cassava
Imports: $150 million (f.0.b., 1975); consumer goods,
fuels, machinery, tobacco, foodstuffs
Major trade partners: mostly with France and other EC
countries
Aid: 1975 disbursements—France, $13.6 million; West
Germany, $2.5 million; EEC, $1.5 million; U.S., $1.1 million;
FY59-75 total commitments—EC, $62.9 million; U.S., $30
million; U.N., $16.8 million; others, $24.6 million; China
(1972), $45 million
Budget: (1977 proposed), revenues and expenditures,
$221 million
Monetary conversion rate: Communaute Financiere
Africaine 249.35 francs=US$1 as of February 1977
Fiscal year: calendar year','1d2c79185bfd51db47bed261ce719bb3e7788a442b7d9adf5d4e25fc1007c9f5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9608342c2dd5620292c76559da3ccb7273d8f5a6c55e7583ca69e7b92c1a773e',1978,'TO','Tonga','economy',507,'GNP: $39 million (1975), $400 per capita
Agriculture: largely dominated by coconut and banana
production with subsistence crops of taro, yams, sweet
potatoes, and bread fruit
Electric power: 4,000 kW capacity (1976); 8 million kWh
produced (1976), 80 kWh per capita
Exports: $10 million (f.0.b., 1975); 65% copra, 7% coconut
products, 8% bananas
Imports: $28 million (c.i.f., 1975); food, machinery, and
petroleum
Major trade partners: (FY74) exports—25% Netherlands,
22% Australia, 20% New Zealand, 11% Norway; imports—
63% New Zealand and Australia
Budget: (FY76) revenues $6.7 million, expenditures $8.3
million
Monetary conversion rate: 1 Tonga dollar=US$1.40
(1976)
Fiscal year: 1 July-30 June','123e6d2b37f9420c828aa6dcba9f2a2c3b13459d43723b15783eecceeb507cfc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc8a04ed41bf12403dde1ce02a0ae1e0d3ae83789b0c43115071215dbef24940',1978,'TT','Trinidad and Tobago','economy',511,'GDP: $2,300 million (1976), $2,240 per capita; real
growth rate 1976, 4.8%
Agriculture: main crops—sugarcane, cocoa, coffee, rice,
citrus, bananas; largely dependent upon imports of food
Fishing: catch 13,880 metric tons (1976); exports $1.1
million (1975), imports $4.5 million (1975)
Major industries: petroleum, tourism, food processing,
cement
Electric power: 375,000 kW capacity (1976); 1.3 billion
kWh produced (1976), 1,280 kWh per capita
Exports: $2.2 billion (f.0.b., 1976); petroleum and
petroleum products ($2.04 million), sugar, cocoa
207
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
TRINIDAD AND TOBAGO/TUNISIA
Imports: $2.0 billion (c.i.f., 1976); crude petroleum ($1.1
billion), machinery, fabricated metals, transportation equip-
ment, manufactured goods, food
Major trade partners: (excludes trade under petroleum
agreement) exports—U.S. 71%, U.K. 9%, Caricom 15%;
imports—U.S. 45%, U.K. 17%, Caricom 6% (1976)
Aid: economic—from U.S. (FY46-76), $40.5 million in
grants; from international organizations (FY53-75), $14.8
million
Budget: (1977) central government revenues $1 billion,
expenditures $1 billion (current $487 million, investment
$156 million, development project funds, $371 million)
Monetary conversion rate: tied to US dollar in 1976;
TT$2.40=US$1
Fiscal year: calendar year','ab0b872875dda8b07b3a85c8c8502713659fb18a66d81ae835b83e05a61d263b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9463c14b39f73393aa3f176c9d13267aff23a3ee22d2d811ce56133502ec524',1978,'TN','Tunisia','economy',515,'GDP: $4.5 billion (1976 est.), $760 per capita; real growth
of 2% in 1976
Agriculture: cereal farming and livestock herding pre-
dominate; main crops—wheat, barley, olives, fruits (espe-
cially citrus), viticulture, vegetables, dates
Major sectors: tourism, mining, food processing, textiles
and leather, light manufacturing, construction materials,
chemical fertilizers, petroleum
Electric power: 425,000 kW capacity (1976); 1.3 billion
kWh produced (1976), 220 kWh per capita
Exports: $847 million (f.0.b., 1975); 34% petroleum, 20%
phosphates, 18% olive oil
Imports: $1.5 billion (c.i.f., 1975); 36% raw materials, 23%
machinery and equipment, 14% consumer goods, 19% food
and beverages, 3% energy, 5% other
Major trade partners: exports—19% France, 19% Italy,
138% West Germany, 10% Libya; imports—36% France, 15%
U.S., 9% Italy, 7% West Germany (1971)
Monetary conversion rate: 1 Tunisian dinar (TD)=
US$2.32
Fiscal year: calendar year
GNP: $41.4 billion (1976), $1,010 per capita; 8.0% real
growth 1976, 7%-8% average annual real growth 1970-76
a Approved For Release 2005/04/22
Agriculture: main products—cotton, tobacco, cereals,
sugar beets, fruits, nuts, and livestock products; self-suffi-
cient in food in average years, 2,900 calories per day per
capita (1972)
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
Crude steel: 1.9 million tons produced (1976), 45 kg per
capita
Electric power: 4,705,000 kW capacity (1976); 19 billion
kWh produced (1976), 470 kWh per capita
Exports: $1,960 million (f.0.b., 1976); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $5,129 million (c.if., 1976); machinery, trans-
port equipment, metals, mineral fuels, fertilizers, chemicals
Major trade partners: 22% West Germany, 9% U.S., 9%
Iraq, 7% U.K., 7% Italy
Budget: (F Y77) revenues $11.2 billion, expenditures $12.2
billion, deficit $1.01 billion
Monetary conversion rate: 19.25 Turkish liras=US$1 (21
September 1977)
Fiscal year: 1 March-28 February','2c3faa86304d424e00285b6ff4d03c334f003ecb06f54a8dcec91ef4e724f3be','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21ab8c6fdcdfb2e331114ed3ad39ed30a7b6dd68b0dcf805e1ec87ce428b6bdf',1978,'TV','Tuvalu','economy',519,'See Gilbert Islands for economic data
GDP: $1,700 million (1974, at current prices), $150 per
capita; 0% real growth between 1970-74
Agriculture: main cash crops—coffee, cotton; other cash
crops—tobacco, tea, sugar, fish, livestock
Fishing: catch 169,700 metric tons (1975) million (1971)
Major industries: agricultural processing (textiles, sugar,
coffee, plywood, beer), cement, copper smelter, corrugated
iron sheet, shoes, fertilizer
Electric power: 175,000 kW capacity (1976); 788 million
kWh produced (1976), 70 kWh per capita
Exports: $244 million (f.o.b., 1975); coffee, cotton, tea,
copper (1971)
Imports: $240 million (c.i.f., 1975); petroleum products,
machinery, cotton piece goods, metals, transport equipment
Major trade partners: U.K., U.S., Kenya
Monetary conversion rate: 8.4 Uganda shillings=US$1
Fiscal year: 1 July-30 June
GNP: $921.7 billion (1976, in 1976 U.S. prices), $3,590 per
capita; in 1976 percentage shares were—57% consumption,
30% investment, 13% government and other, including
defense (based on 1970 GNP in rubles at adjusted factor
cost); average annual rate of growth of real GNP (1971-76),
3.9%
Agriculture: principal food crops—grain (especially
wheat), potatoes; main industrial crops—sugar, cotton,
sunflowers, and flax; degree of self-sufficiency depends on
fluctuations in crop yields; caloric intake, 8,250 calories per
day per capita in recent years
Fishing: catch 10.8 million metric tons (1975); exports
491,000 metric tons (1975), imports 26,700 metric tons
(1975)
Major industries: diversified, highly developed capital
goods industries; consumer goods industries comparatively
less developed
Shortages: natural rubber, bauxite and alumina, tantalum,
tin, tungsten and fluorspar
Crude steel: 156 million metric ton capacity as of 1
January 1977; 145 million metric tons produced in 1976, 560
kg per capita
Electric power: 227,500,000 kW capacity (1976); 1,109
billion kWh produced (1976), 4,320 kWh per capita
Exports: $37,166 million (f.0.b., 1976); fuels (particularly
petroleum and derivatives), metals, agricultural products
(timber, grain), and a wide variety of manufactured goods
(primarily capital goods)
Imports: $38,106 million (f.0.b., 1976); specialized and
complex machinery and equipment, textile fibers, consumer
manufactures, steel products (particularly large diameter
pipe), and any significant shortages in domestic production
(for example, grain imported following poor domestic
harvests)
Major trade partners: $75.7 billion (1976); trade 55%
with Communist countries, 33% with industrialized West,
and 11% with less developed countries
Aid: economic—to less developed countries (total ex-
tended 1976) $915 million; recipients included Syria $300
million, Algeria $290 million, Iraq $150 million; military—
(total extended 1976) $2.6 billion; principal recipients were
Iraq $1.2 billion, Peru $337 million.
Official monetary conversion rate: 0.746] rubles= US$1:
(April 1977)
Fiscal year: calendar year','a8696a41ffec4cd039fa8d0372a35a46b31dfdcbe6b79f113341659eda9b59df','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d259c514de0b31a11e25664b8fd8e9968896b9c37c4e4e486a9782d037dc45e0',1978,'AE','United Arab Emirates','economy',523,'Agriculture: food imported, but some dates, alfalfa,
vegetables, fruit, tobacco raised
Electric power: 700,000 kW capacity (1976); 1.4 billion
kWh produced (1976), 7,860 kWh per capita
Exports: $8.5 billion ($7.0 billion in oil, $0.3 billion
non-oil) (f.0.b., 1976); crude petroleum, pearls, fish
Imports: $3 billion (f.0.b., 1976); food, consumer and
capital goods
Major trade partners: U.K., U.S., Japan, India, EC
Aid: 1974-75 foreign aid totaled $1 billion; the 1975-76
budget committed $875 million to direct foreign aid; Abu
Dhabi Fund for Arab Economic and Social Development in
1975 lent $175 million to LDC’s
Budget: total budget (1976), $1 billion, 70% from Abu
Dhabi
Monetary conversion rate: 1 U.A.E. Dirham =US$0.25
Fiscal year: calendar year','73ccf782bbf75bf8c7a206d89e3669b5ae64b7a2cc877099fe95c013e0efae5c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0e05843e66805a6d4ed4316a03d24da771220654d8c512bfb7a3277f7f5cc05',1978,'GB','United Kingdom','economy',527,'GNP: $218.6 billion (1976 est. in 1976 prices), $3,840 per
capita; 60.4% consumption, 19.0% investment, 21.9% gov-
ernment; —0.1% inventories, —1.4% net foreign balance,
real growth 1.5% (1976)
Agriculture: mixed farming predominates, main prod-
ucts—wheat, barley, potatoes, sugar beets, livestock, dairy
products; 52.2% self-sufficient; food shortages—meat, fruits,
vegetables, cereals, dairy products; caloric intake, 2,910
calories per day per capita, 1975
Fishing: catch 933,000 metric tons (1976), valued at $332
million; 1976 exports $146.2 million, imports $492.5 million
Major industries: machinery and transport equipment,
metals, food processing, paper and paper products, textiles,
chemicals, clothing
Shortages: rubber, timber and woodpulp, textile fibers,
nonferrous metals, foodstuffs
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 a
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
UNITED KINGDOM/UPPER VOLTA
Crude steel: 22.3 million metric tons produced (1976):
28.1 million metric tons capacity (1975), 400 kg per capita
Klectric power: 83,800,000 kW capacity (1976); 277
billion kWh produced (1976), 4,934 kWh per capita
Exports: $45.9 billion (f.0.b., 1976); machinery, transport
equipment, chemicals, metals, nonmetallic mineral manu-
factures, textiles, beverages
Imports: $52.4 billion (f.0.b., 1976); foodstuffs, petroleum,
machinery, crude materials, chemicals, nonferrous metals
Major trade partners: 36.1% EC, 14.1% Commonwealth,
9.6% US., 4.0% Ireland, 3.1% Canada, 2.3% U.S.S.R. and
Eastern Furope, 2.2% South Africa, 1.9% Australia
Aid: $863.4 million of official development assistance
disbursed in 1975; $566.5 million bilateral, $296.9 million
multilateral
Budget (central government): forecasts for FY78, $75.67
billion expenditures, $65.67 billion revenues; central govern-
ment borrowing requirement, $11.93 billion; total public
sector borrowing requirement, $14.74 billion
Monetary conversion rate: pound sterling floating,
average daily exchange rate 1976, 0.55 pounds=US$1
Fiscal year: 1 April-31 March
GNP: $644 million (1976 est.), $110 per capita, annual
growth estimated by U.S. Embassy at 4.6% (1973-76)
Agriculture: cash crops—peanuts, shea nuts, sesame,
cotton; food crops—sorghum, millet, corn, rice; livestock;
largely self-sufficient
Fishing: catch 3,500 metric tons (1975)
Major industries: agricultural processing plants, brewery,
bottling, and brick plants; a few other light industries
Electric power: 21,500 kW capacity (1976); 57 million
kWh produced (1976), 9 kWh per capita
Exports: $44 million (f.0.b., 1975); livestock (on the hoof),
peanuts, shea nut products, cotton, sesame
Imports: $151 million (c.if., 1975); textiles, food, and
other consumer goods, transport equipment, machinery,
fuels
Major trade partners: Ivory Coast and Ghana; overseas
trade mainly with France and other EC countries;
preferential tariff to EC and france zone countries
Aid: economic—France (1964-September 1970), $46
million; EC (FY1960-72), $87 million; U.S.S.R., China,
Ghana, West Germany, and Israel have also extended aid;
U.S. (FY61-76), $53 million; international organizations
(FY60-73), $175 million; China, $51 million (1973-76);
military—France, $3.7 million (1964-70); U.S., $0.1 million
(FY 1962-76)
Budget: (1976) balanced at $94 million
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Monetary conversion rate: about 247.01 Communaute
Financiere Africaine francs=US$1 as of June 1977, floating
Fiscal year: calendar year','3cde27c8175b42083af7bae79dff4c22dc63a8fe5bf82313fff55000784f2072','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f758bdabe4d4e1f73f5ba6a771d1b78c3adaba8577a2d47fe3d2ffabb834815f',1978,'UY','Uruguay','economy',531,'GNP: $3.0 billion (1976), $1,080 per capita; 83% private
consumption, 12% public consumption, 11% gross invest-
ment; real growth rate 1976, 2.6%
Agriculture: large areas devoted to extensive livestock
grazing (17 million sheep, 11 million cattle); main crops—
wheat, rice, corn; self-sufficient in most basic foodstuffs;
caloric intake, 3,000 calories per day per capita, with high
protein content
Major industries: meat processing, wool and hides,
textiles, footwear, cement, petroleum refining
Crude steel: rolled products 34,841 metric tons produced,
castings 263 metric tons (1976)
Electric power: 700,000 kW capacity (1976): 3 billion
kWh produced (1976), 1,079 kWh per capita
Exports: $536 million (f.0.b., 1976); wool, hides
Imports: $599 million (c.i.f., 1976); fuels, metals, machin-
ery, transportation equipment
Major trade partners: exports—-35% EC, 11% U.S., 24%
LAFTA; imports—35% LAFTA, 8% U.S., 16% EC (1974)
Aid: economic—extensions from U.S. (FY46-76), $129
million in loans, $30 million in grants; from other Western
countries (1960-74), $26 million; from Communist coun-
tries—-U.S.S.R. (1969-76), $52 million and Eastern Europe
(1966-76), $31 million; from international organizations
(1946-76), $371 million; military—authorizations from U.S.
(FY53-75), $90 million
Budget: (1976) revenue, $477 million; expenditure, $566
million
Monetary conversion rate: commercial rate, new pesos
4.83=US$1, financial rate, new pesos 4.83=US$1 (August
1977)
Fiscal year: calendar year
The Vatican City, seat of the Holy See, is supported
financially by contributions (known as Peter’s pence) from
Roman Catholics throughout the world; some income
derived from sale of Vatican postage stamps and _ tourist
mementos, fees for admission to Vatican museums, and sale
of publications; industrial activity consists solely of printing
and production of a small amount of mosaics and staff
uniforms
The banking and financial activities of the Vatican are
worldwide; the Institute for Religious Agencies carries out
fiscal operations and invests and transfers funds of Roman
Catholic religious communities throughout the world; the
Cardinal’s Commission controls the administration of ordi-
nary assets of the Holy See and a Special Administration
manages the Holy See’s capital assets
Electric power: obtained from Rome city grid; standby
diesel powerplant with 2,100 kW capacity (1976)
GNP: $32.2 billion (1976, in 1976 dollars), $2,600 per
capita; 48% private consumption, 14% public consumption,
30% gross investment, 8% foreign sector (1975), real growth
rate 5.8%
Agriculture: main crops—sugarcane, corn, coffee, rice;
imports wheat (U.S.), corn (South Africa), sorghum (Argenti-
na, U.S,); caloric intake 2,600 calories per day per capita
(1972)
Fishing: catch 153,396 metric tons (1975); exports $16.1
million (1974), imports $4.1 million (1974)
Major industries: petroleum, iron-ore mining, construc-
tion, food processing, textiles
Crude steel: 1.1 million metric tons produced (1975), 90
kg per capita
Electric power: 4,500,000 kW capacity (1976); 20 billion
kWh produced (1976), 1,620 kWh per capita
Exports: $8.8 billion (f.0.b., 1976); petroleum $8.4 billion
(1976), iron ore, coffee
Imports: $6.5 billion (f.0.b., 1976); industrial machinery
and equipment, chemicals, manufactures, wheat
Major trade partners; imports—48% U.S., 10% Japan, 9%
West Germany; exports—38% U.S., 13% Canada
anh Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
VENEZUELA/VIETNAM
Aid: economic assistance—extensions from US.
(FY46-76), $128 million loans; $73 million grants; from
international organizations (FY46-75), $658 million, from
Communist countries (1954-76), $10 million; military—
assistance from U.S. (FY46-76), $153 million
Budget: 1976—revenues $9.8 billion; expenditures, $10.2
billion, capital $4.3. billion
Monetary conversion rate: 4.2925 bolivares=US$1 (sell-
ing rate)
Fiscal year: calendar year
CNP: $6.5 billion (1976), approximately $140 per capita;
real growth on the order of 2% annually since 1973
Agriculture: main crops—rice, rubber, fruits and vegeta-
bles, mainly in the south; some corn, manioc, and sugarcane;
major food imports—wheat, dairy products
Fishing: catch 776,000 metric tons (1976), of which
600,000 metric tons sea
Major industries: food processing, textiles, machine
building, mining, cement, chemical fertilizer, glass, tires
Shortages: foodgrains, petroleum, capital goods and
machinery, fertilizer
Klectric power: 1,330,000 kW capacity (1976); 3 billion
kWh produced (1976), 65 kWh per capita
Exports: $170 million (1976); agricultural and handicraft
products, coal, minerals, ores
Imports: approximately $1.0 billion (1976); petroleum,
steel products, railroad equipment, chemicals, medicines,
raw cotton, fertilizer, grain
Major trade partners: exports—U.S.S.R., East European
countries, Japan, other Asian markets: imports—U.S.S.R.,
East Europe, China, Japan
Aid: accurate data on aid since April 1975 unification
unavailable; estimated annual commitments of economic aid
are—U.S.S.R., $500 million; East European countries, $350
million; China, $350 million; non-Communist countries,
$100 million; international institutions, $50 million; military
aid deliveries since end of war in April 1975 are minimal
Monetary conversion rate (official): 2.5 northern
dong=US$1; 1.85 southern dong=US$1 (internally), |
northern dong=0.8 southern dong (April 1977)
Fiscal year: calendar year','59b1770483a22ad5c1f25721e0690d95058e3b6e0edb5b189ab9857ffffcac79','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53fd6f1a2401e3aae1ffa46bb4c936fde052b6b417b94af7c360f19eb9ad92af',1978,'WF','Wallis and Futuna','economy',535,'Agriculture: dominated by coconut production with
subsistence crops of yams, taro, bananas
Exports: negligible
Imports: $1.4 million (1972); largely foodstuffs and some
equipment associated with development programs
Monetary conversion rate: 70 Colonial France Pacifique
(CFP)=US$1','c2829ca6265177dee67cfd3288e0908b6b969f51ed9ef6a08eb226bea5606ec5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9006de201bf83659213f495f4e7bb8774d18f88bfa4e4046b75e7dc079fb324f',1978,'EH','Western Sahara','economy',539,'Agriculture: practically none; some barley is grown in
nondrought years; fruit and vegetables in the few oases; food
imports are essential; camels, sheep, and goats are kept by
the nomadic natives; cash economy exists largely for the
garrison forces
phosphate fishing, and
Major industries:
handicrafts
mining,
Shortages: water
Electric power: 4,000 kW capacity (1975); 9 million kWh
produced (1975), 84 kWh per capita
Exports: in 1975, up to $75 million in phosphates, all other
exports valued at under $1 million
Imports: $1,443,000 (1968); fuel for fishing fleet,
foodstuffs
Major trade partners: monetary trade largely with Spain
and Spanish possessions
Aid: small amounts from Spain in prior years
Monetary conversion rate: see Moroccan and Mauritan-
ian currencies
GNP: $45 million (1974), $290 per capita
Agriculture: cocoa, bananas, copra; staple foods include
coconut, bananas, taro, and yams
Exports: $7 million (f.0.b., 1975); copra 38%, cocoa 26%,
timber 3%
Imports: $36 million (c.if., 1975); food, manufactured
goods, machinery
Major trade partners: exports—43% New Zealand, 10%
Netherlands, 14% West Germany, 12% U.S.; imports—33%
New Zealand, 19% Australia, 12% Japan
Aid: New Zealand, $7 million (est. 1972-76)
Budget: 1975 est., revenues 14 million tala, expenditures
22 million tala
Monetary conversion rate: WS Tala=US$1.258 (Febru-
ary 1977), 0.79 WS Tala=US$1
Major industries: timber, tourism
GNP: $440 million (1975 est.), $250 per capita
Agriculture (all outside Aden): cotton is main cash crop;
cereals, dates, kat (qat), coffee, and livestock are raised and
there is a growing fishing industry; large amount of food
must be imported (particularly for Aden); cotton, hides,
skins, dried and salted fish are exported
Major industries: petroleum refinery (production 150,000
b/d) mid-1971; capacity 178,000 b/d at Little Aden operates
on imported crude; oil exploration activity
Electric power: 95,000 kW capacity (1976); 190 million
kWh produced (1976), 277 kWh per capita
Exports: $36 million (1976 provisional), excluding petro-
leum products but including re-exports
Imports: $274 million (1976 provisional)
Major trade partners: Yemen, East Africa, but some
cement and sugar imported from Communist countries;
crude oil imported from Persian Gulf, exported mainly to
U.K. and Japan
Budget: (FY1974-75, est.)—revenues $42 million, expen-
ditures $75 million
Monetary conversion rate: 1 S. Yemeni dinar =US$2.90
Fiscal year: 1 April-31 March
GNP: $1,600 million (1976 est.), $240 per capita
Agriculture: sorghum and millet, gat (a mild narcotic),
cotton, coffee, fruits and vegetables; largely self-sufficient in
food
Major industries: cotton textiles and leather goods
produced on a small scale; handicraft and some fishing;
small aluminum products factory
Electric power: 47,000 kW capacity (1976); 80 million
kWh produced (1976), 12 kWh per capita
Exports: $15 million (1976 est.); qat, cotton, coffee, hides,
vegetables
Imports: $475 million (1976 est.); textiles and other
manufactured consumer goods, petroleum products, sugar,
grain, flour, other foodstuffs, and cement
Major trade partners: China, Yemen (Aden), U.S.S.R.,
Japan, U.K., Australia, Saudi Arabia
Aid: bilateral pledges received—$167 million 1974,
multilateral—$36 million through 1972, $170 million drawn
through 1970; major donors include U.S.S.R., China, U.S.,
West Germany, Saudi Arabia; military—$114 million from
US.S.R.; $37 million from Eastern Europe; $7 million
Western military aid through 1973
Budget: (1974/75 est.) $711 million expenditures
Monetary conversion rate: 1 Yemeni rial=US$0.22 as of
October 1973
Fiscal year: 1 July-30 June
GNP: $42.3 billion (1976 est., at 1976 prices), $1,960 per
capita; real growth rate 5.3% (1971-76)
227
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
YUGOSLAVIA/ZAIRE
Agriculture: diversified agriculture with many small
private holdings and large agricultural combines; main
crops—corn, wheat, tobacco, sugar beets, and sunflowers;
occasionally a net exporter of foodstuffs and live animals:
imports tropical products, cotton, wool, and vegetable meal
feeds; caloric intake, 3,210 calories per day per capita (1967)
Major industries: metallurgy, machinery and equipment,
textiles, wood processing, food processing
Shortages: electricity, fuels, steel, textile fibers, chemicals
Crude steel: 2.75 million metric tons produced (1976),
130 kg per capita
Electric power: 10,173,000 kW capacity (1976); 43.6
billion kWh produced (1976), 2,020 kWh per capita
Exports: $4,880 million (f.0.b., 1976); 10% foodstuffs; 28%
machinery and equipment; 27% intermediate goods; 33%
manufactures
Imports: $7,380 million (c.i.f., 1976); 8% foodstuffs and
tobacco; 24% raw materials, fuels; 33% machinery and
equipment; 35% other manufactures
Major trade partners: 65% non-Communist countries
(34% EC, 6% U.S., 25% other non-Communist countries),
35% Communist countries
Aid: Yugoslav outstanding external debt (medium/long-
term) end 1976, $7 billion, of which $2.7 billion official,
largely non-Communist (U.S. $350 million, FRG $400
million, U.S.S.R. $200 million, IBRD $560 million end 1975);
Yugoslavia has extended aid totalling about $1.2 billion to
developing countries, largely since the late 1960’s
Monetary conversion rate: (official) 17.0 new dinars=
US$1
Fiscal year: same as calendar year (all data refer to
calendar year or to middle or end of calendar year as
indicated)
GDP: $3.59 billion (1976 prices), $100 per capita; 3%
annual growth 1970-76
Agriculture: main cash crops—coffee, palm cil, rubber;
main food crops—manioc, bananas, root crops, corn; some
provinces self-sufficient
Fishing: catch 124,580 metric tons (1975); imports $38
million (1974)
Major industries: mining, mineral processing, light
industries
Electric power: 1,217,000 kW capacity (1976); 3.9 billion
kWh produced (1976), 152 kWh per capita
Exports: $1.2 billion (f.0.b., 1977 projected); copper,
cobalt, diamonds, other minerals, coffee
Imports: $1 billion (f.0.b., 1977 projected); consumer
goods, foodstuffs, mining and other machinery, transport
equipment, fuels
Major trade partners: Belgium, U.S., and West Germany
Aid: economic—U.S. (FY61-76), $488 million; (1971
estimated disbursements) Belgium, $31.4 million; France,
$6.6 million; other bilateral aid $5.4 million; U.N., $9.4
million; EC, $18.9 million; China (1973), $100 million;
military—U.S., $90 million (FY62-76); IMF, $155 million
(1976)
Budget: 1977 proposed—revenue, 770 million; expendi-
tures, $976 million
Approved For Release 2005/04/22
Monetary conversion rate: 1 zaire=US$1.17
Fiscal year: calendar year','16f2a1a18e23d366ee428fc919bc2fe17a9a39699a274fa28099c39dc10d3584','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('132e1e04898cfe6015a35e3fb83af02bb5498c5b9b9639a79e94359033cb8c68',1978,'ZM','Zambia','economy',543,'GNP: $2.1 billion (1976), $420 per capita; real annual
growth rate, 2.1% (1971-76)
Agriculture: main crops—corn, tobacco, cotton; net
importer of most major agricultural products
Major industries: copper mining and processing
Electric power: 1,523,000 kW capacity (1976); 7.0 billion
kWh produced (1976), 1,410 kWh per capita
Exports: $992 million (f.0.b., 1976); copper (92%), zinc,
cobalt, lead, tobacco
Imports: $750 million (c.i.f., 1976); machinery, transport
equipment, foodstuffs, fuels, manufactures
Major trade partners: EEC, Japan, China, South Africa
Aid: economic—China (1967-76), $331 million; U.K.
(1964-67), $63 million; IBRD (1965-75), $432 million; U.S.
(F Y53-76), $36 million; U.S.S.R., $9 million; Eastern Europe,
$50 million; military—$14 million (1964-76), mainly U.K.
and Canada; $18 million, Communist
Budget: 1976 est.—revenue $510 million, expenditures
$665 million
Monetary conversion rate: 1 Zambia kwacha=US$1.2526
(official)
Fiscal year: calendar year','c7b64964b9914d3877dcbfb883bb5bc01e122e3bca2aba700e71d79be019dd62','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fa580fba58eb1c1a2ebfd853e118cc8278e636959d97257220bddc20fd6e330',1978,'US','United States','economy',547,'GNP: $1,706.5 billion (1976); 64% private consumption,
13.5% private investment, 21% government; $7,930 per
capita; 1976 growth rate —6% (constant 1972 dollars)
Fishing: catch 2.8 million metric tons (1975); imports
$1,381 million, (1975); exports $298 million, (1975)
Crude steel: 116.1 million metric tons produced (1976),
540 kg per capita
Electric power: 531,287,000 kW capacity (1976); 2
trillion kWh produced (1976), 9,456 kWh per capita est.
Exports: $114.8 billion (f.0.b., 1976); machinery and
transport equipment, chemicals, cereals, mineral fuels
Imports: $129.6 billion (c.i.f., 1976); transport equipment,
machinery, mineral fuels, steel, nonferrous metals, metal
ores
Major trade partners: 22% Canada, 8% Japan, 5% West
Germany, 5% U.K. (1975)
Official development assistance (aid): obligations and
loan authorizations (FY76), economic $3.9 billion, military
$2.7 billion
Budget: National Accounts Basis, expenditures $323.7
billion, revenues $287.6 billion
Fiscal year: 1 October-30 September','67754521628cea9720bc23c856e15c1e21d71355ac4c75e494b74347a5e09aa2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3487a1880e41c2c0654769bae5719f91b969868e13cba21611a6d8ef894cd0e',1978,'AF','Afghanistan','economy',6,'GNP: $2.4 billion (FY77), $176 per capita, real growth
rate about 2.5% (1973-77)
Agriculture: agriculture and animal husbandry account
for over 50% of GNP and occupy nearly 85% of the labor
force; main crops—wheat and other grains, cotton, fruits,
nuts; largely self-sufficient; food shortages—wheat, sugar,
tea
Major industries: cottage industries, food processing,
textiles, cement, coal mining
Electric power: 360,000 kW capacity (1977); 585 million
kWh produced (1977), 35 kWh per capita
Exports: $310 million (f.0.b., FY77); fresh and dried
fruits, natural gas, karakul skins, carpets, hides, wool and
cotton
Imports: $343 million (f.0.b., FY77); non-metallic miner-
als, sugar, tires and tubes, textiles, tea, used clothing,
tobacco, transportation, and wheat
Major trade partners: exports—U.S.S.R., India, U.K.,
Pakistan, West Germany, Switzerland, U.S.; imports—Japan,
U.S.S.R., India, West Germany, U.K., U.S.
Aid: economic—U.S. (FY70-76), $145.0 million commit-
ted; U.S.S.R. (1970-76), $569.9 million; Eastern Europe
(1970-76), $28 million, China (1970-76), $48.5 million;
OPEC (1970-76), $818 million; military—U.S. (FY70-76),
$1.4 million; U.S.S.R. (1970-76), $259 million; Eastern
Europe (1970-76), $11 million
Budget: current expenditures $158 million, capital
expenditures $163 million for FY76
Monetary conversion rate: 45 Afghanis=US$1 (official);
47.5 Afghanis=US$1 (March 1977)
Fiscal year: 2] March-20 March','d32b0cbd09b7b158ee8fa44360178e600d9b3c0071b9f4e77d021b683a636185','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d8386b661e016bdb57e815a22e363374b40b8232d03c568c80baf4af2cc089c',1978,'AL','Albania','economy',11,'GNP: $748 million in 1970 (at 1970 prices), $350 per
capita
Agriculture: food deficit area; main crops—corn, wheat,
tobacco, sugar beets, cotton; food shortages—wheat; caloric
intake, 2,100 calories per day per capita (1961/62)
Major industries: agricultural processing, textiles and
clothing, lumber, and extractive industries
Shortages: spare parts, machinery and equipment, wheat
Electric power: 500,000 kW capacity (1977); 1.8 billion
kWh produced (1977), 700 kWh per capita
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
ALBANIA/ALGERIA
Exports: $746 million (1971-75 est.); 1964 trade—55%
minerals, metals, fuels; 23% foodstuffs (including cigarettes);
17% agricultural materials (except foods); 5% consumer
goods
Imports: $1,238 million (1971-75 est.), 1964 trade—-50%
machinery, equipment, and spare parts, 16% minerals,
metals, fuels, construction materials; 16% foodstuffs, 7%
consumer goods; 7% fertilizers, other chemicals, rubber; 4%
agricultural materials (except foodstuffs)
Monetary conversion rate: 5 leks=US$1 (commercial);
12.5 leks=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for consumption year 1 July-30 June','b6006fd208583862c1883868a40f03002f3985ad6fe0e0620ad43f541f370429','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1653f25be2ab91e7b5984899fe3a5c92c0fd517e71d2a5e1f56bb79d61c4d0a2',1978,'DZ','Algeria','economy',15,'GNP: $16.2 billion (1977 provisional), $880 per capita; in
real terms, 6% growth in 1977
Agriculture: main crops—wheat, barley, grapes, citrus
fruits
Major industries: petroleum, light industries, natural gas,
mining, petrochemical, electrical, and automotive plants
under construction
Electric power: 1,690,000 kW capacity (1977); 4.5 billion
kWh produced (1977), 250 kWh per capita
Exports: $5.8 billion (t.0.b., 1977 est.); 90% hydrocarbons,
also wine, citrus fruit, iron ore, vegetables; U.S. took 36% of
exports in 1976, supplanting France as Algeria’s leading
trade partner
Imports: $6.9 billion (c.if., 1977); major items—capital
goods 35%, semi-finished goods 38%, foodstuffs 25%; from
France 23%, US. 9%
Monetary conversion rate: 1 DA=US$0.24
Fiscal year: calendar year','676b12d63053ac5a2de908d9814cb8c070d51d132a1ee294aaddcbcb951a9759','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97a50c9ee315a32470f8aa8e79d1b6f7b9d201dd5552d8f5470944b20322eac7',1978,'AD','Andorra','economy',19,'Agriculture: sheep raising; small quantities of tobacco,
rye, wheat, barley, oats, and some vegetables (less than 4% of
land is arable)
Major industries: tourism, sheep, timber, tobacco, and
smuggling
Shortages: food
Electric power: 25,000 kW capacity (1977); 100 million
kWh produced (1977), 3,448 kWh per capita; power is
mainly exported to Spain and France
Major trade partners: Spain, France','95547559bba4f95965e2b92ac73e62cf192687855da83bcd1948cfd18875ed0d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a76c10a251ea088e76fee255553d7bbe18f6dbae8ef64d3ad613d7c491589a30',1978,'AO','Angola','economy',23,'GDP: $3.0 billion (1974 est.), $500 per capita, 6.1% real
growth (1970-72); growth probably negative in 1975-77
Agriculture: cash crops—coffee, sisal, corn, cotton, sugar,
manioc, and tobacco; food crops—cassava, corn, vegetables,
plantains, bananas, and other local foodstuffs; largely
self-sufficient in food
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ANGOLA/ANTIGUA
Fishing: catch 183,850 metric tons (1975); exports $53.0
million; imports $5.6 million (1978)
Major industries: mining (oil, diamonds), fish processing,
brewing, tobacco, sugar processing, textiles, cement, food
processing plants, building construction
Electric power: 525,000 kW capacity (1977): 1.3 billion
kWh produced (1977), 200 kWh per capita
Exports: $1.2 billion (f.0.b., 1974); oil, coffee, diamonds,
sisal, fish and fish products, iron ore, timber, corn, and
cotton; exports down sharply 1975-77
Imports: $614 million (c.if., 1974); capital equipment
(machinery and electrical equipment), wines, bulk iron and
ironwork, steel and metals, vehicles and spare parts, textiles
and clothing, medicines; military deliveries partially offset
drop in imports in 1975-77
Major trade partners: Portugal, West Germany, US.,
U.K., Japan; trade with U.S.S.R. and Cuba increasing since
independence
Aid: military aid from USSR. and Cuba in 1975
Budget: (1975) balanced at about $740 million by former
Portuguese administration; budget not yet published by new','252e37c48e72e8dc7e517c21a09d3e265fec2c9f9fc8e0338d8b8819dd27a5bb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96c11bdeeff6a64e8090896b42c95dddc27aa90c08c1d17e8ea93e3e46d19656',1978,'PR','Puerto Rico','economy',27,'GDP: $51 million (1974 est.), $640 per capita; 2.7% real
growth
Agriculture: main crop, cotton
Major industries: oil refining, tourism
Shortages: electric power
Electric power: 31,200 kW capacity (1977); 60 million
kWh produced (1977), 835 kWh per capita
Exports: $22 million (f.0.b., 1975); petroleum products,
cotton
Imports: $54 million (c.i.f., 1975); crude oil, food, clothing
Major trade partners: 30% U.K., 25% U.S., 18%
Commonwealth Caribbean countries
Aid: economic—U.S. authorizations (FY46-75), $1.5 mil-
lion in loans
Budget: (projected 1977) revenues, $17 million; expendi-
tures, $21 million
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)','cea25dc060a133d3b85d990a9efc40a517989ef7392fbbeb4fa38ec586983178','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0adf3408fde4c3559c24cbcc72bdec4538fbe080ffc47d2676bec5d39bb599aa',1978,'AR','Argentina','economy',31,'GNP: $48 billion (1977), $1,879 per capita; 18%
zovernment consumption, 62% private consumption, 22%
investment, —2% net foreign demand (1975); real GDP
growth rate 1977, 4.4%
Agriculture: main products—cereals, oilseeds, livestock
products; Argentina is a major world exporter of temperate
zone foodstuffs
Fishing: catch 350,000 metric tons (1976 est.); exports $42
million (1976 est.)
Major industries: food processing (especially meatpack-
ing), motor vehicles, consumer durables, textiles, chemicals,
printing, and metallurgy
Crude steel: 2.7 million metric tons produced (1977), 90
kg per capita
Electric power: 9.16 million kW capacity (1977); 27
billion kWh produced (1977), 1,080 kWh per capita
Exports: $5.6 billion (f.0.b., 1977); meat, corn, wheat,
wool, hides, oilseeds
Imports: $4.0 billion (c.i.f., 1977): machinery, fuel and
lubricating oils, iron and steel, intermediate industrial
products
Major trade partners (1976): exports—10% Italy, 6%
U.S.S.R., 9% Netherlands, 11% Brazil, 7% U.S.; imports—
18% U.S., 8% Japan, 11% FRG, 12% Brazil
Aid: economic—extensions from U.S, (FY46-76), $1
billion in loans, $17.9 million in grants; from international
organizations (FY46-75), $1.4 billion; from other Western
countries (1960-66), $315.5 million; from Communist
countries (1954-76), $513 million ($89 million drawn):
military—assistance from U.S. (FY46-76), $265 million
Budget: (1978) 8,000 billion pesos=$11 billion at ex-
change rate of March 1978
Monetary conversion rate: 700 pesos=US$1 (March
1978)
Fiscal year: calendar year','6e6fba99fea36fe8d499335f3d91b00c92db04b21f576f69b3087d39f498e571','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1a4c1b7d651d3b0d2a40ec82aa25824968932dc92009680c942b63dd7f7a385',1978,'AU','Australia','economy',35,'GNP: $95.2 billion (1977), $6,830 per capita; 60% private
consumption, 16% government current expenditure, 24%
investment (1975); 2% real average annual growth (1975-77)
Agriculture: large areas devoted to livestock grazing; 60%
of area used for crops is planted in wheat; major products—
wool, livestock, wheat, fruits, sugarcane; self-sufficient in
food; caloric intake, 3,300 calories per day per capita
Fishing: catch 103,281 metric tons (1975); exports $94.5
million (FY75), imports $86.2 million (FY75)
Major industries: mining, industrial and transportation
equipment, food processing, chemicals
Crude steel: 7.8 million metric tons produced (FY76), 570
kg per capita
Electric power: 22,457,000 kW capacity (1977); 84.1
billion kWh produced (1977), 6,000 kWh per capita
Exports: $12.9 billion (f.o.b., 1977); principal products
(1977) —44% agricultural products, 14% metalliferous ores,
13% wool, 12% coal
Imports: $11.6 billion (c.i.f., 1977); principal products
(1977)—41% manufactured raw materials, 28% capital
equipment, 25% consumer goods
Major trade partners: (1977) exports—34% Japan, 9%
US., 5% New Zealand, 4% U.K.; imports—21% U.S., 11%
U.K., 21% Japan
Aid: economic—Australian aid abroad $2.3 billion
(FY65-75); $430 million (FY75), 55% for Papua New Guinea
Budget: expenditures, A$26.7 billion; receipts A$24.4
billion (FY78)
Monetary conversion rate: 0.88 Australian dollar=US$1
(A$1=US$1.14), January 1978
Fiscal year: 1 July-30 June','19cda1789d3348dd162de3dc14f122e4ecaed08d63ba81cd8848214d018d0c25','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b11d4c8fb078720c899c4324c3d423772fc0b88c3065414824278b9e438a099',1978,'AT','Austria','economy',40,'GNP: $47.8 billion (1977), $6,350 per capita; 59.2%
consumption, 28.1% investment, 11.3% government, 3.5%
stock building; —2.1% net foreign balance (1976 in 1964
prices); 1977 real GNP growth rate, 3.5%
Agriculture: livestock, cereals, potatoes, sugar beets; 84%
self-sufficient; caloric intake 3,230 calories per day per
capita (1969-70)
Major industries: foods, iron and steel, machinery,
textiles, chemicals, electrical, paper and pulp
Crude steel: 4.5 million metric tons produced (1976), 600
kg per capita (1976)
Electric power: 11.5 million kW capacity (1977); 38.3
billion kWh produced (1977), 5,100 kWh per capita
Exports: $9.8 billion (f.0.b., 1977 est.); iron and steel
products, machinery and equipment, lumber, textiles, paper
products, chemicals
Imports: $14.2 billion (c.i-f., 1977 est.); machinery and
equipment, chemicals, textiles and clothing, petroleum,
foodstuffs
Major trade partners: (1977 est.) 34.6% West Germany,
8.6% Italy, 8.1% Switzerland, 4.8% U.K., 3.7% France, 57.9%
EC; 12.5% EFTA; 10.9% Communist countries
Aid: bilateral economic aid authorized (ODA and OOF),
$364 million (1970-76)
Budget: expenditures, $14.6 billion; revenues, $11.9
billion; deficit, $2.8 billion (1977 est.)
Monetary conversion rate: 16.53 shillings=US$1, 1977
average
Fiscal year: calendar year
GNP: $698 million (at market prices, 1976), $3,890 per
capita; real growth rate 1976, 4.8%
Agriculture: food importer, main crops—fish, fruits,
vegetables
Major industries: tourism, cement, oil refining, lumber,
salt production, rum
Electric power: 250,000 kW capacity (1977); 680 million
kWh produced (1977), 3,320 kWh per capita
Exports: $2.6 billion (f.0.b.,.1976); fuel oil, pharmaceuti-
cals, cement, rum
Imports: $2.9 billion (c.i.f., 1976); crude oil, foodstuffs,
manufactured goods
Major trade partners: exports—U.S. 86%, U.K. 2%,
Canada 2%; imports—U.S. 24%, Libya 20%, Nigeria 16%
(1978)
Aid: economic—authorizations from U.S. (FY56-76), $0.3
million in grants; from _ international
(FY71-76), $12 million
Budget: (1977) revenues, $152 million; recurrent expendi-
tures, $168 million
organizations
Monetary conversion rate: 1 Bahamian — dollar
(B$1)=US$1
Fiscal year: calendar year','e97b6f4fcb31e0115220d9278b0255fbeed27f297c0948f2fddddf394529cb2d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a8a498b648fb8a45e3a67a0a9baa3f354291f45ba19f3e34988a170daf98783',1978,'BH','Bahrain','economy',44,'GNP: $600 million (1976 est.), annual growth rate 4.1%
(1975-85 projected average), $2,430 per capita, dominated
by oil industry; 1977 average daily crude oil production,
56,000 bbls (oil expected to last 15 years if no new
discoveries are made), 1975 nonassociated natural gas
production, 102 billion ft?; government oil revenues for 1976
are estimated at $395.7 million
Agriculture: produces dates, alfalfa, vegetables; dairy and
poultry farming; fishing; not self-sufficient in food
Major industries: petroleum refining, aluminum smelt-
ing, boatbuilding, shrimp fishing, pearls and sailmaking on a
small scale; major development projects include flourmill,
and ISA town; OAPEC dry dock to be built by 1977
Electric power: 550,000 kW capacity (1977); 2.0 billion
kWh produced (1977), 7,520 kWh per capita
Exports: $1,346 million (f.0.b., 1976), non-oil exports
(including reexports), $428.7 million (1977 projected); oil
exports, $1,000 million (1976)
Imports: $1,668 million (c.i-f., 1976)
Major trade partners: Saudi Arabia, U.K., US., Japan,
EC
Aid: received $110 million in bilateral commitments and
committed itself $8.5 million to multilateral agencies in
CY74
Budget: (1976) $489 million, 72% of revenues from oil
Monetary conversion rate: 1 Bahrain dinar = US$2.52
(since January 1973)
Fiscal year: calendar year','2a658617c0506a37c0760d920be1924d32e12d65ee0e0390d5cb7b19b2244876','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f262f58c0fda32bd247d5bbbbeb2fef97441278e96c8f68ad994b6bab4c3922',1978,'BD','Bangladesh','economy',48,'GNP: $6.5 billion est. (FY77, current prices), $78 per
capita; real growth, 2.6% (FY77), 9.2% (FY76)
Agriculture: large subsistence farming, heavily dependent
on monsoon rainfall: main crops are jute and rice;
shortages—grain, cotton, and oilseeds
Fishing: catch 640,000 metric tons (1975)
Major industries; jute manufactures, food processing and
cotton textiles
Electric power: 915,000 kw capacity (1977); 1.6 billion
kWh produced (1977), 20 kWh per capita
Exports: $474 million (FY77); raw and manufactured jute,
leather, tea
Imports: $860 million (FY77), foodgrains, fuels, raw
cotton, fertilizer, manufactured products
Major trade partners: exports—U.S. 17%,
imports—U.S. 28.5%, Canada 9.7% (FY76)
Budget: (F Y76) domestic revenues, $692 million; expend-
itures, $1,489 million
UK. 7.4%:
14
adc ee
Monetary conversion rate: 14,26 taka=US$1 (January
1978)
Fiscal year: | July-30 June','da78b3be3e59724421b969900e03d177af3d4206754a7310c9be522169e221ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0218d50fbcd6dba1e44e0177c6ccbd4cc680340a2dd921036ecf2a99ba75ce8',1978,'BB','Barbados','economy',52,'GDP: $396 million (1976), $1,370 per capita; real growth
rate 1976, 6.2%
Agriculture: main products—sugarcane, subsistence foods
Major industries: tourism, sugar milling, light manu-
facturing
Electric power: 107,000 kW capacity (1977); 220 million
kWh produced (1977), 920 kWh per capita
Exports: $208 million (£.0.b., 1976); sugar and sugarcane
byproducts, clothing
Imports: $275 million (c.if., 1976); foodstuffs, machinery,
manufactured goods
Major trade partners: exports—28% U.K., 14% US., 28%
CARIFTA, 30% other; imports—25% U.K., 21% U.S., 11%
Canada, 138% CARIFTA, 30% other (1973)
Aid: economic—authorization from U.S. (FY67-76), $1.4
million; from international organizations (FY63-76), $31.9
million
Budget: (1976) revenues, $152 million; expenditures, $191
million
Monetary conversion rate: 2 Barbados dollars=US$1
Fiscal year: 1 April-31 March','e502488a7f930af86c34c2cb99621cf12ea7a7a7a8ce3777820959a180199ece','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ce3dbf369aa48d45358efcfb76e9946d2d29d2b275fe8946c9fabbf494ce080',1978,'BE','Belgium','economy',56,'GNP: $75. billion (1977), $7,642 per capita; 59%
consumption, 23.8% investment, 14.9% government, 2.2%
stock building, 0.4% net foreign balance (1975); 2.9% real
growth rate in 1976
Agriculture: livestock production predominates; main
crops—grains, beets, potatoes; 80% self-sufficient in food;
caloric intake, 3,230 calories per day per capita (1969-70)
Fishing: exports $37 million (1975), imports $178 million
(1975)
Major industries: engineering and metal products,
processed food and beverages, chemicals, basic metals,
textiles, and petroleum
Crude steel: 12.1 million metric tons produced; 1,240 kg
per capita (1976) :
Electric power: 11,451,000 kW capacity (1977); 48 billion
kWh_ produced (1977), 4,885 kWh per capita
Exports: (Belgium-Luxembourg Economic Union) $37.0
billion (f.0.b., 1976); iron and steel products, finished or
semifinished precious stones, textile products
Imports: (Belgium-Luxembourg Economic Union) $39.3
billion (c.i.f., 1976); nonelectrical machinery, motor vehicles,
textiles, chemicals
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
BELGIUM/BELIZE
Major trade partners: (Belgium-Luxembourg Economic
Union, 1976) 71% EC (21.5% West Germany, 16.9% France,
15.6% Netherlands, 9.1% U.K., 4.0% Italy), 6.3% USS.
Aid: bilateral economic aid authorized (ODA and OOF),
$1,580 million (1970-76)
Budget: (1976) revenues, $20.3 billion; expenditures,
$24.3 billion; deficit, $3.5 billion
Monetary conversion rate: (1977 average) Belgian Franc
36.36= US$1
Fiscal year: calendar year','47e6efddeed5a0db2a68170a242c93410cba10747175c7f94181a21c210885f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2c8505104634969d8222b81fe344a131ff35a9206edf7923dd7e769b5dfd011',1978,'MX','Mexico','economy',61,'GDP: $96 million (1975), $749 per capita; 78% private
consumption, 17% public consumption, 36% domestic
investment, —31% net foreign balance (1968); 3.5% real
growth rate (1971)
Agriculture: main products—sugarcane, citrus fruits,
corn, molasses, rice, beans, bananas, livestock products; net
importer of food; caloric intake, 2,500 calories per day per
capita
Major industries: timber and forest products, food
processing, furniture, rum, soap
Electric power: 16,000 kW capacity (1977); 32 million
kWh produced (1977), 215 kWh per capita
Exports: $73 million (f.o.b., 1975); sugar,
clothing, lumber, citrus fruits, fish
Imports: $86 million (c.i.f., 1975); vehicles, building
materials, petroleum, food, textiles, machinery
Major trade partners: exports—U.S. 30%, U.K. 24%,
Mexico 22%, Canada 13%; imports—U.S. 34%, U.K. 25%,
Jamaica 7% (1970)
Aid: economic—U.S. authorizations (FY46-76), $7.6 mil-
lion in grants; from international organizations (1946-76),
$2.3 million
Monetary conversion rate: 2 Belize dollars=US$1
Fiscal year: calendar year
GNP: $5,485 million (1977 est.), $840 per capita; 82%
private consumption, 6% government consumption, 15%
domestic investment (1975), —8% net foreign balance
(1976); average annual real growth rate (1971-76), 5.3%
Agriculture: main products—coffee, cotton, corn, beans,
sugarcane, bananas, livestock; caloric intake, 2,200 calories
per day per capita (1967)
Fishing: catch 5,000 metric tons (1975); exports $2.6
million (1973), imports $0.7 million (1973)
Major industries: food processing, textiles and clothing,
furniture, chemicals, nonmetallic minerals, metals
Electric power: 365,000 kW capacity (1977); 1.5 billion
kWh produced (1977), 240 kWh per capita
Exports: $782 million (f.0.b., 1976); coffee, cotton, sugar,
bananas, meat
Imports: $905 million (f.0.b., 1976); manufactured prod-
ucts, machinery, transportation equipment, chemicals, fuels
Major trade partners: exports (1974)—34% U.S., 28%
CACM, 11% West Germany, 5% Japan; imports (1974)—
31% U.S., 17% CACM, 12% Venezuela, 9% Japan, 8% West
GDP: $72.5 billion (1977 est.), $1,160 per capita; 66%
private consumption, 16% public consumption, 18% private
investrnent, 7% public investment (1976); net foreign
balance — 2%; real growth rate 1977, 2.8% est.
Agriculture: main crops—corn, cotton, wheat, coffee,
sugarcane, sorghum, oilseeds, pulses, and vegetables; general
self-sufficiency with minor exceptions in meat and dairy
products; caloric intake, 3,110 calories per day per capita
(1968)
Fishing: catch 515,000 metric tons (1976); exports valued
at $151.3 million, imports at $17.8 million (1975)
Major industries: processing of food, beverages, and
tobacco; chemicals, basic metals and metal products,
petroleum products, mining, textiles and clothing, and
transport equipment
Crude steel: 9.0 million metric tons capacity (1977); 5.5
million metric tons produced (1977)
135
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
0010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A00090
July 1978
MEXICO/MONACO
Electric power; 13,900,000 kw capacity (1977); 49.4
billion kWh produced (1977), 755 kWh per capita
Exports: $4,596 million (f.0.b., 1977); cotton, coffee,
nonferrous minerals (including lead and zinc), sugar, shrimp,
petroleum, sulfur, salt, cattle and meat, fresh fruit, tomatoes,
machinery and equipment
Imports: $5,487.55 million (c.i.f,, 1977); machinery,
equipment, industrial vehicles, and intermediate goods
Major trade partners: exports—63% US., 5% EC, 2%
Japan (1977); imports—64% US., 15% EC, 5% Japan
from US. (FY46-76), $14 mhillion
Budget: 1978 federal, revenues
expenditures $634 billion pesos
$434 billion Desos,
Monetary conversion rate: floating
Fiscal year: calendar year','d557170560acc9cb4e78f57ab930e3b4e4204e62ac365d7f46965419491eca99','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ea1d01fc7223e7a7509ce547714854555f24283442a115ab2fef255238651de',1978,'BJ','Benin','economy',65,'GNP: $660 million (1977 est.), $200 per capita; no real
growth during 1970-1974
Agriculture: major cash crop is oil palms; peanuts, cotton,
coffee, sheanuts, and tobacco also produced commercially;
main food crops—corn, cassava, yams, sorghum and millet;
livestock, fish
Fishing: catch 21,415 metric tons (1976); exports 600
metric tons, imports 8,875 metric tons (1975)
Major industries: palm oil and palm kernel oil processing
Electric power: 11,000 kW capacity (1977); 55 million
kWh produced (1977), 20 kWh per capita
Exports: $106 million (f.0.b., 1977); palm products (34%);
other agricultural products
Imports: $264 million (cif, 1977); clothing and other
consumer goods, cement, lumber, fuels, foodstuffs, machin-
ery, and transport equipment
Major trade partners: France, EC, franc zone; preferen-
tial tariffs to EC and frane zone countries
Aid: economic (through FY75)—EC, $67.1 million; U.N.,
$12.5 million; other international organizations, $36.2
million; Taiwan, $1 million; U.S. (FY46-76), $18.1 million;
China, $44 million extended (1972)
Budget: 1977 est.—receipts $110 million, expenditures
$109 million
Monetary conversion rate: 242.69 Communaute Finan-
ciere Africaine (CFA) francs=US$1 as of November 1977
Fiscal year: calendar year','7c6098b66e9df44c9cef5c366fcd191fe7a5325326e691e3277dc51288bd6995','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7217e9141687a3995c2474add9536dff76bce14d45f60ccb8744f39956636fcf',1978,'BM','Bermuda','economy',69,'GNP: $300-$350 million (at market prices,
$5,000-$6,000 per capita
Agriculture: main products—bananas, vegetables, Easter
lilies, dairy products, citrus fruits
1974),
Major industries: tourism, finance
Electric power: 86,200 kW capacity (1977); 300 million
kWh produced (1977), 5,260 kWh per capita
Exports: $34 million (f.0.b., 1975); mostly reexports of
drugs and bunker fuel
Imports: $162 million (£.0.b., 1975); fuel, foodstuffs,
machinery
Major trade partners: 45% U.S., 22% U.K., 9% Canada
(1974)
Monetary conversion rate: 1 Bermuda dollar=US$1
Fiscal year: | April-31 March','336c597fdf60263d4f69868523b418e67d9ae4b467e5cb1bcc9699e2ded407d4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb4b0cb3180b428a33b6c1efbcb7227c146a29cd4d45bf2229d0ea304f87265f',1978,'BT','Bhutan','economy',73,'GNP: $90 million (1976); $70 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 3,000 kW capacity (1977); 8 million kWh
produced (1977), 10 kWh per capita
Exports: about $1 million annually; rice, dolomite, and
handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic—India (FY61-72), $180 million
Monetary conversion rate: both ngultrums and Indian
rupees are legal tender; 8.77 ngultrums=8.77 Indian
rupees=US$1 as of October 1975
Fiscal year: 1 April-31 March
GNP: $3.5 billion (1977, in 1977 dollars), $600 per capita;
69% private consumption, 17% public consumption, 20%
gross domestic investment, —6% net foreign balance (1976);
real growth rate (1972-76), average 6.4%; 1976 growth, 6.0%
Agriculture: main crops—potatoes, corn, rice, sugarcane,
yucca, bananas; imports significant quantities of wheat;
caloric intake, 70% of requirements (1976)
Major industries: mining, smelting, petroleum refining,
food processing, textiles, and clothing
Electric power: 367,000 kW capacity (1977); 1.1 billion
kWh produced (1977), 277 kWh per capita
Exports: $640 million (f.0.b., 1977 est.); tin, petroleum,
lead, zinc, silver, tungsten, antimony, bismuth, gold, coffee,
sugar, cotton, natural gas
Imports: $670 million (c.i.f., 1977); foodstuffs, chemicals,
capital goods, pharmaceuticals, transportation
Major trade partners: exports—Western Europe, 19% (of
which UK is largest market); Latin America, 38%; U.S., 30%;
Japan, 3.9%; imports—U.S., 24%; Western Europe, 15.4% (of
which West Germany is largest supplier); Japan, 15.7%;
Latin America, 33.6% (1975)
Aid: economic—extensions from U.S. (FY46-76), $335
million in loans, $342 million in grants; from international
organizations (FY46-75), $372 million; from other Western
countries (1960-75), $53.8 million; Communist countries
(1970-74), $59.7 million; military—assistance from U.S.
(FY52-76), $70 million
22
Budget: $474 million revenues, $583 million expenditures
(1978)
Monetary conversion rate: 20 pesos=US$1
Fiscal year: calendar year','ee0883b8952c8d7eaec758cc363330e951158b54043ca30093d9b7fce7aca322','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77b46b65c3349c88e89b8dc9ebc54d603c8740962d813a91045240fe11171777',1978,'BW','Botswana','economy',77,'GDP: $300 million (1975 est.), growth in constant prices,
less than 5% in 1977
Agriculture: principal crops are corn and sorghum;
livestock raised and exported
Major industries: livestock processing, mining of dia-
monds, copper, nickel, and coal
Electric power: 75,000 kW capacity (1977); 85 million
kWh produced (1977), 120 kWh per capita
Exports: $176 million (1976); cattle, animal products,
minerals
Imports: $209 million (1976); foodstuffs, vehicles, textiles,
petroleum products
Major trade partners: South Africa and U.K.
Budget: (1977) revenue $107 million ($78 million from
domestic taxes and $29 million from borrowing and foreign
aid), current expenditures $70 million, investment expendi-
tures $44 million
Monetary conversion rate: 1 pula=about US$1.20 as of
October 1977
Fiscal year: 1 April-31 March','2d1ccce49662f644c328300d199e60f26b45185aa552a17292d3ef1d749fe2e4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56f9cfa5dec47e538b87a8831eff31ea8ee406522348ff9466b37419927169cc',1978,'BR','Brazil','economy',81,'GNP: $163 billion (est. 1977 in 1977 prices), $1,430 per
capita; 25% gross investment, 80% consumption, —5% net
foreign balance (1976); real growth rate 4.78% (1977)
Agriculture: main products—coffee, rice, beef, corn,
milk, sugarcane, soybeans; nearly self-sufficient; caloric
intake, 2,900 calories per day per capita (1962)
Fishing: catch 674,500 metric tons (1975); exports, $46.6
million (f.0.b. 1974), imports, $57.8 million (f.0.b. 1974)
Major industries: textiles and other consumer goods,
chemicals, cement, lumber, steel, motor vehicles, other
metalworking industries
Crude steel: 12.0 million metric tons capacity (1977 est.);
11.2 million metric tons produced (1977); 80 kg per capita
Electric power: 24,500,000 kW capacity (1977); 85 billion
kWh produced (1977), 750 kWh per capita
Exports: $12,139 million (f.0.b., 1977); coffee, manufac-
tures, iron ore, cotton, soybeans, sugar, wood, cocoa, beef,
shoes
Imports: $11,999 million (c.i-f., 1977); machinery, chemi-
cals, pharmaceuticals, petroleum, wheat, copper, aluminum
Major trade partners: exports—16% US., 6% Japan, 9%
West Germany, 7% Netherlands, 4% Italy, 4% U.K.;
imports—25% U.S., 9% West Germany, 8% Japan, 3% Italy,
3% U.K. (1976)
Aid: economic—extensions from U.S. (FY46-76), loans
$1.7 billion, grants $690 million; from international organi-
zations (F Y46-75), $4.1 billion; from other Western countries
(1960-71), $617.0 million; from Communist countries
(1959-76), $499 million; drawings (1959-76), $160 million
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
. BRAZIL/BRUNEI
Budget: (1977) revenues $17.2 billion, expenditures $17.1
billion
Monetary conversion rate: 16.50 cruzeiros=US$1 (Feb-
ruary 1978, changes frequently)
Fiscal year: calendar year
GNP: $460 million (1975 est.), $2,970 per capita
Agriculture: main crops—rubber, rice, pepper, must
import most food
Major industry: crude petroleum, liquefied natural gas
Electric power: 84,000 kW capacity (1977); 230 million
kWh produced (1977), 1,300 kWh per capita
Exports: $1,000 million (f.0.b., 1975); 95% crude petro-
leum and liquefied natural gas
Imports: $200 million (c.i.f., 1975); 25% machinery and
transport equipment, 46% manufactured goods, 16% food
Major trade partners: exports of crude petroleum and
liquefied natural gas to Japan; imports from Japan 30%, U.S.
24%, U.K. 15%, Singapore 9%
25
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
BRUNEI/BULGARIA
Budget: (1976) revenues $640 million, expenditures $250
million, surplus $390 million; 20% defense
Monetary conversion rate: 2.5 Brunei dollars=US$1
Fiscal year: calendar year
GNP: $412 million (1976), $526 per capita; real growth
rate 1976, 1.9% est.
Agriculture: main crops—sugarcane, rice, other food
crops; food shortages—wheat flour, cooking oil, processed
meat, dairy products; caloric intake, 2,180 calories per day
per capita (1967)
Fishing: catch 20,123 metric tons (1975); exported 4,445
metric tons valued at $3 million in 1975
Major industries: bauxite mining, alumina production,
sugar and rice milling, timber
Electric power: 175,000 kW capacity (1977); 370 million
kWh produced (1977), 495 kWh per capita
Exports: $257 million (f.0.b., 1976); bauxite, sugar,
alumina, rice, shrimp, molasses, timber, diamonds, rum
Imports: $371 million (c.i.f., 1976); manufactures, ma-
chinery, food, petroleum
Major trade partners: exports—27.4% U.K., 20.5% U.S.,
16.8% CARICOM, 2.4% Canada; imports—28% U.S., 23%
U.K., 22% CARICOM, 4% Canada (1976)
Aid: economic—authorizations from U.S. (FY53-76), $55
million in loans, $26 million in grants; commitments from
Communist countries—China (1972-76), $36 million in
loans, and East Germany (1974), $10 million in loans; from
international organizations (FY46-76), $69 million
Budget: revenue, $186 million; expenditure, $312 million
(1976)
Monetary conversion rate: floating with US dollar, 1
US$=G $2.55
Fiscal year: calendar year','dc66783be21a841012b49c6d1af6bb6fa832a8983c682fe9eda974b61701bfbd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19797a6cd3ac9d3500a5581d522675a499083cbe37b4f908d64f8700517c1c7c',1978,'BG','Bulgaria','economy',85,'GNP: $20.9 billion, 1977 (at 1976 dollars), $2,373 per
capita; 1977 real growth rate, 0.4%
Agriculture: mainly self-sufficient; main crops—grain,
vegetables; caloric intake, 3,000 calories per day per capita
(1969/70)
Fishing: catch 160,000 metric tons (1976)
Major industries: agricultural processing, machinery,
textiles and clothing, mining, ore processing, timber
Shortages: some raw materials, metal products, meat and
dairy products; fodder
Crude steel: 2.6 million metric tons produced (1977), 292
kg per capita
Electric power: 7,300,000 kW capacity (1977); 29.7
billion kWh produced (1977), 3,855 kWh per capita
Exports: $6,330 million (f.0.b., 1977); 46% machinery,
equipment, and transportation equipment, 15% fuels,
minerals, raw materials, metals, and other industrial
material; 2% agricultural raw materials; 29% foodstuffs, raw
materials for food industry, and animals; 10% industrial
consumer goods (1977)
Imports: $6,346 million (f.0.b., 1977 est.); 39% machinery,
equipment, and transportation equipment; 45% fuels,
minerals, raw materials, metals, other materials; 7% agricul-
tural raw materials; 4% foodstuffs and animals; 5% industrial
consumer goods (1977)
Major trade partners: $12,676 million in 1977; 20% with
non-Communist countries, 56% with U.S.S.R., 24% with
other Communist countries
Monetary conversion rate: 0.948 leva=US$1 (1977)
Fiscal year: calendar year; economic data reported for
calendar years except for caloric intake, which is reported
for consumption year 1 July-30 June
NOTE: Foreign trade figures were converted at the 1977
rate of 0.948 leva=US$1
GDP: $8.7 billion (FY77, in current prices), $117 per
capita; real growth rate 6% (FY77); 3.9% over past decade
Agriculture: accounts for nearly 70% of total employment
and about 27% of GDP: main crops—paddy, sugarcane,
corn, peanuts; almost 100% self-sufficient; most rice grown
in deltaic land
Fishing: catch 500,000 metric tons (1976)
Major industries: agricultural processing; textiles and
footwear; wood and wood products; petroleum refining
Electric power: 450,000 kW capacity (1977); 890 million
kWh produced (1977), 30 kWh per capita
Exports: $218 million (f.o.b., 1978); rice, teak
Imports: $174 million (c.if., 1978); machinery and
transportation equipment, textiles, other manufactured
goods
Major trade partners: exports—India, Western Europe,
China, U.K., Japan; imports—Japan, Western Europe, India,
U.K.
Budget: (FY78) $2.765. billion revenues; $2.975 billion
expenditures; $210 million deficit; 30% military, 70%
civilian
Monetary conversion rate: 7.3194 kyat=US$1 (official)
Fiscal year: 1 April-31 March','1f1adc86f0e95ce3c10f24ed25755eec8db292474bb2391871da25f909044e9c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ea3b66c219496af5a4c8ebb59072469e5f85ec1b875e0101a3c699f12c83d04',1978,'BI','Burundi','economy',89,'GNP: about $450 million (1976), $120 per capita; 2% real
growth (1970-74); real GDP growth in 1976, 7%
Agriculture: major cash crops—coffee, cotton, tea; main
food crops—manioc, yams, corn, sorghums, bananas, haricot
beans; marginally self-sufficient
Industries: light consumer goods such as beverages,
blankets, shoes, soap, assembly of imports
Electric power: 7,500 kW capacity (diesel generator
1977); 25 million kWh produced (1977), 6 kWh per capita
Exports: $125 million (f.0.b., 1977 est.); coffee (90%), tea,
cotton, hides, skins
Imports: $75 million (c.i.f., 1977 est.); textiles, foodstuffs,
transport equipment, petroleum products
Major trade partners: U.S., EEC countries
Aid: $40 million all donors (1975 est.), major donors EC,
IBRD/IDA, U.N.
Budget: FY77—revenue $47 million, current expenditure
$48 million
Monetary conversion rate: 90 Burundi francs=US$1
(official)
Fiscal year: calendar year','ef10dd47550f781aa9fbe5781823f8e56fc18eeb2b8be19551cf2b367847e653','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ec770fce353c3dd5273935a080622cd7715539c501cc7efbaa4d198e475ee15',1978,'KH','Cambodia','economy',93,'GNP: less than $500 million (1971), probably less than $70
per capita (1976)
Agriculture: mainly subsistence except for rubber planta-
tions; main crops—rice, rubber, corn; food shortages—rice,
meat, vegetables, dairy products, sugar, flour
Major industries: rice milling, fishing, wood and wood
products
Shortages: fossil fuels
Electric power: 120,000 kW capacity (1977); 260 million
kWh produced (1977), 30 kWh per capita
Exports: probably less than $1 million est. (1977); rubber,
rice
Imports: probably less than $20 million (1976); food, fuel,
machinery
Major trade partners: exports—China, Thailand; im-
ports—China, North Korea
Aid: commitments (1970-76): U.S. economic, $652 mil-
lion; military, $1,260 million; Western (except U:S.), $10.8
million; Eastern Europe, $17 million; ULS.S.R., $25 million;
China, $90 million; military—U.S., $1,334 million (FY46-76)
30
Budget: no budget data available since Communists took
over government
Monetary conversion rate: not announced yet by new
Khmer Rouge government
Fiscal year: calendar year','bce16f12cddf94a5a1759a09042a7d392723eeacb84d3b3551d60628c0df9310','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21399a7558b14aeb6aba4f668b0bc07d7de688fa15981ef1c519ce35744bcc4c',1978,'CM','Cameroon','economy',97,'GDP: $2,500 million (mid 1977), per capita about $310,
real growth rate about 4.9% per annum (mid 1970-mid
1977)
Agriculture: commercial and food crops—cocoa, coffee,
timber, cotton, rubber, bananas, peanuts, palm oil and palm
kernels; root starches, livestock, millet, sorghum, and rice
Approved For Release 2005/04/22
Fishing: imports 7,024 metric tons, $2.2 million; exports
909 metric tons (largely shrimp), $3.5 million (1975)
Major industries: small aluminum plant, food processing
and light consumer goods industries, sawmills
Electric power: 358,000 kW capacity (1977); 1,347
million kWh produced (1977), 200 kWh per capita
Exports: $615 million (f.0.b., FY77); cocoa and coffee
about 60%; other exports include timber, aluminum, cotton,
natural rubber, bananas, peanuts, tobacco, and tea
Imports: $658 million (c.if., FY77); consumer goods,
machinery, transport equipment, alumina for refining,
petroleum products, food and beverages
Major trade partners: about 70% of total trade with
France and other EC countries; about 5% of total trade with
US.
Budget: FY78 budget est. balanced at $560 million
Monetary conversion rate: 242.69 Communaute Finan-
ciere Africaine francs=US$1 as of November 1977
Fiscal year: 1 July-30 June','33bec6d5f784e2c462b2bbcae4d34b7bc394584c6f4cfd45273675d157005248','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa9b6796c33f1e2d7ee5ad0257f63f8cd2082c6fbbd653aa7607b3e6cfd35a3d',1978,'CA','Canada','economy',101,'GNP: $195.3 billion (1977, in 1977 Prices), $8,394 per
capita (1977); 58.7% consumption, 22.5% investment, 19.2%
government (1977); growth rate 4.0% (1970-77, constant
prices)
Agriculture: main products—livestock, grains (principally
wheat), dairy products; food shortages—fresh fruits and
vegetables; caloric intake, 3,180 calories per day per capita
(1966-67)
Fishing: catch 1.065 million metric tons; exports 296,773
metric tons (1976)
Major industries: mining, metals, food products, wood
and paper products, transportation equipment, chemicals
Shortages: rubber, rolled steel, fruits,
instruments
precision
Crude steel: 13.1 million metric tons produced (1976)
Electric power: 73 million kW capacity (1977): 244
million kWh produced (1977), 12,794 kWh per capita
Exports: $45,965 million (f.0.b., 1977, source: LF-.S.);
principal items—transportation equipment, wood and wood
products including paper, ferrous and nonferrous ores, crude
petroleum, wheat; Canada is a maior food exporter
Imports: $44,630 million (c.i.f., 1977, source: LF-S.);
principal items—transportation equipment, machinery,
crude petroleum, communication equipment, textiles, steel,
fabricated metals, office machines, fruits and vegetables
Major trade partners: 68% US. 10% EC, 5% Japan
(1976)
Aid: economic-—(received) U.S., $3888 million (F Y46-75);
gross official aid to less developed countries and multilateral
agencies, $3,688 million (1960-73), $637 million (1973);
military—U.S., $13 million (FY49-76), none since 196]
-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CANADA/CAPE VERDE
Budget: total revenues $33,781 million; current expendi-
tures $39,930 million; gross capital formation $6,833 million;
budget deficit $6,149 million (1977) (National Accounts
Basis)
Monetary conversion rate: there is no designated par
value for the Canadian dollar, which was allowed to float
freely on the exchanges beginning 1 June 1970; since then
the Canadian dollar has moved between US$0.86-1.04 in
value, 1977 average 1C$=US$0.9400
Fiseal year: 1 April-31 March
GDP: $50 million (1975 est.); $170 per capita income
Agriculture: main crops—corn, beans, manioc, sweet
potatoes; barely self-sufficient in food
Fishing: catch, 4,400 metric tons (1975); largely undevel-
oped but provides major source of export earnings
Major industries: salt mining
33
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CAPE VERDE/CENTRAL AFRICAN EMPIRE
Electric power: 6,000 kW capacity (1977); 7 million kWh
produced (1977); 20 kWh per capita
Exports: $2.5 million (f.0.b., 1975); fish, bananas, salt
Imports: $31 million (c.i.f., 1975); machinery, textiles
Major trade partners: Portugal, U.K., Japan, African
neighbors
Aid: Portugal, $30 million (1975), for civil service salaries,
food, medicines; U.S., $7.2 million (1946-76), for food and
employment of rural workers; Netherlands, Scandinavian
countries, UNDP
Budget: (est. 1976) $30 million expenditures, $15 million
revenues
Monetary conversion rate: 40.643 escudos=US$1
(November 1977)
Fiscal year: probably calendar year
GDP: $394 million (1976), $220 per capita
Agriculture: commercial—cotton, coffee, peanuts, ses-
ame, wood; main food crops—manioc, corn, peanuts, rice,
potatoes, beef; requires wheat, flour, rice, beef, and sugar
imports
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CENTRAL AFRICAN EMPIRE/CHAD
Major industries: sawmills, cotton textile mills, brewery,
diamond mining and splitting
Electric power: 44,000 kW capacity (1977); 106 million
kWh produced (1977), 56 kWh per capita
Exports: $100 million (f.0.b., 1977 est.); cotton, coffee,
diamonds, timber
Imports: $100 million (f.0.b., 1977 est.); textiles, petrole-
um products, machinery and electrical equipment, motor
vehicles and eauipment, chemicals and pharmaceuticals
Aid: economic (1946-76) —U.S., $9.6 million; EC, $73.8
million; U.N., $11.5 million; other international organiza-
tions, $23.4 million; Communist countries (1964-75), $7.2
million
Major trade partners: France; preferential tariff applied
to EC countries and franc zone; Yugoslavia, Japan, U.S.
Budget: est. 1977 budget receipts and grants $68 million,
expenditures $81 million
Monetary conversion rate: 242.69 Communaute Finan-
ciere Africaine francs=US$1 as of November 1977
Fiscal year: calendar year','603557a09624d8c7ab6d2cc8efe00d42540751f484f04911c25133e108e2b8b8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07f547b7353688e61fca4116e6cea7982930230792902c3924ba09390f253432',1978,'TD','Chad','economy',105,'GDP: $292 million (est. 1976), $75 per capita; estimated
real annual growth rate nearly zero since 1971
Agriculture: commercial—cotton, gum arabic, livestock,
fish; food crops—peanuts, millet, sorghum, rice, dates,
manioc, wheat; imports food
Fishing: catch 115,000 metric tons (1975)
Major industries: agricultural and livestock processing
plants (cotton textile mill, slaughterhouses, brewery), natron
Electric power: 22,000 kW capacity (1977); 60 million
kWh produced (1977), 15 kWh per capita
Exports: $45 million (f.0.b., 1976); cotton 67%
Imports: $124 million (cif, 1976); cement, petroleum,
foodstuffs, machinery, textiles, and motor vehicles
Major trade partners: France (about 40% in 1973) and
UDEAC countries; preferential tariffs to EC and franc zone
countries
Aid: major source France, more than $10 million
(1971-73); EDF, more than $15 million (1971-73); USS.
(FY46-76), $29.4 million; U.S.S.R., $5.0 million (1968-76);
China, $67.6 million (1971-76); military aid (1955-76)—$7.0
million; from France, $4.1 million, remainder from West
Germany and Israel; more than $10 million annually (est.) in
French military aid (1969-71)
Budget: 1977 ordinary budget—$70 million
Monetary conversion rate: 242.69 Communaute Finan-
ciere Africaine francs=US$1 as of November 1977
Fiscal year: calendar year','cc2f8315644416dc0cb24c09b115070ad7ad98c703d2b2fdeac5da11c9b3f85f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('976e47981b051e19b4060786f23a85cf04dd80eab3c10bca0340c6f78c70a88b',1978,'CL','Chile','economy',109,'GDP: $9.4 billion (1977 in 1976 prices), $886 per capita;
79.1% private consumption, 11.9% government consump-
tion; 12.1% gross investment, —6.3.1% net imports and
factor payments abroad (1976 est.); real growth rate, 1977,
8.6%; 1972-77 average annual increase, negligible
Agriculture: main crops—wheat, other cereals, potatoes,
fruits; about 85% self-sufficient; 2,650 calories per day per
capita (1971 est.)
Fishing: catch 1.5 million metric tons (1977); exports $94
million (1977)
Major industries: copper, nitrates, foodstuffs, fish proc-
essing, textiles and apparel, iron and steel, pulp and paper
Crude steel: 0.7 million metric tons capacity (1967);
450,000 metric tons produced (1976), 42 kg per capita
Electric power: 2,775,000 kW capacity (1977); 9.73
billion kWh produced (1977), 910 kWh per capita
Exports: $2.2 billion (f.0.b., 1977); copper, iron ore, paper
products, nitrates, iodine, and fresh fruit
Imports: $2.3 billion (c.i.f., 1977); foodstuffs, petroleum,
machinery and equipment, chemicals
Major trade partners: exports—17% EC, 14% Japan, 13%
U.S., 89% LAFTA; imports—15% EC, 21% US., 33%
LAFTA, 12% Japan (1977)
Aid: economic—extensions from U.S. (FY46-76), $1,506
million loans, $313 million grants; from international
organizations (FY46-75), $720 million (of which IBRD $266
million, IDB $409 million); from other Western countries
(1960-66), $170.6 million; from Communist countries
(1967-76), $447.7 million; military (FY53-75)—from USS.,
$62 million in loans, $154 million in grants
Budget: $2.5 billion revenues, $2.8 billion expenditures
(1977)
Monetary conversion rate: 29.12 pesos=US$1 (February
1978), changes frequently
Fiscal year: calendar year
GNP: $350 billion (1977), $362 per capita
Agriculture: main crops—rice, wheat, miscellaneous
grains, cotton; caloric intake, 2,000 calories per day per
capita (1977); agriculture mainly subsistence; grain imports
6.75 million metric tons in 1977
Major industries: iron and steel, coal, machine building,
armaments, textiles, petroleum
Shortages: complex machinery and equipment, highly
skilled scientists and technicians
Crude steel: 25 million metric tons produced, 26 kg per
capita (1977)
Electric power: 42 million kW capacity (1977); 150
billion kWh produced (1977), 155 kWh per capita
Exports: $7.9 billion (£.0.b., 1977); agricultural products,
oil, minerals and metals, manufactured goods
Imports: $6.9 billion (c.if,, 1977); grain, chemical
fertilizer, steel, industrial raw materials, machinery and
equipment
Major trade partners: Japan, Hong Kong, West Germany,
France, Romania, U.S.S.R., Australia, U.S., Canada, Singa-
pore (1977)
Monetary conversion rate: as of 31 December 1977,
about 1.73 yuan=US$1 (arbitrarily established)
Fiscal year: calendar year','f88556341ba8393f9a63aa0e592e4fea84f1d56addcf9d24fc28af3e98a3a21a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42fc433264f3d79f49c432ce7a2186c31d26c0d7f88479e944e471c4d6cfe8f8',1978,'CN','China','economy',113,'GNP: $19.5 billion (1977, in 1977 prices), $1,168 per
capita; real growth, 8.3% (1970-76 average)
Agriculture: most arable land intensely farmed—60%
cultivated land under irrigation; main crops—rice, sweet
potatoes, sugarcane, bananas, pineapples, citrus fruits; food
shortages—wheat, corn, soybeans
Fishing: catch 854,784 metric tons (1977)
Major industries: textiles, clothing, chemicals, plywood,
electronics, sugar milling, food processing, cement, ship
building
Electric power: 7,000,000 kW capacity (1977); 29.7
billion kWh produced (1977), 1,765 kWh per capita
Exports: $9,361 million (f.0.b., 1977); 25% textiles, 15.9%
electrical machinery, 7.5% plywood and wood products, 7%
machinery and metal products, 7.5% plastics, 5% sugar
Imports: $8,511 million (c.i-f., 1977); 18% machinery, 9%
electrical machinery, 9% basic metals, 10% crude oil, 10%
chemical products
Major trade partners: exports—38.8% U.S., 11.9% Japan:
imports—31% Japan, 23% U.S. (1977)
Aid: economic—U.S. (FY46-76), $2.2 billion committed;
IBRD (1964-75), $311 million committed; Japan (1965-74),
$247 million committed; ADB (1968-75), $93 million
committed; military—U.S. (FY46-76), $4.3 billion com-
mitted
Central government budget: $3.5. billion (FY78)
Monetary conversion rate: NT$38 (New Taiwan)=US$1
Fiscal year: 1 July-30 June
Monetary conversion rate: 1.94 won=US$1, non-com-
mercial rate
Fiscal year: calendar year
GNP: $31.5 billion (1977, in 1977 prices), $864 per capita;
real growth 10.3% (1977); real growth 11.7% (1972-77
average)
Agriculture: 40% of the population live on the land, but
agriculture, forestry and fishery constitute 24% of GNP;
main crops-—rice, barley; not self-sufficient; food short-
ages—wheat, dairy products, corn
Fishing: catch 2,406,896 metric tons (1976)
Major industries: textiles and clothing, food processing,
chemical fertilizers, chemicals, plywood, steel, electronics
Shortages: base metals, petroleum, lumber and certain
food grains
Electric power: 6,500,000 kW capacity (1977); 27.2
billion kWh produced (1977), 735 kWh per capita
111
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
KOREA, SOUTH/KUWAIT
Exports: $10.0 billion (f.0.b., 1977); textiles and clothing,
electrical machinery, plywood, footwear, steel, ships
Imports: $10.8 billion (c.i-f., 1977); oil, ships, steel, wood,
wheat, organic chemicals, machinery
Major trade partners: exports—32% US., 21% Japan:
imports—35% Japan, 23% U.S. (1977)
Aid: economic—U.S. (FY46-77), $5.8 billion committed;
Japan (1965-75), $1.8 billion extended: military—U.S. (FY
46-77) $7.0 billion committed
Budget: $7.3 billion (1978)
Monetary conversion rate: rate fixed at 484 won= US$]
since December 1974
Fiscal year: calendar year','5c89baa6df74bee4175778594dca76bf8a7cc97ece0a2008e25b099934a9a763','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d778e03c3852e669ef8a980d75ecb31d4b22c5b8dae06724f3fe5cb000af1716',1978,'CO','Colombia','economy',117,'GNP: $16.32 billion, est. (1976, in 1976 prices), $710 per
capita; 76% private consumption, 7% public consumption,
18% gross investment, —9% net foreign balance (1975); real
growth rate (1977), 5.5%; average real growth rate (1972-76),
6.5%
Agriculture: main crops—coffee, rice, corn, sugarcane,
plantains, bananas, cotton, tobacco; caloric intake, 2,140
calories per day per capita (1970)
Fishing: catch 66,575 metric tons 1975; exports $10.6
million (1973), imports $10.3 million (1973)
Major industries: textiles, food processing, clothing and
footwear, beverages, chemicals, and metal products
Crude steel: 356,000 metric tons produced (1976), 15 kg
per capita
41
July 1978
COLOMBIA/ COMOROS
Electric power: 4,650,000 kw Capacity (1977): 13.8
billion kwh produced (1977), 540 kWh per capita
Exports: $1,866 million (f.0.b., 1977); coffee, fuel oil,
cotton,. tobacco, Sugar, textiles, cattle and _ hides
Imports: $1,991 million (f.0.b., 1977); transportation
equipment, machinery, industrial metals and raw materials,
chemicals and pharmaceuticals, fuels, fertilizers, Paper and
Paper products, foodstuffs and beverages
Major trade Partners; exports—48% Japan, 27% US.
16% Germany, 10% Venezuela, 6% Netherlands, imports—
38% US. 9% Germany, 8% Japan, 5% Ecuador (1976)
Aid: economic—extensions from U.S. (FY 46-76), $99)
million loans,
tries (1968-75), $89 million ($2.7 million drawn); military—
assistance from US. (FY 46-76), $130 million
Budget: (1978) revenues $2.09 billion; expenditures $2.30
billion
Monetary conversion rate: 37.70
(November 1977, changes frequently)
Fiscal year: calendar year','375811b64513fa5dbed83d580bb0e290db8d77e85198b7022131fbc5a1fcd3e9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45a58d547f2427b0e5f9b002cd00428a820f43392a04343c49b85452d60b8c46',1978,'KM','Comoros','economy',121,'GDP: $69.5 million (1975), about $200 per capita; growth
probably negligible through 1974
Agriculture: food crops—rice, manioc, maize, fruits,
vegetables; export crops—essential oils for perfumes (mainly
ylang-ylang), vanilla, copra, cloves
Exports: $10.3 million (f.0.b., 1976); perfume oils, vanilla,
copra, cloves
Imports: $13.9 million (c.i.f., 1976); foodstuffs, cement,
fuels, chemicals, textiles
Major trade partners: France, Malagasy Republic, Italy,
Kenya, Tanzania and U.S.
Electric power: 2,400 kW capacity (1977); 3 million kWh
produced (1977); 10 kWh per capita
Aid: French aid in 1971 was about $2.7 million, or about
50% of the island’s entire budget; Arab League, $10 million
in 1976
Budget: 1977 projected—revenues, $5 million; current
expenditures, $11 million; investment expenditures, $5
million
Monetary conversion rate: 242.69 Communaute Finan-
ciere Africaine (CFA) francs=US$1 as of November 1977,
floating','8b9333ae4f13eab415228265e7f962b5b62f940fe9ddf1a3c987747a297c6676','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('663f795351d157629a1cf9e08ba2db398abedb3c111f090d3c5ee7ceb6740d2c',1978,'CG','Congo','economy',125,'GDP: about $700 million (1977 est.), $524 per capita: real
growth rate about 3% per year (1970-77)
Agriculture: cash crops—sugarcane, wood, coffee, cocoa,
palm kernels, peanuts, tobacco; food crops—root ‘crops, rice,
corn, bananas, manioc, fish
Fishing: catch 15,674 metric tons (1975)
Major industries: crude oil, sawmills, brewery, cigarettes,
sugar mill, soap
Electric power: 63,200 kW capacity (1977); 130 million
kWh produced (1977), 90 kWh per capita
Exports; $214 million (f.0.b., 1977 est.); oil (58%), lumber,
sugar, tobacco, veneer, and plywood
Imports: $266 million (f.0.b.. 1977 est.);_ machinery,
transport equipment, manufactured consumer goods, iron
and steel, foodstuffs, petroleum products
Major trade partners: France and other EC countries
Budget: 1977 est.—revenue $216 million, expenditures
$240 million
Monetary conversion rate: 242.69 Communaute Finan-
ciere Africaine francs=US$1 as of November 1977
Fiscal year: calendar year','5e6a5de9c2d7f61e905d6e5ae546b6df169c27b486719632c3aa2f113e98a3df','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23819172c88fe747fca51df548bcd1ec67e3fd192556a3ad41f05cdc28403802',1978,'CK','Cook Islands','economy',129,'GDP: $400 per capita (1973)
Agriculture: export crops include copra, citrus fruits,
pineapples, tomatoes, and bananas, with subsistence crops of
yams and taro
Industry: fruit processing
Electric power: 3,000 kW capacity (1977); 10 million
kWh produced (1977), 525 kWh per capita
Exports: $2.7 million (1971); fruit juice, clothing, citrus
fruits
Imports: $5.8 million (1971)
Major trade partners: (1970) exports—98% New Zealand,
imports—76% New Zealand, 7% Japan
Monetary conversion rate: 1 NZ$=US$0.9947 (July
1976)','928b6e9289fa7fe9360ec369fa41a74646248ac8fdfb64e41a504d7ba5f3e820','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86d861ad8714fd38aa9d285d170b1b23600a53aec4af7d7bef11ca5b66addc45',1978,'CR','Costa Rica','economy',133,'GDP: $2.3 billion (1976, in 1976 dollars), $1,135 per
capita; 72% private consumption, 17% public consumption,
23% gross domestic investment, — 12% net foreign balance
(1975); real growth rate 1977, 6.9%: average growth
(1972-76), 6.0%
Agriculture: main products—bananas, coffee, sugarcane,
Tice, corn, cocoa, livestock products; caloric intake, 2.610
calories per day per capita (1966)
Fishing: catch 15,695 metric tons (1975); exports, $3.7
million (1974), imports, $0.6 million (1974)
Major industries; food Processing, textiles and clothing,
construction materials, fertilizer
Electric power: 410,000 kw capacity (1977); 1.7 billion
kWh produced (1977), 855 kWh per capita
Exports: $770 million (f.0.b., 1977); coffee, bananas, beef,
sugar, cacao
Imports: $840 million (c.i.f,, 1977); manufactured prod-
ucts, machinery, transportation equipment, chemicals, fuels,
foodstuffs, fertilizer
Major trade Partners: exports—32% U.S. 24% CACM,
13% West Germany; imports—34% US., 16% CACM, 6%
West Germany, 10% Japan (1974)
Aid: economic—extensions from US. (FY46-75), $138
million loans, $117 million grants; from international
organizations (FY46-75), $349 million; from other Western
countries (1960-71), $7.7 million; military—assistance from
US. (F Y60-76), $2.0 million; Communist (economic) from
US.S.R., $17 million (1971)
Monetary conversion rate: 8.57 colones= US$]
Fiscal year: calendar year
GDP: $8.0 billion (1976 est., in 1976 prices), $830 per
capita; 60% private consumption, 20% public consumption,
20% gross investment, real growth rate 1976, 3.5%
Agriculture: main crops—sugar, tobacco, coffee, rice,
potatoes, tubers, citrus fruits
Fishing: catch 183,000 metric tons (1976); exports $63
million (1975), imports $24.4 million (1978)
Major industries: sugar milling, petroleum refining, food
and tobacco processing, textiles, chemicals, paper and wood
products, metals
Shortages: spare parts for transportation and industrial
machinery, consumer goods
Crude steel: 0.35 million metric tons capacity (planned);
240,000 metric tons produced (1975); 25 ke per capita
Electric power: 1,936,000 kW capacity (1977); 6.6 billion
kWh produced (1977), 700 kWh per capita
Exports: $3.3 billion (f.0.b., 1976); sugar, nickel, tobacco
Imports: $3.7 billion (c.if., 1976); capital goods, industrial
raw materials, food, petroleum
Major trade partners: exports—65% US.S.R., 15% other
Communist countries; imports—49% USSR, 14% other
Communist countries, 6% Spain (1976)
Budget: $11.1 billion
Monetary conversion rate: 1 peso=US$1.21 (nominal)
Fiscal year: calendar year','e180ceb062fea9917bd03e29f7a84433441832dfebeae47edc28d5a0598a8c3d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b24a552a47a3cf89e33afdf0bb2d872309ffe50f745e10ee2f085d841cc957cf',1978,'CY','Cyprus','economy',137,'GNP: $789.3 million (1976), $1,580 per capita; 1976 real
growth rate 14.6%
Agriculture: main crops—vine products, citrus, potatoes,
other vegetables; food shortages—grain, dairy products,
meat, fish; caloric intake, 2,460 calories per day per capita
(1964-66)
Major industries: mining (cupreous and iron pyrites,
asbestos), manufactures principally for local consumption—
food, beverages, footwear, clothing, cement
Shortages: water, petroleum
Electric power: 338,000 kW capacity (1977); 880 million
kWh produced (1977), 1,875 kWh per capita
Exports: $319 million (f.o.b., 1977, converted at average
trade conversion factor of 1 Cyprus pound =US$2.451);
principal items—asbestos, copper, pyrites, citrus, raisins, and
other agricultural products, potatoes, cement, clothing,
footwear, wine
Turkish Sector exports: $15.7 million (f.o.b., 1976, con-
verted at average conversion factor of 16.053 Turkish
lira=US$1); principal items—citrus fruits, potatoes, manu-
factured goods
Imports: $623 million (c.i.f., 1977, converted at average
trade conversion factor of 1 Cyprus pound=US$2.451);
principal items—manufactured goods, machinery and trans-
port equipment, petroleum products, foods
Turkish Sector imports: $65.9 million (c.i.f., 1976, con-
verted at average trade conversion factor of 16.053 Turkish
lira=US$1); principal items are foodstuffs, livestock, raw
materials, oil, machinery
Major trade partners: (1977) imports—19% U.K., 9%
Italy, 8% Greece, 8% West Germany, 6% U.S., 5% France;
exports—29% U.K., 18% Saudi Arabia, 9% Lebanon, 5%
Libya, 4% Egypt, 3% U.S.S.R., 3% Greece, 3% Syria
Turkish Sector major trade partners: (1976) imports—
48% Turkey, 22% U.K., 7% West Germany, 5% France, 8%
Netherlands, 3% Italy; exports—33% U.K., 29% Turkey, 18%
Netherlands, 10% Italy
Aid: economic—U.S., $49 million authorized (FY70-76);
other Western bilateral authorizations (ODA and OOF), $34
million (1970-76); Greece, $79 million (1976)
Turkish Sector aid: Turkey, $70 million (1974-76)
Budget: 1977—revenues $167.6 million, expenditures
$229.4 million, deficit $61.8 million
Turkish Sector budget: revenues $38 million, expendi-
tures $78 million, deficit $40 million
Monetary conversion rate: 1 Cyprus pound=US$2.61
(December 1971 through January 1973), 1 Cyprus
pound=US$2.4510 (trade conversion factor for 1977)
Turkish Sector monetary conversion rate: 18.002 Turk-
ish lira=US$1 (trade conversion factor for 1977)
Fiscal year: calendar year
NOTE: 1974, 1975, 1976, and 1977 GNP, import, export,
and budget figures are Government of Cyprus figures which
include 100% of island unti] August 1974 and 60% of island
thereafter; the Turkish sector of island for last 4 months of
1974 is part of Turkish mainland economy; with the passage
of time, some information on the Turkish sector of the island
has become available.
GNP: $59.9 billion in 1977 (in 1976 dollars), $3,985 per
capita; 1977 real growth rate 3.4%
Agriculture: diversified agriculture; main crops—wheat,
rye, potatoes, sugar beets; net food importer—meat, wheat,
vegetable oils, fresh fruits and vegetables; caloric intake,
3,100 calories per day per capita (1967)
Major industries: machinery, food processing, metal-
lurgy, textiles, chemicals
Shortages: ores, crude oil
Crude steel: 15.1 million metric tons produced (1977),
1,000 kg per capita
Electric power: 15.2 million kW capacity (1977); 66.4
billion kWh produced (1977), 4,395 kWh per capita
Exports: $10,970 million (f.0.b., 1977 est.); 50% machin-
ery, equipment; 29% fuels, raw materials; 4% foods, food
products, and live animals; 18% consumer goods, excluding
foods (1976)
Imports: $11,100 million (f.0.b., 1977 est.); 37% machin-
ery, equipment; 47% fuels, raw materials; 10% foods, food
products, and live animals; 7% consumer goods, excluding
foods (1976)
Monetary conversion rate: noncommercial
crowns=US$1, commercial 5.64 crowns=US$1
10.15
Fiscal year: calendar year
NOTE: foreign trade figures were converted at the rate of
6.77 crowns=US$1','1699b0e06c2e6319a449e6314225696e2045baba90ffc62aebaa4b564990eb5d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c423e5288662a534f4ebf17cffb5ecc5b3d0a3b276f00dd190cef4772e231e4c',1978,'DK','Denmark','economy',141,'GNP: $43.7 billion (1977), $8,750 per capita; 58% private
consumption, 20% investment, 25% government, — 2.5% net
foreign sector and stock building (1977); 1977 growth rate
0.5%, constant prices
Agriculture: highly intensive, specializes in dairying and
animal husbandry; main crops—cereals, root crops; food
imports—oilseeds, grain, feedstuffs; caloric intake, 3,180
calories per day per capita (1968-69)
Fishing: catch 1.88 million metric tons, exports $507
million (1976)
Major industries: food processing, machinery and equip-
ment, textiles and clothing, chemical products, electronics,
transport equipment, metal products, brick and mortar,
furniture and other wood products
51
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
DENMARK/DJIBOUTI
Crude steel: 722,000 metric tons produced (1976), 140 kg
per capita
Electric power: 7,400,000 kW capacity (1977); 23.9
billion kWh produced (1977), 4,695 kWh per capita
Exports: $10.1 billion (£.0.b., 1977); principal items—
meat, dairy products, industrial machinery and equipment,
textiles and clothing, chemical products, transport equip-
ment, fish, furs, and furniture
Imports: $13.3 billion (cif, 1977); principal items—
industrial machinery, transport equipment, petroleum,
textile fibers and yarns, iron and steel products, chemicals,
grain and feedstuffs, wood and paper
Major trade partners: 46.5% EC-nine (18.1% West
Germany, 13.1% U.K.); 14.9% Sweden; 5.4% US.; 4.2%
Communist countries (1976)
Aid: donor—bilateral economic aid authorized (ODA and
OOF) $717 million (1970-76)
Budget: (FY77) expenditures $20.3 billion, revenues $20.1
billion
Monetary conversion rate: 6.0031 Kroner=US$1 (1977,
average exchange rate)
Fiscal year: 1 April-31 March','4cfa7dfd9d98ee5d9a941c5c8ca8e419d55fe5c760ac41b9ea74dbf09a58dafa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b09e0262713ff2f0d1769a9f69c5ef8c66a8871327e13c3aacace2982d148aab',1978,'DJ','Djibouti','economy',145,'GNP $65 million (1972)
Agriculture: livestock; desert conditions limit commercial
crops to about 15 acres, including fruits and vegetables
Industry: ship repairs and services of port and railroad
drastically reduced with war in Ethiopia’s Ogaden that cut
the railroad line
Electric power: 23,500 kW capacity (1977); 55 million
kWh produced (1977), 310 kWh per capita
Imports: $74 million (1973), almost all domestically
needed goods—foods, machinery, transport equipment
Exports: $20 million, including transit trade (1973); hides
and skins, and transit of coffee; since railroad line has been
cut, values have plummeted
Monetary conversion rate: 182 Diibouti francs= US$1
Fiscal year: probably same as that for France (calendar
year)','0985dc76b68363791ad897ed5944fd114892642f9b0653c91e14fbece9ad3423','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbd7b49510b349d67b07c2e2c1fcea3db5e8d98c53e27ea994de9ee495621031',1978,'DM','Dominica','economy',149,'GDP: $21.0 million (1971 est.), $270 per capita; 8.8%
increase in 1971, including price changes
Agricultural products: bananas, citrus, coconuts, cocoa
Major industries: agricultural processing, tourism
Electric power: 10,000 kw capacity (1977); 7 million
kWh produced (1977), 260 kWh per capita
Exports: $12 million (£.0.b., 1975): bananas, lime juice and
oil, cocoa, reexports
Imports: $22 million (cif, 1975); machinery and
equipment, foodstuffs, manufactured articles, cement
Major trade partners: 47% U.K., 15% Commonwealth
Caribbean countries, 7% U.S., 6% Canada (1975)
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (May 1975), now floating with pound sterling','0933002a23ed06308e86730e463bfe73edf95686eb1bc2421068d4e1893204a4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d314b91180553df8d4717faa31334ce6e03d605fbe023a8ca2f500b0a1c92238',1978,'DO','Dominican Republic','economy',153,'GNP: $4.4 billion (preliminary 1977), $870 per capita;
real growth rate 1977, 3.3%
Agriculture: main crops—sugarcane, coffee, cocoa, to-
bacco, rice, corn; imports rice; caloric intake, 2,200 calories
per day per capita (1966)
Major industries: sugar processing, nickel mining, bauxite
mining, gold mining, textiles, cement
Electric power: 662,000 kW capacity (1977); 2 billion
kWh produced (1977), 400 kWh per capita
Exports: $780 million (f.0.b., preliminary 1977); sugar,
nickel, coffee, tobacco, cocoa, bauxite
Imports: $848 million (f.0.b., prelim. 1977); foodstuffs,
petroleum, industrial raw materials, capital equipment
Major trade partners: exports—81% U.S. (1977); im-
ports—50% U.S. (1977)
Aid: economic—U.S. authorizations (FY46-76), $250
million in grants, $278 million in loans; from international
organizations (FY46-76), $310 million; military—assistance
from U.S. (FY53-76), $40 million, mostly grant
Budget: revenues, $584 million; expenditures, $555
million (1976)
Monetary conversion rate: | peso=US$1
Fiscal year: calendar year','53710d5dcad480dec8ba1da991ea5602238efcbec0c8155f271e9067c27e473a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5aab2ca74a228599f4be46ef2de0cc028997f082cf275ec08c8d05a37aed3f0d',1978,'EC','Ecuador','economy',157,'GNP: $5.7 billion (est. 1977), $795 per capita; 67% private
consumption, 10% public consumption, 23% gross invest-
ment; average annual real growth rate 1974-77, 9.6%
Agriculture: main crops—bananas, coffee, cocoa, sugar-
cane, cotton, corn, potatoes, rice; caloric intake, 1,970
calories per day per capita (1970)
Fishing: catch 233,400 metric tons (1975); exports $65
million (1977), imports negligible
Major industries: food processing, textiles, chemicals,
fishing, petroleum
Electric power: 552,000 kW capacity (1977); 2 billion
kWh produced (1977), 260 kWh per capita
Exports: $1.4 billion (f.0.b., 1977); petroleum, bananas,
coffee, cocoa, sugar, fish products
Imports: $1.3 billion (f.0.b., 1977); agricultural and
industrial machinery, wheat, petroleum products, chemical
products, transportation and communication equipment
56
Major trade partners: exports (1976)—41% US., 20%
LAFTA, 10% EC; imports (1976)—40% U.S., 20% EC, 13%
LAFTA
Aid: economic—extensions from U.S. (FY46-75), $155
million loans, $138 million grants; from international
organizations (FY46-75), $439 million; from Communist
countries (1967-76), $19.4 million loans; military—assistance
from U.S. (FY49-76), $81 million
Budget: (1977) revenues, $850 million; expenditures, $970
million
Monetary conversion rate: 25 sucres= US$1
Fiscal year: calendar year','fd54496ca3af9d275b2ea761e971b7ecd56d3b26350e8f415e9521d317d2c3e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe76f17bb228f45ff480c7026107e9dfab2594f69d613f7fcdf4f97d5dccdbc3',1978,'EG','Egypt','economy',161,'GNP: $14 billion (1976 est.), in current prices, $370 per
capita; average annual growth rate of 6%-7% since 1974
Agriculture: main cash crop—cotton; other crops—rice,
onions, beans, citrus fruit, wheat, corn, barley; not self-suffi-
cient in food, but agriculture a net earner of foreign
exchange
Major industries: textiles, food processing, chemicals,
petroleum, construction, cement
Electric power: 4,400,000 kW capacity (1977); 12 billion
kWh produced (1977), 300 kWh per capita
Monetary conversion rate: official rate—l Egyptian
pound=US$2.54 (selling rate); 0.394 Egyptian pound=
US$1 (selling rate); parallel market rate—l Egyptian
pound=US$$1.43, 0.699 Egyptian pound=US$1
Fiscal year: calendar year, beginning in 1973','0a2cf1a55d855a52ba60f915d2160112e05e511526885d9dedffe2ba94e73399','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f012fb36cc6df2e710e490b9ba41d8ddda054b3719cc412c4fff4d18f77c0bd',1978,'SV','El Salvador','economy',165,'GNP: $2.2 billion (1976), $510 per capita; 71% private
consumption, 12% government consumption, 20% domestic
investment; —3% net foreign balance and draw-down of
stocks, real growth rate, 4.7% (1976)
Agriculture: main crops—coffee, cotton, corn, sugar, rice,
beans; caloric intake, 2,000 calories per day per capita
(1963-64)
Fishing: catch 10,550 metric tons (1975); exports $6.0
million (1971), imports $0.8 million (1974)
Major industries: food processing,
petroleum products
Electric power: 557,000 kW capacity (1977); 1.2 billion
kWh produced (1977), 295 kWh per capita
Exports: $1,021 million (f.0.b., 1977); coffee, cotton, sugar
Imports: $941 million (cif, 1977); machinery, auto-
motive vehicles, petroleum, foodstuffs, fertilizer
Major trade partners: exports—33% U.S., 24% CACM,
11% other (1976); imports—29% U.S., 24% CACM, 7%
Venezuela, 14% West Germany, 8% Netherlands, 40% other
(1976)
Aid: economic—from U.S. (FY46-76), $104 million loans,
$82 million grants; from international organizations
(FY46-75), $287 million; from other Western countries
(1960-71), $9.8 million; military—assistance from U.S.
(FY58-76), $16 million
Budget: (1978) $500 million
Monetary conversion rate: 2.5 colones=US$1 (official)
textiles, clothing,
Fiscal year: calendar year','89cea27a02d4b034c2fd8c72c52c9c578cc5807912591c3e8a5dda9491f28b15','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0ad22f85a74146522deb2ded332e63b8229e225757390ae8f199bf24fc8e134',1978,'GQ','Equatorial Guinea','economy',169,'GNP: $70 million (1972); $240 per capita
Agriculture: major cash crops—Rio Muni, timber, coffee;
Fernando Po, cocoa; main food products—rice, yams,
cassava, bananas, oil palm nuts, manioc, and livestock
Fishing: catch 4,000 metric tons (1975)
Major industries: fishing, sawmilling
Electric power: 5,000 kW capacity (1977); 17 million
kWh produced (1977), 50 kWh per capita
Exports: $19 million (1973); cocoa, coffee, and wood
Imports: $21 million (1973); foodstuffs, chemicals and
chemical products, textiles
Major trade partner: Spain
Aid: Spain, $14.0 million (1969); Libya, $1 million (1971);
China $24 million (Economic) extended (1971)
Budget: (1973) receipts $9 million, expenditures $12
million
Monetary conversion rate: 64.47 Guinean pesetas=US$1
(official)','c1720d428d51ca2058a95d068d94dc3a8359f186c6328fa1eee2d38f3df75ccd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('558a01077c8aadc4e05a0250d9377aa376b9d5bc6ebd97d1c557de3fdf393c88',1978,'ET','Ethiopia','economy',173,'GDP: $2,650 million (1975), $90 per capita; average
annual real growth rate 4% (1967-73), zero (1974 and in
1975)
Agriculture: main crops—coffee, teff, durra, barley,
wheat, corn, sugarcane, cotton, pulses, oilseeds; livestock
Major industries: cement, sugar refining, cotton textiles,
food processing, oil refinery
Electric power: 297,000 kW capacity (1977); 500 million
kWh produced (1977), 20 kWh per capita
Exports: $283 million (f.0.b., 1976); coffee 55%, oilseeds
15%, pulses 10%, hides and skins 9%; $12.6 million to
Communist countries (1976)
Imports: $360 million (cif, 1976); machinery and
transportation equipment (34%), basic manufactures (25%),
fuels (15%); in 1977 military material bulks large; $17.9
million from Communist countries
Major trade partners: imports—Saudi Arabia, Japan,
Italy, West Germany, Iran, U.K., France, and U.S.;
exports—U.S., Djibouti, Saudi Arabia, Japan, Italy, West','14746899426f314a6933f225c48701bac5e6f50bf59d587268e920d2cd486964','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70ad67bfe7e8c91fdb67aaa2af27f738432a0f2e38d1d6857202e0fdabb5c083',1978,'DE','Germany','economy',174,'Monetary conversion rate: 2.085 Ethiopian Birr=US$1
Fiscal year: 8 July-7 July
Government budget: Colony—revenues, $1.0 million
(FY68),; expenditures, $1.1 million (FY68)
Agriculture: Colony—predominantly sheep farming: de-
pendencies—whaling and sealing
depend-
Major industries: Colony—wool processing;
encies—whale and seal processing
Electric power: 1,250 kW capacity (1977); 2.5 million
kWh produced (1977), 1,150 kWh per capita
Exports: Colony—$2.28 million (1969); wool, hides and
skins, and other; dependencies—no exports in 1968 or 1969
Imports: Colony—$1.22 million (1969); food, clothing,
fuels, and machinery; dependencies—$8,368 (1969); mineral
fuels and lubricants, food, and machinery
Major trade partners: nearly all exports to the U.K., also
some to the Netherlands and to Japan; imports from
Curacao, Japan, and the U.K.
Monetary conversion rate: 1 Falkland Island
pound = US$2.60
Aid: economic—from U.S. (FY46-76), $129 million loans,
$236 million grants; from international organizations
(FY46-75), $246 million; from other Western countries
(1960-71), $12.3 million; military—assistance from US.
(FY46-75), $41 million
Central government budget (1978 est.): expenditures,
$943 million; revenues, $943 million
Monetary conversion rate: 1 quetzal=US$1 (official)
Fiscal year: calendar year
Aid: economic assistance commitments, 1970-76; Commu-
nist, $100 million; OPEC, $0; U.S., $1,597 million; other
Western, $3,817 million; bilateral military assistance com-
mitments, 1970-76: Communist, $1 million; U.S., $183
million
Budget: (1978-79) expenditures $11.6 billion; planned
receipts $9.6 billion domestic, $2.0 billion foreign
Monetary conversion rate: 415 rupiah=US$1
Fiscal year: 1 April-31 March
95
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
INDONESTA/TIRAN
GNP: $81.2 billion (1977), $2,366 per capita; 1977 real
GNP growth, 3.2%
Agriculture: wheat, barley, rice, sugar beets, cotton, dates,
raisins, tea, tobacco, sheep, and goats
Major industries: crude oil production (2,080 million bbls
in 1977) and refining, textiles, cement and other building
materials, food processing (particularly sugar refining and
vegetable oil production), metal fabricating
Electric power: 6,000,000 kW capacity (1977); 19 billion
kWh produced (1977), 545 kWh per capita
Exports: $24.3 billion (f.0.b., 1977); 97% petroleum; also
carpets, raw cotton, fruits, and nuts, hide and leather items,
ores
Imports: $14.1 billion (f.0.b., 1977); machinery, iron and
steel products, chemicals, pharmaceuticals, electrical equip-
ment, agricultural products
Major trade partners: exports-—U.S., Japan, U.K., Neth-
erlands, West Germany, U.S.S.R. and other Communist
countries; imports—U.S., West Germany, Japan, U.K.,
U.S.S.R.
Budget: (FY78-79) $59.2 billion
Monetary conversion rate: 70.6 rials=US$1
Fiscal year: 21 March-20 March
Monetary conversion rate: | Tunisian dinar (TD)=
US$2.32
Fiscal year: calendar year
GNP: $45.0 billion (1977),
growth 1977, 7%-8% average annual real growth
$1,070 per capita; 4.5% real
1970-76
Agriculture: main products—cotton, tobacco, cereals,
sugar beets, fruits, nuts, and livestock products; self-suffi-
cient in food in average years, 2,900 calories per day per
capita (1972)
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
Crude steel: 1.9 million tons produced (1976), 45 kg per
capita
Electric power: 4,900,000 kW capacity (1977); 21.5
billion kWh produced (1977), 505 kWh per capita
Exports: $1,750 million (f.0.b., 1977); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $5,800 million (c.i.f., 1977); crude oil, machin-
ery, transport equipment, metals, mineral fuels, fertilizers,
chemicals
Major trade partners: 92% West Germany, 9% U.S., 9%
Iraq, 7% UK., 7% Italy (1976)
Budget: (FY77) revenues $11.2 billion, expenditures $12.2
billion, deficit $1.01 billion
Monetary conversion rate: 25.00 Turkish liras=US$1 (1
March 1978)
Fiscal year: 1 March-28 February','8fce926000d815f5c159699e88239b1bf7040b79de95efb2fc19e4a3c3a23d4d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdb5e2101c875b82748362a48763f0b7a9df0818c1b50b5b6092e531eb0ad3ad',1978,'FO','Faroe Islands','economy',181,'CDP: $173.4 million (1974), about $3,650 per capita
Agriculture: sheep and cattle grazing
Fishing: catch 285,100 metric tons (1975); exports, $77.4
million (1975)
Major industry: fishing
Electric power: 28,500 kW capacity (1977); 90 million
kWh produced (1977), 2,150 kWh per capita
Exports: $80.7 million (f.0.b., 1975); mostly fish and fish
products
Imports: $113.3 million (c.if., 1975); machinery and
transport equipment, petroleum and petroleum products,
food products
Major trade partners: 46.6% Denmark, 12.3% Norway,
8.0% UK., 6.2% US. (1975)
Budget: (FY76) expenditures $52.8 million, revenues
$52.8 million
Monetary conversion rate: 6.0031 Danish Kroner=US$1
(1977, average)
Fiseal year: 1 April-31 March','ec57281f94e6e2075134e8ccbe86802c7d7b5d8d0be155906f2eccc7bc0d07f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a30d6044809678bd0c34abf87379f78bf17ca2d2b80fb8fa2be9ce7ea91fac84',1978,'FJ','Fiji','economy',185,'GNP: $644 million (1975), $1,130 per capita; 5.8% real
growth rate (1971-75)
Agriculture: main crops—sugar, coconut products, ba-
nanas, rice; major deficiency, grains
Major industries: sugar processing, tourism
Electric power: 90,000 kW capacity (1977); 270 million
kWh produced (1977), 450 kWh per capita
Exports: $144 million (f.0.b., 1976, including reexports);
70% sugar, 11% coconut oil, 9% gold
Imports: $245 million (f.0.b., 1976); 20% manufactured
goods, 19% food, 16% machinery (1974)
Major trade partners: exports—38% U.K., 31% US., 11%
Australia; imports—30% Australia, 18% Japan, 11% New
Zealand, 4% US. (1974)
Aid: disbursed 1968—Australia $1.5 million, U.S. $0.6
million, U.K. $4.2 million
Budget: (FY75) revenues $107 million, expenditures $129
million
Monetary conversion rate: Fijian dollar=US$1.1544
(January 1978)
Fiscal year: calendar year','895f397889912d77401b5dd766e986fa4a3464491f99e4f62fd9908ff5c51d19','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eaf0eab19e8326e1975313b36847d60f1a59ad8f91740c1087215307383a36b',1978,'FI','Finland','economy',189,'GNP: $27 billion (1977), $5,689 per capita; 51.6%
consumption, 26.0% investment, 19.9% government; —2%
net exports of goods and services; 1976 growth rate — 0.6%,
constant prices
Agriculture: animal husbandry, especially dairying, pre-
dominates; forestry important secondary occupation for
rural population; main crops—cereals, sugar beets, potatoes;
85% self-sufficient; shortages—food and fodder grains;
caloric intake 2,940 calories per day per capita (1970-71)
Major industries: include metal manufacturing and
shipbuilding, forestry and wood processing (pulp, paper),
copper refining
65
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
FINLAND/FRANCE
Shortages: fossil fuels; industrial raw materials, except
wood, and iron ore
Crude steel: 1.7 million metric tons produced (1976), 358
kg per capita
Electric power: 8,703,000 kW capacity (1977); 31.9
billion kWh produced (1977), 6,735 kWh per capita
Exports: $7.5 billion (f.0.b., 1977); timber, paper and
pulp, ships, machinery, iron and steel, clothing and footwear
Imports: $7.5 billion (c.if., 1977); foodstuffs, petroleum
and petroleum products, chemicals, transport equipment,
iron and steel, machinery, textile yarn and fabrics
Major trade partners: (1976) 87% EC-nine (13% West
Germany, 11% U.K.); 19% U.S.S.R., 16% Sweden; 5% U.S.
Aid: economic authorizations—U.S. $64 million (FY70-76)
Budget: (1976) expenditures $8.4 billion, revenues $7.8
billion
Monetary conversion rate: new markka (Fmk)
4.03=US$1 (1976 trade conversion factor, IMF)
Fiscal year: calendar year','3249dff2f0fac647b7bfd72edc2292d997e6b60ca7d026227934ad8f51ef02a3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5d0de19a3ff341bfca920ba68f17d968815517c42c87727c46716204574fc9e',1978,'FR','France','economy',193,'GNP: $347 billion (1976), $6,547 per capita, 63.9% private
consumption, 22.9% investment (including government),
13.2% government consumption, 1976 real growth rate,
5.2%: average annual growth rate, 5.2% (1965-75)
Agriculture: Western Europe’s foremost producer; main
products—beef, cereals, sugar beets, potatoes, wine grapes;
self-sufficient for most temperate zone foodstuffs; food
shortages—fats and oils, tropical produce; caloric intake,
3,270 calories per day per capita (1969-70)
Fishing: catch 691,394 metric tons (1976); exports
(includes shellfish, etc.) $122 million, imports $506 million
(1976)
Major industries: steel, machinery and eauipment,
textiles and clothing, chemicals, food processing, metallurgy,
aircraft, motor vehicles
Shortages: crude oil, textile fibers, most nonferrous ores,
coking coal, fats and oils
Crude steel: 22.1 million metric tons produced (1977),
440 ke per capita
Electric power: 54,000,000 kW capacity (1977); 210
billion kWh produced (1977), 3,940 kWh per capita
Exports: $65.1 billion (f.0.b., 1977); principal items—
machinery and transportation equipment, foodstuffs, agri-
cultural products, iron and_ steel products, textiles and
clothing, chemicals
Imports: $67.4 billion (cif., 1977); principal items—
crude petroleum, machinery and equipment, chemicals, iron
and steel products, foodstuffs, agricultural products
Major trade partners: 18% West Germany; 9% Belgium-
Luxembourg; 10% Italy; 6% U.S.; 5% Netherlands; 6% U.K.;
2% Eastern Europe; 2% U.S.S.R.; 8% Franc Zone (1977)
Aid: donor—bilateral economic aid authorized (ODA and
OOF), $13,384 million (1970-76)
Budget: (1976) expenditures 346 billion francs, revenues
329 billion francs, deficit 17 billion francs
Monetary conversion rate: | franc=US$0.2035 (1977
average)
Fiscal year: calendar year
GDP: $3.0 billion (1976), $460 per capita; economy
contracting since 1974
Agriculture: main crops—tobacco, corn, sugar, cotton;
livestock; self-sufficient in foodstuffs
Major industries: mining, steel, textiles, chemicals, and
vehicles
Electric power: 1,453,000 kW capacity (1977); 7.5 billion
kWh produced (1977), 1,000 kWh per capita
Exports: $652 million (f.0.b., 1973), including net gold
sales and reexports; tobacco, asbestos, copper, meat, chrome,
gold, nickel, clothing, sugar
Imports: $541 million (c.i.f., 1973); machinery, petroleum
products, wheat, transport equipment
Net merchandise earnings: $264 million (1976)
Major trade partner: South Africa
Aid: no substantial military or economic aid
Budget: FY77—revenues $797 million, expenditures $887
million, deficit $40 million
Monetary conversion rate: 1 Rhodesian dollar=US$1.50
Fiscal year: 1 July-30 June','75b828c94312b5527ee242c7dc279e23941be74e850a8dca029b319617a191a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1443439f4acb2c3d292f28a7118ea33de746649f2540d8fa972616bdf4e236f',1978,'GF','French Guiana','economy',197,'GNP: $40 million (at market prices, 1970), $800 per
capita
Agriculture: main crops—rice, corn, manioc, cocoa,
bananas, sugarcane
Fishing: catch 933 metric tons (1975); exports $0.6 million
(1974); imports $2.2 million (1971)
Major industries: timber, rum, gold mining, production
of rosewood essence, and space center
Electric power: 29,000 kW capacity (1977); 60 million
kWh produced (1977), 985 kWh per capita
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
FRENCH GUIANA/FRENCH POLYNESIA
Exports: $5 million (f.0.b., 1973); shrimp, timber, rum,
rosewood essence
Imports: $56 million (c.i.f., 1973); food (grains, processed
meat), other consumer goods, producer goods and petroleum
Major trade partners: exports—78% U.S., 11% France,
5% Martinique; imports—49% France, 10% US., 3%
Trinidad and Tobago (1969)
Monetary conversion rate: 4.44 French francs=US$1
Fiscal year: calendar year','8075912aa7a25915e35e7146afb31d1baf8a23d5d0dba4f084e88e4afc55a764','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b97ec0fc5c893cf23e0676cbf5cbf68ace13da224b21c8cdc11bb4e563a4855',1978,'PF','French Polynesia','economy',201,'GDP: $259 million (1970) $1,960 per capita (1971)
Agriculture: coconut main crop
Major industries: maintenance of French nuclear test
base, tourism
Electric power: 36,000 kW capacity (1977); 105 million
kWh produced (1977), 740 kWh per capita
Exports: $19 million (1973); principal products—coconut
products (79%), mother-of-pearl (14%) (1971)
Imports: $211 million (1973)
Major trade partners: imports—59% France, 14% U.S.;
exports—86% France
Aid: France $16 million (1973)
Monetary conversion rate: 100 CFP=1NZ$ (1971)','2031afdadc83a481a2bd9d1428e7e2bfaf7e23c029b1909d4ac8df6554b3ca77','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe801c5d911601ce0512f9a03cc85d3e2d9d30d3603edd6a66c32b6e33242893',1978,'GA','Gabon','economy',205,'GDP: $1,605 million (1975), $2,960 per capita; 36%
growth (1973-75)
Agriculture: commercial—cocoa, coffee, wood, palm oil,
rice; main food crops—bananas, manioc, peanuts, root crops;
imports food
Fishing: catch 6,056 metric tons (1975)
Major industries: petroleum production, sawmills, petro-
leum refinery, natural gas, agricultural processing; mining of
increasing importance; major minerals—manganese, uran-
ium, gold, and iron
Electric power: 125,400 kW capacity (1977); 376 million
kWh produced (1977), 665 kWh per capita
Exports: $1.2 billion (f.0.b., 1977); crude petroleum, wood
and wood products, minerals (manganese, uranium concen-
trates, gold)
Imports: $800 million (f.0.b. est., 1977); excluding
UDEAC trade; mining, roadbuilding machinery, electrical
equipment, transport vehicles, foodstuffs, textiles
Major trade partners: France, U.S., West Germany, and
Curacao; preferential tariffs to EC and franc zone
Budget: 1975 est.—receipts $630 million, current expend-
itures $184 million, investment expenditures $446 million
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
GABON/THE GAMBIA
Monetary conversion rate: 242.69 Communaute Finan-
ciere Africaine francs=US$1 as of November 1977
Fiscal year: calendar year
GNP: $115 million (FY76-77 est.), about $200 per capita
Agriculture: main crops—peanuts, rice, palm kernels
Fishing: catch 10,795 metric tons (1975); exports $956,000
(1974)
Major industry: peanut processing
Electric power: 10,000 kW capacity (1977); 30 million
kWh. produced (1977), 55 kWh per capita
71
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
THE GAMBIA/GERMAN DEMOCRATIC REPUBLIC
Exports: $55 million (FY77 est.); peanuts and peanut
products 90% to 95%, palm kernels
Imports: $76.6 million (FY77 est.); textiles, foodstuffs,
tobacco, machinery, petroleum products
Major trade partners: exports—U.K. and France; im-
ports—U.K. and Japan
Aid: economic—U.K. (1968-71), about $8 million commit-
ment; U.S. (FY56-76), $10.6 million; other international
organizations (FY62-75), $10.8 million
Budget: (FY77 est.) current expenditures $25 million,
receipts $30 million; development expenditures $14 million,
development receipts $7.2 million
Monetary conversion rate: 1 Dalasi=US$0.45 (November
1977)
Fiscal year: 1 July-30 June
GNP: $69.2 billion in 1977 (1976 prices), $4,130 per
capita; 1977 growth rate 4.0%
Agriculture: food deficit area; main crops—potatoes, rye,
wheat, barley, oats, industrial crops; shortages in grain,
vegetables, vegetable oil, beef; caloric intake, 3,000 calories
per day per capita (71)
Fish catch: 279,000 metric tons (1976)
Major industries: metal fabrication, chemicals, light
industry, brown coal, and shipbuilding
Shortages: coking coal, coke, crude oil, rolled steel
products, nonferrous metals
Crude steel: 7.00 million metric tons produced (1977,
preliminary estimate), approx. 420 kg per capita
Electric power: 18,500,000 kW capacity (1977); 92 billion
kWh produced (1977), 5,500 kWh per capita
Exports: $11,361 million (f.0.b. delivering country, 1976)
Imports: $13,196 million (f.0.b. delivering country, 1976)
Major trade partners: $25,200 million (1976); 65%
Communist countries, 35% non-Communist countries
Monetary conversion rate: 3.48 DME=US$1 for trade
data (1976 rate)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for the consumption year 1 July-30 June
GNP: $514 billion (1977), $8,361 per capita (including
West Berlin) (1976); 55% consumption, 21% investment, 21%
government consumption (does not include total government
spending); net foreign balance 2%; average annual growth
rate 1966-77, 3.4% in constant 1970 prices
74
Agriculture: main crops—grains, potatoes, sugar beets:
75% self-sufficient; food shortages—fats and oils, pulses,
tropical products; caloric intake, 2,984 calories per day per
capita (1973-74)
Fishing: catch 387,000 metric tons, $155 million (1977);
exports $130 million, imports $352 million (1977)
Major industries: among world’s largest producers of
iron, steel, coal, cement, chemicals, machinery, ships,
vehicles
Shortages: fats and oils, sugar, cotton, wool, rubber,
petroleum, iron ore, bauxite, nonferrous metals, sulfur
Crude steel: 60 million metric tons capacity; 38.9 million
metric tons produced (1977); 632 kg per capita
Electric power: 78,000,000 kW capacity (1977); 370
billion kWh produced (1977), 6,014 kWh per capita
Exports: $141 billion (f.0.b., 1977); manufactures 90.9%
(machines and machine tools, chemicals, motor vehicles, iron
and steel products), agricultural products 5.3%, fuels 2.1%,
raw materials 1.7%
Imports: $130 billion (c.i.f., 1977); manufactures 60.2%,
fuels 8.1%, agricultural products 16.7%, raw materials 15.0%
Major trade partners: EC 46.6% (France 12.0%, Nether-
lands 11.6%, Belgium-Luxembourg 8.2%, Italy 7.8%); other
Europe 12.7%; OPEC 9.6%; Communist economic 5.5%;
US. 7.0%
Aid: donor—bilateral economic aid authorized (ODA and
OOF), $11,659 million (1970-76)
Budget: (1977) expenditures $73.8 billion, revenues $64.1
billion, deficit $9.7 billion
Monetary conversion rate: DM 2.32 (West German
marks)=US$1 (1977 average)
Fiscal year: calendar year','dc532845be43510612565e17a74982a7b2eb9073637df9f6b476f053c92bf5e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd495c5602cae49fd656a67507f4724b9bd307838bb9c565c868c5d836f2230e',1978,'GN','Guinea','economy',209,'GNP: $8 billion (1976 est.) at current prices, about $390
per capita; real growth rate less than 1% (1970-77)
Agriculture: main crop—cocoa; other crops include root
crops, corn, sorghum and millet, peanuts; not self-sufficient,
but can become so
Fishing: catch 200,000 metric tons (1976 est.)
Major industries: mining, lumbering, light manufactur-
ing, fishing, aluminum
Electric power: 1,157,000 kW capacity (1977); 4.0 billion
kWh produced (1977), 370 kWh per capita
Exports: $766 million (f.0.b., 1976); cocoa (about 70%),
wood, gold, diamonds, manganese, bauxite, and aluminum
(aluminum regularly excluded from balance of payments
data)
75
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GHANA/GIBRALTAR
Imports: $466 million (f.0.b., 1976); textiles and other
manufactured goods, food, fuels, transport equipment
Major trade partners: U.K., EC, and US.
Budget: FY78 (proposed) —revenue $1,619 million includ-
ing grants, current expenditure $1,570 million, capital
expenditure $487 million
Monetary conversion rate: | Cedi=US$0.87
Fiscal year: 1 July-30 June
GDP: $820.8 (1976), $180 per capita
Agriculture: cash crops—coffee, bananas, palm products,
peanuts, and pineapples; staple food crops—cassava, rice,
millet, corn, sweet potatoes; livestock raised in some areas
Major industries: alumina, light manufacturing and
processing industries, bauxite mining
Electric power: 101,500 kW capacity (1977); 500 million
kWh produced (1977), 90 kWh per capita
Exports: $240 million (f.0.b., 1976); alumina, bauxite,
coffee, pineapples, bananas, palm kernels
Imports: $248 million (f.o.b., 1976); petroleum products,
metals, machinery and transport equipment, foodstuffs,
textiles
Major trade partners: Communist countries, Western
Europe (including France), U.S.
Budget: (FY77 est.) current revenue $238 million, current
expenditures $176 million
Monetary conversion rate: 21.25 syli=US$1 floating (end
1977)
Fiscal year: 1 October-30 September
GDP: $4.4 billion (1976 est.), $840 capita; average annual
growth rate in constant prices, 8% (1970-76)
Agriculture: commercial—coffee, cocoa, wood, bananas,
pineapples, palm oil; food crops—corn, millet, yams, rice;
other commodities—cotton, tubber, tobacco, fish; self-
sufficient in most foodstuffs, but rice, sugar, and meat
imported
Fishing: catch 63,470 metric tons (1975); exports $]2.8
million (1975), imports $33.6 million (1975)
Major industries: food and lumber processing, oil
refinery, automobile assembly plant, textiles, soap, flour
mill, matches, three small shipyards, fertilizer plant, and
battery factory
Electric power: 525,000 kW capacity (1977); 1.2 billion
kWh _ produced (1977), 165 kWh per capita
Exports: $1.6 billion (f.0.b., 1976): coffee, tropical woods,
cocoa, 70% of total; bananas, pineapples, palm oil
Imports: $1.3 billion (c.i.f., 1976); about 40% consumer
goods, 10% raw materials and fuels, about 50% manufac-
tured goods and semi-finished products
Major trade partners: France and other EC countries
about 65%, U.S. 13%, Communist countries about 1%
Aid: economic—France (1960-69), $312 million; EC
through FY75, $203.2 million; U.S. (FY61-75), $40.7 million;
others (1960-71), $76 million, including $18.5 million
committed; no Communist aid Programs; military— non-
Communist countries (1954-67), $7.3 million
Budget: 1977, broposed—revenues $705 million, current
expenditures $389 million, investment expenditures $316
million
Monetary conversion rate: about 242.69 Communaute
Financiere Africaine francs=US$1, November 1977
Fiscal year: calendar year','9fc7777a5f1f7e5694bce9941a09a9690056927c6d52bafcf10bc1cc9c99c36d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('731a1a8ded05b45387cd7d5309fb48ce6648d2d27a899942e77bbc6a2d6e5aed',1978,'GI','Gibraltar','economy',213,'Economic activity in Gibraltar centers on commerce and
large British naval and air bases; nearly all trade in the
well-developed port is transit trade and port serves also as
important supply depot for fuel, water, and ships’ wares;
recently built dockyards and machine shops provide
maintenance and repair services to 3,500-4,000 vessels that
call at Gibraltar each year.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GIBRALTAR/GILBERT ISLANDS
U.K. military establishments and civil government employ
nearly half the insured labor force; local industry is confined
to manufacture of tobacco, roasted coffee, ice, mineral
waters, candy, beer, and canned fish; some factories for
manufacture of clothing are being developed; a small
segment of local population makes its livelihood by fishing;
in recent years tourism has increased in importance.
Electric power: 40,000 kW capacity (1977); 80 million
kWh produced (1977), 2,670 kWh per capita
Exports: $23.87 million (1975-76), at exchange rate of 1
pound=US¢$2.22; principally rexports of tobacco, petroleum,
and wine; 13% to U.K.
Imports: $60.0 million (1975-76), at exchange rate of 1
pound=US$2.22; 60% from U.K.
Major trade partners: U.K., Morocco, Portugal, Nether-
lands
Budget: (1975-76) revenue, $26.22 million; expenditure
$22.91 million, at exchange rate of 1 pound=US$2.22
Monetary conversion rate: 1 Gibraltar
US$1.8062 (1976)
GDP: $740 per capita (1974)
Agriculture: copra, subsistence crops of vegetables,
supplemented by domestic fishing
Industry: phosphate production, expected to cease in 1978
Electric power: 16,000 kW capacity (1977); 45 million
kWh produced (1977), 865 kWh per capita
Exports: $8.6 million (1970 est.); 70% phosphate, copra
Imports: $3.1 million (1970 est.); foodstuffs, fuel
Budget: (est.) revenue 5.877 million NZ$, expenditure
4.577 million NZ$
Monetary conversion rate:
March 1976
0.80 Australian$=US$1
77
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GILBERT ISLANDS/GREECE','f101de4e33abadd89a979dc0e8b9c124477a31e79160b14bff82215b3543a8f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0e1d4ca7bdeaa994348958dc63df3082147942f1eaabf928140994e18f36335',1978,'GR','Greece','economy',217,'GNP: $22.9 billion (1976 est.), $2,500 per capita; 67.2%
consumption, 21.3% investment, 15.2% government; 2.7%
change in stocks; net foreign balance —6.4%; real growth
rate 5.9% (1976); typical real growth rate averages 7.5%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GREECE/GREENLAND
Agriculture: subject to droughts; main crops—wheat,
olives, tobacco, cotton; nearly self-sufficient; food short-
ages—livestock products; caloric intake, 2,960 calories per
day per capita (1963)
Major industries: food processing, tobacco, chemicals,
textiles, petroleum refining, aluminum processing
Shortages: petroleum, minerals, feed grains
Crude steel: 899,750 metric tons produced (1976), 100 kg
per capita
Electric power: 5,400,000 kW capacity (1977); 20.0
billion kWh produced (1977), 2,165 kWh per capita
Exports: $2,565 million (f.0.b., 1976); principal items—
tobacco, cotton, fruits, textiles
Imports: $6,064 million (c.if., 1976); principal items—
machinery and automotive equipment, manufactured con-
sumer goods, petroleum and petroleum products, chemicals,
meat and live animals
Major trade partners: (1976)—41.6% EC, 9.2% CEMA
countries, 8.0% other European countries, 16.6% US.
Aid: economic (authorized)—U.S., $139 million
(FY70-76); other Western bilateral (ODA and OOF), $649
million (1970-76); military—U.S., $672 million (FY70-76)
Budget: (1977) expenditures $6,500 million, revenues
$6,500 million ;
Monetary conversion rate: | drachma=US$0.027 (1976
average)
Fiscal year: calendar year','bc469cdf08e4379f0e630f3858d61d2a153aec2f7af01e6ca88393600ec8a34e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4b1cb02d0c7a69cab6731e0383372dbad62e0d5a2e84bc49bffb3d287ad39b7',1978,'GL','Greenland','economy',221,'GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep grazing:
garden produce
Fishing: catch 44,638 tons (1976); exports $35.6 million
(1975)
Major industries: mining, slaughtering, fishing, sealing
Electric power: 57,500 kW capacity (1977); 120 million
kWh produced (1977), 2,355 kWh per capita
Exports: $88.7 million (f.0.b., 1975); fish and fish
products, metallic ores and concentrates
Imports: $129.1 million (c.if., 1975); petroleum and
petroleum products, machinery and transport equipment,
food products
Major trade partners: (1975) Denmark 68%, Finland
7.5%, Spain 5.8%
Monetary conversion rate: 6.0031 Danish Kroner= US$1
(1977, average)
Fiscal year: 1 April-31 March','c5c31ef9dc6b26e9915aca8f6b7c5182ef1fe174c4f2bd5a1b3056a5c380904e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b05a768d39a5b92cd10c308513d32a2ee5ee8ea4c9ed882050139887ea36ffb6',1978,'GD','Grenada','economy',225,'GNP: $43 million (in current prices, 1976), $440 per
capita; real growth rate 1976, 13%
Agriculture: main crops—spices, cocoa, bananas
Fishing: 1,800 metric tons (1975)
Electric power: 7,000 kW capacity (1977); 25 million
kWh produced (1977), 230 kWh per capita
Exports: $13 million (f.0.b., 1976); nutmeg, cocoa beans,
bananas, mace
Imports: $25 million (cif, 1976); food, machinery,
building materials
Major trade partners: exports—33% U.K., 19% West
Germany, 13% Netherlands; imports—27% West Indies,
27% U.K., 9% USS.
Monetary conversion rate: 2.70 East Caribbean dollars=
US$1 (July 1976)','da3739e515d5f4ca3dd6093668ddd4fcdc78fed411e09d2e49281826cfa32cc8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5a12f955f284a10b5a06cf6ff70b6c7743d075ce85f81663587af77f03432cf',1978,'GP','Guadeloupe','economy',229,'GDP: $470 million (1975), $1,428 per capita; real growth
rate (1975) 1.4%
Agriculture: main crops, sugarcane and bananas
Major industries: agricultural processing, sugar milling
and rum distillation
Electric power: 50,000 kW capacity (1977); 200 million
kWh produced (1977), 570 kWh. per capita
Exports: $78 million (f.0.b., 1975); sugar, bananas, rum
Imports: $292 million (cif, 1975); foodstuffs, clothing
and other consumer goods, raw materials and supplies, and
petroleum
Major trade partners: exports—71% France, 17% U.S.,
71% Germany, 5% other; imports—70% France, 9% US., 38%
Cermany, 3% Netherlands Antilles, 3% Netherlands, 12%
other (1968)
Monetary conversion rate: 4.75 French francs=US$1
(1976)
Fiscal year: calendar year','8a4b91b5fc1e39510056e65caf3c8a56f609741b6c9be0bc002e4323870592c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03e25f83b84ebf714ff3648dc5563d61903dccfb37eec15b2f02231b79e6dbcb',1978,'GW','Guinea-Bissau','economy',234,'GDP: $112 million (est. 1975), $230 per capita
Agriculture: main crops—palm oil, root crops, rice,
coconuts, peanuts
Electric power: 11,000 kW capacity (1977); 17 million
kWh produced (1977), 30 kWh per capita
Exports: $1] million (f.0.b., 1977); principally peanuts,
coconuts
Imports: $31 million (c.if., 1977); manufactured goods,
fuels, transport equipment, rice
Major trade partners: mostly Portugal, also immediate
neighbors
Aid: Portugal, U.S.S.R.
Monetary conversion rate: using Portuguese currency;
40.643 escudos=US$1 (November 1977)
Fiscal year: probably is the calendar year','db3d4076cce4084ca5448697ee993cad785818fc6d6f1edea6f2dc462651b95a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a22a6fdcef73c09ab6b702b42960b877ec3989921c344b40e443f4b987f4f55d',1978,'HT','Haiti','economy',239,'GNP: $1.0 billion (1976), $197 per capita; real growth rate
1976, 4.7%
Agriculture: main crops—coffee, sugarcane, rice, corn,
sorghum, pulses; caloric intake, 1,850 calories per day per
capita
Major industries: sugar refining, textiles, flour milling,
cement manufacturing, bauxite mining, tourism, light
assembly industries
Electric power: 90,000 kW capacity (1977); 175 million
kWh produced (1977), 40 kWh per capita
Exports: $111 million (f.0.b., 1976); coffee, light industrial
products, bauxite, sugar, essential oils, sisal
87
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
HAITI/HONDURAS
Imports: $158 million (f.0.b., 1976); consumer durables,
foodstuffs, industrial equipment, petroleum products, con-
struction materials
Major trade partners: exports—52% U.S.; imports—47%
U.S. (1976)
Aid: economic authorizations—from U.S. (FY46-75), $46
million loans, $126 million grants; from international
organizations (FY46-76), $169 million; military authoriza-
tions—from U.S. (FY46-76), $4 million in grants
Budget: (1976) revenue, $133 million; expenditure, $146
million
Monetary conversion rate: 5 gourdes=US$]
Fiscal year: 1 October-30 September','c73fbde6f5bf50839f59fe6ef74a32dcee6dd7e9c4211388092bffc48bd9a7ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd6754fcdaff07cb8e7624bc3dc8ade284665d40134c58dc77d8452b89cfe554',1978,'HN','Honduras','economy',243,'GDP: $1,215 million (1976), $430 per capita; 79% private
consumption, 10% government consumption, 22% domestic
investment; — 11% net foreign balance (1975); real growth
rate, average 1971-75, 2.6%; real growth rate 1976, 6.8%
Agriculture: main crops—bananas, coffee, corn, beans,
cotton, sugarcane, tobacco; caloric intake, 2,200 calories per
day per capita (1970)
Fishing: catch 3,262 metric tons (1975); exports est. $0.8
million (1976); imports $0.8 million (1974)
Major industries: agricultural processing, textiles, cloth-
ing, wood products
Electric power: 172,500 kW capacity (1977); 450 million
kWh produced (1977), 155 kWh per capita
Exports: $404 million (f.0.b., 1976); bananas, coffee,
lumber, meat, petroleum products
Imports: $427 million (f.0.b. 1976); manufactured prod-
ucts, machinery, transportation equipment, chemicals,
petroleum
Major trade partners: exports—91% US., 12% CACM,
11% West germany; imports—42% US., 16% Venezuela,
13% CACM, 7% Japan, 3% West Germany (1975)
Aid: economic—extensions from U.S. (FY46-76), $122
million loans, $96 million grants; from international
organizations (FY46-73), $291 million; from other Western
countries (1960-73), $7.0 million; military—assistance from
US. (FY46-75), $20 million
Budget (1977): expenditures, $312 million
Monetary conversion rate: 2 lempiras=US$1 (official)
Fiscal year: calendar year','d3aefc4b563b8f6f0afdf2c0a7a5fd00579d0df518324a6a44c21c0f8557b538','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50a831326d43cb735dcea056fdbb38e371f019ba733c4d97e6f7d19f5464c841',1978,'PH','Philippines','economy',247,'GDP: $9.5 billion ( 1976, in 1976 prices), $2,093 per
capita (est.); average teal growth 4.8% (1970-75)
Agriculture: agriculture occupies a minor position in the
economy; main products—-rice, vegetables, dairy products;
less than 20% self-sufficient; food shortages—rice, wheat
Major industries: textiles and clothing, tourism, plastics,
electronics, light metal products, food processing
Shortages: industrial raw materials, water, food
Electric power: 3,127,000 kW capacity (1977); 8375
million kWh produced (1977), 1,835 kWh per capita
90
Approved For Release 2005/04/22
Exports: $9.7 billion (f.0.b., 1977), including $1.4 billion
Teexports; principal products clothing, plastic articles,
textiles, electrical] goods, wigs, footwear, light metal
manufactures
Imports: $10.5 billion (c.f, 1977)
Major trade partners: (1977) exports—38.7% U.S., 10.5%
West Germany, 8.7% U.K.; imports—23.7% Japan, 16.6%
China, 12.5% US.
Budget: (77/78) $1.82 billion
Monetary conversion rate: AK$4.62=US$1 (December
1977)
Fiscal year: | April-31_ March
GNP: $20.7 billion (1977), $463 per capita; 6.1% real
growth, 1976
Agriculture: main crops—rice, corn, coconut, sugarcane,
bananas, abaca, tobacco
Fishing: catch 1.3 million metric tons (1975)
Major industries: mining, agricultural processing, textiles,
chemicals and chemical products
Electric power: 4,076,000 kW capacity (1977); 14.5
billion kWh produced (1977), 315 kWh per capita
Exports: $3,151 million (f.0.b., 1977); coconut products,
sugar, logs and lumber, copper concentrates, bananas,
garments, nickel, abaca
Imports: $3,915 million (f.0.b., 1977); petroleum, indus-
trial equipment, wheat
Major trade partners: (1976) exports—35% U.S., 25%
Japan; imports—28% Japan, 20% US.
Aid: commitments 1970-76: U.S. economic, $467.3 mil-
lion, military, $204.8 million; Western (except USS.), $996.3
million; Eastern Europe, $35.5 million, OPEC, $61.0 million
Budget: (CY78) revenues $3.8 billion, expenditures $4.6
billion, deficit $0.8 billion; 11% military, 89% civilian
Monetary conversion rate: 7.38 pesos=US$1, February
1978
Fiscal year: calendar year','97159ec976782ef2a4f13f7b019443e45cd2ec1c53af5e0058c19daeb04f3ff6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22d55e5a967eb19c0c38cfcfd963644b9d12b254ad5eaf7ec0dea81d29681a19',1978,'HU','Hungary','economy',252,'GNP: $27.8 billion in 1977 (at 1976 prices), $2,610 per
capita; 1977 growth rate, 4.8%
Agriculture: normally self-sufficient; main crops—corn,
wheat, potatoes, sugar beets, wine grapes; caloric intake
3,140 calories per day per capita (1970)
Major industries: mining, metallurgy, engineering indus-
tries, processed foods, textiles, chemicals (especially pharma-
ceuticals)
Shortages: metallic ores (except bauxite), copper, high
grade coal, forest products, crude oil
Crude steel: 3.72 million metric tons produced (1977),
350 ke per capita
Electric power: 5,100,000 kW capacity (1977); 23.3
billion kWh produced (1977), 2,185 kWh per capita
Exports: $7,959 million (f.o.b., 1977); 27% machinery,
18% industrial consumer goods, 30% raw materials and
semimanufactures, 23% food and raw materials for the food
industry, energy sources 2% (distribution for 1977)
Imports: $8,558 million (c.i.f., 1977); 21% machinery, 8%
industrial consumer goods, 49% raw materials and semi-
manufactures; 11% food and raw materials for the food
industry, energy sources 11% (distribution for 1977)
Major trade partners: $13,371 million (1976); 66% with
Communist countries, 34% with non-Communist countries
Aid: U.S.S.R.—$338 million extended (1956-66), $10
million extended in 1967, $167 million extended in 1968; to
less developed non-Communist countries—$764 million
(1954-77)
Monetary conversion rate: 40.96 forints=US$1 (commer-
cial); 20.60 forints=US$1 (noncommercial) (1977)
Fiscal year: same as calendar year; economic data
reported for calendar years','b1d9e51a9787e9e008ff74f4e1ce4c07b1d256f831cd142a884562861d15f8ca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33200473f8375a5b38091a107daf8a00d34ab28ec199533f9a52c26926e2c4ea',1978,'IS','Iceland','economy',257,'GNP: $1,415 million (1976), $6,343 per capita; 60.2%
consumption, 29.4% investment, 10% government, 0.7%
change in stocks; 1.1% net foreign balance (1976); 1976
growth rate 1.9%, constant prices
Agriculture: cattle, sheep, dairying, hay, potatoes, turnips;
food shortages—grains, sugar, vegetable and other fibers;
caloric intake, 2,900 calories per day per capita (1964-66)
Fishing: landed 982,100 metric tons; exports $289.9
million (1976)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ICELAND/INDIA
Major industries: fish processing, aluminum smelting,
diatomite production, hydro-electricity
Shortages: grain, fuel, wood, minerals, vegetable fibers
Electric power: 653,000 kW capacity (1977); 2.5 billion
kWh produced (1977), 11,050 kWh per capita
Exports: $512.3 million (f£.0.b., 1977); fish and fish
products, animal products, aluminum, diatomite
Imports: $608.3 million (c.i.f., 1977); machinery and
transportation equipment, petroleum, foodstuffs, textiles
Major trade partners: (1975) exports—U.S. 29%, EC 25%,
U.S.S.R. 11%; imports—EC 45%, US. 9%, U.SS.R. 10%
Aid: economic authorizations: U.S., $10 million (FY70-76)
Budget: (1977, approved) expenditures $448 million,
revenues $452 million
Monetary conversion rate: 198.9 kronur=US$1 (1977);
182.2 kronur=US$1 (1976)
Fiscal year: calendar year','06c27cdc3daadcf20b107ed326ff789b45ea683bf297f0fd052938d5454f98cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03c4f11d7c3ff3fccf7cac9b18972210c7f60c70f721e458cafee3bacdeb1d93',1978,'IN','India','economy',261,'GNP: $77.3 billion (FY77 at current prices), $123 per
capita; real growth 5.0% in FY78, 1.6% in FYT77
Agriculture: main crops—rice, other cereals, pulses,
oilseeds, cotton, jute, sugarcane, tobacco, tea, and coffee
Fishing: catch 2.3 million metric tons (1975); exports
$95.1 million (1974), imports $3.1 million (1974)
Major industries: textiles, food processing, steel, machin-
ery, transportation equipment, cement, jute manufactures
Crude steel: 8.12 million metric tons of ingots (FY77)
Electric power: 23,700,000 kW capacity (1977); 96 billion
kWh produced (1977), 150 kWh per capita
Exports: $5.8 billion (f.0.b., FY77); engineering goods,
textiles and clothing, tea
94
Imports: $5.7 billion (c.if., FY77); machinery and
transport equipment, petroleum, grains and flour, fertilizers
Major trade partners: US., ULK., U.S.S.R., Japan
Budget: (FY78) central government receipts, $12.8 billion;
expenditures, $13.5 billion
Monetary conversion rate: 2.] rupees=US$1 (January
1978)
Fiseal year: fiscal year ends 31 March of stated year','932ca359616a7ad6d80865948eaa21e836685889a05bd7c223965d746cc633b1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0f657e51a8b6c2438138e3aeea9fa77e4a02d2d1b36357325fd9ea1abe8d1da',1978,'ID','Indonesia','economy',266,'GNP: $43 billion (1977) about $300 per capita; real
average annual growth (1972-77), 7.5%
Agriculture: subsistence food production, and smallholder
and plantation production for export; main crops—rice,
rubber, copra, other tropical products; food shortage—rice,
wheat
Fishing: catch 1.5 million tons (1976); exports $150
million (1977), imports $8 million (1977)
Major industries: petroleum, agricultural processing,
textiles, mining
Electric power: 2,053,900 kW capacity (1977); 5.9 billion
kWh produced (1977), 40 kWh per capita
Exports: total $10.4 billion (f.0.b., 1977); petroleum ($7.1
billion; 530 million bbls), timber, coffee, rubber, tin, palm
oil, tea, pepper, tobacco
Imports: $6.4 billion (c.i-f., 1977); rice, wheat, textiles,
chemicals, iron and steel products, machinery, transport
equipment, consumer durables
Major trade partners: exports (1977)—40% Japan, 28%
US., 9% Singapore; imports—30% Japan, 14% U.S., 8% West','3e292da2dc1015053186e01e73738bc0f384ccd9764a57383704cf2b9b4f20e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8f33b2dc47d54b3a0e25680e586b2de272407aa866a08ac020908c64630f2f7',1978,'IQ','Iraq','economy',270,'GNP: $19 billion (1977 est.), $1,550 per capita
Agriculture: dates, wheat, barley, rice, livestock
Major industry: crude petroleum (third largest producer
in Middle East); 2.3 million b/d (1977); petroleum revenues
for 1977, $10.3 billion
Electric power: 1,200,000 kW capacity (1977); 5.6 billion
kWh produced (1977), 470 kWh per capita
Exports: $10.6 billion (£.0.b., 1977 est.); net receipts from
oil, $10.3 billion; non-oil, $300 million est.
Imports: $5.0 billion (f.0.b., 1977); 26% from Communist
countries (1973)
Major trade partners: exports—France, Italy, Brazil,
Japan, Turkey, U.K., U.S.S.R., other Communist countries;
imports— West Germany, Japan, France, U.S., U.K., U.S.S.R.
and other Communist countries (1977)
18 provinces under centrally
Budget: $25.7 billion (FY78), actual estimated
Monetary conversion rate: ] Iraqi dinar=US$3.39 (end
of December 1977)
Fiscal year: 1 January-31 December','0bc92481eee3d102b4b2dbec33059a7e53ccd59a4bbcd6d7939fd7e22058235f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14a44a08d6c606459bed2c88ccf09d4212e93dddb477bfbffa46263418360913',1978,'IE','Ireland','economy',274,'GNP: $9.3 billion prelim. est. (1977, at 1977 prices),
$2,913 per capita; 63.4% consumption, 25.9% investment,
18.8% government, 2.0% inventories; — 10.2% net export of
goods and services; 1970-77 (inclusive) real growth rate,
average 3.1%
Agriculture: 70% of agricultural area used for permanent
hay and pasture; main products—livestock and dairy
products, turnips, barley, potatoes, sugar beets, wheat; 85%
self-sufficient; food shortages—grains, fruits, vegetables;
caloric intake 8,510 calories per day per capita (1970)
Fishing: catch 80,676 metric tons (1976); exports of fish
and fish products $37.3 million (1976), imports of fish and
fish products $15.7 million (1976)
Major industries: food products, brewing, textiles and
clothing, chemicals and pharmaceuticals, machinery and
transportation equipment
Shortages: coal, petroleum, timber and woodpulp, steel
and nonferrous metals, fertilizers, cereals and animal feeds,
textile fibers and textiles
Crude steel: 85,000 metric tons produced in 1975, 30 ke
per capita
Electric power: 2,387,000 kW capacity (1977); 9 billion
kWh produced (1977), 2,315 kWh per capita
Exports: $4,364 million (f.0.b., 1977 est.); live animals,
meat, dairy products, textiles, clothing, chemicals,
machinery
Imports: $5,400 million (c.i.f., 1977 est.); petroleum and
petroleum products, machinery, chemicals, cereals, textiles
Major trade partners: 66% EC (42% U.K.); 8% US.
(January-November 1977)
Aid: economic—EC Common Borrowing Facility, $300
million (1976)
Budget: (1978 projected) 2,368 million pounds expendi-
tures, 1,963 million pounds revenues, 405 million pounds
deficit, public sector borrowing requirement 821 million
pounds
Monetary conversion rate: 1 Irish pound=US$1.7448
(1977) (annual average, floating)
Fiscal year: calendar year','aaf423a4b2ad2a1a6b2ea8d5dc00d1c324a046d556db0fb4420221036fcc49c0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13417c1c2d76499f570feac728e6ba5d825c5f16ca490715709aa36dd028e24b',1978,'IL','Israel','economy',278,'GNP: $12.8 billion (1977, in 1977 prices), $3,370 per
capita (converted to dollars at 10.50 Israeli pounds=US$1);
1977 growth of real GNP (1.0%
Agriculture: main products—citrus and other fruits,
vegetables, beef and dairy products, poultry products
Major industries: food processing, diamond cutting and
polishing, textiles and clothing, chemicals, metal products,
transport equipment, electrical equipment, miscellaneous
machinery, rubber and plastic products, potash mining
Electric power: 2,500,000 kW capacity (1977); 13.5
billion kWh produced (1977), 3,720 kWh per capita
Exports: $34 billion (f.0.b., 1977); maior iterns—polished
diamonds, citrus and other fruits, textiles and clothing,
processed foods, fertilizer and chemical products; tourism is
leading foreign exchange earner
Imports: $5.4 billion (f.0.b., 1977); major items—tmilitary
equipment, rough diamonds, chemicals, machinery, iron and
steel, cereals, textiles, vehicles, ships, and aircraft
Major trade partners: exports—EC, US., U.K., Japan,
Hong Kong, Switzerland; imports—EC, U.S., U.K., Switzer-
land, Japan
Budget: FY ending 3) March 1978—$10 billion (con-
verted at 18.5 Israeli pounds=US$1)
Monetary conversion rate: the Israeli pound was allowed
to float on 31 October. 1977 and as of 3 November 1977 it
was roughly 15 Israeli pounds=US$1
Fiscal year: 1 April-31 March','77a0b106c74f70cc8940f6ea1659431bb02cf8f9f412eaa4dcd89612689fdd0a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72e2c5c49cbfe9cee4d83c3df048b6e074d2834c879615fd146d4f07c9e12cef',1978,'IT','Italy','economy',282,'GDP: $171 billion (1976), $3,040 Per capita; 65.5%
private consumption, 20.2% gross fixed investment, 13.9%
government, 3.2% inventory change, net foreign balance
— 2.8%; 1973 growth rate 6.3%, 1974 growth rate 3.4%, 1976
growth rate 5.6% (1970 constant prices)
Agriculture: important producer of fruits and vegetables;
main crops—cereals, potatoes, olives; 95% self-sufficient;
food shortages—fats, meat, fish, and eggs; daily caloric
intake, 3,335 calories per capita (1974)
Fishing: catch 376,509 metric tons (1975), $336 million
(1973); exports $46 million (1976), imports $352 million
(1976)
Major industries: machinery and transportation equip-
ment, iron and steel, chemicals, food processing, textiles
Shortages: coal, fuels, minerals
Crude steel: 23.3 million metric tons produced (1976),
418 kg per capita
Electric power: 45,000,000 kW capacity (1977); 163.6
billion kWh produced (1977), 2.875 kWh per capita
Exports: $44.3 billion (f.0.b., 1977); Principal items—
machinery and transport equipment, textiles, foodstuffs,
chemicals, footwear
Imports: $46.5 billion (cif, 1977); principal items—
machinery and transport equipment, foodstuffs, ferrous and
nonferrous metals, wool, cotton, petroleum
Major trade partners: (1977) 48.5% EC-nine (20% West
Germany, 16% France, 5% UK., 4% Netherlands, 3%
Belgium-Luxembourg); 7% U.S.; 83% USSR. and 2% other
Communist countries of Eastern Europe
Aid: donor—bilateral economic aid authorized (ODA and
OOF), $4,991 million (1970-76)
Monetary conversion rate: Smithsonian rate as of
December 1973, 650.4 lira=US$1: average of Friday closing
rates in 1977—882 lira=US$1
Fiscal year: calendar year
: CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
ITALY/IVORY COAST','88c816565f5d8e1651a2ae2e7ea750dc9d4269cb8f32a1cb06ffea0e00d86f4d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8b273de27bbe19a2c56b7817a574a673c9664db69531daedf66e256019d59ff',1978,'JM','Jamaica','economy',286,'GNP: $3,045 million (1976), $1,440 per capita; real
growth rate 1976, —6.9%
Agriculture: main crops—sugarcane, citrus fruits, ba-
nanas, pimento, coconuts, coffee, cocoa
Major industries: bauxite mining, textiles, food process-
ing, light manufactures, tourism
Electric power: 850,000 kW capacity (1977); 2.6 billion
kWh produced (1977), 1,220 kWh hr. per capita
Exports: $605 million (f.o.b., 1976); alumina, bauxite,
sugar, bananas, citrus fruits and fruit products, rum, cocoa
Imports: $991 million (c.if., 1976); fuels, machinery,
transportation and electrical equipment, food, fertilizer
Major trade partners: exports—U.S. 38%, U.K. 23%,
Norway 11%, Canada 4%; imports—U.S. 37%, U.K. 13%,
Canada 5% (1975)
Aid: economic—authorization from U.S. (FY56-76), $48
million in loans, $60 million in grants; from other Western
countries (1960-74), $151 million; from international organi-
zations (FY46-76), $232 million; military—authorizations
from U.S. (FY63-76), $1 million in grants
Budget: FY76-77—1revenue $667 million, expenditure
$1,243 million
Monetary conversion rate: 1 Jamaican dollar=US$0.95
(Basic rate); 1 Jamaican dollar=US$0.74 (Special rate)
Fiscal year: 1 April-31 March','9eecfdbc1a383448ec220ae4c9511ab6030186d92e70921200f7604a8ddb89de','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b6aea6596b24bb13baec3ff972839ff396a1dfb992b9a8d1728e2dada36e4ac',1978,'JP','Japan','economy',290,'GNP: $685 billion (1977, at 268.2 yen=US$1); $5,980 per
capita (1976); 53% personal consumption, 33% investment,
9% government current expenditure; real growth rate 5.2%
(1977); average annual growth rate (1974-76), 2.4%
Agriculture: land intensively cultivated—rice, sugar,
vegetables, fruits; 72% self-sufficient in food (1974); food
shortages—meat, wheat, feed grains, edible oil and fats;
caloric intake, 2,502 calories per day per capita (1974)
Fishing: catch 10.5 million metric tons (1975)
Major industries: metallurgical and engineering indus-
tries, electrical and electronic industries, textiles, chemicals
Shortages: fossil fuels, most industrial raw materials
Crude steel: 102 million metric tons produced (1977)
Electric power: 123,682,000 kW capacity (1977); 537
billion kWh produced (1977), 4,685 kWh per capita
Exports: $79.3 billion (f.0.b., 1977); 63% machinery and
equipment, 18% metals and metal products, 6% textiles
Imports: $61.8 billion (f.0.b., 1977); 44% fossil fuels, 7%
metals and metal products, 14% foodstuffs, 7% machinery
and equipment
Major trade partners: exports—25% US., 6% Communist
countries, 11% EC, 3% Australia, 41% other; imports— 18%
U.S., 8% Australia, 6% EC, 5% Communist countries
Aid: Japanese official foreign economic aid disbursements
1975, $1,148 million
Budget: revenues $105.9 billion, expenditures $155.9
billion, deficit $49.9 billion (general account for fiscal year
ending March 1979)
Monetary conversion rate: 268.2 yen=US$1
average rate), floating since February 1973
Fiscal year: 1 April-31 March
(1977
_ Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
JAPAN/JORDAN
Aid: about $160 million in aid was committed in 1976
from EC, China, IMF, U.S.; China has extended $362
million in aid since 1964, primarily for Tan-Zam Railway
Budget: (1977 est.) receipts including grants, $655 million,
expenditures, $833 million
Monetary conversion rate: 8.4 Tanzanian shillings=US$1
Fiscal year: 1 July-30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops—cloves, coconuts
Industries: agricultural processing
Electric power: see Tanzania (above)
Exports: $12.6 million (1968); cloves and clove products,
coconut products
Imports: $5.6 million (1968); mainly foodstuffs and
consumer goods
Major trade partners: imports—China, Japan, and
mainland Tanzania; exports—Singapore, China, Hong Kong,
Indonesia, India, Pakistan
Aid: U.K. principal source of aid until 1964; U.S. $86
million FY58-73; China is currently major source
Exchange rate: 8.4 Tanzanian shillings=US$1
Fiscal year: 1 July-30 June','70a1cbf6a1db0e948dfde1e619ed9d757c5fe23b8e668bb610e5fb21f4187df6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec0f509517f146ec381cc182f680cbac5c8c427504d06e7ed2563f14326449c7',1978,'JO','Jordan','economy',294,'GNP: $1.65 billion (East Bank only, 1976), $760 per
capita; real growth rate (1973-76), 14%
Agriculture: main crops—wheat, fruits, vegetables, olive
oil; not self-sufficient in many foodstuffs
Major industries: phosphate mining, petroleum refining,
and cement production, light manufacturing
Electric power: 170,000 kW capacity (1977); 360 million
kWh produced (1977), 120 kWh per capita, East Bank only
Exports: $253 million (f.0.b., 1977): fruits and vegetables,
phosphate rock; Communist share 11% of total (1976)
Imports: $1,321 million (c.i.f., 1977); petroleum products,
textiles, capital goods, motor vehicles, foodstuffs; Communist
share 7% of total (1976)
Aid: economic—U.S., $1,048 million economic assistance
(FY46-76), of which $16 million loans, $932 million grants;
military—$552 million total from U.S. (FY53-76) including
$324 million in MAP grants
Budget: (1977 est.)—expenditures $1,005 million (non-
military, $800 million, military $205 million), development
$412 million; deficit $45 million
Monetary conversion rate: 1 Jordanian dinar=US$3.08,
freely convertible; 0.3300 Jordanian dinar=US$1
Fiscal year: calendar year','83b3cbcc4608690d23e8acaaf86203556d0662c421b4d1df85a1a20668d760a5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e968e658cb45ec4c3cb792b3a7207569b5419ff4f53a8c23fd40580e8d0be1c',1978,'KE','Kenya','economy',298,'GDP: $3,200 million at current prices (est. 1976), $225 per
capita; 5% real growth 1970-76
Agriculture: main cash crops—coffee, sisal, tea, pyre-
thrum, cotton, livestock; food crops—corn, wheat, rice,
cassava; largely self-sufficient in food
Fishing: 33,800 metric tons (1975)
Major industries: small-scale consumer goods (plastic,
furniture, batteries, textiles, soap, agricultural processing,
cigarettes, flour), oil refining, cement
Electric power: 420,000 kW capacity (1977); 1.3 billion
kWh produced (1977), 90 kWh per capita
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Exports: $720 million (f.0.b., 1976 est.); coffee, tea,
livestock products, pyrethrum, soda ash, wattle-bark tanning
extract
Imports: $974 million (cif., 1976 est.); machinery,
transport equipment, crude oil, paper and paper products,
iron and steel products, and _ textiles
Major trade partners: U.K. and EC, Uganda, Tanzania
Budget: FY77 current revenues $780 million; current
expenditures $680 million; development expenditures $295
million
Monetary conversion rate: 8.4 Kenya shillings=US$1
Fiscal year: 1 July-30 June
GNP: $10.0 billion (1976), $590 per capita (in 1975
dollars)
Agriculture: main crops—corn, rice, vegetables; food
shortages—meat, cooking oils; production of foodstuffs
adequate for domestic needs at low levels of consumption
Major industries: machine building, electric power,
chemicals, mining, metallurgy, textiles, food processing
Shortages: complex machinery and equipment, coking
coal, petroleum
Crude steel: 2.8 million metric tons produced (1976), 106
kg per capita
Electric power: 4,150,000 kW capacity (1977); 24 billion
kWh produced (1977), 1,345 kWh per capita
Exports: $555 million; minerals, chemical and metallurgi-
cal products (1976)
Imports: $825 million; machinery and equipment, petro-
leum, foodstuffs, coking coal (1976)
Major trade partners: total trade turnover $1.4 billion;
40% with non-Communist countries, 60% with Communist
countries (1976)
Aid: economic and military aid from the U.S.S.R. and
Aid: external aid amounted to $52 million in 1974 with
Belgium providing about 30% of this amount, the European
Development Fund 15%, and World Bank about 15%; other
donors include France, Canada, Germany, U.S., Kuwait,
Abu Dhabi, PRC, UNDP, and Libya
Budget: revenues $71 million; expenditures $53.8 million
(1976 provisional)
172
Monetary conversion rate: 92.84 Rwanda francs= US$]
(official) since January 1974
Fiscal year: calendar year
GDP: $14.7 million (1970), $210 per capita
Agriculture: main crops—sugar on St. Christopher, cotton
on Nevis
Approved For Release 2005/04/22
Major industries: sugar processing, salt extraction
Electric power: 15,000 kW capacity (1977); 32 million
kWh produced (1977), 460 kWh per capita
Exports: $6.8 million (f.0.b., 1973); sugar, molasses, cotton,
salt, copra
Imports: $12.0 million (c.if., 1973); foodstuffs, fuel,
manufactures
Major trade partners: exports—50% U.S., 35% U.K;
imports—21% U.K., 17% Japan, 11% U.S. (1973)
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)
GDP: $20 million (1971 est.), $200 per capita; 6.9%
growth in 1971
Agriculture: main crops—bananas, arrowroot, coconut
Major industries: food processing
Electric power: 6,500 kW capacity (1977); 18 million
kWh produced (1977), 190 kWh per capita
Exports: $4.7 million (f.0.b., 1973); bananas, arrowroot,
copra
Imports: $18.6 million (c.i.f., 1973); fertilizer, flour,
transportation equipment, lumber, textiles
Major trade partners: exports—61% U.K., 30% CARI-
COM, 9% U.S.; imports—29% CARICOM, 28% U.K., 9%
Canada, 9% U.S. (1972)
Monetary conversion rate: 2.70 East Caribbean dol-
lars=US$1 (July 1976)','c858ba4ad455376296d53d7506038e16bc779a2e9bfed062915faa20237192b7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d177c20f9009cfcd3e169766522895595ac09145ad167ed32ec097836a488cf2',1978,'KW','Kuwait','economy',302,'GNP: $13.9 billion (1976), $13,080 per capita est.
Agriculture: virtually none, dependent on imports for
food; approx. 75% of potable water must be distilled or
imported
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
KUWAIT/LAOS
Major industries: crude petroleum production average
for 1977, 1.92 million b/d; government revenues from taxes
and royalties on production, refining, and consumption, $8.5
billion, preliminary est. for 1976; refinery production 132
million bbls (1976), average b/d refinery capacity equaled
645,000 bbls at end of 1976; other major industries include
processing of fertilizers, chemicals; building materials, flour
Electric power: 1,625,000 kW capacity (1977); 5.1 billion
kWh produced (1977), 4,555 kWh per capita
Exports: $9.84 billion (f.0.b., 1976), of which petroleum
accounted for about 98%; nonpetroleum exports are mostly
reexports, $727 million (1976 est.)
Imports: $3.32 billion (c.i.f., 1976); major suppliers—U.S.,
Japan, U.K., West Germany
Aid: an aid donor, committed bilaterally or through
multilateral agencies nearly $3 billion in economic assistance
in 1975
Budget: (FY77/78) $7.9 billion revenues
Monetary conversion rate: 1 Kuwaiti dinar=US$3.48
(1976)
Fiscal year: 1 July-30 June
GNP: $250 million, $80 per capita (1976 est.)
Agriculture: main crops—rice (overwhelmingly domi-
nant), corn, vegetables; formerly self-sufficient; food short-
ages (due in part to distribution deficiencies), including rice
Major industries: tin mining, timber, tobacco, textiles,
electric power
Shortages: capital equipment, petroleum, transportation
system, trained personnel
Electric power: 61,000 kW capacity (1977); 295 million
kWh produced (1977), 85 kWh per capita
Exports: $8.5 million (f.0.b., 1977 est.); electric power,
forest products, tin concentrates; coffee, undeclared exports
of opium and _ tobacco
Imports: $55 million (c.if., est. 1977); rice and other
foodstuffs, petroleum products, machinery, transportation
equipment
Major trade partners: imports from Thailand, U.S.S.R.,
Japan, France, China, Vietnam; exports to Thailand and
Malaysia; trade with Communist countries insignificant;
Laos was once a major transit point in world gold trade,
value of 1973 gold reexports $55 million
Aid: economic—Communist: Eastern Europe, $4.0 mil-
lion (1974-75); U.S.S.R., $66 million committed (1975-76),
China, $42 million committed (1975-76); OPEC, $1.0
million (1975); Western: $151.4 million (1970-76); U.S.,
economic, $272.3 million (1970-75), military, $1,119.5
million (1970-75)
Budget: (1973-74) receipts, 13.3 billion kip; expenditures,
36.0 billion kip; deficit 22.7 billion kip (provisional totals);
45% military, 55% no data available
Communists fully took over government in 1975
civilian; since
Monetary conversion rate: as of September 1977, 200
kip=US$1 (selling), 396-495 kip=US$1 (buying) (official)
2,000 liberation kip=US$1 (free market)
Fiscal year: 1 July-30 June
114','ea928522fc801ddd324993c2a907d643cf7c7760895279856d4619241ed210ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1449aa86fdfd14612ac552fb4fc4b3d4c589360489550e65250c83dfbef80a0d',1978,'LB','Lebanon','economy',306,'Agriculture: fruits, wheat, corn, barley, potatoes, tobacco,
olives, onions; not self-sufficient in food
Major industries: service industries, food processing,
textiles, cement, oil refining, chemicals, some metal fabricat-
ing, tourism
Electric power: 540,000 kW capacity (1977); 1.2 billion
kWh produced (1977), 480 kWh per capita
Major trade partners: exports $0.9 billion est. (f.o.b.,
1976); most to Arab countries; imports $1.4 billion est. (f.0.b.,
1977); prior to the Civil War, chiefly from EC, U.K., and
Arab countries; trade deficit covered by large net receipts
from invisibles (particularly tourism and transportation) and
private capital inflow
Budget: (1978) expenditures $680 million, revenues $460
million est.
Monetary conversion rate: 2.9639 Lebanese pounds=
US$1 as of February 1978
Fiscal year: calendar year','e4a7912ab0bc07a2b4a9195c5e50ea9ff38d4b5ef69a85fef23049429fbf3452','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e8c3a0535c748b9560fb6b72ba63ee4193f6d527aeae75bb367254701e0a2d3',1978,'LS','Lesotho','economy',310,'GNP: $315 million (FY74 est.), $270 per capita
Agriculture: exceedingly primitive, mostly subsistence
farming and livestock; principal crops are corn, wheat,
pulses, sorghum, barley
Major industries: none
Electric power: approximately 20 million kWh imported
from South Africa (1977)
Exports: labor to South Africa (remittances $120 million
est. in 1976); $12.4 million (est. f.0.b., 1976), wool, mohair,
wheat, cattle, diamonds, peas, beans, corn, hides, skins
Imports: $154.3 million (est. c.if., 1976); mainly corn,
building materials, clothing, vehicles, machinery, POL
Major trade partner: South Africa
Aid: economic aid—U.K. $9.4 million (plan FY71-75);
other $17.5 million (plan FY71-75); U.S. $30.2 million
authorized (FY61-76); no military aid
Budget: (FY76) revenues, $63 million; current expendi-
tures, $38 million; development budget, $25 million
Monetary conversion rate: Lesotho uses the South
African rand; 1 SA rand=US$1.15 (as of March 1978)
Fiseal year: 1 April-31 March','30471312151515bbaac6e3359ead2a7ae006edd7476e4f4ec26aa94ced62b2a4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07faf3e32a56e37e3beff393a5f423318d73c145b9cd66147351297bd9bb4ec7',1978,'LR','Liberia','economy',314,'GDP: $923 million (1976 est.), $570 per capita, 4%
current annual growth rate (1967-76)
Agriculture: rubber, rice, oil palm, cassava, coffee, cocoa;
imports of rice, wheat, and live cattle and beef are necessary
for basic diet
Fishing: catch 23,000 metric tons
Industry: rubber processing, food processing, construction
materials, furniture, palm oil processing, mining (iron ore,
diamonds), 10,000 b/d oil refinery
Electric power: 327,000 kW capacity (1977); 980 million
kWh produced (1977), 580 kWh per capita
117
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
LIBERIA/LIBYA
Exports: $460 million (f.0.b., 1976); iron ore, rubber,
diamonds, lumber and logs, coffee, cocoa
Imports: $399 million (c.i.f., 1976); machinery, transpor-
tation equipment, petroleum products, manufactured goods,
foodstuffs
Major trade partners: U.S., West Germany, Netherlands,
Italy, Belgium
Aid: economic—(FY46-75) U.S., $240.2 million; mili-
tary—(FY53-75) U.S., $15.7 million; other aid ($73.1 million
through FY75), sources include IBRD, U.N., IMF, West
Germany, Republic of China
Budget: (FY77) revenues $167 million, expenditures $167
million; development budget $39 million
Monetary conversion rate: Liberia uses US. currency
Fiscal year: 1 July - 30 June','22fea54ddcfe22d75ff465ffa9e56c021437aa4fe5ee7aa8b1132fb860251a98','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99b5db21145687d66e7a34fc9dfa07425232c00e0f0861a3bfcc8616dced2a54',1978,'LY','Libya','economy',318,'GNP: $16.5. billion (1977), at current prices
Agriculture: main crops—wheat, barley, olives, dates,
citrus fruits, peanuts; approaching self-sufficiency in food
Major industries: petroleum, food processing, textiles,
handicrafts
Electric power: 1,500,000 kW capacity (1977); 2.1 billion
kWh produced (1977), 775 kWh per capita
Exports: $10.5 billion (f£.0.b., 1977); over 99% petroleum
Imports: $5.4 billion (c.if., 1977)
Major trade partners: imports—lItaly, West Germany,
US; exports—Italy, West Cermany, U.K., US, France
Aid: economic—no Communist country assistance, US.
aid extended $212.5 million (FY49-76); international organi-
zations $22 million; military—arms obtained by cash
purchase; chief suppliers France, US.S.R., Czechoslovakia;
U.S. suspended since September 1970
Monetary conversion rate: 1 Libyan pound=US$3.38
Fiscal year: 1 January - 31 December (beginning 1974)','ba59a6929c8d76d148a1bb98bd1148b36a4b5280ea1aff1489b12d9d34eb3081','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc4328eb6072f927938bd2c3a6831971de553e86cccffbec012c4391d78a5fad',1978,'LI','Liechtenstein','economy',322,'Liechtenstein has a Prosperous economy based primarily
on small-scale light industry and some farming. Textiles,
ceramics, precision instruments, pharmaceuticals, and
canned foods are the principal manufactures, intended
almost entirely for export. Industry accounts for 95 percent
of total employment. Livestock raising and dairying are the
main sources of income in the small farm sector. A major
source of income to the government is the sale of postage
stamps to foreign collectors, estimated at $6 million
annually. In addition, low business taxes and easy incorpo-
rated rules have induced between 20,000 and 30,000 holding
companies, so-called letter box companies, to establish
nominal offices in the principality. The average tax paid by
one of these companies is about $400 a year.
The Liechtenstein economy is tied closely to that of
Switzerland in a customs union. No national accounts data
are available.
GNP: $292 million (1977 provisional)
Major trade partners: exports (1975)—$202 million;
50.6% EFTA, 41.4% Switzerland, 26.7% EEC; exports
(1977)—$274 million
Electric power: 23,000 kW capacity (1977); 56 million
kWh. produced (1977), 2,240 kWh per capita; power is
exchanged with Switzerland, but net exports average 35
million kWh yearly
Budget: (1977 est.) revenues $79.0 million, expenditures
$75.9 million, surplus $3.1 million','15f643b5bb2af255657ad2043787a4f98b964095f03e6820e1dfdb50966843ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77ede5b4fa0b2cbdcbe4c494c8047790ff63baade9157cd53bc034720ba87816',1978,'LU','Luxembourg','economy',326,'GNP: $2.5 billion, $7,041 per capita (1977); average
annual real GNP growth 2.7% (1971-77); 60% private
consumption, 16% public consumption, 98% investment;
—6.9% net exports, 2.9% change in stocks
Agriculture: mixed farming; main crops—egrains, pota-
toes, fodder beets; food shortages—sugar, bread grains, fats;
caloric intake, 3,150 calories per day per capita (1968-69)
Major industries: iron and steel, food processing,
chemicals, metal products and engineering, tires
Crude steel: 4.28 million metric tons produced (1977),
11.8 metric tons per capita
Approved For Release 2005/04/22 :
Electric power: 1,350,000 kW capacity (1977); 1,600
million kWh produced (1977), 4,420 kWh per capita
Exports: see Belgium
Imports: see Belgium
Major trade partners: Luxembourg and Belgium form an
economic and customs union and report their foreign trade
jointly (see Belgium); Luxembourg’s principal exports are
iron and steel products; principal imports are coal and
consumer products; most foreign trade is with Germany,
Belgium, and other EC countries
Budget (1977) expenditures $1,046 million, revenues
$1,026 million, deficit $20 million
Monetary conversion rate: LF36.36=US$1, 1976 aver-
age; under the BLEU agrcement, the Luxembourg franc is
equal to the Belgian franc which circulates freely in
Fiscal year: calendar year','d82b25e516f28492f7205319f4755aefe890913b5056a52613663736d375175c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f67e04ecb7a97d5c1d180a340b7ab2e7cdabb40bd00584b04bcda7184fc0d5b4',1978,'MO','Macao','economy',330,'Agriculture: main crops—rice, vegetables; food short-
ages—rice, vegetables, meat; depends mostly on imports for
food requirements
Major industries: textiles, fireworks
Electric power: 116,000 kW capacity (1977); 210 million
kWh produced (1977), 835 kWh per capita
Exports: $185 million (f.0.b., 1976); textiles and clothing,
foodstuffs
Imports: $160 million (c.if., 1976)
Major trade partners: exports—23% West Germany, 17%
France, 10% U.K.; imports—68% Hong Kong, 24% China
(1976)
Monetary conversion rate: 5.4 patacas=US$] (December
1975); pataca has been pegged to Hong Kong dollar starting
in 1977
Fiscal year: calendar year','5f140c3aaf188325ef7bcefd3aadac3865166dd62c02342b16c209c666e12ae3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('182969d2a4feb1eda356253aa3e8b18a505b3d6254003316d0fffcd40a2c3140',1978,'MG','Madagascar','economy',334,'GDP: $1.9 billion (1977 est.), about $220 per capita; real
growth less than 1% (1970-75)
Agriculture: cash crops—coffee, vanilla, cloves, sugar,
tobacco, sisal, rice, raphia; food crops—rice, cassava, cereals,
potatoes, corn, beans, bananas, coconuts, and peanuts;
animal husbandry widespread; imports some rice, milk, and
cereal
Fishing: catch 56,000 metric tons (1975); exports $16.5
million (1974)
Major industries: agricultural processing (meat canneries,
soap factories, brewery, tanneries, sugar refining), light
consumer goods industries (textiles, glassware), cement plant,
auto assembly plant, paper mill, oil refinery
123
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
MADAGASCAR/MALAWI
Electric power: 95,000 kW capacity (1977); 465 million
kWh produced (1977), 60 kWh per capita
Exports: $294 million (f.0.b., 1977 est.); 30% coffee, 8%
vanilla, 7% sugar, 6% cloves; agricultural and_ livestock
products account for about 85% of export earnings
Imports: $318 million (c.i.f., 1977 est.); consumer goods
about 19%, 21% foodstuffs, 41% primary products (crude oil,
fertilizers, metal products), 19% capital goods (1974)
Major trade partners: France (in 1974 accounted for 37%
of exports and 48% of imports), U.S., EC; trade with
Communist countries remains a minute part of total trade
Budget: (FY75) revenues $450 million (including $78
million projected borrowing), expenditures $417 million of
which $300 million current, $117 million development
Monetary conversion rate: 248 Malagasy francs=US$1
Fiscal year: calendar year
GNP: $2 billion (1977 est.), $420 per capita; real annual
growth rate, 2.1% (1971-76); negative in 1977
Agriculture: main crops—corn, tobacco, cotton; net
importer of most major agricultural products
Major industries: copper mining and processing
Electric power: 1,563,400 kW capacity (1977); 7.2 billion
kWh produced (1977), 1,340 kWh per capita
Exports: $900 million (f.0.b., 1977 est.); copper (92%),
zine, cobalt, lead, tobacco
Imports: $680 million (c.if., 1977 est.); machinery,
transport equipment, foodstuffs, fuels, manufactures
Major trade partners: EEC, Japan, China, South Africa
Aid: economic—China (1967-76), $331 million; U.K.
(1964-67), $63 million; IBRD (1965-75), $432 million; U.S.
(FY53-76), $36 million; U.S.S.R., $9 million; Eastern Europe,
$50 million; military—$14 million (1964-76), mainly U.K.
and Canada; $18 million, Communist
Budget: 1976 est.—revenue $510 million, expenditures
$665 million
Monetary conversion rate: 1 Zambia kwacha=US$1.12
(official)
Fiscal year: calendar year','1fc475ce4f5a80b6764a12e4f63a8a9e7f4957579bafe6250d5b99823892a90b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa175e926e9d6ce99335924f1683dd63b283509e3e8336cbd2385c970e551999',1978,'MW','Malawi','economy',338,'GDP: $840 million (1977 est.), $150 per capita; real
growth rate 5.5% (1973-75)
Agriculture: cash crops—tobacco, tea, sugar, peanuts,
cotton, tung, maize; subsistence crops—corn, sorghum,
millet, pulses, root crops, fruit, vegetables, rice
Electric power: 105,000 kW capacity (1977); 315 million
kWh produced (1977), 60 kWh per capita
Major industries: agricultural processing (tea, tobacco,
sugar), sawmilling, cement, consumer goods
Exports: $224 million (f.0.b., 1977 est.); tobacco, tea,
sugar, peanuts, cotton
Imports: $24 billion (cif., 1977 est.); manufactured
goods, machinery and transport equipment, building and
construction materials, fuel, fertilizer
Major trade partners: exports—U.K., other EC, Rhodesia,
South Africa; imports—South Africa, U.K., Rhodesia, other
EC
Aid: economic—U.K. provides major development sup-
port, about $144 million (1964-74), U.S. aid commitments,
$31.6 million (FY56-76); military—U.K., $2.4 million
(1954-68)
Budget: FY77/78 revenues $113 million; expenditures
$106 million
Monetary conversion rate: | Malawi kwacha=US$1.12
Fiscal year: 1 April - 31 March','8aa8f4bc9e66a6a97e58899af87b961e87a738afe7c911b4be534e77e13f1f2a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d676051608d159b9ed384a3085b451c7a029eafd6e992494009fc125a7b25e1',1978,'MY','Malaysia','economy',342,'GNP:
Malaysia: $12.4 billion (1977), $989 per capita; average
annual real growth 7.8% (1970-76); 8.0% (1977)
Agriculture:
Peninsular Malaysia: natural rubber, oil palm, rice;
10%-15% of rice requirements imported
Sabah: mainly subsistence; main crops—rubber, tim-
ber, coconut, rice; food deficit—rice
Sarawak: main crops—rubber, timber, pepper; food
deficit—rice
Fishing: catch 376,690 metric tons (1975)
Major industries:
Peninsular Malaysia: rubber and oil palm processing
and manufacturing, light manufacturing industry, elec-
tronics, tin mining and smelting, logging and processing
timber
Sabah: logging, petroleum production
Sarawak: agriculture processing, petroleum production
and refining, logging
Electric power:
Peninsular Malaysia: 1,475,000 kW capacity (1977);
6.5 billion kWh produced (1977), 550 kWh per capita
Sabah: 124,200 kW capacity (1977); 330 million kWh
produced (1977), 375 kWh per capita
Sarawak: 91,000 kW capacity (1977); 250 million kWh
produced (1977), 185 kWh per capita
Exports: $6.1 billion (f.0.b., 1977); natural rubber, palm
oil, tin, timber, petroleum
Imports: $5.0 billion (c.if., 1977)
Major trade partners: exports—19% Singapore, 18% US.,
20% Japan; imports—21% Japan, 11% U.K., 12% U.S., 9%','bf920d13274f3aa7a93827be4d2132917cd33ba4cb14da55c5f76f04848b119f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('025bf6f94ba9eb9fce32016c6d8a2181af9554f160eb88c45ca7ff74b1923907',1978,'SG','Singapore','economy',343,'Aid: U.S. economic 1970-76, $23.1 million; military $64.7
million; Western (except U.S.), $562.6 million; OPEC, 1974-
76, $186.5 million
Budget: 1977 revenues $3.0 billion; expenditures $3.7
billion; deficit $700 million; 20% military, 80% civilian
Monetary conversion rate: (Malaysia) 2.36 ringgits=
US$1 (February 1978)
Fiscal year: calendar year
Approved For Release 2005/04/22 :
GNP: $5.84 billion (1976), $2,560 per capita; 10.4%
average annual real growth (1966-77), 7.8% (1977)
Agriculture: occupies a position of minor importance in
the economy, self-sufficient in pork, poultry, and eggs, must
import much of its other food requirements; major crops—
rubber, copra, fruit and vegetables
Fishing: catch 17,560 metric tons (1975), imports—
137,700 metric tons (1975)
Major industries: petroleum refining, oil drilling equip-
ment, rubber processing and rubber products, processed
food and beverages, electronics, ship repair, entrepot trade,
financial services
Electric power: 1,390,000 kW capacity (1977); 5 billion
kWh produced (1977), 1,500 kWh per capita
Exports: $8.2 billion (f.0.b., 1977); 40% reexports;
petroleum products, rubber, manufactured goods
Imports: $10.5 billion (c.i-f., 1977); 18% goods reexported;
maior retained imports—capital equipment, manufactured
goods, petroleum
Major trade partners: exports—Malaysia, U.S., Japan,
U.K., Indonesia; imports—Japan, Malaysia, U.S., U.K.
Aid: Western (except U.S.) (1970-76), $172.8 million
committed; U.S. (1970-76), $1.9 million committed
Budget: (FY77/78) revenues $1.4 billion, expenditures
$2.2 billion, deficit $800 million; 15% military, 85% civilian
Monetary conversion rate: 2.32 Singapore dollars= US$1
(February 1978)
Fiscal year: 1 April-31 March','e6cdeeb2d31bdb527e0cd58dc2cbbc099f51fbfff585eba126ba98f7fe33ebd2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c47f4e846f0b739c7b64ad1e22f79dd76b40ea8cb6fc39aab038ee86cedf657a',1978,'MV','Maldives','economy',348,'GNP: $17.4 million (1974), $135 per capita
Agriculture: crops—coconut and millet; shortages—rice,
wheat
Fishing: catch 27,900 metric tons (1975)
Major industries: fishing; some coconut processing
Electric power: 4,000 kW capacity (1977); 6 million kWh
produced (1977), 50 kWh per capita
Exports: $3 million (1975); fish
Imports: $9.3 million (1975)
Major trade partners: Sri Lanka, Japan
Aid: U.K. (1960-65), $1.4 million drawn; Sri Lanka (1967),
$1 million committed; Kuwait $5 million; other OPEC
countries, Japan and India (amounts not known)
Monetary conversion rate: 3.93 Maldivian rupees= US$1,
official rate; 8.5 rupees=US$1, market rate (February 1978)
Fiscal year: calendar year','a2ef1c6bc26de9f8c8157c3aea8b6a355d8d15f5a94acf3b789bc53cc8d6de22','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6f6155f880401d7097ff07c022ece092294d68217ba35b81ad01a379a841bee',1978,'ML','Mali','economy',352,'GDP: about $590 million (1976), $100 per capita, annual
real growth rate 5.8% (1973-76)
Agriculture: main crops—millet, sorghum, rice, corn,
peanuts; cash crops—peanuts, cotton, livestock
Fishing: catch 100,000 metric tons (1975)
Major industries: small local consumer goods and
processing
Electric power: 42,000 kW capacity (1977); 105 million
kWh produced (1977), 15 kWh per capita
Exports: $95 million (f.0.b., 1976); livestock, peanuts,
dried fish, cotton, skins
Imports: $113 million (c.if., 1976); textiles, vehicles,
petroleum products, machinery, and sugar
Major trade partners: mostly with franc zone and
Western Europe: also with U.S.S.R., China
Budget: 1976 balanced at $110 million
Monetary conversion rate: 485.38 Mali francs=US$1,
November 1977
Fiscal year: calendar year
GNP: $609 million (1977), $1,970 per capita; 72% private
consumption, 26% gross investment; 17% government
consumption, —15% net foreign sector; in 1977 real GNP
growth was 9% (1977 prelim.); 12.5% (1971-76 average)
Agriculture: overall, 20% self-sufficient; adequate sup-
plies of vegetables, poultry, milk and pork products;
shortages in beef, grain, animal fodder, and fruits at various
seasons; main products—potatoes, cauliflowers, grapes,
wheat, barley, tomatoes, citrus, cut flowers, green peppers,
hogs, poultry, eggs; 2,680 calories per day per capita
Major industries: ship repair yard, clothing, building
industry, food manufacturing, textiles, tourism
Shortages: most consumer and industrial needs (fuels and
raw materials) must be imported
Electric power: 115,700 kW capacity (1977); 420 million
kWh produced (1977), 1,305 kWh per capita
Exports: $229 million (f.0.b., 1976); clothing, textiles,
ships, printed matter
Imports: $423 million (c.i.f., 1976)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
MALTA/MARTINIQUE
Major trade partners: 70% EC-nine (22% U.K., 15% West
Germany, 13% Italy); 7% U.S. (1976)
Aid: economic authorizations; U.S., $55 million (FY70-
76); other Western bilateral (ODA and OOF), $112 million
(1970-76); China, $45 million (1972); OPEC, $22 million
(1974-76)
Budget: (1978/79) projects $259 million in expenditures,
$237 million in revenues
Monetary conversion rate: 1 Maltese pound=US$2.37
(average 1977)
Fiseal year: 1 April-31 March','a29c2a68e584852c2d613cf747a4f9a5d4ba69e60ddb3034371009d9ab11d5b3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a01224fb51549be9446c9732bf01d614eccdacef33d80ca1c6d7c8b468d7189',1978,'MQ','Martinique','economy',356,'GNP: $769 million (1975 at current prices), $2,220 per
capita
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, particularly
sugar milling and rum distillation; cement, oil refining and
tourism
Electric power: 95,500 kW capacity (1977); 150 million
kWh produced (1977), 420 kWh per capita
Exports: $103 million (f.0.b., 1976); bananas, refined
petroleum products, rum, sugar, pineapples
Imports: $324 million (c.i.f., 1976); foodstuffs, clothing
and other consumer goods, raw materials and supplies, and
petroleum
Major trading partners: exports—82% F rance, 9% Italy,
9% other; imports—70% France, 6% United States, 3%
Netherlands Antilles, 3% Netherlands, 18% other (1968)
Monetary conversion rate: 4.75 French francs=US$1
(1976)
Fiseal year: calendar year','fcc195c6bbb996be60fa19b7a839d6a0f2f4cb695a82d37fce2bf188aad0141b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82f76982e760e51738ad1134ecf1ae0adcb1ee41b2e3bc211aa452b238f0db81',1978,'MR','Mauritania','economy',360,'GDP: about 320 million (1975), $240 per capita, average
annual increase in current prices about 3.2% (1971-73)
Agriculture: most Mauritanians are nomads or subsistence
farmers; main products—livestock, small grains, dates; cash
crops—gum arabic; livestock
Fishing: catch, 34,170 metric tons; exports, 29,891 metric
tons (1975)
Major industries: mining of iron ore and copper, fishing
Electric power: 70,000 kW capacity (1977); 100 million
kWh produced (1977), 70 kWh per capita
Exports: $196 million (f.0.b., 1976); iron ore, fish, copper
Imports: $215 million (c.i.f., 1976); foodstuffs, capital
goods
Major trade partners: (trade figures not complete because
Mauritania has a form of customs union with Senegal and
much local trade unreported) France and other EC
members, U.K., and U.S. are main overseas partners
Budget: 1976 est. $139 million total expenditures, $11
million development expenditure included in $139. million
total, $149 million revenue
Monetary conversion rate: 46.12 Ouguiyas=US$1 as of
November 1977
Fiscal year: calendar year','31eadb6f0469d252a440bbeec74fc0c2da7e3dc9d2f7ff690074e109673cbd5a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cde2f0e6c40069bec94be55702de0c5d9fce8d23d9e6198670ad129c99d90c2',1978,'MU','Mauritius','economy',364,'GNP: $572 million (1976), $680 per capita; real growth
(1970-76), 6%
Agriculture: sugar crop is major economic asset; about
40% of land area is planted to sugar; most food imported—
rice is the staple food—and since cultivation is already
intense and expansion of cultivable areas is unlikely, heavy
reliance on food imports except sugar and tea will continue
Shortage: land
Industries: mainly confined to processing sugarcane, tea;
some small-scale, simple manufactures; tobacco fiber; some
fishing; tourism, diamond cutting, weaving and _ textiles,
electronics
Electric power: 81,000 kW capacity (1977); 312 million
kWh produced (1977), 340 kWh per capita
Exports: $300 million (f.0.b., est. 1977); mainly sugar, tea,
molasses
Imports: $339 million (c.i.f., est. 1977); foodstuffs 30%,
manufactured goods about 25%
Major trade partners: all EC-nine countries and U.S.
have preferential treatment, U.K. buys over 50% of
Mauritius’ sugar export at heavily subsidized prices; small
amount of sugar exported to Canada, U.S., and Italy; imports
from U.K. and EC primarily, also from South Africa,
Australia, and Burma; some minor trade with China
Budget: revenues $172 million, current expenditures $168
million, investment expenditure $65 million (1976)
Monetary conversion rate: 6.7 Mauritian rupees= US$1
in August 1976 (floating with pound sterling)
Fiseal year: 1 July-30 June
Agriculture: cash crops—almost entirely sugarcane, small
amounts of vanilla and perfume plants; food crops—tropical
fruit and vegetables, manioc, bananas, corn, market garden
produce, also some tea, tobacco, and coffee; food crop
inadequate, most food needs imported
Major industries: 12 sugar processing mills, rum distilling
plants, cigarette factory, 2 tea plants, fruit juice plant,
canning factory, a slaughterhouse, and a number of small
shops producing handicraft items
Electric power: 75,000 kW capacity (1977); 185 million
kWh produced (1977), 370 kWh per capita
Exports: $62 million (f.0.b., 1975); 90% sugar, 4% perfume
essences, 5% rum and molasses, 1% vanilla and tea (1974)
Imports: $410 million (c.if., 1975); manufactured goods,
food, beverages, and tobacco, machinery and transportation
equipment, raw materials and petroleum products
Major trade partners: France (in 1970 supplied 62% of
Reunions imports, purchased 76% of its exports); Mauritius
(supplied 12% of imports)
Aid: major recipient of French foreign aid in Africa;
French economic aid, $43.8 million (1974)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
REUNION/RHODESIA
Monetary conversion rate: 4.705 French francs=US$1
Fiscal year: probably calendar year','1521af060f9252181a290afb7de660885fbeeda10b160f66b21e8ea1d94037e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67aebc174d728b873b98b2faf09cd32c295091605f78e6b173979edb739f41bd',1978,'MC','Monaco','economy',368,'GNP: 55% tourism; 25%-30% industry (small and primar-
ily tourist oriented); 10%-15% registration fees and sales of
postage stamps; about 4% traceable to the Monte Carlo
casino
Major industries: chemicals, food processing, precision
instruments, glassmaking, printing
Electric power: 8,000 (standby) kW capacity (1977); 100
million kWh supplied by France (1977)
Trade: full customs integration with France, which
collects and rebates Monacan trade duties
Monetary conversion rate: 1 franc=US$0.2102 (1977
average)','d4f2062e96ba537230bda47b5225582654208acc56ed6212820fe88a5a949124','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02b84b4be8de04f744c1bc0af76c301a9a4febd1b7782160c170b9a11fc7b6fe',1978,'MN','Mongolia','economy',372,'Agriculture: livestock raising predominates; main crops—
wheat, oats, barley
Industries: processing of animal products; building
materials; mining
Electric power: 332,000 kW capacity (1977); 995 million
kWh produced (1977), 637 kWh per capita
137
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
MONGOLIA/MOROCCO
Exports: beef for slaughter meat products, wool, fluorspar,
other minerals
Imports: machinery and equipment, petroleum, clothing,
building materials, sugar, and tea
Major trade partners: nearly all trade with Communist
countries (approx. 85% with U.S.S.R.); total turnover about
$900 million (1976)
Aid: heavily dependent on U.SS.R.
Monetary conversion rate: 3.30 tugriks=US$1 (arbitrar-
ily established)
Fiscal year: calendar year','0b82700959ced91cdae916b9e0f8b99b53addec30e6db5a8ab1205635f67a306','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4d173552b808b711307b866aac39ca29db8eea8775ee5673706c59f024a0e7e',1978,'MA','Morocco','economy',376,'GNP: $9.5 billion (1977), about $500 per capita; average
annual real growth 4% during 1970-78, 9% in 1974, under
3% in 1975-77
Agriculture: cereal farming and livestock raising predomi-
nate; main products—wheat, barley, citrus fruit, wine,
vegetables, olives; some fishing
Fishing: catch 210,479 metric tons (1975); exports $64.5
million (1975)
Major sectors: mining and mineral processing (phos-
phates, smaller quantities of iron, manganese, lead, zine, and
other minerals), food processing, textiles, construction and
tourism
Electric power: 938,000 kW capacity (1977); 3.3 billion
kWh produced (1977), 180 kWh per capita
Exports: $1,261 million (f.0.b., 1976); 55% phosphates,
25% agricultural goods, 20% other
Imports: $3.1 billion (c.i.f., 1977); 40% raw material and
semi-finished goods, 25% food, 20% equipment, 15%
consumer goods
Major trade partners: France, West Germany, Italy
Monetary conversion rate: 4.5 dirhams=US$1
Fiscal year: calendar year','57f060a4e9403b5223f2179a4600592c9a109e62fb7afc36ea46490b7a988d4f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5ff8525d4287bde1872ba039db462b99634e71dbe2dca38d1b1cda9289b6448',1978,'MZ','Mozambique','economy',380,'GNP: $2.0 billion (1975 est.), about $220 per capita;
average annual growth probably negative in 1975-77
Agriculture: cash crops—raw cotton, cashew nuts, sugar,
tea, copra, sisal; other crops—corn, wheat, peanuts, potatoes,
beans, sorghum, and cassava; self-sufficient in food except
for wheat which must be imported
Major industries: food Processing (chiefly sugar, tea,
wheat, flour, cashew kernels); chemicals (vegetable oil,
oileakes, soap, paints); petroleum products; beverages;
textiles; nonmetallic mineral products (cement, glass, asbes-
tos, cement products); tobacco
Electric power: 1,664,000 kw capacity (1977); 4.6 million
kWh produced (1977), 470 kWh per capita
140
Approved For Release 2005/04/22
ee
Exports: $155 million (1977 est.); cashew nuts, cotton,
sugar, mineral products, timber products, tea, copra
Imports: $420 million (1977 est.); machinery and electri-
cal equipment, cotton textiles, vehicles, petroleum products,
wine, iron and steel
Major trade partners: Portugal, South Africa, U.S., UK.,
West Germany
Aid: mainly from PRC, U.S., U.K., Eastern Europe, USSR
Budget: (FY76) expenditures, $310 million, revenues,
$237 million
Monetary conversion rate: 40.643 escudos=US$1 as of
November 1977
Fiscal year: calendar year','4383c46479f3719707799f570fabcf939c94e2e0874cc1c9348d0448acdd1690','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2797b01972243eae758b05a3d46c7a6fca930511947fd6d592bd85092dbd47f6',1978,'NA','Namibia','economy',384,'Agriculture: livestock raising (cattle and sheep) predomi-
nates, subsistence crops (millet, sorghum, corn, and some
wheat) are raised but most food must be imported
Fishing: catch 86,650 metric tons (1975) (processed
mostly in South African enclave of Walvis Bay)
Major industries: meatpacking, fish processing, Copper,
lead, diamond, and uranium mining, dairy products
Electric power: 297,400 kW capacity (1977); 1,040
million kWh produced (1977), 1,095 kWh per capita
Aid: South Africa is only donor
Monetary conversion rate: 1 South African Rand=
US$1.15 (as of March 1978); 0.87 SA Rand=US$1
Fiscal year: | April-31 March','49de5f6623f2ffcf276350c58d6aaff978db2f2c0751f88f6eb22296d4e8e6f5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61a5ae87f274d9f3a1b38e1255288a01561bcf0c020d684f6029a8ad96ee043f',1978,'NR','Nauru','economy',388,'GNP: over $120 million (1975), $17,140 per capita (est.)
Agriculture: negligible; almost completely dependent on
imports for food, water
Major industries: mining of phosphates, about 2 million
tons per year
Electric power: 9,000 kW capacity (1977); 26 million
kWh_ produced (1977), 3,715 kWh per capita
Exports: $120 million (f.0.b., 1975 est.); consisting entirely
of phosphates
Imports: $5 million (c.if., FY70)
Major trade partners: exports—7 5% Australia and New
Zealand: imports—Australia, ULK., New Zealand, Japan
Monetary conversion rate: 1 Australian — dol-
lar=US$1.2375 July 1976)
Fiscal year: | July-30 June','b540e168e8f040238d4395d22bdfb47595c0ad252b80619f0731dd3f93654d22','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f53d5410b64b930bfc5fa76d40fff6f4791b4f0a592eaeb0bd95b949ab9d2bd0',1978,'NP','Nepal','economy',392,'GDP: $1.3 billion (FY77, at current prices), $100 per
capita; 1% real growth in FY77
Agriculture: over 90% of population engaged in agricul-
ture; main crops—rice, corn, wheat, sugarcane, oilseeds
Major industries: small rice, jute, sugar, and oilseed mills;
match, cigarette, and brick factories
Electric power: 60,600 kW capacity (1977); 144 million
kWh produced (1977), 10 kWh per capita
Exports: $94 million est. (FY77); rice and other food
products, jute, timber
Imports: $160 million est. (FY77); manufactured con-
sumer goods, fuel, construction materials, food products
Major trade partner: over 80% India
Aid: economic commitments 1970-76: U.S.S.R., $3 mil-
lion; China, $118 million; OPEC, $18.1 million; U.S., $69
million; $48 million disbursements 1977
Budget: (FY77 est.) domestic revenues $106 million,
expenditures $190 million
Monetary conversion rate: 12 Nepalese rupees= US$1
basic rate; 1ENR=US$1 for some non-Indian commodity
trade (April 1978)
Fiscal year: 15 July-14 July','b0c4d55cb30edd83bb219c37c98515e5d811caa1a58a1a44659eab5963433c31','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24b324a0f8e7c448db7348813f6652fda1a4822e790ccd842bbbb67c72707768',1978,'NL','Netherlands','economy',396,'GNP: $105.3 billion (1977 est. in 1977 prices), $7,583 per
capita; 57.7% consumption, 21.7% investment, 17.6% gov-
ernment, 2.7% foreign balance; 0.3% net income from
abroad
Agriculture: animal husbandry predominates; main
crops—horticultural crops, grains, potatoes, sugar beets; food
shortages—grains, fats, oils; calorie intake, 3,186 calories per
day per capita (1970-71)
Fishing: catch 256,000 metric tons, $174 million (1976);
exports 204,628 metric tons, imports 131,070 metric tons
(1976)
Major industries: food processing, metal and engineering
products, electrical and electronic machinery and equip-
ment, chemicals, petroleum products, and natural gas
Shortages: crude petroleum, raw cotton, base metals and
ores, pulp, pulpwood, lumber, feedgrains, and oilseeds
Crude steel: 7.7 million metric ton capacity; 5.2 million
metric tons produced (1976), 380 kg per capita
Electric power: 16,800,000 kW capacity (1977); 63 billion
kWh produced (1977), 4,535 kWh per capita
Exports: $43.7 billion (f.0.b., 1977); foodstuffs, machinery,
chemicals, petroleum products, natural gas, textiles
Imports: $45.6 billion (c.if., 1977); machinery, transpor-
tation equipment, crude petroleum, foodstuffs, chemicals,
raw cotton, base metals and ores, pulp
Major trade partners: (1977) 62.2% EC, 27.6% West
Germany, 13.1% Belgium-Luxembourg, 6.1% U.S.
Aid: donar: bilateral economic aid authorized, $2,731
million (1970-76)
Budget: (1978 est.) revenues $34.1 billion, expenditures
$39.2. billion, deficit $5.1 billion
Monetary conversion rate: 2.4543 guilders=US$1, aver-
age 1977 floating
Fiscal year: calendar year
GNP: $413 million (1975 est.), $1,700 per capita; real
growth rate, —1% (est. )
Agriculture: little production
Major industries; petroleum refining on Curacao and
Aruba; petroleum transshipment facilities on Curacao,
Aruba, and Bonaire; tourism on Curacao, Aruba, and St.
Martin; light manufacturing on Curacao and Aruba
Electric power: 300,000 kW capacity (1977); 1.7 billion
kWh. produced (1977), 7,000 kWh per capita
Exports: $3,661 million (f.0.b., 1976): petroleum products,
phosphate
Imports: $2,519 million (cif, 1976); crude petroleum,
food, manufactures
Major trade partners; exports—64% U.S., 7% EC, 5%
Canada; imports—61% Venezuela, 12% U.S., 6% Nether-
lands (1972)
Budget: (1976) public sector current revenues, $215
million; public sector current expenditures, $212 million
Monetary conversion rate: 1.8 Netherlands Antillean
florins (NAF)=US$1, official
Fiscal year: calendar year','7ac92ec508388c9d1549ab521e9c6d7c7e1c84c5866fa4e823c9a0dae0a74245','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecd6fc891d9b7b7d7ed2f4697f134e098f36d2f51005df7e745824800b022186',1978,'NC','New Caledonia','economy',400,'GNP: $193 million, $1,800 per capita (1971 est.)
Agriculture: large areas devoted to cattle grazing; major
products—coffee and vegetables; 60% self-sufficient in beef;
must import grains and vegetables
Industry: mining of nickel
Electric power: 320,000 kW capacity (1977); 1.7 billion
kWh produced (1977), 12,145 kWh per capita
Exports: $289 million (£.0.b., 1975); 99% nickel
Imports: $348 million (c.i.f., 1975); machinery, transport
equipment, food
Major trade partners: (1972) exports—55% France, 24%
Japan, 11% U.S.; imports—52% France, 13% Australia, 12%
rest of EC
Monetary conversion rate: 86 CFP francs=US$1 (1972)
Agriculture: export crops of copra, cocoa, coffee, some
livestock and fish production; subsistence crops of copra,
taro, yams
148
Approved For Release 2005/04/22
(ee ts
Electric power: 4,000 kW capacity (1977); 18 million
kWh produced (1977), 180 kWh per capita
Exports: $27 million (1974); 24% copra, 59% frozen fish
Imports: $44 million (1974)
Monetary conversion rate: | pound =US$2.37 (official
currency), 0.74 Australian $=US$1, 86 Colonial Franc
Pacifique (CFP)=US$1 (1972)','8c5f76bff3fd3ad92d69a3114be8b212b8c87fe57a31e7984c009b24294a6f04','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c41fa8b28ff6db4b9b3a2411444edde8390ff5ccc9f6a0ef590d2fec56aebac',1978,'NZ','New Zealand','economy',404,'GNP: $12.8 billion (1976), $3,870 per capita; real average
annual growth (1975-77), 1.4%
Agriculture: fodder and silage crops about one-half of
area planted in field crops; main products—wool, meat,
dairy products; New Zealand is food surplus country; caloric
intake, 3,500 calories per day per capita (1964)
Fishing: catch 65,525 metric tons (1975)
Major industries: food processing, textile production,
machinery, transport equipment, wood and paper products
Electric power: 5,380,000 kW capacity (1977); 22.1
billion kWh produced (1977), 6,975 kWh per capita
Exports: $3.3 billion (f.0.b., 1977); principal products
(trade year 1977)—24% meat, 14% dairy products, 20% wool
Imports: $3.1 billion (cif, 1977); 29% machinery, 23%
manufactured goods, 11% chemicals (trade year 1977)
Major trade partners: (trade year 1977) exports—20%
U.K., 138% Japan, 12% Australia, 11% U.S.; imports—21%
Australia, 17% U.K., 15% Japan, 13% US.
Aid: gross official aid deliveries to LDC and multilateral -
agencies FY75, $80.1 million
Budget: expenditures, 3,827 million NZ$, receipts, 3,330
million NZ$ (FY75)
Monetary conversion rate: NZ$1=US$1.0209, January
1978
Fiscal year: 1 April-31 March
NOTE: trade data are for year ending 30 June; trade year
and fiscal year do not correspond','29f109ce657fa3eb174c4757f10b7b3460df5831074195175cb6a7d723ea1f8d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31d74f391dec5de48e5f7a597d284963c0f04a20f9beb50457c9e5312e4be63c',1978,'NI','Nicaragua','economy',408,'GDP: $2,228 million (1977 est.); 72% private consump-
tion, 9% government consumption, 21% domestic invest-
ment, —2% net foreign balance (1976); real growth rate
1977, 5.5% est.
Agriculture: main crops—cotton, coffee, sugarcane, rice,
corn, beans, cattle; caloric intake, 2,300 calories per day per
capita (1966)
Fishing: catch 18,400 metric tons (1975); exports valued
at $19.4 million (1976)
Major industries: food processing, chemicals, metal
products, textiles and clothing
Electric power: 365,000 kW capacity (1977); 1 billion
kWh. produced (1977), 425 kWh per capita
Exports: $630 million (f.0.b., 1977); cotton, coffee,
chemical products, meat, sugar
Imports: $754 million (c.i-f., 1977); food and non-food
agricultural products, chemicals and pharmaceuticals, trans-
portation equipment, machinery, construction materials,
clothing, petroleum
Major trade partners: exports—30% U.S., 23% CACM,
47% other; imports—31% US., 26% CACM, 43% other
(1976)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
or 1 T_T,
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
NICARAGUA/NIGER
Aid: economic—extensions from U.S. (FY46-76), $178
million loans, $89 million grants; international organizations
(FY46-73), $266 million; military—from U.S. (FY46-76),
$29 million
Budget: 1978 expenditures $480 million, revenues $300
million
Monetary conversion rate: 7 cordobas=US$1 (official)
Fiscal year: calendar year','59209a3a7b73255cccf09b08fddcac52e0599b74ab33ff3c1c77d8cdc6328ebb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9e68612371aebc29a5445b28b03a391169122b58c073938353305f141a691a3',1978,'NE','Niger','economy',413,'GDP: $454 million (1975 est.), $100 per capita, annual
growth estimated by U.S. Embassy at 9.8% (1973-76)
Agriculture: commercial—peanuts, cotton, — livestock;
main food crops—millet, sorghum, niebe beans, vegetables
Major industries: cement plant, brick factory, rice mill,
small cotton gins, oil presses, slaughterhouse, and a few other
small light industries; uranium production began in 197]
Electric power: 20,000 kW capacity (1977); 70 million
kWh produced (1977), 15 kWh per capita
Exports: $134 million (f.0.b., 1976); about 65% uranium,
rest peanuts and related products, livestock, hides, skins:
exports understated because much regional trade not
recorded
Imports: $176 million (c.if., 1976); fuels, machinery,
transport equipment, foodstuffs, consumer goods
Major trade partners: France (over 50%), other EC
countries, Nigeria, UDEAC countries, U.S.; preferential
tariff to EC and france zone countries
Aid: economic—France (1960 to mid-1967), $68 million;
EC (FY61-73), $100 million; U.S. (FY61-76), $73 million;
West Germany, Israel, Republic of China, and U.N. have
also extended aid; military—of $2.8 million (1954-68)
Budget: projected to balance at about $173 million (1978)
Monetary conversion rate: about 242.69 Communaute
Financiere Africaine=US$1 as of November 1977, floating
Fiscal year: 1 October-30 September','d88966129a484fb0636e88a9bef7d0bcf21a61c7b07dd8f977d8e6a726abe513','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aa12f3e1093ed7dadc92917e1ab5f01fb4f62b069c203e0fab25047ae00f51e',1978,'NG','Nigeria','economy',417,'GDP: $32 billion (est. 1977 current prices), $490 per
capita; 7.5% growth rate (1970-76)
Agriculture: main crops—peanuts, cotton, cocoa, rubber,
yams, cassava, sorghum, palm kernels, millet, corn, rice;
livestock; almost self-sufficient
Fishing: catch 506,825 metric tons (1975); imports $14.5
million (1974)
Major industries: mining—crude oil, natural gas, coal,
tin, columbite; processing industries—oil palm, peanut,
cotton, rubber, petroleum, wood, hides, skins; manufacturing
industries—textiles, cement, building materials, food pro-
ducts, footwear, chemical, printing, ceramics
Electric power: 1,367,000 kW capacity (1977); 4 billion
kWh produced (1977), 60 kWh per capita
Exports: $11.4 billion (f.0.b., 1977); oil (95%), cocoa, palm
products, rubber, timber, tin
Imports: $8.9 billion (c.if., 1977); machinery and
transport equipment, manufactured goods, chemicals
Major trade partners: U.K., EC, US.
Budget: FY77-78 proposed—current revenue $12.2 bil-
lion, current expenditures, $5.0 billion; capital expenditures,
$8.8 billion
Monetary conversion rate: 1 Naira=US$1.53 (official)
Fiscal year: 1 April-31 March','cdab8ed80db320927f7d7e746ad8f62ce9f298fc7ace1863639c5d5eef230681','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('948613a9ae860fc54e2a0fb03ba031ff263646d1417135e2556cd0eec1586408',1978,'NO','Norway','economy',421,'GNP: $35.8 billion in 1977, $8,831 per capita; 56% private
consumption; 36% investment; 19% government; net foreign
balance —11%; 1976 growth rate 3.9%, in constant prices:
4.8% average (1970-76)
Agriculture: animal husbandry predominates; main
crops—tfeed grains, potatoes, fruits, vegetables; 40% self-suf-
ficient; food shortages—food grains, sugar; caloric intake,
2,940 calories per day per capita (1969-70)
Fishing: catch 3.1 million metric tons (1976); value $476
million (1976); exports $467 million (1976)
Major industries: food processing, shipbuilding, wood
pulp, paper products, metals, chemicals
Shortages: most raw materials with the exception of
timber, petroleum, iron, copper, and ilmenite ore, dairy
products and fish
Crude steel: 732,779 metric tons produced (1977), 181 kg
per capita
Electric power: 18,200,000 kW capacity (1977); 75 billion
kWh produced (1977), 18,500 kWh per capita
Exports:. $8,712 million (f.0.b., 1977); principal items—
metals, pulp and paper, fish products, ships, chemicals, oil
Imports: $12,874 million (c.i.f., 1977); principal items—
foodstuff, ships, fuels, motor vehicles, iron and _ steel,
chemical compounds, textiles
Major trade partners: 49% EC (19% U.K., 12% West
Germany, 6% Denmark); 16% Sweden; 5% U.S.; 3% East
Bloc countries (1977)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
NORWAY/OMAN
Aid: donor: bilateral economic aid authorized (ODA and
OOF), $503 million (1970-76)
Budget: (1977) revenues $8.8 billion, expenditures $9.3
billion
Monetary conversion rate: | kroner=US$0.188 (1977)
Fiscal year: calendar year','b849e424da6b2357e5e0e8b60034215c7432b25765698bd4917a50d1e0fd0311','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89471d293da6fbb450bb82bd30a1bff0b9e51b8c0484b59cf646155d0469403b',1978,'OM','Oman','economy',425,'GNP: $1.4 billion (1976 est.), $2,710 per capita est.
Agriculture: based on subsistence farming (fruits, dates,
cereals, cattle, camels), fishing, and trade
Major industries: petroleum discovery in 1964; produc-
tion began in 1967; production 1977, 340,000 b/d; pipeline
capacity, 400,000 b/d; revenue for 1976 est. at $1.4 billion
Electric power: 200,000 kW capacity (1977); 300 million
kWh produced (1977), 555 kWh per capita
Exports: $1.6 billion (f.0.b., 1976) mostly petroleum;
non-oil exports (mostly agricultural)
Imports: $0.7 billion (c.if., 1976)
Major trade partners: U.K., US., other European, Gulf
states, India, Australia, China, Japan
155
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
OMAN/PAKISTAN
Aid: bilateral assistance pledged, $134 million in 1974,
IBRD $8 million; aid commitment by Oman, $39 million to
multilateral institutions
Budget: (1977) revenues $2.082 billion, expenditures
$2.248 billion
Monetary conversion rate: 1 Riyal Omani=US$2.92 (as
of May 1976)
Fiscal year: calendar year','2a1827275e4b5339234293ba4d1fcdcbd7415059384f22ea03b8a0916191b4ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('495df73463d49703eb05bb354ee30ce4a955e44dd17076c188982257d58c1ce9',1978,'PK','Pakistan','economy',429,'GNP: $15.2 billion (FY77 est.), $200 per capita, average
annual real growth, 3.8% (1970-77)
Agriculture: extensive irrigation; main crops—wheat, rice,
and cotton; foodgrain shortage, about 1 million tons
imported in FY77
Fishing: catch 211,000 metric tons (1976)
Major industries: cotton textiles, food processing, tobacco,
engineering, chemicals, natural gas
Electric power: 3,430,000 kW capacity (1977); 18.3
billion kWh produced (1977), 175 kWh per capita
Exports: $1,174 million (f.0.b., 1977); cotton (raw and
manufactured), rice
Imports: $2,455 million (c.i.f., 1977); fooderains, edible
oil, crude oilmachinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West Germany
Budget: expenditures, FY77—current expenditures,
$2,042 million; capital expenditures, $1,407 million
Monetary conversion rate: 9.9 rupees=US$1 (since
February 1973)
Fiscal year: 1 July-30 June','8423960316a954931c4f35eb47141d3689778cd7291ba0bc1c9787c2991b74db','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d02302e0dc62eb759c885b5bf25f0a6ab51517cd25b87c4398e449879156ae8',1978,'PA','Panama','economy',433,'GNP: $2,006 million (1976), $1,167 per capita; 66%
private consumption, 15% government consumption, 29%
gross fixed investment, —10% net foreign balance (1976):
real growth (1976), 0.0%
Agriculture: main crops—bananas, rice, corn, coffee,
sugarcane; self-sufficient in most basic foods: 2,450 calories
per day per capita (1969 )
Fishing: catch 80,183 metric tons (1975); exports $18.8
million (1974); imports $2.2 million (1974)
Major industries: food Processing, metal products, con-
struction materials, petroleum products, clothing, furniture
Electric power (including Canal Zone): 600,000 kW
capacity (1977); 2.5 billion kWh produced (1977), 1,359
kWh per capita
Exports: $250 million (f.0.b., 1977 est.); bananas, petro-
leum products, shrimp, sugar, meat, coffee
Imports: $700 million (c.i.f., 1977 est.); manufactures,
transportation equipment,
foodstuffs
Major trade partners: exports—45% US., 12% Canal
Zone, 9% West Germany, 7% Italy, 6% Netherlands.
imports—31% U.S., 18% Ecuador, 8% Venezuela, 8% Colon
Free Zone, 5% Japan, 4% Saudi Arabia, 3% Trinidad and
Tobago (1976)
Aid: economic—from US. (FY46-76), $324 million loans,
$177 million grants; from organizations
(FY46-75), $266 million; from other Western countries
(1960-71), $28.9 million; military—assistance from US.
(FY46-75), $10 million
Budget: (1978) $538 million
Monetary conversion rate: 1 balboa=US$1 (official)
crude petroleum, chemicals,
international
Fiscal year: calendar year','084a881cdcac6a20c7ec960777e0e113587c67f2801ea79c0f4ed0826c45055c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bebd05f35b3015ae28dfab267822b5e68ae244b9c7181e8b627bfc954c4b7871',1978,'PG','Papua New Guinea','economy',437,'GNP: $1.2 billion (FY76 est.); real average annual growth
rate (1969-74) 7% est.
Agriculture: main crops—coconuts, coffee, cocoa, tea
Major industries: sawmilling and timber processing,
copper mining (Bougainville)
Electric power: 284,000 kW capacity (1977); 700 million
kWh produced (1977), 240 kWh per capita
Exports: $636 million (f.0.b., FY77); principal products—
copper, coconut products, coffee beans, timber
Imports: $484 million (f.0.b., FY77)
Major trade partners: Australia, U.K., Japan
Aid: economic—Australia, $1,158 million committed
(1976-81); World Bank group (1968-September 1969), $7.5
million committed; U.S. (FY70-74), $32.5 million extended
Budget: (75-76) receipts 400 Australian dollars, expendi-
tures 408 Australian dollars
Monetary conversion rate: Kina $1=US$1.30
Fiscal year: 1 July-30 June','b5e9d27ce76375ae3cd0e03a4479d2193874bb83544f6bdf264882d8a95c8269','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54582a6f071096a099c3b87ec1b8ae2e855d2b117837f19603ec5f1d98b49056',1978,'PY','Paraguay','economy',441,'GDP: $2.0 billion (1977, at current prices), $708 per
capita; 7.0% public consumption; 73.6% private consump-
tion, 29.4% gross domestic investment, — 10.0% net foreign
balance (1976); real growth rate 1977, 8.24%
Agriculture: main crops—oilseeds, cotton, wheat, manioc,
sweet potatoes, tobacco, corn, rice, sugarcane; self-sufficient
in most foods; caloric intake, 2,580 calories per day per
capita (1963-64); protein intake, 70 grams per day per capita
(20 grams of animal origin)
Major industries: meat packing, oilseed crushing, milling,
brewing, textiles, light consumer goods, cement
Electric power: 230,000 kW capacity (1977); 550 million
kWh produced (1977), 193 kWh per capita
Exports: $181.3 million (f.0.b., 1976); cotton, oilseeds,
meat products, tobacco, timber, coffee, essential oils, tung oil
Imports: $236.3 million (£.0.b., 1976); fuels and lubricants,
machinery and motors, motor vehicles, beverages and
tobacco, foodstuffs
Major trade partners: 21% Argentina, 17% Brazil, 13%
Algeria, 10% US.
Aid: economic assistance—extensions from U.S. (FY46-76
and transition quarter), $84 million loans, $78 million grants;
from international organizations (FY46-75), $288.7 million;
from other Western countries (1960-70), $21.9 million;
military—assistance from U.S. (FY57-76), $30 million
Monetary conversion rate: 126 guaranies=US$1 (official
rate, April 1978)
Fiscal year: calendar year','73347e955134e7304bcb529cc4c80507499a299b08035601a9a9f21705056ada','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9c8420af39245b12d2c7b9453f66697e48a178a8a7e3bcac1484da83959b460',1978,'PE','Peru','economy',445,'GNP: $11.3 billion (1977, in current prices), $680 per
capita; 79% private consumption, 13.2% public consumption,
16.3% gross investment; — 8.5% net foreign balance (1976);
real growth rate (1977), —0.1%
Agriculture: main crops—wheat, potatoes, beans, rice,
barley, coffee, cotton, sugarcane; imports—wheat, meat,
lard and oils, rice, corn; caloric intake, 2,200 calories per day
per capita (1967)
Fishing: catch 2.0 million metric tons (1977); exports $219
million (1977)
Major industries: mining of metals, petroleum, fishing,
textiles and clothing, food processing, cement, auto assem-
bly, steel, ship-building, metal fabrication
Electric power: 2,073,000 kW capacity (1977): 8 billion
kWh produced (1977), 475 kWh per capita
Exports: $1,726 million (£.0.b., 1977); fish and fish
products, copper, silver, iron, cotton, sugar, lead, zinc,
petroleum, coffee
Imports: $2,131 million (f.0.b., 1977); foodstuffs, machin-
ery, transport equipment, iron and steel semimanufactures,
chemicals, pharmaceuticals
Major trade partners: exports—24% US., 15% Latin
America, 21% EC, 14% Japan, 2% U.S.S.R. (1976); imports—
31% U.S., 28% EC, 17% Latin America, 12% Japan (1974)
162
Aid: economic—extensions from U.S. (FY46-76), $223
million loans, $244 million grants; from international
organizations (FY46-75), $680 million; from other Western
countries (1960-72), $136.1 million: from Communist
countries (1969-76), $282 million; military—assistance from
US. (FY49-75), $184 million; from Communist countries
(1974), $545 million
Budget: (1977) $1.8 billion current revenues, $2.9 billion
total expenditures including debt amortization
Monetary conversion rate: 130 soles=US$1 (19 April
1978)
Fiscal year: calendar year','3614fe8a0d6d8a296f10bbe7746c0dbf29616cfe660bba7a3d9c81c6695a5277','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a18001e7897f7a2d25907c71f397a0810ca6c8929d66eebd394bd46c516d3b5',1978,'PL','Poland','economy',449,'GNP: $95.2 billion in 1977, at 1976 prices, $2,743 per
capita; 1977 growth rate, 5.1%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
tl al as
July 1978
Appro
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
POLAND/ PORTUGAL
Agriculture: self-sufficient for minimum requirements,
main crops—grain, sugar beets, oilseeds, potatoes, exporter
of livestock products and sugar; importer of grains; 3,200
calories per day per capita (1970)
Fishing: catch 656,200 metric tons (1976)
Major industries: machine building, iron and _ steel,
extractive industries, chemicals, shipbuilding, and food
processing
Crude steel: 17.8 million metric tons produced (1977),
about 510 ke. ver ‘capita
Electric power: 21,675,000 kW capacity (1977); 109.4
billion kWh produced (1977), 3,185 kWh per capita
Exports: $12,287 million (f.0.b., 1977); 46% machinery
and equipment, 35% fuels, raw materials, and sermmimanufac-
tures, 10% agricultural and food products, 9% light industrial
products
Imports: $14,646 million (f.0.b., 1977); 41% machinery
and equipment, 41% fuels, raw materials, and semimanufac-
tures; 13% agricultural and food products; 5% light industrial
products
Major trade partners: $26,933 million (1977); 56% with
Communist countries, 44% with West
Monetary conversion rate: 3,32, zlotys=US$1 {commer-
cial); 33.20 zlotys=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data are
reported for calendar years except for caloric intake which is
reported for the consumption year, 1 July-30 June','115caceac998b814fb4888d12772e9287089b35c353a91c0f021b9e9a367805d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b20fced09aa984a912849ac3e89a21e9afdc0c806416480a8f97ab47712bb897',1978,'PT','Portugal','economy',453,'GNP: $14.8 billion est. (1977); breakdown—18% govern-
ment consumption, 84% private consumption; 10% Zross
fixed investment; — 12% net exports; average annual real
GNP growth 1970-74, 8%: the Portuguese government puts
the change in real GNP at — 2.7% in 1975 and 5.8% in 1976,
but —7,.0% and +3.3% appear more realistic
Agriculture: generally underdeveloped; main crops—
grains, potatoes, olives, grapes for wine; deficit foods—sugar,
8rain, meat, fish, oi] seeds; caloric intake, 2,730 calories per
day per capita (1969)
Fishing: landed 368,633 metric tons (1976)
Major industries: textiles and footwear;
paper, and cork. metalworking;
canning; wine
wood pulp,
oil refining; chemicals: fish
Crude steel:
capita
Electric power: 4,600,000 kw capacity (1977); 10.8
billion kWh produced (1977), 1,099 kWh per capita
Exports: $1.9 billion (f.0.b. 1977): Principal items—cotton
textiles, cork and cork products, canned fish, wine, timber
and_ timber products, resin
Imports: $4.4 billion (f.0.b., 1977); principal items—
petroleum, cotton, industria] machinery, iron and steel,
chemicals
Major trade partners; 45% EC (12% U.K., 11% W.
Germany, 9% France, 4% Italy); 12% EFTA, 8% US., 4%
Spain, 3% Iraq, 3% Saudi Arabia, 3% Japan, (1976)
Aid: economic US., $178 million
(FY70-76)
Budget: 1977—receipts, $2.7 billion; expenditures, $4.2
billion; deficit, $1.5 billion)
Monetary conversion rate:
April, 1977)
Fiscal year: calendar year
COMMUN ICATIONS
Railroads: 3,593 km
460,000 tons produced (1976), 50 ke per
authorizations.
1 escudo= US$0.0258 (15
total: state-owned Portuguese Rail-
road Co. (CP) operates 2,807 km 1.665-meter gage (406 km
electrified and 426 km double track), 760 km meter-gage
(1.000 m); 26 km 1.665-meter gage double track, electrified,
Drivately-owned
Highways; 29,773 km total; 17,703 km bituminous,
bituminous treatment, concrete and stoneblock; 11,587 km
improved earth; plus an
additional 16,898 km of unimproved earth roads (motorable
Inland waterways: 820 km navigable; relatively unimpor-
tant to national economy, used by shallow-draft craft limited
to 297 metric ton cargo capacity
Pipelines: crude oil, 11 km
Ports: 6 major, 34 minor
Civil air: 27 major transport aircraft (including ] leased
out)
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
PORTUGAL/QATAR
Airfields including Azores and Madeira Islands): 50
total, 49 usable; 31 with permanent-surface runways; | with
runway over 3,660 m, 11 with runways 2,440-3,659 m, 9
with runways 1],220-2,439 m; 6 seaplane stations
Telecommunications: facilities are generally adequate;
1.19 million telephones (12.9 per 100 popl.); 39 AM, 34 FM,
and 42 TV stations; 3 submarine coaxial cables, 2 Atlantic
Ocean satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 2,256,000; 1,829,000 fit
for military service; average number reaching age (20)
annually, about 76,000
Military budget: for fiscal year ending 31 December
1977, $575.8 million; about 14% of central government
budget','e04b7a4f1adc449f15f4d5db230e98c438eaea790b9e2f90a67f3eb00c136e4a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70e633d6159a4d097992757892983c2cdf8a6abcd93c87c41697afb8cc3856ba',1978,'QA','Qatar','economy',454,'HRA}
Pig: AIN
(See reference map V}
LAND
About 10,360 km?; negligible amount forested; mostly
desert, waste, or urban
Land boundaries: 56 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 563 km
GNP: $4.0 billion (1976), $22,460 per capita
Agriculture: farming and grazing on small scale; commer-
cial fishing increasing in importance; most food imported;
rice and dates staple diet
Major industries: oil production and refining; crude oil
production from onshore and offshore averaged 435,141 b/d
(1977); 100% takeover was announced in October 1976 of
the Qatar Petroleum Company, still negotiating with Qatar
Shell about offshore fields; oil revenues accrued $2 billion in
1976, representing 95% of government/royal family income;
major development projects include $7 million harbor at Ad
Dawhah, fertilizer plant, 2 desalting plants, refrigerated
storage for fishing, and a cement plant
Electric power: capacity 300,000 kW (1977); 660 million
kWh produced (1977), 4,000 kWh per capita
Exports: crude oil dominates; exports $2.2 billion (1976)
of which petroleum is $2 billion
Imports: $817 million (cif, 1976)
Aid: aid donor, pledged $450 million 1974, disbursed $200
million
Budget: (1976) budgeted expenditures $986 million
Monetary conversion rate: 1 Qatar-Dubai riyal=US$0.26
(through October 1976)
Fiscal year: 1 April-3] March','14e07cde601c842da2013dd78dbdee33dc9291937c74e3ed5679c023649dfce2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d36cc20c78e2f53e8e1f170e622da4bf3137496562ecc4698dca6aa518ab4fdb',1978,'RO','Romania','economy',460,'GNP: $57.0 billion (1977, in 1976 prices), $2,630 per
capita; 1977 real growth rate, 3.6%
Agriculture: net exporter; main crops——corn, wheat,
oilseed; livestock—cattle, hogs, sheep; caloric intake, 118%
of requirements
Fish catch: 124,000 metric tons (1976)
Major industries: machinery, metals, fuels, chemicals,
textiles, food processing, timber processing
Shortages: iron ore, coking coal, metallurgical coke,
cotton fibers, natural rubber
Crude steel: 11.5 million metric tons produced (1977),
527 ke per capita
Electric power: 13,200,000 kW capacity (1977); 59.8
billion kWh produced (1977), 2,750 kWh per capita
Exports: $7.0 billion (f.0.b., 1977), 26% machinery and
equipment; 16% foodstuffs; 16% consumer goods; 24% fuels,
metals, materials; 18% other (1976)
Imports: $7.0 billion (mixture f.o.b. and c.if., 1977); 32%
machinery and equipment; 41% fuels, metals, raw materials;
8% foodstuffs; 19% other (1976)
Major trade partners: $14.0 billion in 1977; 57%
non-Communist countries, 43% Communist countries (18%
US.S.R.) (1976)
Monetary conversion rate: 4.47 lei=US$1 (commercial),
12 lei=US$1 (tourist)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake, which
is reported for consumption year, 1 July-30 June','980556e8e56033e07d53f5817e22cbdcb8c3ee0a1c0700b8bd26657b16c95a56','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1b5eceb9bdb43e0b0d039df812db316cf4080299bbeaf54541e46d1e7d936ec',1978,'RW','Rwanda','economy',464,'GDP: $603 million (1976 provisional), $140 per capita
Agriculture: cash crops—mainly coffee, tea, some pyre-
thrum; main food crops—bananas, cassava; stock raising;
self-sufficiency declining; country imports foodstuffs
Major industries: mining of cassiterite (tin ore), wolfram
(tungsten ore), agricultural processing, and light consumer
goods
Electric power: 35,000 kW capacity (1977); 142 million
kWh produced (1977), 32 kWh per capita
Exports: $104 million (f.0.b., 1976); mainly coffee, tea,
pyrethrum, cassiterite
Imports: $103.7 million (c.if., 1976); textiles, foodstuffs,
machines, equipment
Major trade partners: U.S., Belgium, West Germany,','dffdf83e7093c0f01cbc565e32d6ffcbcdf66f47075c9bc15b1fc44f2547fa7f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8592492245ad205ad1c365fde03222f234cfc763f4122e174d3520a7c8051eb',1978,'SM','San Marino','economy',468,'Principal economic activities of San Marino are farming,
livestock raising, light manufacturing, and tourism; the
largest share of government revenue is derived from the sale
of postage stamps throughout the world and from payments
by the Italian government in exchange for Italy’s monopoly
in retailing tobacco, gasoline, and a few other goods; main
problem is finding additional funds to finance badly needed
water and electric power systems expansions
Agriculture: principal crops are wheat (average annual
output about 4,400 metric tons/year) and grapes (average
annual output about 700 metric tons/year); other grains,
fruits, vegetables, and animal feedstuffs are also grown,
livestock population numbers roughly 6,000 cows, oxen, and
sheep; cheese and hides are most important livestock
products
Electric power: obtained from Italy, 1977
Manufacturing: consists mainly of cotton textile produc-
tion at Serravalle, brick and tile production at Dogane,
cement production at Acquaviva, Dogane, and Fiorentino,
and pottery production at Borgo Maggiore; some tanned
hides, paper, candy, baked goods, Moscato wine, and gold
and silver souvenirs are also produced
176
Foreign transactions: dominated by tourism; in summer
months 20,000 to 30,000 foreigners visit San Marino every
day; a number of hotels and restaurants have been built in
recent years to accommodate them; remittances from
Sanmarinese abroad also represent an important net foreign
inflow; commodity trade consists primarily of exchanging
building stone, lime, wood, chestnuts, wheat, wine, baked
goods, hides, and ceramics for a wide variety of consumer
manufactures','bc580ff8cf150ec0c551094cfb991c0c1d09b410a34625a95a3814d5da1a1e9e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88b514b4839a8b93c596d3cdc66c52b2f0dbecc436037feb1ec8bf4631794228',1978,'ST','Sao Tome and Principe','economy',472,'GNP: $20 million (1975 estimate); per capita income $250
(1975 est.)
Agriculture: cash crops—cocoa, copra, coconut, coffee,
palm oil, bananas
Major industries: food processing on small scale, timber
Electric power: 3,000 kW capacity (1977); 5 million kWh
produced (1977), 70 kWh per capita
Exports: $8.5 million (f.0.b., 1976); mainly cocoa (90%),
copra (7%), coconut, coffee, palm oil
Imports: $10 million (c.if., 1976); communications
equipment, light and heavy vehicles, food products,
beverages, fuels and lubricants
Major trade partners: main partner, Portugal; followed
by Netherlands, West Germany, African neighbors
Aid: Portugal remains principal aid donor; however, the
PRC and UNDP have established substantial programs of
technical assistance and the Romanians and Cubans have
somewhat smaller programs, the U.S. is providing some
training for Sao Tomeans under regional AID programs
Budget: balanced at an estimated $6.6 million (1975)
Monetary conversion rate: 40.64 escudos=US$1 (Novem-
ber 1977)
Fiscal year: probably calendar year
Approved For Release 2005/04/22','81368a502f41d2ebe027da5b82ce7a4368d21bbdf0c3feac470e6a7fa7f34da7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54b86d26575cde7d9ef6add7b7b07a302ed12676ee6a3fd510648dceafb0cb24',1978,'SA','Saudi Arabia','economy',476,'GNP: $48 billion (1976 est.), $8,300 per capita; annual
growth in real non-oil GNP approx. 15% (1973/76 average,
non-oil)
Agriculture: dates, grains, livestock; not self-sufficient in
food
Major industries: petroleum production 8.6 million b/d
(1976); payments to Saudi Arabian Government, $31 billion
(1976 est.); cement production and small steel-rolling mill
and oil refinery; several other light industries, including
factories producing detergents, plastic products, furniture,
etc.; PETROMIN, a semipublic agency associated with the
Ministry of Petroleum, has recently completed a major
fertilizer plant
Electric power: 2,930,000 kW capacity (1977); 6.5 billion
kWh produced (1977), 889 kWh per capita
Exports: $35.5 billion (f.0.b., 1976); 99% petroleum and
petroleum products
Imports: $13.4 billion (cif, 1976); manufactured goods,
transportation equipment, construction materials, and proc-
essed food products
Major trade partners: exports—U.S., Western Europe,
Japan; imports—U.S., Japan, West Germany
Monetary conversion rate: 1 Saudi riyal=US$0.28 as of
February 1976 (linked to SDR, freely convertible)
Fiscal year: follows Islamic year; the 1973-74 Saudi fiscal
year covers the period 30 July 1973 through 1 July 1974','e7165726a0aec88534b800b6fe4eb47a429b93aac263101f47fb187084fc01d3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d7a7afa59458ee062e51be9fa21c7a25615458dde0e6bb9fc419821e7a7dcf0',1978,'SN','Senegal','economy',480,'GNP: $1.7 billion (1976), $360 per capita; real growth
—2.3% in 1976
Agriculture: main crops—peanuts, millet, sorghum, man-
ioc, rice; peanuts primary cash crop; production of food
crops increasing but still insufficient for domestic re-
quirements
Fishing: catch 361,673 metric tons (1975); exports $30.9
million (1974)
Major industries: fishing, agricultural processing plants,
light manufacturing, mining
Electric power: 183,850 kW capacity (1977); 603 million
kWh produced (1977), 115 kWh per capita
Exports: $503 million (f.0.b., 1976); peanuts and peanut
products; phosphate rock; canned fish
Imports: $663 million (c.i.f., 1976); food, consumer goods,
machinery, transport equipment
Major trade partners: France, EC (other than France),
and franc zone
Aid: economic—France (1966-70), $115 million; China
(1976), $51.8 million; U.S. (FY61-76), $69 million; U.S.S.R.,
$7.6 million; EC (1961-73), $154 million; military—U.S.
(FY61-76), $2.8 million
Budget: 1978—balanced at $629 million
Monetary conversion rate: francs; about 242.69 Com-
munaute Financiere Africaine francs=US$1 as of November
1977, floating
Fiscal year: 1 July-30 June','988059c2ebcf56a670f21baaad5a6be6c4be1d57fec79d94411ea68b7ac423ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62b029d19e33e0586231e96b755e3900cd7ba9dd501c3642ba97604d4c2d117d',1978,'SC','Seychelles','economy',484,'GDP: $29 million (1974); $500 per capita; 4.6% growth
rate (1974)
Agriculture: islands depend largely on coconut production
and export of copra; cinnamon, vanilla, and patchouli (used
for perfumes) are other cash crops; food crops—small
quantities of sweet potatoes, cassava, sugarcane, and
bananas; islands not self-sufficient in foodstuffs and the bulk
of the supply must be imported; fish is an important food
source
Major industries: processing of coconut and vanilla,
fishing, small-scale manufacture of consumer goods, coir
rope factory, tea factory, tourism
Electric power: 11,000 kW capacity (1977); 25 million
kWh produced (1977), 410 kWh per capita
Exports: $6 million (f.0.b., 1975); cinnamon (bark and oil)
and vanilla account for almost 50% of the total, copra
accounts for about 40%, the remainder consisting of
patchouli, fish, and guano
Imports: $33 million (c.if., 1975); food, tobacco, and
beverages account for about 40% of imports, manufactured
goods about 25%, machinery and transport equipment,
petroleum products, textiles
Major trade partners: exports—India, U.S.; imports—
U.K., Kenya, South Africa, Burma, India, Australia
Aid: $32 million in aid during 1974-76 from U.K.; US
(FY53-76) $0.8 million
Budget: (1978) proposed revenues, $13 million; expendi-
tures $17 million
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SEYCHELLES/SIERRA LEONE
Monetary conversion rate: 5.4 Seychelles rupees=US$1
Fiscal year: calendar year','3664ba25583b9cd36b473d193f3d979870d952f4221d1ee725003e367919856c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd1d47afc1193c3d164374b35ea08e1e91ce271459ca8ab717cf2b8d34971a02',1978,'SL','Sierra Leone','economy',488,'GDP: $680 million (mid 1975), $240 per capita; growth
rate 1.8% (mid-1971 to mid-1975)
Agriculture: main crops—palm kernels, coffee, cocoa,
rice, yams, millet, ginger, cassava; much of cultivated land
devoted to subsistence farming; food crops insufficient for
domestic consumption
Fishing: catch 67,797 metric tons (1975); imports $2.7
million (1974)
Major industries: mining—diamonds, iron ore, bauxite,
rutile; manufacturing—beverages, textiles, cigarettes, con-
struction goods; 1 oil refinery
Electric power: 85,000 kW capacity (1977); 264 million
kWh produced (1977), 80 kWh per capita
Exports: $105 million (f.0.b., 1976); diamonds, iron ore,
palm kernels, cocoa, coffee
Imports: $124 million (f.0.b., 1976): machinery and
transportation equipment, manufactured goods, foodstuffs,
petroleum products
Major trade partners: U.K., EC, U.S., Japan, Communist
countries
Budget: (FY77 est.) current revenues $102 million, total
expenditures $145 million
Monetary conversion rate: 1 leone=US$0.91 (November
1977)
Fiscal year: 1 July-30 June','db07c191ed33e8ea66f33c6cf218e8b65fecfbecc14499139bd68ab015a9d3b4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78f4c8a455598aa733eb2e310e3e79c8c7862fa11c9dc3db0e9d78c847503c31',1978,'SB','Solomon Islands','economy',494,'GDP: $40 million (1973)
Agriculture: largely dominated by coconut production
with subsistence crops of yams, taro, bananas; self-sufficient
in rice
Electric power: 6,000 kW capacity (1977); 13 million
kWh produced (1977), 60 kWh per capita
Exports: $15.5 million (1975); 39% copra, 27% timber,
23% fish
Imports: $29.2 million (1975)
Major trade partners: exports—EEC excluding U.K. 42%,
Japan 29%; imports—Australia 34%, U.K. 14%, Japan 13%
(1975)
Budget: (1971) revenues $9.8 million, expenditures $9.9
million
Monetary conversion rate: 1 Australian dollar=US$1.24
(July 1976)','8bf011415b304443ec59fdc02fc262482a6fde419069b086e18dfa436b87c1bb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2593682b55f1b11f2e50aa6fb5944525527d8202fa5e5782619add1a629543d1',1978,'SO','Somalia','economy',498,'GDP: $340 million (1975 est.), $110 per capita
Agriculture: mainly a pastoral country, raising livestock;
crops—bananas, sugarcane, cotton, cereals
Major industries: a few small industries, including a sugar
refinery, tuna and beef canneries, textiles, iron rod plant,
and petroleum refining
Electric power: 18,000 kW capacity (1977); 45 million
kWh produced (1977), 10 kWh per capita
Exports: $85 million (f.0.b., 1976); livestock, hides, skins,
bananas
Imports: $176 million (c.if., 1976); textiles, cereals,
transport equipment, machinery, construction materials and
equipment, petroleum products; also military materiel in
1977
Major trade partners: Arab countries and Italy; $21.4
million imports from Communist countries (1975 est.)
Monetary conversion rate: 6.295 Somali shillings=US$1
Fiscal year: 1 January-31 December','695c240be8cf34ead039862cf089b8f2b933ae2e7be78ee4c126a90ecb3cf4f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f31adca60211029eb4a7bd72ab8b07f41318b0b2542a64f6f979bc86e9450da5',1978,'ZA','South Africa','economy',502,'GDP: $38.9 billion (1977), about $1,431 per capita; real
growth rate 0.5% (1977)
Agriculture: main crops—corn, wool, wheat, sugarcane,
tobacco, citrus fruits; dairy products; self-sufficient in
foodstuffs
Fishing: catch 1.3 million metric tons (1975)
Major industries: mining, automobile assembly, metal-
working, machinery, textiles, iron and_ steel, chemical,
fertilizer, fishing
Electric power: 15,272,800 kW capacity (1977); 87 billion
kWh produced (1977), 3,205 kWh per capita
Exports: $7.3 billion (f.o.b., 1977, excluding gold); wool,
diamonds, corn, uranium, sugar, fruit, hides, skins, metals,
metallic ores, asbestos, fish products; gold output $2.7 billion
(1976)
Imports: $8.7 billion (c.if., 1977); motor vehicles,
machinery, metals, petroleum products, textiles, chemicals
186
Major trade partners: U.K. and other Commonwealth
nations, U.S., West Germany, Japan
Aid: no military or economic aid
Budget: FY79—revenue $8.8 billion, expenditures $11.3
billion
Monetary conversion rate: 1 SA Rand=US$1.15 as of
October 1977, 0.87 SA Rand=US$1
Fiscal year: 1 April-31 March
GDP: estimated at $150 million, $86 per capita
Agriculture: cash crops—tea, phormium tenax, small
amount of coffee; food crops—corn, sorghum, dry beans;
imports over half its foodstuffs from South Africa; two-thirds
of Transkei devoted to grazing—1.2 million cattle, 2.5
million sheep, 1.3 million goats
Major industries: forestry, textiles, tourism
Exports: timber, labor to South Africa, tea, sacks
Imports: foodstuffs, machines, equipment
Major trade partners: South Africa
Aid: South Africa, almost $500 million since 1970
Budget: $156 million (1976-77), about 70% of which is
provided by the South African government
Monetary conversion rate: 1 South African Rand=
US$1.15
Fiscal year: 1 April-31 March','8e054c7a00511ec1fcc23fb7ac944d5f8a33a45665e473d6ad1f262e3e4aabbd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8af907c88abc5c7cd0e56de4d08b467c0e2e346119354ce3a44f7aa8fbd5d5b5',1978,'ES','Spain','economy',506,'GNP: $104.2. billion (1976), $2,896 per capita; 69.9%
private consumption, 10.3% public consumption, 23.1% gross
fixed investment, 1.5% stockbuilding; — 4.8% foreign bal-
ance (1976); real growth rate 1.8% (1976); typical growth
rate 6.5%
Agriculture: main crops—cereals, oranges, grapes for
wine, potatoes, olives, sugar beets; virtually self-sufficient in
good crop years; caloric intake, 2,750 calories per day per
capita (1969-70)
Fishing: landed 1.52 million metric tons valued at $1,152
million in 1976
Major industries: food processing, textiles and apparel
(including footwear), metal manufacturing, chemicals, ship-
building, automobiles
Shortages: crude petroleum
Crude steel: 10.9 million metric tons produced (1976),
300 kg per capita
Electric power: 29,100,000 kW capacity (1977); 92.9
billion kWh produced (1977), 2,545 kWh per capita
Exports: $10,208 million (f.0.b., 1977); principal items—
oranges and other fruits, iron and steel products, textiles,
wines, mercury, ships, canned fruits, vegetables, and
footwear
Imports: $17,779 million (c.if., 1977): principal items—
machinery and transportation equipment, petroleum and
petroleum products, grains, cotton, iron and _ steel
Approved For Release 2005/04/22 :
Major trade partners: (1976) 32.1% EC, 10.5% U.S. and
Canada, 16.7% rest of OECD, 81% Latin America, 2.9%
CEMA
Aid: economic authorizations—U.S., $1,236 million autho-
rized (FY70-76); other Western bilateral (ODA and OOF),
$448 million (1970-76); military authorizations—U.S., $238
million (FY70-76)
Budget: (1977 central government)—budgeted revenues
$12,726 billion, budgeted expenditures $12,726 billion
Monetary conversion rate: 1 peseta = US$0.0132 (1977
average)
Fiscal year: calendar year','55a6248bcea50d9dcc71c289df0721ce5fa29e9157e327b21b2bad0f1c8ab285','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e34def48de947eccb27a97a4137edbbaa6f7d65b1eefe93f15d186c47f0ffdc5',1978,'LK','Sri Lanka','economy',509,'GNP: $3.1 billion in 1976 (1976 prices), $200 per capita;
real growth rate 4.4% (1977), 3.0% (1976)
Agriculture: agriculture accounts for about 37% of GNP:
main crops—rice, rubber, tea, coconuts; 60% self-sufficient
in food; food shortages—rice, wheat, sugar
Fishing: catch 136,844 metric tons (1976)
Major industries: processing of rubber, tea, and other
agricultural commodities; consumer goods manufacture
Electric power: 430,000 kW capacity (1977); 1.4 billion
kWh. produced (1977), 100 kWh per capita
Exports: $781 million (1977); tea,
products
rubber, coconut
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
SRI LANKA/SUDAN
Imports: $768 million (1977); food, petroleum, fertilizer
Major trade partners: (1976) exports—10.0% China, 9.7%
U.K.; imports—12.7% Saudi Arabia, 10.6% Iran
Budget: 1977 est. revenue $607 million, expenditure $829
million
Monetary conversion rate: 16 rupees=US$1 (November
1977)
Fiscal year: 1 January-31 December (starting 1973)','9dc34aec68bd830910b79afda00618a46ae1955a99b597f59f49f981e8bc3f58','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6d92cb418bee1ed8e000bb9e58af028266d3f3ef3ae5ec903c656705fb6d02b',1978,'SD','Sudan','economy',513,'GDP: $3.9 billion at current prices (1976), $265 per capita
at current prices; 4%-5% growth rate (1977)
Agriculture: main crops—sorghum, millet, wheat, sesame,
peanuts, beans, barley; not self-sufficient in food production;
main cash crops—cotton, gum arabic, peanuts, sesame
Major industries: cotton ginning, textiles, brewery,
cement, edible oils, soap, distilling, shoes, pharmaceuticals
Electric power: 231,800 kW capacity (1977); 672 million
kWh produced (1977), 40 kWh per capita
Exports: $554 million (f.0.b., 1976): cotton (51%), gum
arabic, peanuts, sesame; $57.5 million exports to Communist
countries (FY76)
Imports: $979 million (c.if., 1976); textiles, petroleum
products, vehicles, tea, wheat; $75 million imports from
Communist countries (FY76)
Major trade partners: U.K., West Germany, Italy, India,
China, France, Japan
Monetary conversion rate: | Sudanese pound= US$2.87
(official); 0.348 Sudanese pound=US$1
Fiscal year: 1 July-30 June
GNP: $503 million (1976 est.); $1,140 per capita; real
growth rate 1976, 0.3%
Agriculture: main crops—rice, sugarcane, bananas; self-
sufficient in major staple (rice); caloric intake 2,350 calories
per day per capita (1968)
Major industries: bauxite mining, alumina and aluminum
production, lumbering, food processing
Electric power: 189,000 kW capacity (1977); 1 billion
kWh produced (1977), 2,330 kWh per capita
Exports: $151 million (f.0.b., 1976 est.); bauxite, alumina,
aluminum, wood and wood products, rice
Imports: $120 million (c.i-f., 1976 est.); capital equip-
ment, petroleum, iron and steel, cotton, flour, meat, dairy
products
Major trade partners: exports—35% U.S., 34% EC, 18%
other European countries; imports—34% US., 38% EC, 13%
Caribbean countries, 18% Europe (1975)
Aid: economic—extensions from U.S. (FY54-76), $1.0
million in loans, $4.8 million in grants; from Netherlands,
EC, UNDP (1964-74), $180 million; planned from Nether-
lands (1976-85), $1.5 billion
Budget: revenue, $352 million; expenditure, $367 million
(1978 est.)
Monetary conversion rate:
f].)=US$0.565 (September 1976)
Fiscal year: calendar year
GDP: approximately $224 million (FY74), about $470 per
capita; growth rate in current prices as much as 11%
(FY71-74)
Agriculture: main crops—maize, cotton, rice, sugar, and
citrus fruits
Major industry: mining
Electric power: 75,000 kW capacity (1977); 180 million
kWh produced (1977), 250 kWh per capita
Exports: $191 million (f.0.b., 1976); sugar, iron ore,
asbestos, wood and forest products, citrus, meat products,
cotton
Imports: $200 million (f.0.b., 1976); motor vehicles,
petroleum products, foodstuffs, and clothing
Major trade partners: South Africa, U.K., USS.
Aid: economic—U.K. $14.7 million (budgeted, 1971-73),
U.S. $10.9 million (FY61-76), others approximately $1.3
million; no military aid
Budget: FY77—revenue $86 million, recurrent expendi-
ture $47 million, development expenditure $39 million
Monetary conversion rate: | Lilangeni=US$1.15 (as of
March 1978)
Fiscal year: 1 April-31 March','a47ddbaa877d581ef788568f288b51898300fcfe0c26607af32355dcfc8e6dd1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61dae30fe80a1c0884e8428d2eacd484aeaa8ede952f46a2cd5ea90124795d6c',1978,'SE','Sweden','economy',517,'GDP: $78.5 billion, $9,000 per capita (1977); 53.8%
consumption, 20.38% investment, 28.7% government, — 0.4%
inventory change; —2.4% net imports of goods and services;
1977 growth rate —2.5% in constant prices
Agriculture: animal husbandry predominates with milk
and dairy products accounting for 40% of farm income;
main crops—erains, sugar beets, potatoes; 80% self-suffi-
cient; food shortages—oils and fats, tropical products; caloric
intake, 2,903 calories per day per capita (1975)
Fishing: catch 198,300 metric tons (1976), exports $28
million, imports $189 million
Major industries: iron and steel, precision equipment
(bearings, radio and telephone parts, armaments), shipbuild-
ing, wood pulp and paper products, processed foods, textiles,
chemicals
Shortages: coal, petroleum, textile fibers, potash, salt
Crude steel: 5.1 million metric tons produced (1976), 625
kg per capita
195
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SWEDEN/SWITZERLAND
Electric power: 25,000,000 kW capacity (1977); 87.5
billion kWh produced (1977), 10,600 kWh per capita
Exports: $18,839 million (f.0.b., 1977); machinery, motor
vehicles and ships, wood pulp, paper products, iron and steel
products, metal ores and scrap, chemicals
Imports: $20,022 million (c.i.f., 1977); machinery, motor
vehicles, petroleum and petroleum products, textile yarn
and fabrics, iron and steel, chemicals, food, and live animals
Major trade partners: (1976) 15% West Germany, 12%
UK., 6% U.S., 9% Norway, 8% Denmark; 49% EC-9; 6%
U.S.S.R. and Eastern Europe
Aid: donor: economic aid authorized (ODA and OOF),
$1,978 million (1970-76)
Budget: 1976—revenues $22.5 billion, expenditures $23.0
billion
Monetary conversion rate: 4.48 kroner=US$1 average
exchange rate 1977
Fiscal year: 1 July-30 June','652910ee5cabf28bb6a2acc19ac067a14dcdba8f1db7dbd49c16e4844db022f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e1a5f68391be4deec4717544d2511f05029453f3cf5f6bf042aab6cdbcd0f6c',1978,'CH','Switzerland','economy',521,'GNP: $63.71 billion provisional (1977 at 1977 prices),
$10,097 per capita; 60.2% consumption, 20.3% investment,
12.8% government, net foreign balance 6.7% (1977); 1970-76
average growth rate 1.3%, constant prices
Agriculture: dairy farming predominates; less than 50%
self-sufficient; food shortages—fish, refined sugar, fats and
oils (other than butter), grains, eggs, fruits, vegetables, meat;
caloric intake, 3,190 calories per day per capita (1969-70)
Major industries: machinery, chemicals, watches, textiles,
precision instruments
Shortages: practically all important raw materials except
hydroelectric energy
Electric power: 12,000,000 kW capacity (1977); 46 billion
kWh produced (1977), 7,290 kWh per capita
Exports: $17.57 billion (£.0.b., 1977); principal items—
machinery and equipment, chemicals, precision instruments,
metal products, textiles, foodstuffs
Imports: $17.93 billion (cif. 1977); principal items—
machinery and transportation equipment, metals and metal
products, foodstuffs, chemicals, textile fibers and yarns
Major trade partners: 56% EC (22% West Germany, 11%
France, 9% Italy, 7% U.K.); 9% EFTA (5% Austria); 7% U.S.;
5% Communist countries (1977)
Aid: donor: bilateral economic aid authorized (ODA and
OOF), $321 million (1970-76)
Budget: receipts, $5,842 million, expenditures, $6,454
million, deficit, $612 million (1977)
Monetary conversion rate: 9.4035 Swiss francs=US$1
(average 1977, floating)
Fiscal year: calendar year
GDP: $5.9 billion (1976), $775 per capita; real GDP
growth rate 8%, 1976
Agriculture: main crops—cotton, wheat, barley and
tobacco; sheep and goat raising; self-sufficient in most foods
in years of good weather
Major industries: textiles, food processing, beverages,
tobacco; petroleum (est. 180,000 b/d production, 117,000
b/d refining capacity)
Electric power: 1,374,000 kW capacity (1977); 1:7 billion
kWh produced (1977), 210 kWh per capita
Exports: $1.1 billion projected (f.0.b., 1976); petroleum,
textiles and textile products,. tobacco, fruits and vegetables,
cotton
Imports: $2.4 billion (c.i.f., 1976); machinery and metal
products, textiles, fuels, foodstuffs
Major trade partners: exports—Italy, West Germany,
U.S.S.R., Yugoslovia; imports—Switzerland, West Germany,
Italy, Saudi Arabia
Budget: 1978 official plan—revenues $4.6 billion (includ-
ing Arab aid payments), expenditures $4.6 billion
Monetary conversion rate: 3.95 Syrian pounds=US$]
Fiscal year: calendar year
Mainland:
GDP: $2.4 billion (1976), about $150 per capita; real
growth rate, 4% (1970-75)
Agriculture: main crops—cotton, coffee, sisal on mainland
Fishing: catch 180,746 metric tons (1975); exports valued
at $638,000, imports $1.1 million (1975)
Major industries: primarily agricultural processing
(sugar, beer, cigarettes, sisal twine), diamond mine, oil
refinery, shoes, cement, textiles, wood products
Electric power: 365,000 kW capacity (1977); 1,278
million kWh produced (1977), 80 kWh per capita
Exports: $468 million (f.o.b., 1977 projected); coffee,
cotton, sisal, cashew nuts, meat, diamonds, cloves, tobacco,
tea
199
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
TANZANIA/THAILAND
Imports: $795.6 million (c.i.f., 1977 projected); manufac-
tured goods, machinery and transport equipment, cotton
piece goods, crude oil, foodstuffs
Major trade partners: exports—China, U.K., Hong Kong,
{ndia, U.S.; imports—U.K., China, West Germany, US.,','d5d4ee5ddaa39ff3c1f15ca15ac252b06fdc130c3946d9c1634182ff542b9568','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab6f6b9e181f4b7af80b631422d9c915c639700df0e75447ba0294e68526d0dc',1978,'TH','Thailand','economy',525,'GDP: $18.2 billion (1977), $406 per capita; 6.2% real
growth in 1977 (7.0% real growth, 1972-77)
Agriculture: main crops—rice, sugar, corn, rubber,
tapioca
Fishing: catch 1.7 million metric tons (1976); major
fishery export, shrimp, 15,218 metric tons, about $66
million, total marine export, about $118 million (1976)
Major industries: agricultural processing, textiles, wood
and wood products, cement, tin and tungsten ore mining;
world’s second largest tungsten producer and third largest tin
producer
Shortages: fuel sources, including coal, petroleum; scrap
iron, and fertilizer
Electric power: 2,829,000 kW capacity (1977); 10.9
billion kWh produced (1977), 245 kWh per capita
Exports: $3.6 billion (f.0.b., 1977); rice, sugar, corn,
rubber, tin, tapioca, kenaf
Imports: $4.6 billion (cif, 1977); machinery and
transport equipment, fuels and lubricants, base metals,
chemicals, and fertilizer
Major trade partners: exports—Japan, U.S., Singapore,
Netherlands, Hong Kong, Malaysia; imports—Japan, U.S.,
West Germany, U.K.; about 1% or less trade with
Communist countries
Aid: OPEC, $7.4 million (1975-76); U.S., economic $164.2
million (1970-76), military $580.0 million (1970-76); West-
ern countries, $573.6 million (1970-76)
Budget: (FY78) planned receipts $4,050 million; 19.5%
military, 80.5% civilian
Monetary conversion rate: 20.4 baht=US$1 (February
1978)
Fiscal year: 1 October-30 September','d57a1c368e56f54eeaef956c315c632e89f1b5de10e492855f560644865d535a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87def3f8d60fb9f0d57086343720078a001294200b98d22abf1b787421e678ca',1978,'TG','Togo','economy',529,'GDP: $525 million (1975), about $210 per capita;
estimated real growth 1966-70, 5.3% average annual rate
no Communist Party; possibly some
Agriculture: main cash crops—coffee, cocoa, cotton;
major food crops—yams, cassava, corn, beans, rice, millet,
sorghum, fish; must import some foodstuffs
Major industries: phosphate mining, agricultural process-
ing, handicrafts, textiles, beverages
Electric power: 30,000 kW capacity (1977); 110 million
kWh produced (1977), 45 kWh per capita
Exports: $128 million (f.0.b., 1976); phosphates, cocoa,
coffee, palm kernels, and cassava
202
Imports: $162 million (c.i-f., 1976); consumer goods, fuels,
machinery, tobacco, foodstuffs
Major trade partners: mostly with France and other EC
countries
Aid: 1975 disbursements—France, $13.6 million; West
Germany, $2.5 million; EEC, $1.5 million; U.S., $1.1 million;
FY59-75 total commitments—EC, $62.9 million; U.S., $30
million; U.N., $16.8 million; others, $24.6 million; China
(1972), $45 million
Budget: (1977 proposed), revenues and expenditures,
$221 million
Monetary conversion rate: Communaute Financiere
Africaine 249.35 francs=US$1 as of February 1977
Fiscal year: calendar year','93c25c606383920abe83aa6bec4af7a65370dc202676f1473e09cb727e5f4eca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('246dc1626304a4b16c02252a5ce0d8977e1cb4cfd2797f34cb7a22c6a84b5cbf',1978,'TO','Tonga','economy',533,'GNP: $39 million (1975), $400 per capita
Agriculture: largely dominated by coconut and banana
production with subsistence crops of taro, yams, sweet
potatoes, and bread fruit
Electric power: 4,000 kW capacity (1977); 8 million kWh
produced (1977), 85 kWh per capita
Exports: $10 million (f.0.b., 1975); 65% copra, 7% coconut
products, 8% bananas
Imports: $28 million (c.if., 1975); food, machinery, and
petroleum
Major trade partners: (FY74) exports—25% Netherlands,
22% Australia, 20% New Zealand, 11% Norway; imports—
63% New Zealand and Australia
Budget: (FY76) revenues $6.7 million, expenditures $8.3
million
Monetary conversion rate: } Tonga dollar=US$1.40
(1976)
Fiscal year: 1 July-30 June','1a8e1575528b8c3a74bc9120f0ea7976a4bdcdf2f0df5e27b7fe9e4e04a67498','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ab86e4365d8e2828c7b5a3c2138a198c87130e645380eba5c47f286243d2255',1978,'TT','Trinidad and Tobago','economy',537,'GDP: $3,159 million (1977), $3,060 per capita; 49%
mining and petroleum, 6% manufacturing, 4% agriculture,
41% other; growth rate 1977, 7.7% est.
Agriculture: main crops—sugarcane, cocoa, coffee, rice,
citrus, bananas; largely dependent upon imports of food
Fishing: catch 13,880 metric tons (1976); exports $1.1
million (1975), imports $4.5 million (1975)
Major industries: petroleum, tourism, food processing,
cement
Electric power: 375,000 kW capacity (1977); 1.3 billion
kWh produced (1977), 1,250 kWh per capita
Exports: $2.2 billion (£.0.b., 1977); petroleum and
petroleum products ($2.0 million), sugar, cocoa
Imports: $1.8 billion (c.if., 1977); crude petroleum ($0.9
billion), machinery, fabricated metals, transportation equip-
ment, manufactured goods, food
Major trade partners: (excludes trade under petroleum
agreement) exports—U.S. 71%, U.K. 9%, Caricom 15%;
imports—U.S. 45%, U.K. 17%, Caricom 6% (1976)
Aid: economic—from U.S. (FY46-76), $40.5 million in
grants; from international organizations (FY53-75), $14.8
million
Budget: (1977) central government revenues $1 billion,
expenditures $1 billion (current $487 million, investment
$156 million, development project funds, $371 million)
Monetary conversion rate: tied to US dollar in 1976;
TT$2.40=US$1
Fiscal year: calendar year
CDP: $4.5 billion (1977 est.), $760 per capita, real growth
of 3% in 1977
Agriculture: cereal farming and livestock herding pre-
dominate; main crops—wheat, barley, olives, fruits (espe-
cially citrus), viticulture, vegetables, dates
Major sectors: tourism, mining, food processing, textiles
and leather, light manufacturing, construction materials,
chemical fertilizers, petroleum
Electric power: 425,000 kW capacity (1977); 1.4 billion
kWh produced (1977), 235 kWh per capita
205
: CIA-RDP79-01051A000900010006-2
-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006
July 1978
TUNISIA/TURKEY
Exports: $1.6 billion (f.0.b., 1977); 25% petroleum, 20%
phosphates, 18% olive oil
Imports: $2.0 billion (c.f, 1977); 36% raw materials, 23%
machinery and equipment, 14% consumer goods, 19% food
and beverages, 3% energy, 5% other
Major trade partners: exports—France, Italy, West','74b281ffd7c9ffe849e17936ac5e7530df9bbb5c0cdf25e88b93e8abd3f2407e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d8775e5fe52964f67af0c0d20b86cb94e349dcd092e355279b7a8b0472ebb0',1978,'TV','Tuvalu','economy',541,'See Gilbert Islands for economic data
Electric power: 175,000 kW capacity (1977): 788 million
kWh produced (1977); 65 kWh per capita','ce6c67f27dffde0e279f7c8c16e7b670813c0221ceee667316d8139603b34fce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('187c234e4c85766a941d042015ba4b5668ba881bbe20f7ee0d24fe8770c8f3d0',1978,'UG','Uganda','economy',545,'GDP: $870 million (1976, at constant prices), $150 per
capita; 0% real growth between 1970-74
Agriculture: main cash crops—coffee, cotton; other cash
crops—tobacco, tea, sugar, fish, livestock
Fishing: catch 169,700 metric tons (1975) million (1971)
Major industries: agricultural processing (textiles, sugar,
coffee, plywood, beer), cement, copper smelter, corrugated
iron sheet, shoes, fertilizer
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
pare ee
July 1978
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
UGANDA/U.S.S.R.
Electric power: 228,500 kW capacity (1977); 1,028
million kWh produced (1977), 80 kWh per capita
Exports: $322 million (f.0.b., 1976 est.); coffee, cotton, tea,
copper (1971)
Imports: $237 million (cif., 1976 est.); petroleum
products, machinery, cotton piece goods, metals, transport
equipment
Major trade partners: UK., US., Kenya
Monetary conversion rate: 8.4 Uganda shillings=US$1
Fiseal year: | July-30 June
GNP: $960.4 billion (1976, in 1976 U.S. prices), $3,742 per
capita; in 1977 percentage shares were—57% consumption,
29% investment, 14% government and other, including
defense (based on 1970 GNP in rubles at adjusted factor
cost); average annual growth rate of real GNP (1971-77),
3.8%, average annual growth rate (1976-77), 3.8%
Agriculture: principal food crops—grain (especially
wheat), potatoes; main industria] crops—sugar, cotton,
sunflowers, and flax; degree of self-sufficiency depends on
fhictuations in crop yields; caloric intake, 3,250 calories per
day per capita in recent years
Fishing: catch 10.3 million metric tons (1975): exports
491,000 metric tons (1975), imports 26,700 metric tons
(1975)
Major industries: diversified, highly developed capital
goods industries; consumer goods industries comparatively
less developed
Shortages: natural rubber, bauxite and alumina, tantalum,
tin, tungsten and fluorspar
Crude steel: 160 million metric ton capacity as of [
January 1978; 147 million metric tons produced in 1977, 570
ke per capita
Electric power: 239,800,000 kw capacity (1977); 1,152
billion kWh produced (1977), 4,430 kWh per capita
Exports: $45,298.6 million (f.0.b., 1977); fuels (partien-
larly petroleum and derivatives), metals, agricultural prod-
ucts (timber, grain), and a wide variety of manufactured
Imports: $40,931.8 million (£.0.b., 1977); specialized and
pipe), and any significant shortages in domestic production
imported following poor domestic
Major trade partners: $86.2 billion (1977 total turnover):
trade 57% with Communist countries, 30% with industrial-
ized West, and 13% with less developed countries
Aid: economic—to less developed countries (total ex-
tended 1977) $392 million; recipients included India $340
million; Jamaica, Tanzania, $19 million:
economic extensions, $12.5 billion (1954-76): military —
billion; India, $0.6 billion; Tunisia, $0.5 billion; military
extensions, $22 billion (1955-76)
210
i
Official monetary conversion rate: (. 7461 rubles=US$1-
(April 1977)
Fiscal year: calendar year','a2f7f83b1bb6c47b62b5cbd37735b1743e68cb38185fe700764add1c83a8dbee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e232f09cbc63fbb8e9e33e9167a050794beca8393b38d53477906b94fb477598',1978,'AE','United Arab Emirates','economy',549,'Agriculture: food imported, but some dates, alfalfa,
vegetables, fruit, tobacco raised
Electric power: 700,000 kW capacity (1977); 1.5 billion
kWh produced (1977), 2,350 kWh per capita
Exports: $8.5 billion ($7.0 billion in oil, $0.3. billion
non-oil) (f.o.b., 1976); crude petroleum, pearls, fish
Imports: $3.3 billion (f.0.b., 1976); food, consumer and
capital goods
Major trade partners: U.K., U.S., Japan, India, EC
Aid: 1974-75 foreign aid totaled $1 billion; the 1975-76
budget committed $875 million to direct foreign aid; Abu
Dhabi Fund for Arab Economic and Social Development in
1975 lent $175 million to LDC’s
Budget: total budget (1977), $2.6 billion
Monetary conversion rate: 1 U.A.E. Dirham=US$0.25
Fiscal year: calendar year','04d0558919032794c4321be14ef7d9c8b375ac10f0099eceb204e07083adf4cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45ad5ef4b897edf755064480b372260d9d96b24d08972bbb912f9febe8ec116e',1978,'GB','United Kingdom','economy',553,'GNP: $243.9 billion (1977 est. in 1977 prices), $4,367 per
capita; 59.7% consumption, 18.1% investment, 21.4% gov-
ernment; 0.5% inventories, 0.2% net foreign balance, real
growth 1.5% (1976)
Agriculture: mixed farming predominates; main prod-
ucts—wheat, barley, potatoes, sugar beets, livestock, dairy
products; 52.2% self-sufficient; food shortages—meat, fruits,
vegetables, cereals, dairy products; caloric intake, 2,910
calories per day per capita, 1975
Fishing: catch 933,000 metric tons (1976), valued at $332
million; 1976 exports $146.2 million, imports $492.5 million
Major industries: machinery and transport equipment,
metals, food processing, paper and paper products, textiles,
chemicals, clothing
Shortages: rubber, timber and woodpulp, textile fibers,
nonferrous metals, foodstuffs
Crude steel: 22.3 million metric tons produced (1976);
28.1 million metric tons capacity (1975), 400 kg per capita
Electric power: 83,800,000 kW capacity (1977); 280
billion kWh_ produced (1977), 5,010 kWh per capita
Exports: $57.5 billion (f.0.b., 1977); machinery, transport
equipment, chemicals, metals, nonmetallic mineral manu-
factures, textiles, beverages
Imports: $63.7 billion (f.0.b., 1977); foodstuffs, petroleum,
machinery, crude materials, chemicals, nonferrous metals
Major trade partners: 37.5% EC, 13.4% Commonwealth,
9.7% US., 4.2% Ireland, 3.9% Switzerland
Aid: donor: bilateral economic aid authorized (ODA and
OOF), $5,058 million (1970-76)
Budget (central government): forecasts for F Y78, $75.67
billion expenditures, $65.67 billion revenues; central govern-
ment borrowing requirement, $11.93 billion; total public
sector borrowing requirement, $14.74 billion
Monetary conversion rate: pound sterling floating,
average daily exchange rate 1976, 0.55 pounds=US$1
Fiscal year: 1 April-31 March
GNP: $644 million (1976 est.), $110 per capita, annual
growth estimated by U.S. Embassy at 4.6% (1973-76)
Agriculture: cash crops—peanuts, shea nuts, sesame,
cotton; food crops—sorghum, millet, corn, rice; livestock;
largely self-sufficient
Fishing: catch 3,500 metric tons (1975)
213
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
UPPER VOLTA/URUGUAY
Major industries: agricultural processing plants, brewery,
bottling, and_ brick plants; a few other light industries
Electric power: 21,500 kW capacity (1977); 57 million
kWh produced (1977), 9 kWh per capita
Exports: $83 million (f.0.b., 1976); livestock (on the hoof),
peanuts, shea nut products, cotton, sesame
Imports: $182. million (c.if., 1976); textiles, food, and
other consumer goods, transport equipment, machinery,
fuels
Major trade partners: Ivory Coast and Ghana; overseas
trade mainly with France and other EC countries;
preferential tariff to EC and franc zone countries
Aid: economic—France (1964-September 1970), $46
million; EC (FY1960-72), $87 million; U.S.S.R., China,
Ghana, West Germany, and Israel have also extended aid;
US. (FY61-76), $53 million; international organizations
(FY60-73), $175 million; China, $51 million (1973-76);
military—France, $3.7 million (1964-70); U.S., $0.1 million
(FY 1962-76)
Budget: (1978) balanced at $125 million
Monetary conversion rate: about 242.69 Communaute
Financiere Africaine francs=US$1 as of November 1977
Fiseal year: calendar year','7dac3bbfc2b5a134cd4ceb2869ccd2e06313b823becb1dad432692c4d44a75c7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60d260eea50336a203c4c814c626ba69953b0cc3759df85deaeafd6cba80804e',1978,'UY','Uruguay','economy',557,'GNP: $3.0 billion (1976), $1,080 per capita; 83% private
consumption, 12% public consumption, 11% gross invest-
ment; real growth rate 1976, 2.6%
Agriculture: large areas devoted to extensive livestock
grazing (17 million sheep, 11 million cattle); main crops—
wheat, rice, corn; self-sufficient in most basic foodstuffs;
caloric intake, 3,000 calories per day per capita, with high
protein content
Major industries: meat processing, wool and_ hides,
textiles, footwear, cement, petroleum refining
Crude steel: rolled products 34,841 metric tons produced,
castings 263 metric tons (1976)
Electric power: 700,000 kW capacity (1977); 3 billion
kWh. produced (1977), 1,070 kWh per capita
Exports: $608 million (f.0.b., 1977); wool, hides
Imports: $721 million (c.i.f., 1977); fuels, metals, machin-
ery, transportation equipment
Major trade partners: exports—34% EC, 7% U.S., 29%
LAFTA; imports—29% LAFTA, 10% U.S., 20% EC (1975)
Aid: economic—extensions from U.S. (FY46-76), $129
million in loans, $30 million in grants; from other Western
countries (1960-74), $26 million; from Communist coun-
tries_U,S.S.R. (1969-76), $52 million and Eastern Europe
(1966-76), $31 million; from international organizations
(1946-76), $371 million; military—authorizations from U.S.
(FY53-75), $90 million
Budget: (1977 est.) revenue, $623 million; expenditure,
$671 million
Monetary conversion rate: 5.46 pesos=US$1 (January
1978)
Fiscal year: calendar year
The Vatican City, seat of the Holy See, is supported
financially by contributions (known as Peter’s pence) from
Roman Catholics throughout the world; some income
derived from sale of Vatican postage stamps and _ tourist
mementos, fees for admission to Vatican museums, and sale
of publications; industrial activity consists solely of printing
and production of a small amount of mosaics and staff
uniforms
The banking and financial activities of the Vatican are
worldwide; the Institute for Religious Agencies carries out
fiscal operations and invests and transfers funds of Roman
Catholic religious communities throughout the world; the
Cardinal’s Commission controls the administration of ordi-
nary assets of the Holy See and a Special Administration
manages the Holy See’s capital assets
216
Electric power: obtained from Rome city grid; standby
diesel powerplant with 2,100 kW capacity (1977)
GNP: $36.0 billion (1977, in 1977 dollars), $2,800 per
capita; 48% private consumption, 15% public consumption,
31% gross investment, 6% foreign sector (1976), real growth
rate 6.4% (1974-77)
Agriculture: main crops—sugarcane, corn, coffee, rice;
imports wheat (U.S.), corn (South Africa), sorghum (Argen-
tina, U.S.); caloric intake 2,600 calories per day per capita
(1972)
Fishing: catch 146,000 metric tons (1976); exports $28.4
million (1976), imports $2.0 million (1976)
Major industries: petroleum, iron-ore mining, construc-
tion, food processing, textiles
Crude steel: 750,000 metric tons produced (1976), 60 kg
per capita
Electric power: 6,170,000 kW capacity (1977); 25 billion
kWh produced (1977), 1,935 kWh per capita
Exports: $9.8 billion (f.0.b., 1977); petroleum $9.1 billion,
iron ore, coffee
Imports: $8.8 billion (f.0.b., 1977); industrial machinery
and equipment, chemicals, manufactures, wheat
Major trade partners: imports—40% U.S., 10% Japan,
10% West Germany; exports—33% U.S., 18% Canada
Aid: economic assistance—extensions from US.
(FY46-76), $128 million loans; $73 million grants; from
international organizations (FY46-75), $658 million; from
Communist countries (1954-76), $10 million; military—
assistance from U.S. (FY46-76), $153 million
Budget: 1977—revenues $9.0 billion; expenditures, $11.4
billion, capital $4.2 billion
Monetary conversion rate: 4.2925 bolivares=US$1 (sell-
ing rate)
Fiscal year: calendar year
GNP: $7.3 billion (1977), approximately $145 per capita;
real growth less than 5% annually
several
Agriculture: main crops—rice, rubber, fruits and vegeta-
bles, mainly in the south; some corn, manioc, and sugarcane;
major food imports—wheat, dairy products
Fishing: catch 776,000 metric tons (1976), of which
600,000 metric tons sea
Major industries: food processing, textiles, machine
building, mining, cement, chemical fertilizer, glass, tires
Shortages: foodgrains, petroleum, capital goods and
machinery, fertilizer
Electric power: 1,342,700 kW capacity (1977); 3.4 billion
kWh produced (1977), 65 kWh per capita
Exports: $300 million (1977); agricultural and handicraft
products, coal, minerals, ores
Imports: $900 million (1977); petroleum, steel products,
railroad equipment, chemicals, medicines, raw cotton,
fertilizer, grain
Major trade partners: exports—U.S.S.R., East European
countries, Japan, other Asian markets; imports—U.S.S.R..,
East Europe, China, Japan
Aid: accurate data on aid since April 1975 unification
unavailable; estimated annual commitments of economic aid
are—U.S.S.R., $500 million; East European countries, $350
million; China, $350 million; non-Communist countries,
$100 million; international institutions, $50 million; military
aid deliveries since end of war in April 1975 are minimal
Monetary conversion rate (official): 2.65 northern
dong=US$1; 1.85 southern dong=US$1 (internally), 1
northern dong=0.8 southern dong (November 1977)
Fiscal year: calendar year','860ddab0808d545da4acf5577cb2c5b9fa2769bb9bb84ac7465fbb4004a61428','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('619f5bf26d8efee91a428a52e690231f5373d72e2c678e2b529963a78d4a8fa0',1978,'WF','Wallis and Futuna','economy',561,'Agriculture: dominated by coconut production with
subsistence crops of yams, taro, bananas
Exports: negligible
Imports: $1.4 million (1972); largely foodstuffs and some
equipment associated with development programs
Monetary conversion rate: 70 Colonial Franc Pacifique
(CFP)=US$1','f8fd40b7a42b8cc74997bc83b305ca0ffd327eeda1a36ae94f96befff016d03f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cc74fb77b19e1ed4618da9d8dd3e18f467024f5fc8241a769d13966985f9f22',1978,'EH','Western Sahara','economy',565,'Agriculture: practically none; some barley is grown in
nondrought years; fruit and vegetables in the few oases; food
imports are essential; camels, sheep, and goats are kept by
the nomadic natives; cash economy exists largely for the
garrison forces
phosphate mining, fishing, and
Major industries:
handicrafts
Shortages: water
Electric power: 4,000 kW capacity (1975); 9 million kWh
produced (1975), 84 kWh per capita
Exports: in 1975, up to $75 million in phosphates, all other
exports valued at under $1 million
$1,443,000 (1968); fuel for
Imports: fishing fleet,
foodstuffs
Major trade partners: monetary trade largely with Spain
and Spanish possessions
Aid: small amounts from Spain in prior years
Monetary conversion rate: see Moroccan and Mauritan-
ian currencies
GNP: $45 million (1974), $290 per capita
Agriculture: cocoa, bananas, copra; staple foods include
coconut, bananas, taro, and yams
Electric power: 9,000 kW capacity (1977); 27 million
kWh produced (1977), 180 kWh per capita
Exports: $15 million (f.0.b., 1977); copra 38%, cocoa 26%,
timber 3%
Imports: $38 million (c.i-f., 1977); food, manufactured
goods, machinery
Major trade partners: exports—37% New Zealand, 7%
Netherlands, 36% West Germany, 8% U.S.; imports—28%
New Zealand, 20% Australia, 15% Japan, 18% U.S.
Aid: New Zealand, $7 million (est. 1972-76)
Budget: 1976 est., revenues and grants $34 million,
expenditures $46 million
Monetary conversion rate: WS Tala=US$1.3391 (Janu-
ary 1978), 0.75 WS Tala=US$1
Major industries: timber, tourism
GNP: $490 million (1976 est.), $280 per capita
Agriculture (all outside Aden): cotton is main cash crop;
cereals, dates, kat (qat), coffee, and livestock are raised and
there is a growing fishing industry; large amount of food
must be imported (particularly for Aden); cotton, hides,
skins, dried and salted fish are exported
Major industries: petroleum refinery (production 150,000
b/d) mid-1971; capacity 178,000 b/d at Little Aden operates
on imported crude; oil exploration aetivity
Electric power: 95,000 kW capacity (1977); 210 million
kWh produced (1977), 115 kWh per capita
Exports: $36 million (1976 provisional), excluding petro-
leum products but including re-exports
Imports: $274 million (1976 provisional)
Major trade partners: Yemen, East Africa, but some
cement and sugar imported from Communist countries;
crude oil imported from Persian Gulf, exported mainly to
U.K. and Japan
Budget: (FY1974-75, est.)—revenues $42 million, expen-
ditures $75 million
Monetary conversion rate: 1 S. Yemeni dinar=US$2.90
Fiscal year: 1 April - 31 March
GNP: $1,600 million (1976 est.), $240 per capita
Agriculture: sorghum and millet, gat (a mild narcotic),
cotton, coffee, fruits and vegetables; largely self-sufficient in
food
Major industries: cotton textiles and leather goods
produced on a small scale; handicraft and some fishing;
small aluminum products factory
Electric power: 48,590 kW capacity (1977); 100 million
kWh produced (1977), 20 kWh per capita
Exports: $15 million (1976 est.); aat, cotton, coffee, hides,
vegetables
Imports: $475 million (1976 est.); textiles and other
manufactured consumer goods, petroleum products, sugar,
grain, flour, other foodstuffs, and cement
Major trade partners: China, Yemen (Aden), U.S.S.R.,
Japan, U.K., Australia, Saudi Arabia
Aid: bilateral pledges received—$167 million 1974,
multilateral—$36 million through 1972, $170 million drawn
through 1970; major donors include U.S.S.R., China, U.S.,
West Germany, Saudi Arabia; military—$114 million from
U.SS.R.; $37 million from Eastern Europe; $7 million
Western military aid through 1973
Budget: (1974/75 est.) $711 million expenditures
Monetary conversion rate: 1 Yemeni rial=US$0.22 as of
October 1973
Fiscal year: 1 July-30 June
GNP: $48.0 billion (1977 est., at 1977 prices), $2,195 per
capita; real growth rate 5.7% (1971-77)
Agriculture: diversified agriculture with many small
private holdings and large agricultural combines; main
crops—corn, wheat, tobacco, sugar beets, and sunflowers;
occasionally a net exporter of foodstuffs and live animals;
imports tropical products, cotton, wool, and vegetable meal
feeds; caloric intake, 3,539 calories per day per capita (1975)
Major industries: metallurgy, machinery and equipment,
oil refining, chemicals, textiles, wood processing, food
processing
Shortages: electricity, fuels, steel
Crude steel: 3.2 million metric tons produced (1977), 146
kg per capita
Electric power: 10,800,000 kW capacity (1977); 48.6
billion kWh produced (1977), 2,225 kWh per capita
Exports: $5.25 billion (f.0.b., 1977); 32% machinery and
equipment; 23% intermediate goods; 45% other
Imports: $9.63 billion (c.if., 1977); 23% raw materials,
fuels; 35% machinery and equipment; 18% intermediate
goods; 24% other goods
Major trade partners: 67% non-Communist countries (6%
U.S., 44% other developed Western countries), 35% Commu-
nist countries
Aid: Yugoslav outstanding external debt (medium /long-
term) end 1976, $7 billion, of which $2.7 billion official,
largely non-Communist (U.S. $350 million, FRG $400
million, U.S.S.R. $200 million, IBRD $560 million end 1975);
Yugoslavia has extended aid totalling about $1.2 billion
(outstanding in 1976) to developing countries, largely since
the late 1960''s
Monetary conversion rate: (official) 17.0 new dinars=
US$1
Fiscal year: same as calendar year (all data refer to
calendar year or to middle or end of calendar year as
indicated)
GDP: $3.59 billion (1976 prices), $100 per capita; 3%
annual growth 1970-76
Agriculture: main cash crops—coffee, palm oil, rubber;
main food crops—manioc, bananas, root crops, corn; some
provinces self-sufficient
Fishing: catch 124,580 metric tons (1975); imports $38
million (1974)
Major industries: mining, mineral processing, light
industries
225
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ZAIRE/ZAMBIA
Electric power: 1,597,500 kW capacity (1977); 5.1 billion
kWh produced (1977), 190 kWh per capita
Exports: $1.2 billion (f.0.b.,. 1977 projected); copper,
cobalt, diamonds, other minerals, coffee
Imports: $1 billion (f.0.b., 1977 projected); consumer
goods, foodstuffs, mining and other machinery, transport
equipment, fuels
Major trade partners: Belgium, US., and West Germany
Aid: economic—U.S. (FY61-76), $488 million; (1971
estimated disbursements) Belgium, $31.4 million; France,
$6.6 million; other bilateral aid $5.4 million; U.N., $9.4
million; EC, $18.9 million; China (1973), $100 million;
military—U.S., $90 million (FY62-76); IMF, $155 million
(1976)
Budget: 1977 proposed—revenue, 770 million; expendi-
tures, $976 million
Monetary conversion rate: |] zaire=US$1.17
Fiscal year: calendar year','8e7aafb009783dfa845804b177d25e50160bc8a1ab7cd15b2be057dc250b56bf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02927cc5073fedfca346d37e258db7c92720214911c14c21cc58ee0a1cb5dd62',1978,'US','United States','economy',571,'GNP: $1,691.6 billion (1976); 64% private consumption,
13.5% private investment, 21% government; $7,860 per
capita; 1976 growth rate, 10.2%
Fishing: catch 2.8 million metric tons (1975); imports
$1,381 million, (1975); exports $298 million, (1975)
Crude steel: 116.1 million metric tons produced (1976),
540 ke per capita
Electric power: 557,012,300 kW capacity (1977); 2
trillion kWh produced (1977), 9,750 kWh per capita est.
Exports: $114.8 billion (f.o.b., 1976); machinery and
transport equipment, chemicals, cereals, mineral fuels
Imports: $129.6 billion (c.i.f., 1976); transport equipment,
machinery, mineral fuels, steel, nonferrous metals, metal
ores
Major trade partners: 22% Canada, 8% Japan, 5% West
Germany, 5% U.K. (1975)
Official development assistance (aid): obligations and
loan authorizations (FY76), economic $3.9 billion, military
$2.7 billion
228
Budget: National Accounts Basis, expenditures $323.7
billion, revenues $287.6 billion
Fiscal year: 1 October-30 September','300cdc9282c8430b0b3ade3c6fd7dff8ebc24bf22516f6ab95f682de0e19caf0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

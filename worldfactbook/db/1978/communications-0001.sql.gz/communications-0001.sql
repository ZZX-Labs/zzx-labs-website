SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b48b802d5d2a1d8b1463ad8d48a56b375cb4223a4b9b4df44ca352193c817402',1978,'AF','Afghanistan','communications',11,'Railroads: 0.6 km (single track) 1.524-meter gage,
government-owned spur of Soviet line
Highways: 20,885 km (1975); 2,460 km paved, 3,910 km
gravel, 8,735 km improved earth, and 5,780 km unimproved
earth
Inland waterways: total navigability 1,200 km; steamers
use Amu Darya
Ports: only minor river ports
Civil air: 6 major transport aircraft
Airfields; 37 total, 36 usable; 9 with permanent-surface
runways; 6 with runways 2,440-3,659 m, 11 with runways
1,220-2,439 m
Telecommunications: limited telephone, telegraph, and
radiobroadcast services; television to be introduced by 1978,
29,000 telephones; 112,000 radio receivers; no TV receivers;
2 AM, no FM, no TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 5.1 million; 2.7
million fit for military service; about 178,000 reach military
age (22) annually
Supply: dependent on foreign sources, almost exclusively
the U.S.S.R.
Military budget: estimated expenditures for fiscal year
ending 31 March 1978, about $60.7 million; approximately
8.3% of central government budget','df144749470173341a59f31d9f532711ea2220358020db633b8762f4d92f3af7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('809aefa467fa739cee6d098b5a71c30ca829e5ef203a5fe04b811822981d150c',1978,'AL','Albania','communications',12,'LAND
28,749 km?; 19% arable, 24% other agricultural, 43%
forested, 14% other
Land boundaries: 716 km
WATER
Limits of territorial waters (claimed): 15 nm
Coastline: 418 km (including Sazan Island)
Railroads: 277 km standard gage (1.435 m), single track,
government-owned (1975)
Highways: 4,989 km; 1,287 km paved, 1,609 km crushed
stone and/or gravel, 2,093 km improved or unimproved
earth (1975)
Inland waterways: 43 km plus Albanian sections of Lake
Scutari, Lake Ohrid, and Lake Prespa (1977)
Freight carried: rail—2.8 million metric tons, 180 million
metric ton/km (1971); highways—39 million metric tons,
900 million metric ton/km (1971)
Ports: 1 major (Durres), 3 minor (1977)
Pipelines: crude oil, 117 km, natural gas, 64 km
DEFENSE FORCES
Military budget (announced): for fiscal year ending 31
December 1977, 805 million leks; about 11% of total budget','4b36ae1260e2b66776656108073d37c8dd157d3354ae5dafc234975b8e0099cd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2feeb6bf0b9a5d1e98f50edbb6ec02b5f8761acd68a0010adfbf7ca06f1d3d0a',1978,'DZ','Algeria','communications',16,'LAND
2,460,500 km?; 3% cultivated, 16% pasture and meadows,
1% forested, 80% desert, waste, or urban
Land boundaries: 6,260 km
Atlantic
Ocean
(Sée reference map V}
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,183 km
Railroads: 3,950 km; 2,690 km standard gage (1.435 m),
1,033 km 1.055-meter gage, 146 km meter gage (1.00 m);
802 km electrified; 193 km double track
Highways: 78,410 km; 45,070 km concrete or bituminous,
33,340 km gravel, crushed stone, unimproved earth
Ports: 9 major, 8 minor
Pipelines: crude oil, 3,983 km; refined products, 298 km;
natural gas, 2,969 km
Civil air: 38 major transport aircraft
Airfields: 182 total, 176 usable; 583 with permanent-sur-
face runways; 21 with runways 2,440-3,659 m; 94 with
runways 1,220-2,489 m; 3 seaplane stations
Telecommunications: adequate domestic and interna-
tional service in the north, sparse radiocommunications in
the south; one Atlantic Ocean satellite station; 250,000
telephones (1.5 per 100 popl.); 18 AM and 40 TV stations; 3
submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 4,236,000; 2,499,000 fit
for military service; average number reaching military age
(19) annually 168,000
Military budget: for fiscal year ending 31 December
1977, $385 million; 6% of national budget
Boundary representation is
aot necessarily authorilative
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4','289b045bf5d4d911f7b4c9404d77feea8ea51441e8032378a884d4842b1bc46c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4021ceba7bc1103597bbca83decb9cd2000f81a5920b1aa8a25d0ee495ed197',1978,'AD','Andorra','communications',20,'Atlantic
Ocean
Mediterranean
oe SBE
(See reference map !V)
LAND
466 km?
Land boundaries: 105 km
Railroads: none
Highways: about 96 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: international circuits to Spain and
France; 2 AM stations, 1 FM, 1 TV station; about 3,900
telephones (14.3 per 100 popl.)
DEFENSE FORCES
Andorra has no defense forces; Spain and France are
responsible for protection as needed','d01cc72ead9403d20053054c74096687b60ec031ff45a5aa26ade22ea7a8880a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('508a717321cfd118c0dae9a1d4a65d9228866027b14b7954def6b6871869eb45',1978,'AO','Angola','communications',24,'Atlantic
Ocean
(See reference map Vi)
LAND
1,245,790 km?; 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow)
Land boundaries: 5,070 km
WATER
Limits of territorial waters (claimed): 20 nm
Coastline: 1,600 km
Railroads: 3,069 km; 2,758 km 1.067-meter gage, 310 km
0.600-meter gage
Highways: 73,828 km; 8,577 km_bituminous-surface
treatment, 28,723 km crushed stone, gravel, or improved
earth, remainder unimproved earth
Inland waterways: 3,220 km navigable
Ports: 3 major (Luanda, Lobito, Mocamedes), 15 minor
Pipelines: crude oil, 179 km
Civil air: 10 major transport aircraft (including 2 leased
in)
Airfields: 571 total, 504 usable; 26 with permanent-
surface runways; 1 with runway over 3,660 m, 8 with
runways 2,440-3,659 m, 80 with runways 1,220-2,439 m
Telecommunications: fair network of open-wire and
radio-relay facilities; 1 Atlantic Ocean satellite station;
37,500 telephones (0.6 per 100 popl.); 24 AM, 12 FM, and no
TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,535,000; 766,000 fit
for military service; average number reaching military age
(20) annually, 61,000
ANTIGUA
Avantic.
_ Qcean
LAND
280 km®; 54% arable, 5% pasture, 14% forested, 9% unused
but potentially productive, 18% wasteland and built on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 153 km
Railroads: 78 km narrow gage (0.760 m), employed
almost exclusively for handling cane
Highways: 380 km; 240 km main, 140 km secondary
Ports: 1 major (St. John’s), 1 minor
Civil air: 8 major transport aircraft
Airfields: 3 total, 8 usable; 1 with asphalt runway 2,745
m; 2 seaplane stations
Telecommunications: automatic telephone system; 3,500
telephones (4.9 per 100 popl.); tropospheric scatter links with
Tortola and $t. Lucia; 3 AM stations, 1 FM station, and 1 TV
station; 1 coaxial submarine cable','d08d20b324d988f5228036705acb423c0fd12d8946e38066e2cfb0f246d119d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f387a58729687068bbc78f5f6d58cf2e430a1cd769630b0718b7b5c98e53e2c9',1978,'AR','Argentina','communications',28,'Pacific
Buenos Aires
Atlantic Ocean
EP FALKLAND ISLANDS
LAN D {See reference imap Il)
2,771,300 km?; 57% agricultural (11% crops, improved
pasture and fallow, 46% natural grazing land), 25% forested,
18% mountain, urban, or waste
Land boundaries: 9,414 km
WATER
Limits of territorial waters (claimed): 200 nm (continental
shelf, including sovereignty over superjacent waters)
Coastline: 4,989 km
Railroads: 39,738 km; 3,086 km standard gage (1.435 m),
22,788 km broad gage (1.676 m), 13,461 km meter gage
(1.00 m), 408 km 0.750-meter gage
Highways: 219,700 km, of which 43,050 km paved,
76,800 km gravel, 85,950 km improved earth, 13,900 km
unimproved earth
8 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ARGENTINA/ AUSTRALIA
Inland waterways: 11,000 km navigable
Ports: 7 major, 21 minor
Pipelines: 4,090 km crude oil; 2,200 km refined products;
8,120 km natural gas
Civil air: 41 major transport aircraft, includes 1 leased
from a foreign country
Airfields: 2,378 total, 2,153 usable; 91 with permanent-
surface runways; 21 with runways 2,440-3,659 m, 315 with
runways 1,220-2,439 m; 6 seaplane stations
Telecommunications: extensive modern system; tele-
phone network has 2,660,000 sets (9.7 per 100 popl.), radio
relay widely used, 1 satellite station with 2 Atlantic Ocean
antennas; 158 AM, 12 FM, and 64 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 6,519,000; 5,254,000 fit
for military service; average number reaching military age
(20) annually about 219,000
Military budget: proposed for fiscal year ending 31
December 1977, $1,391.8 million; about 15% of total central
government budget
4 Tasman
*Canberta <
3 Sea
« Bahia
Concepcion,
Blanca
1000 Kilameters
1000 Miles
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
2 a,
ok Reykjavik
iceland ,
oN aes
icra
North
Atlantic
iecean
‘
/ :
83 egy ty sets
rs ia
Lisbon,','86e040025ed40e7ac4783b562a37f748ca85ab11d50c264bd86e3fa59bdee85f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd786d0c270065b993ef36521cb5f65eed6b2bfe4a7ec339bbd675ef0e48c3e7',1978,'NZ','New Zealand','communications',32,'(See reference map va)
LAND
7,692,300 km?; 6% arable, 58% pasture, 2% forested, 34%
other
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 12
nm; prawn and crayfish on continental shelf)
Coastline: about 25,760 km
Railroads: 40,636 km; 9,197 km 1.60-meter gage, 13,394
km standard gage (1.435 m), 18,045 km 1.067-meter gage;
800 km electrified (June 1962); government-owned (except
for few hundred kilometers of privately owned track)
Highways: 837,866 km (1976); 207,644 km paved,
205,454 km gravel, crushed stone, or stabilized soil surface,
424,768 km unimproved earth
Inland waterways: 8,368 km: mainly by small, shallow-
draft craft
Freight carried: rail—154.4 million metric tons
Ports: 12 major, numerous minor
Pipelines: crude oil, 740 km; refined products, 340 km;
natural gas, 6,947 km
Civil air: around 120 major transport aircraft
Airfields: 1,751 total, 1,662 usable; 195 with permanent-
surface runways, 3 with runways over 3,660 m: 18 with
runways 2,440-3,659 m, 645 with runways 1,220-2,439 m
Telecommunications: very good international and do-
mestic service; 5.3 million telephones; 14 million radio
receivers; 3.7 million TV receivers: 96 AM stations, no FM
station, 120 TV stations and 66 repeaters; 3 earth satellite
stations; submarine cables to New Zealand, New Guinea,
Singapore, Malaysia, Hong Kong, and Guam
DEFENSE FORCES
Military manpower: males 15-49, 3,289,000; 2,906,000 fit
for military service; 125,000 reach military age (17) annually
Military budget: for fiscal year ending 30 June 1978,
$2,577,300,000; about 8.8% of total central government
budget
‘ Cero Sée: eres * .
2 ‘acific
SS Ocean
§ :
NEW hy
a7, Wattington
(See reference mag Vil)
LAND
268,276 km?; 3% cultivated, 50% pasture; 10% parks and
reserves; 20% waste, water, etc., 1% urban, 16% forested; 4
principal islands, 2 minor inhabited islands, several minor
uninhabited islands
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 12
nm)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Coastline: about 15,134 km
Railroads: 4,799 km, all 1.067-meter gage; 274 km double
track; 113 km electrified; over 99% government owned
Highways: 92,374 km (1974); 44,940 km paved, 47,434
km gravel or crushed stone
Inland waterways: 1,609 km; of little importance to','ff372f9408066bca6324e57e2f4894ed96f9e10a3bcbdc92a11420c8fd7be065','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d975df872d7332f2a92ffead45eeb51afeb01dfe0380f7f9ee5b9b5173c75547',1978,'AT','Austria','communications',36,'(See reference map IV)
LAND
83,916 km?®; 20% cultivated, 26% meadows and pastures,
15% waste or urban, 38% forested, 1% inland water
Land boundaries: 2,582 km
Railroads: 6,517 km; 5.877 km government-owned; 5,397
km standard gage (1.435 m) of which 2,384 km electrified
and 1,333 km double tracked; 480 km narrow gage(0.760 m)
of which 91 km electrified; 640 km privately owned (1.435-
and 1.00-meter gage)
Highways: approximately 33,600 km total national
classified network, including 10,400 km federal and 23,200
km provincial roads; about 20,800 km paved (bituminous,
concrete, stone block) and 12,800 km unpaved (gravel,
crushed stone, stabilized soil); additional 60,800 km commu-
nal roads (mostly gravel, crushed stone, earth)
Inland waterways: 427 km
Ports: 2 major river (Vienna, Linz)
Pipelines: 554 km crude oil; 2,611 km natural gas; 171 km
refined products
Civil air: 19 major transport aircraft
Airfields: 52 total, 51 usable; 12 with permanent-surface
runways; 8 with runways 2,440-3,659 m, 7 with runways
1,220-2,489 m
Telecommunications: highly developed and efficient;
extensive TV and radiobroadcast systems with 90 AM, 94
FM, and 295 TV stations; 2.21 million telephones (28.1 per
100 popl.)
ll
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
AUSTRIA/THE BAHAMAS
DEFENSE FORCES
Military manpower: males 15-49, 1,725,000; 1,389,000 fit
for military service; average number reaching military age
(19) annually about 59,000
Military budget: for fiscal year ending 31 December
1977, $606 million; about 4.2% of the federal budget
THE BAHAMAS
A UNITED
& STATES
Atlantic Ocean
DOMINICAN
REPUBLIC
(See raference map tl}
Caribbean Sea
LAND
11,396 km?; 1% cultivated, 29% forested, 70% built on,
wasteland, and other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 3,542 km (New Providence Is. 76 km)
Railroads: none
Highways: 2,100 km total; 850 km paved, 1,250 km
gravel
Ports: 2 major (Freeport, Nassau), 9 minor
Civil air: 15 major transport aircraft (including 8 leased
in)
ss Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
THE BAHAMAS/BAHRAIN
Airfields: 54 total, 51 usable; 9 with permanent-surface
runways; 8 with runways 9,440-8,659 m, 22 with runways
1,220-2,439 m; 4 seaplane stations
Telecommunications: telecom facilities highly developed,
including 61,000 telephones (28.0 per 100 popl.) in totally
automatic system; tropospheric scatter link with Florida; 3
AM and 2 FM stations; 3 coaxial submarine cables','03eac84164ffa9b9e7d75e8a39d57b69eaa84f055de0a147a5e560d753819a14','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51b47125838e174428b41f881ca9091aa81f067d86393fa557b53b29990beb47',1978,'BH','Bahrain','communications',40,': = Arabian
Ben Sea:
(Sea reference map V)
LAND
596 km? plus group of 32 smaller islands; 5% cultivated,
negligible forested area, remainder desert, waste, or urban
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Highways: 93 km bituminous surfaced; undetermined
mileage of natural surface tracks
Ports: 1 major (Bahrain)
Pipelines: crude oil, 56 km; refined products, 16 km;
natural gas, 32 km
Civil air: 21 major transport aircraft (all registered in
Oman)
13
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BAHRAIN/BANGLADESH
Airfields: 2 total, 2 usable; 1 with permanent-surface
runway; 1 with runway over 3,660 m; 1 with runway 1,220-
2,439 m; 1 seaplane station
Telecommunications: excellent international telecom-
munications; limited domestic services; 22,000 telephones
(9.9 per 100 popl.); | AM station, 1 TV station, 1 Indian
Ocean satellite station; tropospheric scatter Bahrain to Qatar
and United Arab Emirates
DEFENSE FORCES
Military manpower: males 15-49, 70,000; fit for military
service 39,000
Supply: mostly from U.K.
Military budget: for fiscal year ending 31 December
1977; $28 million, 5% of total budget','6878df956982abc00ccadb4b6dd26a5d7e43bdc641e7f4e21016d83bac662c82','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9132709aaac8d2ba1a4b6bfbe525032c967e52b0db3cf4491b3a2eea5422681d',1978,'BD','Bangladesh','communications',44,'Bay of Bengal
(See reference map Vit)
LAND
142,500 km’; 66% arable (including cultivated and
fallow), 18% not available for cultivation, 16% forested
Land boundaries: 2,535 km
WATER
Limits of territorial waters (claimed): 12 nm; fishing 200
nm
Coastline: 580 km
Railroads: 3,470 km; 2,483 km meter gage (1.00 m), 953
km broad gage (1.676 m), 85 km narrow gage (0.762 m), 290
km double track; government-owned
Highways: 44,930 km; 4,044 km paved, 2,022 km gravel,
38,864 km earth
Inland waterways: 7,000 km; river steamers navigate
main waterways
Ports: 1 major; 5 minor
Pipelines: 150 km natural gas
Civil air: 9 major transport aircraft
Airfields: 24 total, 16 usable; 18 with permanent surface
runways; 3 with runways 2,440-3,659 m, 8 with runways
1,220-2,489 m
Telecommunications: inadequate international radio-
communications and landline service; fair domestic wire and
microwave service; fair broadcast service; 80,100 (est.)
telephones; 500,000 radio sets, 20,000 (est.) TV sets; 10 AM,
1 FM, 2 TV stations, and 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 18,611,000; 10,681,000
fit for military service
Military budget: for fiscal year ending 30 June 1978,
$152.0 million; about 9.4% of the central government budget','765c31e84120163e90d31b212d689cf285cd1727648abee53f594d2497a234ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4df57fff5bfdfa5adecc1ef5060d04beb53c99a5f8e2c552d08caaeceace1d78',1978,'BB','Barbados','communications',48,'LAND
430 km*; 60% cropped, 10% permanent meadows, 30%
built on, waste, other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 97 km
DOMINICAN
Atlantic
Ocean
{See reference map ff)
Railroads: none
Highways: 1,370 km; 1,290 km paved, and 80 km gravel,
and earth
Ports: 1 major (Bridgetown), 2 minor
Civil air: 4 major transport aircraft
Airfields: 1 with permanent-surface runway 2,440-3,659
m; 1 seaplane station
Telecommunications: islandwide automatic telephone
system with 43,000 telephones (17.2 per 100 popl.);
tropospheric scatter link to Trinidad; UHF/VHF links to St.
Vincent and St. Lucia; 2 AM stations, 1 FM station, 1 TV
station; 2 telegraph submarine cables; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 51,000; 37,000 fit for
military service; average number reaching military age, (18)
annually, 3,000; no conscription','1b8deeb11297d33dcea431f24c1aabfef9395ebc7e92d2e56bcd5fa5a2d43c77','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c3804baf3fc48ae42694390856b708f3460f1a168a9b550cacdf3995a4502e3',1978,'BE','Belgium','communications',52,'(See reference map i¥}
LAND
30,562 km*; 28% cultivated, 24% meadow and pasture,
28% waste, urban, or other; 20% forested
Land boundaries: 1,377 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 64 km
Railroads: 4,394 km; 4,117 km standard gage (1.435 m)
and government-owned, 2,536 km double track, 1,224 km
electrified; 277 km privately owned, electrified meter gage
(1.00 m)
Highways: approximately 104,000 km, including 1,040
km limited access divided “Autoroute”
Inland waterways: 2,043 km, of which 1,528 km are in
regular use by commercial transport
Ports: 5 major, 1 minor
Pipelines: refined products, 965 km; crude, 161 km;
natural gas, 3,218 km
Civil air: 45 major transport aircraft (including 6 leased
out)
Airfields: 46 total, 45 usable; 22 with permanent-surface
runways; 13 with runways 2,440-3,659 m, 5 with runways
1,220-2,489 m
17
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BELGIUM/BELIZE
Telecommunications: excellent domestic and interna-
tional telephone and telegraph facilities; 2.92 million
telephones (28.3 per 100 popl.); 14 AM, 21 FM, and 25 TV
stations, 5 coaxial submarine cables; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,243,000; 1,803,000 fit
for military service; average number reaching military age
(19) annually 76,000','be54bd47d0e372aff69d9aa2f46c7129fdb915f32c3366677782abf93f744272','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e456f68c8b57ee6d9a349b9c42d1b74677e095cf2854cefe1734fba114ba10f7',1978,'BZ','Belize','communications',56,'(formerly British Honduras)
Gulf of . = 8
Mexico y
Caribbean
Sea
Pacific
Ocean
(See referance map Ht}
LAND
22,973 km?; 38% agricultural (5% cultivated), 46%
exploitable forest, 16% urban, waste, water, offshore islands
or other
Land boundaries: 515 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 386 km
Railroads: none
Highways: 2,450 km; 300 km paved, 900 km gravel, 950
km improved earth and 300 km unimproved earth
Inland waterways: 800 km river network used by
shallow-draft craft
Ports: 1 major (Belize), 4 minor
Civil air: 2 major transport aircraft
Airfields: 36 total, 36 usable; 4 with permanent-surface
runways; | with runway 1,220-2,439 m; 1 seaplane station
Telecommunications: 5,800 telephones in automatic and
manual network (4.0 per 100 popl.); radio-relay system; 3
AM. stations
CS Caribbe
onduras
a J
mr Acapulco
Beet
Venezuela
,
Bogota','cd4b9f2fbad45e99e75f91bd53e1815ed54482494b701e0c37c4fbd6ba03d8d5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb9a4e40ac7a56a0face9fa740b9fa6cfddd466d853569e431f16498e46396e1',1978,'BJ','Benin','communications',60,'(formerly Dahomey)
(See reference map Vi}
LAND
115,773 km?; southern third of country is most fertile;
arable land 80% (actually cultivated 11%), forests and game
preserves 19%, non-arable 1%
Land boundaries: 1,963 km
WATER
Limits of territorial waters (claimed): 200 nm (100 nm
mineral exploitation limit)
Coastline: 121 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Railroads: 579 km, all meter gage (1.00 m)
Highways: 3,303 km; 705 km paved, 2,598 km improved
earth
Inland waterways: 645 km navigable
Ports: 1 major (Cotonou), 1 minor
Civil air: no major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-surface
runway; 4 with runways 1,220-2,439 m
Telecommunications: system of open wire and radio
relay; 9,800 telephones; 56,000 radio receivers; 2 AM, 1 FM,
and no TV stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 752,000; 377,000 fit for
military service; about 33,000 males and 32,000 females
reach military age (18) annually; both sexes liable for
military service
Supply: dependent on France and Guinea; aid from North
Korea and PRC is pending
Military budget: for fiscal year ending 31 December
1976, $7.4 million; about 11% of central government budget
Gulf of Guinee
(See ceference map Vi)
LAND
1,266,510 km*; about 3% cultivated, perhaps 20% some-
what arable, remainder desert
Land boundaries: 5,745 km','d7be829148754b52dbb321bb7ed4d46a9a5e89231a623296befaea2a1c144558','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48e01fec5234ba926ce58ea018fa514e5d40bcb03f743319f80492ede38726a6',1978,'BM','Bermuda','communications',64,'LAND
54.4 km; 8% arable, 60% forested, 21% built on,
wasteland, and other, 11% leased for air and naval bases
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 103 km
Atlantic
Ocean
-BERMUDA
(See reference mag tH}
Railroads: none
Highways: 190 km, all paved
Ports: 8 major (Hamilton, St. George Freeport, Ireland
Island)
Civil air: 3 major transport aircraft
Airfields: 1 with concrete runway 2,960 m; 1 seaplane
station
Telecommunications: modern telecom system, includes
fully automatic telephone system with 38,600 sets (63.5 per
100 popl.); 2 AM, 1 FM, and 2 TV stations; 3 coaxial
submarine cables','47ab59ac48b36eab7fc120af9d66be8ef3f0dfda91c389b021775d13cd811426','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13f05695048fe37968326080a8e5906c28fd549c445d86758fe22dbf3aedd3c2',1978,'BT','Bhutan','communications',68,'Bengal.
(See reference map Vit)
LAND
46,600 km?; 15% agricultural, 15% desert, waste, urban,
70% forested
Land boundaries: about 870 km
Highways: 1,304 km; 418 km surfaced, 515 km improved,
371 km unimproved earth
Freight carried: not available, very light traffic
Civil air: no major transport aircraft
Airfields: 2 total, 1 asphalt runway 1,372 m, and 1 with
concrete runway 899 m
Telecommunications: facilities inadequate; 600 tele-
phones; 6,000 est. radio sets; no TV sets; 1 AM station and no
TV stations
DEFENSE FORCES
Military manpower: males 15-49, 293,000; 155,000 fit for
military service; about 13,000 reach military age (18)
annually
Supply: dependent on India
BOLIVIA
Pacific
Ocean
{See reference map Ut}
LAND
1,098,160 km?; 2% cultivated and fallow, 11% pasture and
meadow, 45% urban, desert, waste, or other, 40% forest, 2%
inland water
Land boundaries: 6,083 km
Railroads: 3,572 km single track; 3,540 km meter gage
(1.00 m), 32 km 0.760-meter gage; 96 km meter gage (1.00
m) privately owned
Highways: 37,300 km; 1,150 km paved, 6,550 km gravel,
5,950 km improved earth, 23,650 km unimproved earth
Inland waterways: officially estimated to be 10,000 km
of commercially navigable waterways
Pipelines: crude oil, 1,670 km; refined products, 1,495
km; natural gas, 560 km
Ports: none (Bolivian cargo moved through Arica and
Antofagasta, Chile, and Matarani, Peru)
Civil air: 30 major transport aircraft
Airfields; 574 total, 535 usable; 4 with permanent-surface
runways; 1 with runway over 3,660 m, 5 with runways
2,440-3,659 m, 127 with runways J,220-2,439 m
Telecommunications: radio-relay system from La Paz to
Santa Cruz; improved international services; 55,000 tele-
phones (1.2 per 100 popl.); 89 AM, 18 FM, and 2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,319,000; 834,000 fit
for military service; average number reaching military age
(19) annually about 60,000
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4','54e123eee56156d5c24db2b268131937466bd3de7b78cec8697eacdbae49ed01','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('109b13c22b9fb58a28e5e7f3f6d370cd85448464f4a9a8cf2e10f1984b01d9e8',1978,'BW','Botswana','communications',72,'Indian
Qeean |
Atlantic
Ocean
{See reference map Vi)
LAND
569,800 km®; about 6% arable, less than 1% under
cultivation, mostly desert
Land boundaries: 3,774 km
Railroads: 691 km 1.067-meter gage
Highways: 10,219 km; 438 km paved; 1,426 km crushed
stone or gravel; 5,318 km improved earth and 3,037 km
unimproved earth
Inland waterways: native craft only; of local importance
Civil air: 8 major transport aircraft
Airfields: 83 total, 76 usable; 3 with permanent-surface
runways; 18 with runways 1,220-2,439 m
Telecommunications: the system is a minimal combina-
tion of open-wire lines, radio-relay links, and a few
radiocommunication stations; Gaborone is the center; 7,900
telephones (1.2 per 100 popl.); 1 AM, 1 FM, and no TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 173,000; 87,000 fit for
military service; 8,000 reach military age (18) annually
Windhoek Gaborone
cags 4 Pretoria
M fab bane
Swaziland /
Maseruy’ 7
South Africa \\cesotho
Walvis Bay’
CB. ATS
Cape Tonia
a
500 100Q-Kilometers
500 1000 Miles
Names and oourdary repres
are not secessanly aulhonlative
503395 1-78
}
ee
wh Maputo
ia
rd /
Pig
Aral
'' Sea
Pepe)
a
° Somalia
~ *ogad','1bfb84c04578a5feeeeb5fbcb214c5e47962a4eca515191c5259b621a1c9d16c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65549c37151d63f8cf755436275a4983cf87137fa9f374de9b580fb19dbb3f55',1978,'BR','Brazil','communications',76,'Atlantic
Ocean
(See reference map ttl}
LAND
8,521,100 km?®; 4% cultivated, 13% pasture, 23% built-on
area, waste, and other, 60% forested
Land boundaries: 13,076 km
WATER
Limits of territorial waters (claimed); 200 nm
Coastline: 7,491 km
Railroads: 31,896 km; 28,137 km meter gage (1.00 m),
3,336 km 1.60-meter gage, 194 km standard gage (1.435 m),
229 km narrow gages; 2,593 km electrified
Highways: 1,489,000 km; 71,200 km paved, 1,417,800 km
gravel or earth
Inland waterways: 50,000 km navigable
Ports: 8 major, 23 significant minor
Pipelines: crude oil, 1,365 km; refined products, 465 km;
natural gas, 257 km
Civil air: 149 major transport aircraft
Airfields: 4,307 total, 4,261 usable; 159 with permanent-
surface runways; 16 with runways 2,440-8,659 m, 419 with
runways 1,220-2,439 m; 18 seaplane stations
Telecommunications: fair telecom system; good radio
relay facilities, 1 Atlantic Ocean satellite station with 2
antennas; 3 domestic satellite stations; 3.45 million tele-
phones (3.1 per 100 popl.); 344 AM stations, 150 FM, and 79
TV stations; 6 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 25,499,000; 16,652,000
fit for military service; 1,281,000 reach military age (18)
annually
Military budget: for fiscal year ending 31 December
1977, $1,967 million; 9.4% of central government budget
25
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BRITISH SOLOMON ISLANDS/BRUNEI
BRITISH SOLOMON ISLANDS
BRITISH SOLOMON
et pei
“ Paelfie
eo Ocean
(Sea reference map Vill)
LAND
About 29,785 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 5,313 km
Railroad: none
Highways: 834 km; 241 km sealed or all-weather
Inland waterways: none
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 24 total, 21 usable; 1 with permanent-surface
runway; 5 with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: 3 AM broadcast, no FM, and no
TV stations; 10,000 radio receivers, 1,726 telephones, no TV
sets; international connections with London, England, via
cable broadcasts
BRUNEI
(See reference mag My
LAND
214,970 km?; 1% cropland, 3% pasture, 8% savanna, 66%
forested, 22% water, urban, and waste
Land boundaries: 2.575 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 459 km
Railroads: 109 km, all single track; 80 km 0.914-meter
gage, 29 km 1.067-meter gage
Highways: 4,100 km; 950 km paved, 950 km gravel 1,000
km improved, 1,200 km unimproved earth
Inland waterways: 5,900 km; Demerara River navigable
to Mackenzie by ocean steamers, others by ferryboats, small
craft only
Ports: 1 major (Georgetown), 3 minor
Civil air: 6 major transport aircraft
Airfields: 96 total, 88 usable; 4 with permanent-surface
runways; 18 with runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: highly developed telecom system
with radio-relay network and over 21,300 telephones (2.6
per 100 popl.); tropospheric scatter link to Trinidad; 5 AM, 1
FM and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 189,000; 144,000 fit for
military service','a0533430d1022559375bb89c6724fc05899b4f4e0adb86b2c00697b4620097ce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9f07c734b007b10d063b3f00576b15ed85b0620f7692078d1d7ab6770f66300',1978,'ID','Indonesia','communications',80,'{See reference map Vii)
LAND
5,776 km?; 3% cultivated; 22% industry, waste, urban or
other; 75% forested
Land boundaries: 381 km
a Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BRUNEI/BULGARIA
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Railroads: 9.6 km narrow gage (0.610 m)
Highways: 1,207 km, 376 km paved (bituminous treated),
402 km gravel or stone, 428 km unimproved
Inland waterways: 209 km; navigable by craft drawing
less than 1.2 meters
Ports: 2 minor (Bandar Seri Begawan, formerly Brunei,
and Kuala Belait)
Pipelines: crude oil, 185 km; refined products, 56 km;
natural gas, 56 km; crude oil and natural gas, 241 km under
construction
Civil air: 2 major transport aircraft
Airfields: 3 total, 3 usable; 2 with permanent-surface
runway; 1 with runway over 3,660 m; 2 with runways
1,220-2,439 m
Telecommunications: service throughout country is ade-
quate for present needs; international service good to
adjacent Sabah and Sarawak; radiobroadcast coverage good,
9,610 telephones; 23,000 radio and 13,500 est. TV sets; Radio
Brunei broadcasts from 6 AM stations and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 38,000; 23,000 fit for
military service; about 1,800 reach military age (18)
annually
a
Se INDONESIA :
cs a?
S
indian Ocean
(See reference map vil)
LAND
1,906,240 km?; 12% small holdings and estates, 64%
forests, 24% inland water, waste, urban, and other
Land boundaries: 2,736 km
WATER
Limits of territorial waters (claimed): under an archi-
pelago theory, claim is 12 nm, measured seaward from
straight baselines connecting the outermost islands
Coastline: 54,716 km
Railroads: 7,863 km; 7,246 km 1.067-meter gage, 525 km
0.750-meter gage, 92 km 0.600-meter gage; 211 km double
track; 101 km electrified; government owned
Highways: 93,053 km; 26,573 km paved, 41,521 km
gravel or crushed stone, 24,959 km improved or unimproved
earth
Inland waterways: 21,579 km; Sumatra 5,471 km, Java
and Madura 820 km, Borneo 10,460 km, Celebes 241 km,
and Irian Barat 4,587 km
Ports: 10 major, 63 minor
Civil air: approximately 130 major transport aircraft
Airfields: 388 total, 362 usable; 64 with permanent-
surface runways; 11 with runways 2,440-3,659 m, 66 with
runways 1,220-2,439 m
Telecommunications: interisland microwave system and
HF police net; domestic service poor, international service
good; radiobroadcast coverage good; 305,450 telephones; 5
million radio and 300,000 TV sets; 150 AM, 1 FM, and 13
TV stations; 1 international ground satellite station (1 Indian
Ocean antenna and 1 Pacific Ocean antenna), and 40
domestic ground satellite stations
Military budget: for fiscal year ending 31 March 1978,
$1.5 billion; about 14.8% of central government budget
IRAN
a
x Tehran
Arabian
Sea
(See reference map V)
LAND
1,647,240 km*; 14% agricultural, 11% forested, 16%
cultivable with adequate irrigation, 51% desert, waste, or
urban, 8% migratory grazing and other
Land boundaries: 5,318 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing, 50
nm)
Coastline: 3,180 km, including islands, 676 km
Railroads: 4,509 km standard gage (1.435 m), 92 km
1.676-meter gage
Highways: 43,442 km; 12,060 km bituminous and
bituminous treated, 22,920 km gravel and crushed stone,
8,462 km improved earth
Inland waterways: 904 km, excluding the Caspian Sea,
104 km on the Shatt al Arab
Pipelines: crude oil, 2,639 km; refined products, 3,597
km; natural gas, 2,317 km
Ports: 7 major, 6 minor
Civil air: 55 major transport aircraft
Airfields: 179 total, 166 usable; 65 with permanent-
surface runways; 13 with runways over 3,660 m, 12 with
runways 2,440-3,659 m, 68 with runways 1,220-2,439 m
Telecommunications: most advanced system in the
Middle East of high-capacity radio-relay links, open-wire
lines, cables, and tropospheric links; principal center Tehran,
secondary centers Isfahan, Meshed, and Tabriz; 805,600
telephones (2.0 per 100 popl.); 35 AM, 2 FM, and 67 TV
stations; 1 satellite station with Atlantic Ocean and Indian
Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 8,084,000; 4,789,000 fit
for military service; about 350,000 reach military age (21)
annually
Military budget: for fiscal year ending 20 March 1978,
$9,199,000,000; 27% of central government budget
99
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','5b73abd7b8a5993e98839acf7b23b868ce46c093f349bfb9599091e146cb0a40','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e950383b7056827c04659ec54a45e04298886656ff7ceb1f76aec25b3b372d42',1978,'BG','Bulgaria','communications',84,'Black Sea.
* Sofia
(Sea reference map iV}
LAND
111,852 km?; 41% arable, 11% other agricultural, 33%
forested, 15% other
Land boundaries: 1,883 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 354 km
27
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Railroads: 4,314 km; about 4,069 km standard gage
(1.435 m), 245 km narrow gage; 299 km double track; 1,446
km electrified; government-owned (1976)
Highways: 31,454 km; 6,683 km paved, 6,088 km crushed
stone and gravel, 18,683 km earth (1975)
Inland waterways: 471 km (1977)
Freight carried: rail—76.6 million metric tons, 17.1
billion metric ton/km (1976); highway—277 million metric
tons, 9.1 billion metric ton/km (1976); waterway—4.4
million metric tons, 2.4 billion metric ton/km (excl. int''l.
transit traffic) (1975)
Ports: 2 major (Varna, Burgas), 5 minor (1977)
2 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BURMA
BURMA
Bay
“oF Bengal
South
China Sea
wht
(See reference map Vil}
LAND
678,600 km2; 28% arable, of which 12% is cultivated, 62%
forest, 10% urban and other (1969)
Land boundaries: 5,850 km
WATER
Limits of territorial waters (claimed): 200 nm (200 nm
exclusive economic zone)
Coastline: 3,060 km
Railroads: 3,285 km; 3,172 km meter gage (1.00 m), 113
km narrow-gage industrial lines; 328 km double track;
government-owned
Highways: 27,000 km; 3,200 km bituminous, 17,700 km
improved earth, gravel, 6,100 km unimproved earth
Inland waterways: 12,800 km; 3,200 km navigable by
large commercial vessels
Ports: 4 major, 6 minor
Civil air; about 20 major transport aircraft
29
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BURMA/BURUNDI
Airfields: 80 total, 79 usable; 23 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 38 with runways
1,220-2,489 m
Telecommunications: provide minimum requirements
for local intercity service; international service is fair;
radiobroadcast coverage is limited to the more populous
areas, 30,300 telephones; 627,000 radio, and no TV sets; 5
AM, 1 FM, and no TV stations
DEFENSE FORCES
Military budget: (announced) for fiscal year ending 31
March 1978; $148.9 million, comprising 5% of central
government budget
oe ss .-Qgfstanbul
es OLPADS
ig
Ankara
Turkey
Cyprus oo (
c * Nicosia |
Be Mediterranean Sea
se n
\\
\\
\\ Jiddany «Mecca
\\
)
Ney
Port ae Red
*Khartoum','f5cd4ca95bf23489642d3881f7c8431da3ed5655d289920676277117c7facab7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b624c1b23a29b28a3fab244e536e588276895ecd235954595c01e51f7590466',1978,'BI','Burundi','communications',88,'(See reference mep Vi}
LAND
28,490 km*; about 37% arable (about 66% cultivated), 23%
pasture, 10% scrub and forest, 30% other
Land boundaries: 974 km
Railroads: none
Highways: 7,800 km; 300 km bituminous, 2,500 km
crushed stone, gravel, or laterite, and 3,000 km improved
earth, and 2,000 km unimproved earth
Inland waterways: Lake Tanganyika navigable for lake
steamers and barges, 1 minor lake port
Civil air: 4 major transport aircraft
Airfields: 12 total, 12 usable; 1 with permanent-surface
runway; 1 with runway 2,440-3,659 m
Telecommunications: telegraph is principal service,
limited telephones; 6,000 telephones (0.2 per 100 popl.); 2
AM, 1 FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 907,000; 470,000 fit for
military service; 45,000 reach military age (16) annually
Military budget: for fiscal year ending 31 December
1977, $11,200,000; about 17% of central government budget','28f013052c8a1f1dd4b2b10e19c9a2fab89c3d3ae445869e8ef16585e1f9d2dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28de5164d615d881b5f377099a06fbea725f76ab84984441d6453acec1d8da87',1978,'KH','Cambodia','communications',92,'(See raterence map Vit)
LAND
181,300 km*; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other
Land boundaries: 2,438 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: about 443 km
Railroads: 612 km meter gage (1.00 m); govern-
ment-owned
Highways: 13,086 km; 2,430 km bituminous, 7,033 km
crushed stone, gravel, or improved earth; and 3,573 km
unimproved earth; some roads in disrepair
Inland waterways: 3,700 km navigable all year to craft
drawing 0.6 meters; 282 km navigable to craft drawing 1.8
meters
Ports: 2 major, 5 minor
Airfields: 60 total, 25 usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 6 with runways
1,220-2,439 m; 1 seaplane station
DEFENSE FORCES
Military manpower: males 15-49, 1,831,000; 1,017,000 fit
for military service; 82,000 reach military age (18) annually
Military budget: unknown','a39a25cb4c6f965c1940bfacf5bc2c1c59b8803bb8848984aaa60d26230e03e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c8dbe598c669ac40ac007d48424ab07d9719e18f35251da61cf26b59529ebdc',1978,'CM','Cameroon','communications',96,'EQUATORIAL
GUINEA .~
{See reference map Vi}
LAND
475,400 km?; 4% cultivated, 18% grazing, 13% fallow, 50%
forest, 15% other
Land boundaries: 4,554 km
WATER
Limits of territorial waters (claimed): 18 nm
Coastline: 402 km
Railroads: 1,003 km; 858 km meter gage (1.00 m), 145
km 0.600-meter gage
Highways: approximately 29,866 km; including 2,155 km
bituminous, 27,711 km gravel and earth
Inland waterways: 2,090 km
Ports: 1 major (Douala), 3 minor
Civil air: 9 major transport aircraft
Airfields: 63 total, 60 usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 21 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: fair telephone service; fair to good
telegraph service; 26,000 telephones (0.4 per 100 popl.); 4
AM, no FM, and no TV stations; 1 submarine cable; 1
Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,538,000; 766,000 fit
for military service; average number reaching military age
(18) annually about 66,000
Military budget: for fiscal year ending 30 June 1978,
$53,996,400; 9.7% of central government budget','670ab2b98fc634f0a0e6cc841cccdf9962c91188699a36cd1b1891e6ee2a497e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dacd2eb44310f0f50a2faabbd4af57cae5ad97a0f55ff344f4ffd48f9d89c2ea',1978,'CA','Canada','communications',100,'LAND
9,971,500 km’; 4% cultivated, 2% meadows and pastures,
44% forested, 42% waste or urban, 8% inland water
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
& = Aretie Ocean
{See reference map {}
Land boundaries: 9,010 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 90,908 km
Railroads: 71,503 km; 70,14] km standard gage (1.435 m)
(43 km electrified); 1,183 km 1.067-meter gage (in
Newfoundland); 179 km 0.914-meter gage
Highways: 829,325 km; 640,850 km surfaced (189,800 km
paved), 188,475 km earth
Inland waterways: 3,000 km
Pipelines: oil, 21,983 km total crude and refined; natural
gas, 74,740 km
Ports: 19 major, 300 minor
Civil air: 609 major transport aircraft
Airfields: 1,788 total, 1,440 usable; 292 with permanent-
surface runways; 4 with runways over 3,660 m, 29 with
runways 2,440-3,659 m, 284 with runways 1,220-2,439 m: 58
seaplane stations
Telecommunications: excellent service provided by mod-
ern telecom media; 13.54 million telephones (57.2 per 100
popl.); countrywide AM, FM, and TV coverage including
630 AM, 80 FM, and 500 TV stations; 8 coaxial submarine
cables; 3 major COMSAT stations and 70 domestic COMSAT
stations
DEFENSE FORCES
Military manpower: males 15-49, 5,814,000; 4,998,000 fit
for military service; average number reaching military age
(17) annually 233,000
Military budget: proposed for fiscal year ending 31
March 1978, $3.98 billion; about 8.4% of proposed central
government budget
CAPE VERDE
LAND
4,040 km?*, divided among 10 islands and several islets
WATER
Limits of territorial waters: 100 nm
Coastline: 965 km
bi Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CAPE VERDE/CENTRAL AFRICAN EMPIRE
“CAPE VERDE
ee
oe
BS','ac3fa2f07abaa952d76576690f5eb1e260707e1709471b52c3cb222865c15bd2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e017396fc6bd6285407b5934b68a472cb35e0584922f6658bd5a714b6233f851',1978,'GN','Guinea','communications',104,'Atlantic Ocean BISSAU
er
{See reference map iV}
Ports: 1 major (Mindelo), 3 minor
Civil air: 2 major transport aircraft
Airfields: 6 total, 6 usable; 4 permanent-surface runways;
1 with runway 2,440-3,659 m, 4 with runways 1,220-2,489
m; 1 seaplane station
Telecommunications: interisland radio-relay system, HF
radio to mainland Portugal, about 2,500 telephones (0.8 per
100 popl.); 1 FM and 8 AM stations; 4 submarine cables (2
coaxial)
CENTRAL AFRICAN EMPIRE
CENTRE
AFRICAN
(See reference map Vi)
LAND
626,780 km? 10%-15% cultivated, 5% dense forests,
80%-85% grazing, fallow, vacant arable land, urban, waste
35
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CENTRAL AFRICAN EMPIRE
(See reference map Vi}
Land boundaries: 4,981 km
Railroads: none
Highways: 22,250 km; 290 km bituminous, 4,120 km
gravel and/or crushed stone, 7,800 km improved earth,
remainder unimproved earth
Inland waterways: 7,080 km; traditional trade carried on
by means of dugouts on the extensive system of rivers and
streams; the Oubangui River between Bangui and Brazza-
ville is navigable for about 8 months a year, and short
sections of the Sangha and the Lobaye Rivers are navigable
throughout year; during high-water period (July-December)
Oubangui navigable upstream from Bangui as far as Quango
36 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CENTRAL AFRICAN EMPIRE/CHAD
Ports: Bangui, Quango (river ports)
Civil air; 5 major transport aircraft
Airfields: 54 total, 48 usable; 3 with permanent-surface
runways; | with runway 2,440-3,659 m, 18 with runways
1,220-2,439 m
Telecommunications: facilities are meager; network is
composed of low-capacity, low-powered radiocommunica-
tion stations and radio-relay links; 5,540 telephones (0.3 per
100 popl.); 72,000 radio receivers; 1 AM station, 1 FM
station, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 464,000; 237,000 fit for
military service
Supply: mainly dependent on France, but has received
equipment from Israel, Italy, U.S.S.R., and FRG
Military budget: for fiscal year ending 31 December
1976, $7,879,414; about 9% of central government budget
6
Atlantic
Qcean
(See referance map Vi)
LAND
27,972 km?*; Rio Muni, about 25,900 km’, largely forested;
Fernando Po, about 2,072 km?
Land boundaries: 539 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 296 km
Railroads: none
Highways: Rio Muni—2,460 km, including approx. 185
km bituminous, remainder gravel and earth; Fernando Po—
300 km, including 146 km bituminous, remainder gravel
and earth
Inland waterways: Rio Muni has approximately 167 km
of year-round navigable waterway, used mostly by pirogues
Ports: 2 major (Macias Nguema Biyogo, Rey Malabo), 3
minor
Civil air: 2 major transport aircraft (leased in)
Airfields: 5 total, 3 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m
Telecommunications: fairly adequate for the size and
stage of development of the country; international commu-
nications by radio from Bata and Malabo to Cameroon,
Nigeria, and Spain; 1,700 telephones (0.5 per 100 popl.); 2
AM stations, no FM stations, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 77,000; 38,000 fit for
military service
Military budget: for fiscal year ending 31 December
1970, $3,475,700; 14.3% of central government budget
(See reference map vi)
LAND
238,280 km?*; 19% agricultural, 60% forest and brush, 21%
other
Land boundaries: 2,285 km
WATER
Coastline: 539 km
Limits of territorial waters (claimed): 200 nm
Railroads: 953 km, all 1.067-meter gage; 32 km double
track; diesel locomotives gradually replacing steam engines
Highways: 34,449 km: 5,260 km concrete or bituminous
surface, 19,945 km gravel or laterite, 9,242 km unimproved
earth
Inland waterways: Volta, Ankobra, and Tano rivers
provide 235 km of perennial navigation for launches and
lighters; additional routes navigable seasonally by small
craft; Lake Volta reservoir provides 1,125 km of arterial and
feeder waterways .
Pipelines: refined products, 3 km
Ports: 2 major (Tema, Takoradi), 1 naval base (Sekondi), 4
minor
Civil air: 11 major transport aircraft (including 2 leased
in)
Airfields: 19 total, 18 usable: 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 9 with runways
1,220-2,489 m
Telecommunications: good system of open-wire and
cable, radio-relay links and radiocommunication stations;
60,000 telephones (0.6 per popl.); 6 AM, no FM, and 8 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 2,375,000; 1,309,000 fit
for military service; 108,000 reach military age (18) annually
Atlantic Ocean
{See reference mag Vi)
LAND
246,050 km?; 3% cropland, 10% forest
Land boundaries: 3,476 km
WATER
Limits of territorial waters (claimed): 180 nm
Coastline: 346 km
Railroads: 805 km meter gage (1.00 m), 8 km standard
gage
Highways: 7,604 km; 4,949 km paved, remainder
unimproved earth
Inland waterways: 1,795 km; 500 km navigable by small
oceangoing vessels, 1,295 km navigable by shallow-draft
steamers and barges
Ports: 1 major (Conakry), 3 minor
Civil air: 7 major transport aircraft
BS Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GUINEA/GUINEA-BISSAU
Airfields: 17 total, 17 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 9 with runways
1,220-2,489 m; 3 seaplane landing areas
Telecommunications: inadequate system of openwire
lines, small radiocommunication stations, and 1 radio-relay
link; principal center Conakry, secondary center Kankan;
8,300 telephones (0.2 per 100 popl.); 1 AM station, no FM,
and no TV stations; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 995,000; 502,000 fit for
military service
Military budget: for fiscal year ending 30 September
1970 (latest information available), $6,073,000; 8.0% of
central government budget
Atlantic Ocean
(See reference map VI)
LAND
323,750 km2; 40% forest and woodland, 8% cultivated,
52% grazing, fallow, and waste, 200 mi. of lagoons and
connecting canals along eastern coast
Land boundaries: 3,227 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 515 km
105
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
IVORY COAST
Railroads: 657 km of the 1,173 km Abidjan to OQuagadou-
gou, Upper Volta line, all single track meter gage (1.00 m):
only diesel locomotives in use
Highways: 46,675 km, 2,388 km bituminous and bitumi-
nous-surface treatment; 33,097 km gravel, crushed stone,
laterite, and improved earth; 11,090 km unimproved
Inland waterways: 740 km navigable rivers and numer-
ous coastal lagoons
Ports: 2 major (Abidjan, San Pedro), 3 minor
Civil air: 18 major transport aircraft
Airfields: 50 total, 48 usable; 3 with permanent-surface
runways; 2 with runways 2,440-3,659 m: 8 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: system only slightly above African
average; consists of open-wire lines and radio relay links,
which provide incomplete coverage of country; Abidjan is
only center; 58,700 telephones (0.9 per 100 popl.); 2 AM, 4
FM, and 6 TV stations; 1 submarine cable; 1 Atlantic Ocean
satellite station
106 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
IVORY COAST/JAMAICA
DEFENSE FORCES
Military manpower: males 15-49, 1,579,000; 820,000 fit
for military service; 55,000 males reach military age (18)
annually
Military budget: for fiscal year ending 31 December
1976, $51,393,190; about 6.1% of total operating budget','0516bb770f0cbf4e6ec6ae5b43a41b16ba1291de7b75249bc96288d49b16d9e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7866aeafe4e10d205f5a96f58dcc31a8b99abede740ba267056bf4e81b4ba7e0',1978,'TD','Chad','communications',108,'{Sea reference map VI)
LAND
1,284,640 km*; 17% arable, 35% pastureland, 2% forest
and scrub, 46% other uses and waste
Land boundaries: 5,987 km
Railroads: none
Highways: 27,505 km; 242 km bituminous, 4,385 km
gravel and laterite, and remainder unimproved
Inland waterways: approximately 2,090 km of year-
round navigability, increased to 4,830 km during high-water
period
Civil air: 4 major transport aircraft
Airfields: 67 total, 63 usable; 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 24 with runways
1,220-2,439 m
Telecommunications: fair system of radiocommunication
stations only for intercity links; principal center N’Djamena,
secondary center Sarh; 5,480 telephones (0.1 per 100 popl.);
1 AM, no FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,004,000; 524,000 fit
for military service; average number reaching military age
(20) annually about 40,000
Supply: dependent on France primarily
Pacific
Ocean
Atlantic
Ocean
(See reference map tH)
LAND
740,740 km*; 2% cultivated, 7% other arable, 15%
permanent pasture, grazing, 29% forest, 47%
mountains, deserts, and cities
Land boundaries: 6,325 km
barren
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 6,435 km','9bb0537ddfb2d09b17b68db788ef6e56fbc5612b3d4dc7f68b2d58598e4ec624','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d3ecf8d5bd4680b83c2abed5ee8b4d2bc4768c22aeccbc7c75b8592204a6129',1978,'CL','Chile','communications',114,'Railroads: 6,361 km; 3,111 km 1.676-meter gage, 135 km
standard gage (1.435 m), 3,115 km meter gage (1.00 m)
Highways: 75,200 km; 9,000 km paved, 38,200 km gravel,
28,000 km improved and unimproved earth
Inland waterways: 725 km
Pipelines: crude oil, 755 km; refined products, 785 km;
natural gas, 320 km
Ports: 10 major, 20 minor
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CHILE/CHINA, PEOPLES REPUBLIC OF
Civil air: 87 major transport aircraft
Airfields: 352 total, 351 usable; 45 with permanent-
surface runways; 7 with runways 2,440-8,659 m, 53 with
runways 1,220-2,439 m; 6 seaplane stations
Telecommunications: modern telephone system based on
extensive radio relay facilities; 2,469,000 telephones (4.4 per
100 popl.); 1 Atlantic Ocean satellite station; 158 AM, 30
FM, and 56 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 2,773,000; 2,089,000 fit
for military service; average number reaching military age
(19) annually about 116,000
Military budget: for fiscal year ending 31 December
1977, US$420.5 million; about 28.5% of central government
budget
CHINA, PEOPLES REPUBLIC OF
Peking*
P
<
}
3 Uruguay
Buenos Aires*
Valparaiso
°
Santiag
*
Montevideo','0086d0b90fae1d43437844fe60db5ae7c8a8654d53fa1611a1dabddc6441a027','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb86a668e87e30455be22096a324d62a71231dffb474aac98b2c63b1551e7f43',1978,'CN','China','communications',115,'(See reference map Vil}
LAND
9.6 million km’; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of this area
consists largely of denuded wasteland, plains, rolling hills,
and basins from which about 3% could be reclaimed), 8%
forested; 2%-3% inland water
Land boundaries: 24,000 km
WATER
Limits of territorial waters (claimed); 12 nm
Coastline: 14,500 km
Railroads: networks total about 45,000 route km com-
mon-carrier lines; about 600 km meter gage (1.00 m); rest
standard gage (1.435 m); all single track except 9,000 km
double track on standard gage lines; approximately 1,025 km
electrified; about 9,700 km industrial lines (gages range from
0.59 to 1.435 m)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Highways: about 835,000 km all types roads; almost half
(about 300,000 km) unimproved natural earth roads and
tracks; about 215,000 km improved earth roads about 2- to
5-meters wide and in poor to fair condition; remainder
(about 260,000 km) includes majority of principal roads
Ports: 10 major, 180 minor
Airfields: 389 total; 247 with permanent-surface runways;
10 with runways 3,500 m and over; 50 with runways 2,500 to
3,499 m; 226 with runways 1,200 to 2,499 m; 92 with
runways less than 1,200 m; 2 seaplane stations; 9 airfields
under construction
Telecommunications: urban and industrial areas served
by reasonably adequate facilities for domestic and interna-
tional communication needs; facilities being expanded;
effective broadcast coverage is provided by radio, extensive
wired-broadcast networks, and an expanding TV network;
estimated 5 million telephones, 45 million radio receivers,
140 million wired-speakers and est. 500,000 TV receivers,
250 AM, 7 FM, and 120 TV transmitter and rebroadcast
stations; 3 standard international communications satellite
ground stations; coaxial cable links Canton to Hong Kong;
submarine cable links Shanghai to Japan; additional
submarine cables planned
CHINA, REPUBLIC OF
Taipei
PR
REPUBLIC OF
"South China
Railroads: 4,535 km operating in 1976; 3,870 km standard
gage (1.435 m), 665 km narrow gage (0.762 m); 259 km
double tracked; about 1,180 km_ electrified; govern-
ment-owned
Highways: about 20,278 km; 98.5% gravel, crushed stone,
or earth surface; 1.5% concrete or bituminous
Inland waterways: 2,253 km; mostly navigable by small
craft only
Ports: 6 major, 26 minor
DEFENSE FORCES
Military manpower: males 15-49, 3,905,000; 2,392,000 fit
for military service; 192,000 reach military age (18) annually
Military budget: announced for fiscal year ending 31
December 1977, $1.05 billion; about 15.4% of total
government budget
KOREA, SOUTH
(See reference map Vil}
LAND
98,400 km?; 23% arable (22% cultivated), 10% urban and
other, 67% forested
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Land boundaries: 241 km
WATER
Limits of territorial waters; 3 nm (fishing, 12 nm)
Coastline: 2,413 km
Freight carried: rail (1973) 4.8 billion metric ton/km,
34.2 million metric tons; highway 21.8 million metric tons;
air (1959) 361,184 kg carried
Pipelines: 515 km refined products
Ports: 10 major, 18 minor
Civil air: 28 major transport aircraft
Airfields: 121 total, 114 usable; 54 with permanent-
surface runways; 15 with runways 2,440-3,659 m, 17 with
runways 1,220-2,4389 m
DEFENSE FORCES
Military manpower: males 15-49, 8,777,000; 5,707,000 fit
for military service; average number reaching military age
(18) annually 408,000
Military budget: for fiscal year ending 31 December
1978, $2.6 billion; about 35% of central government budget
BN PHILIPPINES
Sea #
af
{See reference map Vil)
LAND
300,440 km?; 53% forested, 30% arable land, 5%
permanent pasture, 12% other
WATER
Limits of territorial waters (claimed): 0-300 nm (under
an archipelago theory, waters within straight lines joining
appropriate points of outermost islands are considered
internal waters; waters between these baselines and the
limits described in the Treaty of Paris, December 10, 1898,
the U.S.-Spain Treaty of November 7, 1900, and the
US.-U.K. Treaty of January 2, 1930 are considered to be the
territorial sea)
Coastline: about 22,540 km
Railroads: 3,508 km; 2 common-carrier systems
1.067-meter gage totaling about 1,170 km; 19 industrial
systems with 4 different gages totaling 2,333 km; 34%
government owned
Highways: 109,690 km (1976); 20,483 km paved; 51,642
km gravel, crushed stone, or stabilized soil surface; 37,565
km unimproved earth
Inland waterways: 3,219 km, limited to shallow-draft
(less than 1.5 m) vessels
Pipelines: refined products, 251 km
Ports: 11 major, numerous minor
Civil air: approximately 60 major transport aircraft
Airfields: 331 total, 302 usable; 53 with permanent-sur-
face runways, 8 with runways 2,440-3,659 m, 30 with
runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 9,713,000; 6,941,000 fit
for military service; about 448,000 reach military age (20)
annually
Supply: limited small arms and small arms ammunition,
small patrol craft, and helicopter production; other materiel
obtained almost exclusively from U.S.; naval ships and
equipment from Australia, Japan, Singapore, US., and Italy;
aircraft and helicopters from West Germany and USS.','cb3c96c9255f77f393c54155d7adcad232d9024e8012f657a6c89cfa320f5472','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d81792eebaf493b3ba3dba46b766944a02baa1143d020577fc9e953c2c603da5',1978,'PH','Philippines','communications',119,'(See reference map Vil}
LAND
32,260 km? (Taiwan and Pescadores); 24% cultivated, 6%
pasture, 55% forested, 15% other (urban, industrial, de-
nuded, water area)
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 990 km Taiwan, 459 km offshore islands
41
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CHINA, REPUBLIC OF
Railroads: about 1,000 km common-carrier and 3,500 km
industrial lines, all on Taiwan; common-carrier lines consist
of West System: 825 km meter gage (1.00 m) with 325 km
double track, complete line under construction for electrifi-
cation (approx. 30% complete); East Line: 175 km narrow
gage (0.762 m) (presently under constuction to convert to
meter gage compatible with West System); common-carrier
lines owned by government and operated by Railway
Administration (TRA) under Ministry of Communications;
industrial lines owned and operated by government
enterprises
Highways: network totals 16,900 km (construction of
North-South Freeway approximately 84%—250 km—com-
plete), plus 483 km on Penghu and offshore islands; 7,564
km paved, 6,276 km gravel and crushed stone, 2,736 km
earth
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CHINA, REPUBLIC OF/COLOMBIA
Pipelines: 615 km refined products, 97 km natural gas
Ports: 5 major, 5 minor
Airfields: 38 total, 36 usable; 26 with permanent-surface
runways; 2 with runways over 3,660 m, 11 with runways
2,440-3,659 m, 10 with runways 1,220-2,489 m; 1 seaplane
station
Telecommunications: good international and domestic
service; 1.1 million telephones; est. 3 million radio receivers;
2.9 million TV receivers, 111 AM, 6 FM broadcast stations; 3
TV systems; 2 international COMSAT ground stations; radio
relay links to Hong Kong and the Philippines; new inter-
island submarine cables; Manila submarine cable planned
DEFENSE FORCES
Military manpower: males 15-49, 4,146,000; 3,328,000 fit
for military service; about 199,000 currently reach military
age (19) annually
Military budget: for fiscal year ending 30 June 1978,
$1,814.7 million including personnel costs; about 52.5% of
central government budget
Railroads: 35 km standard gage (1.435 m); government
owned
Highways: 966 km; 660 km paved, 306 km gravel and
crushed stone, or earth
Ports: 1 major
Civil air: 17 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 1 with runway
1,220-2.439 m; 1 seaplane station
o2 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
HONG KONG/HUNGARY
Telecommunications: modern facilities provide domestic
and international services; excellent broadcast coverage
provided by wired and radio broadcast stations; closed-cir-
cuit TV and TV broadcast facilities; 1 million telephones; 2.5
million radio receivers; 100,000 wired-speakers, 2 FM, 2 AM
stations; wired-broadcast network; 859,000 TV receivers, 2
TV stations, 2 closed-circuit TV networks; radio relay link to
Taiwan; 2 international communications satellite ground
stations; coaxial cable link to Canton; 5 submarine cables;
submarine cable to Japan and Philippines completed
DEFENSE FORCES
Military manpower: males 15-49, 1,201,000; 937,000 fit
for military service; about 55,000 reach military age (18)
annually
Defense is the responsibility of U.K.
Highways: 42 km paved
Ports: ] major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
Telecommunications: fairly modern communication fa-
cilities provide adequate services for domestic and interna-
tional requirements; broadcasting coverage is provided by
AM and FM radio facilities and a wired broadcast network;
9,633 telephones; 65,000 radio receivers; 2 AM, 1 FM and no
TV stations; no submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 60,000; 35,000 fit for
military service
Defense is responsibility of Portugal
Personnel: there are no Portuguese military personnel in
Philippine Sea
Manila
Ln
s N)
South','20055988d8249b7c81b31e877b79a84b27b9aa44c954cc29a6ae7c23c43068e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76e18626a6d0558ad5b3336178c6739a461384e51a59920318a19e9056d16fd7',1978,'CO','Colombia','communications',123,'—-
4 Bogota
(See reference map fil}
LAND
1,139,600 km?; settled area 28% consisting of cropland and
fallow 5%, pastures 14%, woodland, swamps, and water 6%,
urban and other 3%; unsettled area 72% —mostly forest and
savannah
Land boundaries: 6,035 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 2,414 km
Railroads: 3,436 km, all 0.914-meter gage, single track, 35
km electrified
Highways: 56,650 km; 8,200 km paved, 44,750 km
crushed stone or gravel, 6,700 km improved earth
Inland waterways: 14,300 km, navigable by river boats
Pipelines: crude oil, 3,220 km; refined products, 1,330
km; natural gas, 590 km; natural gas liquids, 125 km
Ports: 5 major, 5 minor
Civil air: 87 major transport aircraft
Airfields: 722 total, 680 usable; 48 with permanent-
surface runways; 1 with runway over 3,660 m; 5 with
runways 2,440-3,659 m, 86 with runways 1,220-2,439 m; 11
seaplane stations
Telecommunications: nationwide radio-relay system; 1
Atlantic Ocean satellite station; 1.34 million telephones (5.5
per 100 popl.); 325 AM, 180 FM, and 48 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 5,502,000; 3,594,000 fit
for military service; average number reaching military age
(18) annually about 260,000
Military budget: proposed for fiscal year ending 31
December 1978, $181.8 million; about 7.7% of central
government budget
SRecife
P
5
? Salvador
Brasilia
’
ee i ‘
~ Rio de Janeiro
So Paulo,
Antofagasta,
800 Kilometers
400 800 Miles
BOUNDARY REPRESENTATION 15
NOT NECESSARILY AUTHORITATIVE
502848 1-78
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
VIII Oceania
poi Hong Kang ./ Taiwan - Kauai
Oahu
"Don (U.K)
* Maui
Wake @ 83 HAWAIIAN ~ ai
ee D lawaii
tates}
South China v Phifrpoine Sea - Johnston
Cale Saipan
Sea Mani
ae Guam 8. ¢
Trust Territory of the Pacific islands ‘ ts
: clei, Pt : OF RO” OH P
Mindanab var pron ee Me, :
J PALAU me M23. 4 Truk o ;
Brunei ISLANDS : Cc lands Ponape: ; S Kingman Reef <
UK ae hs ARO, ; 4. ALS.) Palmyra #
ik YNE ISLANDS Qs ee 4
; Washington <
Celebes Sea } Fanning
LOL a % Christmas
‘ Ve 4 2 ’ S _ Howland 1.8.3 -
Be CR, oe : Baker (U8. rt.)
is oD jj M SD ’
ee a She Guinea - J Nauru % U.8-8X joint admin Ja rvis c
ane i~ sited oe o Canton =" PHOENIX IS. >
: pales BOK Bismarck Sea Phoenix——>° W.K. admin. US. claim) a
Banda Sea | » ~ invi Gardner Hull
. Java Sea ara 5 :., Bougainville 5 ar fu!
x \\ . alomon islands .
a 7 n ie. onesia } \\ Papua Rew Guities Choiseul WK.) Gilbert tsitiandes ecg
pied = Bes np OZ Mktg? an won Lee ‘Sei ‘amon Sea a Santa Isabel Tuvalu (ULK,) US. cieim:
9 XS az z Ge one : Hohiar \\ Malaita SANTA WK , fay, a , by New Zeeian iw
‘ a Angier Sea : aie =e - Guadalcanal ween Crmae ae American ‘
A = = Rennell e a ILES MARQUISES
; if : ot Wati estern :
INDIAN 4 a. Bip nin?) SAPS “Bago, “Gaal lslands
; Santols, Aviat TF ee a5
: Cuore a b Tutuila 2
OCEAN Peery mace FIJI ISLANDS | € x
. New ree “yt VanuaLevu.=?.''S T > : “&
Shag eae % onga %& oN
: : © Viti ae ° < «Papeete >»,
“Asuva. B Niue V5. Tahiti e
i ad Ss
eS New BN ; : © Ss
", a “
: aledonia aN Big Nuku''alofa Rarotonga hes i Monihis
New Caledonia ~~. : : Sta French lles Gambier
Fro}
Polynesia
é i : a | ; c Pitcairn Islands
{U.K
Rapa
New
zealand &
Tasmania
obart
Line of separation
(not a formal international
boundary or territorial limit)
1000 Nautical Miles
1000 Statute Miles
500
500
BOUNDARY REPRESENTATION IS
NOT NECESSARILY AUTHORITATIVE
503196 1-78
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4','2f951a13e2fad311f6c2c74625e658bf8d50c52840da79da5d1e9c2d7862c7c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('315b3eee042062f8f9de683bf3e23c0b183aa087472529b62414b3545537e9a1',1978,'KM','Comoros','communications',127,'‘ndian Ocean
/ Moroni, COMOROS
{See reference map VI}
LAND
2,170 km?; 4 main islands; forests 16%, pasture 7%,
cultivable area 48%, non-cultivable area 29%
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm), 200 nm exclusive economic zone
Coastline: 340 km
Railroads: none
Highways: 999 km; approximately 295 km bituminous,
remainder crushed stone or gravel
Ports: 1 minor (Moroni on Grande Comore)
Civil air: 4 major transports (2 registered in France)
Airfields: 5 total, 5 usable; 5 with permanent surface
runways; lL with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications: sparse system of HF radiocom-
munication stations for interisland, island and external
communications to Malagasy and Reunion; 1,410 telephones
(0.4 per 100 popl.); 1 AM, 1 FM, and no TV stations
Railroads: 884 km of meter gage (1.00 m)
Highways: 26,992 km; 4,285 km paved, 228 km crushed
stone, gravel, or stabilized soil; remainder improved and
unimproved earth (est.)
Inland waterways: of local importance only, isolated
streams
Ports: 4 major (Tamatave, Diego Suarez, Majunga,
Tulear)
Civil air: 5 major transport aircraft (including 2 leased
out)
Airfields: 239 total, 121 usable; 29 with permanent-sur-
face runways; 3 with runways 2,440-3,659 m, 45 with
runways 1,220-2,439 m
Telecommunications: system above African average;
includes open-wire lines, some radio-relay and coaxial links
and 1 Atlantic Ocean satellite ground station; 32,000
telephones (0.4 per 100 popl.); 10 AM, no FM, and 4 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 1,751,000; 1,034,000 fit
for military service; average number reaching military age
(20) annually about 84,000
Supply: nearly all from France in the past, now mostly
from West and East European countries
(See referance map Vi)
LAND
404 km?; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest land, 29% other (mainly
reefs and other surfaces unsuited for agriculture); 40 granitic
and 48 coral islands
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 491 km (Mahe Island 93 km)','4a0e62e9ef3694d854d6097642b1fcdff2476d581d34c99032bb6a0403ab5d44','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e6f5ddcbe7b1add0ceb70238f6b1ff2e41512b0666a20d91f6743a6212b9f63',1978,'CG','Congo','communications',131,'LAND
349,650 km’; 63% dense forest or woodland, 33%
cultivable or grazing (2% cultivated est.), 4% urban or waste
Atlantic
Ocean
{See reference map Vi}
Land boundaries: 4,514 km
WATER
Limits of territorial waters (claimed): 30 nm
Coastline: 169 km
Railroads: 800 km, 1,067-meter gage, single track
Highways: 8,246 km; 535 km bituminous surface treated;
remainder gravel, laterite, or improved earth
Inland waterways: 6,485 km navigable
Pipelines: crude oil 25 km
Ports: 1 major (Pointe Noire)
Civil air: 6 major transport aircraft
Airfields: 68 total, 51 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 20 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: services adequate for government
and public; network is comprised of low-capacity,
low-powered radiocommunication stations, coaxial cables
and wire lines; key centers are Brazzaville, Pointe-Noire, and
Loubomo; 10,500 telephones (0.7 per 100 popl.); 3 AM
stations, 1 FM station, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 340,000; 169,000 fit for
military service; about 14,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1976, $37,517,400; about 17% of central government budget','8f615b75ff77755b04b68fc04e3b38c1e8544e71c174ca5cd33d31e2a5cd5832','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6040820db1a3c80ebf8147e8a48a6ec32e93022d955898f074c23c4636a26a1',1978,'CK','Cook Islands','communications',135,'Pacific Ocean
*
" cook
ISLANDS
Pacific Ocean
fe NEW
ZEALAND
(See reference map Vill)
LANI#®
About 240 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 120 km
Railroads: none
Highways: 260 km; 19 km paved, 109 km gravel, 84 km
improved earth, 48 km unimproved earth
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 1 with permanent-surface
runway 2,317 m, 2 with natural surface runways 1,220-2,439
m; 1 seaplane station
Telecommunications: 6 AM, no FM, and no TV stations;
7,000 radio receivers, and 960 telephones','2eda8607f12f5f9b1d3159028b3c483ec00055d176aaacb3432048e762791cd9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e7c8cd39ef537e6bfc2722cb0831cc5967f201182e1dec2377843f3296dfc98',1978,'CR','Costa Rica','communications',139,'‘S00 ‘alarence mop
LAND
51,000 km?; 30% agricultural land (8% cultivated, 22%
meadows and pasture), 60% forested, 10% waste, urban, and
other
Land boundaries: 670 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; specialized competence over living resources to 200 nm)
Coastline: 1,290 km
Railroads: 563 km 1.067-meter gage, all single track, 115
km electrified
Highways: 25,600 km; 1,950 km paved, 7,450 km gravel
16,200 km unimproved earth
Inland waterways: about 730 km perennially navigable
Pipelines: refined products, 125 km
Ports: 3 major (Limon, Golfito, Puntarenas), 4 minor
Civil air: 21 major transport aircraft
Airfields: 155 total, 146 usable; 24 with permanent-
surface runways; 1 with runway 2,440-3,659 m; 8 with
runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: good domestic telephone service;
115,000 telephones (5.6 per 100 popl.); connection into
Central American microwave net; 29 AM, 10 FM, and 12
TV stations
DEFENSE FORCES
Military manpower: males 15-49, 460,000; 301,000 fit for
military service; average number reaching military age (18)
annually about 26,000
Supply: dependent on imports from U.S.
Military budget: for fiscal year ending 31 December
1977, $13.5 million for Ministry of Public Security,
including the Civil Guard; about 2.7% of total central
government budget','bcb7d481e0617fc33c36cd0880af59b711f68498e3944e5791ed1c6b26d8ca48','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16e06341d91044cc80c83e3e4c5659a4b53b242889b71e4213485962c8b4d0a8',1978,'CU','Cuba','communications',143,'LAND
114,478 km’; 35% cultivated, 30% meadow and pasture,
20% waste, urban, or other, 15% forested
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
- Coastline: 3,735 km
Railroads: 14,640 km government-owned; 5,040 km
common-carrier lines of which 4,960 km standard gage
(1.435 m), 80 km 0.914-meter gage; about 9,600 km
plantation/industrial lines, 6,400 km standard gage (1.435
m), 3,200 narrow gage
Highways: 20,700 km; 8,800 km paved, 11,900 km gravel
and earth surfaced
Inland waterways: 240 km
Pipelines: natural gas, 80 km
Ports: 8 major (including U.S. Naval Base at Guantan-
amo), 44 minor; Guantanamo under U.S. control
Civil air: 32 major transport aircraft (1 leased)
Airfields: 192 total, 182 usable; 46 with permanent-
surface runways; 1 with runway over 3,660 m, 8 with
runways 2,440-3,659 m, 26 with runways 1,220-2,439 m; 11
seaplane stations
49
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CUBA/CYPRUS
Telecommunications: modern facilities adequately serve
military, governmental, and some civilian needs; excellent
international facilities via HF and satellite; 380,000 tele-
phones (3.9 per 100 popl.); 100 AM, 25 FM, and 15 TV
stations; 4 submarine cables
DEFENSE FORCES
Military budget: for fiscal year ending 31 December 1966
(last announced budget), $213 million; about 7.8% of total
budget','025df33a61eaf4dc431fa8f4ace2e3466864da4f8c91ddf147324bdb1b58dadc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0674dde632618faacf1069bc9dfcc88cf04d5b5ace863883281e59b972ec0a8',1978,'CY','Cyprus','communications',147,'*~
Mediterranean
{See reference map V)
LAND
9,251 km*; 47% arable and land under permanent crops,
18% forested, 10% meadows and pasture, 25% waste, urban
areas, and other
WATER
Limits of territorial waters (claimed): 12 nm
Railroads: none
Highways: 9,358 km; 4,203 km bituminous surface
treated; 5,155 km gravel, crushed stone, and earth
Ports: 8 major (Famagusta, Larnaca, Limassol), 6 minor;
Famagusta under Turkish control
Civil air: 5 major transport aircraft, all leased in
Airfields: 13 total, 12 usable; 8 with permanent-surface
runways; 3 with runways 1,220-2,439 m; 4 with runways
2,440-3,656 m
Telecommunications: moderately good telecommunica-
tion system; 77,000 telephones (11.2 per 100 popl.); 12 AM, 3
FM, and 4 TV stations; tropospheric scatter circuits to
Greece and Turkey; 2 submarine coaxial cables
DEFENSE FORCES
Military budget: for fiscal year ending 81 December
1977, $33.7 million about 14% of central government budget
CZECHOSLOVAKIA
LAND
127,946 km?; 42% arable, 14% other agricultural, 35%
forested, 9% other
Land boundaries: 3,540 km
Railroads: 13,215 km; 12,910 km standard gage (1.435
m), 112 km broad gage (1.524 m), 193 km narrow gage
(0.750 m and 0.760 m); 2,803 km double track; 2,707 km
electrified; government-owned (1975)
Highways: 73,600 km; 2,000 km concrete; 55,200 km
bituminous; 2,880 km cobblestone, brick sett, stone block;
13,520 km crushed stone, gravel, improved earth (1975)
Inland waterways: 483 km (1977)
Pipelines: crude oil, 1,448 km; refined products, 861 km;
natural gas, 5,601 km
52 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CZECHOSLOVAKIA/DENMARK
Freight carried: rail—275.5 million metric tons, 70.7
billion metric ton/km (1976); highway—1,011.9 million
metric tons, 15.2 billion metric ton/km (1976); waterway—
5.9 million metric tons, 2.6 billion metric ton/km (excl. int''l.
transit traffic) (1976)
Ports: no maritime ports; outlets are Gdynia, Gdansk, and
Szezecin in Poland; Rijeka and Koper in Yugoslavia;
Hamburg, FRG; Rostock, GDR; principal river ports are
Prague, Melnik, Usti nad Labem, Decin, Komarno, Bra-
tislava (1976)','3872af7be410817ea35e0c028ea87da6aef1a7cb76bbf192e3599ed65b0d0cda','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2666c51128a68335f6dfa643d2d2f6d2ca1a337fce44a3a15507e068b904c285',1978,'DK','Denmark','communications',151,'By voles A
a e
Si os aitaines ce Ww)
LAND
42,994 km? (exclusive of Greenland and Faroe Islands);
64% arable, 8% meadows and pastures, 11% forested, 17%
other
Land boundaries: 68 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 3,379 km
Railroads: 2,578 km standard gage (1.485 m); Danish
State Railways (DSB) operate.2,131 km (1,999 km rail line
and 132 km rail ferry services); 97 km electrified, 743 km
double tracked; 477 km of standard gage lines are
privately-owned and operated
Highways: approximately 64,480 km; 62,400 km con-
crete, bitumen, or stone block; 2,080 km gravel,. crushed
stone, improved earth
Inland waterways: 417 km
Pipelines: refined products, 418 km
Ports: 16 major, 44 minor
Civil air: 85 major transport aircraft including 3 leased in
and 3 leased out
Airfields: 174 total, 185 usable; 23 with permanent-
surface runways; 8 with runways 2,440-3,659 m, 8 with
runways 1,220-2,489 m; 1 seaplane station
Telecommunications: excellent telephone, telegraph, and
broadcast services; 2.36 million telephones (45.0 per 100
popl.); 5 AM, 13 FM, and 34 TV stations; 14 submarine
coaxial cables
54
DEFENSE FORCES
Military manpower: males 15-49, 1,216,000; 1,065,000 fit
for military service; 38,000 reach military age (20) annually
Military budget: proposed for fiscal year ending 31
March 1978, $940.5 million; about 15.6% of proposed central
government budget','da606ea5c051f3121e2488183ee64dcc2b75a1a1ebbf0fda776bd08d6a867faf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6778b1fdb59c82dcff9bb1fb8a10709a8265802994c51b8d8baf781e44453a86',1978,'DJ','Djibouti','communications',155,'(formerly French Territory of the Afars
and _ Issas)
Red Sea *
(See reference map Vi)
LAND
23,310 km’; 89% desert wasteland, 10% permanent
pasture, and less than 1% cultivated
Land boundaries: 517 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 314 km (includes offshore islands)
Railroads: 97 km meter gage (1.00 m)
Highways: 750 km; 100 km paved, 650 km improved
earth
Ports: 1 major (Djibouti)
Airfields: 7 total, 7 usable; 1 with permanent-surface
runway; 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m
Civil air: no major transport aircraft
Telecommunications: fair system of urban facilities in
Djibouti and radiocommunication stations at outlying places;
3,600 telephones (2.0 per 100 popl.); 1 AM, no FM, and 1 TV
station
DEFENSE FORCES
Military manpower: males 15-49, about 30,000; about
17,000 fit for military service
Defense is responsibility of France
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
500 Kilometers
500 Miles
Names and boundary representation
are not necessarily authoritative
Indian Ocean
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009000100@4-4 Africa
PS , ae Poland
North bo hop ean?
fresh
Atlantic sy Zine. - pe
fc Bt :
Ocean - ; * Ay: ee aN
Switz.
= ; a : ‘i i.
ea 1S os . Black Sea
\\ -
Portugal ig Spain |
a
4
;
J
oe SAE PS ated
j Cyprus 7
Ye yf + iy
y Mediterranean Sea
Rabat \\
Left,
Turkey
‘ .
> Caspian
* Sea
a
Syr
Morocco , : . ; israe ven”
Canary | 3009 sh A 5: x : x A
: Fa
17,
N Algeria
ae','4c9127905c1f605f92dfdcd4e812fea65749db60e0500d98124203e880225461','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fbdc5b9ed8743d53ec92cce9410249d2ff6a7917259d8fb54b27da90d16e94d',1978,'DM','Dominica','communications',159,'DOMINICAN Atlantic
re
DOMINICA®
Caribbean Sea
LAND
790 km; 24% arable, 2% pasture, 67% forests, 7% other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 148 km
Railroads: none
Highways: 750 km; 500 km paved, 250 km gravel and
earth
Ports: 2 minor (Roseau, Portsmouth)
Civil air: no major transport aircraft
Airfields: 1 with asphalt runway 1,472 m
Telecommunications: 3,000 telephones in fully automatic
network (4.1 per 100 popl.); VHF and UHF link to St. Lucia;
1 AM and 1 TV station','b3902ef06a7d001d0c44547232769c9ddce1e786c3fde9d5f78db5798c971d37','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d7b9e923e941b42562c7bb190bac136bd02caf49c8acaba639b3d74835973d1',1978,'JM','Jamaica','communications',163,'Caribbean Sea
(See reference map tl}
LAND
48,692 km’; 14% cultivated, 4% fallow, 17% meadows and
pastures, 45% forested, 20% built-on or waste
Land boundaries: 361 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 1,288 km
Railroads: 1,600 km; 104 km government-owned com-
mon-carrier 1.065-meter gage; 1,496 km privately owned
plantation lines of 4 different gages ranging from 0.60 m to
1.43 m, 0.760-meter gage predominating
Highways: 11,400 km; 5,800 km paved, 5,600 km gravel
and improved earth
Pipelines: refined products, 69 km
Ports: 5 major (Santo Domingo, Barahona, Haina, Las
Calderas, San Pedro de Macoris), 17 minor
Civil air: 31 major transport aircraft
Airfields: 52 total, 46 usable; 11 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 9 with runways
1,220-2,489 m; 1 seaplane station
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Telecommunications: relatively efficient domestic system
based on islandwide radio relay network; 115,000 telephones
(2.4 per 100 popl.); 110 AM, 31 FM, and 11 TV stations; 3
submarine cables, including 1 coaxial; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,135,000; 718,000 fit
for military service; 52,000 reach military age (18) annually
Atlantic
Ocean
ass
JAMAICA Ringston
Caribbean Sea
(See reference map tt)
LAND
11,422 km?; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,022 km
Railroads: 326 km government-owned, 69 km privately
owned, all standard gage (1.435 m), single track
Highways: 11,250 km; 7,600 km paved, 2,150 km gravel,
1,500 km improved earth
Pipelines: refined products, 10 km
Ports: 3 major (Kingston, Montego Bay, Montego Free-
port), 10 minor
Civil air: 14 major transport aircraft
Airfields: 42 total, 22 usable; 12 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 1 with runway
1,220-2,439 m; 3 seaplane stations
Telecommunications: fully automatic domestic telephone
network with 100,200 telephones (5.0 per 100 popl.); 1
Atlantic Ocean satellite station; 8 AM, 11 FM, and 9 TV
stations; 3 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 450,000; 320,000 fit for
military service; no conscription; average number currently
reaching minimum volunteer age (18) 25,000
Supply: dependent on U.K. and USS.
Military budget: for fiscal year ending 31 March 1977,
$29.5 million; about 2.2% of central government budget','8c99a63ecde3168d75df13d7f676f6ed43e54a7ffd3c0369e412dadb0d6952c0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b64ed16e7dae06848dffecc90dfe0fb656d2d5c749f3d2af1c103702babc15ad',1978,'EC','Ecuador','communications',167,'Galapagos
Islands
Pacific Ocean
(See reference map It}
LAND
274,540 km? (including Galapagos Islands); 11% culti-
vated, 8% meadows and pastures, 55% forested, 26% waste,
urban, or other (excludes the Oriente and the Galapagos
Islands, for which information is not available)
Land boundaries: 1,931 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2,237 km (includes Galapagos Is.)
Railroads: 1,121 km; 966 km 1.067-meter gage, 155 km
0.750-meter gage; all single track
Highways: 22,250 km; 3,300 km paved, 11,300 km
otherwise improved, 7,650 km unimproved earth
Inland waterways: 1,500 km
Pipelines: crude oil, 623 km; refined products, 473 km
Ports: 3 major (Guayaquil, Manta, Puerto Bolivar), 1]
minor
Civil air: 37 major transport aircraft
Airfields: 173 total, 173 usable; 17 with permanent-
surface runways; 6 with runways 2,440-3,659 m, 21 with
runways 1,220-2,439 m; 3 seaplane stations
Telecommunications: facilities adequate only in largest
cities; | Atlantic Ocean satellite station; 193,000 telephones
(2.9 per 100 popl.); 240 AM, 38 FM, and 10 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,692,000; 1,103,000 fit
for military service; average number reaching military age
(20) annually 78,000
Guayaquil*
502849 1-78
Approved For Release 2005/04/22 : CIA-RDP79-01@3TA0QQQORH Mtterica
Hertadss','b485a69bdebec2297922d439eea743db279bae785d1c31e6259e3d4f1cecf80c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('542230b4e20107b21832baef285734cd384a14caee13e1bab86742eb43d62f30',1978,'EG','Egypt','communications',171,'LAND
1,000,258 km? (including 57,498 km? occupied by Israel);
2.8% cultivated (of which about 70% multiple cropped),
96.5% desert, waste, or urban; 0.7% inland water
a Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
(See reference map y}
Land boundaries: 2,527 km (1967); approximately 2,580
km including border of occupied Sinai area (since Septem-
ber 1975)
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 2,450 km (1967); includes approximately 500
km within occupied Sinai area (since September 1975)
Railroads: 5,405 km; 951 km double track; 25 km
electrified; 4,858 km standard gage (1.435 m), 200 km meter
gage (1.00 m), 347 km 0.750-meter gage
Highways: 47,276 km; 9,524 km paved, 450 km gravel
and crushed stone, 10,302 km improved earth, 27,000 km
unimproved earth
Inland waterways: 3,360 km; Suez Canal, 160 km long,
used by ocean-going vessels drawing up to 11.5 meters of
water; Alexandria-Cairo waterway navigable by barges of
metric ton capacity; Nile and large canals by barges of
420-metric ton capacity; Ismailia Canal by barges of 200- to
300-metric ton capacity; secondary canals by sailing craft of
10- to 70-metric ton capacity
Freight carried: Suez Canal (1966)—242 million metric
tons of which 175.6 million metric tons were POL
59
0004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A00090001
January 1978
EGYPT/EL SALVADOR
Pipelines: crude oil, 675 km; refined products, 240 km;
natural gas, 340 km
Ports: 3 major (Alexandria, Port Said, Suez), 8 minor
Civil air: 20 major transport aircraft
Airfields: 100 total, 81 usable; 66 with permanent-surface
runways; 43 with Tunways 2,440-3,659 m, 1 with runway
over 3,660 m, 21 with Tunways 1,220-2,439 m; 1 seaplane
station
Telecommunications; second-best system in Africa; prin-
cipal centers Alexandria and Cairo, secondary centers Al
Mansurah, Ismailia, and Tanta; intercity connections by
coaxial and multiconductor cables, wire lines, and radio
links; extensive upgrading of telephone system in progress to
improve capacity and quality; 503,000 telephones (1.3 per
100 popl.); 21 AM, 1 FM, and 29 Tv Stations; 1 Atlantic
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 8,592,000; 5,603,000 fit
for military service; about 384,000 reach military age (20)
annually','bfdd7a144a78a498301b864516b2dc077a671cf1ca88d334d9d88cf0073efda4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('991bb7957c9a5fb8c520900ee5a71460c4acbcf603e51fd6bbfe2ab674a3b69f',1978,'SV','El Salvador','communications',175,'Caribbean
Pacific Ocean
(See reference map Hl)
LAND
21,400 km?; 32% cropland (9% corn, 5% cotton, 7% coffee,
11% other), 26% meadows and pastures, 31% nonagricul-
tural, 11% forested
Land boundaries: 515 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 307 km
Railroads: 600 km 0.914-meter gage, single-tracked;
Highways: 7,250 km; 1,500 km paved, 1,300 km gravel
4,400 km improved and unimproved earth
Inland waterways: Lempa River partially navigable
Ports: 2 major (Acajutla, La Union), 1 minor
Civil air: 9 major transport aircraft
Airfields: 161 total, 153 usable; 1 with permanent-
surfaced runways; 9 with runways 1,220-2,439 m; 1 seaplane
station
Telecommunications: nationwide trunk radio relay sys-
tem; connection into Central American microwave net,
54,200 telephones (1.4 per 100 popl.); 51 AM, 6 FM, and 5
TV stations; 1 COMSAT station under construction
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
DEFENSE FORCES
Military manpower: males 15-49, 969,000; 594,000 fit for
military service; 46,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1977, $33.2 million; 7.75% of central government budget','87f52e25b76f82e1cefb08ec142e6e0bd2bbd3d125c00b27d848510526858474','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feebbe90d6e39485bfb5eb1a7916e62f4fbcaab77c82abc2500028b3d4c70239',1978,'ET','Ethiopia','communications',179,'= osiBourps™”
Addis
Ababa, seed
MALIA
Indian
Ocean
{See reference map Vij
LAND
1,178,450 km?2; 10% cropland and orchards, 55% meadows
and natural pastures, 6% forests and woodlands, 29%
wasteland, built-on areas, and other
Land boundaries: 5,198 km
WATER
Limits of territorial waters (claimed): 12 nm; sedentary
fisheries extends to limit of fisheries
Coastline: 1,094 km (includes offshore islands)
Addis Ababa*
503396 1-78
V The Middie East
. Caspian
Sea
@! abriz
Kirkik Tehran ,','83e25d5237ac6c32d1c64893c8cb0df7eb60eb014a327d78ac87959ace533b8c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32799326fafbd4a5c39b85e03c184e104095d19ed669fde04887871b0cf97584',1978,'DE','Germany','communications',184,'Railroads: 1,014 km; 676 km meter gage (1.00 m), 32 km
1.067-meter gage, 306 km 0.95-meter gage; all single track
Highways: 10,895 km; 3,229 km bituminous, 7,666 km
crushed stone, gravel, or stabilized earth, remainder earth
Inland waterways: 41 navigation possible on Lake Tana
and on approx. 225 km of unconnected and_ basically
unimproved waterways, of which only 114 km are navigable
year round
Ports: 2 major (Assab, Massawa)
Civil air: 20 major transport aircraft (including 1 leased in
and 2 leased out)
Airfields: 190 total, 176 usable; 7 with permanent-surface
runways; 1 with runway over 3,660 m, 7 with runways
2,440-3,659 m, 48 with runways 1,220-2,439 m
Telecommunications: system better than most African
countries; composed of open-wire lines, radiocommunication
stations, and small number of multiconductor cable and
radio-relay links; principal center Addis Ababa, secondary
center Asmara; 69,000 telephones (0.3 per 100 popl.); 4 AM
stations, no FM stations, and 1 TV station
63
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ETHIOPIA/FALKLAND ISLANDS (MALVINAS)/FAROE ISLANDS
DEFENSE FORCES
Military manpower: males 15-49, 7,366,000; 8,920,000 fit
for military service; average number reaching military age
(18) annually 301,000
Military budget: for fiscal year ending 6 July 1977,
$104,445,000; 14.7% of central government budget
FALKLAND ISLANDS (MALVINAS)*
Atlantic
Ocean
FALKLAND
JED ISLANDS
{See reference map tt)
LAND
Colony—12,168 km?; area consists of some 200 small
islands, chief of which are East Falkland (6,680 km?) and
West Falkland (5,276 km2); dependencies—consists of the
South Sandwich Islands, South Georgia, and the Shag and
Clerke Rocks
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 1,288 km
Railroads: none
Highways: 35 km; 16 km paved, 19 km gravel, and earth;
no other made-up roads in the islands beyond the immediate
vicinity of Stanley
Ports: 1 major (Port Stanley), 4 minor
Civil air: no major transport aircraft
Airfields: 1 usable airfield, 1 seaplane station
Telecommunications: government-operated and _radio-
telephone networks providing effective service to almost all
points on both islands; approximately 650 telephones (est. 30
per 100 popl.)
Railroads: 947 km, 0.914-meter gage, single-tracked; 832
km government-owned, 115 km privately owned
Highways: 13,700 km, 2,550 km paved, 3,200 km gravel,
5,500 km improved earth, 2,450 km unimproved earth
Inland waterways: 260 km navigable year-round; addi-
tional 730 km navigable during high-water season
Pipelines: crude oil, 48 km
Ports: 2 major (Puerto Barrios, Santo Tomas de Castilla), 3
minor
Airfields: 359 total, 358 usable; 8 with permanent-surface
runways; | with runway 2,440-3,659 m, 16 with runways
1,220-2,439 m; 1 seaplane station
Civil air; 11 major transport aircraft
Telecommunications: modern telecom facilities limited
to Guatemala City; 58,500 telephones (0.9 per 100 popl.); 97
AM, 20 FM, and 5 TV stations; connection into Central
American microwave net
DEFENSE FORCES
Military manpower: males 15-49, 1,489,000; 966,000 fit
for military service; about 65,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1977, $41.3 million, 52% of central government
budget
CIA-RDP79-01051A000900010004-4 i
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','ec4356e593cf8cb78f0132d0991554cbb20963ef9dbf51274217aec80a18d09b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3221de23a4587f94ffeb543611e1324813554e5515c191c90ce51822fb90fd25',1978,'FO','Faroe Islands','communications',187,'LAND
1,340 km; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited islands and
a few uninhabited islets
a Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
FAROE ISLANDS/FIJI
Norwegian
Sea
FAROE *
ISLANDS
Atlantic
he
{See reference map {V)
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 764 km
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less than
1,220 m
Civil air: no major transport aircraft
Telecommunications: good international communica-
tions; fair domestic facilities; 15,000 telephones (35 per 100
popl.); 1 AM, and 3 FM stations; 8 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49 included with Denmark','bc34029c96e42112e75654de2aed57828fe94aea98cbf6274904ea99a333cd54','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8d8f3b8272c952e443d64971ecd30f06ea38121cc16505a42c6e078af62f006',1978,'FJ','Fiji','communications',191,'LAND
18,272 km2; landownership—83.6% Fijians, 1.7% Indians,
6.4% government, 7.2% European, 1.1% other; about 30% of
land area is suitable for farming
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Pacific Ocean
Caral Sea
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,129 km
Railroads: none
Highways: 3,205 km (1976); 307 km paved, 2,676 km
gravel, crushed stone, or stabilized soil surface; 222
unimproved earth
Inland waterways: 203 km; 122 km_ navigable by
motorized craft and 200-metric ton barges
Ports: | major, 6 minor
Civil air: 5 major transport aircraft
Airfields: 15 total, 15 usable; 2 with permanent-surface
runways, 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,4389 m
Telecommunications: modern _ local, interisland, and
international (wire/radio integrated) public and special-pur-
pose telephone, telegraph, and teleprinter facilities; regional
radio center; important COMPAC cable link between
U.S./Canada and New Zealand/Australia, et al.; 29,000
telephones; 300,000 radio receivers; 5 AM, 2 FM, and no TV
stations; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 153,000; 84,000 fit for
military service; 6,000 reach military age (18) annually
ee Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
FIJI/FINLAND
Military budget: the defense of the Fiji Islands was the
responsibility of the U.K. until 10 October 1970; military
budget for 1971, $314,000','f84d9a894319d51b60dad86cb99c4553da70a62ebc8e543ef452afab6ff26e02','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ad63f3249146b16a8fc038d0c9146f58a61aaf2d9610822bda5489d8dd79ded',1978,'FI','Finland','communications',195,'Norwegian
Sea
(See reference map iV)
LAND
336,700 km?; 8% arable, 58% forested, 34% other
Land boundaries: 2,534 km
WATER
Limits of territorial waters (claimed): 4 nm; Aaland
Islands, 3 nm
Coastline: 1,126 km (approx.) excludes islands and coastal
indentations
Railroads: 6,038 km; Finnish State Railways (VR) operate
a total 6,010 km 1.524-meter gage, 477 km multiple track,
and 395 km electrified; 22 km 0.750-meter gage and 6 km
1.524-meter gage are privately owned
Highways: about 72,800 km in national classified net
work, including 29,600 km paved (bituminous, concrete,
bituminous surface treated) and 43.200 km unpaved
(stabilized gravel, gravel, earth); additional 29,440 km of
private (state subsidized) roads
Inland waterways: 6,597 km total (including Saimaa
Canal); 3,700 km suitable for steamers; Saimaa Canal locks
(84 m by 13.2 m with a 5.2 m depth over sill) can
accommodate vessels of up to 82 m in length, 11.8 m beam,
4.4 m draft, and 24.5 m mast height
Pipelines: natural gas, 161 km
Ports: 11 major, 14 minor
Civil air: 39 major transport aircraft
Airfields: 112 total, 111 usable; 36 with permanent-
surface runways; 17 with runways 2,440-3,659 m, 24 with
runways 1,220-2,439 m
Telecommunications: good telecom service from cable
and radio-relay network; 1.87 million telephones (38.9 per
100 popl.); 15 AM, 40 FM, and 76 TV stations; 4 submarine
cables, including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 1,217,000; 974,000 fit
for military service; 39,000 reach military age (17) annually
Military budget: proposed for fiscal year ending 31
December 1977, $478.4 million; about 5.5% of central
government budget
(See reference map 1¥)
LAND
551,670 km?; 35% cultivated, 26% meadows and pastures,
14% waste, urban, or other, 25% forested
Land boundaries: 2,888 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 3,427 km (includes Corsica, 644 km)','f093a965ef3ad5421c4706f1827e6c11afb1e6140708a40a7f6a9e2f8baa5895','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f40e747f0ec567b3d3a931109f8a53c993a75f6e6806c492301de1fb3d6b03d',1978,'FR','France','communications',201,'Railroads: 36,720 km; 35,552 km standard gage (1.485
m), 1,168 km other gages (1.00 m to 1.435 m); 9,345 km
electrified, 15,630 km double or multiple track
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
FRANCE/FRENCH GUIANA
Highways: National, Departmental, and Communal roads
total 795,520 km comprising 468,160 km paved, 304,000 km
crushed stone and gravel, and 23,360 km improved earth; in
addition, there are approximately 694,400 km of local farm
and forest roads
Inland waterways: 14,912 km; 5,604 km heavily traveled
Pipelines: crude oil, 2,253 km; refined products, 4,344
km; natural gas, 22,047 km
Ports: 23 major, 165 minor
Civil air: 297 major transport aircraft (including 9 foreign
based but French registered)
Airfields: 452 total, 433 usable; 220 with permanent-
surface runways; 2 with runways over 3,660 m, 28 with
runways 2,440-3,659 m, 123 with runways 1,220-2,439 m; 2
seaplane stations
Telecommunications: highly developed system provides
satisfactory telephone, telegraph, and radio and TV broad-
cast services; 14.1 million telephones (26.2 per 100 popl.); 42
AM, 94 FM, and 1,473 TV stations; 22 submarine cables (21
coaxial); 1 communication satellite ground station with 3
Atlantic Ocean and 2 Indian Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 12,888,000; fit for
military service 10,398,000; 425,000 reach military age (18)
annually
Military budget: for fiscal year ending 31 December
1977, $11.7 billion; about 17% of central government budget
RHODESIA
/ndian Ocean
(See reference map Vi)
LAND
391,090 km?; 40% arable (of which 6% cultivated); 60%
available for extensive cattle grazing; 389% European
alienated lands (farmed by modern methods), 48% African,
7% national land, 6% not alienated
Land boundaries: 3,017 km
Railroads: 2,743 km narrow gage (1.067 m); 41 km
double track
Highways: 78,428 km; 7,995 km paved, 32,855 km
crushed stone, gravel, stabilized soil, or improved earth;
37,578 km unimproved earth (est. )
Inland waterways: 280 km on Lake Kariba
Pipelines: 8 km crude oil (nonoperating)
Airfields: 346 total, 342 usable; 16 with permanent-sur-
face runways; 2 with runways over 3,660 m, 1 with runway
2,440-3,659 m, 26 with runways 1,220-2,489 m
Civil air: 15 major transport aircraft (including 2 leased
out)
Telecommunications: system is one of the best in Africa;
consists of radio-relay links, open-wire lines, and radiocom-
munication stations; principal center Salisbury, secondary
center Bulawayo; 182,600 telephones (2.9 per 100 popl.); 8
AM, 1 FM, and 3 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,511,000; 923,000 fit
for military service; average number reaching military age
(18) annually, 71,000
Military budget: for fiscal year ending 30 June 1978,
$306,000,000; 24.2% of central government budget','1b5b4427a5f343c533fdc90680f5ec6b0a2be98fba6948b55fce3283aa12aefe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('944294d0345f60ec41a847dc0aa6701b2089d47c4bce7f63489f4377e9be271c',1978,'GF','French Guiana','communications',202,'Atlantic. Ocean
FRENCH
UIANA
syenne
(See reference map tit}
LAND
90,909 km?; 90% forested, 10% wasteland, built-on, inland
water and other, of which .05% is cultivated and pasture
Land boundaries: 1,183 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 378 km
Railroads: 32 km private plantation line, 0.600-meter
gage
Highways: 500 km; 425 km paved, 75 km improved and
unimproved earth
Inland waterways: 460 km, navigable by small ocean-
going vessels and river and coastal steamers; 3,300 km
possibly navigable by native craft
Ports: | major (Cayenne), 7 minor
Civil air: no major transport aircraft
Airfields: 13 total, 10 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m
Telecommunications: limited open-wire and radio-relay
system with about 8,400 telephones (14.9 per 100 popl.); 9
AM, 2 FM, and 2 TV stations; 1 Atlantic Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 13,000; 9,000 fit for
military service
-FRENCH POLYNESIA
LAND
About 4,000 km?
WATER
Limits of territorial waters: 12 nm
Coastline: about 2,525 km
Highways: 3,700 km, all types
Ports: 1 major, 6 minor
Airfields: 25 total, 25 usable; 9 with permanent-surface
runways, 2 with runways 2,440-3,659 m, 13 with runways
1,220-2,439 m; 2 seaplane stations
Civil air: about 3 major transport aircraft
Telecommunications: 12,400 telephones; 72,000 radio
and 14,000 TV sets; 5 AM, 2 FM, and 6 TV stations
en)
EQUATORIAL
GUINEA» és
Atlantic
Ocean
{See reference map Vi)
LAND
264,180 km?*; 75% forested, 15% savanna, 9% urban and
wasteland, less than 1% cultivated
Land boundaries: 2,422 km
WATER
Limits of territorial waters (claimed): 100 nm: fishing,
150 nm
Coastline: 885 km
Railroads: none
Highways: 6,878 km; 342 km paved, 5,636 km gravel
and/or improved earth, remainder unimproved earth
Inland waterways: approximately 1,600 km perennially
navigable
Pipelines: crude oil, 129 km
Ports: 3 major (Libreville, Port-Gentil, Owendo), 2 minor
Civil air: 29 major transport aircraft (including 1 leased in
and 2 leased out)
Airfields: 163 total, 105 usable; 6 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 20 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: system of open-wire, radio-relay,
tropospheric scatter links and radiocommunication stations;
1 Atlantic Ocean satellite station; 5 AM, no FM, and 3 TV
stations; 7,000 telephones (1.3 per 100 popl.)
DEFENSE FORCES
Military manpower: males 15-49, 135,000; 69,000 fit for
military service; 6,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1977, $28,773,300; 2.8% of central government budget
THE GAMBIA
LAND
10,360 km?*; 25% uncultivated savanna, 16% swamps, 4%
forest parks, 55% upland cultivable areas, built-up areas, etc.
Land boundaries: 740 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 80 km
Railroads: none
Highways: 1,858 km; 190 km bituminous-surface treated,
1,330 km gravel/laterite, remainder unimproved earth
Inland waterways: 605 km
Ports: 1 major (Banjul)
Civil air: no major transport aircraft
Airfields: 1 usable with permanent-surface runway
1,220-2,489 m; 1 seaplane station (non-operational)
Telecommunications: adequate network of radio-relay;
2,500 telephones; 60,500 radio receivers; 1 AM station, 1 FM
station, and no TV station; 1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 127,000; 63,000 fit for
military service
GERMAN DEMOCRATIC REPUBLIC
LAND
108,262 km?; 48% arable, 15% meadows and pasture, 27%
forested, 15% other
Land boundaries: 2,309 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 901 km (including islands)
North Sea
“Baltic Sea
(See reference map iV}
Railroads: 14,298 km; 13,963 km standard gage (1.435
m), 335 km meter (1.00 m) or other narrow gage, 2,850 km
double track standard gage (1.485 m); 1,454 km overhead
electrified (1975)
Highways: 47,573 km classified highways; 12,978 km
state highways including 1,561 km autobahn; 34,595 km
district roads; additionally about 80,000 km communal roads
(1975)
Inland waterways: 2,520 km (1977)
Freight carried: rail—289.0 million metric tons, 49.7
billion metric ton/km (1975); highway—588.2 million
metric tons, 16.7 billion metric ton/km (1975); waterway—
14.6 million metric tons, 2.4 billion metric ton/km (excl.
int’L. transit traffic) (1976)
Pipelines: crude oil, 805 km; refined products, 241 km;
natural gas 483 km
Ports: 4 major (Rostock, Wismar, Stralsund, Sassnitz), 18
minor (1977)
DEFENSE FORCES
Military Budget: for fiscal year ending 31 December
1977, est. 13.2 billion marks; about 10.8% of total budget
GERMANY, FEDERAL REPUBLIC OF
(See reference map WV)
LAND
248,640 km? (including West Berlin); 33% cultivated, 23%
meadows and pastures, 13% waste or urban, 29% forested,
2% inland water
Land boundaries: 4,232 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 1,488 km (approx. )
Railroads: 33,453 km; 29,032 km government-owned,
standard gage (1.435 m), 12,491 km double track; 9,760 kim
electrified; 4,421 km non-government owned; 3,997 km
standard gage (1.435 m); 214 km electrified; 424 km meter
gage (1.00 m); 186 km electrified
Highways: 398,720 km; 161,400 km classified, includes
153,160 km cement-concrete, bituminous, or stone block
(includes 5,792 km of autobahnen); 8,240 km gravel, crushed
stone, improved earth; in addition, 237,320 km of unclassi-
fied roads of various surface types
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CERMANY, FEDERAL REPUBLIC OF/GHANA
Inland waterways: 5,106 km of which almost 70% usable
by craft of 990 metric-ton capacity or larger
Pipelines: crude oil, 1,931 km; refined products, 1,609
km; natural gas, 95,414 km
Ports: 10 major, 1] minor
Civil air: 180 major transport aircraft (including 3 leased
out)
Airfields: 436 total, 386 usable; 208 with permanent-
surface runways; 3 with runways over 3,660 m, 33 with
runways 2,440-3,659 m, 39 with runways 1,220-2,439 m
Telecommunications: highly developed, modern tele-
communication service to all parts of the country; fully
adequate in all respects; 20.4 million telephones (31.7 per
100 popl.); 90 AM, 129 FM, and 2,350 TV stations; 6
submarine cables; satellite station with 1 Indian Ocean and 2
Atlantic Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 14,775,000; 12,378,000
fit for military service; 496,000 reach military age (18)
annually
Military budget: for fiscal year ending 31 December
1977, $13,765,957,445; about 18.6% of the central govern-
ment budget','c6abae42e602ee2080f721ba200ced26ca469335e5693804f81293ed874066c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99972ceddb336a92147c30ff546d2e95614a243d9351fcf1fca348db82ca1d8c',1978,'GI','Gibraltar','communications',206,'LAND
6.5 km?
Land boundaries: 1.6 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 12 km
- Approved For Release 2005/04/22 :
POR
GIBRALTA
Atlantic Ocean
(See reference map iV}
Railroads: none
Gibraltar pound=
Highways: 56 km, mostly paved
Ports: 1 major (Gibraltar)
Civil air: 1 major transport aircraft
Airfields: 1 permanent-surface runway, 1,220-2,439 m; 1
seaplane station
Telecommunications: international radiocommunication
facilities; automatic telephone system servidng 8,250 tele-
phones (26.0 per 100 popl); 1 AM, 1 FM, and 2 TV stations;
3 submarine telegraph cables
DEFENSE FORCES
Military manpower: males 15-49, about 6,000; about
3,000 fit for military service
Defense is responsbility of United Kingdom
GILBERT ISLANDS
NOTE: On October 1, 1975, by Constitutional Order, the
Ellice Islands were formally separated from the British
colony of Gilbert and Ellice Islands, thus forming the new
colony of Tuvalu. The remaining islands in the former
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
uniten
‘sige ‘STAT
Pacific Ocean EATER,
: GILBERT
*) ISLANDS
a
“3 FUVALU
(See reference map Vit)
Gilbert and Ellice Islands Colony were renamed the Gilbert
Islands.
The islands that comprise the Gilbert Islands Colony are
the Gilbert Islands; Fanning Atoll and Washington Island in
the Line Islands; Ocean Island; and those islands claimed by
the United States: Caroline, Christmas, Flint, Malden,
Starbuck, and Vostok in the Line Islands; and Birnie,
Gardner, Hull, McKean, Phoenix, and Sydney in the
Phoenix Islands.
LAND
About 684 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 1,143 km
Railroads: none
Highways: 483 km of motorable roads
Inland waterways: small network of canals, totaling 5
km, in Northern Line Islands
Ports: 1 minor
Civil air: no major transport aircraft
Telecommunications: 1 AM broadcast station; 5,000 radio
receivers, no TV sets, and 250 telephones; connected with
Lisbon, Portugal, via cable broadcasts
\\ fe}
Rabat
4','85963d20b40538f2b665747b3d57b14730178c0987e43742679b96eee2e244a5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f113289b6181956028a3e165f3e077a23b0f7b00a95fe5252f35a3bb4eed70f',1978,'GR','Greece','communications',210,'{See reference map (¥}
LAND
132,608 km?; 29% arable and land under permanent
crops, 40% meadows and pastures, 20% forested. 11%
wasteland, urban, other
Land boundaries: 1,191 km
WATER
Limits of territorial waters (claimed): 6 nm
Coastline: 13,676 km
Railroads: 2,607 km; 1,569 km standard gage (1.435 m) of
which 36 km electrified and 100 km double track, 960 km
meter gage (1.000 m), 29 km narrow gage (0.600 m), 22 km
narrow gage (0.750 m); all government-owned
Highways: 36,714 km; 18,223 km paved, 12,451 km
crushed stone and gravel, 5,062 km improved earth, 978 km
unimproved earth
Approved For Release 2005/04/22 :
Inland waterways: system consists of 3 coastal canals and
3 unconnected rivers which provide navigable length of just
less than 80 km
Pipelines: crude oil, 26 km, refined products, 547 km
Ports: 17 major, 37 minor
Airfields: 68 total, 63 usable; 46 with permanent-surface
runways; 17 with runways 9,440-3,659 m, 23 with runways
1,220-2,4389 m
Civil air: 32 major transport aircraft
Telecommunications: adequate modern networks reach
all areas on mainland and islands; 2.18 million telephones
(22.1 per 100 popl.); 31 AM, 18 FM, and 34 TV stations; 4
coaxial submarine cables; 1 satellite station with 1 Atlantic
Ocean antenna and | Indian Ocean antenna
DEFENSE FORCES
Military manpower: males 15-49, 2,266,000; 1,737,000 fit
for military service; about 76,000 reach military age (21)
annually
Military budget: est. for fiscal year ending 31 December
1977, $1.35 billion; about 20.2% of central government
budget','74b2e43993b8704a8ec08758606cbfe90b52dc8cf2e3c9d33b3ef62ed932c52a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea98a23460997c400b20ac919b007ad23df40e183b915bc1421e1d49066edb36',1978,'GL','Greenland','communications',214,'Arctic Ocean ~
} & US.S.RF
§
‘4 <
orwegian
ea
; SHEEALAN :
., oe S
i
Te aah
Atlantic Ocean
(See reference map 4)
LAND
2,175,600 km?; less than 1% arable (of which only a
fraction cultivated), 84% permanent ice and snow, 15%
other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 44,087 km (approx., includes minor islands)
Railroads: none
Highways: none
Ports: 9 major, 23 minor
Civil air: 2 major transport aircraft (registered in
Denmark)
Airfields: 11 total, 6 usable; 3 with permanent-surface
runways, 3 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m; 7 seaplane stations
Telecommunications;: adequate domestic and interna-
tional service provided by cables and radio relay; 9,000
telephones (17.0 per 100 popl.); 5 AM, 6 FM, and 2 TV
stations; 2 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, included with Den-
mark','e10c452c357975f2693993d13078ad79013ab9bb844aeed843edd011808aef97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('786febeef0639c6e4a33a10289b25b5d57fa5b553b76d1d8dc110f6624ff3454',1978,'GD','Grenada','communications',218,'Atlantic
Ocean
(See reference map il}
LAND
344 km® (Grenada and southern Grenadines); 44%
cultivated, 4% pastures, 12% forests, 17% unused but
potentially productive, 23% built on, wasteland, other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 121 km
Railroads: none
Highways: 1,000 km; 600 km paved, 300 km otherwise
improved; 100 km unimproved
Ports: 1 major (St. Georges), 1 minor
Civil air: no major transport aircraft
Airfields: 3 total, 2 usable; 2 with permanent-surface
runways, 1 with runway 1,220-2,489 m
Telecommunications: automatic, islandwide telephone
system with 5,250 telephones (4.5 per 100 popl.); VHF and
UHF links to Trinidad and Carriacou; 3 AM stations
Trinidad aad Tabago
* Caracas
, Georgetown
Paramaribo
_ uy ana Va
, 7 Cayenne
Surinam
Frenth Guiana
[Pry
VYenezuela','75e767f3f9519e29624af92ff61595f4c3bce8ecb3c567b4fa1db432862e21fc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d06c445203da826a992099ba77f7cce4f02981079c1a0dc882b301983153d87',1978,'GP','Guadeloupe','communications',222,'“DOMINICAN
PUERTO
RICO
»
8
Caribbean Sea
caee
{See reference map tt}
LAND
1,779 km*; 24% cropland, 9% pasture, 4% potential
cropland, 16% forest, 47% wasteland, built on; area consists
of two islands
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 306 km
Railroads: privately owned, narrow-gage plantation lines
Highways: 2,300 km; 1,500 km paved, 800 km gravel and
earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 2 major transport aircraft
Airfields: 8 total, 8 usable, 8 with permanent-surface
runways; | with runway 2,440-3,659 m; 2 seaplane stations
Telecommunications: domestic facilities inadequate;
24,600 telephones (6.7 per 100 popl.); interisland VHF radio
links; 2 AM and 3 TV transmitters','b97b9438eb66e33baeef03f6b30c2f91ad506c2e7ef19137c5ec7d6163724926','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d336d9bd26f64b75fe39db4c8bb59474719b291cc79ac39844658cd282e9c5e',1978,'GT','Guatemala','communications',226,'Gulf of
Mexico o
Caribbean
Sea
EL
SALVADOR
Pacific Ocean
(See reference map it)
LAND
108,880 km?; 14% cultivated, 10% pasture, 57% forest,
19% other
Land boundaries: 1,625 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 400 km','de8f25c151bc0b72d150866cfcf7e8db7c2914d95c98759423d9de8b5d6388d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33d20f74809640a87428a266d0b78e3ad9c170bd064c6c46b63e209b33935554',1978,'GW','Guinea-Bissau','communications',230,'(formerly Portuguese Guinea)
ee tlentic Ocean
{See reference mep Vi}
LAND
36,260 km? (includes Bijagos archipelago)
Land boundaries: 740 km
WATER
Limits of territorial waters (claimed): 150 nm (fishing
200 nm) ;
Coastline: 274 km
Railroads: none
Highways: approx. 3,218 km (418 km_ bituminous,
remainder earth)
Inland waterways: 1,600 km
Ports: 1 major (Bissau), 2 minor
Civil air: no major transport aircraft
87
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GUINEA-BISSAU/GUYANA
Airfields: 60 total, 59 usable; 5 with permanent-surface
runways; 8 with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: limited system of open-wire lines
and radiocommunication stations; 2,700 telephones (0.5 per
100 popl.); 1 AM, 1 FM and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 122,000; 70,000 fit for
military service','57c91a846d66e6fc80ab2b349bf92ae334d316a411d651b843cf1fccd39bbfe8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0334079d8582687a2decf36614c59e70e0bf306b269e2ece5046a22f3f382bf3',1978,'HT','Haiti','communications',234,'LAND
27,713 km?; 31% cultivated, 18% rough pastures, 7%
forested, 44% unproductive
Land boundary: 361 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 1,771 km
Railroads: 80 km narrow gage (0.760 m), single-track,
privately owned industrial line; 8 km dual-gage 0.760- to
1.065-meter gage, government line, dismantled
Highways: 3,200 km; 600 km paved, 950 km otherwise
improved, 1,650 km unimproved
Inland waterways: negligible; about 100 km navigable
Ports: 2 major (Port-au-Prince, Cap Haitian), 12 minor
Civil air: 6 major transport aircraft
Airfields: 14 total, 13 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 5 with runways
1,220-2,439 m; 2 seaplane stations
Telecommunications: all domestic facilities inadequate,
international facilities slightly better; telephone expansion
program underway; 11,000 telephones (0.23 per 100 popl.);
32 AM, 5 FM, and 1 TV station; 1 Atlantic Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 1,180,000; 628,000 fit
for military service; about 51,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1976, $10.9 million; about 13.6% of operational budget','ebd9b38b935704efdbc12551ef5972bfc180c9042ea1df85aa0c1e2041e102c3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d18c7575e596e94739c6000328145782edbb6985483b06b3b71baa1298b676f',1978,'HN','Honduras','communications',238,'Caribbean
Pacific Qcean
(See reference map it}
LAND
112,150 km*; 27% forested, 30% pasture, 36% waste and
built-up, 7% cropland
Land boundaries: 1,530 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 820 km
Railroads: 574 km; 325 km 1.067-meter gage, 249 km
0.914-meter gage
Highways: 8,700 km; 1,150 km_ bituminous surfaced,
2,500 km gravel surfaced or improved earth, 5,050 km
unimproved earth
Inland waterways: 1,200 km navigable by small craft
Ports: 3 major (Puerto Cortes, La Ceiba, Tela), 9 minor
Civil air: 23 major transport aircraft
Airfields: 245 total, 224 usable; 4 with permanent-surface
runways; 1 with runway 2,440-3,659 m; 9 with runways
1,220-2,439 m; 2 seaplane stations
Telecommunications: improved, but still inadequate;
connection into Central American microwave net; 19,500
telephones (0.7 per 100 popl.); 97 AM, 12 FM, and 5 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 680,000; 401,000 fit for
military service; about 31,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1977, $25.3 million; about 8.1% of central
government budget (includes the armed forces and other','f55f25e23b2b6e442b64546109158f5a858ed7ab3c93c0fbcd241153af98ee97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0c6adeb3610005149f6867de06d826065108f1a2f230e87f2c0fcf87b98bb3a',1978,'HU','Hungary','communications',244,'(See reference map IV}
LAND
92,981 km?; 60% arable, 14% other agricultural, 16%
forested, 10% other
Land boundaries: 2,245 km
Railroads: 8,392 km; 7,879 km standard gage (1.435 m),
478 km narrow gage (mostly 0.760 m), 35 km broad gage
(1.524 m), 1,159 km double track, 1,303 km electrified;
government owned (1975)
Highways: 99,595 km; 32,583 km paved; 10,408 km
gravel, crushed stone, stabilized earth; 56,604 km unim-
proved earth (1975)
Inland waterways: 1,688 km (1977)
Pipelines: crude oil, 1,287 km; refined products, 290 km;
natural gas, 2,896 km
Freight carried: rail—131.7 million metric tons, 23.5
billion metric ton/km (1975); highway—479.4_ million
metric tons, 8.1 billion metric ton/km (1975); waterway—
est. 14.2 million metric tons, 8.3 billion metric ton/km incl.
int’l. transit traffic (1975)
River ports: 2 principal (Budapest, Dunaujvaros); no
maritime ports; outlets are Rostock, GDR, and Gdansk,
Gdynia, and Szczecin in Poland
DEFENSE FORCES
Military manpower: males 15-49, 2,650,000; 2,314,000 fit
for military service; about 70,000 reach military age (18)
annually
Military budget: for fiscal year ending 31 December
1977, est. 15.8 billion forints; about 4.4% of total budget','3a90a1f0f8dff90298c26cd0b965ea4ee87f4e9a5d0d43422c9e0546f7670e83','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f4af6a68f5db8076e708f326b117b830f343dce5586d69f9ce904feef00b8ca',1978,'IS','Iceland','communications',248,'LAND
102,952 km*; arable negligible, 22% meadows and
pastures, forested negligible, 78% other
: ee Jan Mayen
Seon cee * Island
a er Greenland 7
4 Sea Norwegian
, seo ICELAND aid
ae
Atlantic
Qcean
{See reference map IVj
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm)
Coastline: 4,988 km
Railroads: none
Highways: 11,137 km; 7,959 km crushed stone (including
lava) and gravel, 2,276 improved, 757 unimproved earth,
145 km concrete or paved
Ports: 4 major (Akureyri, Hafnarfjordhur, Reykjavik,
Seydhisfjordhur), and about 50 minor
Civil air: 24 major transport aircraft (including 7 leased
in)
Airfields: 126 total, 101 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 10 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: adequate domestic service, wire
and radio communication system; 93,400 telephones (41.7
per 100 popl.); 17 AM, 14 FM, and 80 TV stations; 2 coaxial
submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 54,000; 49,000 fit for
military service (Iceland has no conscription or compulsory
military service)
(See reference map Vit)
LAND
3,186,500 km? (includes Indian part of Jammu-Kashmir,
Sikkim, Goa, Damao and Diu); 50% arable, 5% permanent
meadows and pastures, 20% desert, waste, or urban, 22%
forested, 3% inland water
Land boundaries: 12,700 km?
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; additional 100 nm is fisheries conservation zone,
December 1968; archipelago concept baselines); 200 nm
exclusive economic zone
Coastline: 7,000 km (includes offshore islands)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','ebc7df79a9fc2750382232bd9c6df6030720e041f0bce8da92405a6032a90850','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3384b0b174cf80247cf532c980165147302dc529c2da53887df5497c4f0a784c',1978,'IN','India','communications',255,'Railroads: 61,313 km; 25,550 km meter gage (1.00 m),
30,041 km broad gage (1.676 m), 4,476 km narrow gage
(0.762 m and 0.610 m), government owned; 46 km meter
gage (1.00 m), 855 km broad gage (1.676 m), 345 km narrow
gage (0.762 m and 0.610 m), privately owned; 12,304 km
double track; 10,160 km electrified
oe Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
INDIA/INDONESIA
Highways: 1,327,450 km; 415,250 km paved, 190,600 km
gravel or crushed stone, 304,900 km improved earth,
416,700 km unimproved earth
Inland waterways: 14,300 km; 2,575 km navigable by
river steamers
Pipelines: crude oil, 1,432 km; refined products, 2,020
km; natural gas, 359 km
Ports: 8 major, 80 minor
Civil air: 93 major transport aircraft
Airfields: 359 total, 344 usable; 189 with permanent-
surface runways; 2 with runways over 3,660 m, 54 with
runways 2,440-3,659 m, 123 with runways 1,220-2,439 m
Telecommunications: fair domestic telephone service
where available, good internal microwave links; telegraph
facilities widespread; AM broadcast adequate; international
radio communications adequate; 1,816,900 telephones;
14,100,000 radio and 162,000 TV sets; about 172 AM stations
at 80 locations, 7 TV stations, 2 earth satellite stations;
submarine cables extend to Malaysia, Sri Lanka, and Aden
DEFENSE FORCES
Military manpower: males 15-49, 153,307,000,
90,220,000 fit for military service; about 7,132,000 reach
military age (17) annually
Military budget: for fiscal year ending 31 March 1978,
$3.4 billion; 19.5 of central government budget','8834558c468f36e76b8642da4e1c55515d4e6ec98bec794aad4326ed50def5b7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35a3a8f2487a9f3961765836963ab33ef92ecc2013e4fbf4d1425eb06b0cd9d1',1978,'IQ','Iraq','communications',256,'Caspian
Sea
Baghdad,
(See reference map V}
LAND
445,480 km?; 18% cultivated, 68% desert, waste, or urban,
10% seasonal and other grazing land, 4% forest and
woodland
Land boundaries: 3,668 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 58 km
Railroads: 1,700 km; 1,123 km standard gage (1.435 m),
577 km meter gage (1.00 m); 16 km meter gage double track
Highways: 20,791 km; 6,490 km paved, 4,645 km
improved earth, 9,656 km unimproved earth
Inland waterways: 1,015 km; Shatt al Arab navigable by
maritime traffic for about 104 km; Tigris and Euphrates
navigable by shallow-draft steamers
1 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
IRAQ/IRELAND
Ports: 3 major (Basra, Umm Qasr, Al Faw)
Pipelines: crude oil, 3,821 km; 585 km refined products;
1,360 km natural gas
Civil air: 26 major transport aircraft
Airfields: 76 total, 67 usable; 24 with permanent-surface
runways; 40 with runways 2,440-3,659 m, 16 with runways
1,220-2,439 m
Telecommunications: network consists of open-wire lines,
radio-relay links, and radiocommunication stations; 184,900
telephones (1.7 per 100 popl.); 9 AM, no FM and 10 TV
stations; 1 satellite station with Atlantic Ocean and Indian
Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 2,642,000; 1,478,000 fit
for military service; about 118,000 reach military age (18)
annually
Military budget: est. for fiscal year ending 31 December
1977, $1,660,000,000; 12% of central government budget
and 22.5% of est. GNP; no service allocation is available
(dollar value converted from Iraqi dinars at official rate of
0.2961 dinars=US$1)
Baghdad, iran
Esfahan®','70e7ecdea542ff72405fe82b55d46e6df1f114f10c1f1bcc01f3386b4fb5c7fd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1064513de19904f86c4b9b6062fb98784c45e237dd12ddcdbc7f0cd680ea83f',1978,'IE','Ireland','communications',260,'Atlantic
(See roference map WwW)
LAND
68,894 km’; 17% arable, 51% meadows and pastures, 3%
forested, 2% inland water, 27% waste and urban
Land boundaries: 360 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 1,448 km
Railroads: 2,189 km 1.600-meter gage, government-
owned
Highways: 88,302 km; 78,616 km surfaced, 9.686 km
earth
Inland waterways: approximately 1,000 km
Ports: 6 major, 38 minor
Civil air: 30 major transport aircraft (including 7 leased
out)
Airfields: 38 total, 38 usable; 8 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: small, modern system; all cities
interconnected for telephone and telegraph service; 444,000
telephones (14.1 per 100 popl.); 6 AM, 7 FM, and 28 TV
stations; 4 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 739,000; 579,000 fit for
military service; about 29,000 reach military age (17)
annually
Military budget: for fiscal year ending 31 March 1977,
$144.8 million; about 5.7% of the central government budget','ceba016d403c6b154d6663a6f23d349bf725555165b0e12f5c4bc29136f40ce3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd8779d289822063f56110f947d985deaad422a5a2ce401bd2a6e693147337f0',1978,'IL','Israel','communications',264,'g
Mediterranean
(See reference mag V)
NOTE: The Arab territories occupied since the 1967 war
are not included in the data below unless so indicated.
LAND
20,720 km? (excluding about 64,750 km? of occupied
territory in Jordan, Egypt, and Syria); 20% cultivated, 40%
pastureland and meadows, 4% forested, 4% desert, waste, or
urban, 3% inland water, 29% unsurveyed (mostly desert)
Land boundaries: 1,036 km (prior to 1967 war); including
occupied areas, approximately 1,050 km (1977)
WATER
Limits of territorial waters (claimed); 6 nm
Coastline: 273 km (prior to 1967 war); including occupied
areas, approximately 848 km (1977)
Railroads: 767 km standard gage (1.435 m)
Highways: 4,348 km paved, 7 km gravel/crushed stone,
remainder unknown
Pipelines: crude oil, 708 km; refined products, 290 km;
natural gas, 89 km
Ports: 3 major (Haifa, Ashdod, Flat), 5 minor
Airfields: 55 total, 46 usable; 20 with permanent-surface
runways; 5 with runways 9,440-3,659 m, 7 with runways
1,220-2,489 m
Civil air: 84 major transport aircraft (including 2 leased
in)
Telecommunications: second to Iran, the most modern
and highly developed in the Middle East; 796,348 telephones
(22.8 per 100 popl.); 33 TV, 14 AM, and 10 FM stations; 1
submarine cable; 1 Atlantic Ocean satellite station
103
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ISRAEL/ITALY
DEFENSE FORCES
Military manpower: Jewish males 15-49, 760,000:
655,000 fit for military service; average number of Jews
teaching military age (18) annually—30,000 males, 30,000
females; both sexes liable for military service
Military budget: for fiscal year ending 31 March 1978,
$4,501,000,000; about 34% of central government budget
(See reference map IV)
LAND
301,217 km?; 50% cultivated, 17% meadow and pasture,
21% forest, 3% unused but potentially productive, 9% waste
or urban
Land boundaries: 1,702 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4,996 km
Railroads: 20,690 km; 15,970 km government-owned
standard gage (1.485 m), 7,850 km electrified; 4,720 km
non-government owned, 2,507 km standard gage (1.435 m),
1,270 km electrified; 2,213 km narrow gage (0.950 m), 517
km electrified
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Highways: 286,400 km; autostrade 4,800 km, state
highways 41,200 km, provincial highways 91,200 km,
communal highways 149,200 km; 254,400 km concrete,
bituminous, or stone block, 24,800 km gravel and crushed
stone, 7,200 km earth
Inland waterways: 2,500 km navigable routes
Pipelines: crude oil, 1,770 km; refined products, 2,179
km; natural gas, 13,079 km
Ports: 16 major, 22 significant minor
Civil air: 129 major transport aircraft
Airfields: 149 total, 149 usable; 84 with permanent-
surface runways; 2 with runways over 3,660 m, 29 with
runways 2,440-3,659 m, 42 with runways 1,220-2,439 m; 11
seaplane stations
Telecommunications: well engineered, well constructed,
and efficiently operated; 14.8 million telephones (25.9 per
100 popl.); 102 AM, 658 FM, and 892 TV stations; 12 coaxial
submarine cables; 4 communication satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 13,986,000; 11,719,000
fit for military service; 442,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1977, $4.05 billion; about 7.7% of proposed
central government budget
IVORY COAST','1b42a6e0b241a8344eb2587db83f734430d3a5892c90a51d305a2ba7f01d1ee1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2952e1b69610b3dc7feb68f9dcf0afa6beddb2018ea56e34bceae1aea2c7282b',1978,'JP','Japan','communications',268,'LAND
370,370 km?; 16% arable and cultivated, 3% grassland,
12% urban and waste, 69% forested
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 12,075 km Japan; 1,610 km Ryukyus
Railroads: 28,912 km; 1,077 km standard gage (1.435 m),
27,835 km predominantly narrow gage (1.067 m), 6,195 km
double track, 7,376 km or 26% of total route length
electrified; 73% government-owned
Highways: 1,066,028 km (1976); 336,733 km paved, most
of remainder gravel or crushed stone
Inland waterways: approx. 1,770 km; seagoing craft ply
all coastal “inland seas”
Pipelines: crude oil, 109 km; natural gas, 1,847 km
Ports: 53 major, over 2,000 minor
Civil air: 230 major transport aircraft (includes 2 leased)
Airfields: 180 total, 175 usable; 117 with permanent-
surface runways; 2 with runways over 3,660 m; 22 with
runways 2,440-8,659 m, 44 with runways 1,220-2,439 m, 5
seaplane stations
DEFENSE FORCES
Military manpower: males 15-49, 31,668,000; 26,654,000
fit for military service; about 815,000 reach military age (18)
annually
Supply: defense industry potential is large, with capability
of producing the most sophisticated equipment; manufac-
tured equipment includes small arms artillery, armored
vehicles, and other types of ground forces materiel, aircraft
(jet and prop), naval vessels (submarines, guided missile and
other destroyers, patrol craft, mine warfare ships, and other
minor craft including amphibious, auxiliaries, service craft,
and small support ships), small amounts of all types of army
materiel
Military budget: for fiscal year ending 31 March 1979,
$7.0 billion proposed; about 6% of total budget
Railroads: 1,543 km; 1,281 km standard gage, 262 km
narrow gage (1.050 m)
Highways: 11,500 km; 6,930 km paved, 1,300 km gravel
or crushed stone, 2,470 km improved earth, 800 km
unimproved earth
Inland waterways: 672 km; of little importance
Pipelines: 1,304 km crude oil; 515 km refined products
Ports: 3 major (Tartus, Latakia, Baniyas), 2 minor
Civil air: 13 major transport aircraft
Airfields: 40 total, 34 usable; 25 with permanent-surface
runways; 22 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: good international and domestic
service; 143,300 telephones (1.8 per 100 popl.); 9 AM, no FM
and 5 TV stations; 1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,824,000; 1,021,000 fit
for military service; about 96,000 reach military age (19)
annually
Military budget: for fiscal year ending 31 December
1977, $995,000,000, 23% of central government budget
TANZANIA
(See reference map Vi}
LAND
939,652 km? (including islands of Zanzibar and Pemba,
2,642 km?); 6% inland water, 15% cultivated, 31% grassland,
ae Approved For Release 2005/04/22
48% bush forest, woodland; on mainland, 60% arable, of
which 40% cultivated on islands of Zanzibar and Pemba
Land boundaries: 3,883 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 1,424 km (this includes 113 km Mafia Island;
177 km Pemba Island; and 212 km Zanzibar)
Railroads: 3,555 km; 960 km 1.067-meter gage; 2,595 km
meter gage (1.00 m), 6.4 km double track; 962 km Tan-Zam
Railroad 1.067-meter gage in Tanzania
Highways: total 17,010 km, 2,581 km paved; 5,529 km
gravel or crushed stone; 8,900 km improved earth
Pipelines: 982 km crude oil
Inland waterways: 1,168 km of navigable streams; several
thousand km navigable on Lakes Tanganyika, Victoria, and','d1d4c6ed3cf9a1502853b8d15cc71b469f3ff20c34d57f41d1dfdff56d62fa2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e45b1a114d70e5b00e903951a773e81dba24071048088a5c9d14a115861158f6',1978,'JO','Jordan','communications',272,'Re ene LEBANO
(Seo reference map V)
NOTE: The war between Israel and the Arab states in
June 1967 ended with Israel in control of West Jordan.
Although approximately 930,000 persons resided in this area
prior to the start of the war, fewer than 750,000 of them
remain there under the Israeli occupation, the remainder
having fled to East Jordan. Over 14,000 of those who fled
were repatriated in August 1967, but their return has been
more than offset by other Arabs who have crossed and are
continuing to cross from West to East Jordan. These and
certain other effects of the 1967 Arab-Israeli war are not
included in the data below.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
LAND
96,089 km? (including about 5,439 km? occupied by
Israel); 11% agricultural, 88% desert, waste, or urban, 1%
forested
Land boundaries: 1,770 km (1967, 1,668 km excluding
occupied areas)
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 26 km
Railroads: 817 km 1.050-meter gage, single track
Highways: 6,677 km; paved, 2,413 km improved earth;
others unknown
Pipelines: crude oil, 209 km
Ports: 1 major (Aqaba)
Civil air: 12 major transport aircraft (including 3 leased
in)
Airfields: 25 total, 16 usable; 13 with permanent-surface
runways; 2 with runways over 3,660 m, 10 with runways
2,440-3,659 m, 1 with runway 1,220-2,439 m
Telecommunications: adequate telecommunication sys-
tem for the needs of the country; 40,500 telephones (1.4 per
100 popl.); 5 AM, no FM and 6 TV stations; 1 Atlantic Ocean
satellite station
110 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
JORDAN/KENYA
DEFENSE FORCES
Military manpower: males 15-49, 624,000; 444,000 fit for
military service; average number currently reaching mili-
tary age (18) annually 32,000
Military budget: for fiscal year ending 31 December
1977, $203 million; 20% of central government budget','86339b90f24dd85faf3af279ebc4b7b2d6c3530ed76804b6d99431922efa659c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('825c6ad5204db2410998d30c8936bfe4a0f159438ebe5975d00141d2751dc52a',1978,'KE','Kenya','communications',276,'x Nairobi
{See reference map VI)
LAND
582,750 km*; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland adequate for
grazing (1971)
Land boundaries: 3,368 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 536 km
Railroads: 2,040 km meter gage (1.00 m)
Highways: 50,290 km; 3,750 km paved, 12,160 km gravel
and/or earth; 26,880 km improved earth and 7,500 km
unimproved earth
Inland waterways: part of Lake Victoria and Lake
Rudolph systems are within boundaries of Kenya
Ports: 1 major (Mombasa), 3 minor
Civil air: 11 major transport aircraft (including 3 leased
in)
Airfields: 237 total, 220 usable; 7 with permanent-surface
runways; 1 with runway over 3,660 m, 3 with runways
2,440-3,659 m, 41 with runways 1,220-2,439 m
Telecommunicaiions: in top group of African systems;
consists of radio-relay links, open-wire lines, and radiocom-
munication stations; principal center Nairobi, secondary
centers Mombasa and Nakuru; 122,700 telephones (0.9 per
100 popl.); 4 AM, 2 FM, and 5 TV stations; 1 Indian Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,116,000; 1,913,000 fit
for military service; no conscription
Military budget: for fiscal year ending 30 June 1978,
$79,968,647; about 5.8% of central government budget
KOREA, NORTH
Fast
China Sea
(Sea reference map Vil}
LAND
121,730 km?; 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban
Land boundaries: 1,675 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 2,495 km
Railroads: none
175
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
RWANDA/ST. CHRISTOPHER-NEVIS-ANGUILLA
Highways: 9,120 km; 120 km paved, 3,000 km gravel
and/or improved earth, 6,000 km unimproved
Inland waterways: Lake Kivu navigable by barges and
native craft
Civil air: 1 major transport aircraft
Airfields: 10 total, 9 usable; 2 with permanent-surface
runways, 2 with runways 1,220-2,439 m, 1 with runway
2,440-3,659 m
Telecommunications: low-capacity radio-relay system
centered on Kigali; 3,500 telephones (0.1 per 100 popl.); 2
AM, 1 FM, no TV stations; Symphonie COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 998,000; 503,000 fit for
military service; no conscription; 46,000 reach military age
(18) annually
Military budget: for fiscal year ending 31 December
1976, $11,172,295; 19% of central government budget
ST. CHRISTOPHER-NEVIS-ANGUILLA
Atlantic Ocean
@ ANGUILLA
G>-"
ST. CHRISTOPHER %»
NEVIS * oP:
Caribbean Sea
(See reference map 1}
LAND
389 km?; 40% arable, 10% pasture, 17% forest, 33%
wasteland and_ built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 193 km
Railroads: 57 km, narrow gage (0.760 m) on St. Kitts for
sugar cane
Highways: 300 km; 100 km paved, 150 km otherwise
improved, 50 km unimproved earth
Ports: 3 minor (1 on each island)
Civil air; 1 major transport aircraft
Airfields: 3 total, 3 usable; 3 with permanent-surface
runways; 1 with runway 1,220-2,439 m; 1 seaplane station
Telecommunications: good interisland VHF/UHF radio
connections and international link via Antigua; about 1,900
telephones (3.5 per 100 popl.); 3 AM and 5 TV stations
ST. LUCIA
Atlantic Ocean
= =
Caribbean Sea
(See reference man tli
LAND
616 km?; 50% arable, 3% pasture, 19% forest, 5% unused
but potentially productive, 23% wasteland and built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 158 km
Railroads: none
Highways: 750 km; 450 km paved; 300 km otherwise
improved
Ports: 1 major (Castries), 1 minor
177
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ST. LUCIA/ST. VINCENT/SAN MARINO
Civil air: 1 major transport aircraft
Airfields: 3 total; 3 usable, 2 with permanent-surface
runways, 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m; 2 seaplane stations
Telecommunications: fully automatic telephone system
with 6,980 telephones (5.7 per 100 popl.); direct radio-relay
link with Martinique; interisland tropospheric links to
Barbados and Antigua; 3 AM stations, 1 TV station
ST. VINCENT
Atlantic Ocean
ah
(See reference map t/)
LAND
389 km? (including northern Grenadines); 50% arable, 3%
pasture, 44% forest, 3% wasteland and _ built-on
WATER
Limits of territorial waters (claimed); 3 nm
Coastline: 84 km
Railroads: none
Highways: 550 km; 200 km paved: 500 km otherwise
improved; 150 km unimproved earth
Ports: | major, 1 minor
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface
runways, | with runway 1,220-2,439 m
Telecommunications: islandwide fully automatic tele-
phone system with 5,130 sets (4.8 per 100 popl.); VHF/UHF
interisland links to Barbados and the Grenadines; 10,000
radio and 600 TV receivers; 2 AM _ stations
Nairobi
Vict
j Bujumbura Burundi an
wa
Camoros
Moroni
| 4 An
Madagascar,
Ma
Ci
Mozambique /
/
Indian
Ocean
iscio','9d8a7ebabb4c4ee2abfb11f1ff057b789d45347cb5f987f6ab0fd5a5eaa6bab8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5eeeac0e1fc1b466f1c7fae67d7f9d3aa7557ac7c7c62796c355477ccf0bf29',1978,'KW','Kuwait','communications',280,'* Kuwait
{See reference map V)
LAND
16,058 km? (excluding neutral zone but including islands);
insignificant amount forested; nearly all desert, waste, or
urban
Land boundaries: 459 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 499 km
Railroads: none
Highways: 2,494 km; 2,195 km bituminous; 250 km earth,
sand, light gravel
Pipelines: crude oil, 877 km; refined products, 40 km;
natural gas, 121 km
Ports: 3 major (Ash Shuwaikh, Ash Shuaybah, Mina al
Ahmadi), 4 minor
Civil air: 15 major transport aircraft (including 1 leased
in)
Airfields: 11 total, 6 usable; 3 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: excellent international and ade-
quate domestic telecommunication facilities; 129,000 tele-
phones (12.5 per 100 popl.); 3 AM, 1 FM and 3 TV stations;
1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, about 311,000; about
179,000 fit for military service
Coast Guard: 22 patrol boats, 8 port security boats, 3
utility landing craft
Military budget: for fiscal year ending 31 March 1976,
$222,428,950; 8% of central government budget
LAOS
LAND
236,804 km’; 8% agricultural, 60% forests, 32% urban,
waste, and other; except in very limited areas, soil is very
poor; most of forested area is not exploitable
Land boundaries: 5,053 km
Highways: about 18,000 km; 1,300 km bituminous or
bituminous treated, 5,900 km gravel, crushed stone, or
improved earth; 10,800 km unimproved earth and often
impassable during rainy season mid-May to mid-September
Inland waterways: about 4,587 km, primarily Mekong
and tributaries; 2,897 additional kilometers are sectionally
navigable by craft drawing less than 0.5 m
116 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
LAOS/LEBANON
Ports (river): 5 major, 4 minor
Airfields: 87 total, 78 usable; 9 with permanent-surface
runways; Ll with runways 1,220-2,439 m, 1 with runway
2,440-3,659 m
DEFENSE FORCES
Military manpower: males 15-49, 826,000; 441,000 fit for
military service; average number currently reaching usual
military age (18) annually, 37,000; no conscription age
specified
Lao People’s Liberation Army (LPLA): the LPLA
consists of an army with naval and aviation elements
Military budget: unknown','43b10b61f01c415610a57024b19c0b12d8ebfe207bfa003361ee2126b6c97055','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31b362937ef2751e7b6128266182de9357e64dd3d68ee638e96edcd6229fe1d9',1978,'LB','Lebanon','communications',284,'(Sea reference mep V}
LAND
10,360 km?; 27% agricultural land, 64% desert, waste, or
urban, 9% forested
Land boundaries: 531 km
WATER
Limits of territorial waters (claimed): no specific claims
(fishing, 6 nm)
Coastline: 225 km
Railroads: 383 km; 296 km standard gage (1.435 m), 82
km 1.050-meter gage; all single track
Highways: 7,370 km; 6,270 km paved, 450 km gravel and
crushed stone, 650 km improved earth
Pipelines: crude oil, 72 km
Ports: 3 major (Beirut, Tripoli, Sayda), 5 minor
Civil air: 31 major transport aircraft (including 13 leased
out)
Airfields: 8 total, 6 usable; 83 with permanent-surface
runways; 3 with runways 2,440-3,659 m; 2 with runways
1,220-2,439 m
Telecommunications: excellent international telecom-
munication facilities include satellite ground station; good
domestic telephone and telegraph service; 227,000 tele-
phones (9.1 per 100 popl.); 2 FM, 7 AM, and 7 TV stations; 1
submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 584,000; 357,000 fit for
military service; average of about 27,000 reach military age
(18) annually
Military budget: for fiscal year ending 31 December
1977, $649,000,000; 17% of central government budget','b6ffbfaf2841192b09158dab265291a9d73c3ff67d883152a362ec0bb03b6b0b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38b8a9e74edf92d78cc4696daf668d8fdc5d3b0198a15ba203eb4a763a8313f0',1978,'LS','Lesotho','communications',288,'Indian Ocean
(See raference map Vi}
LAND
80,303 km?; 15% cultivable; largely mountainous
Land boundaries: 805 km
Railroads: 1.6 km; owned, operated, and included in the
statistics of the Republic of South Africa
Highways: approx. 3,916 km; 218 km paved; 993 km
crushed stone, gravel, or stabilized soil; 1,046 km improved,
1,659 km unimproved earth
Civil air: no major transport aircraft
Airfields: 21 total, 20 usable; 2 with runways 1,220-2,439
m, 1 with permanent surface runway
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Telecommunications: system a modest one consisting of a
few landlines, a small radio-relay system, and minor
radiocommunication stations; Maseru is the center; 3,725
telephones (0.3 per 100 popl.); 2 AM, no FM or TY stations
DEFENSE FORCES
Military manpower: males 15-49, 220,000; fit for military
service 122,000','da4f45b77e92db4807ef492278ee724e83a91bf038ec23524d09474901aabf80','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f74fa5aee70963fea1e8875ef4a856b88b0c5c5cb0d9344da8f063345b0b4e03',1978,'LR','Liberia','communications',292,'Atlantic Qcean
(See reference map VI)
LAND
111,370 km?; 20% agricultural, 30% jungle and swamps,
40% forested, 10% unclassified
Land boundaries: 1,336 km
WATER
Limits of territorial waters (claimed): 22 nm
Coastline: 579 km
Railroads: 502 km; 354 km standard gage (1.435 m), 145
km narrow gage (1.067 m); all lines single track; rail systems
owned and operated by foreign steel and financial interests
in conjunction with Liberian Government
Highways: 7,952 km; 603 km bituminous treated; 2,055
km gravel, and remainder improved and unimproved earth
Inland waterways: 370 km
Ports: 3 major (Monrovia, Buchanan, Greenville-Sino
Harbor), 4 minor
Civil air: 1 major transport aircraft
Airfields: 80 total, 78 usable; 2 with permanent-surface
Tunways; 1 with runway 2,440-3,659 m, 6 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: telephone and telegraph limited;
main center is Monrovia; 3,400 telephones (0.2 per 100
popl.); 5 AM, 1 FM, and 5 TV stations; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 364,000; 194,000 fit for
military service; no conscription
Military budget: for year ending 30 June 1978, $8.9
million; 4.8% of central government budget','304fb67e0092429bacf65a7ce53e1c16654cde8bb0e28556eaf42b1cdcd5c634','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36b22b8205abdd31abcf323d636f39500f9628429bb6198c5d3c9d920de98b1e',1978,'LY','Libya','communications',296,'LAND
1,758,610 km’; 6% agricultural, 1% forested, 93% desert,
waste, or urban
Land boundaries: 4,345 km
WATER
Limits of territorial waters (claimed): 12 nm (except for
Gulf of Sidra where sovereignty is claimed and northern
limit of jurisdiction fixed at 32°30''N. and the unilaterally
proclaimed 100 nm zone around Tripoli)
Coastline: 1,770 km
ma Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
oF
Laer 2
Mediterranean Sea fg _
(See reterence map Vi}
Railroads: none
Highways: 16,212 km; 7,712 km bituminous and bitumi-
nous treated, 8,500 km gravel, crushed stone and earth
Pipelines: crude oil 3,251 km; natural gas 282 km; refined
products 443 km (includes 217 km liquid petroleum gas)
Ports: 3 major (Tobruk, Tripoli, Benghazi), 4 minor, and 5
petroleum terminals
Civil air: 35 major transport aircraft (including 1 leased
in)
Airfields: 78 total, 77 usable; 15 with permanent-surface
runways, 1 with runway over 3,660 m, 11 with runways
2,440-3,659 m, 30 with runways 1,220-2,439 m; 2 seaplane
stations
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
LIBYA/LIECHTENSTEIN
Telecommunications: system is in top one-third of
African systems; consists of radio-relay and tropo-
spheric-scatter links, open-wire lines, and radiocommunica-
tion stations; principal centers are Tripoli and Benghazi;
49,800 telephones (1.8 per 100 popl.); 10 AM, 1 FM, and 11
TV stations; 1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 559,000; 327,000 fit for
military service; about 22,000 reach military age (17)
annually; conscription now being implemented
Military budget: for fiscal year ending 31 December
1977, $286,000,000, 4% of central government budget','27f74a3cab0ba20352c03a133bac0e734c0b986b422233d4bce87ad7a4bf455a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c30de8dc73eed339afdbb005355a9c6d1961dae28b26a7a3a5757e6cd6390103',1978,'LI','Liechtenstein','communications',300,'{See reference map IV}
LAND
168 km?
Land boundaries: 76 km
Railroads: 16.00 km, standard gage (1.435 m), electrified;
owned, operated, and included in statistics of Austrian
Federal Railways
Highways: no information on total kilometers
Civil air: 3 major transport aircraft registered in','976a4ffa4e173fe1fb0fb31a66a89c64f98b2b7dfc871817042a12ff537410ce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67769199a64086d2fac16b28cc8c5ac917a141058ad7d99dee1423fde6f30e36',1978,'CH','Switzerland','communications',304,'CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
LIECHTENSTEIN/ LUXEMBOURG
Airfields: none
Telecommunications: automatic telephone system serv-
ing about 15,900 telephones (64.0 per 100 popl.); no
broadcast facilities
DEFENSE FORCES
Defense is responsibility of Switzerland
(See reference map IV}
LAND
41,440 km*; 10% arable, 43% meadows and pastures, 20%
waste or urban, 24% forested, 3% inland water
Land boundaries: 1,884 km
Railroads: 5,098 km; 2,895 km government-owned (SBB),
2,822 km standard gage (1.435 m); 73 km narrow gage (1.00
m); 1,339 km double track, 99% electrified; 2,203 km
non-government owned, 710 km standard gage (1.485 m),
1,418 km meter-gage (1.00 m), 75 km 0.790-meter gage,
100% electrified
Highways: 60,512 km, all paved
Pipelines: 314 km crude oil; 1,046 km natural gas
Inland waterways: 65 km; Rhine River-Basel to Rhein-
felden, Schaffhausen to Constanz; in addition, there are 12
navigable lakes ranging in size from Lake Geneva to
Hallwilersee
Ports: 1 major (Basel), 2 minor
Civil air: 83 major transport aircraft (including 1 leased
in)
Airfields: 79 total, 73 usable; 40 with permanent-surface
runways; 2 with runways over 3,660 m, 8 with runways
2,440-3,659 m, 12 with runways 1,220-2,439 m
200 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SWITZERLAND/SYRIA
Telecommunications: excellent domestic, international,
and broadcast services; 3.96 million telephones (61.1 per 100
popl.); 7 AM, 94 FM, and 332 TV stations; | Atlantic ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,518,000; 1,315,000 fit
for military service; 48,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1977, $1,141 million; 18% of central government budget
SYRIA
SAUDI ARABIA.
-
(See reference map V)
LAND
186,480 km? (including 1,295 km? of Israeli-occupied
territory); 48% arable, 29% grazing, 2% forest, 21% desert
Land boundaries: 2,196 km (1967) (excluding occupied
area 2,156 km)
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 193 km','5bbab8f73a8dd8b8206243f7240a7699162984a76011c6a20c4568eb649c2a89','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50454cb5616952bf295c45e2a514ba6da5489366c4025bd683b2674aa1187e5a',1978,'LU','Luxembourg','communications',305,'(See reference map (V}
LAND
2,590 km?;, 25% arable, 27% meadows and pasture, 15%
waste or urban, 33% forested, negligible amount of inland
water
Land boundaries: 356 km
Railroads: 270 km standard gage (1.435 m); 160 km
double track; 136 km electrified
Highways: 4,528 km; all paved; about 80 km limited
access divided highway completed or under construction
Inland waterways: 87 km: Moselle River
Pipelines: refined products, 48 km
Port: (river) Mertert
Civil air: 8 major transport aircraft
Airfields: 1 total, 1 usable with permanent-surface
runway 2,440-3,659 m
Telecommunications: adequate and efficient system;
153,100 telephones (41.1 per 100 popl.); 4 AM, 1 FM, 2 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 83,000; 71,000 fit for
military service; about 3,000 reach military age (19)
annually
Military budget: for fiscal year ending 31 December
1977, $28,794,467, 3.5% of the central government budget','e959233589b17291c009f58f00d730b504ebb1c230c1f4bbf113cd04bec8c630','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d571dc48aae5d1abfdd403d67dbe939c848de769107c7796ae9e503dac04f3b4',1978,'MO','Macao','communications',309,'LAND
15.5 km*; 10% agricultural, 90% urban
Land boundaries: 201 m
WATER
Limits of territorial waters (claimed): 6 nm; fishing, 12
nm
Coastline: 40 km','0d7c75a586617fe6870c8a1cc93dd6c6af90f6866e235dfae42a7831fdb5601e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e13b8a48d7f0f28f31eee657d1363feb7f267031e1d4f67672457f5b854783f',1978,'MG','Madagascar','communications',311,'LAND
595,700 km?; 5% cultivated, 58% pastureland, 21%
forested, 8% wasteland, 2% rivers and lakes, 6% other
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 4,828 km','38754d99676381a4e39cc86c5aeab4aa9f256762a61ffdfc0d7a2ab4198bfd94','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c03bf61b291eceea0834c79578623760655ae5dacb8e3f0a1741448fdc8e39a6',1978,'MW','Malawi','communications',313,'LAND
95,053 km?; about 31% of land area arable (of which less
than half is cultivated), nearly 25% forested, 6% meadow
and pasture, 38% other
Land boundaries: 2,881 km
sas Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Indian
Ocean
“southern. ¢
RHODESIA
{See reference map Vi}
Railroads: 566 km 1.067-meter gage
Highways: 14,913 km; 1,385 km paved; 631 km crushed
stone, gravel, or stabilized soil; 8,714 km improved earth,
4,183 km unimproved earth
Inland waterways: Lake Malawi, 1,290 km and Shire
River, 144 km, 3 lake ports
Ports: no maritime ports
Civil air: 6 major transport aircraft
Airfields: 48 total, 46 usable; 1 with permanent-surface
runway; 8 with runways 1,220-2,439 m
Telecommunications: the system is above average for
African countries and consists of open-wire lines, radio-relay
links, and radiocommunication stations; principal centers are
Blantyre, Zomba, Lilongwe, and Muzuzu; 19,800 telephones
(0.4 per 100 popl.); 5 AM, 4 FM and no TV stations; 1 Indian
Ocean satellite station
127
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MALAWI/MALAYSIA
DEFENSE FORCES
Military manpower: males
561,000 fit for military service
Military budget: for fiscal year ending 31 March 1978,
$14.0 million; 6.7% of recurrent central government budget
15-49, 1,104,000: about
Ports: 3 major (Dar es Salaam, Mtwara, Tanga)
Civil air: 9 major transport aircraft
Airfields: 103 total, 97 usable; 9 with permanent-surface
runways; | with runway 2,440-3,659 m, 41 with runways
1,220-2,439 m
Telecommunications: fair system of open wire, micro-
wave, and troposcatter; 62,600 telephones (0.4 per 100
popl.); 4 AM, no FM or TV stations; 1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 3,659,000; 2,097,000 fit
for military service
Military budget: for fiscal year ending 30 June 1978,
$141.3 million; 17% of central government budget','dbda4c6909f11deffdec385676ca8cb38fff20f2aa049526a81f26a8ea41eacf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0966caf67e7408bae1792c3e30b7eb64a31138b6478d245674d10787ce07a9dc',1978,'MY','Malaysia','communications',317,'"ey? Varna
{See reference map Vil}
NOTE: Malaysia, which came into being on 16 September
1963, consists of Peninsular Malaysia, which includes 11
states of the former Federation of Malaya, plus East
Malaysia, which includes the 2 former colonies of North
Borneo (renamed Sabah) and Sarawak
LAND
Peninsular Malaysia: 131,313 km?; 20% cultivated, 26%
forest reserves, 54% other
Sabah: 76,146 km’; 13% cultivated, 34% forest reserves,
53% other
Sarawak: 125,097 km?; 21% cultivated, 24% forest
reserves, 55% other
Land boundaries: 509 km Peninsular Malaysia, 1.786 km
East Malaysia
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 2,068 km Peninsular Malaysia, 2,607 km East','630b4e2e7ddfe2bc967d4f22251cbc2f198583faa963e5e05293b9b5b8bcca61','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98720f3047a5bca0139b422fe46067e0e9e192f59b1494e274d369d40674ffdc',1978,'SG','Singapore','communications',322,'Railroads:
Peninsular Malaysia: 1,665 km 1.04-meter gage; 13
km double track; government-owned
East Malaysia: 154 km meter gage (1.00 m) in Sabah
Highways:
Peninsular Malaysia: 19,753 km; 15,900 km hard
surfaced (mostly bituminous surface treatment), 2,970 km
crushed stone/gravel, 883 km improved or unimproved
earth
East Malaysia: about 4,544 km (1,644 km in Sarawak,
2,899 km in Sabah); 819 km hard surfaced (mostly
bituminous surface treatment), 2,936 km gravel or crushed
stone, 1,234 km earth
Inland waterways:
Peninsular Malaysia: 3,194 km
Fast Malaysia: 4,087 km (1,569 km in Sabah, 2,518 km
in Sarawak)
Ports:
Peninsular Malaysia: 2 major, 15 minor
East Malaysia: 1 major, 14 minor (5 minor in Sabah: 1
major, 9 minor in Sarawak)
Civil air: approximately 27 major transport aircraft
Pipelines: crude oil, 69 km; refined products, 56 km
Airfields:
Peninsular Malaysia: 60 total, 60 usable; 16 with
permanent-surface runways; 2 with runways 2,440-3,659 m,
1! with runways 1,220-2,439 m
Sabah: 34 total, 34 usable; 5 with permanent-surface
runways; | with runway 2,440-3,659 m; 4 with runways
1,220-2,439 m
Sarawak: 45 total, 45 usable; 5 with permanent-surface
runways; 4 with runways 1,220-2,439 m
Telecommunications:
Peninsular Malaysia: good intercity service provided
mainly by microwave relay; international service good; good
coverage by radio and television broadcasts; 220,000
telephones; 450,000 radio and 2,600,000 TV receivers; 26
AM, 1 FM, and 16 TV stations; submarine cables extend to
India, Ceylon, and Singapore; connected to SEACOM
submarine cable terminal at Singapore by microwave relay;
1 ground satellite station
Sabah: adequate intercity radio-relay network extends
to Sarawak via Brunei; 18,500 telephones; 35,500 radio
receivers; 3,200 TV receivers; 5 AM, 1 FM, 5 TV stations;
SEACOM submarine cable links to Hong Kong and
Singapore; 1 ground satellite station
Sarawak: adequate intercity radio-relay network ex-
tends to Sabah via Brunei; 22,000 telephones; 107,000 radio
and 1,000 TV receivers; 4 AM stations, no FM, and 1 TV
station
DEFENSE FORCES
Military manpower:
Peninsular Malaysia: males
1,535,000 fit for military service
Sabah: males 15-49, 195,000; 114,000 fit for military
service
Sarawak: males 15-49, 258,000; 154,000 fit for military
service; conscription age for Malaysia is 21—an age reached
by about 125,000 annually
External defense dependent on loose Five Power Defense
Agreement (FPDA) which replaced Anglo-Malayan Defense
Agreement of 1957 as amended in 1963
Military budget: for fiscal year ending 31 December
1977, $539 million; about 12.5% of central government
budget
15-49, 2,421,000;
x)
South
China Sea
(See reference map Vil}
LAND
583 km?; 31% built up area, roads, railroads, and airfields,
22% agricultural, 47% other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 193 km
Railroads: 38 km of meter gage
Highways: 2,200 km (1976); 1,700 km paved, 500 km
crushed stone or improved earth
Ports: 3 major
Civil air: approximately 20 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: adequate domestic facilities; good
international service; good radio and television broadcast
coverage; 317,000 telephones; 356,000 radio and 269,000 TV
sets; 13 AM, 4 FM, and 2 TV stations, SEACOM submarine
cable extends to Hong Kong via Sabah, Malaysia; 1 ground
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 643,000; 468,000 fit for
military service
Military budget: for fiscal year ending 31 March 1978,
$413.2 million; about 18.5% of central government budget','35901d3a152b6e16d15338cbe1cd734e5264b535499ad8597e8c4b6e11b3d9d4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a37c692d4698640796b33ac93836eadce2c90e023d0d57399e21ab1911f6c0e',1978,'MV','Maldives','communications',323,'ahi
Arabian
Sea;
> SRI
“s-deecadive -,. LANKA
See
Indian Ocean
{See reference map Vil}
LAND
298 km’; 2,000 islands grouped into 12 atolls, about 220
islands inhabited
WATER
Limits of territorial waters (claimed): the land and sea
between latitudes 7°9’N. and 0°45’S. and between longi-
tudes 72°30’E. and 73°48’E; these coordinates form a
rectangle of approximately 37,000 nm’; territorial sea ranges
from 2.75 to 55 nm; fishing, approximately 100 nm
Coastline: 644 km (approx.)
Railroads: none
Highways: none
Ports: 2 minor
Civil air: 2 major transport aircraft
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways; | with runway 2,440-3,659 m, 1 with runway
1,220-2,489 m
Telecommunications: minimal domestic and internation-
al telecommunication facilities; 411 telephones (0.3 per 100
popl.); 6 AM stations; 1 COMSAT station under construction','f1dca0a3c3ef73a9c448915655d88f16ad58e0feff65a25b6ad72ffa7943ce59','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a74683b0227f05226b0d50b46558a98307f0a6c1166d2833fce92bd6948930de',1978,'ML','Mali','communications',327,'Atlantic
Ocean
(See reference map Vi}
LAND
1,204,350 km?; only about a fourth of area arable, forests
negligible, rest sparse pasture or desert
Land boundaries: 7,459 km
Railroads: 642 km meter gage (1.00 m)
Highways: approximately 15,699 km; 1,669 km bitumi-
nous, 3,670 km gravel and improved earth, 10,360 km
unimproved earth
Inland waterways: 1,815 km navigable
Civil air: 2 major transport aircraft
Airfields: 42 total, 38 usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 10 with runways
1,220-2,439 m
Telecommunications: domestic system poor and provides
only minimal service; open-wire and radiocommunication
used for long distance telecommunications; 78,000 tele-
phones (0.1 per 100 popl.); 2 AM, no FM, and no TV
stations; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,364,000; 767,000 fit
for military service; no conscription
Military budget: for fiscal year ending 31 December
1976, $19,419,900; about 18% of central government budget
Mediterranean Sea
(See reference map IV}
LAND
313 km?*; 45% agricultural, negligible amount forested,
remainder urban, waste, or other (1965)
WATER
Limits of territorial waters (claimed): 6 nm (fishing 20
nm)
Coastline: 140 km
Highways: 1,239 km; 1,128 km paved (asphalt), 79 km
crushed stone or gravel, 32 km improved and unimproved
earth
Ports: 1 major (Valletta), 2 minor
Civil air: 3 major transport aircraft (leased in)
Airfields: 4 total, 2 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: modern automatic telephone sys-
tem centered in Valletta; 55,000 telephones (17.4 per 100
popl.); 1 TV, 5 AM, and 4 FM stations; 8 submarine cables,
including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 91,000; 70,000 fit for
military service
Supply: has received 2 patrol boats, small arms, and
mortars from Libya; vehicles and engineer equipment from
? Praia Senne
fmm “Timbuktu
The Gambiag Banjul i om
ns uirweeent ot *
Guinea ke goed
ineeai. [pissau ts _:) a £
Guinea aN? Djamena Sudan
Conakry en ‘ procieeeeg ia ,
y : :
Freetown ‘ ‘ 2 .
Sierra Nigeria
Leone %
Monrovia Lagos rut Centra} African
Liberte, fay ca ee,
Beare bidjan
Khartoum ,
Malabot Yaoundé
£q. Guinea - 2
Sao Tome and o*
Principe congo]
Eq. anes Tomes “Gabon i Zz a i re Rwanda
Kisanganie
a ge "I
\\ inshasa
South Luanda}
Atlantic |
Lobitog Angola
Ocean
; Southern
(South-West Rhodesia
Africa)','c706295e9eef792ae6bfa97df744d2e41929746bea00e9f08fbcf6a9c218a4a1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('440fe25182c7513e9a943563c71c6ee15cd1006653da6e34140c5fa2f6b75cfd',1978,'IT','Italy','communications',331,'Military budget: for fiscal year ending 31 March 1978,
$11,082,210; about 6% of central government budget','4cc604e885924f521c38d24918f2b37725175b4ce197f3ce7018c631d353814c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('042788cb49e791c2f86831cb80b7537577a6e0d312ea19eab8b4b850ea08cdff',1978,'MQ','Martinique','communications',332,'LAND
1,100 km’; 81% cropland, 16% pasture, 29% forest, 24%
wasteland, built on
WATER
Limits of territorial waters (claimed); 12 nm
Coastline: 290 km
Railroads: none
Highways: 1,450 km; 1,000 km paved, 450 km gravel and
earth
Ports: 1 major ( Fort-de-France), 5 minor
Civil air: no major transport aircraft
Airfields: 3 usable; 1 with permanent-surface runway; 1
with runway 2,440-3,659 m; 1 seaplane station
Telecommunications: domestic facilities inadequate;
31,700 telephones (9.0 per 100 popl.); inter-island VHF and
UHF radio links; COMSAT ground station; 1 AM, 1 FM, and
5 TV stations','2480ed1af4b1713f78bb9086e9f5e920d69315ce100bf4341a0691b6cb4348d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3a86f585fbe5be775591b8c3677a9ce49fa7b9661ca1493c5b3065fef28a864',1978,'MR','Mauritania','communications',336,'LAND
1,085,210 km*; less than 1% suitable for crops, 10%
pasture, 90% desert
Land boundaries: 5,118 km
WATER
Limits of territorial waters (claimed): 30 nm (fishing, 36
nm)
Coastline: 754 km
Railroads: 650 km standard gage (1.435 m), single track,
privately owned
Highways: 6,090 km; 558 km paved; 607 km gravel,
crushed stone, or otherwise improved; 4,925 km unimproved
Inland waterways: 800 km
Ports: 1 major (Nouadhibou), 2 minor
Civil air: 8 major transport aircraft
Airfields: 29 total, 29 usable; 9 with permanent-surface
runways; 1 with runway 2,440-3,659 m; 16 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: poor system of fragmentary open-
wire lines, a minor radio-relay link, and radiocommunica-
tions stations; 1,500 telephones (0.1 per 100 popl.); 1 AM, no
FM or TV stations
135
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MAURITANIA/MAURITIUS
DEFENSE FORCES
Military manpower: males 15-49, 321,000: 153,000 fit for
military service; conscription law not implemented
Supply: primarily dependent on France; has also received
material from Algeria, Morocco, U.K., and Spain
Military budget: for fiscal year ending 31 December 1976
(revised), $29 million; 22% of central government budget
,Gane- verde J Nouakchott','8cad6ae4322c8a482a7fa655812a51e8ee928c457f7ed3185348d16f8590fe8f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b7be1fd88a52d97c1427c71756aea933e1d8883ee390d6695eed1a3419b0c0d',1978,'MU','Mauritius','communications',340,'MADAGASCAR:
REUNION
fndian Ocean
(See reference map Vi)
LAND
1,856 km? (excluding dependencies); 50% agricultural,
intensely cultivated; 39% forests, woodlands, mountains,
river, and natural reserves; 3% built-up areas; 5% water
bodies, 2% roads and tracks, 1% permanent wastelands
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 177 km
Highways: 1,770 km; 1,598 km paved, 177 km earth
Civil air: 2 major transport aircraft (leased in)
Ports: 1 major (Port Louis)
Airfields: 6 total, 5 usable; 1 with permanent surface
runway; | with runway 2,440-3,659 m
Telecommunications: radio telegraph service with Re-
union, Malagasy Republic, Seychelles, Zanzibar, and other
places in Africa; 1 AM, no FM, and 4 TV stations; 22,600
telephones (2.9 per 100 popl.); 2 submarine cables, 1
COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 205,000; 106,000 fit for
military service
Military budget: for fiscal year ending 30 June 1973,
$3,981,038; 6.5% of central government budget
e 6
REUNION
Ocean
(See reference map Vi}
LAND
2,512 km?; two-thirds of island extremely rugged,
consisting of volcanic mountains; 48,600 hectares (less than
one-fifth of the land) under cultivation
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 201 km
Railroads: none
Highways: 1,983 km; 1,683 km paved, 300 km gravel,
crushed stone, or stabilized earth
Ports: 1 major (Port des Galets)
Civil air: no major transport aircraft
Airfields: 7 total, 7 usable; 2 with permanent-surface
runways; | with runway 2,440-3,659 m, 2 with runways
1,220-2,4389 m
Telecommunications: adequate system for size of island
of fairly modern open-wire lines and radiocommunication
stations; principal center Saint-Denis; external radiocom-
munications to Comoro Islands, France, Madagascar, and
Mauritius; 25,400 telephones (5.8 per 100 popl.); 2 AM, no
FM, and 14 TV stations; 1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: military age males included with
Port Louis,
S
Reunion
{Fr}
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79- CONTIN ORS SR Maind Asia
Greeniand
(Denmark)
Hemand
Yakutsk f
.
U.S. S_R. }
Kuybyshev
*Sverdiovsk
eVolgograd
Omsk ope
Pacific
» Novosibirsk
j Ocean
culsk,
be
Ha-erh-pin
/ i ostok
Pn f
(Harbin) *
Ulaanbaatar. -','c37ec0d60285fe2663bb56d0f9b11d9ae21bc782851d73ea67846e26d212dc95','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0b06e54e3cba45fbc75dd166761034312b21bd13c3c15ee1f39755743029640',1978,'MX','Mexico','communications',344,'LAND
1,978,800 km?; 12% cropland, 40% pasture, 22% forested,
26% other (including waste, urban areas and public lands)
Land boundaries: 4,220 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Gulf
of Mexico
Pacific Qcean
GUATEMALA,
(See reference map Il)
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm), 200 nm exclusive economic zone
Coastline: 9,330 km
Railroads: 19,680 km; 18,576 km standard gage (1.435
m); 1,104 km narrow gage (0.914 m): 102 km electrified;
19,573 km government-owned, 107 km_ privately-owned
Inland waterways: 2,900 km navigable rivers and coastal
canals
Pipelines: crude oil, 3,880 km; refined products, 3,360
km; natural gas, 5,580 km
Ports: 9 major, 20 minor
Civil air: 110 major transport aircraft (including 2 leased
in)
Airfields: 1,769 total, 1,718 usable; 1836 with permanent-
surface runways; 2 with runways over 3,660 m, 21 with
runways 2,440-3,659 m, 256 with runways 1,220-2,439 m; 9
seaplane stations
Telecommunications: highly developed telecom system
with extensive radio-relay links; connection into Central
American microwave net; 1 Atlantic Ocean satellite ground
station; 2.96 million telephones (4.8 per 100 popl.); 574 AM,
109 FM, and 163 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 13,867,000; 10,558,000
fit for military service; average number reaching military
age (18) annually, 738,000
Military budget: for year ending 31 December 1977,
$612.8 million; about 3.9% of direct federal budget (includes
merchant marine and military industry)','c0c3356ade657fb14ac1a17fbcfe100ca835f65c7a074122acdcebcd86a315a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f987fdf0d1b096623271e2677ffcd44c84cf8a80c375a38096006ca572e5e8e1',1978,'MC','Monaco','communications',348,'LAND
15 km?
Land boundaries: 3.7 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4.1 km
138 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MONACO/MONGOLIA
Mediterranean Sea
(See caference map ty)
Railroads: 1.609 km (see France)
Highways: none; city streets
Ports: 1 minor
Civil air: no major aircraft
Airfields: none
Telecommunications: served by the French communica-
tions system; automatic telephone system with about 22,550
telephones (84.1 per 100 popl.); 2 AM, 1 FM, and 3 TV
stations
DEFENSE FORCES
France responsible for defense','012ac56e6621985e6610a8dbb166c3eb306020fa0f17fc9413b677204b10221f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78fd3ccdc7d61bf59103bb4864d0608ac4e5815d81dca6aca5866fe7c84c9939',1978,'MN','Mongolia','communications',352,'(See reference map Vil)
LAND
1,564,619 km®; almost 90% of land area is pasture or desert
wasteland, varying in usefulness, less than 1% arable, 10%
forested
Land boundaries: 8,000 km
Railroads: 1,516 km; all broad gage (1.524 m) (1976)
Inland waterways: 616 km of principal routes (1975)
Freight carried: rail—6.9 million metric tons, 8,150
million metric ton/km (1975); highway—13.9 million metric
tons, 953 million metric ton/km; waterway—0.05 million
metric tons, 0.04 billion metric ton/km (1975)
DEFENSE FORCES
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 31 December
1975, 268 million tugriks, 10% of total budget
rth \\¢
‘orea y
Pyongyang Ke ayokyo
e lachkent
°
Wu-lu-mu-ch''i
pow ee (Urumchi)
VL
Ch''ing- ‘too et be ae japan
= indian claim) (Tsingt Me
= gtao) oD
? Lan-chou , Hsien / »/
x * ° \\ ”
A> Chinese fine [ o h Fria (Sian) ~
7 of copbot ®Shang-hai
Saudi “5 re y nd @Wu-han = .
Arabia Paes eGh''eng-tu e F
Taipei
é re
Yemen ir , Kuang-chgi
Aden) © op K''un-ming (Canton) | Taiwan
Macagse Hong Kong
Bombay{, gm ae Gas
: Azahi F
poe Avabian Sea tyderabad ‘
i \\ ee Rangobn,,
e \\ a {* ih Thailand
\\ i ?
ad tae Madras 4 Bangkok.
“/\\ Sri Lanka
\\iCeytan) Ho Chi Minh City)
(.\\ BoA)
; oe } ’ is Brunei * \\
ae 7 ye. Ww. fore Maes
Maldives * mes \\Koshe Lumpur Sarawak ee &
a he Maiaysia y = ee
“3 Ge oc
thao oe MADE ik atimantan GifRrest “0 EX
Palembangu, «, Béviagmasing fC \\ ;
* Paden 0
1 JaRarth . _ Surabaya “. fe a
indtan Ocean eter e a6 0c 7 ree:
Perth soy 2
1200 Kilometers sa aft
1200 Miles
NAMES NATION (eee
ARE MOT ae £ pid QETATIVE f =
503195 1-78 (540317)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
II Middie America
..gLo8 Angeles U n i te a 4 tates
Hermosiilo
. mead
New Orleans y79
SAG
Monterrey, ; ;
Gulf of Mexico
: »Mazatlan
Meawice
Havana, _
eFampico is foe
2.7 Cigy f8gos™ Ne
a
eGuadaiajara
maval Bass Ma z
* F ‘ Pome : Bs
Mexico Veracruz ES ‘ : a. Port-au-Prinee
he Bs Bae . Soe if
% Sea Domingo
ee
“Beimopan Kingston','d69cd9bb451257e1ab56a1f9292f33597045a22572927c952c01209f142f4ea8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a670da02186a40b3301dc4f49142df36ba2f0bb20505b06e988d0f48fa97b9a',1978,'MA','Morocco','communications',356,'POATU
Atlantic j
2 é
Mediterranean Sea <r
{See reference map Vif
LAND
409,200 km?; about 32% arable and grazing land, 17%
forest and esparto, 51% desert, waste, and urban
Land boundaries: 1,996 km
WATER
Limits of territorial waters (claimed): 12 nm (200 nm
exclusive economic zone)
Coastline: 1,835 km
Railroads: 1,756 km standard gage (1.435 m), 161 km
double track; 708 km electrified
Highways: 52,304 km; 18,299 km bituminous treated,
5,681 km gravel, crushed stone, and improved earth, 28,324
km unimproved earth
Pipelines: 362 km crude oil; 491 km (abandoned) refined
products; 241 km natural gas
Ports: 8 major (including Spanish-controlled Ceuta and
Melilla), 10 minor
Civil air: 20 major transport aircraft
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 Me
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MOROCCO/MOZAMBIQUE
Airfields: 78 total, 78 usable; 25 with permanent-surface
runways; 2 with runways over 3,660 m, 13 with runways
2,440-3,659 m, 32 with runways 1,220-2,439 m; 4 seaplane
stations
Telecommunications: good system by African standards
composed of open-wire lines, coaxial, multiconductor and
submarine cables and radio-relay links; principal centers
Casablanca and Rabat, secondary centers Fes, Marrakech,
Oujda, Sebaa Aioun, Tangier and Tetouan; 199,000 tele-
phones (1.1 per 100 popl.); 25 AM, 4 FM, 27 TV stations; 3
submarine cables; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,996,000; 2,372,000 fit
for military service; about 211,000 reach military age (18)
annually; limited conscription
Military budget: for fiscal year ending 31 December
1977, $781 million; 17% of central government budget
503001 1-78
ee
wie? gédinburgh
Ly Glasgo
Bolfgst
IV Europe
400 Kilometers
400 Miles
#7 Jan ) Mayen
e
Murmansk
Norwegian
Sea
0%, oe
Faroe Is. pe Sweden
2
Fen.) e q Finland
$ of \\ }
we - FO ahingiad
am) e
Le aig
stein) —
de
Lope
i o
id ad £ o.. ag ree
My ? ) Riga
D
+* Moscow
Ry _fS .
evil''nyus
Minsk
U.S.S.R.
Wr
Ae
fe
- < German
a ~/London P : ; i
ta T Dem. Rep.
Warsaw
*','ef144bdbb28e394ab87cfe69d0709f383d5597d995546fd07fa743de75a598fc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02c66f1b18ae2ebb46387190e7df0dc115abb4fd811f252cc033c7a9ffa4b400',1978,'MZ','Mozambique','communications',360,'4
=
>
§
e
RN
Q
E
RHODESIA} MOZAMBIOU
&
£
¥
/ndian Ocean
(See reference map Vi}
Land
786,762 km*; 30% arable, of which 1% cultivated, 56%
woodland and forest, 14% wasteland and inland water
Land boundaries: 4,627 km
WATER
Limits of territorial waters (claimed): 12 nm (200 nm
exclusive economic zone)
Coastline: 2,470 km
Railroads: 3,162 km; 3,020 km 1.067-meter gage; 141 km
narrow gage (0.750 m)
Highways: 26,477 km; 4,322 km paved; 607 km improved
earth; 21,548 km unimproved earth, unconnected
Inland waterways: approx. 3,750 km of navigable routes
Pipelines: crude oil, 306 km (not operating)
Ports; 8 major (Maputo, Beira, Nacala), 2 significant
minor
Civil air: 14 major transport aircraft
Airfields: 330 total, 321 usable, 28 with permanent-sur-
face runways; 6 with runways 2,440-3,659 m; 37 with
runways 1,220-2,439 m
Telecommunications: fair system of troposcatter, open-
wire lines, and radiocommunications; principal centers
Maputo, Beira, and Nampula; 50,000 telephones (0.6 per 100
popl.); 10 AM, 2 FM, no TV stations; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,280,000; 1,181,000 fit
for military service
Supply: mostly from the USSR and PRC, and to a lesser
extent from other Communist countries and Portugal
Military budget: for fiscal year ending 31 December
1977, $63.3 million; 18% of central government budget','a1fd0274d97fde6edeaec348546031a66c8c25e8e4b4b525d18ca6e3304b510e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8340e627d92ad89cd4190be444d662e886b1973538f547768ebb9a76f39d26c',1978,'NA','Namibia','communications',364,'(South-West Africa)
LAND
823,620 km®; mostly desert except for interior plateau and
area along northern border
Land boundaries: 3,798 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 1,489 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Atlantic
Qeean
Windhoek ra
indian
Ocean
(See reference map Vi}
Railroads: 2,326 km 1.067-meter gage, single track
Highways: 3,400 km; 2,680 km paved, remainder gravel,
remainder earth roads and tracks
Ports: 1 major (Walvis Bay), 1 minor
Civil air: 5 major transport aircraft (registered in South
Africa)
Airfields: 113 total, 85 usable; 13 with permanent-surface
runways; 1 with runway over 3,660 m; 3 with runways
2,440-3,659 m, 34 with runways 1,220-2,489 m
Telecommunications: sparse system of open wire and
radio relay routes; out-lying areas connected by radiocom-
munication; Windhoek is the only major center; 46,400
telephones (6.2 per 100 popl.); 1 FM, no AM and no TV
stations
DEFENSE FORCES
Military manpower: males 15-49, about 221,000: about
128,000 fit for military service
Defense is responsibility of Republic of South Africa','4411ed7e448131bc59ca3a528809c62ba7bf7a852858aabe53931bd757861cf8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3d2a192c2120a31549f1c029334a328bee4b2210c2edba6df8dc42ba8fa6307',1978,'NR','Nauru','communications',368,'NAURU®
Pacific Ocean
{See reference map Viit{
LAND
21.2 km*; insignificant arable land, no urban areas,
extensive phosphate mines
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 24 km
Railroads: none
Highways: about 927 km; 21 km paved, 6 km improved
earth
Inland waterways: none
Ports: ] minor
Civil air: 4 major transport aircraft
Airfields: 1, coral-surfaced, over 1,220 m
Telecommunications: adequate intraisland and interna-
tional radiocommunications provided via Australian facili-
ties; 700 telephones; 3,600 radio receivers, 1 AM, no FM and
no TV stations; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, about 1,800; fit for
military service, about 1,000; average number reaching
military age (18) annually, 1975-79, less than 100
No formal defense structure and no regular armed forces','13c396b1774a6d3354fc4b3acb557a37372fd8ce407d98d0153e072121e13e84','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('754b9aff543e4905e14aa6dbe0a56cc8ecd4b7a714021017e3ee455ff101ee19',1978,'NP','Nepal','communications',372,'LAND
141,400 km’; 16% agricultural area, 14% permanent
meadows and pastures, 38% alpine land (unarable), waste, or
urban; 32% forested
Land boundaries: 2,800 km
Approved For Release 2005/04/22 :
Bay
of Bengal
(See reference map vi
Railroads: 169 km, all narrow gage (0.762 m); mostly
government owned; all in Terai close to Indian border; only
53 km sector from border to Bizalpura presently in use; a 45
Highways: 3,700 km; 1,666 km paved, 533 km gravel or
crushed stone, 1,501 km improved and unimproved earth,
322 km of seasonally motorable tracks
Civil air: 5 major transport aircraft
Airfields: 53 total, 52 usable; 5 with permanent-surface
Tunways; 1 with runway 2,440-3,659 m, 7 with runways
1,220-2,439 m
Telecommunications; poor telephone and telegraph
service; good radiocommunication and broadcast service;
no TV stations
DEFENSE FORCES
Military budget: for fiscal year ending 14 July 1978,
$13.9 million; 5.6% of central government budget','a2015178f74c33db7059bfe3dee017a216651a131682273f356ebd95ea4fcf35','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e68c28afabdb830696acee9fa3a63a9b00f0e49d5376faccbbb50fc43ee38395',1978,'NL','Netherlands','communications',376,'North DENN
Sea
oe
‘Amsterdam
(See reference map iv)
LAND
33,929 km?: 70% cultivated, 5% waste, 8% forested, 8%
inland water, 9% other
Land _ boundaries: 1,022 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 12
nm)
Coastline: 451 km
Railroads: 2,979 km standard gage (1.435 m); 2,813 km
government-owned (NS), 1,638 km electrified, 1,556 km
double track; 166 km privately-owned
147
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
NETHERLANDS/NETHERLANDS ANTILLES
Wighways: approximately 100,960 km including 1,440
km of limited access, divided “Motorways”; about 82,240
km paved (bituminous, concrete, stone block) and 2,720 km
unpaved (gravel, crushed stone, stabilized earth)
Inland waterways: 6,340 km, of which 35% is usable by
craft of 900 metric ton capacity or larger
Pipelines: 418 km crude oil; 965 km refined products;
4,489 km natural gas
Ports: 8 major, 5 minor
Civil air: 106 major transport aircraft (including 9 leased
out and 4 leased in)
Airfields: 27 total, 26 usable; 16 with permanent-surface
runways; 13 with runways 2,440-3,659 m, 3 with runways
1,220-2,489 m
Telecommunications: highly developed, well maintained,
and integrated; extensive system of multiconductor cables,
supplemented by radio-relay links; 5.1 million telephones
(36.8 per 100 popl.); 5 AM, 12 FM, and 13 TV stations; 12
coaxial submarine cables; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,454,000; 3,099,000 fit
for military service; average number reaching military age
(20) annually 118,000
Military budget: proposed for fiscal year ending 31
December 1977, $3,291 million; about 9.7% of central
government budget
NETHERLANDS ANTILLES
Atlantic Ocean
Caribbean ANTILLES
Sea rh
{See reference map Ii)
LAND
1,020 km?; 5% arable, 95% waste, urban, or other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 364 km
Railroads: none
Highways: 950 km; 300 km paved, 650 km gravel and
earth
Ports: 3 major (Willemstad, Oranjestad, Caracasbaai,
Bullennbaai); 6 minor
Civil air; 10 major transport aircraft
Airfields: 7 total, all usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 2 with runways
1,220-2,489 m; 1 seaplane station
Telecommunications: generally adequate telecom facili-
ties; extensive interisland radio-relay links, 47,000 telephones
(19.7 per 100 popl.); 11 AM, 1 FM and 5 TV stations, 5
submarine cables, including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 58,000; 34,000 fit for
military service;~ about 2,000 reach military age (20)
annually
Defense is responsibility of the Netherlands
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
NETHERLANDS ANTILLES/NEW CALEDONIA','14ea78e7808e0648a0d37152a6efdfcd77c13f11932b9cd09921f4a2b46439cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c2c72a2a82f14e826fecdd93bda4b3e733d5b21c3cc5ad18d14012e2ae22bf3',1978,'NC','New Caledonia','communications',380,'EW
CALEDONIA
Pacific
Ocean
Tasman Sea
(See reference map Vill}
LAND
22,015 km?; 6% cultivable, 22% pasture land, 15% forests,
57% waste or other
WATER
Limits of territorial waters (claimed): 12 nm (fishing, 3
nm)
Coastline: 2,254 km
Railroads: none
Highways: 5,200 km; 600 km paved, 1,450 km gravel,
crushed stone, or stabilized surface, 650 km improved earth,
2,696 km earth
Inland waterways: none
Ports: 1 major (Noumea), 21 minor
Civil air: no major transport aircraft
Airfields: 31 total, 31 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m; 1 airfield over
2,440 m; 1 seaplane station
Telecommunications: 19,230 telephones; 60,000 radio
and 15,000 TV sets; 5 AM, no FM, and 7 TV stations; 1 earth
satellite station
NEW HEBRIDES
Pacific
BRITISH Ocean
Coral Sea
wi
HEBRIDES’,
NEW
CALEDONIA
(See reference map Vitl)
LAND
About 14,763 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 2,528 km
Railroads: none
Highways: at least 240 km sealed or all-weather roads
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Telecommunications: 3 AM broadcast stations, 11,000
radio receivers, and 1,650 telephones
DEFENSE FORCES
Personnel: no military forces maintained; however, the
French and British maintain constabularies of about 70 men
each','459d38d4930770b70348a8894137583481eec95d96b9c16cea10d7fef2d029cc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2726f65e625210730e70ef709e8aa385138c8a426fd7476d70e6a4a33a27f3c7',1978,'NI','Nicaragua','communications',389,'Railroads: 318 km 1.067-meter gage, government owned
Highways: 16,900 km; 1,500 km paved, 6,200 km
otherwise improved, 9,200 km unimproved
Inland waterways: 2,220 km, including 2 large lakes
Pipelines: crude oil, 56 km
Ports: 4 major (Corinto, Puerto Cabezas, Puerto Somoza,
San Juan del Sur), 6 minor
Civil air: 11 major transport aircraft (including 1 leased
in)
153
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
NICARAGUA/NIGER
Airfields: 429 total, 405 usable; 7 with permanent-surface
runways; | with runway 2,440-3,659 m, 9 with runways
1,220-2,439 m; 2 seaplane stations
Telecommunications: low-capacity wire and radio-relay
network; connection into Central American microwave net;
satellite ground station; 22,000 telephones (1.0 per 100
popl.); 75 AM, 30 FM, and 7 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 561,000; 343,000 fit for
military service; 25,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1977, $29.2 million for the Ministry of Defense, including
civil functions (e.g., police and civil air); 7.7% of central
government budget','bad19208caac458d2cf2213528eaf4417a59ee9799ca8d741dc75d1b29306e0e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65caaac0d5ee430f0eb05bee266b123f62047803c5980017c65e5002d6021996',1978,'NE','Niger','communications',393,'Railroads: none
Highways: 7,122 km; 1,889 km bituminous, 2,579 km
gravel, 2,654 km unimproved earth
Inland waterways: Niger River navigable 300 km from
Niamey to Gaya on the Benin frontier from mid- December
through March
Ports: Niger landlocked; outlet to sea is Cotonou, Benin
Civil air: 4 major transport aircraft
Airfields: 66 total, 63 usable; 5 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 18 with runways
1,220-2,439 m
Telecommunications: sparse system of open-wire lines,
radio-relay links, and small radiocommunications stations;
principal telecommunication center Niamey; 4,000 tele-
phones (0.1 per 100 popl.); 9 AM stations, no FM, and 1 TV
station
DEFENSE FORCES
Military manpower: males 15-49, 1,114,000; 595,000 fit
for military service; about 47,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1977, $6.9 million; about 5% of central government budget','9554617ffc554ce6c4c182b550880fee1f0f45eba201174a30ff36ff15e4ab62','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3dc4c6e9ab314dc5a717b75801bf9c982263b007bf7ded35029ec48e71dc2a3',1978,'NG','Nigeria','communications',394,'LAND
924,630 km?; 24% arable (13% of total land area under
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Lagos
{See reference meg Vi}
cultivation), 35% forested, 41% desert, waste, urban, or other
Land boundaries: 4,034 km
WATER
Limits of territorial waters (claimed): 30 nm
Coastline: 853 km
Railroads: 3,508 km 1.067-meter gage
Highways: 89,318 km; 15,300 km paved (mostly bitumi-
nous surface treatment); remainder laterite, gravel, crushed
stone, improved earth
Inland waterways: 8,575 km consisting of Niger and
Benue rivers and smaller rivers and creeks; additionally, the
newly formed Kainji Lake has several hundred miles of
navigable lake routes
Pipelines: 1,207 km crude oil; 97 km natural gas; 5 km
refined products
Ports: 2 major (Lagos/Apapa, Port Harcourt), 10 minor
Civil air: 35 major transport aircraft (including 5 leased
in)
Airfields: 91 total, 76 usable; 15 with permanent-surface
runways; 5 with runways 2,440-3,659 m, 24 with runways
1,220-2,4389 m
TYelecommunications: composed of radio-relay _ links,
open-wire lines, and radiocommunication stations; principal
center l.agos, secondary centers Ibadan and Kaduna:
115,000 telephones (0.2 per 100 popl.); 25 AM, 6 FM, and 9
TV stations; 2 submarine cables; 1 Atlantic Ocean and 1
Indian Ocean satellite station and 19 domestic stations
DEFENSE FORCES
Military manpower: males 15-49, 15,033,000; 8,650,000
fit for military service; average number reaching military
age (18) annually 706,000
Military budget: for fiscal year ending 31 March 1978,
$2.7 billion; about 17% of central government budget','2df699f6221fb67fb6dfadcc7975c5b447090401ac10ea06e2b0e87acc52b0fc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5e9ff2a86b35808519424da9f12993ca51556b0eca84c8f6db86e4fc79d8a16',1978,'NO','Norway','communications',398,'LAND
Norway: 323,750 km?; Svalbard, 62,160 km?; Jan Mayen,
pe Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Norwegian
{See reference map IV}
873 km’; 3% arable, 2% meadows and pastures, 21%
forested, 74% other
Land boundaries: 2,579 km
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: mainland 3,419 km; islands 2,413 km (excludes
long fjords and numerous small islands and minor indenta-
tions which total as much as 16,093 km overall)
Railroads: 4,257 km standard gage (1.485 m); Norwegian
State Railways (NSB) operates 4,241 km (2,440 km
electrified and 91 km double track); 16 km privately-owned
and electrified
Highways: 73,600 km; 14,400 km paved, 59,200 km
crushed stone and gravel ,
Inland waterways: 1,577 km; 1.5-2.4 m draft vessels
maximum
Pipelines: refined products, 53 km
Ports: 9 major, 69 minor
Civil air: 49 major transport aircraft
Airfields: 105 total, 105 usable; 53 with permanent-
surface runways; 11 with runways 2,440-8,659 m, 17 with
runways 1,220-2,439 m; 20 seaplane stations
Telecommunications: high-quality domestic and interna-
tional telephone, telegraph, and telex service; 1.43 million
telephones (35.0 per 100 popl.); 32 AM, 357 FM, and 740 TV
stations; 5 coaxial submarine cables; 2 domestic satellite
stations
DEFENSE FORCES
Military manpower: males 15-49, 925,000; 751,000 fit for
military service; average number reaching military age (20)
annually, 31,000
Military budget: proposed for fiscal year ending 31
December 1977, $1,026.9 million; about 8.9% of central
government budget
(See reference map V}
LAND
About 212,380 km?; negligible amount forested, remain-
der desert, waste, or urban
Land boundaries: 1,384 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 50
nm)
Coastline: 2,092 km
Highways: 2,816 km; 5 km bituminous surface, 2,811 km
motorable track
Pipelines: crude oil 370 km
Ports: 1 major (Qaboos), 3 minor
Civil air: 25 major transport aircraft (including 1 leased
in)
Airfields: 162 total, 140 usable; 4 with permanent-surface
runways; 1 runway over 3,660 m, 5 with runways
2,440-3,659 m, 49 with runways 1,220-2,439 m
Telecommunications: limited facilities of open-wire,
radio-relay and radiocommunications stations; 1 satellite
ground station; 4,500 telephones (0.7 per 100 popl.); 2 AM,
no FM, no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 118,000; 68,000 fit for
military service','c68b4f271e8bebc3b800cd978f59d4d3153ad344038025d3684ca74b50786adf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f4a4f9ee9d4195ef94d54445b461e8d73f41360e2fa8ab5e29f35750ca451e1',1978,'PK','Pakistan','communications',402,'LAND
803,000 km? (includes Pakistani part of Jammu-Kashmir);
40% arable, including 24% cultivated; 23% unsuitable for
cultivation; 34% unreported, probably mostly waste, 8%
forested
Land boundaries: 5,900 km
Approved For Release 2005/04/22 :
Arabian Sea
ease
(See reference map Vil)
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; plus right to establish 100 nm conservation zones
beyond territorial sea); 200 nm exclusive economic zone
Coastline: 1,046 km
Railroads: 7,489 km; 446 km meter gage (1.00 m), 6,431
km broad gage (1.676 m), 612 km narrow gage (0.762 m);
1,022 km _ double track; 286 km electrified;
government-owned
9.9 rupees=US$1 (since
Highways: 63,567 km; 16,077 km paved, 12,862 km
gravel, 1,843 km improved earth, 32,785 km unimproved
earth
Inland waterways: 1,850 km
Pipelines: 230 km crude oil; 1,981 km natural gas
Ports: 1 major, 5 minor
Civil air: 27 major transport aircraft
Airfields: 110 total, 105 usable: 64 with permanent-sur-
face runways; 1 with runway over 3,600 m, 25 with runways
2,440-3,659 m, 48 with runways 1,200-2.489 m
Telecommunications: good international radiocommuni-
cation service over CENTO microwave and intelsat satellite;
domestic radiocommunications poor; broadcast service very
good; 239,000 (est.) telephones; 1,100,000 radio and 250,000
TV sets; 20 AM, no FM, 5 TV stations, and 4 repeaters; |
ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 17,693,000; 10,485,000
fit for military service; 838,000 reach military age (17)
annually
Military budget: for fiscal year ending 30 June 1978,
$996 million; about 28.4% of central government budget
@°-
‘Sy
SG py
Dhahran ae
j * Oman
Riyadh, ‘Abu Dhabj * ‘
United Arab Muscat®*.
Emirates Se','f52daf487727bbf0301f5c04ffcc048f5fcd70522b5520a1ad247e54187c4fd6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c47e1a2d544fb60795bb23bc051158828bfa7aa1769db1fad8a68a6e6cc3e669',1978,'PA','Panama','communications',406,'Caribbean Sea
Pacific Qcean
{See reference map
LAND
75,650 km? (excluding Canal Zone, 1,430 km?); 24%
agricultural land (9% fallow, 4% cropland, 11% pasture),
20% exploitable forest, 56% other forests, urban, and waste
Land boundaries: 630 km
WATER
Limits of territorial waters (claimed): 200 nm (continen-
tal shelf including sovereignty over superjacent waters)
Coastline: 2,490 km
ne Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Railroads: 488 km; 77 km 1.524-meter gage, 171 km
0.914-meter gage; 240 km plantation feeder lines
Highways: 7,800 km; 2,500 km paved, 2,300 km gravel or
crushed stone, 3,000 km improved and unimproved earth;
Panama Canal Zone 240 km; 230 km paved, 10 km gravel
161
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
PANAMA/PAPUA NEW GUINEA
Inland waterways: 800 km navigable by shallow draft
vessels; 82 km Panama Canal
Pipelines: refined products, 96 km
Ports: 2 major (Cristobal/Colon/Coco Solo, Balboa/Pan-
ama City), 10 minor
Civil air: 18 major transport aircraft
Airfields: (including Canal Zone) 151 total, 151 usable; 33
with permanent-surface runways; 2 with runways
2,440-3,659 m; 16 with runways 1,220-2,439 m; 2 seaplane
stations
Telecommunications: domestic and international telecom
facilities well developed; connection into Central American
microwave net; COMSAT ground station; 155,200 tele-
phones (8.5 per 100 popl.); 80 AM, 30 FM, and 13 TV
stations; 1 coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 389,000; 270,000 fit for
military service; no conscription
Military budget: for fiscal year ending 31 December
1976, $32.6 million; about 10% of central government
budget
vung «bat Zone
Gosta , (8. juris.)
Rica +
Barranquilla,
o Medellin
xBogota
*auito','ac71001f9a1184a0b9419538a839386262f046d1487028eaf35f24fb637d3454','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b726a0cbb42a11651b638d36d7dbad814b46d63b60139b6fa4fc7f3f3d4dcdb6',1978,'PG','Papua New Guinea','communications',410,'Pacific Ocean
= ‘ ~ BRITISH
Ma {ndwouwmex Salaun
5 Parts .* wet
Moresby &
b
Coral Sea *
{See reference map Vill)
LAND
475,369 km?
Land boundaries: 966 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: about 5,152 km
Railroads: none
Highways: 19,200 km; 640 km paved, 10,960 km gravel,
crushed stone, or stabilized soil surface, 7,600 km unim-
proved earth
Inland waterways: 10,940 km
Ports: 5 principal, 8 minor
Civil air: about 19 major transport aircraft
Airfields: 538 total, 478 usable; 17 with permanent-sur-
face runways; 2 with runways 9,440-with 3,659 m; 43 with
runways 1,220-2,439 m, 1 with runway 2,750 m—Port
Moresby
Telecommunications: Papua New Guinea telecom serv-
ices are adequate and are being improved; principal telecom
centers include Goroka, Lae, Madang, Mount Hagen, and
Wewak in New Guinea; and Daru, Port Moresby and
Samarai in Papua; facilities provide radiobroadcast, radio-
telephone and telegraph, coastal radio, aeronautical radio
and international radiocommunication services; numerous
privately owned radio facilities exist; submarine cables
extend from Madang to Australia and Guam; 35,600
telephones, 110,000 radios, but no TV sets; 31 AM, no FM
and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 687,000; about 378,000
fit for military service
Supply: dependent on Australia
Military budget: for fiscal year ending 30 June 1976,
$22.3 million; 4.8% of central government budget','aa56e910f699eabefa6618be239cde86a5e27efe6815822746de66ebb582d4ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca5cf0e73da48a91f09fb3faf0c254d0bba87131e2dceb138583c9d18a86b187',1978,'PY','Paraguay','communications',414,'LAND
406,630 km?; 2% under crops, 24% meadow and pasture,
52% forested, 22% urban, waste, and other
Land boundaries: 3,444 km
Railroads: 1,043 km; 437 km standard gage (1.435 m),
136 km meter gage (1.00 m), 470 km various narrow gage
(privately owned)
Highways: 7,500 km; 900 km paved, 600 km gravel 6,000
km unimproved earth
Inland waterways: 3,100 km
Ports: 1 major (Asuncion), 9 minor {all river)
Civil air: 7 major transport aircraft
Airfields: 928 total, 801 usable; 1 with permanent-surface
runway; | with runway 2,440-3,659 m, 19 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: local telecom facilities in Asuncion
good, intercity microwave net; 38,400 telephones (1.4 per
100 popl.); 25 AM, 9 FM stations, and 1 TV station;
COMSAT station under construction
DEFENSE FORCES
Military manpower: males 15-49, 687,000; 518,000 fit for
military service; average number currently reaching mili-
tary age (17) annually, 33,000
Military budget: for fiscal year ending 31 December
1977, $36.1 million; about 15.4% of central government
budget','50b63efc1ddcf04b18ca1d8b8b63d8b10aba4aa61ad1ca497d173444da9a0223','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6457a9e5b09b86f495bfbb099dd823e9837ca371020d059de9d2aef02f030263',1978,'PE','Peru','communications',418,'Pacific
Ocean Bing
(See reference map til}
LAND
1,284,640 km? (other estimates range as low as 1,248,380
km*); 2% cropland, 14% meadows and _ pastures, 55%
forested, 29% urban, waste, other
Land boundaries: 6,131 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2.414 km
Railroads: 2,148 km; 1,776 km standard gage (1.435 m);
46 km 0.60-meter gage; 326 km 0.914-meter gage; 14 km
double track
Highways: 52,400 km; 5,400 km paved, 9,900 km gravel,
14,400 km improved earth, 22,700 km unimproved earth
Inland waterways: 8,600 km of navigable tributaries of
Amazon River system and 208 km Lake Titicaca
Pipelines: crude oil, 471 km; natural gas and natural gas
liquids, 64 km
Ports: 7 major, 20 minor
Civil air: 33 major transport aircraft (including 1 leased
in)
CIA-RDP79-01051A000900010004-4 Pe
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
PERU/PHILIPPINES
Airfields: 301 total, 301 usable: 25 with permanent-sur-
face runways; 2 with runways over 3,660 m, 20 with
runways 2,440-3,659 m, 45 with runways 1,220-2,439 m; 3
seaplane stations
Telecommunications: fairly adequate for most require-
ments; new nationwide radio-relay system; 1 Atlantic Ocean
satellite station; 410,000 telephones (2.5 per 100 popl.); 200
AM, 7 FM, and 31 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 3,695,000; 2,503,000 fit
for military service; average number currently reaching
military age (20) annually, 167,000
Military budget: for fiscal year ending 31 December
1977, $483 million; about 13.6% of central government
budget','14c25ab746d2cc2f8432f95716916855f0b73d1a9cf33fcbd0de71a657638e10','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1501f5703450dfb187523d0f8147bc5460606ca62dd7c7582087f7c932fe1a4',1978,'PL','Poland','communications',422,'LAND
312,354 km?; 49% arable, 14% other agricultural, 27%
forested, 10% other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
(See reference map IV}
Land boundaries: 3,090 km
WATER
Limits of territorial waters (claimed): 3 nm (3 nm
contiguous zone claimed in addition to the territorial sea)
(fishing 12 nm)
Coastline: 491 km
Railroads: 26,597 km; 23,255 km standard gage (1.435
m), 3,347 km narrow gage; 7,474 km double track; 5,558 km
electrified; government owned (1975)
Highways: 305,863 km; 65,000 km paved; 98,000 km
crushed stone, gravel; 142,863 km earth (improved and
unimproved) (1976)
Inland waterways: 3,759 km navigable streams and
canals (1977)
Pipelines: 3,540 km for natural gas; 1,408 km for crude
oil; 822 km for refined products
Freight carried: rail—455 million metric tons (1976),
130.1 billion metric ton/km (1975); highway—1,950 million
metric tons, 32.3 billion metric ton/km (1976): waterway—
16.6 million metric tons, 2.4 billion metric ton/km; excl.
int''l. transit traffic (1976)
Ports: 4 major (Gdansk, Gdynia, Szczecin, Swinoujscie), 6
minor (1977)
Fadera *Wroctaw
Bonn
eid
Repubiic
Varde -
Lux.
af Germany
Munich,
oe
ae
oe','6584cc995aea61aeea0fee97296d4037f3f27e81eca63eea316a0a904e09238b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('659412015f47ea925570fe3a923bcef64b6f11d2fd2d1c2f8a474c35363ffe67',1978,'PT','Portugal','communications',426,'Atlantic
(See reference map IV}
LAND
Metropolitan Portugal: 94,276 km?, including the Azores
and Madeira Islands; 48% arable, 6% meadow and pasture,
31% forested, 15% waste and urban, inland water, and other
Land boundaries: 1,207 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm); 200 nm exclusive economic zone
Coastline: 860 km (excludes Azores (708 km) and
Madeira (225 km))
Railroads: 3,593 km: state-owned Portuguese Railroad
Co. (CP) operates 2,807 km 1.665-meter gage (406 km
electrified and 426 km double track), 760 km meter-gage
(1.000 m); 26 km 1.665-meter gage double track, electrified,
privately-owned
Highways: 29,600 km; 17,600 km bituminous, bituminous
treatment, concrete and stoneblock; 11,520 km gravel and
crushed stone; 480 km improved earth: plus an additional
16,800 km of unimproved earth roads (motorable tracks)
Inland waterways: 820 km navigable; relatively unim-
portant to national economy, used by shallow-draft craft
limited to 297 metric ton cargo capacity
Pipelines: crude oil, 11 km
Ports: 6 major, 34 minor
Civil air: 28 major transport aircraft (including 1 leased
out)
Airfields including Azores and Madeira Islands): 50
total, 49 usable; 31 with permanent-surface runways; | with
runway over 3,660 m, 11 with runways 2,440-3,659 m, 9
with runways 1,220-2,439 m; 6 seaplane stations
Telecommunications: facilities are generally adequate;
1.11 million telephones (12.3 per 100 popl.); 39 AM, 34 FM,
and 42 TV stations; 6 submarine cables (including 2 coaxial);
I Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,256,000; 1,829,000 fit
for military service: average number reaching age (20)
annually, about 76,000
Military budget: for fiscal year ending 31 December
1977, $575.8 million; about 14% of central government
budget','ba9c614333f6034dff7a6b7dcc980992295ddadf9c5fa2e207a675a7565219c1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc64d5366208ad3d18c2e25795541ce93b796075397162323c3b37abac415128',1978,'QA','Qatar','communications',430,'LAND
About 10,360 km®*; negligible amount forested; mostly
desert, waste, or urban
“—
%
“5,
a)
Leize
5 BAHRAIN
: QATAR
Doha
(See reference mag V}
Land boundaries: 56 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 563 km
Railroads: none
Highways: 805 km; 442 km bituminous; 362 km gravel;
undetermined mileage of earth tracks
Pipelines: crude oil, 169 km; natural gas, 97 km
Ports: 1 major (Ad Dawhah), 1 minor
Airfields: 2 total, 1 usable; 2 with permanent-surface
runways, 1 with runway over 3,660 m
Civil air: 1 major transport aircraft, registered in the U.K.
Telecommunications: international telecom traffic is by
tropospheric scatter through Bahrain; fair domestic facilities;
21,000 telephones (11.0 per 100 polp.); 1 AM station, 1 FM
station, and 2 TV stations, 1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, about 41,000; about
24,000 fit for military service
Supply: mostly from U.K.
Military budget: for fiscal year ending 24 January 1974,
$53,680,900; 18% of central government budget
REUNION
Indian','eb339ba32a2ed7f291e360380e9db5ed487ff43b488c1f77b4fe862984782a18','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66782adbbd87ac1da77a5bbed216d6a96da3a4336d44d964db5700751eba1130',1978,'RO','Romania','communications',435,'LAND
237,503 km?; 44% arable, 19% other agriculture, 27%
forested, 10% other
Land boundary: 2,969 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 225 km
173
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
OMANIAY
ucharest
Black Sea
{See reference map {V)
Railroads: 12,048 km; 10,403 km standard gage (1.435
m), 1,632 km narrow gage, 13 km broad gage; 1,203 km
electrified, 1,999 km double track; government owned
(1976)
Highways: 77,949.km; 13,117 km paved; 26,232 km other
improved surfaces, 37,900 km earth (1976)
Inland waterways: 1,691 km (1977)
Pipelines: 2,735 km crude oil; 1,429 km refined products;
5,149 km natural gas
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Freight carried: rail—228.3 million metric tons, 64.8
billion metric ton/km (1975); highway—418.8 million
metric tons, 9.3 billion metric ton/km (1975); waterway—
7.9 million metric tons, 2.1 billion metric ton/km (1976)
Ports: 4 major (Constanta, Galati, Braila, Mangalia), 2
minor (1977)
DEFENSE FORCES
Military budget (announced): for fiscal year ending 31
December 1977, 13.6 billion lei; about 4.8% of total budget
Bucharest, Rlack Sea
} Bordeaux Belgrade,
Yugoslavia
Monacog_“
Be tos , OSaa Marine
“Marsoitio®-—~ \\ Ne
Andorra’ a =
yrome oe
\\,
Corsica Tirang
— ea,
‘Naples e
\\ ( ~~
© Balearic is. \\, Bi 3
yo “Barcelona
Wt 2
pane F
Sa pSicily
yiilaita
Valletta = Mediterranean
CX<C~ crete
Sea
oN
; Tuapse
Black Sea BS','f4b53fe631d27d8da1e7456844ef8df7d7bff57c406110bec2be71975c657100','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac657d7b7120ed530a70b507e234ada3410580518af1e8377d97bb2ab23956e4',1978,'RW','Rwanda','communications',439,'{See reference map Vi}
LAND
25,900 km?2; almost all the arable land, about 1/3 under
cultivation, about 1/3 pastureland
Land boundaries: 877 km','d97996c4059952973cbb841e5f0f51a27169defaf08b05561be37cae227ff9e1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef1ba704c60e3b2260f10e8c968855916fccbe0751d3b5dd03ba1e6fc606c443',1978,'SM','San Marino','communications',443,'LAND
62 km?; 74% cultivated, 22% meadows and pastures, 4%
built-on
ne Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Mediterranean Sea
(See reference map (¥}
Land boundaries: 34 km
Railroads: none
Highways: about 104 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serv-
ing 5,600 telephones (26.1 per 100 popl.); no radiobroadcast-
ing or television facilities','6b1906f828f276bcf9549244783e9edf7c66e9c5de5c45f98795b2512a77f4b1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31bb9a6401240119916056d271ae9339771d93654f99b0d96d33935508ca8b29',1978,'ST','Sao Tome and Principe','communications',447,'SAO TOME
AND
PRINCIPE) *
Sie Toms™ sone |
Atlantic Ocean
(See reference map V)
LAND
964 km? (Sao Tome, 855 km? and Principe, 109 km?;
including small islets of Pedras Tinhosas)
WATER
Limits of territorial waters: 6 nm (fishing 12 nm)
Coastline: estimated 209 km
Ports: 1 major (Sao Tome)
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m
Telecommunications: minimal system; 657 telephones
(0.9 per 100 popl.); 2 AM, 1 FM, and no TY stations','f592fc5c9d388cf037f9c285e42ee866914ba2f83bb508e49bfdae5eeaee4e9e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6074b89a656b3a2f3fe2339a591491e838e36059e166186fc6cd11d464946de7',1978,'SA','Saudi Arabia','communications',451,'Arabian
Sea
(See reference map V)
LAND
Estimated at about 2,331,000 km? (boundaries undefined
and disputed); 1% agricultural, 1% forested, 98% desert,
waste, or urban
Land boundaries: 4,537 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone”)
Coastline: 2,510 km
Railroads: 575 km standard gage (1.435 m)
Highways: 17,850 km; 10,750 km bituminous, 7,100 km
gravel and improved earth, undetermined kilometers of
earth roads and _ tracks
Pipelines: 2,480 km crude oil; 386 km refined products:
98 km natural gas
Ports: 3 major (Jidda, Ad Damman, Ras Tanura), 6 minor
Civil air: 62 major transport aircraft (including 13 leased
in or US. registry)
Airfields: 114 total, 89 usable; 26 with permanent-surface
runways; 17 with runways 2,440-3,659 m, 39 with runways
1,220-2,4839 m, 4 with runways over 3,660 m
Telecommunications: fair system exists, major expansion
program underway with microwave, coaxial cable, satellite
systems; 200,000 telephones (2.5 per 100 popl.); 6 AM, 1 FM,
11 TV stations 2 submarine cables; 2 Intelsat stations, several
domestic satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 1,810,000; 1,022,000 fit
for military service; about 66,000 reach military age (18)
annually
Military budget: for fiscal year ending 1 July 1977,
$11,569,000; about 37% of central government budget
é
Oman ./)
} moran, 5
M7
Arabian Sea
“>
pecs
Djibouti Socotra','79048b2f7f8e4c956c8b3e343fa74bb592a179831025d56a0e55de357c1c4051','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d36deb47480513f6d780c741c67fd75825f5135fc17cb5a2c2fe4bbd330119f',1978,'SN','Senegal','communications',455,'THE GAM&IA Somes
GUINEAS
BISSAU
Atlantie
Qeean
(See reference map VI}
LAND
196,840 km’; 13% forested, 40% agricultural (12%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 2,680 km
182 Approved For Release 2005/04/22 :
WATER
Limits of territorial waters (claimed): 150 nm (fishing
200 nm); 200 nm exclusive economic zone
Coastline: 531 km
Railroads: 1,033 km meter gage (1.00 m); 64 km double
track
Highways: 13,589 km; 2,549 km bituminous, 11,042 km
improved and unimproved earth
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Inland waterways: 1,505 km
Ports: 1 major (Dakar), 2 minor
Civil air: 5 major transport aircraft
Airfields: 27 total, 27 usable; 11 with permanent-surface
runways; 1 with runway 2,440-8,659 m, 19 with runways
1,220-2,489 m; 3 seaplane stations
Telecommunications: relatively advanced for Africa;
37,500 telephones (0.9 per 100 popl.); 3 AM stations, no FM
station, and 1 TV station; 4 submarine cables, 1 Atlantic
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,179,000, 609,000 fit
for military service; 48,000 reach military age (18) annually','ef8f52f62fbf1b1e4c6c5240e7ba54f52be3ba5c261987da645bf3877cb66985','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cfa724b89587eeb9ba463208992ee0e9c8c60d804cb9d7f89152c021b7cf0c8',1978,'SC','Seychelles','communications',459,'ea
Indian Ocean ~
acetal Pare
a.
Railroads: none
Highways: 215 km; 145 km bituminous, 70 km crushed
stone or earth
Ports: 1 small port (Victoria)
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable (on Praslin Island, Astove
Island, Bird Island, Mahe Island); with 1 permanent-surface
runway 2,440-3,659
Telecommunications: direct radiocommunications with
adjacent islands and African coastal countries; 2,860
telephones (5.6 per 100 popl.); 16,000 radio, and no TV sets;
2 AM, no FM, and no TV stations; submarine cables to Sri
Lanka; Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 14,000; 7,000 fit for
military service
Supply: infantry-type weapons and ammunition from
Tanzania
Victoria,’
‘ananarivo','867a72406eead5f09bf9854a2a4877d3e705b0b107c231dc649fb378d4adb43f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4d970bd42ea97f30a03420524d2cf579fb8c4163580640e684534280362aa70',1978,'SL','Sierra Leone','communications',463,'LAND
72,261 km?; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
Land boundaries: 933 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 402 km
Railroads: about 84 km narrow gage (1.067 m) privately
owned mineral line operated by the Sierra Leone Develop-
ment Company
Highways: 7,073 km; 1,148 km bituminous, 507 km
laterite (some gravel), and 5,418 km improved earth
Inland waterways: 800 km; 600 km navigable year-round
Ports: 1 major (Freetown), 2 minor
Civil air: 1 major transport aircraft
Airfields: 16 total, 16 usable; 6 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 5 with runways
1,220-2,4839 m; 1 seaplane station
185
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
STERRA LEONE/SINGAPORE
Telecommunications: telephone and telegraph are ade-
quate; 11,000 telephones (0.4 per 100 popl.); 2 AM stations,
no IM, and 1 TV station; 1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 660,000; 317,000 fit for
military service; no conscription
Military budget: for year ending 80 June 1978,
$11,379,310 (excluding procurement funds); 8.5% of central
government budget','ad0d1f4c9211a676d313e4bfb613372a6b36bee008202f65360d1bf69c685c84','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('352cc6329656cbbfbd55844fc40a2b274c7942f1d0c464cc36d174b4a200b434',1978,'SO','Somalia','communications',469,'Indian
Ocean
{See reference map VI)
LAND
637,140 km?; 13% arable (0.3% cultivated), 32% grazing,
14% scrub and forest, 41% mainly desert, urban, or other
Land boundaries: 2,263 km
Approved For Release 2005/04/22
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 3,025 km
Railroads: none
Highways: 13,541 km; 936 km paved, 770 km crushed
stone, gravel, or stabilized soil, 11,835 km improved or
unimproved earth (est.)
Ports: 3 major (Mogadiscio, Berbera, Chisimaio)
Civil air: 6 major transport aircraft
Airfields: 55 total, 50 usable; 6 with permanent-surface
runways; 2 with runways over 3,660 m; 3 with runways
2,440-3,659 m; 15 with runways 1220-2,439 m
Telecommunications: telephone poor, telegraph fair;
6,000 telephones (0.2 per 100 popl.); 2 AM, no FM, L TV
station
DEFENSE FORCES
Military manpower: males 15-49, 786,000; 435,000 fit for
military service; no conscription
Military budget: for fiscal year ending 31 December
1976, 34,650,357; 17.3% of central government budget','02b253d851bb5a1c1ca86d98fbfe714f8c6838cf1005ae509d85f62cd4d718b2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d56a5c840f0411f98e01ecb285758d6835efc4d50c028d002ed83c18a5eabca',1978,'ZA','South Africa','communications',473,'{See raference map Vij
NOTE: separate data on Transkei follows last entry for
LAND
1,222,480 km? (includes enclave of Walvis Bay, 1,124 km?
and Transkei 44,000 km?2); 12% cultivable, 2% forested, 86%
desert, waste, or urban
Land boundaries: 2,044 km
ate Approved For Release 2005/04/22
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 2,881 km including Transkei
Railroads: 22,432 km; 21,726 km 1.067-meter gage of
which 2,567 km are multiple track; 4,921 km electrified; 706
km 0.160-meter gage single track
Highways: 209,244 km; 57,368 km paved, 148,786 km
crushed stone, gravel, or improved earth, 3,090 km
unimproved earth
Pipelines: 836 km crude oil; 1,048 km refined products;
322 km natural gas
Ports: 8 major
Civil air: 89 major transport aircraft
Airfields: 662 total, 523 usable; 63 with permanent-sur-
face runways; 2 with runway over 3,660 m, 7 with runways
2,440-3,659 m, 130 with runways 1,220-2,439 m
Telecommunications: the system is the best developed,
most modern, and highest capacity in Africa and consists of
carrier-equipped open-wire lines, coaxial cables, radio-relay
links, and radiocommunication stations, key centers are
Bloemfontein, Cape Town, Durban, Johannesburg, Port
Elizabeth, and Pretoria; 2.1 million telephones (8.1 per 100
popl.); 13 AM, 84 FM, and 34 TY stations; 1 submarine
cable; 1 satellite station with Atlantic Ocean and Indian
Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 6,006,000; 3,666,000 fit
for military service; obligation for service in Citizen Force
begins at 18; volunteers for service in permanent force must
be 17
Military budget: for year ending 31 March 1978, $1.9
billion; 18.8% of central government budget
Transkei
NOTE: Formerly an autonomous tribal homeland in
South Africa, Transkei was granted independence by South
Africa on 26 October 1976, but has not been recognized by
any other government or any international organization. It
remains heavily dependent on South Africa for administra-
tive and economic support.
LAND
44,000 km? in one large and two small pieces separated
from each other by parts of South Africa
Land boundaries: 1,200 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 250 km
189
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Railroads: less than 160 km
Highways: 725 km paved, 7,768 km unpaved
Ports: none; Transkei dependent on the South African
port of East London
DEFENSE FORCES
Military manpower: males 15-49, 215,000
Personnel: 254 army (including 7 officers)
Major ground units: 1 infantry battalion','00c315dad349a7d12fadaec7db58159dace853a78f2d169cc3a7f38b99b5ea76','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d6114981733d1e3825b1da4fa4000724551f99f256ddab0844a90d464a230cf',1978,'ES','Spain','communications',478,'Atlantic
Ocean
»
CANARY
(SLANDS
%e
(See reference map (IV)
LAND
505,050 km’, including Canary (7,511 km?) and Balearic
Islands (5,025 km?); 41% arable and land under permanent
crops, 27% meadow and pasture, 22% forest, 10% urban or
other
Land boundaries: 1,899 km
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4,964 km (includes Balearic Islands, 677 km,
and Canary Islands, 1,158 km)
Railroads: 15,975 km; Spanish National Railways
(RENFE) operates 19,509 km 1.668-meter gage, 4,328 km
electrified and 2,081 km double track; FEVE (government-
owned narrow gage railways) operates 1,676 km, of
predominantly meter gage (1.000 m) and 310 km electrified;
privately-owned railways operate 790 km, of predominantly
meter gage (1.000 m), 245 km electrified and 56 km double
track
Highways: 138,560 km national—56,280 km bituminous
treatment, 15,040 km crushed stone, 6,760 km bituminous,
stone block and concrete; provincial—29,120 km bituminous
treatment, 29,440 km crushed stone, 1,920 km bituminous,
concrete, and stone block
Inland waterways: 1,045 km: of minor importance as
transport arteries and contribute little to economy
Pipelines: 386 km crude oil; 1,030 km refined products;
98 km natural gas
Ports: 23 major, 150 minor
Civil air: 171 major transport aircraft (including 4 leased
in and 2 leased out)
Airfields (including Balearic and Canary Islands): 94
total, 87 usable; 51 with permanent-surface runways; 3 with
runways over 3,660 m, 19 with runways 2,440-3,659 m, 33
with runways 1,220-2,439 m; 4 seaplane stations
Telecommunications: generally adequate, modern facili-
ties; 8.0 million telephones 22.0 per 100 popl.); 170 AM, 238
FM, and 791 TV stations; 11 coaxial submarine cables; 4
communication satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 8,799,000; 6,768,000 fit
for military service; 301,000 reach military age (20) annually
Military budget: for fiscal] year ending 31 December
1977, $3,514 million; about 24.7% of the proposed central
government budget','982da71f947b3f5f3c636da6336ab0c3ed95ca80be7a0807f8c013e397ec1969','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('812523a5a3221853f5c60c9f2da4d8f48bc193125762c83a5a6500fa5feeeb7e',1978,'LK','Sri Lanka','communications',481,'(formerly Ceylon)
LAND
65,500 km?; 25% cultivated; 44% forested; 31% waste,
urban, and other
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Arabian. -
Sea Bay”
of Bengal,
SAI
oe
_ Colomha ‘a
Indian Ocean
(See reference map Vii}
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm, plus pearling in the Gulf of Mannar); 200 nm exclusive
economic zone
Coastline: 1,340 km
Railroads: 1,535 km; 1,395 km 1.676-meter gage, 140 km
0.762-meter gage; 102 km double track; no electrification;
government owned
Highways: 52,200 km (1975); 24,300 km paved (mostly
bituminous treated), 18,800 km crushed stone or gravel,
9,400 km improved earth or unimproved earth; in addition
several thousand km of tracks, mostly unmotorable
Inland waterways: 430 km; navigable by shallow-draft
craft
Ports: 3 major, 9 minor
Civil air: 8 major transport (including 1 leased)
Airfields: 14 total, 10 usable; 10 with permanent-surface
runways, 1 with runway 2,440-3,659 m, 7 with runways
1,220-2,489 m
Telecommunications: an inadequate telephone and a less
extensive but more efficient telegraph system serves most
areas, with greatest concentration around Colombo and
Kandy; all areas are served by radio and/or wire broadcast:
good international service; 72,000 (est.) telephones; 530,000
radio sets, 500 TV sets; 11 AM stations, 2 FM stations, and |
TV station; submarine cables extend to India, Malaysia,
Seychelle Islands, and Aden; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,477,000; 2,619,000 fit
for military service; 158,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1977, $23.1 million, 2% of central government budget','ce50d376c08bdf59215fe3629cc7aba24cd657513e066b063685604866108f22','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd0d41ce634149429f50ae45f3bbed7529bf1f803ade9756e690d762f45f1600',1978,'SD','Sudan','communications',485,'LAND
2,504,530 km*; 37% arable (3% cultivated), 15% grazing,
33% desert, waste, or urban, 15% forest
Land boundaries: 7,805 km
i Approved For Release 2005/04/22
Khartoum ,
{See reference map Vi}
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’’)
Coastline: 853 km
Railroads: 5,466 m; 4,754 km 1.067-meter gage, 716 km
1.6096-meter gage plantation line
Highways: 10,560 km; 310 km bituminous-treated, 1,100
km crushed stone or gravel, and 9,150 km improved and
unimproved earth roads; in addition, there are an undeter-
mined number of tracks
Inland waterways: 5,310 km navigable
Pipelines: refined products, 800 km
Ports: 1 major (Port Sudan)
Civil air: 10 major transport aircraft
Airfields: 77 total, 72 usable; 8 with permanent-surface
runways; 3 with runways 2,440-8,659 m, 30 with runways
1,220-2,489 m
Telecommunications: large system by African standards,
but barely adequate; consists of radio relay, cables,
radiocommunications, and troposcatter; domestic satellite
system with 14 stations under construction, centers are
Khartoum, Al Fashir, Port Sudan; 56,000 telephones (0.3 per
100 popl.); 2 AM, no FM, and 2 TV stations; 1 submarine
cable; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 4,189,000; 2,567,000 fit
for military service; average number reaching military age
(18) annually, 201,000
Military budget: for fiscal year ending 30 June 1978,
$237,000,000; 11% of central government budget
SURINAM
Caribbean 3
Sea Atlantic
Ocean
(See reference map Ill)
LAND
142,709 km?; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially
productive, 16% built-on area, wasteland, and other
Land boundaries: 1,561 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 i
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SURINAM
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 386 km
Railroads: 166 km; 86 km meter gage (1.00 m)
(government-owned) and 80 km narrow gage (industrial
lines); all single track
Highways: 2,500 km; 500 km paved, 200 km gravel, 600
km improved earth, 1,200 km unimproved earth
Inland waterways: 4,500 km; most important means of
transport; oceangoing vessels with drafts ranging from 4.2 m
to 7 m can navigate many of the principal waterways while
native canoes navigate upper reaches
1 Surinam guilder (S.
Ports: 1 major (Paramaribo), 6 minor
Civil air: 1 major transport aircraft
Airfields: 30 total, 29 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 3 with runways
1,220-2,489 m; 1 seaplane station
196 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SURINAM /SWAZILAND
Telecommunications: international facilities good; do-
mestic radio-relay system; 17,000 telephones (4.2 per 100
popl.); 6 AM, 1 FM, and 1 TV station with 4 relay
transmitters
DEFENSE FORCES
Military manpower: males 15-49, 102,000; 60,000 fit for
military service
SWAZILAND
ct
{See reference map VI)
LAND
17,364 km?; most of area suitable for crops or pastureland
Land boundaries: 485 km
Railroads: 222 km 1.067-meter gage, single track
Highways: 2,653 km; 224 km paved, 1,114 km crushed
stone, gravel, or stabilized soil, and improved earth
Civil air: 6 major transport aircraft
Airfields: 32 total, 26 usable; 1 with runway 1,220-
2,489 m
Telecommunications: system consists of a few open-wire
lines and low-powered radiocommunication stations; Mba-
bane is the center; 7,500 telephones (1.5 per 100 popl.); 1
AM, 1 FM, no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 117,000; 69,000 fit for
military service :','21dfc9cbeff7009cfb3bd71c1b8f0a45814e14b23e41c48ca38ffd5d7ea8e45f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9fc490e693e2145fad4fdfd69c3f21828d84120b79249f85a117a0b915e5cd5',1978,'SE','Sweden','communications',489,'Norwegian
(See reference mag tV}
LAND
448,070 km?; 8% arable, 1% meadows and pastures, 55%
forested, 36% other
Land boundaries: 2,196 km
WATER
Limits of territorial waters (claimed): 4 nm (fishing 12
nm)
Coastline: 3,218 km
Railroads: 11,943 km; Swedish State Railways (SJ)—
11,179 km standard gage (1.435 m), 6,959 km electrified and
1,152 km double track; 182 km 0.891-meter gage; privately-
owned railways—472 km standard gage (1.485 m) and 300
km electrified; 110 km 0.891-meter gage electrified
Highways: 96,640 km; 67,680 km are crushed stone,
gravel, or improved earth; and 28,960 km are bitumen,
concrete, stone block, or cobblestone
Inland waterways: 2,052 km navigable for small steamers
and barges
Ports: 17 major, and 30 minor
Civil air: 66 major transports (including 1 leased in)
Airfields: 248 total, 240 usable; 132 with permanent-
surface runways; 7 with runways 2,440-3,659 m, 87 with
runways 1,220-2,439 m
Telecommunications: excellent domestic and interna-
tional facilities; 5.37 million telephones (66.1 per 100 popl.);
9 AM, 91 FM, and 240 TV stations; 10 submarine cables,
including 4 coaxial; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,881,000; 1,670,000 fit
for military service; 55,000 reach military age (19) annually
Military budget: for fiscal year ending 30 June 1977,
$2.64 billion; about 10% of central government budget','674ac4e3be79af7ddb887e952af750c163276aa52556c12304ded67c0df11afd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6adb31b51ac5c98c6cdb811405a9efe437766a1d99c906d0c8b34facd1e5913c',1978,'TH','Thailand','communications',496,'LAND
512,820 km?; 24% in farms, 56% forested, 20% other
Land boundaries: 4,868 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 3,219 km
Railroads: 3,833 km meter gage (1.00 m), 97 km double
track
Highways: 28,806 km; 14,773 km paved, 4,731 km
crushed stone or gravel, 9,302 km earth and laterite
Inland waterways: 3,999 km principal waterways; 3,701
km with navigale depths of 0.9 m or more throughout the
year; numerous minor waterways navigable by shallow-
draft native craft
Ports: 2 major, 16 minor
Civil air: 25 major transport aircraft
Airfields: 154 total, 153 usable; 55 with permanent-
surface runways; 10 with runways 2,440-3,659 m, 28 with
runways 1,220-2,489 m
Telecommunications: service to general public improved,
but inadequate; bulk of service to government activities
provided by radiocommunication stations and radio-relay
network; satellite ground station; 312,000 telephones; over 3
million radios; and over 650,000 televisions; approx. 110 AM,
30 FM, and 10 TV stations in government-controlled
networks
DEFENSE FORCES
Military manpower: males 15-49, 11,244,000; 6,844,000
fit for military service; about 503,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1977, $723.4 million; 17.8% of central government budget
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','a65a2c627916141ea8ad8034ee9f4667cbaf9df75b8159fd9c8c990d21bd98a3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7c666f96a9d30e09425f239a0bbe769b8ed75a28bed959c55e9f3e8fa911cea',1978,'TG','Togo','communications',500,'Gulf of Guinea
{See reference map Vi)
LAND
56,980 km?; nearly one-half is arable, under 15%
cultivated
Land boundaries: 1,646 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 56 km
Railroads: 442 km meter gage (1.00 m), single track
Highways: approx. 6,974 km; 1,208 km paved, 166 km
improved earth, 4,600 unimproved earth
205
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
TOGO/TONGA
Inland waterways: section of Mono River and about 50
km of coastal lagoons and tidal creeks
Ports: | major (Lome), 1 minor
Civil air: 3 major transport aircraft
Airfields: 11 total, 11 usable; 1 with permanent-surface
runway 2,440-3,659 m
Telecommunications: fair system based on_ skeletal
network of open-wire lines supplemented by a radio relay
route radiocommunication stations; only center is Lome;
6,100 telephones (0.3 per 100 popl.); 2 AM stations, 1 FM
radio station, 3 TV station
DEFENSE FORCES
Military manpower: males 15-49, 540,000; 279,000 fit for
military service; no conscription
Supply: most military materiel obtained from France
Military budget: for fiscal year ending 31 December
1977, $18,533,935; 8.3% of central government budget','e4917d687c7cc882204c12f1b6ea0922d13b1a240c09bc40582e97be4d971936','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b11ea6feaf7b63ac35db1e53c9b28d0e90103bb0f00151876a19e73b8081a364',1978,'TO','Tonga','communications',504,'Ms ‘2:
iS Fil - TONGA
NEWS" * Nuku''alofa
CALEDONIA
Pacific Ocean
NEW
ZEALAND’
)
(See reference map Vitt}
LAND
997 km? (150 islands); 77% arable, 3% pasture, 13% forest,
8% inland water, 4% other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 419 km (est.)
Railroads: none
Highways: 249 km (1974); 177 km rolled stone; 72 km
coral base
Ports: 2. minor
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable; 1 with grass runway
1,220-2,439 m; 1 seaplane station
Telecommunications: 1,250 telephones; 11,000 radio sets:
no TV sets; 1 AM_ station
206 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','5797776ea148a9e7cf8ccbdf5b26dc013ee302d98fd93d71e6cea74a113bbbfd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8555e28eb0e50285061babee80b16c749febe8fa9e800d1427a992a988f7628e',1978,'TT','Trinidad and Tobago','communications',508,';
&
a
%
e
Caribbean Sea Atlantic Ocean
Ko Port,
» Spain - TRINIDAD
8 AND TOBAGO
(See reference map it)
LAND
5,128 km?; 41.9% in farms (25.7% cropped or fallow, 1.5%
pasture, 10.6% forests, and 4.1% unused or built-on), 58.1%
outside of farms, including grassland, forest, built-up area,
and wasteland
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 362 km
Railroads: none
Highways: 3,100 km; 2,800 km paved, 200 km gravel, 100
km improved earth
Pipelines: 430 km crude oil; 19 km refined products; 209
km natural gas
Ports: 3 major (Port of Spain, Chaquaramars Bay, Point
Tembladora), 6 minor
Civil air: 10 major transport aircraft
Airfields: 8 total, 7 usable; 4 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m; 2 seaplane stations
Telecommunications: excellent international service via
tropospheric scatter links to Barbados and Guyana; good
local service; 1 Atlantic Ocean satellite station; 68,600
telephones (6.3 per 100 popl.); 2 AM, 2 FM, and 3 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 261,000; 184,000 fit for
military service
Supply: mostly from U.K.
“Military budget: proposed for fiscal year ending 31
December 1977, $48.4 million; about 4.8% of central
government budget','ee4c1c558af84cccdf7e2b41fdf630fa60cdb96ac68d069aeab33a69dd5f75b1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('992a14ed120fbaa819c69d855bcc6bba6b6a7a0625b962865c38fb5c2b8e9764',1978,'TN','Tunisia','communications',512,'LAND
164,206 km?; 28% arable land and tree crops, 23% range
and esparto grass, 6% forest, 43% desert, waste or urban
Land boundaries: 1,408 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 12
nm exclusive fisheries zone follows the 50-meter isobath for
part of the coast, maximum 65 nm)
Coastline: 1,143 km (includes offshore islands)
one Approved For Release 2005/04/22
(See reference map Vi)
Railroads: 2,089 km; 503 km standard gage (1.435 m),
1,586 km meter gage (1.00 m)
Highways: 16,093 km; 10,646 km bituminous 483 km
gravel; 1,609 km improved earth; 3,355 km unimproved
earth
Pipelines: 797 km crude oil; 10 km refined products, 72
km natural gas
Ports: 4 major, 8 minor
Civil air: 12 major transport aircraft
Airfields: 34 total, 29 usable; 11 with permanent-surface
runways; 3 with runways 2,440-3,659 m; 15 with runways
1,220-2,439 m; 1 seaplane station
Approved For Release 2005/04/22
Telecommunications: the system is above the African
average in amount and capacity of facilities which consist of
open-wire lines with multiconductor cable or radio relay on
trunk routes; key centers are Safaqis, Susah, Bizerte, and
Tunis; 127,000 telephones (2.3 per 100 popl.); 3 AM, 3 FM,
and 7 TV stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 1,547,000; 850,000 fit
for military service; about 59,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1977, $369,000,000; 20% of central government budget
TURKEY
Black Sea
a
+ Ankara
TURKEY
a
ood
., Mediterranean Sea CYPRUS
(See reference map V}
LAND
766,640 km?; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km
Railroads: 8,253 km standard gage (1.435 m); 143 km
double track; 72 km electrified
Highways: 60,000 km; 21,000 km bituminous; 28,000 km
gravel or crushed stone; 2,500 km improved earth; 8,500 km
unimproved earth
Inland waterways: approx. 1,689 km
Pipelines: 1,288 km crude oil; 2,055 km refined products
Ports: 10 major, 35 minor
Civil air: 23 major transport aircraft (including one leased
in)
Airfields: 120 total, 101 usable; 56 with permanent-
surface runways; 3 with runways over 3,660 m, 22 with
runways 2,440-3,659 m, 22 with runways 1,220-2,439 m
Telecommunications: new trunk domestic radio-relay
net, good international service; 1,023,000 telephones (2.5 per
100 popl.); 40 AM, 4 FM, and 36 TV stations; 1 submarine
cable
DEFENSE FORCES
Military manpower: males 15-49, 10,665,000; 6,282,000
fit for military service; about 461,000 reach military age (20)
annually
Military budget: proposed for fiscal year ending 28
February 1978, $2,652 million; about 20.8% of proposed
central government budget','fee3ea11838b8c371300bc42506e5f5737820a3ac98e3ac41ebad14067e5a7b4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('392842c6c9917d566b13eceb856767b099f35d7b77ae9863f259a2d6a102b7af',1978,'TV','Tuvalu','communications',516,'(formerly Ellice Islands)
NOTE: On October 1, 1975, by Constitutional Order, the
Ellice Islands were formally separated from the British
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
TUVALU/UGANDA
UNITED"
4 STATES
Pacific Ocean
GILBERT
*, , SSLANDS
sey -, TUVALU
~
(See reference map Vill)
colony of Gilbert and Ellice Islands, thus forming the new
colony of Tuvalu. The remaining islands in the former
Gilbert and Ellice Islands Colony were renamed the Gilbert
Islands.
The new colony of Tuvalu includes the islands of
Nanumanga, Nanumea, Nui, Niutao, Vaitupu, and those
islands claimed by the United States: Funafuti, Nukufetau,
Nukulailai, and Nurakita.
LAND
26 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 24 km
Railroads: none
Highways: 8 km gravel
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 1 total; 1 usable with runway 1,220-2,439 m; |
seaplane station
Telecommunications: 1 AM _ station; about 300 tele-
phones; 4,000 radio sets
Indian
Ocean
a
{See reference map Vi)
LAND
235,690 km?; 21% inland water and swamp, including
territorial waters of Lake Victoria, about 21% cultivated,
13% national parks, forest, and game reserves, 45% forest,
woodland, and grassland
Land boundaries: 2,680 km
Railroads: 1,216 km, meter gage (1.00 m), single track
Highways: 6,763 km; 1,934 km paved; 4,829 km crushed
stone, gravel, and laterite; remainder earth roads and tracks
(est.)
Inland waterways: Lake Victoria, Lake Albert, Lake
Kyoga, Lake George, and Lake Edward (9,670 km); Kagera
River and Victoria Nile (610 km)
Civil air: 4 major transport aircraft
Airfields: 50 total, 48 usable; 5 with permanent-surface
runways; | with runway over 3,660 m, 3 with runways
2,440-3,659 m, 12 with runways 1,220-2.439 m
a Approved For Release 2005/04/22
Telecommunications: fair system based on open wire
lines and low-capacity radio relay links; 46,000 telephones
(0.4 per 100 popl.); 6 AM, no FM, 6 TV stations; 1 Atlantic
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, about 2,763,000; about
1,485,000 fit for military service
See reference map Vil)
LAND
22,274,000 km?; 9.3% cultivated, 37.1% forest and brush,
2.6% urban, industrial, and transportation, 16.8% pasture
and natural hay land, 34.2% desert, swamp, or waste
Land boundaries: 20,619 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 46,670 km (incl. Sakhalin)
Railroads: 138,776 km; 136,943 km broad gage (1.524 m);
1,833 km narrow gage (mostly 0.750 m); 109,316 km broad
gage single track; 90,294 km electrified; does not inclyde
industrial lines (1975)
Highways: 1,564,000 km; 322,000 km paved; 372,000 km
gravel, crushed stone; 870,000 km improved or unimproved
earth (1976)
Inland waterways: 146,400 km navigable, exclusive of
Caspian Sea (1976)
Pipelines: 56,000 km crude oil; 13,000 km refined
products; 114,000 km natural gas
Ports: 52 major (most important: Leningrad, Murmansk,
Odessa, Novorossiysk, Ilichevsk, Vladivostok, Nakhodka,
Arkhangel’sk, Riga, Tallinn, Kaliningrad, Liepaja, Ventspils,
Nikolayev, Sevastopol); 116 selected minor (1977)
Freight carried: rail—3,621 million metric tons, 3,236.5
billion metric ton/km (1975); highways—22.1 billion metric
tons, 360.0 billion metric ton/km (1976); waterway—484.9
million metric tons, 222.7 billion metric ton/km, excluding
Caspian Sea (1976)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 213
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','866e4629fad4a7e3558a70414d97f2157276122d94eeb03f1a4eddfe61407c4e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('535ae43017288a514813dd33668d9d54c0f67df2a458261b1e9955a07a251c8e',1978,'AE','United Arab Emirates','communications',520,'(See reference map V}
LAND
82,880 km?; almost all desert, waste or urban
Land boundaries: 1,094 km (does not include boundaries
between adjacent U.A.E. states)
WATER
Limits of territorial waters (claimed): 3 nm for all states
except Sharjah (12 nm)
Coastline: 1,448 km
Railroads: none
Highways: 780 km bituminous, undetermined mileage of
earth tracks
Pipelines: 282 km crude oil
Ports; 8 major, 1 minor
Civil air; 4 major transport aircraft
Airfields: 56 total, 40 usable; 12 with permanent-surface
runways; 3 with runways over 3,660 m, 1 with runway
2,440-3,659 m, 8 with runways 1,220-2,439 m
Telecommunications: system is adequate; key centers are
Abu Dhabi and Dubai; 44,300 telephones (7.3 per 100 popl.);
4 AM, 2 FM, and 3 TV stations; 2 COMSAT ground stations
DEFENSE FORCES
Military manpower: males 15-49, 180,000; 90,000 fit for
military service
a Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
UNITED ARAB EMIRATES/UNITED KINGDOM
Personnel: 22,900 Army, 550 Air Force, 400 Navy, and
6,600 Paramilitary','094d184a54f2415441380b9424051b2c46907400be9f36da1f3ca424482b2307','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6453f98230d86046caf46a9ab0ac271657d7c04303bec85976b874109fe0221b',1978,'GB','United Kingdom','communications',524,'Atlanti¢
Ocean
(See reference map 1V¥}
LAND
243,978 km?; 30% arable, 50% meadow and pasture, 12%
waste or urban, 7% forested, 1% inland water
Land boundaries: 360 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 12,429 km
Railroads: Great Britain—18,287 km; British Railways
(BR) operates 18,012 km standard gage (1.435 m) (3,806 km
electrified, 11,410 km double track, 2,366 km multiple
track) and 19 km 0.597-meter gage; 256 km of standard
gage (1.435 m) and several narrow gages are privately-
owned; Northern Ireland Railways (NIR) operates 327 km
1.600-meter gage, 190 km double track
Highways: approx. 343,315 km paved and 23,175 km in
Northern Ireland, 22,227 km paved; 949 km gravel
Inland waterways: 1,770 km of commercial routes
Pipelines: 933 km crude oil, almost all insignificant; 2,907
km refined products; 1,770 km natural gas
Ports: 23 major, 350 minor
Civil air: 503 major transport aircraft
Telecommunications: modern, efficient domestic and
international system; 22.4 million telephones (37.5 per 100
popl.); excellent countrywide broadcast; 97 AM, 118 FM,
and 800 TV stations; 45 submarine cables (42 coaxial); 1
earth satellite station with 2 Atlantic Ocean antennas and |
Indian Ocean antenna
DEFENSE FORCES
Military manpower: males 15-49, 12,715,000; 10,738,000
fit for military service; no conscription; 448,000 reach
military age (18) annually
Military budget: proposed for fiscal year ending 31
March 1978, $10.8 billion; about 14.5% of central govern-
ment budget
UPPER VOLTA
Atlantic
Ocean
(See reference map Vi)
LAND
274,540 km*; 50% pastureland, 21% fallow, 10% culti-
vated, 9% forest and scrub, 10% waste and other uses
Land boundaries: 3,307 km
Railroads: 1,173 km, 516 km meter gage (1.00 m), single
track; Ouagadougou to Abidjan, Ivory Coast line
Highways: approximately 16,320 km; 520 km _ paved,
3,600 km improved, 12,200 km unimproved
Civil air: no major transport aircraft
Airfields: 55 total, 54 usable; 2 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: all services generally poor; 3,400
telephones (0.1 per 100 popl.); 3 AM stations, 1 FM station,
and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 1,478,000; 739,000 fit
for military service; no conscription
Supply: mainly dependent on France
Military budget: for fiscal year ending 31 December
1976, $18,243,900; 19.7% of central government budget','9a7deb119095970d96462886dfdf41a038bdfabc3e361890a7b79da40a0eca0e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cf778fb7364001cc2df0b5971f9c8f97678ad2d368a3badcfea7309833bd939',1978,'UY','Uruguay','communications',528,'Atlantic
x
Montevideo Ocean
(See ceference map IV)
LAND
186,998 km’; 84% agricultural land (73% pasture, 11%
cropland), 16% forest, urban, waste and other
Land boundaries: 1,352 km
WATER
Limits of territorial waters (claimed): 200 nm (fishing
200 nm)
Coastline: 660 km
217
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Railroads: 2,795 km, all standard gage (1.435 m) and
government owned
Highways: 15,700 km; 10,000 km paved, 2,700 km gravel,
3,000 km improved earth
Inland waterways: 1,600 km; used by coastal and
shallow-draft river craft
Freight carried: highways 80% of total cargo traffic, rail
15%, waterways 5%
Ports: 4 major (Montevideo, Colonia, Fray Bentos,
Paysandu), 6 minor
Civil air: 12 major transport aircraft
Airfields: 101 total, 63 usable; 10 with permanent-surface
Tunways; | with runway 2,440-3,659 m, 11 with runways
1,220-2,439 m; 2 seaplane stations
Telecommunications: most modern facilities concen-
trated in Montevideo; 258,000 telephones (9.0 per 100 popl.);
75 AM, 3 FM, and 27 TV stations; 2 submarine cables
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
URUGUAY/VATICAN CITY
DEFENSE FORCES
Military manpower: males 15-49, 672,000; 542,000 fit for
military service; no conscription
Military budget: proposed for fiscal year ending 31
December 1977, $79.9 million; 17.3% of central government
budget
VATICAN CITY
Tyrshenian:
Sea
Mediterranean
Sea
(See reference map lV)
LAND
0.438 km?
Land boundaries: 3 km
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 1 AM station and 1 FM station;
2,000-line automatic telephone exchange
DEFENSE FORCES
Defense is responsibility of Italy
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 a
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
VENEZUELA
VENEZUELA
Atlantic :
Ocean
{See reference map
LAND
911,680 km?; 4% cropland, 18% pasture, 21% forest, 57%
urban, waste, and other
Land boundaries: 4,181 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 2,800 km
Railroads: 373 km standard gage (1.435 m) all single
track; 171 km government owned, 202 km privately owned
Highways: 58,600 km; 21,200 km paved, 22,800 km
gravel, 14,600 km improved earth
Inland waterways: 7,100 km; Orinoco River and Lake
Maracaibo accept oceangoing vessels
Pipelines: 6,110 km crude oil; 400 km refined products;
2,495 km natural gas
Ports: 6 major, 17 minor
Civil air: 70 major transport aircraft
Airfields: 292 total, 260 usable; 108 with permanent-sur-
face runways; 9 with runways 2,440-3,659 m, 76 with
runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: modern expanding telecom system;
satellite ground station; 649,000 telephones (5.3 per 100
popl.); 157 AM, 50 FM, and 43 TV stations; 4 submarine
cables, including 2 coaxial, 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,707,000; 1,911,000 fit
for military service; 138,000 reach military age (18) annually
VIETNAM
LAND
329,707 km®; 14% cultivated, 50% forested, 36% urban
inland water, and other
Land boundaries: 4,562 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 3,444 km (excluding islands)
Wighways: 41,190 km; 5,471 km bituminous, 27,030 km
gravel or improved earth, 8,690 km unimproved earth
Inland waterways: about 17,072 km navigable; more
than 5,149 km navigable at all times by vessels up to 1.8-m
draft
Ports: 9 major, 23 minor
Civil air: military controlled
Airfields: 172 total, 142 usable: 60 with permanent-
surface runways; 8 with runways 2,440-3,659 m, 18 with
runways 1,220-2,4389 m; 2 seaplane stations
DEFENSE FORCES
Supply: dependent on the U.S.S.R., Kastern European
Communist countries, and the PRC for virtually all new
equipment; produces negligible quantities of infantry
weapons, ammunition and explosive devices (Vietnam
possesses a huge inventory of U.S.-manufactured weapons
and equipment captured from the RVN)
222
Approved For Release 2005/04/22 :
Military budget: no expenditure estimates are available:
military aid from the U.S.S.R. and PRC has been so
extensive that actual allocation of Vietnam''s domestic
resources to defense has not been indicative of total military
effort
NOTE: VN figures preliminary','7eb74c9414e843e35f249a54c84c442c2b93d7c637151efbefed8cc178577006','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('129d9a2842e98724bdcd0c53a69f43131a4aef3b38823f2232276ef27c0f2c64',1978,'WF','Wallis and Futuna','communications',532,'a
s
a Fidl
ad t=)
NEW :
CALEDONIAS — , , WALLIS
AND FUTUNA
Pacific Ocean
4 / NEW
{ ZEALAND
a
{See reference map Vill}
LAND
About 207 km?
WATER
Limits of territorial waters: 12 nm
Coastline: about 129 km
Highways: 100 km of improved road on Uvea Island
(1972)
Ports: 2 minor
Airfields: 2 total, 2 usable; 1 with runway 1,220-2,489 m
Telecommunications: 70 telephones
DEFENSE
No formal defense structure; no regular Armed Forces','3bfe1bed832e966aeafbdcfdd6edbe7ac1f90e49df9f703edd77389269a283e8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0c9db6355519daf224b70219c40db4190ba0b5447155b2b8259de8c70b8807a',1978,'EH','Western Sahara','communications',536,'(formerly Spanish Sahara)
Atlantic Ocean
e
CANARY
ISLANDS.
Se)
WESTERN
SAHARA ¢
ZS
(See reference map
i
LAND
266,770 km?, nearly all desert
Land boundaries: 2,086 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 1,110 km
Railroads: none
Highways: 6,100 km; 500 km bituminous treated, 5,600
km unimproved earth roads and tracks
Ports: 2 major (El Aaiun, Villa Cisneros), 2 minor
Civil air: no major transport aircraft
Airfields: 13 total, 12 usable; 3 with permanent-surface
runways; 1 with runway over 3,660 m; 5 with runways
1,220-2,4389 m
Telecommunications: telephone and telegraph poor;
1,000 telephones (0.7 per 100 popl.); 2 AM, no FM, 5 TV
stations
223
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
WESTERN SAMOA/YEMEN (ADEN)
WESTERN SAMOA
o, WESTERN
* SAMOA
NEW
ZEALAND
{See reference map V1)
LAND
2,849 km*; comprised of 2 large islands of Savai''i and
Upolu and several smaller islands, including Manono and
Apolima; 65% forested, 24% cultivated, 11% industry, waste,
or urban
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 403 km
Railroads: none
Highways: 784 km; 375 km bituminous, remainder
mostly gravel, crushed stone, or earth
Inland waterways: none
Ports: 1 principal (Apia), 1 minor
Civil air: 2 major transport aircraft
Airfields: 4 total, all usable; 1 with permanent-surface
runway 1,220-2,.489 m
Telecommunications: 3,160 telephones; 20,000 radio
receivers; 2 AM_ stations
YEMEN (ADEN)
LAND
287,490 km; (border with Saudi Arabia undefined); only
about 1% arable (of which less than 25% cultivated)
Land boundaries: 1,802 km
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
YEMEN (ADEN)
Arabian
Indian
Ocean
(See reference map V)
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 1,383 km
Railroads: none
Highways: 5,311 km; 322 km bituminous treated, 290 km
crushed stone and gravel, 4,699 km motorable track
Ports: 1 major (Aden)
Pipelines: refined products, 32 km
Civil air: 6 major transport aircraft
Airfields: 94 total, 56 usable; 2 with permanent-surface
runways; 4 with runways 2,440-3,659 m, 31 with runways
1,220-2,4389 m
Telecommunications: small system of open-wire line,
multiconductor cable, and radiocommunications stations,
only center Aden; 9,900 telephones (0.6 per 100 popl.); 1
AM, no FM and 3 TV stations; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 422,000; 233,000 fit for
military service
Military budget: for fiscal year ending 31 December
1978, $58,000,000; about 16% of central government budget
225
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
YEMEN (SANA)
YEMEN (SANA)
Arabian
Indian
Ocean
{See reference map V}
LAND
194,250 km* (parts of border with Saudi Arabia and
Southern Yemen undefined); 20% agricultural, 1% forested,
79% desert, waste, or urban
Land boundaries: 1,528 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone”)
Coastline: 523 km
Railroads: none
Highways: 3,477 km; 467 km bituminous; 435 km
crushed stone and gravel; 2,575 km earth, sand, and light
gravel
Ports: 1 major (Al Hudaydah), 2 minor
Civil air: 14 major transport aircraft (including 2 leased
in)
Airfields: 27 total, 17 usable, 4 with permanent-surface
runways, 4 with runways 2,440-3,659 m, 5 with runways
1,220-2,489 m
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
YEMEN (SANA)/YUGOSLAVIA
Telecommunications: system among Mideast’s worst;
consists of meager open-wire lines and low-power radiocom-
munication stations; principal center Sana, secondary centers
Al Hudaydah and Taizz; 4,600 telephones (0.1 per 100
popl.); 2 AM stations, no FM, | TV station; 1 Indian Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,622,000; 895,000 fit
for military service; about 72,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 June 1975,
$50,402,000; 54.6% of central government budget
YUGOSLAVIA
, &
Mediterranean
Sea
ct
(See reference map Itt}
LAND
255,892 km?; 32% arable, 25% meadows and pastures, 34%
forested, 9% other
Land boundaries: 3,001 km
WATER
Limits of territorial waters (claimed): 10 nm (fishing 12
nm)
Coastline: 1,521 km (mainland), plus 2,414 km (offshore
islands)
Railroads: 10,319 km; 9,353 km standard gage (1.435 m),
966 km narrow gage; 794 double track; 2,600 km electrified
(1975)
Highways: 100,300 km; 38,700 km paved (concrete,
asphalt, stone block), 36,500 km macadamized, 25,100 km
earth (1975)
Inland waterways: 2,001 km (1977)
Freight carried: rail—73.7 million metric tons, 37.3
billion metric ton/km (1974); highway—84.1 million metric
tons, 11.2 billion metric ton/km (1976); waterway—29.0
million metric tons, 7.7 billion metric ton/km (incl. int’l.
transit traffic) (1976)
Pipelines: 322 km crude oil; 892 km natural gas
Ports: 9 major (most important: Rijeka, Split, Koper, Bar),
24 minor (1976)
Military budget (announced): for fiscal year ending 31
December 1977, 38 billion dinars; about 6% of national
income
228
Approved For Release 2005/04/22 :
ZAIRE
Atlantic
Ocean
(See reference map V}
LAND
2,343,950 km?; 22% agricultural land (1% cultivated), 45%
forested, 33% other
Land boundaries: 9,902 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 37 km
Railroads: 5,149 km; 3,870 km 1.067-meter gage, 126 km
meter gage (1.00 m); 136 km 0.610-meter gage, 1,017 km
(0.600-meter gage, 851 km 1.065-meter gage electrified
Highways: 145,000 km; 2,000 km bituminous, 66,000 km
improved earth, 77,000 km unimproved
Inland waterways: comprising the Zaire, its tributaries,
and unconnected lakes, the waterway system affords over
15,000 km of navigable routes
Ports: 2 major (Matadi, Boma), 1 minor
Pipelines: refined products, 740 km
Civil air: 42 major transport aircraft
Airfields: 332 total, 280 usable; 21 with permanent-sur-
face runways; 1 with runway over 3,660 m, 2 with runways
2,440-8,659 m, 57 with runways 1,220-2,439 m
Telecommunications: limited, barely adequate telephone
service, telegraph service good; 28,000 telephones (0.1 per
100 popl.); 7,100 TV receivers; 12 AM, 1 FM, and 2 TV
stations; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 6,291,000; 3,149,000 fit
for military service','2dc050491eb3d7790f70504cd43dfde92574c47218121ba5be663203f35bffad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ea5f8af9050a7f403788d9860148c1e51600c25c4878e40519650181aa1dab0',1978,'ZM','Zambia','communications',540,'Indian
* Ocean
(See reference map Vi}
LAND
745,920 km?; 5% under cultivation, 5% arable, 10%
grazing, 13% dense forest, 6% marsh, 61% scattered trees
and grassland
Land boundaries: 6,003 km
229
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Railroads: 2,014 km, all narrow gage (1.067 m); 13 km
double track
Highways: 34,869 km; 4,456 km paved, 2,853 km crushed
stone, gravel, or stabilized soil; 4,660 km improved and
unimproved earth
Inland waterways: 2,250 km including Zambezi River,
Luapula River, Lake Kariba, Lake Bangweulu, Lake
Tanganyika; principal port on Lake Tanganyika is
Mpulungu (of only local importance)
Pipelines: 724 km crude oil
Civil air: 10 major transport aircraft
Airfields: 172 total, 165 usable; 12 with permanent-sur-
face runways; 1 with runway over 8,660 m, 3 with runways
2,440-3,659 m, 22 with runways 1,220-2,489 m
Telecommunications: all services being modernized and
increased; high-capacity wire and radio relay connect
centers of Kitwe in northern mining region and Lusaka
along axial north-south route; 77,400 telephones; (1.7 per 100
popl.); 4 AM, 1 FM, and 3 TV stations; 1 Indian Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,160,000; 603,000 fit
for military service
Military budget: for fiscal year ending 31 December
1977, $79 million; 12.9% of central government budget
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','2e3d196db201ef39a95016313939177e29b19babc57984f1ca2ac804bd49775d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('050a95ab89e36402a671f4591ba8debd9aecd84d0cf857a624d8874df190c566',1978,'US','United States','communications',544,'This “Factsheet” on the U.S. is provided solely as a service
to those wishing to make rough comparisons of foreign
country data with a U.S. “yardstick.” Information is from
U.S. open sources and publications and in no sense represents
estimates by the U.S. intelligence community.
LAND
9,363,396 km? (contiguous U.S. plus Alaska and Hawaii);
19% cultivated, 27% grazing and pasture, 32% forested, 22%
waste, urban, and other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 19,924 km
Railroads: 277,686 km (1973)
Highways: 6,059,200 km (1972)
Inland waterways: 40,416 km of navigable inland
channels, exclusive of the Great Lakes; freight carried 951
million short tons (1970)
Pipelines: petroleum, 279,966 km (1972)
Ports; 25 major
Merchant marine: 600 ships (1,000 GRT or over) totaling
9,982,730 GRT, 14,722,666 DWT; includes 3 passenger, 5
short-sea passenger, 163 cargo, 119 container, 14 roll-on/
roll-off cargo, 234 tanker, 1 liquefied gas, 17 bulk, 2
combination ore/oil, 23 LASH Seebee and barge carriers, 19
specialized carriers; in addition there are 178 ships in reserve
fleet
Civil air: 5,480 major transport aircraft (1976)
Airfields: 15,257 (1976)
Telecommunications: 4,398 AM, 3,151 FM, 940 TV
broadcast stations (1974); 147 million telephones (1975), 69.5
telephones per 100 population (1976); 360 million radio and
110 million TV receivers
DEFENSE FORCES
Personnel: army 1,148,000, navy and marines 1,065,000,
air force 942,000 (1973)
Military budget: $80.6 billion (1974 est.)
231
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
I Canada
Bay ee
(Denmark) reyijanitlo?
icefand
Greentlan ca i
United \\ {
States
Fairbanks »
Ng Godthaab
9, Ty
ae
ell] ate
». Whitehorse al " ;
it a * ; ‘
iaveat
Slave Lake
. os aha | og
es jiudson 4 Moy
wat es a * rye
: ay ae 5 ip
‘ ae Nae
Churchill” \\ \\ ra YX
ey Pa é P \\ .
+ : he et Nilo. a d @ \\y Schefferville.e> vi re
. Edmonton ~, i “Goose 2B ae
| «Vancouver
Aes . Calgary: Saskatoon : a on yf
aes ey : - - 3 : .
Nevis. Seattle : ° . F i \\ \\ “f — : Lu
Pals! ond
. dake ie
Regina. wWinnipe 2 aa (\\s
noioet : aXe ‘Sydney
: 2 Kathy rlattetown
Seas Quebec
° Ae
og
ee A Montreal «
Lan t _ : G
ee NS Ottawa* ops
Lak
NG L Sh Ontario
vie Salt Lake City lg Boston \\)
Milwaukee a _
New York ¢*”
Chicago
Denver .
7 , = Atlantic Ocean
Washington x ¢
- Los Angeles Kansas City ® : fy
\\ e St. Louis x
United States %
Oklahoma City *
\\
i
\\
Pres
\\ “
i
\\
i
t
/
\\
500 Kilometers
ee
2
a, Mexico
BOUNDARY REPRESENTATION 1S
NOT NEGESSABILY AUTHORITATIVE
500 Miles
502847 1-78
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
damaica','6fd70aa2640ed703f322ab158bc7a1eb67dc473c4c91c21e301fade9b441e90c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64285bb886b1783a34ecee363270cce54489cc79a9030f6bdf33b6797bb05581',1978,'AF','Afghanistan','communications',7,'Railroads: 0.6 km (single track) 1.524-meter gage,
government-owned spur of Soviet line
Highways: 20,885 km total (1975); 2,460 km paved, 3,910
km gravel, 8,735 km improved earth, and 5,780 km
unimproved earth
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
AFGHANISTAN/ ALBANIA
Inland waterways: total navigability 1,200 km; steamers
use Amu Darya
Ports: only minor river ports
Civil air: 6 major transport aircraft
Airfields: 36 total, 35 usable; 9 with permanent-surface
runways; 6 with runways 2,440-3,659 m, 11 with runways
1,220-2.439 m
Telecommunications: limited telephone, telegraph, and
radiobroadcast services: television to be introduced by 1979;
35,000 telephones (0.2 per 100 popl.); 2 AM, no FM, no TV
stations
DEFENSE FORCES
Military manpower: males 15-49, about 4.] million; 2.2
million fit for military service; about 162,000 reach military
age (22) annually
Supply: dependent on foreign sources, almost exclusively
the U.S.S.R.
Military budget: estimated expenditures for fiscal year
ending 31 March 1978, about $60.7 million; approximately
8.3% of central government budget','a1996dc64a0a4ad0bbc765e658fb1c0f7b994c9ac8495a875b0dd4b80b201c67','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27dca2882c98e5a785bdcb520d5f5987a3b000d17fbea635ccf5c5e9e7419f9f',1978,'AL','Albania','communications',8,'Mediterranean Sea
(See reference map (V}
LAND
28,749 km?; 19% arable, 24% other agricultural, 43%
forested, 14% other
Land boundaries: 716 km
WATER
Limits of territorial waters (claimed): 15 nm
Coastline: 418 km (including Sazan Island)
Railroads: 277 km standard gage (1.435 m), single track,
government-owned (1975)
Highways: 4,989 km total; 1,287 km paved, 1,609 km
crushed stone and/or gravel, 2,093 km improved or
unimproved earth (1975)
Inland waterways: 43 km plus Albanian sections of Lake
Scutari, Lake Ohrid, and Lake Prespa (1977)
Freight carried: rail—2.8 million metric tons, 180 million
metric ton/km (1971); highways—39 million metric tons,
900 million metric ton/km (1971)
Ports: 1 major (Durres), 3 minor (1977)
Pipelines: crude oil, 117 km; refined products, 65 km;
natural gas, 64 km
Civil air: no civil airline
DEFENSE FORCES
Military budget (announced): for fiscal year ending 31
December 1978, 824 million leks; 10.7% of total budget','857cdd72ffa26e820f17d943250b590a0df646f074c30d2d301b2090400ac13a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deeee52a207625936f9eb0663bf381c49b75731d7cd9de816378e915be888db6',1978,'DZ','Algeria','communications',12,'LAND
2,460,500 km?; 3% cultivated, 16% pasture and meadows,
1% forested, 80% desert, waste, or urban
Land boundaries: 6,260 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,183 km
Railroads: 3,950 km total; 2,690 km standard gage (1.435
m), 1,140 km 1.055-meter gage, 120 km meter gage (1.000
m); 302 km electrified; 193 km double track
Highways: 78,410 km total; 45.070 km concrete or
bituminous, 33,340 km gravel, crushed stone, unimproved
earth
Ports: 9 major, 8 minor
Pipelines: crude oil, 3,983 km; refined products, 298 km;
natural gas, 2,398 km
Civil air: 39 major transport aircraft (including 1 leased
in)
Airfields: 182 total, 176 usable; 58 with permanent-sur-
face runways; 21 with runways 2,440-3,659 m; 94 with
runways 1,220-2,439 m; 3 seaplane stations
Telecommunications: adequate domestic and interna-
tional service in the north, sparse in the south; Atlantic
Ocean satellite station plus domestic satellite system U/C
and partially operative, 266,000 telephones (1.5 per 100
popl.); 18 AM and 40 TV stations; 5 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 3,740,000; 2,233,000 fit
for military service; average number reaching military age
(19) annually 192,000
Military budget: for fiscal year ending 31 December
1977, $385 million; 6% of national budget','052741b57a726f24173c9e7f1c6d2e653ecbc370c4e618891e7e2c09fabb372c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d23291fddfc396abb87618e27f6aff92c37762cf3c181b01e59f8ad5416edc3',1978,'AD','Andorra','communications',16,'Atlantic
Qcean
Mediterranean
{See refereace map iV)
LAND
466 km?
Land boundaries: 105 km
Railroads: none
Highways: about 96 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: international circuits to Spain and
France; 2 AM stations, 1 FM, 1 TV station; about 3,900
telephones (14.3 per 100 popl.}
DEFENSE FORCES
Andorra has no defense forces; Spain and France are
responsible for protection as needed','564518e0a569b7a5a59d85ec0c15be150cc85af2ef15db9226f4c22f22b157bf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6ed2b87d44f1745123af13adefde64b91a634ad92dd1e6a45d66e9d1ae83a2f',1978,'AO','Angola','communications',20,'LAND
1,245,790 km’, 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow)
Land boundaries: 5,070 km
WATER
Limits of territorial waters (claimed): 20 nm
Coastline: 1,600 km
Railroads: 3,088 km total; 2,778 km 1.067-meter gage,
310 km 0.600-meter gage
Highways: 73,828.km total; 8.577 km bituminous-surface
treatment, 28,723 km crushed stone, gravel, or improved
earth, remainder unimproved earth
Inland waterways: 3,220 km _ navigable
Ports: 3 major (Luanda, Lobito, Mocamedes), 15 minor
Pipelines: crude oil, 179 km
Civil air: 23 major transport aircraft (including 2 leased
in)
Airfields: 574 total, 508 usable; 25 with permanent-
surface runways; 1 with runway over 3,660 m, 8 with
runways 2,440-3.659 m, 88 with runways 1,220-2.439 m
Telecommunications: fair network of open-wire and
radio-relay facilities: ] Atlantic Ocean satellite station;
32,000 telephones (0.5 per 100 popl.); 24 AM, 12 FM, and 1
TV station
DEFENSE FORCES
Military manpower: males 15-49, 1,574,000; 791,000 fit
for military service; average number reaching military age
(20) annually, 59,000
ANTIGUA
LAND
280 km?; 54% arable, 5% pasture, 14% forested, 9% unused
but potentially productive, 18% wasteland and built on
Atlantic
Ocean
DOMINICAN:
REPUBLIC','728dec738074a737fa0f297627dc104c5184aa1b6262bf2ed21cd014200280b7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f24c77744d1f43f1309f340a8e8bf01684bed58903caad93d09fe5fa9d0b9ad',1978,'PR','Puerto Rico','communications',24,'oe eee
ANTIGUA ae
Caribbean Sea
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 153 km
Railroads: 78 km narrow gage (0.760 mm), employed
almost exclusively for handling cane
Highways: 380 km total; 240 km main, 140 km secondary
Ports: 1 major (St. John’s), 1 minor
Civil air: 9 major transport aircraft, including 1 leased out
Airfields: 3 total, 3 usable; 1 with asphalt runway 2,745
m; 2 seaplane stations
Telecommunications: automatic telephone system; 3,500
telephones (4.9 per 100 popl.); tropospheric scatter links with
Tortola and St. Lucia; 3 AM stations, 1 FM station, and 1 TV
station; 1 coaxial submarine cable','3be1d2ec6005e49033f0df97860369ac9f53cdd7ce09329f4c712e2208c51b5c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('062316499f6ad385a18eabe3c55c39e54e57d5dc425403178225931710354641',1978,'AR','Argentina','communications',28,'LAND
2,771,300 km*®, 57% agricultural (11% crops, improved
pasture and fallow, 46% natural grazing land), 25% forested,
18% mountain, urban, or waste
Land boundaries: 9,414 km
WATER
Limits of territorial waters (claimed): 200 nm (continen-
tal shelf, including sovereignty over superjacent waters)
Coastline: 4,989 km
Approved For Release 2005/04/22
Pacific
Ocean
Buenos Aires
Atlantic Ocean
EP FALKLAND ISLANDS
(Seo reference map Hi
Railroads: 39,738 km total; 3,086 km standard gage (1.435
m), 22,788 km broad gage (1.676 m), 13,461 km meter gage
(1.000 m), 403 km 0.750-meter gage
Highways: 219,700 km total, of which 43,050 km paved,
76,800 km gravel, 85,950 km improved earth, 13,900 km
unimproved earth
Inland waterways: 11,000 km navigable
Ports: 7 major, 21 minor
Pipelines: 4,090 km crude oil; 2,200 km refined products;
8,172 km natural gas
Civil air: 43 major transport aircraft, includes 2 leased in
Airfields: 2,388 total, 2,151 usable; 90 with permanent-
surface runways; 21 with runways 2,440-3,659 m, 315 with
runways 1,220-2,439 m; 6 seaplane stations
Telecommunications;: extensive modern system; tele-
phone network has 2.54 million sets (9.8 per 100 popl.), radio
relay widely used, 1 satellite station with 2 Atlantic Ocean
antennas; 160 AM, 12 FM, and 64 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 6,535,000; 5;299,000 fit
for military service; average number reaching military age
(20) annually about 226,000
Military budget: proposed for fiscal year ending 3]
December 1978, $1,742.2 million; about 15% of total central
government budget','76a8ee79fcf8aff19b5f8ce1bf21a2b0f7bfe67b18540a25e976cb7bc19d1f86','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23e57c6df6760ef2a8476c5d3881a4e7cfceae6944e82663fc0b4b8632f29990',1978,'AU','Australia','communications',32,'LAND
7,692,300 km?; 6% arable, 58% pasture, 2% forested, 34%
other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm; prawn and crayfish on continental shelf)
Coastline: about 25,760 km
Railroads: 40,636 km total; 9,197 km 1.60-meter gage,
13,394 km standard gage (1.485 m), 18,045 km 1.067-meter
gage; 800 km electrified (June 1962); government-owned
(except for few hundred kilometers of privately owned
track)
Highways: 837,866 km total (1976); 207,644 km paved,
205,454 km gravel, crushed stone, or stabilized soil surface,
424,768 km unimproved earth
Inland waterways: 8,368 km; mainly by small, shallow-
draft craft
Freight carried: rail—154.4 million metric tons
Ports: 12 major, numerous minor
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
AUSTRALIA/ AUSTRIA
Pipelines: crude oil, 740 km; refined products, 340 km;
natural gas, 6,947 km
Civil air: around 120 major transport aircraft
Airfields: 1,634 total, 1,566 usable; 198 with permanent-
surface runways, 2 with runways over 3,660 m; 19 with
runways 2,440-3,659 m, 642 with runways 1,220-2,439 m
Telecommunications: very good international and do-
mestic service; 5.5 (39.5 per 100 popl.) million telephones;
204 AM stations, 5 FM stations, 112 TV stations and 66
repeaters; 3 earth satellite stations; submarine cables to New
Zealand, New Guinea, Singapore, Malaysia, Hong Kong, and
>erth Pe ie: el
0 1200 Kilometers Per a SAH Adelaide
Es ef er 4% Melbourne
9 1200 Miles eye Dt
: 2
Boundary representation is a
not necessarily authoritative [
503778 7-78
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
VIII Oceania
De \\ (Tai Kaual
ao’ Hong Kong J Taiwan oshus.
t? =, +
GK) HAWAIIAN
"Wake &.8) ISLANDS (> Hawaii
Huzon MARIANA (Wnited
LUZ _— ; ISLANDS Johnston States)
south China Philippine Sea seipan us)
Sea Guam 3.) a
Trust Territory of the Pacific Islands “ty :
“4, -
Yap “(5.) ms Kwajalein kon we N Oo R T Hi P A Cc I F | Cc Oo Cc E A N
2 at ie 7 "2
t PALAU Truk : : an : ¢
ISLANDS Islands © «. Ponape» : an Kingman Reef, Pa
CAR, . : ey WS) _Paimyra
: OLINE “ ISLA ‘ 2 ws. 4
. NDS oe ‘Washington <&
: e ‘Fanning
a Christmas
S Howland .8.)
Pos ‘Baker (U.S> Sf
“e
. ee: so,
a Nauru Sg . (OS ALK, paint admin? Jans c
<= “s-<., New Ireland Qy" Canton.“ PHOENIX IS. >
iy jrian Jaya . Bismarck Sea “s. Phoenix ——> ° (U.K. admia.. U8. elgimi
ee “ New Britain 9 {Bougainville go Gardner’ Hull — 2
'' Q wong Se ww olomon islands . i
s \\ Papua WGuitea SS raphoiseul (UK) ; Gititbert Ilstands ALi admin. 0
Qe. ae Solomon Sea a, Santa Isabel Tuvalu _ (UK) US. caim
_ wo ° Hohiarg,, \\alaita SANTA wK Y, ne 2 Agminisiered by New Zealand on
! Port Ws : 2 . . j ayes : .
Arafura Sea Menosby On Guadalcanal’ +$2" Cristobat “CRUZ ; American .
es = Rennell re Samoa fLES MARQUISES
- | Wallle and Futuna este” YS? Cook Island
Fiji allis and Futuna Samoa Pago ook isiands
INDIAN : } ry Apa «Pago iNew Zealand)
‘Tutuila
OCEAN Ceral Santots FIJ| ISLANDS , to, “ee <sy 4 1g.
_,New Hebrides ~ Vanua Levi? Tonga NO, fry
iAngia- french Condominium) Viti Levi. X<g . Papeete , 7%
‘ , Suva’, ‘Niue S> Tahiti rn
; o oft on .,
New |x, 4 Peo “As :
_ Caledonia ‘ {Nuku''alofa Rarotonga , RES 7 Mururua ..
o UR, . a
New Caledonia | Bla French ites Gambier
Polynesia
SOUTH PACIFIC OCEAN | airtnaial
oe Rapa’ .
G pe
'' &>.
y
se
, va
. x
Tasman
Sea New
Zealand North Island
Tasmania
obart Line of separation
(not a formal international
? boundary or territorial limit)
ie} 500 1000 Nautical Miles
0 500 1000 Statute Miles
5038779 7-73
Boundary representation is
not necessarily authoritatve
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2','9dd52d0d97c292d46d1838ab6c2add866ba221178a2e8de3bc5d26df477c4ef8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d694141769082ff46254bc18b49573f54792eb6f75c14c813956d844cf7a18e6',1978,'GU','Guam','communications',36,'DEFENSE FORCES
Military manpower: males 15-49, 3,551,000; 3,142,000 fit
for military service; 130,000 reach military age (17) annually
Military budget: for fiscal year ending 30 June 1978,
$2,577,300,000; about 8.8% of total central government
budget','80897feeee4ec0297f013cd70ee55cf9e4e3cde2c559348729c3a0f59c9af951','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60aa0a5da98052bf7b7127fb9ea0b282c47d0581ef09e582b05312dfaafdc9ec',1978,'AT','Austria','communications',37,'FEDERAL S04
~ REPUBI
(See reference map iV}
LAND
83,916 km?*; 20% cultivated, 26% meadows and pastures,
15% waste or urban, 38% forested, 1% inland water
Land boundaries: 2,582 km
Railroads: 6,517 km total; 5.877 km government-owned;
5,397 km standard gage (1.435 m) of which 2,730 km
electrified and 1,333 km double tracked; 480 km narrow
gage (0.760 m) of which 91 km electrified; 640 km privately
owned (1.435- and 1.000-meter gage)
Highways: approximately 33,600 km_ total national
classified network, including 10,400 km federal and 23,200
km provincial roads; about 20,800 km paved (bituminous,
concrete, stone block) and 12,800 km unpaved (gravel,
crushed stone, stabilized soil); additional 60,800 km commu-
nal roads (mostly gravel, crushed stone, earth)
Inland waterways: 427 km
Ports: 2 major river (Vienna, Linz)
Pipelines: 554 km crude oil; 2,611 km natural gas; 171 km
refined products
Civil air: 22 major transport aircraft, includes 1 leased in
Airfields: 51 total, 50 usable; 12 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 7 with runways
1,220-2,4389 m
Telecommunications: highly developed and efficient;
extensive TV and radiobroadcast systems with 90 AM, 94
FM, and 350 TV stations; 1 Comsat station U/C; 2.28 million
telephones (29.9 per 100 popl.)
DEFENSE FORCES
Military manpower: males 15-49, 1,766,000; 1,495,000 fit
for military service; average number reaching military age
(19) annually about 62,000
Military budget: for fiscal year ending 31 December
1978, $693.5 million; about 4.0% of the federal budget
THE BAHAMAS
UNITED
STATES
Atlantic Ocean
: THE
° 4, BAHAMAS
a o
7D
Caribbean Sea REPUBLIC
(See reference map tl)
LAND
11,396 km?; 1% cultivated, 29% forested, 70% built on,
wasteland, and other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 3,542 km (New Providence Is. 76 km)
Railroads: none
Highways: 2,100 km total; 850 km paved, 1,250 km
gravel
Ports: 2 major (Freeport, Nassau), 9 minor
Civil air: 8 major transport aircraft (including 2 leased in)
12
Airfields: 54 total, 51 usable; 10 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 22 with runways
1,220-2,439 m; 4 seaplane stations
Telecommunications: telecom facilities highly developed,
including 58,000 telephones (27.5 per 100 popl.) in totally
automatic system; tropospheric scatter link with Florida; 3
AM, 2 FM stations and 1 TV station; 3 coaxial submarine
cables','9edbcdb4296b776d7029213983428193c781f7e49e38f93992ea34e4ee40904e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('631352b5a3558c7199f761b1b4933fb96bf4913fdb693929a71f1effd6c94a21',1978,'BH','Bahrain','communications',41,'Arabian
Sea
(See reference map V)
LAND
596 km? plus group of 32 smaller islands; 5% cultivated,
negligible forested area, remainder desert, waste, or urban
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Highways: 93 km bituminous surfaced; undetermined
mileage of natural surface tracks
Ports: 1 major (Bahrain)
Pipelines: crude oil, 56 km; refined products, 16 km;
natural gas, 32 km
Civil air: 18 major transport aircraft, including 3 leased in
and 1 leased out (all registered in Oman)
Airfields: 2 total, 2 usable; 1 with permanent-surface
runway; 1 with runway over 3,660 m; 1 with runway 1,220-
2,439 m; | seaplane station
Telecommunications: excellent international telecom-
munications; limited domestic services; 31,000 telephones
(11.6 per 100 popl.); 1 AM station, 1 TV station, 1 Indian
Ocean satellite station; tropospheric scatter and microwave
to Qatar and United Arab Emirates
DEFENSE FORCES
Military manpower: males 15-49, 64,000; fit for military
service, 37,000
Supply: mostly from U.K.
Military budget: for fiscal year ending 31 December
1978; $42.8 million, 6% of total budget
ue hs
Gatar
AL Doha
M
Abu Dhabj *
United Arab
Emirates
DHOFAR
Rate','224c31cf7a0c0a00bfb2ddd63a402487a75fce4473a8d378f36448ba91139274','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7ea8f27557b5a6cb602b6db7951e8fd16035e782f1b80709327fa15cb3d2c27',1978,'BD','Bangladesh','communications',45,'Bay of Bengal
(See reference Map Vil}
LAND
142,500 km’; 66% arable (including cultivated and
fallow), 18% not available for cultivation, 16% forested
Land boundaries: 2535 km
WATER
Limits of territorial waters (claimed); 12 nm; fishing 200
nm
Coastline: 580 km
Railroads: 3,470 km total; 2,483 km meter gage (1.000 m),
953 km broad gage (1.676 m), 35 km narrow gage (0.762 m),
290 km double track; government-owned
Highways: 44,930 km total; 4,044 km paved, 2,022 km
gravel, 38,864 km earth
Inland waterways: 7,000 km; river steamers navigate
main waterways
Ports: | major; 5 minor
Pipelines: 150 km natural gas
Civil air: 9 major transport aircraft
Airfields: 24 total, 16 usable; 18 with permanent surface
runways; 3 with runways 2,440-3,659 m, 8 with runways
1,220-2,439 m
Telecommunications: adequate international radiocom-
munications and landline service; fair domestic wire and
microwave service; fair broadcast service; 100,000 (est.)
telephones (0.1 per 100 popl.); 8 AM, 1 FM, 3 TV stations,
and 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 18,237,000; 10,498,000
fit for military service
Military budget: for fiscal year ending 30 June 1978,
$152.0 million; about 9.4% of the central government budget','a13f1d8554b36bda36698b76c381b8046d8e3ec2c041e221fdcaf72718afe4a5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17ad704eb65b111ed03c3dff85785f6819e441c9f9ca3467e5695700a71da088',1978,'BB','Barbados','communications',49,'DOMINICAN
REPUBLIC
E>. «
PUERTO™ =
RICO
Atlantic
Ocean
ry
‘
&
9
Caribbean Sea ;
%
(See ceference mag tl}
LAND
430 km?; 60% cropped, 10%
built on, waste, other
permanent meadows, 30%
10006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009000
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
BARBADOS / BELGIUM
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 97 km
Railroads: none
Highways: 1,370 km total; 1,290 km paved, and 80 km
gravel, and earth
Ports: 1 major (Bridgetown), 2 minor
Civil air: 4 major transport aircraft
Airfields: 1 with permanent-surface runway 2,440-3,659
m; 1 seaplane station
Telecommunications: islandwide automatic telephone
system with 44,000 telephones (17.8 per 100 popl.);
tropospheric scatter link to Trinidad, UHEF/VHF links to St.
Vincent and St. Lucia; 2 AM stations, 1 FM station, 1 TV
station; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 58,000; 42,000 fit for
military service; average number reaching military age (18)
annually, 3,000; no conscription','285e9d4504c8b7af53e85170a477ce25a7478d33546c2aed49f0f7dfaf0d6243','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e28dc308f2b406beed96224e311ab816d5a0a0475436ae68f7266ebab2da6366',1978,'BE','Belgium','communications',53,'LAND
30,562 km?; 28% cultivated, 24% meadow and pasture,
28% waste, urban, or other; 20% forested
Land boundaries: 1,377 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 64 km
15
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
(See reference mag i}
Railroads: 4,394 km total; 4,117 km standard gage (1.435
m) and government-owned, 2,536 km double track, 1,224
km electrified; 277 km privately owned, electrified meter
gage (1.000 m)
Highways: 104,607 km total; 1,046 km paved, limited
access, divided autoroute; 51,780 km other paved; 51,781 km
unpaved
Inland waterways: 2,043 km, of which 1,528 km are in
regular use by commercial transport
Ports: 5 major, 1 minor
Pipelines: refined products, 965 km; crude, 161 km;
natural gas, 3,218 km
Civil air: 56 major transport aircraft (including 1 leased in
and 8 leased out)
Airfields: 46 total, 45 usable; 22 with permanent-surface
runways; 13 with runways 2,440-3,659 m, 5 with runways
1,220-2,489 m
Telecommunications: excellent domestic and interna-
tional telephone and telegraph facilities; 2.95 million
telephones (30.0 per 100 popl.); 14 AM, 21 FM, and 25 TV
stations; 5 coaxial submarine cables; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,248,000; 1,803,000 fit
for military service; average number reaching military age
(19) annually 76,000
Military budget: proposed for fiscal year ending 31
December 1978, $2.3 billion; about 7% of proposed central
government budget','63610e571441c9af57c39efe5abbb2677173b578aa261a2cf151859984a20f72','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5092a96a9eb1e0028b213ac092e22bb0b65147834abc96ec04125a55fee821d8',1978,'BZ','Belize','communications',57,'(formerly British Honduras)
LAND
22,973 km?; 38% agricultural (5% cultivated), 46%
exploitable forest, 16% urban, waste, water, offshore islands
or other
Land boundaries: 515 km
Gulf of S','4720b9f6e93bf3d15bac4d8c527e740034fa1ee979f48eb092c72c3e8a929f8d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a76e30a543a0ad5e1f2298ef7d5f513fb7adfe7aa37ca951ebea6336c5efcf3',1978,'MX','Mexico','communications',58,'Caribbean
Sea
Pacific
Ocean
~~
(See reference map {1}
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 386 km
Railroads: none
Highways: 2,450 km total; 300 km paved, 900 km gravel,
950 km improved earth and 300 km unimproved earth
Inland waterways: 800 km river network used by
shallow-draft craft
Ports: 1 major (Belize), 4 minor
Civil air: 4 major transport aircraft
Airfields: 37 total, 37 usable; 4 with permanent-surface
runways; 1 with runway 1,220-2,489 m; 1 seaplane station
Telecommunications: 5,600 telephones in automatic and
manual network (4.3 per 100 popl.); radio-relay system; 6
AM stations
molasses,
DEFENSE FORCES
Military manpower: males 15-49, 32,000; 19,000 fit for
military service; 1,700 reach military age (18) annually
18
Caribbean
Sea
Pacific Ocean
{See reference map tl}
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 400 km
Gulf
of Mexico
Pacific Ocean
(See reference map u}
LAND
1,978,800 km*; 12% cropland, 40% pasture, 29% forested,
26% other (including waste, urban areas and public lands)
Land boundaries: 4,220 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm), 200 nm exclusive economic zone
Coastline: 9,330 km
Railroads: 19,680 km total;
(1.485 m); 1,104 km narrow gage (0.914 m); 102 km
electrified; 19.573 km government-owned, 107 km
Drivately-owned
Highways: 175,500 km total; 74,000 km paved, 85,500
km otherwise improved, 16,000 km unimproved
18.576 km standard gage
Inland waterways: 2,900 km navigable rivers and coastal
canals
Pipelines: crude oil, 3,910 km; refined products, 3,490
km; natural gas, 5,710 km
Ports: 9 major, 20 minor
Civil air: 128 major transport aircraft (including 4 leased
in)
Airfields: 2,015 total, 1,959 usable; 140 with permanent-
surface runways; 2 with runways over 3,660 m, 21 with
Tunways 2,440-3,659 m, 270 with runways 1,220-2,439 m: 9
seaplane stations
Telecommunications: highly developed telecom system
links; connection into Central
American microwave net: | Atlantic Ocean satellite ground
station; 3.31 million telephones (5.2 per 100 popl.); 574 AM,
109 FM, and 163 Tv stations
DEFENSE FORCES
Military manpower: males 15-49, 13,867,000; 10,558,000
fit for military service; average number reaching military
age (18) annually, 738,000
Military budget: for year ending 3] December 1978,
$632.8 million; about 2.9% of direct federal budget (includes
merchant marine and military industry)
136','ec03dfc141ab3aac47ee180cf33bf15d3e3d6313efe06ebf1f5363c1131ecd83','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e87c1f7554e3dde6947ee75702b38086f0f15b71dbfb9a0a27eac673dbbe4506',1978,'BJ','Benin','communications',62,'(formerly Dahomey)
Gulf of Guinea
(See reference map Vi}
LAND
115,773 km?; southern third of country is most fertile;
arable land 80% (actually cultivated 11%), forests and game
preserves 19%, non-arable 1%
Land boundaries: 1,963 km
WATER
Limits of territorial waters (claimed): 200 nm (100 nm
mineral exploitation limit)
Coastline: 121 km
Railroads: 579 km, all meter gage (1.00 m)
Highways: 3,303 km total; 705 km paved, 2,598 km
improved earth
Inland waterways: 645 km navigable
Ports: 1 major (Cotonou), 1 minor
Civil air: no major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-surface
runway; 4 with runways 1,220-2,439 m
Telecommunications: system of open wire and radio
relay; 9,900 telephones (0.3 per 100 popl.); 2 AM, 1 FM, and
no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 752,000; 377,000 fit for
military service; about 33,000 males and 32,000 females
reach military age (18) annually; both sexes liable for
military service
Supply: dependent on France and Guinea; aid from North
Korea and PRC is pending
Military budget: for fiscal year ending 31 December
1976, $7.4 million; about 11% of central government budget','a0e07d07fd3978070bbf6de3dec1ec6a553cf6d002f4cd05630d5d4a68fd4c70','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b63e92167cc025e91d7e7e5b10758c12e6ba2518a6c9894fabac1cd217f7f410',1978,'BM','Bermuda','communications',66,'Atlantic
Ocean
(See reference map II)
LAND
54.4 km?; 8% arable, 60% forested, 21% built on,
wasteland, and other, 11% leased for air and naval bases
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 108 km
Railroads: none
Highways: 190 km, all paved
Ports: 3 major (Hamilton, St. George Freeport, Ireland
Island)
Civil air: 3 major transport aircraft
Airfields: 1 with concrete runway 2,960 m; 1 seaplane
station
Telecommunications: modern telecom system, includes
fully automatic telephone system with 38,600 sets (66.6 per
100 popl.); 8 AM, 1 FM, and 2 TV stations; 3 coaxial
submarine cables
20','8aac0035ca5d3a017113fcd33285951e00b17de7904eec150a0d1994830a97b8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36e10157d4635d147d077b3865836174bcd52c74234de67e81ab3d56631c67c0',1978,'BT','Bhutan','communications',70,'Bay of
Bengal
(See reference map Vil}
LAND
46,600 km*; 15% agricultural, 15% desert, waste, urban,
70% forested
Land boundaries: about 870 km
Highways: 1,304 km total; 418 km surfaced, 515 km
improved, 371 km unimproved earth
Freight carried: not available, very light traffic
Civil air: no major transport aircraft
Airfields: 2 total, 1 asphalt runway 1,372 m, and 1 with
concrete runway 899 m
Telecommunications: facilities inadequate; 1,000 tele-
phones (0.1 per 100 popl.); 6,000 est. radio sets; no TV sets; 1
AM station and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 293,000; 155,000 fit for
military service; about 13,000 reach military age (18)
annually
Supply: dependent on India
BOLIVIA
LAND
1,098,160 km?2; 2% cultivated and fallow, 11% pasture and
meadow, 45% urban, desert, waste, or other, 40% forest, 2%
inland water
Land boundaries: 6,083 km
Railroads: 3,572 km total, goverment owned, single track;
3,540 km meter gage (1.000 m), 32 km 0.760-meter gage; in
addition, 96 km meter gage (1.000 m) privately owned
Highways: 37,300 km total; 1,150 km paved, 6,550 km
gravel, 5,950 km improved earth, 23,650 km unimproved
earth
Inland waterways: officially estimated to be 10,000 km
of commercially navigable waterways
Pipelines: crude oil, 1,670 km; refined products, 1,495
km; natural gas, 580 km
Ports: none (Bolivian cargo moved through Arica and
Antofagasta, Chile, and Matarani, Peru)
Civil air: 88 major transport aircraft
Airfields: 576 total, 536 usable; 5 with permanent-surface
runways; 1 with runway over 3,660 m, 6 with runways
2,440-3,659 m, 128 with runways 1,220-2,489 m
Telecommunications: radio-relay system from La Paz-to
Santa Cruz; improved international services; 55,000 tele-
phones (1.2 per 100 popl.); 122 AM, 18 FM, and 5 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 1,319,000; 834,000 fit
for military service; average number reaching military age
(19) annually about 60,000
Military budget: proposed for fiscal year ending 31
December 1978, $90.2 million; about 13.2% of central
government budget','b4964d2ea05bbf3a09b602cbdee1984e92b5e5b77ebc23ea91e9097dd2543b8c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('659baf392160c63f1741c3ba8d9c4e8e1109efa14a1204ae3c43cb75f8527a83',1978,'BW','Botswana','communications',74,'LAND
569,800 km?*; about 6% arable, less than 1% under
cultivation, mostly desert
Land boundaries: 3,774 km
Railroads: 691 km 1.067-meter gage
Highways: 10,219 km total; 438 km paved; 1,426 km
crushed stone or gravel; 5,318 km improved earth and 3,037
km unimproved earth
Inland waterways: native craft only; of local importance
Civil air: 6 major transport aircraft
Airfields: 83 total, 59 usable; 3 with permanent-surface
runways; 16 with runways 1,220-2,439 m
Telecommunications: the system is a minimal combina-
tion of open-wire lines, radio-relay links, and a few
radiocommunication stations; Gaborone is the center; 7,900
telephones (1.2 per 100 popl.); 1 AM, 1 FM, and no TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 173,000; 87,000 fit for
military service; 8,000 reach military age (18) annually','63ee403eb50187a86a8e9db3b5671d986a566b6b55d75ae58d8346e74c0a76b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0ddb3b2be7818bfd5d842392714b6887030a38ae7389add08dfa89019b6a255',1978,'BR','Brazil','communications',78,'LAND
8,521,100 km’; 4% cultivated, 18% pasture, 23% built-on
area, waste, and other, 60% forested
Land boundaries: 13,076 km
23
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Atlantic
Ocean
Brasilia
*
(See reference map Uf}
WATER
Limits of territorial waters (claimed); 200 nm
Coastline: 7,491 km
Railroads: 30,300 km total; 26,543 km meter gage (1.000
m), 3,361 km 1.60-meter gage, 194 km standard gage (1.435
m), 202 km 0.76-meter gage; 2,249 km electrified
Highways: 1,489,000 km total; 71,200 km paved,
1,417,800 km gravel or earth
Inland waterways: 50,000 km navigable
Ports: 8 major, 23 significant minor
Pipelines: crude oil, 2,000 km; refined products, 465 km;
natural gas, 257 km
Civil air: 144 maior transport aircraft, including 1 leased
in
Airfields: 4,306 total, 4,059 usable; 157 with permanent-
surface runways; 16 with runways 2,440-3,659 m, 499 with
runways 1,220-2,439 m; 18 seaplane stations
Telecommunications: fair telecom system; good radio
relay facilities; 1 Atlantic Ocean satellite station with 2
antennas; 3 domestic satellite stations; 3.99 million tele-
phones (3.5 per 100 popl.); 1,100 AM stations, 150 FM, and
175 TV stations; 2 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 25,499,000; 14,605,000
fit for military service; 1,281,000 reach military age (18)
annually
Military budget: for fiscal year ending 31 December
1978, $2,153 million; 8.6% of central government budget
BRUNEI
LAND
5,776 km?; 3% cultivated; 22% industry, waste, urban or
other; 75% forested
Land boundaries: 381 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Railroads: 9.6 km narrow gage (0.610 m)
Highways: 1,206 km total; 376 km paved (bituminous
treated), 402 km gravel or stone, 428 km unimproved
Inland waterways: 209 km; navigable by craft drawing
less than 1.2 meters
Ports: 2 minor (Bandar Seri Begawan, formerly Brunei,
and Kuala Belait)
Pipelines: crude oil, 135 km; refined products, 56 km;
natural gas, 56 km; crude oil and natural gas, 241 km under
construction
Civil air: 2 major transport aircraft
Airfields: 3 total, 3 usable; 2 with permanent-surface
runway; 1 with runway over 3,660 m; 2 with runways
1,220-2,489 m
Telecommunications: service throughout country is ade-
quate for present needs; international service good to
adjacent Sabah and Sarawak; radiobroadcast coverage good:
11,000 telephones (0.3 per 100 popl.); Radio Brunei
broadcasts from 6 AM stations and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 38,000; 23,000 fit for
military service; about 1,800 reach military age (18)
annually
(See reference map it}
Railroads: 109 km total, all single track; 80 km 0.914-
meter gage, 29 km 1.067-meter gage
Highways: 4,100 km total; 950 km paved, 950 km gravel
1,000 km improved, 1,200 km unimproved earth
Inland waterways: 5,900 km; Demerara River navigable
to Mackenzie by ocean steamers, others by ferryboats, small
craft only
86 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
i TT TTS
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GUYANA/HAITI
Ports: 1 major (Georgetown), 3 minor
Civil air: 6 major transport aircraft
Airfields: 95 total, 88 usable; 4 with permanent-surface
runways; 13 with runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: highly developed telecom system
with radio-relay network and over 22,500 telephones (2.6
per 100 popl.); tropospheric scatter link to Trinidad; 5 AM, 1
¥M and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 189,000; 144,000 fit for
military service','50e1aadab03769001074779b868a446260d5574229f357d502c124fee5bb2f6c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b518df87ba0deb6c7e908b6863da3a89b6948447c44f61d4d556fb46edea7eb8',1978,'BG','Bulgaria','communications',82,'Black Sea
Sofia
(See reference map !V)
LAND
111,852 km*; 41% arable, 11% other agricultural, 33%
forested, 15% other
Land boundaries: 1,883 km
26
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 354 km
Railroads: 4,314 km total; about 4,069 km standard gage
(1.435 m), 245 km narrow gage; 299 km double track; 1,446
km electrified; government-owned (1976)
Highways: 31,454 km total; 6,683 km concrete, asphalt,
stone block; 6,088 km asphalt treated, gravel, crushed stone;
18,683 km earth (1976)
Inland waterways: 471 km (1978)
Freight carried: rail—75.2 million metric tons, WA
billion metric ton/km (1977); highway—319 million metric
tons, 6.7 billion metric ton/km (1977); waterway—4.4
million metric tons, 2.4 billion metric ton/km (excl. int’l.
transit traffic) in approximately 214 waterway craft with
227,000 metric ton capacity (1976)
Ports: 8 major (Varna, Varna West, Burgas), 4 minor
(1977)
BURMA
Ranggon
Bay a
of Bengal
South
China Sea
Se
(See reference map Vil}
LAND
678,600 km2; 28% arable, of which 12% is cultivated, 62%
forest, 10% urban and other (1969)
Land boundaries: 5,850 km
WATER
Limits of territorial waters (claimed): 200 nm (200 nm
exclusive economic zone)
Coastline: 3,060 km
Railroads: 3,285 km total; 3,172 km meter gage (1.00 m),
113 km narrow-gage industrial lines; 328 km double track;
government-owned
28
Highways: 27,000 km total; 3,200 km bituminous, 17,700
km improved earth, gravel, 6,100 km unimproved earth
Inland waterways: 12,800 km; 3,200 km navigable by
large commercial vessels
Ports: 4 major, 6 minor
Civil air: about 20 major transport aircraft
Airfields: 80 total, 78 usable; 23 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 39 with runways
1,220-2,4389 m
Telecommunications: provide minimum requirements
for local intercity service: international service is fair;
radiobroadcast coverage is limited to the most populous
areas; 31,400 telephones (0.1 per 100 popl.); 1 AM, 1 FM,
and no TV stations
DEFENSE FORCES
Military budget: (announced) for fiscal year ending 31
March 1978; $148.9 million, 5% of central government
budget','959c7e061bfe362a4e150622c21db2ae381e0454094e9a0724708bdb763450cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4634a96a1e2606cc9d41c098666e536dc530417532d1db03291823a1ee503cb1',1978,'BI','Burundi','communications',86,'(See reference map V1}
LAND
28,490 km*; about 37% arable (about 66% cultivated), 23%
pasture, 10% scrub and forest, 30% other
Land boundaries: 974 km
Railroads: none
Highways: 7,800 km total; 300 km bituminous, 2,500 km
crushed stone, gravel, or laterite, and 3,000 km improved
earth, and 2,000 km unimproved earth
Inland waterways: Lake Tanganyika navigable for lake
steamers and barges, 1 minor lake port
Civil air; 5 major transport aircraft
Airfields: 12 total, 12 usable; 1 with permanent-surface
runway; 1 with runway 2,440-3,659 m
Telecommunications: telegraph is principal service,
limited telephones; 6,000 telephones (0.2 per 100 popl.); 2
AM, 1 FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 907,000; 470,000 fit for
military service; 45,000 reach military age (16) annually
Military budget: for fiscal year ending 31 December
1977, $11,200,000; about 17% of central government budget','b989bb9214abcb3f58fb022130277673f997e08c22fedfc9de769f1e788e57de','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b0a6f01346cdf004c23ff1125314561f43e4f16f67378a39fb3bb51610558f7',1978,'KH','Cambodia','communications',90,'China Sea
EXE
{See reference map Vil}
LAND
181,300 km2; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other
Land boundaries: 2,438 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: about 443 km
29
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CAMBODIA/CAMEROON
Railroads: 612 km meter gage (1.00 m); govern-
ment-owned
Highways: 13,351 km total; 2,622 km bituminous, 7,105
km crushed stone, gravel, or improved earth; and 3,624 km
unimproved earth; some roads in disrepair
Inland waterways: 3,700 km navigable all year to craft
drawing 0.6 meters; 282 km navigable to craft drawing 1.8
meters
Ports: 2 major, 5 minor
Airfields: 60 total, 25 usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 6 with runways
1,220-2,439 m; 1 seaplane station
DEFENSE FORCES
Military manpower: males 15-49, 1,831,000; 1,017,000 fit
for military service; 82,000 reach military age (18) annually','f46d16b32a25abe64b3b949a319e775e75cc942f53b257477383e60c92c2a3c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76bc6152a8dafceec8b51189e706fc3c886371d0c1866413d1fd6ee24da8662a',1978,'CM','Cameroon','communications',94,'* :
Yaounde
EQUATORIAL
GUINEA |
a
(See reference map Vi}
LAND
475,400 km?; 4% cultivated, 18% grazing, 138% fallow, 50%
forest, 15% other
Land boundaries: 4,554 km
WATER
Limits of territorial waters (claimed): 18 nm
Coastline: 402 km
Railroads: 1,003 km total; 858 km meter gage (1.00 m),
145 km 0.600-meter gage
Highways: approximately 29,866 km total; including
2,155 km bituminous, 97,711 km gravel and earth
Inland waterways: 2,090 km
Ports: 1 major (Douala), 3 minor
Civil air: 8 major transport aircraft
Airfields: 63 total, 60 usable; 7 with permanent-surface
runways; 2 with runways 9,440-3,659 m, 21 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: fair telephone service; fair to good
telegraph service; 26,000 telephones (0.4 per 100 popl.); 4
AM, no FM, and no TV stations; 1 submarine cable; 1
Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,538,000; 766,000 fit
for military service; average number reaching military age
(18) annually about 66,000
Military budget: for fiscal year ending 30 June 1978,
$53,996,400; 9.7% of central government budget','fb8150d4ca4cf6b4546e1bcd5df93a7e974360c108b8248b273ed750290c9e5b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a903b6c69a82c4819815a13e8f6c390ba25227ee60e2195b4aabd3cf8dd590d4',1978,'CA','Canada','communications',98,'LAND
9,971,500 km’; 4% cultivated, 2% meadows and pastures,
44% forested, 42% waste or urban, 8% inland water
Land boundaries: 9,010 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 90,908 km
31
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22
: CIA-RDP79-01051A000900010006-2
July 1978
(See reference map li
Railroads: 71,503 km total; 70,141 km standard gage
(1.435 m) (43 km electrified); 1,183 km 1.067-meter gage (in
Newfoundland); 179 km 0.914-meter gage
Highways: 829,325 km total; 640,850 km surfaced
(189,800 km paved), 188,475 km earth
Inland waterways: 3,000 km
Pipelines: oil, 23,564 km total crude and refined; natural
gas, 74,980 km
Ports: 19 major, 300 minor
Civil air: 589 major transport aircraft
Airfields: 1,801 total, 1,452 usable; 295 with permanent-
surface runways; 4 with runways over 3,659 m, 29 with
runways 2,440-3,659 m, 285 with runways 1,220-2,439 m; 58
seaplane stations
Telecommunications: excellent service provided by mod-
ern telecom media; 13.8 million telephones (60.4 per 100
popl.); countrywide AM, FM, and TV coverage including
630 AM, 80 FM, and 500 TV stations; 8 coaxial submarine
cables; 3 major COMSAT stations and 70 domestic COMSAT
stations
DEFENSE FORCES
Military manpower: males 15-49, 5,814,000; 4,998,000 fit
for military service; average number reaching military age
(17) annually 233,000
Military budget: proposed for fiscal year ending 31
March 1978, $3.98 billion; about 8.4% of proposed central
government budget
CAPE VERDE
LAND
4,040 km?, divided among 10 islands and several islets
WATER
Limits of territorial waters: 100 nm
Coastline: 965 km
Ports: 1 major (Mindelo), 8 minor
Civil air: 2 major transport aircraft
Airfields: 6 total, 6 usable; 4 permanent-surface runways;
1 with runway 2,440-3,659 m, 4 with runways 1,220-2,439
m; 1 seaplane station
Telecommunications: interisland radio-relay system, HF
radio to mainland Portugal, about 1,600 telephones (0.3 per
100 popl.); 1 FM and 5 AM stations; 2 coaxial submarine
cables
CENTRAL AFRICAN EMPIRE
{See reference map VI)
LAND
626,780 km*; 10%-15% cultivated, 5% dense forests,
80%-85% grazing, fallow, vacant arable land, urban, waste
Land boundaries: 4,981 km
Railroads: none
Highways: 22,250 km total; 290 km bituminous, 4,120 km
gravel and/or crushed stone, 7,800 km improved earth,
remainder unimproved earth
Inland waterways: 7,080 km; traditional trade carried on
by means of dugouts on the extensive system of rivers and
streams; the Oubangui River between Bangui and Brazza-
ville is navigable for about 8 months a year, and short
sections of the Sangha and the Lobaye Rivers are navigable
throughout year; during high-water period (July-December)
Oubangui navigable upstream from Bangui as far as Quango
Ports: Bangui, Ouango (river ports)
Civil air; 5 major transport aircraft
Airfields: 54 total, 46 usable; 3 with permanent-surface
runways; | with runway 2,440-3,659 m, 18 with runways
1,220-2,489 m
Telecommunications: facilities are meager; network is
composed of low-capacity, low-powered radiocommunica-
tion stations and radio-relay links; 5,540 telephones (0.3 per
100 popl.); 1 AM station, 1 FM station, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 464,000; 237,000 fit for
military service
Supply: mainly dependent on France, but has received
equipment from Israel, Italy, U.S.S.R., and FRG
Military budget: for fiscal year ending 31 December
1977, $7.5 million (current budget only); about 10.6% of
central government current budget','603256521bd5036e36b2badf046e5e7ae193a0b63778fcc388c9cb0c4cdb4f67','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14d060827795c41ff40186aef05420db497b5f9314096da753f1cea94e6c9fa3',1978,'TD','Chad','communications',102,'(See reference map vi
LAND
1,284,640 km?; 17% arable, 35% pastureland, 2% forest
and scrub, 46% other uses and waste
Land boundaries: 5,987 km
Railroads: none
Highways: 27,505 km total; 242 km bituminous, 4,385 km
gravel and laterite, and remainder unimproved
36
Inland waterways: approximately 2,090 km of year-
round navigability, increased to 4,830 km during high-water
period
Civil air: 4 major transport aircraft
Airfields: 67 total, 63 usable; 4 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 25 with runways
1,220-2,439 m
Telecommunications: fair system of radiocommunication
stations only for intercity links; principal center N’Djamena,
secondary center Sarh; 5,480 telephones (0.1 per 100 popl.);
1 AM, no FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,004,000; 524,000 fit
for military service; average number reaching military age
(20) annually about 40,000
Supply: dependent on France primarily
Military budget: for fiscal year ending 31 December
1977, $22.2 million; about 33% of total budget','5681bb8752d80b94edb4434c13d1fac5a8e8e21954c369cf502b72f9651d83ef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1d64f6e3d1248c5496fd18bd4c40bb301b6fa13087e4b17a45ec1ff3ee6c0d2',1978,'CL','Chile','communications',106,'Pacific
Atlantic
(See reference mag fl)
LAND
740,740 km?; 2% cultivated, 7% other arable, 15%
permanent pasture, grazing, 29% forest, 47% barren
mountains, deserts, and cities
Land boundaries: 6,325 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 6,485 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Railroads: 6,361 km total; 3,111 km 1.676-meter gage,
1385 km standard gage (1.435 m), 3,115 km meter gage
(1.00 m)
Highways: 75,200 km total; 9,000 km paved, 38,200 km
gravel, 28,000 km improved and unimproved earth
37
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CHILE/CHINA, PEOPLE’S REPUBLIC OF
Inland waterways: 725 km
Pipelines: crude oil, 755 km; refined products, 785 km;
natural gas, 320 km
Ports: 10 major, 20 minor
Civil air: 33 major transport aircraft
Airfields: 352 total, 349 usable; 45 with permanent-
surface runways; 8 with runways 2,440-3,659 m, 53 with
runways 1,220-2,439 m; 6 seaplane stations
Telecommunications: modern telephone system based on
extensive radio relay facilities; 473,000 telephones (4.5 per
100 popl.); 1 Atlantic Ocean satellite station; 180 AM, 30
FM, and 56 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 2,773,000; 2,089,000 fit
for military service; average number reaching military age
(19) annually about 116,000
Military budget: for fiscal year ending 31 December
1978, US$732.6 million; about 26% of central government
budget
CHINA, PEOPLE’S REPUBLIC OF
Peking*%,
PEOPLE''S REPUBLIC
OF CHINA
(See reference map Vit)
LAND
9.6 million km?; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of this area
consists largely of denuded wasteland, plains, rolling hills,
and basins from which about 3% could be reclaimed), 8%
forested; 2%-3% inland water
Land boundaries: 24,000 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 14,500 km
Railroads: networks total about 45,000 route km com-
mon-carrier lines; about 600 km meter gage (1.00 m); rest
standard gage (1.435 m); all single track except 9,000 km
double track on standard gage lines, approximately 1,025 km
electrified; about 9,700 km industrial lines (gages range from
0.59 to 1.435 m)
Highways: about 835,000 km all types roads; almost half
(about 300,000 km) unimproved natural earth roads and
tracks; about 215,000 km improved earth roads about 2- to
5-meters wide and in poor to fair condition; remainder
(about 260,000 km) includes majority of principal roads
Approved For Release 2005/04/22 :
Airfields: 379 total; 9 with runways 3,500 m and over; 45
with runways 2,500 to 3,499 m; 187 with runways 1,200 to
2,499 m; 124 with runways less than 1,200 m; 2 seaplane
stations; 12 airfields under construction, of these, 249 have
permanent surface runways
Telecommunications: urban and industrial areas served
by reasonably adequate facilities for domestic and interna-
tional communication needs; facilities being expanded;
effective broadcast coverage is provided by radio, extensive
wired-broadcast networks, and an expanding TV network;
estimated 5 million telephones, 45 million radio receivers,
140 million wired-speakers and est. 500,000 TV receivers;
250 AM; 7 FM, and 120 TV transmitter and rebroadcast
stations; 3 standard international communications satellite
ground stations; coaxial cable links Canton to Hong Kong;
submarine cable links Shanghai to Japan; additional subma-
rine cables planned
CHINA, REPUBLIC OF
ff
Taipei
i
REPUBLIC OF','b1fb6a14c93037656342c83bc7e7538dab6eb045bc64565b2af2e5847b0d7075','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54185e2a1eaa3923ce7557ce89886e451a5dad5f2b19af144341640f989fe57d',1978,'CN','China','communications',110,'(See reference map Vil)
LAND
32,960 km? (Taiwan and Pescadores); 24% cultivated, 6%
pasture, 55% forested, 15% other (urban, industrial, de-
nuded, water area)
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 990 km Taiwan, 459 km offshore islands
Railroads: about 1,000 km common-carrier and 3,500 km
industrial lines, all on Taiwan; common-carrier lines consist
of West System: 825 km meter gage (1.00 m) with 325 km
double track, complete line under construction for electrifj-
cation; East Line: 175 km narrow gage (0.762 m) (presently
under construction to convert to meter gage compatible with
West System); common-carrier lines owned by government
and operated by Railway Administration (TRA) under
Ministry of Communications; industrial lines owned and
operated by government enterprises
Highways: network totals 16,900 km (construction of
North-South Freeway approximately 84%—250 km—com-
plete), plus 483 km on Penghu and offshore islands; 7,564
km paved, 6,276 km gravel and crushed stone, 2,736 km
earth
Pipelines: 615 km refined products, 97 km natural gas
Ports: 5 major, 5 minor
Airfields: 38 total, 36 usable; 26 with permanent-surface
runways; 11 with runways 2,440-3,659 m, 12 with runways
1,220-2,4389 m; 1 seaplane station
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
mi
Le
July 1978
Approved F
or Release 2005/04/22 : CIA-RDP79-01051A00090001000
6-2
CHINA, REPUBLIC OF/COLOMBIA
DEFENSE FORCES
Military manpower: males 15-49, 4,146,000; 3,328,000 fit
for military service; about 199,000 currently reach military
age (19) annually
Military budget: for fiscal year ending 30 June 1978,
$1,814.7 million including personnel costs; about 52.5% of
central government budget
Railroads: 4,535 km total operating in 1976; 3.870 km
standard gage (1.435 m), 665 km narrow gage (0.762 m): 259
km double tracked; about 1,140 km electrified; govern-
ment-owned
Highways: about 20,280 km; 98.5% gravel, crushed stone,
or earth surface; 1.5% concrete or bituminous
Inland waterways: 2,253 km; mostly navigable by small
craft only
Ports: 6 major, 26 minor
DEFENSE FORCES
Military manpower: males 15-49, 3,905,000; 2,392,000 fit
for military service; 192,000 reach military age (18) annually
Military budget: announced for fiscal year ending 3]
December 1977, $1.05 billion; about 15.4% of total
government budget
KOREA, SOUTH
LAND
98,400 km*; 23% arable (22% cultivated), 10% urban and
other, 67% forested
Land boundaries: 24] km
-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
KOREA, SOUTH
Sea
(See reference map Vil)
WATER
Limits of territorial waters: 12 nm
Coastline: 2,413 km
Freight carried: rail (1976) 9.2 billion metric ton/km,
43.6 million metric tons; highway 21.8 million metric tons;
air (1959) 861,184 kg carried
Pipelines: 515 km refined products
Ports: 10 major, 18 minor
Civil air: 28 major transport aircraft
Airfields: 121 total, 114 usable; 54 with permanent-
surface runways; 16 with runways 2,440-3,659 m, 17 with
runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 8,777,000; 5,707,000 fit
for military service; average number reaching military age
(18) annually 408,000
Military budget: for fiscal year ending 31 December
1978, $2.6 billion; about 35% of central government budget','c50c262d2eb70bfbf69256443303fc66daf58bb3ec3ae7d361f228a6e28b1222','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79870186fa3362a4dbc5b46ed656e515321c86067427cda87eafbb8023e29ba0',1978,'CO','Colombia','communications',114,'» Bogota
Pacific
Ocean
(See reference map Wy
LAND
1,139,600 km’; settled area 28% consisting of cropland and
fallow 5%, pastures 14%, woodland, swamps, and water 6%,
urban and other 3%; unsettled area 72% —mostly forest and
savannah
Land boundaries: 6,035 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 2,414 km
Railroads: 3,436 km, all 0.914-meter age, single track, 35
km electrified
Highways: 56,650 km total; 8,200 km paved, 41,750 km
crushed stone or gravel, 6,700 km improved earth
pesos= US$]
Civil air: 90 major transport aircraft
Airfields; 729 total, 680 usable; 44 with permanent-
surface runways; 1 with runway over 3,660 m; 5 with
runways 2,440-3 659 m, 86 with runways 1,220-2 439 m; 1]
Telecommunications: nationwide radio-relay system; ]
Atlantic Ocean satellite station; 1.34 million telephones (5.5
Der 100 popl.); 395 AM, 130 FM, and 48 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 5,502,000; 3,594,000 fit
for military Service; average number reaching military age
(18) annually about 260,000
Military budget: Proposed for fiscal] year ending 3]
December 1978, $181.8 million; about 7.7% of central
government budget
*auite','53c8fc266b686f62680825a0648b6413a976756b30726d5d0054a3ef242ea296','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('996a03fa4a7dd2bdc46cb00f4041bc27d4809fb51e43b8df8074945238126f75',1978,'KM','Comoros','communications',118,'LAND
2,170 km2; 4 main islands; forests 16%, pasture 7%,
cultivable area 48%, non-cultivable area 29%
42
‘ndian Ocean
Maroni,, Comonas
(See reference map Vi)
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 349 km
Railroads: none
Highways: 999 km total; approximately 295 kin bitumi-
nous, remainder crushed stone or gravel
Ports: 1 minor (Moroni on Grande Comore)
Civil air; 4 major transports (2 registered in France)
Airfields: 5 total, 5 usable; 5 with permanent surface
runways; | with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m
Telecommunications: sparse system of HF radiocom-
munication stations for interisland, island and external
communications to Malagasy and Reunion; 1,100 telephones
(0.3 per 100 popl.); 2 AM, 1 FM, and no TV stations
(See reference map Vi}
LAND
404 km*; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest land, 29% other (mainly
reefs and other surfaces unsuited for agriculture); 40 granitic
and 43 coral islands
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 491 km (Mahe Island 93 km)','b010efcd4aa287963e5ee43c1926ab5c24bdb672d94205b2fd1a16cd9c6b44fc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cebde08c4f4a667aeff912cefc0e1f82d1172b12ca579bae454bc2b3050faea6',1978,'CG','Congo','communications',122,'LAND
349,650 km’; 63% dense forest or woodland, 33%
cultivable or grazing (2% cultivated est.), 4% urban or waste
Land boundaries: 4,514 km
WATER
Limits of territorial waters (claimed): 30 nm
Coastline: 169 km
Railroads: 800 km, 1,067-meter gage, single track
Highways: 8,246 km total; 585 km bituminous surface
treated; remainder gravel, laterite, or improved earth
Inland waterways: 6,485 km navigable
Pipelines: crude oil 25 km
Ports: 1 major (Pointe Noire)
Civil air: 5 major transport aircraft
Airfields: 68 total, 51 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 20 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: services adequate for government
and public; network is comprised of low-capacity,
low-powered radiocommunication stations, coaxial cables
and wire lines; key centers are Brazzaville, Pointe-Noire, and
Loubomo; 10,500 telephones (0.7 per 100 popl.); 3 AM
Stations, 1 FM station, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 340,000; 169,000 fit for
military service; about 14,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1976, $37,517,400; about 17% of central government budget
44','012feeec08a34dc0d5ba5df60e702a777c4d2c928ca8f10ebda40370970c9395','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9a693967abb0ef5348b163cbf6f8900c567c4054eb3d6509cd8376a151e81ce',1978,'CK','Cook Islands','communications',126,'Pacific Ocean
” e00K
ISLANDS
Pacific Ocean
= NEW
LF NE
{See reference mag Vili}
LAND
About 240 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 120 km
Railroads: none
Highways: 260 km total; 19 km paved, 109 km gravel, 84
km improved earth, 48 km unimproved earth
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable; 1 with permanent-surface
runway 2,317 m, 3 with natural surface runways 1,220-2,439
m; 1 seaplane station
Telecommunications: 6 AM, no FM, and no TV stations;
7,000 radio receivers, and 956 telephones','9f65012238c659173c91b638f0c0fe82ab0ec68ff9b401c4a833abfdcbba0447','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e46a27e9fd594a5139c16d84aae7ebedc5aa828bf115355dba571c8b1cbf75c8',1978,'CR','Costa Rica','communications',130,'LAND
51,000 km’; 30% agricultural land (8% cultivated, 22%
meadows and pasture), 60% forested, 10% waste, urban, and
other
Land boundaries: 670 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; specialized competence over living resources to 200 nm)
Coastline: 1,290 km
Railroads: 563 km 1.067-meter gage, all single track, 115
km electrified
Highways; 25,600 km total; 1,950 km paved, 7,450 km
gravel 16,200 km unimproved earth
Inland waterways: about 730 km Perennially navigable
Pipelines: refined products, 318 km
Ports: 3 major (Limon, Golfito, Puntarenas), 4 minor
Civil air; 20 major transport aircraft
Airfields: 186 total, 177 usable; 29 with permanent-
surface runways; 1 with Tunway 2,440-3 659 m; 10 with
Tunways 1,220-2 439 m; 2 seaplane stations
46
Approved For Release 2005/04/22
ee
Telecommunications; good domestic telephone service;
127,000. telephones (6.2 per 100 popl.); connection into
Central American microwave net; 55 AM, 10 FM, and 12
TV stations
DEFENSE FORCES
Military manpower: males 15-49, 460,000; 301,000 fit for
military service; average number reaching military age (18)
annually about 26,000
Supply: dependent on imports from U.S.
Military budget: for fiscal year ending 31 December
1978, $16.2 million for Ministry of Public Security, including
the Civil Guard; about 3% of total central government
budget
Atlantic
Ocean
Yo tHe
Havana \\ BAHAMAS
5 -~ * *
CUBA Gd
of Mexico
HAG ioe
JAMAICA S23
Caribbean Sea
ee
(See reference map i}
LAND
114,478 km?; 35% cultivated, 30% meadow and Pasture,
20% waste, urban, or other, 15% forested
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 3,735 km
Railroads: 14,640 km total, government-owned; 5,040 km
common-carrier lines of which 4,960 km standard gage
(1.485 m), 80 km 0.914-meter gage; about 9,600 km
plantation /industrial lines, 6,400 km standard gage (1.435
m), 3,200 narrow gage
Highways: 20,700 km total; 8,800 km paved, 11,900 km
gravel and earth surfaced
Inland waterways: 240 km
Pipelines: natural gas, 80 km
Ports: 8 major (including U.S. Naval Base at Guantan-
amo), 44 minor; Guantanamo under U.S. control
Civil air: 34 major trarisport aircraft
Airfields: 194 total, 183 usable; 47 with permanent-
surface runways; | with runway over 3,660 m, 8 with
runways 2,440-8,659 m, 95 with runways 1,220-2,439 m; 10
seaplane stations
Telecommunications: modern facilities adequately serve
military, governmental, and some civilian needs; excellent
international facilities via HF and satellite, 380,000 tele-
phones (3.9 per 100 popl.); 100 AM, 25 FM, and 24 TV
stations; 4 submarine cables
DEFENSE FORCES
Military budget: for fiscal year ending 31 December 1978
(last announced budget), $949 million; about 8.6% of total
budget','5394c079f652df72af2ae0abb29b7f4b2929da301ed3fed019b85ebfcec77faa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebfc541162a362c487fa44d7df1f7f0226f8c59ee115266ad40bf90a96d8685c',1978,'CY','Cyprus','communications',134,'LAND
9,251 km*; 47% arable and land under permanent crops,
18% forested, 10% meadows and pasture, 25% waste, urban
areas, and other
WATER
Limits of territorial waters (claimed): 12 nm
AT
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22
: CIA-RDP79-01051A000900010006-2
July 1978
od
CYPRUS LEBAN
Mediterranean
(See reference map ¥}
Railroads: none
Highways: 9,710 km total; 4,580 km bituminous surface
treated; 5,130 km gravel, crushed stone, and earth
Ports: 3 major (Famagusta, Larnaca, Limassol), 6 minor;
Famagusta under Turkish control
Civil air: 5 major transport aircraft, all leased in
Airfields: 13 total, 12 usable; 8 with permanent-surface
runways; 3 with runways 1,220-2,439 m; 4 with runways
2,440-3,656 m
Telecommunications: moderately good telecommunica-
tion system; 77,000 telephones (11.2 per 100 popl.); 12 AM, 4
FM, and 5 TV stations; tropospheric scatter circuits to
Greece and Turkey; 2 submarine coaxial cables
DEFENSE FORCES
Military budget: for fiscal year ending 31 December
1977, $33.7 million about 14% of central government budget
CZECHOSLOVAKIA
CZECHOSLOVAKIA
(See reference mag IV}
LAND
127,946 km’; 42% arable, 14% other agricultural, 35%
forested, 9% other
Land boundaries: 3,540 km
Railroads: 13,186 km total; 12,881 km standard gage
(1.435 m), 112 km broad gage (1.524 m), 193 km narrow
gage (0.750 m and 0.760 m); 2,807 km double track; 2,714
km electrified; government-owned (1975)
Highways: 73,677 km total; 60,157 km concrete, asphalt,
stone block; 13,520 km gravel, crushed stone (1976)
Inland waterways: 483 km (1977)
Pipelines: crude oil, 1,448 km; refined products, 861 km:
natural gas, 5,601 km
Freight carried: rail—275.5 million metric tons, 70.7
billion metric ton/km (1976); highway—1,048.3 million
metric tons, 16.3 billion metric ton/km (1976); waterway—
6.8 million metric tons, 3.0 billion metric ton/km (excl. int''l.
transit traffic) in approximately 417 waterway craft with
350,000 metric ton capacity (1977)
Ports: no maritime ports; outlets are Gdynia, Gdansk, and
Szczecin in Poland; Rijeka and Koper in Yugoslavia;
Hamburg, FRG; Rostock, GDR; principal river ports are
Prague, Melnik, Usti nad Labem, Decin, Komarno, Bra-
tislava (1977)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
i ss
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CZECHOSLOVAKIA/DENMARK
DEFENSE FORCES
Military budget: announced for fiscal year ending 31
December 1978, est. 19.5 billion crowns, about 7.1% of total
budget','16f04c076df72f691eacffc81fba144ccc56c5f705fc3227ac3358d455693bb4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('465384bb1109175a237e42644b1c5f884bf3d00aecad4631904791aa6ce5bd9c',1978,'DK','Denmark','communications',138,'SAS
{See reference map IV)
LAND
42,994 km? (exclusive of Greenland and Faroe Islands);
64% arable, 8% meadows and pastures, 11% forested, 17%
other
Land boundaries: 68 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 3,379 km
Railroads: 2,591 km standard gage (1.435 m); Danish
State Railways (DSB) operate 2,101 km (1,999 km rail line
and 102 km rail ferry services); 97 km electrified, 730 km
double tracked; 490 km of standard gage lines are
privately-owned and operated
Highways: approximately 66,482 km total; 64,551 km
concrete, bitumen, or stone block; 1,931 km gravel, crushed
stone, improved earth
Inland waterways: 417 km
Pipelines: refined products, 418 km
Ports: 16 major, 44 minor
Civil air: 71 major transport aircraft, including 1 leased in
and 4 leased out
Airfields: 175 total, 133 usable; 23 with permanent-
surface runways; 9 with runways 2,440-3,659 m, 6 with
runways 1,220-2,489 m; 1 seaplane station
Telecommunications: excellent telephone, telegraph, and
broadcast services; 2.53 million telephones (48.9 per 100
popl.); 6 AM, 13 FM, and 34 TV stations; 14 submarine
coaxial cables
DEFENSE FORCES
Military manpower: males 15-49, 1,216,000; 1,065,000 fit
for military service; 38,000 reach military age (20) annually
Military budget: proposed for fiscal year ending 31]
December 1978, $1.140 million; about 15.6% of proposed
central government budget
52
July 1978
Males 15-49, included with
80','09d2968a82cdb0a2c12371ee9f7b6889a1222af8a4c8eb10ea77fac9e0c9a32e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff4b2943c312c87649e1409d9d07b93c3bb0943f05d78e57e6f7239695851981',1978,'DJ','Djibouti','communications',142,'(formerly French Territory of the Afars
and Issas)
(See reference map Vij
LAND
23,310 km2?; 89% desert wasteland,
pasture, and less than 1% cultivated
Land boundaries: 517 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 314 km (includes offshore islands)
Railroads: 97 km meter gage (1.00 m)
Highways: 750 km total; 100 km paved, 650 km
improved earth
Ports: 1 major (Djibouti)
Airfields: 7 total, 7 usable; 1 with permanent-surface
runway; 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m
Civil air: no major transport aircraft
Telecommunications: fair system of urban facilities in
Djibouti and radiocommunication stations at outlying places;
3,600 telephones (2.0 per 100 popl.); 1 AM, no FM, and 1 TV
station
DEFENSE FORCES
Military manpower: males 15-49, about 30,000; about
17,000 fit for military service
Defense is responsibility of France','b4380d3f69a3ded31a272b333048516bb11b4b8ebd08261fa32f81671d103e0f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e62f0177a0f729262e5d5fe4781bfe6be571ebc09ace8ab8c9efe69be8a8b058',1978,'DM','Dominica','communications',146,'LAND
790 km*; 24% arable, 2% pasture, 67% forests, 7% other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 148 km
Atlantic
Ocean
(See reference map 7)
Railroads: none
Highways: 750 km total; 500 km paved, 250 km gravel
and earth
Ports: 2 minor (Roseau, Portsmouth)
Civil air: 1 major transport aircraft, leased in
Airfields: 1 with asphalt runway 1,472 m
Telecommunications: 3,600 telephones in fully automatic
network (4.8 per 100 popl.); VHF and UHF link to St. Lucia;
1 AM and 1 TV station','6b95738897d8865c290366ad087d7127b0764b2bfb2b91ecf3ed9158ddc2624c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e3ca56b6362a42802231ba2eefe57eb2b864a2a162898ac53fb7b367822f8ef',1978,'DO','Dominican Republic','communications',150,'Atlantic
Ocean
DOMINICAN
REPUBLIC
SS
of
Har]
Sar
Santa
JAMAICA Domingo
Caribbean Sea
ay
(See reference map it
LAND
48,692 km?; 14% cultivated, 4% fallow, 17% meadows and
pastures, 45% forested, 20% built-on or waste
Land boundaries: 36] km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 1,288 km
54
Approved For Release 2005/04/22
Railroads: 1,600 km total; 104 km government-owned
common-carrier 1.065-meter gage; 1,496 km _ privately
owned plantation lines of 4 different gages ranging from
0.60 m to 1.43 m, 0.760-meter gage predominating
Highways: 11,400 km total; 5,800 km paved, 5,600 km
gravel and improved earth
Pipelines: refined products, 69 km
Ports: 5 major (Santo Domingo, Barahona, Haina, Las
Calderas, San Pedro de Macoris), 17 minor
Civil air: 15 major transport aircraft
Airfields: 52 total, 45 usable; 11 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 9 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: relatively efficient domestic system
based on islandwide radio relay network; 127,000 telephones
(2.6 per 100 popl.); 185 AM, 31 FM, and 11 TV stations; 1
coaxial submarine cable; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,135,000; 718,000 fit
for military service; 52,000 reach military age (18) annually','1ea2062ee76aef80aa0a4124062049160022e7a9d177c06fb09d15db80eec46a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a9b4b31b435e5d2fb4b5a8ecbb389739b0cafb85467dfacc4651ffd118e2c3c',1978,'EC','Ecuador','communications',154,'Galapagos
Islands
Pacific Ocean
(See reference map iff}
LAND
274,540 km?® (including Galapagos Islands); 11% culti-
vated, 8% meadows and pastures, 55% forested, 26% waste,
urban, or other (excludes the Oriente and the Galapagos
Islands, for which information is not available)
Land boundaries: 1,931 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2,237 km (includes Galapagos Is.)
Railroads: 1,121 km total: 966 km 1.067-meter gage, 155
km 0.750-meter gage: all single track
Highways: 22,250 km total; 3,300 km paved, 11,300 km
otherwise improved, 7,650 km unimproved earth
Inland waterways: 1,500 km
Pipelines: crude oil, 623 km; refined products, 1,358 km
Ports: 3 major (Guayaquil, Manta, Puerto Bolivar), 11]
minor
Civil air: 27 major transport aircraft, including 1 leased in
Airfields: 173 total, 173 usable; 16 with permanent-
surface runways; 5 with runways 2,440-3,659 m, 22 with
runways 1,220-2,439 m; 3 seaplane stations
Telecommunications: facilities adequate only in largest
cities; 1 Atlantic Ocean satellite station; 174,000 telephones
(2.5 per 100 popl.); 250 AM, 38 FM, and 10 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,692,000; 1,103,000 fit
for military service; average number reaching military age
(20) annually 78,000
Military budget: for fiscal year ending 31 December
1978, $114.2 million; about 17.5% of central government
budget
Guayaqait
Manaus
. amazes
Iquitos
Brazi
*
Bolivia
Sucre
Sao Paulo,
3 ) MS
Valparais Uroauay Zz
Santi se 7
Buenos Aires aaa, ei
) Montevideo
Argenti na,
“Banca
5
503774 7-78
eRtiramerica
North
Atlantic
“Salvador
x
Brasilia
/
ra
va
f
pron :
Pec Rio de Janeiro
South
Atlantic
Ocean
1000 Kilometers
1000 Miles
South Georgia
SS (Falkland ts.)
if
Boundary representation is
not necessarily authoritative
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
IV a
Or
Greenland .—
Penmark),
A, : oe ee
a oe 2 Jan, tayen
ar.
De
yp
a
PM
Pt 400 Kilometers
400 Miles
’) Tomer
ne i
re H wey
& Norwegian ay
sae if
Reykjavik eArkangel sk
iceland Sea
N
N ene
ee aa Sweden s
4 Gon) Finland
3
& %','fd87bcda534822303b76375e79196c664d0e6cced35a7a606beb9f41c49ceb5e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cc71d534f6a5429ddb09d22bc52d7337936178426376507f9a52e528bf372d4',1978,'EG','Egypt','communications',158,'LAND
1,000,258 km? (including 57,498 km? occupied by Israel);
2.8% cultivated (of which about 70% multiple cropped);
96.5% desert, waste, or urban; 0.7% inland water
Land boundaries: 2,527 km (1967); approximately 2,580
km including border of occupied Sinai area (since September
1975)
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’’)
Coastline: 2,450 km (1967); includes approximately 500
km within occupied Sinai area (since September 1975)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
(See reference map V}
Railroads: 5,405 km total; 951 km double track; 25 km
electrified; 4,858 km standard gage (1.435 m), 200 km meter
gage (1.00 m), 347 km 0.750-meter gage
Highways: 47,275 km total; 12,650 km paved, 2,500 km
gravel and crushed stone, 14,100 km improved earth, 18,025
km unimproved earth
Inland waterways: 3,360 km; Suez Canal, 160 km long,
used by ocean-going vessels drawing up to 11.5 meters of
water; Alexandria-Cairo waterway navigable by barges of
metric ton capacity; Nile and large canals by barges of
420-metric ton capacity; Ismailia Canal by barges of 200- to
300-metric ton capacity; secondary canals by sailing craft of
10- to 70-metric ton capacity
Freight carried: Suez Canal (1966)—-242 million metric
tons of which 175.6 million metric tons were POL
Pipelines: crude oil, 675 km; refined products, 240 km;
natural gas, 365 km
Ports: 38 major (Alexandria, Port Said, Suez), 8 minor
Civil air; 27 major transport aircraft, including 4 leased in
and 2 leased out
Airfields: 100 total, 81 usable; 66 with permanent-surface
runways; 43 with runways 2,440-3,659 m, 1 with runway
over 3,660 m, 21 with runways 1,220-2,439 m; 1 seaplane
station
57
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
EGYPT/EL SALVADOR
Telecommunications: second-largest system in Africa but
inadequate for needs and poorly maintained; principal
centers Alexandria and Cairo, secondary centers Al Man-
surah, Ismailia, and Tanta; intercity connections by coaxial
cable and microwave; extensive upgrading in progress;
500,000 telephones (1.3 per 100 popl.); 22 AM, no FM, and
29 TV stations; 1 Atlantic Ocean satellite station; Symphonie
satellite station; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 8,592,000; 5,603,000 fit
for military service; about 384,000 reach military age (20)
annually','0042891ecab309df87d985a9d8f12416d58683245633f6628e7daa2696f24bce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cf1e434ea9c21663f4915c064ac34850b4fcd658dc83b906440913a2ffe7587',1978,'SV','El Salvador','communications',162,'Caribbean
ce
Pacific Ocean
(See reference map it}
LAND
21,400 km*; 32% cropland (9% corn, 5% cotton, 7% coffee,
11% other), 26% meadows and pastures, 31% nonagricul-
tural, 11% forested
Land boundaries: 515 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 307 km
Railroads: 600 km 0.914-meter gage, single-tracked;
Highways: 7,250 km total; 1,500 km paved, 1,300 km
gravel 4,400 km improved and unimproved earth
Inland waterways: Lempa River partially navigable
Ports: 2 major (Acajutla, La Union), 1 minor
Civil air: 8 major transport aircraft
Airfields: 161 total, 153 usable; 5 with permanent-
surfaced runways; 1 with runway 2,440-3,659 m; 10 with
runways 1,220=2,439 m; 1 seaplane station
Telecommunications: nationwide trunk radio relay sys-
tem; connection into Central American microwave net;
54,200 telephones (1.3 per 100 popl.); 60 AM, 9 FM, and 5
TV stations; 1 Atlantic Ocean COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 969,000; 594,000 fit for
military service; 46,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1978, $42.2 million; 8.4% of central government budget','8a60c7b2dff90a6d6b09d29a7488ef90745416721262225b0d3f4bfc891e61f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0338d03a3749cd993a226053fdfcd42164b1ce9e88a3d04dbb072de06342bd8e',1978,'GQ','Equatorial Guinea','communications',166,'Atlantic
Ocean
{See reference map Vi}
LAND
27,972 km?; Rio Muni, about 25,900 km’, largely forested;
Fernando Po, about 2,072 km?
Land boundaries: 539 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 296 km
Railroads: none
Highways: Rio Muni—2,460 km, including approx. 185
km bituminous, remainder gravel and earth; Fernando Po—
300 km, including 146 km bituminous, remainder gravel and
earth
Inland waterways: Rio Muni has approximately 167 km
of year-round navigable waterway, used mostly by pirogues
Ports: 2 major (Macias Nguema Biyogo, Rey Malabo), 3
minor
Civil air: 2 major transport aircraft (leased in)
Airfields: 5 total, 3 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,489 m
60
Telecommunications: fairly adequate for the size and
stage of development of the country; international commu-
nications by radio from Bata and Malabo to Cameroon,
Nigeria, and Spain; 1,700 telephones (0.5 per 100 popl.); 2
AM sstations, no FM stations, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 77,000; 38,000 fit for
military service
Military budget: for fiscal year ending 31 December
1970, $3,475,700; 14.3% of central government budget','37c60aae26ead11d71befcd50c65adfe37d11f207a6e5376c1c7551e080672f4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c371f87ac875378e8d7483c801fd6f2edcdfc2d468ced9f74e136c4f21c8e076',1978,'ET','Ethiopia','communications',170,'Saag
7 OJIBOUT,
Addis r
(See reference mag Vi)
LAND
1,178,450 km?*; 10% cropland and orchards, 55% meadows
and natural pastures, 6% forests and woodlands, 29%
wasteland, built-on areas, and other
Land boundaries: 5,198 km
WATER
Limits of territorial waters (claimed): 12 nm; sedentary
fisheries extends to limit of fisheries
Coastline: 1,094 km (includes offshore islands)
500 Kilometers
Addis Ababa* 500 Miles
Boundary representation is
not necessarily authoritative
503776 7-78
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Guinedwk gg
Bissau. ¢ 7
") Guinea
Conakry,
Freetown &
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009000100Q@6f2 Agtica
‘Sweden
Qenmark’ :
— U.S. SR.
Aral
Naordh
Abdaa Pas
ns Set
flaoean Caspian
‘ Sra
Portuggl
ha ‘ 7 7
G ty ee * S44 ; ;
rr Rabat y Algiers Onis pratta Cyprus Syria aa
al Tunisia fyiedifterramean Sea ae
- Gees Morocco * israel~
Canary te. (Sp. i Tripoli *
» F a ae ; é i f er
e ; tie aD a8 ae!
fa ’ A i = ~
ip ral Algeria Libya : Qatar
Sahara . Egypt ; UAE
Pa .
: : : Saudi
i Arabia
: Sape Verde : iS o Port Sudar, L Oman
ces Heed
‘ - . Hod 3
aK! : Moaili : a : s
Praia = Senegal es Niger ve
x '' Timbuktu ; idk ; emen
Dakar\\ Banjul Mitbiiwa. = iSanad
The Gambiage BARh Khartoum , Asifera® s
3 ; Yemen
Ss {Aden)
Djiboufi ibouti
“Berbera
sau
eKano
Addis.
* Ababa Oe
Ethiopia Yo
ra
ent
Sierra,
Leone
Monrovia ™<:* ? he
Liberhe tia = i :
“t Abidjan Porto-Novo . s
L a Son EAMETOON, Bangui -* Somalia
Malabo’ : oa
£q. Guinea -* Ea eee *mogadiscio
Sao Fome and vo - Kenya
Principe Sw # Libreville Conge ie f
Sao Tomé, = Nairobi
Eq. Guinea + a Gabon * : :
'' wake
‘i 7 ictoria tae
Brazzaville Bujumbura Burundi “Mombasa aces
‘ * Kinshasa 3 ictoria
ic Lake | Tanzania ,,Dar es Salaam
x a i \\ Tanganyika 5
saPua Luanda).
Rid oe 4 Comoros
ATI ARLPEC } gMoroni
l obtog Angola ns
(ecean 7 Litangwe
/
j
Namibi y Antananarivo
a aminia Mauritius
\\. Madagascar Pot Lou;
‘ Mozambique cs Rewaic
South Africa y a Botswana : i
Walvis Bay) | Windhoek | Gaborone : i
: - Pretoria. f
\\ . coe ge
\\ “Mbabane y Maputo
5, a Swaziland
Maserug i a
South Attica. \\ecutno
a a a cr eee
Cape Towrigee
ie) 500 1000 Kilometers
it = me
0 500 1000 Miles
Boundary representation is
not necessarily authoritative
503777 7-78
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-0109/g4000@9091908$-2and Asia
Greenland Fe
Chee es ng oF 3 a d
iceland ¥ a
sa aS United an
| States s
Nori Pole - SO
as
Arctic *"- Ocean cy ae v. 7
; Sweden RX , B, =
$ j £ 4 Lae urmansk td ae a Se rl a *
Bey ow Finland oo ee , :
DR bai Seas Me a &/ 2 ; Q Cee a - :
mm VEN wee, Se ou :
“29 poland iga Leningrad Arkhangel’sk 2 r
bs a e Minsk wel ? ae
Moscow
okey
Yakutsk
°
a oe SuNPy SEN Sea ardlowsk 7
é a" Vol d wi
_. Black! or soe Omsk IN , pe
Sea Novosibirsk \\ Pacific
om
Ocean
eae XS
,Ha-erh-pin,
Ulaanbaatar
ideas (Harbin)
Mongotia
Lan-chou »
e Shen-yang, a pith yy
Wu-lu-mu-ch''i ns
(Urumehi) Pei-ching wenavang i arise
. (Peking)
Pao-t''ous * c seit
ju
wage) Solt DUAL
hi ta
om fndian clair mie ja pan
etisi-an
Chinese fine Ching “sien
of contrat ®Shang-hai
2 WVu-har
eChreng-tu e
aipei
Kuang-chot Taiwan
oK''un-ming e(Cantph)
s Macag fae Kong
(A)
Kathmandd
» Ahmadabad
=" Sappines
ve Lanka
a Colombo ° . Brunei an .
at © CULK.) af
Maldives > dan, a a Lumpur Sarawy
= SO "ia
Sa
ou tra ing alimantan
sh mbangy! 9 Bani jarmasin
ye ndonesi
indian Ocean er ye %
Yogyakanae— a
ay c','ccabed7cd9fc1853aa48521f54f8c6ecf3152a04b01819662ebe41089db3b1d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('563e4b43ca214f3b9a82efdc95f6031c54ecd94ee156220f7439b68db2fe6e63',1978,'DE','Germany','communications',175,'Railroads: 1,014 km total; 676 km meter gage (1.00 m), 32
km 1.067-meter gage, 306 km 0.95-meter gage; all single
track
Highways: 10,895 km total; 3,229 km bituminous, 7,666
km crushed stone, gravel, or stabilized earth, remainder
earth
Inland waterways: 41 navigation possible on Lake Tana
and on approx. 225 km of unconnected and_ basically
unimproved waterways, of which only 114 km are navigable
year round
Ports: 2 major (Assab, Massawa)
Civil air: 20 major transport aircraft
Airfields: 190 total, 176 usable; 7 with permanent-surface
runways; 1 with runway over 3,660 m, 6 with runways
2,440-3,659 m, 49 with runways 1,220-2,489 m
Telecommunications: system composed of open-wire
lines, radiocommunication stations, and small number of
multiconductor cable and radio-relay links; principal center
Addis Ababa, secondary center Asmara; 73,000 telephones
(0.3 per 100 popl.); 4 AM stations, no FM stations, and 1 TV
station
61
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ETHIOPIA/FALKLAND ISLANDS/FAROE ISLANDS
DEFENSE FORCES
Military manpower: males 15-49, 7,366,000; 3,920,000 fit
for military service; average number reaching military age
(18) annually 301,000
Military budget: for fiscal year ending 6 July 1977,
$104,445,000; 14.7% of central government budget
FALKLAND ISLANDS
(Islas Malvinas) !
Atlantic
Ocean
FALKLAND
St ISLANDS
_
(See reference map iit)
LAND
Colony—12,168 km?; area consists of sore 200 small
islands, chief of which are East Falkland (6,680 km?) and
West Falkland (5,276 km?*); dependencies—consists of the
South Sandwich Islands, South Georgia, and the Shag and
Clerke Rocks
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 1,288 km
Railroads: none
Highways: 35 km total; 16 km paved, 19 km gravel, and
earth; no other made-up roads in the islands beyond the
immediate vicinity of Stanley
Ports: 1 major (Port Stanley), 4 minor
Civil air: no major transport aircraft
Airfields: 1 usable airfield, 1 seaplane station
Telecommunications: government-operated and _radio-
telephone networks providing effective service to almost all
points on both islands; approximately 650 telephones (est. 30
per 100 popl.); 1 AM station
Railroads: 947 km, 0.914-meter gage, single-tracked; 832
km government-owned, 115 km_ privately owned
Highways: 13,700 km total; 2,550 km paved, 3,200 km
gravel, 5,500 km improved earth, 2,450 km unimproved
earth
Inland waterways: 260 km navigable year-round; addi-
tional 730 km navigable during high-water season
Pipelines: crude oil, 48 km
Ports: 2 maior (Puerto Barrios, Santo Tomas de Castilla), 3
minor
Airfields: 383 total, 381 usable; 7 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 16 with runways
1,220-2,489 m; 1 seaplane station
Civil air: 11 major transport aircraft
Telecommunications: modern telecom facilities limited
to Guatemala City; 58,500 telephones (0.9 per 100 popl.); 97
AM, 20 FM, and 5 TV stations, connection into Central
American microwave net
DEFENSE FORCES
Military manpower: males 15-49, 1,489,000; 966,000 fit
for military service; about 65,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1978, $58.5 million; 6.2% of central government
budget
Railroads: 7,863 km total; 7,246 km 1.067-meter gage,
525 km 0.750-meter gage, 92 km 0.600-meter gage; 211 km
double track; 101 km electrified; government owned
Highways: 93,053 km total; 26,573 km paved, 41,521 km
gravel or crushed stone, 24,959 km improved or unimproved
earth
Inland waterways: 21,579 km; Sumatra 5,471 km, Java
and Madura 820 km, Borneo 10,460 km, Celebes 241 km,
and Irian Barat 4,587 km
Ports: 10 major, 63 minor
Civil air: approximately 130 major transport aircraft
Airfields: 393 total, 367 usable; 66 with permanent-
surface runways; 11 with runways 2,440-3,659 m, 66 with
runways 1,220-2,489 m
Telecommunications: interisland microwave system and
HIF police net; domestic service poor, international service
good; radiobroadeast coverage good; 314,000 telephones (0.2
per 100 popl.); 291 AM, 1 FM, and 13 TV stations; 1
international ground satellite station (1 Indian Ocean
antenna and | Pacific Ocean antenna), and 40 domestic
ground satellite stations
Arabian
(See reference map V}
LAND
1,647,240 km’; 14% agricultural, 11% forested, 16%
cultivable with adequate irrigation, 51% desert, waste, or
urban, 8% migratory grazing and other
Land boundaries: 5,318 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing, 50
nm)
Coastline: 3,180 km, including islands, 676 km
96
Railroads: 4,601 km total; 4,509 km standard gage
(1.435 m), 92 km 1.676-meter gage
Highways: 43,442 km total; 12,060 km bituminous and
bituminous treated, 22,920 km gravel and crushed stone,
8,462 km improved earth
Inland waterways: 904 km, excluding the Caspian Sea,
104 km on the Shatt al Arab
Pipelines: crude oil, 3,072 km; refined products, 3,597
km; natural gas, 2,317 km
Ports: 7 major, 6 minor
Civil air: 57 major transport aircraft, including 7 leased in
and 1 leased out
Airfields: 181 total, 167 usable; 65 with permanent-
surface runways; 13 with runways over 3,660 m, 15 with
runways 2,440-3,659 m, 70 with runways 1,220-2,439 m
Approved For Release 2005/04/22 :
Telecommunications: advanced system of high-capacity
radio-relay links, open-wire lines, cables, and tropospheric
links; principal center Tehran, secondary centers Isfahan,
Meshed, and Tabriz; 805,600 telephones (2.0 per 100 popl.);
35 AM, 2 FM, and 67 TV stations; 1 satellite station with
Atlantic Ocean and Indian Ocean antennas, extensive
upgrading in progress
DEFENSE FORCES
Military manpower: males 15-49, 8,084,000; 4,789,000 fit
for military service; about 350,000 reach military age (21)
annually
Military budget: for fiscal year ending 20 March 1979,
$9,933 million; 17% of central government budget
Railroads: 2,089 km total; 503 km standard gage (1.435
m), 1,586 km meter gage (1.00 m)
Highways: 17,140 km total; 7,940 km bituminous, 660 km
gravel; 2,000 km improved earth; 6,540 km unimproved
earth
Pipelines: 797 km crude oil; 10 km refined products; 72
km _ natural gas
Ports: 4 major, 8 minor
Civil air: 14 major transport aircraft
Airfields: 33 total, 26 usable; 11 with permanent-surface
runways; 3 with runways 2,440-3,659 m; 14 with runways
1,220-2,489 m; 1 seaplane station
Telecommunications; the system is above the African
average in amount and capacity of facilities which consist of
open-wire lines with multiconductor cable or radio relay;
key centers are Safaqis, Susah, Bizerte, and Tunis; 100,000
telephones (1.7 per 100 popl.); 3 AM, 3 FM, and 7 TV
stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 1,547,000; 850,000 fit
for military service; about 59,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1978, $153 million; 6% of central government budget
TURKEY
LAND
766,640 km?; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land _ boundaries: 2,574 km
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km
Railroads: 8,253 km standard gage (1.485 m); 143 km
double track; 72 km electrified
Highways: 60,000 km total; 21,000 km_ bituminous;
28,000 km gravel or crushed stone; 2,500 km improved
earth; 8,500 km unimproved earth
Approved For Release 2005/04/22
Inland waterways: approx. 1,689 km
Pipelines: 1,288 km crude oil; 2,055 km refined products
Ports: 10 major, 35 minor
Civil air: 24 major transport aircraft (including 5 leased
in)
Airfields: 120 total, 101 usable; 57 with permanent-sur-
face runways, 3 with runways over 3,660 m, 22 with
runways 2,440-3,659 m, 23 with runways 1,220-2,439 m
Telecommunications: new trunk domestic radio-relay
net, good international service; 1.1 million telephones (2.7
per 100 popl.); 40 AM, 4 FM, and 36 TV stations; 1
submarine cable; Comsat station near completion
DEFENSE FORCES
Military manpower: males 15-49, 10,665,000; 6,282,000
fit for military service; about 461,000 reach military age (20)
annually
Military budget: proposed for fiscal year ending 28
February 1979, $2.3 billion; about 22% of proposed central
government budget','3fdadc004e1f76f77f32a501346ed6c0a71adb6a34c7f32e48f983fd1955edec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df69469ccda7622383d78474c3b5cbea33f32b78264805117c84941aa45da078',1978,'FO','Faroe Islands','communications',178,'LAND
1,340 km’; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited islands and
a few uninhabited islets
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
FAROE ISLANDS/FIJI
Norwegian
Sea
FAROE ©
ISLANDS
Atlantic
(See reference map IV}
WATER
Limits of territorial waters (claimed): 12 nm; fishing
200 nm
Coastline: 764 km
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less than
1,220 m
Civil air: no major transport aircraft
Telecommunications: good international communica-
tions; fair domestic facilities; 15,000 telephones (85 per 100
popl.); 1 AM, and 3 FM stations; 3, coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49 included with Denmark','cfd406b33c3b74a87e71071a0400bf29794bc646cfe11ea80f8229aa9430e8ed','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d91e3524a7a21169127da538b03adf8915ccfdbbad06399c674626a1b02163d7',1978,'FJ','Fiji','communications',182,'LAND
18,272 km’; landownership—83.6% Fijians, 1.7% Indians,
6.4% government, 7.2% European, 1.1% other; about 30% of
land area is suitable for farming
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,129 km
63
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Coral Sea
(See reference map VIE}
Railroads: 644 km narrow gage (0.610 m); owned by Fiji
Sugar Corp., Ltd.
Highways: 3,205 km total (1976); 307 km paved, 2.676
km gravel, crushed stone, or stabilized soil] surface; 222
unimproved earth
Inland waterways: 203 km; 122 km navigable by
motorized craft and 200-metric ton barges
Ports: | major, 6 minor
Civil air: 5 major transport aircraft
Airfields: 15 total, 15 usable; 2 with permanent-surface
runways, | with runway 2,440-3,659 m, 1 with runway
1,220-2,489 m
Telecommunications: modern local, interisland, and
international (wire/radio integrated) public and special-pur-
pose telephone, telegraph, and teleprinter facilities; regional
radio center; important COMPAC cable link between
U.S./Canada and New Zealand/Australia, et al.; 80,700
telephones (5.3 per 100 popl.); 6 AM, 2 FM, and no TV
Stations; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 153,000; 84,000 fit for
military service; 6,000 reach military age (18) annually
Military budget: the defense of the Fiji Islands was the
responsibility of the U.K. until 10 October 1970; military
budget for 1971, $314,000
™ Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978','675276ff28ca35728bf10fd506cce670df28e274ebb0fb3d5028b868e1b917e9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ff64241c743112b5363ddd9cb118b40247b27cfde9ce3c9e0323f3d06113af0',1978,'FI','Finland','communications',186,'Norwegian
Sea
(See reference mep {V}
LAND
336,700 km?; 8% arable, 58% forested, 34% other
Land boundaries: 2,534 km
WATER
Limits of territorial waters (claimed): 4 nm; fishing 12
nm; Aaland Islands, 3 nm
Coastline: 1,126 km (approx.) excludes islands and coastal
indentations
Railroads: 6,038 km total; Finnish State Railways (VR)
operate a total 6,010 km 1.524-meter gage, 477 km multiple
track, and 395 km electrified; 22 km 0.750-meter gage and 6
km 1.524-meter gage are privately owned
Highways: about 73,552 km total in national classified net
work, including 31,000 km paved (bituminous, concrete,
bituminous surface treated) and 42,552 km unpaved
(stabilized gravel, gravel, earth); additional 29,440 km of
private (state subsidized) roads
Inland waterways: 6,597 km total (including Saimaa
Canal); 3,700 km suitable for steamers; Saimaa Canal locks
(84 m by 13.2 m with a 5.2 m depth over sill) can
accommodate vessels of up to 82 m in length, 11.8 m beam,
4.4 m draft, and 24.5 m mast height
Pipelines: natural gas, 161 km
Ports: 11 major, 14 minor
Civil air: 40 major transport aircraft, including 2 leased
out
Airfields: 112 total, 111 usable; 36 with permanent-
surface runways; 17 with runways 2,440-3,659 m, 24 with
runways 1,220-2,439 m
Telecommunications: good telecom service from cable
and radio-relay network; 1.94 million telephones (40.9 per
LOO popl.); 15 AM, 40 FM, and 76 TV stations; 4 submarine
cables, including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 1,217,000; 974,000 fit
for military service; 39,000 reach military age (17) annually
Military budget: proposed for fiscal year ending 31
December 1978, $514.8 million; about 5.5% of central
government budget
66','f0899f34401d6d134f5822d53107c2b9c4f24c2797725c3355e2100cd82bd98a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58c649684a1eaf3cd0f4bffde1a8958bd46b1d8d24078942c411f7408c300e5a',1978,'FR','France','communications',190,'I North Sea
Atlantic = ~ <
Ocean ee aris
rt FRANCE
}
(See reference map IV}
LAND
551,670 km?; 35% cultivated, 26% meadows and pastures,
14% waste, urban, or other, 25% forested
Land boundaries: 2,888 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 3,427 km (includes Corsica, 644 km)
Railroads: 36,810 km total; French National Railways
(SNCF) operates 34,717 km standard gage (1.435 m); 9,374
kin electrified, 15,630 km double or multiple track; 2,093
km of various gages (1,000 m to 1,445 m), privately owned
and operated
Highways: 788,580 km total; 128,745 km bitumen and
concrete (incl. 2,415 km_ of controlled access, divided
“AUTOROUTES”); 339,315 km bituminous treated;
301,000 km crushed stone and gravel; 19,520 km improved
earth; in addition, there are approximately 700,065 km of
local farm and forest roads
Inland waterways: 14,912 km; 5,604 km heavily traveled
67
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
FRANCE/FRENCH GUIANA
Pipelines: crude oil, 2,253 km; refined products, 4,344
km; natural gas, 22,047 km
Ports: 23 major, 165 minor
Civil air: 317 major transport aircraft, including 2 leased
in and 3 leased out
Airfields: 453 total, 434 usable; 221 with permanent-
surface runways; 2 with runways over 3,660 m, 30 with
runways 2,440-3,659 m, 122 with runways 1,220-2,439 m; 2
seaplane stations
Telecommunications: highly developed system provides
satisfactory telephone, telegraph, and radio and TV broad-
cast services; 15.5 million telephones (29.3 per 100 popl.); 55
AM, 94 FM, and 1,500 TV stations; 22 submarine cables; 2
communication satellite ground stations with 4 Atlantic
Ocean, and 2 Indian Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 12,888,000; fit for
military service 10,398,000; 425,000 reach military age (18)
annually
Military budget: for fiscal year ending 31 December
1978, $13.9 billion; about 18% of central government budget
RHODESIA
Indian Ocean
(See reference map Vi}
LAND
391,090 km?; 40% arable (of which 6% cultivated), 60%
available for extensive cattle grazing; 39% European
alienated lands (farmed by modern methods), 48% African,
7% national land, 6% not alienated
Land boundaries: 3,017 km
Railroads: 3,239 km narrow gage (1.067 m); 41 km double
track
Highways: 78,428 km total; 7,995 km paved, 32,855 km
crushed stone, gravel, stabilized soil, or improved earth:
37,578 km unimproved earth (est. )
Inland waterways: 280 km on Lake Kariba
Pipelines: 8 km crude oil (nonoperating)
Airfields: 369 total, 364 usable; 16 with permanent-sur-
face runways; 2 with runways over 3,660 m, 1 with runway
2,440-3,659 m, 30 with runways 1,220-2,439 m
Civil air: 16 major transport aircraft (including 2 leased
out)
Telecommunications: system is one of the best in Africa;
consists of radio-relay links, open-wire lines, and radiocom-
munication stations; principal center Salisbury, secondary
center Bulawayo; 190,300 telephones (2.8 per 100 popl.); 8
AM, 1 FM, and 5. TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,511,000; 923,000 fit
for military service; average number reaching military age
(18) annually, 71,000
170','fd4cf4e930c658d06dc6a04894c24e426e31411e02a1f47c90e62a757c218379','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('356b3a3e03f2e312b06a61358be036eb1950bdd67f6699b638481b5e98c81720',1978,'GF','French Guiana','communications',194,'Atlantic Ocean
FAENCH
{See reference map tl)
LAND
90,909 km?*; 90% forested, 10% wasteland, built-on, inland
water and other, of which .05% is cultivated and pasture
Land boundaries: 1,183 km
WATER
Limits of territorial waters (claimed); 12 nm
Coastline: 378 km
Railroads: 32 km private plantation line, 0.600-meter
gage
Highways: 500 km total; 425 km paved, 75 km improved
and unimproved earth
Inland waterways: 460 km, navigable by small ocean-
going vessels and river and coastal steamers; 3,300 km
possibly navigable by native craft
Ports: 1 major (Cayenne), 7 minor
Civil air: no major transport aircraft
Airfields: 13 total, 10 usable; 2 with permanent-surface
runways; | with runway 2,440-3,659 m
Telecommunications: limited open-wire and radio-relay
system with about 8,906 telephones (17.8 per 100 popl.); 9
AM, 2 FM, and 2 TV stations; | Atlantic Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 13,000; 9,000 fit for
military service','f37ae946afa78d01266a5c7f635140f26dac5c8ce46d6e6b26ed932ba3585dd2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffd7acbb8668ea310feb7299b5f2ec67f4994ab03bea6045cff3205fafe64a4c',1978,'PF','French Polynesia','communications',198,'LAND
About 4,000 km?
WATER
Limits of territorial waters: 12 nm
Coastline: about 2,525 km
Highways: 3,700 km, all types
Ports: 1 major, 6 minor
Airfields: 28 total, 28 usable; 10 with permanent-surface
runways, 2 with runways 2,440-3,659 m, 14 with runways
1,220-2,489 m; 2 seaplane stations
Civil air: about 3 major transport aircraft
69
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
FRENCH POLYNESIA/GABON
Telecommunications: 14,700 telephones (11.3 per 100
popl.); 72,000 radio and 14,000 TV sets; 5 AM, 2 FM, and 6
TV stations
DEFENSE FORCES
Defense is responsibility of France.','9e4c629652906934608314988b8cb8266bf9a98742b4d3e5e5d3eb394a5c1fbe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4def3dc17a01491abf76583af279b83ca1a46349e3fbef60b2ff9463c94c05a',1978,'GA','Gabon','communications',202,'Atlantic
Ocean
(See reference map V1)
LAND
264,180 km?*; 75% forested, 15% savanna, 9% urban and
wasteland, less than 1% cultivated
Land boundaries: 2,422 km
WATER
Limits of territorial waters (claimed): 100 nm; fishing,
150 nm
Coastline: 885 km
Railroads: none
Highways: 6,878 km total; 342 km paved, 5,636 km
gravel and/or improved earth, remainder unimproved earth
Inland waterways: approximately 1,600 km perennially
navigable
Pipelines: crude oil, 129 km
Ports: 3 major (Libreville, Port-Gentil, Owendo), 2 minor
Civil air: 29 maior transport aircraft, including 1 leased in
and 2 leased out
Airfields: 163 total, 102 usable; 6 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 20 with runways
1,220-2,489 m; 1 seaplane station
Telecommunications: system of open-wire, radio-relay,
tropospheric scatter links and radiocommunication stations;
1 Atlantic Ocean satellite station; 5 AM, no FM, and 3 TV
stations; 7,000 telephones (1.3 per 100 popl.)
DEFENSE FORCES
Military manpower: males 15-49, 135,000; 69,000 fit for
military service; 6,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1978, $52,627,100; 5.1% of central government budget
THE GAMBIA
BISSAU>
Atlantic Ocean
(See reference map Vi}
LAND
10,360 km?; 25% uncultivated savanna, 16% swamps, 4%
forest parks, 55% upland cultivable areas, built-up areas, etc.
Land boundaries: 740 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 80 km
Railroads: none
Highways: 1,858 km total; 190 km bituminous-surface
treated, 1,330 km egravel/laterite, remainder unimproved
earth
Inland waterways: 605 km
Ports: 1 major (Banjul)
Civil air: no major transport aircraft
Airfields: 1 usable with permanent-surface runway
1,220-2,439 m; 1 seaplane station (non-operational)
Telecommunications: adequate network of radio-relay;
2,700 telephones (0.5 per 100 popl.); 1 AM station, 1 FM
station, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 127,000; 63,000 fit for
military service
GERMAN DEMOCRATIC REPUBLIC
LAND
108,262 lam?*; 43% arable, 15% meadows and pasture, 27%
forested, 15% other
Land boundaries: 2,309 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 901 km (including islands)
Railroads: 14,306 km total; 13,975 km standard gage
(1.435 m), 331 km meter (1.00 m) or other narrow gage,
2,960 km double track standard gage (1.435 m); 1,508 km
overhead electrified (1976)
Highways: 127,530 km total; 47,530 km concrete, asphalt,
stone block, of which 1,679 are autobahn and limited access
roads; over 80,000 km asphalt treated, gravel, crushed stone,
and earth (1976)
Inland waterways: 2,546 km (1978)
Freight carried: rail—295.7 million metric tons, 51.7
billion metric ton/km (1976); highway—670.3 million
metric tons, 18.4 billion metric ton/km (1976); waterway—
140.0 million metric tons, 2.0 billion metric ton/km (excel.
int’l. transit traffic) (1977)
Pipelines: crude oil, 1,075 km; refined products, 350 km;
natural gas 483 km
Ports: 4 major (Rostock, Wismar, Stralsund, Sassnitz), 13
minor (1978)
DEFENSE FORCES
Military budget: announced for fiscal year ending 31
December 1978, 11.6 billion marks; about 8.9% of total
budget
GERMANY, FEDERAL REPUBLIC OF
North Sea
(See reference map 1V)
LAND
248,640 km? (including West Berlin); 33% cultivated, 23%
meadows and pastures, 13% waste or urban, 29% forested,
2% inland water
Land boundaries: 4,232 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 1,488 km (approx.)
Railroads: 33,453 km total; 29,082 km government-
owned, standard gage (1.435 m), 12,491 km double track;
9,760 km electrified; 4,421 km non-government owned;
3,997 km standard gage (1.435 m); 214 km electrified; 424
km meter gage (1.00 m); 186 km electrified
Highways: 398,720 km total; 161,400 km _ classified,
includes 153,160 km cement-concrete, bituminous, or stone
block (includes 5,792 km of autobahnen); 8,240 km gravel,
crushed stone, improved earth; in addition, 237,320 km of
unclassified roads of various surface types
Inland waterways: 5,222 km of which almost 70% usable
by craft of 990 metric-ton capacity or larger
Pipelines: crude oil, 1,931 km; refined products, 1,942
km; natural gas, 95,414 km
Ports: 10 major, 11 minor
Civil air: 176 major transport aircraft (including 4 leased
out)
Airfields: 482 total, 388 usable; 211 with permanent-
surface runways; 3 with runways over 3,660 m, 33 with
runways 2,440-3,659 m, 40 with runways 1,220-2,439 m
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GERMANY, FEDERAL REPUBLIC OF/GHANA
Telecommunications: highly developed, modern tele-
communication service to all parts of the country; fully
adequate in all respects; 21.2 million telephones (34.4 per
100 popl.); 90 AM, 129 FM, and 2,350 TV stations; 6
submarine cables; satellite station with 1 Indian Ocean and 2
Atlantic Ocean antennas, and symphonie antenna
DEFENSE FORCES
Military manpower: males 15-49, 14,775,000; 12,378,000
fit for military service; 496,000 reach military age (18)
annually
Military budget: for fiscal year ending 31 December
1978, $16,863 million; about 18% of the central government
budget','fa938c3102c5e471a26fdd431fa2e451f59f6847fe43cae8f42ebc634475192f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16c856d926485527650a5b83d437a55d6581199f3678342f10fbfe2036a5b78e',1978,'GN','Guinea','communications',206,'{See reference map V1}
LAND
238,280 km*; 19% agricultural, 60% forest and brush, 21%
other
Land boundaries: 2,285 km
WATER
Coastline: 539 km
Limits of territorial waters (claimed): 200 nm
Railroads: 953 km, all 1.067-meter gage; 32 km double
track; diesel locomotives gradually replacing steam engines
Highways: 34,447 km total; 5,260 km concrete or
bituminous surface, 19,945 km gravel or laterite, 9,242 km
unimproved earth
Inland waterways: Volta, Ankobra, and Tano rivers
provide 235 km of perennial navigation for launches and
lighters; additional routes navigable seasonally by small
craft; Lake Volta reservoir provides 1,125 km of arterial and
feeder waterways
Pipelines: refined products, 8 km
Ports: 2 major (Tema, Takoradi), 1 naval base (Sekondi), 4
minor
Civil air: 15 major transport aircraft
Airfields: 19 total, 18 usable; 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 9 with runways
1,220-2,439 m
Telecommunications: fair system of open-wire and cable,
radio-relay links and radiocommunication stations; 66,000
telephones (0.7 per 100 popl.); 6 AM, no FM, and 8 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 2,375,000; 1,309,000 fit
for military service; 108,000 reach military age (18) annually
Atlantic Ocean
(See reference map Vi}
LAND
246,050 km?; 3% cropland, 10% forest
Land boundaries: 3,476 km
83
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GUINEA/ GUINEA-BISSAU
WATER
Limits of territorial waters (claimed): 130 nm
Coastline: 346 km
Railroads: 805 km meter gage (1.00 m), 8 km standard
gage
Highways: 7,604 km total; 4,949 km paved, remainder
unimproved earth
Inland waterways: 1,795 km; 500 km navigable by small
oceangoing vessels, 1,295 km navigable by shallow-draft
steamers and barges
Ports: 1 major (Conakry), 3 minor
Civil air: 9 major transport aircraft
Airfields: 17 total, 16 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 9 with runways
1,220-2,439 m; 3 seaplane landing areas
Telecommunications: inadequate system of openwire
lines, small radiocommunication stations, and 1 radio-relay
link; principal center Conakry, secondary center Kankan;
8,300 telephones (0.2 per 100 popl.); 1 AM station, no FM,
and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 995,000; 502,000 fit for
military service
Military budget: for fiscal year ending 30 September
1970 (latest information available), $6,073,000; 8.0% of
central government budget
Railroads: 657 km of the 1,173 km Abidjan to Ouagadou-
gou, Upper Volta line, all single track meter gage (1.00 m);
only diesel locomotives in use
Highways: 46,675 km total; 2,388 km bituminous and
bituminous-surface treatment; 33,097 km gravel, crushed
stone, laterite, and improved earth; 11,090 km unimproved
Inland waterways: 740 km navigable rivers and numer-
ous coastal lagoons
no Communist party; possibly some
104
Ports: 2. major (Abidjan, San Pedro), 3 minor
Civil air: 18 major transport aircraft
Airfields: 50 total, 48 usable; 3 with permanent-surface
runways; 2 with runways 2,440-3,659 m; 8 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: system only slightly above African
average; consists of open-wire lines and radio relay links,
which provide incomplete coverage of country; Abidjan is
only center; 58,700 telephones (0.9 per 100 popl.); 2 AM, 4
FM, and 6 TV stations; | Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,579,000; 820,000 fit
for military service; 55,000 males reach military age (8)
annually
Military budget: for fiscal year ending 31 December
1977, $78,153,621; about 5.2% of total operating budget
BISSAU
Atlantic
Ocean
(See ceference map V1)
LAND
196,840 km?; 13% forested, 40% agricultural
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 2,680 km
(12%
WATER
Limits of territorial waters (claimed): 150 nm (fishing
200 nm); 200 nm exclusive economic zone
Coastline: 531 km','0ae0cf233a54e386885cf5116b04e8e1232da6df1b8d16c1be0bc1d496cf94f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0ef0a2d2a65269ca1dba8e88762a84de5c62cc590bab7cad7ec33a845b9f115',1978,'GI','Gibraltar','communications',210,'LAND
6.5 km?
Land boundaries: 1.6 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 12 km
Railroads: none
Highways: 56 km, mostly paved
Ports: 1 major (Gibraltar)
Civil air: 1 major transport aircraft
Airfields: | permanent-surface runway, 1,220-2,439 m, 1
seaplane station
Telecommunications: international radiocommunication
facilities; automatic telephone system serving 8,100 tele-
phones (27.1 per 100 popl.); 1 AM, 1 FM, and 2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 6,000; about
8,000 fit for military service
Defense is responsibility of United Kingdom
pound=
GILBERT ISLANDS
NOTE: On October 1, 1975, by Constitutional Order, the
Ellice Islands were formally separated from the British
colony of Gilbert and Ellice Islands, thus forming the new
colony of Tuvalu. The remaining islands in the former
Gilbert and Ellice Islands Colony were renamed the Gilbert
Islands.
The islands that comprise the Gilbert Islands Colony are
the Gilbert Islands; Fanning Atoll and Washington Island in
the Line Islands; Ocean Island; and those islands claimed by
the United States: Caroline, Christmas, Flint, Malden,
Starbuck, and Vostok in the Line Islands; and Birnie,
Gardner, Hull, McKean, Phoenix, and Sydney in the
Phoenix Islands.
LAND
About 684 km?
UNITED “y
Pacific Ocean STATES
_ GILBERT
* ISLANDS
PAPUA Sy
: mee BY
NFA ea “MA
"S; TUVALU
on
© Fidl
(See refarence map Vill}
WATER
Limits of territorial waters: 3 nm
Coastline: about 1,143 km
Railroads: none
Highways: 483 km of motorable roads
Inland waterways: small network of canals, totaling 5
km, in Northern Line Islands
Ports: 1 minor
Civil air: no major transport aircraft
Telecommunications: 1 AM _ broadcast station; 250
telephones (0.1 per 100 popl.); connected with Lisbon,
Portugal, via cable broadcasts','44a983286a151f4487ffccc073f093a1d871b8b4fd2f10329132ccee0558a7ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5746e6a2ba424fa1fe3784fed90c6d35956b4e309254e091f43cbde01e7c53d',1978,'GR','Greece','communications',214,'{See reference map !V;
LAND
132,608 km?*; 29% arable and land under permanent
crops, 40% meadows and pastures, 20% forested, 11%
wasteland, urban, other
Land boundaries: 1,191 km
WATER
Limits of territorial waters (claimed): 6 nm
Coastline: 13,676 km
Railroads: 2,476 km total; 1,565 km standard gage (1.485
m) of which 36 km electrified and 100 km double track, 889
km meter gage (1.000 m), 22 km narrow gage (0.750 m); all
government-owned
Highways: 36,714 km total; 18,223 km paved, 12,451 km
crushed stone and gravel, 5,062 km improved earth, 978 km
unimproved earth
Inland waterways: system consists of 3 coastal canals and
3 unconnected rivers which provide navigable length of just
less than 80 km
Pipelines: crude oil, 26 km, refined products, 547 km
Ports: 17 major, 37 minor
Airfields: 70 total, 65 usable; 49 with permanent-surface
runways; 17 with runways 2,440-3,659 m, 23 with runways
1,220-2,439 m
Civil air: 32 major transport aircraft
Telecommunications: adequate modern networks reach
all areas on mainland and islands; 2.18 million telephones
(23.1 per 100 popl.); 31 AM, 30 FM, and 34 TV stations; 5
coaxial submarine cables; 1 satellite station with 1 Atlantic
Ocean antenna and 1 Indian Ocean antenna
DEFENSE FORCES
Military manpower: males 15-49, 2,266,000; 1,737,000 fit
for military service; about 76,000 reach military age (21)
annually
Military budget: est. for fiscal year ending 31 December
1978, $1,651 million; about 20% of central government
budget','ebca888fed2d10e27d276439b59c2bcdd341f95340d26ea930a33bd4780e1b4e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab3cce06cefb3e2612491c80609e1d5536c964140530f770e0957d2e3a0575bc',1978,'GL','Greenland','communications',218,'. 9 {CELAND 3 .
oe aks ic
Atlantic Ocean
(See reference map t}
LAND
2,175,600 km?; less than 1% arable (of which only a
fraction cultivated), 84% permanent ice and snow, 15%
other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 44,087 km (approx., includes minor islands)
Railroads: none
Highways: 80 km
Ports: 7 major, 16 minor
Civil air: 2 major transport aircraft
Denmark)
(registered in
Airfields: 11 total, 6 usable; 3 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 2 with runways
1,220-2,4389 m; 7 seaplane stations
Telecommunications: adequate domestic and interna-
tional service provided by cables and radio relay: 9,000
telephones (17.0 per 100 popl.); 5 AM, 6 FM, and 2 TV
stations; 2 coaxial submarine cables
DEFENSE FORCES
Military manpower:','da9bda19d2474cb89064bbe7295732b264aaa09d4aac34771d13c8120d54760b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13050521b2e5858838479c7f77b7bedc9b836b60640c802f76076e982b267465',1978,'GD','Grenada','communications',222,'3°77 puerro
exes ERT Atlantic
Ocean
eo
9
Caribbean .
BY
ea
@GRENADA
.
(See reference map tt}
LAND
344 km? (Grenada and southern Grenadines); 44%
cultivated, 4% pastures, 12% forests, 17% unused but
potentially productive, 23% built on, wasteland, other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 121 km
Railroads: none
Highways: 1,000 km total; 600 km paved, 300 km
otherwise improved; 100 km unimproved
Ports: 1 major (St. Georges), 1 minor
Civil air: no major transport aircraft
Airfields: 3 total, 2 usable; 2 with permanent-surface
runways, 1 with runway 1,220-2,439 m
Telecommunications: automatic, islandwide telephone
system with 5,100 telephones (4.5 per 100 popl.); VHF and
UHF links to Trinidad and Carriacou; 3 AM stations','09236ab2f920d9f7d921498ecb069a6951d57c616d16960b531c70171e5b9c4d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adf06356671d2752e5ca2c9071b44dac839bb213b5f0a261637a726779688648',1978,'GP','Guadeloupe','communications',226,'LAND
1,779 km*; 24% cropland, 9% pasture, 4% potential
cropland, 16% forest, 47% wasteland, built on; area consists
of two islands
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 306 km
“DOMINICAN
REPUBLIC
PUERTO
RICO
a
Caribbean Sea
{See refereace map it}
Railroads: privately owned, narrow-gage plantation lines
Highways: 2,300 km total; 1,500 km paved, 800 km
gravel and earth
Ports: | major (Pointe-a-Pitre), 3 minor
Civil air: 2 major transport aircraft
Airfields: 8 total, 8 usable, 8 with permanent-surface
runways; 1 with runway 2,440-3,659 m; 2 seaplane stations
Telecommunications: domestic facilities inadequate;
26,800 telephones (7.9 per 100 popl.); interisland VHF radio
links; 2 AM and 3 TV transmitters
DEFENSE FORCES
Military manpower: males 15-49, included with France','e88a421b0e60f4d392e6b00d4af9eab6b8a4bfe3c40a58abfdaabd8cab58727c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('895e2d5067ed1b684a0350dab0afab6a59dd3e31baff03640e707262267b08ec',1978,'GT','Guatemala','communications',230,'LAND
108,880 km?; 14% cultivated, 10% pasture, 57% forest,
19% other
Land boundaries: 1,625 km
82
Gulf of','72d80004d3535301c045e09f4532cbb765cea5f5bed62f7eb23ff6e0a258d0e9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4fa1776944431d654f02d543112d77a7d98d3d96c413555543c1ca839e0aa7a',1978,'GW','Guinea-Bissau','communications',231,'(formerly Portuguese Guinea)
LAND
36,260 km? (includes Bijagos archipelago)
Land boundaries: 740 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GUINEA-BISSAU/GUYANA
Atlantic Ocean
(See reference map V1)
WATER
Limits of territorial waters (claimed): 150 nm (fishing
200 nm)
Coastline: 274 km
Railroads: none
Highways: approx. 3,218 km (418 km_ bituminous,
remainder earth)
Inland waterways: 1,600 km
Ports: 1 major (Bissau), 2 minor
Civil air: no major transport aircraft
Airfields: 60 total, 59 usable; 4 with permanent-surface
runways; 8 with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: limited system of open-wire lines
and radiocommunication stations; 2,700 telephones (0.5 per
100 popl.); 1 AM, 1 FM and no TV stations
DEFENSE FORCES:
Military manpower: mates 15-49, 122,000; 70,000 fit for
military service','56ef82e3a1df27479e8d8fbd918dc688eccc2a39d9e153c489b98c60dbdc4098','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad7fae7c5eb981eed7bf4531b56ca5d1f88bd665d1055b2a3229b13be0025241',1978,'GY','Guyana','communications',235,'LAND
214,970 km2; 1% cropland, 3% pasture, 8% savanna, 66%
forested, 22% water, urban, and waste
Land boundaries: 2,575 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 459 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
; Atlantic
Sd Ocean
Caribbean
§','73b019b684348873983d04e1b67412089ca1979429089ba049d4def96e59c625','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75afdb79a8654977a696c544b25bd3c9aa48d81ff1aee302ca428e7ada4b4072',1978,'HT','Haiti','communications',236,'Atlantic Ocean
{See reference map I!)
LAND
27,713 km?; 31% cultivated, 18% rough pastures, 7%
forested, 44% unproductive
Land boundary: 361 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 1,771 km
Railroads: 80 km narrow gage (0.760 m), single-track,
privately owned industrial line; 8 km dual-gage 0.760- to
1.065-meter gage, government line, dismantled
Highways: 3,200 km total; 600 km paved, 950 km
otherwise improved, 1,650 km unimproved
Inland waterways: negligible; about 100 km navigable
Ports: 2 major (Port-au-Prince, Cap Haitian), 12 minor
Civil air: 7 major transport aircraft
Airfields: 14 total, 13 usable; 3 with permanent-surface
Tunways; 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m; 2 seaplane stations
Telecommunications: al] domestic facilities inadequate,
international facilities slightly better; telephone expansion
program underway; 17,800 telephones (0.4 per 100 popl.); 40
AM, 5 FM, and 1 TV station; 1 Atlantic Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 1,180,000; 628,000 fit
for military service; about 51,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1978, $10.4 million; about 13.4% of operational budget','ad841fdffcf81ab81b051d2d787d7baf25ca80a4afe955f31ca204ac122ad285','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24d8ae8198a2f9b4d964a23b34fd01fb9bcf58ce41df8d427ee5e57a1a03b39d',1978,'HN','Honduras','communications',240,'LAND
112,150 km?; 27% forested, 30% pasture, 36% waste and
built-up, 7% cropland
Land boundaries: 1,530 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 820 km
Railroads: 574 km total; 325 km 1.067-meter gage, 249
km 0.914-meter gage
Highways: 8,700 km total; 1,150 km bituminous surfaced,
2,500 km gravel surfaced or improved earth, 5,050 km
unimproved earth
Inland waterways: 1,200 km navigable by small craft
Approved For Release 2005/04/22
Ports: 3 major (Puerto Cortes, La Ceiba, Tela), 9 minor
Civil air: 19 major transport aircraft
Airfields: 244 total, 219 usable; 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 8 with runways
1,220-2,439 m; 2 seaplane stations
Telecommunications: improved, but still inadequate;
connection into Central American microwave net, 19,500
telephones (0.7 per 100 popl.); 104 AM, 12 FM, and 6 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 680,000; 401,000 fit for
military service; about 31,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1978, $31.4 million; about 7.5% of central
government budget (includes the armed forces and other','fd8e453e9d59cc57acdf76b05003599aa953df50f93b1d4b32f9e024efa04ffa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3907141982ec43824d8cf966b174f3b794c9f7823140ecdce504f9acedcad2e',1978,'PH','Philippines','communications',248,'Railroads: 35 km standard gage
owned
Highways: 966 km total; 660 km paved, 306 km gravel
and crushed stone, or earth
Ports: 1 major
Civil air: 17 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways; | with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m; 1 seaplane station
Telecommunications:
and international services;
provided by wired and radio
(1.435 m); government
Stations; closed-cir-
million telephones;
2.5 million radio receivers; 100,000 wired-speakers; 2 FM, 2
AM stations; wired-broadcast network; 859,000 TV receiv-
ers, 2 TV stations, 2 closed-circuit TV networks; radio relay
ground stations;
cables; submarine cable to Japan-and Philippines completed
DEFENSE FORCES
Military Manpower: males 15-49, 1,201,000; 937,000 fit
for military service; about 55,000 reach military age (18)
annually
Defense is the responsibility of U.K.
LAND
300,440 km?*; 53% forested, 30%
permanent pasture, 12% other
WATER
Limits of territorial waters (claimed): 0-300 nm (under
an archipelago theory, waters within straight lines joining
appropriate points of outermost islands are considered
internal waters; waters between these baselines and the
arable land, 5%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Philippine Sea
2 feos
{See reference mag Vil}
limits described in the Treaty of Paris, December 10, 1898,
the U.S.-Spain Treaty of November 7, 1900, and the
US.-U.K. Treaty of January 2, 1980 are considered to be the
territorial sea)
Coastline: about 22,540 km
Railroads: 3,503 km total; 2 common-carrier systems
1.067-meter gage totaling about 1,170 km; 19 industrial
systems with 4 different gages totaling 2,333 km; 34%
government owned
163
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
PHILIPPINES /POLAND
Highways: 109,690 km total (1976); 20,483 km paved:
51,642 km gravel, crushed stone, or stabilized soil surface;
37,565 km unimproved earth
Inland waterways: 3,219 km; limited to shallow-draft
(less than 1.5 m) vessels
Pipelines: refined products, 251 km
Ports: 11 major, numerous minor
Civil air: approximately 65 major transport aircraft
Airfields: 332 total, 304 usable; 55 with permanent-
surface runways; 8 with runways 2,440-3,659 m, 33 with
runways 1,220-2,4389 m
DEFENSE FORCES
Military manpower: males 15-49, 9,713,000; 6,941,000 fit
for military service; about 448,000 reach military age (20)
annually
Supply: limited small arms and small arms ammunition,
small patrol craft, and helicopter production; other materiel
obtained almost exclusively from U.S.; naval ships and
equipment from Australia, Japan, Singapore, US., and Italy;
aircraft and helicopters from West Germany and U.S.','bc685f8670f5e6c74ee7e0e1bcea6ef393718bdd6e85bdd49fd0e77a10712a00','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6a0a5cd20175a9528b5f7bdb32a9a16da7dd21cf851ba01d1485599cd39f14b',1978,'HU','Hungary','communications',249,'LAND
92,981 km?; 60% arable, 14%
forested, 10% other
Land boundaries: 2,245 km
Railroads: 8,392 km total; 7,879 km standard gage (1.435
m), 478 km narrow gage (mostly 0.760 m), 35 km broad gage
(1.524 m), 1,159 km double track, 1,303 km electrified;
government owned (1975)
Highways: 99,595 km total; 32,583 km concrete, asphalt,
stone block; 10,408 km asphalt treated, gravel, crushed stone;
56,604 km earth (1976)
Inland waterways: 1,688 km (1977)
Pipelines: crude oil, 1,287 km; refined products, 500 km;
natural gas, 2,896 km
Freight carried: rail—131.7 million metric tons, 23.5
billion metric ton/km (1975); highway—479.4 million
metric tons, 8.1 billion metric ton/km (1975); waterway—
91
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
HUNGARY/ICELAND
est. 14.2 million metric tons, 8.3 billion metric ton/km incl.
int''l. transit traffic in approximately 308 waterway craft
with 231,000 metric ton capacity
River ports: 2 principal (Budapest, Dunaujvaros); no
maritime ports; outlets are Rostock, GDR; and Gdansk,
Gdynia, and Szczecin in Poland; and Galati and Brails in','45f4be997eabec478a9dd533b8a0d330940e3081d61d91a574bdf57bd71a610f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da5788e2f9b36da49a3d1f8177b67f8e59a1e65748ee75171c44e2f628045db3',1978,'RO','Romania','communications',253,'DEFENSE FORCES
Military manpower: males 15-49, 2,650,000; 2,314,000 fit
for military service; about 70,000 reach military age (18)
annually
Military budget: announced for fiscal year ending 31
December 1978, est. 14.4 billion forints; about 3.7% of total
budget
" =
Black Sea
(See reference map iV}
LAND
237,503 km*; 44% arable, 19% other agriculture, 27%
forested, 10% other
Land boundary: 2,969 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 225 km
Railroads: 12,080 km total; 10,467 km standard gage
(1.435 m), 1,600 km narrow gage, 13 km broad gage; 1,407
km electrified, 2,040 km double track; government owned
(1976)
Wighways: 77,768 km total; 13,470 km concrete, asphalt,
stone block; 14,412 km asphalt treated, gravel, crushed stone;
49,886 km earth (1976)
Inland waterways: 1,691 km (1 77)
Pipelines: 2,735 km crude oil; 1,429 km refined products;
5,149 km natural gas
Freight carried: rail—238.0 million metric tons, 67.6
billion metric ton/km (1976); highway—442.2 million
metric tons, 9.9 billion metric ton/km (1976); waterway—
7.9 million metric tons, 2.1 billion metric ton/km in
approximately 515 waterway craft, with 493,750 metric ton
capacity (1977)
Ports: 5 major (Constanta, Galati, Braila, Mangalia,
Tulcea), 1 minor (1978)
DEFENSE FORCES
Military budget (announced): for fiscal year ending 31
December 1978, 12.0 billion lei; about 3.8% of total budget','bb5e0098e82aacd4aacaf01e858d84e30e05aa6664ddf7bc92a1de81522c1146','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fec3b89c99075dc9e2485dd55a671ff1a0bacfd27b478f2f7694fe815986f324',1978,'IS','Iceland','communications',254,'Jan Mayen
¢ Island
Greenland Fi
Sea Norwegian
vo St" ICELAND aa
pen
Reykiavik™
Atlantic
Ocean
(See reference map IV}
LAND
102,952 km?; arable negligible, 22% meadows and
pastures, forested negligible, 78% other
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm)
Coastline: 4,988 km
Railroads: none
Highways: 12,343 km total; 166 km bitumen and
concrete; 1,284 km bituminous treated and gravel; 10,893
km earth
Ports: 4 major (Akureyri, Hafnarfjordhur, Reykjavik,
Seydhisfiordhur), and about 50 minor
Civil air: 23 maior transport aircraft, including 4 leased in
Airfields: 126 total, 101 usable; 3 with permanent-surface
runways; | with runway 2,440-3,659 m, 10 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: adequate domestic service, wire
and radio communication system; 93,700 telephones (42.4
per 100 popl.); 17 AM, 14 FM, and 80 TV stations; 2 coaxial
submarine cables; Comsat station under construction
DEFENSE FORCES
Military manpower: males 15-49, 54,000; 49,000 fit for
military service (Iceland has no conscription or compulsory
military service)','7cace4c2eee5be03d3445a7ee9db7a32e4b1df3224a602c8375360d55319e00f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f07c4c64a19698ea10158cf7c3c0ee9fa73855843b5cf23d13f93639bb084f03',1978,'IN','India','communications',258,'LAND
3,136,500 km? (includes Indian part of Jammu-Kashmir,
Sikkim, Goa, Damao and Diu); 50% arable, 5% permanent
meadows and pastures, 20% desert, waste, or urban, 22%
forested, 3% inland water
Land boundaries: 12,700 km?
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; additional 100 nm is fisheries conservation zone,
December 1968; archipelago concept baselines); 200 nm
exclusive economic zone
Coastline: 7,000 km (includes offshore islands)
Approved For Release 2005/04/22 :
Arabian
Sea
(See reference map Vil}
Railroads: 61,313 km total; 25,550 km meter gage (1.00
m), 30,041 km broad gage (1.676 m), 4,476 km narrow gage
(0.762 m and 0.610 m), government owned; 46 km meter
gage (1.00 m), 855 km broad gage (1.676 m), 345 km narrow
gage (0.762 m and 0.610 m), privately owned; 12,304 km
double track; 10,160 km electrified
Highways: 1,327,450 km total; 415,250 km paved,
190,600 km gravel or crushed stone, 304,900 km improved
earth, 416,700 km unimproved earth
Inland waterways: 14,300 km; 2,575 km navigable by
river steamers
Pipelines: crude oil, 1,552 km; refined products, 2,020
km; natural gas, 359 km
Ports: 9 major, 80 minor
Civil air: 938 major transport aircraft
Airfields: 358 total, 343 usable; 190 with permanent-
surface runways; 2 with runways over 3,660 m, 54 with
runways 2,440-3,659 m, 123 with runways |,220-2,439 m
Telecommunications: fair domestic telephone service
where available, good internal microwave links; telegraph
facilities widespread; AM broadcast adequate; international
radio communications adequate; 2.1 million telephones (0.3
per 100 popl.); about 163 AM stations at 80 locations, 9 TV
stations, 4 earth satellite stations; submarine cables extend to','649ed040e648a7a12921a08ab120ece43fda89e099f84a3952a93eecfb3e1e5e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2099460671b716ee25c1998547505eac26c219315b509e361a1ad1c754128034',1978,'LK','Sri Lanka','communications',262,'DEFENSE FORCES
Military manpower: males 15-49, 153,307,000;
90,220,000 fit for military service; about 7,132,000 reach
military age (17) annually
Military budget: for fiscal year ending 31 March 1979,
$3.6 billion; 16% of central government budget
(formerly Ceylon)
LAND
65,500 km?; 25% cultivated; 44% forested; 31% waste,
urban, and other
189
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Arabian
See
of Bengal |
SRI
/\\LANKA
Colombo!
‘ndian Qcean
(See reference mep Vit}
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
um, plus pearling in the Gulf of Mannar); 200 nm exclusive
economic zone
Coastline: 1,340 km
Railroads: 1,535 km total; 1,395 km 1.676-meter gage,
140 km 0.762-meter gage; 102 km double track; no
electrification; government owned
Highways: 52,200 km total (1975); 24,300 km paved
(mostly bituminous treated), 18,800 km crushed stone or
gravel, 9,400 km improved earth or unimproved earth; in
addition several thousand km of tracks, mostly unmotorable
Inland waterways: 430 km; navigable by shallow-draft
craft
Ports: 3 major, 9 minor
Civil air: 8 major transport (including 1 leased)
Airfields: 14 total, 12 usable; 12 with permanent-surface
runways; | with runway 2,440-3,659 m, 7 with runways
1,220-2,489 m
Telecommunications: good international service; 75,000
(est.) telephones (0.5 per 100 popl.); 530,000 radio sets, 500
TV sets; 14 AM stations, 2, FM stations, and 1 TV station;
submarine cables extend to India; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,477,000; 2,619,000 fit
for military service; 158,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1978, $24.7 million, 2% of central government budget','7ad38134712baaff4ceaccf274824ac9d5c0982eb7828075a33dd0a22b9fac74','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f745778b15c14078052627b2c6f78dc215ab88c77b46685fe015ab05cc59a8e6',1978,'ID','Indonesia','communications',263,'LAND
1,906,240 km*®; 12% small holdings and estates, 64%
forests, 24% inland water, waste, urban, and other
Land boundaries: 2,736 km
WATER
Limits of territorial waters (claimed): under an archi-
pelago theory, claim is 12 nm, measured seaward from
straight baselines connecting the outermost islands
Coastline: 54,716 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Indian Ocean
(See reference map Vil)','50d37e81f6335ab04913cf109f2bad8ae4f6bdb3c5d27d788ffe9a60b81b9ad4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9125b6be2d57dbde3c66742e281187a0e93696fd3732587c651027494c70b636',1978,'IQ','Iraq','communications',267,'Caspian
Sea
Baghdad,
(See reference map V}
LAND
445,480 km?*; 18% cultivated, 68% desert, waste, or urban,
10% seasonal and other grazing land, 4% forest and
woodland
Land boundaries: 3,668 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 58 km
Railroads: 1,700 km total: 1,123 km standard gage (1.435
m), 577 km meter gage (1.00 m); 16 km meter gage double
track
Highways: 20,791 km total; 6,490 km paved, 4,645 km
improved earth, 9,656 km unimproved earth
Inland waterways: 1,015 km; Shatt al Arab navigable by
maritime traffic for about 104 km; Tigris and Euphrates
navigable by shallow-draft steamers
Ports: 3° major (Basra, Umm Qasr, Al Faw)
Pipelines: crude oil, 3,821 km; 585 km refined products;
1,360 km natural gas
Civil air: 26 major transport aircraft
Airfields: 75 total, 66 usable; 24 with permanent-surface
runways; 39 with runways 2,440-3,659 m, 16 with runways
1,220-2.489 m
Telecommunications: network consists of coaxial cables,
radio-relay links, and radiocommunication stations; 320,000
telephones (2.8 per 100 popl.); 9 AM, no FM and 10 TV
stations; | satellite station with Atlantic Ocean and Indian
Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 2,642,000; 1,478,000 fit
for military service; about 118,000 reach military age (18)
annually
Military budget: est. for fiscal year ending 31 December
1977, $1,660,000,000; 12% of central government budget
Baghdad,
V The Middle East
Tehran ,
iran
Egtahan®
trageSaudi Ai abi
=sNeutral:Zone ~
Dlianrang
- Riyadh,
| Saudi Arabia
°
Shiraz','5ad6b821c3f27667ac152ae391ecee041a26e9a197a89b2fb1dccecbc1c7b14e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0db5c92f649aa66a7ea6a6f7bbd44435b40af267e66d2b8f7fc0fd2c3b3b517',1978,'IE','Ireland','communications',271,'LAND
68,894 km*; 17% arable, 51% meadows and pastures, 3%
forested, 2% inland water, 27% waste and urban
Land boundaries: 360 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 1,448 km
Railroads: 2,009 km 1.600-meter gage; 1,894 km govern-
ment-owned; 115 km_ privately-owned
Highways: 88,302 km total; 78,616 km surfaced, 9,686
km earth
Inland waterways: approximately 1,000 km
Ports: 6 major, 38 minor
CIA-RDP79-01051A000900010006-2 99
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
IRELAND/ISRAEL
Civil air: 30 major transport aircraft (including 7 leased
out)
Airfields: 38 total, 38 usable; 8 with permanent-surface
runways; | with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: small, modern system; all cities
interconnected for telephone and telegraph service; 480,000
telephones (15.1 per 100 popl.); 6 AM, 7 FM, and 28 TV
stations; 4 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 739,000; 579,000 fit for
military service; about 29,000 reach military age (17)
annually
Military budget: for fiscal year ending 31 March 1978,
$193.8 million; about 6% of the central government budget','e9f055729ceb119e228f95463125fa90e1bd94f568fefd70cc0e033c297e0c19','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f268907076cf63b99b08d28958c723611d031d5acef6b781db8b6a3693ae34d6',1978,'IL','Israel','communications',275,'g
Mediterranean
Sea
“SAUDE
ARABIA
‘See reference map V)
NOTE: The Arab territories occupied since the 1967 war
are not included in the data below unless so indicated.
LAND
20,720 km? (excluding about 64,750 km? of occupied
territory in Jordan, Egypt, and Syria); 20% cultivated, 40%
pastureland and meadows, 4% forested, 4% desert, waste, or
urban, 3% inland water, 29% unsurveyed (mostly desert)
Land boundaries: 1,036 km (prior to 1967 war); including
occupied areas, approximately 1,050 km (1977)
WATER
Limits of territorial waters (claimed): 6 nm
Coastline: 273 km (prior to 1967 war); including occupied
areas, approximately 848 km (1977)
Railroads: 767 km standard gage (1.435 m)
Highways: 4,348 km paved, 7 km gravel/crushed stone,
remainder unknown
Pipelines: crude oil, 708 km; refined products, 290 km;
natural gas, 89 km
Approved For Release 2005/04/22
Ports: 3 major (Haifa, Ashdod, Elat), 5 minor
Airfields: 55 total, 46 usable; 20 with permanent-surface
runways; 5 with runways 2,440-8,659 m, 7 with runways
1,220-2,489 m
Civil air: 40 major transport aircraft (including 5 leased
in)
Telecommunications: most highly developed in the
Middle East though not the largest; 870,000 telephones (24.0
per 100 popl.); 14 AM, 10 FM stations, 15 TV stations and 30
repeater stations; 2 submarine cables; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: Jewish males 15-49, 760,000;
655,000 fit for military service; average number of Jews
reaching military age (18) annually—30,000 males, 30,000
females; both sexes liable for military service','94ae2fe1f0604696eb3713293bef88210b4af0a3c6a147e59507f453b97ca57b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae800c6d4a463f0c6b9eebcb0b036e83246c035c40f72a2e23c3aadffb5afb21',1978,'IT','Italy','communications',279,'lonian
Sea
{See reference map IV)
LAND
301,217 km*; 50% cultivated, 17% meadow and pasture,
21% forest, 3% unused but potentially productive, 9% waste
or urban
Land boundaries: 1,702 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4,996 km
Railroads: 20,690 km total; 15,970 km government-
owned standard gage (1.435 m), 7,850 km electrified; 4,720
km non-government owned, 2,507 km standard gage (1.435
m), 1,270 km electrified; 2,213 km narrow gage (0.950 m),
517 km electrified
Highways: 286,400 km total; autostrade 4,800 km, state
highways 41,200 km, provincial highways 91,200 km,
communal highways 149,200 km; 254,400 km _ concrete,
bituminous, or stone block, 24,800 km gravel and crushed
stone, 7,200 km earth
Inland waterways: 2,500 km navigable routes
Pipelines: crude oil, 1,770 km; refined products, 2,179
km; natural gas, 13,079 km
Ports: 16 maior, 22 significant minor
Civil air: 130 major transport aircraft, including 7 leased
in
Airfields: 151 total, 151 usable; 81 with permanent-
surface runways; 2 with runways over 3,660 m, 28 with
runways 2,440-3,659 m, 44 with runways 1,220-2,439 m; 10
seaplane stations
Telecommunications: well engineered, well constructed,
and efficiently operated; 15.2 million telephones (27.1 per
100 popl.); 135 AM, 660 FM, and 900 TV stations; 14 coaxial
submarine cables; 2 communication satellite ground stations
with Atlantic Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 13,986,000; 11,719,000
fit for military service; 442,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1978, $5,018.8 million; about 8% of proposed
central government budget
IVORY COAST
LAND
323,750 km’;
52% grazing, fallow, and waste, 200 mi.
connecting canals along eastern coast
Land boundaries: 3,227 km
40% forest and woodland, 8% cultivated,
of lagoons and
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 515 km
Military budget: for fiscal year ending 31 March 1978,
$11,032,210 (includes funds for Pioneer Corps and the Arms
of Malta, totaling about $8 million); about 6% of central
government budget','75b8f7c9fd169609d9317a0d92a825390c559a5ad4d2e882f8b44e1f24f25dd2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6740fc7f4c0d357897bfbcbd7e672e050d47ca744db7c8944028cc55a553e3ef',1978,'JM','Jamaica','communications',283,'Atlantic
Ocean
~
= DOMINICAN
: PUB
Z ''UBLIC
HAITI es
JAMAICA Ringston
(See reference map iH}
LAND
11,422 km?; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,022 km
Railroads: 330 km, all standard gage (1.435 m), single
track
Highways: 11,250 km total; 7,600 km paved, 2,150 km
gravel, 1,500 km improved earth
Pipelines: refined products, 10 km
Ports: 3 major (Kingston, Montego Bay, Montego Free-
port), 10 minor
Civil air: 13 major transport aircraft, including 1 leased in
and 3 leased out
Airfields: 42 total, 22 usable; 12 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 1 with runway
1,220-2,439 m; 3 seaplane stations
Telecommunications: fully automatic domestic telephone
network with 109,000 telephones (5.4 per 100 popl.); 1
Atlantic Ocean satellite station, 8 AM, 11 FM, and 9 TV
stations; 3 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 450,000; 320,000 fit for
military service; no conscription; average number currently
reaching minimum volunteer age (18) 25,000
Supply: dependent on U.K. and USS.
Military budget: for fiscal year ending 31 March 1977,
$29.5 million; about 2.2% of central government budget','d41d71b764f7a6d96ca6c4a85044bf54b46fab8c5df46e1750fa2e2ffb8fb16d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd2d2e99b9c31f14d2bfadfe56601f7775b8f09a90d4f4fd70c144c2abca9b09',1978,'JP','Japan','communications',287,'LAND
370,370 km’; 16% arable and cultivated, 3% grassland,
12% urban and waste, 69% forested
105
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 :
CIA-RDP79-01051A000900010006-2
July 1978
Pacific
Ocean
Philippine
Sea
{See reference map Vit}
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 12,075 km Japan; 1,610 km Ryukyus
Railroads: 28,912 km total; 1,077 km standard gage (1.485
m), 27,835 km predominantly narrow gage (1.067 m), 6,195
km double track, 7,376 km or 26% of total route leneth
electrified; 73% government-owned
Highways: 1,067,643 km total (1977); $38,343 km paved,
most of remainder gravel or crushed stone
Inland waterways: approx. 1,770 km; seagoing craft ply
all coastal “inland seas”
Pipelines: crude oil, 109 km; natural gas, 1,847 km
Ports: 53 major, over 2,000 minor
Civil air: 224 major transport aircraft (includes 2 leased)
Airfields: 183 total, 177 usable; 119 with permanent-
surface runways; 2 with runways over 3,660 m; 22 with
runways 2,440-3,659 m, 44 with runways 1,220-2,489 m, 5
seaplane stations
DEFENSE FORCES
Military manpower: males 15-49, 31,668,000; 26,654,000
fit for military service; about 815,000 reach military age (18)
annually
Supply: defense industry potential is large, with capability
of producing the most sophisticated equipment; manufac-
tured equipment includes small arms artillery, armored
vehicles, and other types of ground forces materiel, aircraft
(jet and prop), naval vessels (submarines, guided missile and
other destroyers, patrol craft, mine warfare ships, and other
minor craft including amphibious, auxiliaries, service craft,
and small support ships), small amounts of all types of army
materiel
Military budget: for fiscal year ending 31 March 1979,
$7.9 billion proposed; about 5.5% of total budget
Railroads: 3,555 km total; 960 km 1.067-meter gage;
2,595 km meter gage (1.00 m), 6.4 km double track; 962 km
Tan-Zam Railroad 1.067-meter gage in Tanzania
Highways: total 17,010 km, 2,581 km paved; 5,529 km
gravel or crushed stone; 8,900 km improved earth
Pipelines: 982 km crude oil
Inland-waterways: 1,168 km of navigable streams; several
thousand km navigable on Lakes Tanganyika, Victoria, and','dfeeff50d85e98876aa03abff719a63bec333059411e7eccd8df40ad9aaeb046','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('277a763e9c6bde61769be7a6acf6588524032fbe6600e6965bd2c50620216d13',1978,'JO','Jordan','communications',291,'NOTE: The war between Israel and the Arab states in
June 1967 ended with Israel in control of West Jordan.
Although approximately 930,000 persons resided in this area
prior to the start of the war, fewer than 750,000 of them
remain there under the Israeli occupation, the remainder
having fled to East Jordan. Over 14,000 of those who fled
were repatriated in August 1967, but their return has been
more than offset by other Arabs who have crossed and are
continuing to cross from West to East Jordan. These and
certain other effects of the 1967 Arab-Israeli war are not
included in the data below.
LAND
96,089 km? (including about 5,439 km? occupied by
Israel); 11% agricultural, 88% desert, waste, or urban, 1%
forested
Land boundaries: 1,770 km (1967, 1,668 km excluding
occupied areas)
(See reference map V}
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 26 km
Railroads: 817 km_ 1.050-meter gage, single track
Highways: 6,677 km paved; 2,413 km improved earth;
others unknown
Pipelines: crude oil, 209 km
Ports: 1 major (Aqaba)
Civil air: 14 major transport aircraft (including 3 leased
in)
108
Airfields: 25 total, 16 usable; 14 with permanent-surface
runways; 3 with runways over 3,660 m, 10 with runways
2,440-3,659 m, 1 with runway 1,220-2,489 m
Telecommunications: adequate telecommunication sys-
tem for the needs of the country; 44,000 telephones (1.6 per
100 popl.); 5 AM, no FM and 6 TV stations; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 624,000; 444,000 fit for
military service; average number currently reaching military
age (18) annually 32,000
Military budget: for fiscal year ending 31 December
1978, $246 million; 29% of central government budget','aa1670d22781d24649b4e859a15e388b1a8c72bd8a4d2efce36a473777468463','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f47deeb795083728eb9bf45aea163571271e0b4c386aaa0fbab154c2bf9f38b',1978,'KE','Kenya','communications',295,'+ Nairabi
Indian
Ocean
(See reference map Vi}
LAND
582,750 km*; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland adequate for
grazing (1971)
Land boundaries: 3,368 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 536 km
Railroads: 2,040 km meter gage (1.00 m)
Highways: 50,290 km total; 3,750 km paved, 12,160 km
gravel and/or earth; 26,880 km improved earth and 7,500
km unimproved earth
Inland waterways: part of Lake Victoria and Lake
Rudolph systems are within boundaries of Kenya
Pipelines: refined products, 483 km
Ports: 1 major (Mombasa), 3 minor
Civil air: 20 major transport aircraft (including 5 leased
in)
Airfields: 238 total, 221 usable; 8 with permanent-surface
runways; ] with runway over 3,660 m, 3 with runways
2,440-3,659 m, 41 with runways 1,220-2,439 m
Telecommunications: in top group of African systems;
consists of radio-relay links, open-wire lines, and radiocom-
munication stations; principal center Nairobi, secondary
centers Mombasa and Nakuru; 132,000 telephones (1.0 per
100 popl.); 4 AM, 2 FM, and 5 TV stations; 1 Indian Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,116,000; 1,913,000 fit
for military service; no conscription
Military budget: for fiscal year ending 30 June 1978,
$79,968,647, about 5.8% of central government budget
KOREA, NORTH
LAND
121,730 km?*, 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban
Land boundaries: 1,675 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
200 nm, military 50 nm)
Coastline: 2,495 km
Railroads: none
Highways: 9,020 km total; 320 km paved, 2,700 km
gravel and/or improved earth, 6,000 km unimproved
Inland waterways: Lake Kivu navigable by barges and
native craft ;
Civil air: 1 major transport aircraft
Airfields: 9 total, 9 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m, 1 with runway
2,440-3,659 m
Telecommunications: low-capacity radio-relay system
centered on Kigali; 3,600 telephones (0.1 per 100 popl.); 2
AM, 1 FM, no TV stations, Symphonie COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 998,000; 503,000 fit for
military service; no conscription; 46,000 reach military age
(18) annually
Military budget: for fiscal year ending 31 December
1976, $11,172,295; 19% of central government budget
ST. CHRISTOPHER-NEVIS-ANGUILLA
Atlantic Ocean
oe ANGUILLA
ap
hac a
ST. CHRISTOPHER %e -
NEVIS * 9.
Caribbean Sea
(See reference map tt}
LAND
389 km*; 40% arable, 10% pasture, 17% forest, 33%
wasteland and_ built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 193 km
Railroads: 57 km, narrow gage (0.760 m) on St. Kitts for
sugar cane
Highways: 300 km total; 100 km paved, 150 km otherwise
improved, 50 km unimproved earth
Ports: 8 minor (1 on each island)
Civil air: ] major transport aircraft
Airfields: 3 total, 3 usable; 3 with permanent-surface
runways; 1 with runway 1,220-2,439 m; 1 seaplane station
Telecommunications: good interisland VHF/UHF radio
connections and international link via Antigua; about 2,500
telephones (4.4 per 100 popl.); 3 AM and 5 TV stations
ST. LUCIA
Atlantic Ocean
Caribbean Sea <
ST. LUCIA
(See reference man tt)
LAND
616 km?; 50% arable, 3% pasture, 19% forest, 5% unused
but potentially productive, 23% wasteland and built-on
WATER
Limits of territorial waters (claimed); 3 nm
Coastline: 158 km
Railroads: none
Highways: 750 km total; 450 km paved; 300 km otherwise
improved
174
Ports: 1 major (Castries), 1 minor
Civil air: 1 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways, 1 with runway 2,440-3,659 m, | with runway
1,220-2,439 m; 2 seaplane stations
Telecommunications: fully automatic telephone system
with 6,600 telephones (5.8 per 100 popl.); direct radio-relay
link with Martinique; interisland tropospheric links to
Barbados and Antigua; 3 AM stations, 1 TV station
ST. VINCENT
Atlantic Ocean
REP.
ae |
Caribbean Sea n
° ST. VINCENT
(See reference map H)
LAND
389 km? (including northern Grenadines); 50% arable, 3%
pasture, 44% forest, 3% wasteland and built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 84 km
Railroads: none
Highways: 550 km total; 200 km paved; 200 km otherwise
improved; 150 km unimproved earth
Ports: ] major, 1 minor
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface
runways, 1 with runway 1,220-2,439 m
Telecommunications: islandwide fully automatic tele-
phone system with 4,900 sets (4.8 per 100 popl.); VHF/UHF
interisland links to Barbados and the Grenadines; 2 AM
stations','4ca7dbb6647fc0bd58723ebee793ef23782dc1cc9caa0406bb467112351a0b39','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac92fdc523545f810a18063c591bad7ab2f413dbce1149735e036c32aaceddd9',1978,'KW','Kuwait','communications',299,'LAND
16,058 km? (excluding neutral zone but including islands):
insignificant amount forested; nearly all desert, waste, or
urban
Land boundaries: 459 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 499 km
Railroads: none
Highways: 2,445 km total; 2,195 km bituminous, 250 km
earth, sand, light gravel
Pipelines: crude oil, 877 km; refined products, 40 km;
natural gas, 121 km
Ports: 8 major (Ash Shuwaikh, Ash Shuaybah, Mina al
Ahmadi), 4 minor
Civil air: 17 major transport aircraft (including 7 leased
in)
Airfields: 11 total, 6 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: excellent international and ade-
quate domestic telecommunication facilities; 140,000 tele-
phones (13.0 per 100 popl.); 3 AM, 1 FM and 3 TV stations;
1 satellite station with Indian and Atlantic Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, about 311,000; about
179,000 fit for military service
Military budget: for fiscal year ending 31 March 1976,
$222,428,950; 8% of central government budget
LAOS
LAND
236,804 km’; 8% agricultural, 60% forests, 32% urban,
waste, and other; except in very limited areas, soil is very
poor; most of forested area is not exploitable
Land boundaries: 5,053 km
Approved For Release 2005/04/22
(See reference map Vil}
Highways: about 18,000 km total; 1,300 km bituminous
or bituminous treated, 5,900 km gravel, crushed stone, or
improved earth; 10,800 km unimproved earth and often
impassable during rainy season mid-May to mid-September
Inland waterways: about 4,587 km, primarily Mekong
and tributaries; 2,897 additional kilometers are sectionally
navigable by craft drawing less than 0.5 m
Ports (river); 5 major, 4 minor
Airfields: 87 total, 77 usable; 9 with permanent-surface
runways; 11 with runways 1,220-2,439 m, 1 with runway
2,440-3,659 m
DEFENSE FORCES
Military manpower: males 15-49, 826,000; 441,000 fit for
military service; average number currently reaching usual
military age (18) annually, 37,000; no conscription age
specified','bdef7afd4ad700a0bae8bc6f8b0a9cf249ee06e4945967b3180ca6fb138350bc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3467180ed6385fbf3ddcef094a201d0239e6e0bd828ddfd642848bf18f784245',1978,'LB','Lebanon','communications',303,'Meditettanean
Sea.
{See reference map V}
LAND
10,360 km?*; 27% agricultural land, 64% desert, waste, or
urban, 9% forested
Land boundaries: 531 km
WATER
Limits of territorial waters (claimed): no specific claims
(fishing, 6 nm)
Coastline: 225 km
Railroads: 378 km total; 296 km standard gage (1.435 m),
82 km 1.050-meter gage; all single track
Highways: 7,370 km total; 6,270 km paved, 450 km
gravel and crushed stone, 650 km improved earth
Pipelines: crude oil, 72 km
Ports: 3 major (Beirut, Tripoli, Sayda), 5 minor
Civil air: 35 major transport aircraft (including 13 leased
out)
Airfields: 8 total, 4 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m; 2 with runways
1,220-2,439 m
Telecommunications: rebuilding in progress; internation-
al facilities restored, domestic being rebuilt; fair system of
microwave, cable; approx 125,000 telephones (5.0 per 100
popl.); 2 FM, 7 AM, 7 TV stations; 1 Indian Ocean satellite
station; 8 submarine cables.
DEFENSE FORCES
Military manpower: males 15-49, 584,000; 357,000 fit for
military service; average of about 27,000 reach military age
(18) annually
115
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
T.ESOTHO','5c22f7f5a3ee1e9663722589d0999a2a3dc3e318c2ae77fc374f43f9d985e53e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('740f449463cb3145b5f5f6b36b5e92e6fbcc78726e12827595af501b4aceb562',1978,'LS','Lesotho','communications',307,'Indian Qcean
(See reference map Vt)
LAND
80,303 km?; 15% cultivable; largely mountainous
Land boundaries: 805 km
Railroads: 1.6 km; owned, operated, and included in the
statistics of the Republic of South Africa
Highways: approx. 3,916 km total; 218 km paved; 993 km
crushed stone, gravel, or stabilized soil; 1,046 km improved,
1,659 km unimproved earth
Civil air: no major transport aircraft
Airfields: 21 total, 20 usable; 2 with runways 1,220-2,439
m, 1 with permanent surface runway
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
LESOTHO/ LIBERIA
Telecommunications: system a modest one consisting ofa
few landlines, a small radio-relay system, and minor
radiocommunication stations, Maseru is the center; 3,725
telephones (0.3 per 100 popl.), 2 AM, 1 FM, 1 TV station
planned
DEFENSE FORCES
Military manpower: males 15-49, 220,000; fit for military
service 122,000','799bf6f94f2596ddc3d8995b6258a39cdc3a9f8f1adadc0b15a735fc8b42ca0b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9851e92b974db7708fa9d79b532da972ac14f03cc2c8809d8ee72fcfad7bb65',1978,'LR','Liberia','communications',311,'Ne
Monrovia
Atlantic Qcean
(See reference map VI)
LAND
111,370 km*; 20% agricultural, 30% jungle and swamps,
40% forested, 10% unclassified
Land boundaries: 1,336 km
WATER
Limits of territorial waters (claimed): 22 nm
Coastline: 579 km
Railroads: 499 km total; 354 km standard gage (1.435 m),
145 km narrow gage (1.067 m); all lines single track; rail
systems owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 7,952 km total; 603 km bituminous treated;
2,055 km_gravel, and remainder improved and unimproved
earth
Inland waterways: 370 km
Ports: 3 major (Monrovia, Buchanan, Greenville-Sino
Harbor), 4 minor
Civil air: 8 major transport aircraft
Airfields: 80 total, 78 usable; 2 with permanent-surface
runways; | with runway 2,440-3,659 m, 6 with runways
1,220-2,4389 m; 1 seaplane station
Telecommunications: telephone and telegraph limited;
main center is Monrovia; 3,400 telephones (0.2 per 100
popl.); 5 AM, 2 FM, and 3 TV stations; 1 Atlantic Ocean
Comsat station
DEFENSE FORCES
Military manpower: males 15-49, 364,000; 194,000 fit for
military service; no conscription
Military budget: for year ending 30 June 1978, $8.9
million; 4.8% of central government budget','463bae08d92241ce649abab4f83220fd12fdf56f4044d6525603333866c46c9c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d973d0d4945faa8b50d072c3b8fb4567b91259ffca3b877b01e6cdd270e096b',1978,'LY','Libya','communications',315,'LAND
1,758,610 km?; 6% agricultural, 1% forested, 93% desert,
waste, or urban
Land boundaries: 4,345 km
WATER
Limits of territorial waters (claimed): 12 nm (except for
Gulf of Sidra where sovereignty is claimed and northern
limit of jurisdiction fixed at 32°30''N. and the unilaterally
proclaimed 100 nm zone around Tripoli)
Coastline: 1,770 km
118
(See reference map Vi}
Railroads: none
Highways: 16,250 km total; 7,750 km bituminous and
bitumi-nous treated, 8,500 km gravel, crushed stone and
earth
Pipelines: crude oil 3,251 km; natural gas 282 km; refined
products 443 km (includes 217 km liquid petroleum gas)
Ports: 3 maior (Tobruk, Tripoli, Benghazi), 4 minor, and 5
petroleum terminals
Civil air: 87 major transport aircraft (including 1 leased
in)
Airfields: 87 total, 77 usable; 14 with permanent-surface
runways, ] with runway over 3,660 m, 12 with runways
2,440-3,659 m, 29 with runways 1,220-2,439 m; 2 seaplane
stations
Telecommunications: system is in top one-third of
African systems; consists of radio-relay and tropo-
spheric-scatter links, open-wire lines, and radiocommunica-
tion stations; principal centers are Tripoli and Benghazi;
49,800 telephones (1.8 per 100 popl.); 15 AM, 1 FM, and 12
TV stations; 1 coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 559,000; 327,000 fit for
military service; about 22,000 reach military age (17)
annually; conscription now being implemented
Military budget: for fiscal year ending 31 December
1978, $448 million; 5% of central government budget','1f409ea26d768ddcecab98af038946811ee942b6afa0614d2f0003bb6d379259','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f77ec28b81e10ee772900c53a7a050be630b13090db19c990c82b14dfe27a611',1978,'LI','Liechtenstein','communications',319,'(See reference map iV}
LAND
168 km?
Land boundaries: 76 km
Railroads: 16.00 km, standard gage (1.435 m), electrified;
owned, operated, and included in statistics of Austrian
Federal Railways
120
Highways: no information on total kilometers
Civil air: 3 major transport aircraft registered and
operated in Switzerland
Airfields: none
Telecommunications: automatic telephone system sery-
ing about 16,200 telephones (67.7 per 100 popl.); no
broadcast facilities
DEFENSE FORCES
Defense is responsibility of Switzerland','8f491d29b3754483470458440ca10f5c4845b6afada2b426bf2805aa1f52c0d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c34353385b4d6eb787ebe188f7622d112d8e2910cd756445676fc4bc3cfb7ae',1978,'LU','Luxembourg','communications',323,'(See reference map IV}
LAND
2,590 km?; 25% arable, 27% meadows and pasture, 15%
waste or urban, 33% forested, negligible amount of inland
water
Land boundaries: 356 km
Railroads: 270 km standard gage (1.435 m); 160 km
double track; 186 km electrified
Highways: 4,985 km total; all paved; about 80 km limited
access divided highway completed or under construction
Inland waterways: 37 km; Moselle River
Pipelines: refined products, 48 km
Port: (river) Mertert
Civil air: 14 major transport aircraft, including 1 leased in
and 1 leased out
Airfields: 2 total, 2 usable; 1 with permanent-surface
runway; 1 with runway 2,440-3,659 m
Telecommunications: adequate and efficient system;
158,000 telephones (44.2 per 100 popl.); 4 AM, 3 FM, 2 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 83,000; 71,000 fit for
military service; about 3,000 reach military age (19)
annually
Military budget: for fiscal year ending 31 December
1977, $28,794,467, 3.5% of the central government budget','db91c7f589559b94f533d24386daf9251dcd5b0e65dfe38526fc652411f52714','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b9e822a9de80342268c4bf684d599f8ba9d6ce40a8558f71b6bb7603b0e5ce7',1978,'MO','Macao','communications',327,'LAND
15.5 km’; 10% agricultural, 90% urban
Land boundaries: 201 m
WATER
Limits of territorial waters (claimed): 6 nm; fishing, 12
nm
Coastline: 40 km
121
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
MACAO/MADAGASCAR
<t HONG KONG
{See reference map Vii}
Highways: 42 km paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; | seaplane station
Telecommunications: fairly modern communication fa-
cilities provide adequate services for domestic and interna-
tional requirements; broadcasting coverage is provided by
AM and FM radio facilities and a wired broadcast network;
11,765 telephones; 75,000 radio receivers; 2 AM, 2 FM and
no TV stations; no submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 60,000; 35,000 fit for
military service
Defense is responsibility of Portugal
Personnel; there are no Portuguese military personnel in','94a2d0a64cce700e6c27ea6f702aa5ef97dd12790ee5c76752fcee1dadecb08b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c592b09ea46c258ff0c7a8db08a27c41465461904078e65d834e7a4f065e2189',1978,'MG','Madagascar','communications',331,'LAND
595,700 km* 5% cultivated, 58% pastureland, 21%
forested, 8% wasteland, 2% rivers and lakes, 6% other
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 4,828 km
Railroads: 884 km of meter gage (1.00 m)
Highways: 26,992 km total; 4,285 km paved, 228 km
crushed stone, gravel, or stabilized soil; remainder improved
and unimproved earth (est.)
Inland waterways: of local importance only, Lake
Alaotra, isolated streams and portions of Canal des
Pangalanes
Ports: 4 major (Tamatave, Diego Suarez, Majunga,
Tulear)
Civil air: 3 major transport aircraft (including 1 leased
out)
Airfields: 211 total, 118 usable; 28 with permanent-sur-
face runways; 3 with runways 2,440-3,659 m, 43 with
runways 1,220-2,439 m
Telecommunications: system above African average;
includes open-wire lines, some radio-relay and coaxial links
and 1 Atlantic Ocean satellite ground station; 28,000
telephones (0.4 per 100 popl.); 10 AM, no FM, and 4 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 1,751,000; 1,034,000 fit
for military service; average number reaching military age
(20) annually about 84,000
Railroads: 2,014 km, all narrow gage (1.067 m); 13 km
double track
Highways: 34,869 km total; 4,456 km paved, 2,853 km
crushed stone, gravel, or stabilized soil; 4,660 km improved
and unimproved earth
Inland waterways: 2,250 km including Zambezi River,
Luapula River, Lake Kariba, Lake Bangweulu, Lake
Tanganyika; principal port on Lake Tanganyika is
Mpulungu (of only local importance)
Pipelines: 724 km crude oil
Civil air: 10 major transport aircraft
Airfields: 172 total, 165 usable; 14 with permanent-sur-
face runways; 1 with runway over 3,660 m, 3 with runways
2,440-3,659 m, 22 with runways 1,220-2,439 m
Telecommunications: facilities being modernized and
expanded; high-capacity wire and radio relay connect
centers of Kitwe in northern mining region and Lusaka
along axial north-south route; 77,400 telephones; (1.7 per 100
popl.); 4 AM, 1 FM, and 3 TV stations; 1 Indian Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,160,000; 603,000 fit
for military service
Military budget: for fiscal year ending 31 December
1977, $79 million; 12.9% of central government budget','59b2aa19a1027f389a7957152ed87051b5b3e2a108f05b11485593360c602add','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54c47db0a17bae178a265f722c05271fe4dbf9eafa05fb2940830a3ac1de5cb1',1978,'MW','Malawi','communications',335,'LAND
95,053 km®*; about 31% of land area arable (of which less
than half is cultivated), nearly 25% forested, 6% meadow
and pasture, 38% other
Land boundaries: 2,881 km
Railroads: 566 km 1.067-meter gage
Highways: 14,913 km total; 1,385 km paved; 631 km
crushed stone, gravel, or stabilized soil; 8,714 km improved
earth, 4,183 km unimproved earth
Inland waterways: Lake Malawi, 1,290 km and Shire
River, 144 km, 3 lake ports
Ports: no maritime ports
Civil air; 6 major transport aircraft
Airfields: 46 total, 46 usable; 1 with permanent-surface
runway; 9 with runways 1,220-2,489 m
Telecommunications: the system is above average for
African countries and consists of open-wire lines, radio-relay
links, and radiocommunication stations, principal centers are
Blantyre, Zomba, Lilongwe, and Muzuzu; 19,800 telephones
(0.4 per 100 popl.); 6 AM, 4 FM and no TV stations; 1 Indian
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,104,000, about
561,000 fit for military service
Military budget: for fiscal year ending 31 March 1978,
$14.0 million; 6.7% of recurrent central government budget
Approved For Release 2005/04/22 :
Ports: 3 major (Dar es Salaam, Mtwara, Tanga)
Civil air: 9 major transport aircraft
Airfields: 103 total, 97 usable; 10 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 41 with runways
1,220-2,439 m
Telecommunications: fair system of open wire, micro-
wave, and troposcatter; 68,400 telephones (0.4 per 100
popl.); 5 AM, no FM, 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 3,659,000; 2,097,000 fit
for military service
Military budget: for fiscal year ending 30 June 1978,
$141.3 million; 17% of central government budget
200','b8c13bfe23acb6d8866c475a724452bbdd6864e9d07607a1a8413e849742859e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e885c5044e1ae9eb80ca7142f66bf919d05cef98b756a02ec8a43a005cc6a754',1978,'MY','Malaysia','communications',339,'South China
Sea
dava Sea
(See reference map Vi}
NOTE: Malaysia, which came into being on 16 September
1963, consists of Peninsular Malaysia, which includes 11
states of the former Federation of Malaya, plus East
Malaysia, which includes the 2 former colonies of North
Borneo (renamed Sabah) and Sarawak
LAND
Peninsular Malaysia: 131,313 km’; 20% cultivated, 26%
forest reserves, 54% other
Sabah: 76,146 km’; 13% cultivated, 34% forest reserves,
53% other
Sarawak: 125,097 km’; 21% cultivated, 24% forest
reserves, 55% other
Land boundaries: 509 km Peninsular Malaysia, 1,786 km
East Malaysia
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 2,068 km Peninsular Malaysia, 2,607 km East','1289cb2ce58345b7392fe0b26ded6d508892d9324db2892da8b5c4cb75ce3618','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47e2f0b03e83a430c6d2ec78c70c21c0d48e960c7382a3908c3d464f9fdff486',1978,'SG','Singapore','communications',344,'Railroads:
Peninsular Malaysia: 1,665 km 1.04-meter gage; 13 km
double track; government-owned
East Malaysia: 154 km meter gage (1.00 m) in Sabah
Highways:
Peninsular Malaysia: 19,753 kan total; 15,900 km hard
surfaced (mostly bituminous surface treatment), 2,970 km
crushed stone/gravel, 883 km improved or unimproved
earth
East Malaysia: about 5,426 km total (1,644 km in
Sarawak, 3,782 km in Sabah); 819 km hard surfaced (mostly
bituminous surface treatment), 2,936 km gravel or crushed
stone, 1,671 km earth
Inland waterways:
Peninsular Malaysia: 3,194 km
East Malaysia: 4,087 km (1,569 km in Sabah, 2,518 km
in Sarawak)
Ports:
Peninsular Malaysia: 2 major, 15 minor
East Malaysia: 1 major, 14 minor (5 minor in Sabah; 1
major, 9 minor in Sarawak)
Civil air: approximately 27 major transport aircraft
Pipelines: crude oil, 69 km; refined products, 56 km
Airfields:
Peninsular Malaysia: 60 total, 60 usable; 16 with
permanent-surface runways; 3 with runways 2,440-3,659 m,
ll with runways 1,220-2,439 m
Sabah: 34 total, 34 usable; 5 with permanent-surface
runways; 1 with runway 9,440-3,659 m; 4 with runways
1,220-2,489 m
Sarawak: 45 total, 45 usable; 5 with permanent-surface
runways; 4 with runways 1,220-2,439 m
Telecommunications:
Peninsular Malaysia: good intercity service provided
mainly by microwave relay; international service good; good
coverage by radio and _ television broadcasts; 278,000
telephones (2.7 per 100 popl.); 26 AM, 1 FM, and 16 TV
stations; submarine cables extend to India, Sri Lanka, and
Singapore; connected to SEACOM submarine cable terminal
at Singapore by microwave relay; 1 ground satellite station
Sabah: adequate intercity radio-relay network extends
to Sarawak via Brunei; 23,068 telephones (2.7 per 100 popl.);
5 AM, 1 FM, 5 TV stations; SEACOM submarine cable links
to Hong Kong and Singapore; 1 ground satellite station
Sarawak: adequate intercity radio-relay network ex-
tends to Sabah via Brunei; 28,000 telephones (2.4 per 100
popl.); 4 AM stations, no FM, and 1 TV station
DEFENSE FORCES
Military manpower:
Peninsular Malaysia: males
1,535,000 fit for military service
15-49, 2,421,000;
127
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
MALAYSIA/MALDIVES
Sabah: males 15-49, 195,000; 114,000 fit for military
service
Sarawak: males 15-49, 258,000; 154,000 fit for military
service; conscription age for Malaysia is 21—an age reached
by about 125,000 anmually
External defense dependent on loose Five Power Defense
Agreement (FPDA) which replaced Anglo-Malayan Defense
Agreement of 1957 as amended in 1963
Military budget: for fiscal year ending 31 December
1978, $689 million; about 13.4% of central government
budget
LAND
583 km?; 31% built up area, roads, railroads, and airfields,
22% agricultural, 47% other
182
South j
China Sea L
(See reference map Vili
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 193 km
Railroads: 38 km of meter gage
Highways: 2,200 km total (1976); 1,700 km paved, 500
km crushed stone or improved earth
Ports: 3 major
Civil air: approximately 23 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 2 with runways
1,220-2,489 m
Approved For Release 2005/04/22 :
Telecommunications: adequate domestic facilities; good
international service; good radio and television broadcast
coverage; 374,000 telephones (16.3 per 100 popl.); 13 AM, 4
FM, and 2 TV stations; SEACOM submarine cable extends
to Hong Kong via Sabah, Malaysia; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 643,000; 468,000 fit for
military service
Military budget: for fiscal year ending 31 March 1978,
$413.2 million; about 18.5% of central government budget','98edc2acad51525c7fc18ca8284d8043dbbbbd7217fca85a79414f3d7a5ef2cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4a385f80e098cd03996cfd280055f3f78db07d5f580e2fd83810e96e3aefb17',1978,'MV','Maldives','communications',345,'Arabian
Sea
; 2) SRI
“: laccedive “LANKA
: Sea
MALDIves “a
‘Indian Ocean
(See reference map Vit}
LAND
298 km?; 2,000 islands grouped into 12 atolls, about 220
islands inhabited
WATER
Limits of territorial waters (claimed): the land and sea
between latitudes 7°9''N, and 0°45’S. and between longi-
tudes 72°30’E. and 73°48''E; these coordinates form a
rectangle of approximately 37,000 nm‘; territorial sea ranges
from 2.75 to 55 nm; fishing, approximately 100 nm
Coastline: 644 km (approx.)
Railroads: none
Highways: none
Ports: 2 minor
Civil air: 2 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways; | with runway 2,440-3,659 m, 1 with runway
1,220-2,489 m
Telecommunications: minimal domestic and internation-
al telecommunication facilities; 480 telephones (0.4 per 100
popl.); 1 AM station; 1 Comsat station under construction
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978','a436fe0f34a99b8eb3fccd666f56b172d183cbbd9a1ce81e882041b0135361aa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02bcf8b2e09640fca82f2707155d1dda0b39fbb764449adaea33d8dc1a09eb45',1978,'ML','Mali','communications',349,'Atlantic
Ocean
(See reference map Vi}
LAND
1,204,350 km’; only about a fourth of area arable, forests
negligible, rest sparse pasture or desert
Land boundaries: 7,459 km
Railroads: 642 km meter gage (1.00 m)
Highways: approximately 15,699 km total; 1,669 km
bituminous, 3,670 km gravel and improved earth, 10,360 km
unimproved earth
Inland waterways: 1,815 km navigable
Civil air; 2 major transport aircraft
Airfields: 42 total, 38 usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 11 with runways
1,220-2,4389 m
129
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
MALI/MALTA
Telecommunications: domestic system poor and provides
only minimal service; open-wire and radiocommunication
used for long distance telecommunications; 78,000 tele-
phones (0.1 per 100 popl.); 2 AM, no FM, and no TV
stations; 1 Atlantic Ocean and 1 Indian Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 1,364,000; 767,000 fit
for military service; no conscription
Military budget: for fiscal year ending 31 December
1976, $19,419,900; about 18% of central government budget
(See reference map (V)
LAND
313 km?; 45% agricultural, negligible amount forested,
remainder urban, waste, or other (1965)
WATER
Limits of territorial waters (claimed): 6 nm (fishing 20
nm)
Coastline: 140 km
Highways: 1,271 km total; 1,159 km paved (asphalt), 77
km crushed stone or gravel, 35 km improved and
unimproved earth
Ports: 1] major (Valletta), 2 minor
Civil air: 5 major transport aircraft, including 4 leased in
Airfields: 4 total, 2 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m; 1 seaplane station
Telecommunications: modern automatic telephone sys-
tem centered in Valletta; 62,200 telephones (19.6 per 100
popl.); 1 TV, 5 AM, and 4 FM stations; 1 coaxial submarine
cable
DEFENSE FORCES
Military manpower: males 15-49, 91,000; 70,000 fit for
military service
Supply: has received 2 patrol boats, small arms, and
mortars from Libya; vehicles and engineer equipment from','330cc5bda681c85635d5fadcba7b6f951f36409a4c16478b65bdb232a36d61d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('410edf960faee0c86d83ee8f831ee3f3eb5ec911edbbae9cba4c8c3ea55df3a6',1978,'MQ','Martinique','communications',353,'LAND
1,100 km2; 31% cropland, 16% pasture, 29% forest, 24%
wasteland, built on
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 290 km
Railroads: none
Highways: 1,450 km total; 1,000 km paved, 450 km
gravel and earth
Ports: 1 major ( Fort-de-France), 5 minor
Civil air: no major transport aircraft
Airfields: 3 usable; 1 with permanent-surface runway; |
with runway 2,440-3,659 m; 1 seaplane station
Telecommunications: domestic facilities inadequate;
34,700 telephones (10.2 per 100 popl.); inter-island VHF and
UHF radio links; COMSAT ground station; 1 AM, 1 FM, and
5 TV stations
DEFENSE FORCES
Military manpower: males 15-49, included in France','a2d46989138cfd1d5a20372532e19f4bc101f64c4837f7b0e40eef92bdb77a4f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5e952bd3b8b6bf8bec64f323efa79fe99d22b6528b51668f81a2c25417cd1dc',1978,'MR','Mauritania','communications',357,'LAND
1,085,210 km?®, less than 1% suitable for crops, 10%
pasture, 90% desert
Land boundaries: 5,118 km
132
Atlantic
Qeean
{See reference map V1}
WATER
Limits of territorial waters (claimed): 30 nm (fishing, 36
nm)
Coastline: 754 km
Railroads: 650 km standard gage (1.435 m), single track,
privately owned
Highways: 6,090 km total; 558 km paved; 607 km gravel,
crushed stone, or otherwise improved; 4,925 km unimproved
Inland waterways: 800 km
Ports: 1 major (Nouadhibou), 2 minor
Civil air; 8 major transport aircraft
Airfields: 29 total, 29 usable; 9 with permanent-surface
runways; 1 with runway 2,440-3,659 m; 16 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: poor system of fragmentary open-
wire lines, a minor radio-relay link, and radiocommunica-
tions stations; 2,000 telephones (0.1 per 100 popl.); 1 AM, no
FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 321,000; 153,000 fit for
military service; conscription law not implemented
Supply: primarily dependent on France; has also received
material from Algeria, Morocco, U.K., and Spain
Military budget: for fiscal year ending 31 December 1976
(revised), $29 million; 22% of central government budget','5f70831cf4dfe8a3564ae2668da8c2b806ac6e369bb8bfc141ef3c73bef96239','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee67883f1c0198187d603a91d973ec7a0afb764a530f996fc8a6a886cd473e56',1978,'MU','Mauritius','communications',361,'9
REUNION
{ndian Qeean
(See reference mag V1)
LAND
1,856 km? (excluding dependencies); 50% agricultural,
intensely cultivated; 39% forests, woodlands, mountains,
river, and natural reserves; 3% built-up areas; 5% water
bodies, 2% roads and tracks, 1% permanent wastelands
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 177 km
Highways: 1,786 km total; 1,636 km paved, 150 km earth
Civil air: 3 major transport aircraft, including 2 leased in
Ports: 1 major (Port Louis)
Airfields: 6 total, 5 usable; 1 with permanent surface
runway; | with runway 2,440-3,659 m
Telecommunications: radio telegraph service with Re-
union, Malagasy Republic, Seychelles, Zanzibar, and other
places in Africa; 1 AM, no FM, and 4 TV stations; 26,500
telephones (2.9 per 100 popl.); 1 Indian Ocean Comsat
station
DEFENSE FORCES
Military manpower: males 15-49, 205,000; 106,000 fit for
military service
Military budget: for fiscal year ending 30 June 1973,
$3,981,038; 6.5% of central government budget
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
a
July 1978
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
{See reference map Vi}
LAND
2,512 km?; two-thirds of island extremely rugged,
consisting of volcanic mountains; 48,600 hectares (less than
one-fifth of the land) under cultivation
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 201 km
Railroads: none
Highways: 1,983 km total; 1,683 km paved, 300 km
gravel, crushed stone, or stabilized earth
Ports: 1 major (Port des Galets)
Civil air: no major transport aircraft
Airfields: 7 total, 7 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 2 with runways
1,220-2,4389 m
Telecommunications: international telecom traffic is by
tropospheric scatter through Bahrain; fair domestic facilities;
31,709 telephones (6.5 per 100 popl.); 1 AM station, 1 FM
Station, and 2 TV stations; 1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: military age males included with','0c0af7937a6bb4b1e3c8e2ce6e76991f0d4cb22991795a9cd75a6e1ab0f7782c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1879876a0197ebc0746bad00be4f7ac38455583ab21bcff3b1dc70b39fceb89',1978,'MC','Monaco','communications',365,'Be
}
Mediterranean Sea
{See reference map ly)
LAND
1.5 km?
Land boundaries; 3.7 km
WATER
Limits of territorial
Coastline: 4.1 km
Railroads: 1.6 km of 1.485 m gage
Highways: none; city streets
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: none
Telecommunications: served by the French communica-
tions system; automatic telephone system with about 23,700
telephones (96.5 per 100 popl.); 2 AM, 4 FM, and 3 TV
stations
DEFENSE FORCES
France responsible for defense','17bb3377e6fb3a64ac94918fceea55ed1df83e80c599828fb743c91b2cb4aba0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('054083f2e260ef67948f0bc9c32f5f65124af106ce9c74855fdd257324ae8dad',1978,'MN','Mongolia','communications',369,'(See reference map Vif)
LAND
1,564,619 km’; almost 90% of land area is pasture or desert
wasteland, varying in usefulness, less than 1% arable, 10%
forested
Land boundaries: 8,000 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Railroads: 1,516 km; all broad gage (1.524 m) (1976)
Inland waterways: 616 km of principal routes (1975)
Freight carried: rail—6.9 million metric tons, 3,150
million metric ton/km (1975); highway—13.9 million metric
tons, 953 million metric ton/km; waterway—0.05 million
metric tons, 0.04 billion metric ton/km (1975)
DEFENSE FORCES
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 31 December
1977, 405 million tugriks, 12% of total budget','4555cd781c8d1d982d37e0af294b5fe4aea28f47e3e7f500960aae1df68c4fb8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0fe73d7e76c052b89a51e661502f9ce189cafd6ab5240af090a9912dbbbe851',1978,'MA','Morocco','communications',373,'PORTUGA
Atlantic
(See reference map Vi}
LAND
409,200 km?; about 32% arable and grazing land, 17%
forest and esparto, 51% desert, waste, and urban
Land boundaries: 1,996 km
WATER
Limits of territorial waters (claimed): 12 nm (200 nm
exclusive economic zone)
Coastline: 1,835 km
Railroads: 1,756 km standard gage (1.435 m), 161 km
double track; 708 km electrified
Highways: 57,200 km total; 23,860 km bituminous
treated, 4,020 km gravel, crushed stone, and improved earth,
29,320 km unimproved earth
Approved For Release 2005/04/22
Pipelines: 362 km crude oil; 491 km (abandoned) refined
products; 241 km natural gas
Ports: 8 major (including Spanish-controlled Ceuta and
Melilla), 10 minor
Civil air; 21 major transport aircraft
Airfields: 77 total, 77 usable; 26 with permanent-surface
runways; 2 with runways over 3,660 m, 13 with runways
2,440-3,659 m, 30 with runways 1,220-2,439 m; 4 seaplane
stations
Telecommunications: good system by African standards
composed of open-wire lines, coaxial, multiconductor and
submarine cables and radio-relay links; principal centers
Casablanca and Rabat, secondary centers Fes, Marrakech,
Ouida, Sebaa Aioun, Tangier and Tetouan; 199,000. tele-
phones (1.1 per 100 popl.); 25 AM, 4 FM, 27 TV stations; i}
submarine cables, 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,996,000; 2,372,000 fit
for military service; about 911,000 reach military age (18)
annually; limited conscription','cb29020c976277b0bb1840095b0fa845842b1a4edfe3c944302eb2d97109e193','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8e97382add4855d145f2e5eead367b4df3452cedfd371a8a10e1e51fcac894d',1978,'MZ','Mozambique','communications',377,'indian Ocean
(See reference map vi
Land
786,762 km?; 30% arable, of which 1% cultivated, 56%
woodland and forest, 14% wasteland and inland water
Land boundaries: 4,627 km
WATER
Limits of territorial waters (claimed): 12 nm (200 nm
exclusive economic zone)
Coastline: 2,470 km
Railroads: 3,161 km total; 3,020 km 1.067-meter gage:
141 km narrow gage (0.750 m)
Highways: 26,477 km total; 4,322 km paved; 607 km
improved earth; 21,548 km unimproved earth, unconnected
Inland waterways: approx. 3,750 km of navigable routes
Pipelines: crude oil, 306 km (not operating)
Ports: 3 major (Maputo, Beira, Nacala), 2 significant
minor
Civil air: 13 major transport aircraft
Airfields: 330 total, 320 usable; 29 with permanent-sur-
face runways; 6 with runways 2,440-3,659 m; 36 with
runways 1,220-2.439 m
Telecommunications; fair system of troposcatter, open-
wire lines, and radiocommunications; principal centers
Maputo, Beira, and Nampula; 52,200 telephones (0.5 per 100
popl.); 10 AM, 2 FM, no TV Stations; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,280,000; 1,181,000 fit
for military service
Supply: mostly from the USSR and PRC, and to a lesser
extent from other Communist countries and Portugal
Military budget: for fiscal year ending 31 December
1977, $63.3 million; 18% of central government budget','2691c8e2910e9e9befebcf94ce748a5c6b2afa9831d9caf180adda8f2e60bcf3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c88f61e7f0d0a289e0d774e11bcdd7940899a82b5482bb2ad118a10cce5cd181',1978,'NA','Namibia','communications',381,'(South-West Africa)
LAND
823,620 km?, mostly desert except for interior plateau and
area along northern border
Land boundaries: 3,798 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 1,489 km
: CIA-RDP79-01051A000900010006-2
ere or
TT a _CT
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Atlantic
Ocean
Windhoek ,
SOUTH AFRICA?
(ALVIS BAY)
Indian
Ocean
(See reference map vi
Railroads: 2,326 km 1,067-meter gage, single track
Highways: 3,400 km; 2,680 km paved, remainder gravel,
remainder earth roads and _ tracks
Ports: 2 major (Walvis Bay and Luderitz)
Civil air: 4 major transport aircraft (registered in South
Africa)
Airfields: 113 total, 86 usable; 13 with permanent-surface
runways, 1 with runway over 3,660 m; 3 with runways
2,440-3,659 m, 34 with runways 1,220-2,489 m
Telecommunications: sparse system of open wire and
radio relay routes, out-lying areas connected by radiocom-
munication; Windhoek is the only major center; 46,400
telephones (6.2 per 100 popl.); 1 FM, no AM and no TV
stations
141
6-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A00090001000
July 1978
NAMIBIA/NAURU/NEPAIT,
DEFENSE FORCES
Military manpower: males 15-49, about 221,000; about
128,000 fit for military service
Defense is responsibility of Republic of South Africa','4558e6f3b9445f9d5f4ff0535af0ffd3bd695fe0d3c8055ffd95eeb9091baae8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10a6fdf712a19f3a50bbd232d11129615e46ff4c399724d6b101a1ce913758eb',1978,'NR','Nauru','communications',385,'Pacific Qcean
(See reference map Vill}
LAND
21.2 km?; insignificant arable land,
extensive phosphate mines
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 24 km
Railroads: none
Highways: about 27 km total; 21 km paved, 6 km
improved earth
Inland waterways: none
Ports: | minor
Civil air: 4 major transport aircraft
Airfields:
Telecommunications; adequate intraisland and interna-
tional radiocommunications provided via Australian facili-
ties; 700 telephones; 3,600 radio receivers, 1 AM, no FM and
no TV stations; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, about 1,800; fit for
military service, about 1,000; average number reaching
military age (18) annually, 1975-79, less than 100
No formal defense structure and no regular armed forces
1, coral-surfaced, over 1,220 m','aa04b0503b7b68c75c1dff7b7e069616f599d5d735b8871262540cb032173073','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7ffe36fedd22d960514be848ad5859cea26e189ecf3a5814d55b2cf96379650',1978,'NP','Nepal','communications',389,'LAND
141,400 km?; 16% agricultural area, 14% permanent
meadows and pastures, 38% alpine land (unarable), waste, or
urban; 32% forested
Land boundaries: 2,800 km
06-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009000100
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Bay
of Bengal
(See reference map Vil}
Railroads: 169 km, all narrow gage (0.762 m); mostly
government owned; all in Terai close to Indian border; only
53 km sector from border to Bizalpura presently in use; a 45
km segment has been abandoned and 71 km utilized to
transport rock from quarry near Dharau to Kosi Dam near
Rajbiras
143
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
NEPAL/NETHERLANDS
Highways: 3,700 km total; 1,666 km paved, 533 km
gravel or crushed stone, 1,501 km improved and unim-
proved earth; additionally 322 km of seasonally motorable
tracks
Civil air: 5 major transport aircraft
Airfields: 52 total, 51 usable; 5 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 7 with runways
1,220-2,489 m
Telecommunications: poor telephone and telegraph
service; good radiocommunication and broadcast service;
international radiocommunication service is poor; 14,000
telephones (0.1 per 100 popl.); 3 AM, no FM, and no TV
stations
DEFENSE FORCES
Military budget: for fiscal year ending 14 July 1978,
$13.9 million; 5.6% of central government budget','e2782a0e625ae92a213f55dbb4b4b479847e548dff7757a84435d696382cf113','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1257392b241f51d03317c7be6b8946bb1e548f8d89537fd029a39257706b056',1978,'NL','Netherlands','communications',393,'North DENMARK:
(See reference mag {V}
LAND
33,929 km?*; 70% cultivated, 5% waste, 8% forested, 8%
inland water, 9% other
Land boundaries: 1,022 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 12
nm)
Coastline: 451 km
Railroads: 2,979 km standard gage (1.435 m); 2,813 km
government-owned (NS), 1,638 km electrified, 1,556 km
double track; 166 km privately-owned
Highways: 104,236 km total; 86,110 km paved (including
1,450 km of limited access, divided “Motorways”; 18,126
km gravel, crushed stone
Inland waterways: 6,340 km, of which 35% is usable by
craft of 900 metric ton capacity or larger
Pipelines: 418 km crude oil; 965 km refined products;
4,489 km natural gas
Ports: 8 maior, 5 minor
Civil air: 107 major transport aircraft (including 3 leased
out and 2 leased in)
Airfields: 29 total, 28 usable; 16 with permanent-surface
runways; 13 with runways 2,,440-3,659 m, 3 with runways
1,220-2,489 m
Telecommunications: highly developed, well maintained,
and integrated; extensive system of multiconductor cables,
supplemented by radio-relay links; 5.41 million telephones
(39.2 per 100 popl.); 6 AM, 19 FM, and 16 TV stations; 12
coaxial submarine cables; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,454,000; 3,099,000 fit
for military service; average number reaching military age
(20) annually 118,000
Military budget: proposed for fiscal year ending 31
December 1978, $4.2866 million; about 9.5% of central
government budget
NETHERLANDS ANTILLES
Be
Caribbean ANTILLES
Sea PAN
4"
(See reference map It}
LAND
1,020 km’; 5% arable, 95% waste, urban, or other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 364 km
Railroads: none
Highways: 950 km total; 800 km paved, 650 km gravel
and earth
Ports: 3. major (Willemstad, Oranjestad, Caracasbaai,
Bullennbaai); 6 minor
Civil air: 6 major transport aircraft (including 1] leased in)
Airfields: 7 total, all usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 2 with runways
1,220-2,489 m: 1 seaplane station
Telecommunications: generally adequate telecom facili-
ties; extensive interisland radio-relay links; 48,000 telephones
(19.9 per 100 popl.); 11 AM, 1 FM and 5 TV stations; 2
submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 58,000; 34,000 fit for
military service: about 2,000 reach military age (20)
annually
006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2','6499d0925229a83f03d4a83b54a035e7c8acfb4a67e974647370fa8b56998da0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53ed39e3bc9072c99404c1cc92574f6b20953fd759be97be4dc825adb807c1ca',1978,'NC','New Caledonia','communications',397,'EW
CALEDONIA Pacific
Ocean
Tasman Sea
(See reference map Vill)
LAND
22,015 km?*; 6% cultivable, 22% pasture land, 15% forests,
57% waste or other
WATER
Limits of territorial waters (claimed): 12 nm (fishing, 3
nm)
Coastline: 2,254 km
Railroads: none
Highways: 5,214 km total, 600 km paved, 1,400 km
gravel, crushed stone, or stabilized surface, 618 km
improved earth, 2,596 km earth
Inland waterways: none
Ports: 1 major (Noumea), 21 minor
Civil air: no major transport aircraft
Airfields: 31 total, 31 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m; 1 airfield over
9,440 m; 1 seaplane station
Telecommunications: 20,600 telephones (14.9 per 100
popl.); 5 AM, no FM, and 7 TV stations; 1 earth satellite
station
147
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
NEW HEBRIDES/NEW ZEALAND
NEW HEBRIDES
Pacific
Ocean
~ unos
“
5
ek
=
Coral Sea
EW *
HEBRIDES *,
4
NEW
CALEDONIA
(See reference map VI}
LAND
About 14,763 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 2528 km
Railroads: none
Highways: at least 240 km sealed or all-weather roads
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 29 total, 26 usable; 2 runways 1,220-2,439 m, 2
with permanent-surface runways
Telecommunications: 3 AM broadcast stations; 2,300
telephones (2.3) per 100 popl.)
DEFENSE FORCES
Personnel: no mnilitary forces maintained; however, the
French and British maintain constabularies of about 70 men
each','265c1e491a51eeb304c5a59c8b733c1e29945767702fc93855f3fafb34a3ca86','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43dc81d390dfe07841c8052d454d6f91e7f947d77645b1405d73fcc1e5f8482c',1978,'NZ','New Zealand','communications',401,'=
. Pacific
“ Ocean
Coral Sea
z i,
t)
{See reference map Vii)
LAND
268,276 kin?; 3% cultivated, 50% pasture; 10% parks and
reserves; 20% waste, water, etc., 1% urban, 16% forested; 4
Principal islands, 2 minor inhabited islands, several minor
uninhabited islands
WATER
Limits of territorial waters (claimed): 12 nm (fishing,
200 nm)
Coastline: about 15,184 km
: CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
NEW ZEALAND/NICARAGUA
Railroads: 4,799 km; all 1.067-meter gage; 274 km double
track; 113 km electrified; over 99% government owned
Highways: 92,374 km total (1974); 44,940 km paved,
47,434 km gravel or crushed stone
Inland waterways: 1,609 km; of little importance to','14475196d09dba52b0a0dcbba0de83693e1db6f095305a9a9a5d78b025c60110','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86021528ebab425c587f952664db0d157a88cfd65ad259a729e205c5846e36bb',1978,'NI','Nicaragua','communications',409,'Railroads: 318 km 1.067-meter gage, government owned
Highways: 16,900 km total; 1,500 km paved, 6,200 km
otherwise improved, 9,200 km unimproved
Inland waterways: 2,220 km, including 2 large Jakes
Pipelines: crude oil, 56 km
Ports: 4 major (Corinto, Puerto Cabezas, Puerto Somoza,
San Juan del Sur), 6 minor
Civil air: 12 major transport aircraft (including 2 leased
in)
Airfields: 428 total, 401 usable; 7 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 7 with runways
1,220-2,439 m; 2 seaplane stations
Telecommunications: low-capacity wire and radio-relay
network; connection into Central American microwave net;
satellite ground station; 55,300 telephones (2.5 per 100
popl.); 85 AM, 30 FM, and 7 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 561,000; 343,000 fit for
military service; 25,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1978, $56.2 million for the Ministry of Defense, including
civil functions (e.g., police and civil air); 13% of central
government budget','2b9b88a1e534d43b89f5298b2cf3074ae69d50f169f1232cc4107d93a5f6a83e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d06ef6d4d4c78663e8f53dfe25a8bcb19e62c676370bb2ed556e0350f22d7e99',1978,'NE','Niger','communications',410,'LAND
1,266,510 km?; about 3% cultivated, perhaps 20% some-
what arable, remainder desert
Land boundaries: 5,745 km
Railroads: aone
Wighways: 7,122 km total; 1,889 km bituminous, 2,579
km gravel, 2.654 km unimproved earth
Inland waterways: Niger River navigable 300 km from
Niamey to Gaya on the Benin frontier from mid- December
through March
Ports: Niger landlocked; outlet to sea is Cotonou, Benin
Civil air: 4 major transport aircraft
Airfields: 66 total, 62 usable; 5 with permanent-surface
runways; | with runway 2,440-3,659 m, 18 with runways
1,220-2,439 m
Telecommunications: sparse system of open-wire lines,
radio-relay links, and small radiocommunications stations;
principal telecommunication center Niamey; 8,000 tele-
phones (0.2 per 100 popl.); 10 AM stations, no FM, and 1 TV
station; 1 Atlantic Ocean Comsat station
DEFENSE FORCES
Military manpower: males 15-49, 1,114,000; 595,000 fit
for military service; about 47,000 reach military age ( 18)
annually
Military budget: for fiscal year ending 30 September
1977, $6.9 million; about 5% of central government budget
152','2ed4caeea1f15dfceb59b05dd8eb7995b0ed2f18d6752dc37418197d1516b458','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41b96b19495f1c04ac9e50269ce38dd39b8ada59f95f99e34aef2ff9f7c74d71',1978,'NG','Nigeria','communications',414,'of Guinea
(See reference map Vi)
LAND
924,630 km?; 24% arable (13% of total land area under
cultivation), 35% forested, 41% desert, waste, urban, or other
Land boundaries: 4,034 km
WATER
Limits of territorial waters (claimed): 30 nm
Coastline: 853 km
Railroads: 3,508 km 1.067-meter gage
Highways: 89,318 km total 15,300 km paved (mostly
bituminous surface treatment); remainder laterite, gravel,
crushed stone, improved earth
Inland waterways: 8,575 km consisting of Niger and
Benue rivers and smaller rivers and creeks; additionally,
Kainji Lake has several hundred miles of navigable lake
routes
Pipelines: 1,207 km crude oil; 97 km natural gas; 5 km
refined products
Ports: 2 major (Lagos/Apapa, Port Harcourt), 10 minor
Civil air: 29 major transport aircraft (including 3 leased
in)
Airfields: 83 total, 76 usable; 16 with permanent-surface
runways; 6 with runways 2,440-3,659 m, 23 with runways
1,220-2,439 m
Telecommunications: composed of radio-relay links,
open-wire lines, and radiocommunication stations; principal
center Lagos, secondary centers Ibadan and Kaduna;
121,000 telephones (0.2 per 100 popl.); 25 AM, 6 FM, and 9
TV stations; 1 Atlantic Ocean and | Indian Ocean satellite
station and 19 domestic stations
DEFENSE FORCES
Military manpower: males 15-49, 16,425,000; 9,527,000
fit for military service; average number reaching military
age (18) annually 706,000
Military budget: for fiscal year ending 31 March 1978,
$2.6 billion; about 17% of central government budget','b856ebb8d093a1c27683de6f72b3d4fee398ec136cddddc490ed65798ce58e17','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fea92f208abad554dc2ac51710a623544020cfac1ae5efda86143fcbdcc17fbb',1978,'NO','Norway','communications',418,'LAND
Norway: 323,750 km’; Svalbard, 62,160 km?; Jan Mayen,
373 km?; 3% arable, 2% meadows and_ pastures, 21%
forested, 74% other
Land boundaries: 2,579 km
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: mainland 3,419 km; islands 2,413 km (excludes
long fjords and numerous small islands and minor indenta-
tions which total as much as 16,093 km overall)
Railroads: 4,257 km standard gage (1.435 m); Norwegian
State Railways (NSB) operates 4241 km (2,440 km
electrified and 91 km double track); 16 km privately-owned
and electrified
Highways: 77,100 km total; 16,683 km concrete and
bitumen; 17,877 km bituminous treated; 42,540 km gravel,
crushed stone, and earth
Inland waterways: 1,577 km; 1.5-2.4 m draft vessels
maximum
Pipelines: refined products, 53 km
Ports: 9 major, 69 minor
Civil air: 5] major transport aircraft (including 1 leased
out)
Airfields: 106 total, 105 usable; 53 with permanent-
surface runways; 12 with runways 2,440-3,659 m, 18 with
runways 1,220-2,439 m; 20 seaplane stations
Telecommunications: high-quality domestic and interna-
tional telephone, telegraph, and telex service; 1.48 million
telephones (36.6 per 100 popl.); 40 AM, 357 FM, and 740 TV
stations; 5 coaxial submarine cables; 2 domestic satellite
stations
DEFENSE FORCES
Military manpower: males 15-49, 925,000; 751,000 fit for
military service; average number reaching military age (20)
annually, 31,000
Military budget: proposed for fiscal year ending 31
December 1978, $1,300.5 million; about 9.5% of central
government budget
Helsinki a
Morth § one = Leningrad
Bergen 4 a
meen ae Stockholm Tallin
a ff eat &
BLD . .
g En. ys Gdteborg Raltic y Moscow
eriga
5 us dinburgh = North p / Sea
en
Atlantic Bell) iB ." gycorpfhagen ) sVithyus U.S.S.R.
Sea oO 8 _Minsk
Dablin. m Rg \\
2 Sun d
Hambs& Ve Pas ‘
ce King a Warsaw
C hg German * ee
‘A gtondon, i. } Berlin Poland ony
f fem. Rep .
hoe r ~ RED. Wreck
(cean ee ee rascals, / Federal es Lvov
: a® ewes rs
roo AC iux: Republic pragtie ; , 4 1
aes i Czech. | i!
eorN hina
2 af Germany eKishinéy 2 |
ey Munich as
ok :
a ugk wae Austria :
; France Romania
Lyon» : Bucharest, Rlack Sea
Belgrade,
Bordeaux italy Ja
Yugoslavia oS
Manacag)
ee i oh
Marseillé a eae istanbul a Ankara,
R irate } s
Por ewe) a ems Ly
¥5 arcolona Turkey
Lisb s
isbon, Spain
Q od
a) Sardinia
@ Balearic Is. \\ =
% ca) ht hens ee
_ 6
Coe 0 4
ae A
Gibraltar Sicily
Wk) te
Malta Crete
Rabat ;
ee Valletta Mediterranean Sea
ne
a
/ Morocco
SVeeeaeattly quthewiative. 2
503775 7-78
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Sea
Black
5 >, {Stanbul ae x
one oe
> pAnkara
Turkey
Adana
: d
S ee ie
Cyprus $ i
1 &NIcosia }
° pia
i
Sea
\\ Jiddah
N,
Pott Sudand gee!
ae
rae
\\e.Mecca
U.S. S.R.
“~ Tuapse
elabriz
Kirkiky','2a42422f37b57f9bddec4c0e0d1ca96058d2652856bf1b58f70f10267447e2e4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fde289d0cb3aa25c0c9b9febe81519d9684ae5da6bb81b7b23208181c47b5999',1978,'OM','Oman','communications',422,'LAND
About 212,380 km’; negligible amount forested, remain-
der desert, waste, or urban
Land boundaries: 1,384 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 50
nm)
Coastline: 2,092 km
Highways: 2,816 km total; 5 km_ bituminous surface,
2,811 km motorable track
Pipelines: crude oil 370 km
Ports: 1 major (Qaboos), 3 minor
Civil air: 5 major transport aircraft (including 1 leased in)
Airfields: 163 total, 131 usable; 4 with permanent-surface
runways; 1] runway over 3,660 m, 5 with runways
2,440-3,659 m, 47 with runways 1,220-2.439 m
Telecommunications: limited facilities of open-wire,
radio-relay and radiocommunications stations; 2 satellite
ground stations; 7,300 telephones (1.3 per 100 popl.); 3 AM,
no FM, 2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 118,000; 68,000 fit for
military service','f9594fc789c55e65e7be8ae12470ed0e2960c25aa19b343d803d3d596e4d9361','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6f4270ad44f5cc2dafe4525889563eb6fa21b11da4c7adffa7455253efe813c',1978,'PK','Pakistan','communications',426,'Arabian Sea
(See reference map Vij
LAND
803,000 km? (includes Pakistani part of Jammu-Kashmir);
40% arable, including 24% cultivated; 23% unsuitable for
cultivation; 34% unreported, probably mostly waste; 3%
forested
Land boundaries: 5,900 km
156
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; plus right to establish 100 nm conservation zones
beyond territorial sea); 200 nm exclusive economic zone
Coastline: 1,046 km
Railroads: 7,489 km total; 446 km meter gage (1.00 m),
6,431 km broad gage (1.676 m), 612 km narrow gage
(0.762 m); 1,022 km double track; 286 km electrified;
government-owned
Highways: 63,567 km total; 16,077 km paved, 12,862 km
gravel, 1,843 km improved earth, 32,785 km unimproved
earth
Inland waterways: 1,850 km
Pipelines: 230 km crude oil; 1,931 km natural gas
Ports: | major, 5 minor
Civil air: 27 major transport aircraft
Airfields: 108 total, 102 usable; 64 with permanent-sur-
face runways; | with runway over 3,660 m, 25 with runways
2,440-3,659 m, 48 with runways 1,200-2,439 m
Telecommunications: good international radiocommuni-
cation service over CENTO microwave and intelsat satellite;
domestic radiocommunications poor; broadcast service very
Approved For Release 2005/04/22
good; 300,000 (est.) telephones (0.4 per 100 popl.); 27 AM,
no FM, 16 TV stations, and 4 repeaters; 1 ground satellite
station
DEFENSE
Military manpower: males 15-49, 17,693,000; 10,485,000
fit for military service; 838,000 reach military age (17)
annually
Military budget: for fiscal year ending 30 June 1978, $996
million; about 28.4% of central government budget
Bandar ‘Abbas
ONAN
u
Muscat* .
Oman i)
Sacatra','aea04bb0acc775ccb6b58694047e11abbca6fa7701ee84a5c23156328be7109a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd98089c429e581b40fcee7ead5b9c4954a01c35662c2b7e72a4e4f1e82715a3',1978,'PA','Panama','communications',430,'Caribbean Sea
Pacific Ocean
(See reference map II)
LAND
75,650 km?* (excluding Canal Zone, 1,430 km?); 24%
agricultural land (9% fallow, 4% cropland, 11% pasture),
20% exploitable forest, 56% other forests, urban, and waste
Land boundaries: 630 km
WATER
Limits of territorial waters (claimed): 200 nm (continen-
tal shelf including sovereignty over superjacent waters)
Coastline: 2,490 km
Railroads: 249 km total; 77 km 1.524-meter gage, 172 km
0.914-meter gage
Highways: 7,800 km total; 2500 km paved, 2,300 km
gravel or crushed stone, 3,000 km improved and unim-
proved earth; Panama Canal Zone 240 km; 230 km paved,
10 km gravel
Inland waterways: 800 km navigable by shallow draft
vessels; 82 km Panama Canal
Pipelines: refined products, 96 km
Ports: 2 major (Cristobal/Colon/Coco Solo, Balboa/
Panama City), 10 minor
Civil air: 19 major transport aircraft
Airfields: (including Canal Zone) 151 total, 151 usable; 34
with permanent-surface runways; 2 with runways
2,440-3,659 m; 16 with runways 1,220-2,439 m; 2 seaplane
stations
-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
PANAMA/PAPUA NEW GUINEA
Telecommunications: domestic and international telecom
facilities well developed; connection into Central American
microwave net; COMSAT ground station; 155,200 tele-
phones (9.0 per 100 popl.); 90 AM, 30 FM, and 13 TV
stations; 1 coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 389,000; 270,000 fit for
military service; no conscription
Military budget: for fiscal year ending 31 December
1976, $32.6 million; about 10% of central government
budget','26c4ea6e61de134b2640abdb1a6fcd8ecda7ff44c219ad9c312fa1d94d68cae4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d5a020bfad2973850362bf281d30b1e400b75230469e378f2c055897a3d0033',1978,'PG','Papua New Guinea','communications',434,'Pacific Ocean
* i
PAPUAN? X¥ SOLOMON
NEW. GUINEA “Sq ISLANDS
Ports x
Pia Masts
Coral Sea
(See reference map Vill)
LAND
475,369 km?
Land boundaries: 966 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: about 5,152 km
Railroads: none
Highways: 19,200 km total; 640 km paved, 10,960 km
gravel, crushed stone, or stabilized soil surface, 7,600 km
unimproved earth
159
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
PAPUA NEW GUINEA/PARAGUAY
Inland waterways: 10,940 km
Ports: 5 principal, 8 minor
Civil air: about 19 major transport aircraft
Airfields: 540 total, 481 usable; 19 with permanent-sur-
face runways; 2 with runways 2,440-with 3,659 m; 43 with
runways 1,220-2,489 m; 1 with runway 2,750 m—Port
Moresby
Telecommunications: Papua New Guinea telecom serv-
ices are adequate and are being improved; principal telecom
centers include Goroka, Lae, Madang, Mount Hagen, and
Wewak in New Guinea; and Daru, Port Moresby and
Samarai in Papua; facilities provide radiobroadcast, radio-
telephone and telegraph, coastal radio, aeronautical radio
and international radiocommunication services; numerous
privately owned radio facilities exist; submarine cables
extend from Madang to Australia and Guam; 37,500
telephones (1.3 per 100 popl.); 31 AM, no FM and no TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 687,000; about 378,000
fit for military service
Supply: dependent on Australia
Military budget: for fiscal year ending 30 June 1976,
$22.3 million; 4.3% of central government budget','b8663406a9fdbf153004ce1a25a8f0500086bb3ee389e9792b2a044895edc2cc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ea25269426b77893eb16f0c662ae89f505232980c705361a40ebd3cf0681bfc',1978,'PY','Paraguay','communications',438,'f .
Atlantic Ocean
{See reference map tl}
LAND
406,630 km?; 2% under crops, 24% meadow and pasture,
52% forested, 22% urban, waste, and other
Land boundaries: 3,444 km
Railroads: 1,043 km total; 437 km standard gage (1.485
m), 136 km meter gage (1.00 m), 470 km various narrow
gage (privately owned)
Highways: 7,500 km total; 900 km paved, 600 km gravel,
6,000 km unimproved earth
Inland waterways: 3,100 km
Ports: 1 major (Asuncion), 9 minor (all river)
Civil air: 7 major transport aircraft
Airfields: 940 total, 810 usable; 1 with permanent-surface
runway; 1 with runway 2,440-3,659 m, 19 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: local telecom facilities in Asuncion
good, intercity microwave net, 41,600 telephones (1.5 per
100 popl.); 25 AM, 9 FM stations, and 1 TV station; 1
Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 687,000; 518,000 fit for
military service; average number currently reaching military
age (17) annually, 33,000
Military budget: for fiscal year ending 31 December
1978, $41.2 million; about 14.7% of central government
budget','cc320d35d49e6fdf33ff3bcc613aec96d96cf1cb07120fc24036e2584aa07cff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afb245f22885bf3e60fd6e781fbcf1a27a658304b2d41b1ade8efda8023d1460',1978,'PE','Peru','communications',442,'Pacific
Ocean
LAND
1,284,640 km? (other estimates range as low as 1,248,380
km?); 2% cropland, 14% meadows and pastures, 55%
forested, 29% urban, waste, other
Land boundaries: 6,131 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2,414 km
Railroads: 2,148 km total; 1,776 km standard gage (1.435
m), 46 km 0.60-meter gage, 326 km 0.914-meter gage: 14 km
double track
Highways: 52,400 km total; 5,400 km paved, 9,900 km
gravel, 14,400 km improved earth, 22,700 km unimproved
earth
Inland waterways: 8,600 km of navigable tributaries of
Amazon River system and 208 km Lake Titicaca
Pipelines: crude oil, 730 km; natural gas and natural gas
liquids, 64 km
Ports: 7 major, 20 minor
Civil air: 26 major transport aircraft
Airfields: 301 total, 301 usable; 24 with permanent-sur-
face runways; 2 with runways over 3,660 m, 20 with
runways 2,440-3,659 m, 46 with runways 1,220-2,489 m; 3
seaplane stations
Telecommunications: fairly adequate for most require-
ments, new nationwide radio-relay system; 1 Atlantic Ocean
satellite station; 410,000 telephones (2.5 per 100 popl.); 200
AM, 7 FM, and 31 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 3,695,000; 2,503,000 fit
for military service; average number currently reaching
military age (20) annually, 167,000
Military budget: for fiscal year ending 31 December
1978, $254 million; about 11.4% of central government
budget','6c7973304c5b6251fc87e6648eaff6848e270d816a8fbba57f3d7e8f091cc02c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99637aabbee30b7e50baa9bd14ef96a582e4fe0aaa03cd76dbb1ee7fe30d40b5',1978,'PL','Poland','communications',446,'(See reference map IV)
LAND
312,354 km?®,; 49% arable, 14% other agricultural, 27%
forested, 10% other
Land boundaries: 3,090 km
WATER
Limits of territorial waters (claimed): 3 nm (3 nm
contiguous zone claimed in addition to the territorial sea)
(fishing 12 nm)
Coastline: 491 km
164
Railroads: 26,695 km total; 23,816 km standard gage
(1.485 m), 2,879 km other gage; 7,474 km double track;
6,308 km electrified; government owned (1976)
Highways: 305,863 km total; 65,000 km concrete, asphalt,
stone block; 98,000 km crushed stone, gravel; 142,863 km
earth (1976)
Inland waterways: 3,759 km navigable streams and
canals (1977)
Pipelines: 3,540 km for natural gas; 1,515 km for crude
oil; 322 km for refined products
Freight carried: rail—470 million metric tons (1976),
130.8 billion metric ton/km (1976); highway—1,950 million
metric tons, 32.3 billion metric ton/km (1976); waterway—
17.4 million metric tons, 3.0 billion metric ton/km; excl.
int''l. transit traffic in approximately 1,560 waterway craft
with 525,600 metric ton capacity (1977)
Ports: 4 major (Gdansk, Gdynia, Szczecin, Swinoujscie), 6
minor (1977)','09028bced11ba520bb04d6573de4f1e9bb35b0f04c777ba958ac2f7a6548f363','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca215db32593db373bcefaf78e718d47aeacdbad62afc637163952c1f30b7364',1978,'PT','Portugal','communications',450,'LAND
Metropolitan Portugal: 94,276 km?, including the Azores
and Madeira Islands; 48% arable, 6% meadow and pasture,
31% forested, 15% waste and urban, inland water, and other
Land boundaries: 1,207 km
Atlantic
(See reference map IV)
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm); 200 nm exclusive economic zone
Coastline: 860 km (excludes Azores (708 km) and
Madeira (225 km))','dfab61c0d6e1072bcbbb2a768fb44c6014dc3956f89073f680420d45918d2bbb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('982bee623633b3c38c500317788797783fcc895574ca50ae617fde1e42e57e06',1978,'QA','Qatar','communications',457,'Railroads: none
Highways: 805 km total; 442 km bituminous; 362 km
gravel; undetermined mileage of earth tracks
167
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
QATAR/REUNION
Pipelines: crude oil, 169 km: natural gas, 97 km
Ports: lt major (Ad Dawhah), 1 minor
Airfields: 2 total, 1 usable; 2 with permanent-surface
runways, 1 with runway over 3,660 m
Civil air: 2 major transport aircraft, 1 registered in the
ULK.
Telecommunications: international telecom traffic is by
tropospheric scatter through Bahrain; fair domestic facilities;
24,000 telephones (14.8 per 100 popl.); 1 AM station, 1 FM
station, and 2 TV stations, 1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, about 41,000; about
24,000 fit for military service
Military budget: for fiscal year ending 24 January 1974,
$53,680,900; 18% of central government budget
REUNION
Indian','928fdc2c90fe9b429487f0a5630e7bd506ad0c0f3cdbc35c6a854cc8be468ffd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c93374197dd05ffac64247fc46a4382ba9a4789b5b6d1fe52762f160fe316b8',1978,'RW','Rwanda','communications',461,'(See reference map Vi}
LAND
25,900 km?; almost all the arable land, about 1/3 under
cultivation, about 1/3 pastureland
Land boundaries:, 877 km','1cdb4d745fb46ebdee92b6ad42fa91b9c46103303efba220d192e6a10e40d898','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d475c98c8e5fca1e8e8d581ac5d38979a608125a9bc909b2fe91e71c75d384fb',1978,'SM','San Marino','communications',465,'LAND
62 km*; 74% cultivated, 22% meadows and pastures, 4%
built-on
Land boundaries: 34 km
Mediterranean Sea
(See reference map {V)
Railroads: none
Iighways: about 104 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system serv-
ing 5,700 telephones (28.1 per 100 popl.); no radiobroadcast-
ing or television facilities','c72f2f4daf416f710dc8b164891b583b9539ef8660ce9068cc912bba9f302d92','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41049cb42e0592bd7fa67fad47d8874ee721d1c8524797e55a7fdb8e2885341d',1978,'ST','Sao Tome and Principe','communications',469,'SAQ TOME
AND.
PRINCIPE \\
Siu Tome®
Pa
Atlantic Ocean
(See reference map V)
LAND
964 km? (Sao Tome, 855 km? and Principe, 109 km/?;
including small islets of Pedras Tinhosas)
WATER
Limits of territorial waters: 6 nm (fishing 12 nm)
Coastline: estimated 209 km
Ports: 1 major (Sao Tome)
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,489 m
Telecommunications: minimal system; 750 telephones
(1.0 per 100 popl.); 2 AM, 1 FM, and no TV stations','6df5e0d9dc85c6aa4b88dbd821d428e1a5a2b2a9201b803792539ef915d7a8b1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cb5f87d3c20ab3a058aef644f0eca4beb4e8aec4eb89742dd096b3a4522f8a5',1978,'SA','Saudi Arabia','communications',473,'° Arabian
Sea
(See reference map V)
LAND
Fstimated at about 2,331,000 km? (boundaries undefined
and disputed); 1% agricultural, 1% forested, 98% desert,
waste, or urban
Land boundaries: 4,537 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 2,510 km
Railroads: 575 km standard gage (1.435 m)
Highways: 17,850 km total; 10,750 km bituminous, 7,100
km gravel and improved earth, undetermined kilometers of
earth roads and _ tracks
Pipelines: 2,430 km crude oil; 386 km refined products;
98 km natural gas
Ports: 3 major (Jidda, Ad Damman, Ras Tanura), 6 minor
Civil air: 77 major transport aircraft (including 10 leased
in)
178
Airfields: 119 total, 94 usable; 28 with permanent-surface
runways; 15 with runways 2,440-3,659 m, 43 with runways
1,220-2,439 m, 6 with runways over 3,660 m
Telecommunications: fair system exists, major expansion
program underway with microwave, coaxial cable, satellite
systems; 200,000 telephones (2.5 per 100 popl.); 6 AM, 1 FM,
11 TV stations, 1 submarine cable; 2 Intelsat stations, several
domestic satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 1,810,000; 1,022,000 fit
for military service; about 66,000 reach military age (18)
annually
Military budget: for fiscal year ending 1 July 1978,
$9,528 million; about 28% of central government budget','2eaca96fb58faad9c48524af7f6aae5f2f859ae686165450653b4281ec3e9c4b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a879ae1e478026d6af855ebe8787631aee604c83d878a89641713640397ae2b',1978,'SN','Senegal','communications',477,'Dakar
* SENEGA
THE GAMBIA paseo
Railroads: 1,033 km meter gage (1.00 m); 64 km double
track
Highways: 13,589 km total; 2,547 km paved, 11,042 km
other
Inland waterways: 1,505 km
Ports; 1 major (Dakar), 2 minor
Civil air: 8 major transport aircraft (including 1 leased in)
Airfields: 27 total, 27 usable; 11 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 19 with runways
1,220-2,439 m; 3 seaplane stations
Telecommunications: relatively advanced for Africa;
39,000 telephones (0.7 per 100 popl.); 3 AM stations, no FM
station, and 1 TV station; 2 submarine cables; 1 Atlantic
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,179,000; 609,000 fit
for military service; 48,000 reach military age (18) annually
Military budget: for fiscal year ending 30 June 1978,
$45,117,408; about 7.2% of central government budget
179
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978','3bee5a6334cda3733ba054796d1e3b4b55dd9509d41a6da0e8688dbd0e247944','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a2d31204b31af3c4d53f40025afe0df352eaaf70899b3579657b54e5678953f',1978,'SC','Seychelles','communications',481,'indian Ocean
Victoria
4
Railroads: none
Highways: 215 km total; 145 km bituminous, 70 km
crushed stone or earth
Ports: 1 small port (Victoria)
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable (on Praslin Island, Astove
Island, Bird Island, Mahe Island); with 1 permanent-surface
runway 2,440-3,659
Telecommunications: direct radiocommunications with
adjacent islands and African coastal countries; 3,900
telephones (6.4 per 100 popl.); 2 AM, no FM, and no TV
stations; Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 14,000; 7,000 fit for
military service
Supply: infantry-type weapons and ammunition from
Tanzania','02e984d99dd7e1c547ca4bc850985be70f5bb3f506337a3e1bd21b9b9ee2e6e1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('daef25eb6e9baca53b394459665ea052904e76afff8254b6a0e3c3043ef09ecf',1978,'SL','Sierra Leone','communications',485,'GUINEA-
BISSAU
Atlantic
Ocean
{See reference map Vi}
LAND
72,261 km%; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
Land boundaries: 933 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 402 km
Railroads: about 84 km narrow gage (1.067 m) privately
owned mineral line operated by the Sierra Leone Develop-
ment Company
Highways: 7,073 km total; 1,148 km bituminous, 507 km
laterite (some gravel), and 5,418 km improved earth
Inland waterways: 800 km; 600 km navigable year-round
Ports: 1 major (Freetown), 2 minor
Civil air: no major transport aircraft
Airfields: 16 total, 16 usable; 6 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 5 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: telephone and telegraph are inade-
quate; 15,000 telephones (0.5 per 100 popl.); 2 AM stations,
no FM, and 1 TV station; 1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 660,000; 317,000 fit for
military service; no conscription
Military budget: for year ending 30 June 1978,
$11,379,310 (excluding procurement funds); 8.5% of central
government budget','fcad7dc9e88cdb661ba7eed6a2c09b3f776d0f73de173f13ba1cc22b428c307f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b3a6da00e256f3b09e9ac39ed0665004120f08d6367c3319bc0ddb8294ee0fb',1978,'SB','Solomon Islands','communications',491,'PAPUA
ae, SOLOMON
ty
, «ISLANDS
SI
-)
Coral Sea :
Pacific
Ocean |
(See reference map Vill)
LAND
About 29,785 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 5,313 km
Railroad: none
Highways: 834 km total; 241 km sealed or all-weather
Inland waterways: none
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 22 total, 21 usable: 1 with permanent-surface
tunway; 5 with runways 1,220-2,489 m; 1 seaplane station
Telecommunications: 3 AM broadcast, no FM, and no
TV stations; 10,000 radio receivers, 1,726 telephones, no TV
sets; international connections with London, England, via
cable broadcasts','1878ea699fe9d7a0d403db417241f13bce57980dd0ff7ede828f7c2d66d7b644','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ed80a80be6b12af292adb8e9691872fb90720c12956b53c17f96285719dc6c7',1978,'SO','Somalia','communications',495,'LAND
637,140 km?*; 13% arable (0.3% cultivated), 32% grazing,
14% scrub and forest, 41% mainly desert, urban, or other
Land boundaries: 2,263 km
184
‘Mogadiscio
{See reference map Vi}
WATER
Limits of territorial waters (claimed); 200 nm
Coastline: 3,025 km
Railroads: none
Highways: 13,541 km total, 986 km paved, 770 km
crushed stone, gravel, or stabilized soil, 11,835 km improved
or unimproved earth (est.)
Ports: 3 major (Mogadiscio, Berbera, Chisimaio)
Civil air: 6 major transport aircraft
Airfields: 55 total, 49 usable; 6 with permanent-surface
runways; 2 with runways over 3,660 m; 3 with runways
2,440-3,659 m; 16 with runways 1,220-2,439 m
Telecommunications: telephone poor, telegraph fair;
6,000 telephones (0.2 per 100 popl.); 2 AM, no FM, 1 TV
station
DEFENSE FORCES
Military manpower: males 15-49, 786,000; 435,000 fit for
military service; no conscription
Military budget: for fiscal year ending 31 December
1976, 34,650,357; 17.3% of central government budget','0691c243138b64995607063afb781a9ac816f6a322567431466d23bbd315d5d4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a529f98e99c45d130604711081703a51f912bf2e976359354f43dd6c1f4fa87',1978,'ZA','South Africa','communications',499,'NOTE: separate data on Transkei follows last entry for
LAND
1,222,480 km? (includes enclave of Walvis Bay, 1,124 km’;
and Transkei, 44,000 km?); 12% cultivable, 2% forested, 86%
desert, waste, or urban
Land boundaries: 2,044 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 2,881 km, including Transkei
SOUTH sftp Indian
lee,
AFRICA Ocean
(See reference map Vi}
Railroads: 25,560 km total; 24,854 km 1.067-meter gage
of which 5,292 km are multiple track; over 5,000 km
electrified; 706 km 0.160-meter gage single track
Highways: 209,244 km total; 57,368 km paved, 148,786
km crushed stone, gravel, or improved earth; 3,090 km
unimproved earth
Pipelines: 836 km crude oil; 1,048 km refined products;
322 km natural gas
Ports: 8 major
Civil air: 80 major transport aircraft
Airfields: 657 total, 520 usable; 66 with permanent-sur-
face runways; 3 with runways over 3,660 m, 6 with runways
2,440-8,659 m, 126 with runways 1,220-2.439 m
Telecommunications: the system is the best developed,
most modern, and highest capacity in Africa and consists of
carrier-equipped open-wire lines, coaxial cables, radio-relay
links, and radiocommunication stations; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg, Port
Elizabeth, and Pretoria; 2.2 million telephones (8.3 per 100
popl.); 13 AM, 84 FM, and 34 TV stations; 1 submarine
cable; 1 satellite station with Atlantic Ocean and Indian
Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 6,006,000; 3,666,000 fit
for military service; obligation for service in Citizen Force or
Commandos begins at 18; volunteers for service in
permanent force must be 17; national service obligation is
two years
Military budget: for year ending 81 March 1979, $2.0
billion; 18% of central government budget
Transkei
NOTE: Formerly an autonomous tribal homeland in
South Africa, Transkei was granted independence by South
Africa on 26 October 1976, but has not been recognized by
any other government or any international organization. It
remains heavily dependent on South Africa for administra-
tive and economic support.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
a —
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
SOUTH AFRICA/SPAIN
LAND
44,000 km’ in one large and two small pieces separated
from each other by parts of South Africa
Land boundaries: 1,200 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 250 km
Railroads: less than 160 km
Highways: 725 km paved, 7,768 km unpaved
Ports: none; Transkei dependent on the South African
port of East London
DEFENSE FORCES
Military manpower: males 15-49, 215,000
Personnel: 254 army (including 7 officers)
Major ground units: 1 infantry battalion','4bdc15a926df7fdd9a1688018ceb142e653315c879e922a9f130074210a332ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cab9e4f9882f82178a21ba6223ebee296e043b7e1da366c2812018323d821b41',1978,'ES','Spain','communications',503,'LAND
505,050 km’, including Canary (7,511 km?) and Balearic
Islands (5,025 km?*); 41% arable and land under permanent
crops, 27% meadow and pasture, 22% forest, 10% urban or
other
Land boundaries: 1,899 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4,964 km (includes Balearic Islands, 677 km,
and Canary Islands, 1,158 km) :
Railroads: 15,975 km total; Spanish National Railways
(RENFE) operates 13,509 km 1.668-meter gage, 4,328 km
electrified and 2,162 km double track; FEVE (government-
owned narrow gage railways) operates 1,676 km, of
predominantly meter gage (1.000 m) and 310 km electrified;
privately-owned railways operate 790 km, of predominantly
meter gage (1.000 m), 245 km electrified and 56 km double
track
Highways: 189,350 km total; 78,585 national—6,810 km
bituminous, concrete, stone block; 56,650 bituminous treated;
15,125 km crushed stone; the remaining 60,765 km are
classified as provincial or local roads
Inland waterways: 1,045 km; of minor importance as
transport arteries and contribute little to economy
Pipelines: 386 km crude oil; 1,080 km refined products;
98 km natural gas
Ports: 23 major, 150 minor
Civil air: 178 major transport aircraft (including 4 leased
in)
Airfields (including Balearic and Canary Islands): 94
total, 86 usable; 51 with permanent-surface runways; 4 with
runways over 3,660 m, 19 with runways 2,440-3,659 m, 34
with runways 1,220-2,439 m; 4 seaplane stations
Telecommunications: generally adequate, modern facili-
ties; 8.6 million telephones (23.9 per 100 popl.); 180 AM, 250
FM, and 791 TV stations; 14 coaxial submarine cables; 4
communication satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 8,799,000; 6,768,000 fit
for military service; 301,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1979, $4,117.9 million; about 22% of the proposed central
government budget','90fa545755e41668be463c80e1c61f5bfadc5a570622ee224b32baa3682e47ba','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db0cc4ca39e3d0b44987d4295f9ef4a4ba9df7d0617da2676b1700013b548360',1978,'SD','Sudan','communications',510,'LAND
2,504,530 km?; 37% arable (3% cultivated), 15% grazing,
33% desert, waste, or urban, 15% forest
Land boundaries: 7,805 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone”)
Coastline: 853 km
Railroads: 5,470 km total; 4,754 km 1.067-meter gage,
716 km 1.6096-meter gage plantation line
Highways: 10,550 km total; 600 km bituminous-treated,
800 km crushed stone or gravel, and 9,150 km improved and
unimproved earth roads; in addition, there are an undeter-
mined number of tracks
Inland waterways: 5,310 km navigable
Pipelines: refined products, 800 km
Ports: 1 major (Port Sudan)
Civil air: 9 major transport aircraft
Airfields: 80 total, 75 usable; 8 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 31 with runways
1,220-2,4389 m
192
Telecommunications: large system by African standards,
but barely adequate; consists of radio relay, cables,
radiocommunications, and troposcatter; domestic satellite
system with 14 stations under construction; centers are
Khartoum, Al Fashir, Port Sudan; 56,000 telephones (0.3 per
100 popl.); 2 AM, no FM, and 2 TV stations; 1 submarine
cable; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 4,189,000; 2,567,000 fit
for military service; average number reaching military age
(18) annually, 201,000
Military budget: for fiscal year ending 30 June 1978,
$237,000,000; 11% of central government budget
SURINAM
LED oe
Caribbean = % :
Sea 8 Atlantic
Ocean
(See reference map f}
LAND
142,709 km*; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially
productive, 16% built-on area, wasteland, and other
Land boundaries: 1,561 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 386 km
Railroads: 166 km total; 86 km meter gage (1.00 m)
(government-owned) and 80 km narrow gage (industrial
lines); all single track
Highways: 2,500 km total; 500 km paved, 200 km gravel,
600 km improved earth, 1,200 km unimproved earth
Inland waterways: 4,500 km; most important means of
transport; oceangoing vessels with drafts ranging from 4.2 m
to 7 m can navigate many of the principal waterways while
native canoes navigate upper reaches
1 Surinam guilder (S.
Ports: 1 major (Paramaribo), 6 minor
Civil air: 1 major transport aircraft
Airfields: 30 total, 29 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 2 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: international facilities good; do-
mestic radio-relay system; 18,600 telephones (4.9 per 100
popl.); 6 AM, 1 FM, and 1 TV station with 4 relay
transmitters
DEFENSE FORCES
Military manpower: males 15-49, 102,000; 60,000 fit for
military service
SWAZILAND
LAND
17,364 km2; most of area suitable for crops or pastureland
Land boundaries: 485 km
Railroads: 222 km 1.067-meter gage, single track
Highways: 2,653 km total; 224 km paved, 1,114 km
crushed stone, gravel, or stabilized soil, and 1,315 km
improved earth
Civil air: 3 major transport aircraft
Airfields: 31 total, 23 usable; 1 with runway 1,220-
2,489 m
Telecommunications: system consists of a few open-
wire lines and low-powered radiocommunication stations;
Mbabane is the center; 8,200 telephones (1.6 per 100 popl.);
1 AM, 2 FM, no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 117,000; 69,000 fit for
military service
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978','603c859fc007bc516025f04f9f9d9248dd0187050dfbe582c72444e07a125d4b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('691c32d5ac14204cb28405cda5b2f472920654cc9e8e5eba5fb00c30826fd02d',1978,'SE','Sweden','communications',514,'Norwegian
(See reference map lV}
LAND
448,070 km?®; 8% arable, 1% meadows and pastures, 55%
forested, 36% other
Land boundaries: 2,196 km
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm)
Coastline: 3,218 km
Railroads: 12,220 km total; Swedish State Railways (SJ =
11,179 km standard gage (1.435 m), 6,959 km electrified and
1,152 km double track; 182 km 0.891-meter gage; 159 km
rail ferry service; privately-owned railways—311 km stand-
ard gage (1.435 m), 332 km electrified; 189 km 0.891-meter
gage electrified
Highways: 97,400 km total; 51,899 km bitumen, concrete;
20,659 km bituminous treated, gravel, improved earth;
24,842 km unimproved earth
Inland waterways: 2,052 km navigable for small steamers
and _ barges
Ports: 17 major, and 30 minor
Civil air: 63 major transports (including 1 leased in)
Airfields: 243 total, 236 usable; 131 with permanent-sur-
face runways; 7 with runways 2,440-3,659 m, 85 with
runways 1,220-2,439 m
Telecommunications: excellent domestic and interna-
tional facilities; 5.67 million telephones (68.9 per 100 popl.);
9 AM, 91 FM, and 240 TV stations; 10 submarine cables,
including 4 coaxial; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,881,000; 1,670,000 fit
for military service; 55,000 reach military age (19) annually
Military budget: for fiscal year ending 30 June 1978,
$2.91 billion; about 9% of central government budget','9f245bc6fedc421021df09224137060c3c83ec764f69a98d08461ec94c299d41','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e56692544c042e902623fd228595c8e514e0b379c1056737bc58f9aa0b81a9d',1978,'CH','Switzerland','communications',518,'LAND
41,440 km?; 10% arable, 43% meadows and: pastures, 20%
waste or urban, 24% forested, 3% inland water
Land boundaries: 1,884 km
196
(See reference map {¥)
Railroads: 5,098 km total; 2,895 km government-owned
(SBB), 2,822 km standard gage (1.435 m); 73 km narrow
gage (1.00 m), 1,339 km double track, 99% electrified;
2,203 km non-government owned, 710 km standard gage
(1.435 m), 1,418 km meter-gage (1.00 m), 75 km 0.790-me-
ter gage, 100% electrified
Highways: 62,145 km, all paved
Pipelines: 314 km crude oil; 1,046 km natural gas
Inland waterways: 65 km; Rhine River-Basel to Rhein- —
felden, Schaffhausen to Constanz; in addition, there are 12
navigable lakes ranging in size from Lake Geneva to
Hallwilersee
Ports: 1 major (Basel), 2 minor
Civil air: 88 major transport aircraft (including 1 leased
in)
Airfields: 79 total, 72 usable; 40 with permanent-surface
runways; 2 with runways over 3,660 m, 8 with runways
2,440-3,659 m, 12 with runways 1,220-2,439 m
Telecommunications: excellent domestic, international,
and broadcast services; 4.02 million telephones (63.8 per 100
popl.); 8 AM, 94 FM, and 350 TV stations; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,518,000; 1,315,000 fit
for military service; 48,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1977, $1,141 million; 18% of central government budget
SYRIA
LAND
186,480 km? (including 1,295 km? of Israeli-occupied
territory); 48% arable, 29% grazing, 2% forest, 21% desert
Land boundaries: 2,196 km (1967) (excluding occupied
area 2,156 km)
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 193 km
Railroads: 1,543 km total; 1,281 km standard gage, 262
km narrow gage (1.050 m)
Highways: 11,500 km total; 6,930 km paved, 1,300 km
gravel or crushed stone, 2,470 km improved earth, 800 km
unimproved earth
Inland waterways: 672 km; of little importance
Pipelines: 1,304 km crude oil; 515 km refined products
Ports: 3 major (Tartus, Latakia, Baniyas), 2 minor
Civil air: 10 major transport aircraft
Airfields: 40 total, 34 usable; 25 with permanent-surface
runways; 22 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: good international and domestic
service; 177,000 telephones (2.2 per 100 popl.); 9 AM, no FM
and 5 TV stations; 1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,824,000; 1,021,000 fit
for military service; about 96,000 reach military age (19)
annually
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
TANZANIA
TANZANIA
TANZANIA
Dar es Salaam
(See reference map Vi)
LAND
939,652 km? (including islands of Zanzibar and Pemba,
2,642 km?); 6% inland water, 15% cultivated, 31% grassland,
48% bush forest, woodland; on mainland, 60% arable, of
which 40% cultivated on islands of Zanzibar and Pemba
Land boundaries: 3,883 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 1,424 km (this includes 113 km Mafia Island;
177 km Pemba Island; and 212 km Zanzibar)','21e508fc4ccdef18f972d3ff8968ce688e64b612b2deb4b4e194cce14aeef0f4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1111aab0b7c1d939309bf3d67b57fceb8c3310e14663459f75c27346bbb67127',1978,'TH','Thailand','communications',522,'Bay
of Bengal
/
: Gulf of
‘ndian Ocean :
(See reference map Vil}
LAND
512,820 km; 24% in farms, 56% forested, 20% other
Land boundaries: 4,868 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 3,219 km
Railroads: 3,833 km meter gage (1.00 m), 97 km double
track
Highways: 28,806 km total; 14,773 km paved, 4,731 km
crushed stone or gravel, 9,302 km earth and laterite
Inland waterways: 3,999 km principal waterways; 3,701
km with navigale depths of 0.9 m or more throughout the
year; numerous minor waterways navigable by shallow-
draft native craft
Ports: 2 major, 16 minor
Civil air: 25 major transport aircraft
Airfields: 154 total, 153 usable; 55 with permanent-
surface runways; 10 with runways 2,440-3,659 m, 29 with
runways 1,220-2,439 m
Telecommunications: service to general public adequate;
bulk of service to government activities provided by
radiocommunications stations and radio-relay network;
satellite ground station; 312,000 telephones; over 8 million
radios; and over 650,000 televisions; approx. 150 AM, 15
FM, and 10 TV transmitters in government-controlled
networks
DEFENSE FORCES
Military manpower: males 15-49, 11,244,000; 6,844,000
fit for military service; about 503,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1978, $760.7 million; 18.8% of central government budget','b551ae1aefbcbc79bc30540cc80a915ce989ddeb2bd5ff3767b6a724a0693f6c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4819502e161886313d94db9031bdb8b332bb0670b7d768576f57d7b69cfb3830',1978,'TG','Togo','communications',526,'Gulf of Guinea
{See reference map V1)
LAND
56,980 km’; nearly one-half is arable, under 15%
cultivated
Land boundaries: 1,646 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 56 km
Railroads: 442 km meter gage (1.00 m), single track
Highways: approx. 6,974 km total; 1,208 km paved, 166
km improved earth, 4,600 unimproved earth
Inland waterways: section of Mono River and about 50
km of coastal lagoons and tidal creeks
Ports: 1 major (Lome), 1 minor
Civil air: 4 major transport aircraft
Airfields: 11 total, 11 usable; 1 with permanent-surface
runway 2,440-3,659 m
Telecommunications: fair system based on skeletal
network of open-wire lines supplemented by a radio relay
route radiocommunication stations; only center is Lome;
6,300 telephones (0.3 per 100 popl.); 2 AM stations, | FM
radio station, 3 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 540,000; 279,000 fit for
military service; no conscription
Supply: most military materiel obtained from France
Military budget: for fiscal year ending 31 December
1978, $19,927,920; 7.8% of central government budget','a3ca1a6e233a09a3cafbef2ab1615db9432e0d2d5beb18ec926d4e8ddb21dbb5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92aca4928ae451e713d6e9e4329958c6e799a992d67151d1b6a5d5351ec25678',1978,'TO','Tonga','communications',530,'LAND
997 km? (150 islands); 77% arable, 3% pasture, 13% forest,
3% inland water, 4% other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 419 km (est.)
Railroads: none
Highways: 249 km total (1974); 177 km rolled stone; 72
km coral base
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable;
1,220-2,439 m; 1 seaplane station
1 with grass runway
Telecommunications: 552 telephones (2.2 per 100 popl.);
11,000 radio sets; no TV sets; 1 AM station','30f962f964f95156af597d4c21ef6632cc14a6705e9f1d9dd40f32edb7ac806a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a20cd09514c5311d4d6fee69a3830ac5489a2a1fb042eb6fab25f45b38ab624d',1978,'TT','Trinidad and Tobago','communications',534,'Atlantic Ocean
e
Caribbean Sea ©
°
x
Ff
Spain - TRINIDAD
23 AND TOBAGO
(See reference map it)
LAND
5,128 km?; 41.9% in farms (25.7% cropped or fallow, 1.5%
pasture, 10.6% forests, and 4.1% unused or built-on), 58.1%
outside of farms, including grassland, forest, built-up area,
and wasteland
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 362 km
Railroads: none
Highways: 3,100 km total; 2,800 km paved, 200 km
gravel, 100 km improved earth
Pipelines: 1,032 km crude oil and refined products; 832
km natural gas
Ports: 3 major (Port of Spain, Chaquaramars Bay, Point
Tembladora), 6 minor
Civil air: 13 major transport aircraft
Airfields: 8 total, 7 usable; 4 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m; 2 seaplane stations
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
TRINIDAD AND TOBAGO/TUNISIA
Telecommunications: excellent international service via
tropospheric scatter links to Barbados and Guyana; good
local service; 1 Atlantic Ocean satellite station; 70,400
telephones (6.6 per 100 popl.); 2 AM, 2 FM, and 3 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 261,000, 184,000 fit for
military service
Supply: mostly from U.K.
Military budget: proposed for fiscal year ending 31
December 1977, $48.4 million; about 4.8% of central
government budget
(See reference map VI}
LAND
164,206 km?; 28% arable land and tree crops, 23% range
and esparto grass, 6% forest, 43% desert, waste or urban
Land boundaries: 1,408 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 12
nm exclusive fisheries zone follows the 50-meter isobath for
part of the coast, maximum 65 nm)
Coastline: 1,143 km (includes offshore islands)','24210abba3055cfa09339b2953c14c7593e3205c28372040c74c1f61eff94d25','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b28f213390b1772b2e52a263c72982376ba89eca8d90e2d870dd8510123cc41a',1978,'TV','Tuvalu','communications',538,'(formerly Ellice Islands)
“.
UNITED “"p,
STATES
Pacific Ocean
GILBERT
*,_,, ISLANDS
+, TUVALU
~
{See reference map VIN}
NOTE: On October 1, 1975, by Constitutional Order, the
Fllice Islands were formally separated from the British
colony of Gilbert and Ellice Islands, thus forming the new
colony of Tuvalu. The remaining islands in the former
Gilbert and Ellice Islands Colony were renamed the Gilbert
Islands.
The new colony of Tuvalu includes the islands of
Nanumanga, Nanumea, Nui, Niutao, Vaitupu, and those
islands claimed by the United States: Funafuti, Nukufetau,
Nukulailai, and Nurakita.
LAND
26 km?
207
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
TUVALU/UGANDA
WATER
Limits of territorial waters: 3 nm
Coastline: about 24 km
Railroads: none
Highways: 8 km gravel
Inland waterways: none
Ports: lt minor
Civil air: no major transport aircraft
Airfields: 1 total; 1 usable with runway 1,220-2,439 m; 1
seaplane station
Telecommunications: 1 AM station; about 300 telephones
(0.5 per 100 popl.); 4,000 radio sets','c42f0c41ccfe7d42ca363ef6d5fea392a3c4953cfd810ce33606b5efb8e3808b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37d1549263e72d112c155abecd6fe882784a333d0846b0cfa6c64a54c8eda8f5',1978,'UG','Uganda','communications',542,'LAND
235,690 km?; 21% inland water and swamp, including
territorial waters of Lake Victoria, about 21% cultivated,
13% national parks, forest, and game reserves, 45% forest,
woodland, and grassland
Land boundaries: 2,680 km
Railroads: 1,216 km, meter gage (1.00 m), single track
Highways: 6,763 km total; 1,934 km paved; 4,829 km
crushed stone, gravel, and laterite; remainder earth roads
and tracks (est.)
Inland waterways: Lake Victoria, Lake Albert, Lake
Kyoga, Lake George, and Lake Edward (9,670 km); Kagera
River and Victoria Nile (610 km)
Civil air: 5 major transport aircraft (including | leased in)
Airfields: 49 total, 48 usable; 5 with permanent-surface
runways; l with runway over 3,660 m, 3 with runways
2,440-3,659 m, 12 with runways 1,220-2,439 m
Telecommunications: fair system based on open wire
lines and low-capacity radio relay links; 46,000 telephones
(0.4 per 100 popl.); 6 AM, no FM, 6 TV stations; 1 Atlantic
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, about 2,763,000; about
1,485,000. fit for military service
US.S.R.
LAND
22,274,000 km?*; 9.3% cultivated, 37.1% forest and brush,
2.6% urban, industrial, and transportation, 16.8% pasture
and natural hay land, 34.2% desert, swamp, or waste
Land boundaries: 20,619 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 46,670 km (incl. Sakhalin)
Railroads: 139,805 km total; 137,972 km broad gage
(1.524 m); 1,833 km narrow gage (mostly 0.750 m); 109,316
km broad gage single track; 40,399 km electrified; does not
include industrial lines (1977)
Highways; 1,564,000 km total; 322,000 km asphalt.
concrete, stone block; 372,000 km asphalt treated, gravel,
crushed stone; 870,000 km earth (1976)
Inland waterways: 146,400 km navigable, exclusive of
Caspian Sea (1978)
Pipelines: 56,500 km crude oil; 13,000 km refined
products; 115,000 km natural gas
Arkhangel''sk, Riga, Tallinn, Kaliningrad, Liepaja, Ventspils,
Nikolayey, Sevastopol); 116 selected minor (1978)
Freight carried: rail—3,705 million metric tons, 3,330.0
billion metric ton/km (1977); highways—29.] billion metric
tons, 360.0 billion metric ton/km (1976); waterway—520.0
million metric tons, 231.0 billion metric ton/km, excluding
Caspian Sea in approximately 16,000 waterway craft with
8,000,000 metric tons capacity (1977)','082abf24a26a7a6da17a85963329b9a9d0ed404f2089980d6411905e3909ff11','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b491bf139b4d877a5300da0a562831eb6ec23e54616db7843fab6a9f3c7c051a',1978,'AE','United Arab Emirates','communications',546,'(See reference map V}
LAND
82,880 km’; almost all desert, waste or urban
Land boundaries: 1,094 km (does not include boundaries
between adjacent U.A.E. states)
WATER
Limits of territorial waters (claimed): 3 nm for all states
except Sharjah (12 nm)
Coastline: 1,448 km
0010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A00090
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
UNITED ARAB EMIRATES/UNITED KINGDOM
Railroads: none
Highways: 780 km bituminous, undetermined mileage of
earth tracks
Pipelines: 282 km crude oil
Ports: 3 major, 1 minor
Civil air: 13 major transport aircraft (including 4 leased
in)
Airfields: 57 total, 41 usable; 12 with permanent-surface
runways; 3 with runways over 3,660 m, 1 with runway
2,440-3,659 m, 20 with runways 1,220-2,489 m
Telecommunications: system is adequate; key centers are
Abu Dhabi and Dubai; 70,800 telephones (10.8 per 100
popl.); 4 AM, 2 FM, and 3 TV stations; 2 COMSAT ground
stations
DEFENSE FORCES
Military manpower: males 15-49, 180,000; 90,000 fit for
military service','98327ee5308d108532d79d917c38166f39ced966594d1e454414a45ac0b9508d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caaff23c7297627d5e8b2fd7e3af8e7b134adc067e5e4c10b299192cd2cade82',1978,'GB','United Kingdom','communications',550,'§
a
i
i ala
a din) ae
x
Atlantic
Ocean
(See reference map IV)
LAND
248,978 km?*; 30% arable, 50% meadow and pasture, 12%
waste or urban, 7% forested, 1% inland water
Land boundaries: 360 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 12,429 km
211
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Railroads: Great Britain—18,287 km total; British Rail-
ways (BR) operates 18,012 km standard gage (1.435 m)
(3,735 km electrified, 11,410 km double track, 2,366 km
multiple track) and 19 km 0.597-meter gage; 256 km of
standard gage (1.435 m) and several narrow gages are
privately owned; Northern Ireland Railways (NIR) operates
327 km 1.600-meter gage, 190 km double track
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
UNITED KINGDOM/UPPER VOLTA
Highways: approx. 343,315 km paved and 23,175 km in
Northern Ireland, 22,227 km paved; 949 km gravel
Inland waterways: 1,770 km of commercial routes
Pipelines: 933 km crude oil, almost all insignificant; 2,907
km refined products; 1,770 km natural gas
Ports: 23 major, 350 minor
Civil air: 506 major transport aircraft (including 4 leased
in and 17 leased out)
Telecommunications: modern, efficient domestic and
international system; 22.4 million telephones (39.4 per 100
popl.); excellent countrywide broadcast; 97 AM, 120 FM,
and 300 TV stations; 42 submarine cables; 1 earth satellite
station with 2 Atlantic Ocean antennas and 1 Indian Ocean
antenna
DEFENSE FORCES
Military manpower: males 15-49, 12,715,000; 10,738,000
fit for military service; no conscription; 448,000 reach
military age (18) annually
Military budget: proposed for fiscal year ending 31
March 1979, $13,353.7 million; about 15% of central
government budget
UPPER VOLTA
Atlantic
Ocean
(See reference map vi)
LAND
274,540 km*; 50% pastureland, 21% fallow, 10% culti-
vated, 9% forest and scrub, 10% waste and other uses
Land boundaries: 3,307 km
Railroads: 1,173 km, 516 km meter gage (1.00 m), single
track; Ouagadougou to Abidjan, Ivory Coast line
Highways: approximately 16,320 km total; 520 km paved,
3,600 km improved, 12,200 km unimproved
Civil air: no major transport aircraft
Airfields: 55 total, 54 usable; 2 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 3 with runways
1,220-2,4389 m
Telecommunications: all services generally poor; 3,400
telephones (0.1 per 100 popl.); 3 AM stations, 1 FM station,
and 1 TV station; 1 Atlantic Ocean Comsat station
DEFENSE FORCES
Military manpower: males 15-49, 1,478,000: 739,000- fit
for military service; no conscription
Supply: mainly dependent on France
Military budget: for fiscal year ending 81 December
1976, $18,243,900; 19.7% of central government budget','0657ab624786dbe1743d70b748135a25b784563c4c40392063216992faeee91e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82c689765c07df29041c8825848c5ad46c2784d5777af79443c79850f43bdc63',1978,'UY','Uruguay','communications',554,'LAND
186,998 km?*; 84% agricultural land (73% pasture, 11%
cropland), 16% forest, urban, waste and other
Land boundaries: 1,352 km
WATER
Limits of territorial waters (claimed): 200 nm (fishing
200 nm)
Coastline: 660 km
214
Atlantic
Ocean
Montevideo
(See reference map IV}
Railroads: 2,795 km, all standard gage (1.435 m) and
government owned
Highways: 15,700 km total; 10,000 km paved, 2,700 km
gravel, 3,000 km improved earth
Approved For Release 2005/04/22
Inland waterways: 1,600 km; used by coastal and
shallow-draft river craft
Freight carried: highways 80% of total cargo traffic, rail
15%, waterways 5%
Ports: 4 major (Montevideo, Colonia, Fray Bentos,
Paysandu), 6 minor
Civil air: 10 major transport aircraft
Airfields: 101 total, 63 usable; 10 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 11 with runways
1,220-2,489 m; 2 seaplane stations
Telecommunications: most modern facilities concen-
trated in Montevideo; 258,000 telephones (9.0 per 100 popl.);
85 AM, 3 FM, and 27 TV stations; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 672,000; 542,000 fit for
military service; no conscription
Military budget: proposed for fiscal year ending 31
December 1977, $79.9 million; 17.3% of central government
budget
VATICAN CITY
Mediterranean
Sea
(See reference map IV}
LAND
0.438 km?
Land boundaries: 38 km
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 3 AM stations and 2 FM stations.
2,000-line automatic telephone exchange
DEFENSE FORCES
Defense. is responsibility of Italy
VENEZUELA
at
Atlantic
“ Oeean
(See reference map II!)
LAND
911,680 km?; 4% cropland, 18% pasture, 21% forest, 57%
urban, waste, and other
Land boundaries: 4,181 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 2,800 km
Railroads: 373 km standard gage (1.435 m) all single
track; 171 km government owned, 202 km privately owned
Highways: 58,600 km total; 21,200 km paved, 22,800 km
gravel, 14,600 km improved earth
Inland waterways: 7,100 km; Orinoco River and Lake
Maracaibo accept oceangoing vessels
Pipelines: 6,110 km crude oil; 400 km refined products;
2,495 km natural gas
Ports: 6 major, 17 minor
Civil air: 70 major transport aircraft (including 4 leased
in)
Airfields: 292 total, 261 usable; 110 with permanent-sur-
face runways; 9 with runways 2,440-3,659 m, 76 with
runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: modern expanding telecom system;
satellite ground station; 649,000 telephones (5.3 per 100
popl.); 157 AM, 50 FM, and 43 TV stations; 2 submarine
cables; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,707,000; 1,911,000 fit
for military service; 188,000 reach military age (18) annually
Military budget: proposed for fiscal year ending 31
December 1978, $614.3 million; about 5.9% of central
government budget
217
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
VIETNAM
VIETNAM
LAND
829,707 km?; 14% cultivated, 50% forested, 36% urban
inland water, and other
Land boundaries: 4,562 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 3,444 km (excluding islands)
Highways: 41,190 km total; 5,471 km bituminous, 27,030
km gravel or improved earth, 8,690 km unimproved earth
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
VIETNAM/WALLIS AND FUTUNA/WESTERN SAHARA
Inland waterways: about 17,072 km navigable; more than
5,149 km navigable at all times by vessels up to 1.8-m draft
Ports: 9 major, 23 minor
Civil air: military controlled
Airfields: 172 total, 139 usable; 59 with permanent-
surface runways; 8 with runways 2,440-3,659 m, 18 with
runways 1,220-2,439 m; 2 seaplane stations
DEFENSE FORCES
Supply: dependent on the U.S.S.R., Eastern European
Communist countries, and the PRC for virtually all new
equipment; produces negligible quantities of infantry
weapons, ammunition and _ explosive devices (Vietnam
possesses a huge inventory of U.S.-manufactured weapons
and equipment captured from the RVN)
Military budget: no expenditure estimates are available;
military aid from the U.SS.R. and PRC has been so
extensive that actual allocation of Vietnam’s domestic
resources to defense has not been indicative of total military
effort
NOTE: VN figures preliminary','aeeb286364fc509bda64d1feec6ad44c5cd3cc70e873e704b9efa1a96af40d06','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0236554a4e858a7c60fcc279211c7e6fbb8e6eee8a287cbd98a2460a560637b',1978,'WF','Wallis and Futuna','communications',558,'PAPUA»
| Wen
Ae a
Coral ‘ oy:
Sea Fildes
NEW
“CALEDONIA Pen
Pacifie Qcean
NEW
LAND
(See reference map Vill}
LAND
About 207 km?
WATER
Limits of territorial waters: 12 nm
Coastline: about 129 km
Highways: 100 km of improved road on Uvea Island
(1972)
Ports: 2 minor
Airfields: 2 total, 2 usable; 1 with runway 1,220-2,439 m
Telecommunications: 85 telephones (0.9 per 100 popl.)
DEFENSE
No formal defense structure; no regular Armed Forces','6f5036bf56053cf7fd746d9830ee0fb8db506436eee6faabfe00f9d6cfd8ba6d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed0c953339495c9921f8323c168acb6b8a6c6553c74257bef648ccbc330256b5',1978,'EH','Western Sahara','communications',562,'(formerly Spanish Sahara)
Atlantic Ocean
®
CANARY
ISLANDS ,
t, 2
WESTERN
SAHARA
(See reference map VI}
LAND
266,770 km*, nearly all desert
Land boundaries: 2,086 km
219
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
WESTERN SAHARA/WESTERN SAMOA
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 1,110 km
Railroads: none
Highways: 6,100 km total; 500 km bituminous treated,
5,600 km unimproved earth roads and tracks
220
Ports: 2 major (El Aaiun, Villa Cisneros), 2. minor
Civil air: no major transport aircraft
Airfields: 12 total, 11 usable; 3 with permanent-surface
runways; 1 with runway over 3,660 m; 5 with runways
1,220-2,439 m
Telecommunications: telephone and telegraph poor:
1,000 telephones (0.7 per 100 popl.); 2 AM, no FM, 5 TV
stations
WESTERN SAMOA
eo, WESTERN
° SAMOA
(See reference map Vi)
LAND
2,849 km?; comprised of 2 large islands of Savai’''i and
Upolu and several smaller islands, including Manono and
Apolima; 65% forested, 24% cultivated, 11% industry, waste,
or urban
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 403 km
Railroads: none
Highways: 784 km total; 375 km bituminous, remainder
mostly gravel, crushed stone, or earth
Inland waterways: none
Ports: 1 principal (Apia), 1 minor
Approved For Release 2005/04/22
Civil air: 2 major transport aircraft
Airfields: 4 total, all usable; 1 with permanent-surface
runway 1,220-2,439 m
Tclecommunications: 3,300 telephones (2.2 per 100
popl.); 20,000 radio receivers, 2 AM_ stations
YEMEN (ADEN)
Arabian
Sea
Indian
Ocean
(See reference map Vj
LAND
287,490 km2; (border with Saudi Arabia undefined); only
about 1% arable (of which less than 25% cultivated)
Land boundaries: 1,802 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 1,383 km
Railroads: none
Highways: 5,311 km total; 322 km bituminous treated,
290 km crushed stone and gravel, 4,699 km motorable track
Ports: 1 major (Aden)
Pipelines: refined products, 32 km
Civil air: 7 major transport aircraft
222
Airfields: 94 total, 56 usable; 4 with permanent-surface
runways; 4 with runways 2,440-3,659 m, 3] with runways
1,220-2,439 m
Telecommunications: small system of open-wire line,
multiconductor cable, and radiocommunications stations;
only center Aden; 9,900 telephones (0.6 per 100 popl.); |
AM, no FM and 8 TV stations; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 422,000; 233,000 fit for
military service
Military budget: for fiscal year ending 31 December
1978, $58,000,000; about 16% of central government budget
YEMEN (SANA)
Indian
Ocean
{See reference map V)
LAND
194,250 km? (parts of border with Saudi Arabia and
Southern Yemen undefined); 20% agricultural, 1% forested,
79% desert, waste, or urban
Land boundaries: 1,528 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone”)
Coastline: 523 km
Railroads; none
Highways: 3,477 km total; 467 km bituminous; 485 km
crushed stone and gravel; 2,575 km earth, sand, and light
gravel
Ports: 1 major (Al Hudaydah), 2 minor
Civil air: 14 major transport aircraft (including 2 leased
in)
Airfields: 27 total, 15 usable; 4 with permanent-surface
runways; 4 with runways 2,440-3,659 m, 5 with runways
1,220-2,489 m
Telecommunications: system inadequate; consists of
meager open-wire lines and low-power radiocommunication
stations; principal center Sana, secondary centers Al
Hudaydah and Taizz; 4,600 telephones (0.1 per 100 popl.); 2
AM stations, no FM, 1 TV station; 1 Indian Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 1,622,000; 895,000 fit
for military service; about 72,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 June 1975,
$50,402,000; 54.6% of central government budget
YUGOSLAVIA
Belgrade,
(See reference map Hl)
LAND
255,892 km?; 32% arable, 25% meadows and pastures, 34%
forested, 9% other
Land boundaries: 3,001 km
223
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
YUGOSLAVIA
WATER
Limits of territorial waters (claimed): 10 nm (fishing 12
nm)
Coastline: 1,521 km (mainland), plus 2,414 km (offshore
islands)
Railroads: 9,967 km_ total; 9,619 km standard gage
(1.485 m), 348 km narrow gage; 793 double track; 2,649 km
electrified (1976)
ae Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
YUGOSLAVIA/ZAIRE
Highways: 101,607 km total; 41,018 km asphalt, concrete,
stone block; 35,980 km asphalt treated, gravel, crushed stone;
24,609 km earth (1976)
Inland waterways: 2,001 km (1977)
Freight carried: rail—73.7 million metric tons, 21.0
billion metric ton/km (1976); highway—84.1 million metric
tons, 11.2 billion metric ton/km (1976); waterway—29.0
million metric tons, 7.7 billion metric ton/km (incl. int''l.
transit traffic) in approximately 1,225 waterway craft with
703,600 metric ton capacity
Pipelines: 623 km crude oil; 1,860 km natural gas
Ports: 9 major (most important: Rijeka, Split, Koper, Bar,
and Ploce), 24 minor (1978)
DEFENSE FORCES
Military budget (announced): for fiscal year ending 31
December 1978, 42.7 billion dinars; about 4.7% of Gross
Social Product (Yugoslavia’s measure of production)
ZAIRE
Atlantic
Ocean
(See reference map V}
LAND
2,343,950 km?; 22% agricultural land (1% cultivated), 45%
forested, 33% other
Land boundaries: 9,902 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 37 km
Railroads: 5,149 km total; 3,870 km 1,067-meter gage
(851 km electrified), 126 km meter gage (1.00 m); 186 km
0.610-meter gage, 1,017 km 0.600-meter gage
Highways: 145,000 km total; 2,000 km bituminous,
66,000 km improved earth; 77,000 km unimproved
Inland waterways: comprising the Zaire, its tributaries,
and unconnected lakes, the waterway system affords over
15,000 km of navigable routes
Ports: 2 major (Matadi, Boma), 1 minor
Pipelines: refined products, 740 km
Civil air: 48 major transport aircraft
Airfields: 337 total, 281 usable; 23 with permanent-sur-
face runways; 2 with runways over 3,660 m, 2 with runways
2,440-3,659 m, 61 with runways 1,220-2,439 m
Telecommunications: limited, barely adequate telephone
service, telegraph service good; 28,000 telephones (0.1 per
100 popl.); 12 AM, 1 FM, and 2 TV stations; | Atlantic
Ocean satellite station; domestic Comsat network
DEFENSE FORCES
Military manpower: males 15-49, 6,291,000; 3,149,000 fit
for military service','c88656952cabf90e399472fdc5e1dd040767dc947996d690be25f05d8c07729f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e304227537f9082ad99ef3aab6adc1beb10c6bd47c975bf4c1916f4a9e471caf',1978,'ZM','Zambia','communications',566,'LAND
745,920 km?; 5% under cultivation, 5% arable, 10%
grazing, 13% dense forest, 6% marsh, 61% scattered trees and
grassland
Land boundaries: 6,003 km','4cb636808554cf767e740c5d7fc6328e65a16e232f704f7a7133fcd4e255984f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd8caada09928e10d6440319ed400f68603065db5f399ab52dbb103bae2a85fe',1978,'US','United States','communications',568,'This “Factsheet” on the U.S. is provided solely as a service
to those wishing to make rough comparisons of foreign
country data with a U.S. “yardstick.” Information is from
U.S. open sources and publications and in no sense represents
estimates by the U.S. intelligence community.
LAND
9,363,396 km? (contiguous U.S. plus Alaska and Hawaii);
19% cultivated, 27% grazing and pasture, 32% forested, 22%
waste, urban, and other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 19,924 km
Railroads: 277,686 km (1973)
Highways: 6,059,200 km (1972)
Inland waterways: 40,416 km of navigable inland
channels, exclusive of the Great Lakes: freight carried 951
million short tons (1970)
Pipelines: petroleum, 279,966 km (1972)
Ports: 25 major
Merchant marine: 600 ships (1,000 GRT or over) totaling
9,982,730 GRT, 14,722,666 DWT; includes 3 passenger, 5
short-sea passenger, 163 cargo, 119 container, 14 roll-on/
roll-off cargo, 234 tanker, 1 liquefied gas, 17 bulk, 2
combination ore/oil, 23 LASH Seebee and barge carriers, 19
specialized carriers; in addition there are 178 ships in reserve
fleet
Civil air: 2,716 major transport aircraft (1976)
Airfields: 15,257 (1976)
Telecommunications: 155 million telephones (7.8 tele-
phones per 100 popl.); 4,500 AM, 3,600 FM, and 985 TV
broadcast stations; 436 million radio and 133 million TV
receivers (1977)
DEFENSE FORCES
Personnel: army 1,133,000, navy and marines 1,029,000,
air force 827,000 (1976)
Military budget: $100.1 billion (1977)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
I Canada
&
Ellesmere
= %
cr. id
island s\\
S abs is &
Ih Pay
RO
3
BS Greenland
‘ J ban OU ao (Denmark)
wy ENS panei oy p Thulens he
ZY Sth Ay Bg) Osha |
Fairbanks » Fe \\ wy “ in .
a Roos Dnt ad é
- < it ee yi 2S ce
oS ; pias : : } Ys * *
‘ i > Gp a
sc &
“ f : Ss WVictoriz {
.
iceq
ReyKjawvi
3
‘ c a i
{ ; 2 ek $
: : 3 Bear lake ; pa) ‘ \\
5
Yq ellowknife
et OL AERED
Churchill” \\
a n).a
© Edmonton
: °
ae oy i
Victoria } “Vancouver nti eas
rs & Calgary? — Saskatoon :
l. ee 5 f K :
goa Seattle . _
: > Lake VAG (
winnipeg) i
-Winnipeg” | EN eee : é ee sydney
i Se j & \\
: A i CrAriottetown
oFr con
sad 3
Regina,
ey, .
Na Salt Lake-City sl } Boston *\\.»
Milwaukee = as a
ia Now York ¢”
Chicago @_- é
Washington s ( . Atlantic Ocean
i cect ‘ Kansas City ® « C
: « St. Louis : x
Oklahoma City *
‘\\
\\
}
i
|
}
500 Kilometers
500 Miles
503772 7-78
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
II Middie America
7
Washington
ng, bee: Angales United States eS
. : vy
3 _ a
SR ts y
ose ee
‘ } ~ i {Dallas w
: ; : ial S oe
5, -
| ‘ ( ee ae | ee
’ ( 4 q
2 Rectan Pape OM \\
u STA fe New | Qrleans''e: i) eae \\
. é 4 pie aedne: a \\
\\ va Bored Ocean
my an " \\
q \\ a
: \\ i % : a
i % 1 H 4d ge
Pike Monterrey, ~ = Miami i “By
sc a (adi oi Mexico ie %
7 ‘ ‘ 2 Ce i. ,
es pMazatian i “s Weg Sy
Mexico \\ :
t i Havana, %s
\\
ay {Tampico : BP
; \\ Cienfuegos
»Guadalajara ¢ co
x s “ Puerto Rico vog:
\\ : Gaynan } “ae beaiyy pLOIMO- > tus) ae :
a * maxico \\y : / ape . °S. Naval fase Haiti Rep. coy te
M e¥eracru ” wales Port-au:Prifics'' Sa cr fk
NL Be Pn) _ A Domingo
Acapulco pores Kingston
*
splize
a {f{ ariht
wim _aArinp oh ean 3s ¢€ a
j 5 & gd ¢ Honduras
oe boast aaa x Heine | N innds Antilles
San Salvador™
4 Ei ny Soe MY
: = ;, aon El Salvador rae Port-of- Spain spumiiiad
| @! ne ‘and Tebage
Managua* ! ; \\ eB , ste
Pe : Caracas ;
‘ p 2 ( : \\
Costa/Rica \\ fA | 5 me
} .
San’ Jose Cs (U.S. WS) eve anama
ie Pana SS Venezuela fauyana
ee ON
\\ :
\\ Bogota
p Colombia
i?) 100 Boe Kilometers ( ‘
<I \\
; 400 800 Miles ¢ Brazil
Boundary representation 1s “
not necessarily authoritative \\Ecuador
503773 7-78
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIARDP 720 10S 1 ANNI 2008
Jamaica-->
Handuras
ie .
Caribbean Sea Barbados
Nickraguia S38
; - ae . 5
‘ Panama p ia, as eo, ini
Banal zane arranquilla, sgt coos inidad and Tohage
(US. juris.) }
o Grenada
Venezuela >» ¢
i) Georgetown
Paramaribo
«Medeitin Guyanay-~s
yBagota','447a60514e4f4d32e082bb16013895b1d853c11e4ffd7be546f9f6a6ef5ed648','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

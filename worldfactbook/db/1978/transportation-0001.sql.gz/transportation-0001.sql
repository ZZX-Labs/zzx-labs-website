SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da60f7cae83fbe388c9d53679f0e827c0fd5e55137bd5615cff3b0e550349637',1978,'NZ','New Zealand','transportation',384,'Pipelines: natural gas, 785 km
Ports: 3 major
Civil air: about 50 major transport aircraft
Airfields: 193 total, 184 usable: 23 with permanent-sur-
face runways; 2 with runways 2,440-3,659 m, 50 with
runways 1,220-2,489 m; 5 seaplane stations
Telecommunications: excellent international and domes-
tic systems; 1,570,000 telephones; 2,700,000 radio and
799,000 TV sets; 60 AM stations in 31 cities, no FM, 9 TV
stations, and 129 repeaters; submarine cables extend to
Australia and Fiji Islands; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 744,000; 629,000 fit for
military service; average number reaching military age (20)
annually about 29,000
Military budget: proposed for fiscal year ending 31
March 1978, $230.1 million; about 3.7% of central govern-
ment budget','0e73abd22948ad60cc2898f49d5e0e6ce9e2ff59d8f662e2ae34788e09ef1e0b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82b605234905781e35ace9063202a882c25f92e35c8b788b9592fd23fc21c27e',1978,'NI','Nicaragua','transportation',385,'Pacific Ocean
(See reference map tt)
LAND
147,900 km*, 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other
Land boundaries: 1,220 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 200
nm; continental shelf, including sovereignty over superjacent
waters)
Coastline: 910 km','6056fd68acfbc4f1b1d95545d56fe17e4db8b3f4457ff5b384a3c976ce087019','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64068e3257ea8f85c985e01b939d03d06c876c75fb1bb9bee740cbabeceaf8f3',1978,'NZ','New Zealand','transportation',405,'Pipelines: natural gas, 785 km
Ports: 3 major
Civil air: about 50 major transport aircraft
Airfields: 198 total, 184 usable; 23 with permanent-sur-
face runways; 2 with runways 2,440-3,659 m, 50 with
runways 1,220-2,489 m; 5 seaplane stations
Telecommunications: excellent international and domes-
tic systems; 1,570,000 telephones (52 per 100 popl.); 60 AM
stations in 31 cities, no FM, 11 TV stations, and 129
repeaters; submarine cables extend to Australia and Fiji
Islands; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 744,000; 629,000 fit for
military service; average number reaching military age (20)
annually about 29,000
Military budget: proposed for fiscal year ending 31
March 1978, $230.1 million; about 3.7% of central govern-
ment budget','30843815c0d8a6b745d7f9b009625aaaee0b66161442ebd90b469ee73776069a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bee7ba0246a143ed8da118797e05945c3241aefbbba348ee454ee209128e17d',1978,'NI','Nicaragua','transportation',406,'LAND
147,900 km?; 7% arable, 7% prairie and pasture, 50%
forest, 36% urban, waste, or other
149
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Caribbean Sea
Pacific Qcean
(See reference map H)
Land boundaries: 1,220 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 200
nm; continental shelf, including sovereignty over superjacent
waters)
Coastline: 910 km','1b9b477d791da7eb9d6726d800044391f490cada89ac8412f276f01eb353136b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

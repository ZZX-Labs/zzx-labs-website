SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30f6d7540f0e228d19c467efa58626ef1f4eb2833748b3fe9288408ec2502923',1978,'AF','Afghanistan','government',9,'Legal name: Republic of Afghanistan
Type: republic
Capital: Kabul
Political subdivisions: 26 provinces with centrally ap-
pointed governors
Legal system: based on Islamic law; constitution adopted
February 1977; semi-independent judiciary; legal education
at University of Kabul; has not accepted compulsory IC]
jurisdiction
National holiday: Republic Day, 17 July
Branches: executive dominant; legislature is to begin
functioning in November 1979; judiciary consists of High
Judicial Council (to begin functioning in June 1978) and
lower courts. Party of National Revolution has some
government functions.
Government leaders: President Mohammad Daoud;
Mohammad Naim, Daoud’s brother and personal adviser
Suffrage: universal from age 18
Elections: before November 1979
Political parties and leaders: Party of National Revolu-
tion, only legal party under constitution, is in process of
formation
Communists; Khalq, a pro-Moscow party, believed to
have several hundred members, and Sholaye-Jaweid, a
smaller pro-Peking group
Other political or pressure groups: most military officers
support the government; no known organized opposition
Member of: ADB, Colombo Plan, FAO, G-77, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, NAM, U.N.,
UNESCO, UPU, WHO, WMO, WSG','ffc8919e94b762cee37b71bd6754ccacb099a561d01cab2f0a1d1a60500fe61a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ac34a3893d02adefa3c2935c911cf33982b1a1e84acef9fb995e89d02fe87c9',1978,'AL','Albania','government',14,'Legal name: Peoples Socialist Republic of Albania
Type: Communist state
Capital: Tirané
Political subdivisions: 27 rethet (districts), including
capital, 200 localities, 2,600 villages
Legal system: based on constitution adopted in 1976;
judicial review of legislative acts only in the Presidium of the
People’s Assembly, which is not a true court; legal education
at State University of Tirané; has not accepted compulsory
IC] jurisdiction
National holiday: Liberation Day, 29 November
Branches: People’s Assembly, Council of Ministers,
judiciary
Government leaders: Chairman of Council of Ministers,
Mehmet Shehu; Chairman Presidium of the People’s
Assembly, Haxhi Lleshi (Chief of State)
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held every 4
years; last elections 6 October 1974; 99.9% of electorate
voted
Political parties and leaders: Albanian Workers Party
only; First Secretary, Enver Hoxha
Communists: 101,500 party members (November 1976)
Member of: CEMA, IAEA, IPU, ITU, U.N., UNESCO,
UPU, WFTU, WHO, WMO; has not participated in CEMA
since rift with U.S.S.R. in 1961; officially withdrew from
Warsaw Pact 13 September 1968
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ALBANIA/ALGERIA','c23a8f2a4751250fa4e8dc2ace143f9cd61c1f5f594bcb5f197b69710ef64880','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb4320d56d11152f16119af29bc2eb2132d6f6c03b71d149ef0970f0fcd3e650',1978,'DZ','Algeria','government',18,'Legal name: Democratic and Popular Republic of Algeria
Type: republic
Capital: Algiers
Political subdivisions: 31 Wilayas (departments or
provinces)
Legal system: based on French and Islamic law, with
socialist principles; new constitution adopted by referendum
November 1976; judicial review of legislative acts in ad hoc
Constitutional Council composed of various public officials,
including several Supreme Court justices, Supreme Court
divided into 4 chambers; legal education at Universities of
Algiers, Oran and Constantine; has not accepted compulsory
ICJ jurisdiction
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ALGERIA/ANDORRA
National holiday: 1 November
Branches: executive dominant; unicameral legislature
reconvened in March 1977; judiciary
Government leader: Houari Boumediene, President of
State and President of Council of the Revolution, overthrew
elected President Ahmed Ben Bella June 19, 1965
Suffrage: universal over age 19
Elections (latest): presidential December 10, 1976;
departmental assemblies June 2, 1974; local assemblies
March 30, 1975; legislative elections held February 25, 1977
Political parties and leaders: National Liberation Front
(FLN)
Communists: 400 (est.); Communist Party illegal (banned
1962)
Member of: AFDB, AIOEC , Arab League, ASSIMER,
FAO, G-77, GATT (de facto), IAEA, IBRD, ICAO, IDA,
ILO, International Lead and Zinc Study Group, IMCO,
IMF, IOOC, ITU, NAM, OAPEC, OAU, OPEC, U.N.,
UNESCO, UPU, WHO, WIPO, WMO','f3e622892820a884133ed3bba8d24a91172dd398363764eb67c0d2a9d430115e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('660098f664d49056acf58f76bca32d2b736cb74c9660a8034531d192ccbf9bf2',1978,'AD','Andorra','government',22,'Legal name: The Valleys of Andorra
Type: unique coprincipality under formal sovereignty of
President of France and Spanish Bishop of Seo de Urgel,
who are represented locally by officials called verguers
4 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ANDORRA/ANGOLA
Capital: Andorra
Political subdivisions: 6 districts—Andorra la Vella, Saint
Julia de Loria, Encamp, Canillo, La Massana, and Ordino
Legal system: based on French and Spanish civil codes;
Plan of Reform adopted 1866 serves as constitution; no
judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Branches: legislature (General Council) of 24 members
with one-half elected every 2 years for 4-year term;
executive—syndic and a deputy sub-syndic chosen by
General Council for 3-year terms; judiciary chosen by
coprinces who appoint 2 civil judges, a judge of appeals, and
2 Batles (court prosecutors)
Suffrage: males of 21 or over who are third generation
Andorrans vote for General Council members; same right
granted to women in April 1970
Elections: half of General Council chosen every 2 years,
last election December 1977
Political parties and leaders: traditionally no political
parties but only partisans for particular independent
candidates for the General Council, on the basis of
competence, personality and orientation toward Spain or
France; various small pressure groups developed in 1972;
first formal political party—Andorran Democratic Associ-
ation—formed in November 1976
Communists: negligible','dba7e6cc565d2d4c2645626b7eb2f72a453ac1016b4a0ae3c6323c983427398e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bf1e4123cce48beec3a71413a740af625bf32d1e37baf98dc72c9fc00bdc1b3',1978,'AO','Angola','government',26,'Legal name: Peoples Republic of Angola
Type: republic; achieved independence from Portugal in
November 1975; constitution promulgated 1975; govern-
ment formed after civil war which ended in early 1976
Capital: Luanda
Political subdivisions: 16 administrative districts includ-
ing the coastal exclave of Cabinda
Legal system: to be determined
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4 5
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ANGOLA/ANTIGUA
National holiday: Independence Day, 11 November
Branches: the official party is the supreme political
institution
Government leaders: Agostinho Neto, President
Suffrage: to be determined
Elections: none held to date
Political parties and leaders: Popular Movement for the
Liberation of Angola (MPLA), led by Agostinho Neto, only
legal party; National Front for the Liberation of Angola
(FNLA) and National Union for the Total Independence of
Angola (UNITA), defeated in civil war, carrying out limited
insurgencies
Member of: G-77, NAM, U.N.
Monetary conversion rate: (still using Portuguese cur-
rency) 38,732 escudos=US$1 as of June 1977
Fiscal year: calendar year
Legal name: State of Antigua
Type: dependent territory with full internal autonomy as
a British “Associated State”
Capital: St. Johns
Political subdivisions: 6 parishes, 2 dependencies (Bar-
buda, Redonda)
Legal system: based on English law; British Caribbean
Court of Appeal has exclusive original jurisdiction and an
appellate jurisdiction, consists of Chief Justice and 5 justices
Branches: legislative, 2l-member popularly elected
House of Representatives; executive, Prime Minister and
Cabinet
Government leaders: Premier Vere C. Bird, Sr.; Deputy
Premier Lester Bird; Governor Sir Wilfred Ebenezer Jacobs
Suffrage: universal suffrage age 18 and over
Elections: every 5 years; last general election 11 February
1976
Political parties and leaders: Antigua Labor Party
(ALP), Vere C. Bird, Sr., Lester Bird; Progressive Labor
Movement (PLM), George Herbert Walter; Antigua People’s
Party (APP), J. Rowan Henry
Voting strength: 1976 election—House of Representative
seats—ALP 10, PLM 5, independent 1, tie 1
Communists: negligible
Other political or pressure groups: Afro-Caribbean
Liberation Movement (ACLM), a small black nationalist
group led by Timothy Hector; Antigua Freedom Fighters
(AFF), a small black radical group, leaders unknown
Member of: CARICOM, ISO','21753df3477260cbee6186e855f09813188126d1e0569f276e4d3fa1d3f29dcd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1014bb962d15732c68787320ea404c9212f23128d5f74b309cf6d7c5489cb23a',1978,'AR','Argentina','government',30,'Legal name: Argentine Republic
Type: republic
Capital: Buenos Aires
Political subdivisions: 22 provinces, 1 district (Federal
Capital), and 1 territory
Legal system: based on Spanish and French civil codes;
constitution adopted 1853 partially superseded in 1966 by
the Statute of the Revolution which takes precedence over
the constitution when the two are in conflict, further
changes may be made by new government; judicial review
of legislative acts; legal education at University of Buenos
Aires and other public and private universities; has not
accepted compulsory IC] jurisdiction
National holiday: Independence Day, 25 May
Branches: Presidency; legislature; national judiciary
Government leader: President, Lt. General Jorge Rafael
Videla, Commander in Chief of the Army, chosen by the
three-man junta that took power on March 24, 1976
Government structure: the junta, composed of the chiefs
of the three armed services, retains supreme authority;
active duty or retired officers fill all but two cabinet posts
and administer all provincial and many local governments;
in addition, the military now oversee the nation’s principal
labor confederation and unions, as well as other civilian
pressure groups; Congress has been disbanded and all
political activity suspended; a nine-man Legislative Council,
composed of senior officers, advises the junta on lawmaking
Political parties: a number of civilian political groupings
remain potentially influential, despite the suspension of all
“artisan activity; these include Justicialist Party (Peronist
coalition that formerly governed) and the Radical Civic
Union, center-left party providing the chief civilian
opposition to the Peronists; the Moscow-oriented Communist
Party remains legal, but extreme leftist splinter groups have
been outlawed
Communists: some 70,000 members in various party
organizations, including a small nucleus of activists
Other political or pressure groups: Peronist-dominated
labor movement, General Economic Confederation (Peron-
ist-leaning association of small businessmen), Argentine
Industrial Union (manufacturer’s association), Argentine
Rural Society (large landowner’s association), business
organizations, students, and the Catholic Church
Member of: FAO, G-77, GATT, IADB, IAEA, IBRD,
ICAC, ICAO, IDA, IDB, IFC, IHO, ILO, IMCO, IMF,
IOOC, ISO, ITU, IWC—International Whaling Commis-
sion, IWC—International Wheat Council, LAFTA, NAM,
OAS, SELA, U.N., UNESCO, UPU, WHO, WMO, WSG,
Non-Aligned Nations Group','1fe85c13eb72f2a4e43bde3a894ffc6c9628c12b0cfd3cf6b790d61ec30a39d4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa96bbc5b051b5aea099531118bf11c4fc359ba89c6ee41883f6752b4e8340e2',1978,'NZ','New Zealand','government',34,'Legal name: Commonwealth of Australia
Type: federal state recognizing Elizabeth II as sovereign
or head of state
Capital: Canberra
Political subdivisions: 6 states and 2 territories (Austra-
lian Capital Territory (Canberra) and Northern Territory)
Legal system: based on English common law; constitution
adopted 1900; High Court has jurisdiction over cases
involving interpretation of the constitution; accepts compul-
sory ICJ jurisdiction, with reservations
National holiday: 26 January
Branches: Parliament (House of Representatives and
Senate); Prime Minister and Cabinet responsible to House;
independent judiciary
Government leaders: Governor General Sir John Kerr;
Prime Minister John Malcolm Fraser
Suffrage: universal over age 18
Elections: held at 3-year intervals, or sooner if Parliament
is dissolved by Prime Minister; next election December 1977
Political parties and leaders: Government—Liberal
Party (Malcolm Fraser) and National Country Party
(Douglas Anthony); opposition—Labour Party (Gough
Whitlam)
Voting strength (1975 Parliamentary election): lower
house: Liberal-Country Coalition, 92 seats; Labour Party, 35
seats; Senate: Liberal Country Coalition, 35 seats; Labour, 27
seats; Independents, 2 seats
Communists: 3,900 members (est.)
Other political or pressure groups: Democratic Labour
Party (anti-Communist Labour Party splinter group)
Member of: ADB, AIOEC, ANZUS, CIPEC (associate),
Colombo Plan, Commonwealth, DAC, ELDO, ESCAP,
FAO, GATT, IAEA, IATP, IBA, IBRD, ICAC, ICAO, IDA,
IEA, IFC, IHO, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IOOC, IPU, Iso, ITC, ITU, IWC—
International Whaling Commission, IWC—International
Wheat Council, OECD, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG
Legal name: Dominion of New Zealand (rarely used)
Type: independent state within Commonwealth, recogniz-
ing Elizabeth II as head of state
Capital: Wellington
Political subdivisions: 112 counties
Legal system: based on English law, with special land
legislation and land courts for Maori tribesmen; constitution
consists of various documents, including certain acts of the
U.K. and New Zealand Parliaments; legal education at
Victoria, Auckland, Canterbury, and Otago Universities;
accepts compulsory IC] jurisdiction, with reservations
National holiday: Waitangi Day, 6 February
Branches: unicameral legislature (General Assembly,
commonly called Parliament); Cabinet responsible to Parlia-
ment; 3-level court system (Magistrates, Courts, Supreme
Court, and Court of Appeal)
Government leader: Prime Minister Robert D. Muldoon
Suffrage: universal age 18 and over
Elections: held at 3 year intervals or sooner if parliament
is dissolved by Prime Minister; last election November 1975
Political parties and leaders: National Party (Govern-
ment), Robert D. Muldoon; Labour Party (Opposition),
Wallace E. Rowling; Social Credit Political League, Bruce
Beetham; Communist Party, George Victor Wilcox; pro-So-
viet Socialist Unity Party, George Edward Jackson
Voting strength (1975 election): National Party 55 seats,
Labour Party 32 seats
Communists: CPNZ about 300, SUP about 100
Member of: ADB, ANZUS, ASPAC, Colombo Plan, DAC,
ESCAP, FAO, GATT, IAEA, IBRD, ICAO, IEA, IFC, THO,
ILO, IMCO, IMF, IPU, ISO, ITU, OECD, U.N., UNESCO,
UPU, WHO, WMO, WSG
151
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
NEW ZEALAND/NICARAGUA','4357c9a5ab9f19686cefa3fb0d34593c07df3fd50cb3e985fcdca4b04b8739c7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25169b5046ee5969a3c53b1e1dfb20dd2e7cef333da9076869c7ab5fa4ddaf28',1978,'AT','Austria','government',38,'Legal name: Republic of Austria
" Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (Laender) including the
capital
Legal system: civil law system with Roman law origin;
constitution adopted 1920, reprormulgated in 1945; judicial
review of legislative acts by a Constitutional Court; separate
administrative and civil/penal supreme courts; legal educa-
tion at Universities of Vienna, Graz, Innsbruck, Salzburg,
and Linz; has not accepted compulsory ICJ jurisdiction
National holiday: 26 October
Branches: bicameral parliament, directly elected Presi-
dent whose functions are largely representational, independ-
ent federal judiciary
Government leaders: President Rudolf Kirchschlaeger,
Chancellor Bruno Kreisky leads a one-party Socialist
Suffrage: universal over age 19; compulsory for presiden-
tial elections
Elections: presidential, every 6 years (next 1980);
parliamentary, every 4 years (next 1979)
Political parties and leaders: Socialist Party of Austria
(SPOe), Bruno Kreisky, Chairman; Austrian People’s Party
(OeVP), Josef Taus, Chairman; Liberal Party (FPOe),
Friedrich Peter, Chairman; Communist Party, Franz Muhri,
Chairman
Voting strength (1975 election): 50.6% SPOe, 42.7%
OeVP, 5.3% FPOe, 1.2% Communist
Communists: membership 25,000 est.; —_ activists
7,000-8,000
Other political or pressure groups: Federal Chamber of
Commerce and Industry; Austrian Trade Union Federation
(primarily Socialist); three composite leagues of the Austrian
Peoples Party (OeVP) representing business, labor, and
farmers; the OeVP-oriented League of Austrian Industrial-
ists; Roman Catholic Church, including its chief lay
organization, Catholic Action
Member of: ADB, Council of Europe, DAC, ECE, EFTA,
EMA, ESRO (observer), FAO, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IEA, IFC, ILO, International Lead and Zinc
Study Group, IMF, ITU, 1WC— International Wheat Coun-
cil, OECD, U.N., UNESCO, UPU, WHO, WIPO, WMO,
WSG
Legal name: The Commonwealth of The Bahamas
Type: independent commonwealth since July 1973,
recognizing Elizabeth II as Chief of State
Capital: Nassau (New Providence Island)
Legal system: based on English law
National holiday: Independence Day, 10 July
Branches: bicameral legislature (appointed Senate,
elected House); executive (Prime Minister and cabinet);
judiciary
Government leaders: Prime Minister Lynden O. Pindling
Suffrage: universal over age 18; registered voters (July
1977) 73,309
Elections: House of Assembly (19 July 1977); next
election due constitutionally in 5 years
Political parties and leaders: Progressive Liberal Party
(PLP), predominantly black, Lynden O. Pindling; Bahamian
Democratic Party (BDP), Henry Bostwick; Free National
Movement (FNM), Cecil Wallace-Whitfield
Voting strength (1977 election): PLP (55%) 30 seats, BDP
(27%) 6 seats, FNM (15%) 2 seats, others (8%) O seats
Communists: none known
Member of: G-77, ILO, IMCO, IMF, U.N., WHO, WIPO,
WMO','d5f30a48bef22647f67e90f5d673e23efc0e0ea06989f4db0ae29386001f1b9b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21efbff8dd5a5161141aea71c9b94785a9ad3f77062fe6a19857c77cfa95b414',1978,'BH','Bahrain','government',42,'Legal name: State of Bahrain
Type: traditional monarchy; independence declared in
1971
Capital: Manama
Legal system: based on Islamic law and English common
law; constitution went into effect December 1973
National holiday: 16 December
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Branches: Amir rules with help of a cabinet led by Prime
Minister; a National Assembly, made up of cabinet and 30
directly elected members, was formed in early 1974; Amir
dissolved assembly in August 1975 and suspended the
constitutional provision for election of the assembly
Government leader: Amir ‘Isa ibn Salman Al-Khalifah
Political parties and pressure groups: political parties
prohibited; no significant pressure groups although numer-
ous small clandestine groups are active
Communists: negligible
Member of: Arab League, FAO, G-77, GATT (de facto),
IBRD, ICAO, IMF, NAM, OAPEC, U.N., UNESCO, WHO','43ec08198c4917c8e77b28b2a824b892132f41eb46e260812b892e05a71b4a33','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be82ef83faaa82d27d54abfebd4fcf330b37c0fb8c19c84b877f7cd9d019d29f',1978,'BD','Bangladesh','government',46,'Legal name: Peoples Republic of Bangladesh
Type: independent republic since December 1971; Gov-
ernment of President Sheikh Mujibur Rahman overthrown
in August 1975; two other coups followed; country currently
governed by military-backed martial law administration
with military president and chief martial law administrator
and two military service chiefs as deputy martial law
administrators
Capital: Dacca
Political subdivisions: 19 districts, 413 thanas (counties),
4,053 unions (village groupings)
Legal system: based on English common law; constitution
adopted December 1972; amended January 1975 to more
authoritarian presidential system, changed by proclamation
in April 1977 to reflect Islamic character of nation
National holiday: Independence Day, 26 March
Branches: constitution provides for unicameral legisla-
ture, strong president; controlled judiciary; parliament
dissolved by current regime
Government leader: President Zair Rahman
Suffrage: universal over age 18
Elections: First Parliament (House of the Nation) elected
in March 1978; elections every 5 years; Government has
lifted previous ban on political activity and announced its
intention to hold national elections in December 1978:
current President given mandate to continue his rule in
nationwide referendum held in May 1977
Communists: 2,500 members (est.)
Other political or pressure groups: 15 political parties
legalized by government as of October 1976, student groups,
bands of former guerrillas
Member of: ADB, Afro-Asian People’s Solidarity Organi-
zation, Colombo Plan, Commonwealth, ESCAP, G-77,
GATT, IAEA, IBRD, ICAO, IDA, IMF, ILO, NAM, U.LN.,
UNCTAD, UNESCO, UPU, WHO','a4564151d125abe1070e4da7b930b83212033d19db1fc985ee1263aa1d95d494','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('118ac262066e50b873fdb29b1d41d3b73f7c8b957e12ea0ecfd1ae6ee046b4a0',1978,'BB','Barbados','government',50,'Legal name: Barbados
Type: independent sovereign state within the Common-
wealth since November 1966, recognizing Elizabeth II as
Chief of State
Capital: Bridgetown
Political subdivisions: 11 parishes and city of Bridgetown
Legal system: English common law; constitution came
into effect upon independence in 1966; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
National holiday: 30 November
Branches: legislature consisting of a 2l-member ap-
pointed Senate and a 24-member elected House of
Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister J. M. G. “Tom”
Adams
Suffrage: universal over age 18
Elections: House of Assembly members have terms no
longer than 5 years; last general election held 2 September
1976
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BARBADOS /BELGIUM
Political parties and leaders: Barbados Labor Party
(BLP), J. M. G. “Tom” Adams; Democratic Labor Party
(DLP), Errol Barrow
Voting strength (1976 election): Barbados Labor Party
(BLP), 58% Democratic Labor Party, 46%; Independent,
negligible; House of Assembly seats—BLP 17, DLP 7
Communists: negligible
Other political or pressure groups: People’s Progressive
Movement (PPM), a small black-nationalist group led by
Calvin Alleyne
Member of: CARICOM, Commonwealth, FAO, G-77,
GATT, IADB, IBRD, ICAO, IDB, ILO, IMCO, IMF, ISO,
ITU, TWC—International Wheat Council, OAS, SELA,
U.N., UNESCO, UPU, WHO, WMO','26f3d57b5d4eac850e8795697a9136d4b7f18e28cf85447e08829b609e20d91b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ba71e820ea1d2015b097ca24277d4848f14d20afc9018c802d3a080a03f078c',1978,'BE','Belgium','government',54,'Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil law system influenced by English
constitutional theory; constitution adopted 1831, since
amended; judicial review of legislative acts; legal education
at 4 law schools; accepts compulsory ICJ jurisdiction, with
reservations
National holiday: National Day, 21 July
Branches: executive branch consists of King and cabinet;
cabinet responsible to bicameral parliament, independent
judiciary; coalition governments are usual
Government leader: Head of State, King Baudouin;
Prime Minister Leo Tindemans
Suffrage: universal over age 21
Elections: held 17 April 1977 (held at least once every 4
years)
Political parties and leaders: Social Christian, Georges
Gramme and Wilfred Martens, co-presidents; Socialist,
Andre Cools and Willy Claes, co-presidents; Liberal, Pierre
Dechamps, national president; Brussels Liberal, Basile
Risopoulos, party president; Francophone Democratic Front,
Andre Lagasse, party president; Walloon Rally, Paul-Henri
Gendebien, party president; Volksunie (Flemish nationalist),
Hugo Schiltz, party president; Communist, Louis Van Gent,
president of political bureau
Voting strength (1977 election): 80 seats Social Christian,
62 seats Socialist, 31 seats Liberal, 20 seats Volksunie, 10
seats Francophone Democratic Front, 5 seats Walloon Rally,
2 seats Brussels Liberal, 2 seats Communist
Communists: 10,000 members (est.)
Other political or pressure groups: Christian and Socialist
Trade Unions; the Federation of Belgium Industries;
numerous other associations representing bankers, manufac-
turers, middle-class artisans, and the legal and medical
professions; two major organizations represent the cultural
interests of Flanders and Wallonia
Member of: ADB, Benelux, BLEU, Council of Europe,
DAC, EC, ECE, ECOSOC, ECSC, EEC, EIB, ELDO, EMA,
ESRO, EURATOM, FAO, GATT, IAEA, IBRD, ICAC,
ICAO, ICES, IDA, IEA, IFC, ILO, International Lead and
Zinc Study Group, IMCO, IMF, IOOC, IPU, ITC, ITU,
NATO, OAS (observer), OECD, U.N., UNESCO, UPU,
WEU, WHO, WIPO, WMO, WSG','1d5bd10bf0ebccb38caab030ded19089e5a8c3c7dc20d52f1b88b1edf2dfa677','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c16170b54bba7805877a8d8a1adbabeec42f5cf46788276aef45ad2bde5864e',1978,'BZ','Belize','government',58,'Legal name: Belize
Type: internal self-governing British colony
Capital: Belmopan
Legal system: English law; constitution came into force in
1964, although country remains a British colony
Branches: 18-member elected National Assembly and
8-member Senate (either house may choose its speaker or
president, respectively, from outside its elected member-
ship); cabinet; judiciary
Government leader: Premier George Price
Suffrage: universal adult (probably 21)
Elections: must be held within 5 years of last elections
held in October 1974
Political parties and leaders: People’s United Party
(PUP), George Price; United Democratic Party (UDP), a
coalition comprised of the National Independence Party
(NIP) led by Philip Goldson, the People’s Democratic Union
(PDM) led by Dean Lindo, and the Liberal Party (LP) led
by Harry Lawrence; Corozal United Front (CUF), San-
tiago Ricalde; United Black Association for Development
(UBAD), Evan X. Hyde
Voting strength (National Assembly): PUP 12 seats, UDP
6 seats
Communists: negligible
Other political or pressure groups: Christian Workers’
Union (CWU) which is connected with PUP
Member of: CARICOM, ISO','5e6a1f9ffe1977f485643df375d3c989dfbfa67d69d10243ad9f762726a41c36','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e801ddd8813d6c4298eff9893892286a890634f6d5982d5c3814157656542538',1978,'BJ','Benin','government',62,'Legal name: Peoples Republic of Benin
Type: party state, under military rule since 26 October
1972
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 provinces, 46 districts
Legal system: based on French civil Jaw and customary
law; legal education generally obtained in France; has not
accepted compulsory IC] jurisdiction
National holiday: 30 November
Branches: National Revolutionary Council, Council of
Ministers, Central Committee of Party
Government leader: Lt. Col. Mathieu Kerekou, President,
and Chief of State, Charged with National Defense
Suffrage: suspended
Elections: current government has held no elections and
none are scheduled
Political parties: People’s Revolutionary Party of Benin
established in 1975
Communists: sole party espouses Marxism-Leninism
Member of: AFDB, CEAO, EAMA, ECA, ECOWAS,
Entente, FAO, G-77, GATT, IBRD, ICAO, IDA, ILO, IMF,
ITU, NAM, Niger River Commission, OAU, OCAM, U.N.,
UNESCO, UPU, WHO, WIPO, WMO','3caab53a024a23dd411a1f40913f7ac53bd2478b4e44154ef71aba55f82e949c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1e6dcb81f387deee785ff56be61f7dd0931389c58c8df44e0093f53e7b40059',1978,'BM','Bermuda','government',66,'Legal name: Colony of Bermuda
Type: British colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English law
Branches: Executive Council (cabinet) appointed by
governor, led by government leader; bicameral legislature
with an appointed Legislative Council, and a 40-member
directly elected House of Assembly
Government leaders: Governor, Sir Peter Ramsbotham;
Premier, J. David Gibbons
Suffrage: universal over age 21
Elections: at least once every 5 years; last general
election, May 1976
Political parties and leaders: United Bermuda Party
(UBP), J. David Gibbons; Progressive Labor Party (PLP),
Lois Browne Evans
Voting strength (1976 elections): UBP 55.5%, PLP 44.4%;
House of Assembly seats—UBP 26%, PLP 14%
Communists: negligible
Other political or pressure groups: Bermuda Industrial
Union (BIU)
20 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BERMUDA/BHUTAN','a7c221182a57ed5dc5d783fac45a028b9b99a5cf99a0c99f9e721e48d3c3b1b2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a94ffab0271146d843f720f4faa24b47d9b9abc41a0a8f404583dc150a1e464',1978,'BT','Bhutan','government',70,'Legal name: Kingdom of Bhutan
Type: monarchy; special treaty relationship with India
Capital: Thimphu
Political subdivisions: 4 regions (east, central, west,
south), further divided into 15-18 subdivisions
Legal system: based on Indian law and English common
law; in 1964 the monarch assumed full power—no
constitution existed beforehand; a Supreme Court hears
appeals from district administrators; has not accepted
compulsory ICJ jurisdiction
National holiday: 17 December
Branches: appointed Minister and indirectly elected
Assembly consisting of village elders, monastic representa-
tives, and all district and senior government administrators
Government leader: King Jigme Singhi Wangchuk
Suffrage: each family has one vote
Elections: popular elections on village level held every 3
years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist clergy
Member of: Colombo Plan, G-77, NAM, UPU, U.N.
Legal name: Republic of Bolivia
Type: republic; de facto military dictatorship government
Capital: La Paz (seat of government); Sucre (judicial
capital)
Political subdivisions: 9 departments with limited
autonomy
Legal system: based on Spanish law and Code Napoleon;
constitution adopted 1967; constitution in force except
where contrary to dispositions dictated by governments since
1969; legal education at University of San Andres and
several others; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 6 August
Branches: executive; congress of two chambers (Senate
and Chamber of Deputies), congress disbanded after 26
September 1969 ouster of President Siles; judiciary
Government leaders: President Hugo Banzer Suarez
Suffrage: universal and compulsory at age 18 if married,
21 if single
Elections: postponed indefinitely
Political parties and leaders: political activities are
proscribed indefinitely; most party leaders are in exile
Voting strength (1966 elections): Frente de la Revolucion
Boliviana (a coalition composed of the MPC, PIR, PRA,
PSD, and two interest groups, the campesinos and Chaco
War Veterans) 61%, FSB 12%, MNR 10%, other 17%
Communists: three parties (all proscribed); PCB/Soviet
led by Jorge Kolle Cueto, about 300 members, PCB/Chinese
led by Oscar Zamora, 150 (including 100 in exile); POR
(Trotskyist), about 50 members divided between three
factions led by Hugo Gonzalez Moscoso, Guillermo Lora
Escobar, and Amadeo Arze
Member of: FAO, G-77, IAEA, IADB, IATP, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMF, ISO, ITC, ITU, WC—
International Wheat Council, LAFTA and Andean Sub-Re-
gional Group (created in May 1969 within LAFTA), OAS,
SELA, U.N., UNESCO, WHO, WMO','f4ce997ef2e802383b7f0a0f4c2b9c03aebab268351956aa90b5670ab93fc909','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de2822bab1a28576017a343628d280102da7d7a5ca9e1a07c6e22ab06fc41734',1978,'BW','Botswana','government',74,'Legal name: Republic of Botswana
Type: parliamentary republic; independent member of
Commonwealth since 1966
Capital: Gaborone
Political subdivisions: 12 administrative districts
Legal system: based on Roman-Dutch law and local
customary law; constitution came into effect 1966; judicial
review limited to matters of interpretation; legal education
at University of Botswana, Lesotho and Swaziland (24% years)
and University of Edinburgh (2 years); has not accepted
compulsory ICJ jurisdiction
23
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
BOTSWANA/BRAZIL
National holiday: 30 September
Branches: executive—President appoints and presides
over the cabinet which is responsible to Legislative
Assembly; legislative—Legislative Assembly with 32 popu-
larly elected members and 4 members elected by the 32
representatives, House of Chiefs with deliberative powers
only; judicial—local courts administer customary law, High
Court and subordinate courts have criminal jurisdiction over
all residents, Court of Appeal has appellate jurisdiction
Government leader: President Seretse Khama
Suffrage: universal, age 21 and over
Elections: general elections held 26 October 1974
Political parties and leaders: Botswana Democratic Party
(BDP), Seretse Khama; Bechuanaland People’s Party (BPP),
Philip Matante; Botswana Independence Party (BIP),
Motsamai Mpho; Botswana National Front (BNF), Kenneth
Koma
Voting strength: (October 1974 election) BDP (27 ‘seats);
BPP (2 seats); BNF (2 seats); BIP (1 seat)
Communists: no known Communist organization; Koma
of BNF has long history of Communist contacts
Member of: AFDB, Commonwealth, FAO, G-77, GATT
(de facto), IBRD, IDA, IMF, ITU, NAM, OAU, U.N., UPU,
WMO','dac61a5093718deca10c0a305fbb2a87e45e3622c22adcb637add2bd51e43460','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56922d31af611d703cbb048d763b55e3d893daf7199765fe888452b6aa6fc076',1978,'BR','Brazil','government',78,'Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presidential re-
gime since April 1964
Capital: Brasilia
Political subdivisions: 21 states, 4 territories, federal
district (Brasilia)
Legal system: based on Latin codes; dual system of courts,
state and federal; constitution adopted 1967 and extensively
amended in 1969; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 7 September
Branches: strong executive with very broad powers;
bicameral legislature (powers of the two bodies have been
sharply reduced); 1l-man Supreme Court
Government leader: President Ernesto Geisel
Suffrage: compulsory over age 18, except illiterates and
those stripped of their political rights; approximately 30
million registered voters in October 1970
Elections: President Medici’s successor was chosen by a
505-member electoral college, composed of the members of
Congress and delegates selected from the state legislatures,
on 15 January 1974 and took office on 15 March 1974; Geisel
was the choice of Medici and top military chiefs
Voting strength: (November 1974 congressional elections)
33.6% ARENA, 81.9% MDB, 35.5% blank and void
Political parties and leaders: National Renewal Alliance
(ARENA), pro-government Francelino Pereira, president;
Brazilian Democratic Movement (MDB), opposition, Ulisses
Guimaraes, president
Communists: 6,000, 1,000 militants
Other political or pressure groups: excepting the
military, the Catholic Church is the only active nationwide
pressure group, however, divisions within the Church often
prevent it from speaking with one voice; labor and student
groups have almost no influence on the government
Member of: FAO, G-77, GATT, IADB, IAEA, IBRD,
ICAG, ICAO, IDA, IDB, IFC, THO, ILO, IMCO, IMF, IPU,
ISO, ITU, IWC—International Wheat Council, LAFTA,
OAS, SELA, U.N., UNESCO, UPU, WHO, WIPO, WMO
Legal name: British Solomon Islands Protectorate
Type: British protectorate administered as crown colony,
became self-governing January 1976, stated for indepen-
dence July 1978
Capital: Honiara
Political subdivisions: 4 administrative districts
Legal system: a High Court plus Magistrates Courts, also
a system of native courts throughout the islands
Branches: executive authority in High Commissioner; a
legislative assembly of 38 members
Government leaders: Governor Colin H. Allan, and Chief
Minister Kenilorea
Suffrage: universal age 21 and over
Elections: every 4 years, latest June 1976
Political parties and leaders: United Solomon Islands
Party
Member of: ADB
Legal name: Cooperative Republic of Guyana
Type: republic within Commonwealth
Capital: Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with certain
admixtures of Roman-Dutch law; has not accepted compul-
sory IC] jurisdiction
National holiday: 23 February
Branches: Council of Ministers presided over by Prime
Minister; 58-member unicameral legislative National Assem-
bly (elected); Supreme Court
Government leader: Prime Minister L. F. §. Burnham
Suffrage: universal over age 18 as of constitutional
amendment August 1973
Elections: last held in July 1973; next election’ must be
called within 5 years
Political parties and leaders: People’s National Congress
(PNC), L. F. S. Burnham; People’s Progressive Party (PPP),
Cheddi Jagan; United Force (UF), Feilden Singh
Voting strength (1973 election): 70.2% PNC, 26.2% PNC,
3.6% other
Communists: est. 100 hard-core within PPP; top echelons
of PPP and PYO (Progressive Youth Organization, militant
wing of the PPP) include many Communists, but rank and
file is conservative and non-Communist; small but unknown
number of orthodox Marxist-Leninists within PNC, some of
whom are PPP turncoats
Other political or pressure groups: Trades Union
Congress (TUC); Working People’s Alliance (WPA); Work-
ing People’s Vanguard Party (WPVP); Guyana Council of
Indian Organizations (GCIO); Civil Liberties Action Com-
mittee (CLAC); the latter two organizations are small and
active but not well organized
Member of: CARICOM, CDB, FAO, G-77, GATT, IADB,
IBA, IBRD, ICAO, IDA, IFC, ILO, IMF, ISO, ITU, NAM,
OAS (observer), SELA, U.N., UNESCO, UPU, WHO, WMO','d8404d916e02c1e06dafb05c4fc0f291ad8bc450028e62fde685afa810b97ef9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8daba1740f9b47fd2e69243bcdc36a5dc9d4e3dd498bc06ec0ce2dd1b28caf45',1978,'ID','Indonesia','government',82,'Legal name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: 4 administrative districts
Legal system: based on Islamic law; constitution promul-
gated by the Sultan in 1959
Branches: Chief of State is Sultan (advised by appointed
Privy Council) who appoints Executive Council and
Legislative Council
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 8-tiered system of
indirect elections; popular vote cast for lowest level (district
councilors)
Elections: last elections—March 1965; further elections
postponed _ indefinitely
Political parties and leaders: antigovernment, exiled
Brunei People’s Party, Chairman A. M. N. Azahari
Communists: information not available
Legal name: Republic of Indonesia
Type: republic
Capital: Jakarta
Political subdivisions: 27 first-level administrative subdi-
visions or provinces which are further subdivided into 282
second-level areas
Legal system: based on Roman-Dutch law, substantially
modified by indigenous concepts; constitution of 1945 is
legal basis of government; legal education at University of
Indonesia, Jakarta; has not accepted compulsory IC]
jurisdiction
National holiday: Independence Day, 17 August
Branches: executive headed by President who is chief of
state and head of cabinet; cabinet selected by President;
unicameral legislature (Parliament), of 460 members (100
appointed, 360 elected); second and larger body (Congress)
of 920 members and includes the legislature and 460 other
members (chosen by several processes, but not directly
elected) elects President and Vice President, and theoreti-
cally determines national policy
Government leader: President Suharto (elected by
Congress, March 1973)
Suffrage: universal over age 17 and married persons
regardless of age
Political parties and leaders: Golkar (quasi-official
“party” based on functional groups), Amir Moertono;
Indonesian Democratic Party (federation of former Nation-
alist and Christian parties), Mohammed Isnaeni; Unity
Development Party (federation of former Islamic parties),
Idham Chalid
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
INDONESTA/TIRAN
Voting strength (1977 election): Golkar 232 seats,
Indonesian Democratic 29, Unity Development 99
Communists: Communist Party (PKI) was officially
banned in March 1966; current strength est. at 1,000, with
less than 10% engaged in organized activity; pre-October
1965 hard-core membership has been estimated at 1.5
million
Member of: ADB, ANRPC, ASEAN, CIPEC, ESCAP,
FAO, G-77, IAEA, IBA, IBRD, ICAO, IDA, IFC, IHO, ILO,
IMCO, IMF, IPU, ISO, ITC, ITU, NAM, OPEC, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Empire of Iran
Type: constitutional monarchy, controlled by the Shah
Capital: Tehran
Political subdivisions: 23 provinces, subdivided into
districts, sub-districts, counties, and villages
Legal system: based largely on French law, with elements
drawn from other continental systems; personal law based on
Islamic practice generally with residual traces of Roman
law; constitution adopted 1906 and constitutional law of
1907; High Court of Appeal may judge disputes relating to
government departments acting according to law; legal
education at University of Teheran; has not accepted
compulsory ICJ jurisdiction
National holiday: Birthday of the Shah, 26 October
Branches: executive power rests in Shah who appoints a
Prime Minister; Prime Minister must be approved by lower
house (Majlis); while Cabinet theoretically responsibility of
Prime Minister, Shah usually exerts strong influence over its
selection; bicameral legislature; Majlis has 268 members
elected to 4-year terms, and Senate 60 members serving
4-year terms; half of Senate members appointed by Shah,
other half elected; no provision for judicial review of
constitutionality of legislative acts
Government leaders: Shah Mohammad Reza Pahlavi and
Prime Minister Jamshid Amuzegar
Suffrage: universal over age 20
Elections: Majlis every 4 years; Senate every 4 years;
latest national elections June 1975, last district and
municipal October 1976
Political parties and leaders: a single party system,
designated The Resurgence Party of the People of Iran
(RPPI) with Modammad Baheri as Secretary-General, was
formed by Shah in March 1975; all other political parties
disbanded
Voting strength: all candidates government approved and
members of the RPPI
Communists: 1,000-2,000 (hard-core, est.); sympathizers
(15,000-20,000 est.); mostly pro-U.S.S.R. but pro-Chinese
faction developing
Other political or pressure groups: Tudeh Party (Com-
munist, illegal); National Front (coalition of neutralist urban
elements virtually discredited because of opposition to
Shah’s reform program); Confederation of Iranian Students
(illegal)
Member of: CENTO, Colombo Plan, FAO, G-77, IAEA,
IBRD, ICAC, ICAO, IDA, IFC, THO, ILO, IMCO, IMF,
IPU, ITU, OPEC, RCD, U.N., UNESCO, UPU, WFTU,
WHO, WMO, WSG','feeca765b1f5aef25d347e415c677e4fa84a6b6a8687f5fae7a2608d0f5a1e46','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('932490ce9c80c3cee68b8ed1749631ef375a4e614abd6634ace7d50b4fc86df5',1978,'BG','Bulgaria','government',86,'Legal name: Peoples Republic of Bulgaria
Type: Communist state
Capital: Sofia
Political subdivisions: 28 okrugs (districts), including
capital city of Sofia
Legal system: based on civil law system, with Soviet law
influence; new constitution adopted in 1971; judicial review
of legislative acts in the State Council; legal education at
University of Sofia; has accepted compulsory ICJ jurisdiction
National holiday: National Liberation Day, 9 September
Branches: legislative, National Assembly; judiciary, Coun-
cil of Ministers
Government leaders: Todor Zhivkov, Chairman, State
Council (President and chief of state); Stanko Todorov,
Chairman, Council of Ministers (premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 5 years for National
Assembly; last elections held on 20 May 1976; 99.85% of the
electorate voted
Political parties and leaders: Bulgarian Communist
Party, Todor Zhivkov, First Secretary; Bulgarian National
Agrarian Union, a puppet party, Petur Tanchev, secretary of
Permanent Board
Communists: 781,000 party members (March 1976)
Mass organizations and front groups: Fatherland Front,
Dimitrov Communist Youth League, Central Council of
Trade Unions, National Committee for Defense of Peace,
Union of Fighters Against Fascism and Capitalism, Commit-
tee of Bulgarian Women, All-National Committee for
Bulgarian-Soviet Friendship
Member of: CEMA, FAO, IAEA, ICAO, ILO, Interna-
tional Lead and Zine Study Group, IMCO, IPU, ITC, ITU,
IWC— International Wheat Council, U.N., UNESCO, UPU,
WHO, WIPO, WMO, Warsaw Pact, International Organiza-
tion of Journalists, International Medical Association, Inter-
national Radio and Television Organization
Legal name: Socialist Republic of the Union of Burma
Type: republic under 1974 constitution
Capital: Rangoon
Political subdivisions: seven divisions and seven constitu-
ent states; subdivided into townships, villages, and wards
Legal system: People’s Justice system and People’s Courts
instituted under 1974 constitution; legal education at
Universities of Rangoon and Mandalay; has not accepted
compulsory ICJ jurisdiction
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
National holiday: Independence Day, 4 January
Branches: State Council rules through a Council of
Ministers; People’s Assembly has legislative power
Government leader: Chairman of State Council and
President, Gen. U. Ne Win
Suffrage: universal over age 18
Elections: People’s Assembly and local People’s Councils
elected in 1974
Political parties and leaders: government-sponsored
Burma Socialist Program Party only legal party
Communists: estimated 5,000-8,000
Other political or pressure groups: People’s Patriotic
Party; Kachin Independence Army; Karen Nationalist
Union, several Shan factions
Member of: ADB, Colombo Plan, FAO, G-77, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO, IMCO, IMF,
ITU, NAM, U.N., UNESCO, UPU, WHO, WMO','2964cf45eef4e90180255813179df8a18c6f49aabac11f806e0119d6cf50bf2a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97e257653c0ed3292ee77e27a7a36750b6417e682aa15a5604d410d101d9d928',1978,'BI','Burundi','government',90,'Legal name: Republic of Burundi
Type: republic; military government overthrown by
military coup, November 1976; constitution abolished
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into 18
arrondissements and 78 communes; Bujumbura city (popula-
tion est. 160,000) has status equal to a province
Legal system: based on German and French civil codes
and customary law; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 1 July
Branches: Supreme Revolutionary Council is governing
body
Government leader: Col. Jean Bagaza, Chairman of
Supreme Revolutionary Council, established November 1976
Elections: last legislative election May 1965; legislature
dissolved in 1966
Political parties and leaders: National Party of Unity and
Progress (UPRONA), a Tutsi led party, declared sole
legitimate party in 1966
Communists: no Communist party; resumed diplomatic
relations with the Peoples Republic of China in October
1971 following a six-year suspension; U.S.S.R., North Korea,
and Romania also have diplomatic missions in Burundi
Member of: AFDB, EAMA, ECA, FAO, G-77, GATT,
IBRD, ICAO, IDA, ILO, IMF, ITU, NAM, OAU, U.N.,
UNESCO, UPU, WHO, WMO','2814f271eaa8d5be533f6a16dcfd5203b61a71010faa08efcd5c8c68793f17d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('401c447ea85e23493c0afd29b2fed35d72c1ac88ddbdc645fd6674117851c5f2',1978,'KH','Cambodia','government',94,'Legal name: Democratic Kampuchea (Cambodia)
Type: Communist state
Capital: Phnom Penh
Political subdivisions: 19 or 20 provinces
Legal system: Tribunal Committee chosen by People’s
Representative Assembly
National holiday: 17 April
Branches: State Presidium, composed of chairman and
two vice chairmen; nine-member cabinet, totally Commu-
nist, announced on 14 April; 250-member People’s Repre-
sentative Assembly elected 20 March for 5-year term;
ten-member Assembly Standing Committee
Government leader: Presidium Chairman, Khieu Sam-
phan; Prime Minister, Pol Pot; Deputy Prime Ministers, leng
Sary, Vorn Vet, Son Sen; Assembly Standing Committee
Chairman, Nuon Chea
Suffrage: universal over age 18
Political parties and leaders: political life dominated by
Khmer Communist Party and panoply of mass front
organizations
Member of: G-77, NAM, U.N.','e9bd855d70edcdc6e96cec678d9a1405ed0ecfee6321bb7d89cf395fada58221','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76882d116843a51d3effbbb9f28ea67d82087de54caa739a941d5301b143b45f',1978,'CM','Cameroon','government',98,'Legal name: United Republic of Cameroon
Type: unitary republic; one-party presidential regime
Capital: Yaounde
Political subdivisions: 7 provinces divided into 39
departments
Legal system: based on French civil law system, with
common law influence; new unitary constitution adopted
1972; judicial review in Supreme Court, when a question of
constitutionality is referred to it by the President of the
Republic; has not accepted compulsory IC] jurisdiction
National holiday: 20 May
Branches: executive, legislative, and judicial
Government leader: President Ahmadou Ahidjo
Suffrage: universal over age 2]
Elections: presidential elections held 5 April 1975;
parliamentary elections last held 18 May 1973
Political parties and leaders: single party, Cameroonian
National Union (UNC), President Ahmadou Ahidjo
Communists: no Communist Party or significant number
of sympathizers
Other political or pressure groups: Cameroon Peoples
Union (UPC), an illegal terrorist group now reduced to
scattered acts of banditry with its factional leaders in exile
Member of: AFBD, EAMA, ECA, EIB (associate), FAO,
G-77, GATT, IAEA, IBRD, ICAC, ICAO, IDA, IFC, ILO,
IMCO, IMF, IPU, ISO, ITU, Lake Chad Basin Commission,
NAM, Niger River Commission, OAU, UDEAC, U.N.,
UNESCO, UPU, WHO, WIPO, WMO
a2 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CAMEROON/CANADA','a0b93ec22adfdeb9454462a42578a01a99ce4982671b896dea6c7ea0e715916d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('444ab18b1f1c708bb966e2d36182e7f407dade920ddcff37131c687b6ba9b4cc',1978,'CA','Canada','government',102,'Legal name: Canada
Type: federal state recognizing Elizabeth II as sovereign
Capital: Ottawa
Political subdivisions: 10 provinces and 2 territories
Legal system: based on English common law, except in
Quebec, where civil law system based on French law
prevails; constitution is British North America Act of 1867
and various amendments; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: Dominion Day, 1 July
Branches: federal executive power vested in cabinet
collectively responsible to House of Commons, and headed
by Prime Minister; federal legislative authority resides in
Parliament consisting of Queen represented by Governor-
General, Senate, and Commons; judges appointed by
Governor-General on the advice of the government;
Supreme Court is highest tribunal
33
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CANADA/CAPE VERDE
Government leader: Pierre Elliott Trudeau
Suffrage: universal over age 18
Elections: legal limit of 5 years but in practice held at
least every 4 years, last election July 1974
Political parties and leaders: Liberal, Pierre Trudeau;
Progressive-Conservatives, Joe Clark; New Democratic,
Edward Broadbent; Social Credit, vacant since death of
Andre Fortin in July 1977
Voting strength (1974 election (numbers in parens
indicate current party strengths in Parliament): Liberal
43% (142 seats), Progressive Conservative 35% (91 seats),
New Democratic Party 16% (16 seats), Social Credit 5% (9
seats), other 1%, Independents hold 2 seats, 4 seats
unoccupied; Parliament enlarged from 264 seats to 282 seats
on 12 June but new seats will not be filled until next general
election expected in 1978
Communists: 2,000 approx.
Member of: ADB, Colombo Plan, Commomwealth. DAC,
FAO, GATT, IAEA, IBRD, ICAO, ICES, ICRC, [DA, IDB,
IEA, IFC, THO, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IPU, ISO, ITC, ITU, [WC—Interna-
tional Whaling Commission, [WC—International Wheat
Council, NATO, OAS (observer), OECD, U.N., UNC-
TAD, UNESCO, UPU, WHO, WIPO, WMO, WSG','e838f0ad11d78bce3fe2455605031f1c800f6c8790b7fe60a63b54d469a17944','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc93ce7d0351612bcc11cd13062509b26169af550494357589ee7aa7289d87a0',1978,'GN','Guinea','government',106,'Legal name: Republic of Cape Verde
National holiday: 12 September
Type: republic; achieved independence from Portugal in
July 1975
Capital: Praia
Political subdivisions: 10 islands
Legal system: to be determined
National holiday: 12 September
Branches: National Assembly, 56 members; the official
party is the supreme political institution
Government leaders: President, Aristides Pereira; Prime
Minister, Pedro Pires; Minister of Foreign Affairs, Abilio
Duarte
Suffrage: universal over age 18
Elections: to be determined
Political parties and leaders: Partido Africano da
Independencia da Guinee e Cabo Verde (PAIGC), led by
Aristide Pereira, only legal party
Communists: none known
Member of: G-77, NAM, OAU, U.N.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Legal name: Central African Empire
Type: constitutional monarchy, founded on a single party
Capital: Bangui
Political subdivisions: 14 prefectures, 47 subprefectures
Legal system: based on French, Islamic, and tribal Jaw; in
1966 the Chief of State assumed all power and abrogated the
constitution; in 1976 he promulgated a new constitution; has
not accepted compulsory ICJ jurisdiction
National holiday: 1 December
Branches: Emperor Bokassa is chief of state and rules by
decree; government is headed by a Prime Minister assisted
by the Council of Ministers; judiciary, Supreme Court, court
of appeals, criminal court, and numerous lower courts;
constitution calls for a National Assembly
Government leader: Emperor Salah Ad-Din Ahmad
Bokassa I
Suffrage: universal over age 21
Elections: none have been held yet under Bokassa regime;
provided for in new constitution
Political parties and leaders: Movement for the Social
Evolution of Black Africa (MESAN), ruling party under
former regime, continues as a key body for organizing
support for the regime led by Emperor Bokassa
Communists: no Communist Party or significant number
of sympathizers
Member of: AFDB, Conference of East and Central
African States, EAMA, ECA, FAO, G-77, GATT, IBRD,
ICAO, IDA, ILO, IMF, ITU, NAM, OAU, OCAM, UDEAC,
UN., UNESCO, UPU, WHO, WMO
Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since 1968
Capital: Malabo, Province Francisco Macias Nguema
Political subdivisions: 2 provinces (Province Francisco
Macias Nguema and Rio Muni)
Legal system: based on Spanish Civil law system and
customary law, new constitution adopted August 1973: has
not accepted compulsory ICJ jurisdiction
National holiday: 5 March
Branches: there are legislative and judicial branches but
President exercises virtually unlimited power
Government leader: President for life, Francisco Macias
Nguema
Suffrage: universal age 21 and over
Elections: parliamentary elections held December 1973
Political parties and leaders: National Unity Party of
Workers (PUNT) is the sole legal party, led by President
Macias
Communists: no significant number of Communists or
sympathizers
Member of: Conference of East and Central African
States, ECA, G-77, IBRD, ICAO, IDA, IMCO, IMF, ITU,
NAM, OAU, U.N., UPU
Legal name: Republic of Ghana
Type: republic; independent since March 1957; Military
regime since January 1972
Capital: Accra
Political subdivisions: 8 administrative regions and
separate Greater Accra Area; regions subdivided into 58
districts and 267 local administrative districts
Legal system: based on English common law and
customary law; constitution suspended January 1972; legal
education at University of Ghana (Legon); has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 6 March
Branches: executive and legislative authority vested in
Supreme Military Council (SMC); independent judiciary
Government leaders: Chief of State, Chairman of SMC
General Ignatius Kutu Acheampong
Suffrage: universal over 21 under previous constitution,
now suspended
Elections: no elections since 1969; the military has
promised to return power to an elected civilian regime in
June 1979; popular referendum scheduled for March 1978 to
approve a new form of government
Political parties and leaders: parties banned by military
junta which took power 13 January 1972
Communists: a small number of Communists and
sympathizers
Member of: AFDB, Commonwealth, ECA, ECOWAS,
FAO, G-77, GATT, IAEA, IBA, IBRD, ICAO, IDA, IFC,
ILO, IMCO, IMF, ISO, ITU, NAM, OAU, U.N., UNESCO,
UPU, WCL, WHO, WIPO, WMO
Legal name: Republic of Guinea
Type: republic; under one-party presidential regime
Capital: Conakry
Political subdivisions: 29 administrative regions, 209
arrondissements, about 8,000 local entities at village level
Legal system: based on French civil law system,
customary law, and presidential decree; constitution adopted
1958; no constitutional provision for judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 2 October
Branches: executive branch dominant, with power
concentrated in President’s hands and a small group who are
both ministers and members of the party’s politburo;
unicameral National Assembly and judiciary have little
independence
Government leader: President Ahmed Sekou Toure, who
has been designated “The Supreme Leader of the
Revolution”
Suffrage: universal over age 18
Elections: approximate schedule—5 years parliamentary,
latest in 1975; 7 years presidential, latest in 1975
Political parties and leaders: only party is Democratic
Party of Guinea (PDG), headed by Sekou Toure
Communists: no Communist party, although there are
some sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, G-77, IBA,
IBRD, ICAO, IDA, ILO, IMF, ITU, Niger River Commis-
sion, NAM, OAU, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Ivory Coast
Type: republic, one-party presidential regime established
1960
Capital: Abidjan
Political subdivisions: 24 departments subdivided into
127 subprefectures
Legal system: based on French civil law system and
customary law; constitution adopted 1960; judicial review in
the Constitutional Chamber of the Supreme Court; legal
education at Abidjan School of Law; has not accepted
compulsory ICJ jurisdiction
National holiday: 7 December
Branches: President has sweeping powers, unicameral
legislature, separate judiciary
Government leader: President Felix Houphouet-Boigny
Suffrage: universal over age 21
Elections: uncontested Presidential and legislative elec-
tions held in November 1975 for 5-year term
Political parties and leaders: Parti Democratique de la
Cote d''Ivoire (PDCI), (only party); official party leader is
Secretary General Philippe Yace, but Houphouet-Boigny is
in control
Communists: no Communist
sympathizers
Member of: AFDB, CEAO, EAMA, ECA, ECOWAS, EIB
(associate), Entente, FAO, G-77, GATT, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU, Niger River
Commission, NAM, OAU, OCAM, U.N., UNESCO, UPU,
WHO, WIPO, WMO','9806db1e63e5d54b229a1409f4a6ec0db05d8b00fd6843165ed37c4e1b38ced2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd6054c389ebd356cc0189b6ed3995910564bd3a529ce4c77efeb774fa2f5051',1978,'TD','Chad','government',110,'Legal name: Republic of Chad
Type: republic; military regime in power since April 1975
Capital: N’Djamena
Political subdivisions: 14 prefectures
Legal system: based on French civil law system and
Chadian customary law; constitution adopted 1962; constitu-
tion suspended and national assembly dissolved April 1975,
judicial review of legislative acts in theory a power of the
Supreme Court; has not accepted compulsory IC] juris-
diction
National holiday: 13 April
Branches: executive authority exercised by Supreme
Military Council composed of 9 officers
Government leader: President of Supreme Military
Council, General Felix Malloum
Suffrage: universal over age 20
Elections: all political activity banned
Political parties and leaders: political parties banned
Communists: no front organizations or underground
party; probably a few Communists and some sympathizers
Other political or pressure groups: lightly armed Muslim
rebel bands have been opposing the government since
October 1965 in east-central and since August 1969 in
northern Chad
Member of: AFDB, Conference of East and Central
African States, EAMA, ECA, FAO, G-77, GATT, ICAC,
ICAO, IBRD, IDA, IMF, ITU, Lake Chad Basin Commis-
sion, NAM, OAU, UEAC, U.N., UNESCO, UPU, WHO,
WIPO, WMO
Legal name: Republic of Chile
Type: republic
" Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978','ac7515b330f83b72f2f50826bf03b0248a23f01108acf4c87b7a6f4d6e9d66d5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2736c3c8b84ce52fa734e60c056a8f583c282e8cc556116ac6fefb94cbf68865',1978,'CL','Chile','government',112,'Capital: Santiago
Political subdivisions: 12 regions plus one metropolitan
district, 41 provincial subdivisions
Legal system: based on Code 1857 derived from Spanish
law and subsequent codes influenced by French and
Austrian law; constitution adopted 1925, amended since
then, currently being revised; judicial review of legislative
acts in the Supreme Court; legal education at University of
Chile, Catholic University, and several others; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 18 September
Branches: four-man Military-Police Junta, which exer-
cises constituent and legislative powers and has delegated
executive powers to President of Junta; the President has
announced a plan for transition from military to civilian rule
by 1985; Congress dissolved; civilian judiciary remains
Government leader: President, Gen. Augusto PINO-
CHET Ugarte; other Junta members, Adm. Jose Toribio
MERINO Castro, Gen. Gustavo LEIGH Guzman, Gen.
Cesar MENDOZA Duran
Suffrage: none
Elections: prohibited by decree; all electoral registers
were destroyed in 1974
Political parties and leaders: Christian Democratic Party
(PDC), Andres Zaldivar and Eduardo Frei; National Party
(PN), Sergio Onofre Jarpa; PDC and (PN) are officially
banned; Popular Unity coalition parties (outlawed)—
Communist Party (PCCh), Luis Corvalan (in exile); Socialist
Party (PS), Clodomiro Almeyda and Carlos Altamirano
(both in exile); Radical Party (PR); Christian Left (IC);
United Popular Action Movement (MAPU); Independent
Popular Action (API)
Voting strength (1970 presidential election): 36.6%
Popular Unity coalition, 35.3% conservative independent,
28.1% Christian Democrat; (1973 Congressional election)
44% Popular Unity coalition, 56% Democratic Confeder-
ation (PDC and PN)
Communists: 248,000 when PCCh was legal in 1973;
active militants now estimated at about 20,000
Other political or pressure groups: organized labor;
business organizations; landowners’ associations (SNA—
Sociedad Nacional de Agricultural); Catholic church; ex-
treme leftist, Movement of Revolutionary Left (MIR),
outlawed; rightist, Patria y Libertad (PyL), outlawed
Member of: CIPEC, ECOSOC, FAO, G-77, GATT,
IADB, IAEA, IBRD, ICAO, IDA, IDB, IFC, IHO, ILO,
IMCO, IMF, IPU, ITU, LAFTA, OAS, SELA, U.N.,
UNESCO, UPU, WHO, WIPO, WMO, WSG
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4','6c039eb3e8dbd9a3993c3f1656639fb93080630c3e5d33f2b19040f35fec3c4d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25d91a9d2774595b3d92118f7bd548a95f2476c36f4b3866327d9185ca0ed182',1978,'CN','China','government',117,'Legal name: Peoples Republic of China
Type: Communist state; real authority lies with Commu-
nist party’s political bureau; the National People’s Congress,
in theory the highest organ of government, in reality merely
rubber stamps the party’s programs; the State Council is the
actual governing organism
Capital: Peking
Political subdivisions: 21 provinces, 3 centrally governed
municipalities, and 5 autonomous regions
Legal system: before 1966, a complex amalgam of custom
and statute, largely criminal; little ostensible development of
uniform code of administrative and civil law; highest
judicial organ is Supreme People’s Court although legal
activity centered in parallel network of Public Security
organs; laws and legal procedure clearly subordinated to
priorities of party policy; whole system largely suspended
during Cultural Revolution, but gradually being revived
National holiday: National Day, 1 October
Branches: prior to 1966 control was exercised by Chinese
Communist Party, through State Council, which supervised
more than 50 ministries, commissions, bureaus, etc., all
technically under the standing committee of the National
People’s Congress; this system broke down under “Cultural
Revolution” pressures but has been reconsolidated and
streamlined to 29 ministries
Government leader: Premier of State Council, Hua
Kuo-feng; government subordinate to central committee of
CCP, under Chairman Hua Kuo-feng
40 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CHINA, PEOPLES REPUBLIC OF/CHINA, REPUBLIC OF
Suffrage: universal over age 18, though this is academic
Elections: no meaningful elections
Political parties and leaders: Chinese Communist Party
(CCP), headed by Hua Kuo-feng; Hua is Chairman of
Central Committee; a new central committee was formed at
the llth Party Congress held in August 1977
Voting strength: 100% Communist for practical purposes;
no political nonconformity permitted
Communists: about 35 million party members in 1977
Other political or pressure groups: army (PLA) remains a
major force, although many soldiers who acquired a wide
range of civil political-administrative duties during the
Cultural Revolution have been removed; many veteran
civilian officials, in eclipse since the Cultural Revolution,
have been reinstated; mass organizations, such as the trade
unions and the youth league, have been rebuilt in the
provinces; plans are underway to rebuild the national
organizations
Member of: FAO, IAEA, IBRD, ICAO, IDA, IFC, IHO,
ILO, IMCO, IMF, ITU, Red Cross, U.N., UNESCO, UPU,
WHO, WMO, other international bodies
Legal name: Republic of Korea
Type: republic; power centralized in a strong executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities; heads
centrally appointed
Legal system: combines elements of continental Europe-
an civil law systems, Anglo-American law, and Chinese
classical thought; constitution approved 1972; has not
accepted compulsory ICJ jurisdiction
National holiday: 15 August
Branches: executive, legislative (unicameral), judiciary,
National Conference of Unification
Government leaders: President Pak Chong-hui; Prime
Minister Choe Kyu-ha
Suffrage: universal over age 20
Elections: presidential every 6 years indirectly by the
National Conference of Unification, last election December
1972; two-thirds of the 219-member National Assembly is
elected directly for the same period within six months of the
presidential election, remaining third nominated by the
President and elected by the National Conference for a
three-year term; last election February 1973, Revitalization
Group—73 seats, Democratic Republican Party—68 seats,
New Democratic Party—55 seats, Democratic Unification
Party—3 seats, Independents—15 seats
113
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
KOREA, SOUTH/KUWAIT
Political parties and leaders: pro-government—Revital-
ization Group (appointed) (Chairman, Pak Tu-Chin) and
Democratic Republican Party (Acting Chairman, Yi
Hyo-sang); New Democratic Party (Chairman, Yi Chol-
sung); Democratic Unification (Chairman, Yang I]-tong)
Voting strength: (1973 election) popular vote 11,896,484;
DRP 38.8%, NDP 32.8%, DUP 10.2%, Independent 18.1%,
0.1% invalid
Communists: Communist activity banned by govern-
ment; an estimated 37,000-50,000 former members and
supporters
Other political or pressure groups: Federation of Korean
Trade Unions; Korean Veterans’ Association; large poten-
tially volatile student population concentrated in Seoul
Member of: ADB, Asian Parliamentary Union, Asian
People’s Anti-Communist League (APACL), ASPAC,
Colombo Plan, ESCAP, FAO, G-77, GATT, Geneva
Conventions of 1949 for the protection of war victims,
IAEA, IBRD, ICAC, ICAO, IDA, IFC, IHO, IMCO, IMF,
INTELSAT, INTERPOL, IPU, ITU, IWC—International
Wheat Council, UNESCO, U.N. Special Fund, UPU, WHO,
WMO, World Anti-Communist League (WACL); official
observer at U.N., does not hold U.N. membership
Legal name: Republic of the Philippines
Type: republic
Capital: Manila
Political subdivisions: 72 provinces
Legal system: based on Spanish, Islamic, and Anglo-
American law; parliamentary constitution passed 1973;
judicial review of legislative acts in the Supreme Court; legal
education at University of the Philippines, Ateneo de Manila
University, and 71 other law schools; accepts compulsory IC]
jurisdiction, with reservations; currently being ruled under
martial law
National holiday: Independence Day, 12 June
Branches: new constitution (currently suspended) pro-
vides for unicameral National Assembly, and a strong
executive branch under a Prime Minister; judicial branch
headed by Supreme Court with descending authority in a
Court of Appeals, courts of First Instance in various
provinces, municipal courts in chartered cities, and justices
of the peace in towns and municipalities; these justices have
considerably more authority than do justices of the peace in
the U.S.
Government leader: President Ferdinand FE. Marcos
Suffrage: universal over age 18
Elections: elections suspended for the indefinite future
Political parties and leaders: political parties currently in
limbo because of martial law
Communists: about 1,600 armed insurgents
Member of: ADB, ASEAN, ASPAC, Colombo Plan,
ESCAP, FAO, G-77, IAEA, IBRD, ICAO, IDA, IFC, IHO,
ILO, IMCO, IMF, IPU, ISO, ITU, U.N., UNESCO, UPU,
WHO,','54f70d1533381744190c909b919e576c5af0478ab4bfad68651a1788543d3961','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f95f09ebc065b38b28788d0bd7e11227a7816a879005dc8e1361ddaac27dc55f',1978,'PH','Philippines','government',121,'Legal name: Republic of China
Type: republic; one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 4 cities, 1 special
municipality (Taipei)
Legal system: based on civil law system; constitution
adopted 1947, amended 1960 to permit Chiang Kai-shek to
be reelected, and amended 1972 to permit President to
restructure certain government organs; accepts compulsory
IC] jurisdiction, with reservations
Branches: 5 independent branches (executive, legislative,
judicial, plus traditional Chinese functions of examination
and control), dominated by executive branch; President and
Vice President elected by National Assembly
Government leaders: President Yen Chia-kan; Premier
Chiang Ching-kuo
Suffrage: universal over age 20
Elections: national level—tegislative yuan every 3 years
but no general election held since 1948 election on mainland
(partial elections for Taiwan province representatives
December 1969, December 1972, and December 1975);
local level—provincial assembly, county and municipal
executives every 4 years; county and municipal assemblies
every 4 years
Political parties and leaders: Kuomintang, or National
Party, led by Chairman Chiang Ching-kuo, has no real
opposition; 2 insignificant parties are Democratic Socialist
Party, Young China Party
Voting strength (1972 provincial assembly election): 58
seats Kuomintang, 13 seats independents
Other political or pressure groups: none
Member of: expelled from U.N. General Assembly and
Security Council on 25 October 1971 and withdrew on same
date from other charter-designated subsidiary organs;
attempting to retain membership in international financial
institutions, ICAC, ISO, IWC-International Wheat Council
Legal name: Hong Kong
Type: U.K. crown colony
Capital: None
Political subdivisions: Hong Kong, Kowloon, and New
Territories
Legal system: English common law
Branches: Governor assisted by advisory Executive
Council; he legislates with advice and consent of Legislative
Council; Urban Council which alone includes elected
representatives, responsible for health, recreation, and
resettlement; independent judiciary
Government leader: Sir C. M. MacLehose, Governor and
Commander in Chief
Suffrage: limited to 200,000 to 300,000 professional or
skilled persons
Elections: every 2 years to select one-half of elected
membership of Urban Council; other Urban Council
members appointed by the Governor
Political parties: Civic Association; Reform Club; Socialist
Democratic Party; Hong Kong Labour Party
Voting strength: (elected Urban Council members) Civic
Association 4, Reform Club 3, and 1 independent
Communists: an estimated 2,000 cadres affiliated with
Communist Party of China
Other political or pressure groups: Federation of Trade
Unions (Communist controlled), Hong Kong and Kowloon
Trade Union Council (Nationalist Chinese dominated),
Hong Kong General Chamber of Commerce, Chinese
General Chamber of Commerce (Communist controlled),
Federation of Hong Kong Industries, Chinese Manufactur-
ers) Association of Hong Kong
Member of: ADB
Legal name: Province of Macao
Type: overseas province of Portugal
Capital: Lisbon (Portugal)
Political subdivisions: municipality of Macao, and 2
islands
Legal system: Portuguese civil law system
Branches: 17-member Legislative Assembly, with Gover-
nor and 5 appointed, 1 specially nominated, and 10 elected
representatives
Government leader: Col. Eduardo Garcia Leandro
Suffrage: Portuguese, Chinese and foreign residents over
18
Elections: conducted every 4 years; last held 1976
Political parties and leaders: Association to Defend the
Interests of Macao; Macao Democratic Center; Group to
Study the Development of Macao; Macao Independent
Group
Communists: numbers unknown
Other political or pressure groups: wealthy Macanese
and Chinese representing local interests, wealthy pro-Com-
munist merchants representing China’s interests; in January
1967 Macao Government acceded to Chinese demands
which gave Chinese veto power over administration of the
enclave
ae Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MACAO/MADAGASCAR','c01f891dc7e935b6bbf34543f497118cfbf282068b955f9a4196e6227c04906f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56050a69dacb7fbf420557d9c22075167365af0a0caa23caec2eb72b4c9058ac',1978,'CO','Colombia','government',125,'Legal name: Republic of Colombia
Type: republic; executive branch dominates government
structure
Capital: Bogota
Political subdivisions: 22 departments, 3 Intendants, 5
Commissariats, Bogota Special District
Legal system: based on Spanish law; religious courts
regulate marriage and divorce; constitution decreed in 1886,
amendments codified in 1946 and 1968; judicial review of
legislative acts in the Supreme Court; accepts compulsory
ICJ jurisdiction, with reservations
National holiday: Independence Day, 30 July
Branches: President, bicameral legislature, judiciary
Government leader: President Alfonso Lopez Michelsen
Suffrage: universal over age 21
Elections: every fourth year; last presidential and
congressional elections April 1974; municipal and depart-
mental elections, April 1976
Political parties and leaders: Liberal Party, President
Alfonso Lopez Michelsen; Conservative Party, Alvaro
Gomez Hurtado; Alianza Nazional Popular, Maria Eugenia
Rojas de Moreno
Voting strength: 1974 presidential election—Alfonso
Lopez Michelsen 55%, Alvaro Gomez Hurtado 32%, Maria
Eugenia Rojas de Moreno 9.5%; 1976 municipal election,
52% Liberal Party, 40% Conservative Party, 7% combined
far left parties; 70% abstention of eligible voters
Communists: 10,000-12,000 members est.
Other political or pressure groups: Communist Party
(PCC), Gilberto Vieira White; PCC/ML, Chinese Line
Communist Party
Member of: FAO, G-77, IADB, IAEA, IBRD, ICAC,
ICAO, IDA, IDB, IFC, IHO, ILO, IMF, ISO, ITU, LAFTA
and Andean Sub-Regional Group (created in May 1969
within LAFTA), OAS, SELA, U.N., UNESCO, UPEB, UPU,
WHO, WMO, WSG','b8f00c0786401ac23d7a3ca52337c02e59ae964a42cf333cd4ddd0156b2da939','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fe189c8cceb764edb26d6beb24001717a3c66578b839c3c7123be1c9b610c56',1978,'KM','Comoros','government',129,'Legal name: Republic of the Comoros
Type: three of the four islands comprise an independent
republic, following local government’s unilateral declaration
of independence from France in July 1975; other island,
Mayotte, disallowed declaration and is now a French
Territorial community
Capital: Moroni
Political subdivisions: the three islands are organized into
7 regions; these regions are broken down into 55 to 60
“Moudirias” or regional council centers; the “Bavous” are
the principle units of local government and they are grouped
together to form the “Moudirias”
= Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
COMOROS /CONGO
Legal system: French and Muslim law
Branches: Ali Soilih elected President of the Comoros,
April 1977; he immediately reorganized the Central
Government into 4 major components: the presidency,
internal affairs Central Committee, external affairs Central
Committee, and a Supreme Court
Suffrage: universal adult
Elections: last election took place April 1977; date of next
election unknown
Communists: information not available
Member of: G-77, NAM, OAU, U.N.
Legal name: Democratic Republic of Madagascar
Type: republic; real authority in hands of military-
dominated Supreme Revolutionary Council
Capital: Antananarivo
Political subdivisions: 6 provinces
Legal system: based on French civil law system and
traditional Malagasy law; constitution of 1959 modified in
October 1972 by law establishing provisional government
institutions; new constitution accepted by referendum in
December 1975; legal education at National School of Law,
University of Madagascar; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 26 June
Branches: executive—a 21-member Supreme Revolution-
ary Council (made up of military and_ political leaders);
assisted by cabinet called Council of Ministers; People’s
125
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MADAGASCAR/MALAWI
National Assembly; Military Committee for Development;
regular courts are patterned after French system, and a High
Council of Institutions reviews all legislation to determine its
constitutional validity
Government leader: Commander Didier Ratsiraka,
President
Suffrage: universal for adults (18 and above)
Elections: referendum held in December 1975 gave
overwhelming approval to government and new constitu-
tion; elections for People’s National Assembly held in June
1977; only one political grouping allowed to take part in the
election, “The Front for the Defense of Malagasy Socialist
Revolution,” which presented a single list of candidates
Political parties and leaders: 6 parties are now allowed
political activity under the National Front and are
represented on the Supreme Revolutionary Council; the 6
parties are: AREMA (President Ratsiraka’s Advance Guard
of the Malagasy Revolution); AKFM (Pastor Richard
Andriamanjato’s pro-Soviet Congress Party for Malagasy
Independence); VONJY (Dr. Pazanabahiny Marojama’s
Movement for National Unity); UDECMA (Norbert Andria-
morasata’s Malagasy Christian Democratic Union); MFM
(Manandafy Rakotonirina’s Militants for the Establishment
of a Proletarian Regime); MONIMA (Mouvement Nationale
pour L’Independence de Madagascar) party apparently split
over issue of joining National Front, leader of faction
supporting Front unknown, Monja Jaona leads other faction
Voting strength: number of registered voters (1977)—3.5
million; in 1977 local elections, President Ratsiraka’s
AREMA captured approximately 89.5% of the 73,000
available positions on 11,400 local Executive Committees;
AKFM won about 7.3% of the seats, MONIMA 1.7%. and
VONJY 1.4%; UDECMA won only about 45. seats
Communists: Communist party of virtually no impor-
tance; small and vocal group of Communists has gained
strong position in leadership of AKFM, the rank and file of
which is non-Communist
Member of: EAMA, FAO, G-77, GATT, IAEA, IBRD,
IFC, ILO, IMF, ISO, ITU, NAM, OAU, OCAM, U.LN.,
UNESCO, WHO, WMO','f2d9aefb294d3258ee1ffdd2b0ead4d59df6e55950b53db766dc67ad9b54a805','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6098d3851ff2f26ccc0415f26181a70fead20b5a1413ca5859aa08f956c109b',1978,'CG','Congo','government',133,'Legal name: Peoples Republic of the Congo
Type: republic; military regime established September
1968
Capital: Brazzaville
Political subdivisions: 9 regions divided into districts
Legal system: based on French civil law system and
customary law; constitution adopted 1973
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CONGO/COOK ISLANDS
National holiday: National Day, 15 August
Branches: President, Military Committee, Council of
State; judiciary; all policy made by Congolese Workers Party
Central Committee and Politburo
Government leaders: President, Colonel Joachim
Yhombi-Opango; Prime Minister Louis Goma
Suffrage: universal over age 18
Elections: last legislative elections June 1973
Political parties and leaders: Congolese Workers Party
(PCT) is only legal party
Communists: unknown number of Communists and
sympathizers
Other political or pressure groups: Union of Congolese
Socialist Youth (UJSC), Congolese Trade Union Congress
(CSC), Revolutionary Union of Congolese Union (URFC),
General Union of Congolese Pupils and Students (UGEEC)
Member of: AFDB, Conference of East and Central
African States, EAMA, ECA, EIB (associate), FAO, G-77,
GATT, IBRD, ICAO, IDA, ILO, IMF, ITU, NAM, OAU,
UDEAC, UEAC, U.N., UNESCO, UPU, WHO, WIPO,
WMO','69d4d9712b070f055361cae228d0fa7e715f10aaada05d50eb24799ed45a70e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6078999ae164817dfea21e8858b1589c4a275f4fdface78744c66de4e277e020',1978,'CK','Cook Islands','government',137,'Legal name: Cook Islands
Type: self-governing in “free association” with New
Zealand; Cook Islands government fully responsible for
internal affairs and has right at any time to move to full
independence by unilateral action, New Zealand retains
responsibility for external affairs, in consultation with Cook
Islands government
Capital: Rarotonga
Branches: New Zealand Governor General appoints
Representative to Cook Islands, who represents the Queen
and the New Zealand government; Representative appoints
the Premier; Legislative Assembly of 22 members, popularly
elected; House of Arikis (chiefs), 15 members, appointed by
Representative, an advisory body only
Government leader: Premier Albert Henry
Suffrage: universal adult
Elections: every 4 years, latest in December 1975
Political parties and leaders: Cook Islands Party, Sir
Albert Henry; Democratic Party, Dr. Thomas Davis
Voting strength (1974): Cook Islands Party, 13. seats;
Democratic Party, 9 seats','eaf7de4b8834cbde98f81ec0090ead29b8680c75fbdd39398e425f19d4ddcbce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e60f58f220b51f9a67f0193ba121275785cda56269fcc0644b453a7d08ae69ee',1978,'CR','Costa Rica','government',141,'Legal name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system;
constitution adopted 1949; judicial review of legislative acts
in the Supreme Court; legal education at University of Costa
Rica; has not accepted compulsory ICJ jurisdiction
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
COSTA RICA/CUBA
National holiday: Independence Day, 15 September
Branches: President, unicameral legislature, Supreme
Court elected by legislature
Government leader: President Daniel Oduber
Suffrage: universal and compulsory age 18 and over
Elections: every 4 years; next, February 1978
Political parties and leaders: National Liberation Party
(PLN), Luis Alberto Monge, president, Carlos Manuel
Castillo, secretary-general; National Unification Party
(PUN), Francisco Calderon Guardia; Democratic Renova-
tion Party (PRD), Rodrigo Carazo; Christian Democratic
Party (PDC), Jorge Monge Zamora; National Independence
Party (PNI), Jorge Gonzalez Marten; Popular Vanguard
Party (PVP, Communist), Manuel Mora Valverde
Voting strength (1974 election): National Unification
(coalition of PUN and others) 30.4%, 16 seats; PLN 48.5%,
27 seats; PNI 11%, 6 seats; PRD 9%, 3 seats; other 2.3%, 2
seats
Communists: 3,200 members, 10,000 sympathizers
Other political or pressure groups: Costa Rican Confed-
eration of Democratic Workers (CCTD), General Confeder-
ation of Workers (CGT), Chamber of Coffee Growers,
National Association for Economic Development (ANFE)
Member of: CACM, FAO, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMF, IPU, ITU, [WC—International
Wheat Council, NAMUCAR (Caribbean Multinational
Shipping Line—Naviera Multinacional del Caribe), OAS,
ODECA, SELA, U.N., UNESCO, UPEB, UPU, WHO,
WMO','0eb92a02f70bae40b35593423e6237737cd9d0e6928b3da6ce675229dc51db3e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e33fb69513a661799218cb784bc8d127313484853ea5e059d48cda85857b6a8f',1978,'CU','Cuba','government',145,'Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: 14 provinces and 169 munici-
palities
Legal system: based on Spanish and American law, with
large elements of Communist legal theory; Fundamental
Law of 1959 replaced Constitution of 1940; a new
constitution was approved at the Cuban Communist Party’s
First Party Congress in December 1975 and by a popular
referendum which took place on 15 February 1976; portions
of the new constitution were put into effect on 24 February
1976, by means of a Constitutional Transition Law, and the
entire constitution became effective on 2 December 1976;
legal education at Universities of Havana, Oriente, and Las
Villas; does not accept compulsory ICJ jurisdiction
National holiday: Anniversary of the Revolution, 1
January
Branches: executive; legislature (National People’s Assem-
bly); controlled judiciary
Government leader: President Fidel Castro Ruz
Suffrage: universal, but not compulsory, over age 16
Elections: National People’s Assembly (indirect election)
every five years; election held November 1976
Political parties and leaders: Cuban Communist Party
(PCC), First Secretary Fidel Castro Ruz, Second Secretary
Raul Castro Ruz
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Communists: approx. 200,000 party members
Member of: CEMA, ECLA, FAO, G-77, GATT, IADB
(nonparticipant), ICAO, IHO, ILO, IMCO, International
Rice Commission, ISO, 1''WC—International Wheat Council,
ITU, NAM, NAMUCAR (Caribbean Multinational Shipping
Line—Naviera Multinacional del Caribe), OAS (nonpartici-
pant), Permanent Court of Arbitration, Postal Union of the
Americas and Spain, SELA, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG','7779389bccbeef16e3c1e658f5fe1bb4091ab73ec7749bf340439be9c5385351','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58417ad65339679cf0540abd3529b0e7f464344e0aa75249cef9dfbae5c0cf45',1978,'CY','Cyprus','government',149,'Legal name: Republic of Cyprus
Type: republic since August 1960; separate de facto Greek
Cypriot, and Turkish Cypriot governments have evolved
since outbreak of communal strife in 1963; this separation
was further solidified following the Turkish invasion of the
island in July 1974; negotiations, which have been going on
since January 1975, have focused on the creation of a federal
system of government with substantial autonomy for each of
the two communities
Capital: Nicosia
Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil law
modifications; negotiations to create the basis for a new or
revised constitution to govern the island and relations
between Greek and Turkish Cypriots have been going on
intermittently
National holiday: Independence Day, 1 October
Branches: currently a rump government with effective
authority only over the Greek Cypriot community, consist-
ing of Greek Cypriot parts of bodies provided for by
constitution; headed by President of the Republic and
comprised of Council of Ministers, House of Representatives,
and Supreme Court, Turkish Cypriots have their own
“Constitution” and governing bodies within the “Federated
Turkish State of Cyprus”
Government leaders: President, Spyros Kyprianou, elect-
ed interim President in September 1977, to serve out the
remainder of the term of Archbishop Makarios who died on
3 August 1977 (Greek); Vice President, Rauf Denktash
(furk); Prime Minister, N’ejat Konuk
Suffrage: universal age 2] and over
Elections: officially every 5 years; Turkish Cypriot
“Presidential” and “Parliamentary” elections held June
1976; Greek Cypriot parliamentary elections held in
September 1976; Greek Cypriot presidential election to be
held in February 1978
Political parties and leaders: Restorative Party of the
Working People (AKEL) (Communist Party), Ezekias
Papaioannou; Democratic Rally (DR), Glafkos Clerides;
Democratic Party (DP) (pro-Makarios), Spyros Kyprianou;
United Democratic Union of the Center (EDEK), Vassos
Lyssarides; National Unity Party, Rauf Denktash; Populist
Party, Alper Orhon; Republican Turkish Cypriot Party,
Ahmet Berberoglou; Communal Salvation Party, Alpay
Durduran; Republic Turkish Cypriot Party (RTCP), Ozker
Ozgur
Voting strength: Rauf Denktash won the 1976 “‘Presiden-
tial” contest in the Turkish Cypriot zone with 76% of the
vote and his party won 30 of 40 seats in the “Assembly” with
54% of the vote; a pro-Makarios coalition composed of
AKEL, EDEK, and the DF received 75% of the vote in the
September 1976 Greek Cypriot parliamentary election and
34 of 35 seats while Clerides’ DM won 25% of the vote and
no seats; the remaining seat was given to an independent
50 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CYPRUS /CZECHOSLOVAKIA
Communists: 12,000; sympathizers estimated to number
60,000
Other political or pressure groups: United Democratic
Youth Organization (EDON) (Communist-controlled),; Pan
Cyprian Labor Federation (PEO) (Communist-controlled);
Cyprus Confederation of Labor (SEK) (pro-West); Cyprus
Turkish Federation of Trade Unions (KTIBF); Confeder-
ation of Revolutionary Worker Unions (DISK); Turkish-
Cypriot Federation of Labor Union
Member of: Commonwealth, Council of Europe, FAO,
G-77,GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF,
ITU, NAM, U.N., UNESCO, UPU, WHO, WMO
Legal name: Czechoslovak Socialist Republic (C.S.S.R.)
Type: Communist state
Capital: Prague
Political subdivisions: 2 ostensibly separate and nomi-
nally autonomous republics (Czech Socialist Republic and
Slovak Socialist Republic); 7 regions (kraj) in Czech lands,
three regions in Slovakia; national capitals of Prague and
Bratislava have regional status
Legal system: civil law system based on Austrian-
Hungarian codes, modified by Communist legal theory;
revised constitution adopted 1960, amended in 1968 and
1970; no judicial review of legislative acts; legal education at
Karlova University School of Law; has not accepted
compulsory [CJ jurisdiction
National holiday: Liberation Day, 9 May
Branches: executive—President (elected by Federal As-
sembly), cabinet (appointed by President); legislative—
Federal Assembly (elected directly), Czech and Slovak
National Councils (aiso elected directly) legislate on limited
area of regional matters; judiciary—Supreme Court (elected
by Federal Assembly); entire governmental structure domi-
nated by Communist Party
Government leaders: President Gustav Husak (elected
May 1975), Premier Lubomir Strougal
Suffrage: universal over age 18
Elections: governmental bodies every 5 years (last
election, October 1976); President every 5 years
Dominant political party and leader: Communist Party
of Czechoslovakia (KSC), Gustav Husak, General Secretary;
Communist Party of Slovakia (KSS) has status of “provincial
KSC organization”
Voting strength (1976 election): 99.7% for Communist-
sponsored single slate
Communists: 1.38 million party members (April 1976)
Other political groups: puppet parties—Czechoslovak
Socialist Party, Czechoslovak People’s Party, Slovak Free-
dom Party, Slovak Revival Party
Member of: CEMA, FAO, GATT, IAEA, ICAO, IDA,
IFC, ILO, International Lead and Zinc Study Group, IMCO,
IPU, ISO, ITC, ITU, U.N., UNESCO, UPU, Warsaw Pact,
WHO, WIPO, WMO, WSG','9fa92548d4355eed80ee0f19e9d3092666f30730d5bd043bb6975dbf38e901ae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37482be96f71766bde10229fe5487de81afcf1767c416c0ddce861d5ebf1bf9f',1978,'DK','Denmark','government',153,'Legal name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes, 88
towns
Legal system: civil law system; constitution adopted 1953;
judicial review of legislative acts; legal education at
Universities of Copenhagen and Arhus; accepts compulsory
IC] jurisdiction, with reservations
National holiday: Birthday of the Queen, 16 April
Branches: legislative authority rests jointly with Crown
and parliament (Folketing), executive power vested in
Crown but exercised by cabinet responsible to parliament;
Supreme Court, 2 superior courts, 106 lower courts
Government leaders: Queen Margrethe IJ; Prime Minis-
ter, Anker Jorgensen
Suffrage: universal, but not compulsory, over age 21
Elections: on call of prime minister but at least every four
years (last election 15 February 1977)
Political parties and leaders: Social Democratic, Anker
Jorgensen; Liberal, Poul Hartling; Conservative, Poul
Schluter; Radical Liberal, Kristen Helveg Petersen; Socialist
Peoples, Gert Petersen; Communist, Knud Jespersen; Left
Socialist, Preben Wilhjelm; Center Democratic, Erhard
Jakobsen; Christian People’s, Jens Moller; Justice, Ib
Christensen; Communist League Marxist-Leninest, Benito
Scocozza
Voting strength (1977 election): 37.5% Social Democratic,
14.3% Progressive, 12.3% Moderate Liberals, 8.3% Conserva-
tive, 6.4% Center Democratic, 3.9% Socialist Peoples, 3.7%
Communist, 3.6% Radical Liberal, 3.5% Christian, 3.2%
Justice, 2.7% Leftist Socialist
Communists: 7,500-8,000; a number of sympathizers, as
indicated by 114,034 Communist votes cast in 1977 elections
Member of: ADB, Council of Europe, DAC, EC, EEC,
ELDO (observer), EMA, ESRD, EURATOM, FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC, THO,
ILO, International Lead and Zinc Study Group, IMCO,
IMF, IPU, ISO, ITC, ITU, IWC—International Wheat
Council, NATO, Nordic Council, OECD, U.N., UNESCO,
UPU, WHO, WIPO, WMO, WSG','76828057e808e257d66096b6c464461a7e83bae457183d6788efdbc64bc098b0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8289c8c9b1bd782f8457b276c32bc33314fedd2d50cfdb7317bf5d674648b96c',1978,'DJ','Djibouti','government',157,'Legal name: Republic of Djibouti
Type: republic
Capital: Djibouti
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
DJIBOUTI/DOMINICA
Legal system: based on French civil law system,
traditional practices and Islamic law
Branches: 65-member parliament, cabinet, president,
prime minister
Government leader: President, Hassan Gouled
Suffrage: universal
Elections: Parliament elected May 1977
Political parties and leaders: National Independence
Union (UNI), Ali Aref Bourhan; African People’s Independ-
ence League (LPAI), Hassan Gouled and Ahmed Dini;
Popular Liberation Movement, Kamil Ali; Front for the
Liberation of the Somali Coast (FLCS); governing coalition
consists of the LPAI, the FLCS, and their Afar allies, elected
under the banner of the National Independence Rally (RNI)
Communists: possibly a few sympathizers
Member of: Arab League','7c1d81d669f9058c997f1187abda0e10715b1d5ce32f49889413252660425ec3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1122c6186321bb2d5a9f3ec0b4f0bf06f4cd6f491fcd7fb3807c6f3244ebca7',1978,'DM','Dominica','government',161,'Legal name: State of Dominica
Type: dependent territory with full internal autonomy as
a British “Associated State;” may become independent in
February 1978
Capital: Roseau
Political subdivisions: 10 parishes
Legal system: based on English common law; three local
magistrate courts and the British Caribbean Court of
Appeals
Branches: legislature, 11 member popularly elected
House of Assembly; executive, cabinet headed by Premier
Government leaders: Premier Patrick Roland John; U.K.
Governor Sir Louis Cools-Lartigue
Suffrage: universal adult suffrage over age 18
Elections: every 5 years; most recent March 1975
55
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
DOMINICA/DOMINICAN REPUBLIC
Political parties and leaders: Dominica Labor Party
(DLP), Patrick John; Dominica Freedom Party (DFP), Miss
M. Eugenia Charles (unofficial)
Voting strength: House of Assembly seats—DFP 3 seats,
DLP 16 seats, independent 2 seats
Communists: negligible
Member of: CARICOM','cf6c1c6e9d3b98708d66d2b9e793f8b4cf25b88cb6b40c14636771c0aa65a68c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7827c832adaa9917816e401aba5d4e8cfedd0b5c03fe820a272b61bf51173a5e',1978,'JM','Jamaica','government',165,'Legal name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 provinces and ‘the National
District
Legal system: based on French civil codes; 1966
constitution
National holiday: Independence Day, 27 February
Branches: President popularly elected for a 4-year term;
bicameral legislature consisting of Senate (27 seats) and
Chamber of Deputies (91 seats) elected for 4-year terms;
Supreme Court
Government leader: President Joaquin Balaguer
Suffrage: universal and compulsory, over age 18 or
married, except members of the armed forces and police,
who cannot vote
Elections: national, last election May 1974, next election
May 1978
Political parties and leaders: Reformist Party (PR),
Joaquin Balaguer; Dominican Revolutionary Party (PRD),
Francisco Pena Gomez, Dominican Liberation Party (PLD),
Juan Bosch; Democratic Quisqueyan Party (PQD), Elias
Wessin y Wessin; Revolutionary Social Christian Party
(PRSC), Rogelio Delgado Bogaert; Movement for National
Conciliation (MNC), Jaime Manuel Fernandez Gonzalez;
Anti-reelection Movement of Democratic Integration
(MIDA), Francisco Augusto Lora; National Civic Union
(UCN), Guillermo Delmonte Urraca; National Salvation
Movement (MSN), Luis Julian Perez; Popular Democratic
Party (PDP), Homero Lajara Burgos; Fourteenth of June
Revolutionary Movement (MR-1J4), split into several fac-
tions, illegal; Dominican Communist Party (PCD), central
56 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
DOMINICAN REPUBLIC/ECUADOR
committee, illegal; Dominican Popular Movement (MPD),
illegal; 12th of January National Liberation Movement
(ML-12E), Plinio Matos Moquete, illegal; Communist Party
of the Dominican Republic (PACOREDO), Luis Montas
Gonzalez, illegal; Popular Socialist Party (PSP), illegal
Voting strength (1974 election): 85% PR, 15% PDP, all
other parties abstained
Communists: an estimated 1,500 to 1,800 members in six
different factions; effectiveness limited by ideological
differences and organizational inadequacies
Member of: FAO, G-77, GATT, IADB, IAEA, IBA,
IBRD, ICAO, IDA, IDB, IFC, THO, ILO, IMCO, IMF,
1OOC, ISO, ITU, OAS, SELA, U.N., UNESCO, UPU, WHO,
WMO
Legal name: Jamaica
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Type: independent state within Commonwealth since
August 1962, recognizing Elizabeth II as head of state
Capital: Kingston
Political subdivisions: 12 parishes and the Kingston-St.
Andrew corporate area
Legal system: based on English common law; has not
accepted compulsory ICJ jurisdiction
National holiday: 7 August
Branches: cabinet headed by Prime Minister; 60-member
elected House of Representatives; 21-member Senate (13
nominated by the Prime Minister, 8 by opposition leader);
judiciary follows British tradition under a Chief Justice
Government leader: Prime Minister Michael Manley
Suffrage: universal, age 18 and over
Elections: at discretion of Governor-General upon advice
of Prime Minister but within 5 years; latest held 15
December 1976
Political parties and leaders: People’s National Party
(PNP), Michael Manley; Jamaica Labor Party (JLP),
Edward Seaga
Voting strength: (1976 general elections) 56.8% PNP,
43.2% JLP
Communists: a few hundred Marxist and Communist
sympathizers
Other political or pressure groups: New World Group
(Caribbean regionalists, nationalists, and leftist intellectual
fraternity); Rastafarians (Negro religious/racial cultists,
pan-Africanists); New Creation International Peacemakers
Tabernacle (leftist group); Workers Liberation League (a
Marxist coalition of students/labor)
Member of: CARICOM, FAO, G-77, GATT, IADB,
IAEA, IBA, IBRD, ICAO, IDB, IFC, ILO, IMF, ISO, ITU,
NAM, OAS, Pan American Health Organization, SELA,
U.N., UNESCO, UPU, WHO, WMO','1ff345f8bc31b0a2032ce223b14f6bdd20fa46c03c95f8cbb86e0fa87080156b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('568d9a0ac8551d4b795ee4e8d8517caf63d9c697843c04b6712723403de3c4f2',1978,'EC','Ecuador','government',169,'Legal name: Republic of Ecuador
National holiday: Independence Day, 10 August
Type: republic; under military regime since 1972
Capital: Quito
Political subdivisions: 20 provinces including Galapagos
Islands
Legal system: based on civil law system; modified 1945
constitution re-instituted in February 1972; legal education
at 4 state and 2 private universities; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 10 August
Branches: Supreme Council of Government, made up of
the three military chiefs, assumed power January 1976;
judiciary system supervised by Supreme Court; six special
tribunals established in July 1972
Government leader: President of Supreme Council
Admiral Alfredo POVEDA Burbano
Suffrage: universal for literates over age 18
Elections: popular referendum on a new constitution
scheduled for January 1978; will be followed by presidential
and parliamentary elections, with the new president to be
sworn in sometime during the summer
Political parties and leaders: National Velasquista Front,
Jose Maria Velasco Ibarra, personalistic; Radical Liberal
Party, Pedro Jose Arteta, Francisco Huerta, centrist;
Conservative Party (split), Rodrigo Suarez Morales, center
right; Julio Cesar Trujillo (Progressive), center left; Concen-
tration of Popular Forces, Assad Bucaram, populist; National
Revolutionary Party, Carlos Julio Arosemena, leftist: Chris-
tian Democrats, Osvaldo Hurtado, center left; Democratic
left, Rodrigo Borja, center left
Voting strength: in June 1968 national elections, Velas-
quistas, a center-left coalition, and a rightist coalition each
got approximately one-third
Communists: Communist Party of Ecuador (PCE, pro-
Moscow, Pedro Saad—secretary-general), 500 members plus
an estimated 3,000 sympathizers, Communist Party of
Ecuador (PCE/ML, pro-Peking), 100 members; Revolution-
ary Socialist Party of Ecuador (PSRE), 200 members
Member of: ECOSOC, FAO, G-77, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, THO, ILO, IMCO, IMF, ITU,
LAFTA and Andean Sub-Regional Group (formed in May
1969 within LAFTA), OAS, OPEC, SELA, U.N., UNESCO,
UPEB, UPU, WHO, WMO','ddd43543655d884fb04e2bf069f12b558891649c7973cfd13a892e89a8108537','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaf157e72da7f5599716c511a4dbd37e9059aa45c703083bf5cb10c6934ca873',1978,'EG','Egypt','government',173,'Legal name: Arab Republic of Egypt
Type: republic; under presidential rule since June 1956
Capital: Cairo
Political subdivisions: 25 governorates
Legal system: based on English common law, Islamic law,
and Napoleonic codes; permanent constitution written in
1971; judicial review of limited nature in Supreme Court,
also in Council of State which oversees validity of
administrative decisions, legal education at Cairo University;
accepts compulsory ICJ jurisdiction, with reservations
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
National holiday: National Day, 23 July
Branches: executive power vested in President, who
appoints cabinet; People’s Assembly has little actual power
(serves mainly for discussion and automatic approval);
independent judiciary administered by Minister of Justice
Government leader: President Anwar Sadat
Suffrage: universal over age 18
Elections: elections to People’s Assembly every 5 years
(most recent October 1976); presidential elections every 6
years (most recent September 1976)
Political parties and leaders: political parties banned
except for the government-endorsed political groupings
within the Arab Socialist Union (ASU)
Communists: approximately 500, party members
Member of: AAPSO, AFDB, Arab League, FAO, G-77,
GATT, IAEA, IBRD, ICAG, ICAO, IDA, IFC, IHO, ILO,
IMCO, IMF, LOOC, IPU, ITU, {wWC—International Wheat
Council, NAM, OAPEC, OAU, U.N., UNESCO, UPU,
WHO, WIPO, WMO, WPeC, WSG','f3b58da4534f06908c5c7085bccabc6a6dad5d1581b023d00aedc84b921266fa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('566b6733bc4524e22f97550d5a002273a02c1529c6e70346be058e01da69627e',1978,'SV','El Salvador','government',177,'Legal name: Republic of El Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
National holiday: Independence Day, 15 September
Branches; traditionally dominant executive, unicameral
legislature, Supreme Court
Government leader: President Arturo Armando Molina,
Carlos Humburto Romero takes office on 1 July 1977
Suffrage: universal over age 18
Elections: legislative elections every 2 years; presidential
elections every 5 years; presidential elections March 1977,
legislative and municipal elections March 1978
Political parties and leaders: National Conciliation Party
(PCN), President Arturo A. Molina, and replaced by Carlos
Jose Antonio Guzman; Communist Party of El Salvador
(PCES), illegal, Jorge Shafick Handal: National Revolution-
ary Movement (MNR), Dr. Guillermo Manuel Ungo;
National Democratic Union Party (PUDN), Communist
Front, Jorge Shafisk Handal, Francisco Roberto Lima, Julio
Ernesto Contreras, Julio Castro Belloso; Independent Demo-
cratic United Front (F UDI), Gen. Jose A. Medrano, Raul
Salaverria
Voting strength: February 1977 presidential election—
PCN 66%, PDC, PUDN, and MNR coalition, 34%; March
1976 legislative election—PCN, 54 seats; opposition parties
boycotted the election
Communists: 100 to 200 active members; sympathizers,
5,000
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
EL SALVADOR/EQUATORIAL GUINEA
Other political or pressure groups: the military; about
100 prominent families; General Confederation of Trade
Unions (CGS); Unifying Federation of Salvadoran Trade
Unions (FUSS), Communist dominated; Federation of
Construction and Transport Workers Unions (FESINCONS-
TRANS), independent; Catholic Church; Salvadoran Na-
tional Association of Educators (ANDES)
Member of: Central American Common Market (CACM),
FAO, G-77, IADB, IAEA, IBRD, ICAC, ICAO, IDA, IDB,
IFC, ILO, IMF, ITU, [WC —International Wheat Council,
OAS, ODECA, SELA, U.N., UNESCO, UPU, WHO, WMO','75fe73a2c15e4a4ca78bd0606d68fa4cf6bb908433fe1d89bf713b89b471edee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4244f16a0a80f111dfe009ab0f81d9017183760e320bf50194a8f7d669508b27',1978,'ET','Ethiopia','government',181,'Legal name: Ethiopia
Type: under military rule since mid-1974,; monarchy
abolished in March 1975, but republic not yet declared
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred to as
regional administrations)
Legal system: complex structure with civil, Islamic,
common and customary law influences; constitution sus-
pended September 1974; military leaders have promised a
new constitution but established no time frame for its
adoption; legal education at Addis Ababa University; has not
accepted compulsory ICJ jurisdiction
National holiday: Popular Revolution Commemoration
Day, 12 September
Branches: effective power exercised by Provisional
Military Administrative Council (PMAC), a group estimated
at 40-100 officers and enlisted men which operates on
committee system; predominantly civilian cabinet is ineffec-
tual and holds office at suffrance of military; legislature
dissolved September 1974; judiciary at higher levels based on
Western pattern, at lower levels on traditional pattern,
without jury system in either
Covernment leader: Lieutenant Colonel Mengistu Haile-
Mariam, Chairman of the Provisional Military Administra-
tive Council
Suffrage: universal over age 21
Elections: union dwellers’ association officials elected
October-December 1976
Political parties and leaders: Common front of Ethiopian
Marxist-Leninist organizations, encompassing five quasi-
official groups—All-Ethiopian Socialist Movement (Mel
Sone), Revolutionary Flame (seded), and three less impor-
tant ones
Communists: Ethiopian Communist Party is a small
group opposed to military government
Other political or pressure groups: important dissident
groups include Eritrean Liberation Front (ELF) and
Eritrean People’s Liberation Front (EPLF) in Eritrea;
Ethiopian People’s Revolutionary Party (EPRP), a socialist
underground movement in central and northern Ethiopia;
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
and Ethiopian Democratic Union (EDU), primarily an exile
group, although it has made some inroads inside Ethiopia;
several other dissident groups with ethnic or provincial bases
of support
Member of: AFDB, ECA, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, NAM, OAU, U.N.,
UNESCO, UPU, WHO, WMO','b37b04bddb79196621e33fe48b9b0816347b517fdd56061297bab699fa4103c6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b41ced5cb19ba45dbcf101ddeea88411ec8bbc9bab54f1e09f0b257041c187f1',1978,'DE','Germany','government',186,'Legal name: Colony of the Falkland Islands
“ The possession of the Falkland Islands has been disputed by the
U.K. and Argentina (which refers to them as the Malvinas) since
18383.
Type: British crown colony
Capital: Stanley
Political subdivisions: local government is confined to
capital
Legal system: English common law
Branches:
Council
Governor, Executive Council, Legislative
Government leader: Governor and Commander in Chief
Ernest G. Lewis (also High Commissioner for British
Antarctic Colony)
Suffrage: universal','63171daf08bd6c40cbbb70cefe58aed142bd24f1ddab39de1ed9312b78f2392b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('067c7c2467a359cd188d004c70f8fa3c7e3502d92bea5e9e45dd0be0c3691009',1978,'FO','Faroe Islands','government',189,'Legal name: The Faroe Islands
Type: self-governing province within the Kingdom of
Denmark; 2 representatives in Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, ] town
Legal system: based on Danish law; Home Rule Act
enacted 1948
Branches: legislative authority rests jointly with Crown,
acting through appointed High Commissioner, and _ provin-
cial parliament (Lagting) in matters of strictly Faroese
concern; executive power vested in Crown, acting through
High Commissioner, but exercised by provincial cabinet
responsible to provincial parliament
Government leaders: Queen Margrethe II; Prime Minis-
ter, Atli Dam; Danish Governor, Leif Groth
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years; next election 1981
(coincides with Danish elections)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Political parties and leaders: Peoples, Hakun Djurhuus,
Republican, Erlendur Patursson; Home Rule, Samuel
Petersen; Progressive, Kjartan Mohr; Social Democratic, Atli
Dam; Union, Kristian Djurhuus
Voting strength (1975 election): Social Democratic 25.8%,
Republican 22.5%, Peoples 20.5%, Union 19.1%, Home Rule
7.2%, Progressive 2.5%
Communists: insignificant number
Member of: Nordic Council','ed164e2b3bb8dc2e632e2aa1b9e9697e58b5d478500c8fc690f8618849789b5f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a6c360a3c70e327e0690f88a5fa737a090c98c1279051f1e50e7e5cb40f4bc8',1978,'FJ','Fiji','government',193,'Legal name: Dominion of Fiji
Type: independent state within Commonwealth; Eliza-
beth II recognized as head of state
Capital: Suva
Political subdivisions: 14 provinces
Legal system: based on British
National holiday: 10 October
Branches: executive—Prime Minister; _ legislative—
52-member House of Representatives; Alliance Party 36
seats, National Federation Party 15 seats; 1 independent
Government leader: Prime Minister Ratu Sir Kamisese
Mara
Suffrage: universal adult
Elections: every 5 years unless House dissolves earlier, last
held September 1977
January 1978
Political parties: Alliance, primarily Fijian, headed by
Ratu Mara; National Federation, primarily Indian, headed
by Mrs. Irene Nayaran
Communists: few, no figures available
Member of: ADB, Colombo Plan, Commonwealth, FAO,
G-77, GATT (de facto), IBRD, ICAO, IDA, IMF, Iso, ITU,
U.N., UPU, WHO, WIPO','6a8fd64a1d627c84924f3141cb137df9b65414b266086d363308635001e96c8d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd389962dbcaba67c0640b81c232ac768dfa6446288a81afacd38eac333d4a83',1978,'FI','Finland','government',197,'Legal name: Republic of Finland
Type: republic
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Capital: Helsinki
Political subdivisions: 12 provinces; 443 communes, 78
towns
Legal system: civil law system based on Swedish law;
constitution adopted 1919; Supreme Court may request
legislation interpreting or modifying laws; legal education at
Universities of Helsinki and Turku; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Independence Day, 6 December
Branches: legislative authority rests jointly with President
and parliament (Eduskunta); executive power vested in
President and exercised through cabinet responsible to
parliament; Supreme Court, 4 superior courts, 193 lower
courts
Government leader: President Urho K. Kekkonen; Prime
Minister Kalevi Sorsa
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1979);
presidential, every 6 years (extraordinary parliamentary
legislation extended President Kekkonens term, which
normally expires in 1974, to 1978)
Political parties and leaders: Social Democratic, Rafael
Paasio; Center, Johannes Virolainen; Peoples Democratic
League (Communist front), Ele Alenius; Conservative, Harri
Holker; Liberal, Pekka Tarjanne; Swedish Peoples Party,
Kristan Gestrin; Rural, Veikko Vennamo; Finnish People’s
Unity Party, Eino Haikala; Communist, Aarne Saarinen
Voting strength (1975 election): 25% Social Democratic,
18.4% Conservative, 19.0% Peoples Democratic League,
17.7% Center, 3.6% Rural, 4.7% Swedish Peoples, 4.4%
Liberals, 3.3% Christian Peoples
Communists: 43,000; an additional 65,000 persons belong
to Peoples Democratic League; a further number of
sympathizers, as indicated by 438,757 votes cast for Peoples
Democratic League in 1975 elections
Member of: ADB, CEMA (special cooperation agree-
ment), DAC, EC (free trade agreement), EFTA (associate),
FAO, GATT, IAEA, IBRD, ICAC, ICAO, ICES, IDA, IFC,
IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, ITU, IWC —International Wheat Coun-
cil, Nordic Council, OECD, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG','e9c715afdbecbded7055437ddfb0cde90e4e4640fe48e10222a07d3aa90aa0dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('417493b826e56dfd60a86d1bb5cc987f0ab9d6232cb30a29b1f8a551c6114d46',1978,'FR','France','government',199,'Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 95 metropolitan departments, 21
regional economic districts
Legal system: civil law system with indigenous concepts;
new constitution adopted 1958, amended concerning elec-
tion of President in 1962; judicial review of administrative
but not legislative acts; legal education at over 25 schools of
law
National holiday: National Day, 14 July
Branches: presidentially appointed Prime Minister heads
Council of Ministers, which is formally responsible to
National Assembly; bicameral legislature—National Assem-
bly (490 members), Senate (295 members) restricted to a
delaying action; judiciary independent in principle
Government leader: President Valery Giscard d’Estaing
Suffrage: universal over age 18; not compulsory
Elections: National Assembly—every 5 years, last election
March 1973, direct universal suffrage, 2 ballots; Senate—
indirect collegiate system for 9 years, renewable by
one-third every 3 years, last election September 1977;
President—years, direct, universal suffrage every 7 years, 2
ballots, last election May 1974
Political parties and leaders: Majority Coalition—Rally
for the Republic (RPR, formerly UDR), Jacques Chirac;
Independent Republicans (IR), Jean-Pierre Soisson; Center-
for Social Democrats (CDS), Jean Lecanuet; Radical Socialist
(RS), Jean-Jacques Servan-Schreiber; Left Opposition—
Socialist Party (PS), Francois Mitterrand; Communist Party
(PCF), Georges Marchais; Left Radical Movement (MRG),
Robert Fabre; Unified Socialist Party (PSU), Michel Mousel
Voting strength (first ballot, 1974 election): 43.2%
Communist /Socialist Alliance, 32.6% IR, 15.1% UDR, 9.1%
other
Communists: 600,000 claimed; Communist voters, 5
million average
Other political or pressure groups: Communist-con-
trolled labor union (Confederation Generale du Travail)
nearly 2.4 million members (claimed); Socialist leaning labor
union (Confederation Francais du Travail) about 800,000
members est.; Independent labor union (Force Ouvriere)
about 800,000 members est.; Independent white collar union
(Confederation Generale “des Cadres) 200,000 members
(claimed); National Council of French Employers (Conseil
National du Patronat Francais—CNPF or Patronat)
Member of: ADB, Council of Europe, DAC, EC, ECSC,
EEC, EIB, ELDO, EMA, ESRO, EURATOM, FAO, GATT,
IAFA, IATP, IBRD, ICAC, ICAO, ICES, IDA, IFC, THO,
ILO, International Lead and Zinc Study Group, IMCO,
IMF, IOOC, IPU, ISO, ITC, ITU, IWC—International
Whaling Commission, NATO (signatory), OAS (observer),
OECD, South Pacific Commission, U.N., UNESCO, UPU,
WEU, WHO, WIPO, WMO, WSG
Legal name: Colony of Southern Rhodesia
Type: self-proclaimed independent state since 1965 (not
recognized by U.S.); provisional settlement with U.K. in
November 1971 cancelled by U.K. in May 1972 in response
to Pearce Commission’s conclusion that its terms were
unacceptable to the majority of black Rhodesians; a
conference in Geneva in late 1976, failed to agree on a new
multiracial interim government in Rhodesia to govern the
country during a transition to black majority rule
Capital: Salisbury
Political subdivisions: 11 magisterial districts
Legal system: Smith government implemented a republi-
can constitution on 2 March 1970 which institutionalized
white rule
Branches: President Wrathall is ceremonial head of state;
executive council (cabinet) lead by Prime Minister Smith;
National Assembly gives highly disproportionate representa-
tion to white minority—50 white constituency seats and 16
black constituency seats
Government leaders: Prime Minister Ian Smith and
President John Wrathall
Suffrage: franchise is based on income, property holdings,
and education; there are separate rolls for Africans and
non-Africans
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front, Prime
Minister Smith; Rhodesian Action Party, Ian Sandeman;
National Unifying Force, Allan Savory; Zimbabwe United
People’s Party, Jeremiah Chirau
Voting strength (1974 elections): Rhodesian Front won all
50 white constituency seats in Parliament in August 1974
elections
Communists: negligible
Other pressure groups and leaders: black nationalists are
badly divided—Joshua Nkomo and Robert Mugabe are
loosely allied in the Patriotic Front; Ndabaningi Sithole is
challenging Mugabe’s leadership of the Zimbabwe African
National Union faction; Abel Muzorewa heads the African
National Council
Member of: ITU','45f9b60fde6080afb5cffa2fb9f9459de0c87b6b1e383c47ee8b7c77a8eb98b8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23673e16324438b685043394ac14b736a978c8d101d97349fe985f9b6babcea0',1978,'GF','French Guiana','government',204,'Legal name: Overseas Department of French Guiana
Type: overseas department and region of France;
represented by one deputy in French National Assembly and
one senator in French Senate
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19 communes
each with a locally elected municipal council
Legal system: French legal system; highest court is Court
of Appeal based in Martinique with jurisdiction over
Martinique, Guadeloupe, and French Guiana
Branches: executive: prefect appointed by Paris; legisla-
tive: popularly elected 16-member General Council and a
Regional Council composed of members of the local General
Council and of the locally elected deputy and senator to the
French parliament; judicial, under jurisdiction of French
judicial system
Government leader: Prefect Herve Bourseiller
Suffrage: universal over age 18
Elections: General Council elections normally are held
every 5 years; last election March 1976; local elections last
held March 1977
Political parties and leaders: Parti Socialiste Guyanais
(PSG), Leopold Heder, Senator; Union du Peuple Guyanaise
(UPG), weak leftist allied with, but also reported, to have
been absorbed by the PSG; Rassemblement Pour La
Republique (RPR), Hector Rivierez, delegate to French
National Assembly
Communists: Communist party membership negligible
Legal name: Territory of French Polynesia
Type: overseas territory of France, administered by
French Ministry for Overseas Territories
Capital: Papeete
Political subdivisions: 5 districts
Legal system: based on French; lower and higher courts
Branches: 33-member Territorial Assembly, popularly
elected; 5-member Council of Government, elected by
Assembly; popular election of one deputy to National
Assembly in Paris, also one Senator
Government leader: Charles Schmitt, Governor, ap-
pointed by French government
Suffrage: universal adult
Elections: every 5 years, May 1977
Political parties and leaders: Le Front Uni, autonomist
coalition, Francis Sanford; Tahoeraa Hairaatira, conservative
Gaullist, Gaston Flosse
Voting strength (1977 election): Le Front Uni, 14 seats;
Tahoerra Huiraatira, 10 seats; Independents, 9 seats
Legal name: Gabonese Republic
Type: republic; one-party presidential regime since 1964
Capital: Libreville
Political subdivisions: 9 provinces subdivided into 36
prefectures
Legal system: based on French civil law system and
customary law; constitution adopted 1961; judicial review of
legislative acts in Constitutional Chamber of the Supreme
Court; legal education at Center of Higher and Legal Studies
at Libreville; compulsory IC] jurisdiction not accepted
National holiday: 17 August
Branches: power centralized in President, elected by
universal suffrage for 7-year term; unicameral 70-member
National Assembly has limited powers; judiciary
Government leader: President Omar Bongo
Suffrage: universal over age 21
Elections: Presidential and parliamentary elections last
held February 1973
Political parties and leaders: Gabonese Democratic Party
(PDG) led by President Bongo is only legal party
Communists: no organized party; probably some Com-
munist sympathizers
Member of: AFDB, Conference of East and Central
African States, EAMA, EIB (associate), FAO, G-77, GATT,
IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, IPU, ITU, NAM,
OAU, OPEC, UDEAC, UN., UNESCO, UPU, WHO,
WIPO, WMO
Legal name: Republic of The Gambia
Type: republic; independent since February 1965
Capital: Banjul
Political subdivisions: Banjul and 5 divisions
Legal system: based on English common law and
customary law; constitution came into force upon independ-
ence in 1965, new republican constitution adopted in April
1970; accepts compulsory IC] jurisdiction, with reservations
National holiday: 18 February
Branches: cabinet of 11 members, 41-member House of
Representatives, in which 4 seats are reserved for chiefs, 4
are appointed, 32 are filled by election for 5-year terms, a
Speaker is elected by the House, and the Attorney General is
an ex officio member; independent judiciary
Government leader: Dawda K. Jawara, President
Political parties and leaders: People’s Progressive Party
(PPP), Secretary General Dawda K. Jawara, United Party
(UP), John Forster, and National Convention Party, Sherrif
Dibba
Suffrage: universal adult
Elections: general elections held April 1977; PPP 27 seats,
NCP 5 seats, UP 2 seats
Communists: insignificant number
Member of: AFBD, APC, Commonwealth, ECA,
ECOWAS, FAO, G-77, GATT, IBRD, IDA, IMF, NAM,
OAU, U.N., WHO
73
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
THE GAMBIA/GERMAN DEMOCRATIC REPUBLIC
Legal name: German Democratic Republic
Type: Communist state
Capital: East Berlin (not officially recognized by US.,
U.K., and France, which together with the U.S.S.R. have
special rights and responsibilities in Berlin)
Political subdivisions: (excluding East Berlin) 14 districts
(Bezirke), 218 counties (Kreise), 7,643 communities
(Gemeinden)
Legal system: civil law system modified by Communist
legal theory; new constitution adopted 1974; court system
parallels administrative divisions; no judicial review of
legislative acts; legal education at Universities of Berlin,
Leipzig, Halle and Jena; has not accepted compulsory IC]
jurisdiction; more stringent penal code adopted 1968,
amended in 1974
National holiday: Foundation of German Democratic
Republic, 7 October
Branches: legislative—Volkskammer (elected directly);
executive—Chairman of Council of State, Chairman of
Council of Ministers, Cabinet (approved by Volkskammer);
is Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
CERMAN DEMOCRATIC REPUBLIC/GERMANY, FEDERAL REPUBLIC OF
judiciary—Supreme Court; entire structure dominated by
Socialist Unity (Communist) Party
Government leaders: Chairman, Council of State, Erich
Honecker (Head of State); Chairman, Council of Ministers,
Willi Stoph (Head of Government)
Suffrage: all citizens age 18 and over
Elections: national every 5 years; prepared by an electoral
commission of the National Front; ballot supposed to be
secret and voters permitted to strike names off ballot; more
candidates than offices available; parliamentary elections
held 17 October 1976
Political parties and leaders: Socialist Unity (Commu-
nist) Party (SED), headed by General Secretary Erich
Honecker, dominates the regime; 4 token parties (Christian
Democratic Union, National Democratic Party, Liberal
Democratic Party, and Democratic Peasant’s Party) and an
amalgam of special interest organizations participate with
the SED in National Front
Voting strength: 1976 parliamentary elections: 99.86%
voted the regime slate; 1970 local elections: 99.85% voted the
regime slate
Communists: 1.9 million party members
Other special interest groups: Free German Youth, Free
German Trade Union Federation, Democratic Women’s
Federation of Germany, German Cultural Federation (all
Communist dominated)
Member of: CEMA, ICES, IPU, ITU, U.N., UNESCO,
UPU, Warsaw Pact, WHO, WIPO
Legal name: Federal Republic of Germany
Type: federal republic
Capital: Bonn
Political subdivisions: 10 Laender (states); Western
sectors of Berlin are ultimately controlled by U.S., U.K., and
France which, together with the U.S.S.R., have special rights
and responsibilities in Berlin
Legal system: civil law system with indigenous concepts;
constitution adopted 1949; judicial review of legislative acts
in the Supreme Federal Constitutional Court; has not
accepted compulsory ICJ jurisdiction
Branches: bicameral parliament—Bundesrat (upper
house), Bundestag (lower house); President (titular head of
state), Chancellor (executive head of government);
independent judiciary
Government leaders: President, Walter Scheel; Chancel-
lor, Helmut Schmidt leads coalition of Social Democrats and
Free Democrats
Suffrage: universal over age 18
Elections: next national election scheduled for fall of 1980
Political parties and leaders: Christian Democratic
Union/Christian Social Union (CDU/CSU), Helmut Kohl,
Franz-Josef Strauss, Karl Carstens, Kurt Biedenkopf; Social
Democratic Party (SPD), Willy Brandt, Hans Koschnick,
Helmut Schmidt; Free Democratic Party (F DP), Hans-Die-
trich Genscher, Hans Friderichs, Wolfgang Mischnick;
National Democratic Party (NPD), Martin Mussgnug;
Communist Party (DKP), Herbert Mies
Voting strength (1976 election): 42.6% SPD, 48.6%
CDU/CSU, 7.9% FDP, 0.9% Splinter groups of left and right
(no parliamentary representation)
Communists: about 40,000 members and supporters
Other political or pressure groups: expellee, refugee, and
veterans groups
Member of: ADB, Council of Europe, DAC, EC, ECSC,
EIB, ELDO, EMA, ESRO, EURATOM, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC, THO, Interna-
tional Lead and Zinc Study Group, IMCO, IMF, IPU, ITC,
ITU, NATO, OAS (observer), OECD, U.N., UNESCO, UPU,
WEU, WHO, WIPO, WMO, WSG','c0198286b844ac6e26a7bf3acc90e55a9c626dbe328bb6f0715f888fbaa10085','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d8d7b4381acae03ce48c07da36151efd62b1f054ef5ca280853158931ae829b',1978,'GI','Gibraltar','government',208,'Legal name: Colony of Gibraltar
Type: U.K. colony
Capital: none
Legal system: English law; constitutional talks in July
1968; new system effected in 1969 after electoral enquiry
Branches: parliamentary system comprised of the Gibral-
tar House of the Assembly (15 elected members and 3 ex
officio members), the Council of Ministers headed by the
Chief Minister, and the Gibraltar Council; the Governor is
appointed by the Crown
Government leaders: Governor and Commander in
Chief, Marshall of the RAF Sir John Grandy, Chief Minister,
Sir Joshua Hassan
Suffrage: all adult Gibraltarians, plus other U.K. subjects
resident 6 months or more
Elections: every 5 years; last held in September 1976
Political parties and leaders: Labor, Sir Joshua Hassan;
Democratic Movement, Joe Boscano
Voting strengths: (September 1976) Labor, 8 seats;
Democratic Movement, 4 seats; independents, 3 seats
Communists: negligible
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GIBRALTAR/GILBERT ISLANDS
Other political or pressure groups: the Housewives
Association; the Chamber of Commerce; Gibraltar Repre-
sentatives Organization
Legal name: Gilbert Islands Colony
Type: British crown colony with large measure of
self-government
Capital: Tarawa
Branches: 20-member House of Assembly elects a Chief
Minister
Government leader: Governor John H. Smith; Chief
Minister, Naboua Ratieta
Political parties and leaders: Gilbertese National Party,
Christian Democratic Party
Member of: ADB
79
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GILBERT ISLANDS/GREECE','9d7e0cb5ed9b94fd1a519dffcbe1aac3a4f2058fe42d7718b10139c042eb48b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f347be222c5efc6c268f9a6ce30b9ff93d9878a46714c56f808c3d69428a3cd5',1978,'GR','Greece','government',212,'Legal name: Hellenic Republic
Type: presidential parliamentary government; monarchy
rejected by referendum December 8, 1974
Capital: Athens
Political subdivisions: 52 departments (nomoi) constitute
basic administrative units for country; each nomos headed
by officials appointed by central government and policy and
programs tend to be formulated by central ministries; degree
of flexibility each nomos may have in altering or avoiding
programs imposed by Athens depends upon tradition
(Thessaloniki and other areas exercise considerable tradi-
tional autonomy in local administrative decisions) and
influence which prominent local leaders and citizens may
exercise vis-a-vis key figures in central government
Legal system: new constitution enacted in June 1975
National holiday: Independence Day, 25 March
Branches: executive consisting of a President {to be
elected by Parliament) and a Prime Minister and cabinet;
legislative comprising the 300-member Parliament; inde-
pendent judiciary
Government leaders: President Constantine Tsatsos;
Prime Minister Constantine Caramanlis
Suffrage: universal age 21 and over
Elections: every 4 years; the government called for early
elections to be held on 20 November 1977
Political parties and leaders: Union of the Democratic
Center, George Mavros; New Democracy, Constantine
Caramanlis; Panhellenic Socialist Movement, Andreas
Papandreou; Communist Party—Exterior, Harilaos Florakis;
Communist Party—Interior, Haralambos Drakopoulos; and
the United Democratic Left, Ilias Iliou; Socialist Initiative,
George Mangakis; Socialist March; Christian Democracy;
Nationalist Camp, Stephanos Stephanopoulos
Voting strength: New Democracy, 215 seats; Union of the
Democratic Center, 57 seats; Panhellenic Socialist Move-
ment, 15 seats; Communists, 8 seats; independent, 5 seats
Communists: an estimated 25,000-30,000 members and
sympathizers
0 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
GREECE/GREENLAND
Member of: EC (associate), EIB (associate), EMA, GATT,
FAO, IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO, IMCO,
IMF, IOOC, ITU, {WC —International Wheat Council,
NATO, OECD, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG','1ae069dd909966f129b949e8483bf44864de5617a47a82870dcbcb3c2ce19728','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c577b21e59e7d49feb96151094d29337ebd2f36d6986ba5336abdbf1942813e',1978,'GL','Greenland','government',216,'Legal name: Greenland
Type: province of Kingdom of Denmark; 2 representa-
tives in Danish parliament; separate Minister for Greenland
in the Danish cabinet
Capital: Godthaab (administrative center)
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from colony to
province in 1953
Branches: legislative authority rests jointly with Crown
and Danish parliament; executive power vested in Crown,
acting through provincial governor responsible to Minister
for Greenland; local affairs handled by provincial council
(Landsrad) subject to approval of provincial governor: 19
lower courts
Government leader: Queen Margrethe II, Governor Hans
Lassen
Suffrage: universal, but not compulsory, over age 2]
Elections: held every 4 years (next 1981—coincides with
Danish elections)
Political parties: Inuit (advocating close ties with
Denmark); Sukaq (moderate socialist, advocating more
distinct Greenland identity); Siumut (a more radical party
advocating greater autonomy from Denmark)','62910bb9bbe34f5801781bf25a46c71d9f06eba0e6dca616754ed77372bc5456','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a994571474755990abda6d04b95f48b2a08099063717d45a2e8cbdc1f8106303',1978,'GD','Grenada','government',220,'Legal name: Grenada
Type: independent state since February 1974, recognizes
Elizabeth II as Chief of State
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
National holiday: Independence Day, 7 February
Branches: legislative branch consists of 15-member
elected House of Representatives and 13-member Senate
appointed by the Governor; executive branch is cabinet led
by Prime Minister
Government leaders: Prime Minister Sir Eric Matthew
Gairy; U.K. Governor General Leo de Gale
Suffrage: universal adult suffrage
Elections: every 5 years; most recent general election 7
December 1976
Political parties and leaders: Grenada United Labor
Party (GULP), Eric Matthew Gairy; Peoples Alliance—a
coalition consisting of the New Jewel Movement (NJM),
Maurice Bishop; United People’s Party (UPP), Winston
Whyte; Grenada National Party (GNP), Herbert A. Blaize
Voting strength (1976 election): GULP 51.7%, Peoples
Alliance, 48.3%; Legislative Council seats, GULP 9, Peoples
Alliance 6 (NJM 38, UPP 1, GNP 1, unaffilated 1)
Communists: negligible
Member of: CARICOM, G-77, IMF, OAS, SELA, U.N.','5077a171972dfbb5c81da068b8630e4da706e5f2dc12afc7668f55ba5d83cf90','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d14895bd2d6280512633720badee51833c582439e31855968dbc2489524fdb3',1978,'GP','Guadeloupe','government',224,'Legal name: Overseas Department of Guadeloupe
Type: overseas department and region of France;
represented by 3 deputies in the French National Assembly
and 2 Senators in the Senate
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34 communes,
each with a locally elected municipal council
Legal system: French legal system; highest court is a
court of appeal based in Martinique with jurisdiction over
Guadeloupe, French Guiana, and Martinique
Branches: executive, Prefect appointed by Paris; legisla-
tive, popularly elected General Council of 36 members and
a Regional Council composed of members of the local
General Council and the locally elected deputies and
senators to the French parliament; judicial, under jurisdic-
tion of French judicial system
Government leader: Prefect Paul Noirot Cosson
Suffrage: universal over age 18
Elections: General Council elections are held normally
every 5 years; last General Council election took place in
March 1976; local election Jast held March 1977
Political parties and leaders: Rassemblement Pour la
Republique (RPR), Gabriel Lisette; Communist Party of
Guadeloupe (PCG), Henri Bangou; Socialist Party (MSG),
leader unknown; Progressive Party of Guadeloupe (PPG),
Henri Rodes; Independent Republicans; Federation of the
Left
Voting strength: MSG, 1 seat in French National
Assembly; UDG, 2 seats; (1973 election)
Communists: 3,000 est.
Other political or pressure groups: Group of National
Organization of Guadeloupe (GONG)','eb7f362aa27d84fac2e8e123e881f30c0ca7e823e38d71fa229e5b3b1e9663ed','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ce88eb5506688f8b495b6e24d25802f12459ee307b557ea975144b8e3d1827a',1978,'GT','Guatemala','government',228,'Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system: civil law system; constitution came into
effect 1966; judicial review of legislative acts; legal
education at University of San Carlos of Guatemala; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 15 September
Branches: traditionally dominant executive; elected uni-
cameral legislature; 7-member (minimum) Supreme Court
Government leader: President Kjell Laugerud
Suffrage: universal over age 18, compulsory for literates,
optional for illiterates
Elections: next elections (President and Congress) 1978;
President cannot succeed himself; Presidential candidates
are General Fernando Romeo Lucas (PID/PR), General
Ricardo Peralta Mendez (DCG), Colonel Enrique Peralta
Azurdia (MLN)
Political parties and leaders: Democratic Institutional
Party (PID), Donaldo Alvarez Ruiz; Revolutionary Party
(PR), Jorge Garcia-Granados Quinonez (secretary general);
National Liberation Movement (MLN), Mario Sandoval
Alarcon; Guatemalan Christian Democratic Party (DCG),
Vinicio Cerezo Arevalo (sec. gen.); Rene de Leon Schlotter
(honorary President and party strongman); several unregis-
tered parties
Voting strength: for President—MLN-PID 298,953
(44.6%), DCG 228,067 (34.0%), PR 143,111 (21.4%); for
congressional seats—MLN-PID 36, DCG 15, PR 10
Communists: Communist party outlawed; underground
membership estimated at 750
Other political or pressure groups: outlawed (Commu-
nist) Guatemalan Labor Party (PGT), Eleuterio Cabrera
Mejia (provisional secretary general)
Member of: CACM, FAO, G-77, IADB, IAEA, IBRD,
ICACG, ICAO, IDA, IDB, IFC, IHO, ILO, IMF, ISO, ITU,
IWC — International Wheat Council, OAS, ODECA, SELA,
U.N., UNESCO, UPEB, UPU, WHO, WMO','1ee0ffa3ada1a4f8aff29731bcbf5f77a70b81d89c3997ab125565cdbe98d35d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e0787a2ed8fa8f9ab9492540aa5ff43bb0244cd715530a9b16279e7948d9716',1978,'GW','Guinea-Bissau','government',232,'Legal name: Republic of Guinea-Bissau
Type: republic; achieved independence from Portugal in
September 1974; constitution promulgated 1974
Capital: Bissau
Political subdivisions: 9 municipalities, 3. circumscrip-
tions (predominantly indigenous population)
Legal system: to be determined
National holiday: 12 September
Branches: National Popular Assembly to be elected for
three-year term; Council of State Commissars, 16 members;
the official party is the supreme political institution.
Government leaders: President of Council of State and
Chief of State is Luis Cabral; Principal Commissar and Head
of Government, Francisco Mendes; Secretary General of the
Official party, Aristides Pereira
Suffrage: universal over age 18
Elections: none held to date
Political parties and leaders: Partido Africano da
Independencia da Guinee e Cabo Verde (PAIGC), led by
Aristide Pereira, only legal party; Front de Lutte pour
l''Independence Nationale de la Guinea (FLING), a largely
dormant, loose coalition of nationalist elements opposed the
PAIGC, leadership fragmented
Communists: none known
Member of: G-77, NAM, OAU, U.N., UPU','8eabdc63f666087c69147b6c077080ed9b64c4baab758040f3243c884f16f1a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccb62f894ed53eed6c5dba0cd0939d163e935bbcdb746896b576c6015980afae',1978,'HT','Haiti','government',236,'Legal name: Republic of Haiti
Type: republic under the 14-year dictatorship of Francois
Duvalier who was succeeded upon his death on 21 April
1971 by his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite constitu-
tional provision for 9)
Legal system: based on Roman civil law system;
constitution adopted 1964 and amended 1971; legal educa-
tion at State University in Port-au-Prince and private law
colleges in Cap-Haitien, Les Cayes, Gonaives, and Jeremie;
accepts compulsory ICJ jurisdiction
National holiday: Independence Day, 1 January
Branches: lifetime President, unicameral 58-member
legislature of very limited powers, judiciary appointed by
President
President-for-life Jean-Claude
Government _ leader:
Duvalier
Suffrage: universal over age 18
Elections: constitution as amended in 1971 provides for
lifetime president to be designated by his predecessor and
ratified by electorate in plebiscite; legislative elections,
which are held every 6 years, last held February 1973
89
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
HAITI/HONDURAS
Political parties: National Unity Party, only legal party;
United Haitian Communist Party (PUCH), illegal (Com-
munist)
Voting strength (1973 legislative elections); 100% Na-
tional Unity Party (Duvalier)
Communists: strength unknown; party leaders believed in
exile
Other political or pressure groups: none
Member of: FAO, G-77, GATT, IADB, IAEA, IBA,
IBRD, ICAO, IDA, IDB, IFC, ILO, IMCO, IMF, ITU, OAS,
SELA, U.N., UNESCO, UPU, WHO, WMO','ffd77fda20dba595dfaf38db50600b4e60a775669945675c9b46c2a6c37eb576','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c7f5560346bf4ce0e3af2f7f3517ca5e5825a1941f501a1a514717e845eb3ff',1978,'HN','Honduras','government',240,'Legal name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: based on Roman and Spanish civil law;
some influence of English common law; constitution
adopted 1965; judicial review of legislative acts in Supreme
Court; legal education at University of Honduras in
Tegucigalpa; accepts compulsory IC] jurisdiction, with
reservations
National holiday: Independence Day, 15 September
Branches: constitution provides for elected President,
unicameral legislature, and national judicial branch
Government leader: Juan Alberto Melgar Castro
Suffrage: universal and compulsory over age 18
Elections: government Jeaders have indicated an inten-
tion to hold elections in 1979
Political parties and leaders: all parties, even legal ones,
are dormant at present; Liberal Party (PLH), Modesto Rodas
Alvarado, Carlos Roberto Reina Idiaguez, Jorge Bueso Arias;
National Party (PNH), Alejandro Lopez Cantarero, Ricardo
Zuniga Augustinus; Mario Rivera Lopez, Martin Aquero;
Popular Progressive Party (PPP) (uninscribed), Gonzalo
Carias Castillo; National Innovation and Unity Party (PINU)
(uninscribed), Miguel Andonie Fernandez; Workers Party of
Honduras (PTH) (Communist) (uninscribed), Rogue Ochoa;
Communist Party of Honduras/Soviet (PCH/S-outlawed),
Dionisio Ramos Bejarano; Communist Party of Honduras/
China (PCH/C-outlawed), Agapito Robledo Castro
Voting strength (1971 elections): National Party (PNH)
306,028; Liberal Party (PLH) 276,777
Communists: about 650; 500 sympathizers
Other political or pressure groups: National Association
of Honduran Campesinos (ANACH); Council of Honduran
Private Enterprise (COHEP); Confederation of Honduran
Workers (CTH)
Member of: CACM, FAO, G-77, IADB, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMCO, IMF, ISO, ITU, OAS, U.N.,
UNESCO, UPEB, UPU, WHO, WMO','69757c58bd060233b95daef850041b2fc55ee60f497cffb8f039bd16c0c90c09','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1dc56e4e3fab439ef4d3f108e32fcf29249076231e49c0d1a9856036f685e363',1978,'HU','Hungary','government',246,'Legal name: Hungarian Peoples Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 megyes (counties), 5 autono-
mous cities in county status, 97 jaras (districts)
Legal system: based on Communist legal theory, with
both civil law system (civil code of 1960) and common law
elements; constitution adopted 1949 amended 1972; Su-
preme Court renders decisions of principle that sometimes
have the effect of declaring legislative acts unconstitutional;
legal education at Lorand Eotvos Tudomanyegyetem School
of Law in Budapest and 2 other schools of law; has not
accepted compulsory IC] jurisdiction
National holiday: Anniversary of the Liberation, 4 April
Branches: executive—Presidential Council (elected by
Parliament); legislative—Parliament (elected by direct
suffrage); judicial—Supreme Court, (elected by Parliament)
Government leaders: Gyorgy Lazar, Chairman, Council
of Ministers; Pal Losonczi, President, Presidential Council
Suffrage: universal over age 18
Elections: every 5 years; national and local elections are
held separately
Political parties and leaders: Hungarian Socialist (Com-
munist) Workers Party (sole party); Janos Kadar is First
Secretary of Central Committee
Voting strength (1975 election): 7,497,061 (99.6 %) for
Communist-approved candidates; 30,108 (0.4%) invalid and
negative votes; total eligible electorate about 7.76 million;
next elections will be held in 1980
Communists: about 754,000 party members (March 1975)
Member of: CEMA, Danube Commission, FAO, GATT,
IAEA, ICAC, ICAO, ILO, International Lead and Zinc
Study Group, IMCO, IPU, ISO, ITC, ITU, U.N., UNESCO,
UPU, Warsaw Pact, WHO, WIPO, WMO','904a85ad94509fb2675427bf8c9075531c6e506b1099895588f4da3cb47cd287','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81fa50bd5886e8c3e1476f3037f14ab698151914e36a580700d342e3990082bd',1978,'IS','Iceland','government',250,'Legal name: Republic of Iceland
Type: republic
Capital: Reykjavik
Political subdivisions: 23 rural districts, 215 parishes, 14
incorporated towns
Legal system: civil law system based on Danish law;
constitution adopted 1944; legal education at University of
Iceland; does not accept compulsory ICJ jurisdiction
National holiday: Anniversary of the Establishment of
the Republic, 17 June
Branches: legislative authority rests jointly with President
and parliament (Althing); executive power vested in
President but exercised by cabinet responsible to parliament;
Supreme Court and 29 lower courts
Government leaders: President Kristjan Eldjarn; Prime
Minister Geir Hallgrimsson
e Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ICELAND/INDIA
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in (1978);
presidential, every 4 years
Political parties and leaders: Independence (conserva-
tive), Geir Hallgrimsson; Progressive, Olafur Johannesson;
Social Democratic, Benedikt Grondal, People’s Alliance
(Communist front), Ragnar Arnalds; Organization of Liber-
als and Leftists, Magnus Torfi Olafsson
Voting strength (1974 election): 42.7% Independence,
24.9% Progressive, 9.1% Social Democratic, 18.3% People’s
Alliance, organization of leftists and liberals 4.6%
Communists: est. 2,200; a number of sympathizers, as
indicated by 20,922 votes cast for People’s Alliance in 1974
election
Member of: Council of Europe, EC (free trade agreement
pending resolution of fishing limits issue), EFTA, FAO,
GATT, IAEA, IBRD, ICAO, ICES, IDA, IFC, THO, ILO,
IMCO, IMF, IPU, ITU, IWC—International Whaling
Commission, NATO, Nordic Council, OECD, U.N.,
UNESCO, UPU, WHO, WMO, WSG','12af999955a5b0222b01f6285791c746952bb1cf09426fed6d9019a6dabeb6ab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83f519dd09303dd699b2fdd2377f911d48c7d653caa3d31f31782a9d332080f5',1978,'IN','India','government',253,'Legal name: Republic of India
Type: federal republic
Capital: New Delhi
Political subdivisions: 22 states, 9 union territories
Legal system: based on English common law; constitution
adopted 1950; limited judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Anniversary of the Proclamation of the
Republic, 26 January
Branches: parliamentary government, national and state;
relatively independent judiciary
Government leader: Prime Minister Morarji Desai
Suffrage: universal over age 21
Elections: national and state elections ordinarily held
every 5 years; may be postponed in emergency and may be
held more frequently if government loses confidence vote;
postponed general election due in March 1977, held in
March 1977; most state elections must be held no later than
March 1978
Political parties and leaders: Indian National Congress,
controlled national government from independence to
March 1977, parliamentary leader is Y. B. Charan, party
president is K. Brahmananda Reddy; Janata Party (a merger
of 5 pre-1977 election parties) led by Prime Minister Desai
and party president, Chandra Shekar; Communist Party of
India (CPI), C. Rajeswara Rao, general secretary; Commu-
nist Party of India/Marxist (CPI/M), E. M. S. Namboodiri-
pad, general secretary; Communist Party of India/Marxist-
Leninist (CPI/ML), Satyanarayan Singhh, general secretary;
All-India-Anna Dravida Munnetra Kazhagam (ADMK), a
regional party in Tamil Nadu led by M. G. Ramachandran;
Akali Dal representing Sikh religious community in the
Punjab
Voting strength (1977 election); 43.17% Janata and CFD,
34.54% Congress, 4.30% CPI/M, 2.82% CPI, 15.17% regional
parties and others
Communists: 90,000 members of CPI (est.), 85,000
members of CPI/M (est.); Communist sympathizers, 13
million
Other political or pressure groups: various separatist
groups seeking reorganization of states; numerous “senas” or
militant/chauvinistic organizations, including Shiv Sena and
Dalit Panthers in Bombay, the Anand Marg, and the
Rashtriya Swayamserak Sangh
Member of: ADB, AIOEC, Colombo Plan, Common-
wealth, FAO, G-77 GATT, IAEA, IBRD, ICAC, ICAO, IDA,
IFC, THO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, ITC, ITU, IWC—International Wheat
Council, NAM, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG','bf4a9224db0473b6d310a73c6e5810aa5c0bd0d5fff70bb58c209e20b2aabb73','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eddbd17f1db29af45e39a62169739f4227944727e17370a9ae0e8fbee3d1fbe7',1978,'IQ','Iraq','government',258,'Legal name: Republic of Iraq
Type: republic; National Front Government consisting of
Ba’th Party (BPI), and Iraq Communist Party (CPI) formed
in July 1973 (Kurds invited to join National Front
government but have refused pending solution of Kurdish
autonomy issue; Communists play nominal role in govern-
ment)
Capital: Baghdad
Political subdivisions: 18 provinces under centrally
appointed officials
Legal system: based on Islamic law in special religious
courts, civil law system elsewhere; provisional constitution
adopted in 1968; judicial review was suspended; legal
education at University of Baghdad; has not accepted
compulsory IC] jurisdiction
National holiday: 14 July
Branches: Ba''th Party of Iraq has been in power since
1968 coup
Government leaders: President Ahmad Hasan al-Bakr;
Deputy Chairman of the Revolutionary Command Council
Saddam Husayn ‘Abd-al-Majid al-Tikriti
Suffrage: no elective bodies exist
Elections: no national elections since overthrow of
monarchy in 1958
Communists: Communist Party allowed token representa-
tion in cabinet; est. 2,000 hard-core members
Political or pressure groups: political parties banned,
possibly some opposition to regime from disaffected
members of the regime and army officers
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, NAM, OAPEC, OPEC,
U.N., UNESCO, UPU, WFTU, WHO, WIPO. WMO, WSG','8096337d0d29239f1ca5c743e31fd9b9029a96ef03ac35051be6395910c57d90','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69729ed424efde3c5de465ff68a20029d14a0cc07ace22f6bdaf3cdfadea0d7e',1978,'IE','Ireland','government',262,'Legal name: Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law, substan-
tially modified by indigenous concepts; constitution adopted
1937; judicial review of legislative acts in Supreme Court;
has not accepted compulsory IC] jurisdiction
National holiday: St. Patrick’s Day, 17 March
Branches: elected President; bicameral parliament re-
flecting proportional and vocational representation; judici-
ary appointed by President on advice of government
Government leaders: President Patrick Hillery; Prime
Minister (Taoiseach) John (Jack) Lynch, Deputy Prime
Minister (Tanaiste) George Colley
Suffrage: universal over age 18
Elections: Dail (lower house) elected every 5 years—last
election June 1977; President elected for 7-year term—last
election November 1976
Political parties and leaders: Fianna Fail, John (Jack)
Lynch; Labor Party, Frank Cluskey; Fine Gael, Garret
Fitzgerald, Communist Party of Ireland, Michael O''Riordan
Voting strength: (1977 election) Fianna Fail (84 seats),
Fine Gael (43 seats), Labor Party (17 seats), Independents
hold 4 seats
Communists: approximately 600
Member of: Council of Europe, EC, EEC, ESRO
(observer), EURATOM, FAO, GATT, IBRD, ICAO, ICES,
IDA, IEA, IFC, ILO, IMCO, IMF, IPU, ISO, ITC, ITU,
{WC—International Wheat Council, OECD, U.N.
UNESCO, UPU, WHO, WIPO, WMO, WSG','d50e24d9083266f1f6d2fa670898129cfd89e2e06e921c4c1de01318cc74ee7b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23e60a313ee2532bbfbfaa85031228f06b993ebd631c10b560485f63abea6b29',1978,'IL','Israel','government',266,'Legal name: State of Israel
Type: republic
Capital: Jerusalem; not recognized by U.S. which
maintains Embassy in Tel Aviv
Political subdivisions: 6 administrative districts
Legal system: mixture of English common law and, in
personal area, Jewish, Christian and Muslim legal systems;
commercial matters regulated substantially by codes
adopted since 1948; no formal constitution; some of the
functions of a constitution are filled by the Declaration of
Establishment (1948), the basic laws of the Knesset
(legislature) relating to the Knesset, Israeli lands, the
president, the government and the Israel citizenship law; no
judicial review of legislative acts; legal education at Hebrew
University in Jerusalem; accepts compulsory IC] jurisdiction,
with reservations
National holiday: Independence Day, 11 May
Branches: President Ephraim Katzir has largely ceremo-
nial functions, executive power vested in cabinet; unicam-
eral parliament (Knesset) of 120 members elected under a
system of proportional representation; legislation provides
fundamental laws in absence of a written constitution, 2
distinct court systems (secular and religious}
Government leader: Prime Minister Menachem Begin
Suffrage: universal over age 18
Elections: held every 4 years unless required by
dissolution of Knesset; last election held in May 1977
Principal political parties and leaders: Herut, Prime
Minister Menachem Begin, Defense Minister Ezer Weiz-
man; Liberal Party, Finance Minister Simcha Ehrlich;
La’am, Yigal Hurvitz; (Likud is a coalition formed of Herut,
Liberals and La’am); National Religious Party, Joseph Burg,
Zevulun Hammer; Democratic Movement for Change, Yi-
gael Yadin, Shmuel Tamir, Meir Amit; Israel Labor Party,
Shimon Peres, Yitzhak Rabin, Yigal Allon; SHELLI, Arieh
Eliav
Voting strength: Likud 45 seats; National Religious Party
12 seats; Orthodox Augudat parties 5 seats; Samuel Flatto-
Sharon 1 seat; Moshe Dayan | seat, Labor Party-MAPAM-
Arab List Alignment 32 seats; Democratic Movement for
Change 15 seats; Independent Liberal Party 1 seat; Citizens
Rights Movement | seat; RAKAH 5 seats; SHELLI 2 seats
Communists: RAKAH (predominantly Arab but with
Jews in its leadership) has some 1,500 members; the Jewish
Communist Party, MAKI, is now part of Moked, which is a
far-left Zionist party
Other political or pressure groups: right-wing Jewish
Defense League led by Rabbi Meir Kahane; Black Panthers,
a loosely organized youth group seeking more benefits for
oriental Jews; Gush Emunim, Jewish religious zealots
pushing for freedom for Jews to settle anywhere on the West
Bank
Approved For Release 2005/04/22 :
Member of: FAO, GATT, IAEA, IBRD, ICAC, ICAO,
IDA, IFC, ILO, IMCO, IMF, IOOC, IPU, ITU, IWC—
International Wheat Council, OAS (observer), U.N.,
UNESCO, UPU, WHO, WIPO, WMO, WSG
Legal name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides for establish-
ment of 20 regions; 5 (Sicilia, Sardegna, Trentino-Alto
Adige, Friuli-Venezia Giulia, and Valle d''Aosta) have been
functioning for some time and the remaining 15 regions
were instituted on 1] April 1972; 94 provinces
Legal system: based on civil law system, with ecclesiasti-
cal law influence; constitution came into effect 1 January
1948; judicial review under certain conditions in Constitu-
tional Court; has not accepted compulsory IC] jurisdiction
National holiday: Anniversary of the Republic, 2 June
Branches: executive—President empowered to dissolve
Parliament and call national election; he is also Commander
of the Armed Forces and presides over the Supreme Defense
Council; otherwise, authority to govern invested in Council
of Ministers; legislative power invested in bicameral,
popularly elected Parliament: Italy has an independent
judicial establishment
Government leaders: President Giovanni Leone; Premier
Guilio Andreotti
Suffrage: universal over age 18 (except in Senatorial
elections where minimum age of voter is 25)
Elections: national elections for Parliament held every 5
years (most recent, June 1976); Provincial and municipal
elections held every 5 years with some out of phase; regional
elections every 5 years (held June 1975)
Political parties and leaders: Christian Democratic Party
(DC), Benigno Zaccagnini (secretary general), Aldo Moro
(party president); Communist Party (PCI), Enrico Berlin-
guer (secretary general), Luigi Longo (party president);
Socialist Party (PSI), Bettino Craxi (secretary general), Pietro
Nenni (party president); Social Democratic Party (PSDI),
Pierluigi Romita (secretary general); Liberal Party (PLI),
Valerio Zanone (party secretary); Italian Social Movement
(MSI), Giorgio Almirante: Republican Party (PRI), Oddo
Biasini (party secretary); Ugo La Malfa (party president)
Voting strength (1976 election): 38.7% DC, 34.4% PCI,
9.6% PSI, 6.1% MSI, 3.4% PSDI, 3.1% PRI, 1.3% PLI, 3.4%
other
Communists: 1,712,084 members (April 1976)
Other political or pressure groups: the Vatican; three
major trade union confederations (CGIL—Communist
dominated, CISL—Christian Democratic, and VIL—Social
Democratic, Socialist, and Republican); Italian manufactur-
ers association (Confindustria): organized farm groups
we Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ITALY/IVORY COAST
Member of: ADB, ASSIMER, Council of Europe, DAC,
EC, ECOWAS, ECSC, EEC, EIB, ELDO, ESRO,
EURATOM, FAO, GATT, IAEA, IBRD, ICAC, ICAO, IDA,
IEA, IFC, IHO, ILO, International Lead and Zine Study
Group, IMCO, IMF, IOOC, IPU, ITU, NATO, OAS
(observer), OECD, U.N., UNESCO, UPU, WEU, WHO,
WMO, WSG','15f068a2396a708552a0439e1bdeca918444d589575cf42ada4fee52151d53a2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('665e7c3cab0a7eba424b3f9721519ef9b2bf01ab6abd9b7cb4c4eb8be753afca',1978,'JP','Japan','government',270,'Legal name: Japan
Type: constitutional monarchy
Capital: Tokyo
Political subdivisions: 47 prefectures (Ryukyus became
47th prefecture on 15 May 1972)
Legal system: civil law system with English-American
influence; constitution promulgated in 1946; judicial review
of legislative acts in the Supreme Court; accepts compulsory
ICJ jurisdiction, with reservations
National holiday: Birthday of the Emperor, 29 April
Branches: Emperor is merely symbol of state; executive
power is vested in cabinet dominated by the Prime Minister,
chosen by the Lower House of the bicameral, elective
legislature (Diet); judiciary is independent
Government leader: Prime Minister Takeo Fukuda
Suffrage: universal over age 20
Elections: general elections held every 4 years or upon
dissolution of Lower House, triennially for one-half of
Upper House
Political parties and leaders: Liberal Democratic Party
(LDP), T. Fukuda, President; Japan Socialist Party (JSP),
T. Narita, Chairman; Democratic Socialist Party (DSP),
R. Sasaki, Chairman; Japan Communist Party (JCP), K.
Miyamoto, Presidium Chairman; Komeito (CGP), Y.
Takeiri, Chairman; New Liberal Club (NLC), Y. Kono
ie Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
JAPAN/JORDAN
Voting strength (1977 election): 37.6% LDP, 21.6% JSP,
10.2% CGP, 9.6% JCP, 5.6% DSP, 4.8% NLC, minor parties,
6.1% independents
Communists: 350,000; 3,000,000 sympathizers
Member of: ADB, ASPAC, Colombo Plan, DAC, ESCAP,
FAO, GATT, IAEA, IBRD, ICAC, ICAO, IDA, IEA, IFC,
IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, IRC, ISO, ITC, ITU, IWC—International]
Whaling Commission, IWC—International Wheat Council,
OECD, U.N., UNESCO, UPU, WHO, WIPO, WMO, WSG
Legal name: United Republic of Tanzania
Type: republic; single party on the mainland and on
Zanzibar
Capital: Dar es Salaam
Political subdivisions: 25 regions—20 on mainland, 5 on
Zanzibar islands
Legal system: based on English common law, Islamic law,
customary law, and German civil law system; permanent
constitution adopted 1977, replaced interim constitution
adopted 1965; judicial review of legislative acts limited to
matters of interpretation; legal education at University of
Dar es Salaam; has not accepted compulsory IC] jurisdiction
National holiday: “Union Day,” 26 April
Branches: President Julius Nyerere has full executive
authority on the mainland; National Assembly dominated by
Nyerere and the Chama Cha Mapinduzi (Revolutionary
Party); National Assembly consists of 218 members, includ-
ing 57 appointed from Zanzibar, 65 appointed from the
mainland, plus 96 directly elected from the mainland; new
constitution calls for popular election of some members from
Zanzibar; Vice President Aboud Jumbe (President of
Zanzibar) and the Revolutionary Council still run Zanzibar
despite the efforts of Nyerere to integrate the islands into the
political system of the mainland
Government leader: President Julius Nyerere
Suffrage: universal adult
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
TANZANIA/THAILAND
Political party and leaders: Chama Cha Mapinduzi
(Revolutionary Party), only political party, dominated by
Nyerere and Vice President Jumbe, his top lieutenant, party
was formed in 1977 as a result of the union of the
Tanganyika African National Union, the sole mainland
party, and the Afro-Shirazi Party, the only party in
Zanzibar; party union was part of effort by Nyerere to
integrate Zanzibar and mainland
Voting strength (October 1975 national elections): over 5
million registered voters; Nyerere received 95% of about 4
million votes cast; general parliamentary elections scheduled
for Fall of 1980
Communists: a few Communist sympathizers, especially
on Zanzibar
Member of: AFDB, Commonwealth, EAC, FAO, G-77,
GATT, IBRD, ICAC, ICAO, IDA, IFC, ILO, IMF, ITU,
NAM, OAU, U.N., UNESCO, UPU, WHO, WMO','ba8e5c8279e74994ba1030586582d3d99b16fd05476e4e9f8e1c2fcd131ac864','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a0fa71f6cbca02c5355ee6afc70048760bcf760bd97a725941885a18ce8342d',1978,'JO','Jordan','government',274,'Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: “Amman
Political subdivisions: 8 governorates (3 are under Israeli
occupation) under centrally appointed officials
Legal system: based on Islamic law and French codes;
constitution adopted 1952; judicial review of legislative acts
in a specially provided High Tribunal; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 25 May
Branches: King holds balance of power; Prime Minister
exercises executive authority in name of King; Cabinet
appointed by King and responsible to parliament; bicameral
parliament with House of Representatives last chosen by
national elections in April 1967, and dissolved by King in
February 1976; Senate last appointed by King in November
1974; met briefly in February 1976 to amend constitution
allowing King to postpone elections; present parliament
subservient to executive; secular court system based on
differing legal systems of the former Transjordan and
Palestine; law Western in concept and structure; Sharia
(religious) courts for Muslims, and religious community
council courts for non-Muslim communities; desert police
carry out quasi-judicial functions in desert areas
Government leader: King Husayn ibn Talal al-Hashimi
Suffrage: all citizens over age 20
Political parties and leaders: political party activity
illegal since 1957; Palestine Liberation Organization and
various smaller fedayeen groups clandestinely active on
West Bank; Muslim Brotherhood
Communists: party actively repressed, membership esti-
mated at less than 500
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, NAM, U.N.,
UNESCO, UPU, WHO, WIPO, WMO','725c30d4e011e33a44645a0ff66a96b15cfe14f491893a72046de3ecc584cf18','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85288b6b1beba34101f7c2b9c0bd663040ff791e77b0de6760e7d3169ab8f857',1978,'KE','Kenya','government',278,'Legal name: Republic of Kenya
’
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Type: republic within Commonwealth since December
1963
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi Area
Legal system: based on English common law, tribal law
and Islamic law; constitution enacted 1963; judicial review
in Supreme Court; legal education at University Kenya
School of Law in Nairobi; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: 12 December
Branches: President and Cabinet responsible to unicam-
eral legislature (National Assembly) of 170 seats, 158 directly
elected by constituencies and 12 appointed by the President;
Assembly must be reelected at least every 5 years; High
Court, with Chief Justice and at least 11 justices, has
unlimited original jurisdiction to hear and determine any
civil or criminal proceeding; provision for systems of courts
of appeal with ultimate appeal to East African Court of
Appeals
Government leader: President Jomo Kenyatta
Suffrage: universal over age 21
Elections: general election (October 1974) elected present
National Assembly; next elections due 1979
Political party and leaders: Kenya Africa National Union
‘(KANU), president, Jomo Kenyatta
Voting strength: KANU holds all seats in the National
Assembly
Communists: may be a
sympathizers
few Communists and
Other political or pressure groups: labor unions
Member of: AFDB, EAC, FAO, G-77, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMF, ISO, ITU, IwC—
International Wheat Council, NAM, OAU, U.N., UNESCO,
UPU, WHO, WIPO, WMO
Legal name: Democratic Peoples Republic of Korea
Type: Communist state; one-man rule
Capital: P’yongyang
Political subdivisions: 9 provinces, 2 special cities
(P’yongyang and Kaesong)
Legal system: based on German civil law system with
Japanese influences and Communist legal theory; constitu-
tion adopted 1948 and revised 1972; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
National holiday: 9 September
Branches: Supreme Peoples Assembly theoretically super-
vises Legislative and Judicial function; State Administration
Council (cabinet) oversees ministerial operations
Government and party leaders: Kim Il-song, President
DPRK, and General Secretary of the Korean Workers Party;
Pak Song-chol, Premier
Suffrage: universal at age 17
Elections: election to SPA every 4 years, but this
constitutional provision not necessarily followed—last elec-
tion November 1977
Political party: Korean Workers (Communist) Party;
claimed membership of about 2 million, or about 11% of
population
Member of: IAEA, ICAO, IPU, IRCS, U.N. (observer
status only), UNCTAD, UNESCO, WHO WIPO
Legal name: State of St. Christopder-Nevis-Anguilla
Type: dependent territory with full internal autonomy as
a British “Associated State”; Anguilla formally seceded in
May 1967 but has not been recognized as an independent
state by any government; in July 1968 a legislative council
headed by Ronald Webster was elected to govern Anguilla;
in March 1969 the U.K. sent troops to Anguilla, placing the
island again under colonial rule; in 197], Anguilla reverted
to its former colonial relationship with the U.K. although
nominally remaining part of the Associated state of St.
Christopher-Nevis-Anguilla; Webster became leader of
Anguillan Council after constitutionally held elections
(1972); in February 1976, the U.K. granted a new
constitution to Anguilla which changed its status to that of a
crown colony; in February 1977 Emile Gumbs replaced
Webster as Chief Minister
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law; constitution
of 1960; highest judicial organ is Court of Appeal of
Leeward and Windward Islands
Branches: legislative, 10-member popularly elected
House of Assembly; executive, cabinet headed by Premier
Government leaders: Premier, Robert Bradshaw; U.K.
Governor, Probyn Inniss
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent December
1975
Political parties and leaders: St. Chirstopher-Nevis-An-
guilla Labor Party, Robert L. Bradshaw; People’s Action
Movement (PAM), William Herbert: Nevis Reformation
Party (NRP), Ivor Stevens
Voting strength (December 1975 election): St. Christo-
pher-Nevis-Anguilla Labor Party won 7 seats in the House of
Assembly, NRP won 2, and 1 seat remains open for Anguilla
which did not participate in the election
Communists: none known
Member of: CARICOM, ISO
Legal name: State of St. Lucia
Type: dependent territory with full internal autonomy as
a British “Associated State”
Capital: Castries
Political subdivisions: 16 parishes
Legal system: based on English common law; constitution
of 1960; highest judicial body is Court of Appeal of Leeward
and Windward Islands
Branches: legislative, 17-member popularly elected
House of Assembly; executive, cabinet headed by Premier
Government leaders: Premier John Compton; U.K.
Governor Sir Allen Lewis
Suffrage: universal adult suffrage
Elections: every 5 years; most recent May 1974
Political parties and leaders: United Worker''s Party
(UWP), John Compton; St. Lucia Labor Party (SLP), Allan
Louisy
Voting strength (1974 election): UWP (53%) won 10 of
the 17 elected seats in House of Assembly; SLP (45%) won 7
seats; independents (2%) no seats
Communists: negligible
Member of: CARICOM
Legal name: State of St. Vincent
Type: dependent territory with full internal autonomy as
a British “Associated State”
Capital: Kingstown
Legal system: based on English common law; constitution
of 1960; highest judicial body is Court of Appeal of Leeward
and Windward Islands
Government leaders: Premier R. Milton Cato; Governor
General (U.K.) Sir Rupert G. John
Suffrage: universal adult suffrage (18 years old and over)
Elections: every 5 years; most recent December 9, 1974
Political parties and leaders: People’s Political Party
(PPP), Ebenezer Joshua; St. Vincent Labor Party (LP), R.
Milton Cato; Democratic Freedom Movement, Parnell
Campbell and Kenneth John
Voting strength (1975 election): LP 10 seats, PPP 2 seats,
independent 1 seat in the Legislature
Communists: negligible; Marxist opposition group, You-
lon United Liberation Organization (Yulimo)
Member of: CARICOM','601be43748aea70fec3aa34cf803cc5aea76f8fd3781629fc85e270d1d26d091','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e64ae1734633db99a76f6c6b0434a6a0143bb5d27f3f22b682c90bb34990e413',1978,'KW','Kuwait','government',282,'Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Kuwait
Political
constituencies
subdivisions: 8 governorates, 10 voting
Legal system: civil law system with Islamic law
significant in personal matters; constitution took effect 1968;
key provisions regarding election of National Assembly
suspended in August 1976; judicial review of legislative acts
not yet determined; has not accepted compulsory ICJ
jurisdiction
National holiday: 25 February
Branches: Council of Ministers
Government leader: Emir Sabah al-Salim Al Sabah
Suffrage: native born and naturalized males age 21 or
over
Elections: National Assembly dissolved by Emir’s decree
in August 1976
Political parties and leaders: political parties prohibited,
some small clandestine groups are active
Communists: insignificant
Other political or pressure groups: none
Member of: Arab League, FAO, G-77, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
OAPEC, OPEC, U.N., UNESCO, UPU, WHO, WIPO,
WMO
Legal name: Lao People’s Democratic Republic
Type: Communist state
Capital: Vientiane
Political subdivisions: 13 provinces subdivided into
districts, cantons, and villages
Legal system: based on civil law system; has not accepted
compulsory ICJ jurisdiction
National holiday: 2 December
Branches: President; 45-member Supreme People’s Coun-
cil; 39-member cabinet formed on 4 December 1975;
cabinet is totally Communist but council contains a few
nominal neutralists and non-Communists; National Congress
of People’s Representatives established the current govern-
ment structure in December 1975
Government leaders: President, Souphanouvong; Prime
Minister, Kaysone Phomvihan; Deputy Prime Ministers,
Nouhak Phoumsavan, Phoumi Vongvichit, Phoun Sipaseut,
and Khamtai Siphandone
Suffrage: universal over age 18
Elections: elections for new National Assembly, scheduled
for April 1, 1976, have been postponed
Political parties and leaders: Lao People’s Revolutionary
Party (Communist) includes Lao Patriotic Front and
Alliance Committee of Patriotic Neutralist Forces; other
parties are moribund
Communists: Lao People’s Revolutionary Party; member-
ship unknown
Other political or pressure groups: non-Communist
political groups are moribund; most leaders have fled the
country
Member of: ADB, Colombo Plan, ESCAP, FAO, G-77,
IBRD, ICAO, IDA, ILO, IMF, IPU, ITU, Mekong Commit-
tee, NAM, SEAMES, U.N., UNCTAD, UNESCO, UPU,
WHO, WMO','336cb216a344acb5436f5bfc9d9e86dced47c909612524183f0c6011f6f30902','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4469f412544d41cfb97c1e584499ce777484417c5b4364ffea5fddfc341a4e5c',1978,'LB','Lebanon','government',286,'NOTE: Civil strife between Lebanese Christians aided by
Syrian troops on the one hand, and Lebanese Muslims and
their Palestinian allies on the other hand, has plagued
Lebanon since early 1975. A cease-fire established in
October 1976 has generally held, although it is marred by
frequent incidents and occasional outbreaks of more serious
fighting, especially in the south. The country is now largely
under the occupation of Arab peacekeeping forces, almost
completely Syrian; Damascus is trying to nurture the
development of a central Lebanese government strong
enough to maintain a unitary state, but responsive to Syria’s
influence. At issue in the fighting have been the structure of
Lebanon’s parliamentary government and the country’s
traditional political practices, which have favored the
Christian minority. These have not yet been changed—the
Sarkis government is concentrating on economic reconstruc-
tion and the re-establishment of order—and the following
description is based on the present constitutional and
customary practices of the Lebanese system.
Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law, and
civil law system; constitution mandated in 1920; no judicial
review of legislative acts; legal education at University of
Lebanon; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 22 November
Branches: power lies with President elected by parlia-
ment (Chamber of Deputies); cabinet appointed by Presi-
dent, approved by parliament; independent secular courts
on French pattern; religious courts for matters of marriage,
divorce, inheritance, etc.; by custom, President is a Maronite
Christian, Prime Minister a Sunni Muslim, and president of
parliament a Shia Muslim; each of 9 religious communities
represented in parliament in proportion to national numeri-
cal strength
Government leader: President Ilyas Sarkis
Suffrage: compulsory for all males over 21; authorized for
women over 21 with elementary education
Elections: Chamber of Deputies held every 4 years or
within 3 months of dissolution of Chamber; latest April 1972
Political parties and leaders: political party activity is
organized along sectarian lines; numerous political groupings
exist, consisting of individual political figures and followers
motivated by religious, clan, and economic considerations;
political stability dependent on maintenance of balance
between religious communities
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
LEBANON/ LESOTHO
Communists: only legal Communist party in Middle East:
legalized in 1970; members and sympathizers estimated at
2,000-3,000
Other political or pressure groups: Palestinian guerrilla
organizations
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU, IWC—
International Wheat Council, NAM, U.N., UNESCO, UPU,
WHO, WMO, WSG','cd41cf2288f7c1a2f8ac30fc3e918f0d5fdef93e0110b922ca628ceff22ced3d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b764e0c10925efc8779a3d8a15bdb26fe20e64b8ce694924415d6927a758bed3',1978,'LS','Lesotho','government',290,'Legal name: Kingdom of Lesotho
Type: constitutional monarchy under King Moshoeshoe II;
independent member of commonwealth since 1966
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and
Roman-Dutch law; constitution came into effect 1966;
judicial review of legislative acts in High Court and Court of
Appeal; legal education at National University of Lesotho;
has not accepted compulsory ICJ jurisdiction
National holiday: 4 October
Branches: executive, divided between a largely ceremo-
nial King and a Prime Minister who leads cabinet of at least
7 members; Prime Minister dismissed bicameral legislature
in early 1970 and subsequently ruled by decree until 1973
when he appointed Interim National Assembly to act as
118 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
LESOTHO/ LIBERIA
legislative branch; judicial—63 Lesotho courts administer
customary law for Africans, High Court and subordinate
courts have criminal jurisdiction over all residents, Court of
Appeal at Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua
Jonathan
Suffrage: universal for adults
Elections: elections held in January 1970; nullified
allegedly because of election irregularities; subsequent
elections promised at unspecified date
Political parties and leaders: National Party (BNP),
Chief Leabua Jonathan; Basutoland Congress Party (BCP),
Ntsu Mokhele
Voting strength: in 1965 elections for National Assembly,
BNP won 32 seats; BCP, 22 seats; minor parties, 4 seats
Communists: negligible, Communist Party of Lesotho
banned in early 1970
Member of: Commonwealth, FAO, G-77, GATT (de
facto), IBRD, IDA, IFC, IMF, ITU, NAM, OAU, U.N.,
UNESCO, UPU, WHO','106d1ab8f0d9f50c2ab6263e50156d964b5da8a1225d6513c9a8de335de56473','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffe10c63d172594804083b6beb1fc8f05e6aaee47352f3ca0df0651cc43d1d78',1978,'LR','Liberia','government',294,'Legal name: Republic of Liberia
Type: republic in form; strong executive dominates, with
few constraints
Capital: Monrovia
Political subdivisions: country divided into 9 counties;
President appoints all officials of significance
Legal system: based on U.S. constitutional theory; recent
codes drawn up by Cornell University; constitution adopted
1847; amended 1907, 1926, 1934, 1955, and 1975; no
constitutional provision for judicial review of legislative acts;
legal education at Louis Arthur Grimes School of Law,
University of Liberia; accepts compulsory ICJ jurisdiction,
with reservations
National holiday: Independence Day, 26 July
Branches: President, elected by popular vote, limited to a
single eight-year term, controls through appointive powers,
authority over national expenditures, and a variety of
informal sanctions; 2-house legislature elected by popular
vote; judiciary consisting of Supreme Court and variety of
lower courts
Government leader: President William R. Tolbert, Jr.
Suffrage: universal 18 years and over
Elections: members of House of Representatives elected
for 4-year terms, most recently in October 1975; Senate
members elected for 6-year terms, one-half elected in May
1973; President Tolbert, constitutional successor to President
Tubman who died in July 1971, completed the four year
term to which Tubman was elected and was then elected in
October 1975 for an eight-year term beginning in January
1976
Political parties and leaders: True Whig Party, in power
since 1878, only political party; President Tolbert is leader
Voting strength: 1975 elections uncontested; True Whig
Party won all but a handful of votes
Communists: no Communist Party and only a few
sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, G-77, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU, NAM,
OAU, U.N., UNESCO, UPU, WHO','4179b92751a524a09d53b356773d57996e808d59e29dbc5ef7731b27571908b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6194bbe0e4675695c4f53643e70ba4a3b7efb91b4b8e310385aa9ed3674ca4ee',1978,'LY','Libya','government',298,'Legal name: Socialist Peoples Libyan Arab Jamahiriya
Type: republic; under military control following ouster of
king on 1 September 1969; major revision of the 1969
constitution promulgated; loosely confederated with Egypt
and Syria in Confederation of Arab Republics (CAR) on 1
September 1971
Capital: Tripoli
Political subdivisions: 10 administrative provinces closely
controlled by central government
Legal system: based on Italian civil law system and
Islamic law; separate religious courts; no constitutional
provision for judicial review of legislative acts; legal
education at Law School, at University of Libya at Benghazi;
has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 1 September
Branches: paramount political power and authority rests
with the Secretariat of the General People’s Congress which
theoretically functions as a parliament with a cabinet called
the General People’s Committee
Government leaders: Colonel Mu’ammar Qadhafi; Prime
Minister, Abdul Ati Ubaydi
Suffrage: universal
Elections: resentatives to the General People’s Congress
are drawn from popularly elected municipal committees
(elections are more or less continuous) election for CAR
assembly in March 1972
Political parties and leaders: Libyan Arab Socialist
Union, Ahmad Shahati, Secretary General; Mu’ammar
Qadhafi, President
Communists: no organized party, negligible membership
Other political or pressure groups: various Arab nation-
alist movements and the Arab Socialist Resurrection (Bath)
party with small, almost negligible memberships may be
functioning clandestinely
Member of: AFDB, Arab League, FAO, G-77, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IOOC, ITU,
NAM, OAPEC, OAU, OPEC, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG','594f2587566df635ceaccd8e319f17697a9bdb2d9a2de0988a9947d5d175616d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22614b39c3e476fb329de99dbdf9abe05ce1278df218cc083c0be4b8e1e0f7f5',1978,'LI','Liechtenstein','government',302,'Legal name: Principality of Liechtenstein
noun—Liechtensteiner(s); adjective—
Type: hereditary constitutional monarchy
Capital: Vaduz
Political subdivisions: 11 districts
122 Approved For Release 2005/04/22 :
Legal system: based on Swiss law; constitution adopted
1921; judicial review of legislative acts in a special
Constitutional Court; accepts compulsory ICJ jurisdiction,
with reservations
Branches: unicameral Parliament, hereditary Prince,
independent judiciary
Government leaders: Head of State, Prince Franz Joseph
If; Chief of Government, Dr. Walter Kieber
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1978
Political parties and leaders: Fatherland Union Party
(VU), Dr. Alfred Hilbe; Progressive Citizens’ Party (FBP),
Dr. Gerard Batliner
Voting strength (1974 election): FBP over 50%
Communists: none
Member of: IAEA, ITU, UPU, considering U.N. member-
ship; desires affiliation with The Council of Europe; under a
1923 treaty, Switzerland handles Liechtenstein’s post and
telegraph systems, customs, and foreign relations, WIPO','1f0306ac7144850fff48519c90a4df4c713b33a0676bca80ccc64cf209fb894d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5bd39ded37ed8b365b7a851d9e53f30bfb0a7126a77e44c9a60db7ce0ec4d23',1978,'LU','Luxembourg','government',307,'Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for administra-
tive purposes has 3 districts (Luxembourg, Diekirch,
Grevenmacher) and 12 cantons
Legal system: based on civil law system; constitution
adopted 1868; judicial review of legislative acts in the
Cassation Court only; accepts compulsory IC] jurisdiction
National holiday: 23 June
Branches: parliamentary democracy; seven ministers
comprise Council of Government headed by President,
which constitutes the executive; it is responsible to the
unicameral legislature, the Chamber of Deputies; the
Council of State, appointed for indefinite term, exercises
some powers of an upper house; judicial power exercised by
independent courts
Government leaders: Grand Duke Jean, Head of State;
Gaston Thorn, Prime Minister
Suffrage: universal and compulsory over age 18
Elections: every 5 years for entire Chamber of Deputies;
latest elections May 1974
Political parties and leaders: Christian Social Party,
Pierre Werner (Parliamentary President) and Jacques Santer
(Party President); Socialist, Lydie Schmit (Party President);
Social Democrat, Henry Cravatte (Party President); Demo-
cratic, Gaston Thorn (Party President and Prime Minister);
Communist, Dominique Urbany
Voting strength in Chamber of Deputies (1974):
Christian Socialist, 18; Socialist Workers, 17; Democrats, 14;
Social Democrats, 5; Communists, 5
Communists: 500 party members (1974)
Other political or pressure groups: group of steel
industries representing iron and steel industry, Centrale
Paysanne representing agricultural producers; Christian and
Socialist labor unions, Federation of Industrialists; Artisans
and Shopkeepers Federation
Member of: Benelux, BLEU, Council of Europe, EC,
ECSC, EEC, EIB, EURATOM, FAO, GATT, IAEA, IBRD,
ICAO, IDA, IEA, IFC, ILO, IMF, IOOC, IPU, ITU, NATO,
OECD, U.N., UNESCO, UPU, WEU, WHO, WIPO, WMO','9db7af604b5264d86742da4af43453dfacc83297dcb3af592b8d18e29177ee8a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70a748d4836b4777d34df70f45eb1e27d6b5c13816dc99259c5a328bd5830849',1978,'MW','Malawi','government',315,'Legal name: Republic of Malawi
Type: republic since July 1966; independent member of
Commonwealth since July 1964
Capital: Lilongwe
Political subdivisions: 3 administrative regions and 23
districts
Legal system: based on English common law and
customary law; constitution adopted 1964; judicial review of
legislative acts in the Supreme Court of Appeal; has not
accepted compulsory ICJ jurisdiction
National holiday: Republic Day, 6 July
Branches: strong presidential system with cabinet ap-
pointed by President; unicameral National Assembly of 60
elected and 15 nominated members; High Court with Chief
Justice and at least 2 justices
Government leader: Life President H. Kamuzu Banda
Suffrage: universal adult
Elections: scheduled for 1976 but MCP candidates were
unopposed and polling did not take place
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Political parties and leaders: Malawi Congress Party
(MCP), Dr. H. Kamuzu Banda
Communists: no Communist Party; Malawi maintains no
foreign relations with Communist governments
Member of: AFDB, EEC (associate member), FAO, G-77,
GATT, IBRD, ICAO, IDA, IFC, ILO, IMF, IPU, ISO, ITU,
OAU, U.N., UNESCO, WHO, WIPO, WMO','44602a3f85e537e3672154abc8b4b6d676e7a8c82da6de2964b394c2cc2a910e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da042e4db9185f2747fee47939367439022406c35294a593c2431b5d2ea59d4b',1978,'MY','Malaysia','government',319,'Legal name: Malaysia
Type:
Malaysia: constitutional monarchy nominally headed
by Paramount Ruler (King); a bicameral Parliament
consisting of a 58-member Senate and a 154-member House
of Representatives
Peninsular Malaysian states: hereditary rulers in all
but Penang and Malacca where Governors appointed by
Malaysian Government; powers of state governments limited
by federal constitution
Sabah: self-governing state within Malaysia in which it
holds 16 seats in House of Representatives; foreign affairs,
defense, internal security, and other powers delegated to
federal government
_ Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Sarawak: self-governing state within Malaysia in which
it holds 24 seats in House of Representatives; foreign affairs,
defense, and internal security, and other powers are
delegated to federal government
Capital:
Peninsular Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu
Sarawak: Kuching
Political subdivisions: 13 states (including Sabah and
Sarawak)
Legal system: based on English common law; constitution
came into force 1963; judicial review of legislative acts in the
Supreme Court at request of Supreme Head of the
Federation; has not accepted compulsory [CJ jurisdiction
National holiday: 31 August
Branches: 9 state rulers alternate as Paramount Ruler for
5-year terms; locus of executive power vested in Prime
Minister and cabinet, who are responsible to bicameral
parliament; following communal rioting in May 1969,
government imposed state of emergency and suspended
constitutional rights of all parliamentary bodies; parliamen-
tary democracy resumed in February 1971
Peninsular Malaysia: executive branches of 11 states
vary in detail but are similar in design; a Chief Minister,
appointed by hereditary ruler or Governor, heads an
executive council (cabinet) which is responsible to an
elected, unicameral legislature
Sarawak and Sabah: executive branch headed by
Governor appointed by central government, largely ceremo-
nial role; executive power exercised by Chief Minister who
heads parliamentary cabinet responsible to unicameral
legislature; judiciary part of Malaysian judicial system
Government leader: Head of State, Hussein Onn
Suffrage: universal over age 20
Elections: minimum of every 5 years, last elections
August 1974
Political parties and leaders:
Peninsular Malaysia: National Front, a confederation
of 9 political parties dominated by United Malays National
Organization (UMNO), Hussein Onn; only opposition party
of consequence—Democratic Action Party (DAP)
Sabah: Berjaya Party, Datak Harris Sallah; United
Sabah National Organization (USNO), Tan Sri Haji Mohd
Said Keruak; Sabah Chinese Association (SCA), Khoo Siak
Chiew
Sarawak: coalition Sarawak Alliance composed of the
Pesaka/Bumipatra Party, the United People’s Party (SUPP),
Ong Kee Hui and Sarawak Chinese Association; Sarawak
National Party (SNAP), Stephen Ningkan
Voting strength:
Peninsular Malaysia: (1974 election) National Front
controls 135 of 154 seats in lower house of parliament
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Sabah: (April 1976 Assembly Elections) Berjaya Party
controls 35 of 54 seats in State Assembly, USNO controls 20
remaining seats
Sarawak: (1974 elections) National Front 30 out of 48
State Assembly seats
Communists:
Peninsular Malaysia: approximately 3,000 armed
insurgents on Thailand side of Thai/Malaysia border;
approximately 800 full-time inside Peninsular Malaysia
Sarawak: 125 armed insurgents in Sarawak
Sabah: insignificant
Member of: ADB, ANRPC, ASEAN, Colombo Plan,
Commonwealth, FAO, G-77, GATT, IAEA, IBRD, ICAO,
IDA, IFC, ILO, IMCO, IMF, IPU, ITC, ITU, NAM, U.N.,
UNESCO, UPU, WHO, WMO','987254bc7181796136e65b0e8007bca81c7e619e7ee643d60912836dcb53a5d8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8db26df837a4ca631319c586b55675f47bfb1dfe1d0a393e88756e69dc044e76',1978,'MV','Maldives','government',325,'Legal name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative districts corre-
sponding to atolls
Legal system: based on Islamic law with admixtures of
English common law primarily in commercial matters; has
not accepted compulsory ICJ jurisdiction
National holiday: 26 July
Branches: popularly elected unicameral national legisla-
ture (Majlis) (members elected for 5-year terms); elected
President, chief executive; appointed Chief Justice responsi-
ble for administration of Islamic law
Government leader: President Ibrahim Nasir
Suffrage: universal over age 21
Political parties and leaders: no organized political
parties; country governed by the Didi clan for the past eight
centuries
Communists: negligible number
Member of: Colombo Plan, FAO, G-77 GATT (de facto),
IMCO, ITU, NAM, U.N., UPU, WHO','fdef920731efa58d5ebee70632d912b6f38cdc82ca2234db281c214801e660d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c66fdd4784871e1a77f2395d815d53766127693f59c2cb94743848a379f4b3e',1978,'ML','Mali','government',329,'Legal name: Republic of Mali
Type: republic; under military regime since November
1968
Capital: Bamako
131
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MALI/MALTA
Political subdivisions: 6 administrative regions; 42
administrative districts (cercles), arrondissements, villages;
all subordinate to central government
Legal system: based on French civil law system and
customary law; constitution adopted 1974, comes into full
effect in 1979; judicial review of legislative acts in
Constitutional Section of Court of State; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 22 September
Branches: executive authority exercised by Military
Committee of National Liberation (MCNL) composed of 11
urmy officers; under MCNL functional cabinet composed of
civilians and army officers; judiciary
Government leaders: Col. Moussa Traore, President of
MCNL, Chief of State and head of government
Suffrage: universal over age 21
Political parties and leaders: political activity proscribed
by military government but government in process of
forming new single party called the Democratic Union of
Malian People (UDPM)
Elections: MCNL promises elections at unspecified date
Communists: a few Communists and some sympathizers
Member of: AFDB, APC, CEAO, ECA, ECOWAS, FAO,
G-77, GATT (de facto), IAEA, IBRD, ICAO, IDA, ILO,
IMF, ITU, Niger River Commission, NAM, OAU, OMVS
(Organization for the Development of the Senegal River
Valley), U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Malta
Type: parliamentary democracy, independent republic
within the Commonwealth since December 1974
Capital: Valletta
Political subdivisions: 2 main populated islands, Malta
and Gozo, divided into 13 electoral districts (divisions)
Legal system: based on English common law; constitution
adopted 1961, came into force 1964; has accepted compul-
sory IC] jurisdiction, with reservations
Branches: executive, consisting of Prime Minister and
cabinet; legislative, comprising 65-member House of Repre-
sentatives; independent judiciary
National holiday: Republic Day, 13 December
Government leader: Prime Minister Dom Mintoff
Suffrage: universal over age 18; registration required
Elections: at the discretion of the Prime Minister, but
must be held before the expiration of a 5-year electoral
mandate; last election September 1976
Political parties and leaders: Nationalist Party, Edward
Fenech Adami; Malta Labor Party, Dom Mintoff
Voting strength (1976 election): Labor, 34 seats (51.54%);
Nationalist, 31 seats (48.43%)
Communists: less than 100 (est.)
Member of: Commonwealth, Council of Europe, FAO, G-
77, GATT, IBRD, ICAO, ILO, IMCO, IMF, ITU, NAM,
U.N., UNESCO, UPU, WHO','8aef659da76ea8821014e6486b55149e71fe39b44c74ee9f728d1ba7ca91ca28','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('214116845824244d8894af771fe84895deb36aa448b83f41416c331778bbcc98',1978,'MQ','Martinique','government',334,'Legal name: Overseas Department of Martinique
Type: overseas department of France; represented by 3
deputies in the French National Assembly and 2 Senators in
the Senate
Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34 communes,
each with a locally elected municipal council
Legal system: French legal system; highest court is a
court of appeal based in Martinique with jurisdiction over
Guadeloupe, French Guiana, and Martinique
Branches: executive, Prefect appointed by Paris; legisla-
tive, popularly elected council of 36 members and a
Regional Council including all members of the local general
council and the locally elected deputies and senators to the
French parliament; judicial, under jurisdiction of French
judicial system
Government leader: Prefect Herve Bourseilleur
Suffrage: universal over age 18
Elections: General Council elections normally are held
every five years; last General Council election took place in
March 1976; last local election held March 1977, last French
Presidential election May 1974
Political parties and leaders: Rassemblement Pour la
Republique (RPR), Emile Maurice; Progressive Party of
Martinique (PPM), Aime Cesaire; Communist Party of
Martinique (PCM), Armand Nicolas; Democratic Union of
Martinique (UDM), Leon-Laurent Valere; Socialist Party,
leader unknown; Federation of the Left, leader unknown
Voting strength: RPR, 2 seats in French National
Assembly; PPM, 1 seat (1973 election)
Communists: 1,000 estimated
Other political or pressure groups: Proletarian Action
Group (GAP), Socialist Revolution Group (GRS)','9d36763df6034e8b330c9f6fcd4c5d03596908ce38c737c3148b8d9edf9ee580','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('759854d4a6d382590c17e5fc35f413625c104b7c0efcfffe3c9b1b81f31d6562',1978,'MR','Mauritania','government',338,'Legal name: Islamic Republic of Mauritania
Type: republic; one-party presidential rule since 1960
Capital: Nouakchott
Political subdivisions: 12 regions and a capital district
NOTE: Mauritania has acquired administrative control of
the southern third of Western (formerly Spanish) Sahara
under an agreement with Morocco, but the legal question of
sovereignty over the area has yet to be determined. Spain''s
role as co-administrator of the disputed territory ended
February 1976. The newly acquired region, which lies below
the 24th parallel, becomes the district of Tiris el Gharbia—a
territorial division of the state. The district’s headquarters is
Dakhla, formerly Villa Cisneros. Tiris el Gharbia is
subdivided into three departments—Dakhla, Ausert, and
Aargub.
Legal system: based on French civil law system and
Islamic law; constitution adopted 1961; judicial review of
legislative acts in the Supreme Court; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 28 November
Branches: executive, President; separate judiciary (ap-
pointed by president)
Government leader: President Moktar Ould Daddah
Suffrage: universal for adults
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Elections: presidential and parliamentary election every 5
years; most recent October 1975
Political parties and leaders: Mauritanian Peoples Party
is only legal party, Secretary General Moktar Ould Daddah
Communists: no Communist Party, but there is a
scattering of Maoist sympathizers
Member of: AFDB, AIOEC, Arab League, CEAO,
CIPEC (associate), EAMA, EIB (associate), FAO, G-77,
GATT, IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU,
ITU, NAM, OAU, OMVS (Organization for the Develop-
ment of the Senegal River Valley), U.N., UNESCO, UPU,
WHO, WIPO, WMO','f098f4ae935180fbf0d3ece7067d36148f3c0c8dd090e8adf48c80e9c62496fa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a454bcfd5635bc69f29e2b24a89d8cd1f5f486e8b5af96b50cec49cfb58a6643',1978,'MU','Mauritius','government',342,'Legal name: Mauritius
Type: independent state since 1968, recognizing Elizabeth
II as Chief of State
Capital: Port Louis
Political subdivisions: 5 organized municipalities and
various island dependencies
Legal system: based on French civil law system with
elements of English common law in certain areas; constitu-
tion adopted 6 March 1968
National holiday: Independence Day, 12 March
Branches: executive power exercised by Prime Minister
and 2l-man Council of Ministers; unicameral legislature
(National Assembly) with 62 members elected by direct
suffrage, 8 specially elected
Government leader: Prime Minister Dr. Seewoosagur
Ramgoolam
Suffrage: universal over age 18
Elections: legislative elections held in December 1976;
municipal elections held in 1977
Political parties and leaders: a government coalition
consisting of Labor Party (S. Ramgoolam) and Parti
Mauricien Social Democrate (G. Duval); opposition parties—
Independent Forward Bloc (S. Bissoondoyal), Mauritius
Democratic Union (M. Lesage), Mouvement Militant Mauri-
tian (P. Berenger), Mouvement Militant Mauritian Socialiste
Progressist (D. Virahsawmy)
Voting strength: Mauritius Labor Party, 29 seats; Parti
Mauricien Social Democrate, 8 seats; Movement Militant
Mauritian, 32 seats; 1 independent
Communists: may be 2,000 sympathizers; several Com-
munist organizations; Mauritius Lenin Youth Organization,
Mauritius Women’s Committee, Mauritius Communist
Party, Mauritius People’s Progressive Party, Mauritius
Young Communist League, Mauritius Liberation Front,
Chinese Middle School Friendly Association, Mauri-
tius/USSR Friendship Society
Other political or pressure groups: Tamil United Party,
Mauritius Workers Party
Member of: Commonwealth, FAO, G-77, GATT, IBRD,
ICAO, IDA, IFC, ILO, IMF, ISO, ITU, IWC—International
Wheat Council, NAM, OAU, OCAM, U.N., UNESCO, UPU,
WHO, WIPO WMO
Legal name: Overseas Department of Reunion
Type: overseas department of France; represented in
French Parliament by three Deputies and two Senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect ap-
pointed by the French Minister of Interior, assisted by a
Secretary-General and an elected 36-man General Council
Government leader: Prefect Paul Cousseran
Suffrage: universal adult
171
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
REUNION/RHODESIA
Elections: last municipal and general council elections in
1976; Parliamentary election March 1976
Political parties and leaders: Reunion Communist Party
(RCP) led by Paul Verges, only organized political
movement on island; other political candidates affiliated
with metropolitan French parties, which do not maintain
permanent organizations on Reunion
Voting strength (Parliamentary election 1973): Rally for
the Republic (formerly Union of Democrats for the
Republic) elected, one senator and two deputies; Centrist
Union, one deputy; one Senator independent
Communists: Communist Party small—probably only
15-20 hard-line Communists—but has support among
sugarcane cutters and in Le Port district
Member of: EC, WFTU','f77df50a58c6f68e6147ed21d330088bab5006192a08675c1e48301c1800791d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('233c474856bdf14a5513ee6bb3aa76ade7e13e03c31041599bbc873e1805d377',1978,'MX','Mexico','government',346,'Legal name: United Mexican States
Type: federal republic operating in fact under a
centralized government
Capital: Mexico
Political subdivisions: 31 states, Federal District
Legal system: mixture of U.S. constitutional theory and
civil law system; constitution established in 1917; judicial
review of legislative acts; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: Independence Day, 16 September
Branches: dominant executive, bicameral legislature,
Supreme Court
Government leader: President Jose Lopez-Portillo
universal over compulsory but
Suffrage: age 18;
unenforced
137
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
MEXICO/MONACO
Elections: congressional elections July 1979
Political parties and leaders: Institutional Revolutionary
Party (PRI), Carlos Sansores Perez; National Action Party
(PAN), Manuel Gonzalez Hinojosa; Popular Socialist Party
(PPS), Jorge Cruickshank Garcia; Authentic Party of the
Revolution (PARM), Pedro Gonzalez Azcuaga
Voting strength: 1976 presidential election: 98.7% PRI
(unopposed), 1.3% other; 1976 congressional election: 80.2%
PRI; 8.5% PAN; 5.8% other opposition (votes cast for PPS,
PARM, and unregistered candidates), 5.4% annulled
Communists: estimated 5,000 in Communist Party
Other political or pressure groups: Roman Catholic
Church, Confederation of Mexican Workers (CTM), Con-
federation of Industrial Chambers (CONCAMIN), Confed-
eration of National Chambers of Commerce (CONCA-
NACO), National Cofederation of Campesinos (CNC),
National Confederation of Popular Organizations (CNOP),
Revolutionary Confederation of Workers and Peasants
(CROC)
Member of: FAO, G-77, IADB, IAEA, IBRD, ICAC,
ICAO, IDA, IDB, IFC, ILO, International Lead and Zinc
Study Group, IMCO, IMF, ISO, ITU, [WC—International
Whaling Commission, LAFTA, NAMUCAR (Carribean
Multinational Shipping Line—Naviera Multinacional del
Caribe), OAS, SELA, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG','09c5fbf980f21501a3be091f714d30811a8e9bd73a216551ce19655f4693fc77','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c59e30ea2a8bb55c77c874a4e68c22020b37a417c6c167bc48d0687c67f40a6',1978,'MC','Monaco','government',350,'Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections
Legal system: based on French law; new constitution
adopted 1962; has not accepted compulsory ICJ jurisdiction
National holiday: 19 November
Branches: National Council (18 members); Communal
Council (15 members, headed by a mayor)
Government leader: Prince Rainier III
Suffrage: universal
Elections: National Council every 5 years; most recent
1973
Political parties and leaders: National Democratic
Entente,-Democratic Union Movement, Monegasque Action-
ist (1973)
Voting strength: figures for 1973: National Democratic
Entente, 16 seats; Democratic Union Movement and
Monegasque Actionist, 1 seat each
Member of: IAEA, IHO, IPU, ITU, U.N. (permanent
observer), UNESCO, UPU, WHO, WIPO','c8a792a7b2b5cd1399d99b1091ab13b402cca368df99ed93ceaf480864fc22ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('505b66f8575416ec4ebe030755bd89046bbc2813cfa9f0838c9931dd5f9881b2',1978,'MN','Mongolia','government',354,'Legal name: Mongolian Peoples Republic
Type: Communist state
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 2 autonomous
municipalities (Ulaanbaatar and Darhan)
Legal system: blend of Russian, Chinese, and Turkish
systems of law; new constitution adopted 1960; no constitu-
tional provision for judicial review of legislative acts; legal
education at Ulaanbaatar State University; has not accepted
compulsory IC] jurisdiction
National holiday: People’s Revolution Day, 11 July
Branches: constitution provides for a People’s Great
Hural (national assembly) and a highly centralized
administration
Party and government leaders: Y. Tsedenbal, First
Secretary of the MPRP and Chairman of the Presidium of
the People’s Great Hural; J. Batmunh, Chairman of the
Council of Ministers
Suffrage: universal; age 18 and over
Elections: national assembly elections held every 4 years;
last election held June 1977
Political party: Mongolian People’s Revolutionary (Com-
munist) Party (MPRP); estimated membership, 67,000
(1976)
Member of: CEMA, ESCAP, IAEA, ILO, IPU, ITU, U.N.,
UNESCO, UPU, WHO, WMO','fb564d239d3c1c8ac3bdb527bdef4a9f4b84cb127c9d8058d72f80f9b7eaea90','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae54c2186bd5323fc0c07315d01cc1a31d39b025a31e7e4c98832520493bfcf7',1978,'MA','Morocco','government',358,'Legal name: Kingdom of Morocco
Type: constitutional monarchy (constitution adopted
1972)
Capital: Rabat
Political subdivisions: 83 provinces and 2 prefectures
NOTE: Morocco has acquired the northern two-thirds of
the former Spanish Sahara under an agreement with
Mauritania, but the legal question of sovereignty over the
area has yet to be determined. Spain’s role as co-
administrator of the disputed territory ended in February
1976. Rabat has established three provinces in its area of
control, with headquarters at E] Aaiun, Semara, and Cabo
Bojador.
Legal system: based on Islamic law and French and
Spanish civil law system; judicial review of legislative acts in
Constitutional Chamber of Supreme Court; modern legal
education at branches of Mohamed V University in Rabat
and Casablanca and Karaouine University in Fes; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 3 March
Branches: constitution provides for Prime Minister and
ministers named by and responsible to King; King has
paramount executive powers; unicameral legislature two-
thirds directly elected, one-third indirectly; judiciary inde-
pendent of other branches
Government leaders: King Hassan II; Prime Minister
Ahmed Osman
Suffrage: universal over age 20
Elections: local elections held 12 November 1976;
provincial elections held 25 January 1977; elections for new
National Assembly provided for in Constitution adopted 15
March 1972 were held June 1977
Political parties and leaders: Istiqlal Party, M’hamed
Boucetta; Popular Movement (MP), Mahjoubi Aherdan;
Constitutional and Democratic Popular Movement (MPCD),
Dr. Abdelkrim Khatib; National Union of Popular Forces
(UNFP), split into competitive factions under Abdallah
Ibrahim and Mahjoub Ben Seddik of Casablanca-based
faction and Abderrahim Bouabid of Rabat-based faction
with latter becoming Socialist Union of Popular Forces
(USFP) in September 1974; Democratic Constitutional Party
(PDC), Mohamed Hassan Ouazzani; Party for Progress and
Socialism (PPS), legalized in August 1974, successor to Party
for Progress and Socialism (PPS), is front for Moroccan
Communist Party (MCP), which was proscribed in 1959, Ali
Yata; Istiqlal and the UNFP formed a National Front in July
1970 to oppose the new constitution, boycotted the
parliamentary elections and the 1972 constitutional
referendum
Voting strength: pro-government independents hold
absolute majority in new National Assembly; with palace-
oriented Popular Movement deputies, the government holds
over two-thirds of the seats
Communists: 300 est.
Member of: AFDB, Arab League, EC (association until
1974), FAO, G-77, GATT, IBRD, ICAO, IDA, IFC, ILO,
International Lead and Zine Study Group, IMCO, IMF,
IOOC, IPU, ITU, NAM, OAU, U.N., UNESCO, UPU,
WHO, WIPO, WMO','9ae4a6e2ce7de2ad8faa5ff733c24fdd6b466371a10e9744ccdb9ed6d492dfbb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efae14e2170dbc2ec6620b227fddd178aaf0ddfbd80e6db439c8729a8474dccb',1978,'MZ','Mozambique','government',362,'Legal name: Peoples Republic of Mozambique
Type: peoples republic; achieved independence from
Portugal in June 1975
Capital: Maputo
Political subdivisions: 10 districts administered by
district governors; municipalities governed by appointed
official
Legal system: based on Portuguese civil law system and
customary law
National holiday: Independence Day, 25 June
Branches: none established
Government leader: President Samora Machel
Suffrage: not yet established
Elections: information not available on future election
schedule
Political parties and leaders: the Mozambique Liber-
ation Front (FRELIMO), led by Samora Machel, is only
legal party
Communists: none known
Member of: G-77, NAM, OAU, U.N.','82fa9697c25c343424e10eccbdcc2bb40df9b5690f8e7d96373000d2851ba411','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84b26ff5358fdf3c5d0af76cd07a67da459f9fe583fdb680353619e15a27a4db',1978,'NA','Namibia','government',366,'Legal name: Namibia
Type: former German colony of South-West Africa
mandated to South Africa by League of Nations in 1920;
U.N. formally ended South Africa’s mandate on October 27,
1966, but South Africa has retained administrative control
Capital: Windhoek
Political subdivisions: 10 tribal homelands, mostly in
northern sector, and zone open to white settlement with
administrative subdivisions similar to a province of South
Africa
Legal system: based on Roman-Dutch law and customary
law
National holiday: Independence Day, 25 June
Branches: since September 1977 an administrator-gener-
al, appointed by South African government, has exercised
coordinative functions over zone of white settlement, where
white-elected Legislative Assembly handles some local
matters, and tribal homelands, where traditional chiefs and
representative councils exercise limited autonomy
143
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
NAMIBIA/NAURU
Government leader: Martinus T. Steyn, Administrator-
general
Suffrage: limited to white adults
Elections: last general election, 1974
Political parties and leaders: white parties— National
Party of South-West Africa (NPSWA), Abraham H.
du Plessis; Federal Party, Bryan O’Linn; Republican Party,
Dirk Mudge
Voting strength: NP (1974 election) won 5 of 6 seats in
Republic legislature
Communists: no Communist Party, but some influence by
South African Communists and other Communists on
Namibian blacks outside territory
Other political or pressure groups: nonwhite—South-
West Africa People’s Organization (SWAPO), almost exclu-
sively based on Ovambo tribe led by Sam Nujoma, in exile;
South-West Africa National Union (SWANU), primarily
based on Herero tribe, leaders in exile; National Unity
Democratic Organization (NUDO), primarily based on
Herero tribe led by Clements Kapuuo; Namibian National
Front, an alliance of non-white groups that oppose separate
development for tribal homelands','128fa5eb19957d02911b1f0185470dcb2ace6753b70975a143b529695f7017fa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8792f5dc9a0aa6746645edc7c001259b6137c9486172dbb5ddf7471cef475712',1978,'NR','Nauru','government',370,'Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se: government offices in
Yeran District
Political subdivisions: 14 districts
Branches: President elected from and by Parliament for
an unfixed term; popularly elected 18-member unicameral
legislature, the Parliament; Cabinet to assist the President,
four members, appointed by President from Parliament
members
= Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
TT
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
NAURU/NEPAL
Government leader: President Bernard Dowiyogo
Suffrage: universal adult
Elections: last held in December 1976, next to be held in
November 1977
Political parties and leaders: there are no political parties
Member of: no present plans to join U.N.; enjoys “special
membership” in Commonwealth; South Pacific Commission,
ESCAP, INTERPOL, ITU, UPU','25308c3fdafb8d685a793813fe420986cf3f627fc1f10d876af0d826a2e0c03a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15da8931c04e81a58c47ca61ae95309b4440e2cc1988597a1114ad03f0ba25b4',1978,'NP','Nepal','government',374,'Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Birendra exercises
autocratic control over multitiered panchayat system of
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and English
common law; legal education at Nepal Law College in
Kathmandu; has not accepted compulsory iCJ jurisdiction
National holiday: Birthday of the King, 28 December
Branches: Council of Ministers appointed by the King;
indirectly elected National Panchayat (Assembly)
Government leaders: King Birendra Bir Bikram Shah
Deva; Prime Minister Kirtinidhi Bista
Suffrage: universal over age 21
145
CIA-RDP79-01051A000900010004-4
10004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009000
January 1978
NEPAL /NETHERI.ANDS
Elections: village and town councils (panchayats) elected
by universal suffrage; district, zonal, and National Pan-
chayat members indirectly elected, most for 6-year terms; 15
National Panchayat members elected from five class and
professional organizations (women, workers, peasants, youth,
and ex-servicemen), four directly elected by all voters
possessing a B.A. or its equivalent, and 16 are appointed by
the King
Political
outlawed
parties and leaders: all political parties
Communists: the combined membership of the two wings
of the Communist Party of Nepal (CPN) about 6,500, the
majority (perhaps 5,000) in the pro-Chinese wing; the CPN
continues to operate more or less openly, but internal
dissension has greatly hindered its effectiveness
Other political or pressure groups: proscribed Nepali
Congress Party led by B. P. Koirala
Member of: ADB, Colombo Plan, FAO, G-77, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, NAM, UN.,
UNESCO, UPU, WHO, WMO','776f237a2c1a3d51411ea52638c978212f7285ddcab28882590707a356f74885','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df82ca0b1599fdff6bb16081819c3e00af5f601edc5f88cc9e29d5c4daf55130',1978,'NL','Netherlands','government',378,'Legal name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at The
Hague
Political subdivisions: 11 provinces governed by cen-
trally appointed commissioners of Queen
Legal system: civil law system incorporating French
penal theory; constitution of 1815 frequently amended,
reissued 1947; judicial review in the Supreme Court of
legislation of lower order than Acts of Parliament; legal
education at six law schools; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Birthday of the Queen, 30 April
Branches: executive (Queen and Cabinet of Ministers),
which is responsible to bicameral States General (parlia-
ment); independent judiciary
Government leaders: Head of State, Queen Juliana;
Johannes den Uyl, Prime Minister
Suffrage: universal over age 21
Elections: must be held at least every 4 years for lower
house (most recent held May 1977), and every 3 years for
half of upper house (most recent July 1977)
Political parties and leaders: Catholic People’s Party
(KVP), W. J. Vergeer; Antirevolutionary (ARP), J. deKoning;
Labor (PvdA), Mrs. C. (Ien) van den Heuvel; Liberal (VVD),
F. Korthals Altes; Christian Historical Union (CHU), Otto
W. A. Baron van Verschuer; Democrats "66 (D-66), Jan
Frederik glastra van Loon; Communist (CPN), Henk
Hoekstra; Pacifist Socialist (PSP), P. Hoogerwerf; Political
Reformed (SGP), H. G. Abma; Reformed Political Union
(GVP), G. Veurink; Radical Party (PPR), Mrs. R. (Ria)
Beckers; Democratic Socialist 70 (DS-70), H. Staneke;
Farmers’ Party (BP), Hendrik Koekoek; Christian Demo-
cratic Appeal (CDA), coalition of KVP, ARP, and CHU
formed prior to 1977 elections
Voting strength (1977 election): 33.81% PydA, 31.91%
CDA, 17.95% VVD, 5.43% D’66, 2.18% SGP, 1.73% CPN,
1.69% PPR, 0.96% GPV, 0.94% PSP, 0.84% BP, 0.72% DS’70
Communists: 13,000 est. members
Other political or pressure groups: great multinational
firms; Socialist, Catholic, and Protestant trade unions;
Federation of Catholic and Protestant Employers Associ-
ations; the non-denominational Federation of Netherlands
Enterprises
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Member of: ADB, Benelux, Council of Europe, DAC, EC,
ECE, EEC, EIB, ELDO, EMA, ESRO, EURATOM, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC,
IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, ITC, ITU, IWC—International Wheat
Council (with respect to interests of the Netherlands Antilles
and Surinam), NATO, OAS (observer), OECD, ULN.,
UNESCO, UPU, WEU, WHO, WIPO, WMO, WSG
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands,
enjoying complete domestic autonomy
Capital: Willemstad, Curacao
Political subdivisions: 4 island territories—Aruba, Bon-
aire, Curacao, and the Windward Islands—St. Eustatius,
southern part of St. Martin (northern part is French), Saba
Legal system: based on Dutch civil law system, with some
English common law influence; Constitution adopted 1954
Branches: federal executive power rests nominally with
Governor (appointed by the Crown), actual power exercised
by 8-member Council of Ministers or Cabinet presided over
by Minister-President; legislative power rests with 22-mem-
ber Legislative Council; independent court system under
control of Chief Justice of Supreme Court of Justice
(administrative functions under Minister of Justice); each
island territory has island council headed by Lieutenant
Governor
Government leader: Minister-President Silvo G. M.
Rozendal
Suffrage: universal age 18 and over
Elections: Federal elections held every 4 years, last held
17 June 1977; Island council elections every 4 years, last held
April and May 1975
Political parties and leaders: political parties are
indigenous to each island:
Curacao: National People’s Party-United (NVP-U),
Juan Evertsz; Frente Obrero de Liberation’ 30 di Mayo
(FOL), Wilson “Papa” Godett; Social Democratic Party
(PSD), R. J. Isa; Democratic Party (DP), S. G. M. Rozendaal
Aruba: People’s Electoral Movement (MEP), G. F.
“Betico” Croes; Aruban Patriotic Party (PPA), L. O. Chance:
Aruban People’s Party (AVP), D. G. Croes
Bonaire: Labor Party (POB); Democratic Party Bonaire
(UPB); New Democratic Action (ADEN)
or Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Windward Islands: Windward Islands Democratic
Party (DPWI); United Federation of Antillean Workers
(UFA); Windward Islands Political Movement (WIPM); and
others
Voting strength: (1977 federal election) 6 seats DP, 5 seats
MEP, 3 seats FOL, 3 seats NVP, 3 seats PPA, 1 seat DPWI, 1
seat UPB
Communists: no Communist Party
Member of: EC (associate), WHO','61c3a207d7f807310b56cafa70b45d091c40b1b684fc90ac14382e60b217b6c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f6fc78db7d896c427ff8de0985fdd5f79dfcee72c66190a0343de60edd972e9',1978,'NC','New Caledonia','government',382,'Legal name: Overseas Territory of New Caledonia
Type: French overseas territory; represented in French
parliament by one deputy and one Senator
Capital: Noumea
Political subdivisions: 4 islands or island group depen-
dencies—Isle of Pines, Loyalty Islands, Huon Islands, Island
of New Caledonia
Legal system: French law
149
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
NEW CALEDONIA/NEW HEBRIDES
Branches: administered by Governor, who is also High
Commissioner for France in the Pacific; responsible to
French Ministry for Overseas France and Governing
Council; Assemblee Territoriale
Government leader: Jean Risterucci, Governor and
French High Commissioner
Suffrage: restricted (1957 election roll listed 32,370 males
and females over 21 years of age, of whom 18,964 were
classed as indigenous inhabitants)
Elections: Assembly elections every 5 years, last in
September 1977
Political parties: Rassemblement Pour La Caledonie—
Conservative; Union Caledonienne—eventual indepen-
dence; Union Multiraciale and Palika—independence
parties
Voting strength (1977 election): Rassemblement Pour La
Caledonie, 12 seats; Union Caledonienne, 9 seats; Palika, 2
seats; 8 other parties divide up remaining 12 seats
Communists: number unknown; Union Caledonienne
strongly leftist; some politically active Communists were
deported during 1950''s; small number of North Vietnamese
Other political parties and pressure groups: several
lesser parties
Member of: EIB (associate)
Legal name: New Hebrides Condominium
Type: Anglo-French condominium
Capital: Vila
Political subdivisions: 4 administrative districts
Legal system: 3 sets of courts; one each for French and
British subjects, one for New Hebrides native affairs
Branches: Representative Assembly, 42 members, elected
November 1975
Government leaders: two resident commissioners, one
French, Robert Gauger; one British, John Champion
Political parties and leaders: National Party (Vanuaaku
Pati), chairman Walter Lini; NA Griamel Party, leader
Jimmy Stevens; Mouvement d’Action des Nouvelles Hebri-
des (MANH)
150 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
NEW HEBRIDES/NEW ZEALAND','c79ac132782b940a0922a0cd556a94d9239028a5ee2e847b0bc5b381cb0b3de7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4a8ae94e9bd62ad95a65b1ff9a65e09b5407c198ad8f43cea75c371c9099e8e',1978,'NI','Nicaragua','government',387,'Legal name: Republic of Nicaragua
Type: republic
Capital: Managua
Political
departments
Legal system: based on Spanish civil law system;
subdivisions: 1 national district and 16
constitution adopted in 1974; legal education at Universidad
Nacional de Nicaragua and Universidad Centroamericana;
accepts compulsory ICJ jurisdiction
National holiday: Independence Day, 15 September
Branches: President (traditionally dominant), bicameral
legislature, judiciary elected by legislature, and Supreme
Electoral Tribunal (4th branch)
Government leader: President Anastasio Somoza
Suffrage: universal over age 18 if married or literate,
otherwise 21
Elections: every 6 years; municipal elections every 3 years
Political parties and leaders: Nationalist Liberal Party
(PLN), Anastasio Somoza; Nicaraguan Conservative Party
(PCN), Rene Sandino
Voting strength (1974 elections): PLN, 95% of votes;
PCN, 5% of votes; PCN will, however, occupy 40% of
legislative seats by constitutional provision
Communists: Communist movement split into hard-line
Nicaraguan Socialist Party (PSN) illegal, 60 members;
soft-line Nicaraguan Communist Party (PCN) illegal, 40
members, and small pro-Castro Sandinist National Liber-
ation Front (FSLN) activist, 50-150 members; about 1,000
sympathizers
Other political or pressure groups: Democratic Union of
Liberation (UDEL), an opposition front lacking legal status
of a political party, composed of anti-Somoza political
movements and labor groups with orientations ranging from
conservative to Christian Democrat to Communist, leader-
ship includes Pedro J. Chamorro, Ramiro Sacasa, Ignacio
Zelaya, Domingo Sanchez; Nicaraguan Development Insti-
tute (INDE), a private sector pressure group with two
operative arms: FUNDE and EDUCREDITO which,
respectively, promote cooperatives and disburse educational
loans
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Member of: CACM, FAO, G-77, GATT, IADB, IBRD,
ICAC, ICAO, IDA, IDB, IFC, ILO, IMF, INTELSAT, IPU,
ISO, ITU, NAMUCAR (Caribbean Multinational Shipping
Line—Naviera nacional del Caribe), OAS, ODECA, SELA,
U.N., UNESCO, UPEB, UPU, WHO, WMO','c7432e241a07ab99e7357f1742f55e74588921c632b6548584014ecedc3d8808','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5eb547b84eee871c7f454af2985199416a6b5ed491d516ac903d1f1e31c20d48',1978,'NE','Niger','government',391,'Legal name: Republic of Niger
Type: republic; military regime in power since April 1974
Capital: Niamey
Political subdivisions: 7 departments, 32 arrondissements
Legal system: based on French civil law system and
customary law; constitution adopted 1960, suspended 1974;
judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; has not accepted compulsory ICJ
jurisdiction
National holiday: Proclamation of the Republic, 18
December
Branches: executive authority exercised by Supreme
Military Council (SMC) composed of army officers; cabinet
includes civilians
Government leader: Lt. Col. Seyni Kountche, President
of Supreme Military Council and Chief of State
Suffrage: suspended
Elections: political activity banned
Political parties and leaders: political parties banned
Communists: no Communist party; some sympathizers in
outlawed Sawaba party
Member of: AFDB, APC, CEAO, EAMA, ECA,
ECOWAS, Entente, FAO, G-77, GATT, IAEA, IBRD,
ICAO, IDA, ILO, IMF, IPU, ITU, Lake Chad Basin
Commission, Niger River Commission, NAM, OAU, OCAM,
U.N., UNESCO, UPU, WHO, WIPO, WMO','7308279ca1c8350c85aec4faad3c6543db75407b7d70136aa6c697d4fac48837','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b426c875c9435757bdff349ca8c077e8539f8b528866dbc27868b2fbb842f7e7',1978,'NG','Nigeria','government',396,'Legal name: The Federal Republic of Nigeria
Type: federal republic since 1963; under military rule
since January 1966
155
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
NIGERIA/NORWAY
Capital: Lagos
Political subdivisions: 19 states, headed by military
governors
Legal system: based on English common law, tribal law,
and Islamic law; proposed new constitution to be reviewed
and adopted by October 1979 by a constituent assembly;
accepts compulsory [CJ jurisdiction, with reservations
National holiday: Independence Day, | October
Branches: Federal Military Government; decrees issued
by Supreme Military Council, advised by largely civilian
Vederal Executive Council
Government leader: Lieutenant General Olusegun Oba-
sanjo, Head of Federal Military Government and Com-
mander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage
Kiections: nonpartisan elections for local government
councils held in late 1976; the military has promised to
restore power to an elected civilian regime when state and
federal legislative elections are held between October 1978
and October 1979
Political parties and leaders: political parties and
politically active tribal societies were dissolved by decree on
24 May 1966; some sub rosa political activity continues
Communists: the banned Socialist Workers and Farmers
Party and the Nigerian Trade Union Congress have a
limited political following, no influence on government
Member of: AFDB, APC, Commonwealth, ECA,
HCOWAS, FAO, G-77, IAEA, IBRD, ICAO, IDA, [FC, ILO,
IMCO, IMF, ISO, ITC, ITU, [WC—International Wheat
Council, Lake Chad Basin Commission, Niger River
Commission, NAM, OAU, OPEC, U.N., UNESCO, UPU,
WHO, WMO','90ff1cf98a654e02f1e9bc98c579e3af1aaea4148ae88969f3f332e4a114c342','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5e5ae27d6ca40bb5223ba7c938dce7b0cde8b8ff6383593c90a7173e6891b34',1978,'NO','Norway','government',400,'Legal name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 19 counties, 404 communes, 47
towns
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Legal system: mixture of customary law, civil law system,
and common law traditions; constitution adopted 1814,
modified 1884; Supreme Court renders advisory opinions to
legislature when asked; legal education at University of Oslo;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Constitution Day, 17 May
Branches: legislative authority rests jointly with Crown
and parliament (Storting); executive power vested in Crown
but exercised by cabinet responsible to parliament; Supreme
Court, 5 superior courts, 104 lower courts
Government leaders: King Olav V; Prime Minister Odvar
Nordli
Suffrage: universal, but not compulsory, over age 20
Elections: held every 4 years (next in September 1981)
Political parties and leaders: Labor, Reiulf Steen;
Conservative, Erling Norvik; Center, Gunnar Stalsett;
Christian People’s, Lars Kosvald; Liberal, Hans Hammond
Rossbach; New People’s Party, Magne Lerheim; Socialist
Left, Berge Furre; Norwegian Communist, Martin Gunnar
Knutsen; Progressive, Arve Loennum
Voting strength (1977 election): Labor, 42.5%; Conserva-
tive, 24.6%; Christian People’s, 12.1%; Center, 8.6%; New
People’s Party (anti-tax), 1.7%; Socialist Left (Socialist
Electoral Alliance) (formerly anti-tax), 4.1%; liberal, 3.2%
Progressive, 1.9%; Norwegian Communist, 0.4%, Red
Election Alliance, 0.6%, latter two are communist parties
Communists: 2,500 est.; a number of sympathizers as
indicated by the 22,500 Communist votes cast in the 1969
election (in the 1973 election the Communist Party vote total
was submerged in the 241,851 votes won by the Socialist
Electorial Alliance which included the Norwegian Commu-
nist Party and two other parties)
Member of: ADB, Council of Europe, DAC , EC (Free
Trade Agreement), EFTA, ESRO (observer), FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, IDA, IEA (associate
member), IFC, IHO, ILO, International Lead and Zinc
Study Group, IMCO, IMF, IPU, ITU, IWC—International
Whaling Commission, 1WC—International Wheat Council,
NATO, Nordic Council, OECD, U.N., UNESCO, UPU,
WHO, WIPO, WMO, WSG
Legal name: Sultanate of Oman
Type: absolute monarchy; independent, with strong
residual U.K. influence
Capital: Muscat
Legal system: based on English common law and Islamic
law; no constitution; ultimate appeal to the Sultan; has not
accepted compulsory IC] jurisdiction
National holiday: 18 November
Government leader: Sultan Qabus ibn Sa‘id Al Bu Sa‘id
Other political or pressure groups: Popular Front for the
Liberation of Oman (PFLO), based in South Yemen
158 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
OMAN/PAKISTAN
Member of: Arab League, FAO, G-77, IBRD, ICAO,
IDA, SFC, IMF, NAM, U.N., UNESCO, UPU, WHO','e16e40db45b39e8eae1381aeaefdeb6cda64b2bd4881a57fa021e6d80a165135','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('455eadd8af1d5a7e162537851f26ed2afaf9cafa07a366f458d5a333b6e63169',1978,'PK','Pakistan','government',404,'Legal name: Islamic Republic of Pakistan
Type: parliamentary, federal republic; military seized
power 5 July 1977 and temporarily suspended some
constitutional provisions
Capital: Islamabad
Political subdivisions: 4 provinces—Punjab, Sind, Balu-
chistan, and Northwest Frontier—with the capital territory
of Islamabad and certain tribal areas centrally administered;
Pakistan claims that Azad Kashmir is independent pending a
settlement of the dispute with India, but it is in fact under
Pakistani control
Legal system: based on English common law; accepts
compulsory ICJ jurisdiction, with reservations
National holiday: Pakistan Day, 93 March
Government leaders: President Fazal Elahi Chaudhry;
Chief Martial Law Administrator Mohammed Zia-ul-Haq
159
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
PAKISTAN/PANAMA
Suffrage: universal from age 18
Klections: opposition agitation against rigging of elections
in March 1977 eventually led to military coup; military
promised to hold new national and provincial assembly
elections in October 1977 but later postponed them
indefinitely
Political parties and leaders: Pakistan People’s Party
(PPP), Z. A. Bhutto; Pakistan Muslim League (QML), Abdul
Qaiyum Khan; Pakistan National Alliance (PNA), a coalition
of nine parties including Pakistan Muslim League (PML)—
Pir of Pagaro group; Tehrik-i-Istiqulal, Asghar Khan;
National Democratic Party (NDP), Sherbaz Mazari (formed
in 1975 by members of outlawed National Awami Party
(NAP) of Abdul Wali Khan); Jamaat-i-Islami JI), Tofail
Mohammed; Jamiat-ul-Ulema-i-Pakistan (JUP), Maulana
Shah Ahmed Noorani; Jamiat-ul-Ulema-i-Islam (JU), Mufti
Mahmud; Pakistan Democratic Party (PDP), Nasrullah
Khan
Communists: party membership very small; sympathizers
estimated at several thousand
Other political or pressure groups: military remains
potentially strong political force
Member of: ADB, CENTO, Colombo Plan, FAO, GATT,
G-77, IAEA, IBRD, ICAC, ICAO, IDA, IFC, THO, ILO,
IMCO, IMF, ITU, IWC—International Wheat Council,
RCD, U.N., UNESCO, UPU, WHO, WMO, WSsG','41f1d153c38ca55551d88e0c7d701969e21ada5eeb635382d40d042e0b5087a4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a1e88c6fe4e0b39b46170cad3c834595b5ee090c5d3be210553d60612b9e111',1978,'PA','Panama','government',408,'Legal name: Republic of Panama
Type: republic
Capital: Panama
Political subdivisions: 9 provinces, 1 intendancy
Legal system: based on civil law system; constitution
adopted in 1972; judicial review of legislative acts in the
Supreme Court; legal education at University of Panama;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Independence Day, 3 November
Branches: President (figurehead, subordinate to National
Guard Commandant, General Omar Torrijos, who was
granted special powers for 6 years by the Constitutional
Assembly in 1972); popularly elected unicameral legislature
(Corregimiento), which elects the President but which
exercises few, if any, legislative powers and meets for one
month each year; during the remainder of the year the
National Legislative Council, the President, Vice President,
Cabinet, and selected members of the Corregimiento
exercise legislative functions; presidentially appointed Su-
preme Court
Government leaders: Demetrio Lakas is Constitutional
President and Chief of State, but subordinate to Gen. Omar
Torrijos, the National Guard Commandant and Chief of
Suffrage: universal and compulsory over age 18
Elections: elections for assembly of corregimientos in
1978
Political parties and leaders: political parties suspended;
Communist Party illegal but allowed to operate
Voting strength: no parties were active in the 1972
elections
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Communists: 500 active and several hundred inactive
members People’s Party (PdP); 500-600 members of rival
Fraccion movement which split from PdP in 1974; 2,500
sympathizers
Other political or pressure groups: National Council of
Private Enterprise (CONEP); Panamanian Association of
Business Executives (APEDE)
Member of: FAO, G-77, IADB, IAEA, IBRD, ICAO, IDA,
IDB, IFC, ILO, IMCO, IMF, ITU, IWC— International
Whaling Commission, IWC—International Wheat council,
NAM, OAS, SELA, U.N., UNESCO, UPEB, UPU, WHO,
WMO','eba85791df02be15382727dc81b0049ee382e9a4bb9c17f92e9f3eaee6c27f09','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a6c278426ff81bfa23e6d6df509fc28046784971de30ed0a9a4e49eb3a319aa',1978,'PG','Papua New Guinea','government',412,'Legal name: Papua New Guinea
Type: independent state within Commonwealth recogniz-
ing Elizabeth II as head of state
Capital: Port Moresby
Political subdivisions: 18 administrative districts (12 in
New Guinea, 6 in Papua)
Legal system: based on English common law
National holiday: Independence Day, 16 September
Branches: executive—Executive Council; legislature—
House of Assembly (109 members); judiciary—court system
consists of Supreme Court of Papua New Guinea and various
inferior courts (District Courts, Local Courts, Children’s
Courts, Wardens’ Courts)
Government leaders: Governor General, Tore Lokoloko;
Prime Minister, Michael Somare
Suffrage: universal adult suffrage
Elections: preferential-type elections for 109-member
House of Assembly every 4 years, last held in June 1977
Political parties: Pangu Party, People’s Progress Party,
United Party, Papua Besena
Communists: no significant strength
Member of: ADB, CIPEC (associate), Commonwealth,
ESCAP (associate), G-77, IBRD, IMF, U.N.. WHO
(associate)','c553be250e557fef2ff94032ab4801ec980bf299e5f074b3250ed6a5f061c6f4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4045f60641a4a4db5574aec1ef63c26e8b49464449283aa187ccc0ba630b8286',1978,'PY','Paraguay','government',416,'Legal name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion
Political subdivisions: 16 departments and the national
capital, 154 municipalities
Legal system: based on Argentine codes, Roman law, and
French codes; constitution promulgated 1967; judicial
review of legislative acts in Supreme Court; legal education
at National University of Asuncion and Catholic University
of Our Lady of the Assumption; does not accept compulsory
IC] jurisdiction
National holiday: Independence Day, 14 May
Branches: President heads executive; bicameral legisla-
ture; judiciary headed by Supreme Court
Government leader: President (General) Alfredo
Stroessner
Suffrage: universal; compulsory between ages of 18-60
Elections: President and Congress elected together every
5 years; last election held in February 1973
Political parties and leaders: Colorado Party, Juan
Ramon Chavez; Liberal Party (Levi-Liberal Party), Carlos
Levi Ruffinelli; Febrerista Party, Roque Gaona; Radical
Liberal Party and United Liberal Party (provisional
unification of Liberal and Radical Liberal parties), Miguel
Angel Martinez Yaryes; Christian Democratic Party, Anibal
Recalde Sosa
163
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
PARAGUAY/PERU
Voting strength (February 1973 general election): 84%
Colorado Party, 13% Radical Liberal Party, 3% Liberal
Party, Febrerista Party boycotted elections
Communists: Oscar Creydt faction and Miguel Angel
Soler faction (both illegal); est. 3,000 to 4,000 party members
and sympathizers in Paraguay, very few are hard core; party
in exile is small and deeply divided
Other political or pressure groups: Popular Colorado
Movement (MoPoCo) led by Epifanio Mendez Fleitas, in
exile
Member of: FAO, G-77, IADB, IAEA, IBRD, ICAO, IDA,
IDB, IFC, ILO, IMF, IPU, ITU, LAFTA, OAS, SELA, U.N.,
UNESCO, UPU, WHO, WMO, WSG','115d5b13ce3369fd738aac189e766baa2297cb07ddc6a73a49663ed22aafbe31','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41743ae463b8cafc6b8c50e62ed3454ad09ab8e04141b6652d1c3cc424bae77c',1978,'PE','Peru','government',420,'Legal name: Republic of Peru
Type: republic; under military regime since October 1968
Capital: Lima
Political subdivisions: 23 departments with limited
autonomy plus constitutional Province of Callao
Legal system: based on civil law system; military
government rules by decree and functions under Revolution-
ary Statute which supersedes 1933 constitution; legal
education at the National Universities in Lima, Trujillo,
Arequipa, and Cuzco; has not accepted compulsory IC]
jurisdiction
National holiday: Independence Day, 28 July
Branches: executive, judicial; congress disbanded after 3
October 1968 ouster of President Fernando Belaunde Terry
Government leader: President, General Francisco Mo-
rales Bermudez Cerrutti
Suffrage: obligatory for citizens (defined as adult men
and women and married persons over age 18) until age 60
Elections: June of 1978 a constituent assembly to be
elected to draw up a new constitution; issuance of the new
charter to be followed by presidential and parliamentary
elections in 1980
Political parties and leaders: Christian Democratic Party
(PDC), Juan Lituma Portocarrero, President, supports the
government; opposition parties include the Popular Action
Party (AP), Fernando Belaunde Terry; American Popular
Revolutionary Alliance (APRA), Victor Raul Haya de la
Torre; and Popular Christian Party (PPC), Luis Bedoya
Reyes
Voting strength (1963 election): 39% AP-PDC, 34%
APRA, 25% UNO, 1% Communist, 1% other
Communists: pro-Soviet (PCP/S) 2,000; pro-Chinese (2
factions) 1,200
Member of: AIOEC, ASSIMER, CIPEC, FAO, G-77,
GATT, IADB, IAEA, IATP, IBRD, CIPEC, ICAO, IDA,
IDB, IFC, ILO, International Lead and Zinc Study Group,
IMCO, IMF, ISO, ITU, [WC—International Wheat Council,
LAFTA and Andean Pact, NAM, OAS, U.N., UNESCO,
UPU, WHO, WMO, WSG','a96269ce152138f1a5c9ace30471ceed079df7c09d1dbe2fafe0ed391329991f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2be0751cf096fffd5a70f676d8973f0f273405301ec3272d78bcb0e19e1301dd',1978,'PL','Poland','government',424,'Legal name: Polish Peoples Republic (PRL)
Type: Communist state
Capital: Warsaw
Political subdivisions: 49 provinces
Legal system: mixture of Continental (Napoleonic) civil
law and Communist legal theory; constitution adopted 1952;
court system parallels administrative divisions with Supreme
Court, composed of 104 justices, at apex; no judicial review
of legislative acts; legal education at 7 law schools; has not
accepted compulsory ICJ jurisdiction
National holiday: National Liberation Day, 22 July
Branches: legislative, executive, judicial system domi-
nated by parallel Communist party apparatus
Government leaders: Piotr Jaroszewicz, Premier; Henryk
Jablonski, chairman of Council of State (President)
167
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
POLAND/PORTUGAL
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government every 4
years
Dominant political party and leader: Polish United
Workers’ Party (PZPR) (Communist), Edward Gierek, First
Secretary
Voting strength (1975 election): 99% voted for Commu-
nist-approved single slate
Communists: 2,573,000 party members (June 1977)
Other political or pressure groups: National Unity Front
(FJN), including United Peasant Party (ZSL), Democratic
Party (SD), progovernment pseudo-Catholic Pax Association
and Christian Social Association, Catholic independent Znak
group; powerful Roman Catholic Church, Stefan Cardinal
Wyszynski, Primate
Member of: CEMA, GATT, ICAO, ICES, IHO, Indochina
Truce Commission, International Lead and Zinc Study
Group, IPU, ISO, ITC, Korea Truce Commission, U.N. and
all specialized agencies except IMF and IBRD, Warsaw
Pact, WIPO','1276166860824e8928ac235e2823e13b3ff543e1468e16cdedc7df588eb8c0cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d80e3aee1f7a1a6af45ef07562a3222b481e97f4d1b1e2d8e7d2525acba3371f',1978,'PT','Portugal','government',428,'Legal name: Republic of Portugal
Type: republic, first government under new constitution
formed July 1976; major political parties and officers of
all-military Revolutionary Council signed document in
December 1975 agreeing to multiparty parliamentary
democracy with military oversight for period of 4 years
following presidential elections in June 1976
Capital: Lisbon
Political subdivisions: 18 districts in mainland Portugal
and 2 autonomous districts in Azores and Madeira Islands;
Macao, Portugal’s remaining overseas territory, was granted
broad executive and legislative autonomy in February 1976;
Portugal has not officially recognized the unilateral annex-
ation of Portuguese Timor by Indonesia
Legal system: civil law system; new constitution adopted
April 1976; for next four years, legislative assembly acts to
be reviewed for constitutionality by Revolutionary Council;
vetoes of laws by the Council, through the agency of the
presidency, may be appealed to a Constitutional Commis-
sion as a court of last resort; legal education at Universities of
Lisbon and Coimbra; accepts compulsory ICJ jurisdiction,
with reservations
National holiday: 25 April
Branches: executive with President and Prime Minister,
with 18-member Revolutionary Council as advisory body to
the President; popularly elected Assembly of the Republic;
independent judiciary
Government leaders: President Antonio Ramalho Eanes;
Prime Minister Mario Soares
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Suffrage: universal over age 18, except for those barred
by law for participation in “undemocratic” institutions prior
to April 25, 1974
Elections: national elections for Assembly of the Republic
to be held every 4 years, first Assembly under new
constitution elected April 1976, will sit until October 14,
1980 unless earlier dissolved by the President; national
election for president to be held every 5 years, term of first
constitutional president—elected in June 1976—will end
with 4 year transitional period, local elections to be held
every 3 years, last elections in December 1976
Political parties and leaders: the Portuguese Socialist
Party (PS) is led by Mario Soares, the Social Democratic
Party (PSD), formerly the Popular Democratic Party (PPD),
by Francisco Sa Carneiro, the Social Democratic Center
(CDS) by Diogo Freitas do Amaral, and the Portuguese
Communist Party (PCP) by Alvaro Cunhal
Voting strength: (1976 parliamentary election) the
Socialists polled 35% of the vote; the PSD received 24%, the
CDS 16%, and the Communists 15%; (1976 local elections)
PS 33%, PSD 24%, PCP 18%, CDS 17%
Communists: Portuguese Communist Party claims mem-
bership of around 120,000
Member of: Council of Europe, EFTA, FAO, GATT,
IAFA, IATP, IBRD, ICAC, ICAO (restricted membership),
ICES, IFC, IHO, ILO, IMF, IOOC, ISO, ITU, TWC—
International Wheat Council, NATO, OECD, U.N.,
UNESCO, UPU, WHO, WIPO, WMO, WSG','4aed20d1f08d6bf6504d54cbf858965e540641425cbc01fedd26598d1f86aa6c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fb4e9c8c4cfa030b02649dd3f13c8e5012915fa646edc2f111e80213d57c957',1978,'QA','Qatar','government',432,'Legal name: State of Qatar
Type: traditional monarchy; independence declared in
197]
Capital: Doha
Legal system: discretionary system of law controlled by
the ruler, although new civil codes are being implemented;
Islamic law is significant in personal matters; a constitution
was promulgated in 1970
National holiday: 3 September
Government leader: Amir Khalifa ibn Hamad Al-Thani
Suffrage: no specific provisions for suffrage laid down
Elections: constitution calls for elections for part of State
Advisory Council, semi-legislative body, but none have been
held
Political parties and pressure groups: none; a few small
clandestine organizations are active
nm Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
QATAR/REUNION
Branches: Council of Ministers; appointive 30-member
Advisory Council
Member of: Arab League, FAO, G-77, GATT (de facto),
IBRD, ICAO, ILO, IMF, NAM, OAPEC, OPEC, U.N.,
UNESCO, UPU, WHO, WIPO','b40baa263504d91a53487c25e69a520eef977b1bf82b6d1b5e726d9bdc04ead3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3ae25baf5fdf49a250e9e1bdb3925970a4564be8adace08738e05cabae636c5',1978,'RO','Romania','government',437,'Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 39 counties and 46 municipalities,
including Bucharest that has administrative status equal toa
county
Legal system: mixture of civil law system and Communist
legal theory which increasingly reflects Romanian traditions;
constitution adopted 1965; legal education at University of
Bucharest and two other law schools; has not accepted
compulsory [CJ jurisdiction
National holiday: Liberation Day, 23 August
Branches: Presidency; Council of Ministers; the Grand
National Assembly, under which is Office of Prosecutor
General and Supreme Court; Council of State
Government leaders: Nicolae Ceausescu, President of the
Socialist Republic, head of state; Manea Manescu, Chairman
of the Council of Ministers, head of government
Suffrage: universal over age 18, compulsory
Elections: elections held every 5 years for Grand National
Assembly deputies and local people’s councils
174
Political parties and leaders: Communist Party of
Romania only functioning party, Nicolae Ceausescu, Secre-
tary General
Voting strength (1975 election): overall participation
reached 99.96%: of those registered to vote (14,900,032),
98.8% voted for party candidates
Communists: 2,577,534 party members (December 1975)
Member of: CEMA, FAO, G-77, GATT, IAEA, IBRD,
ICAO, ILO, IMF, IPU, ITC, ITU, U.N., UNESCO, UPU,
Warsaw Pact, WHO, WIPO, WMO','8250acc26430bed861a24c248a36055fc6be9527fe65c29a6fe1d07fe6ee3571','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dacf208d5ab4e93c384b8f8257dd77f486bed2a69492d285b0927444f1219564',1978,'RW','Rwanda','government',441,'Legal name: Republic of Rwanda
Type: republic, presidential system in which military
leaders hold key offices; 1962 constitution still in force
except for Title V on the National Assembly
ROMANIA/RWANDA
Capital: Kigali
Political subdivisions: 10 prefectures, subdivided into
142 communes
Legal system: based on German and Belgian civil law
systems and customary law; constitution adopted 1962;
judicial review of legislative acts in the Supreme Court; has
not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 1 July
Branches: President, and 15-member cabinet
Government leader: General Juvenal Habyarimana,
Head of State
Suffrage: universal
Elections: last legislative election September 1969; none
allowed by present government; elections of Communal
Counsellors held November 1974
Political parties and leaders: National Revolutionary
Movement for Development, General Habyarimana
Communists: no Communist party; U.S.S.R. and People’s
Republic of China have diplomatic missions in Rwanda
Member of: AFDB, EAMA, FAO, G-77, GATT, IBRD,
ICAO, IDA, ILO, IMF, IPU, ITU, NAM, OAU, OCAM,
U.N., UNESCO, UPU, WHO, WMO','6307891967630d4ed70b1121c2809f4f7f07276caae57d699d95a88b0a2e18a9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32162045ea7404eb800b91e15704f73d158c4ef3b55dc121f70b981477aa140d',1978,'SM','San Marino','government',445,'Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in 1862 the
Kingdom of Italy concluded a treaty guaranteeing the
independence of San Marino; although legally sovereign, San
Marino is vulnerable to pressure from the Italian
Capital: San Marino
Political subdivisions: San Marino is divided into 9
castelli: Acquaviva, Borgo Maggiore, Chiesanuova, Dogman-
ano, Faetano, Fiorentino, Monte Giardino, San Marino,
Serravalle
Legal system: based on civil law system with Italian law
influences; electoral law of 1926 serves some of the functions
of a constitution; has not accepted compulsory ICJ
jurisdiction
Branches: the Grand and General Council is the
legislative body elected by popular vote; its 60 members
serve 5-year terms; Council in turn elects two Captains-Re-
gent who exercise executive power for term of 6 months, the
Council of State whose members head government adsinis-
trative departments and the Council of Twelve, the supreme
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
judicial body; actual executive power is wielded by the
Secretary of State for Foreign Affairs and the Secretary of
State for Internal Affairs
Government leaders: Secretary of State for Foreign and
Political Affairs and for Information, Giancarlo Ghironzi
(Christian Democratic party); Secretary of State for Internal
Affairs and Justice, Clara Boscaglia (Christian Democratic
party); Secretary of State for Budget, Finance, and Planning,
Remy Giacomini (Socialist Party)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General Council
required at least every 5 years; next elections 1979
Political parties and leaders: Christian Democratic party
(DCS), Gian Luigi Berti; Social Democratic Party (PSDSM),
Alvaro Casali; Socialist Party (PSS), Remy Giacomini;
Communist Party (PCS), Umberto Barulli; People’s Demo-
cratic Party (PDP), leader unknown; Committee for the
Defense of the Republic (CDR), leader unknown
Voting strength (1974 election): 39.6% DCS, 23.7% PCS,
15.4% PSDIS, 13.9% PSS, 1.9% PDP, 2.9% CDR
Communists: approx. 300 members (number of sympa-
thizers cannot be determined); PSS, in government with
Christian Democrats since March 1978, formed a govern-
ment with the PCS from the end of World War II to 1957
Other political parties or pressure groups: political
parties influenced by policies of their counterparts in Italy,
the two Socialist parties are not united
Member of: ICJ, International Institute for Unification of
Private Law, International Relief Union, IRC, UPU','7bdb8e05dd45a17f2bc32e9224742ff87c34a046ef0110fa7e1d6da4b3b48bf1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82586f84c5f218a005888af5996b97769f577971d9ee8fb1b2b01045be691ec0',1978,'ST','Sao Tome and Principe','government',449,'Legal name: Democratic Republic of Sao Tome and
Principe
Type: republic established when independence received
from Portugal in July 1975; constitution adopted December
1975
Capital: Sao Tome
Legal system: based on Portuguese law system and
customary law; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 12 July
Branches: Da Costa heads the government assisted by a
cabinet of ministers
Government leaders: President Manuel Pinto Da Costa,
Prime Minister Miguel Anjos da Cuna Lisboa Trovoada
Suffrage: universal for age 18 and over
Elections: elections were held July 1975 for the President
Political parties and leaders: Movement for the Liber-
ation of Sao Tome and Principe (MLSTP), Secretary-General
Manuel Pinto Da Costa
Communists: no Communist party, probably a few
Communist sympathizers
Member of: G-77, NAM, OAU, U.N.','82903974db33fbeaeddd162f108db5dfb7bd0742dd41b802a243eb6ba34211fc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f10b8a590854d3db34096d91e273ef91ee3141e55e5c43444a8e2f5340c34595',1978,'SA','Saudi Arabia','government',453,'Legal name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh; foreign ministry and foreign diplomatic
representatives located in Jiddah
Political subdivisions: 18 amirates
Legal system: largely based on Islamic law, several
secular codes have been introduced; commercial disputes
handled by special committees; has not accepted compulsory
ICJ jurisdiction
National holiday: 23 September
Branches: King Khalid (Al Saud, Khalid ibn Abd al-Aziz)
rules in consultation with royal family (especially Crown
Prince Fahd), and Council of Ministers
Government leader: King Khalid
Communists: negligible
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, IMF, ITU, IWC—International Wheat
Council, NAM, OAPEC, OPEC, U.N., UNESCO, UPU,
WHO, WMO','6a9bd02d1fb377faa41198c8c134f69d506adbe6dc8749af92cc4c1198b45f32','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('974129fc1093ba7ceadf76335905da82bcb23ee333da1670b63cab4fd5daff6c',1978,'SN','Senegal','government',457,'Legal name: Republic of Senegal
Type: republic
Capital: Dakar
Political subdivisions: 8 regions, each subdivided into 27
departments, 95 arrondissements
Legal system: based on French civil law system;
constitution adopted 1960, revised 1963 and 1970; judicial
review of legislative acts in Supreme Court (which also
audits the government''s accounting office); legal education
at University of Dakar; has not accepted compulsory IC]
jurisdiction 7
National holiday: Independence Day, 4 April
Branches: government dominated by President who is
assisted by Prime Minister, appointed by President and
subject to dismissal by President or censure by National
Assembly; 100-member National Assembly, elected for 5
years (effective 1973); President elected for 5-year term
(effective 1973) by universal suffrage; judiciary headed by
Supreme Court, with members appointed by President
Government leaders: Leopold Sedar Senghor, President;
Abdou Diouf, Prime Minister
Suffrage: universal adult
Elections: uncontested presidential and legislative elec-
tions held February 1973 for 5-year term
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SENEGAL/SEYCHELLES
Political parties and leaders: legal parties are Parti
Socialiste (PS), ruling party led by President Leopold
Senghor; Parti Democratique Senegalaise (PDS), “liberal
democratic” party founded July 1974, and “Marxist-Lenin-
ist” African Independence Party (PAI), legalized in August
1976; unauthorized parties include clandestine PAI splinter
group, leftist Rassemblement Nationale Democratique, and
Parti Communiste Senegalais (PCS)
Communists: small number of Communists and sympa-
thizers associated with PAI and PCS
Other political or pressure groups: students and teachers
occasionally strike
Member of: AFDB, APC, CEAO, EAMA, ECA,
ECOWAS, EIB, (associate), FAO, G-77, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, ITU, NAM,
OAU, OCAM, OMVS (Organization for the Development of
the Senegal River Valley), U.N., UNESCO, UPU, WHO,
WIPO, WMO','24055f2b22870972487617bc7d08cbb684447af29f5200e659cb675d9a7cfeb4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('559c9d21cda823ca1176b1a9793d6f509773987732d1ef097c99b507622ae012',1978,'SC','Seychelles','government',461,'Legal name: Seychelles
Type: republic; member of the Commonwealth
Capital: Victoria, Mahe Island
Legal] system: based on English common law, French civil
law system, and customary law
National holiday: 29 June
Branches: President, Council of Ministers
Government leader: President, France Albert Rene
Suffrage: universal adult
Elections: April 1974, new government has promised
election by June 1979, but not before new constitution
drafted :
Political parties and leaders: Rene, who heads the
Seychelles People’s United Party, came to power by a
military coup in June 1977, until then he had been Prime
Minister in an uneasy coalition with then President James
Mancham, who headed the Seychelles Democratic Party.
The Seychelles Democratic Party has not been banned but
has been moribund since the coup. Rene dissolved the
National Assembly, and plans to rule by presidential decree
until a new constitution is drafted. Rene abrogated the
constitution without qualification upon taking power.
Subsequently the government decided to retain some
provisions, but presidential decree enables the President and
specified subordinates to violate constitutional safeguards in
interests of state security
Communists: negligible
Other political or pressure groups: trade unions which
are appendages of political parties
Member of: G-77, NAM, OAU, U.N.','cf3a57b11f9dc5ca45aa5bd7c20054304cbf5ffee98ec87d0ff40db4cd627c5b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85d2540e17967504e3ac8be9cdd8ab9dab7f1c7abac8cd6f09dc4ad3d50e38ad',1978,'SL','Sierra Leone','government',465,'Legal name: Republic of Sierra Leone
Type: republic under presidential regime since April 1971
Capital: Freetown
Political subdivisions: 8 provinces; divided into 12
districts with 146 chiefdoms, where paramount chief and
council of elders constitute basic unit of government; plus
western area, which comprises Freetown and other coastal
areas of the former colony
Legal system: based on English law and customary laws
indigenous to local tribes; constitution adopted April 1971;
highest court of appeal is the Sierra Leone Court of Appeals;
has not accepted compulsory ICJ jurisdiction
National holiday: National Day, 19 April
Branches: executive authority exercised by President;
parliament consists of 100 authorized seats, 85 of which are
filled by elected representatives of constituencies and 12 by
Paramount Chiefs elected by fellow Paramount Chiefs in
each district; President authorized to appoint four members,
of which two, currently, are filled by the heads of the Army
and the Police independent judiciary
Covernment leader: Siaka Stevens, President, heads APC
government composed of members of his political party
Suffrage: universal over age 21
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Flections: the maximum life of an elected parliament is 5
years, but it may be dissolved earlier by the President;
parliamentary election held in May 1977; President is
elected by parliament for 5 year term; next presidential
election 1981
Political parties and leaders: All People’s Congress
(APC), headed by Stevens; Sierra Leone People’s Party
(SLPP) is the opposition party
Communists: no party, although there are a few
Communists and a slightly larger number of sympathizers
Member of: AFDB, AIOEC, Commonwealth, ECA,
ECOWAS, FAO, G-77, GATT, IAEA, IBA, IBRD, ICAO,
IDA, IFC, ILO, IMF, IPU, ITU, NAM, OAU, UN.,
UNESCO, UPU, WHO, WMO','be5d047709edefdb53df60b093bc7bf16c355b1c592e5985eaeaf27b90fba7a0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69278496316bb372835f84fa5022711383f927217149c26ad226b2dc9327cca8',1978,'SG','Singapore','government',468,'Legal name: Republic of Singapore
Type: republic within Commonwealth since separation
from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law; constitution
based on preindependence State of Singapore constitution;
legal education at University of Singapore; has not accepted
compulsory ICJ jurisdiction
National holiday: 9 August
Branches: ceremonial President; executive power exer-
cised by Prime Minister and cabinet responsible to unitary
legislature
Government leaders: President, Dr. Benjamin Sheares;
Prime Minister, Lee Kuan Yew
Suffrage: universal over age 20: voting compulsory
Elections: normally every 5 years
Political parties and _ leaders: government—People’s
Action Party (PAP), Lee Kuan Yew; opposition—Barisan
Sosialis Party (BSP), Dr. Lee Siew Choh; Workers’ Party, J.
B. Jeyaretnam; Communist Party illegal
Voting strength (1976 election): PAP won all 69 seats in
Parliament and received 72.4% of vote: remaining 27.6% to
four opposition parties
Communists: 200-500; Barisan Sosialis Party infiltrated
by Communists
Member of: ADB, ANRPC, ASEAN, Colombo Plan, G-77,
GATT, IBRD, ICAO, IFC, IHO, ILO, IMCO, IMF, IPU,
ISO, ITU, NAM, U.N., UNESCO, UPU, WHO, WMO','367f2438019cf66b3e708d7cfeccd7c97ff7b406f8268b01d5c1fbe8e93ee1e9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c66b77b2d07a88c1986d190eaefb7329a9d5401b997677752cd7362acb114636',1978,'SO','Somalia','government',471,'Legal name: Somali Democratic Republic
Type: republic
Capital: Mogadiscio
National holiday: 21 October
Political subdivisions: 16 regions, 60 districts
Organization: the Somali Socialist Revolutionary Party,
created on July 1; 1976, has become the new executive body
in the country; party has 74-man central committee and
5-man politburo headed by President Siad
Government leader: President and Prime Minister, Gen.
Mohamed Siad Barre
Communists: possibly some Communist sympathizers in
the government hierarchy
Member of: AFDB, EAMA, FAO, G-77, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, NAM, OAU, U.N., UNESCO,
UPU, WHO, WMO','0ecf7b1c80cd4c31d8f6fdf96618099f18fd8f61a11cbde663f4e714aca425ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e8a50f64004d03bc7b2edcac3b40f9ef9eccd0f91ff03281a911388a7b237e4',1978,'ZA','South Africa','government',475,'Legal name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape Town:
judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by
centrally appointed administrator; provincial councils, elect-
ed by white electorate, retain limited powers
Legal system: based on Roman-Dutch law and English
common law; constitution enacted 1961, changing the Union
of South Africa into a Republic; possibility of judicial review
of Acts of Parliament concerning dual official languages;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Republic Day, 31 May
Branches: President as formal chief of state; Prime
Minister as head of government; Cabinet responsible to
bicameral legislature; lower house elected directly by white
electorate; upper house indirectly elected and appointed;
judiciary maintains substantial independence of government
influence
Government leader: Prime Minister Balthazar Johannes
Vorster
Suffrage: general suffrage limited to whites over 18 (17 in
Natal Province)
Elections: must be held at least every 5 years; last
elections 830 November 1977
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
Political parties and leaders: National Party, B. J.
Vorster, P. W. Botha, C. Mulder, R. F. Botha; Progressive
Federal Party, Colin Eglin, Ray Swart, Helen Suzman, New
Republic Party, Radclyffe Cadman; South Africa Party,
Myburgh Streicher; Herstigte Nasionale Party, J. Marais
Voting strength: (1977 general elections) parliamentary
seats: 134 National Party, 17 Progressive Federal Party, 10
New Republic Party, 8 South Africa Party
Communists: small Communist Party illegal since 1950,
party in exile maintains headquarters in London; Dr. Yasuf
Dadoo, Moses Kotane, Joe Slovo
Other political groups: (insurgent groups in exile) African
National Congress (ANC), Oliver Tambo; Pan- Africanist
Congress (PAC), leadership in dispute
Member of: GATT, IAEA, IBRD, ICAO, IDA, IFC, THO,
International Lead and Zinc Study Group, IMF, ISO, ITU,
IWC—International Whaling Commission, [WC—Interna-
tional Wheat Council, U.N., UPU, WHO, WIPO, WMO,
WSG
Legal name: Republic of Transkei
Type: republic
Capital: Umtata
Political subdivisions: 28 administrative districts
Legal system: based on English common law and African
customary law; decisions of Transkei Supreme Court can be
appealed to South African Supreme Court
Branches: President as formal chief of state: Prime
Minister as head of government; Cabinet responsible to
National Assembly, which has 75 seats for hereditary tribal
chiefs and 75 seats for popularly elected members
Government leader: Prime Minister Kaiser Matanzima
Suffrage: Transkeian citizens over 21 years of age
Flections: must be held at least every 5 years; last general
election October 1976
Political parties and leaders: Transkei National Inde-
pendence Party, Chief Kaiser Matanzima; Transkei People’s
Freedom Party, Cromwell Diko; Democratic Party, Hector
Neokazi; New Democratic Party, Knowledge Guzana
Voting strength: (1976 general election) National Assem-
bly seats; 142 Transkei National Independence Party, 4
Transkei People’s Freedom Party, 2 Democratic Party, 2
New Democratic Party
Communists: no Communist Party','73a5bd54c5feddfa67bbce0f445e80730293e417f07efb7e374798903b47e46e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf46f29dc09d25516ad60ddc818d12500c8e2d0d90e006e86d2cdd63739cce38',1978,'ES','Spain','government',479,'Legal name: (The) Spanish State
Type: a monarchy in the process of replacing the
authoritarian regime of the late Generalissimo Franco witha
modified Western-style parliamentary system; Juan Carlos
proclaimed King, on November 22, 1975
Capital: Madrid
Political subdivisions: metropolitan Spain, including the
Canaries and Balearics, divided into 50 provinces with
governors appointed by the central government; also 5
places of sovereignty (presidios) on the Mediterranean coast
of Morocco; transferred administration of Spanish Sahara to
Morocco and Mauritania on February 26, 1976
Legal system: civil law system, with regional applications
of customary law; the 7 basic laws of the Franco era
constitution were greatly modified by the constitutional law
for political reform of December 1976 providing for a
freely-elected parliament to draw up a new constitution;
judges decide cases, no jury system; does not accept
compulsory ICJ jurisdiction
National holiday: 12 October
Branches: executive, with King’s acts subject to counter-
signature, Prime Minister appointed for 5-year term by the
King from 3 names submitted by King’s advisory Council of
the Realm, may be removed by the King with consent of the
Council; not legally responsible to the parliament; legislative
with new bicameral Cortes elected on June 15 this year
likely to adjust the executive-legislative relationship through
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
its consituent power; the more powerful Chamber has 350
members chosen by proportional representation, and the
Senate has 248 members (207 directly elected and 41
appointed by the King); judicial, independent in principle
but generally limited to interpretation of laws
Government leaders: King Juan Carlos I—Chief of State,
and Commander in Chief of the armed forces; and Prime
Minister Adolfo Suarez Gonzalez
Suffrage: universal in national referendums, over age 2]
and in parliamentary elections, beginning in June 1977
Elections: free parliamentary elections in June 1977 for 4-
year term; postponed local elections promised by end of the
year but likely to be delayed at best until February 1978
Political parties and leaders: Under the revised law on
political parties of February 1977 over 150 parties were
legalized by the time of the parliamentary election in June
and others have been approved after the election. Most of
the prominent semiclandestine parties of the Franco era
have been legalized, including the Spanish Communist Party
(PCE). Franco’s National Movement was dissolved in April.
In view of the multiplicity of parties, a number of
electoral coalitions were formed. The principal national
coalitions and parties from right to left are: the Popular
Alliance (AP)—the conservative coalition led by ex-minister
Fraga and including 6 other former ministers under Franco,
the major rightist group—made a poor showing in the
parliamentary election, The Union of the Democratic
Center (UCD)—a center-right coalition of 15 reform-
minded parties backing Prime Minister Suarez—includes ex-
ministers Calvo-Sotelo and Cabanillas, Social Democrat
Fernandez-Ordonez, Liberal Democrat Garrigues Walker,
and Christian Democrat Alvarez de Miranda. Suarez forged
the coalition into a single party on 4 August 1977. The
Spanish Socialist Workers Party (PSOE), led by Felipe
Gonzalez, is the major party of the democratic left. Two
much smaller contenders are the Popular Socialist Party of
Enrique Tierno Galvan and the PSOE (Historical Branch),
which Gonzalez hopes to bring into the PSOE. The Spanish
Communist Party (PCE), led by Santiago Carrillo, and its
several regional branches espouse Eurocommunism. There
are also several Basque and Catalan regional parties of
mixed orientation which are united by their goal of greater
regional autonomy.
Voting strength: (1977 parliamentary election) UCD
polled 34% of votes and received 165 chamber seats (47.1%),
1] seats short of a majority, the PSOE polled 28.5% and
received 118 seats (34%); the PCE polled 9.2% and received
20 seats (5.7%); the AP polled 8.2% and received 16 seats; the
PSP polled 4.3% and received 6 seats; the various Basque
and Catalan regional parties received 20 seats.
Communists: PCE claimed to have 200,000 members
before legalization in April and said it would have 300,000
by the election in June, figures that are difficult to analyze.
191
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SPAIN/SRI LANKA
Other political or pressure groups: on the extreme left,
the illegal Basque Fatherland and Liberty (ETA) and the
Anti-Fascist and Patriotic Revolutionary Front (FRAP) use
terrorism to oppose the government; on the extreme right,
the Guerrillas of Christ the King carry out vigilante attacks
on ETA members and other leftists: free labor unions
(authorized in April 1977) include the Communist-domi-
nated Workers’ Commissions; the Socialist General Union of
Workers (UGT), and the independent Worker’s Syndical
Union (USO); the Catholic Church; business and land
owning interests; Opus Dei; Catholic Action; university
students
Member of: ASSIMER, ESRO, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC, THO, ILO,
International Lead and Zinc Study Group, IMCO, IMF,
IOOC, IPU, ITC, ITU, [WC—International Wheat Council,
OAS (observer), OECD, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG:; applied for full membership in the FC
28 July 1977; invited to join Council of Europe 18 October
1977','cb89a665e68bee89f1e816656ae2b2b66c384c70e34967ef2933262f1bfcba1f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f35859921041946d0c07149ae6bcb9a2df4385db6b4b78d4958c3f91df79ae56',1978,'LK','Sri Lanka','government',483,'Legal name: Republic of Sri Lanka
Type: independent state since 1948
Capital: Colombo
Political subdivisions: 9 provinces, 22 administrative
districts, and four categories of semiautonomous elected
local governments
Legal system: a highly complex mixture of English
common law, Roman-Dutch, Muslim and customary law;
new constitution 22 May 1972; no judicial review of
legislative acts; legal education at Sri Lanka Law College
and University of Sri Lanka, Peradeniya; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 22 May
Branches: On 4 October 1977, the Constitution of Sri
Lanka was amended to establish a strong presidential form
of government. When the law is promulgated on | January
1978, Prime Minister Jayawardene will automatically
become president. He will remain president until 1983,
regardless of whether parliament is dissolved and subsequent
parliamentary elections are held. When his term in office
expires, a new president will be chosen by a direct national
election for a six year term.
Government leader: Prime Minister J. R. Jayewardene
Suffrage: universal over age 18, but most Indian Tamils,
who comprise 10.6% of population, are not enfranchised
Elections: national elections, ordinarily held every 6
years; must be held more frequently if government loses
confidence vote; last election held May 1977
Political parties and leaders: Sri Lanka Freedom Party,
Sirimavo Ratwatte Dias Bandaranaike, President; Lanka
Sama Samaja Party (Trotskyite), N. M. Perera, President;
Tamil United Liberation Front, A. Amirthalingam leader;
United National Party, J. R. Jayewardene; Communist
Party/Moscow, Pieter Keuneman, General Secretary; Com-
munist Party/Peking, N. Shanmugathasan, General Secre-
tary; Mahajana Eksath Peramuna (People’s United Front),
M. B. Ratnayaka, President
Voting strength (1970 election): 30% Sri Lanka Freedom
Party, 51% United National Party, 3.9% Lanka Sama Samaja
Party, 1.8% Communist Party/Moscow, 6.5% TULF minor
parties and independents accounted for remainder
Communists: approximately 107,000 voted for the
Communist Party in the May 1977 general election;
Communist Party/Moscow approximately 5,000 members
(1975), Communist Party/Peking 1,000 members (1970 est.)
Other political or pressure groups: Buddhist clergy,
Sinhalese Buddhist lay groups; far-left violent revolutionary
groups; labor unions
Member of: ADB, ANRPC, Colombo Plan, Common-
wealth, FAO, G-77, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMCO, IMF, IPU, NAM, U.N., UNESCO, UPU, WHO,
WMO','929c360eec50f22e7750ffbab6baa4ad56cfd575c3b6cecff443fc33d2054647','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7d16819e3df863f8ec08af8938c4e39262496b931a9b8068983cc1c0fb06b56',1978,'SD','Sudan','government',487,'Legal name: Democratic Republic of the Sudan
Type: republic under military control since coup in May
1969
Capital: Khartoum
Political subdivisions: 18 provinces, provincial and local
administrations controlled by central government; limited
regional autonomy in 6 southern provinces
Legal system: based on English common law and Islamic
law; some separate religious courts; permanent constitution
promulgated April 1973; legal education at University of
Khartoum and Khartoum extension of Cairo University at
Khartoum; accepts compulsory ICJ jurisdiction, with
reservations
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SUDAN/SURINAM
National holiday: Independence Day, 1 January
Government leader: President Jafar al-Numayri
Suffrage: universal adult
Elections: elections for Southern Regional People’s
Assembly held in November 1973; elections for National
People’s Assembly scheduled for March 1978; most recent
Presidential election held April 1977 with Numayri as sole
candidate
Political parties and leaders: all parliamentary political
parties outlawed since May 1969; the ban on the Sudan
Communist Party was not enforced until after abortive coup
in July 1971; the government’s mass political organization,
the Sudan Socialist Union, was formed in January 1972
Communists: party decimated following July 1971 coup
and counter-coup, several top leaders executed; actual
hard-core membership down to lowest point in years; party
control over labor unions, professional groups and university
student groups ended; Communists purged from govern-
ment; party is being reorganized underground under
leadership of Secretary-General Muhammad Nujud, 3,500
CP members
Other political or pressure groups: Muslim Brotherhood;
Ansar Muslim sect, at odds with the military regime since
the May coup, are being reintegrated into national political
life; Sudan Opposition Front, composed of former political
party elements and other disgruntled conservative interests,
is also being asked to join national reconciliation effort
Member of: AFDB, APC, Arab League, FAO, G-77,
IAEA, IBRD, ICAC, ICAO, IDA, IFC, ILO, IMF, ITU,
NAM, OAU, U.N., UNESCO, UPU, WHO, WIPO, WMO
Legal name: Republic of Surinam
Type: Parliamentary Democracy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by District
Commissioner responsible to Minister of District government
and Decentralization except for Paramaribo, whose commis-
sioner is responsible to Minister of Home Affairs
Legal system: Dutch civil law system; constitution
adopted November 1975
National holiday: Independence Day, 25 November
Branches: President (Chief of State) elected by Parlia-
ment for five-year term; Council of Ministers headed by a
Prime Minister constitutes the Cabinet; 39-member Parlia-
ment popularly elected for 4-year term; court system
administered by Attorney-General under Minister of Justice
and Police
Government leaders: President, Johan H. E. Ferrier;
Prime Minister, Henck A. E. Arron
Suffrage: universal over age 21
Elections: every 4 years or earlier upon request of Prime
Minister; latest held October 1977 won by National Party
Combination (NPK), a creole-based election coalition in
which the National Party of Surinam (NPS) is the largest
party
Political parties and leaders: National Party of Surinam
(NPS), Henck A. E. Arron; Nationalist Republic Party
(PNR), Edward Bruma (principal leftist party); Progressive
Reform Party (VHP), J. Lachmon; United Indonesian
People’s Party (SRI), F. Karsowidijojo; Javanese Farmers’
Party (KTPI), Willy Soemita; Progressive Surinam People’s
Party (PSV), Emile Wijntuin; Reformed Progressive Party
(HPP), George Hindorie
Voting strength (1977): NPK 22 seats, Opposition United
Democratic Parties Combination (VDP) 15 seats
Communists: (all small groups) Democratic Peoples
Front, Communist Third Front, People’s Party Progressive
Laborers and Farmers Union
Member of: EC (associate), ECLA, G-77, IBA, ILO, ITU,
OAS, U.N., UNESCO, UPU, WIPO, WMO
Legal name: Kingdom of Swaziland
Type: monarchy, under King Sobhuza II; independent
member of Commonwealth since September 1968
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Capital: Mbabane (administrative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-Dutch law
in statutory courts, Swazi traditional law and custom in
traditional courts; legal education at University of Botswana
and Swaziland (located in Swaziland); has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 6 September
Branches: in April 1973 King abolished the constitution,
dismissed parliament, and assumed personal rule; he has
ruled under a King-in-Council arrangement with the cabinet
being retained as an advisory council; a constitutional
commission submitted recommendations in June 1975, but
King has not authorized further action toward a new
constitution
Government leaders: Head of State King Sobhuza IL;
Prime Minister Maphevu Dlamini
Suffrage: universal for adults
Elections: first elections for Legislative Council held in
June 1964; latest for House of Assembly in May 1972
Political parties and leaders: Imbokodvo, the traditional-
ist party, controlled by King Sobhuza IE the opposition
Ngwane National Liberatory Congress (NNLC), led by Dr.
Ambrose Zwane, has been dissolved
Voting strength: in 1972 elections, Imbokodvo won 21
seats, NNLC won 8 seats in the House of Assembly
Communists: no Communist Party
Member of: AFDB, FAO, G-77, GATT (de facto), IBRD,
ICAO, IDA, IFC, IMF, ISO, ITU, NAM, OAU, U.N., UPU,
WHO','92eb3fa80c7c9ff779138e01d6b082177fb1153d5e1c58b0ddf27902d79b026d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0057db1a37175c7c52b4f7d3d935d67dd9e2b7c78c34136cb4df52319b34bb8f',1978,'SE','Sweden','government',491,'Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces, 624 communes, 224
towns
Legal system: civil law system influenced by customary
law; Acts of 1809, 1810, 1866, and 1949 serve as constitution;
legal education at Universities of Lund, Stockholm, and
Uppsala; accepts compulsory ICJ jurisdiction, with
reservations
National holiday: Birthday of the King, 30 April
Branches: legislative authority rests with parliament
(Riksdag); executive power vested in cabinet, responsible to
parliament; Supreme Court, 6 superior courts, 108 lower
courts
Government leaders: King Carl XVI Gustaf; Prime
Minister Thorbjorn Falldin
Suffrage: universal, but not compulsory, over age 20
Elections: every 3 years (next in September 1979)
Political parties and leaders: Moderate Coalition (con-
servative), Gosta Bohman; Center, Thorbjorn Falldin;
Liberal, Per Ahlmark; Social Democratic, Olof Palme: Left
Party Communist, Lars Werner; Swedish Communist Party,
Roland Petersson; Swedish Workers’ Party, Rolf Hagel;
Communist League of Marxist Leninists-Revolutionary
(KFML-R), Frank Baude
Voting strength (1976 election): 15.6% Moderate Coali-
tion, 24.1% Center, 11.0% Liberal, 42.9% Social Democratic,
4.7% Communist, 1.7% other
Communists: 17,000; a number of sympathizers as
indicated by the 257,967 Communist votes cast in 1973
elections; an additional 17,274 votes cast for Maoist KFML
Member of: ADB, Council of Europe, DAC, EC (Free
Trade Agreement), EFTA, ESRO, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC, IHO, ILO,
International Lead and Zine Study Group, IMCO, IMF, IPU,
IsO, ITU, IWC—International Whaling Commission,
IWC—International Wheat Council, Nordic Council,
OECD, U.N., UNESCO, UPU, WHO, WIPO, WMO, WSG
ue Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
SWEDEN/SWITZERLAND','1e7ebc5979fbfb377a27a087746c3ce4b6be70ba72dd1e59268c25047d8fab11','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7df7e73c4e7d809eafb2a4623e93bf57438245e1f5110fa2d19d6646a0bdebd6',1978,'CH','Switzerland','government',494,'Legal name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 22 cantons (3 divided into half
cantons); a local referendum held in Bern Canton in 1975
indicated that three districts wished to form a separate
canton for a portion of the French-speaking Jura region
Legal system: civil law system influenced by customary
law; constitution adopted 1874, amended since; judicial
review of legislative acts, except with respect to Federal
decrees of general obligatory character; legal education at
Universities of Bern, Geneva and Lausanne, and four other
university schools of law; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: 1 August
Branches: bicameral parliament has legislative authority;
federal council (Bundesrat) has executive authority; justice
left chiefly to cantons
Government leader: Kurt Furgler (1-year term as
President began on January 1977), President
Suffrage: universal over age 20
Elections: held every 4 years; next elections 1979
Political parties and leaders: Social Democratic Party
(SPS), Arthur Schmid, president; Radical Democratic Party
(FDP), Henri Schmitt, president; Christian Conservative
People’s Party (CVP), Franz Josef Kurmann, president; Swiss
People’s Party (SVP), Hans Conzett, president; Communist
Party (PdA), Jean Vincent, leading Secretariat member;
National Action Party (N.A.), James Schwarzenbach
Voting strength (1975 election): 22.2% FDP, 20.6% CVP,
25.4% SPS, 10.2% BGB, 2.2% PdA, 2.5% N.A., 3.0% Rep,
6.2% LdU, 2.3% Lidus, 2.0% EvP, 1.3% POSH, 2.2% other
Communists: less than 60,000 votes in 1975 election
Other parties: Landesring (LdU); Republican Movement
(Rep); Liberal Democratic Union (Lidus); Evangelical Party
(EvP); Maoist Party (POSH/PSA)
Member of: ADB, Council of Europe, DAC, EFTA,
ELDO (observer), ESRO, FAO, GATT, IAEA, ICAC, ICAO,
IEA, ILO, IMCO, IPU, ITU, I[WC—International Wheat
Council, OECD, U.N. (permanent observer), UNESCO,
UPU, WCL, WHO, WIPO, WMO, WSG
Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime since
March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of Damascus
administered as separate unit
Legal system: based on Islamic law and civil law system,
special religious courts; constitution promulgated in 1973;
legal education at Damascus University and University of
Aleppo; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 17 April
Branches: executive powers vested in President and
Council of Ministers; legislative power rests in the People’s
Assembly; seat of power is the Ba’th Party Regional (Syrian)
Command
Government leader: President Hafiz Al-Asad
Suffrage: universal at age 18
Elections: no electoral laws being drafted; last elections in
December 1961; presidential referendum in 1971; local
councils elected in March 1972
Political parties and leaders: ruling party is the Arab
Socialist Resurrectionist (Ba’th) Party; the “national front”
cabinet is dominated by Ba’thists, but includes independents
and members of the Syrian Arab Socialist Party (ASP), Arab
Socialist Union (ASU), and Syrian Communist Party (SCP)
Communists: mostly sympathizers, numbering about
5,000
Other political or pressure groups: non-Ba’th parties
have little effective political influence; Communist Party
ineffective; greatest threat to Ba’thist regime lies in
factionalism in Ba’th Party itself; conservative religious
leaders
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IOOC, IPU, ITU,
IWC—International Wheat Council, NAM, OAPEC, U.N.,
UNESCO, UPU, WFTU, WHO, WMO, WSG','0b11449a963a4692cc8b77efa05968d9b6187e515431432b1e93d5c7fc0ab9d7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('537c1ceb23b6d016c9107b4169354ea9783aa7b22f654ad47ecddbefc10686fe',1978,'TH','Thailand','government',498,'Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 71 centrally controlled provinces
Legal system: based on civil law system, with influences
of common law; new constitution being drafted; legal
education at Thammasat University; has not accepted
compulsory ICJ jurisdiction
National holiday: National Day, 5 December
Branches: King is head of state with nominal powers;
civilian government suspended on 20 October 1977; military
staffed Revolutionary Party governing in interim pending
selection of new cabinet; judiciary relatively independent
except in important political subversive cases
Government leaders: King Phumiphon Adundet
Elections: suspended
Political parties: suspended
Communists: strength of illegal Communist Party is about
1,200; Thai Communist insurgents throughout Thailand
total about 9,400
Member of: ADB, ANRPC, ASEAN, ASPAC, Colombo
Plan, ESCAP, FAO, G-77, IAEA, IBRD, ICAO, IDA, IFC,
THO, ILO, IMF, IPU, ITC, ITU, SEAMES, U.N., UNESCO,
UPU, WHO, WMO','8d949eaf1e6dc0fe25f6354a224316aad2618f81050a3ef1596ce8dbd8d32b17','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3d0c7e7dbd6dbc67d753e9334f5c7b1e8aa740059df7d868b9d589f25fd98ed',1978,'TG','Togo','government',502,'Legal name: Togolese Republic
Type: republic; under military rule since January 1967
Capital: Lome
Political subdivisions: 21 circumscriptions
Legal system: based on French civil law and customary
practice; no constitution; has not accepted compulsory IC]
jurisdiction
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
National holiday: Independence Day, 27 April
Branches: military government, with civilian-dominated
cabinet, took over on 14 April 1967, replacing provisional
government created after January coup; no legislature;
separate judiciary including State Security Court established
1970
Government leader: General Gnassingbé Eyadéma, Presi-
dent, Minister of National Defense, and Armed Forces Chief
of Staff
Suffrage: universal adult
Elections: presidential referendum of January 1972
elected Gen. Eyadéma for indefinite period
Political party: single party formed by President Eya-
déma in September 1969, Rassemblement du Peuple
Togolais, structure and staffing of party closely controlled by
Communists: no Communist some
sympathizers
Member of: AFDB, CEAO (observer), EAMA, ECA,
ECOWAS, ENTENTE, FAO, G-77, GATT, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, NAM, OAU, OCAM, ULN.,
UNESCO, UPU, WHO, WIPO, WMO
Party; possibly','f63b6f2aa7a1ab035f63317b100b7e1672e4fff7f523b027ba42547ae15d4465','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a86f92b3e60735a2e3eef4db9a39f970803e08b7365abd51aaa26b277c07bc92',1978,'TO','Tonga','government',506,'Legal name: Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa
Political subdivisions: 3 main island groups (Tongatapu,
Haapi, Vavau)
Legal system: based on English law
Branches: Executive (King and Privy Council); Legisla-
tive (Legislative Assembly composed of 7 nobles elected by
their peers, 7 elected representatives of the people, 7
Ministers of the Crown; the King appoints one of the 7
nobles to be the speaker); Judiciary (Supreme Court,
magistrate courts, Land Court)
Government leaders: King Taufa’ahau Tupou IV; Pre-
mier, Prince Tu''ipelehake (younger brother of the King)
Suffrage: granted to all literate adults over 21 years of age
who pay taxes
Flections: held every 3 years
Communists: none known
Member of: ADB, Commonwealth','0015919d8861f06efde3893ca54c1f2ced5f039605da2499adc9bb7e6d3f222b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3dd14dd40702259bad1ebae6c70005428a3b789fec9ce852377bac0365d9fd6',1978,'TT','Trinidad and Tobago','government',510,'Legal name: Republic of Trinidad and Tobago
Type: independent state since August 1962; in August
1976 country officially became a republic severing legal ties
with British crown
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards, Tobago is
30th)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Legal system: based on English common law; constitution
came into effect 1976; judicial review of legislative acts in
the Supreme Court; has not accepted compulsory IC]
jurisdiction
National holiday: 31 August
Branches: legislative branch consists of 36-member
elected House of Representatives and 31-member appointed
Senate; executive is cabinet led by the Prime Minister;
judiciary is headed by the Chief Justice and includes a Court
of Appeal, High Court, and lower courts
Government leader: Prime Minister, Dr. Eric Williams
Suffrage: universal over age 18
Elections: elections to be held at intervals of not more
than five years; last election held 13 September 1976
Political parties and leaders: People’s National Move-
ment (PNM), Dr. Eric Williams; United Labor Front (ULF),
Raffique Shah; Democratic Labor Party (DLP), Dr. Romesh
Mootoo; Democratic Action Congress (DAC), Arthur Napo-
leon Raymond Robinson; West Indian National Party
(WINP), Ashford Sinanani; Tapia House Movement, Lloyd
Best :
Voting strength (1976 election): 56% of registered voters
cast ballots, PNM captured 24 seats in House of Representa-
tives, ULF 10, and DAC the two Tobago seats
Communists: not significant
Other political pressure groups: National Joint Action
Congress (NJAC), radical anti-government Black-identity
organization; United Revolutionary Organization (URO),
Marxist amalgam; Trinidad and Tobago Peace Council,
leftist organization affiliated with the World Peace Council;
Trinidad and Tobago Chamber of Industry and Commerce;
Trinidad and Tobago Labor Congress, moderate labor
federation; Council of Progressive Trade Unions, radical
labor federation
Member of: CARICOM, Commonwealth, FAO, G-77,
GATT, IADB, IBRD, International Coffee Agreement,
ICAO, IDA, IDB, IFC, ILO, IMCO, IMF, ISO, ITU, IWC—
International Wheat Council, NAM, OAS, SELA, U.N,
UNESCO, UPU, WHO, WMO','d00b4eb0603c9de1e6ed83c9548111d157208ac15c8952a157ed90c0f939520d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8a17443538f554ee6bfaf060fa8f7a433cc51dce1c6c418c72bdf569be19164',1978,'TN','Tunisia','government',514,'Legal name: Republic of Tunisia
Type: republic
Capital: Tunis
Political subdivisions: 17 governorates (provinces)
Legal system: based on French civil law system and
Islamic law; constitution patterned on Turkish and US.
constitutions adopted 1959; some judicial review of legisla-
tive acts in the Supreme Court in joint session; legal
education at Institute of Higher Studies and Ecole
Superieure de Droit of the University of Tunis; has not
accepted compulsory IC] jurisdiction
National holiday: Independence Day, 1 June
Branches: executive dominant; unicameral legislative
largely advisory; judicial, patterned on French system and
Koranic law
Government leaders: President Habib Bourguiba; Prime
Minister Hedi Nouira
: CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
TUNISIA/TURKEY
Suffrage: universal over age 21
Elections: national elections held every 5 years; last
elections 2 November 1974
Political party and leader: Destourian Socialist Party,
Habib Bourguiba
Voting strength (1974 election): 100% Destourian Social-
ist Party
Communists: a small number of nominal Communists,
mostly students; Tunisian Communist Party proscribed in
January 1963
Member of: AFDB, Arab League, AIOEC, EC (associ-
ation until 1974), FAO, G-77, IAEA, IBRD, ICAO, IDA,
IFC, ILO, International Lead and Zinc Study Group, IMCO,
IMF, IO0OC, ITU, IWC—International Wheat Council,
NAM, OAU, U.N., UNESCO, UPU, WHO, WIPO, WMO
Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal
systems; constitution adopted 1961; judicial review of
legislative acts by Constitutional Court; legal education at
Universities of Ankara and Istanbul; accepts compulsory IC]
jurisdiction, with reservations
National holiday: Republic Day, 29 October
Branches: President elected by parliament; Prime Minis-
ter appointed by President from members of parliament;
Prime Minister is effective executive; cabinet, selected by
Prime Minister and approved by President, must command
majority support in lower house; parliament bicameral
under constitution promulgated in 1961; National Assembly
has 450 members serving 4 years; Senate has 150 elected
members, one-third elected every 2 years, 15 appointed by
the President to 6-year terms (one-third appointed every 2
years), and 18 life members; highest court for ordinary
criminal and civil cases is Court of Cassation, which hears
appeals directly from criminal, commercial, basic, and peace
courts
Government leaders: President Fahri Koruturk; three-
party coalition comprising JP, NSP, and NAP took power on
1 August 1977
Suffrage: universal over age 21
Elections: National Assembly and Senate (1/3 of seats),
Republican People’s Party won a plurality in June 1977:
Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People’s Party (RPP), Bulent
Ecevit; National Salvation Party (NSP), Necmettin Erbakan:
Democratic Party (DP), Ferruh Bozbeyli; Republican
Reliance Party (RRP), Turhan Feyzioglu; Nationalist Action
Party (NAP), Alpaslan Turkes; Unity Party (UP), Mustafa
Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government in March 1971 and
remains an influential force in national affairs
Member of: ASSIMER, CENTO, Council of Europe, EC
{associate member), ECOSOC, FAO, GATT, IAEA, IBRD,
ICAC, ICAO, IDA, IEA, IFC, IHO, ILO, IMCO, IMF,
TOOC, IPU, ITC, ITU, NATO, OECD, Regional Coopera-
tion for Development, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG','565c2d0936713a2cc6989ec2996a04559be17b00f996bbab99660e572e7364a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0d3044546089fe7d82f5214264d67a292b97dfc9a0d0140b58aac6bc648c9d4',1978,'TV','Tuvalu','government',518,'Legal name: Tuvalu
Type: British crown colony with a large measure of
self-government; independence expected in October 1978
Capital: Funafuti
House of Assembly: eight members
Chief minister: Toalipi Lauti
Her Majesty’s Commissioner (Governor): Thomas Layng
Legal name: Republic of Uganda
Type: republic independent since October 1962
Capital: Kampala
Political subdivisions: 10 provinces and 34 districts
211
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
UGANDA/U.S.S.R.
Legal system: based on English common law and
customary law; constitution adopted 1967; present govern-
ment rules despotically, has intimidated judicial officials and
has made constitution of no consequence; legal education at
Makerere University, Kampala; accepts compulsory IC]
jurisdiction, with reservations
National holiday: Independence Day, 9 October
Branches: Field Marshall Amin rules by decree; assisted
by Council of Ministers and Defense Council, a group of
military officers
Government leader: Field Marshall Idi Amin, President
for life
Suffrage: universal adult
Elections: none scheduled by military government
Political parties: none
Communists: possibly a few sympathizers
Member of: AFDB, Commonwealth, EAC, FAO, G-77,
GATT, IAEA, IBRD, ICAC, ICAO, IDA, IFC, ILO, IMF,
ISO, ITU, NAM, OAU, U.N., UNESCO, UPU, WHO,
WIPO, WMO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, 20 autonomous
republics, 6 krays, 121 oblasts, and 8 autonomous oblasts
Legal system: civil law system as modified by Communist
legal theory; constitution adopted 1936; no judicial review of
legislative acts; legal education at 18 universities and 4 law
institutes; has not accepted compulsory IC] jurisdiction
National holiday: October Revolution Day, 7 November
Branches: Council of Ministers (executive), Supreme
Soviet (legislative), Supreme Court of U.S.S.R. (judicial)
Government leaders: Leonid I. Brezhnev, General
Secretary of the Central Committee of the Communist Party
and Chairman of the Presidium of the U.S.S.R. Supreme
Soviet; Aleksey N. Kosygin, Chairman of the Council of
Ministers; Nikolay V. Podgornyy, Chairman of the Presid-
ium of the U.S.S.R. Supreme Soviet
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every 5 years; 1,517 deputies
elected in 1974; 72.2% party members
Political party: Communist Party of the Soviet Union
(CPSU) only party permitted
Voting strength (1974 election): 153,237,112 persons over
18; allegedly 99.98% voted
Communists: over 16 million party members
Other political or pressure groups: Komsomol, trade
unions, and other organizations which facilitate Communist
control
Member of: CEMA, Geneva Disarmament Conference,
IAEA, ICAC, ICAO, ICES, ILO, International Lead and
Zine Study Group, IMCO, IPU, ISO, ITC, ITU, IWC—
International Whaling Commission, IWC—International
Wheat Council, U.N., UNESCO, UPU, Warsaw Pact, WHO,
WIPO, WMO, Universal Copyright Convention','8273d744f3dd1b2921886d22021e7413b3c9c674a77f7382bccde19977ab1e8d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6267b8c8cc1e08c06f8604861fb7342c0f4e7c9fb9f55e3c64b6c47ed225608f',1978,'AE','United Arab Emirates','government',522,'Legal name: United Arab Emirates (composed of former
Trucial States)
Member states: Abu Dhabi; Ajman; Dubai; Fujairah; Ras
al-Khaimah; Sharjah; Umm al-Qaiwain
Type: federation; constitution signed December 1971,
which delegated specified powers to the United Arab
Emirates central government and reserved other powers to
member shaykhdoms
Capital: Abu Dhabi
Legal system: secular codes are being introduced by the
U.A.E. government and in several member shaykhdoms;
Islamic law remains very influential
National holiday: 2 December
Branches: Supreme Council of Rulers (7 members), from
which a President and Vice President are elected; Prime
Minister and Council of Ministers; National Consultative
Council; federal Supreme Court
Government leaders: Shaykh Zayid of Abu Dhabi,
President; Shaykh Rashid of Dubai, Vice President; Shaykh
Maktum of Dubai, Prime Minister
Suffrage: none
Elections: none
Political or pressure groups: none; a few small clandes-
tine groups are active
Member of: Arab League, G-77, [BRD, ICAO, ILO, IMF,
NAM, OAPEC, OPEC, U.N., UNESCO, UPU, WHO,
WIPO','cdfb81786a62ac57b2e5241297ca2e7675656b3e48cca1493a94399306d5fd67','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('934049c93f3c8026e3d9e3e80e407d9180dfd39fe9df61adb85450f650648543',1978,'GB','United Kingdom','government',526,'Legal name: United Kingdom of Great Britain and
Northern Ireland
Type: constitutional monarchy
Capital: London
Political subdivisions: 635 parliamentary constituencies
Legal system: common law tradition with early Roman
and modern continental influences; no judicial review of
Acts of Parliament; accepts compulsory ICJ jurisdiction,
with reservations
National holiday: Celebration of Birthday of the Queen,
16 June
Branches: legislative authority resides in Parliament;
executive authority lies with collectively responsible cabinet
led by Prime Minister; House of Lords is supreme judicial
authority and highest court of appeal
Government leader: Prime Minister James Callaghan
Suffrage: universal over age 18
Elections: at discretion of Prime Minister, but must be
held before expiration of a 5-year electoral mandate; last
election 10 October 1974
Political parties and leaders: Conservative, Margaret
Thatcher; Labor, James Callaghan; Liberal, David Steel;
Communist, Gordan McLennan; Scottish National, William
Wolfe; Plaid Cymru, Phi] Williams
Voting strength (1974 election): Conservative 277 seats
(35.9%), Labor 319 seats (39.3%); Liberal 13 seats (18.3%);
Scottish National 11 seats (2.8%); Plaid Cymru 8 seats (0.6%);
other 12 seats (3.2%)
Communists: 29,000
Other political or pressure groups: Trades Union
Congress, Confederation of British Industry, National
Farmers’ Union
Member of: ADB, CENTO, Colombo Plan, Council of
Europe, DAC, EC, EEC, ELDO, ESRO, EURATOM, FAO,
GATT, JAEA, IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC,
IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IOOG, IPU, ISO, ITC, ITU, WC—Interna-
tional Whaling Commission, IWC—lInternational Wheat
Council, NATO, OECD, UN., UNESCO, UPU, WEU,
WHO, WIPO, WMO, WSG
Legal name: Republic of Upper Volta
Type: republic; military regime in power since January
1966
Capital: Ouagadougou
Political subdivisions: 10 departments, composed of 44
cercles, headed by civilian prefects
Legal system: based on French civil law system and
customary law; constitution adopted 1970, suspended
February 1974; a national referendum on a draft constitu-
tion is expected in the last quarter of 1977; legislative and
aiG Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
UPPER VOLTA/URUGUAY
presidential elections to be held within six months after new
constitution has been approved; judicial review of legislative
acts in Supreme Court; has not accepted compulsory IC]
jurisdiction
National holiday: Proclamation of the Republic, 11
December
Branches: President is an army officer; 57-man National
Assembly was elected in December 1970, suspended
February 1974
Government leader: Gen. Sangoule Lamizana, President
and Prime Minister
Suffrage: universal for adults
Elections: all political activity has been banned, Parlia-
mentary and Presidential elections expected toward the end
of 1977
Political parties and leaders: ban on political parties and
activities, imposed February 1974, lifted 1 October 1977
Communists: no Communist party; some sympathizers
Other political or pressure groups: labor organizations
are badly splintered, students and teachers occasionally
strike
Member of: AFDB, CEAO, EAMA, ECA, EIB (associate),
Entente, FAO, G-77, IBRD, ICAO, IDA, ILO, IMF, IPU,
ITU, NAM, Niger River Commission, OAU, OCAM, U.N.,
UNESCO, UPU, WCL, WHO, WIPO, WMO','c60526ddc752ae6e465617691754ebd856c571eef04d015998b858ebd70cc3f6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('561a65714a2bd442294042f3e0e655c93e0eb86ef4dbf6bbee4de66739a1e2e0',1978,'UY','Uruguay','government',530,'Legal name: Oriental Republic of Uruguay
Type: republic, government under strong military
influence
Capital: Montevideo
Political subdivisions: 19 departments with limited
autonomy
Legal system: based on Spanish civil law system; new
constitution implemented 1967; judicial review of legislative
acts in Supreme Court; legal education at University of the
Republic at Montevideo; accepts compulsory IC) jurisdiction
National holiday: Independence Day, 25 August
Branches: executive, headed by President; since 1973 the
military has had considerable influence in policymaking;
bicameral legislature (closed indefinitely by presidential
decree in June 1973), Council of State set up to act as
legislature; national judiciary headed by Supreme Court
Government leader: President Aparecio Mendez
Suffrage: universal over age 18
Elections: projected for 1980
Political parties and leaders: political activities are
proscribed
Voting strength (1971 elections): 40.8% Colorado, 40.1%
Blanco, 18.6% Frente Amplio, 0.5% Radical Christian Union
Communists: 35,000-40,000 including Communist youth
group and sympathizers
Other political or pressure groups: Communist Party
(PCU), Rodney Arismendi (in exile in the ULS.S.R.):
Christian Democratic Party (PDC); Socialist Party of
Uruguay (PSU); Revolutionary Movement of Uruguay
(MRO) pro-Cuban Communist Party; National Liberation
Movement (MLN-Tupamaros) Marxist revolutionary terror-
ist group
Member of: FAO, G-77, GATT, IADB, IAEA, IBRD,
ICAO, IDB, IFC, ILO, IMCO, IMF, ITU, LAFTA, OAS,
SELA, U.N., UNESCO, UPU, WHO, WMO, WSG
218
Approved For Release 2005/04/22 :
Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St. Peter''s,
the Vatican Palace and Museum and neighboring buildings
covering more than 18 acres; 13 buildings in Rome, although
outside the boundaries, enjoy extraterritorial rights
Legal system: Canon law; constitutional laws of 1929
serve some of the functions of a constitution
National holiday: 30 June
Branches: the Pope possesses full executive, legislative,
and judicial powers; he delegates these powers to the
governor of Vatican City, who is subject to pontifical
appointment and recall; high Vatican offices include the
Secretariat of State, the College of Cardinals (chief papal
advisers), the Roman Curia (which carries on the central
administration of the Roman Catholic Church), the Presi-
dence of the Prefecture for the Economy, and the synod of
bishops (created in 1965)
Government leader: Supreme Pontiff, Paul VI (Giovanni
Battista Montini, born 26 September 1897, elected Pope 21
June 1963)
Suffrage: limited to cardinals less than 80 in age
Elections: Supreme Pontiff elected for life by College of
Cardinals
Communists: none known
Other political or pressure groups: none (exclusive of
influence exercised by other church officers in universal
Roman Catholic Church)
Member: IAEA, IWC—International Wheat Council,
U.N. (permanent observer)
Legal name: Republic of Venezuela
Type: republic
Capital: Caracas
Political subdivisions: 20 states, 1 federal district, 2
federal territories
Legal system: based on Spanish civil law system with
influence of U.S. law; constitution promulgated 1961:
judicial review of legislative acts in Cassation Court only;
dual court system, state and federal; legal education at
Central University of Venezuela; has not accepted compul-
sory 1OJ jurisdiction
National holiday: Independence Day, 5 July
Branches: executive (President), bicameral legislature,
judiciary
Government leader: President Carlos Andres Perez
Suffrage: universal and compulsory over age 18
Elections: every 5 years: next to be held December 1978
Political parties and leaders: Accion Democratica (AD),
Carlos Andres Perez and Gonzalo Barrios; Social Christian
Party (COPED, Rafael Caldera and Luis Herrera Campins;
People’s Electoral Movement (MEP), Jesus Angel Paz
Galarraga; Partido Comunista de Venezuela (PCV), Secre-
tary-General Jesus Faria; Movement to Socialism (MAS),
Teodoro Petkoff and Pompey Marquez
Voting strength (1973 election): 49% AD, 37% COPEI,
5% New Force (MEP & PCV), 4% MAS, 83% URD, 2% others
Communists: 4,000-6,000 members (est.)
Other political or pressure groups: Fedecamaras (a
conservative business group); PRO VENEZUELA (leftist,
nationalist economic group); DESARROLLISTAS (group of
wealthy, independent businessmen led by former finance
minister Pedro Tinoco and historian Guillermo Moron)
Member of: Andean Pact, AIOEC, FAO, G-77, IADB,
IAEA, IBRD, ICAO, IDB, IFC, IHO, ILO, IMF, IPU, ITU,
!WC—International Wheat Council, LAFTA, NAMUCAR
(Caribbean Multinational Shipping Line—Naviera Multina-
cional del Caribe), OAS, OPEC, SELA, U.N., UNESCO,
UPL, WHO, WMO
Legal name: Socialist Republic of Vietnam
Type: Communist state
Capital: Hanoi
Political subdivisions: 38 provinces
Legal system: based on Communist legal theory and
French civil law system; constitution enacted 1960
National holiday: 2 September
Branches: constitution provides for a National Assembly
and highly centralized executive nominally subordinate to it
Party and government leaders: Ton Duc Thang, Presi-
dent of DRV; Le Duan, First Secretary; Truong Chinh,
Chairman, Standing Committee of National Assembly;
Pham Van Dong, Premier; Vo Nguyen Giap, Minister of
National Defense; Nguyen Duy Trinh, Minister for Foreign
Affairs
Suffrage: over age 18
Elections: pro forma elections held for national and local
assemblies; lastest election for National Assembly held on
April 25, 1976
Political parties: ruled by Lao Dong Party (Communist)
with membership of approximately 900,000; minor subordi-
nate parties
Member of: ADB, ESCAP, G-77, IBRD, IMF, NAM, U.N.
(permanent observer) UNESCO, UNGA, WHO, WIPO
221
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
VIETNAM/WALLIS AND FUTUNA','0d38d047e6735914b648b754a46d8a09b0063b721ee21ddde989bef4ecb81bbc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70b60860178809e01573a0254102a61f211be0367cfcdb0dacabeb7a7d30ead3',1978,'WF','Wallis and Futuna','government',534,'Legal name: Territory of the Wallis and Futuna Islands
Type: overseas territory of France
Capital: Matu Utu
Political subdivisions: 3 districts
Branches: territorial assembly of 20 members; popular
election of one deputy to National Assembly in Paris, and
one Senator
Government leader: Superior Administrator Jacques de
Agostini
Suffrage: universal adult
Elections: every 5 years
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
WALLIS AND FUTUNA/WESTERN SAHARA','e4a995e8016eed93f12a58465b4bb765af9afbcd9cad3e92fe94be97d324c08d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a03082ddb8ecd624ba2e37cd6f1c5ea514a042cf664211a5c7513a22fa72de6a',1978,'EH','Western Sahara','government',538,'Type: legal status of territory unresolved; territory
partitioned between Morocco and Mauritania; the legal
question of sovereignty over the area has yet to be
determined; both countries have established political admin-
istration within their own zones of influence; the line of
partition begins at a point on the coast where the Atlantic
Ocean intersects the 24th parallel, and extends in a
southeasterly direction to the point where the 23d parallel
intersects the 13th meridian
Legal name: The Independent State of Western Samoa
Type: constitutional monarchy under native chief; special
treaty relationship with New Zealand
Capital: Apia
Legal system: based on English common law and local
customs; constitution came into effect upon independence in
1962; judicial review of legislative acts with respect to
fundamental rights of the citizen: has not accepted
compulsory IC] jurisdiction
ade Approved For Release 2005/04/22 :
National holiday: 1 January
Branches: Head of State and Executive Council; Legisla-
tive Assembly; Supreme Court, Court of Appeal, Land and
Titles Court, village courts
Government leaders: Head of State, Malietoa Tanumafili
I; Prime Minister, Tupuola Efi
Suffrage: 45 Samoan members of Legislative Assembly
are elected by holders of matai (heads of family) titles (about
5,000); 2 European members are elected by universal adult
suffrage
Elections: held triennially, last in February 1976
Political parties and leaders: no clearly defined political
party structure
Communists: unknown
Member of: ADB, Commonwealth, ESCAP, G-77, IBRD,
IFC, IMF, U.N., WHO
Legal name: Peoples Democratic Republic of Yemen
Type: republic; power centered in ruling Unified National
Front Party
Capital: Aden; Madinat ash Sha’b, administrative capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal matters)
and English common law (for commercial matters), highest
judicial organ, Federal High Court, interprets constitution
and determines disputes between states
National holiday: 14 October
Branches: Presidential Council; cabinet; Supreme Peo-
ple’s Council
Government leaders: Chairman of Presidential Council,
Salim Rubayyi Ali; Prime Minister Ali Nasir Muhammed
al-Hasani; NF Secretary General Abd Al-Fattah Ismail
Suffrage: granted by constitution to all citizens 18 and
over
Elections: elections for legislative body, Supreme People’s
Council, called for in constitution, none have been held
Political parties and leaders: Unified National Front
(NF), the only legal party, is coalition of National Front,
Baath, and Communist parties
Communists: unknown number
Member of: Arab League, FAO, G-77, GATT (de facto),
IBRD, ICAO, IDA, ILO, IMF, ITU, NAM, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Yemen Arab Republic
Type: republic; military regime assumed power in June
1974
Capital: Sana
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law, and
local customary law; first constitution promulgated
December 1970, suspended June 1974; has not accepted
compulsory ICJ jurisdiction
National holiday: Proclamation of the Republic, 26
September
Branches: Military Command Council, Prime Minister,
cabinet
226
Approved For Release 2005/04/22 :
Government leaders: Head of Military Command Coun-
cil, Lt. Col. Ahmad Ghashmi; Prime Minister Abd al-Aziz
Abd _ al-Ghani
Communists: small number
Political parties or pressure groups: Yemeni Union, a
small inactive government party formed in February 1973;
conservative tribal groups, some Muslim Brotherhood
followers, leftist sentiment represented by pro-Iraqi Baath-
ists, Nasirists, small clandestine groups supported by Yemen
(Aden)
Member of: Arab League, FAO, G-77, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, NAM, U.N., UNESCO, UPU,
WHO, WMO
Legal name: Socialist Federal Republic of Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Political subdivisions: 6 republics with 2 autonomous
provinces (within the Republic of Serbia)
Legal system: mixture of civil law system and Communist
legal theory; constitution adopted 1974; legal education at
several law schools; has not accepted compulsory ICJ
jurisdiction
National holiday: Proclamation of the Socialist. Federal
Republic of Yugoslavia, 29 November
Branches: parliament (Federal Assembly) constitutionally
supreme; executive includes cabinet (Federal Executive
Council) and the federal administration; independent
judiciary; the State Presidency is a collective policymaking
body composed of a representative from each republic and
province, Tito presides as President of the Republic
Government leader: Josip Broz Tito, President of
Republic and President of League of Communists of
Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years by a
complicated, indirect system of voting
Political parties and leaders: League of Communists of
Yugoslavia (LCY) only; leaders are President Tito and
influential presidium members Edvard Kardelj, Vladimir
Bakaric, and Stane Dolanc
Voting strength: voter participation in national elections
has declined, as follows—1963, 95.5%; 1965, 93.6%; 1967,
89%; 1969, 88%; 1974, no data available
Communists: 1,500,000 party members (April 1977)
Other political or pressure groups: Socialist Alliance of
Working People of Yugoslavia (SAWPY), the major mass
front organization for the LCY; Confederation of Trade
Unions of Yugoslavia (CTUY), Union of Youth of Yugoslavia
(UYY), Federation of Yugoslav War Veterans (SUBNOR)
Member of: ASSIMER, CEMA (observer but participates
in certain commissions), EC (5-year non-preferential trade
agreement signed in May 1973), FAO, G-77, GATT, IAEA,
IBA, IBRD, ICAC, ICAO, IDA, IFC, IHO, ILO, Interna-
tional Lead and Zinc Study Group, IMCO, IMF, IPU, ITC,
ITU, NAM, OECD (participant in some activities), U.N.,
UNESCO, UPU, WHO, WIPO, WMO
Legal name: Republic of Zaire (until October 1971 known
as Democratic Republic of the Congo)
Type: republic; constitution establishes strong presidential
system
Capital: Kinshasa
Political subdivisions: 8 regions and federal district of
Kinshasa
Legal system: based on Belgian civil law system and tribal
law; new constitution promulgated 1967, revised 1974; legal
CIA-RDP79-01051A000900010004-4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4
January 1978
ZAIRE/ZAMBIA
education at National University of Zaire; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 30 June
Branches: president elected 1970 for seven-year term
limited to two five-year terms, thereafter; National Legisla-
tive Council of 210 members elected for five-year term; the
official party is the supreme political institution
Government leader: Lt. Gen. Mobutu Sese Seko,
President
Suffrage: universal and compulsory over age 18
Elections: presidential and legislative elections in October
and November 1970; elections for urban zone councils,
legislative council, and political bureau of sole political party
held in October 1977
Political parties and leaders: Mouvement Populaire de la
Revolution (MPR), only legal party, organized from above
Voting strength: MPR slate polled 96.3% of vote in 1970
elections
Communists: no Communist Party; U.S.S.R. and Peoples
Republic of China have diplomatic missions in Zaire
Member of: AFDB, APC, CIPEC, EAMA, EIB (associate),
FAO, G-77, GATT, IAEA, IBRD, ICAO, IDA, IFC, THO,
ILO, IMF, IPU, ITC, ITU, NAM, OAU, OCAM, UDEAC,
U.N., UNESCO, UPU, WHO, WIPO, WMO','3f0ff8bba0c724a7c4239800fa03cb497ca18e24918f2de8fda02e7cfaf6df32','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab9b590c60fe73b4f49f4e2491e059a01a76966835664ea231015187c6054452',1978,'ZM','Zambia','government',542,'Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
Political subdivisions: 9 provinces
Legal system: based on English common law and
customary law; new constitution adopted September 1973;
judicial review of legislative acts in an ad hoc constitutional
council; legal education at University of Zambia in Lusaka;
has not accepted compulsory IC] jurisdiction
National holiday: 24 October
Branches: modified presidential system; unicameral legis-
lative; judiciary
Government leaders: President Kenneth Kaunda; Prime
Minister Mainza Chona
Suffrage: universal adult
Elections: general election scheduled for 1978
Political parties and leaders: United National Independ-
ence Party (UNIP), Kenneth Kaunda; former opposition
party banned in December 1972 when 1 party state
proclaimed
Voting strength (1973 election): in first presidential and
parliamentary elections under single-party system, 43% of
eligible voters went to polls; Kaunda was only candidate for
President; National Assembly seats were contested by
members of UNIP
Communists: no Communist Party, but sympathizers of
socialism in upper levels of government, UNIP, and labor
unions
Member of: AFDB, Commonwealth, FAO, G-77, GATT
(de facto), IAEA, IBRD, ICAO, IDA, IDB, IEA, IFC, ILO,
International Lead and Zinc Study Group, IMF, IPU, ITU,
NAM, OAU, U.N., UNESCO, UPU, WHO, WMO
mae Approved For Release 2005/04/22','ff118f35253a2d7e2291c25eced192e8d84bdccdf54bef217c6131868d382ca2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ae77255e6eba343eb4fc8365b471540180c31689b091e5d4f26536d99e0c48b',1978,'US','United States','government',546,'Legal name: United States of America
Legal system: based on English common law; dual system
of courts, state and federal; constitution adopted 1789;
judicial review of legislative acts, accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Independence Day, 4 July
Voting strength (1976 presidential election); Democratic
Party (Carter), 40,291,626 (51%); Republican Party (Ford),
38,563,089 (48%); minor parties, 826,258 (preliminary
figures)
Communists: party membership, 10,000-11,000 (est.);
General Secretary, Gus Hall
Member of: ADB, ANZUS, CENTO, Colombo Plan,
DAC, FAO, GATT, IADB, IAEA, IBRD, ICAC, ICAO,
ICES, IDA, IDB, IEA, IFC, THO, ILO, International Lead
and Zinc Study Group, IMCO, IMF, IPU, ITC, ITU, IWC—
International Whaling Commission, IWC— International
Wheat Council, NATO, OAS, OECD, U.N., UNESCO,
UPU, WHO, WIPO, WMO, WSG
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010004-4','388e7480b881feb4f5738e50658cbee2a220686afce260326ab965a081558aeb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010004-4','txt','ed44eaa6c5a9c3e95ad1f2a6e631b897600fb2d98f3255f5d9aa55f27f77c6a5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010004-4/cia-rdp79-01051a000900010004-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27a35f371c517563b5525d792f27f8b19201643e0c90d07183ba5e213b41d9cf',1978,'AF','Afghanistan','government',5,'Legal name: Republic of Afghanistan
Type: martial law
Capital: Kabul
Political subdivisions: 26 provinces with centrally ap-
pointed governors
Legal system: not established; legal education at Uni-
versity of Kabul; has not accepted compulsory ICJ
jurisdiction
Branches: leaders of the Khalk communist party seized
power in late April 1978; they are in the process of forming a
People’s Democratic Party; its central committee will be the
highest authority in the state; future government structure is
unclear
Covernment leaders: President of the Revolutionary
Counci) and Prime Minister Nur Mohammad Taraki; Vice
President of the Revolutionary Council and Deputy Prime
Minister Babrak Karmal; Minister of Defense Col. Abdul
Qader
Suffrage: universal from age 18
Political parties and leaders: The People’s Democratic
Party of Afghanistan is being formed by the new regime
Communists: Khalq, a pro-Moscow party, led by Taraki
and Karmal, claims 50,000 members, the Sholaye-Jaweid is a
much smaller pro-Peking group
Other political or pressure groups: the military supports
the government; possible religious or tribal opposition
Member of: ADB, Colombo Plan, FAO, G-77, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, NAM, ULN.,
UNESCO, UPU, WHO, WMO, WSG','832f4cb6168b5fd84e9b50f71a4cd712a1a78237ac0417a0d89bfe6d2fb2f9fd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24cfd3daf919bebb1d305937aca4e39226eacfc67d9f1f3d4a5f1ab9e8e0af05',1978,'AL','Albania','government',10,'Legal name: People’s Socialist Republic of Albania
Type: Communist state
Capital: Tirané
Political subdivisions: 27 rethet (districts), including
capital, 200 localities, 2,600 villages
Legal system: based on constitution adopted in 1976;
judicial review of legislative acts only in the Presidium of the
People’s Assembly, which is not a true court; legal education
at State University of Tirané; has not accepted compulsory
ICJ jurisdiction
National holiday: Liberation Day, 29 November
Branches: People’s Assembly, Council of Ministers,
judiciary
Government leaders: Chairman of Council of Ministers,
Mehmet Shehu; Chairman Presidium of the People’s
Assembly, Haxhi Lleshi (Chief of State)
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held every 4
years; last elections 6 October 1974; 99.9% of electorate
voted
Political parties and leaders: Albanian Workers Party
only; First Secretary, Enver Hoxha
Communists: 101,500 party members (November 1976)
Member of: CEMA, IAFA, IPU, ITU, U.N., UNESCO,
UPU, WFTU, WHO, WMO; has not participated in CEMA
since rift with U.S.S.R. in 1961: officially withdrew from
Warsaw Pact 13 September 1968','45c2b9255f5b610d56211447e71e6c903428111a2dbdb508a1efdb77567f9f58','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef5637e86e5edcfeebe4742e568bb05a9376d33e9295c7bbfc43b3ea46e0149d',1978,'DZ','Algeria','government',14,'Legal name: Democratic and Popular Republic of Algeria
Type: republic
Capital: Algiers
Political subdivisions: 31 Wilayas (departments or
provinces)
Legal system: based on French and Islamic law, with
socialist principles; new constitution adopted by referendum
November 1976; judicial review of legislative acts in ad hoc
Constitutional Council composed of various public officials,
including several Supreme Court justices; Supreme Court
divided into 4 chambers; legal education at Universities of
Algiers, Oran, and Constantine; has not accepted compulsory
IC] jurisdiction
National holiday: 1 November
Branches: executive dominant; unicameral legislature
reconvened in March 1977; judiciary
Government leader: Houari Boumediene, President of
State and President of Council of the Revolution, overthrew
elected President Ahmed Ben Bella June 19, 1965
Suffrage: universal over age 19
Elections (latest): presidential 10 December 1976; depart-
mental assemblies 2 June 1974; local assemblies 30 March
1975; legislative elections held 25 February 1977
Political parties and leaders: National Liberation Front
(FLN)
Communists: 400 (est.); Communist Party illegal (banned
1962)
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ALGERIA/ANDORRA
Member of: AFDB, AIOEC , Arab League, ASSIMER,
FAO, G-77, GATT (de facto), IAFA, IBRD, ICAO, IDA,
ILO, International Lead and Zinc Study Group, IMCO,
IMF, IOOC, ITU, NAM, OAPEC, OAU, OPEC, U.N.,
UNESCO, UPU, WHO, WIPO, WMO','b891040b8e7a56a625bcf18b21522d629121f724c99f5191fea09263c1d4722f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40e72a776e8fccc7e3f485334e43d34ec3a6efc59012bcdef1777843b4a226d5',1978,'AD','Andorra','government',18,'Legal name: Valls de’Andorra (Catalan)
Type: unique coprincipality under formal sovereignty of
President of France and Spanish Bishop of Seo de Urgel,
who are represented locally by officials called verguers
Capital: Andorra
Political subdivisions: 6 districts—Andorra la Vella, Saint
Julia de Loria, Encamp, Canillo, La Massana, and Ordino
Legal system: based on French and Spanish civil codes;
Plan of Reform adopted 1866 serves as constitution; no
judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Branches: legislature (General Council) consisting of 24
members with one-half elected every 2 years for 4-year
term; executive—syndic and a deputy sub-syndic chosen by
General Council for 3-year terms; judiciary chosen by
coprinces who appoint 2 civil judges, a judge of appeals, and
2 Batles (court prosecutors)
Suffrage: males of 21 or over who are third generation
Andorrans vote for General Council members; same right
granted to women in April 1970
Elections: half of General Council chosen every 2 years,
last election December 1977
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
ooo
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ANDORRA/ ANGOLA
Political parties and leaders: traditionally no political
parties but only partisans for particular independent
candidates for the General Council, on the basis of
competence, personality and orientation toward Spain or
France; various small pressure groups developed in 1972,
first formal political party—Andorran Democratic Associ-
ation—formed in November 1976
Communists: negligible','fd36237267578b89c7203dce9e1206e4126efab4f9812529ff882607252857d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87ca3a55f7eb067d4ebd028d391347cc2b3d8375281778129a2f00e7ac837ab0',1978,'AO','Angola','government',22,'Legal name: People’s Republic of Angola
Type: republic; achieved independence from Portugal in
November 1975; constitution promulgated 1975; govern-
ment formed after civil war which ended in early 1976
Capital: Luanda
Political subdivisions: 16 administrative districts includ-
ing the coastal exclave of Cabinda
Legal system: based on Portuguese civil law system and
customary law
National holiday: Independence Day, 11 November
Branches: the official party is the supreme political
institution
Government Jeaders: Agostinho Neto, President
Suffrage: to be determined
Elections: none held to date
Political parties and leaders: Popular Movement for the
Liberation of Angola-Labor Party (MPLA-Labor Party), led
by Agostinho Neto, only legal party; National Front for the
Liberation of Angola (FNLA) and National Union for the
Total Independence of Angola (UNITA), defeated in civil
war, carrying out insurgencies
Member of: G-77, ILO, NAM, OAU, U.N., UNICEF,
WHO
Monetary conversion rate: 40.643, escudos=US$1L as of
November 1977
Fiscal year: calendar year','dba65915dd7fa039fc70cab47c47fd7fcab742fd6bf52526100c3f0d7fbc3ba2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cc29f1b29ce6415d8aa15c951a2d980a8d9d481081f33d446578684adbc8173',1978,'PR','Puerto Rico','government',26,'Legal name: State of Antigua
Type: dependent territory with full internal autonomy as
a British “Associated State”
Capital: St. Johns
Political subdivisions: 6 parishes, 2 dependencies (Bar-
buda, Redonda)
Legal system: based on English law; British Caribbean
Court of Appeal has exclusive original jurisdiction and an
appellate jurisdiction, consists of Chief Justice and 5 justices
Branches: legislative, 21-member popularly elected
House _ of Representatives; executive, Prime Minister and
Cabinet
Government leaders: Premier Vere C. Bird, Sr.; Deputy
Premier Lester Bird; Governor Sir Wilfred Ebenezer Jacobs
Suffrage: universal suffrage age 18 and over
Flections: every 5 years; last general election 1] February
1976
Political parties and leaders: Antigua Labor Party (ALP),
Vere C. Bird, Sr., Lester Bird; Progressive Labor Movement
(PLM), George Herbert Walter; Antigua People’s Party
(APP), J. Rowan Henry
Voting strength: 1976 election—House of Representative
seats—AI.P 10, PLM 5, independent 1, tie 1
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ANTIGUA/ ARGENTINA
Communists: negligible
Other political or pressure groups: Afro-Caribbean
Liberation Movement (ACLM), a small black nationalist
group led by Timothy Hector; Antigua Freedom Fighters
(AFF), a small black radical group, leaders unknown
Member of: CARICOM, ISO','df13c747f28cc9745a0aa88c44b9af2cd4bff89ba5f6763393456a31363c97cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe54b20428259afd75313de24cce23f871fc31be78cd9bd86344e9355880dc3e',1978,'AR','Argentina','government',30,'Legal name: Argentine Republic
Type: republic
Capital; Buenos Aires
Political subdivisions: 22 provinces, 1 district (Federal
Capital), and 1 territory
Legal system: based on Spanish and French civil codes;
constitution adopted 1853 partially superseded in 1966 by
the Statute of the Revolution which takes precedence over
the constitution when the two are in conflict, further
changes may be made by new government; judicial review
of legislative acts; legal education at University of Buenos
Aires and other public and private universities; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 25 May
Branches: presidency; legislature; national judiciary
Government leader: President, Lt. Gen. Jorge Rafael
Videla, Commander in Chief of the Army, chosen by the
three-man junta that took power on 24 March 1976
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ARGENTINA/AUSTRALIA
Government structure: the junta, composed of the chiefs
of the three armed services, retains supreme authority;
active duty or retired officers fill all but two cabinet posts
and administer all provincial and many local governments;
in addition, the military now oversee the nation’s principal
labor confederation and unions, as well as other civilian
pressure groups; Congress has been disbanded and all
political activity suspended; a nine-man Legislative Council,
composed of senior officers, advises the junta on lawmaking
Political parties: a number of civilian political groupings
remain potentially influential, despite the suspension of all
partisan activity; these include Justicialist Party (Peronist
coalition that formerly governed) and the Radical Civic
Union, center-left party providing the chief civilian
opposition to the Peronists; the Moscow-oriented Communist
Party remains legal, but extreme leftist splinter groups have
been outlawed
Communists: some 70,000 members in various party
organizations, including a small nucleus of activists
Other political or pressure groups: Peronist-dominated
labor movement, General Economic Confederation (Peron-
ist-leaning association of small businessmen), Argentine
Industrial Union (manufacturer’s association), Argentine
Rural Society (large landowner’s association), business
organizations, students, and the Catholic Church
Member of: FAO, G-77, GATT, IADR, IAEA, IBRD,
ICAC, ICAO, IDA, IDB, IFC, THO, ILO, IMCO, IMF,
{OO0C, ISO, ITU, IWC—International Whaling Commis-
sion, [WC—International Wheat Council, LAFTA, NAM,
OAS, SELA, U.N., UNESCO, UPU, WHO, WMO, WSG','f76e789a068047d5c0460c1093466d501cfe2899bacb8f62ba1d4900ba32a3fb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cf6535b366351213e940b8a672ea053a2b934a9918d3e8ba675f65c4ba128bc',1978,'AU','Australia','government',34,'Legal name: Commonwealth of Australia
Type: federal state recognizing Elizabeth II as sovereign
or head of state
Capital: Canberra
Political subdivisions: 6 states and 2 territories (Austra-
lian Capital Territory (Canberra) and Northern Territory)
Legal system: based on English common law; constitution
adopted 1900; High Court has jurisdiction over cases
involving interpretation of the constitution; accepts compul-
sory ICJ jurisdiction, with reservations
National holiday: 26 January
Branches: Parliament (House of Representatives and
Senate); Prime Minister and Cabinet responsible to House;
independent judiciary
Government leaders: Governor General Sir Zelman
Cowen; Prime Minister John Malcolm Fraser
Suffrage: universal over age 18
Elections: held at 3-year intervals, or sooner if Parliament
is dissolved by Prime Minister; last election December 1977
Political parties and_ leaders: Government—Liberal
Party (Malcolm Fraser) and National Country Party
(Douglas Anthony); opposition—Labour Party (William J.
Hayden)
Voting strength (1977 Parliamentary election): lower
house: Liberal-Country Coalition, 86 seats, Labour Party, 38
seats; Senate: Liberal Country Coalition, 35 seats; Labour, 26
seats; Democrats, 2 seats; Independents, 1 seat
Communists: 3,900 members (est.)
Other political or pressure groups: Democratic Labour
Party (anti-Communist Labour Party splinter group)
Member of: ADB, AIOEC, ANZUS, CIPEC (associate),
Colombo Plan, Commonwealth, DAC, ELDO, ESCAP,
FAO, GATT, IAEA, IATP, IBA, IBRD, ICAC, ICAO, IDA,
IEA, IFC, IHO, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IOOC, IPU, ISO, ITC, ITU, IWC—
International Whaling Commission, IWC—International
Wheat Council, OECD, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG','e2ad632a3a9dfc1dfd925f443c6b9f501a546927e0843a275768c23ab1c74c6d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec7e7a9070490ec4c6426d41da839a50e5b11080a503d456e78df0e946d813e9',1978,'AT','Austria','government',39,'Legal name: Republic of Austria
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (Laender) including the
capital
Legal system: civil law system with Roman law origin;
constitution adopted 1920, repromulgated in 1945; judicial
review of legislative acts by a Constitutional Court; separate
administrative and civil/penal supreme courts; legal educa-
tion at Universities of Vienna, Graz, Innsbruck, Salzburg,
and Linz; has not accepted compulsory ICJ jurisdiction
National holiday: 26 October
Branches: bicameral parliament, directly elected Presi-
dent whose functions are largely representational, independ-
ent federal judiciary
Government leaders: President Rudolf Kirchschlaeger,
Chancellor Bruno Kreisky leads a one-party Socialist
Suffrage: universal over age 19; compulsory for presiden-
tial elections
Elections: presidential, every 6 years (next 1980);
parliamentary, every 4 years (next 1979)
Political parties and leaders: Socialist Party of Austria
(SPOe), Bruno Kreisky, Chairman; Austrian People’s Party
(OeVP), Josef Taus, Chairman; Liberal Party (FPOe),
Friedrich Peter, Chairman; Communist Party, Franz Muhri,
Chairman
Voting strength (1975 election): 50.6% SPOe, 42.7%
OeVP, 5.8% FPOe, 1.2% Communist
Communists: | membership 25,000 est.;
7,000-8,000
Other political or pressure groups: Federal Chamber of
Commerce and Industry; Austrian Trade Union Federation
(primarily Socialist); three composite leagues of the Austrian
Peoples Party (OeVP) representing business, labor, and
farmers; the OeVP-oriented League of Austrian Industrial-
ists; Roman Catholic Church, including its chief lav
organization, Catholic Action
Member of: ADB, Council of Europe, DAC, ECE, EFTA,
EMA, ESRO (observer), FAO, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IEA, IFC, ILO, International Lead and Zinc
Study Group, IMF, ITU, I[WC—International Wheat Coun-
cil, OECD, U.N., UNESCO, UPU, WHO, WIPO, WMO,
WSG
activists
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
AUSTRIA/THE BAHAMAS
Legal name: Commonwealth of The Bahamas
Type: independent commonwealth since July 1973,
recognizing Elizabeth II as Chief of State
Capital: Nassau (New Providence Island)
11
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
THE BAHAMAS/BAHRAIN
Legal system: based on English law
National holiday: Independence Day, 10 July
Branches: bicameral legislature (appointed Senate,
elected House); executive (Prime Minister and _ cabinet);
judiciary
Government leaders: Prime Minister Lynden O. Pindling
Suffrage: universal over age 18; registered voters (July
1977) 73,309
Elections: House of Assembly (19 July 1977); next
election due constitutionally in 5 years
Political parties and leaders: Progressive Liberal Party
(PLP), predominantly black, Lynden O. Pindling; Bahamian
Democratic Party (BDP), Henry Bostwick, Free National
Movement (FNM), Cecil Wallace-Whitfield
Voting strength (1977 election): PLP (55%) 30 seats, BDP
(27%) 6 seats, FNM (15%) 2 seats, others (8%) O seats
Communists: none known
Member of: CDB, G-77, IBRD, IDB, ILO, IMCO, IMF,
U.N., WHO, WIPO, WMO','3a6ddebf65b8b8f30d794869e09558e6f11828cb4fafee2a65f0ba3b18c83470','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('233ccbaf5554136862a29bb4f2d011baed7fc76c831aa2589e6a248ca2beda63',1978,'BH','Bahrain','government',43,'Legal name: State of Bahrain
Type: traditional monarchy; independence declared in
1971
Capital: Manama
Legal system: based on Islamic law and English common
law; constitution went into effect December 1973
National holiday: 16 December
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Ne
July 1978
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
BAHRAIN/BANGLADESH
Branches: Amir rules with help of a cabinet led by Prime
Minister; a National Assembly, made up of cabinet and 30
directly elected members, was formed in early 1974; Amir
dissolved assembly in August 1975 and suspended the
constitutional provision for election of the assembly
Government leader: Amir ‘Isa ibn Salman Al-Khalifah
Political parties and pressure groups: political parties
prohibited; no significant pressure groups although numer-
ous small clandestine groups are active
Communists: negligible
Member of: Arab League, FAO, G-77, GATT (de facto),
IBRD, ICAO, IMF, NAM, OAPEC, U.N., UNESCO, WHO','0e0e34e7596b0c5d76226fd6b4b3e1eb30551e92003c18abd34d7d5fbfb42e88','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e260f2a0e5cd843420a44761d06863ceb96d88741cc9e5625181e20933307dd1',1978,'BD','Bangladesh','government',47,'Legal name: People’s Republic of Bangladesh
Type: independent republic since December 1971: Goy-
ernment of President Sheikh Muijibur Rahman overthrown
in August 1975; two other coups followed; country currently
governed by a military president who is also chief martial
law administrator and his council of civilian advisers
Capital: Dacca
Political subdivisions: 19 districts, 413 thanas (counties),
4,053 unions (village groupings)
Legal system: based on English common law; constitution
adopted December 1972; amended January 1975 to more
authoritarian presidential system, changed by proclamation
in April 1977 to reflect Islamic character of nation
National holiday: Independence Day, 26 March
Branches; constitution provides for unicameral legisla-
ture, strong president; controlled judiciary; parliament
dissolved by current regime
Elections: First Parliament (House of the Nation) elected
Government is
election in early June: a separate parliamentary election is
planned for November 1978; current President given
mandate to continue his rule in nationwide referendum held
in May 1977
Communists: 2,500 members (est.)
Other political or pressure groups: 15 political parties
legalized by government as of October 1976, student groups,
bands of former guerrillas
Member of: ADB, Afro-Asian People’s Solidarity Organi-
zation, Colombo Plan, Commonwealth, ESCAP, G-77,
GATT, IAFA, IBRD, ICAO, IDA, IMF, ILO, NAM, U. N.,
UNCTAD, UNESCO, UPU, WHO','5d8fdc6858011c2e573e8645aa2cd11f2451b1190d832ec05bb5cc0d6b369b95','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1dfe8000cc9cfa81cd4ce2f67fe226c2b135f200590548370166137f3b82752',1978,'BB','Barbados','government',51,'Legal name: Barbados
Type: independent sovereign state within the Common-
wealth since November 1966, recognizing Elizabeth II as
Chief of State
Capital: Bridgetown
Political subdivisions: 11 parishes and city of Bridgetown
Legal system: English common law; constitution came
into effect upon independence in 1966; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
National holiday: 30 November
Branches: legislature consisting of a 2l-member ap-
pointed Senate and a 94-member elected House of
Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister J. M. G. “Tom”
Adams
Suffrage: universal over age 18
Elections: House of Assembly members have terms no
longer than 5 years; last general election held 2 September
1976
Political parties and leaders: Barbados Labor Party
(BLP), J. M. G. “Tom” Adams; Democratic Labor Party
(DLP), Errol Barrow
Voting strength (1976 election): Barbados Labor Party
(BLP), 53%; Democratic Labor Party, 46%; Independent,
negligible; House of Assembly seats—BLP 17, DLP 7
Communists: negligible
Other political or pressure groups: People’s Progressive
Movement (PPM), a small black-nationalist group led by
Calvin Alleyne
Member of: CARICOM, Commonwealth, FAO, G-77,
GATT, IADB, IBRD, ICAO, IDB, ILO, IMCO, IMF, ISO,
ITU, [WC—International Wheat Council, OAS, SELA,
U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2005/04/22 :','4227c82af550139b61530eaf1d85bb0723430e1f24c019978d63977db5f0839e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31389887a95e835596dacd9e64497a9de5869a408e0852359c3fc515ca4c9712',1978,'BE','Belgium','government',55,'Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil law system influenced by English
constitutional theory; constitution adopted 1831, since
amended; judicial review of legislative acts: legal education
at 4 law schools; accepts compulsory ICJ jurisdiction, with
reservations
National holiday: National Day, 21 July
Branches: executive branch consists of King and cabinet;
cabinet responsible to bicameral parliament; independent
judiciary; coalition governments are usual
Government leader: Head of State, King Baudouin;
Prime Minister Leo Tindemans
16
Suffrage: universal over age 2]
Elections: held 17 April 1977 (held at least once every 4
years)
Political parties and leaders: Social Christian, Georges
Gramme and Wilfred Martens, co-presidents; Socialist.
Andre Cools and Karl Van Miert, co-presidents; Liberal,
Pierre Dechamps, national president; Brussels Liberal, Basile
Risopoulos, party president; Francophone Democratic F ront,
Andre Lagasse, party president; Walloon Rally, Paul-Henri
Gendebien, party president; Volksunie (Flemish nationalist),
Hugo Schiltz, party president; Communist, Louis Van Gent,
president of political bureau
Voting strength (1977 election): 80 seats Social Christian,
62 seats Socialist, 31 seats Liberal, 20 seats Volksunie, 10
seats Francophone Democratic Front, 5 seats Walloon Rally,
2 seats Brussels Liberal, 2 seats Communist
Communists: 10,000 members (est.)
Other political or pressure groups: Christian and Socialist
Trade Unions; the Federation of Belgium Industries;
numerous other associations representing bankers, manufac-
turers, middle-class artisans, and the legal and medical
professions; two major organizations represent the cultural
interests of Flanders and Wallonia
Member of: ADB, Benelux, BLEU, Council of Europe,
DAC, EC, ECE, ECOSOC, ECSC, EEC, EIB, ELDO, EMA,
FSRO, EURATOM, FAO, GATT, IAEA, IBRD, ICAC,
ICAO, ICES, IDA, IEA, IFC, ILO, International Lead and
Zine Study Group, IMCO, IMF, IOOC, IPU, ITC, ITU,
NATO, OAS (observer), OECD, U.N., UNESCO, UPU,
WEU, WHO, WIPO, WMO, WSG','fadeb0d5b24cdf302d6b193ac8445a18f8cb201ebb88809b6ccda339c44a0fae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba4d5f15fba9a51465869b738508218b14e3541ea45c06ed2a560b934277ebf9',1978,'MX','Mexico','government',60,'Legal name: Belize
Type: internal self-governing British colony
Capital: Belmopan
Legal system: English law; constitution came into force in
1964, although country remains a British colony
Branches: 18-member elected National Assembly and
8-member Senate (either house may choose its speaker or
president, respectively, from outside its elected member-
ship); cabinet; judiciary
Government leader: Premier George Price
Suffrage: universal adult (probably 21)
Elections: must be held within 5 years of last elections
held in October 1974
Political parties and leaders: People’s United Party
(PUP), George Price; United Democratic Party (UDP), a
17
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
BELIZE/BENIN
coalition comprised of the National Independence Party
(NIP) led by Philip Goldson, the People’s Democratic Union
{(PDM) led by Dean Lindo, and the Liberal Party (LP) led
by Harry Lawrence; Corozal United Front (CUF), San-
tiago Ricalde; United Black Association for Development
(UBAD), Evan X. Hyde
Voting strength (National Assembly): PUP 12 seats, UDP
6 seats
Communists: negligible
Other political or pressure groups: Christian Workers’
Union (CWU) which is connected with PUP
Member of: CARICOM, ISO
Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system: civil law system, constitution came into
effect 1966; judicial review of legislative acts; legal
education at University of San Carlos of Guatemala; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 15 September
Branches: traditionally dominant executive; elected uni-
cameral legislature; 7-member (minimum) Supreme Court
Government leader: President Brig. Gen. Kjell Laugerud
Garcia; President-elect Gen. Fernando Romeo Lucas to be
inaugurated 1 July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
GUATEMALA/GUINEA
Suffrage: universal over age 18, compulsory for literates,
optional for illiterates
Elections: next elections (President and Congress) 1982
Political parties and leaders: Democratic Institutional
Party (PID), Donaldo Alvarez Ruiz; Revolutionary Party
(PR), Jorge Garcia-Granados Quinonez (secretary general);
National Liberation Movement (MLN), Mario Sandoval
Alarcon; Guatemalan Christian Democratic Party (DCG),
Vinicio Cerezo Arevalo (sec. gen.); Rene de Leon Schlotter
(honorary President and party strongman); several unregis-
tered parties
Voting strength: for President—PID/PR, 269,973
(42.3%); MLN, 211,393 (33.1%); DCG, 156,730 (24.6%); for
congressional seats—PID/PR, 34 seats; MLN, 20 seats; DCG,
7 seats
Communists: Communist party outlawed; underground
membership estimated at 750
Other political or pressure groups: outlawed (Commu-
nist) Guatemalan Labor Party (PGT), Eleuterio Cabrera
Mejia (provisional secretary general)
Member of: CACM, FAO, G-77, IADB, IAEA, IBRD,
ICAC, ICAO, IDA, IDB, IFC, IHO, ILO, IMF, ISO, ITU,
{1WC—International Wheat Council, OAS, ODECA, SELA,
U.N., UNESCO, UPEB, UPU, WHO, WMO
Legal name: United Mexican States
Type: federal republic operating in fact under a
centralized government
Capital: Mexico
Political subdivisions: 31 states, Federal District
Legal system: mixture of US. constitutional theory and
civil law system; constitution established in 1917; judicial
review of legislative acts; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: Independence Day, 16 September
Branches: dominant executive, bicameral legislature,
Supreme Court
Government leader: President Jose Lopez-Portillo
Suffrage: universal over age 18; compulsory but
unenforced
Elections: congressional elections July 1979
Political parties and leaders: Institutional Revolutionary
Party (PRI), Carlos Sansores Perez; National Action Party
(PAN), Manuel Gonzalez Hinojosa; Popular Socialist Party
(PPS), Jorge Cruickshank Garcia; Authentic Party of the
Revolution (PARM), Pedro Gonzalez Azcuaga
Voting strength: 1976 presidential election: 98.7% PRI
(unopposed), 1.3% other; 1976 congressional election: 80.2%
PRI; 8.5% PAN; 5.8% other opposition (votes cast for PPS,
PARM, and unregistered candidates), 5.4% annulled
Communists: Mexican Communist Party (estimated
25,000) and other far-left parties seeking legal registration
under government''s 1977 political reform program
Other political or pressure groups: Roman Catholic
Church, Confederation of Mexican Workers (CTM), Con-
federation of Industrial Chambers (CONCAMIN), Confed-
eration of National Chambers of Commerce (CONCA-
NACO), National Cofederation of Campesinos (CNC),
National Confederation of Popular Organizations (CNOP),
Revolutionary Confederation of Workers and Peasants
(CROC)
Member of: FAO, G-77, IADB, IAEA, IBRD, ICAC,
ICAO, IDA, IDB, IFC, ILO, International Lead and Zinc
Study Group, IMCO, IMF, ISO, ITU, 1WC—International
Whaling Commission, LAFTA, NAMUCAR (Carribean
Multinational Shipping Line—Naviera Multinacional del
Caribe), OAS, SELA, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG','3a55375a18c8d9158f974850eddaf7c1dead2a9f1a9e0b9c4093f5cbca6b0181','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('435eef9bd7b88b7a9b38f092831d7291fe5ac58f9fbca83948610f3def0d998c',1978,'BJ','Benin','government',64,'Legal name: People’s Republic of Benin
Type: party state, under military rule since 26 October
1972
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 provinces, 46 districts
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
BENIN/BERMUDA
Legal system: based on French civil law and customary
law; legal education generally obtained in France; has not
accepted compulsory IC] jurisdiction
National holiday: 30 November
Branches: National Revolutionary Council, Council of
Ministers, Central Committee of Party
Government leader: Lt. Col. Mathieu Kerekou, President,
and Chief of State, Charged with National Defense
Suffrage: suspended
Elections: current government has held no elections and
none are scheduled
Political parties: People’s Revolutionary Party of Benin
established in 1975
Communists: sole party espouses Marxism-Leninism
Member of: AFDB, CEAO, EAMA, ECA, ECOWAS,
Entente, FAO, G-77, GATT, IBRD, ICAO, IDA, ILO, IMF,
ITU, NAM, Niger River Commission, OAU, OCAM, U.LN.,
UNESCO, UPU, WHO, WIPO, WMO','998c2c2b08e97dee6764f4c2d769e09653e2d4e56ff1abce1c94740df9e903e8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3b9f3dd3eaa12117d54dbfc266601018888532645390374891e24df377ad240',1978,'BM','Bermuda','government',68,'Legal name: Colony of Bermuda
Type: British colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English law
Branches: Executive Council (cabinet) appointed by
governor, led by government leader; bicameral! legislature
with an appointed Legislative Council, and a 40-member
directly elected House of Assembly
Government leaders: Governor, Sir Peter Ramsbotham,
Premier, J. David Gibbons
Suffrage: universal over age 2]
Elections: at least once every 5 years; last general election,
May 1976
Political parties and leaders: United Bermuda Party
(UBP), J. David Gibbons; Progressive Labor Party (PLP),
Lois Browne Evans
Voting strength (1976 elections): UBP 55.5%, PLP 44.4%;
House of Assembly seats—UBP 26%, PLP 14%
Communists: negligible
Other political or pressure groups: Bermuda Industrial
Union (BIU)','eb4d7c3ae19fc936e65136000ac495ebf32b1bdd34ebb2f7ee050128d4452865','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8aea309807c51e2a18f1bf0a8e587ba85a8e9409fa3384ec119679034fabe610',1978,'BT','Bhutan','government',72,'Legal name: Kingdom of Bhutan
Type: monarchy; special treaty relationship with India
Capital: Thimphu
Political subdivisions: 4 regions (east, central, west,
south), further divided into 15-18 subdivisions
Legal system: based on Indian law and English common
law; in 1964 the monarch assumed full power—no
constitution existed beforehand; a Supreme Court hears
appeals from district administrators; has not accepted
compulsory ICJ jurisdiction
National holiday: 17 December
Branches: appointed Minister and indirectly elected
Assembly consisting of village elders, monastic representa-
tives, and all district and senior government administrators
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
BHUTAN/ BOLIVIA
Government leader: King Jigme Singhi Wangchuk
Suffrage: each family has one vote
Elections: popular elections on village level held every 3
years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist clergy
Member of: Colombo Plan, G-77, NAM, UPU, U.N.
Legal name: Republic of Bolivia
Type: republic; de facto military dictatorship government
Capital: La Paz (seat of government); Sucre (legal capital
and seat of judiciary)
Political subdivisions: 9 departments with limited
autonomy
Legal system: based on Spanish law and Code Napoleon;
constitution adopted 1967; constitution in force except
where contrary to dispositions dictated by governments since
1969; legal education at University of San Andres and
several others; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 6 August
Branches: executive; congress of two chambers (Senate
and Chamber of Deputies), congress disbanded after 26
September 1969 ouster of President Siles; judiciary
Government leaders: President Maj. Gen. Hugo Banzer
Suarez
Suffrage: universal and compulsory at age 18 if married,
21 if single
Elections: presidential and congressional elections sched-
uled for 9 July 1978, Bolivia’s first elections in 12 years;
President Banzer would like to postpone them but the
military seems to favor proceeding with the electoral process
21
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
BOLIVIA/BOTSWANA
Political parties and leaders: ban on political parties was
lifted in December 1977, but party activity is disorganized
so far; the two traditional political parties in Bolivia are the
Nationalist Revolutionary Movement (MNR) and the Boliv-
ian Socialist Phalange (FSB), both are seriously factionalized;
Bolivian Socialist Falange; (Mario Gutierrez); Nationalist
Revolutionary Movement of the People (Jaime Arellano);
Nationalist Revolutionary Movement of Left (Hernan Siles
Zuazo); Authentic Revolutionary Party (Walter Guevara
Arce); Christian Democratic Party (Benjamin Miguel);
Nationalist Revolutionary Party of Left (Juan Lachin
Oquendo); Paz Estenssorista MNR (Leonidas Sanchez)
Voting strength (1966 elections): Frente de la Revolucion
Boliviana (a coalition composed of the MPC, PIR, PRA,
PSD, and two interest groups, the campesinos and Chaco
War Veterans) 61%, FSB 12%, MNR 10%, ot her 17%
Communists: three parties; PCB/Soviet led by Jorge Kolle
Cueto, about 300 members; PCB/Chinese led by Oscar
Zamora, 150 (including 100 in exile); POR (Trotskyist),
about 50 members divided between three factions led by
Hugo Gonzalez Moscoso, Guillermo Lora Escobar, and
Amadeo Arze
Member of: FAO, G-77, IAEA, IADB, IATP, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMF, ISO, ITC, ITU, IWC—
International Wheat Council, LAFTA and Andean Sub-Re-
gional Group (created in May 1969 within LAFTA), OAS,
SELA, U.N., UNESCO, WHO, WMO','9ade07fc515f67f7113e532264c1dba4b65693b693f64a9157829e86e53b1ff9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78a3b91c9039fd77b718ff03cf4ac5c72cd36ea585fb0a64aaafed7c3fe2382e',1978,'BW','Botswana','government',76,'Legal name: Republic of Botswana
Type: parliamentary republic; independent member of
Commonwealth since 1966
Capital: Gaborone
Political subdivisions: 12 administrative districts
Legal system: based on Roman-Dutch law and local
customary law; constitution came into effect 1966; judicial
review limited to matters of interpretation; legal education
at University of Botswana and Swaziland (2% years) and
University of Edinburgh (2 years); has not accepted
compulsory ICJ jurisdiction
National holiday: 30 September
Branches: executive—President appoints and presides
over the cabinet which is responsible to Legislative
Assembly; legislative—Legislative Assembly with 32 popu-
larly elected members and 4 members elected by the 32
representatives, House of Chiefs with deliberative powers
only; judicial—local courts administer customary law, High
Court and subordinate courts have criminal jurisdiction over
all residents, Court of Appeal has appellate jurisdiction
Government leader: President Seretse Khama
Suffrage: universal, age 21 and over
Elections: general elections held 26 October 1974
Political parties and leaders: Botswana Democratic Party
(BDP), Seretse Khama; Botswana National Front (BNF),
Kenneth Koma; Bechuanaland People’s Party (BPP), Philip
Matante; Botswana Independence Party (BIP), Motsamai
Mpho
Voting strength: (October 1974 election) BDP (27 seats);
BPP (2 seats); BNF (2 seats); BIP (1 seat)
Communists: no known Communist organization, Koma
of BNF has long history of Communist contacts
Member of: AFDB, Commonwealth, FAO, G-77, GATT
(de facto), IBRD, IDA, IMF, ITU, NAM, OAU, U.N., UPU,
WMO','1a93d9aed4fadbde631254c54a46f4e1b119bd553630955274f3a66ec0ea4f97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('845a52ded47784b527632a711bd0cfa295e4cfc8136a6b5f191817d7a204cc31',1978,'BR','Brazil','government',80,'Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presidential re-
gime since April 1964
Capital: Brasilia
Political subdivisions: 21 states, 4 territories, federal
district (Brasilia)
Legal system: based on Latin codes; dual system of courts,
state and federal; constitution adopted 1967 and extensively
amended in 1969; has not accepted compulsory IC]
jurisdiction
National holiday: Independence Day, 7 September
Branches: strong executive with very broad powers;
bicameral legislature (powers of the two bodies have been
sharply reduced); 1l-man Supreme Court
Government leader: President Ernesto Geisel
24
Suffrage: compulsory over age 18, except illiterates and
those stripped of their political rights; approximately 30
million registered voters in October 1970
Elections: President Geisel’s successor will be chosen by a
505-member electoral college, composed of the members of
Congress and delegates selected from the state legislatures,
on 15 January 1979, taking office 15 March 1979
Voting strength: (November 1974 congressional elections)
33.6% ARENA, 31.9% MDB, 35.5% blank and void
Political parties and leaders: National Renewal Alliance
(ARENA), pro-government Francelino Pereira, president;
Brazilian Democratic Movement (MDB), opposition, Ulisses
Guimaraes, president
Communists: 6,000, 1,000 militants
Other political or pressure groups: excepting the
military, the Catholic Church is the only active nationwide
pressure group, however, divisions within the Church often
prevent it from speaking with one voice; labor and student
groups have more vocal in recent months
Member of: FAO, G-77, GATT, IADB, IAEA, IBRD,
ICAC, ICAO, IDA, IDB, IFC, IHO , ILO, IMCO, IMF, IPU,
ISO, ITU, IWC—International Wheat Council, LAFTA,
OAS, SELA, U.N., UNESCO, UPU, WHO, WIPO, WMO
Legal name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: 4 administrative districts
Legal system: based on Islamic law; constitution promul-
gated by the Sultan in 1959
Branches: Chief of State is Sultan (advised by appointed
Privy Council) who appoints Executive Council and
Legislative Council
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 3-tiered system of
indirect elections; popular vote cast for lowest level (district
councilors)
Elections: last elections—March 1965; further elections
postponed indefinitely
Political parties and leaders: antigovernment, exiled
Brunei People’s Party, Chairman A. M. N. Azahari
Communists: information not available
Legal name: Cooperative Republic of Guyana
Type: republic within Commonwealth
Capital: Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with certain
admixtures of Roman-Dutch law; has not accepted compul-
sory ICJ jurisdiction
National holiday: 23 February
Branches: Council of Ministers presided over by Prime
Minister; 53-member unicameral legislative National Assem-
bly (elected); Supreme Court
Government leader; Prime Minister L. F. S$. Burnham
Suffrage: universal over age 18 as of constitutional
amendment August 1973
Elections: last held in July 1973; next election must be
called within 5 years
Political parties and leaders: People’s National Congress
(PNC), L. F. S. Burnham; People’s Progressive Party (PPP),
Cheddi Jagan; United Force (UF), Feilden Singh
Voting strength (1973 election): 70.2% PNC, 26.2% PNC,
3.6% other
Communists: est. 100 hard-core within PPP; top echelons
of PPP and PYO (Progressive Youth Organization, militant
wing of the PPP) include many Communists, but rank and
file is conservative and: non-Communist; small but unknown
number of orthodox Marxist-Leninists within PNC, some of
whom are PPP turncoats
Other political or pressure groups: Trades Union
Congress (TUC); Working People’s Alliance (WPA); Work-
ing People’s Vanguard Party (WPVP); Guyana Council of
Indian Organizations (GCIO); Civil Liberties Action Com-
mittee (CLAC); the latter two organizations are small and
active but not well organized
Member of: CARICOM, CDB, FAO, G-77, GATT, IADB,
IBA, IBRD, ICAO, IDA, IFC, ILO, IMF, ISO, ITU, NAM,
OAS (observer), SELA, U.N., UNESCO, UPU, WHO, WMO','11f95037ec0cd84980145b198a6f5a356d98d86fce60fa9c917da7b10cea5c2b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d72ec9d3fc1c91eac25524148dc6f533cfa686f5c6fb53899d73a7d4f8422429',1978,'BG','Bulgaria','government',84,'Legal name: People’s Republic of Bulgaria
Type: Communist state
Capital: Sofia
Political subdivisions: 28 okrugs (districts), including
capital city of Sofia
Legal system: based on civil law system, with Soviet law
influence; new constitution adopted in 1971; judicial review
of legislative acts in the State Council; legal education at
University of Sofia; has accepted compulsory ICJ jurisdiction
National holiday: National Liberation Day, 9 September
Branches: legislative, National Assembly; judiciary, Coun-
cil of Ministers
Government leaders: Todor Zhivkov, Chairman, State
Council (President and chief of state); Stanko Todorov,
Chairman, Council of Ministers (premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 5 years for National
Assembly; last elections held on 20 May 1976; 99.85% of the
electorate voted
Political parties and leaders: Bulgarian Communist
Party, Todor Zhivkov, First Secretary; Bulgarian National
Agrarian Union, a puppet party, Petur Tanchev, secretary of
Permanent Board
Communists: 817,000 party members (January 1978)
Mass organizations and front groups: Fatherland Front,
Dimitrov Communist Youth League, Central Council of
Trade Unions, National Committee for Defense of Peace,
Union of Fighters Against Fascism and Capitalism, Commit-
tee of Bulgarian Women, All-National Committee for
Bulgarian-Soviet Friendship
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
BULGARIA/BURMA
Member of: CEMA, FAO, IAEA, ICAO, ILO, Interna-
tional Lead and Zinc Study Group, IMCO, IPU, ITC, ITU,
[WC—International Wheat Council, U.N., UNESCO, UPU,
WHO, WIPO, WMO, Warsaw Pact, International Organiza-
tion of Journalists, International Medical Association, Inter-
national Radio and Television Organization
Legal name: Socialist Republic of the Union of Burma
Type: republic under 1974 constitution
27
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
BURMA/BURUNDI
Capital: Rangoon
Political subdivisions: seven divisions and seven constitu-
ent states; subdivided into townships, villages, and wards
Legal system: People’s Justice system and People’s Courts
instituted under 1974 constitution; legal education at
Universities of Rangoon and Mandalay; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 4 January
Branches: State Council rules through a Council of
Ministers; People’s Assembly has legislative power
Government leader: Chairman of State Council and
President, Gen. U. Ne Win
Suffrage: universal over age 18
Elections: People’s Assembly and local People’s Councils
elected in 1978
Political parties and leaders: government-sponsored
Burma Socialist Program Party only legal party
Communists: estimated 5,000-8,000
Other political or pressure groups: People’s Patriotic
Party; Kachin Independence Army; Karen Nationalist
Union, several Shan factions
Member of: ADB, Colombo Plan, FAO, G-77, GATT,
IAEA, IBRD, ICAO, IDA, IFC, THO, ILO, IMCO, IMF,
ITU, NAM, UN., UNESCO, UPU, WHO, WMO','48846a8ab4c98f0505f9c770833661806799879edd7a311d5ebf47e1dd876ff0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('919613919468b2e7a37062d8535427f2bbc33e6556aecc09fdf6c60d669dedd7',1978,'BI','Burundi','government',88,'Legal name: Republic of Burundi
Type: republic; military government overthrown by
military coup, November 1976; constitution abolished
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into 18
arrondissements and 78 communes; Bujumbura city (popula-
tion est. 160,000) has status equal to a province
Legal system: based on German and French civil codes
and customary law; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 1 July
Branches: Supreme Revolutionary Council is governing
body
Government leader: Col. Jean Bagaza, Chairman of
Supreme Revolutionary Council, established November 1976
Elections: last legislative election May 1965; legislature
dissolved in 1966
Political parties and leaders: National Party of Unity and
Progress (UPRONA), a Tutsi led party, declared sole
legitimate party in 1966
Communists: no Communist party; resumed diplomatic
relations with the Peoples Republic of China in October
1971 following a six-year suspension; U.S.S.R., North Korea,
and Romania also have diplomatic missions in Burundi
Member of: AFDB, EAMA, ECA, FAO, G-77, GATT,
IBRD, ICAO, IDA, ILO, IMF, ITU, NAM, OAU, U.N.,
UNESCO, UPU, WHO, WMO','2814f271eaa8d5be533f6a16dcfd5203b61a71010faa08efcd5c8c68793f17d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fc3b7d5286d0c9466ea6fd9ac1cf38d6359dc4e399329621763da337a5ac7aa',1978,'KH','Cambodia','government',92,'Legal name: Democratic Kampuchea (Cambodia)
Type: Communist state
Capital: Phnom Penh
Political subdivisions: 19 or 20 provinces
Legal system: Tribunal Committee chosen by People’s
Representative Assembly
National holiday: 17 April
Branches: State Presidium, composed of chairman and
two vice chairmen; cabinet, totally Communist; 250-mem-
ber People’s Representative Assembly elected 20 March
1976 for 5-year term; ten-member Assembly Standing
Committee
Government leader: Presidium Chairman, Khieu Sam-
phan; Prime Minister, Pol Pot; Deputy Prime Ministers, Ieng
Sary, Vorn Vet, Son Sen; Assembly Standing Committee
Chairman, Nuon Chea
Suffrage: universal over age 18
Political parties and leaders: political life dominated by
Khmer Communist Party
Member of: Colombo Plan G-77, Mekong Committee
(inactive), NAM, U.N.','9bb5b8eff04d555040730ceb6fb7614552d5df86914845af0250808cc1e64406','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f430e721c277017f43441e4805f14188025145a138178ef494f8ebb728548d7b',1978,'CM','Cameroon','government',96,'Legal name: United Republic of Cameroon
Type: unitary republic; one-party presidential regime
Capital: Yaounde
Political subdivisions: 7 provinces divided into 39
departments
Legal system: based on French civil law system, with
common law influence; new unitary constitution adopted
1972, judicial review in Supreme Court, when a question of
constitutionality is referred to it by the President of the
Republic; has not accepted compulsory ICJ jurisdiction
National holiday: 20 May
Branches: executive, legislative, and judicial
Government leader: President Ahmadou Ahidijo
Suffrage: universal over age 21
Elections: presidential elections held 5 April 1975;
parliamentary elections last held 18 May 1973
Political parties and leaders: single party, Cameroonian
National Union (UNC), President Ahmadou Ahidio
Communists: no Communist Party or significant number
of sympathizers
Other political or pressure groups: Cameroon Peoples
Union (UPC), an illegal terrorist group now reduced to
scattered acts of banditry with its factional leaders in exile
Member of: AFBD, EAMA, ECA, EIB (associate), FAO,
G-77, GATT, IAEA, IBRD, ICAC, ICAO, IDA, IFC, ILO,
IMCO, IMF, IPU, ISO, ITU, Lake Chad Basin Commission,
NAM, Niger River Commission, OAU, UDEAC, U.N.,
UNESCO, UPU, WHO, WIPO, WMO','e46df778938472721d5d376d000195cc8150cc4bbcf156cd5dd6870b54498bd5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b4d6017ca626254fa0de2918921f5576eba3f381a9e9be5e37fa371a463c521',1978,'CA','Canada','government',100,'Legal name: Canada
Type: federal state recognizing Elizabeth II as sovereign
Capital: Ottawa
Political subdivisions; 10 provinees and 2 territories
Legal system: based on English common law, except in
Quebec, where civil law system based on French law
prevails; constitution is British North America Act of 1867
and various amendments; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: Dominion Day, | July
Branches: federal executive power vested in cabinet
collectively responsible to House of Commons, and headed
by Prime Minister; federal legislative authority resides in
Parliament consisting of Queen represented by Governor-
General, Senate, and Commons; judges appointed by
Governor-General on the advice of the government;
Supreme Court is highest tribunal
Government leader: Pierre Elliott Trudeau
Suffrage: universal over age 18
Elections: legal limit of 5 years but in practice held at
least every 4 years, last election July 1974
32
Political parties and leaders: Liberal, Pierre Trudeau;
Progressive-Conservatives, Joe Clark; New Democratic,
Edward Broadbent; Social Credit, vacant since death of
Andre Fortin in July 1977
Voting strength (1974 election (numbers in parens
indicate current party strengths in Parliament)): Liberal
43% (140 seats), Progressive Conservative 35% (90 seats),
New Democratic Party 16% (16 seats), Social Credit 5% (9
seats), other 1%,, Independents hold 2 seats, 7 seats
unoccupied; Parliament enlarged from 264 seats to 282 seats
on 12 June but new seats will not be filled until next general
election expected in 1978
Communists: 2,000 approx.
Member of: ADB, Colombo Plan, Commomwealth, DAC,
FAO, GATT, IAFA, IBRD, ICAO, ICES, ICRC, IDA, IDB,
IEA, IFC, THO, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IPU, ISO, ITC, ITU, IWC—Interna-
tional Whaling Commission, IWC—International Wheat
Council, NATO, OAS (observer), OECD, U.N., UNC.
TAD, UNESCO, UPU, WHO, WIPO, WMO, WSG
Legal name: Republic of Cape Verde
National holiday: 12 September
Type: republic; achieved independence from Portugal in
July 1975
Capital: Praia
Political subdivisions: 10 islands
Legal system: to be determined
National holiday: 12 September
Branches: National Assembly, 56 members; the official
party is the supreme political institution
Government leaders: President, Aristides Pereira; Prime
Minister, Pedro Pires; Minister of Foreign Affairs, Abilio
Duarte
Suffrage: universal over age 18
Elections: to be determined
Political parties and leaders: Partido Africano da
Independencia da Guinee e Cabo Verde (PAIGC), led by
Aristide Pereira, only legal party
Communists: none known
Member of: G-77, NAM, OAU, U.N.
Legal name: Central African Empire
Type: constitutional monarchy, founded on a single party
Capital: Bangui
Political subdivisions: 14 prefectures, 47 subprefectures
Legal system: based on French, Islamic, and tribal law; in
1966 the Chief of State assumed all power and abrogated the
constitution; in 1976 he promulgated a new constitution; has
not accepted compulsory ICJ jurisdiction
National holiday: 1 December
Branches: Emperor Bokassa is chief of state and rules by
decree; government is headed by a Prime Minister assisted
by the Council of Ministers; judiciary, Supreme Court, court
of appeals, criminal court, and numerous lower courts:
constitution calls for a National Assembly
Government leader: Emperor Salah Ad-Din Ahmad
Bokassa I
Suffrage: universal over age 21
Elections: none have been held yet under Bokassa regime;
provided for in new constitution
Political parties and leaders: Movement for the Social
Evolution of Black Africa (MESAN), ruling party under
former regime, continues as a key body for organizing
support for the regime led by Emperor Bokassa
Communists: no Communist Party or significant number
of sympathizers
Member of: AFDB, Conference of East and Central
African States, EAMA, ECA, FAO, G-77, GATT, IBRD,
ICAO, IDA, ILO, IMF, ITU, NAM, OAU, OCAM, UDEAC,
U.N., UNESCO, UPU, WHO, WMO','cd21a87e29fad974b318938e187b0acd1f911411231aea0a24bac033e1a0b25b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f1c504f06d3fc93eecd4f3496c1015db8352d8e5af9411f5acd625103d5d22f',1978,'TD','Chad','government',104,'Legal name: Republic of Chad
Type: republic; military regime in power since April 1975
Capital; N’Djamena
Political subdivisions: 14 prefectures
Legal system: based on French civil law system and
Chadian customary law; constitution adopted 1962; constitu-
tion suspended and national assembly dissolved April 1975;
judicial review of legislative acts in theory a power of the
Supreme Court; has not accepted compulsory ICJ juris-
diction
35
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CHAD/CHILE
National holiday: 13 April
Branches: executive authority exercised by Supreme
Military Council composed of 9 officers
Government leader: President of Supreme Military
Council, General Felix Malloum
Suffrage: universal over age 20
Elections: all political activity banned
Political parties and leaders: political parties banned
Communists: no front organizations or underground
party; probably a few Communists and some sympathizers
Other political or pressure groups: armed Muslim rebel
bands have been opposing the government since October
1965 in east-central and since August 1969 in northern
Chad; rebels currently control the northern half of the
country
Member of: AFDB, Conference of East and Central
African States, EAMA, ECA, FAO, G-77, GATT, ICAC,
ICAO, IBRD, IDA, ILO, IMF, ITU, Lake Chad Basin
Commission, NAM, OAU, UEAC, U.N., UNESCO, UPU,
WHO, WIPO, WMO','375bcee6dd6f116d06939f9069df6ede3332707cbbc47f9fd2daa150228304cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12de2cfbeb35ff4f9b8961030b0af19ef6559c662c06d77e3565ffadf110a098',1978,'CL','Chile','government',108,'Legal name: Republic of Chile
Type: republic
Capital: Santiago
Political subdivisions: 12 regions plus one metropolitan
district, 41 provincial subdivisions.
Legal system: based on Code 1857 derived from Spanish
law and subsequent codes influenced by French and
Austrian law; constitution adopted 1925, amended since
then, currently being revised; judicial review of legislative
acts in the Supreme Court; legal education at University of
Chile, Catholic University, and several others; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 18 September
Branches: four-man Military-Police Junta, which exer-
cises constituent and legislative powers and has delegated
executive powers to President of Junta; the President has
announced a plan for transition from military to civilian rule
by 1985; Congress dissolved; civilian judiciary remains
Government leader: President, Gen. Augusto PINO-
CHET Ugarte; other Junta members, Adm. Jose Toribio
MERINO Castro, Gen. Gustavo LEIGH Guzman, Gen.
Cesar MENDOZA Duran
Suffrage: none
Elections: prohibited by decree; all electoral registers
were destroyed in 1974
Political parties and leaders: Christian Democratic Party
(PDC), Andres Zaldivar and Eduardo Frei; National Party
(PN), Sergio Onofre Jarpa; PDC and (PN) are officially
banned; Popular Unity coalition parties (outlawed)—
Communist Party (PCCh), Luis Corvalan (in exile); Socialist
Party (PS), Clodomiro Almeyda and Carlos Altamirano
(both in exile); Radical Party (PR); Christian Left (IC);
United Popular Action Movement (MAPU); Independent
Popular Action (API)
Voting strength (1970 presidential election): 36.6%
Popular Unity coalition, 35.3% conservative independent,
28.1% Christian Democrat; (1973 Congressional election)
44% Popular Unity coalition, 56% Democratic Confeder-
ation (PDC and PN)
Communists: 248,000 when PCCh was legal in 1973;
active militants now estimated at about 20,000
Other political or pressure groups: organized labor;
business organizations; landowners’ associations (SNA—
Sociedad Nacional de Agricultural); Catholic church; ex-
treme leftist, Movement of Revolutionary Left (MIR),
outlawed; rightist, Patria y Libertad (PyL), outlawed
Member of: CIPEC, ECOSOC, FAO, G-77, GATT,
IADB, IAEA, IBRD, ICAO, IDA, IDB, IFC, IHO, ILO,
IMCO, IMF, IPU, ITU, LAFTA, OAS, SELA, U.N.,
UNESCO, UPU, WHO, WIPO, WMO, WSG
Legal name: People’s Republic of China
Type: Communist state; real authority lies with Commu-
nist party''s political bureau; the National People’s Congress,
in theory the highest organ of government, in reality merely
rubber stamps the party’s programs; the State Council is the
actual governing organism
Capital: Peking
Political subdivisions: 21 provinces, 3 centrally governed
municipalities, and 5 autonomous regions
Legal system: before 1966, a complex amalgam of custom
and statute, largely criminal; little ostensible development of
uniform code of administrative and civil law; highest judicial
organ is Supreme People’s Court although legal activity
centered in parallel network of Public Security organs; laws
and legal procedure clearly subordinated to priorities of
party policy; whole system largely suspended during
Cultural Revolution, but has been revived
National holiday: National Day, 1 October
Branches: prior to 1966 control was exercised by Chinese
Communist Party, through State Council, which supervised
more than 50 ministries, commissions, bureaus, etc., all
technically under the standing committee of the National
People’s Congress; this system broke down under “Cultural
Revolution” pressures but has been reconsolidated and
streamlined to 37 ministries
Government leader: Premier of State Council, Hua
Kuo-feng; government subordinate to central committee of
CCP, under Chairman Hua Kuo-feng
Suffrage: universal over age 18, though this is academic
Elections: no meaningful elections
Political parties and leaders: Chinese Communist Party
(CCP), headed by Hua Kuo-feng; Hua is Chairman of
Central Committee; a new central committee was formed at
the llth Party Congress held in August 1977
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CHINA, PEOPLE’S REPUBLIC OF/CHINA, REPUBLIC OF
Voting strength: 100% Communist for practical purposes;
no political nonconformity permitted
Communists: about 35 million party members in 1977
Other political or pressure groups: army (PLA) remains a
major force, although many soldiers who acquired a wide
range of civil political-administrative duties during the
Cultural Revolution have been removed; many veteran
civilian officials, in eclipse since the Cultural Revolution,
have been reinstated; mass organizations, such as the trade
unions and the youth league, have been rebuilt in the
provinces; plans are underway to rebuild the national
organizations
Member of: FAO, IAEA, IBRD, ICAO, IDA, IFC, THO,
ILO, IMCO, IMF, ITU, Red Cross, U.N., UNESCO, UPU,
WHO, WMO, other international bodies','028a2ef197c837688e66b7f3b94d7518e723bf98c99ed779e6deaaa92d499b98','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a978d34d114a7e2b02d69082d4dd63abf518afeb957338e36a07937740ec9a01',1978,'CN','China','government',112,'Legal name: Republic of China
Type: republic; one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 4 cities, 1 special
municipality (Taipei)
Legal system: based on civil law system; constitution
adopted 1947, amended 1960 to permit Chiang Kai-shek to
be reelected, and amended 1972 to permit President to
restructure certain government organs; accepts compulsory
IC] jurisdiction, with reservations
Branches: 5 independent branches (executive, legislative,
judicial, plus traditional Chinese functions of examination
and control), dominated by executive branch; President and
Vice President elected by National Assembly
Government leaders: President Chiang Ching-kuo
Suffrage: universal over age 20
Elections: national level—legislative yuan every 3 years
but no general election held since 1948 election on mainland
(partial elections for Taiwan province representatives
December 1969, December 1972, and December 1975);
local level—provincial assembly, county and municipal
executives every 4 years; county and municipal assemblies
every 4 years
Political parties and leaders: Kuomintang, or National
Party, led by Chairman Chiang Ching-kuo, has no real
opposition; 2 insignificant parties are Democratic Socialist
Party, Young China Party
Voting strength (1972 provincial assembly election): 58
seats Kuomintang, 13 seats independents
Other political or pressure groups: none
Member of: expelled from U.N. General Assembly and
Security Council on 25 October 1971 and withdrew on same
date from other charter-designated subsidiary organs;
attempting to retain membership in international financial
institutions, ICAC, ISO, IWC-International Wheat Council
40
Legal name: Republic of Korea
Type: republic; power centralized in a strong executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities; heads
centrally appointed
Legal system: combines elements of continental Europe-
an civil law systems, Anglo-American law, and Chinese
classical thought; constitution approved 1972; has not
accepted compulsory ICJ jurisdiction
National holiday: 15 August
Branches: executive, legislative (unicameral), judiciary,
National Conference of Unification
Government leaders: President Pak Chong-hui; Prime
Minister Choe Kyu-ha
Suffrage: universal over age 20
Elections: presidential every 6 years indirectly by the
National Conference of Unification, last election May 1978;
two-thirds of the 219-member National Assembly is elected
directly for the same period within six months of the
presidential election, remaining third nominated by the
President and elected by the National Conference for a
three-year term; last election February 1978, Revitalization
Group—78 seats, Democratic Republican Party—68 seats,
New Democratic Party—55 seats, Democratic Unification
Party—3 seats, Independents—15 seats
Political parties and leaders: pro-government—Revital-
ization Group (appointed) (Chairman, Paek Tu-Chin) and
Democratic Republican Party (Acting Chairman, Yi
Hyo-sang); New Democratic Party (Chairman, Yi Chol-
sung); Democratic Unification (Chairman, Yang Il-tong)
Voting strength: (1973 election) popular vote 11,896,484;
DRP 38.8%, NDP 32.8%, DUP 10.2%, Independent 18.1%,
0.1% invalid
Communists: Communist activity banned by govern-
ment; an estimated 37,000-50,000 former members and
supporters
Other political or pressure groups: Federation of Korean
Trade Unions; Korean Veterans’ Association, Korean Nation-
al Christian Council; large potentially volatile student
population concentrated in Seoul
Member of: ADB, Asian Parliamentary Union, Asian
People’s Anti-Communist League (APACL), ASPAC,
Colombo Plan, ESCAP, FAO, G-77, GATT, Geneva
Conventions of 1949 for the protection of war victims,
IAEA, IBRD, ICAC, ICAO, IDA, IFC, IHO, IMCO, IMF,
INTELSAT, INTERPOL, IPU, ITU, 1WC—International
Wheat Council, UNESCO, U.N. Special Fund, UPU, WHO,
WMO, World Anti-Communist League (WACL); official
observer at U.N., does not hold U.N. membership','12c21c63bc1ac24e5bfd18f60ba519f166c078a0c1dbe60f785bd9d4af15cfbf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('432219a79cf4b9ff14aa88a3c7ed6945e9789fced6e2627db806c26864df8b84',1978,'CO','Colombia','government',116,'Legal name: Republic of Colombia
Type: republic; executive branch dominates government
structure
Capital: Bogota
Political subdivisions: 92, departments, 3 Intendants, 5
Commissariats, Bogota Special District
Legal system: based on Spanish law; religious courts
regulate marriage and divorce; constitution decreed in 1886,
amendments codified in 1946 and 1968; judicial review of
legislative acts in the Supreme Court; accepts compulsory
IC] jurisdiction, with reservations
National holiday: Independence Day, 30 July
Branches: President, bicameral legislature, judiciary
Government leader: President Alfonso Lopez Michelsen
Suffrage: universal over age 21
Elections: every fourth year; last presidential and
congressional elections April 1974; municipal and depart-
mental elections, April 1976
Political parties and leaders: Liberal Party, President
Alfonso Lopez Michelsen; Conservative Party, Alvaro
Gomez Hurtado; Alianza Nazional Popular, Maria Eugenia
Rojas de Moreno
Voting strength: 1974 presidential election— Alfonso
Lopez Michelsen 55%, Alvaro Gomez Hurtado 32%, Maria
Eugenia Rojas de Moreno 9.5%; 1976 municipal election,
52% Liberal Party, 40% Conservative Party, 7% combined
far left parties; 70% abstention of eligible voters
Communists: 10,000-12,000 members est.
Other political or pressure groups: Communist Party
(PCC), Gilberto Vieira White, PCC/ML, Chinese Line
Communist Party
Member of: FAO, G-77, IADB, IAEA, IBRD, ICAC,
ICAO, IDA, IDB, IFC, IHO, ILO, IMF, ISO, ITU, LAFTA
and Andean Sub-Regional Group (created in May 1969
within LAFTA), OAS, SELA, UN., UNESCO, UPEB, UPU,
WwHO, WMO, WSG','32941f1c9be8c2b49637055ec9dc00546ea15c6d50fee169ae4ca4fc5281eb10','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20bbf14a13e92c230f307d1db1ad0c55e2de005481647595361d185230df62b3',1978,'KM','Comoros','government',120,'Legal name: Republic of the Comoros
of independence from France in July 1975; other island,
Political subdivisions: the three islands are organized into
7 regions; these Tegions are broken down into 55 to 60
“Moudirias” or regional council centers; the “Bavous” are
the principle units of local government and they are grouped
together to form the “Moudirias”
Legal system: French and Muslim law
Branches: Al; Soilih elected President of the Comoros,
April 1977; he immediately reorganized the Central
the presidency,
internal affairs Central Committee, external affairs Central
Committee, and a Supreme Court
Communists: information not available
Member of: G-77, NAM, OAU, UN.
- 000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A
p
———— ee
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
COMOROS/CONGO','6c480e53e346b194d0d222e505ca3a0d5cc8de680c6f5b03dca49dd475cbabdb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b716cbc54f9c499e4a196b113c28a331f8a79cb30853e65ebc84395912614e9a',1978,'CG','Congo','government',124,'Legal name: People’s Republic of the Congo
Type: republic; military regime established September
1968
Capital: Brazzaville
Political subdivisions: 9 regions divided into districts
Legal system: based on French civil law system and
customary law; constitution adopted 1973
National holiday: National Day, 15 August
Branches: President, Military Committee, Council of
State; judiciary; all policy made by Congolese Workers Party
Central Committee and Politburo
Government leaders: President, Brigadier General
Joachim Yhombi-Opango; Prime Minister Louis Goma
Suffrage: universal over age 18
Elections: Jast legislative elections June 1973
Political parties and leaders: Congolese Workers Party
(PCT) is only legal party
Communists: unknown number of Communists and
sympathizers
Other political or pressure groups: Union of Congolese
Socialist Youth (UJSC), Congolese Trade Union Congress
43
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CONGO/COOK ISLANDS
(CSC), Revolutionary Union of Congolese Union (URFC),
General Union of Congolese Pupils and Students (UGEEC)
Member of: AFDB, Conference of East and Central
African States, EAMA, ECA, EIB (associate), FAO, G-77,
GATT, IBRD, ICAO, IDA, ILO, IMF, ITU, NAM, OAU,
UDEAC, UEAC, U.N., UNESCO, UPU, WHO, WIPO,
WMO','7da16afb79cbb6138a208c68ebcaff0521cd8798525117eb02e943665cb16bba','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('378535dad7bb771f6ebc2bc7a6f7aba84384ed3e3a7e361c04ada4f74e72f7da',1978,'CK','Cook Islands','government',128,'Legal name: Cook Islands
Type: self-governing in “free association” with New
Zealand; Cook Islands government fully responsible for
internal affairs and has right at any time to move to full
independence by unilateral action; New Zealand retains
responsibility for external affairs, in consultation with Cook
Islands government
Capital: Rarotonga
Branches: New Zealand Governor General appoints
Representative to Cook Islands, who represents the Queen
and the New Zealand government; Representative appoints
the Premier; Legislative Assembly of 22 members, popularly
elected; House of Arikis (chiefs), 15 members, appointed by
Representative, an advisory body only
Government leader: Premier Albert Henry
Suffrage: universal adult
Elections: every 4 years, latest in March 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
_! _—
July 1978
A
COOK ISLANDS/COSTA RICA
Political parties and leaders: Cook Islands Party, Sir
Albert Henry; Democratic Party, Dr. Thomas Davis
Voting strength (1978): Cook Islands Party, 15 seats;
Democratic Party, 7 seats','cef007c43c9c169899d317069fae76bda20054a47cd254527a9d7ecaf90d6b93','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2de94e26711c5020b5449e3ae2cb2d5f580b85f511956752e0c592e6ca8e8c82',1978,'CR','Costa Rica','government',132,'Legal name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system;
constitution adopted 1949; judicial review of legislative acts
in the Supreme Court; legal education at University of Costa
Rica; has not accepted compulsory IC) jurisdiction
National holiday: Independence Day, 15 September
Branches: President, unicameral legislature, Supreme
Court elected by legislature
Government leader: President Rodrigo Carazo Odio
Suffrage: universal and compulsory age 18 and over
Flections: every 4 years, next, February 1982
Political parties and leaders: National Liberation Party
(PLN), Daniel Oduber, Luis Alberto Monge, Carlos Manuel
Castillo; Democratic Renovation Party (PRD), Rodrigo
Carazo; Christian Democratic Party (PDC), Jorge Monge
Zamora; Popular Vanguard Party (PVP, Communist),
Manuel Mora Valverde; Republican Calderonista Party
(PRC), Rafael Angel Calderon Fournier; Popular Union
Party (PUP), San Joaquin Trejos Fernandez; Unity Coalition
composed of the PRD, the PDC, the PUP, and the PRC
Voting strength (1978 election): Unity Coalition 43.4%,
27 seats, PLN 38.8%, 25 seats; Leftist Coalition Party (PPU)
7.6%, 3 seats; others, 2 seats
Communists: 3,200 members, 10,000 sympathizers
45
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000
July 1978
COSTA RICA/CUBA
ation of Workers (CGT),
National Association for Economic Development (ANFE)
Wheat Council, NAMUCAR (Caribbean Multinational
Shipping Line—Naviera Multinacional del] Caribe), OAS,
ODECA, SELA, ULN., UNESCO, UPEB, UPU, WHO,
WMO
Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: 14 provinces and 169 munici-
palities
Legal system: based on Spanish and American law, with
large elements of Communist legal theory; Fundamental
Law of 1959 replaced Constitution of 1940; a new
constitution was approved at the Cuban Communist Party’s
First Party Congress in December 1975 and by a popular
referendum which took place on 15 February 1976; portions
of the new constitution were put into effect on 24 February
1976, by means of a Constitutional Transition Law, and the
entire constitution became effective on 2 December 1976;
legal education at Universities of Havana, Oriente, and Las
Villas; does not accept compulsory [CJ jurisdiction
National holiday: Anniversary of the Revolution, 1
January
Branches: executive; legislature (National People’s Assem-
bly); controlled judiciary
Government leader: President Fidel Castro Ruz
Suffrage: universal, but not compulsory, over ase 16
Elections: National People’s Assembly (indirect election)
every five years; election held November 1976
Political parties and leaders: Cuban Communist Party
(PCC), First Secretary Fidel Castro Ruz, Second Secretary
Raul Castro Ruz
Communists: approx. 200,000 party members
Member of: CEMA, ECLA, FAO, G-77, GATT, IADB
(nonparticipant), ICAO, IHO, ILO, IMCO, International
Rice Commission, ISO, {wWC—International Wheat Council,
ITU, NAM, NAMUCAR (Caribbean Multinational Shipping
Line—Naviera Multinacional del Caribe), OAS (nonpartici-
pant), Permanent Court of Arbitration, Postal Union of the
Americas and Spain, SELA, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG','4c83975642d0d082067de1296a5524e4bdd0246e53dd2ff58b63223c5effacde','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af70393d8a292077403faeaded56880f1329f4b5e04c8bb6d2eab1a818cf4e00',1978,'CY','Cyprus','government',136,'Legal name: Republic of Cyprus
Type: republic since August 1960; separate de facto Greek
Cypriot, and Turkish Cypriot governments have evolved
since outbreak of communal strife in 1963; this separation
was further solidified following the Turkish invasion of the
island in July 1974; negotiations, which have been going on
since January 1975, have focused on the creation of a federal
system of government with substantial autonomy for each of
the two communities
Capital: Nicosia
Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil law
modifications; negotiations to create the basis for a new or
revised constitution to govern the island and relations
between Greek and Turkish Cypriots have been going on
intermittently
48
Approved For Release 2005/04/22
National holiday: Independence Day, 1 October
Branches: currently a rump government with effective
authority only over the Greek Cypriot community, consist-
ing of Greek Cypriot parts of bodies provided for by
constitution; headed by President of the Republic and
comprised of Council of Ministers, House of Representatives,
and Supreme Court; Turkish Cypriots have their own
“Constitution” and governing bodies within the “Federated
Turkish State of Cyprus”
Government leaders: President, Spyros Kyprianou,
elected interim President in September 1977, to serve out
the remainder of the term of Archbishop Makarios who died
on 3 August 1977, and elected President in his own right by
acclamation in February 1978 (Greek); “President,” Rauf
Denktash (Turk); “Prime Minister,” Osman Orek (Turk)
Suffrage: universal age 2] and over
Elections: officially every 5 years; Turkish Cypriot
“Presidential” and “Parliamentary” elections held June
1976; Greek Cypriot parliamentary elections held in
September 1976; Greek Cypriot presidential election to be
held in February 1978
Political parties and leaders: Restorative Party of the
Working People (AKEL) (Communist Party), Ezekias
Papaioannou; Democratic Rally (DR), Glafkos Clerides;
Democratic Party (DP) (pro-Makarios), Spyros Kyprianou:;
United Democratic Union of the Center (EDEK), Vassos
Lyssarides; National Unity Party, Rauf Denktash; Populist
Party, Alper Orhon; Republican Turkish Cypriot Party,
Ahmet Berberoglou; Communal Salvation Party, Alpay
Durduran; Republic Turkish Cypriot Party (RTCP), Ozker
Ozeur
Voting strength: Rauf Denktash won the 1976 “Presiden-
tial” contest in the Turkish Cypriot zone with 76% of the
vote and his party won 30 of 40 seats in the “Assembly” with
54% of the vote; a pro-Makarios coalition composed of
AKEL, EDEK, and the DF received 75% of the vote in the
September 1976 Greek Cypriot parliamentary election and
34 of 35 seats while Clerides’ DM won 25% of the vote and
no seats; the remaining seat was given to an independent
Communists: 12,000; sympathizers estimated to number
60,000
Other political or pressure groups: United Democratic
Youth Organization (EDON) (Communist-controlled); Pan
Cyprian Labor Federation (PEO) (Communist-controlled);
Cyprus Confederation of Labor (SEK) (pro-West); Cyprus
Turkish Federation of Trade Unions (KTIBF ); Confeder-
ation of Revolutionary Worker Unions (DISK); Turkish
Cypriot Federation of Labor Union
Member of: Commonwealth, Council of Europe, FAO,
G-77,GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF,
ITU, NAM, ULN., UNESCO, UPU, WHO, WMO
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
CYPRUS /CZECHOSLOVAKIA
Legal name: Czechoslovak Socialist Republic (C.S.S.R.)
Type: Communist state
Capital: Prague
Political subdivisions: 2 ostensibly separate and nomi-
nally autonomous republics (Czech Socialist Republic and
Slovak Socialist Republic); 7 regions (kraj) in Czech lands,
three regions in Slovakia; national capitals of Prague and
Bratislava have regional status
Legal system: civil law system based on Austrian-
Hungarian codes, modified by Communist legal theory:
revised constitution adopted 1960, amended in 1968 and
1970; no judicial review of legislative acts; legal education at
Karlova University School of Law; has not accepted
compulsory ICJ jurisdiction
National holiday: Liberation Day, 9 May
Branches: executive—President (elected by Federal As-
sembly), cabinet (appointed by President); legislative—
Federal Assembly (elected directly), Czech and Slovak
National Councils (also elected directly) legislate on limited
area of regional matters; judiciary-——Supreme Court (elected
by Federal Assembly); entire governmental structure domi-
nated by Communist Party
Government leaders: President Gustav Husak (elected
May 1975), Premier Lubomir Strougal
Suffrage: universal over age 18
Elections: governmental bodies every 5 years (last
election, October 1976); President every 5 years
Dominant political party and leader: Communist Party
of Czechoslovakia (KSC), Gustav Husak, General Secretary;
Communist Party of Slovakia (KSS) has status of “provincial
KSC organization”
Voting strength (1976 election): 99.7% for Communist-
sponsored single slate
Communists: 1.38 million party members (April 1976)
Other political groups: puppet parties—Czechoslovak
Socialist Party, Czechoslovak People’s Party, Slovak Free-
dom Party, Slovak Revival Party
50
Member of: CEMA, FAO, GATT, IAEA, ICAO, IDA,
TEC, ILO, International Lead and Zinc Study Group, IMCO,
IPU, ISO, ITC, ITU, U.N., UNESCO, UPU, Warsaw Pact,
WHO, WIPO, WMO, WSG','cbe8347cc6e71efc80cd919f4f1e7b0fe7c1c26ed59eeadc41faf8b4c87315bc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c87e1e3b31ac61e987b00fc32fb5b404664da812c908c7da0f47db8593a2d691',1978,'DK','Denmark','government',140,'Legal name: Kingdom of Denmark
Type: constitutional monarchy
Approved For Release 2005/04/22
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes, 88
towns
Legal system: civil law system; constitution adopted 1953;
judicial review of legislative acts; legal education at
Universities of Copenhagen and Arhus; accepts compulsory
IC] jurisdiction, with reservations
National holiday: Birthday of the Queen, 16 April
Branches: legislative authority rests jointly with Crown
and parliament (Folketing); executive power vested in
Crown but exercised by cabinet responsible to parliament;
Supreme Court, 2 superior courts, 106 lower courts
Government leaders: Queen Marerethe IJ, Prime Minis-
ter, Anker Jorgensen
Suffrage: universal over age 21
Elections: on call of prime minister but at least every four
years (last election 15 February 1977)
Political parties and leaders: Social Democratic, Anker
Jorgensen; Liberal, Henning Christopherson (interim party
chairman) Conservative, Poul Schluter; Radical Liberal,
Kristen Helveg Petersen; Socialist Peoples, Gert Petersen;
Communist, Joergen Jensen; Left Socialist, Preben Wilhielm;
Center Democratic, Erhard Jakobsen; Christian People’s,
Jens Moller; Justice, Ib Christensen; Communist League
Marxist-Leninest, Benito Scocozza
Voting strength (1977 election): 37.5% Social Democratic,
14.3% Progressive, 12.3% Moderate Liberals, 8.3% Conserva-
tive, 6.4% Center Democratic, 3.9% Socialist Peoples, 3.7%
Communist, 3.6% Radical Liberal, 3.5% Christian, 3.2%
Justice, 2.7% Leftist Socialist
Communists: 7,500-8,000; a number of sympathizers, as
indicated by 114,034 Communist votes cast in 1977 elections
Member of: ADB, Council of Europe, DAC, EC, EEC,
ELDO (observer), EMA, ESRD, EURATOM, FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC, THO,
ILO, International Lead and Zine Study Group, IMCO,
IMF, IPU, ISO, ITC, ITU, {wC—International Wheat
Council, NATO, Nordic Council, OECD, U.N., UNESCO,
UPU, WHO, WIPO, WMO, WSG','5b3c8a99730173dd59f392f11b4d30f27c40d3e32cc91beab754f049340d3e04','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05e1cb7a014a5219d120ad9cb0fa3d023406f33cfcacdaf1adddeaa445d56f64',1978,'DJ','Djibouti','government',144,'Legal name: Republic of Djibouti
Type: republic
Capital: Djibouti
Legal system: based on French civil law system,
traditional practices and Islamic law
Branches: 65-member parliament, cabinet, president,
Prime minister
10% permanent
Government leader: President, Hassan Gouled
Suffrage: universal
Elections: Parliament elected May 1977
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
DJIBOUTI/ DOMINICA
Political parties and leaders: National Independence
Union (UND, Ali Aref Bourhan; African People’s Independ-
ence League (LPAI), Hassan Gouled and Ahmed Dini;
Popular Liberation Movement, Kamil Ali; Front for the
Liberation of the Somali Coast (FLCS); governing coalition
consists of the LPAI, the FLCS, and their Afar allies, elected
under the banner of the National Independence Rally (RNI)
Communists: possibly a few sympathizers
Member of: Arab League','686fe6bbaab3bf855f2eaad7f35ad67bb2b18cdbf0e5cdda2d6c5708104eda72','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('886c9b2f675a0db364558ff5c8d45bd132c59d11c1d948dfd427e22666abf035',1978,'DM','Dominica','government',148,'Legal name: State of Dominica
Type: dependent territory with full internal autonomy as
a British “Associated State; may become independent in
February 1978
Capital: Roseau
Political subdivisions: 10 parishes
Legal system: based on English common law; three local
magistrate courts and the British Caribbean “ Court of
Appeals
Branches: legislature, 11 member popularly elected
House of Assembly; executive, cabinet headed by Premier
Government leaders: Premier Patrick Roland John; U.K.
Governor Sir Louis Cools-Lartigue
Suffrage: universal adult suffrage over age 18
Elections: every 5 years; most recent March 1975
Political parties and leaders: Dominica Labor Party
(DLP), Patrick J ohn; Dominica Freedom Party (DFP), Miss
M. Eugenia Charles (unofficial)
Voting strength: House of Assembly seats—DFP 8 seats,
DLP 16 seats, independent 2 seats
Communists: negligible
Member of: CARICOM
53
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010
July 1978
DOMINICA/DOMINICAN REPUBLIC','a6ca5959c41556ed80919832aeb7880ca06fcbb5537132c2c1c0f41d24726527','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e45db1a1dc8ccde8021c04e5c963da23865df061e22156b14020ded2fad643d6',1978,'DO','Dominican Republic','government',152,'Legal name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 Provinces and the National
District
Legal system: based on French
constitution
civil codes; 1966
National holiday: Independence Day, 27 February
Branches: President popularly elected for a 4-year term;
bicameral legislature consisting of Senate (27 seats) and
Chamber of Deputies (91 seats) elected for 4-year terms:
Supreme Court
Government leader: President Joaquin Balaguer
Suffrage: universal and compulsory, over age 18 or
married, except members of the armed forces and police,
who cannot vote
Elections: national, last election May 1974, next election
May 1978
Political parties and leaders: Reformist Party (PR),
Joaquin Balaguer; Dominican Revolutionary Party (PRD),
Francisco Pena Gomez, Dominican Liberation Party (PLD),
Juan Bosch; Democratic Quisqueyan Party (PQD), Elias
Wessin y Wessin; Revolutionary Social Christian Party
(PRSC), Rogelio Delgado Bogaert; Movement for National
Conciliation (MNC), Jaime Manuel Fernandez Gonzalez;
Anti-reelection Movement of Democratic Integration
(MIDA), Francisco Augusto Lora; National Civic Union
(UCN), Guillermo Delmonte Urraca; National Salvation
Movement (MSN), Luis Julian Perez; Popular Democratic
Party (PDP), Homero Lajara Burgos; Fourteenth of June
Revolutionary Movement (MR-1J4), split into several fac-
tions, illegal; Dominican Communist Party (PCD), central
committee, legalized in 1978; Dominican Popular Move-
ment (MPD), illegal; 12th of January National Liberation
Movement (ML-12E), Plinio Matos Moquete, illegal; Com-
munist Party of the Dominican Republic (PACOREDO),
Luis Montas Gonzalez, illegal; Popular Socialist Party (PSP),
illegal
Voting strength (1974 election): 85% PR, 15% PDP, all
other parties abstained
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
DOMINICAN REPUBLIC/ECUADOR
Communists: an estimated 1,500 to 1,800 members in six
different factions; effectiveness limited by ideological
differences and organizational inadequacies
Member of: FAO, G-77, GATT, IADB, IAEA, IBA,
IBRD, ICAO, IDA, IDB, IFC, THO, ILO, IMCO, IMF,
IOOC, ISO, ITU, OAS, SELA, U.N., UNESCO, UPU, WHO,
WMO','ad747459478990718ee327a08b6dc4d4b270b7bdb4c3caabda344d3a280eeaf3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28bdbaa100aeff55a7ca37be3e509baf19d7009d85bf1e10858b71a8dbde8b74',1978,'EC','Ecuador','government',156,'Legal name: Republic of Ecuador
National holiday: Independence Day, 10 August
Type: republic; under military regime since 1972
Capital: Quito
Political subdivisions: 20 provinces including Galapagos
Islands
Legal system: based on civil law system; progressive new
constitution passed in January, 1978 referendum will come
into effect following the inauguration of a new civilian
55
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ECUADOR/ EGYPT
president before the end of 1978; legal education at 4 state
and 2 private universities; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 10 August
Branches: Supreme Council of Government, made up of
the three military chiefs, assumed power January 1976;
judiciary system supervised by Supreme Court; six special
tribunals established in July 1972
Government leader: President of Supreme Council Vice
Admiral Alfredo Poveda Burbano
Suffrage: universal for literates over age 18
Elections: presidential and municipal elections to be held
16 July 1978; will be followed by parliamentary elections
approximately nine months later
Political parties and leaders: Conservative Party, Sixto
Antonio Durvan-Ballen, center right; Radical Liberal Party,
Francisco Huerta Montalvo, center left; Concentration of
Popular Forces, Assad Bucaram, Jaime Roldos, populist:
Christian Democrats, Osvaldo Hurtado, center left; Demo-
cratic Left, Rodrigo Borja, center left; National Velasquistas
Front, Jose Maria Velasco Ibarra, personalistic
Voting strength: in June 1968 national elections, Velas-
quistas, a center-left coalition, and a rightist coalition each
got approximately one-third
Communists: Communist Party of Ecuador (PCE, pro-
Moscow, Pedro Saad—-secretary-general), 500 members plus
an estimated 3,000 sympathizers; Communist Party of
Ecuador (PCE/ML, pro-Peking), 100 members; Revolution-
ary Socialist Party of Ecuador (PSRE), 200 members
Member of: ECOSOC, FAO, G-77, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, THO, ILO, IMCO, IMF, ITU,
LAFTA and Andean Sub-Regional Group (formed in May
1969 within LAFTA), OAS, OPEC, SELA, U.N., UNESCO,
UPEB, UPU, WHO, WMO','a5ed714bdcbca44a16e749d01850860eb2a944737b9c979975cabd73f7439672','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('235650015745edfe73a52d5ec9e5ef3843a4520d57d8cc7a97459189ae92fdb3',1978,'EG','Egypt','government',160,'Legal name: Arab Republic of Egypt
Type: republic; under presidential rule since June 1956
Capital: Cairo
Political subdivisions: 25 governorates
Legal system: based on English common law, Islamic law,
and Napoleonic codes; permanent constitution written in
1971; judicial review of limited nature in Supreme Court,
also in Council of State which oversees validity of
administrative decisions; legal education at Cairo University;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: National Day, 23 July
Branches: executive power vested in President, who
appoints cabinet; People’s Assembly gradually gaining power
as political liberalization program is implemented; indepen-
dent judiciary administered by Minister of Justice
Government leader: President Anwar Sadat
Suffrage: universal over age 18
Elections: elections to People’s Assembly every 5 years
(most recent October 1976); presidential elections every 6
years (most recent September 1976)
Political parties and leaders: formation of political
parties must be approved by government-controlled Arab
Socialist Union (ASU)
Communists: approximately 500, party members
Member of: AAPSO, AFDB, Arab League, FAO, G-77,
GATT, IAEA, IBRD, ICAC, ICAO, IDA, IFC, THO, ILO,
IMCO, IMF, IOOC, IPU, ITU, !WC—International Wheat
Council, NAM, OAPEC, OAU, U.N., UNESCO, UPU,
WHO, WIPO, WMO, WPC, WSG','b5aab68b2e1392db859b58d8569c3797f2820bea35512f01b94c1286cefeb0d4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8446648402b9534770f668b464eaf55b12e08775e0d0ce4c2fc3c96482fa264',1978,'SV','El Salvador','government',164,'Legal name: Republic of E] Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of
common law; constitution adopted 1962; judicial review of
legislative acts in the Supreme Court; legal education at
University of El Salvador; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: Independence Day, 15 September
Branches: traditionally dominant executive, unicameral
legislature, Supreme Court
Government leader: President Gen. Carlos Humberto
Romero Mena
Suffrage: universal over age 18
Elections: legislative elections every 2 years; presidential
elections every 5 years; presidential elections 1982, legisla-
tive and municipal elections March 1980
Political parties and leaders: National Conciliation Party
(PCN), President Arturo A. Molina, and replaced by Carlos
Humberto Romero on 1 July; Christian Democratic Party
(PDC), Juan Ramirez Rauda, Dr. Pablo Mauricio Alvergue,
Jose Napoleon Duarte; Salvadoran Popular Party (PPS),
Benjamin Wilfredo Navarrete, Roberto Quinonez Meza, Dr.
Jose Antonio Guzman; Communist Party of El Salvador
(PCES), illegal, Jorge Shafick Handal; National Revolution-
ary Movement (MNR), Dr. Guillermo Manuel Ungo;
National Democratic Union Party (PUDN), Communist
Front, Jorge Shafick Handal, Francisco Roberto Lima, Julio
Ernesto Contreras, Julio Castro Belloso; Independent Demo-
cratic United Front (FUDI), Gen. Jose A. Medrano, Raul
Salaverria
Voting strength: February 1977 presidential election—
PCN 66%, PDC, PUDN, and MNR coalition, 34%; March
1978 legislative election—PCN, 50 seats; PPS, 4 seats; all
other opposition parties boycotted the election
Communists: 220 to 225 active members; sympathizers,
5,000
Other political or pressure groups: the military; about
100 prominent families; General Confederation of Trade
Unions (CGS); Unifying Federation of Salvadoran Trade
Unions (FUSS), Communist dominated; Federation of
Construction and Transport Workers Unions (FESINCONS-
TRANS), independent; Catholic Church; Salvadoran Na-
tional Association of Educators (ANDES); National Associ-
ation of Private Enterprise (ANEP); National Democratic
Organization (ORDEN)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
EL SALVADOR/EQUATORIAL GUINEA
Member of: Central American Common Market (CACM),
FAO, G-77, IADB, IAEA, IBRD, ICAC, ICAO, IDA, IDB,
IFC, ILO, IMF, ITU, IWC —International Wheat Council,
OAS, ODEGA, SELA, U.N., UNESCO, UPU, WHO, WMO','d8aaeca5b0c0c8173ae77ae3a0a2c3849a0bbdd8a629dfe50d4415594f158286','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61b831be83d849f1d2bb5088fd5e1192097718f8d9ae2264c2ae4f3e29b6f389',1978,'GQ','Equatorial Guinea','government',168,'Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since 1968
Capital: Malabo, Province Francisco Macias Nguema
Political subdivisions: 2 provinces (Province Francisco
Macias Nguema and Rio Muni)
59
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
EQUATORIAL GUINEA/ETHIOPIA
Legal system: based on Spanish Civil law system and
customary law, new constitution adopted August 1973; has
not accepted compulsory ICJ jurisdiction
National holiday: 5 March
Branches: there are legislative and judicial branches but
President exercises virtually unlimited power
Government leader: President for life, Francisco Macias
Nguema
Suffrage: universal age 21 and over
Elections: parliamentary elections held December 1973
Political parties and leaders: National Unity Party of
Workers (PUNT) is the sole legal party, led by President
Macias
Communists: no significant number of Communists or
sympathizers
Member of: Conference of East and Central African
States, ECA, G-77, IBRD, ICAO, IDA, IMCO, IMF, ITU,
NAM, OAU, U.N., UPU','b83bb1d0d115045dac4459b257fcc69503da87a9822325a2958547f1810b6ff0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc09f723753277b23f84e327357cb6165d352341109dacda139ed6521b62947a',1978,'ET','Ethiopia','government',172,'Legal name: Ethiopia
Type: under military rule since mid-1974; monarchy
abolished in March 1975, but republic not yet declared
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred to as
regional administrations)
Legal system: complex structure with civil, Islamic,
common and customary law influences; constitution sus-
pended September 1974; military leaders have promised a
new constitution but established no time frame for its
adoption; legal education at Addis Ababa University; has not
accepted compulsory ICJ jurisdiction
National holiday: Popular Revolution Commemoration
Day, 12 September
Branches: effective power exercised by Provisional
Military Administrative Council (PMAC), a group estimated
at 40-100 officers and enlisted men which operates on
committee system; predominantly civilian cabinet is ineffec-
tual and holds office at suffrance of military; legislature
dissolved September 1974; judiciary at higher levels based on
Western pattern, at lower levels on traditional pattern,
without jury system in either
Government leader: Lieutenant Colonel Mengistu Haile-
Mariam, Chairman of the Provisional Military Administra-
tive Council
Suffrage: universal over age 21
Elections: union dwellers’ association officials elected
October-December 1976
Political parties and leaders: Common front of Ethiopian
Marxist-Leninist organizations, encompassing five quasi-
official groups—AIl-Ethiopian Socialist Movement (Me’l
Sone), Revolutionary Flame (Seded), and three less impor-
tant ones
Communists: Ethiopian Communist Party is a small
group opposed to military government
Other political or pressure groups: important dissident
groups include Eritrean Liberation Front (ELF), Eritrean
People’s Liberation Front (EPLF), and Eritrean Liberation
Front/Popular Liberation Forces in Eritrea; Ethiopian
People’s Revolutionary Party (EPRP), a radical left under-
ground movement concentrated in Addis Ababa and made
up predominantly of students and intellectuals; it has been
severely reduced by a recent government eradication
campaign; and Ethiopian Democratic Union (EDU), primar
ily an exile group, although it has made some inroads inside
Ethiopia; several other dissident groups with ethnic or
provincial bases of support
Member of: AFDB, ECA, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, NAM, OAU, U.N.,
UNESCO, UPU, WHO, WMO','d54d5476c02ce08687dcafea2a79a13edbacfbd1f5378f5bc387678d941cc32b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ceae08f2dd0358decb2a0f7d930cb93d46bba57c841fc46b8f56a7cfba471855',1978,'DE','Germany','government',177,'Legal name: Colony of the Falkland Islands
Type: British crown colony
Capital: Stanley
'' The possession of the Falkland Islands has been disputed by the
U.K. and Argentina (which refers to them as the Islas Malvinas)
since 1833.
62
Political subdivisions: local government is confined to
capital
Legal system: English common law
Legislative
Branches: Executive Council,
Council
Governor,
Government leader: Governor and Commander in Chief
Ernest G. Lewis (also High Commissioner for British
Antarctic Colony)
Suffrage: universal
Legal name: Empire of Iran
Type: constitutional monarchy, controlled by the Shah
Capital: Tehran
Political subdivisions: 23 provinces, subdivided into
districts, sub-districts, counties, and villages
Legal system: based largely on French law, with elements
drawn from other continental systems; personal law based on
Islamic practice generally with residual traces of Roman
law; constitution adopted 1906 and constitutional law of
1907; High Court of Appeal may judge disputes relating to
government departments acting according to law; legal
education at University of Teheran; has not accepted
compulsory ICJ jurisdiction
National holiday: Birthday of the Shah, 26 October
Branches: executive power rests in Shah who appoints a
Prime Minister; Prime Minister must be approved by lower
house (Mailis); while Cabinet theoretically responsibility of
Prime Minister, Shah usually exerts strong influence over its
selection; bicameral legislature; Majlis has 268 members
elected to 4-year terms, and Senate 60 members serving
4-year terms; half of Senate members appointed by Shah,
other half elected; no provision for judicial review of
constitutionality of legislative acts
Government leaders: Shah Mohammad Reza Pahlavi and
Prime Minister Jamshid Amuzegar
Suffrage: universal over age 20
Elections: Majlis every 4 years; Senate every 4 years;
latest national elections June 1975, last district and
municipal October 1976
Political parties and leaders: a single party system,
designated The Resurgence Party of the People of Iran
(RPPI) with Jamshid Amuzegar as Secretary-General, was
formed by Shah in March 1975; all other political parties
disbanded
Voting strength: all candidates government approved and
members of the RPPI
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
IRAN/IRAQ
Communists: 1,000-2,000 (hard-core, est.); sympathizers
(15,000-20,000 est.); mostly pro-U.S.S.R. but pro-Chinese
faction developing
Other political or pressure groups: Tudeh Party (Com-
munist, illegal); nationalist opposition coalition; Confeder-
ation of Iranian Students (illegal)
Member of; CENTO, Colombo Plan, FAO, G-77, IAA,
IBRD, ICAC, ICAO, IDA, IFC, IHO, ILO, IMCO, IMF,
IPU, ITU, OPEC, RCD, U.N., UNESCO, UPU, WFTU,
WHO, WMO, WSG
Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal
systems; constitution adopted 1961; judicial review of
legislative acts by Constitutional Court; legal education at
Universities of Ankara and Istanbul; accepts compulsory IC]
jurisdiction, with reservations
National holiday: Republic Day, 29 October
Branches: President elected by parliament; Prime Minis-
ter appointed by President from members of parliament;
Prime Minister is effective executive; cabinet, selected by
Prime Minister and approved by President, must command
majority support in lower house; parliament bicameral
under constitution promulgated in 1961; National Assembly
has 450 members serving 4 years; Senate has 150 elected
members, one-third elected every 2 years, 15 appointed by
the President to 6-year terms (one-third appointed every 2
years), and 19 life members; highest court for ordinary
criminal and civil cases is Court of Cassation, which hears
appeals directly from criminal, commercial, basic, and peace
courts
Government leaders: President Fahri Koruturk; Prime
Minister Bulent Ecevit
6-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A00090001000
i ha TECTC
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
TURKEY /TUVALU
Suffrage: universal over age 2]
Elections: National Assembly and Senate (1/3 of seats),
Republican People’s Party won a plurality in June 1977;
Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People’s Party (RPP), Bulent
Ecevit; National Salvation Party (NSP), Necmettin Erbakan;
Democratic Party (DP), Ferruh Bozbeyli; Republican
Reliance Party (RRP), Turhan Feyzioglu; Nationalist Action
Party (NAP), Alpaslan Turkes; Unity Party (UP), Mustafa
Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government in March 1971 and
remains an influential force in national affairs
Member of: ASSIMER, CENTO, Council of Europe, EC
(associate member), ECOSOC, FAO, GATT, IAEA, IBRD,
ICAC, ICAO, IDA, IEA, IFC, THO, ILO, IMCO, IMF,
IOOG, IPU, ITC, ITU, NATO, OECD, Regional Coopera-
tion for Development, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG','ef2d9621b2ca2517cac77f8321a473f138c7252b2ad807396449533d0a75baf3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27a08401df723b07f6747e43e82dd0ed2301d452dfab886b451ab83a3169847d',1978,'FO','Faroe Islands','government',180,'Legal name: Faroe Islands
Type: self-governing province within the Kingdom of
Denmark; 2 representatives in Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, | town
Legal system: based on Danish law; Home Rule Act
enacted 1948
Branches: legislative authority rests jointly with Crown,
acting through appointed High Commissioner, and provin-
cial parliament (Lagting) in matters of strictly Faroese
concern; executive power vested in Crown, acting through
High Commissioner, but exercised by provincial cabinet
responsible to provincial parliament
Government leaders: Queen Marerethe II; Prime Minis-
ter, Atli Dam, Danish Governor, Leif Groth
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years, next election 1981
(coincides with Danish elections)
Approved For Release 2005/04/22 :
Political parties and leaders: Peoples, Hakun Djurhuus;
Republican, Erlendur Patursson; Home Rule, Samuel
Petersen; Progressive, Kiartan Mohr; Social Democratic, Atli
Dam; Union, Kristian Djurhuus
Voting strength (1975 election): Social Democratic 25.8%,
Republican 22.5%, Peoples 20.5%, Union 19.1%, Home Rule
7.2%, Progressive 2.5%
Communists: insignificant number
Member of: Nordic Council','262e01afd705268794d9abad3c09507639fc57abb28ccc7bdce0013c2be7eb7f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27b02691f5dfbf256d3abdaf976a8ef50ddf0fdcaf8a03354f7ac85df7d2aea8',1978,'FJ','Fiji','government',184,'Legal name: Dominion of Fiji
Type: independent state within Commonwealth; Eliza-
beth II recognized as head of state
Capital: Suva
Political subdivisions: 14 provinces
in agriculture, no
Legal system: based on British
National holiday: 10 October
Branches: executive—Prime Minister; legislative—
52-member House of Representatives; Alliance Party 36
seats, National Federation Party 15 seats; 1 independent
Government leader: Prime Minister Ratu Sir Kamisese
Mara
Suffrage: universal adult
Elections: every 5 years unless House dissolves earlier, last
held September 1977
Political parties: Alliance, primarily Fijian, headed by
Ratu Mara; National Federation, primarily Indian, headed
by Jai Ram Reddy
Communists: few, no figures available
July 1978
Member of: ADB, Colombo Plan, Commonwealth, FAO,
G-77, GATT (de facto), IBRD, ICAO, IDA, IMF, ISO, ITU,
U.N., UPU, WHO, WIPO','e3eaa56a6318e5d8fc9e428b06b63116842cc4a2512f1c75a1dcd8b1dff24378','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64ec352b5ce07db3bf350e512661e95a9498b77ac6822524636632e3221903ef',1978,'FI','Finland','government',188,'Legal name: Republic of Finland
Type: republic
Capital: Helsinki
Political subdivisions: 12 provinces; 443 communes, 78
towns
Legal system: civil law system based on Swedish law;
constitution adopted 1919; Supreme Court may request
legislation interpreting or modifying laws; legal education at
Universities of Helsinki and Turku; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Independence Day, 6 December
Branches: legislative authority rests jointly with President
and parliament (Eduskunta); executive power vested in
President and exercised through cabinet responsible to
parliament; Supreme Court, 4 superior courts, 193 lower
courts
Government leader: President Urho K. Kekkonen; Prime
Minister Kalevi Sorsa
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in 1979);
presidential, every 6 years (President Kekkonen reelected to
6-year term in January 1978)
Political parties and leaders: Social Democratic, Rafael
Paasio; Center, Johannes Virolainen; Peoples Democratic
League (Communist front), Ele Alenius; Conservative, Harri
Holker; Liberal, Pekka Tarjanne; Swedish Peoples Party,
Kristan Gestrin; Rural, Veikko Vennamo; Finnish People’s
Unity Party, Eino Haikala, Communist, Aarne Saarinen
Voting strength (1978 election): 23.3% Social Democratic,
19.5% Center, 18.2% People’s Democratic League, 14.7%
Unionist, 8.8% Christian League, 4.7% Finnish Rural Party,
3.6% Swedish Peoples, 3.4% Constitutional Peoples, 2.9%
Liberal Peoples, 0.8% Finnish Peoples Unity Party, 0.1%
Socialist Workers’ Party
Communists: 43,000; an additional 65,000 persons belong
to Peoples Democratic League; a further number of
sympathizers, as indicated by 438,757 votes cast for Peoples
Democratic League in 1975 elections
Member of: ADB, CEMA (special cooperation agree-
ment), DAC, EC (free trade agreement), EFTA (associate),
FAO, GATT, IAEA, IBRD, ICAC, ICAO, ICES, IDA, IFC,
IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, ITU, IWC—International Wheat Coun-
cil, Nordic Council, OECD, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG','41c37ec40671133033e840e222edca5452f3d8a5e95a400a644cfe0a07b41a2e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0a67b4a74de61950a87b8eea13b74236333830e5e4cf1b79119d82830ad89d3',1978,'FR','France','government',192,'Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 96 metropolitan departments, 21
regional economic districts
Legal system: civil law system with indigenous concepts;
new constitution adopted 1958, amended concerning elec-
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
tion of President in 1962; judicial review of administrative
but not legislative acts; legal education at over 25 schools of
law
National holiday: National Day, 14 July
Branches: presidentially appointed Prime Minister heads
Council of Ministers, which is formally responsible to
National Assembly; bicameral legislature—National Assem-
bly (491 members), Senate (295 members) restricted to a
delaying action; judiciary independent in principle
Government leader: President Valery Giscard d’Estaing
Suffrage: universal over age 18; not compulsory
Elections: National Assembly—every 5 years, last election
March 1978, direct universal suffrage, 2 ballots; Senate—
indirect collegiate system for 9 years, renewable by
one-third every 3 years, last election September 1977;
President, direct, universal suffrage every 7 years, 2 ballots,
last election May 1974
Political parties and leaders: Majority Coalition—Rally
for the Republic (RPR, formerly UDR), Jacques Chirac;
Republicans (PR), Jacaues Blanc; Center for Social Demo-
crats (CDS), Jean Lecanuet; Radical Socialist (RS), Jean-
Jacques Servan-Schreiber; Union for French Democracy
(federation of PR, CDS, and RS), Jean Lecanuet;, Left
Opposition—Socialist Party (PS), Francois Mitterrand; Com-
munist Party (PCF), Georges Marchais; Left Radical
Movement (MRG), Robert Fabre; Unified Socialist Party
(PSU), Michel Mousel
Voting strength (first ballot, 1978 election): extreme left,
3.3%; Communist, 21.25%; Socialist, 23.03%; left Radicals
2.28%; RPR, 22.19%; UDF, 21.39%; divided right, 1.68%;
other 4.87%
Communists: 600,000 claimed; Communist voters, 5
million average
Other political or pressure groups: Communist-con-
trolled labor union (Confederation Generale du Travail)
nearly 2.4 million members (claimed); Socialist leaning labor
union (Confederation Francaise Democratique du Travail—
CFDT) about 800,000 members est.; Independent labor
union (Force Ouvriere) about 800,000 members est.;
Independent white collar union (Confederation Generale des
Cadres) 200,000 members (claimed); National Council of
French Employers (Conseil National du Patronat Francais—
CNPF or Patronat)
Member of: ADB, Council of Europe, DAC, EC, ECSC,
EEC, EIB, ELDO, EMA, ESRO, EURATOM, FAO, GATT,
IAEA, IATP, IBRD, ICAC, ICAO, ICES, IDA, IFC, THO,
ILO, International Lead and Zinc Study Group, IMCO,
IMF, IOOC, IPU, ISO, ITC, ITU, 1WC—International
Whaling Commission, NATO (signatory), OAS (observer),
OECD, South Pacific Commission, U.N., UNESCO, UPU,
WEU, WHO, WIPO, WMO, WSG
Approved For Release 2005/04/22 :
Legal name: Colony of Southern Rhodesia
Type: Self-proclaimed independent state since 1965 (not
recognized by U.S.); provisional settlement with U.K. in
November 1971 cancelled by U.K. in May 1972 in response
to Pearce Commission’s conclusion that its terms were
unacceptable to the majority of black Rhodesians. A
conference in Geneva in late 1976, failed to agree on a new
multiracial interim government in Rhodesia to govern the
country during a transition to black majority rule. In March
1978, Prime Minister Smith and three black nationalist
leaders set up an interim government to prepare for transfer
to black majority rule by 31 December 1978. The interim
goverment has not been recognized by the U.S. and U.K,,
who are attempting to negotiate a settlement that will
include external nationalist leaders.
Capital: Salisbury
Political subdivisions: 11 magisterial districts
Legal system: Smith government implemented a republi-
can constitution on 2 March 1970 which institutionalized
white rule
Branches: President Wrathall is ceremonial head of state;
executive council (cabinet) lead by Prime Minister Smith;
National Assembly gives highly disproportionate representa-
tion to white minority—50 white constituency seats and 16
black constituency seats
Government leaders: Prime Minister lan Smith and
President John Wrathall
Suffrage: franchise is based on income, property holdings,
and education; there are separate rolls for Africans and
non-Africans
cr
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front, Prime
Minister Smith; Rhodesian Action Party, Ian Sandeman,
National Unifying Force, Allan Savory; Zimbabwe United
People’s Organization, Jeremiah Chirau; United African
National Council, Bishop Abel Muzorewa; African National
Council/Sithole, Ndabaningi Sithole
Voting strength (1977 elections): Rhodesian Front won all
50 white constituency seats in Parliament in August 1977
elections
169
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
RHODESIA/ROMANIA
Communists: negligible
Other pressure groups and leaders: external black
nationalists Joshua Nkomo and Robert Mugabe are loosely
allied in the Patriotic Front
Member of: ITU','ebe39869b64b252f50c2aaea6c322a26ff714ff0ad64eccc21d1d9706a72a715','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('537934ef35d4b2605890b8055af15ce46a82f2ae4214075cdb141be631e1a15a',1978,'GF','French Guiana','government',196,'Legal name: Department of French Guiana
Type: overseas department and region of France;
represented by one deputy in French National Assembly and
one senator in French Senate; Deputy Hector Rivierez
reelected to National Assembly 12 March 1978
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19 communes
each with a locally elected municipal council
Legal system: French legal system; highest court is Court
of Appeal based in Martinique with jurisdiction over
Martinique, Guadeloupe, and French Guiana
Branches: executive: prefect appointed by Paris; legisla-
tive: popularly elected 16-member General Council and a
Regional Council composed of members of the local General
Council and of the locally elected deputy and senator to the
French parliament; judicial, under jurisdiction of French
judicial system
Government leader: Prefect Herve Bourseiller
Suffrage: universal over age 18
Elections: General Council elections normally are held
every 5 years; last election March 1976; local elections last
held March 1977
Political parties and leaders: Parti Socialiste Guyanais
(PSG), Leopold Heder, Senator; Union du Peuple Guyanaise
(UPG), weak leftist allied with, but also reported, to have
been absorbed by the PSG; Rassemblement Pour La
Republique (RPR), Hector Rivierez, delegate to French
National Assembly
Communists: Communist party membership negligible','a8be5f5b3a48a6e4f31fc308305905d006c6404aad82a639e929db5682b5cf4c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b448572ecb20566bb0231f6851c1ef013e2f634a974ce9a9d98a70eb904c05f8',1978,'PF','French Polynesia','government',200,'Legal name: Territory of French Polynesia
Type: overseas territory of France, administered by
French Ministry for Overseas Territories
Capital: Papeete
Pacific Ocean
CHRISTMAS 1S.
*, FRENCH
POLYNESIA.
cook is.°
{See reference map VIII}
Political subdivisions: 5 districts
Legal system: based on French; lower and higher courts
Branches: 33-member Territorial Assembly, popularly
elected; 5-member Council of Government, elected by
Assembly; popular election of one deputy to National
Assembly in Paris, also one Senator
Government leader: Charles Schmitt, Governor, ap-
pointed by French government
Suffrage: universal adult
Elections: every 5 years, May 1977
Political parties and leaders: Le Front Uni, autonomist
coalition, Francis Sanford; Tahoeraa Hairaatira, conservative
Gaullist, Gaston Flosse
Voting strength (1977 election): Le Front Uni, 14 seats;
Tahoerra Huiraatira, 10 seats; Independents, 9 seats','5142b9e3298a6a209e7947be6a00691c23746c613e1ef6f0e10aeac284fabb9a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('965550abd8b8bcf2b4d37e45e0d8dd51186a6ab7fc784154bd2357320d2fd9fe',1978,'GA','Gabon','government',204,'Legal name: Gabonese Republic
Type: republic; one-party presidential regime since 1964
Capital: Libreville
Political subdivisions: 9 provinces subdivided into 36
prefectures
Legal system: based on French civil law system and
customary law; constitution adopted 1961; judicial review of
legislative acts in Constitutional Chamber of the Supreme
Court; legal education at Center of Higher and Legal Studies
at Libreville; compulsory ICJ jurisdiction not accepted
National holiday: 17 August
Branches: power centralized in President, elected by
universal suffrage for 7-year term; unicameral 70-member
National Assembly has limited powers; judiciary
Government leader: President Omar Bongo
Suffrage: universal over age 21
Elections: Presidential and parliamentary elections last
held February 1973
Political parties and leaders: Gabonese Democratic Party
(PDG) led by President Bongo is only legal party
Communists: no organized party; probably some Com-
munist sympathizers
Member of: AFDB, Conference of East and Central
African States, EAMA, EIB (associate), FAO, G-77, GATT,
IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF, IPU, ITU, NAM,
OAU, OPEC, UDEAC, U.N., UNESCO, UPU, WHO,
WIPO, WMO
Legal name: Republic of The Gambia
Type: republic; independent since February 1965
Capital: Banjul
Political subdivisions: Banjul and 5 divisions
Legal system: based on English common law and
customary law; constitution came into force upon independ-
ence in 1965, new republican constitution adopted in April
1970; accepts compulsory ICJ jurisdiction, with reservations
National holiday: 18 February
Branches: cabinet of 10 members; 44-member House of
Representatives, in which 4 seats are reserved for chiefs, 4
are appointed, 35 are filled by election for 5-year terms, a
Speaker is elected by the House, and the Attorney General is
an appointed member; independent judiciary
Government leader: Alhadji Sir Dawda K. Jawara,
President
Political parties and leaders: People’s Progressive Party
(PPP), Secretary General Dawda K. Jawara, United Party
(UP), John Forster, and National Convention Party, Sherrif
Dibba
Suffrage: universal adult
Elections: general elections held April 1977; PPP 29 seats,
NCP 5 seats, UP 1 seat
Communists: insignificant number
Member of: AFBD, APC, Commonwealth, ECA,
ECOWAS, FAO, G-77, GATT, IBRD, IDA, IMF, NAM,
OAU, U.N., WHO
Legal name: German Democratic Republic
Type: Communist state
Capital: East Berlin (not officially recognized by US.,
U.K., and France, which together with the U.S.S.R. have
special rights and responsibilities in Berlin)
Political subdivisions: (excluding East Berlin) 14 districts
(Bezirke), 218 counties (Kreise), 7,643 communities
(Gemeinden)
Legal system: civil law system modified by Communist
legal theory; new constitution adopted 1974; court system
parallels administrative divisions; no judicial review of
legislative acts; legal education at Universities of Berlin,
Leipzig, Halle and Jena; has not accepted compulsory ICJ
jurisdiction; more stringent penal code adopted 1968,
amended in 1974
National holiday: Foundation of German Democratic
Republic, 7 October
Branches: legislative—Volkskammer (elected directly);
executive—Chairman of Council of State, Chairman of
Council of Ministers, Cabinet (approved by Volkskammer);
judiciary—Supreme Court; entire structure dominated by
Socialist Unity (Communist) Party
Government leaders: Chairman, Council of State, Erich
Honecker (Head of State); Chairman, Council of Ministers,
Willi Stoph (Head of Government)
Suffrage: all citizens age 18 and over
Elections: national every 5 years; prepared by an electoral
commission of the National Front; ballot supposed to be
secret and voters permitted to strike names off ballot; more
candidates than offices available; parliamentary elections
held 17 October 1976
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GERMAN DEMOCRATIC REPUBLIC/GERMANY, FEDERAL REPUBLIC OF
Political parties and leaders: Socialist Unity (Commu-
nist) Party (SED), headed by General Secretary Erich
Honecker, dominates the regime; 4 token parties (Christian
Democratic Union, National Democratic Party, Liberal
Democratic Party, and Democratic Peasant’s Party) and an
amalgam of special interest organizations participate with
the SED in National Front
Voting strength: 1976 parliamentary elections: 99.86%
voted the regime slate; 1970 local elections: 99.85% voted the
regime slate
Communists: 1.9 million party members
Other special interest groups: Free German Youth, Free
German Trade Union Federation, Democratic Women’s
Federation of Germany, German Cultural Federation (all
Communist dominated)
Member of: CEMA, ICES, IPU, ITU, U.N., UNESCO,
UPU, Warsaw Pact, WHO, WIPO
Legal name: Federal Republic of Germany
Type: federal republic
Capital: Bonn
Political subdivisions: 10 Laender (states); Western
sectors of Berlin are ultimately controlled by U.S., U.K., and
France which, together with the U.S.S.R., have special rights
and responsibilities in Berlin
Legal system: civil law system with indigenous concepts;
constitution adopted 1949; judicial review of legislative acts
in the Supreme Federal Constitutional Court; has not
accepted compulsory ICJ jurisdiction
Branches: bicameral parliament—Bundesrat (upper
house), Bundestag (lower house); President (titular head of
state), Chancellor (executive head of government);
independent judiciary
Government leaders: President, Walter Scheel; Chancel-
lor, Helmut Schmidt leads coalition of Social Democrats and
Free Democrats
Suffrage: universal over age 18
Elections: next national election scheduled for fall of 1980
Political parties and leaders: Christian Democratic
Union/Christian Social Union (CDU/CSU), Helmut Kohl,
Franz-Josef Strauss, Karl Carstens, Kurt Biedenkopf; Social
Democratic Party (SPD), Willy Brandt, Hans Koschnick,
Helmut Schmidt; Free Democratic Party (FDP), Hans-Die-
trich Genscher, Hans Friderichs, Wolfgang Mischnick;
National Democratic Party (NPD), Martin Mussgnug;
Communist Party (DKP), Herbert Mies
Voting strength (1976 election): 42.6% SPD, 48.6%
CDU/CSU, 7.9% FDP, 0.9% Splinter groups of left and right
(no parliamentary representation)
Communists: about 40,000 members and supporters
Other political or pressure groups: expellee, refugee, and
veterans groups
Member of: ADB, Council of Europe, DAC, EC, ECSC,
EIB, ELDO, EMA, ESRO, EURATOM, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC, IHO, ILO,
International Lead and Zinc Study Group, IMCO, IMF, IPU,
ITC, ITU, NATO, OAS (observer), OECD, U.N., UNESCO,
UPU, WEU, WHO, WIPO, WMO, WSG','70da4d5cbdd252262743a1c6979cfc5b62ff54217b7dc79b54121a2289b9bdbe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f570a774106073675e78f2c844ce7f31393fc603fd2426f34b4bd729778f75a',1978,'GN','Guinea','government',208,'Legal name: Republic of Ghana
Type: republic; independent since March 1957; Military
regime since January 1972
Capital: Accra
Political subdivisions: 8 administrative regions and
separate Greater Accra Area; regions subdivided into 58
districts and 267 local administrative districts
Legal system: based on English common law and
customary law; constitution suspended January 1972; legal
education at University of Ghana (Legon); has not accepted
compulsory IC] jurisdiction
National holiday: Independence Day, 6 March
Branches: executive and legislative authority vested in
Supreme Military Council (SMC); independent judiciary
Government leaders: Chief of State, Chairman of SMC
General Ignatius Kutu Acheampong
Suffrage: universal over 21 under previous constitution,
now suspended
Elections: no elections since 1969; the military has
promised to return power to an elected civilian regime in
June 1979; a commission was appointed in April 1978 to
draft a new constitution by October 1978 which is then to be
reviewed by a constituent assembly
Political parties and leaders: parties banned by military
junta which took power 18 January 1972
Communists: a small number of Communists and
sympathizers
Member of; AFDB, Commonwealth, ECA, ECOWAS,
FAO, G-77, GATT, IAEA, IBA, IBRD, ICAO, IDA, IFC,
ILO, IMCO, IMF, ISO, ITU, NAM, OAU, U.LN., UNESCO,
UPU, WCL, WHO, WIPO, WMO
Legal name: Republic of Guinea
Type: republic; under one-party presidential regime
Capital: Conakry
Political subdivisions: 29 administrative regions, 209
arrondissements, about 8,000 local entities at village level
Legal system: based on French civil law system,
customary law, and presidential decree; constitution adopted
1958; no constitutional provision for judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 2 October
Branches: executive branch dominant, with power
concentrated in President’s hands and a small group who are
both ministers and members of the party''s politburo;
unicameral National Assembly and judiciary have little
independence
Government leader: President Ahmed Sekou Toure, who
has been designated “The Supreme Leader of the
Revolution”
Suffrage: universal over age 18
Elections: approximate schedule—5 years parliamentary,
latest in 1975; 7 years presidential, latest in 1975
Political parties and leaders: only party is Democratic
Party of Guinea (PDG), headed by Sekou Toure
Communists: no Communist party, although there are
some sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, G-77, IBA,
IBRD, ICAO, IDA, ILO, IMF, ITU, Niger River Commis-
sion, NAM, OAU, U.N., UNESCO, UPU, WHO, WMO
84
Legal name: Republic of the Ivory Coast
Type: republic, one-party presidential regime established
1960
Capital: Abidjan
Political subdivisions: 24 departments subdivided into
127 subprefectures
Legal system: based on French civil law system and
customary law; constitution adopted 1960; judicial review in
the Constitutional Chamber of the Supreme Court; legal
education at Abidjan School of Law; has not accepted
compulsory ICJ jurisdiction
National holiday: 7 December
Branches: President has sweeping powers, unicameral
legislature, separate judiciary
Government leader: President Felix Houphouet-Boigny
Suffrage: universal over age 21
Elections: uncontested Presidential and legislative elec-
tions held in November 1975 for 5-year term
103
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
IVORY COAST/JAMAICA
Political parties and leaders: Parti Democratique de la
Cote d‘Tvoire (PDC), (only party); official party leader is
Secretary General Philippe Yace, but Houphouet-Boigny js
in control
Communists:
sympathizers
Member of: AFDB, CEAO, EAMA, ECA, ECOWAS, EIB
(associate), Entente, FAO, G-77, GATT, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU, Niger River
Commission, NAM, OAU, OCAM, U.LN,, UNESCO, UPU,
WHO, WIPO, WMO','d49c42c7748b515003ea0c0066290ee0e0ea6a93a11478133011b48456c5a61b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30edacff5f488092efb66eea25c6eff70d312e173b548c77cd9a0a79a2d67eac',1978,'GI','Gibraltar','government',212,'Legal name: Colony of Gibraltar
Type: U.K. colony
Capital: none
Legal system: English law; constitutional talks in July
1968; new system effected in 1969 after electoral enquiry
Branches: parliamentary system comprised of the Gibral-
tar House of the Assembly (15 elected members and 3 ex
officio members), the Council of Ministers headed by the
Chief Minister, and the Gibraltar Council; the Governor is
appointed by the Crown
Government leaders: Governor and Commander in
Chief, Marshall of the RAF Sir John Grandy, Chief Minister,
Sir Joshua Hassan
Suffrage: all adult Gibraltarians, plus other U.K. subjects
resident 6 months or more
Elections: every 5 years; last held in September 1976
Political parties and leaders: Labor, Sir Joshua Hassan;
Democratic Movement, Joe Boscano
Voting strengths: (September 1976) Labor, 8 seats;
Democratic Movement, 4 seats; independents, 3 seats
Communists: negligible
Other political or pressure groups: the Housewives
Association; the Chamber of Commerce; Gibraltar Repre-
sentatives Organization
Legal name: Gilbert Islands
Type: British crown colony with large measure of
self-government
Capital: Tarawa
Branches: 36-member House of Assembly elects a Chief
Minister
Government leader: Governor John H. Smith; Chief
Minister, Ieremia Tabia
Political parties and leaders: Gilbertese National Party,
Christian Democratic Party
Member of: ADB','795120f92cac645dbd399cd09108c218c94611fceca8bf95acba7634da981ef7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b12b9098faae0ba3ff7b7f5269f6781589619595a823b6346beb0689213ee80a',1978,'GR','Greece','government',216,'Legal name: Hellenic Republic
Type: presidential parliamentary government; monarchy
rejected by referendum December 8, 1974
Capital: Athens
Political subdivisions: 52 departments (nomoi) constitute
basic administrative units for country; each nomos headed
by officials appointed by central government and policy and
programs tend to be formulated by central ministries; degree
of flexibility each nomos may have in altering or avoiding
programs imposed by Athens depends upon _ tradition
(Thessaloniki and other areas exercise considerable tradi-
tional autonomy in local administrative decisions) and
influence which prominent local leaders and citizens may
exercise vis-a-vis key figures in central government
Legal system: new constitution enacted in June 1975
National holiday: Independence Day, 25 March
Branches: executive consisting of a President (to be
elected by Parliament) and a Prime Minister and cabinet;
legislative comprising the 300-member Parliament; inde-
pendent judiciary
Government leaders: President Constantine Tsatsos:
Prime Minister Constantine Caramanlis
Suffrage: universal age 21 and over
Elections: every 4 years; the government called for new
elections on 20 November 1977 and was returned to power,
albeit with a reduced majority
Political parties and leaders: Union of the Democratic
Center, George Mavros; New Democracy, Constantine
Caramanlis; Panhellenic Socialist Movement, Andreas
Papandreou; Communist Party—Exterior, Harilaos Florakis;
Communist Party—Interior, Haralambos Drakopoulos; and
the United Democratic Left, Ilias Iliou; Socialist Initiative,
George Mangakis; Socialist March; Christian Democracy;
Nationalist Camp, Stephanos Stephanopoulos
Voting strength: New Democracy, 172 seats; Union of the
Democratic Center, 15 seats; Panhellenic Socialist Move-
ment, 93 seats; Communists, 11 seats; Left Alliance, 2 seats;
National Camp, 5 seats; New Liberals, 2 seats
Communists: an estimated 25,000-30,000 members and
sympathizers
Member of: EC (associate), EIB (associate), EMA, GATT,
FAO, IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO, IMCO,
IMF, IOOC, ITU, [WC—International Wheat Council,
NATO, OECD, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG','e0b94f905e77345f56dd238d8ae91f0efd823629b5eb989d0e4eae4cad4b9d38','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04668f02beca19c407ae41ea0ad71ffb2c0cf7559cfdd13434c4fa55a27f81af',1978,'GL','Greenland','government',220,'Legal name: Greenland
Type: province of Kingdom of Denmark; 2 representatives
in Danish parliament; separate Minister for Greenland in the
Danish cabinet
Capital: Godthaab (administrative center)
Political subdivisions: 3 counties, 19 communes
79
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GREENLAND/GRENADA
Legal system: Danish law; transformed from colony to
province in 1953; due for home rule in spring 1979
Branches: legislative authority rests jointly with Crown
and Danish parliament; executive power vested in Crown,
acting through provincial governor responsible to Minister
for Greenland; local affairs handled by provincial council
(Landsrad) subject to approval of provincial governor; 19
lower courts
Government leader: Queen Margrethe II, Governor Hans
Lassen
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years (next 1981—coincides with
Danish elections)
Political parties: Inuit (advocating close ties with
Denmark); Sukaq (moderate socialist, advocating more
distinct Greenland identity); Siumut (a more radical party
advocating greater autonomy from Denmark)','2df7c2e38b8e7bc2d45feac2f139f342ba358e7b2a22be46f53b6bb9921232a0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad7e90131d97df7a04dbff0e2dd6abba8d79f01eb597a7ff038aa927c1815ba4',1978,'GD','Grenada','government',224,'Legal name: Grenada
Type: independent state since February 1974, recognizes
Elizabeth IT as Chief of State
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
National holiday: Independence Day, 7 February
Branches: legislative branch consists of 15-member
elected House of Representatives and 13-member Senate
appointed by the Governor; executive branch is cabinet led
by Prime Minister
Government leaders: Prime Minister Sir Eric Matthew
Gairy; U.K. Governor General Sir Leo V. deGale
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
GRENADA/GUADELOUPE
Suffrage: universal adult suffrage
Elections: every 5 years; most recent general election 7
December 1976
Political parties and leaders: Grenada United Labor
Party (GULP), Eric Matthew Gairy; Peoples Alliance—a
coalition consisting of the New Jewel Movement (NJM),
Maurice Bishop; United People’s Party (UPP), Winston
Whyte; Grenada National Party (GNP), Herbert A. Blaize
Voting strength (1976 election): GULP 51.7%, Peoples
Alliance, 48.3%; Legislative Council seats, GULP 9, Peoples
Alliance 6 (NJM 3, UPP 1, GNP 1, unaffilated 1)
Communists: negligible
Member of: CARICOM, G-77, IMF, OAS, SELA, U.N.','c8267146679da36857c1879dc0c91833611fe21befdf2d3a754b4f8f062ca1e5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87355a33ef39f701adcadcf59b34453acea1f0934e6a11dc3994e47fb7d4a35d',1978,'GP','Guadeloupe','government',228,'Legal name: Department of Guadeloupe
Type: overseas department and region of France;
represented by 3 deputies in the French National Assembly
and 2 Senators in the Senate; last deputy election, 12 March
1978
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34 communes,
each with a locally elected municipal council
Legal system: French legal system; highest court is a court
of appeal based in Martinique with jurisdiction over
Guadeloupe, French Guiana, and Martinique
Branches; executive, Prefect appointed by Paris; legisla-
tive, popularly elected General Council of 36 members and
a Regional Council composed of members of the local
General Council and the locally elected deputies and
senators to the French parliament; judicial, under jurisdic-
tion of French judicial system
Government leader: Prefect Paul Noirot Cosson
Suffrage: universal over age 18
Elections: General Council elections are held normally
every 5 years; last General Council election took place in
March 1976; local election last held March 1977
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
GUADELOUPE/GUATEMALA
Political parties and leaders: Rassemblement Pour la
Republique (RPR), Gabriel Lisette; Communist Party of
Cuadeloupe (PCG), Henri Bangou; Socialist Party (MSG),
leader unknown; Progressive Party of Guadeloupe (PPG),
Henri Rodes; Independent Republicans; Federation of the
Left
Voting strength: MSG, 1 seat in French National
Assembly; UDG, 2 seats; (1973 election)
Communists: 3,000 est.
Other political or pressure groups: Group of National
Organization of Guadeloupe (GONG)','9ce26810440c6e28dfe52b1df966f79619d48c9c26ae45122a5a08a5263aa668','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e8befb92867df02bca06c3cf721a813000ea5ff5f9de603c4814ccbc3bae562',1978,'GW','Guinea-Bissau','government',233,'Legal name: Republic of Guinea-Bissau
Type: republic; achieved independence from Portugal in
September 1974; constitution promulgated 1974
Capital: Bissau
Political subdivisions: 9 municipalities, 3 circumscrip-
tions (predominantly indigenous population)
Legal system: to be determined
National holiday: 12 September
Branches: National Popular Assembly to be elected for
three-year term; Council of State Commissars, 16 members;
the official party is the supreme political institution.
Government leaders: President of Council of State and
Chief of State is Luis Cabral; Principal Commissioner (Head
of Government), Francisco Mendes; Secretary General of the
Official party, Aristides Pereira
Suffrage: universal over age 18
Elections: none held to date
Political parties and leaders: Partido Africano da
Independencia da Guinee e Cabo Verde (PAIGC), led by
Aristide Pereira, only legal party; Front de Lutte pour
''Independence Nationale de la Guinea (FLING), a largely
dormant, loose coalition of nationalist elements opposed the
PAIGC, leadership fragmented
Communists: none known
Member of: G-77, NAM, OAU, U.N., UPU','082218a5423b893e033adb44ce8fd224a5e10375635ffa52720d2154c58c2e21','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ded453cc272a307557202273fc9ae7f84b0f7ac8947107131b42ac3f19dee93',1978,'HT','Haiti','government',238,'Legal name: Republic of Haiti
Type: republic under the 14-year dictatorship of Francois
Duvalier who was succeeded upon his death on 21 April
1971 by his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite constitu-
tional provision for 9)
Legal system: based on Roman civil law system;
constitution adopted 1964 and amended 1971; legal educa-
tion at State University in Fort-au-Prince and private law
colleges in Cap-Haitien, .Les Cayes, Gonaives, and Jeremie;
accepts compulsory IC] jurisdiction
National holiday: Independence Day, 1 January
Branches: lifetime President, unicameral 58-member
legislature of very limited powers, judiciary appointed by
President
Government _ leader: President-for-life Jean-Claude
Duvalier
Suffrage: universal over age 18
Elections: constitution as amended in 1971 provides for
lifetime president to be designated by his predecessor and
ratified by electorate in plebiscite; legislative elections,
which are held every 6 years, last held February 1973
Political parties: National Unity Party, only legal party;
United Haitian Communist Party (PUCH), illegal (Com-
munist)
Voting strength (1973 legislative elections): 100% Na-
tional Unity Party (Duvalier)
Communists: strength unknown; party leaders believed in
exile ;
Other political or pressure groups: none
Member of: FAO, G-77, GATT, IADB, IAEA, IBA,
IBRD, ICAO, IDA, IDB, IFC, ILO, IMCO, IMF, ITU, OAS,
SELA, U.N., UNESCO, UPU, WHO, WMO','89eedec2b1d1db2ec8e67bd89302e5b3ae14fd5b47f1e9638934134d7a9f37d5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('168403f1cff00dea7b38d960f617fe0d8f3b44ff9de33e23a616a7c6e3dbeb7b',1978,'HN','Honduras','government',242,'Legal name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: based on Roman and Spanish civil law;
some influence of English common law; constitution adopted
1965; judicial review of legislative acts in Supreme Court:
legal education at University of Honduras in Tegucigalpa;
accepts compulsory IC] jurisdiction, with reservations
National holiday: Independence Day, 15 September
Branches: constitution provides for elected President,
unicameral legislature, and national judicial branch
Government leader: Brig. Gen. Juan Alberto Melgar
Castro
Suffrage: universal and compulsory over age 18
Elections: government leaders have indicated an inten-
tion to hold elections in 1979
Political parties and leaders: all parties, even legal ones,
are dormant at present; Liberal Party (PLH), Modesto Rodas
Alvarado, Carlos Roberto Reina Idiaguez, Jorge Bueso Arias;
National Party (PNH), Alejandro Lopez Cantarero, Ricardo
Zuniga Augustinus; Mario Rivera Lopez, Martin Aquero;
Popular Progressive Party (PPP) (uninscribed), Gonzalo
Carias Castillo; National Innovation and Unity Party (PINU)
si Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
HONDURAS /HONG KONG
(uninscribed), Miguel Andonie Fernandez; Workers Party of
Honduras (PTH) (Communist) (uninscribed), Rogue Ochoa;
Communist Party of Honduras/Soviet (PCH /S-outlawed),
Dionisio Ramos Bejarano; Communist Party of Honduras/
China (PCH/C-outlawed), Agapito Robledo Castro
Voting strength (1971 elections): National Party (PNH)
306,028; Libera] Party (PLH) 276,777
Communists: about 650; 500 sympathizers
Other political or pressure groups: National Association
of Honduran Campesinos (ANACH); Council of Honduran
Private Enterprise (COHEP); Confederation of Honduran
Workers (CTH)
Member of: CACM, FAO, G-77, IADB, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMCO, IMF, ISO, ITU, OAS, U.N.,
UNESCO, UPEB, UPU, WHO, WMO','0059d20c7e8a3e3afc71f8c94e80b829ce9a25617111272039fcd79be35893db','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88a4ba4cc3c4b209a7b892e732f5cee5a09206d84dc3ff5c809713259e14ac97',1978,'PH','Philippines','government',246,'Legal name: Hong Kong
Type: U.K. crown colony
Capital: None
Political subdivisions: Hong Kong,
Territories
Kowloon, and New
Legal system: English common law
Branches: Governor assisted by advisory Executive
Council; he legislates with advice and consent of Legislative
Council; Urban Council which alone includes elected
representatives, responsible for health, recreation, and
resettlement; independent judiciary
Government leader: Sir C. M. MacLehose, Governor and
Commander in Chief
Suffrage: limited to 200,000 to 300,000 professional or
skilled persons
Elections: every 2 years to select one-half of elected
membership of Urban Council; other Urban Council
members appointed by the Governor
Political parties: Civic Association; Reform Club; Socialist
Democratic Party; Hong Kong Labour Party
Voting strength: (elected Urban Council members) Civic
Association 4, Reform Club 3, and 1 independent
Communists: an estimated 2,000 cadres affiliated with
Communist Party of China
Other political or
Unions (Communist
ers) Association of Hong Kong
Member of: ADB
Legal name: Republic of the Philippines
Type: republic
Capital: Manila
Political subdivisions: 72 provinces
Legal system: based on Spanish, Islamic, and Anglo-
American law; parliamentary constitution passed 1973;
judicial review of legislative acts in the Supreme Court; legal
education at University of the Philippines, Ateneo de Manila
University, and 71 other law schools; accepts compulsory [CJ
jurisdiction, with reservations; currently being ruled under
martial law
National holiday: Independence Day, 12 June
Branches: new constitution (currently suspended) pro-
vides for unicameral National Assembly, and a_ strong
executive branch under a Prime Minister; judicial branch
headed by Supreme Court with descending authority in a
Court of Appeals, courts of First Instance in various
provinces, municipal courts in chartered cities, and justices
of the peace in towns and municipalities; these justices have
considerably more authority than do justices of the peace in
the U.S.
Government leader: President Ferdinand E. Marcos
Suffrage: universal over age 18
Elections: elections held for an interim National Assem-
bly to meet in June
Political parties and leaders: political parties currently in
limbo because of martial law
Communists: about 1,600 armed insurgents
Member of: ADB, ASEAN, ASPAC, Colombo Plan,
ESCAP, FAO, G-77, IAEA, IBRD, ICAO, IDA, IFC, THO,
ILO, IMCO, IMF, IPU, ISO, ITU, U.N., UNESCO, UPU,
WHO','95127016a6b12e4f085c5ceddd639fe88871fef45f5cc611e3c179329fc529c9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cda2e2d18c79f75376b969374b18a7c8e6fd2c340cd3d00637cc5fd60175e685',1978,'HU','Hungary','government',251,'Legal name: Hungarian People’s Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 megyes (counties), 5 autono-
mous cities in county status, 97 jaras (districts)
Legal system: based on Communist legal theory, with
both civil law system (civil code of 1960) and common law
elements; constitution adopted 1949 amended 1972; Su-
preme Court renders decisions of principle that sometimes
have the effect of declaring legislative acts unconstitutional;
legal education at Lorand Eotvos Tudomanyegyetem School
of Law in Budapest and 2 other schools of law; has not
accepted compulsory ICJ jurisdiction
National holiday: Anniversary of the Liberation, 4 April
Branches: executive—Presidential Council (elected by
Parliament); legislative—Parliament (elected by direct suf-
frage); judicial—Supreme Court (elected by Parliament)
Government leaders: Pal Losonczi, President, Presiden-
tial Council; Gyorgy Lazar, Chairman, Council of Ministers
Suffrage: universal over age 18
Elections: every 5 years; national and local elections are
held separately
Political parties and leaders; Hungarian Socialist (Com-
munist) Workers Party (sole party); Janos Kadar is First
Secretary of Central Committee
Voting strength (1975 election): 7,497,061 (99.6 %) for
Communist-approved candidates; 30,108 (0.4%) invalid and
negative votes; total eligible electorate about 7.76 million;
next elections will be held in 1980
Communists: about 754,000 party members (March 1975)
Member of: CEMA, Danube Commission, FAO, GATT,
IAEA, ICAC, ICAO, ILO, International Lead and Zinc
Study Group, IMCO, IPU, ISO, ITC, ITU, U.N., UNESCO,
UPU, Warsaw Pact, WHO, WIPO, WMO','f37fe3fafbe14cc842c1aaf97fcc41d2f43704dfd42532465c06d96f67f07c9e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c21ac99b7323c20ae736d3070a746c9cebdae1f46ffe7696812ac43cb07b3006',1978,'IS','Iceland','government',256,'Legal name: Republic of Iceland
Type: republic
Capital: Reykiavik
Political subdivisions: 23 rural districts, 215 parishes, 14
incorporated towns
Legal system: civil law system based on Danish law;
constitution adopted 1944; legal education at University of
Iceland; does not accept compulsory ICJ jurisdiction
National holiday: Anniversary of the Establishment of
the Republic, 17 June
Branches: legislative authority rests jointly with President
and parliament (Althing),; executive power vested in
President but exercised by cabinet responsible to parliament;
Supreme Court and 29 lower courts
Government leaders: President Kristian Eldiarn; Prime
Minister Geir Hallgrimsson
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary to take place 25 June 1978,
every 4 years; presidential, every 4 years
Political parties and leaders: Independence (conserva-
tive), Geir Hallgrimsson; Progressive, Olafur Johannesson;
Social Democratic, Benedikt Grondal; People’s Alliance
(Communist front), Ragnar Arnalds; Organization of Liber-
als and Leftists, Magnus Torfi Olafsson
Voting strength (1974 election): 42.7% Independence,
24.9% Progressive, 9.1% Social Democratic, 18.3% People’s
Alliance, organization of leftists and liberals 4.6%
Communists: est. 2,200; a number of sympathizers, as
indicated by 20,922 votes cast for People’s Alliance in 1974
election
Member of: Council of Europe, EC (free trade agreement
pending resolution of fishing limits issue), EFTA, FAO,
GATT, IAEA, IBRD, ICAO, ICES, IDA, IFC, THO, ILO,
IMCO, IMF, IPU, ITU, [WC—International Whaling
Commission, NATO, Nordic Council, OECD, U.N.,
UNESCO, UPU, WHO, WMO, WSG','5169d76d2448851aaf6542de6ca142c347032b52767235be0b3eacd6fd3f55c6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdadf0c7383ba6e38b333859405c521ea45b2d0e5d148d56253d33585128fbfe',1978,'IN','India','government',260,'Legal name: Republic of India
Type: federal republic
Capital: New Delhi
Political subdivisions: 22 states, 9 union territories
Legal system: based on English common law; constitution
adopted 1950; limited judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Anniversary of the Proclamation of the
Republic, 26 January
Branches: parliamentary government, national and state;
relatively independent judiciary
Government leader: Prime Minister Morarii Desai
Suffrage: universal over age 21
93
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
INDIA/INDONESIA
Elections: national and state elections ordinarily held
every 5 years; may be postponed in emergency and may be
held more frequently if government loses confidence vote;
next general election due by March 1982; next state elections
staggered in 1982 and 1983
Political parties and leaders: Indian National Congress,
controlled national government from independence to
March 1977, and split in January 1978; larger Congress
group is headed by former Prime Minister Indira Gandhi;
the smaller “official” Congress Party is headed by Swaran
Singh as provisional president; Janata Party (a merger of 5
pre-1977 election parties) led by Prime Minister Desai and
party president, Chandra Shekar; Communist Party of India
(CPI), C. Rajeswara Rao, general secretary; Communist
Party of India/Marxist (CPI/M), E. M. S. Namboodiripad,
general secretary; Communist Party of India/MarxistLenin-
ist (CPI/ML), Satyanarayan Singhh, general secretary; All-
India-Anna Dravida Munnetra Kazhagam (ADMK), a
regional party in Tamil Nadu led by M. G. Ramachandran;
Akali Dal representing Sikh religious community in the
Punjab
Voting strength (1977 election): 43.17% Janata and CFD,
34.54% Congress, 4.30% CPI/M, 2.82% CPI, 15.17% regional
parties and others
Communists: 90,000 members of CPI (est.), 85,000
members of CPI/M (est.); Communist sympathizers, 13
million
Other political or pressure groups: various separatist
groups seeking reorganization of states; numerous “‘senas” or
militant/chauvinistic organizations, including Shiv Sena and
Dalit Panthers in Bombay, the Anand Marg, and the
Rashtriya Swayamserak Sangh
Member of: ADB, AIOEC, Colombo Plan, Common-
wealth, FAO, G-77 GATT, IAEA, IBRD, ICAC, ICAO, IDA,
IFC, THO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, ITC, ITU, IWC—International Wheat
Council, NAM, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG','70bf9bdc5b9493c046281c311296c2f4bd0c0483814b25d0fc5de6e7d29bde37','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f04991f776f6f704c4dd5efa774a1efe80f1195fb122b440d99c487ff6c010e6',1978,'ID','Indonesia','government',265,'Legal name: Republic of Indonesia
Type: republic
Capital: Jakarta
Political subdivisions: 27 first-level administrative subdi-
visions or provinces which are further subdivided into 282
second-level areas
Legal system: based on Roman-Dutch law, substantially
modified by indigenous concepts; constitution of 1945 is
legal basis of government; legal education at University of
Indonesia, Jakarta; has not accepted compulsory IC]
jurisdiction
National holiday: Independence Day, 17 August
Branches: executive headed by President who is chief of
state and head of cabinet; cabinet selected by President;
unicameral legislature (Parliament), of 460 members (100
appointed, 360 elected); second and larger body (Congress)
of 920 members and includes the legislature and 460 other
members (chosen by several processes, but not directly
elected) elects President and Vice President, and theoreti-
cally determines national policy
Government leader: President Suharto (reelected by
Congress, March 1978)
Suffrage: universal over age 17 and married persons
regardless of age
Political parties and leaders: Golkar (quasi-official
“party” based on functional groups), Amir Moertono;
Indonesian Democratic Party (federation of former Nation-
alist and Christian parties), Mohammed Isnaeni; Unity
Development Party (federation of former Islamic parties),
Idham Chalid
Voting strength (1977 election): Golkar 232 seats,
Indonesian Democratic 29, Unity Development 99
Communists: Communist Party (PKI) was officially
banned in March 1966; current strength est. at 1,000, with
less than 10% engaged in organized activity; pre-October
1965 hard-core membership has been estimated at 1.5
million
Member of: ADB, ANRPC, ASEAN, CIPEC, ESCAP,
FAO, G-77, IAEA, IBA, IBRD, ICAO, IDA, IFC, IHO, ILO,
IMCO, IMF, IPU, ISO, ITC, ITU, NAM, OPEC, U.N.,
UNESCO, UPU, WHO, WMO','2247069478d4bb5908a086651ce95ba7ff3d02eb39b947e041d15949ea31cb13','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80eb9214dad3fed3a4140b7c59429d1a4a635467f6372147f88881761f2c78e9',1978,'IQ','Iraq','government',269,'Legal name: Republic of Traq
Type: republic; National Front Government consisting of
Ba’th Party (BPI), Iraq Communist Party (CPI), and pro-
administration Kurds formed in July 1973; Communists play
nominal role in government)
Capital; Baghdad
Political subdivisions:
appointed officials
Legal system: based on Islamic law in special religious
courts, civil law system elsewhere; provisional constitution
adopted in 1968; judicial review was suspended; legal
education at University of Baghdad; has not accepted
compulsory IC] jurisdiction
National holiday: 14 July
Branches: Ba’th Party of Iraq has been in power since
1968 coup
Government leaders: President Ahmad Hasan al-Bakr;
Deputy Chairman of the Revolutionary Command Council
Saddam Husayn ‘Abd-al-Majid al-Tikriti
Suffrage: no elective bodies exist
Elections: no national elections since overthrow of
monarchy in 1958
Communists: Communist Party allowed token representa-
tion in cabinet; est. 2,000 ‘hard-core members
Political or pressure groups: political parties banned,
possibly some opposition to regime from disaffected
members of the regime and army officers
Member of: Arab Teague, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, NAM, OAPEC, OPEC,
U.N., UNESCO, UPU, WFTU, WHO, WIPO, WMO, WSG','6301c8e65da161ed41cd3e33fe30683e6d8781430296388b2b65513a46f51728','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ee0a3e3bda6586819a45de7f5953e1c2ac8e2c1b6837037e336b9691a0c3ced',1978,'IE','Ireland','government',273,'Legal name: Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law, substan-
tially modified by indigenous concepts; constitution adopted
1937; judicial review of legislative acts in Supreme Court;
has not accepted compulsory ICJ jurisdiction
National holiday: St. Patrick’s Day, 17 March
Branches: elected President; bicameral parliament re-
flecting proportional and vocational representation; judici-
ary appointed by President on advice of government
Government leaders: President Patrick Hillery; Prime
Minister (Taoiseach) John (Jack) Lynch; Deputy Prime
Minister (Tanaiste) George Colley
Suffrage: universal over age 18
Elections: Dail (lower house) elected every 5 years—last
election June 1977; President elected for 7-year term—last
election November 1976
Political parties and leaders: Fianna Fail, John (Jack)
Lynch; Labor Party, Frank Cluskey; Fine Gael, Garret
Fitzgerald; Communist Party of Ireland, Michael O’Riordan
Voting strength: (1977 election) Fianna Fail (84 seats),
Fine Gael (43 seats), Labor Party (17 seats), Independents
hold 4 seats
Communists: approximately 600
Approved For Release 2005/04/22 :
Member of: Council of Europe, EC, EEC, ESRO
(observer), EURATOM, FAO, GATT, IBRD, ICAO, ICES,
IDA, TEA, IFC, ILO, IMCO, IMF, IPU, ISO, ITC, ITU,
IWC—International Wheat Council, OECD, U.N,,
UNESCO, UPU, WHO, WIPO, WMO, WSG','bd99f67e13aa343ea2ebb6eaf44749b151cd5397ad1ee6918214434532199324','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8af50d39f503b492460055400a62e015409b08ebc05d050ac86d6e334181347',1978,'IL','Israel','government',277,'Legal name: State of Israel
Type: republic
Capital: Jerusalem; not recognized by US. which
maintains Embassy in Tel Aviv
Political subdivisions: 6 administrative districts
Legal system: mixture of English common law and, in
personal area, Jewish, Christian and Muslim legal systems;
commercial matters regulated substantially by codes
adopted since 1948; no formal constitution; some of the
functions of a constitution are filled by the Declaration of
Establishment (1948), the basic laws of the Knesset
(legislature) relating to the Knesset, Israeli lands, the
president, the government and the Israel citizenship law; no
judicial review of legislative acts; legal education at Hebrew
University in Jerusalem; accepts compulsory ICJ jurisdiction,
with reservations
National holiday: Independence Day, 11 May
Branches: President Ephraim Katzir-has largely ceremo-
nial functions; executive power vested in cabinet; unicam-
eral parliament (Knesset) of 120 members elected under a
system of proportional representation; legislation provides
fundamental laws in absence of a written constitution; 2
distinct court systems (secular and_ religious)
Government leader: Prime Minister Menachem Begin
Suffrage: universal over age 18
Elections: held every 4 years unless required by
dissolution of Knesset; last election held in May 1977
Principal political parties and leaders: Herut, Prime
Minister Menachem Begin, Defense Minister Ezer Weizman,
Liberal Party, Finance Minister Simcha Ehrlich; La’am,
Yigal Hurvitz; (Likud is a coalition formed of Herut,
Liberals and La’am); National Religious Party, Joseph Burg,
Zevulun Hammer; Democratic Movement for Change, Yi-
gael Yadin, Shmuel Tamir, Meir Amit; Israel Labor Party,
Shimon Peres, Yitzhak Rabin, Yigal Allon, SHELLI, Arieh
Eliav
100 Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
ie lA Tz é ATC C CT CSCS
July 1978
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
ISRAEL/ITALY
Voting strength: Likud 45 seats; National Religious Party
12 seats; Orthodox Augudat parties 5 seats; Samuel Flatto-
Sharon | seat; Moshe Dayan | seat; Labor Party-MAPAM-
Arab List Alignment 32, seats; Democratic Movement for
Change 15 seats, Independent Liberal Party 1 seat; Citizens
Rights Movement 1 seat; RAKAH 5 seats; SHELLI 2 seats
Communists: RAKAH (predominantly Arab but with
Jews in its leadership) has some 1,500 members; the Jewish
Communist Party, MAKI, is now part of Moked, which is a
far-left Zionist party
Other political or pressure groups: right-wing Jewish
Defense League led by Rabbi Meir Kahane; Black Panthers,
a loosely organized youth group seeking more benefits for
oriental Jews; Gush Emunim, Jewish religious zealots
pushing for freedom for Jews to settle anywhere on the West
Bank
Member of: FAO, GATT, IAEA, IBRD, ICAC, ICAO,
IDA, IFC, ILO, IMCO, IMF, IOOC, IPU, ITU, IwCc—
International Wheat Council, OAS (observer), UN.,
UNESCO, UPU, WHO, WIPO, WMO, WSG','bc5863d42dec436cab2f0f720f589e341db7e179843b1d33daa70cab9dff46ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9407cdc10b32fef83309a289fa5e29b4adc33b734105e2f00141d0250ee38d57',1978,'IT','Italy','government',281,'Legal name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides for establish-
ment of 20 regions; 5 (Sicilia, Sardegna, Trentino-Alto Adige,
Friuli-Venezia Giulia, and Valle d’Aosta) have been
functioning for some time and the remaining 15 regions
were instituted on | April 1972; 94 provinces
Legal system: based on civil law system, with ecclesiasti-
cal law influence; constitution came into effect 1 January
1948; judicial review under certain conditions in Constitu-
tional Court; has not accepted compulsory ICJ jurisdiction
National holiday: Anniversary of the Republic, 2 June
Branches: executive—President empowered to dissolve
Parliament and call national election; he is also Commander
of the Armed Forces and presides over the Supreme Defense
Council; otherwise, authority to govern invested in Council
of Ministers; legislative power invested in bicameral,
popularly elected Parliament; Italy has an independent
judicial establishment
Government leaders; President Giovanni Leone; Premier
Giulio Andreotti
Suffrage: universal over age 18 (except in Senatorial
elections where minimum age of voter is 25)
Elections: national elections for Parliament held every 5
years (most recent, June 1976); provincial and municipal
elections held every 5 years with some out of phase; regional
elections every 5 years (held June 1975)
Political parties and leaders: Christian Democratic Party
(DC), Benigno Zaccagnini (secretary general): Communist
Party (PCI), Enrico Berlinguer (secretary general), Luigi
Longo (party president); Socialist Party (PSI), Bettino Craxi
(secretary general), Pietro Nenni (party president): Social
Democratic Party (PSDP, Pierluigi Romita (secretary
general); Liberal] Party (PLN), Valerio Zanone (party
secretary); Italian Social Movement (MSD, Giorgio Almir-
ante; Republican Party (PRI), Oddo Biasini (party secre-
tary); Ugo La Malfa (party president)
102
Approved For Release 2005/04/22
Voting strength (1976 election): 38.7% DC, 34.4% PCI,
9.6% PSI, 6.1% MSI, 3.4% PSDI, 3.1% PRI, 1.3% PLI, 3.4%
other
Communists: 1,814,740 members (February 1978)
Other political or pressure groups: the Vatican; three
major trade union confederations (CGIL—Communist
dominated, CISL—Christian Democratic, and UIL—Social
Democratic, Socialist, and Republican); Italian manufactur-
ers association (Confindustria); organized farm groups
Member of: ADB, ASSIMER, Council of Europe, DAC,
EC, ECOWAS, ECSC, EEC, EIB, ELDO, ESRO,
EURATOM, FAO, GATT, TAKA, IBRD, ICAC, ICAO, IDA,
TEA, IFC, THO, ILO, International Lead and Zinc Study
Group, IMCO, IMF, TOOC, IPU, ITU, NATO, OAS
(observer), OECD, ULN., UNESCO, UPU, WEU, WHO,
WMO, WSG','0400f15d63e1f6a1b11f88c53a6df0f4cc0c2a3fe7f08f6631fa75f9bf3b6045','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c67fb084fcdf0c0623c0b8ff0825690e3ccb904ac9b341b6e0d52541c07423b',1978,'JM','Jamaica','government',285,'Legal name: Jamaica
Type: independent state within Commonwealth since
August 1962, recognizing Elizabeth II as head of state
Capital: Kingston
Political subdivisions: 12 parishes and the Kingston-St.
Andrew corporate area
Legal system: based on English common law; has not
accepted compulsory IC] jurisdiction
National holiday: 7 August
Branches: cabinet headed by Prime Minister; 60-member
elected House of Representatives; 21-member Senate (13
nominated by the Prime Minister, 8 by opposition leader);
judiciary follows British tradition under a Chief Justice
Government leader: Prime Minister Michael Manley
Suffrage: universal, age 18 and over
Elections: at discretion of Governor-General upon advice
of Prime Minister but within 5 years; latest held 15
December 1976
Political parties and leaders: People’s National Party
(PNP), Michael Manley; Jamaica Labor Party (JLP),
Edward Seaga
Voting strength: (1976 general elections) 56.8% PNP,
43.2% JLP
Communists: a few hundred Marxist and Communist
sympathizers
Other political or pressure groups: New World Group
(Caribbean regionalists, nationalists, and leftist intellectual
fraternity); Rastafarians (Negro religious/racial cultists,
pan-Africanists); New Creation International Peacemakers
Tabernacle (leftist group); Workers Liberation League (a
Marxist coalition of students/labor)
Member of: CARICOM, FAO, G-77, GATT, IADB,
IAEA, IBA, IBRD, ICAO, IDB, IFC, ILO, IMF, ISO, ITU,
NAM, OAS, Pan American Health Organization, SELA,
U.N., UNESCO, UPU, WHO, WMO','0694cb46f6a0362337b797e5596de49b2accfbb42fcc4aba089fbb7a01ae8c00','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64bbefce658a396ba6edcd6be7740eb8bf7044100a91cb9a1aa069f906b5b61c',1978,'JP','Japan','government',289,'Legal name: Japan
Type: constitutional monarchy
Capital: Tokyo
Political subdivisions: 47 prefectures (Ryukyus became
47th prefecture on 15 May 1972)
Legal system: civil law system with English-American
influence; constitution promulgated in 1946; judicial review
of legislative acts in the Supreme Court; accepts compulsory
IC) jurisdiction, with reservations
National holiday: Birthday of the Emperor, 29 April
Branches: Emperor is merely symbol of state; executive
power is vested in cabinet dominated by the Prime Minister,
chosen by the Lower House of the bicameral, elective
legislature (Diet); judiciary is independent
adjective—
Government leader: Prime Minister Takeo Fukuda
Suffrage: universal over age 20
Elections: general elections held every 4 years or upon
dissolution of Lower House, triennially for one-half of
Upper House
Political parties and leaders: Liberal Democratic Party
(LDP), T. Fukuda, President; Japan Socialist Party (JSP),
I. Asukata, Chairman; Democratic Socialist Party (DSP),
R. Sasaki, Chairman; Japan Communist Party (JCP), K.
Miyamoto, Presidium Chairman; Komeito (CGP), Y.
Takeiri, Chairman; New Liberal Club (NLC), Y. Kono;
United Social Democratic Party (USD)
Voting strength (1977 electien): 37.6% LDP, 21.6% JSP,
10.2% CGP, 9.6% JCP, 5.6% DSP, 4.8% NLC, minor parties,
6.1% independents
Communists: 350,000; 3,000,000 sympathizers
Member of: ADB, ASPAC, Colombo Plan, DAC, ESCAP,
FAO, GATT, IAEA, IBRD, ICAC, ICAO, IDA, IFA, IFC,
THO, ILO, International Lead and Zine Study Group,
IMCO, IMF, IPU, IRC, ISO, ITC, ITU, IWC—International
Whaling Commission, [''WC—International Wheat Council,
OECD, U.N., UNESCO, UPU, WHO, WIPO, WMO, WSG','79d82a12bc690018ac6ac8e6f78ee05be524292adc2765dfb0d50e90a6d26a76','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b3ed18169d5293899b2592adbbf7340500afa8281b0addb081b8324302251e1',1978,'JO','Jordan','government',293,'Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: ‘Amman
Political subdivisions: 8 governorates (3 are under Israeli
occupation) under centrally appointed officials
Legal system: based on Islamic law and French codes;
constitution adopted 1952; judicial review of legislative acts
in a specially provided High Tribunal; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 25 May
Branches: King holds balance of power; Prime Minister
exercises executive authority in name of King; Cabinet
appointed by King and responsible to parliament; bicameral
parliament with House of Representatives last chosen by
national elections in April 1967, and dissolved by King in
February 1976; Senate last appointed by King in November
107
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
JORDAN/KENYA
1974; met briefly in February 1976 to amend constitution
allowing King to postpone elections; present parliament
subservient to executive; secular court system based on
differing legal systems of the former Transjordan and
Palestine; law Western in concept and structure; Sharia
(religious) courts for Muslims, and religious community
council courts for non-Muslim communities; desert police
carry out quasi-judicial functions in desert areas
Government leader: King Husayn ibn Talal al-Hashimi
Suffrage: all citizens over age 20
Political parties and leaders: political party activity
illegal since 1957; Palestine Liberation Organization and
various smaller fedayeen groups clandestinely active on
West Bank; Muslim Brotherhood
Communists: party actively repressed, membership esti-
mated at less than 500
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, NAM, U.N,,
UNESCO, UPU, WHO, WIPO, WMO','1a49d7520b347037ceec4b29979091d3ce4c57c24f86a3a6e0bd93fd1eee30d6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98a0e398e30f9e3eb53cb5ca883dbffc9802c2e150f595fda38b4d14364abacc',1978,'KE','Kenya','government',297,'Legal name: Republic of Kenya
Type: republic within Commonwealth since December
1963.
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi Area
Legal system: based on English common law, tribal law
and Islamic law; constitution enacted 1963; judicial review
in Supreme Court, legal education at University Kenya
School of Law in Nairobi; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: 12 December
Branches: President and Cabinet responsible to unicam-
eral legislature (National Assembly) of 170 seats, 158 directly
elected by constituencies and 12 appointed by the President;
Assembly must be reelected at least every 5 years; High
Court, with Chief Justice and at least 11 justices, has
unlimited original jurisdiction to hear and determine any
civil or criminal proceeding; provision for systems of courts
of appeal
Government leader: President Jomo Kenyatta
Suffrage: universal over age 21
Elections: general election (October 1974) elected present
National Assembly; next elections due 1979
Political party and leaders: Kenya Africa National Union
(KANU), president, Jomo Kenyatta
Voting strength: KANU holds all seats in the National
Assembly
Communists: may be a few Communists and sym-
pathizers
Other political or pressure groups: labor unions
Member of: AFDB, FAO, G-77, GATT, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, ISO, ITU, 1WC-— International
Wheat Council, NAM, OAU, U.N., UNESCO, UPU, WHO,
WIPO, WMO
Legal name: Democratic People’s Republic of Korea
Type: Communist state; one-man rule
Capital: P’yongyang
Political subdivisions: 9 provinces, 2 special cities
(P’yongyang and Kaesong)
Legal system: based on German civil law system with
Japanese influences and Communist legal theory; constitu-
tion adopted 1948 and revised 1972; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
National holiday: 9 September
Branches: Supreme Peoples Assembly theoretically super-
vises Legislative and Judicial function; State Administration
Council (cabinet) oversees ministerial operations
Government and party leaders: Kim Il-song, President
DPRK, and General Secretary of the Korean Workers Party:
Yi Chong-ok, Premier
Suffrage: universal at age 17
Elections: election to SPA every 4 years, but this
constitutional provision not necessarily followed—last elec-
tion November 1977
Political party: Korean Workers (Communist) Party;
claimed membership of about 2 million, or about 11% of
population
Member of: IAEA, ICAO, IPU, IRCS, U.N. (observer
status only), UNCTAD, UNESCO, WHO WIPO
110
Legal name: State of St. Christopher-Nevis- Anguilla
Type: dependent territory with full internal autonomy as
a British “Associated State”; Anguilla formally seceded in
May 1967 but has not been recognized as an independent
state by any government; in July 1968 a legislative council
headed by Ronald Webster was elected to govern Anguilla;
in March 1969 the U.K. sent troops to Anguilla, placing the
island again under colonial rule; in 1971, Anguilla reverted
to its former colonial relationship with the U.K. although
nominally remaining part of the Associated state of St.
Christopher-Nevis-Anguilla; Webster became leader of
Anguillan Council after constitutionally held elections
(1972); in February 1976, the U.K. granted a new
constitution to Anguilla which changed its status to that of a
crown colony; in February 1977 Emile Gumbs replaced
Webster as Chief Minister
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law; constitution
of 1960; highest judicial organ is Court of Appeal of
Leeward and Windward Islands
Branches: _ legislative, 10-member popularly elected
House of Assembly; executive, cabinet headed by Premier
Covernment leaders: Acting Premier C. A. P. Southwell
for ailing Premier Robert Bradshaw; U.K. Governor, Probyn
Inniss
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent December
1975
Political parties and leaders: St. Chirstopher-Nevis- An-
guilla Labor Party, Robert L. Bradshaw; People’s Action
Movement (PAM), William Herbert; Nevis Reformation
Party (NRP), Ivor Stevens
Voting strength (December 1975 election): St. Christo-
pher-Nevis- Anguilla Labor Party won 7 seats in the House of
Assembly, NRP won 2, and 1 seat remains open for Anguilla
which did not participate in the election
Communists: none known
Member of: CARICOM, ISO
Legal name: State of St. Lucia
Type: dependent territory with full internal autonomy as
a British “Associated State”
Capital: Castries
Political subdivisions: 16 parishes
Legal system: based on English common law; constitution
of 1960; highest judicial body is Court of Appeal of Leeward
and Windward Islands
Branches: legislative, 17-member popularly elected
House of Assembly; executive, cabinet headed by Premier
Government leaders: Premier John Compton; U.K.
Governor Sir Allen Lewis
Suffrage: universal adult suffrage
Elections: every 5 years; most recent May 1974
Political parties and leaders: United Worker’s Party
(UWP), John Compton; St. Lucia Labor Party (SLP), Allan
Louisy
Voting strength (1974 election): UWP (53%) won 10 of
the 17 elected seats in House of Assembly; SLP (45%) won 7
seats; independents (2%) no seats
Communists: negligible
Member of: CARICOM
KCONOMY
GDP: $60 million (1974 est.), $530 per capita; real growth
rate 1974, negligible
Agriculture: main crops—bananas, copra, sugar, cocoa,
spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 14,000 kW capacity (1977); 40 million
kWh produced (1977), 365 kWh per capita
Exports: $17 million (£.0.b., 1976); sugar, bananas, cocoa
Imports: $47 million (c.i.f., 1976); foodstuffs, machinery
and equipment, fertilizers, petroleum products
Major trade partners: 51% U.K., 9% Canada, 17% US.
(1970)
Monetary conversion rate: 2.70 Fast Caribbean dol-
lars=US$1 (July 1976)
Legal name: State of St. Vincent
Type: dependent territory with ful] internal autonomy as
a British “Associated State”
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ST. VINCENT/SAN MARINO
Capital: Kingstown
Legal system: based on English common law; constitution
of 1960; highest judicial body is Court of Appeal of Leeward
and Windward Islands
Government leaders: Premier R. Milton Cato; Governor
General (U.K.) Sir Rupert G. John
Suffrage: universal adult suffrage (18 years old and over)
Elections: every 5 years; most recent December 9, 1974
Political parties and leaders: People’s Political Party
(PPP), Ebenezer Joshua; St. Vincent Labor Party (LP), R.
Milton Cato; Democratic Freedom Movement, Parnell
Campbell and Kenneth John
Voting strength (1975 election): LP 10 seats, PPP 2 seats,
independent 1 seat in the Legislature
Communists: negligible; Marxist opposition group, Youlon
United Liberation Organization (Yulimo)
Member of: CARICOM','c0020cf0bc743019c9a5bee09c3ee053ef5e37c599b2fec97bdbbd5122e7d1e2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1eca415336d28f8417f67af42a26d32bdd5b881262f296f324a9e00280b6b64e',1978,'KW','Kuwait','government',301,'Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Kuwait
Political subdivisions: 3 governorates, 10 voting
constituencies
Legal system: civil law system with Islamic law
significant in personal matters; constitution took effect 1963;
key provisions regarding election of National Assembly
suspended in August 1976; judicial review of legislative acts
not yet determined; has not accepted compulsory ICJ
jurisdiction
National holiday: 25 February
Branches: Council of Ministers
Government leader: Amir Jabir al-Ahmad Al Sabah
Suffrage: native born and naturalized males age 2] or
over
Elections: National Assembly dissolved by Emir’s decree
in August 1976
Political parties and leaders: political parties prohibited,
some small clandestine groups are active
Communists: insignificant
Other political or pressure groups: none
Member of: Arab League, FAO, G-77, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
OAPEC, OPEC, U.N., UNESCO, UPU, WHO, WIPO,
WMO
Legal name: Lao People’s Democratic Republic
Type: Communist state
Capital: Vientiane
Political subdivisions: 13 provinces subdivided into
districts, cantons, and villages
Legal system: based on civil law system; has not accepted
compulsory ICJ jurisdiction
National holiday: 2 December
Branches: President; 45-member Supreme People’s Coun-
cil; cabinet; cabinet is totally Communist but council
contains a few nominal neutralists and non-Communists;
National Congress of People’s Representatives established
the current government structure in December 1975
Government leaders: President, Souphanouvong; Prime
Minister, Kaysone Phomvihan; Deputy Prime Ministers,
Nouhak Phoumsavan, Phoumi Vonevichit, Phoun Sipaseut,
and Khamtai Siphandone
Suffrage: universal over age 18
Elections: elections for new National Assembly, scheduled
for April 1, 1976, have been postponed
113
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
1. AOS/LEBANON
Political parties and leaders: Lao People’s Revolutionary
Party (Communist) includes Lao Patriotic Front and
Alliance Committee of Patriotic Neutralist Forces; other
parties are moribund
Communists: Lao People’s Revolutionary Party; member-
ship unknown
Other political or pressure groups: non-Communist
political groups are moribund; most leaders have fled the
country
Member of: ADB, Colombo Plan, ESCAP, FAO, G-77,
IBRD, ICAO, IDA, ILO, IMF, IPU, ITU, Mekong Commit-
tee, NAM, SEAMES, U.N., UNCTAD, UNESCO, UPU,
WHO, GWMO','856d8ec9f27fbfe7d26d419b8861efd7ed4357fa91967a7cfa83eb12bfa1398c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4510b33da39b87e7b310e8791a0310431d95a9e8deaa99c63a571bbd8305351',1978,'LB','Lebanon','government',305,'NOTE: Between early 1975 and late 1976, Lebanon was
torn by civil war between its Christians—then aided by
Syrian troops—and its Muslims and their Palestinian allies.
The cease-fire established in October 1976 has generally
held, despite occasional fighting, although the country is still
under the occupation of Arab peacekeeping forces, almost
entirely Syrian. In March 1978 southern Lebanon was
invaded by Israeli troops, who are slowly turning it over to a
United Nations interim force. The country’s own army is
gradually being re-established but is still too fragile to give
the central government effective power. Israel’s support of
the Christians and Syria’s recent support of the Palestinians
have brought the two sides into rough equilibrium, but no
progress has been made on national reconciliation or
political reforms—the original cause of the war. The
following description is based on the present constitutional
and customary practices of the Lebanese system.
Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law, and
civil law system; constitution mandated in 1920; no judicial
review of legislative acts; legal education at University of
Lebanon; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 22 November
Branches: power lies with President elected by parlia-
ment (Chamber of Deputies); cabinet appointed by Presi-
dent, approved by parliament; independent secular courts
on French pattern; religious courts for matters of marriage,
divorce, inheritance, etc.; by custom, President is a Maronite
Christian, Prime Minister a Sunni Muslim, and president of
parliament a Shia Muslim; each of 9 religious communities
represented in parliament in proportion to national numeri-
cal strength
Government leader: President Ilyas Sarkis
Suffrage: compulsory for all males over 21; authorized for
women over 21 with elementary education
Elections: Chamber of Deputies held every 4 years or
within 3 months of dissolution of Chamber; latest April 1972
Political parties and leaders: political party activity is
organized along sectarian lines; numerous political groupings
exist, consisting of individual political figures and followers
motivated by religious, clan, and economic considerations;
all parties have well-armed militias which are still involved
in occasional clashes
Communists: only legal Communist party in Middle East;
legalized in 1970; members and sympathizers estimated at
2,000-3,000
Other political or pressure groups: Palestinian guerrilla
organizations
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU, IwC—
International Wheat Council, NAM, U.N., UNESCO, UPU,
WHO, WMO, WSG','c2d650c4e2285ce7518c5b14c67cde8121887358a8a4130cbc525f623fece88c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acd479b30781cb63e5b268125b893a32d7c270140aa47e352eebce8f5e927c1a',1978,'LS','Lesotho','government',309,'Legal name: Kingdom of Lesotho
Type: constitutional monarchy under King Moshoeshoe II:
independent member of commonwealth since 1966
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and
Roman-Dutch law; constitution came into effect 1966;
judicial review of legislative acts in High Court and Court of
Appeal; legal education at National University of Lesotho;
has not accepted compulsory ICJ jurisdiction
National holiday: 4 October
Branches: executive, divided between a largely ceremo-
nial King and a Prime Minister who leads cabinet of at least
7 members; Prime Minister dismissed bicameral legislature
in early 1970 and subsequently ruled by decree until 1973
116
when he appointed Interim National Assembly to act as
legislative branch; judicial—63 Lesotho courts administer
customary law for Africans, High Court and subordinate
courts have criminal jurisdiction over all residents, Court of
Appeal at Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua
Jonathan
Suffrage: universal for adults
Elections: elections held in January 1970; nullified
allegedly because of election irregularities; subsequent
elections promised at unspecified date
Political parties and leaders: National Party (BNP),
Chief Leabua Jonathan; Basutoland Congress Party (BCP),
Ntsu Mokhehle
Voting strength: in 1965 elections for National Assembly,
BNP won 32 seats; BCP, 22 seats; minor parties, 4 seats
Communists: negligible, Communist Party of Lesotho
banned in early 1970
Member of: Commonwealth, FAO, G-77, GATT (de
facto), IBRD, IDA, IFC, IMF, ITU, NAM, OAU, ULN.,
UNESCO, UPU, WHO','0377f68ea3438bc731058c7df10901546e14638e9012f8642aa65d11ceb5b69b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6eb8a0ab0818f536dbea5ee0ad0b3678ecf6b08aa52e5a1a051120e7f8e1dd8',1978,'LR','Liberia','government',313,'Legal name: Republic of Liberia
Type: republic in form; strong executive dominates, with
few constraints
Capital: Monrovia
Political subdivisions: country divided into 9 counties;
President appoints all officials of significance
Legal system: based on U.S. constitutional theory; recent
codes drawn up by Cornell University; constitution adopted
1847; amended 1907, 1926, 1934, 1955, and 1975; no
constitutional provision for judicial review of legislative acts;
legal education at Louis Arthur Grimes School of Law,
University of Liberia; accepts compulsory [CJ jurisdiction,
with reservations
National holiday: Independence Day, 26 July
Branches: President, elected by popular vote, limited to a
single eight-year term, controls through appointive powers,
authority over national expenditures, and a variety of
informal sanctions; 2-house legislature elected by popular
vote; judiciary consisting of Supreme Court and variety of
lower courts
Government leader: President William R. Tolbert, Jr.
Suffrage: universal 18 years and over
Elections: members of House of Representatives elected
for 4-year terms, most recently in October 1975; Senate
members elected for 6-year terms, one-half elected in May
1973; President Tolbert, constitutional successor to President
Tubman who died in July 1971, completed the four year
term to which Tubman was elected and was then elected in
October 1975 for an eight-year term beginning in January
1976
Political parties and leaders: True Whig Party, in power
since 1878, only political party; President Tolbert is leader
Voting strength: 1975 elections uncontested; True Whig
Party won all but a handful of votes
Communists: no Communist Party and only a few
sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, G-77, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU, NAM,
OAU, U.N., UNESCO, UPU, WHO','afc58aa9afd92e38cba8131e4667690bee632272f7324342e4734f2002ef6292','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e33be9ef86600732fbd2b96096aab579b42e01d6926f842fb264ae6f29665768',1978,'LY','Libya','government',317,'Legal name: Socialist People’s Libyan Arab Jamahiriya
Type: republic; major overhaul of the constitution and
government structure in March 1977 established a system of
popular congresses which theoretically controls the ruling
General Secretariat; nominally confederated with Egypt and
Syria in Confederation of Arab Republics (CAR) on |!
September 1971
Capital: Tripoli
Political subdivisions: 10 administrative provinces closely
controlled by central government
Legal system: based on Italian civil law system and
Islamic law; separate religious courts; no constitutional
provision for judicial review of legislative acts; legal
education at Law School, at University of Libya at Benghazi;
has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 1 September
Branches: paramount political power and authority rests
with the Secretariat of the General People’s Congress which
theoretically functions as a parliament with a cabinet called
the General People’s Committee
Government leaders: Colonel Mu’ammar Qadhafi; Prime
Minister, Abdul Ati Ubaydi
Suffrage: universal
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
LIBYA/ LIECHTENSTEIN
Elections: resentatives to the General People’s Congress
are drawn from popularly elected municipal committees
(elections are more or less continuous) election for CAR
assembly in March 1972
Political parties and leaders: Libyan Arab Socialist
Union, Ahmad Shahati, Secretary General; Mu’ammar
Oadhafi, President
Communists: no organized party, negligible membership
Other political or pressure groups: various Arab nation-
alist movements and the Arab Socialist Resurrection (Bath)
party with small, almost negligible memberships may be
functioning clandestinely
Member of: AFDB, Arab League, FAO, G-77, JAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IOOC, ITU,
NAM, OAPEC, OAU, OPEC, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG','0475207efb1b28503e4a2a1aa9eba8fc8078be0a39e1b419b685fb61809fcc97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcb0cdcdf4562544aa15192e936380af25e5000f6435af49f264339a31a3da07',1978,'LI','Liechtenstein','government',321,'Legal name: Principality of Liechtenstein
Type: hereditary constitutional monarchy
Capital: Vaduz
119
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
LIECHTENSTEIN/ LUXEMBOURG
Political subdivisions: 1] districts
Legal system: based on Swiss law; constitution adopted
1921; judicial review of legislative acts in a special
Constitutional Court; accepts compulsory IC] jurisdiction,
with reservations
Branches: unicameral Parliament, hereditary Prince,
independent judiciary
Government leaders: Head of State, Prince Franz Joseph
fl; Chief of Government, Dr. Walter Kieber
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1978
Political parties and leaders: Fatherland Union Party
(VU), Dr. Alfred Hilbe; Progressive Citizens’ Party (FBP),
Dr. Gerard Batliner
Voting strength (1974 election): FBP over 50%
Communists: none
Member of: IAEA, ITU, UPU, considering U.N. member-
ship; desires affiliation with The Council of Europe; under a
1923 treaty, Switzerland handles Liechtenstein’s post and
telegraph systems, customs, and foreign relations, WIPO','7e26f5e9e12a7c0496bb5cc76e8603a27499a021e758b08e0c4bf7a216ade23f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1574a38c94c215cfe394420e39548dd3904e36180adf06dd219247e558246056',1978,'LU','Luxembourg','government',325,'Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for administra-
tive purposes has 3 districts (Luxembourg, Diekirch,
Grevenmacher) and 12 cantons
Legal system: based on civil law system; constitution
adopted 1868; judicial review of legislative acts in the
Cassation Court only; accepts compulsory IC] jurisdiction
National holiday: 23 June
Branches: parliamentary democracy; seven ministers
comprise Council of Government headed by President,
which constitutes the executive; it is responsible to the
unicameral legislature, the Chamber of Deputies; the
Council of State, appointed for indefinite term, exercises
some powers of an upper house; judicial power exercised by
independent courts
Government leaders: Grand Duke Jean, Head of State;
Gaston Thorn, Prime Minister
Suffrage: universal and compulsory over age 18
Elections: every 5 years for entire Chamber of Deputies;
latest elections May 1974
Political parties and leaders: Christian Social Party,
Pierre Werner (Parliamentary President) and Jacques Santer
(Party President); Socialist, Lydie Schmit (Party President);
Social Democrat, Henry Cravatte (Party President); Demo-
cratic, Gaston Thorn (Party President and Prime Minister);
Communist, Dominique Urbany
Voting strength in Chamber of Deputies (1974):
Christian Socialist, 18; Socialist Workers, 17; Democrats, 14;
Social Democrats, 5; Communists, 5
Communists: 500 party members (1974)
Other political or pressure groups: group of steel
industries representing iron and steel industry, Centrale
Paysanne representing agricultural producers; Christian and
Socialist labor unions, Federation of Industrialists; Artisans
and Shopkeepers Federation
Member of: Benelux, BLEU, Council of Europe, EC,
ECSG, EEC, EIB, EURATOM, FAO, GATT, IAEA, IBRD,
ICAO, IDA, TEA, IFC, ILO, IMF, IOOC, IPU, ITU, NATO,
OECD, U.N., UNESCO, UPU, WEU, WHO, WIPO, WMO','269038b34fe8db0b0dd5211613389c835dcb9ef5f83817b98b8d1abe5635c374','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff5914ec3fc366e37d1580f834e89e2953ca0c8b109e311960b0c47df785242a',1978,'MO','Macao','government',329,'Legal name: Province of Macao
Type: overseas province of Portugal
Capital: Lisbon (Portugal)
Political subdivisions: municipality of Macao, and 2
islands
Legal system: Portuguese civil law system
Branches: 17-member Legislative Assembly, with Gover-
nor and 5 appointed, 1 specially nominated, and 10 elected
representatives
Government leader: Col. Eduardo Garcia Leandro
Suffrage: Portuguese, Chinese and foreign residents over
18
Elections: conducted every 4 years; last held 1976
Political parties and leaders; Association to Defend the
Interests of Macao; Macao Democratic Center; Group to
Study the Development of Macao; Macao Independent
Group
Communists: numbers unknown
Other political or pressure groups: wealthy Macanese
and Chinese representing local interests, wealthy pro-Com-
munist merchants representing China’s interests; in January
1967 Macao Government acceded to Chinese demands
which gave Chinese veto power over administration of the
enclave
122','7a772b0aef4371447fe4a2751cc829958ea1b00ffc137466334ecaf95e792228','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bd84d788ef77c1dafdadcaa4f371eff0cca2150476ec6e934c31a0fe0932e77',1978,'MG','Madagascar','government',333,'Legal name: Democratic Republic of Madagascar
Type: republic; real authority in hands of military-
dominated Supreme Revolutionary Council
Capital: Antananarivo
Political subdivisions: 6 provinces
Legal system: based on French civil law system and
traditional Malagasy law; constitution of 1959 modified in
October 1972 by law establishing provisional government
institutions; new constitution accepted by referendum in
December 1975; legal education at National School of Law,
University of Madagascar; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 26 June
Branches: executive—a 21-member Supreme Revolution-
ary Council (made up of military and political leaders);
assisted by cabinet called Council of Ministers; People’s
Approved For Release 2005/04/22 :
National Assembly; Military Committee for Development;
regular courts are patterned after French system, and a High
Council of Institutions reviews all legislation to determine its
constitutional validity
Government leader: Commander Didier Ratsiraka,
President
Suffrage: universal for adults (18 and above)
Elections: referendum held in December 1975 gave
overwhelming approval to government and new constitu-
tion; elections for People’s National Assembly held in June
1977; only one political grouping allowed to take part in the
election, “The Front for the Defense of Malagasy Socialist
Revolution,” which presented a single list of candidates
Political parties and leaders: 6 parties are now allowed
political activity under the National Front and are
represented on the Supreme Revolutionary Council; the 6
parties are: AREMA (President Ratsiraka’s Advance Guard
of the Malagasy Revolution); AKFM (Pastor Richard
Andriamanjato’s pro-Soviet Congress Party for Malagasy
Independence); VONJY (Dr. Pazanabahiny Marojama’s
Movement for National Unity); UDECMA (Norbert Andria-
morasata’s Malagasy Christian Democratic Union); MFM
(Manandafy Rakotonirina’s Militants for the Establishment
of a Proletarian Regime); MONIMA (Mouvement Nationale
pour L’Independence de Madagascar) party apparently split
over issue of joining National Front, leader of faction
supporting Front unknown, Monja Jaona leads other faction
Voting strength: number of registered voters (1977)—3.5
million; in 1977 local elections, President Ratsiraka’s
AREMA captured approximately 89.5% of the 73,000
available positions on 11,400 local Executive Committees,
AKFM won about 7.3% of the seats, MONIMA 1.7%, and
VONJY 1.4%; UDECMA won only about 45 seats
Communists: Communist party of virtually no impor-
tance; small and vocal group of Communists has gained
strong position in leadership of AKFM, the rank and file of
which is non-Communist
Member of: EAMA, FAO, G-77, GATT, IAEA, IBRD,
IFC, ILO, IMF, ISO, ITU, NAM, OAU, OCAM, U.N.,
UNESCO, WHO, WMO
Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
Political subdivisions: 9 provinces
Legal system: based on English common law and
customary law; new constitution adopted September 1973;
judicial review of legislative acts in an ad hoc constitutional
council; legal education at University of Zambia in Lusaka;
has not accepted compulsory ICJ jurisdiction
National holiday: 24 October
Branches: modified presidential system; unicameral legis-
lative; judiciary
Government leaders: President Kenneth Kaunda; Prime
Minister Mainza Chona
Suffrage: universal adult
Elections: general election scheduled for 1978
Politica] parties and leaders: United National Independ-
ence Party (UNIP), Kenneth Kaunda; former opposition
party banned in December 1972 when 1 party state
proclaimed
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ZAMBIA/UNITED STATES
Voting strength (1973 election): in first presidential and
parliamentary elections under single-party system, 43% of
eligible voters went to polls; Kaunda was only candidate for
President; National Assembly seats were contested by
members of UNIP
Communists: no Communist Party, but sympathizers of
socialism in upper levels of government, UNIP, and labor
unions
Member of: AFDB, Commonwealth, FAO, G-77, GATT
(de facto), IAEA, IBRD, ICAO, IDA, IDB, IEA, IFC, ILO,
International Lead and Zinc Study Group, IMF, IPU, ITU,
NAM, OAU, U.N., UNESCO, UPU, WHO, WMO','83b345a0b5ee6c9b3afdb28ea2958c70b436a2d24411e2ac2d9a875d582f47e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bbc93b9634a4bc77b4b8ea2eb87c0fe2637d4e0efefa2e55894ac2de6e3b97a',1978,'MW','Malawi','government',337,'Legal name: Republic of Malawi
Type: republic since July 1966; independent member of
Commonwealth since July 1964
Capital: Lilongwe
Political subdivisions: 3 administrative regions and 23
districts
Legal system: based on English common law and
customary law; constitution adopted 1964; judicial review of
legislative acts in the Supreme Court of Appeal; has not
accepted compulsory ICJ jurisdiction
National holiday: Republic Day, 6 July
Branches: strong presidential system with cabinet ap-
pointed by President; unicameral National Assembly of 60
elected and 15 nominated members; High Court with Chief
Justice and at least 2 justices
Government leader: Life President H. Kamuzu Banda
Suffrage: universal adult
Elections: parliamentary elections scheduled to be held
before the end of 1978
Political parties and leaders: Malawi Congress Party
(MCP), Dr. H. Kamuzu Banda
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
MALAWI/MALAYSIA
Communists: no Communist Party; Malawi maintains no
foreign relations with Communist governments
Member of: AFDB, EEC (associate member), FAO, G-77,
GATT, IBRD, ICAO, IDA, IFC, ILO, IMF, IPU, ISO, ITU,
OAU, U.N., UNESCO, WHO, WIPO, WMO','5bbe2ad4c157324910d8258fc52273cdd21761163baebfb2b6ef19a71abc03fd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9b8c6561190fa3cc8a0bbb102bdfb6504b76388415897d333b56770df411bf7',1978,'MY','Malaysia','government',341,'Legal name: Malaysia
Type:
Malaysia: constitutional monarchy nominally headed
by Paramount Ruler (King); a bicameral Parliament
consisting of a 58-member Senate and a 154-member House
of Representatives
Peninsular Malaysian states: hereditary rulers in all
but Penang and Malacca where Governors appointed by
Malaysian Government; powers of state governments limited
by federal constitution
Sabah: self-governing state within Malaysia in which it
holds 16 seats in House of Representatives; foreign affairs,
defense, internal security, and other powers delegated to
federal government
Sarawak: self-governing state within Malaysia in which
it holds 24 seats in House of Representatives; foreign affairs,
defense, and internal security, and other powers are
delegated to federal government
126
Capital:
Peninsular Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu
Sarawak: Kuching
Political subdivisions: 13. states (including Sabah and
Sarawak)
Legal system: based on English common law; constitution
came into force 1963; judicial review of legislative acts in the
Supreme Court at request of Supreme Head of the
Kederation; has not accepted compulsory IC] jurisdiction
National holiday: 31 August
Branches: 9 state rulers alternate as Paramount Ruler for
5-year terms; locus of executive power vested in Prime
Minister and cabinet, who are responsible to bicameral
parliament; following communal rioting in May 1969,
government imposed state of emergency and suspended
constitutional rights of all] parliamentary bodies; parliamen-
tary democracy resumed in February 1971
Peninsular Malaysia: executive branches of 11 states
vary in detail but are similar in design; a Chief Minister,
appointed by hereditary ruler or Governor, heads an
executive council (cabinet) which is responsible to an
elected, unicameral legislature
Sarawak and Sabah: executive branch headed by
Governor appointed by central government, largely ceremo-
nial role; executive power exercised by Chief Minister who
heads parliamentary cabinet responsible to unicameral
legislature; judiciary part of Malaysian judicial system
Government leader: Head of State, Hussein Onn
Suffrage: universal over age 20
Elections: minimum of every 5 years, last elections
August 1974
Political parties and leaders:
Peninsular Malaysia: National Front, a confederation
of 11 political parties dominated by United Malays National
Organization (UMNO), Hussein Onn; opposition parties are
Democratic Action Party (DAP) and Islamic Party (PAS)
Sabah: Berjaya Party, Datak Harris Sallah; United
Sabah National Organization (USNO), Tan Sri Haji Mohd
Said Keruak; Sabah Chinese Association (SCA), Khoo Siak
Chiew
Sarawak: coalition Sarawak Alliance composed of the
Pesaka/Bumipatra Party, Rahman Yaacub, the United
People’s Party (SUPP), Ong Kee Hui, and Sarawak Chinese
Association; Sarawak National Party (SNAP), Stephen
Ningkan; Sarawak Native Peoples Party (PAJAR), Alli Kawi
Voting strength:
Peninsular Malaysia: (1974 election) National Front
controls 135 of 154 seats in lower house of parliament
Sabah: (April 1976 Assembly Elections) Berjaya Party
controls 35 of 54 seats in State Assembly, USNO controls 19
remaining seats
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Sarawak: (1974 elections) National Front controls all 48
State Assembly seats
Communists:
Peninsular Malaysia: approximately 3,000 armed
insurgents on Thailand side of Thai/Malaysia border;
approximately 300 full-time inside Peninsular Malaysia
Sarawak: 125 armed insurgents in Sarawak
Sabah: insignificant
Member of: ADB, ANRPC, ASEAN, Colombo Plan,
Commonwealth, FAO, G-77, GATT, IAEA, IBRD, ICAO,
IDA, IFC, ILO, IMCO, IMF, IPU, ITC, ITU, NAM, U.LN.,
UNESCO, UPU, WHO, WMO','bd7eead9e8d69fa967418fa906c394da83b8133f05c6719fbd4d2b9004b55b07','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f88b4e237daf21ea7ad7f89fc4246acfaff076b3f8872953867253a88f53443',1978,'MV','Maldives','government',347,'Legal name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative districts corre-
sponding to atolls
Legal system: based on Islamic law with admixtures of
English common law primarily in commercial matters; has
not accepted compulsory IC] jurisdiction
National holiday: 26 July
Branches: popularly elected unicameral national legisla-
ture (Majlis) (members elected for 5-year terms); elected
President, chief executive; appointed Chief Justice responsi-
ble for administration of Islamic law
Government leader: President [brahim Nasir
Suffrage: universal over age 2]
Political parties and leaders: no organized political
parties; country governed by the Didi clan for the past eight
centuries
Communists: negligible number
Member of: Colombo Plan, FAO, G-77 GATT (de facto),
IMCO, ITU, NAM, U.N., UPU, WHO','093920b9082eaac634f17481f266ffc205bff629d8bd77e746c5c1b517d4397b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c7ae618aa1bbdc2bf4618ae8a58e24de5b2cd421f63c0b731d7005b98cd9aff',1978,'ML','Mali','government',351,'Legal name: Republic of Mali
Type: republic; under military regime since November
1968
Capital: Bamako
Political subdivisions: 6 administrative regions; 42
administrative districts (cercles), arrondissements, villages;
all subordinate to central government
Legal system: based on French civil law system and
customary law; constitution adopted 1974, comes into full
effect in 1979; judicial review of legislative acts in
Constitutional Section of Court of State; has not accepted
compulsory ICJ jurisdiction
Approved For Release 2005/04/22 :
National holiday: Independence Day, 22 September
Branches: executive authority exercised by Military
Committee of National Liberation (MCNL) composed of 11
army officers; under MCNL functional cabinet composed of
civilians and army officers; judiciary
Government leaders: Col. Moussa Traore, President of
MCNL, Chief of State and head of government
Suffrage: universal over age 21
Political parties and leaders: political activity proscribed
by military government but government in process of
forming new single party called the Democratic Union of
Malian People (UDPM)
Elections: MCNL promises elections at unspecified date
Communists: a few Communists and some sympathizers
Member of: AFDB, APC, CEAO, ECA, ECOWAS, FAO,
G-77, GATT (de facto), IAEA, IBRD, ICAO, IDA, ILO,
IMF, ITU, Niger River Commission, NAM, OAU, OMVS
(Organization for the Development of the Senegal River
Valley), U.N.. UNESCO, UPU, WHO, WMO
Legal name: Republic of Malta
Type: parliamentary democracy, independent republic
within the Commonwealth since December 1974
Capital; Valletta
Political subdivisions: 2 main populated islands, Malta
and Gozo, divided into 18 electoral districts (divisions)
Legal system: based on English common law; constitution
adopted 1961, came into force 1964; has accepted compul-
sory ICJ jurisdiction, with reservations
Branches: executive, consisting of Prime Minister and
cabinet; legislative, comprising 65-member House of Repre-
sentatives; independent judiciary
National holiday: Republic Day, 13 December
Government leader: Prime Minister Dom Mintoff
Suffrage: universal over age 18; registration required
Elections: at the discretion of the Prime Minister, but
must be held before the expiration of a 5-year electoral
mandate; last election September 1976
Political parties and leaders: Nationalist Party, Edward
Fenech Adami; Malta Labor Party, Dom Mintoff
Voting strength (1976 election): Labor, 34 seats (51.54%);
Nationalist, 31 seats (48.43%)
Communists: less than 100 (est.)
Member of: Commonwealth, Council of Europe, FAO, G-
77, GATT, IBRD, ICAO, ILO, IMCO, IMF, ITU, NAM,
U.N., UNESCO, UPU, WHO','3eed5560042770c849d4b42a317cd470ede412f6f8c64d26caa0579fcfa197f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c198947d8c4fa188177299e632ee80c22279f0e8212154a13d9e2a66b205368',1978,'MQ','Martinique','government',355,'Legal name: Department of Martinique
Type: overseas department of France; represented by 3
deputies in the French National Assembly and 2 Senators in
the Senate; incumbent deputies Aime Cesaire, Camille Petit,
and Victor Sable reelected to National Assembly, 12 March
1978
Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34 communes,
each with a locally elected municipal council
Legal system: French legal system; highest court is a court
of appeal based in Martinique with jurisdiction over
Guadeloupe, French Guiana, and Martinique
Branches: executive, Prefect appointed by Paris, legisla-
tive, popularly elected council of 36 members and a
Regional Council including all members of the local general
council and the locally elected deputies and senators to the
French parliament; judicial, under jurisdiction of French
judicial system
Government leader: Prefect Herve Bourseilleur
Suffrage: universal over age 18
Flections: General Council elections normally are held
every five years; last General Council election took place in
March 1976; last local election held March 1977, last French
Presidential election May 1974
Political parties and leaders: Rassemblement Pour la
Republique (RPR), Emile Maurice; Progressive Party of
Martinique (PPM), Aime Cesaire,; Communist Party of
131
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
MARTINIQUE/MAURITANIA
Martinique (PCM), Armand _ Nicolas; Democratic Union of
Martinique (UDM), Leon-Laurent Valere; Socialist Party,
leader unknown; Federation of the Left, leader unknown
Voting strength: RPR, 2 seats in French National
Assembly; PPM, 1 seat (1973 election)
Communists: 1,000 estimated
Other political or pressure groups: Proletarian Action
Group (GAP), Socialist Revolution Group (GRS)','a466c7f73423492f60a5f8f6e8e033c7ffc7bd3e9d815e7a4a9970dce8d4d341','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2aee03afb7a5ff86bbff4ae6393970d4415bbd71e35de6b84a026f96c51bed06',1978,'MR','Mauritania','government',359,'Legal name: Islamic Republic of Mauritania
Type: republic; one-party presidential rule since 1960
Capital: Nouakchott
Political subdivisions: 12 regions and a capital district
NOTE: Mauritania has acquired administrative control of
the southern third of Western (formerly Spanish) Sahara
under an agreement with Morocco, but the legal question of
sovereignty over the area has yet to be determined. Spain’s
role as co-administrator of the disputed territory ended
February 1976. The newly acquired region, which lies below
the 24th parallel, becomes the district of Tiris el Gharbia—a
territorial division of the state. The district’s headquarters is
Dakhla, formerly Villa Cisneros. Tiris el Gharbia is
subdivided into three departments—Dakhla, Ausert, and
Aargub.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
MAURITANIA/ MAURITIUS
Legal system: based on French civil law system and
Islamic law; constitution adopted 1961; judicial review of
legislative acts in the Supreme Court; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 28 November
Branches: executive, President; separate judiciary (ap-
pointed by president)
Covernment leader: President Moktar Ould Daddah
Suffrage: universal for adults
Elections: presidential and parliamentary election every 5
years; most recent October 1975
Political parties and leaders: Mauritanian Peoples Party
is only legal party, Secretary General Moktar Ould Daddah
Communists: no Communist Party, but there is a
scattering of Maoist sympathizers
Member of: AFDB, AIOEC, Arab League, CEAO,
CIPEC (associate), EAMA, EIB (associate), FAO, G-77,
GATT, IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU,
ITU, NAM, OAU, OMVS (Organization for the Develop-
ment of the Senegal River Valley), U.N., UNESCO, UPU,
WHO, WIPO, WMO','c29794b2217a98af278567acb8943cf1d733b5be394abfe357f86e5d50cf8d67','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('606c7fef7f86e20cafbf6a83235c7d3dba258bf8d62475853bf038ad3fae292d',1978,'MU','Mauritius','government',363,'Legal name: Mauritius
Type: independent state since 1968, recognizing Elizabeth
II as Chief of State
Capital: Port Louis
Political subdivisions: 5 organized municipalities and
various island dependencies
Legal system: based on French civil law system with
elements of English common law in certain areas; constitu-
tion adopted 6 March 1968
National holiday: Independence Day, 12 March
Branches: executive power exercised by Prime Minister
and 2l-man Council of Ministers: unicameral legislature
(National Assembly) with 62 members elected by direct
suffrage, 8 specially elected
Government leader: Prime Minister Dr. Seewoosagur
Ramgoolam
Suffrage: universal over age 18
Elections: legislative elections held in December 1976;
municipal elections held in 1977
Political parties and leaders: a government coalition
consisting of Labor Party (S. Ramgoolam) and Parti
Mauricien Social Democrate (G. Duval); opposition parties—
Independent Forward Bloc (S. Bissoondoyal), Mauritius
Democratic Union (M. Lesage), Mouvement Militant Mauri-
tian (P. Berenger), Mouvement Militant Mauritian Socialiste
Progressist (D. Virahsawmy)
Voting strength: Mauritius Labor Party, 29 seats; Parti
Mauricien Social Democrate, 8 seats; Movement Militant
Mauritian, 32 seats; 1 independent
Communists: may be 2,000 sympathizers; several Com-
munist organizations; Mauritius Lenin Youth Organization,
Mauritius Women’s Committee, Mauritius Communist
Party, Mauritius Peoples Progressive Party, Mauritius
Young Communist League, Mauritius Liberation Front,
Chinese Middle School Friendly Association,
tius/USSR Friendship Society
Other political or pressure groups: Tamil United Party,
Mauritius Workers Party
Mauri-
134
Member of: Commonwealth, FAO, G-77, GATT, IBRD,
ICAO, IDA, IFC, ILO, IMF, ISO, ITU, [WC—International
Wheat Council, NAM, OAU, OCAM, U.N., UNESCO, UPU,
WHO, WIPO WMO
Legal name: Department of Reunion
Type: overseas department of France; represented in
French Parliament by three Deputies and two Senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect ap-
pointed by the French Minister of Interior, assisted by a
Secretary-General and an elected 36-man General Council
Government leader: Prefect Paul Cousseran
Suffrage: universal adult
Elections: last municipal and general council elections in
1976, Parliamentary election March 1978
Political parties and leaders: Reunion Communist Party
(RCP) led by Paul Verges, only organized political
movement on island; other political candidates affiliated
with metropolitan French parties, which do not maintain
permanent organizations on Reunion
Voting strength (Parliamentary election 1978): Rally for
the Republic (formerly Union of Democrats for the
Republic) elected one deputy; Giscardian alliance elected
one Republican deputy and one Centrist deputy
Communists: Communist Party small—probably only
15-20 hard-line Communists—but has support among
sugarcane cutters and in Le Port district
Member of: EC, WFTU','c57238e6572f4895cdf858a8aedebf45ab38e28eb7ddb100570fc807c7a784be','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16c52cc02045a5e24f2bfa02a5360a129e38c88681a92bd0f8f57a9e7e1a7955',1978,'MC','Monaco','government',367,'Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections
Legal system: based on French law; new constitution
adopted 1962: has not accepted compulsory ICJ jurisdiction
National holiday: 19 November
Branches: National Council
Couneil (15 members,
(18 members); Communal
headed by a mayor)
Government leader: Prince Rainier HI
Suffrage: universal
Elections: National Council every 5 years; most recent
1978
Political parties and leaders: National Democratic
Entente, Democratic Union Movement, Monegasque Action-
ist (1973)
Voting Strength: figures for 1978: National Democratic
Entente, 18 seats
00010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009
Eee
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
MONACO/MONGOLIA
Member of: IAEA, IHO, IPU, ITU, U.N. (permanent
observer), UNESCO, UPU, WHO, WIPO','ca44b2c3911c2641c9c6ae1eeb2eec79a03671dd0bea8bd6db9a56fb25ef895a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcbd8a39c0c8eccd3aca4d66aff537499864b2bb4fe9845f96c8482da544c11c',1978,'MN','Mongolia','government',371,'Legal name: Mongolian People’s Republic
Type: Communist state
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 2 autonomous
municipalities (Ulaanbaatar and Darhan)
Legal system: blend of Russian, Chinese, and Turkish
systems of law; new constitution adopted 1960; no constitu-
tional provision for judicial review of legislative acts; legal
education at Ulaanbaatar State University; has not accepted
compulsory IC] jurisdiction
National holiday: People’s Revolution Day, 11 July
Branches: constitution provides for a People’s Great
Hural (national assembly) and a highly centralized
administration
Party and government leaders: Y. Tsedenbal, First
Secretary of the MPRP and Chairman of the Presidium of
the People’s Great Hural; J. Batmunh, Chairman of the
Council of Ministers
Suffrage: universal; age 18 and over
Elections; national assembly elections held every 4 years;
last election held June 1977
Political party: Mongolian People’s Revolutionary (Com-
munist) Party (MPRP); estimated membership, 67,000
(1976)
Member of: CEMA, ESCAP, IAEA, ILO, IPU, ITU, U.N.,
UNESCO, UPU, WHO, WMO','c455f09104ec5d642645ea51b46ca5aa1d0657da9e6e5623fa404d4d53255595','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0e912bdf0f1cd7a508eca6ca283b7fca96fb2d53906515aa8d3125b9f564b5a',1978,'MA','Morocco','government',375,'Legal name: Kingdom of Morocco
Type: constitutional monarchy (constitution adopted
1972)
Capital: Rabat
Political subdivisions: 33 provinces and 2 prefectures
NOTE: Morocco has acquired administrative control over
the northern two-thirds of the former Spanish Sahara under
an agreement with Mauritania, but the legal question of
sovereignty over the area has yet to be determined. Spain’s
role as co-administrator of the disputed territory ended in
February 1976. Rabat has established three provinces in its
area of control, with headquarters at El Aaiun, Semara, and
Cabo Bojador.
Legal system: based on Islamic law and French and
Spanish civil law system; judicial review of legislative acts in
Constitutional Chamber of Supreme Court; modern legal
education at branches of Mohamed V University in Rabat
and Casablanca and Karaouine University in Fes; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 3 March
Branches: constitution provides for Prime Minister and
ministers named by and responsible to King; King has
paramount executive powers; unicameral legislature two-
thirds directly elected, one-third indirectly; judiciary inde-
pendent of other branches
Government leaders: King Hassan II; Prime Minister
Ahmed Osman
Suffrage: universal over age 20
Elections: local elections held 12 November 1976;
provincial elections held 25 January 1977; elections for new
National Assembly provided for in Constitution adopted 15
March 1972 were held June 1977
Political parties and leaders: Istiqlal Party, M’hamed
Boucetta; Popular Movement (MP), Mahjoubi Aherdan;
Constitutional and Democratic Popular Movement (MPCD),
Dr. Abdelkrim Khatib; National Union of Popular Forces
“ Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
id AL A CY__C''Y
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
MOROCCO/MOZAMBIQUE
(UNFP), split into competitive factions under Abdallah
Ibrahim and Mahjoub Ben Seddik of Casablanca-based
faction and Abderrahim Bouabid of Rabat-based faction
with latter becoming Socialist Union of Popular Forces
(USFP) in September 1974; Democratic Constitutional Party
(PDC), Mohamed Hassan Quazzani; Party for Progress and
Socialism (PPS), legalized in August 1974, successor to Party
of Liberation and Socialism (PLS), is front for Moroccan
Communist Party (MCP), which was proscribed in 1959, Ali
Yata; Istiqlal and the UNFP formed a National Front in July
1970 to oppose the new constitution, boycotted the
parliamentary elections and the 1972 constitutional
referendum
Voting strength: pro-government independents hold
absolute majority in new National Assembly; with palace-
oriented Popular Movement deputies, the government holds
over two-thirds of the seats
Communists: 300 est.
Member of: AFDB, Arab League, EC (association until
1974), FAO, G-77, GATT, IBRD, ICAO, IDA, IFC, ILO,
International Lead and Zinc Study Group, IMCO, IMF,
1OOC, IPU, ITU, NAM, OAU, U.N. UNESCO, UPU,
WHO, WIPO, WMO','7aaa76d9cd9692ed2d02c3c19c792ea0d2f0cc120efc9306f27961f09712d7ae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d17e79dbe7ab89bc38b35ce8bc1596053ac9cfa2ed9cbc0de4cea5f62b476650',1978,'MZ','Mozambique','government',379,'Legal name: People’s Republic of Mozambique
Type: peoples republic; achieved independence from
Portugal in June 1975
Capital: Maputo
Political subdivisions: 10 districts administered by
district governors, municipalities governed by appointed
official
Legal system: based on Portuguese civil law system and
customary law
National holiday: Independence Day, 25 June
Branches: none established
Government leader: President Samora Machel
Suffrage: not yet established
Elections: information not available on future election
schedule
Political parties and leaders: the Mozambique Liber-
ation Front (FRELIMO), led by Samora Machel, is only
legal party
Communists: none known
Member of: G-77, ILO, NAM, OAU, U.N.','ec756d40bcd957efadc967682eeaf38c2cadaa61fe1de02d3bb86bbf7d6c0760','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ac8934538e98a001f3cbf8aa8541edd5cfd861107da1a75bc7ba6e41c1608e3',1978,'NA','Namibia','government',383,'Legal name: Namibia
Type: former German colony of South-West Africa
mandated to South Africa by League of Nations in 1920;
UN. formally ended South Africa’s mandate on October 27,
1966, but South Africa has retained administrative control
Capital: Windhoek
Political subdivisions: 10 tribal homelands, mostly in
northern sector, and zone open to white settlement with
administrative subdivisions similar to a province of South
Africa
Legal system: based on Roman-Dutch law and customary
jaw
Branches: since September 1977 an administrator-gen-
eral, appointed by South African government, has exercised
coordinative functions over zone of white settlement, where
white-elected Legislative Assembly handles some local
matters, and tribal homelands, where traditional chiefs and
representative bodies exercise limited autonomy
Government leader: Martinus T. Steyn, Administrator-
general
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Suffrage: franchise for Legislative Assembly limited to
white adults; several tribal homelands have adult franchise
for homeland legislatures
Elections: last general election, 1974
Political parties and leaders: white parties—National
Party of South-West Africa (NPSWA), Abraham H.
du Plessis; Federal Party, Bryan O’Linn; Republican Party,
Dirk Mudge; most of the nonwhite parties belong to one of
two muli-ethnic alliances—the Democratic Turnhalle Alli-
ance (the traditional tribal leaders and the white Republican
Party) or the Namibian National Front (the white Federal
Party and nonwhite groups that oppose the bantustan
system)
Voting strength: (1974 election) NPSWA won all 18 seats
in Legislative Assembly
Communists: no Communist Party, SWAPO guerrilla
force is supported by US.S.R., Cuba, and other Communist
states as well as OAU
Other political or pressure groups: South-West Africa
People’s Organization (SWAPO), led by Sam Nujoma,
maintains a foreign-based guerrilla movement; is predomi-
nantly Ovambo but has some influence among other tribes;
is the only Namibian group recognized by the U.N. General
Assembly and the Organization of African Unity','f997d31d91bfb587f35716d1d2e1febb18687d9f508147314afa4c0beb958817','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edc5b2fe53c7063a3bac8dbd2043876322e40930f4232465ee7fcca9927d074f',1978,'NR','Nauru','government',387,'Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices in
Yeran District
Political subdivisions; 14 districts
Branches: President elected from and by Parliament for
an unfixed term; popularly elected 18-member unicameral!
legislature, the Parliament; Cabinet to assist the President,
four members, appointed by President from Parliament
members
142
Government leader: President Lagumot Harris
Suffrage: universal] adult
Elections: last held in November 1977
Political parties and leaders: Nauru Party, President
Harris; opposition faction, ex-President De Roburt
Member of: no present plans to join U.N.; enjoys “special
membership” in Commonwealth; South Pacific Commission.
ESCAP, INTERPOL, ITU, UPU','684b4dce34d1229fdae870b582240bea087d77b75f50f9617a5678c71067d0e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7b320016d20a780ac1902271260629af027791f839c6ae965ebeeeeb1dbd210',1978,'NP','Nepal','government',391,'Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Birendra exercises
autocratic control over multitiered panchayat system of
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and English
common law; legal education at Nepal Law College in
Kathmandu; has not accepted compulsory ICJ jurisdiction
National holiday: Birthday of the King, 28 December
Branches: Council of Ministers appointed by the King;
indirectly elected National Panchayat (Assembly)
Government leaders: King Birendra Bir Bikram Shah
Deva; Prime Minister Kirtinidhi Bista
Suffrage: universal over age 21
Elections: village and town councils (panchayats) elected
by universal suffrage; district, zonal, and National Pan-
chayat members indirectly elected, most for 6-year terms; 15
National Panchayat members elected from five class and
professional organizations (women, workers, peasants, youth,
and ex-servicemen), four directly elected by all voters
possessing a B.A. or its equivalent, and 16 are appointed by
the King
Political parties
outlawed
and leaders: all political parties
Communists: the combined membership of the two wings
of the Communist Party of Nepal (CPN) about 6,500, the
majority (perhaps 5,000) in the pro-Chinese wing; the CPN
continues to operate more or less openly, but internal
dissension has greatly hindered its effectiveness
Other political or pressure groups: proscribed Nepali
Congress Party led by B. P. Koirala
Member of: ADB, Colombo Plan, FAO, G-77, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, NAM, U.N.,
UNESCO, UPU, WHO, WMO','cf7a590a0d372632ef036ab2424f7d7a2451d97c7613affca085212dfccc29b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6da48e794b5b0a9063d7bbc9949b83350a79b51dfa7c2da507f11eab23ca4a79',1978,'NL','Netherlands','government',395,'Legal name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at The
Hague
Political subdivisions: 11 provinces governed by centrally
appointed commissioners of Queen
Legal system: civil law system incorporating French
penal theory; constitution of 1815 frequently amended,
reissued 1947; judicial review in the Supreme Court of
legislation of lower order than Acts of Parliament; legal
education at six law schools; accepts compulsory IC]
jurisdiction, with reservations
National holiday: Birthday of the Queen, 30 April
Branches: executive (Queen and Cabinet of Ministers),
which is responsible to bicameral States General (parlia-
ment); independent judiciary
Government leaders: Head of State, Queen Juliana:
Andreas van Agt, Prime Minister
Suffrage: universal over age 21
Elections: must be held at least every 4 years for lower
house (most recent held May 1977), and every 8 years for
half of upper house (most recent July 1977)
Political parties and leaders: Catholic People’s Party
(KVP), W. J. Vergeer; Antirevolutionary (ARP), H. A.
de Boer; Labor (PvdA), Mrs. C. (Ien) van den Heuvel:
Liberal (VVD), F. Korthals Altes; Christian Historical Union
(CHU), Otto W. A. Baron van Verschuer; Democrats "66
(D-66), F. Eenstra; Communist (CPN), Henk Hoekstra;
Pacifist Socialist (PSP), Lamber Meertens; Political Re-
formed (SGP), H. G. Abma; Reformed Political Union
(GVP), G. Veurink; Radical Party (PPR), Wisnand Van
Hoogevest; Democratic Socialist "70 (DS-70), H. Staneke;
Farmers’ Party (BP), Hendrik Koekoek; Christian Demo-
cratic Appeal (CDA), coalition of KVP, ARP, and CHU
formed prior to 1977 elections
Voting strength (1977 election): 33.81% PvdA, 31.91%
CDA, 17.95% VVD, 5.43% D’66, 2.13% SGP, 1.73% CPN,
1.69% PPR, 0.96% GPV, 0.94% PSP, 0.84% BP, 0.72% DS’70
Communists: 13,000 est. members
fa Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
i! zl ea
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
NETHERLANDS / NETHERLANDS ANTILLES
Other political or pressure groups: great multinational
firms; Socialist, Catholic, and Protestant trade unions;
Federation of Catholic and Protestant Employers Associ-
ations; the non-denominational Federation of Netherlands
Enterprises
Member of: ADB, Benelux, Council of Europe, DAC, EC,
ECE, EEC, EIB, ELDO, EMA, ESRO, EURATOM, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC,
IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, Itc, ITU, {wC—International Wheat
Council (with respect to interests of the Netherlands Antilles
and Surinam), NATO, OAS. (observer), OECD, UN.,
UNESCO, UPU, WEU, WHO, WIPO, WMO, WSG
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands,
enjoying complete domestic autonomy
Capital: Willemstad, Curacao
Political subdivisions: 4 island territories—Aruba, Bon-
aire, Curacao, and the Windward Islands—St. Eustatius,
southern part of St. Martin (northern part is French), Saba
Legal. system: based on Dutch civil law system, with some
English common law influence; Constitution adopted 1954
Branches: federal executive power rests nominally with
Governor (appointed by the Crown), actual power exercised
by 8-member Council of Ministers or Cabinet presided over
by Minister-President; legislative power rests with 22-mem-
ber Legislative Council; independent court system under
control of Chief Justice of Supreme Court of Justice
(administrative functions under Minister of Justice); each
island territory has island council headed by Lieutenant
Governor
Government leader: Minister-President Silvo G. M.
Rozendal
Suffrage: universal age 18 and over
Elections: Federal elections held every 4 years, last held
17 June 1977; Island council elections every 4 years, last held
April and May 1975
Political parties and leaders:
indigenous to each island:
Curacao: Democratic Party (DP), S. G. M. Rozendal:
National People’s Party-United (NVP-U) Edsel Jenerun;
Frente Obrero de Liberation’ 30 di Mayo (FOL), Wilson
“Papa” Godett; Social Democratic Party (PSD), R. J. Isa
Aruba: People’s Electoral Movement (MEP), G. F,
“Betico” Croes; Aruban Patriotic Party (PPA), L. O. Chance;
Aruban People’s Party (AVP), D. G. Croes
Bonaire: Labor Party (POB); Democratic Party Bonaire
(UPB); New Democratic Action (ADEN)
political parties are
146
Windward Islands: Windward Islands Democratic
Party (DPWI); United F ederation of Antillean Workers
(UFA); Windward Islands Political Movement (WIPM); and
others
Voting strength: (1977 federal election) 6 seats DP, 5 seats
MEP, 3 seats FOL, 3 seats NVP, 8 seats PPA, 1 seat DPWI, !
seat UPB
Communists: no Communist Party
Member of: EC (associate), WHO','f13634623ae736ac730dddab0d11c9d72e6fb5cf4c2a70b4ce49d192dd33ff19','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d317d593c69ca2770b7ff2645ba5a2e6d457cd0d4da0b8c969e9d0705761c3d',1978,'NC','New Caledonia','government',399,'Legal name: Territory of New Caledonia and
dependencies
Type: French overseas territory; represented in French
parliament by one deputy and one Senator
Capital: Noumea
Political subdivisions: 4 islands or island group depen-
dencies—Isle of Pines, Loyalty Islands, Huon Islands, Island
of New Caledonia
Legal system: French law
Approved For Release 2005/04/22 :
Branches: administered by Governor, who is also High
Commissioner for France in the Pacific; responsible to
French Ministry for Overseas France and Governing
Council; Assemblee Territoriale
Government leader: Jean-Gabriel Eriau, Governor and
French High Commissioner
Suffrage: universal
Elections: Assembly elections every 5 years, last in
September 1977
Political parties: Rassemblement Pour La Caledonie—
Conservative; Union Caledonienne—eventual independ-
ence; Union Multiraciale and Palika—independence parties
Voting strength (1977 election): Rassemblement Pour La
Caledonie, 12 seats; Union Caledonienne, 9 seats; Palika, 2
seats; 8 other parties divide up remaining 12 seats
Communists: number unknown; Union Caledonienne
strongly leftist; some politically active Communists were
deported during 1950''s; small number of North Vietnamese
Other political parties and pressure groups: several
lesser parties
Member of: EIB (associate)
Legal name: New Hebrides Condominium
Type: Anglo-French condominium
Capital: Vila
Political subdivisions: 4 administrative districts
Legal system: 3 sets of courts; one each for French and
British subjects, one for New Hebrides native affairs
Branches: Representative Assembly, 42 members, elected
November 1977, election boycotted by major party
Government leaders: two resident commissioners, one
French, Robert Gauger; one British, John Champion
Political parties and leaders: National Party (Vanuaaku
Pati), chairman Walter Lini; NA Griamel Party, leader
Jimmy Stevens; Mouvement d’Action des Nouvelles Hebri-
des (MANH)','ad79ba3c7e72d99299505825a39005a66215734427f74ece225c3bc655888771','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59b5338bbdca094290815b1d1e4bda6eb526513737c13fc28010342a10530ac9',1978,'NZ','New Zealand','government',403,'Legal name: Dominion of New Zealand (rarely used)
Type: independent state within Commonwealth, recogniz-
ing Elizabeth II as head of state
Capital: Wellington
Political subdivisions: 112 counties
Legal system: based on English law, with special land
legislation and land courts for Maori tribesmen; constitution
consists of various documents, including certain acts of the
U.K. and New Zealand Parliaments; legal education at
Victoria, Auckland, Canterbury, and Otago Universities;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Waitangi Day, 6 February
Branches: unicameral legislature (General Assembly,
commonly called Parliament); Cabinet responsible to Parlia-
ment; 3-level court system (Magistrates, Courts, Supreme
Court, and Court of Appeal)
Government leader: Prime Minister Robert D. Muldoon
Suffrage: universal age 18 and over
Elections: held at 3 year intervals or sooner if parliament
is dissolved by Prime Minister; last election November 1975
Political parties and leaders: National Party (Govern-
ment), Robert D. Muldoon; Labour Party (Opposition),
Wallace E. Rowling; Social Credit Political League, Bruce
Beetham; Communist Party, George Victor Wilcox; pro-
Soviet Socialist Unity Party, George Edward Jackson
Voting strength (1975 election): National Party 55 seats,
Labour Party 32 seats
Communists: CPNZ about 300, SUP about 100
Member of: ADB, ANZUS, ASPAC, Colombo Plan, DAC,
ESCAP, FAO, GATT, IAEA, IBRD, ICAO, IEA, IFC, IHO,
ILO, IMCO, IMF, IPU, ISO, ITU, OECD, U.N., UNESCO,
UPU, WHO, WMO, WSG','2ca2348ae6e76331d768b991b4d84f0bad584db668ac2990d0934556a9372479','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47d3f1ad468ac5dc34c20b55a79c3c907d938eb37f3f41e3b5851740074c3ee6',1978,'NE','Niger','government',412,'Legal name: Republic of Niger
Type: republic; military regime in power since April 1974
Capital: Niamey
Political subdivisions: 7 departments, 32 arrondissements
Legal system: based on French civil law system and
customary law; constitution adopted 1960, suspended 1974;
judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; has not accepted compulsory ICJ
jurisdiction
National holiday: Proclamation of the Republic, 18
December
Branches: executive authority exercised by Supreme
Military Council (SMC) composed of army officers; cabinet
includes civilians
Government leader: Lt. Col. Seyni Kountche, President
of Supreme Military Council and Chief of State
Suffrage: suspended
Elections: political activity banned
Political parties and leaders: political parties banned
Communists: no Communist party; some sympathizers in
outlawed Sawaba party
Member of: AFDB, APC, CEAO, EAMA, ECA,
ECOWAS, Entente, FAO, G-77, GATT, IAEA, IBRD,
ICAO, IDA, ILO, IMF, IPU, ITU, Lake Chad Basin
Commission, Niger River Commission, NAM, OAU, OCAM,
U.N., UNESCO, UPU, WHO, WIPO, WMO
151
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
NIGER/NIGERIA','74140b199fc7221c66456f0437a2532213f8cafe5fdda58e61e3f27bc01b42d3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ad9c7b0e05ca99279caf0c23224d4b49383f97a0ec83ff90db407595cf7a186',1978,'NG','Nigeria','government',416,'Legal name: Federal Republic of Nigeria
Type: federal republic since 1963; under military rule
since January 1966
Capital: Lagos
Political subdivisions: 19 States, headed by military
governors
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
NIGERIA/NORWAY
Legal system: based on English common law, tribal law,
and Islamic law; proposed new constitution to be reviewed
and adopted by October 1979 by a constituent assembly;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Independence Day, 1 October
Branches: Federal Military Government, decrees issued
by Supreme Military Council, advised by largely civilian
Federal Executive Council
Government leader: Lieutenant General Olusegun Oba-
sanjo, Head of Federal Military Government and Com-
mander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage
Elections: nonpartisan elections for local government
councils held in late 1976, the military has promised to
restore power to an elected civilian regime when state and
federal legislative elections are held between October 1978
and October 1979
Political parties and _ leaders: political parties and
politically active tribal societies were dissolved by decree on
24 May 1966; behind-the-scenes politicking is quickening in
anticipation of scheduled lifting of ban on political activity
in October 1978
Communists: the banned Socialist Workers and Farmers
Party and the Nigerian Trade Union Congress have a limited
political following, no influence on government
Member of: AFDB, APC, Commonwealth, ECA,
ECOWAS, FAO, G-77, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMCO, IMF, ISO, ITC, ITU, IWC—International Wheat
Council, Lake Chad Basin Commission, Niger River
Commission, NAM, OAU, OPEC, U.N., UNESCO, UPU,
WHO, WMO','e5c39951a10b098bd0323187db03ba572c9ec285227765967aa2be984cb24f65','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b381c68a264c5e52e816271f0d65aaa2ccd3b23ce7483ac741278724d1c23607',1978,'NO','Norway','government',420,'Legal name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 19 counties, 404 communes, 47
towns
Legal system: mixture of customary law, civil law system,
and common law traditions; constitution adopted 1814,
modified 1884; Supreme Court renders advisory opinions to
legislature when asked: legal education at University of Oslo;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Constitution Day, 17 May
Branches: legislative authority rests jointly with Crown
and parliament (Storting); executive power vested in Crown
but exercised by cabinet responsible to parliament; Supreme
Court, 5 superior courts, 104 lower courts
Government leaders: King Olav V; Prime Minister Odvar
Nordli
Suffrage: universal, but not compulsory, over age 20
Elections: held every 4 years (next in September 1981)
154
Political parties and leaders: Labor, Reiulf Steen;
Conservative, Erling Norvik; Center, Gunnar Stalsett;
Christian People’s, Lars Kosvald; Liberal, Hans Hammond
Rossbach; New People’s Party, Magne Lerheim; Socialist
Left, Berge Furre; Norwegian Communist, Martin Gunnar
Knutsen; Progressive, Arve Loennum
Voting strength (1977 election): Labor, 42.5%; Conserva-
tive, 24.6%; Christian People’s, 12.1%; Center, 8.6%; New
People’s Party (anti-tax), 1.7%; Socialist Left (Socialist
Electoral Alliance) (formerly anti-tax), 4.1%; liberal, 3.2%
Progressive, 1.9%; Norwegian Communist, 0.4%; Red Elec-
tion Alliance, 0.6%, latter two are communist parties
Communists: 2,500 est.; a number of sympathizers as
indicated by the 22,500 Communist votes cast in the 1969
election (in the 1973 election the Communist Party vote total
was submerged in the 241,851 votes won by the Socialist
Electorial Alliance which included the Norwegian Commu-
nist Party and two other parties)
Member of: ADB, Council of Europe, DAC , EC (Free
Trade Agreement), EFTA, ESRO (observer), FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, IDA, IEA (associate
member), IFC, IHO, ILO, International Lead and Zinc
Study Group, IMCO, IMF, IPU, ITU, IWC—International
Whaling Commission, IWC—International Wheat Council,
NATO, Nordic Council, OECD, U.N., UNESCO, UPU,
WHO, WIPO, WMO, WSG','bd3743a619ffd8ee733aa7c3e0b2dbef2ced884a1e1250da2b09e43eba35b086','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ee7e524adcdc05d2e8cdb14a6de1db5427db6b290ccc1e55ed5e0f243cbbd0e',1978,'OM','Oman','government',424,'Legal name: Sultanate of Oman
Type: absolute monarchy; independent, with strong
residual U.K. influence
Capital: Muscat
Legal system: based on English common law and Islamic
law; no constitution; ultimate appeal to the Sultan; has not
accepted compulsory IC] jurisdiction
National holiday: 18 November
Government leader: Sultan Qabus ibn Sa‘id Al Bu Sa‘id
Other political or pressure groups: Popular Front for the
Liberation of Oman (PFLO), based in South Yemen
Member of: Arab League, FAO, G-77, IBRD, ICAO,
IDA, IFC, IMF, NAM, U.N., UNESCO, UPU, WHO','b8f365691cca2be7b69ce37308b011ab7fa84a8f774e08229b367389977c2424','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd34212ac5dc149a615a5a9e06d94724ea7cd063bce1f1a6712f4650d227a3b0',1978,'PK','Pakistan','government',428,'Legal name: Islamic Republic of Pakistan
Type: parliamentary, federal republic; military seized
power 5 July 1977 and temporarily suspended some
constitutional provisions
Capital: Islamabad
Political subdivisions: 4 provinces—Punjab, Sind, Balu-
chistan, and North-West F rontier—with the capital territory
of Islamabad and certain tribal areas centrally administered;
Pakistan claims that Azad Kashmir is independent pending a
settlement of the dispute with India, but it is in fact under
Pakistani control
Legal system: based on English common law; accepts
compulsory IC] jurisdiction, with reservations
National holiday: Pakistan Day, 23 March
Government leaders: President Fazal Elahi Chaudhry;
Chief Martial Law Administrator Mohammed Zia-ul-Haq
Suffrage: universal from age 18
Elections: opposition agitation against rigging of elections
in March 1977 eventually led to military coup; military
promised to hold new national and provincial assembly
elections in October 1977 but later postponed them
indefinitely
Political parties and leaders: Pakistan People’s Party
(PPP), pro-Bhutto wing, Mrs. Z. A. Bhutto, moderate wing,
Maulana Kauser Niazi; Pakistan Muslim League (QML),
Abdul Qaiyum Khan; Tehrik-i-Istiqlal, Asghar Khan; Paki-
stan National Alliance (PNA), a coalition of eight parties
including Pakistan Muslim League (PML)—Pir of Pagaro
group; National Democratic Party (NDP), Sherbaz Mazari
(formed in 1975 by members of outlawed National Awami
Party (NAP) of Abdul Wali Khan, who is de facto NDP
leader); Jamaat-i-Islami (1), Tofail Mohammed: Jamiat-
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
PAKISTAN/PANAMA
ul-Ulema-i-Pakistan (JUP), Maulana Shah Ahmed Noorani;
Jamiat-ul-Ulema-i-Islam (JUI), Mufti Mahmud; Pakistan
Democratic Party (PDP), Nasrullah Khan
Communists: party membership very small; sympathizers
estimated at several thousand
Other political or pressure groups: military remains
potentially strong political force
Member of: ADB, CENTO, Colombo Plan, FAO, GATT,
G-77, IAEA, IBRD, ICAC, ICAO, IDA, IFC, IHO, ILO,
IMCO, IMF, ITU, {1wWC—International Wheat Council,
RCD, U.N., UNESCO, UPU, WHO, WMO, WSG','a4f6bcc2b80594ebcd8952a4b1da055f2861b6e769b5553ed0b9f2f424c9226b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa7d6ed3d7f3ed1d7e48b9efb3b53abafc2264adadde842b4ff44cc00b6e1891',1978,'PA','Panama','government',432,'Legal name: Republic of Panama
Type: republic
Capital: Panama
Political subdivisions: 9 provinces, | intendancy
Legal system: based on civil law system; constitution
adopted in 1972; judicial review of legislative acts in the
Supreme Court; legal education at University of Panama;
accepts compulsory IC] jurisdiction, with reservations
National holiday: Independence Day, 3 November
Branches: President (figurehead, subordinate to National
Guard Commandant, General Omar Torrijos, who was
granted special powers for 6 years by the Constitutional
Assembly in 1972); popularly elected unicameral legislature
(Corregimiento), which elects the President but which
exercises few, if any, legislative powers and meets for one
month each year; during the remainder of the year the
National Legislative Council, the President, Vice President,
Cabinet, and selected members of the Corregimiento
exercise legislative functions; presidentially appointed Su-
preme Court
Government leaders: Demetrio Lakas is Constitutional
President and Chief of State, but subordinate to Gen. Omar
Torrijos, the National Guard Commandant and Chief of
Suffrage: universal and compulsory over age 18
Elections: elections for assembly of corregimientos in
August 1978; corregimiento to choose President
Political parties and leaders: political parties suspended;
although the government in April 1978 indicated it would
establish a new basis for parties, the new law will probably
not be promulgated until very late 1978 or 1979; Communist
Party illegal but allowed to operate
Voting strength: no parties were active in the 1972
elections
Communists: 500 active and several hundred inactive
members People’s Party (PdP); 500-600 members of rival
Fraccion movement which split from PdP in 1974; 2.500
sympathizers
Other political or pressure groups: National Council of
Private Enterprise (CONEP); Panamanian Association of
Business Executives (APEDE)
Member of: FAO, G-77, TADB, IAFA, IBRD, ICAO, IDA,
IDB, IFC, ILO, IMCO, IMF, ITU, !WC—International
Whaling Commission, IWC— International Wheat Council,
NAM, OAS, SELA, U.N., UNESCO, UPEB, UPU, WHO,
WMO
158','dd4707f2e3020efca56863808308a3b7c70da2833d5f333c653f4b98343b1895','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c775c030d085b6ad1cef44108bc0099155c93f3cf82463948e98d9c74bd4814',1978,'PG','Papua New Guinea','government',436,'Legal name: Papua New Guinea
Type: independent state within Commonwealth recogniz-
ing Elizabeth II as head of state
Capital: Port Moresby
Political subdivisions: 18 administrative districts (12 in
New Guinea, 6 in Papua)
Legal system: based on English common law
National holiday: Independence Day, 16 September
Branches: executive—Executive Council; legislature—
House of Assembly (109 members); judiciary—court system
consists of Supreme Court of Papua New Guinea and various
inferior courts (District Courts, Local Courts, Children’s
Courts, Wardens’ Courts)
Government leaders: Governor General, Tore Lokoloko;
Prime Minister, Michael Somare
Suffrage: universal adult suffrage
Elections: preferential-type elections for 109-member
House of Assembly every 4 years, last held in June 1977
Political parties: Pangu Party, People’s Progress Party,
United Party, Papua Besena
Communists: no significant strength
Member of: ADB, CIPEC (associate), Commonwealth,
ESCAP (associate), G-77, IBRD, ILO, IMF, U.N., WHO
(associate)','41ac5f8a6d9b28851262860263b086345c9a53d500566c6f336571cad2262730','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('974c610f42062c6c977e1cb6da998cacdf536870d71d77e4e9b724937e3f1c96',1978,'PY','Paraguay','government',440,'Legal name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion
Political subdivisions: 16 departments and the national
capital, 154 municipalities
Legal system: based on Argentine codes, Roman law, and
French codes; constitution promulgated 1967; judicial
review of legislative acts in Supreme Court; legal education
at National University of Asuncion and Catholic University
of Our Lady of the Assumption; does not accept compulsory
IC} jurisdiction
National holiday: Independence Day, 14 May
Branches: President heads executive; bicameral legisla-
ture; judiciary headed by Supreme Court
Government leader: President General Alfredo Stroessner
Suffrage: universal; compulsory between ages of 18-60
Elections: President and Congress elected together every
5 years; last election held in February 1978
Political parties and leaders: Colorado Party, Juan
Ramon Chavez; Liberal Party (Levi-Liberal Party), Carlos
Levi Ruffinelli; Febrerista Party, Roque Gaona; Radical
Liberal Party and United Liberal Party (provisional
unification of Liberal and Radical Liberal parties), Miguel
Angel Martinez Yaryes; Christian Democratic Party, Anibal
Recalde Sosa
Voting strength (February 1978 general election): 90%
Colorado Party, 5% Radical Liberal Party, 3% Liberal Party,
Febrerista Party boycotted elections
Communists: Oscar Creydt faction and Miguel Angel
Soler faction (both illegal); est. 3,000 to 4,000 party members
and sympathizers in Paraguay, very few are hard core; party
in exile is small and deeply divided
Other political or pressure groups: Popular Colorado
Movement (MoPoCo) led by Epifanio Mendez Fleitas, in
exile
Member of: FAO, G-77, IADB, IAEA, IBRD, ICAO, IDA,
IDB, IFC, ILO, IMF, IPU, ITU, LAFTA, OAS, SELA, UN.,
UNESCO, UPU, WHO, WMO, WSG
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
PARAGUAY/PERU
July 1978','aa191222c2ae76577d1bad13c7c2e04fb470d63fc93f2033246b1f11f676d142','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bedbb0b8cedc2162556c24416ed21ed0c63c5bfd4ec47067ba6d3541a2e0a03',1978,'PE','Peru','government',444,'Legal name: Republic of Peru
Type: republic; under military regime since October 1968
Capital: Lima
Political subdivisions: 23 departments with limited
autonomy plus constitutional Province of Callao
Legal system: based on civil law system; military
government rules by decree and functions under Revolution-
ary Statute which supersedes 1933 constitution; legal
education at the National Universities in Lima, Trujillo,
Arequipa, and Cuzco; has not accepted compulsory ICJ
jurisdiction
161
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
PERU/ PHILIPPINES
National holiday: Independence Day, 28 July
Branches: executive, judicial; congress disbanded after 3
October 1968 ouster of President Fernando Belaunde Terry
Government leader: President, General Francisco Mo-
rales Bermudez Cerrutti
Suffrage: obligatory for citizens (defined as adult men
and women and married persons over age 18) until age 60
Elections: June of 1978 a constituent assembly to be
elected to draw up a new constitution; issuance of the new
charter to be followed by presidential and parliamentary
clections in 1980
Political parties and leaders: Popular Action Party (AP),
Fernando Belaunde Terry; American Popular Revolutionary
Alliance (APRA), Victor Raul Haya de la Torre; and Popular
Christian Party (PPC), Luis Bedoya Reyes; Christian
Democratic Party (PDC), Juan Lituma Portocarrero
Voting strength (1963 election): 39% AP-PDC, 34%
APRA, 25% UNO, 1% Communist, 1% other
Communists: pro-Soviet (PCP/S) 2,000; pro-Chinese (2
factions) 1,200
Member of: AIOEC, ASSIMER, CIPEC, FAO, G-77,
GATT, IADB, IAEA, IATP, IBRD, CIPEC, ICAO, IDA,
IDB, IFC, ILO, International Lead and Zinc Study Group,
IMCO, IMF, ISO, ITU, [WC—International Wheat Council,
LAFTA and Andean Pact, NAM, OAS, U.N., UNESCO,
UPU, WHO, WMO, WSG','017a74b21b5674db57a85adcf6ca03296b941aec3a59aa13b35b425b1f8a8886','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cffbc753d27327b6514cdd8dced56ae8cbbecf6cb3e01b4556942dc2decf9a7',1978,'PL','Poland','government',448,'Legal name: Polish People’s Republic (PRL)
Type: Communist state
Capital: Warsaw
Political subdivisions: 49 provinces
Legal system: mixture of Continental (Napoleonic) civil
law and Communist legal theory; constitution adopted 1952;
court system parallels administrative divisions with Supreme
Court, composed of 104 justices, at apex: no judicial review
of legislative acts; legal education at 7 law schools; has not
accepted compulsory ICJ jurisdiction
National holiday: National Liberation Day, 22 July
Branches: legislative, executive, judicial system domi-
nated by parallel Communist party apparatus
Government leaders: Piotr Jaroszewicz, Premier; Henryk
Jablonski, chairman of Council of State (President)
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government every 4
years
Dominant political party and leader: Polish United
Workers’ Party (PZPR) (Communist), Edward Gierek, First
Secretary
Voting strength (1975 election): 99% voted for Commu-
nist-approved single slate
Communists: 2,758,000 party members (March 1978)
Other political or pressure groups: National Unity Front
(FJN), including United Peasant Party (ZSL), Democratic
Party (SD), progovernment pseudo-Catholic Pax Association
and Christian Social Association, Catholic independent Znak
group; powerful Roman Catholic Church, Stefan Cardinal
Wyszynski, Primate
Member of: CEMA, GATT, ICAO, ICES, IHO, Indochina
Truce Commission, ILO, International Lead and Zinc Study
Group, IPU, ISO, ITC, Korea Truce Commission, U.N. and
all specialized agencies except IMF and IBRD, Warsaw Pact,
WIPO','f6d063d70a2f76df09aec71ba98112d2c3811860fe0583104acfccc18b68f431','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4255bbf4c1431b8f6c2caf01d126caacb368e334eb164d790d26398960f30361',1978,'PT','Portugal','government',452,'Legal name: Portuguese Republic
Type: republic, first government under new constitution
formed July 1976; major political parties and officers of
all-military Revolutionary Council signed document in
December 1975 agreeing to multiparty parliamentary
democracy with military oversight for period of 4 years
following presidential elections in June 1976
165
A
pproved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000
July 1978
PORTUGATI,
Capital: Lisbon
Political subdivisions: 18 districts in mainland Portugal:
Portugal’s two autonomous regions, the Azores and Madeira
Islands, have 4 districts (3. of them in the Azores); Macao,
Portugal’s remaining overseas territory, was granted broad
executive and legislative autonomy in February 1976;
Portugal has not officially recognized the unilateral annex-
ation of Portuguese Timor by Indonesia
vetoes of laws by
presidency, may be appealed to a Constitutional ¢ sommis-
with reservations
National holiday; 25 April
Branches: executive with
with 18-member Revolutionary Council as advisory body to
Government leaders: President Antonio Ramalho Eanes;
Prime Minister Mario Soares
Suffrage: universal over age 18, except for those barred by
law for Participation in “undemocratic” institutions prior to
April 25, 1974
Elections: national elections for Assembly of the Republic
to be held every 4 years, first Assembly under new
constitution elected April 1976, will sit until October 14,
1980 unless earlier dissolved by the President; national
election for president to be held
in June 1976—will end
with 4 year transitional period; local elections to be held
December 1976
Political parties and leaders: the Portuguese Socialist
Party (PS) is led by Mario Soares, the Social Democratic
Party (PSD), formerly the Popular Democratic Party (PPD),
Diogo Freitas do Amaral, and the
Party (PCP) by Alvaro Cunhal
Voting strength:
Socialists polled 35%
(1976 parliamentary election) the
of the vote; the PSD received 24%, the
CDS 16%, and the Communists 15%; (1976 local elections)
PS 33%, PSD 24%, PCP 18%, CDS 17%
Communists: Portuguese Communist Party claims mem-
bership of 142,512 (March 1978)
Member of: Council of Europe, EFTA, FAO, GATT,
TAEA, IATP, IBRD, ICAC, ICAO (restricted membership),
ICES, IFC, THO, ILO, IMF, IOOC, ISO, ITU, Iwc—
Internationa] Wheat Council, NATO, OECD, UN.
UNESCO, UPU, WHO, WIPO, WMO, WSG
166
Approved For Release 2005/04/22','8ff1d2092d6b04b997ab8024d2bf97442e467e44fcd2d54dee18990eb4c7a8db','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9249395cb5ebc04aac9e92318b842c153aacff7cce2f95b3c26f2281a45e52cd',1978,'QA','Qatar','government',456,'Legal name: State of Qatar
Type: traditional monarchy; independence declared in
197]
Capital: Doha
Legal system: discretionary system of law controlled by
the ruler, although new civil codes are being implemented;
Islamic law is significant in personal matters; a constitution
was promulgated in 1970
National holiday: 3 September
Government leader: Amir Khalifa ibn Hamad Al-Thani
Suffrage: no specific provisions for suffrage laid down
Elections: constitution calls for elections for part of State
Advisory Council, semi-legislative body, but none have been
held
Political parties and pressure groups: none; a few small
clandestine organizations are active
Branches: Council of Ministers; appointive 30-member
Advisory Council
Member of: Arab League, FAO, G-77, GATT (de facto),
IBRD, ICAO, ILO, IMF, NAM, OAPEC, OPEC, U.N.,
UNESCO, UPU, WHO, WIPO','fd2d73a9041836c0196c5e6ca1c597b5437715072b17a1b69c7aa0bde6b7e751','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07bec08d3b190457be3e3821654aa49f1a5c1a7ee8fbc370a35cab63d79eeb63',1978,'RO','Romania','government',459,'Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 39 counties and 46 municipalities,
including Bucharest that has administrative status equal to a
county
Legal system: mixture of civil law system and Communist
legal theory which increasingly reflects Romanian traditions;
constitution adopted 1965; legal education at University of
Bucharest and two other law schools; has not accepted
compulsory IC] jurisdiction
National holiday: Liberation Day, 23 August
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
ROMANIA/RWANDA
Branches: Presidency; Council of Ministers; the Grand
National Assembly, under which is Office of Prosecutor
General and Supreme Court; Council of State
Government leaders: Nicolae Ceausescu, President of the
Socialist Republic, head of state; Manea Manescu, Prime
Minister
Suffrage: universal over age 18, compulsory
Elections: elections held every 5 years for Grand National
Assembly deputies and local people’s councils
Political parties and leaders; Communist Party of
Romania only functioning party, Nicolae Ceausescu, Secre-
tary General
Voting strength (1975 clection): overall participation
reached 99.96%; of those registered to votc (14,900,032),
98.8% voted for party candidates
Communists: 2,747,000 (end of 1975)
Member of: CEMA, FAO, G-77, GATT, IAEA, IBRD,
ICAO, ILO, IMF, IPU, ITG, ITU, U.N., UNESCO, UPU,
Warsaw Pact, WHO, WIPO, WMO','a1d6f36f772d456f212438bd45ef810480e66c6d93b0c3f533b31c979ffc9e6d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('318be5d96ee684b292793ec8c96523eaaa5d367f539066e9282c68614cbc9460',1978,'RW','Rwanda','government',463,'Legal name: Republic of Rwanda
Type: republic, presidential system in which military
leaders hold key offices; 1962 constitution still in force
except for Title V on the National Assembly
Capital: Kigali
Political subdivisions: 10 prefectures, subdivided into
142 communes
Legal system: based on German and Belgian civil law
systems and customary law; constitution adopted 1962;
judicial review of legislative acts in the Supreme Court; has
not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 1 July
Branches: President, and 15-member cabinet
Government leader: Major General Juvenal Habyari-
mana, Head of State
Suffrage: universal
Elections: last legislative election September 1969; none
allowed by present government; elections of Communal
Counsellors held November 1974
Political parties and leaders: National Revolutionary
Movement for Development, General Habyarimana (offi-
cially not a party—a “development movement” only)
Communists: no Communist party
Member of: AFDB, EAMA, FAO, G-77, GATT, IBRD,
ICAO, IDA, ILO, IMF, IPU, ITU, NAM, OAU, OCAM,
U.N., UNESCO, UPU, WHO, WMO','903042ed67e53bacadd426e94ad3b4197314ede6f0d91f1d739a5d2cf47d8cda','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c15517494a480c57fb38739d11a108fcb129e73f91d1e069c379f23491ffa4f6',1978,'SM','San Marino','government',467,'Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in 1862 the
Kingdom of Italy concluded a treaty guaranteeing the
independence of San Marino; although legally sovereign, San
Marino is vulnerable to pressure from the Italian
Capital: San Marino
Political subdivisions: San Marino is divided into 9
castelli: Acquaviva, Borgo Maggiore, Chiesanuova, Dog-
manano, Faetano, Fiorentino, Monte Giardino, San Marino,
Serravalle
Legal system: based on civil law system with Italian law
influences; electoral law of 1926 serves some of the functions
of a constitution; has not accepted compulsory IC]
jurisdiction
Branches: the Grand and General Council is the
legislative body elected by popular vote; its 60 members
serve 5-year terms; Council in turn elects two Captains-Re-
gent who exercise executive power for term of 6 months, the
Council of State whose members head government adminis-
trative departments and the Council of Twelve, the supreme
judicial body; actual executive power is wielded by the
Secretary of State for Foreign Affairs and the Secretary of
State for Internal Affairs
175
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SAN MARINO/SAO TOME AND PRINCIPE
Government leaders (in caretaker status since fall of
government 17 November 1977): Secretary of State for
Foreign and Political Affairs and for Information, Giancarlo
Ghironzi (Christian Democratic party); Secretary of State for
Internal Affairs and Justice, Clara Boscaglia (Christian
Democratic party); Secretary of State for Budget, Finance,
and Planning, Remy Giacomini (Socialist Party)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General Council
required at least every 5 years; an election was held 28 May
1978 in effort to resolve government crisis pending since
November 1977
Political parties and leaders: Christian Democratic party
(DCS), Gian Luigi Berti; Social Democratic Party (PSDSM),
Alvaro Casali; Socialist Party (PSS), Remy Giacomini;
Communist Party (PCS), Umberto Barulli; People’s Demo-
cratic Party (PDP), leader unknown; Committee for the
Defense of the Republic (CDR), leader unknown
Voting strength (1974 election): 39.6% DCS, 23.7% PCS,
15.4% PSDIS, 13.9% PSS, 1.9% PDP, 2.9% CDR
Communists: approx. 300 members (number of sympa-
thizers cannot be determined); PSS, in government with
Christian Democrats since March 1973, formed a govern-
ment with the PCS from the end of World War II to 1957
Other political parties or pressure groups: political
parties influenced by policies of their counterparts in Italy,
the two Socialist parties are not united
Member of: ICJ, International Institute for Unification of
Private Law, International Relief Union, IRC, UPU','a62a953130e9acbaadd8e02758e6c898715b3b1142bbd7e9a41679fc84ceaad8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('720b324cbf7e3e6882cd20c8930a05ad634d8669bb25e69c6e837f064d3e90ee',1978,'ST','Sao Tome and Principe','government',471,'Legal name: Democratic Republic of Sao Tome and
Principe
Type: republic established when independence received
from Portugal in July 1975; constitution adopted December
1975
Capital: Sao Tome
Legal system: based on Portuguese law system and
customary law; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 12 July
Branches: Da Costa heads the government assisted by a
cabinet of ministers
Government leaders: President Manuel Pinto Da Costa,
Prime Minister Miguel Anjos da Cuna Lisboa Trovoada
Suffrage: universal for age 18 and over
Elections: elections were held J uly 1975 for the President
Political parties and leaders: Movement for the Liber-
ation of Sao Tome and Principe (MLSTP), Secretary-General
Manuel Pinto Da Costa
Communists: no Communist party, probably a few
Communist sympathizers
Member of: G-77, NAM, OAU, U.N.','bce55895a2a7d5856a30e0bbb2e68bca88b016f9ce2c6ed79538d63be68c235c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2d6a0f9f1fdcfb3cf0605cd1dba939ac5115c5c9947bf140ff961e08a052b09',1978,'SA','Saudi Arabia','government',475,'Legal name: Kingdom of Saudi Arabia
Type: monarchy
177
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SAUDIA ARABIA/SENEGAL
Capital: Riyadh; foreign ministry and foreign diplomatic
representatives located in Jiddah
Political subdivisions: 18 amirates
Legal system: largely based on Islamic law, several
secular codes have been introduced; commercial disputes
handled by special committees; has not accepted compulsory
{CJ jurisdiction
National holiday: 23 September
Branches: King Khalid (Al Saud, Khalid ibn Abd al-Aziz)
rules in consultation with royal family (especially Crown
Prince Fahd), and Council of Ministers
Government leader: King Khalid
Communists: negligible
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, [WC—International
Wheat Council, NAM, OAPEC, OPEC, U.N., UNESCO,
UPU, WHO, WMO','6c8c99c2a8f1bd97cf50a9dd366ea82da0409d0a042196310c266d44a658022a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d15e391ec48a07a043ed8189f2867111b9cdfd23f4eb620978a778dfba3c0d79',1978,'SN','Senegal','government',479,'Legal name: Republic of Senegal
Type: republic
Capital: Dakar
Political subdivisions: 8 regions, subdivided into 27
departments, 95 arrondissements
Legal system: based on French civil law system;
constitution adopted 1960, revised 1963 and 1970; judicial
review of legislative acts in Supreme Court (which also
audits the government’s accounting office); legal education
at University of Dakar; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 4 April
Branches: government dominated by President who is
assisted by Prime Minister, appointed by President and
subject to dismissal by President or censure by National
Assembly; 100-member National Assembly, elected for 5
years (effective 1978); President elected for 5-year term
(effective 1978) by universal suffrage; judiciary headed by
Supreme Court, with members appointed by President
Covernment leaders: Leopold Sedar Senghor, President;
Abdou Diouf, Prime Minister
Suffrage: universal adult
Elections: presidential and_ legislative elections held
February 1978 for 5-year term
Political parties and leaders: legal parties are Parti
Socialiste (PS), ruling party led by President Leopold
Senghor; Parti Democratique Senegalaise (PDS), “liberal
democratic” party founded July 1974, and “Marxist-Lenin-
ist” African Independence Party (PAI), legalized in August
1976; unauthorized parties include clandestine PAI splinter
group, leftist Rassemblement Nationale Democratique, and
Parti Communiste Senegalais (PCS)
Communists: small number of Communists and sympa-
thizers associated with PAI and PCS
Other political or pressure groups: students and teachers
occasionally strike
Member of: AFDB, APC, CEAO, EAMA, ECA,
ECOWAS, EIB (associate), FAO, G-77, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, JTU, NAM,
OAU, OCAM, OMVS (Organization for the Development of
the Senegal River Valley), U.N., UNESCO, UPU, WHO,
WIPO, WMO','2238e28338e28206eb5eb0991cb98cea25cd523be472da02f73d1f699272c796','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32d1c9fd139712e241c985d6c50a018fa08e39c6797170db4bd7768c6175b9c8',1978,'SC','Seychelles','government',483,'Legal name: Republic of Seychelles
Type: republic; member of the Commonwealth
Capital: Victoria, Mahe Island
Legal system: based on English common law, French civil
law system, and customary law
National holiday: 29 June
Branches: President, Council of Ministers
180
Government leader: President, France Albert Rene
Suffrage: universal adult
Elections: April 1974, new government has promised
election by June 1979, but not before new constitution
drafted
Political parties and leaders: Rene, who heads the
Seychelles People’s United Party, came to power by a
military coup in June 1977, until then he had been Prime
Minister in an uneasy coalition with then President James
Mancham, who headed the Seychelles Democratic Party.
Rene banned the Seychelles Democratic Party in mid-March
and plans to turn the country into a one-party state. Rene
dissolved the National Assembly, and plans to rule by
presidential decree until a new constitution is drafted. Rene
abrogated the constitution without qualification upon taking
power. Subsequently the government decided to retain some
provisions, but presidential decree enables the President and
specified subordinates to violate constitutional safeguards in
interests of state security
Communists: negligible
Other political or pressure groups: trade unions which
are appendages of political parties
Member of: G-77, NAM, OAU, UN.','88b38f92015787f7beca3b223cf9353504d0c1fb8bd177c5dd9a6e64c63a5432','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ee50a87252310a6801ae20140c035341a30f09e211a699ffc1394068c7e6632',1978,'SL','Sierra Leone','government',487,'Legal name: Republic of Sierra Leone
Type: republic under presidential regime since April 1971
Capital: Freetown
Political subdivisions: 3 provinces; divided into 12
districts with 146 chiefdoms, where paramount chief and
council of elders constitute basic unit of government; plus
western area, which comprises Freetown and other coastal
areas of the former colony
Legal system: based on English law and customary laws
indigenous to local tribes; constitution adopted April 1971;
highest court of appeal is the Sierra Leone Court of Appeals;
has not accepted compulsory ICJ jurisdiction
National holiday: National Day, 19 April
Branches: executive authority exercised by President;
parliament consists of 100 authorized seats, 85 of which are
filled by elected representatives of constituencies and 12 by
Paramount Chiefs elected by fellow Paramount Chiefs in
each district; President authorized to appoint four members,
of which two, currently, are filled by the heads of the Army
and the Police independent judiciary
Government leader: Siaka Stevens, President, heads APC
government composed of members of his political party
Suffrage: universal over age 21
Elections: the maximum life of an elected parliament is 5
years, but it may be dissolved earlier by the President;
parliamentary election held in May 1977; President is
elected by parliament for 5 year term; next presidential
election 1981
Political parties and leaders: All People’s Congress
(APC), headed by Stevens; Sierra Leone People’s Party
(SLPP) is the opposition party
Communists: no party, although there are a few
Communists and a slightly larger number of sympathizers
Member of: AFDB, AIOEC, Commonwealth, ECA,
ECOWAS, FAO, G-77, GATT, IAEA, IBA, IBRD, ICAO,
IDA, IFC, ILO, IMF, IPU, ITU, NAM, OAU, ULN.,
UNESCO, UPU, WHO, WMO
181
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SIERRA LEONE/SINGAPORE','d894057b59ba59adef2c7ce36e3016682754b05aa9fe470473ccabf40a524b25','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b24a1e4ebe4aabb6f68d12892ab4662d511095a1225409c40cfad36d90cc0222',1978,'SG','Singapore','government',490,'Legal name: Republic of Singapore
Type: republic within Commonwealth since separation
from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law; constitution
based on preindependence State of Singapore constitution;
legal education at University of Singapore; has not accepted
compulsory ICJ jurisdiction
National holiday: 9 August
Branches: ceremonial President; executive power exer-
cised by Prime Minister and cabinet responsible to unitary
legislature
Government leaders: President, Dr. Benjamin Sheares;
Prime Minister, Lee Kuan Yew
Suffrage: universal over age 20; voting compulsory
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SINGAPORE/SOLOMON ISLANDS
Elections: normally every 5 years
Political parties and leaders: government—People’s
Action Party (PAP), Lee Kuan Yew; opposition—Barisan
Sosialis Party (BSP), Dr. Lee Siew Choh; Workers’ Party, J.
B. Jeyaretnam; Communist Party illegal
Voting strength (1976 election): PAP won all 69 seats in
Parliament and received 72.4% of vote; remaining 27.6% to
four opposition parties
Communists: 200-500; Barisan Sosialis Party infiltrated
by Communists
Member of: ADB, ANRPC, ASEAN, Colombo Plan, G-77,
GATT, IBRD, ICAO, IFC, THO, ILO, IMCO, IMF, IPU,
ISO, ITU, NAM, UN., UNESCO, UPU, WHO, WMO','89679346d7d5ae03a68ce3a8e40781c40f709d814dd1c44c993fcae0c9d37e20','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b2e388d386de576be713585469475f68fee2639eb6e768e5ada31c523cc46d3',1978,'SB','Solomon Islands','government',493,'Legal name: Solomon Islands
Type: British protectorate administered as crown colony,
became self-governing January 1976, slated for indepen-
dence July 1978
183
CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SOLOMON ISLANDS/SOMALIA
Capital: Honiara
Political subdivisions: 4 administrative districts
Legal system: a High Court plus Magistrates Courts, also a
system of native courts throughout the islands
Branches: executive authority in High Commissioner; a
legislative assembly of 38 members
Government leaders: Governor Colin H. Allan, and Chief
Minister Kenilorea
Suffrage: universal age 21 and over
Elections: every 4 years, latest June 1976
Political parties and leaders: no real political parties,
groupings of independents
Member of: ADB','f6b4bd5040bd3a6f42ef590e3d67d96974e9829b1d9bc55a8f7be55765a2d9fa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7226746ed1b8ba0accd86ac26ca5d3e49a069303780512c639bdbfe6d35b353d',1978,'SO','Somalia','government',497,'Legal name: Somali Democratic Republic
Type: republic
Capital: Mogadiscio
National holiday: 21 October
Political subdivisions: 16 regions, 60 districts
Organization: the Somali Revolutionary Socialist Party,
created on July 1, 1976, has become the new executive body
in the country; party has 74-man central committee and
5-man politburo headed by President Siad
Government leader: President and Prime Minister, Gen.
Mohamed Siad Barre
Communists: possibly some Communist sympathizers in
the government hierarchy
Member of: AFDB, ARAB LEAGUE, EAMA, FAO, G-
77, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, NAM, OAU,
U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
arc oA ——
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SOMALIA/SOUTH AFRICA','9507476a20062cddc83fac71c81ec21350979d8470e85b2b2bb97bb59f5cf78e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84400b6ea12f456a4535b535154285c1446e7b6b2308a96616331c4f51fe7bf9',1978,'ZA','South Africa','government',501,'Legal name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape Town;
judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by
centrally appointed administrator; provincial councils, elect-
ed by white electorate, retain limited powers
Legal system: based on Roman-Dutch law and English
common law; constitution enacted 1961, changing the Union
of South Africa into a Republic; possibility of judicial review
of Acts of Parliament concerning dual official languages;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Republic Day, 31 May
185
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Branches: President as formal chief of state; Prime
Minister as head of government: Cabinet responsible to
bicameral legislature; lower house elected directly by white
electorate; upper house indirectly elected and appointed;
judiciary maintains substantial independence of government
influence
Government leader: Prime Minister Balthazar Johannes
Vorster
Suffrage: general suffrage limited to whites over 18 (17 in
Natal Province)
Elections: must be held at least every 5 years; last
elections 830 November 1977
Political parties and leaders: National Party, B. J.
Vorster, P. W. Botha, C. Mulder, R. F. Botha; Progessive
Federal Party, Colin Eglin, Ray Swart, Helen Suzman; New
Republic Party, Radclyffe Cadman; South Africa Party,
Myburgh Streicher; Herstigte Nasionale Party, J. Marais
Voting strength: (1977 general elections) parliamentary
seats: 184 National Party, 17 Progressive Federal Party, 10
New Republic Party, 3 South Africa Party
Communists: small Communist Party illegal since 1950;
party in exile maintains headquarters in London; Dr. Yasuf
Dadoo, Moses Kotane, Joe Slovo
Other political groups: (insurgent groups in exile) African
National Congress (ANC), Oliver Tambo; Pan-Africanist
Congress (PAC), leadership in dispute
Member of: GATT, IAEA, IBRD, ICAO, IDA, IFC, IHO,
International Lead and Zinc Study Group, IMF, ISO, ITU,
IWC—International Whaling Commission, IWC—Interna-
tional Wheat Council, U.N., UPU, WHO, WIPO, WMO,
WSG
Legal name: Republic of Transkei
Type: republic
Capital: Umtata
Political subdivisions: 28 administrative districts
Legal system: based on English common law and African
customary law; decisions of Transkei Supreme Court can be
appealed to South African Supreme Court
Branches: President is formal chief of state; Prime
Minister is head of government, Cabinet responsible to
National Assembly, which has 75 seats for hereditary tribal
chiefs and 75 seats for popularly elected members
Government leader: Prime Minister Kaiser Matanzima
Suffrage: Transkeian citizens over 21 years of age
Elections: must be held at least every 5 years; last general
election October 1976
Political parties and leaders: Transkei National Inde-
pendence Party, Chief Kaiser Matanzima; Transkei People’s
Freedom Party, Cromwell Diko; Democratic Party, Hector
Neokazi; New Democratic Party, Knowledge Guzana
Voting strength: (1976 general election) National Assem-
bly seats; 142 Transkei National Independence Party, 4
Approved For Release 2005/04/22
Transkei People’s Freedom Party, 2 Democratic Party, 2
New Democratic Party
Communists: no Communist Party','9274f64e7a52783c4bdf9b2435c7775841e6a2cf34b41faec3f223a2f576cace','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d55f0e87ae23fa72aa98296a526be4a986303e878b5bdf143c162088a5dee88',1978,'ES','Spain','government',505,'Legal name: Spanish State
Type: a monarchy in the process of replacing the
authoritarian regime of the late Generalissimo Franco with a
modified Western-style parliamentary system; Juan Carlos
proclaimed King, on November 22, 1975
Capital: Madrid
Political subdivisions: metropolitan Spain, including the
Canaries and Balearics, divided into 50 provinces with
Sovernors appointed by the central government; also 5 places
of sovereignty (presidios) on the Mediterranean coast of
Morocco; transferred administration of Spanish Sahara to
Morocco and Mauritania on February 26, 1976
Legal system: civil law system, with regional applications
of customary law; the 7 basic laws of the Franco era
Constitution were greatly modified by the constitutional law
for political reform of December 1976 providing for a
freely-elected parliament to draw up a new constitution;
judges decide cases, no jury system; does not accept
compulsory ICJ jurisdiction
National holiday: 12 October
Branches: executive, with King’s acts subject to counter-
signature, Prime Minister appointed for 5-year term by the
King from 3 names submitted by King’s advisory Council of
the Realm, may be removed by the King with consent of the
188
Council; not legally responsible to the parliament; legislative
with new bicameral Cortes elected on June 15, 1977 likely to
adjust the executive-legislative relationship through its
consituent power; the more powerful Chamber has 350
members chosen by proportional representation, and the
Senate has 248 members (207 directly elected and 4]
appointed by the King); judicial, independent in principle
but generally limited to interpretation of laws
Government leaders: King Juan Carlos I—Chief of State,
and Commander in Chief of the armed forces; and Prime
Minister Adolfo Suarez Gonzalez
Suffrage: universal in national referendums, over age 21
and in parliamentary elections, beginning in June 1977
Elections: free parliamentary elections in June 1977 for 4-
year term; postponed local elections likely to be delayed
until fall 1978 or early 1979
Political parties and leaders: Under the revised law on
political parties of February 1977 over 150 parties were
legalized by the time of the parliamentary election in June
and others have been approved after the election. Most of
the prominent semiclandestine parties of the Franco era
have been legalized, including the Spanish Communist Party
(PCE). Franco’s National Movement was dissolved in April.
In view of the multiplicity of parties, a number of
electoral coalitions were formed. The Principal national
coalitions and parties from right to left are: the Popular
Alliance (AP)—the conservative coalition led by ex-minister
Center (UCD)—a centrist coalition of 15 reform-minded
parties backing Prime Minister Suarez—includes ex-minis-
ters Calvo-Sotelo and Cabanillas, Social Democrat Fernan-
dez-Ordonez, Liberal Democrat Garrigues Walker, and
Christian Democrat Alvarez de Miranda. Suarez formally
forged the coalition into a single party on 4 August 1977 but
continues to have problems getting the disparate groups to
pull together. The Spanish Socialist Workers Party (PSOE),
led by Felipe Gonzalez, is the major party of the democratic
left. A much smaller contender, the Popular Socialist Party
of Enrique Tierno Galvan merged with the PSOE in May
1978. The Spanish Communist Party (PCE), led by Santiago
Carrillo, and its several regional branches espouse Eurocom-
munism. There are also several Basque and Catalan regional
parties of mixed orientation which are united by their goal
of greater regional autonomy,
Voting strength: (1977 parliamentary election) UCD
polled 84% of votes and received 165 chamber seats (47.1%),
11 seats short of a majority; the PSOE polled 28.5% and
received 118 seats (34%); the PCE polled 9.2% and received
20 seats (5.7%); the AP polled 8.2% and received 16 seats: the
PSP polled 4.3% and received 6 seats; the various Basque
and Catalan regional parties received 20 seats.
06-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A0009000100
et sor
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
SPAIN/SRI LANKA
Communists: PCE claims to have 200,000 members, but
this figure is difficult to verify; the PCE’s greatest strength is
in labor where it dominates the country’s strongest trade
union, the Workers Commissions, which has a membership
estimated around 1 million.
Other political or pressure groups: on the extreme left,
the illegal Basque Fatherland and Liberty (ETA) and the
Anti-Fascist and Patriotic Revolutionary Front (FRAP) use
terrcrism to oppose the government; on the extreme right,
the Guerrillas of Christ the King carry out vigilante attacks
on ETA members and other leftists; free labor unions
(authorized in April 1977) include the Communist-domi-
nated Workers Commissions; the Socialist General Union of
Workers (UGT), and the independent Workers Syndical
Union (USO); the Catholic Church; business and land
owning interests, Opus Dei; Catholic Action; university
students
Member of: ASSIMER, ESRO, FAO, GATT, TAFA,
IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC, THO, ILO,
International Lead and Zinc Study Group, IMCO, IMF,
IOOC, IPU, ITC, ITU, {WC—lInternational Wheat Council,
OAS (observer), OECD, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG; applied for full membership in the EC
28 July 1977; invited to join Council of Europe 18 October
1977','2d34c5df301c92c20bd0183c73303dcb6c6f27c2a2db9fdf22dfcc9d3999be6e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbd7417e31ed620e0a9b14588be0831c596b68e6173edeb2c17eb88d0fa7b1a4',1978,'LK','Sri Lanka','government',508,'Legal name: Republic of Sri Lanka
Type: independent state since 1948
Capital: Colombo
Political subdivisions; 9 provinces, 22 administrative
districts, and four categories of semiautonomous elected
local governments
Legal system: a highly complex mixture of English
common law, Roman-Dutch, Muslim and customary law;
new constitution 22 May 1972; no judicial review of
legislative acts; legal education at Sri Lanka Law College
and University of Sri Lanka, Peradeniya: has not accepted
compulsory IC] jurisdiction
190
National holiday: Independence Day, 22 May
Branches: A constitutional amendment promulgated on |
January 1978 established a strong presidential form of
government under J. R. Jayewardene, who became Prime
Minister following his party''s election victory in July 1977.
Jayewardene will remain president until 1983, regardless of
whether parliament is dissolved and subsequent parliamen-
tary elections are held. When his term in office expires, a
new president will be chosen by a direct national election for
a six year term.
Government leader: President J. R. Jayewardene
Suffrage: universal over age 18, but most Indian Tamils,
who comprise 10.6% of population, are not enfranchised
Elections: national elections, ordinarily held every 6
years; must be held more frequently if government loses
confidence vote; last election held July 1977
Political parties and leaders: Sri Lanka Freedom Party,
Sirimavo Ratwatte Dias Bandaranaike, President; Lanka
Sama Samaja Party (Trotskyite), N. M. Perera, President:
Tamil United Liberation Front, A. Amirthalingam leader;
United National Party, J. R. Jayewardene; Communist
Party/ Moscow, Pieter Keuneman, General Secretary; Com-
munist Party/Peking, N., Shanmugathasan, General Secre-
tary; Mahajana Eksath Peramuna (People’s United Front),
M. B. Ratnayaka, President
Voting strength (1977 election): 30% Sri Lanka F reedom
Party, 51% United National Party, 3.9% Lanka Sama Samaja
Party, 1.8% Communist Party/Moscow, 6.5% TULF minor
parties and independents accounted for remainder
Communists: approximately 107,000 voted for the
Communist Party in the July 1977 general election;
Communist Party /Moscow approximately 5,000 members
(1975), Communist Party/Peking 1,000 members (1970 est.)
Other political or pressure groups: Buddhist clergy,
Sinhalese Buddhist lay groups; far-left violent revolutionary
groups; labor unions
Member of: ADB, ANRPC, Colombo Plan, Common-
wealth, FAO, G-77, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMCO, IMF, IPU, NAM, U.N., UNESCO, UPU, WHO,
WMO','03b1f314c592d759dc53e1df412e058e038ab3bd63e64ad9290b329080797178','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('703ca577c2aca4dfc019e96ce22b3d12afc87fbe8ce7804b6fea22375832ccf9',1978,'SD','Sudan','government',512,'Legal name: Democratic Republic of the Sudan
Type: republic under military control since coup in May
1969
Capital: Khartoum
Political subdivisions: 18 provinces, provincial and local
administrations controlled by central government; limited
regional autonomy in 6 southern provinces
Legal system: based on English common law and Islamic
law; some separate religious courts, permanent constitution
promulgated April 1973; legal education at University of
Khartoum and Khartoum extension of Cairo University at
Khartoum; accepts compulsory ICJ jurisdiction, with
reservations
National holiday: Independence Day, 1 January
Government leader: President Ja’far al-Numayri
Suffrage: universal adult
Elections: elections for National People’s Assembly and
Southern Regional People’s Assembly held in February 1978;
most recent Presidential election held April 1977 with
Numayri as sole candidate
Political parties and leaders: all parliamentary political
parties outlawed since May 1969; the ban on the Sudan
Communist Party was not enforced until after abortive coup
in July 1971; the government’s mass political organization,
the Sudan Socialist Union, was formed in January 1972
191
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SUDAN/SURINAM
Communists: party decimated following July 1971 coup
and counter-coup, several top leaders executed; actual
hard-core membership down to lowest point in years; party
control over labor unions, professional groups and universi ty
student groups ended; Communists purged from govern-
ment; party is being reorganized underground under
leadership of Secretary-General Muhammad Nujud, 3,500
CP members
Other political or pressure sroups: Muslim Brotherhood;
Ansar Muslim sect, at odds with the military regime since
the May coup, are being reintegrated into national political
life; members of opposition National Front, composed of
former political party elements and other disgruntled
conservative interests, agreed to disband and join national
reconciliation efforts in April 1978
Member of: AFDB, APC, Arab League, FAO, G-77,
IAEA, IBRD, ICAC, ICAO, IDA, IFC, ILO, IMF, ITU,
NAM, OAU, U.N., UNESCO, UPU, WHO, WIPO, WMO
Legal name: Republic of Surinam
Type: Parliamentary Democracy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by District
Commissioner responsible to Minister of District government
and Decentralization except for Paramaribo, whose commis-
sioner is responsible to Minister of Home Affairs
Legal system: Dutch civil law system; constitution
adopted November 1975
National holiday: Independence Day, 25 November
Branches: President (Chief of State) elected by Parlia-
ment for five-year term; Council of Ministers headed by a
Prime Minister constitutes the Cabinet; 39-member Parlia-
ment popularly elected for 4-year term; court system
administered by Attorney-General under Minister of Justice
and Police
Government leaders: President, Johan H. E. Ferrier;
Prime Minister, Henck A. E. Arron
Suffrage: universal over age 21
Elections: every 4 years or earlier upon request of Prime
Minister; latest held October 1977 won by National Party
Combination (NPK), a creole-based election coalition in
which the National Party of Surinam (NPS) is the largest
party
Political parties and leaders: National Party of Surinam
(NPS), Henck A. E. Arron; Nationalist Republic Party
(PNR), Edward Bruma (principal leftist party); Progressive
Reform Party (VHP), J. Lachmon; Pendawa Lima, 5S.
Somohardijo; Javanese Farmers’ Party (KTPI), Willy Soe-
mita; Progressive Surinam People’s Party (PSV), Emile
Wijntuin; Reformed Progressive Party (HPP), Pannalal
Parmessar
Voting strength (1977): NPK 22 seats, Opposition United
Democratic Parties Combination (VDP) 17 seats
Communists: (all small groups) Democratic Peoples
Front, Communist Party of Surinam (KPS)
Member of: EC (associate), ECLA, IBA, ILO, ITU, OAS,
U.N., UNESCO, UPU, WIPO, WMO
Legal name: Kingdom of Swaziland
Type: monarchy, under King Sobhuza II; independent
member of Commonwealth since September 1968
of wage earners are
Capital: Mbabane (administrative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-Dutch law
in statutory courts, Swazi traditional law and custom in
traditional courts; legal education at University of Botswana
and Swaziland; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 6 September
Branches: in April 1973 King abolished the constitution,
dismissed parliament, and assumed personal rule; he has
ruled under a King-in-Council arrangement with the cabinet
being retained as an advisory council: a constitutional
commission submitted recommendations in June 1975, but
King has not authorized further action toward a new
constitution
Government leaders: Head of State King Sobhuza II;
Prime Minister Maphevu Dlamini
Suffrage: universal for adults
Elections: first elections for Legislative Council held in
June 1964; latest for House of Assembly in May 1972
194
Political parties and leaders: Imbokodvo, the traditional-
ist party, controlled by King Sobhuza II; the opposition
Ngwane National Liberatory Congress (NNLGC), led by Dr.
Ambrose Zwane, has been dissolved
Voting strength: in 1972 elections, Imbokodvo won 2]
seats, NNLC won 3 seats in the House of Assembly
Communists: no Communist Party
Member of: AFDB, FAO, G-77, GATT (de facto), IBRD,
ICAO, IDA, IFC, ILO, IMF, ISO, ITU, NAM, OAU, UN.,
UPU, WHO','111735e1cf5d0d8840e6680e974345f515468bc1b158e73975a3d017d4853e06','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00ce9111449f587d95b6d973a4adf822252bd2f0d8090bb7be1a1c6941052dba',1978,'SE','Sweden','government',516,'Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces, 624 communes, 224
towns
Legal system: civil law system influenced by customary
law; Acts of 1809, 1810, 1866, and 1949 serve as constitution;
legal education at Universities of Lund, Stockholm, and
Uppsala; accepts compulsory ICJ jurisdiction, with reser-
vations
National holiday: Birthday of the King, 30 April
Branches: legislative authority rests with parliament
(Riksdag); executive power vested in cabinet, responsible to
parliament; Supreme Court, 6 superior courts, 108 lower
courts
Government leaders: King Carl XVI Gustaf; Prime
Minister Thorbjorn Falldin
Suffrage: universal, but not compulsory, over age 20
Elections: every 3 years (next in September 1979)
Political parties and leaders: Moderate Coalition (con-
servative), Gosta Bohman; Center, Thorbjorn Falldin;
Liberal, Ola Ullsten; Social Democratic, Olof Palme; Left
Party Communist, Lars Werner; Swedish Communist Party,
Roland Petersson; Swedish Workers’ Party, Rolf Hagel;
Communist League of Marxist Leninists-Revolutionary
(KFML-R), Frank Baude
Voting strength (1976 election): 15.6% Moderate Coali-
tion, 24.1% Center, 11.0% Liberal, 42.9% Social Democratic,
4.7% Communist, 1.7% other
Communists: 17,000; a number of sympathizers as
indicated by the 257,967 Communist votes cast in 1978
elections; an additional 17,274 votes cast for Maoist KFML
Member of: ADB, Council of Europe, DAC, EC (Free
Trade Agreement), EFTA, ESRO, FAO, GATT, JAEA,
IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC, THO, ILO,
International Lead and Zinc Study Group, IMCO, IMF, IPU,
ISO, ITU, IWC—TInternational Whaling Commission,
{WC—International Wheat Council, Nordic Council,
OECD, U.N., UNESCO, UPU, WHO, WIPO, WMO, WSG','b20509defb2129e8c552aa5e76d69baeed3c7fa73efe71e79904636fd3b921f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afa363b929587d854c4b44a58f36b3ffbeb406bf61d5be727c92abf30a9683a3',1978,'CH','Switzerland','government',520,'Legal name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 22 cantons (8 divided into half
cantons); a local referendum held in Bern Canton in 1975
indicated that three districts wished to form a separate
canton for a portion of the French-speaking Jura region
Legal system: civil law system influenced by customary
law; constitution adopted 1874, amended since; judicial
review of legislative acts, except with respect to Federal
decrees of general obligatory character; legal education at
Universities of Bern, Geneva and Lausanne, and four other
university schools of law; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: 1 August
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
SWITZERLAND/SYRIA
Branches: bicameral parliament has legislative authority;
federal council (Bundesrat) has executive authority; justice
left chiefly to cantons
Government leader: Kurt Furgler (1-year term as
President began on January 1977), President
Suffrage: universal over age 20
Elections: held every 4 years; next elections 1978
Political parties and leaders: Social Democratic Party
(SPS), Arthur Schmid, president; Radical Democratic Party
(FDP), Henri Schmitt, president; Christian Conservative
People’s Party (CVP), Franz J osef Kurmann, president; Swiss
People’s Party (SVP), Hans Conzett, president; Communist
Party (PdA), Jean Vincent, leading Secretariat member;
National Action Party (N.A.), James Schwarzenbach
Voting strength (1975 election): 22.2% FDP, 20.6% CVP,
25.4% SPS, 10.2% BGB, 2.2% PdA, 2.5% N.A., 3.0% Rep,
6.2% LAU, 2.8% Lidus, 2.0% EvP, 1.3% POSH, 2.2% other
- Communists: less than 60,000 votes in 1975 election
Other parties: Landesring (LdU); Republican Movement
(Rep); Liberal Democratic Union (Lidus); Evangelical Party
(EvP); Maoist Party (POSH/PSA)
Member of: ADB, Council of Europe, DAC, EFTA,
ELDO (observer), ESRO, FAO, GATT, IAEA, ICAC, ICAO,
IEA, ILO, IMCO, IPU, ITU, IWC—lInternational Wheat
Council, OECD, U.N. (permanent observer), UNESCO,
UPU, WCL, WHO, WIPO, WMO, WSG
Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime since
March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of Damascus
administered as separate unit
Legal system: based on Islamic law and civil law system;
special religious courts; constitution promulgated in 1978,
legal education at Damascus University and University of
Aleppo; has not accepted compulsory IC] jurisdiction
National holiday: Independence Day, 17 April
Branches: executive powers vested in President and
Council of Ministers; legislative power rests in the People’s
Assembly; seat of power is the Ba’th Party Regional (Syrian)
Command
Government leader: President Hafiz Al-Asad
Suffrage: universal at age 18
Elections: People’s Assembly election August 1977;
Presidential election February 1978
Political parties and leaders: ruling party is the Arab
Socialist Resurrectionist (Ba’th) Party; the “national front”
cabinet is dominated by Ba’thists, but includes independents
and members of the Syrian Arab Socialist Party (ASP), Arab
Socialist Union (ASU), and Syrian Communist Party (SCP)
198
Communists: mostly sympathizers, numbering about
5,000
Other political or pressure groups: non-Ba’th parties
have little effective political influence; Communist Party
ineffective; greatest threat to Ba’thist regime lies in
factionalism in Ba’th Party itself; ‘conservative religious
leaders
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, 1OOC, IPU, ITU,
[WC—International Wheat Council, NAM, OAPEC, U.N.,
UNESCO, UPU, WFTU, WHO, WMO, WSG
Legal name: United Republic of Tanzania
Type: republic; single party on the mainland and on
Zanzibar
Capital: Dar es Salaam
Political subdivisions: 25 regions—20 on mainland, 5 on
Zanzibar islands
Legal system: based on English common law, Islamic law,
customary law, and German civil law system; permanent
constitution adopted 1977, replaced interim constitution
adopted 1965; judicial review of legislative acts limited to
matters of interpretation; legal education at University of
Dar es Salaam; has not accepted compulsory ICJ jurisdiction
National holiday: “Union Day,” 26 April
Branches: President Julius Nyerere has full executive
authority on the mainland; National Assembly dominated by
Nyerere and the Chama Cha Mapinduzi (Revolutionary
Party); National Assembly consists of 233 members, 72 from
Zanzibar, of which 10 are directly elected, 65 appointed
from the mainland, plus 96 directly elected from the
mainland; new constitution calls for popular election of some
members from Zanzibar; Vice President Aboud Jumbe
(President of Zanzibar) and the Revolutionary Council still
run Zanzibar despite the efforts of Nyerere to integrate the
islands into the political system of the mainland
Government leader: President Julius Nyerere
Suffrage: universal adult
Political party and leaders: Chama Cha Mapinduzi
(Revolutionary Party), only political party, dominated by
Nyerere and Vice President J umbe, his top lieutenant; party
was formed in 1977 as a result of the union of the
Tanganyika African National Union, the sole mainland
party, and the Afro-Shirazi Party, the only party in
Zanzibar; party union was part of effort by Nyerere to
integrate Zanzibar and mainland
Voting strength (October 1975 national elections): over 5
million registered voters; Nyerere received 95% of about 4
million votes cast; general parliamentary elections scheduled
for Fall of 1980
Communists: a few Communist sympathizers, especially
on Zanzibar
Member of: AFDB, Commonwealth, EAC, FAO, G-77,
GATT, IBRD, ICAC, ICAO, IDA, IFC, ILO, IMF, ITU,
NAM, OAU, U.N., UNESCO, UPU, WHO, WMO','d5cf01ebee770731543adff06b3873de593d9f6c1af6b43cc94e353c7b7319d9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dc163b2d8ea3ec5b41089c439a7d3e319b6881ef5c5ba47cceda9f1de13fa26',1978,'TH','Thailand','government',524,'Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 71 centrally controlled provinces
Legal system: based on civil law system, with influences
of common law; new constitution being drafted; legal
education at Thammasat University; has not accepted
compulsory ICJ jurisdiction
National holiday: National Day, 5 December
Branches: King is head of state with nominal powers;
civilian government suspended on 20 October 1977; military
staffed Revolutionary Party governing in interim pending
drafting of new constitution; judiciary relatively indepen-
dent except in important political subversive cases
Government leaders: King Phumiphon Adundet, Prime
Minister General Kriangsak Chamanan
Elections: suspended
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
THAILAND/TOGO
Political parties: suspended
Communists: strength of illegal Communist Party is about
1,200; Thai Communist insurgents throughout Thailand total
about 9,400
Member of: ADB, ANRPC, ASEAN, ASPAC, Colombo
Plan, ESCAP, FAO, G-77, IAEA, IBRD, ICAO, IDA, IFC,
IHO, ILO, IMF, IPU, ITC, ITU, SEAMES, U.N., UNESCO,
UPU, WHO, WMO','1b577a30d44e346192a813dead3b757c8455c581d325b71df56f82217d448ae8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af77f242a99c4107a3209bef3a9cd3ab3c007008b8430526665bae3260e9115a',1978,'TG','Togo','government',528,'Legal name: Republic of Togo
Type: republic; under military rule since January 1967
Capital: Lome
Political subdivisions: 2] circumscriptions
Legal system: based on French civil law and customary
practice; no constitution; has not accepted compulsory IC]
jurisdiction
National holiday: Independence Day, 27 April
Branches: military government, with civilian-dominated
cabinet, took over on 14 April 1967, replacing provisional
government created after January coup; no legislature;
separate judiciary including State Security Court established
1970
Government leader: General Gnassingbé Eyadéma, Presi-
dent, Minister of National Defense, and Armed Forces Chief
of Staff
Suffrage: universal adult
Elections: presidential referendum of January 1972
elected Gen. Eyadéma for indefinite period
Political party: single party formed by President Fya-
déma in September 1969, Rassemblement du Peuple
Togolais, structure and staffing of party closely controlled by
Communists:
sympathizers
Member of: AFDB, CEAO (observer), EAMA, ECA,
ECOWAS, ENTENTE, FAO, G-77, GATT, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, NAM, OAU, OCAM, U.N.,
UNESCO, UPU, WHO, WIPO, WMO','e03de56dda7f183cdce1bfd83507b60a22e63d9d0eaede405509a1c970cee709','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f12f7976596a8c2c66524c1068954cb431d3561355202a7a462182503c3fb714',1978,'TO','Tonga','government',532,'Legal name: Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa
Political subdivisions: 8 main island groups (Tongatapu,
Haapi, Vavau)
Legal system: based on English law
Branches: Executive (King and Privy Council); Legisla-
tive (Legislative Assembly composed of 7 nobles elected by
their peers, 7 elected representatives of the people, 8
Ministers of the Crown; the King appoints one of the 7
nobles to be the speaker); Judiciary (Supveme Court,
magistrate courts, Land Court)
Government leaders: King Taufa’ahau Tupou IV; Pre-
mier, Prince Tu’ipelehake (younger brother of the King)
Suffrage: granted to all literate adults over 21 years of age
who pay taxes
Elections: held every 3 years, last in April 1978
Communists: none known
Member of: ADB, Commonwealth','7d78d1c89b8f950a861777c130b139b0b3947d98d169b10f438889ce624b60c9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5529676e6fd2851e2f54b9840e55bf8897c7ddbb0b326073a214b5d9e9fb5577',1978,'TT','Trinidad and Tobago','government',536,'Legal name: Republic of Trinidad and Tobago
Type: independent state since August 1962; in August
1976 country officially became a republic severing legal ties
with British crown
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards, Tobago is
30th)
Legal system: based on English common law; constitution
came into effect 1976; judicial review of legislative acts in
the Supreme Court; has not accepted compulsory IC]
jurisdiction
National holiday: 31 August
Branches: legislative branch consists of 36-member
elected House of Representatives and 31-member appointed
Senate; executive is cabinet led by the Prime Minister;
judiciary is headed by the Chief Justice and includes a Court
of Appeal, High Court, and lower courts
Government leaders: Prime Minister Dr. Eric Williams,
President Ellis Clarke
Suffrage: universal over age 18
Elections: elections to be held at intervals of not more
than five years; last election held 13 September 1976
Political parties and leaders: People’s National Move-
ment (PNM), Dr. Eric Williams; United Labor Front (ULF),
Bosdeo Panday; Democratic Labor Party (DLP), Dr.
Romesh Mootoo; Democratic Action Congress (DAC),
Arthur Napoleon Raymond Robinson: West Indian National
Party (WINP), Ashford Sinanani; Tapia House Movement,
Lloyd Best
Voting strength (1976 election): 56% of registered voters
cast ballots; PNM captured 24 seats in House of Representa-
tives, ULF 10, and DAC the two Tobago seats
Communists: not significant
Other political pressure groups: National Joint Action
Congress (NJAC), radical anti-government Black-identity
organization; United Revolutionary Organization (URO),
Marxist amalgam; Trinidad and Tobago Peace Council,
leftist organization affiliated with the World Peace Council;
Trinidad and Tobago Chamber of Industry and Commerce;
204
Trinidad and Tobago Labor Congress, moderate labor
federation; Council of Progressive Trade Unions, radical
labor federation
Member of: CARICOM, Commonwealth, FAO, G-77,
GATT, IADB, IBRD, International Coffee Agreement,
ICAO, IDA, IDB, IFC, ILO, IMCO, IMF, ISO, ITU, IWC—
International Wheat Council, NAM, OAS, SELA, U.N.,
UNESCO, UPU, WHO, WMO
Legal name: Republic of Tunisia
Type: republic
Capital: Tunis
Political subdivisions: 17 governorates (provinces)
Legal system: based on French civil law system and
Islamic law; constitution patterned on Turkish and U.S.
constitutions adopted 1959, some judicial review of legisla-
tive acts in the Supreme Court in joint session; legal
education at Institute of Higher Studies and Ecole Super-
ieure de Droit of the University of Tunis; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 1 June
Branches: executive dominant, unicameral legislative
largely advisory; judicial, patterned on French system and
Koranic law
Government leaders: President Habib Bourguiba; Prime
Minister Hedi Nouira
Suffrage: universal over age 21
Elections: national elections held every 5 years; last
elections 2 November 1974
Political party and leader: Destourian Socialist Party,
Habib Bourguiba
Voting strength (1974 election): 100% Destourian Social-
ist Party
Communists: a small number of nominal Communists,
mostly students; Tunisian Communist Party proscribed in
January 1963
Member of: AFDB, Arab League, AIOEC, EC (associ-
ation until 1974), FAO, G-77, IAEA, IBRD, ICAO, IDA,
IFC, ILO, International Lead and Zinc Study Group, IMCO,
IMF, IOOC, ITU, [WC —International Wheat Council,
NAM, OAU, U.N., UNESCO, UPU, WHO, WIPO, WMO','dfd8a7210d7fb0584740d01e0a9adb148d63c0876f3f67ddc45330189b63a530','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3931b8e519abd74a93953a82f38519360f25afc4ba43c422299fda569b8581c4',1978,'TV','Tuvalu','government',540,'Legal name: Tuvalu
Type: British crown colony with a large measure of
self-government: independence expected in October 1978
Capital: Funafuti
House of Assembly: eight members
Chief minister: Toalipi Lauti
Her Majesty’s Commissioner (Governor): Thomas Layng','5b6ec87ccce21d1c664961b4a323f1aa80ebfb86b960529ce698016b3aa59350','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbb3813821b3b4b73852593efda32e91685e9fc6a17103eecf53640f4ecf7b11',1978,'UG','Uganda','government',544,'Legal name: Republic of Uganda
Type: republic independent since October 1962
Capital: Kampala
Political subdivisions: 10 provinces and 34 districts
Legal system: based on English common law and
customary law; constitution adopted 1967; present govern-
ment rules despotically, has intimidated judicial officials and
has made constitution of no consequence; legal education at
Makerere University, Kampala; accepts compulsory ICJ
jurisdiction, with reservations
National holiday; Independence Day, 9 October
Branches: Gen. Amin rules by decree; assisted by Council
of Ministers and Defense Council, a group of military
officers
Government leader: Gen. Idi Amin, President for life
Suffrage: universal adult
Elections: none scheduled by military government
Political parties: none
Communists: possibly a few sympathizers
Member of: AFDB, Commonwealth, FAO, G-77, GATT,
IAFA, IBRD, ICAC, ICAO, IDA, IFC, ILO, IMF, ISO, ITU,
NAM, OAU, U.N., UNESCO, UPU, WHO, WIPO, WMO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, 20 autonomous
republics, 6 krays, 121 oblasts, and 8 autonomous oblasts
Legal system: civil law system as modified by Communist
legal theory; revised constitution adopted 1977; no judicial
review of legislative acts; legal education at 18 universities
and 4 law institutes; has not accepted compulsory ICJ
jurisdiction
National holiday: October Revolution Day, 7 November
Branches: Council of Ministers (executive), Supreme
Soviet (legislative), Supreme Court of U.S.S.R. (judicial)
Government leaders: Leonid I. Brezhnev, General
Secretary of the Central Committee of the Communist Party
and Chairman of the Presidium of the U.S.S.R. Supreme
Soviet; Aleksey N. Kosygin, Chairman of the Council of
Ministers
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every 5 years; 1,517 deputies
elected in 1974; 72.2% party members
Political party: Communist Party of the Soviet Union
(CPSU) only party permitted
Voting strength (1974 election): 153,237,112 persons over
18; allegedly 99.98% voted
Communists: over 16 million party members
Other political or pressure groups: Komsomol, trade
unions, and other organizations which facilitate Communist
control
209
0010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A00090
July 1978
U.S.S.R./UNITED ARAB EMIRATES
Member of: CEMA, Geneva Disarmament Conference,
TAFA, ICAC, ICAO, ICES, ILO, International Lead and
Zinc Study Group, IMCO, IPU, ISO, ITC, ITU, we
International Whaling Commission, IWC— International
Wheat Council, U. N., UNESCO, UPU, Warsaw Pact, WHO.
WIPO, WMO, Universal Copyright Convention','d888580c92bfb2e64ab39f665f6a4761dfc10a9bdefc286c5489379884f9cb73','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b24f56e1181645c5e4f0beaba4a7c74edba51f3cbac19277f6fbd48b7c3e176a',1978,'AE','United Arab Emirates','government',548,'Legal name: United Arab Emirates (composed of former
Trucial States)
Member states: Abu Dhabi; Ajman; Dubai; Fujairah; Ras
alKhaimah; Sharjah; Umm alQaiwain
Type: federation; constitution signed December 1971,
which delegated specified powers to the United Arab
Emirates central government and reserved other powers to
member shaykhdoms
Capital; Abu Dhabi
Legal system: secular codes are being introduced by the
U.AE. Government and in several member shaykhdoms;
Islamic law remains very influential
National holiday: 2 December
Branches: Supreme Council of Rulers (7 members), from
which a President and Vice President are elected; Prime
Minister and Council of Ministers; National Consultative
Council; federal Supreme Court
Government leaders: Shaykh Zayid of Abu Dhabi,
President; Shaykh Rashid of Dubai, Vice President; Shaykh
Maktum of Dubai, Prime Minister
Suffrage: none
Elections: none
Political or pressure groups: none; a few small clandes-
tine groups are active
Member of: Arab League, G-77, IBRD, ICAO, ILO, IMF,
NAM, OAPEC, OPEC, U.N., UNESCO, UPU, WHO,
WIPO','8fc54aab59d047bc091b7b1a6b89f3d5d0989da5f16f232251d021bd0d3fde55','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06c34cfa02899fc57b91566f54c4e5467e2259c7798ad9eeb9d79e7025291ef2',1978,'GB','United Kingdom','government',552,'Legal name: United Kingdom of Great Britain and
Northern Ireland
Type: constitutional monarchy
Capital; London
Political subdivisions: 635 parliamentary constituencies
Legal system: common law tradition with early Roman
and modern continental influences; no judicial review of
Acts of Parliament; accepts compulsory ICJ jurisdiction,
with reservations
National holiday: Celebration of Birthday of the Queen,
16 June
Branches: legislative authority resides in Parliament;
executive authority lies with collectively responsible cabinet
led by Prime Minister; House of Lords is supreme judicial
authority and highest court of appeal
Government leader: Prime Minister James Callaghan
Suffrage: universal over age 18
Elections: at discretion of Prime Minister, but must be
held before expiration of a 5-year electoral mandate: last
election 10 October 1974
Political parties and leaders: Conservative, Margaret
Thatcher; Labor, James Callaghan; Liberal, David Steel;
Communist, Gordan McLennan; Scottish National, William
Wolfe; Plaid Cymru, Phil Williams
Voting strength (1974 election): Conservative 277 seats
(35.9%); Labor 319 seats (39.3%): Liberal 13 seats (18.3%);
Scottish National 11 seats (2.8%); Plaid Cymru 3 seats (0.6%);
other 12 seats (3.2%)
Communists: 29,000
Other political or pressure groups: Trades Union
Congress, Confederation of British Industry, National
Farmers’ Union
212
Member of: ADB, CENTO, Colombo Plan, Council of
Europe, DAC, EC, EEC, ELDO, ESRO, EURATOM, FAO,
GATT, TAEA, IBRD, ICAC, ICAO, ICES, IDA, IEA, IFC,
THO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IOOC, IPU, ISO, ITC, ITU, IWC—Interna-
tional Whaling Commission, IWC—International Wheat
Council, NATO, OECD, UN., UNESCO, UPU, WEU,
WHO, WIPO, WMO, WSG
Legal name: Republic of Upper Volta
Type: republic; military regime in power since January
1966
Capital: Ouagadougou
Political subdivisions: 10 departments, composed of 44
cercles, headed by civilian prefects
Legal system: based on French civil law system and
customary law; constitution adopted 1970, suspended
February 1974; a national referendum on a draft constitu-
tion held in November 1977 and country to return to civilian
rule with legislative and presidential elections in 1978; has
not accepted compulsory ICJ jurisdiction
National holiday: Proclamation of the Republic, 11
December
Branches: President is an army officer; 57-man National
Assembly was elected 30 April 1978
Government leader: Gen. Sangoule Lamizana, President
and Prime Minister
Suffrage: universal for adults
Elections: Parliamentary elections held on 30 April 1978
and Presidential elections on 14 May
Political parties and leaders: 3 parties elected to seats in
the National Assembly: Voltan Democratic Union (UDV)
holds the majority of seats; National Union for the Defense
of Democracy (UNDD); Voltan Progressive Union (UPV)
Communists: no Communist party; some sympathizers
Other political or pressure groups: labor organizations
are badly splintered, students and teachers occasionally
strike
Member of: AFDB, CEAO, EAMA, ECA, EIB (associate),
Entente, FAO, G-77, IBRD, ICAO, IDA, ILO, IMF, IPU,
ITU, NAM, Niger River Commission, OAU, OCAM, U.N.,
UNESCO, UPU, WCL, WHO, WIPO, WMO','c38af789f0d954e68337c8faa6731a84b9944d12eec53695fee23cb9beebd433','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdb8ca8f557181f0288d10214971af86cfdb08204caecacbd348648ef96d894e',1978,'UY','Uruguay','government',556,'Legal name: Oriental Republic of Uruguay
Type: republic, government under strong military
influence
Capital: Montevideo
Political subdivisions: 19 departments with limited
autonomy
Legal system: based on Spanish civil law system; new
constitution implemented 1967; judicial review of legislative
acts in Supreme Court; legal education at University of the
Republic at Montevideo; accepts compulsory ICJ jurisdiction
National holiday: Independence Day, 25 August
Branches: executive, headed by President; since 1978 the
military has had considerable influence in policymaking:
bicameral legislature (closed indefinitely by presidential
decree in June 1973), Council of State set up to act as
legislature; national judiciary headed by Supreme Court
President Aparicio Mendez
Government _ leader:
Manfredini
Suffrage: universal over age 18
Elections: projected for 1980
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
URUGUAY/VATICAN CITY
Political parties and leaders: political activities are
proscribed
Voting strength (1971 elections): 40.8% Colorado, 40.1%
Blanco, 18.6% Frente Amplio, 0.5% Radical Christian Union
Communists: 35,000-40,000 including Communist youth
group and sympathizers
Other political or pressure groups: Communist Party
(PCU), Rodney Arismendi (in exile in the US.S.B.);
Christian Democratic Party (PDC); Socialist Party of
Uruguay (PSU); Revolutionary Movement of Uruguay
(MRO) pro-Cuban Communist Party; National Liberation
Movement (MLN-Tupamaros) Marxist revolutionary terror-
ist group
Member of: FAO, G-77, GATT, IADB, IAEA, IBRD,
ICAO, IDB, IFC, ILO, IMCO, IMF, ITU, LAFTA, OAS,
SELA, U.N., UNESCO, UPU, WHO, WMO, WSG
Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St. Peter’s,
the Vatican Palace and Museum and neighboring buildings
covering more than 13 acres; 13 buildings in Rome, although
outside the boundaries, enjoy extraterritorial rights
Legal system: Canon law; constitutional laws of 1929
serve some of the functions of a constitution
National holiday: 30 June
Branches: the Pope possesses full executive, legislative,
and judicial powers; he delegates these powers to the
governor of Vatican City, who is subject to pontifical
appointment and recall; high Vatican offices include the
Secretariat of State, the College of Cardinals (chief papal
advisers), the Roman Curia (which carries on the central
administration of the Roman Catholic Church), the Presi-
dence of the Prefecture for the Economy, and the synod of
bishops (created in 1965)
Government leader: Supreme Pontiff, Paul VI (Giovanni
Battista Montini, born 26 September 1897, elected Pope 21
June 1963)
Suffrage: limited to cardinals less than 80 in age
Elections: Supreme Pontiff elected for life by College of
Cardinals
Communists: none known
Other political or pressure groups: none (exclusive of
influence exercised by other church officers in universal
Roman Catholic Church)
Member: IAEA, I[WC—International Wheat Council,
U.N. (permanent observer)
Legal name: Republic of Wenezuela
Type: republic
Capital: Caracas
Political subdivisions: 20 states, 1 federal district, 2
federal territories
Legal system: based on Spanish civil law system with
influence of U.S. law; constitution promulgated 1961,
judicial review of legislative acts in Cassation Court only;
dual court system, state and federal; legal education at
Central University of Venezuela; has not accepted compul-
sory IC] jurisdiction
National holiday: Independence Day, 5 July
Branches: executive (President), bicameral legislature,
judiciary
Government leader: President Carlos Andres Perez
Suffrage: universal and compulsory over age 18
Elections: every 5 years; next to be held December 1978
Political parties and leaders: Accion Democratica (AD),
Carlos Andres Perez, Luis Pinerva Ordaz, and Gonzalo
Barrios; Social Christian Party (COPEI), Rafael Caldera and
Luis Herrera Campins; People’s Electoral Movement (MEP),
Jesus Angel Paz Galarraga; Partido Comunista de Venezuela
(PCV), Secretary-General Jesus Faria; Movement to Social-
ism (MAS), Teodoro Petkoff and Pompey Marquez
Voting strength (1973 election): 49% AD, 37% COPETI,
5% New Force (MEP & PCV), 4% MAS, 3% URD, 2% others
Communists: 4,000-6,000 members (est.)
Other political or pressure groups: Fedecamaras (a
conservative business group); PRO VENEZUELA (leftist,
nationalist economic group); DESARROLLISTAS (group of
wealthy, independent businessmen led by former finance
minister Pedro Tinoco and historian Guillermo Moron)
Member of: Andean Pact, AIOEC, FAO, G-77, IADB,
IAEA, IBRD, ICAO, IDB, IFC, IHO, ILO, IMF, IPU, ITU,
IWC—International Wheat Council, LAFTA, NAMUCAR
(Caribbean Multinational Shipping Line—Naviera Multina-
cional del Caribe), OAS, OPEC, SELA, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Socialist Republic of Vietnam
Type: Communist state
Capital: Hanoi
Political subdivisions: 38 provinces
Legal system: based on Communist legal theory and
French civil law system
National holiday: 2 September
Branches: constitution provides for a National Assembly
and highly centralized executive nominally subordinate to it
218
Party and government leaders: Ton Duc Thang, Presi-
dent of DRV; Le Duan, Party Secretary General; Truong
Chinh, Chairman, Standing Committee of National Assem-
bly; Pham Van Dong, Premier; Vo Nguyen Giap, Minister of
National Defense; Nguyen Duy Trinh, Minister for Foreign
Affairs; Tran Quoc Hoan, Minister of Interior
Suffrage: over age 18
Elections: pro forma elections held for national and local
assemblies; lastest election for National Assembly held on
April 25, 1976
Political parties: National United Front, consisting of the
predominate Vietnam Communist Party, successor to the
Vietnam Workers Party and other _ political
organizations
Member of: ADB, Colombo Plan, ESCAP, FAO, G-77,
IBRD, ICAO, IMF, Mekong Committee, NAM, U.N. UNDP,
UNESCO, UNICEF, WHO, WIPO','efef3b1dc60e67a1595a2192a0dd5e8f0677abee8acbb1b74a22a14a0897fc7f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b67bcffbd1a888479f00515cbbc0f04c3b2d6f9c0b1808c3336bc8c917eb802e',1978,'WF','Wallis and Futuna','government',560,'Legal name: Territory of the Wallis and Futuna Islands
Type: overseas territory of France
Capital: Matu Utu
Political subdivisions: 3 districts
Branches: territorial assembly of 20 members; popular
election of one deputy to National Assembly in Paris, and
one Senator
Government leader: Superior Administrator Jacques de
Agostini
Suffrage: universal adult
Elections: every 5 years','983f2b4ced656a4158df34058700939ff5694f92ce203a98f92e0a68f07e1c36','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('296f40757d2ec5194df95343e5312f066f26fd6b22d5c525344df0178397fdea',1978,'EH','Western Sahara','government',564,'Type: legal status of territory and question of sovereignty
unresolved; territory partitioned between Morocco and
Mauritania in April 1976, with Morocco acquiring the
Northern two-thirds including the rich phosphate reserves at
Bu Craa; both countries have established political adminis-
tration within their own zones of influence; the line of
partition begins at a point on the coast where the Atlantic
Ocean intersects the 24th parallel, and extends in a
southeasterly direction to the point where the 23d parallel
intersects the 13th meridian
Legal name: Independent State of Western Samoa
Type: constitutional monarchy under native chief; special
treaty relationship with New Zealand
Capital: Apia
Legal system: based on English common law and local
customs; constitution came into effect upon independence in
1962; judicial review of legislative acts with respect to
fundamental rights of the citizen; has not accepted
compulsory IC] jurisdiction
National holiday: 1 January
Branches: Head of State and Executive Council; Legisla-
tive Assembly; Supreme Court, Court of Appeal, Land and
Titles Court, village courts
Government leaders: Head of State, Malietoa Tanumafili
Il, Prime Minister, Tupuola Efi
Suffrage: 45 Samoan members of Legislative Assembly
are elected by holders of matai (heads of family) titles (about
5,000); 2 European members are elected by universal adult
suffrage
Elections: held triennially, last in February 1976
Political parties and leaders: no clearly defined political
party structure
Communists: unknown
Member of: ADB, Commonwealth, ESCAP, G-77, IBRD,
IFC, IMF, U.N., WHO
Legal name: Pcople’s Democratic Republic of Yemen
Type: republic; power centered in ruling Unified National
Front Party
Capital: Aden; Madinat ash Sha’b, administrative capital
Political subdivisions: 6 provinces
221
: CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
YEMEN (ADEN)/YEMEN (SANA)
Legal system: based on Islamic law (for personal matters)
and English common law (for commercial matters); highest
judicial organ, Federal High Court, interprets constitution
and determines disputes between states
National holiday: 14 October
Branches: Presidential Council; cabinet; Supreme Peo-
ple’s Council
Government leaders: Chairman of Presidential Council,
Salim Rubayyi Ali; Prime Minister Ali Nasir Muhammed
al-Hasani; NF Secretary General Abd Al-Fattah Ismail
Suffrage: granted by constitution to all citizens 18 and
over
Elections: elections for legislative body, Supreme People’s
Council, called for in constitution; none have been held
Political parties and leaders: Unified National Front
(NF), the only legal party, is coalition of National Front,
Baath, and Communist parties
Communists: unknown number
Member of: Arab League, FAO, G-77, GATT (de facto),
IBRD, ICAO, IDA, ILO, IMF, ITU, NAM, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Yemen Arab Republic
Type: republic; military regime assumed power in June
1974
Capita]: Sana
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law, and
local customary law; first constitution promulgated
December 1970, suspended June 1974; has not accepted
compulsory ICJ jurisdiction
National holiday: Proclamation of the Republic, 26
September
Branches: Military Command Council, Prime Minister,
cabinet; People’s Assembly
Government leaders: Head of Military Command Coun-
cil, Lt. Col. Ahmad Ghashmi; Prime Minister Abd al-Aziz
Abd al-Ghani
Communists: small number
Political parties or pressure groups: Yemeni Union, a
small inactive government party formed in February 1973;
conservative tribal groups, some Muslim Brotherhood
followers, leftist sentiment represented by pro-Iraai Baath-
ists, Nasirists, small clandestine groups supported by Yemen
(Aden)
Member of: Arab League, FAO, G-77, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, NAM, U.N., UNESCO, UPU,
WHO, WMO
Legal name: Socialist Federal Republic of Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Political subdivisions: 6 republics with 2 autonomous
provinces (within the Republic of Serbia)
Legal system: mixture of civil law system and Communist
legal theory; constitution adopted 1974; legal education at
several law schools; has not accepted compulsory IC]
jurisdiction
National holiday: Proclamation of the Socialist Federal
Republic of Yugoslavia, 29 November
Branches: parliament (Federal Assembly) constitutionally
supreme; executive includes cabinet (Federal Executive
Council) and the federal administration; judiciary; the State
Presidency is a collective policymaking body composed of a
representative from each republic and province. Tito
presides as President of the Republic
Government leader: Josip Broz Tito, President of
Republic and President of League of Communists of
Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years by a
complicated, indirect system of voting
Political parties and leaders: League of Communists of
Yugoslavia (LCY) only; leaders are President Tito and
influential presidium members Edvard Kardelj, Vladimir
Bakaric, and Stane Dolanc
Communists: 1,629,082 party members (December 1977)
Other political or pressure groups: Socialist Alliance of
Working People of Yugoslavia (SAWPY), the major mass
front organization for the LCY; Confederation of Trade
Unions of Yugoslavia (CTUY), Union of Youth of Yugoslavia
(UYY), Federation of Yugoslav War Veterans (SUBNOR)
Member of: ASSIMER, CEMA (observer but participates
in certain commissions), EC (5-year non-preferential trade
agreement signed in May 1973 currently being renegoti-
ated), FAO, G-77, GATT, IAEA, IBA, IBRD, ICAC, ICAO,
IDA, IFC, IHO, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IPU, ITC, ITU, NAM, OECD
(participant in some activities), U.N., UNESCO, UPU,
WHO, WIPO, WMO
Legal name: Republic of Zaire (until October 1971 known
as Democratic Republic of the Congo)
Type: republic; constitution establishes strong presidential
system
Capital: Kinshasa
Political subdivisions: 8 regions and federal district of
Kinshasa
Legal system: based on Belgian civil law system and tribal
law; new constitution promulgated 1967, revised 1974; legal
education at National University of Zaire; has not accepted
compulsory IC) jurisdiction
National holiday: Independence Day, 30 June
Branches: president elected 1970 for seven-year term
limited to two five-year terms, thereafter; National Legisla-
tive Council of 210 members elected for five-year term; the
official party is the supreme political institution
Government leader: Lt. Gen. Mobutu Sese Seko,
President
Suffrage: universal and compulsory over age 18
Elections: presidential and legislative elections in October
and November 1970; elections for urban zone councils,
legislative council, and political bureau of sole political party
held in October 1977
Political parties and leaders: Mouvement Populaire de la
Revolution (MPR), only legal party, organized from above
Voting strength: MPR slate polled 96.3% of vote in 1970
elections
Communists: no Communist Party; U.S.S.R. and Peoples
Republic of China have diplomatic missions in Zaire
Member of: AFDB, APC, CIPEC, EAMA, EIB (associate),
FAO, G-77, GATT, IAEA, IBRD, ICAO, IDA, IFC, IHO,
ILO, IMF, IPU, ITC, ITU, NAM, OAU, OCAM, UDEAC,
U.N., UNESCO, UPU, WHO, WIPO, WMO','bfcdca2c4f34bd6b479403ec7da3676c6fd5d3e39bdc69925395ad43bd139184','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b30bee6896a8e68f526ca3a2a8217e37a3967c6053711b31900048e2b42e86a',1978,'US','United States','government',570,'Legal name: United States of America
Legal system: based on English common law; dual system
of courts, state and federal; constitution adopted 1789;
judicial review of legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Independence Day, 4 July
Voting strength (1976 presidential election): Democratic
Party (Carter), 40,829,000 (50.1%); Republican Party (Ford),
39,146,000 (48%); minor parties, 1,578,000 (preliminary
figures)
227
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
Approved For Release 2005/04/22 : CIA-RDP79-01051A000900010006-2
July 1978
Communists: party membership, 10,000-11,000 (est.);
General Secretary, Gus Hall
Member of: ADB, ANZUS, CENTO, Colombo Plan,
DAC, FAO, GATT, IADB, IAEA, IBRD, ICAC, ICAO,
ICES, IDA, IDB, IEA, IFC, THO, ILO, International Lead
and Zinc Study Group, IMCO, IMF, IPU, ITC, ITU, IWC—
International Whaling Commission, IWC—International
Wheat Council, NATO, OAS, OECD, U.N., UNESCO,
UPU, WHO, WIPO, WMO, WSC','7e065a59dab742aa740d639ea873d54cc61c4c394c59b2bf1a8432e61cca2049','internet-archive','cia-readingroom-document-cia-rdp79-01051a000900010006-2','txt','1827d91ff12c0c4b723652cb5d79040905cc85ee2fe4b231c6ea3bd081fb3826','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000900010006-2/cia-rdp79-01051a000900010006-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

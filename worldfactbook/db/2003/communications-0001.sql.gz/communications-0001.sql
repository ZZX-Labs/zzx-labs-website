SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b397b04c7aae34c09dc3f1b2b5ce505194a6dc7b8c7fca99d39ae3129f08abd2',2003,'ZW','Zimbabwe','communications',5,'Telephones - main lines in use
Telephones - mobile cellular
Internet users
This category deals with the means of exchanging information and
includes the telephone, radio, television, and Internet service
provider entries.
Communications - note
This entry includes miscellaneous communications information of
significance not included elsewhere.
Constitution
This entry includes the dates of adoption, revisions, and major
amendments.
Country data codes
see Data codes
Country map
Most versions of the Factbook provide a country map in color. The maps
were produced from the best information available at the time of
preparation. Names and/or boundaries may have changed subsequently.
Country name
This entry includes all forms of the country''s name approved by the US
Board on Geographic Names (Italy is used as an example): conventional
long form (Italian Republic), conventional short form (Italy), local
long form (Repubblica Italiana), local short form (Italia), former
(Kingdom of Italy), as well as the abbreviation. Also see the
Terminology note.
Currency
This entry identifies the national medium of exchange and its basic
subunit.
Crude oil
See "Oil" entries
Currency code
This entry gives the International Organization for Standardization
(ISO) 4217 alphabetic currency code for each country.
Data codes
This information is presented in Appendix D: Cross-Reference List of
Country Data Codes and Appendix E: Cross-Reference List of
Hydrographic Data Codes. This appendix includes the US Government
approved Federal Information Processing Standards (FIPS) codes, the
International Organization for Standardization (ISO) codes, and
Internet codes for land entities. The appendix also includes the
International Hydrographic Organization (IHO) codes, Aeronautical Chart
and Information Center (ACIC; now a part of the National Imagery and
Mapping Agency or NIMA) codes, and Defense Intelligence Agency (DIA)
codes for hydrographic entities. The US Government has not yet approved
a standard for hydrographic data codes similar to the FIPS 10-4
standard for country data codes.
Date of information
In general, information available as of 1 January 2003 was used in the
preparation of this edition.
Death rate
This entry gives the average annual number of deaths during a year per
1,000 population at midyear; also known as crude death rate. The death
rate, while only a rough indicator of the mortality situation in a
country, accurately indicates the current mortality impact on
population growth. This indicator is significantly affected by age
distribution, and most countries will eventually show a rise in the
overall death rate, in spite of continued decline in mortality at all
ages, as declining fertility results in an aging population.
Debt - external
This entry gives the total public and private debt owed to nonresidents
repayable in foreign currency, goods, or services.
Dependency status
This entry describes the formal relationship between a particular
nonindependent entity and an independent state.
Dependent areas
This entry contains an alphabetical listing of all nonindependent
entities associated in some way with a particular independent state.
Diplomatic representation
The US Government has diplomatic relations with 185 independent states,
including 183 of the 189 UN members (excluded UN members are Bhutan,
Cuba, Iran, Iraq, North Korea, and the US itself). In addition, the US
has diplomatic relations with 1 independent state that is not in the UN
- Holy See.
Diplomatic representation in the US
This entry includes the chief of mission, chancery, telephone, FAX,
consulate general locations, and consulate locations.
Diplomatic representation from the US
This entry includes the chief of mission, embassy address, mailing
address, telephone number, FAX number, branch office locations,
consulate general locations, and consulate locations.
Disputes - international
This entry includes a wide variety of situations that range from
traditional bilateral boundary disputes to unilateral claims of one
sort or another. Information regarding disputes over international
terrestrial and maritime boundaries has been reviewed by the US
Department of State. References to other situations involving borders
or frontiers may also be included, such as resource disputes,
geopolitical questions, or irredentist issues; however, inclusion does
not necessarily constitute official acceptance or recognition by the US
general assessment: system was once one of the best in
Africa, but now suffers from poor maintenance; more than 100,000
outstanding requests for connection despite an equally large number
of installed but unused main lines
domestic: consists of microwave radio relay links, open-wire lines,
radiotelephone communication stations, fixed wireless local loop
installations, and a substantial mobile cellular network; Internet
connection is available in Harare and planned for all major towns
and for some of the smaller ones
international: satellite earth stations - 2 Intelsat; two
international digital gateway exchanges (in Harare and Gweru)
This page was last updated on 18 December, 2003
======================================================================
@2125 Terrain
mostly high plateau with higher central plateau (high
veld); mountains in east
This page was last updated on 18 December, 2003
======================================================================
@2127 Total fertility rate (children born/woman)
3.66 children born/woman (2003 est.)
This page was last updated on 18 December, 2003
======================================================================
@2128 Government type
parliamentary democracy
This page was last updated on 18 December, 2003
======================================================================
@2129 Unemployment rate (%)
70% (2002 est.)
This page was last updated on 18 December, 2003
======================================================================
@2137 Military - note
conventional long form: Republic of Zimbabwe
conventional short form: Zimbabwe
former: Southern Rhodesia, Rhodesia
This page was last updated on 18 December, 2003
======================================================================
@2144 Location
Southern Africa, between South Africa and Zambia
This page was last updated on 18 December, 2003
======================================================================
@2145 Map references
Africa
This page was last updated on 18 December, 2003
======================================================================
@2146 Irrigated land (sq km)
1,170 sq km (1998 est.)
This page was last updated on 18 December, 2003
======================================================================
@2147 Area (sq km)
total: 390,580 sq km
land: 386,670 sq km
water: 3,910 sq km
This page was last updated on 18 December, 2003
======================================================================
@2149 Diplomatic representation in the US
chief of mission: Ambassador Simbi Veke MUBAKO
chancery: 1608 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 332-7100
FAX: [1] (202) 483-9326
This page was last updated on 18 December, 2003
======================================================================
@2150 Telephones - main lines in use
212,000 (in addition, there are about 20,000 fixed
telephones in wireless local loop connections) (1997)
This page was last updated on 18 December, 2003
======================================================================
@2151 Telephones - mobile cellular
111,000 (2001)
This page was last updated on 18 December, 2003
======================================================================
@2152 Internet Service Providers (ISPs)
6 (2000)
This page was last updated on 18 December, 2003
======================================================================
@2153 Internet users
100,000 (2002)
This page was last updated on 18 December, 2003
======================================================================
@2154 Internet country code
.zw
This page was last updated on 18 December, 2003
======================================================================
@2155 HIV/AIDS - adult prevalence rate (%)
33.7% (2001 est.)
This page was last updated on 18 December, 2003
======================================================================
@2156 HIV/AIDS - people living with HIV/AIDS
2.3 million (2001 est.)
This page was last updated on 18 December, 2003
======================================================================
@2157 HIV/AIDS - deaths
200,000 (2001 est.)
This page was last updated on 18 December, 2003
======================================================================
@2158 Currency code
ZWD
This page was last updated on 18 December, 2003
======================================================================
@2172 Distribution of family income - Gini index
50.1 (1995)
This page was last updated on 18 December, 2003
======================================================================
@2173 Oil - production (bbl/day)
0 bbl/day (2001 est.)
This page was last updated on 18 December, 2003
======================================================================
@2174 Oil - consumption (bbl/day)
23,000 bbl/day (2001 est.)
This page was last updated on 18 December, 2003
======================================================================
@2175 Oil - imports (bbl/day)
NA (2001)
This page was last updated on 18 December, 2003
======================================================================
@2176 Oil - exports (bbl/day)
NA (2001)
This page was last updated on 18 December, 2003
======================================================================
@2177 Median age (years)
total: 18.9 years
male: 18.9 years
female: 18.9 years (2002)
This page was last updated on 18 December, 2003
======================================================================
@2178 Oil - proved reserves (bbl)
subbureaus - (14) American Samoa, Anguilla, Bermuda, British Virgin
Islands, Cayman Islands, Gibraltar, Guam, Hong Kong, Macau, Montserrat,
Northern Mariana Islands, Puerto Rico, Turks and Caicos Islands, Virgin
Islands
International Development Association (IDA): established - 26 January
1960; effective - 24 September 1960
aim - to provide economic loans for low-income countries; UN
specialized agency and IBRD affiliate
members - (164)
Part I - (27 developed countries) Australia, Austria, Belgium, Canada,
Denmark, EU, Finland, France, Germany, Iceland, Ireland, Italy, Japan,
Kuwait, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South
Africa, Spain, Sweden, Switzerland, UAE, UK, US
Part II - (137 less developed countries) Afghanistan, Albania, Algeria,
Angola, Argentina, Armenia, Azerbaijan, Bangladesh, Barbados, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cyprus, Czech Republic, Djibouti, Dominica,
Dominican Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Georgia, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel, Jordan,
Kazakhstan, Kenya, Kiribati, South Korea, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Moldova, Mongolia, Morocco, Mozambique, Nepal, Nicaragua, Niger,
Nigeria, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Serbia and Montenegro, Sierra Leone, Slovakia,
Slovenia, Solomon Islands, Somalia, Sri Lanka, Sudan, Swaziland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Uganda, Uzbekistan, Vanuatu, Vietnam, Yemen, Zambia,
International Energy Agency (IEA): established - 15 November 1974
aim - to promote cooperation on energy matters, especially emergency
oil sharing and relations between oil consumers and oil producers;
established by the OECD
members - (26) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Portugal,
Spain, Sweden, Switzerland, Turkey, UK, US
International Federation of Red Cross and Red Crescent Societies
(IFRCS): note - formerly known as League of Red Cross and Red Crescent
Societies (LORCS)
established - 5 May 1919
aim - to organize, coordinate, and direct international relief actions;
to promote humanitarian activities; to represent and encourage the
development of National Societies; to bring help to victims of armed
conflicts, refugees, and displaced people; to reduce the vulnerability
of people through development programs
members - (179) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia
and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Taiwan,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members - (7 plus the Palestine Liberation Organization)
Comoros, Cook Islands, Eritrea, Israel, Kazakhstan, Federated States of
Micronesia, Tuvalu, Palestine Liberation Organization
International Finance Corporation (IFC): established - 25 May 1955;
effective - 24 July 1956
aim - to support private enterprise in international economic
development; a UN specialized agency and IBRD affiliate
members - (175) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Samoa, Saudi Arabia, Senegal, Serbia and
Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
International Fund for Agricultural Development (IFAD): established -
NA November 1974
aim - to promote agricultural development; a UN specialized agency
members - (162)
Category I - (23 industrialized aid contributors) Australia, Austria,
Belgium, Canada, Denmark, Finland, France, Germany, Greece, Iceland,
Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal,
Spain, Sweden, Switzerland, UK, US
Category II - (12 petroleum-exporting aid contributors) Algeria, Gabon,
Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia,
UAE, Venezuela
Category III - (127 aid recipients) Afghanistan, Albania, Angola,
Antigua and Barbuda, Argentina, Armenia, Azerbaijan, Bangladesh,
Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India,
Israel, Jamaica, Jordan, Kazakhstan, Kenya, North Korea, South Korea,
Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Nicaragua, Niger, Oman, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Romania, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Sao Tome and Principe, Senegal, Serbia and Montenegro, Seychelles,
Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan,
Suriname, Swaziland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Uruguay, Vietnam,
Yemen, Zambia, Zimbabwe
International Hydrographic Organization (IHO): note - name changed
from International Hydrographic Bureau on 22 September 1970
established - NA June 1919; effective - NA June 1921
aim - to train hydrographic surveyors and nautical cartographers to
achieve standardization in nautical charts and electronic chart
displays; to provide advice on nautical cartography and hydrography; to
develop the sciences in the field of hydrography and techniques used
for descriptive oceanography
members - (70) Algeria, Argentina, Australia, Bahrain, Bangladesh,
Belgium, Brazil, Canada, Chile, China (including Hong Kong and Macau),
Colombia, Democratic Republic of the Congo, Croatia, Cuba, Cyprus,
Denmark, Dominican Republic, Ecuador, Egypt, Estonia, Fiji, Finland,
France, Germany, Greece, Guatemala, Iceland, India, Indonesia, Iran,
Italy, Jamaica, Japan, North Korea, South Korea, Malaysia, Monaco,
Morocco, Mozambique, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan,
Papua New Guinea, Peru, Philippines, Poland, Portugal, Russia, Serbia
and Montenegro, Singapore, South Africa, Spain, Sri Lanka, Suriname,
Sweden, Syria, Thailand, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Ukraine, UAE, UK, US, Uruguay, Venezuela
membership pending - (3) Bulgaria, Mauritania, Qatar
International Labor Organization (ILO): established - 28 June 1919 set
up as part of Treaty of Versailles; 11 April 1919 became operative; 14
December 1946 affiliated with the UN
aim - to deal with world labor issues; a UN specialized agency
members - (175) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
International Maritime Organization (IMO): note - name changed from
Intergovernmental Maritime Consultative Organization (IMCO) on 22 May
1982
established - 6 March 1948 set up as the Inter-Governmental Maritime
Consultative Organization; effective - 17 March 1958
aim - to deal with international maritime affairs; a UN specialized
agency
members - (162) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and
Herzegovina, Brazil, Brunei, Bulgaria, Burma, Cambodia, Cameroon,
Canada, Cape Verde, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Latvia, Lebanon,
Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of','ebd4c60a6038ab8a1ffeedd3dfb1a19eaf90d2c1f927c2cf5959af2b44e2f849','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df1facb37b7ee296f7ada845805586e3c0446dbd444793062bb0c5a09cc0ec3d',2003,'ZW','Zimbabwe','communications',6,'Macedonia, Madagascar, Malawi, Malaysia, Maldives, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and
Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Ukraine, UAE, UK,
US, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen
associate members - (3) Faroe Islands, Hong Kong, Macau
International Monetary Fund (IMF): established - 22 July 1944;
effective - 27 December 1945
aim - to promote world monetary stability and economic development; a
UN specialized agency
members - (184) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, East Timor, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
International Olympic Committee (IOC): established - 23 June 1894
aim - to promote the Olympic ideals and administer the Olympic games:
2004 Summer Olympics in Athens, Greece; 2006 Winter Olympics in Turin,
Italy; 2008 Summer Olympics in Beijing, China; 2010 Winter Olympics in
British Colombia, Canada
National Olympic Committees - (198 and the Palestine Liberation
Organization) Albania, Algeria, American Samoa, Andorra, Angola
(suspended), Antigua and Barbuda, Argentina, Armenia, Aruba, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bermuda, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Cayman Islands, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles,
NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto
Rico, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Taiwan, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Virgin Islands, Yemen, Zambia, Zimbabwe, Palestine Liberation
Organization
International Organization for Migration (IOM): note - established as
Provisional Intergovernmental Committee for the Movement of Migrants
from Europe; renamed Intergovernmental Committee for European Migration
(ICEM) on 15 November 1952; renamed Intergovernmental Committee for
Migration (ICM) in November 1980; current name adopted 14 November 1989
established - 5 December 1951
aim - to facilitate orderly international emigration and immigration
members - (98) Albania, Algeria, Angola, Argentina, Armenia, Australia,
Austria, Azerbaijan, Bangladesh, Belgium, Belize, Benin, Bolivia,
Bulgaria, Burkina Faso, Cambodia, Canada, Cape Verde, Chile, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominican
Republic, Ecuador, Egypt, El Salvador, Finland, France, The Gambia,
Georgia, Germany, Greece, Guatemala, Guinea, Guinea-Bissau, Haiti,
Honduras, Hungary, Iran, Ireland, Israel, Italy, Japan, Jordan,
Kazakhstan, Kenya, South Korea, Kyrgyzstan, Latvia, Liberia, Lithuania,
Luxembourg, Madagascar, Mali, Mexico, Morocco, Netherlands, Nicaragua,
Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Rwanda, Senegal, Serbia and Montenegro, Sierra
Leone, Slovakia, Slovenia, South Africa, Sri Lanka, Sudan, Sweden,
Switzerland, Tajikistan, Tanzania, Thailand, Tunisia, Uganda, Ukraine,
UK, US, Uruguay, Venezuela, Yemen, Zambia, Zimbabwe
observers - (33) Afghanistan, Belarus, Bhutan, Bosnia and Herzegovina,
Brazil, Burundi, China, Cuba, Estonia, Ethiopia, Ghana, Holy See,
India, Indonesia, Jamaica, Libya, The Former Yugoslav Republic of
Macedonia, Malta, Mauritania, Moldova, Mozambique, Namibia, Nepal, NZ,
Papua New Guinea, Russia, San Marino, Sao Tome and Principe, Somalia,
Spain, Turkey, Turkmenistan, Vietnam
International Organization for Standardization (ISO): established - NA
February 1947
aim - to promote the development of international standards with a view
to facilitating international exchange of goods and services and to
developing cooperation in the sphere of intellectual, scientific,
technological and economic activity
members - (94 national standards organizations) Algeria, Argentina,
Armenia, Australia, Austria, Bangladesh, Barbados, Belarus, Belgium,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Canada, Chile,
China, Colombia, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Ecuador, Egypt, Ethiopia, Finland, France,
Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
North Korea, South Korea, Kuwait, Libya, Luxembourg, The Former
Yugoslav Republic of Macedonia, Malaysia, Malta, Mauritius, Mexico,
Mongolia, Morocco, Netherlands, NZ, Nigeria, Norway, Pakistan, Panama,
Philippines, Poland, Portugal, Romania, Russia, Saudi Arabia, Serbia
and Montenegro, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri
Lanka, Sweden, Switzerland, Syria, Tanzania, Thailand, Trinidad and
Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Zimbabwe
correspondent members - (34) Albania, Angola, Azerbaijan, Bahrain,
Bolivia, Brunei, Cameroon, Estonia, Guatemala, Hong Kong, Kyrgyzstan,
Latvia, Lebanon, Lithuania, Macau, Madagascar, Malawi, Moldova,
Mozambique, Namibia, Nepal, Nicaragua, Oman, Papua New Guinea,
Paraguay, Peru, Qatar, Rwanda, Saint Lucia, Seychelles, Sudan,
Swaziland, Turkmenistan, Yemen
subscriber members - (12) Antigua and Barbuda, Burundi, Cambodia,
Dominica, Dominican Republic, Eritrea, Fiji, Grenada, Guyana, Honduras,
Mali, Niger
International Red Cross and Red Crescent Movement (ICRM): established
- NA 1928
aim - to promote worldwide humanitarian aid through the International
Committee of the Red Cross (ICRC) in wartime, and International
Federation of Red Cross and Red Crescent Societies (IFRCS; formerly
League of Red Cross and Red Crescent Societies or LORCS) in peacetime
National Societies - (176 countries); note - same as membership for
International Federation of Red Cross and Red Crescent Societies
(IFRCS)
International Telecommunication Union (ITU): established - 17 May 1865
set up as the International Telegraph Union; 9 December 1932 adopted
present name
effective - 1 January 1934; affiliated with the UN - 15 November 1947
aim - to deal with world telecommunications issues; a UN specialized
agency
members - (189) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy
See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
Islamic Development Bank (IDB): established - 15 December 1973 by
declaration of intent; effective - 12 August 1974
aim - to promote Islamic economic aid and social development
members - (53 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Cote d''Ivoire, Djibouti, Egypt,
Gabon, The Gambia, Guinea, Guinea-Bissau, Indonesia, Iran, Iraq,
Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia,
Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Oman, Pakistan,
Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan, Suriname,
Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE,
Yemen, Palestine Liberation Organization
Latin American Economic System (LAES): note - also known as Sistema
Economico Latinoamericana (SELA)
established - 17 October 1975
aim - to promote economic and social development through regional
cooperation
members - (28) Argentina, The Bahamas, Barbados, Belize, Bolivia,
Brazil, Chile, Colombia, Costa Rica, Cuba, Dominican Republic, Ecuador,
El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica,
Mexico, Nicaragua, Panama, Paraguay, Peru, Suriname, Trinidad and
Tobago, Uruguay, Venezuela
Latin American Integration Association (LAIA): note - also known as
Asociacion Latinoamericana de Integracion (ALADI)
established - 12 August 1980; effective - 18 March 1981
aim - to promote freer regional trade
members - (12) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba,
Ecuador, Mexico, Paraguay, Peru, Uruguay, Venezuela
observers - (23) China, Commission of the European Communities,
Corporacion Andina de Fomento, Costa Rica, Dominican Republic, El
Salvador, Guatemala, Honduras, Inter-American Development Bank, Inter-
American Institute for Cooperation on Agriculture, Italy, Latin America
Economic System, Nicaragua, Organization of American States, Panama,
Pan-American Health Organization, Portugal, Romania, Russia, Spain,
Switzerland, United Nations Development Program, United Nations
Economic Commission for Latin America and the Caribbean
least developed countries (LLDCs): that subgroup of the less developed
countries (LDCs) initially identified by the UN General Assembly in
1971 as having no significant economic growth, per capita GDPs normally
less than $1,000, and low literacy rates; also known as the undeveloped
countries; the 42 LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan,
Botswana, Burkina Faso, Burma, Burundi, Cape Verde, Central African
Republic, Chad, Comoros, Djibouti, Equatorial Guinea, Eritrea,
Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti, Kiribati, Laos,
Lesotho, Malawi, Maldives, Mali, Mauritania, Mozambique, Nepal, Niger,
Rwanda, Samoa, Sao Tome and Principe, Sierra Leone, Somalia, Sudan,
Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
less developed countries (LDCs): the bottom group in the hierarchy of
developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); mainly countries and dependent
areas with low levels of output, living standards, and technology; per
capita GDPs are generally below $5,000 and often less than $1,500;
however, the group also includes a number of countries with high per
capita incomes, areas of advanced technology, and rapid rates of
growth; includes the advanced developing countries, developing
countries, Four Dragons (Four Tigers), least developed countries
(LLDCs), low-income countries, middle-income countries, newly
industrializing economies (NIEs), the South, Third World,
underdeveloped countries, undeveloped countries; the 172 LDCs are:
Afghanistan, Algeria, American Samoa, Angola, Anguilla, Antigua and
Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh, Barbados,
Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin
Islands, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape
Verde, Cayman Islands, Central African Republic, Chad, Chile, China,
Christmas Island, Cocos Islands, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia,
Falkland Islands, Fiji, French Guiana, French Polynesia, Gabon, The
Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe,
Guam, Guatemala, Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hong Kong, India, Indonesia, Iran, Iraq, Jamaica, Jersey,
Jordan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Laos,
Lebanon, Lesotho, Liberia, Libya, Macau, Madagascar, Malawi, Malaysia,
Maldives, Mali, Isle of Man, Marshall Islands, Martinique, Mauritania,
Mauritius, Mayotte, Federated States of Micronesia, Mongolia,
Montserrat, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands
Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue, Norfolk
Island, Northern Mariana Islands, Oman, Palau, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Pitcairn Islands, Puerto Rico,
Qatar, Reunion, Rwanda, Saint Helena, Saint Kitts and Nevis, Saint
Lucia, Saint Pierre and Miquelon, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra
Leone, Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname,
Swaziland, Syria, Taiwan, Tanzania, Thailand, Togo, Tokelau, Tonga,
Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu, UAE,
Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Virgin Islands, Wallis
and Futuna, West Bank, Western Sahara, Yemen, Zambia, Zimbabwe; note -
similar to the new International Monetary Fund (IMF) term "developing
countries" which adds Malta, Mexico, South Africa, and Turkey but omits
in its recently published statistics American Samoa, Anguilla, British
Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos
Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana,
French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada,
Guadeloupe, Guam, Guernsey, Jersey, North Korea, Macau, Isle of Man,
Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk
Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico,
Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks
and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West
Bank, Western Sahara
low-income countries: another term for those less developed countries
with below-average per capita GDPs; see less developed countries (LDCs)
middle-income countries: another term for those less developed
countries with above-average per capita GDPs; see less developed
countries (LDCs)
Monetary and Economic Community of Central Africa (CEMAC): note - was
formerly the Central African Customs and Economic Union (UDEAC)
established - 8 December 1964; effective - 1 January 1966
aim - to promote the establishment of a Central African Common Market
members - (6) Cameroon, Central African Republic, Chad, Republic of the
Congo, Equatorial Guinea, Gabon
Near Abroad: Russian term for the 14 non-Russian successor states of
the USSR, in which 25 million ethnic Russians live and in which Moscow
has expressed a strong national security interest; the 14 countries are
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine,
Warsaw Pact (WP): established 14 May 1955 to promote mutual defense;
members met 1 July 1991 to dissolve the alliance; member states at the
time of dissolution were Bulgaria, Czechoslovakia, Hungary, Poland,
Romania, and the USSR; earlier members included GDR and Albania
West African Development Bank (WADB): note - also known as Banque
Ouest-Africaine de Developpement (BOAD); is a financial institution of
WAEMU
established - 14 November 1973
aim - to promote regional economic development and integration
regional members - (9) Central Bank of West African States, Benin,
Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
international/nonregional members - (5) African Development Bank,
Belgium, European Investment Bank, France, Germany
West African Economic and Monetary Union (WAEMU): note - also known as
Union Economique et Monetaire Ouest Africaine (UEMOA)
established - 1 August 1994
aim - to increase competitiveness of members'' economic markets; to
create a common market
members - (8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali,
Niger, Senegal, Togo
Western European Union (WEU): established - 23 October 1954; effective
- 6 May 1955
aim - to provide mutual defense and to move toward political
unification
members - (10) Belgium, France, Germany, Greece, Italy, Luxembourg,
Netherlands, Portugal, Spain, UK
associate members - (6) Czech Republic, Hungary, Iceland, Norway,
Poland, Turkey
associate partners - (7) Bulgaria, Estonia, Latvia, Lithuania, Romania,
Slovakia, Slovenia
observers - (5) Austria, Denmark, Finland, Ireland, Sweden
World Bank Group: includes International Bank for Reconstruction and
Development (IBRD), International Development Association (IDA), and
International Finance Corporation (IFC)
World Confederation of Labor (WCL): established - 19 June 1920 as the
International Federation of Christian Trade Unions (IFCTU), renamed 4
October 1968
aim - to promote the trade union movement
members - (102 national organizations) Antigua and Barbuda, Argentina,
Aruba, Austria, Bangladesh, Belgium, Belize, Benin, Bolivia, Brazil,
Bulgaria, Burkina Faso, Cameroon, Canada, Central African Republic,
Chad, Chile, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic,
Dominica, Dominican Republic, Ecuador, El Salvador, France, French
Guiana, Gabon, The Gambia, Ghana, Guadeloupe, Guatemala, Guinea,
Guyana, Haiti, Honduras, Hong Kong, Hungary, India, Indonesia, Iran,
Italy, Japan, Kazakhstan, South Korea, Liberia, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malaysia, Malawi, Malta, Martinique, Mauritania, Mauritius,
Mexico, Morocco, Namibia, Netherlands, Netherlands Antilles, Nicaragua,
Niger, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal,
Puerto Rico, Romania, Rwanda, Saint Lucia, Saint Vincent and the
Grenadines, Sao Tome and Principe, Senegal, Serbia and Montenegro,
Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka,
Suriname, Switzerland, Taiwan, Thailand, Togo, Trinidad and Tobago,
Ukraine, US, Uruguay, Venezuela, Vietnam, Zambia, Zimbabwe
World Customs Organization (WCO): note - began as the Customs
Cooperation Council (CCC)
established - 15 December 1950
aim - to promote international cooperation in customs matters
members - (161) Albania, Algeria, Andorra, Angola, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Benin, Bermuda, Bhutan, Bolivia, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Ecuador, Egypt, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guatemala, Guinea, Guyana, Haiti, Hong Kong, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lebanon,
Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, Netherlands Antilles, NZ,
Nicaragua, Niger, Nigeria, Norw','0b44e5d03fa71afc8f24b30cfbcb42c93982a8cdb03c0fd523a9fd770f422c92','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d37e21501fe4e76cef53414ddf7e9d9a1ef7202440d823a2f22dde50dde1f4e3',2003,'ZW','Zimbabwe','communications',7,'ay, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Samoa, Saudi Arabia, Senegal, Serbia and Montenegro,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
World Federation of Trade Unions (WFTU): established - 3 October 1945
aim - to promote the trade union movement
members - (125 and the Palestine Liberation Organization) Afghanistan,
Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Benin,
Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon,
Canada, Chile, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic,
Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea,
Ethiopia, Fiji, Finland, France, French Guiana, The Gambia, Ghana,
Greece, Guadeloupe, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, India, Indonesia, Iran, Iraq, Jamaica, Japan,
Jordan, Kazakhstan, North Korea, Kuwait, Kyrgyzstan, Laos, Lebanon,
Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Mali,
Martinique, Mauritius, Mexico, Mozambique, Nepal, New Caledonia, NZ,
Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru,
Philippines, Poland, Portugal, Puerto Rico, Reunion, Romania, Russia,
Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the
Grenadines, Saudi Arabia, Senegal, Sierra Leone, Slovakia, Solomon
Islands, Somalia, South Africa, Sri Lanka, Sudan, Sweden, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zimbabwe, Palestine Liberation Organization
World Food Program (WFP): established - 24 November 1961
aim - to provide food aid in support of economic development or
disaster relief; an ECOSOC organization
members - (36) selected on a rotating basis from all regions
World Health Organization (WHO): established - 22 July 1946; effective
- 7 April 1948
aim - to deal with health matters worldwide; a UN specialized agency
members - (192) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, East
Timor, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,
associate members - (2) Puerto Rico, Tokelau
observers - (2) Holy See, Liechtenstein
World Intellectual Property Organization (WIPO): established - 14 July
1967; effective - 26 April 1970
aim - to furnish protection for literary, artistic, and scientific
works; a UN specialized agency
members - (179) Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania,
Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and
Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia,
World Meteorological Organization (WMO): established - 11 October
1947; effective - 4 April 1951
aim - to sponsor meteorological cooperation; a UN specialized agency
members - (185) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, British
Caribbean Territories, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, French Polynesia, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, Netherlands Antilles, New Caledonia, NZ, Nicaragua,
Niger, Nigeria, Niue, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Lucia, Samoa, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
World Tourism Organization (WToO): established - 2 January 1975
aim - to promote tourism as a means of contributing to economic
development, international understanding, and peace
members - (140) Afghanistan, Albania, Algeria, Andorra, Angola,
Argentina, Armenia, Austria, Azerbaijan, Bahrain, Bangladesh, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Djibouti, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea,
Guinea-Bissau, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea,
South Korea, Kyrgyzstan, Laos, Lebanon, Lesotho, Libya, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, Nicaragua, Niger,
Nigeria, Pakistan, Panama, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles,
Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sudan, Swaziland, Switzerland, Syria, Tanzania, Thailand, Togo,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members - (7) Aruba, Flanders, Hong Kong, Macau, Madeira
Islands, Netherlands Antilles, Puerto Rico
observers - (2) Holy See, Palestine Liberation Organization
World Trade Organization (WTrO): note - succeeded General Agreement on
Tariff and Trade (GATT)
established - 15 April 1994; effective - 1 January 1995
aim - to provide a forum to resolve trade conflicts between members and
to carry on negotiations with the goal of further lowering and/or
eliminating tariffs and other trade barriers
members - (145) Albania, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Bahrain, Bangladesh, Barbados, Belgium,
Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cameroon, Canada, Central African Republic, Chad,
Chile, China, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Estonia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland,
India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lesotho, Liechtenstein,
Lithuania, Luxembourg, Macau, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco,
Mozambique, Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Senegal, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa,
Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Taiwan,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda,
UAE, UK, US, Uruguay, Venezuela, Zambia, Zimbabwe
observers - (31) Algeria, Andorra, Azerbaijan, The Bahamas, Belarus,
Bhutan, Bosnia and Herzegovina, Cambodia, Cape Verde, Equatorial
Guinea, Ethiopia, The Former Yugoslav Republic of Macedonia, Holy See,
Kazakhstan, Laos, Lebanon, Nepal, Russia, Samoa, Sao Tome and Principe,
Saudi Arabia, Serbia and Montenegro, Seychelles, Sudan, Tajikistan,
Tonga, Ukraine, Uzbekistan, Vanuatu, Vietnam, Yemen; note - must start
accession negotiations within five years of becoming observers
Zangger Committee (ZC): established - early 1970s
aim - to establish guidelines for the export control provisions of the
Nonproliferation of Nuclear Weapons Treaty (NPT)
members - (35) Argentina, Australia, Austria, Belgium, Bulgaria,
Canada, China, Czech Republic, Denmark, Finland, France, Germany,
Greece, Hungary, Ireland, Italy, Japan, South Korea, Luxembourg,
Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia, Slovakia,
Slovenia, South Africa, Spain, Sweden, Switzerland, Ukraine, UK, US
This page was last updated on 1 August, 2003
=====================================================================
Appendix C - Selected International Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Persistent Organic Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or Their Transboundary
Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
Antarctic-Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature - 1 December 1959
entered into force - 23 June 1961
objective - to ensure that Antarctica is used for peaceful purposes
only (such as international cooperation in scientific research); to
defer the question of territorial claims asserted by some nations and
not recognized by others; to provide an international forum for
management of the region; applies to land and ice shelves south of 60
degrees South latitude
parties - (45) Argentina, Australia, Austria, Belgium, Brazil,
Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech Republic,
Denmark, Ecuador, Estonia, Finland, France, Germany, Greece, Guatemala,
Hungary, India, Italy, Japan, North Korea, South Korea, Netherlands,
NZ, Norway, Papua New Guinea, Peru, Poland, Romania, Russia, Slovakia,
South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US,
Uruguay, Venezuela
Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal
note - abbreviated as Hazardous Wastes
opened for signature - 22 March 1989
entered into force - 5 May 1992
objective - to reduce transboundary movements of wastes subject to the
Convention to a minimum consistent with the environmentally sound and
efficient management of such wastes; to minimize the amount and
toxicity of wastes generated and ensure their environmentally sound
management as closely as possible to the source of generation; and to
assist LDCs in environmentally sound management of the hazardous and
other wastes they generate
parties - (149) Albania, Algeria, Andorra, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina
Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, EU,
Finland, France, The Gambia, Georgia, Germany, Greece, Guatemala,
Guinea, Guyana, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Ireland, Israel, Italy, Japan, Jordan, Kenya, Kiribati, South Korea,
Kuwait, Kyrgyzstan, Latvia, Lebanon, Lesotho, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sweden,
Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified - (3) Afghanistan,
Haiti, US
Biodiversity
see Convention on Biological Diversity
Convention for the Conservation of Antarctic Seals
note - abbreviated as Antarctic Seals
opened for signature - 1 June 1972
entered into force - 11 March 1978
objective - to promote and achieve the protection, scientific study,
and rational use of Antarctic seals, and to maintain a satisfactory
balance within the ecological system of Antarctica
parties - (16) Argentina, Australia, Belgium, Brazil, Canada, Chile,
France, Germany, Italy, Japan, Norway, Poland, Russia, South Africa,
UK, US
countries that have signed, but not yet ratified - (1) NZ
Convention on Biological Diversity
note - abbreviated as Biodiversity
opened for signature - 5 June 1992
entered into force - 29 December 1993
objective - to develop national strategies for the conservation and
sustainable use of biological diversity
parties - (182) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,
countries that have signed, but not yet ratified - (6) Afghanistan,
Kuwait, Serbia and Montenegro, Thailand, Tuvalu, US
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on
Climate Change
Convention on Fishing and Conservation of Living Resources of the High
Seas
note - abbreviated as Marine Life Conservation
opened for signature - 29 April 1958
entered into force - 20 March 1966
objective - to solve through international cooperation the problems
involved in the conservation of living resources of the high seas,
considering that because of the development of modern technology some
of these resources are in danger of being overexploited
parties - (37) Australia, Belgium, Bosnia and Herzegovina, Burkina
Faso, Cambodia, Colombia, Denmark, Dominican Republic, Fiji, Finland,
France, Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia,
Mauritius, Mexico, Netherlands, Nigeria, Portugal, Senegal, Serbia and
Montenegro, Sierra Leone, Solomon Islands, South Africa, Spain,
Switzerland, Thailand, Tonga, Trinidad and Tobago, Uganda, UK, US,
Venezuela
countries that have signed, but not yet ratified - (21) Afghanistan,
Argentina, Bolivia, Canada, Costa Rica, Cuba, Ghana, Iceland,
Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ,
Pakistan, Panama, Sri Lanka, Tunisia, Uruguay
Convention on Long-Range Transboundary Air Pollution
note - abbreviated as Air Pollution
opened for signature - 13 November 1979
entered into force - 16 March 1983
objective - to protect the human environment against air pollution and
to gradually reduce and prevent air pollution, including long-range
transboundary air pollution
parties - (48) Armenia, Austria, Belarus, Belgium, Bosnia and
Herzegovina, Bulgaria, Canada, Croatia, Cyprus, Czech Republic,
Denmark, Estonia, EU, Finland, France, Georgia, Germany, Greece,
Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malta, Moldova, Monaco, Netherlands, Norway, Poland,
Portugal, Romania, Russia, Serbia and Montenegro, Slovakia, Slovenia,
Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
countries that have signed, but not yet ratified - (2) Holy See, San
Marino
Convention on the Conservation of Antarctic Marine Living Resources
note - abbreviated as Antarctic-Marine Living Resources
opened for signature - 5 May 1980
entered into force - 7 April 1982
objective - to safeguard the environment and protect the integrity of
the ecosystem of the seas surrounding Antarctica, and to conserve
Antarctic marine living resources
parties - (31) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada,
Chile, EU, Finland, France, Germany, Greece, India, Italy, Japan, South
Korea, Namibia, Netherlands, NZ, Norway, Peru, Poland, Russia, South
Africa, Spain, Sweden, Ukraine, UK, US, Uruguay, Vanuatu
Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES)
note - abbreviated as Endangered Species
opened for signature - 3 March 1973
entered into force - 1 July 1975
objective - to protect certain endangered species from overexploitation
by means of a system of import/export permits
parties - (156) Afghanistan, Algeria, Antigua','afb8edb36767c4d04f57147664bd51bf8cb359536193e58da0d0a6aad67a48d6','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b25a98b8ac8da6ebaef2e80ef2beb5e564f6f2b24dbeff098c58252584eb23b',2003,'ZW','Zimbabwe','communications',8,'and Barbuda, Argentina,
Australia, Austria, Azerbaijan, The Bahamas, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, South Korea, Latvia, Liberia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (3) Ireland, Kuwait,','69a00aa17c08f7a21c2fc8c63d55f8d588207cf65af29fa3568a0f96b2039c5d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4595ccd2afad0126fddc41fbdfb2c19b673c80b46d5fe28b33be31da07ea72a4',2003,'ET','Ethiopia','communications',197,'domestic: radiotelephone communications between islands
international: NA
Radio broadcast stations:
AM 1, FM 0, shortwave 0 (1999)
Radios:
4,000 (1997)
Television broadcast stations:
0 (1997)
Televisions:
800
Internet country code:
.tv
Internet Service Providers (ISPs):
1 (2000)
Internet users:
NA
Transportation Tuvalu
Railways:
0 km
Highways:
total: 8 km
paved: 0 km
unpaved: 8 km (1999 est.)
Waterways:
none
Ports and harbors:
Funafuti, Nukufetau
Merchant marine:
total: 4 ships (1,000 GRT or over) 33,199 GRT/56,187 DWT
note: includes some foreign-owned ships registered here as a flag of
convenience: Germany 5 (2002 est.)
ships by type: cargo 2, passenger/cargo 1, petroleum tanker 1
Airports:
1 (2002)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2002)
Military Tuvalu
Military branches:
no regular military forces; Police Force (includes Maritime
Surveillance Unit for search and rescue missions and surveillance
operations)
Military expenditures - dollar figure:
$NA
Military expenditures - percent of GDP:
NA%
Transnational Issues Tuvalu
Disputes - international:
none
This page was last updated on 18 December, 2003
======================================================================
@Uganda
Introduction Uganda
high plateau with central mountain range divided by Great
Rift Valley
Europa Island
low and flat
Falkland Islands (Islas Malvinas)
rocky, hilly, mountainous with
some boggy, undulating plains
5.55 children born/woman (2003 est.)
Falkland Islands (Islas Malvinas)
NA children born/woman
federal republic
Falkland Islands (Islas Malvinas)
NA
NA%
Falkland Islands (Islas Malvinas)
full employment; labor shortage
conventional long form: Federal Democratic Republic of
conventional short form: Ethiopia
local long form: Ityop''iya Federalawi Demokrasiyawi Ripeblik
local short form: Ityop''iya
former: Abyssinia, Italian East Africa
abbreviation: FDRE
Europa Island
conventional long form: none
conventional short form: Europa Island
local long form: none
local short form: Ile Europa
Falkland Islands (Islas Malvinas)
conventional long form: none
conventional short form: Falkland Islands (Islas Malvinas)
Eastern Africa, west of Somalia
Europa Island
Southern Africa, island in the Mozambique Channel,
about one-half of the way from southern Madagascar to southern
Africa
Europa Island
Africa
Falkland Islands (Islas Malvinas)
South America
1,900 sq km (1998 est.)
Europa Island
0 sq km (1998 est.)
Falkland Islands (Islas Malvinas)
NA sq km
total: 1,127,127 sq km
land: 1,119,683 sq km
water: 7,444 sq km
Europa Island
total: 28 sq km
land: 28 sq km
water: 0 sq km
Falkland Islands (Islas Malvinas)
total: 12,173 sq km
land: 12,173 sq km
water: 0 sq km
note: includes the two main islands of East and West Falkland and
about 200 small islands
chief of mission: Ambassador KASSAHUN Ayele
chancery: 3506 International Drive NW, Washington, DC 20008
telephone: [1] (202) 364-1200
FAX: [1] (202) 686-9551
consulate(s) general: Los Angeles
consulate(s): New York
Falkland Islands (Islas Malvinas)
none (overseas territory of the
UK; also claimed by Argentina)
231,900 (2000)
Falkland Islands (Islas Malvinas)
NA
17,800 (2000)
Falkland Islands (Islas Malvinas)
NA
1 (2002)
Falkland Islands (Islas Malvinas)
2 (2000)
20,000 (2002)
Falkland Islands (Islas Malvinas)
NA; however one-half of all
households are reported to have internet access (2002)
.et
Falkland Islands (Islas Malvinas)
.fk
6.4% (2001 est.)
Falkland Islands (Islas Malvinas)
NA%
2.1 million (2001 est.)
Falkland Islands (Islas Malvinas)
NA
160,000 (2001 est.)
Falkland Islands (Islas Malvinas)
NA
ETB
Falkland Islands (Islas Malvinas)
FKP
40 (1995)
0 bbl/day (2001 est.)
Falkland Islands (Islas Malvinas)
0 bbl/day (2001 est.)
23,000 bbl/day (2001 est.)
Falkland Islands (Islas Malvinas)
200 bbl/day (2001 est.)
NA (2001)
Falkland Islands (Islas Malvinas)
NA (2001)
NA (2001)
Falkland Islands (Islas Malvinas)
NA (2001)
total: 17.3 years
male: 17.3 years
female: 17.4 years (2002)
214,000 bbl (37257)
12.46 billion cu m (37257)','0e1b18a91045dfdd05f6b299e7d7f26781318ce014d7ea7f4306f0a3b60c6f1f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cb3df3622c127a1e5860cf6311c608a431b0b687a50f4f9903347a0a8ea33de',2003,'TV','Tuvalu','communications',789,'domestic: radiotelephone communications between islands
international: NA
very low-lying and narrow coral atolls
3.05 children born/woman (2003 est.)
constitutional monarchy with a parliamentary democracy; began
debating republic status in 1992
NA%
conventional long form: none
conventional short form: Tuvalu
former: Ellice Islands
note: "Tuvalu" means "group of eight," referring to the country''s
eight traditionally inhabited islands
Oceania, island group consisting of nine coral atolls in the
South Pacific Ocean, about one-half of the way from Hawaii to
Oceania
NA sq km
total: 26 sq km
land: 26 sq km
water: 0 sq km
Tuvalu does not have an embassy in the US - the country''s
only diplomatic post is in Fiji - Tuvalu does, however, have a UN
office located at 800 2nd Avenue, Suite 400D, New York, New York
10017, telephone: [1] (212) 490-0534
1,000 (1997)
0 (1994)
1 (2000)
NA
.tv
NA%
NA
NA
AUD
total: 24.2 years
male: 22.9 years
female: 25.8 years (2002)','ddfaed5171776271ffa9ced3a658987c2a604c4d65935e235af43da33e1e18ee','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e19c6623cebc2fa72d17929c448ee31c7ecebf661893468338898e2f19325c97',2003,'UG','Uganda','communications',790,'general assessment: seriously inadequate; two cellular
systems have been introduced, but a sharp increase in the number of
main lines is essential; e-mail and Internet services are available
domestic: intercity traffic by wire, microwave radio relay, and
radiotelephone communication stations, fixed and mobile cellular
systems for short-range traffic
international: satellite earth stations - 1 Intelsat (Atlantic
Ocean) and 1 Inmarsat; analog links to Kenya and Tanzania
mostly plateau with rim of mountains
6.72 children born/woman (2003 est.)
republic
NA%
conventional long form: Republic of Uganda
conventional short form: Uganda
Eastern Africa, west of Kenya
Africa
90 sq km (1998 est.)
total: 236,040 sq km
land: 199,710 sq km
water: 36,330 sq km
chief of mission: Ambassador Edith Grace SSEMPALA
chancery: 5911 16th Street NW, Washington, DC 20011
telephone: [1] (202) 726-7100 through 7102, 0416
FAX: [1] (202) 726-1727
50,074; however, 80,868 main lines have been installed (1998)
9,000 (1998)
2 (2000)
60,000 (2002)
.ug
5% (2001 est.)
600,000 (2001 est.)
84,000 (2001 est.)
UGX
37.4 (1996)
0 bbl/day (2001 est.)
8,750 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 14.7 years
male: 14.6 years
female: 14.8 years (2002)
International Atomic Energy Agency (IAEA): established - 26 October
1956; effective - 29 July 1957
aim - to promote peaceful uses of atomic energy
members - (135) Afghanistan, Albania, Algeria, Angola, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bangladesh, Belarus, Belgium,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Cambodia, Cameroon, Canada, Central African
Republic, Chile, China, Colombia, Democratic Republic of the Congo,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia,
Ethiopia, Finland, France, Gabon, Georgia, Germany, Ghana, Greece,
Guatemala, Haiti, Holy See, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, South Korea, Kuwait, Latvia, Lebanon, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malaysia, Mali, Malta, Marshall
Islands, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco,
Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Saudi Arabia, Senegal, Serbia and Montenegro, Sierra Leone,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Tunisia,
Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe; note - Eritrea, Kyrgyzstan, and
Seychelles membership has been approved; membership will take effect
once legal instruments have been deposited
International Bank for Reconstruction and Development (IBRD): note -
also known as the World Bank
established - 22 July 1944; effective - 27 December 1945
aim - to provide economic development loans; a UN specialized agency
members - (184) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, East Timor, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
International Chamber of Commerce (ICC): established - NA 1919
aim - to promote free trade and private enterprise and to represent
business interests at national and international levels
members - (84 national committees) Algeria, Argentina, Australia,
Austria, Bahrain, Bangladesh, Belgium, Brazil, Burkina Faso, Cameroon,
Canada, Caribbean, Chile, China, Colombia, Costa Rica, Cuba, Cyprus,
Czech Republic, Denmark, Ecuador, Egypt, Finland, France, Georgia,
Germany, Ghana, Greece, Hong Kong, Hungary, Iceland, India, Indonesia,
Iran, Ireland, Israel, Italy, Japan, Jordan, South Korea, Kuwait,
Lebanon, Lithuania, Luxembourg, Mexico, Monaco, Mongolia, Morocco,
Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia
and Montenegro, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri
Lanka, Sweden, Switzerland, Syria, Taiwan, Tanzania, Thailand, Togo,
Tunisia, Turkey, Ukraine, UK, US, Uruguay, Venezuela
International Civil Aviation Organization (ICAO): established - 7
December 1944; effective - 4 April 1947
aim - to promote international cooperation in civil aviation; a UN
specialized agency
members - (188) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt,
El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia,
Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and
Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
International Committee of the Red Cross (ICRC): established - 17
February 1863
aim - to provide humanitarian aid in wartime
members - (25 individuals) all Swiss nationals
International Confederation of Free Trade Unions (ICFTU): established
- NA December 1949
aim - to promote the trade union movement
members - (231 affiliated organizations in the following 149 countries
plus the Palestine Liberation Organization) Albania, Algeria, Angola,
Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The
Bahamas, Bangladesh, Barbados, Belgium, Belize, Benin, Bermuda,
Botswana, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, Colombia, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Curacao, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, El Salvador, Eritrea, Estonia,
Falkland Islands, Fiji, Finland, France, French Polynesia, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Holy See, Honduras, Hong Kong, Hungary, Iceland,
India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kenya, Kiribati, South Korea, Latvia, Lebanon, Liberia, Lithuania,
Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania,
Mauritius, Mexico, Moldova, Mongolia, Montserrat, Morocco, Mozambique,
Namibia, Nepal, Netherlands, New Caledonia, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Puerto Rico, Romania, Russia, Rwanda,
Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Senegal, Serbia and Montenegro,
Seychelles, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri
Lanka, Suriname, Swaziland, Sweden, Switzerland, Taiwan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda,
UK, US, Vanuatu, Venezuela, Yemen, Zambia, Zimbabwe, Palestine
Liberation Organization
International Court of Justice (ICJ): note - also known as the World
Court
established - 3 February 1946 superseded Permanent Court of
International Justice
aim - primary judicial organ of the UN
members - (15 judges) elected by the UN General Assembly and Security
Council to represent all principal legal systems
International Criminal Court (ICCt): established - 11 April 2002
aim - to hold all individuals and countries accountable to
international laws of conduct; to specify international standards of
conduct; to provide an important mechanism for implementing these
standards; to ensure that perpetrators are brought to justice
members - (89) Afghanistan, Albania, Andorra, Antigua and Barbuda,
Argentina, Australia, Austria, Barbados, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Cambodia,
Canada, Central African Republic, Colombia, Costa Rica, Croatia,
Cyprus, Democratic Republic of the Congo, Denmark, Djibouti, Dominica,
East Timor, Ecuador, Estonia, Fiji, Finland, France, Gabon, The Gambia,
Germany, Ghana, Greece, Honduras, Hungary, Iceland, Ireland, Italy,
Jordan, South Korea, Latvia, Lesotho, Liechtenstein, Luxembourg, The
Former Yugoslav Republic of Macedonia, Malawi, Mali, Malta, Marshall
Islands, Mauritius, Mongolia, Namibia, Nauru, Netherlands, NZ, Niger,
Nigeria, Norway, Panama, Paraguay, Peru, Poland, Portugal, Romania,
Saint Vincent and the Grenadines, Samoa, San Marino, Senegal, Serbia
and Montenegro, Sierra Leone, Slovakia, Slovenia, South Africa, Spain,
Sweden, Switzerland, Tajikistan, Tanzania, Trinidad and Tobago, Uganda,
UK, Uruguay, Venezuela, Zambia
signatory states - (54) Algeria, Angola, Armenia, The Bahamas, Bahrain,
Bangladesh, Burkina Faso, Burundi, Cameroon, Cape Verde, Chad, Chile,
Comoros, Republic of the Congo, Cote d''Ivoire, Czech Republic,
Dominican Republic, Egypt, Eritrea, Georgia, Guinea, Guinea-Bissau,
Guyana, Haiti, Iran, Israel, Jamaica, Kenya, Kuwait, Kyrgyzstan,
Liberia, Lithuania, Madagascar, Mexico, Moldova, Monaco, Morocco,
Mozambique, Oman, Philippines, Russia, Saint Lucia, Sao Tome and
Principe, Seychelles, Solomon Islands, Sudan, Syria, Thailand, Ukraine,
UAE, US, Uzbekistan, Yemen, Zimbabwe
International Criminal Police Organization (Interpol): established -
NA September 1923 set up as the International Criminal Police
Commission; 13 June 1956 constitution modified and present name adopted
aim - to promote international cooperation among police authorities in
fighting crime
members - (181) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles,
NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia,','2983153452f1b8c1fb948deecff48bf122b53b96e739e273a96f20c56ab581f9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('079d85f26bac3c4c107bbf55ada4f907d7a3ad57aeed1e6ab22b28f6c03daaf2',2003,'UA','Ukraine','communications',791,'general assessment: Ukraine''s telecommunication development
plan, running through 2005, emphasizes improving domestic trunk
lines, international connections, and the mobile cellular system
domestic: at independence in December 1991, Ukraine inherited a
telephone system that was antiquated, inefficient, and in disrepair;
more than 3.5 million applications for telephones could not be
satisfied; telephone density is now rising slowly and the domestic
trunk system is being improved; the mobile cellular telephone system
is expanding at a high rate
international: two new domestic trunk lines are a part of the
fiber-optic Trans-Asia-Europe (TAE) system and three Ukrainian links
have been installed in the fiber-optic Trans-European Lines (TEL)
project which connects 18 countries; additional international
service is provided by the Italy-Turkey-Ukraine-Russia (ITUR)
fiber-optic submarine cable and by earth stations in the Intelsat,
Inmarsat, and Intersputnik satellite systems
most of Ukraine consists of fertile plains (steppes) and
plateaus, mountains being found only in the west (the Carpathians),
and in the Crimean Peninsula in the extreme south
1.34 children born/woman (2003 est.)
republic
3.8% officially registered; large number of unregistered or
underemployed workers (2002)
conventional long form: none
conventional short form: Ukraine
local long form: none
local short form: Ukrayina
former: Ukrainian National Republic, Ukrainian State, Ukrainian
Soviet Socialist Republic
Eastern Europe, bordering the Black Sea, between Poland and
Russia
Asia, Europe
24,540 sq km (1998 est.)
total: 603,700 sq km
land: 603,700 sq km
water: 0 sq km
chief of mission: Ambassador (vacant); Charge d''Affaires
Sergiy KORSUNSKYI
chancery: 3350 M Street NW, Washington, DC 20007
telephone: [1] (202) 349-2920
FAX: [1] (202) 333-0817
consulate(s) general: Chicago and New York
9.45 million (April 1999)
236,000 (1998)
260 (2001)
750,000 (2001)
.ua
1% (2001 est.)
250,000 (2001 est.)
11,000 (2001 est.)
UAH
29 (1999)
86,490 bbl/day (2001 est.)
290,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 38 years
male: 34.8 years
female: 40.9 years (2002)
197.5 million bbl (37257)
560.7 billion cu m (37257)
18.2 billion cu m (2001 est.)
74.1 billion cu m (2001 est.)
55.9 billion cu m (2001 est.)
0 cu m (2001 est.)
United Nations Iraq-Kuwait Observation Mission (UNIKOM): established -
9 April 1991
aim - to observe and monitor the demilitarized zone established between
Iraq and Kuwait; established by the UN Security Council
members - (32) Argentina, Austria, Bangladesh, China, Denmark, Fiji,
Finland, France, Germany, Ghana, Greece, Hungary, India, Indonesia,
Ireland, Italy, Kenya, Malaysia, Nigeria, Pakistan, Poland, Romania,
Russia, Senegal, Singapore, Sweden, Thailand, Turkey, UK, US, Uruguay,
Venezuela
United Nations Military Observer Group in India and Pakistan (UNMOGIP):
established - 24 January 1949
aim - to observe the 1949 India-Pakistan cease-fire; established by the
UN Security Council
members - (9) Belgium, Chile, Croatia, Denmark, Finland, Italy, South
Korea, Sweden, Uruguay
United Nations Mission for the Referendum in Western Sahara (MINURSO):
established - 29 April 1991
aim - to supervise the cease-fire and conduct a referendum in Western
Sahara; established by the UN Security Council
members - (24) Argentina, Austria, Bangladesh, China, Egypt, El
Salvador, France, Ghana, Greece, Guinea, Honduras, Hungary, Ireland,
Italy, Kenya, South Korea, Malaysia, Nigeria, Pakistan, Poland,
Portugal, Russia, US, Uruguay
United Nations Mission in Bosnia and Herzegovina (UNMIBH): established
- 21 December 1995
aim - to establish an International Police Task Force (IPTF) to
implement the Dayton Peace Agreement in Bosnia and Herzegovina
members - (47) Argentina, Austria, Bangladesh, Bulgaria, Canada, Chile,
China, Czech Republic, Denmark, Egypt, Estonia, Fiji, Finland, France,
Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Ireland,
Italy, Jordan, Kenya, Lithuania, Malaysia, Nepal, Nigeria, Netherlands,
Norway, Pakistan, Poland, Portugal, Romania, Russia, Senegal, Spain,
Sweden, Switzerland, Thailand, Tunisia, Turkey, Ukraine, UK, US,
United Nations Mission of Observers in Tajikistan (UNMOT): established
16 December 1994; to monitor and investigate violations of the cease-
fire of 17 September 1994 between Tajikistan and the Tajik opposition
and to assist in the political negotiation process; established by the
UN Security Council; members were Austria, Bangladesh, Bulgaria, Czech
Republic, Denmark, Ghana, Indonesia, Jordan, Nepal, Nigeria, Poland,
Ukraine, Uruguay; mission ended May 2000
United Nations Mission of Support in East Timor (UNMISET): established
- 17 May 2002
aim - to provide assistance to structures critical to political
stability; to provide law enforcement and public security and to assist
in the development of law enforcement agencies; to contribute to
external security
members - (29) Australia, Bangladesh, Bolivia, Brazil, Denmark, Egypt,
Fiji, Ireland, Japan, Jordan, Kenya, South Korea, Malaysia, Mozambique,
Nepal, NZ, Norway, Pakistan, Philippines, Portugal, Russia, Serbia and
Montenegro, Singapore, Slovakia, Sweden, Thailand, Turkey, US, Uruguay
United Nations Monitoring, Verification, and Inspection Commission
(UNMOVIC): note - formerly known as United Nations Special Commission
for the Elimination of Iraq''s Weapons of Mass Destruction (UNSCOM)
established - NA December 1999
aim - to identify, account for, and eliminate Iraq''s weapons of mass
destruction and the capacity to produce them
commissioners - (15) Argentina, Brazil, Canada, China, France, Germany,
India, Japan, Mexico, Nigeria, Russia, Senegal, Ukraine, UK, US
United Nations Observer Mission in Georgia (UNOMIG): established - 24
August 1993
aim - to verify compliance with the cease-fire agreement, to monitor
weapons exclusion zone, and to supervise CIS peacekeeping force for
Abkhazia; established by the UN Security Council
members - (22) Albania, Austria, Bangladesh, Czech Republic, Denmark,
Egypt, France, Germany, Greece, Hungary, Indonesia, Jordan, South
Korea, Pakistan, Poland, Russia, Sweden, Switzerland, Turkey, UK, US,','8a1d7fc31700ee52ac6cea6e4a6ba6db8786975719d4ac2eef539f8b889078e2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3c51173865a3f1e454ebb34ff7307e812924a2b0c025f737e586d04a6891ed9',2003,'AE','United Arab Emirates','communications',792,'general assessment: modern system of microwave
radio relay and coaxial cable; key centers are Abu Dhabi and Dubai
domestic: microwave radio relay and coaxial cable
international: satellite earth stations - 3 Intelsat (1 Atlantic
Ocean and 2 Indian Ocean) and 1 Arabsat; submarine cables to Qatar,
Bahrain, India, and Pakistan; tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia
flat, barren coastal plain merging into rolling
sand dunes of vast desert wasteland; mountains in east
3.09 children born/woman (2003 est.)
federation with specified powers delegated to
the UAE federal government and other powers reserved to member
emirates
NA%
conventional long form: United Arab Emirates
conventional short form: none
local long form: Al Imarat al Arabiyah al Muttahidah
local short form: none
former: Trucial Oman, Trucial States
abbreviation: UAE
Middle East, bordering the Gulf of Oman and the
Persian Gulf, between Oman and Saudi Arabia
Middle East
720 sq km (1998 est.)
total: 82,880 sq km
land: 82,880 sq km
water: 0 sq km
chief of mission: Ambassador Asri Said Ahmad
al-DHAHIRI
chancery: 3522 International Court NW, Washington, DC 20037
telephone: [1] (202) 243-2400
FAX: [1] (202) 243-2432
915,223 (1998)
1 million (1999)
1 (2000)
900,000 (2002)
.ae
0.18% (2001 est.)
NA
NA
AED
2.566 million bbl/day (2001 est.)
310,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 27.6 years
male: 36.1 years
female: 21.9 years (2002)
80.31 billion bbl (37257)
5.892 trillion cu m (37257)
44.94 billion cu m (2001 est.)
37.86 billion cu m (2001 est.)
0 cu m (2001 est.)
7.08 billion cu m (2001 est.)','fb684b132a65eeb437d1acec21a1c0ffc0c909d3258ab37015fa4a2457554591','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('564d76ff1ee7a5c1a2e318b5819cc9a4048bdee4f3a89b3e05266eafca754506',2003,'GB','United Kingdom','communications',793,'general assessment: technologically advanced domestic
and international system
domestic: equal mix of buried cables, microwave radio relay, and
fiber-optic systems
international: 40 coaxial submarine cables; satellite earth stations
- 10 Intelsat (7 Atlantic Ocean and 3 Indian Ocean), 1 Inmarsat
(Atlantic Ocean region), and 1 Eutelsat; at least 8 large
international switching centers
mostly rugged hills and low mountains; level to
rolling plains in east and southeast
1.66 children born/woman (2003 est.)
constitutional monarchy
5.2% (2002 est.)
conventional long form: United Kingdom of Great
Britain and Northern Ireland
conventional short form: United Kingdom
abbreviation: UK
Western Europe, islands including the northern
one-sixth of the island of Ireland between the North Atlantic Ocean
and the North Sea, northwest of France
Europe
1,080 sq km (1998 est.)
total: 244,820 sq km
land: 241,590 sq km
water: 3,230 sq km
note: includes Rockall and Shetland Islands
chief of mission: Ambassador David G. MANNING
chancery: 3100 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 588-6500
FAX: [1] (202) 588-7870
consulate(s) general: Atlanta, Boston, Chicago, Houston, Los
Angeles, New York, and San Francisco
consulate(s): Dallas, Denver, Miami, and Seattle
34.878 million (1997)
43.5 million (yearend 1998)
more than 400 (2000)
34.3 million (2002)
.uk
0.1% (2001 est.)
34,000 (2001 est.)
460 (2001 est.)
GBP
36.8 (1995)
2.541 million bbl/day (2001 est.)
1.71 million bbl/day (2001 est.)
1.418 million bbl/day (2001)
2.205 million bbl/day (2001)
total: 38.4 years
male: 37.3 years
female: 39.5 years (2002)
4.741 billion bbl (37257)
714.9 billion cu m (37257)
105.9 billion cu m (2001 est.)
92.85 billion cu m (2001 est.)
2.7 billion cu m (2001 est.)
15.75 billion cu m (2001 est.)','e753d45ee57feba6152fb79c2b1532e26bcceafe0569fa319800a126bf1fd13f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6c60a4ee99b014f9df9730977ab05eb1c3b83aba634c76c7587c87ed2d6b8a1',2003,'US','United States','communications',794,'general assessment: a very large, technologically
advanced, multipurpose communications system
domestic: a large system of fiber-optic cable, microwave radio
relay, coaxial cable, and domestic satellites carries every form of
telephone traffic; a rapidly growing cellular system carries mobile
telephone traffic throughout the country
international: 24 ocean cable systems in use; satellite earth
stations - 61 Intelsat (45 Atlantic Ocean and 16 Pacific Ocean), 5
Intersputnik (Atlantic Ocean region), and 4 Inmarsat (Pacific and
Atlantic Ocean regions) (2000)
vast central plain, mountains in west, hills and low
mountains in east; rugged mountains and broad river valleys in
Alaska; rugged, volcanic topography in Hawaii
2.07 children born/woman (2003 est.)
Constitution-based federal republic; strong democratic
tradition
5.8% (2002)
note: 2002 estimates for military manpower are based
on projections that do not take into consideration the results of
the 2000 census
Virgin Islands
defense is the responsibility of the US
Wake Island
defense is the responsibility of the US
conventional long form: United States of America
conventional short form: United States
abbreviation: US or USA
North America, bordering both the North Atlantic Ocean
and the North Pacific Ocean, between Canada and Mexico
North America
214,000 sq km (1998 est.)
total: 9,629,091 sq km
land: 9,158,960 sq km
water: 470,131 sq km
note: includes only the 50 states and District of Columbia
194 million (1997)
69.209 million (1998)
7,000 (2002 est.)
165.75 million (2002)
.us
0.6% (2001 est.)
900,000 (2001 est.)
15,000 (2001 est.)
USD
40.8 (1997)
8.054 million bbl/day (2001 est.)
19.65 million bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 35.8 years
male: 34.5 years
female: 37.1 years (2002)
22.45 billion bbl (37257)
5.195 trillion cu m (37257)
548.1 billion cu m (2001 est.)
640.9 billion cu m (2001 est.)
114.1 billion cu m (2001 est.)
11.16 billion cu m (2001 est.)
Minor Outlying
Islands - UM UMI 581 .um
ISO includes Baker Island, Howland Island, Jarvis Island,
Johnston Atoll, Kingman Reef, Midway Islands, Palmyra Atoll,
Wake Island
Uruguay UY UY URY 858 .uy
Uzbekistan UZ UZ UZB 860 .uz
Vanuatu NH VU VUT 548 .vu
Venezuela VE VE VEN 862 .ve
Vietnam VM VN VNM 704 .vn
Virgin Islands VQ VI VIR 850 .vi
Virgin Islands (UK) - - - - .vg
see British Virgin Islands
Virgin Islands (US) - - - - .vi
see Virgin Islands
Wake Island WQ - - - -
ISO includes with the US Minor Outlying Islands
Wallis and Futuna WF WF WLF 876 .wf
West Bank WE - - - -
Western Sahara WI EH ESH 732 .eh
Western Samoa - - - - .ws
see Samoa
World - - - - -
the Factbook uses the W data code from DIAM 65-18 Geopolitical
Data Elements and Related Features, Data Standard No. 3, December
1994, published by the Defense Intelligence Agency
Yemen YM YE YEM 887 .ye
Zaire - - - - -
see Democratic Republic of the Congo
Zambia ZA ZM ZWB 894 .zm
Zimbabwe ZI ZW ZWE 716 .zw
This page was last updated on 1 August, 2003
=====================================================================
Appendix E - Cross-Reference List of Hydrographic Data Codes
IHO 23-4th: Limits of Oceans and Seas, Special Publication 23, Draft
4th Edition 1986, published by the International Hydrographic Bureau of
the International Hydrographic Organization
IHO 23-3rd: Limits of Oceans and Seas, Special Publication 23, 3rd
Edition 1953, published by the International Hydrographic Organization
ACIC M 49-1: Chart of Limits of Seas and Oceans, revised January 1958,
published by the Aeronautical Chart and Information Center (ACIC),
United States Air Force; note - ACIC is now part of the National
Imagery and Mapping Agency (NIMA)
DIAM 65-18: Geopolitical Data Elements and Related Features, Data
Standard No. 4, Defense Intelligence Agency Manual 65-18, December
1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes
similar to the Federal Information Processing Standards (FIPS) 10-4
country codes. The names and limits of the following oceans and seas
are not always directly comparable because of differences in the
customers, needs, and requirements of the individual organizations.
Even the number of principal water bodies varies from organization to
organization. Factbook users, for example, find the Atlantic Ocean and
Pacific Ocean entries useful, but none of the following standards
include those oceans in their entirety. Nor is there any provision for
combining codes or overcodes to aggregate water bodies. The recently
delimited Southern Ocean is not included.
Principal Oceans and Seas of the World
With Hydrographic Codes by Institution
IHO 23-4th IHO 23-3rd* ACIC M 49-1 DIAM 65-18
Arctic Ocean 9 17 A 5A
Atlantic Ocean - - - -
North Atlantic Ocean 1 23 B 1A
South Atlantic Ocean 4 32 C 2A
Baltic Sea 2 1 B26 7B
Indian Ocean 5 45 F 6A
Mediterranean Sea 3.1 28 B11 -
Eastern Mediterranean 3.1.2 28 B - 8E
Western Mediterranean 3.1.1 28 A - 8W
Pacific Ocean - - - -
North Pacific Ocean 7 57 D 3A
South Pacific Ocean 8 61 E 4A
South China and Eastern
Archipelagic Seas 6 49, 48 D18 plus 3U plus
others others
*The letters after the numbers are subdivisions, not footnotes.
This page was last updated on 1 August, 2003
=====================================================================
Appendix F - Cross-Reference List of Geographic Names
Name Entry in The World Latitude Longitude
Factbook (deg min) (deg min)
Abidjan (capital) Cote d''Ivoire 5 19 N 4 02 W
Abkhazia (region) Georgia 43 00 N 41 00 E
Abu Dhabi (capital) United Arab Emirates 24 28 N 54 22 E
Abu Musa (island) Iran 25 52 N 55 03 E
Abuja (capital) Nigeria 9 12 N 7 11 E
Abyssinia (former name Ethiopia 8 00 N 38 00 E
for Ethiopia)
Acapulco (city) Mexico 16 51 N 99 55 W
Accra (capital) Ghana 5 33 N 0 13 W
Adamstown (capital) Pitcairn Islands 25 04 S 130 05 W
Addis Ababa (capital) Ethiopia 9 02 N 38 42 E
Adelie Land (claimed by Antarctica 66 30 S 139 00 E
France; also Terre
Adelie)
Aden (city) Yemen 12 46 N 45 01 E
Aden, Gulf of Indian Ocean 12 30 N 48 00 E
Admiralty Island United States 57 44 N 134 20 W
(Alaska)
Admiralty Islands Papua New Guinea 2 10 S 147 00 E
Adriatic Sea Atlantic Ocean 42 30 N 16 00 E
Adygey (region) Russia 44 30 N 40 10 E
Aegean Islands Greece 38 00 N 25 00 E
Aegean Sea Atlantic Ocean 38 30 N 25 00 E
Afars and Issas, French Djibouti 11 30 N 43 00 E
Territory of the (or
FTAI; former name for
Djibouti)
Afghanestan (local name Afghanistan 33 00 N 65 00 E
for Afghanistan)
Agalega Islands Mauritius 10 25 S 56 40 E
Agana (city; former name Guam 13 28 N 144 45 E
for Hagatna)
Ajaccio (city) France (Corsica) 41 55 N 8 44 E
Ajaria (region) Georgia 41 45 N 42 10 E
Akmola (city; former name Kazakhstan 51 10 N 71 30 E
for Astana)
Aksai Chin (region) China (de facto), 35 00 N 79 00 E
India (claimed)
Al Arabiyah as Suudiyah Saudi Arabia 25 00 N 45 00 E
(local name for Saudi
Arabia)
Al Bahrayn (local name Bahrain 26 00 N 50 33 E
for Bahrain)
Al Imarat al Arabiyah al United Arab Emirates 24 00 N 54 00 E
Muttahidah (local name
for the United Arab
Emirates)
Al Iraq (local name for Iraq 33 00 N 44 00 E
Iraq)
Al Jaza''ir (local name Algeria 28 00 N 3 00 E
for Algeria)
Al Kuwayt (local name for Kuwait 29 30 N 45 45 E
Kuwait)
Al Maghrib (local name Morocco 32 00 N 5 00 W
for Morocco)
Al Urdun (local name for Jordan 31 00 N 36 00 E
Jordan)
Al Yaman (local name for Yemen 15 00 N 48 00 E
Yemen)
Aland Islands Finland 60 15 N 20 00 E
Alaska (state) United States 65 00 N 153 00 W
Alaska, Gulf of Pacific Ocean 58 00 N 145 00 W
Alboran Sea Atlantic Ocean 36 00 N 2 30 W
Aldabra Islands (Groupe Seychelles 9 25 S 46 22 E
d''Aldabra)
Alderney (island) Guernsey 49 43 N 2 12 W
Aleutian Islands United States 52 00 N 176 00 W
(Alaska)
Alexander Archipelago United States 57 00 N 134 00 W
(island group) (Alaska)
Alexander Island Antarctica 71 00 S 70 00 W
Alexandretta (region; Turkey 36 34 N 36 08 E
former name for
Iskenderun)
Alexandria (city) Egypt 31 12 N 29 54 E
Algiers (capital) Algeria 36 47 N 2 03 E
Alhucemas, Penon de Spain 35 13 N 3 53 W
(island group)
Alma-Ata (city; former Kazakhstan 43 15 N 76 57 E
name for Almaty)
Almaty (former capital) Kazakhstan 43 15 N 76 57 E
Alofi (capital) Niue 19 01 S 169 55 W
Alphonse Island Seychelles 7 01 S 52 45 E
Alsace (region) France 48 30 N 7 20 E
Amami Strait Pacific Ocean 28 40 N 129 30 E
Amindivi Islands (former India 11 30 N 72 30 E
name for Laccadive
Islands)
Amirante Isles (island Seychelles 6 00 S 53 10 E
group; also Les
Amirantes)
Amman (capital) Jordan 31 57 N 35 56 E
Amsterdam (capital) Netherlands 52 23 N 4 54 E
Amsterdam Island (Ile French Southern and 37 52 S 77 32 E
Amsterdam) Antarctic Lands
Amundsen Sea Southern Ocean 72 30 S 112 00 W
Amur River China, Russia 52 56 N 141 10 E
Amurskiy Liman (strait) Pacific Ocean 53 00 N 141 30 E
Anadyrskiy Zaliv (gulf) Pacific Ocean 64 00 N 177 00 E
Anatolia (region) Turkey 39 00 N 35 00 E
Andaman Islands India 12 00 N 92 45 E
Andaman Sea Indian Ocean 10 00 N 95 00 E
Andorra la Vella Andorra 42 30 N 1 30 E
(capital)
Andros (island) Greece 37 45 N 24 42 E
Andros Island The Bahamas 24 26 N 77 57 W
Anegada Passage Atlantic Ocean 18 30 N 63 40 W
Angkor Wat (ruins) Cambodia 13 26 N 103 50 E
Anglo-Egyptian Sudan Sudan 15 00 N 30 00 E
(former name for Sudan)
Anjouan (island) Comoros 12 15 S 44 25 E
Ankara (capital) Turkey 39 56 N 32 52 E
Annobon (island) Equatorial Guinea 1 25 S 5 36 E
Antananarivo (capital) Madagascar 18 52 S 47 30 E
Antigua (island) Antigua and Barbuda 14 34 N 90 44 W
Antipodes Islands New Zealand 49 41 S 178 43 E
Antwerp (city) Belgium 51 13 N 4 25 E
Aomen (local Chinese Macau 22 10 N 113 33 E
short-form name for
Macau)
Aozou Strip (region) Chad 22 00 N 18 00 E
Apia (capital) Samoa 13 50 S 171 45W
Aqaba, Gulf of Indian Ocean 29 00 N 34 30 E
Arab, Shatt al (river) Iran, Iraq 29 57 N 48 34 E
Arabian Sea Indian Ocean 15 00 N 65 00 E
Arafura Sea Pacific Ocean 9 00 S 133 00 E
Aral Sea Kazakhstan, 45 00 N 60 00 E','bd16403d2a5b5a7213cd97cd3754441b51f03540a8124cd47ae065bb43e6ad01','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e2bdf7ae3fafc4aa27f8601d1eb101a34e6236f87840508dfee4456f0792fbc',2003,'UY','Uruguay','communications',795,'general assessment: fully digitalized
domestic: most modern facilities concentrated in Montevideo; new
nationwide microwave radio relay network
international: satellite earth stations - 2 Intelsat (Atlantic
Ocean) (2002)
mostly rolling plains and low hills; fertile coastal lowland
2.35 children born/woman (2003 est.)
constitutional republic
19.4% (2002)
conventional long form: Oriental Republic of Uruguay
conventional short form: Uruguay
local long form: Republica Oriental del Uruguay
local short form: Uruguay
former: Banda Oriental, Cisplatine Province
Southern South America, bordering the South Atlantic Ocean,
between Argentina and Brazil
South America
1,800 sq km (1998 est.)
total: 176,220 sq km
land: 173,620 sq km
water: 2,600 sq km
chief of mission: Ambassador Hugo FERNANDEZ-FAINGOLD
chancery: 1913 I Street NW, Washington, DC 20006
telephone: [1] (202) 331-1313 through 1316
FAX: [1] (202) 331-8142
consulate(s) general: Chicago, Los Angeles, Miami, and New York
929,141 (2001)
350,000 (2001)
14 (2001)
400,000 (2002)
.uy
0.3% (2001 est.)
6,300 (2001 est.)
less than 500 (2001 est.)
UYU
42.3 (1989)
0 bbl/day (2001 est.)
41,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 31.8 years
male: 30.2 years
female: 33.4 years (2002)
0 cu m (2001 est.)
40 million cu m (2001 est.)
40 million cu m (2001 est.)
0 cu m (2001 est.)
United Nations Organization Mission in the Democratic Republic of the
Congo (MONUC): established - 30 November 1999
aim - to establish contacts with the signatories to the cease-fire
agreement and to plan for the observation of the cease-fire and
disengagement of forces
members - (51) Algeria, Argentina, Bangladesh, Belgium, Benin, Bolivia,
Burkina Faso, Cameroon, Canada, China, Cote d''Ivoire, Czech Republic,
Denmark, Egypt, France, Ghana, Guinea, India, Indonesia, Ireland,
Italy, Jordan, Kenya, Malawi, Malaysia, Mali, Mongolia, Morocco,
Mozambique, Nepal, Niger, Nigeria, Pakistan, Paraguay, Peru, Poland,
Portugal, Romania, Russia, Senegal, South Africa, Spain, Sri Lanka,
Sweden, Switzerland, Tunisia, Turkey, Ukraine, UK, Uruguay, Zambia
United Nations Peace-keeping Force in Cyprus (UNFICYP): established -
4 March 1964
aim - to serve as a peacekeeping force between Greek Cypriots and
Turkish Cypriots in Cyprus; established by the UN Security Council
members - (9) Argentina, Austria, Canada, Finland, Hungary, Ireland,
South Korea, Slovakia, UK
United Nations Population Fund (UNFPA): note - acronym retained from
predecessor organization UN Fund for Population Activities
established - NA July 1967
aim - to assist both developed and developing countries to deal with
their population problems
members (executive board ) - (36) selected on a rotating basis from all
regions
United Nations Preventive Deployment Force (UNPREDEP): established 31
March 1995; to monitor border activity in the Former Yugoslav Republic
of Macedonia; members were Argentina, Bangladesh, Belgium, Brazil,
Canada, Czech Republic, Denmark, Egypt, Finland, Ghana, Indonesia,
Ireland, Jordan, Kenya, Nepal, NZ, Nigeria, Norway, Pakistan, Poland,
Portugal, Russia, Sweden, Switzerland, Turkey, Ukraine, US; mandate
ended 25 March 1999
United Nations Relief and Works Agency for Palestine Refugees in the
Near East (UNRWA): established - 8 December 1949
aim - to provide assistance to Palestinian refugees
members (advisory commission) - (10) Belgium, Egypt, France, Japan,
Jordan, Lebanon, Syria, Turkey, UK, US
United Nations Research Institute for Social Development (UNRISD):
established - NA 1963
aim - to conduct research into the problems of economic development
during different phases of economic growth
members - no country members, but a Board of Directors consisting of a
chairman appointed by the UN secretary general and 11 individual
members
United Nations Secretariat: established - 26 June 1945; effective - 24
October 1945
aim - to serve as the primary administrative organ of the UN; a
Secretary General is appointed for a five-year term by the General
Assembly on the recommendation of the Security Council
members - the UN Secretary General and staff
United Nations Security Council (UNSC): established - 26 June 1945;
effective - 24 October 1945
aim - to maintain international peace and security
permanent members - (5) China, France, Russia, UK, US
nonpermanent members - (10) elected for two-year terms by the UN
General Assembly; Angola (2003-04), Bulgaria (2002-03), Cameroon (2002-
03), Chile (2003-04), Germany (2003-04), Guinea (2002-03), Mexico
(2002-03), Pakistan (2003-04), Spain (2003-04), Syria (2002-03)
United Nations Transitional Administration in East Timor (UNTAET):
established 25 October 1999 to provide security throughout the
territory of East Timor; to establish an effective administration; to
ensure the coordination and delivery of humanitarian assistance; to
support capacity-building for self-government; 28 members including
Australia, Bangladesh, Bolivia, Brazil, Chile, Denmark, Egypt, Fiji,
Ireland, Jordan, South Korea, Malaysia, Mozambique, Nepal, NZ, Norway,
Pakistan, Philippines, Portugal, Russia, Singapore, Slovakia, Sweden,
Thailand, Turkey, UK, US, Uruguay
United Nations Truce Supervision Organization (UNTSO): established -
NA June 1948
aim - to supervise the 1948 Arab-Israeli cease-fire; currently supports
timely deployment of reinforcements to other peacekeeping operations in
the region as needed; initially established by the UN Security Council
members - (23) Argentina, Australia, Austria, Belgium, Canada, Chile,
China, Denmark, Estonia, Finland, France, Ireland, Italy, Nepal,
Netherlands, NZ, Norway, Russia, Slovakia, Slovenia, Sweden,
Switzerland, US
United Nations Trusteeship Council: established on 26 June 1945,
effective on 24 October 1945, to supervise the administration of the 11
UN trust territories; members were China, France, Russia, UK, US; it
formally suspended operations 1 November 1995 after the Trust Territory
of the Pacific Islands (Palau) became the Republic of Palau, a
constitutional government in free association with the US; the
Trusteeship Council was not dissolved
United Nations University (UNU): established - 3 December 1973
aim - to conduct research in development, welfare, and human survival
and to train scholars
members - (24 members of UNU Council and the Rector are appointed by
the Secretary General of the United Nations and the Director General of
UNESCO)
Universal Postal Union (UPU): established - 9 October 1874, affiliated
with the UN 15 November 1947; effective - 1 July 1948
aim - to promote international postal cooperation; a UN specialized
agency
members - (187) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy
See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,','55a739b49efe4938b9a1f6d84f87bfbad791d800a877e9971200d76c3797f6e9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('670994caf537129a1e870d6ab457e3a817fc15bf1c96d945b37a903acb3e4cc2',2003,'UZ','Uzbekistan','communications',796,'general assessment: antiquated and inadequate; in serious
need of modernization
domestic: the domestic telephone system is being expanded and
technologically improved, particularly in Tashkent (Toshkent) and
Samarqand, under contracts with prominent companies in
industrialized countries; moreover, by 1998, six cellular networks
had been placed in operation - four of the GSM type (Global System
for Mobile Communication), one D-AMPS type (Digital Advanced Mobile
Phone System), and one AMPS type (Advanced Mobile Phone System)
international: linked by landline or microwave radio relay with CIS
member states and to other countries by leased connection via the
Moscow international gateway switch; after the completion of the
Uzbek link to the Trans-Asia-Europe (TAE) fiber-optic cable,
Uzbekistan will be independent of Russian facilities for
international communications; Inmarsat also provides an
international connection, albeit an expensive one; satellite earth
stations - NA (1998)
mostly flat-to-rolling sandy desert with dunes; broad,
flat intensely irrigated river valleys along course of Amu Darya,
Syr Darya (Sirdaryo), and Zarafshon; Fergana Valley in east
surrounded by mountainous Tajikistan and Kyrgyzstan; shrinking Aral
Sea in west
3 children born/woman (2003 est.)
republic; authoritarian presidential rule, with little
power outside the executive branch
10% plus another 20% underemployed (1999 est.)
conventional long form: Republic of Uzbekistan
conventional short form: Uzbekistan
local long form: Ozbekiston Respublikasi
local short form: Ozbekiston
former: Uzbek Soviet Socialist Republic
Central Asia, north of Afghanistan
Asia
42,810 sq km (1998 est.)
total: 447,400 sq km
land: 425,400 sq km
water: 22,000 sq km
chief of mission: Ambassador Abdulaziz KAMILOV
chancery: 1746 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 293-6803
FAX: [1] (202) 293-6804
consulate(s) general: New York
1.98 million (1999)
130,000 (2003)
42 (2000)
100,000 (2002)
.uz
less than 0.1% (2001 est.)
less than 740 (2001 est.)
less than 100 (2001 est.)
UZS
44.7 (1998)
Venezuela
49.5 (1998)
Vietnam
36.1 (1998)
142,700 bbl/day (2001 est.)
142,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 21.8 years
male: 21.2 years
female: 22.5 years (2002)
297 million bbl (37257)
Venezuela
63.95 billion bbl (37257)
Vietnam
1.4 billion bbl (37257)
World
1.025 trillion bbl (37257)
937.3 billion cu m (37257)
Venezuela
4.202 trillion cu m (37257)
Vietnam
192.6 billion cu m (37257)
World
161.2 trillion cu m (37257)
63.1 billion cu m (2001 est.)
Venezuela
31.71 billion cu m (2001 est.)
Vietnam
1.3 billion cu m (2001 est.)
World
2.569 trillion cu m (2001 est.)
45.2 billion cu m (2001 est.)
Venezuela
31.71 billion cu m (2001 est.)
Vietnam
1.3 billion cu m (2001 est.)
World
2.556 trillion cu m (2001 est.)
0 cu m (2001 est.)
Venezuela
0 cu m (2001 est.)
Vietnam
0 cu m (2001 est.)
World
697.5 billion cu m (2001 est.)
17.9 billion cu m (2001 est.)
Venezuela
0 cu m (2001 est.)
Vietnam
0 cu m (2001 est.)
World
703.9 billion cu m (2001 est.)
Communist countries: traditionally the Marxist-Leninist states with
authoritarian governments and command economies based on the Soviet
model; most of the original and the successor states are no longer
Communist; see centrally planned economies
Coordinating Committee on Export Controls (COCOM): established in 1949
to control the export of strategic products and technical data from
member countries to proscribed destinations; members were Australia,
Belgium, Canada, Denmark, France, Germany, Greece, Italy, Japan,
Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey, UK, US;
abolished 31 March 1994; COCOM members established a new organization,
the Wassenaar Arrangement, with expanded membership on 12 July 1996
which focuses on nonproliferation export controls as opposed to East-
West control of advanced technology
Council for Mutual Economic Assistance (CEMA): note - also known as
CMEA or Comecon
established 25 January 1949 to promote the development of socialist
economies and abolished 1 January 1991; members included Afghanistan
(observer), Albania (had not participated since 1961 break with USSR),
Angola (observer), Bulgaria, Cuba, Czechoslovakia, Ethiopia (observer),
GDR, Hungary, Laos (observer), Mongolia, Mozambique (observer),
Nicaragua (observer), Poland, Romania, USSR, Vietnam, Yemen (observer),
Yugoslavia (associate)
Council of Arab Economic Unity (CAEU): established - 3 June 1957;
effective - 30 May 1964
aim - to promote economic integration among Arab nations
members - (10 plus the Palestine Liberation Organization) Egypt, Iraq,
Jordan, Kuwait, Libya, Mauritania, Somalia, Syria, UAE, Yemen,
Palestine Liberation Organization
Council of Europe (CE): established - 5 May 1949; effective - 3 August
1949
aim - to promote increased unity and quality of life in Europe
members - (44) Albania, Andorra, Armenia, Austria, Azerbaijan, Belgium,
Bosnia and Herzegovina, Bulgaria, Croatia, Cyprus, Czech Republic,
Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary,
Iceland, Ireland, Italy, Latvia, Liechtenstein, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Malta, Moldova, Netherlands,
Norway, Poland, Portugal, Romania, Russia, San Marino, Slovakia,
Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK
guests - (1) Serbia and Montenegro
observers - (6) Canada, Holy See, Israel, Japan, Mexico, US
Council of the Baltic Sea States (CBSS): established - 6 March 1992
aim - to promote cooperation among the Baltic Sea states in the areas
of aid to new democratic institutions, economic development,
humanitarian aid, energy and the environment, cultural programs and
education, and transportation and communication
members - (12) Denmark, Estonia, EC, Finland, Germany, Iceland, Latvia,
Lithuania, Norway, Poland, Russia, Sweden
Council of the Entente (Entente): established - 29 May 1959
aim - to promote economic, social, and political coordination
members - (5) Benin, Burkina Faso, Cote d''Ivoire, Niger, Togo
countries in transition: a term used by the International Monetary
Fund (IMF) for the middle group in its hierarchy of advanced economies,
countries in transition, and developing countries; recently published
IMF statistics include the following 28 countries in transition:
Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic
of Macedonia, Moldova, Mongolia, Poland, Romania, Russia, Serbia and
Montenegro, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan; note - this group is identical to the group traditionally
referred to as the "former USSR/Eastern Europe" except for the addition
of Mongolia
Customs Cooperation Council (CCC): note - see World Customs
Organization (WCO)
developed countries (DCs): the top group in the hierarchy of developed
countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less
developed countries (LDCs); includes the market-oriented economies of
the mainly democratic nations in the Organization for Economic
Cooperation and Development (OECD), Bermuda, Israel, South Africa, and
the European ministates; also known as the First World, high-income
countries, the North, industrial countries; generally have a per capita
GDP in excess of $10,000 although four OECD countries and South Africa
have figures well under $10,000 and two of the excluded OPEC countries
have figures of more than $10,000; the 34 DCs are: Andorra, Australia,
Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland,
France, Germany, Greece, Holy See, Iceland, Ireland, Israel, Italy,
Japan, Liechtenstein, Luxembourg, Malta, Monaco, Netherlands, NZ,
Norway, Portugal, San Marino, South Africa, Spain, Sweden, Switzerland,
Turkey, UK, US; note - similar to the new International Monetary Fund
(IMF) term "advanced economies" which adds Hong Kong, South Korea,
Singapore, and Taiwan but drops Malta, Mexico, South Africa, and Turkey
developing countries: a term used by the International Monetary Fund
(IMF) for the bottom group in its hierarchy of advanced economies,
countries in transition, and developing countries; recently published
IMF statistics include the following 126 developing countries:
Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Aruba,
The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan,
Bolivia, Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia,
Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica,
Jordan, Kenya, Kiribati, Kuwait, Laos, Lebanon, Lesotho, Liberia,
Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Morocco, Mozambique, Namibia, Nepal, Netherlands Antilles, Nicaragua,
Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia,
South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania,
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, UAE, Uganda,
Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; note -
this category would presumably also cover the following 46 other
countries that are traditionally included in the more comprehensive
group of "less developed countries": American Samoa, Anguilla, British
Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos
Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana,
French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada,
Guadeloupe, Guam, Guernsey, Jersey, North Korea, Macau, Isle of Man,
Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk
Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico,
Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks
and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West
Bank, Western Sahara
East African Development Bank (EADB): established - 6 June 1967;
effective - 1 December 1967
aim - to promote economic development
members - (3) Kenya, Tanzania, Uganda
Economic and Social Council (ECOSOC): established - 26 June 1945;
effective - 24 October 1945
aim - to coordinate the economic and social work of the UN; includes
five regional commissions (Economic Commission for Africa, Economic
Commission for Europe, Economic Commission for Latin America and the
Caribbean, Economic and Social Commission for Asia and the Pacific,
Economic and Social Commission for Western Asia) and nine functional
commissions (Commission for Social Development, Commission on Human
Rights, Commission on Narcotic Drugs, Commission on the Status of
Women, Commission on Population and Development, Statistical
Commission, Commission on Science and Technology for Development,
Commission on Sustainable Development, and Commission on Crime
Prevention and Criminal Justice)
members - (54) selected on a rotating basis from all regions
Economic Community of the Great Lakes Countries (CEPGL): note -
acronym from Communaute Economique des Pays des Grands Lacs
established - 20 September 1976
aim - to promote regional economic cooperation and integration
members - (3) Burundi, Democratic Republic of the Congo, Rwanda
Economic Community of West African States (ECOWAS): established - 28
May 1975
aim - to promote regional economic cooperation
members - (15) Benin, Burkina Faso, Cape Verde, Cote d''Ivoire, The
Gambia, Ghana, Guinea, Guinea-Bissau, Liberia, Mali, Niger, Nigeria,
Senegal, Sierra Leone, Togo
Economic Cooperation Organization (ECO): established - 27-29 January
1985
aim - to promote regional cooperation in trade, transportation,
communications, tourism, cultural affairs, and economic development
members - (10) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan,
Pakistan, Tajikistan, Turkey, Turkmenistan, Uzbekistan
associate member - (1) "Turkish Republic of Northern Cyprus"
Economic and Monetary Union (EMU): note - an integral part of the
European Union; also known as the European Economic and Monetary Union
proposed - 1-2 December 1969 at summit conference of heads of
government; signed - 7 February 1992 - Maastricht Treaty
aim - to promote a single market by creating a single currency, the
euro; timetable - 2 May 1998: European exchange rates fixed for 1
January 1999; 1 January 1999: all banks and stock exchanges begin using
euros; 1 January 2002: the euro goes into circulation; 1 July 2002
local currencies no longer accepted
members - (12) Austria, Belgium, Finland, France, Germany, Greece,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain; note -
Denmark, Sweden, and UK decided not to join
Euro-Atlantic Partnership Council (EAPC): note - began as the North
Atlantic Cooperation Council (NACC); an extension of NATO
established - 8 November 1991; effective - 20 December 1991
aim - to discuss cooperation on mutual political and security issues
members - (46) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium,
Bulgaria, Canada, Croatia, Czech Republic, Denmark, Estonia, Finland,
France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Moldova, Netherlands, Norway, Poland,
Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US,
European Bank for Reconstruction and Development (EBRD): established -
8-9 January 1990 (proposals made); 15 April 1991 (bank inaugurated)
aim - to facilitate the transition of seven centrally planned economies
in Europe (Bulgaria, former Czechoslovakia, Hungary, Poland, Romania,
former USSR, and former Yugoslavia) to market economies by committing
60% of its loans to privatization
members - (62) Albania, Armenia, Australia, Austria, Azerbaijan,
Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Cyprus, Czech Republic, Denmark, Egypt, EU, European Investment Bank
(EIB), Estonia, Finland, France, Georgia, Germany, Greece, Hungary,
Iceland, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Malta, Mexico, Moldova, Mongolia,
Morocco, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia,
Serbia and Montenegro, Slovakia, Slovenia, Spain, Sweden, Switzerland,
Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
European Community (or European Communities, EC): was established 8
April 1965 to integrate the European Atomic Energy Community (Euratom),
the European Coal and Steel Community (ESC), the European Economic
Community (EEC or Common Market), and to establish a completely
integrated common market and an eventual federation of Europe; merged
into the European Union (EU) on 7 February 1992; member states at the
time of merger were Belgium, Denmark, France, Germany, Greece, Ireland,
Italy, Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association (EFTA): established - 4 January 1960;
effective - 3 May 1960
aim - to promote expansion of free trade
members - (4) Iceland, Liechtenstein, Norway, Switzerland
European Investment Bank (EIB): established - 25 March 1957; effective
- 1 January 1958
aim - to promote economic development of the EU and its predecessors,
the EEC and the EC
members - (15) Austria, Belgium, Denmark, Finland, France, Germany,
Greece, Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain,
Sweden, UK
European Organization for Nuclear Research (CERN): note - acronym
retained from the predecessor organization Conseil Europeenne pour la
Recherche Nucleaire
established - 1 July 1953; effective - 29 September 1954
aim - to foster nuclear research for peaceful purposes only
members - (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark,
Finland, France, Germany, Greece, Hungary, Italy, Netherlands, Norway,
Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers - (7) European Commission, Israel, Japan, Russia, Turkey,
United Nations Educational, Scientific, and Cultural Organization
(UNESCO), US
European Space Agency (ESA): established - 31 May 1975
aim - to promote peaceful cooperation in space research and technology
members - (15) Austria, Belgium, Denmark, Finland, France, Germany,
Ireland, Italy, Netherlands, Norway, Portugal, Spain, Sweden,
Switzerland, UK
cooperating state - (1) Canada
European Union (EU): note - evolved from the European Community (EC)
established - 7 February 1992; effective - 1 November 1993
aim - to coordinate policy among the 15 members in three fields:
economics, building on the European Economic Community''s (EEC) efforts
to establish a common market and eventually a common currency to be
called the ''euro'', which superseded the EU''s accounting unit, the ECU;
defense, within the concept of a Common Foreign and Security Policy
(CFSP); and justice and home affairs, including immigration, drugs,
terrorism, and improved living and working conditions
members - (15) Austria, Belgium, Denmark, Finland, France, Germany,
Greece, Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain,
Sweden, UK
membership applicants - (13) Bulgaria, Cyprus, Czech Republic, Estonia,
Hungary, Latvia, Lithuania, Malta, Poland, Romania, Slovakia, Slovenia,
Turkey
First World: another term for countries with advanced, industrialized
economies; this term is fading from use; see developed countries (DCs)
Food and Agriculture Organization (FAO): established - 16 October 1945
aim - to raise living standards and increase availability of
agricultural products; a UN specialized agency
members - (184) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, EC, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia
and Montenegro, Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon
Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
former Soviet Union (FSU): former term often used to identify as a
group the successor nations to the Soviet Union or USSR; this group of
15 countries consists of Armenia, Azerbaijan, Belarus, Estonia,
Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan, Ukraine, Uzbekistan
former USSR/Eastern Europe (former USSR/EE): the middle group in the
hierarchy of developed countries (DCs), former USSR/Eastern Europe
(former USSR/EE), and less developed countries (LDCs); these countries
are in political and economic transition and may well be grouped
differently in the near future; this group of 27 countries consists of
Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic
of Macedonia, Moldova, Poland, Romania, Russia, Slovakia, Slovenia,
Tajikistan, Turkmenistan, Ukraine, Uzbekistan, Yugoslavia; this group
is identical to the IMF group "countries in transition" except for the
IMF''s inclusion of Mongolia
Four Dragons: the four small Asian less developed countries (LDCs)
that have experienced unusually rapid economic growth; also known as
the Four Tigers; this group consists of Hong Kong, South Korea,
Singapore, Taiwan; these countries are included in the IMF''s "advanced
economies" group
Franc Zone (FZ): note - also known as Conference des Ministres des
Finances des Pays de la Zone Franc
established - NA 1964
aim - to form a monetary union among countries whose currencies are
linked to the French franc
members - (15) Benin, Burkina Faso, Cameroon, Central African Republic,
Chad, Comoros, Republic of the Congo, Cote d''Ivoire, Equatorial Guinea,
Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo; note - France''s three
overseas territories, French Polynesia, New Caledonia, and Wallis and
Futuna, use the Comptoires Francais du Pacifique francs (XPF)
Front Line States (FLS): established to achieve black majority rule in
South Africa; has since gone out of existence; members included Angola,
Botswana, Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade (GATT): see the World Trade
Organization (WTrO)
Group of 2 (G-2): informal term that came into use about 1986; to
facilitate bilateral economic cooperation between the two most powerful
economic giants; members were Japan, US
Group of 3 (G-3): established - NA September 1990
aim - mechanism for policy coordination
members - (3) Colombia, Mexico, Venezuela
Group of 5 (G-5): established - 22 September 1985
aim - to coordinate the economic policies of five major noncommunist
economic powers
members - (5) France, Germany, Japan, UK, US
Group of 6 (G-6): note - also known as Groupe des Six Sur le
Desarmement; not to be confused with the Big Six
established - 22 May 1984
aim - to achieve nuclear disarmament
members - (6) Argentina, Greece, India, Mexico, Sweden, Tanzania
Group of 7 (G-7): note - membership is the same as the Big Seven
established - 22 September 1985
aim - to facilitate economic cooperation among the seven major
noncommunist economic powers
members - (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada
and Italy
Group of 8 (G-8): established - NA October 1975
aim - to facilitate economic cooperation among the developed countries
(DCs) that participated in the Conference on International Economic
Cooperation (CIEC), held in several sessions between NA December 1975
and 3 June 1977
members - (9) Canada, EU (as one member), France, Germany, Italy,
Japan, Russia, UK, US
Group of 9 (G-9): established - NA
aim - to discuss matters of mutual interest on an informal basis
members - (9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary,
Romania, Serbia and Montenegro, Sweden
Group of 10 (G-10): note - also known as the Paris Club; i','6d7441084fde4612a1f90dc5c976dc1fdbecf656e356112e0e6880c1a7b5c4cb','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c40ed4ee3c984199021ee8b06207cd6ab6030feb9e8beda6e71478559e11532',2003,'UZ','Uzbekistan','communications',797,'ncludes the
wealthiest members of the IMF who provide most of the money to be
loaned and act as the informal steering committee; name persists in
spite of the addition of Switzerland on NA April 1984
established - NA October 1962
aim - to coordinate credit policy
members - (11) Belgium, Canada, France, Germany, Italy, Japan,
Netherlands, Sweden, Switzerland, UK, US
nonstate participants - (4) BIS, EU, IMF, OECD
Group of 11 (G-11): note - also known as the Cartagena Group;
established in 21-22 June 1984, in Cartagena, Colombia; aim was to
provide a forum for largest debtor nations in Latin America; members
were Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic,
Ecuador, Mexico, Peru, Uruguay, Venezuela
Group of 15 (G-15): note - byproduct of the Nonaligned Movement
established - NA September 1989
aim - to promote economic cooperation among developing nations; to act
as the main political organ for the Nonaligned Movement
members - (19) Algeria, Argentina, Brazil, Chile, Colombia, Egypt,
India, Indonesia, Iran, Jamaica, Kenya, Malaysia, Mexico, Nigeria,
Peru, Senegal, Sri Lanka, Venezuela, Zimbabwe
Group of 24 (G-24): established - 1 August 1989
aim - to promote the interests of developing countries in Africa, Asia,
and Latin America within the IMF
members - (24) Algeria, Argentina, Brazil, Colombia, Democratic
Republic of the Congo, Cote d''Ivoire, Egypt, Ethiopia, Gabon, Ghana,
Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru,
Philippines, South Africa, Sri Lanka, Syria, Trinidad and Tobago,
Venezuela
Group of 77 (G-77): established - 15 June1964; NA October 1967 first
ministerial meeting
aim - to promote economic cooperation among developing countries; name
persists in spite of increased membership
members - (133 plus the Palestine Liberation Organization) Afghanistan,
Algeria, Angola, Antigua and Barbuda, Argentina, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran,
Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon,
Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Federated States of
Micronesia, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua,
Niger, Nigeria, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Qatar, Romania, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome
and Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles,
Sierra Leone, Singapore, Solomon Islands, Somalia, South Africa, Sri
Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE,
Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe,
Palestine Liberation Organization
Gulf Cooperation Council (GCC): note - also known as the Cooperation
Council for the Arab States of the Gulf
established - 25 May 1981
aim - to promote regional cooperation in economic, social, political,
and military affairs
members - (6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
GUUAM: note - acronym standing for the member countries, Georgia,
Uzbekistan, Ukraine, Azerbaijan, Moldova
established - 7 June 2001
aim - commits the countries to cooperation and assistance in social and
economic development, the strengthening and broadening of trade and
economic relations, and the development and effective use of transport
and communications, highways, and related infrastructure crossing the
boundaries of the member states
members - (5) Azerbaijan, Georgia, Moldova, Ukraine, Uzbekistan
high-income countries: another term for the industrialized countries
with high per capita GDPs; see developed countries (DCs)
Indian Ocean Commission (InOC): established - 21 December 1982
aim - to organize and promote regional cooperation in all sectors,
especially economic
members - (5) Comoros, France (for Reunion), Madagascar, Mauritius,
new independent states (NIS): a term referring to all those countries
of the FSU except the Baltic countries (Estonia, Latvia, Lithuania)
newly industrializing countries (NICs): former term for the newly
industrializing economies; see newly industrializing economies (NIEs)
newly industrializing economies (NIEs): that subgroup of the less
developed countries (LDCs) that has experienced particularly rapid
industrialization of their economies; formerly known as the newly
industrializing countries (NICs); also known as advanced developing
countries; usually includes the Four Dragons (Hong Kong, South Korea,
Singapore, Taiwan), and Brazil
Nonaligned Movement (NAM): established - 1-6 September 1961
aim - to establish political and military cooperation apart from the
traditional East or West blocs
members - (114 plus the Palestine Liberation Organization) Afghanistan,
Algeria, Angola, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic,
Chad, Chile, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominican
Republic, Ecuador, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon,
The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North
Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger,
Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines,
Qatar, Rwanda, Saint Lucia, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore,
Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkmenistan,
Uganda, UAE, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,
Zimbabwe, Palestine Liberation Organization
observers - (13) Armenia, Belarus, Brazil, China, Costa Rica, Croatia,
Dominica, Kazakhstan, Kyrgyzstan, Mexico, Paraguay, Ukraine, Uruguay
guests - (28) Australia, Austria, Bosnia and Herzegovina, Bulgaria,
Canada, Finland, France, Germany, Greece, Holy See, Hungary, Ireland,
Italy, Japan, South Korea, Netherlands, NZ, Norway, Poland, Portugal,
Romania, Russia, Slovakia, Slovenia, Sweden, Switzerland, UK, US
Nordic Council (NC): established - 16 March 1952; effective - 12
February 1953
aim - to promote regional economic, cultural, and environmental
cooperation
members - (5) Denmark (including Faroe Islands and Greenland), Finland
(including Aland Islands), Iceland, Norway, Sweden
observers - (3) the Sami (Lapp) local parliaments of Finland, Norway,
and Sweden
Nordic Investment Bank (NIB): established - 4 December 1975; effective
- 1 June 1976
aim - to promote economic cooperation and development
members - (5) Denmark (including Faroe Islands and Greenland), Finland
(including Aland Islands), Iceland, Norway, Sweden
North: a popular term for the rich industrialized countries generally
located in the northern portion of the Northern Hemisphere; the
counterpart of the South; see developed countries (DCs)
North Atlantic Treaty Organization (NATO): established - 4 April 1949
aim - to promote mutual defense and cooperation
members - (19) Belgium, Canada, Czech Republic, Denmark, France,
Germany, Greece, Hungary, Iceland, Italy, Luxembourg, Netherlands,
Norway, Poland, Portugal, Spain, Turkey, UK, US
Nuclear Energy Agency (NEA): note - also known as OECD Nuclear Energy
Agency
established - 1 February 1958
aim - to promote the peaceful uses of nuclear energy; associated with
OECD
members - (28) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway,
Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
Nuclear Suppliers Group (NSG): note - also known as the London
Suppliers Group or the London Group
established - NA 1974; effective - NA 1975
aim - to establish guidelines for exports of nuclear materials,
processing equipment for uranium enrichment, and technical information
to countries of proliferation concern and regions of conflict and
instability
members - (40) Argentina, Australia, Austria, Belarus, Belgium, Brazil,
Bulgaria, Canada, Cyprus, Czech Republic, Denmark, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Japan, Kazakhstan, South
Korea, Latvia, Luxembourg, Netherlands, NZ, Norway, Poland, Portugal,
Romania, Russia, Slovakia, Slovenia, South Africa, Spain, Sweden,
Switzerland, Turkey, Ukraine, UK, US
observer - (1) European Commission (a policy-planning body for the EU)
Organization for Economic Cooperation and Development (OECD):
established - 14 December 1960; effective - 30 September 1961
aim - to promote economic cooperation and development
members - (30) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, NZ, Norway,
Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
special member - (1) EU
Organization for Security and Cooperation in Europe (OSCE): note -
formerly the Conference on Security and Cooperation in Europe (CSCE)
established 3 July 1975
established - 1 January 1995
aim - to foster the implementation of human rights, fundamental
freedoms, democracy, and the rule of law; to act as an instrument of
early warning, conflict prevention, and crisis management; and to serve
as a framework for conventional arms control and confidence building
measures
members - (55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus,
Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany,
Greece, Holy See, Hungary, Iceland, Ireland, Italy, Kazakhstan,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Malta, Moldova, Monaco, Netherlands,
Norway, Poland, Portugal, Romania, Russia, San Marino, Serbia and
Montenegro, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan,
Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
partners for cooperation - (9) Algeria, Egypt, Israel, Japan, Jordan,
South Korea, Morocco, Thailand, Tunisia
Organization for the Prohibition of Chemical Weapons (OPCW):
established - 29 April 1997
aim - to enforce the Convention on the Prohibition of the Development,
Production, Stockpiling and Use of Chemical Weapons and on Their
Destruction; to provide a forum for consultation and cooperation among
the signatories of the Convention
members - (148) Albania, Algeria, Argentina, Armenia, Australia,
Austria, Azerbaijan, Bahrain, Bangladesh, Belarus, Belgium, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burundi, Cameroon, Canada, Chile, China, Colombia, Cook
Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Ecuador, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Guinea, Guyana, Holy See, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Laos, Latvia,
Lesotho, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Saudi Arabia, Senegal, Serbia and
Montenegro, Seychelles, Singapore, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
signatory states - (25) Afghanistan, The Bahamas, Bhutan, Burma,
Cambodia, Cape Verde, Central African Republic, Chad, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Djibouti,
Dominican Republic, Grenada, Guinea-Bissau, Haiti, Honduras, Israel,
Kyrgyzstan, Liberia, Madagascar, Marshall Islands, Rwanda, Saint Kitts
and Nevis, Sierra Leone; note - states have signed but not ratified the
convention
Organization of African Unity (OAU): established 25 May 1963; to
promote unity and cooperation among African states; members were
Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon,
Cape Verde, Central African Republic, Chad, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Djibouti,
Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana,
Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya, Madagascar,
Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger,
Nigeria, Rwanda, Sahrawi Arab Democratic Republic, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa,
Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe;
ended 8 July 2001 with the establishment of the African Union
Organization of American States (OAS): established - 14 April 1890 as
the International Union of American Republics; 30 April 1948 adopted
present charter; effective - 13 December 1951
aim - to promote regional peace and security as well as economic and
social development
members - (35) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Cuba
(excluded from formal participation since 1962), Dominica, Dominican
Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti,
Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Suriname, Trinidad and Tobago, US, Uruguay, Venezuela
observers - (56) Algeria, Angola, Armenia, Austria, Azerbaijan,
Belgium, Bosnia and Herzegovina, Bulgaria, Croatia, Cyprus, Czech
Republic, Denmark, Egypt, Equatorial Guinea, Estonia, EU, Finland,
France, Georgia, Germany, Ghana, Greece, Holy See, Hungary, India,
Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Latvia,
Lebanon, Morocco, Netherlands, Norway, Pakistan, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Saudi Arabia, Serbia and Montenegro,
Slovakia, Spain, Sri Lanka, Sweden, Switzerland, Thailand, Tunisia,
Turkey, Ukraine, UK, Yemen
Organization of Arab Petroleum Exporting Countries (OAPEC):
established - 9 January 1968
aim - to promote cooperation in the petroleum industry
members - (11) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar,
Saudi Arabia, Syria, Tunisia, UAE
Organization of Eastern Caribbean States (OECS): established - 18 June
1981; effective - 4 July 1981
aim - to promote political, economic, and defense cooperation
members - (7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines
associate members - (2) Anguilla, British Virgin Islands
Organization of Petroleum Exporting Countries (OPEC): established - 14
September 1960
aim - to coordinate petroleum policies
members - (11) Algeria, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria,
Qatar, Saudi Arabia, UAE, Venezuela
Organization of the Islamic Conference (OIC): established - 22-25
September 1969
aim - to promote Islamic solidarity in economic, social, cultural, and
political affairs
members - (56 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Cote d''Ivoire, Djibouti, Egypt,
Gabon, The Gambia, Guinea, Guinea-Bissau, Guyana, Indonesia, Iran,
Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia,
Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman,
Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan,
Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan,
Uganda, UAE, Uzbekistan, Yemen, Palestine Liberation Organization
observers - (10) Bosnia and Herzegovina, Central African Republic, ECA,
LAS, Moro National Liberation Front, NAM, OAU, Thailand, Turkish Muslim
Community of Kibris, UN
Pacific Community: note - formerly known as the South Pacific
Commission (SPC)
established - 6 February 1947; effective - 29 July 1948
aim - to promote regional cooperation in economic and social matters
members - (27) American Samoa, Australia, Cook Islands, Fiji, France,
French Polynesia, Guam, Kiribati, Marshall Islands, Federated States of
Micronesia, Nauru, New Caledonia, NZ, Niue, Northern Mariana Islands,
Palau, Papua New Guinea, Pitcairn Islands, Samoa, Solomon Islands,
Tokelau, Tonga, Tuvalu, UK, US, Vanuatu, Wallis and Futuna
Pacific Island Forum : note - formerly known as South Pacific Forum
(SPF)
established - 5 August 1971
aim - to promote regional cooperation in political matters
members - (16) Australia, Cook Islands, Fiji, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua
New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
observer - (1) New Caledonia
Paris Club: established - 1956
aim - to provide a forum for debtor countries to negotiate rescheduling
of debt service payments or loans extended by governments or official
agencies of participating countries; to help restore normal trade and
project finance to debtor countries
members - (19) Austria, Australia, Belgium, Canada, Denmark, Finland,
France, Germany, Ireland, Italy, Japan, Netherlands, Norway, Russia,
Spain, Sweden, Switzerland, UK, US
Partnership for Peace (PFP): established - 10-11 January 1994
aim - to expand and intensify political and military cooperation
throughout Europe, increase stability, diminish threats to peace, and
build relationships by promoting the spirit of practical cooperation
and commitment to democratic principles that underpin NATO; program
under the auspices of NATO
members - (30) Albania, Armenia, Austria, Azerbaijan, Belarus,
Bulgaria, Croatia, Czech Republic, Estonia, Finland, Georgia, Hungary,
Ireland, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav
Republic of Macedonia, Moldova, Poland, Romania, Russia, Slovakia,
Slovenia, Sweden, Switzerland, Tajikistan, Turkmenistan, Ukraine,
Permanent Court of Arbitration (PCA): established - 29 July 1899
aim - to facilitate the settlement of international disputes
members - (97) Argentina, Australia, Austria, Belarus, Belgium,
Bolivia, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon, Canada,
Chile, China, Colombia, Democratic Republic of the Congo, Costa Rica,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic,
Ecuador, Egypt, El Salvador, Eritrea, Fiji, Finland, France, Germany,
Greece, Guatemala, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Iran, Iraq, Ireland, Israel, Italy, Japan, Jordan, South Korea,
Kyrgyzstan, Laos, Latvia, Lebanon, Libya, Liechtenstein, Luxembourg,
The Former Yugoslav Republic of Macedonia, Malaysia, Malta, Mauritius,
Mexico, Morocco, Netherlands, NZ, Nicaragua, Nigeria, Norway, Pakistan,
Panama, Paraguay, Peru, Poland, Portugal, Romania, Russia, Saudi
Arabia, Senegal, Serbia and Montenegro, Singapore, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Thailand, Turkey, Uganda, Ukraine, UK, US, Uruguay,
Venezuela, Zambia, Zimbabwe
Rio Group (RG): note - formerly known as Grupo de los Ocho,
established NA December 1986; composed of the Contadora Group and the
Lima Group
established - NA 1988
aim - to consult on regional Latin American issues
members - (19) Argentina, Bolivia, Brazil, Chile, Colombia, Costa Rica,
Dominican Republic, Ecuador, El Salvador, Guatemala, Guyana, Honduras,
Mexico, Nicaragua, Panama, Paraguay, Peru, Uruguay, Venezuela
Second World: another term for the traditionally Marxist-Leninist
states of the USSR and Eastern Europe, with authoritarian governments
and command economies based on the Soviet model; the term is fading
from use; see centrally planned economies
Shanghai Cooperative Organization (SCO): established - 15 June 2001
aim - to combat terrorism, extremism, and separatism; to safeguard
regional security through mutual trust, disarmament, and cooperative
security; and to increase cooperation in political, trade, economic,
scientific and technological, cultural, and educational fields
members - (6) China, Kazakhstan, Kyrgyzstan, Russia, Tajikistan,
socialist countries: in general, countries in which the government
owns and plans the use of the major factors of production; note - the
term is sometimes used incorrectly as a synonym for Communist countries
South: a popular term for the poorer, less industrialized countries
generally located south of the developed countries; the counterpart of
the North; see less developed countries (LDCs)
South Asian Association for Regional Cooperation (SAARC): established
- 8 December 1985
aim - to promote economic, social, and cultural cooperation
members - (7) Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri
Lanka
South Pacific Forum (SPF): note - see Pacific Island Forum
South Pacific Regional Trade and Economic Cooperation Agreement
(Sparteca): established - NA 1981
aim - to redress unequal trade relationships of Australia and New
Zealand with small island economies in the Pacific region
members - (16) Australia, Cook Islands, Fiji, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua
New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
Southern African Customs Union (SACU): established - 11 December 1969
aim - to promote free trade and cooperation in customs matters
members - (5) Botswana, Lesotho, Namibia, South Africa, Swaziland
Southern African Development Community (SADC): note - evolved from the
Southern African Development Coordination Conference (SADCC)
established - 17 August 1992
aim - to promote regional economic development and integration
members - (14) Angola, Botswana, Democratic Republic of the Congo,
Lesotho, Malawi, Mauritius, Mozambique, Namibia, Seychelles, South
Africa, Swaziland, Tanzania, Zambia, Zimbabwe
Southern Cone Common Market (Mercosur) or Southern Common Market: note
- also known as Mercado Comun del Cono Sur (Mercosur)
established - 26 March 1991
aim - to increase regional economic cooperation
members - (4) Argentina, Brazil, Paraguay, Uruguay
associate member - (2) Bolivia, Chile
Third World: another term for the less developed countries; the term
is obsolescent; see less developed countries (LDCs)
underdeveloped countries: refers to those less developed countries
with the potential for above-average economic growth; see less
developed countries (LDCs)
undeveloped countries: refers to those extremely poor less developed
countries (LDCs) with little prospect for economic growth; see least
developed countries (LLDCs)
United Nations (UN): established - 26 June 1945; effective - 24
October 1945
aim - to maintain international peace and security and to promote
cooperation involving econo','1f558a5c415837577e4e1c08cb50405e18593f400d7909b2f0209e94ecc55495','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b5478ce05b1e439c937d0f581316d97591f867eeec96f8299a4e3b695c55c1b',2003,'UZ','Uzbekistan','communications',798,'mic, social, cultural, and humanitarian
problems
constituent organizations - the UN is composed of six principal organs
and numerous subordinate agencies and bodies as follows:
1) Secretariat
2) General Assembly: Joint United Nations Program on HIV/AIDS,
International Research and Training Institute for the Advancement of
Women (INSTRAW), Office of the United Nations High Commissioner for
Human Rights, United Nations Center for Human Settlements (Habitat),
United Nations Children''s Fund (UNICEF), United Nations Conference on
Trade and Development (UNCTAD), United Nations Development Program
(UNDP), United Nations Drug Control Program (UNDCP), United Nations
Environment Program (UNEP), United Nations High Commissioner for Human
Rights (UNHCHR), United Nations High Commissioner for Refugees (UNHCR),
United Nations Institute for Disarmament Research (UNIDIR), United
Nations Institute for Training and Research (UNITAR), United Nations
Interregional Crime and Justice Research Institute (UNICRI), United
Nations Population Fund (UNFPA), United Nations Office of Project
Services (UNOPS), United Nations Relief and Works Agency for Palestine
Refugees in the Near East (UNRWA), United Nations Research Institute
for Social Development (UNRISD), United Nations System Staff College
(UNSSC), and United Nations University (UNU), World Food Program (WFP)
3) Security Council: International Criminal Tribunal for the Former
Yugoslavia (ICTY), International Criminal Tribunal for Rwanda (ICTR),
United Nations Assistance Mission in Afghanistan (ANAMA), United
Nations Compensation Commission, United Nations Disengagement Observer
Force (UNDOF), United Nations Interim Administration Mission in Kosovo
(UNMIK), United Nations Interim Force in Lebanon (UNIFIL), United
Nations Iraq/Kuwait Boundary Demarcation Commission, United Nations
Iraq-Kuwait Observation Mission (UNIKOM), United Nations Military
Observer Group in India and Pakistan (UNMOGIP), United Nations Mission
for the Referendum in Western Sahara (MINURSO), United Nations Mission
in Ethiopia and Eritrea (UNMEE), United Nations Mission in Sierra Leone
(UNAMSIL), United Nations Monitoring and Verification Commission
(UNMOVIC), United Nations Observer Mission in Georgia (UNOMIG), United
Nations Organization Mission in the Democratic Republic of the Congo
(MONUC), United Nations Peace-Keeping Force in Cyprus (UNFICYP), United
Nations Transitional Administration in East Timor (UNTAET), and United
Nations Truce Supervision Organization (UNTSO)
4) Economic and Social Council (ECOSOC): Commission for Social
Development, Commission on Crime Prevention and Criminal Justice,
Commission on Human Rights, Commission on Narcotics Drugs, Commission
on Population and Development, Commission on Science and Technology for
Development, Commission on Sustainable Development, Commission on the
Status of Women, Economic and Social Commission for Asia and the
Pacific (ESCAP), Economic and Social Commission for Western Asia
(ESCWA), Economic Commission for Africa (ECA), Economic Commission for
Europe (ECE), Economic Commission for Latin America and the Caribbean
(ECLAC), Food and Agriculture Organization of the United Nations (FAO),
International Atomic Energy Agency (IAEA), International Bank for
Reconstruction and Development (IBRD), International Center for
Secretariat of Investment Disputes (ICSID), International Civil
Aviation Organization (ICAO), International Development Association
(IDA), International Finance Corporation (IFC), International Fund for
Agricultural Development (IFAD), International Labor Organization
(ILO), International Maritime Organization (IMO), International
Monetary Fund (IMF), International Telecommunication Union (ITU),
Multilateral Investment Geographic Agency (MIGA), Statistical
Commission, United Nations Educational, Scientific, and Cultural
Organization (UNESCO), United Nations Forum on Forests, United Nations
Industrial Development Organization (UNIDO), Universal Postal Union
(UPU), World Health Organization (WHO), World Intellectual Property
Organization (WIPO), World Meteorological Organization (WMO), World
Tourism Organization (WToO), and World Trade Organization (WTrO)
5) Trusteeship Council (inactive; no trusteeships at this time)
6) International Court of Justice (ICJ)
UN members - (191) Afghanistan, Albania, Algeria, Andorra, Angola,
Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE,
UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe; note - all UN members are represented in the General
Assembly
observers - (1 plus the Palestine Liberation Organization) Holy See,
Palestine Liberation Organization
United Nations Children''s Fund (UNICEF): note - acronym retained from
the predecessor organization, UN International Children''s Emergency
Fund
established - 11 December 1946
aim - to help establish child health and welfare services
members - (36) selected on a rotating basis from all regions
United Nations Civilian Police Mission in Haiti (MIPONUH): established
28 November 1997; to support the professionalization of the Haitian
National Police; established by UN Security Council; members were
Argentina, Benin, Canada, France, India, Mali, Niger, Senegal, Togo,
Tunisia, US; mission ended March 2000
United Nations Conference on Trade and Development (UNCTAD):
established - 30 December 1964
aim - to promote international trade
members - (191) all UN members plus Holy See
United Nations Development Program (UNDP): established - 22 November
1965
aim - to provide technical assistance to stimulate economic and social
development
members (executive board) - (36) selected on a rotating basis from all
regions
United Nations Disengagement Observer Force (UNDOF): established - 31
May 1974
aim - to observe the 1973 Arab-Israeli cease-fire; established by the
UN Security Council
members - (6) Austria, Canada, Japan, Poland, Slovakia, Sweden
United Nations Educational, Scientific, and Cultural Organization
(UNESCO): established - 16 November 1945; effective - 4 November 1946
aim - to promote cooperation in education, science, and culture
members - (188) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members - (6) Aruba, British Virgin Islands, Cayman Islands,
Macau, Netherlands Antilles, Tokelau
United Nations Environment Program (UNEP): established - 15 December
1972
aim - to promote international cooperation on all environmental matters
members - (58) selected on a rotating basis from all regions
United Nations General Assembly: established - 26 June 1945; effective
- 24 October 1945
aim - to function as the primary deliberative organ of the UN
members - (191) all UN members are represented in the General Assembly
United Nations High Commissioner for Refugees (UNHCR): established - 3
December 1949; effective - 1 January 1951
aim - to ensure the humanitarian treatment of refugees and find
permanent solutions to refugee problems
members (executive committee) - (61) Algeria, Argentina, Australia,
Austria, Bangladesh, Belgium, Brazil, Canada, Chile, China, Colombia,
Democratic Republic of the Congo, Cote d''Ivoire, Denmark, Ecuador,
Ethiopia, Finland, France, Germany, Greece, Guinea, Holy See, Hungary,
India, Iran, Ireland, Israel, Italy, Japan, South Korea, Lebanon,
Lesotho, Madagascar, Mexico, Morocco, Mozambique, Namibia, Netherlands,
NZ, Nicaragua, Nigeria, Norway, Pakistan, Philippines, Poland, Russia,
Serbia and Montenegro, Somalia, South Africa, Spain, Sudan, Sweden,
Switzerland, Tanzania, Thailand, Tunisia, Turkey, Uganda, UK, US,
Venezuela
United Nations Industrial Development Organization (UNIDO):
established - 17 November 1966; effective - 1 January 1967
aim - UN specialized agency that promotes industrial development
especially among the members
members - (169) Afghanistan, Albania, Algeria, Angola, Argentina,
Armenia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Slovakia,
Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
United Nations Institute for Training and Research (UNITAR):
established - 11 December 1963 adoption of the resolution establishing
the Institute; effective - 24 March 1965
aim - to help the UN become more effective through training and
research
members (Board of Trustees) - (21) Austria, Brazil, China, Czech
Republic, Egypt, France, Ghana, Japan, Kuwait, Mexico, Monaco, Morocco,
Netherlands, Nigeria, Pakistan, Russia, South Africa, Sweden,
Switzerland, UK, US; note - the UN Secretary General can appoint up to
30 members
United Nations Interim Administration Mission in Kosovo (UNMIK):
established - 10 June 1999
aim - to promote the establishment of substantial autonomy and self-
government in Kosovo; to perform basic civilian administrative
functions; to support the reconstruction of key infrastructure and
humanitarian and disaster relief
members - (48) Argentina, Austria, Bangladesh, Belgium, Bolivia,
Bulgaria, Canada, Chile, Czech Republic, Denmark, Egypt, Fiji, Finland,
France, Germany, Ghana, Greece, Hungary, Iceland, India, Ireland,
Italy, Jordan, Kenya, Kyrgyzstan, Lithuania, Malawi, Malaysia, Nepal,
NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Romania, Russia,
Slovenia, Spain, Sweden, Switzerland, Tunisia, Turkey, Ukraine UK, US,
Zambia, Zimbabwe
United Nations Interim Force in Lebanon (UNIFIL): established - 19
March 1978
aim - to confirm the withdrawal of Israeli forces, and assist in
reestablishing Lebanese authority in southern Lebanon; established by
the UN Security Council
members - (8) Fiji, France, Ghana, India, Ireland, Italy, Poland,
Argun River China, Russia 53 20 N 121 28 E
Aru Sea Pacific Ocean 6 15 S 135 00 E
Ascension Island Saint Helena 7 57 S 14 22 W
Ashgabat (capital) Turkmenistan 37 57 N 58 23 E
Ashkhabad (see Ashgabat) Turkmenistan 37 57 N 58 23 E
Asmara (capital) Eritrea 15 20 N 38 53 E
Asmera (see Asmara) Eritrea 15 20 N 38 53 E
As-Sudan (local name for Sudan 15 00 N 30 00 E
Sudan)
Assumption Island Seychelles 9 46 S 46 34 E
Astana (capital; formerly Kazakhstan 51 10 N 71 30 E
Akmola)
Asuncion (capital) Paraguay 25 16 S 57 40 W
Asuncion Island Northern Mariana 19 40 N 145 24 E
Islands
Atacama (desert) Chile 23 00 S 70 10 W
Atacama (region) Chile 24 30 S 69 15 W
Athens (capital) Greece 37 59 N 23 44 E
Attu Island United States 52 55 N 172 57 E
Auckland Islands New Zealand 51 00 S 166 30 E
Australes, Iles (island French Polynesia 23 20 S 151 00 W
group; also Iles Tubuai)
Avarua (capital) Cook Islands 21 12 S 159 46 W
Axel Heiberg Island Canada 79 30 N 90 00 W
Azad Kashmir (region) Pakistan 34 30 N 74 00 E
Azarbaycan (local name Azerbaijan 40 30 N 47 30 E
for Azerbaijan)
Azerbaidzhan (local name Azerbaijan 40 30 N 47 30 E
for Azerbaijan)
Azores (islands) Portugal 38 30 N 28 00 W
Azov, Sea of Atlantic Ocean 49 00 N 36 00 E
This page was last updated on 1 August, 2003
=====================================================================
End of the Project Gutenberg EBook of The 2003 CIA World Factbook, by
United States. Central Intelligence Agency
*** END OF THIS PROJECT GUTENBERG EBOOK THE 2003 CIA WORLD FACTBOOK ***
***** This file should be named 27558.txt or 27558.zip *****
This and all associated files of various formats will be found in:
http://www.gutenberg.org/2/7/5/5/27558/
Produced by Al Haines
Updated editions will replace the previous one--the old editions
will be renamed.
Creating the works from public domain print editions means that no
one owns a United States copyright in these works, so the Foundation
(and you!) can copy and distribute it in the United States without
permission and without paying copyright royalties. Special rules,
set forth in the General Terms of Use part of this license, apply to
copying and distributing Project Gutenberg-tm electronic works to
protect the PROJECT GUTENBERG-tm concept and trademark. Project
Gutenberg is a registered trademark, and may not be used if you
charge for the eBooks, unless you receive specific permission. If you
do not charge anything for copies of this eBook, complying with the
rules is very easy. You may use this eBook for nearly any purpose
such as creation of derivative works, reports, performances and
research. They may be modified and printed and given away--you may do
practically ANYTHING with public domain eBooks. Redistribution is
subject to the trademark license, especially commercial
redistribution.
*** START: FULL LICENSE ***
THE FULL PROJECT GUTENBERG LICENSE
PLEASE READ THIS BEFORE YOU DISTRIBUTE OR USE THIS WORK
To protect the Project Gutenberg-tm mission of promoting the free
distribution of electronic works, by using or distributing this work
(or any other work associated in any way with the phrase "Project
Gutenberg"), you agree to comply with all the terms of the Full Project
Gutenberg-tm License (available with this file or online at
http://gutenberg.net/license).
Section 1. General Terms of Use and Redistributing Project Gutenberg-tm
electronic works
1.A. By reading or using any part of this Project Gutenberg-tm
electronic work, you indicate that you have read, understand, agree to
and accept all the terms of this license and intellectual property
(trademark/copyright) agreement. If you do not agree to abide by all
the terms of this agreement, you must cease using and return or destroy
all copies of Project Gutenberg-tm electronic works in your possession.
If you paid a fee for obtaining a copy of or access to a Project
Gutenberg-tm electronic work and you do not agree to be bound by the
terms of this agreement, you may obtain a refund from the person or
entity to whom you paid the fee as set forth in paragraph 1.E.8.
1.B. "Project Gutenberg" is a registered trademark. It may only be
used on or associated in any way with an electronic work by people who
agree to be bound by the terms of this agreement. There are a few
things that you can do with most Project Gutenberg-tm electronic works
even without complying with the full terms of this agreement. See
paragraph 1.C below. There are a lot of things you can do with Project
Gutenberg-tm electronic works if you follow the terms of this agreement
and help preserve free future access to Project Gutenberg-tm electronic
works. See paragraph 1.E below.
1.C. The Project Gutenberg Literary Archive Foundation ("the Foundation"
or PGLAF), owns a compilation copyright in the collection of Project
Gutenberg-tm electronic works. Nearly all the individual works in the
collection are in the public domain in the United States. If an
individual work is in the public domain in the United States and you are
located in the United States, we do not claim a right to prevent you from
copying, distributing, performing, displaying or creating derivative
works based on the work as long as all references to Project Gutenberg
are removed. Of course, we hope that you will support the Project
Gutenberg-tm mission of promoting free access to electronic works by
freely sharing Project Gutenberg-tm works in compliance with the terms of
this agreement for keeping the Project Gutenberg-tm name associated with
the work. You can easily comply with the terms of this agreement by
keeping this work in the same format with its attached full Project
Gutenberg-tm License when you share it without charge with others.
1.D. The copyright laws of the place where you are located also govern
what you can do with this work. Copyright laws in most countries are in
a constant state of change. If you are outside the United States, check
the laws of your country in addition to the terms of this agreement
before downloading, copying, displaying, performing, distributing or
creating derivative works based on this work or any other Project
Gutenberg-tm work. The Foundation makes no representations concerning
the copyright status of any work in any country outside the United
States.
1.E. Unless you have removed all references to Project Gutenberg:
1.E.1. The following sentence, with active links to, or other immediate
access to, the full Project Gutenberg-tm License must appear prominently
whenever any copy of a Project Gutenberg-tm work (any work on which the
phrase "Project Gutenberg" appears, or with which the phrase "Project
Gutenberg" is associated) is accessed, displayed, performed, viewed,
copied or distributed:
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
1.E.2. If an individual Project Gutenberg-tm electronic work is derived
from the public domain (does not contain a notice indicating that it is
posted with permission of the copyright holder), the work can be copied
and distributed to anyone in the United States without paying any fees
or charges. If you are redistributing or providing access to a work
with the phrase "Project Gutenberg" associated with or appearing on the
work, you must comply either with the requirements of paragraphs 1.E.1
through 1.E.7 or obtain permission for the use of the work and the
Project Gutenberg-tm trademark as set forth in paragraphs 1.E.8 or
1.E.9.
1.E.3. If an individual Project Gutenberg-tm electronic work is posted
with the permission of the copyright holder, your use and distribution
must comply with both paragraphs 1.E.1 through 1.E.7 and any additional
terms imposed by the copyright holder. Additional terms will be linked
to the Project Gutenberg-tm License for all works posted with the
permission of the copyright holder found at the beginning of this work.
1.E.4. Do not unlink or detach or remove the full Project Gutenberg-tm
License terms from this work, or any files containing a part of this
work or any other work associated with Project Gutenberg-tm.
1.E.5. Do not copy, display, perform, distribute or redistribute this
electronic work, or any part of this electronic work, without
prominently displaying the sentence set forth in paragraph 1.E.1 with
active links or immediate access to the full terms of the Project
Gutenberg-tm License.
1.E.6. You may convert to and distribute this work in any binary,
compressed, marked up, nonproprietary or proprietary form, including any
word processing or hypertext form. However, if you provide access to or
distribute copies of a Project Gutenberg-tm work in a format other than
"Plain Vanilla ASCII" or other format used in the official version
posted on the official Project Gutenberg-tm web site (www.gutenberg.net),
you must, at no additional cost, fee or expense to the user, provide a
copy, a means of exporting a copy, or a','6c3161dd97e876c3bbef492baee3f3f4c7397816547d717d152c8f55916d8424','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('531e4208c1c757a0e69a43760fea16e3fa55fe4dfd97e2e70782278da5352f42',2003,'UZ','Uzbekistan','communications',799,'means of obtaining a copy upon
request, of the work in its original "Plain Vanilla ASCII" or other
form. Any alternate format must include the full Project Gutenberg-tm
License as specified in paragraph 1.E.1.
1.E.7. Do not charge a fee for access to, viewing, displaying,
performing, copying or distributing any Project Gutenberg-tm works
unless you comply with paragraph 1.E.8 or 1.E.9.
1.E.8. You may charge a reasonable fee for copies of or providing
access to or distributing Project Gutenberg-tm electronic works provided
that
- You pay a royalty fee of 20% of the gross profits you derive from
the use of Project Gutenberg-tm works calculated using the method
you already use to calculate your applicable taxes. The fee is
owed to the owner of the Project Gutenberg-tm trademark, but he
has agreed to donate royalties under this paragraph to the
Project Gutenberg Literary Archive Foundation. Royalty payments
must be paid within 60 days following each date on which you
prepare (or are legally required to prepare) your periodic tax
returns. Royalty payments should be clearly marked as such and
sent to the Project Gutenberg Literary Archive Foundation at the
address specified in Section 4, "Information about donations to
the Project Gutenberg Literary Archive Foundation."
- You provide a full refund of any money paid by a user who notifies
you in writing (or by e-mail) within 30 days of receipt that s/he
does not agree to the terms of the full Project Gutenberg-tm
License. You must require such a user to return or
destroy all copies of the works possessed in a physical medium
and discontinue all use of and all access to other copies of
Project Gutenberg-tm works.
- You provide, in accordance with paragraph 1.F.3, a full refund of any
money paid for a work or a replacement copy, if a defect in the
electronic work is discovered and reported to you within 90 days
of receipt of the work.
- You comply with all other terms of this agreement for free
distribution of Project Gutenberg-tm works.
1.E.9. If you wish to charge a fee or distribute a Project Gutenberg-tm
electronic work or group of works on different terms than are set
forth in this agreement, you must obtain permission in writing from
both the Project Gutenberg Literary Archive Foundation and Michael
Hart, the owner of the Project Gutenberg-tm trademark. Contact the
Foundation as set forth in Section 3 below.
1.F.
1.F.1. Project Gutenberg volunteers and employees expend considerable
effort to identify, do copyright research on, transcribe and proofread
public domain works in creating the Project Gutenberg-tm
collection. Despite these efforts, Project Gutenberg-tm electronic
works, and the medium on which they may be stored, may contain
"Defects," such as, but not limited to, incomplete, inaccurate or
corrupt data, transcription errors, a copyright or other intellectual
property infringement, a defective or damaged disk or other medium, a
computer virus, or computer codes that damage or cannot be read by
your equipment.
1.F.2. LIMITED WARRANTY, DISCLAIMER OF DAMAGES - Except for the "Right
of Replacement or Refund" described in paragraph 1.F.3, the Project
Gutenberg Literary Archive Foundation, the owner of the Project
Gutenberg-tm trademark, and any other party distributing a Project
Gutenberg-tm electronic work under this agreement, disclaim all
liability to you for damages, costs and expenses, including legal
fees. YOU AGREE THAT YOU HAVE NO REMEDIES FOR NEGLIGENCE, STRICT
LIABILITY, BREACH OF WARRANTY OR BREACH OF CONTRACT EXCEPT THOSE
PROVIDED IN PARAGRAPH F3. YOU AGREE THAT THE FOUNDATION, THE
TRADEMARK OWNER, AND ANY DISTRIBUTOR UNDER THIS AGREEMENT WILL NOT BE
LIABLE TO YOU FOR ACTUAL, DIRECT, INDIRECT, CONSEQUENTIAL, PUNITIVE OR
INCIDENTAL DAMAGES EVEN IF YOU GIVE NOTICE OF THE POSSIBILITY OF SUCH
DAMAGE.
1.F.3. LIMITED RIGHT OF REPLACEMENT OR REFUND - If you discover a
defect in this electronic work within 90 days of receiving it, you can
receive a refund of the money (if any) you paid for it by sending a
written explanation to the person you received the work from. If you
received the work on a physical medium, you must return the medium with
your written explanation. The person or entity that provided you with
the defective work may elect to provide a replacement copy in lieu of a
refund. If you received the work electronically, the person or entity
providing it to you may choose to give you a second opportunity to
receive the work electronically in lieu of a refund. If the second copy
is also defective, you may demand a refund in writing without further
opportunities to fix the problem.
1.F.4. Except for the limited right of replacement or refund set forth
in paragraph 1.F.3, this work is provided to you ''AS-IS'' WITH NO OTHER
WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
WARRANTIES OF MERCHANTIBILITY OR FITNESS FOR ANY PURPOSE.
1.F.5. Some states do not allow disclaimers of certain implied
warranties or the exclusion or limitation of certain types of damages.
If any disclaimer or limitation set forth in this agreement violates the
law of the state applicable to this agreement, the agreement shall be
interpreted to make the maximum disclaimer or limitation permitted by
the applicable state law. The invalidity or unenforceability of any
provision of this agreement shall not void the remaining provisions.
1.F.6. INDEMNITY - You agree to indemnify and hold the Foundation, the
trademark owner, any agent or employee of the Foundation, anyone
providing copies of Project Gutenberg-tm electronic works in accordance
with this agreement, and any volunteers associated with the production,
promotion and distribution of Project Gutenberg-tm electronic works,
harmless from all liability, costs and expenses, including legal fees,
that arise directly or indirectly from any of the following which you do
or cause to occur: (a) distribution of this or any Project Gutenberg-tm
work, (b) alteration, modification, or additions or deletions to any
Project Gutenberg-tm work, and (c) any Defect you cause.
Section 2. Information about the Mission of Project Gutenberg-tm
Project Gutenberg-tm is synonymous with the free distribution of
electronic works in formats readable by the widest variety of computers
including obsolete, old, middle-aged and new computers. It exists
because of the efforts of hundreds of volunteers and donations from
people in all walks of life.
Volunteers and financial support to provide volunteers with the
assistance they need, is critical to reaching Project Gutenberg-tm''s
goals and ensuring that the Project Gutenberg-tm collection will
remain freely available for generations to come. In 2001, the Project
Gutenberg Literary Archive Foundation was created to provide a secure
and permanent future for Project Gutenberg-tm and future generations.
To learn more about the Project Gutenberg Literary Archive Foundation
and how your efforts and donations can help, see Sections 3 and 4
and the Foundation web page at http://www.pglaf.org.
Section 3. Information about the Project Gutenberg Literary Archive
Foundation
The Project Gutenberg Literary Archive Foundation is a non profit
501(c)(3) educational corporation organized under the laws of the
state of Mississippi and granted tax exempt status by the Internal
Revenue Service. The Foundation''s EIN or federal tax identification
number is 64-6221541. Its 501(c)(3) letter is posted at
http://pglaf.org/fundraising. Contributions to the Project Gutenberg
Literary Archive Foundation are tax deductible to the full extent
permitted by U.S. federal laws and your state''s laws.
The Foundation''s principal office is located at 4557 Melan Dr. S.
Fairbanks, AK, 99712., but its volunteers and employees are scattered
throughout numerous locations. Its business office is located at
809 North 1500 West, Salt Lake City, UT 84116, (801) 596-1887, email
business@pglaf.org. Email contact links and up to date contact
information can be found at the Foundation''s web site and official
page at http://pglaf.org
For additional contact information:
Dr. Gregory B. Newby
Chief Executive and Director
gbnewby@pglaf.org
Section 4. Information about Donations to the Project Gutenberg
Literary Archive Foundation
Project Gutenberg-tm depends upon and cannot survive without wide
spread public support and donations to carry out its mission of
increasing the number of public domain and licensed works that can be
freely distributed in machine readable form accessible by the widest
array of equipment including outdated equipment. Many small donations
($1 to $5,000) are particularly important to maintaining tax exempt
status with the IRS.
The Foundation is committed to complying with the laws regulating
charities and charitable donations in all 50 states of the United
States. Compliance requirements are not uniform and it takes a
considerable effort, much paperwork and many fees to meet and keep up
with these requirements. We do not solicit donations in locations
where we have not received written confirmation of compliance. To
SEND DONATIONS or determine the status of compliance for any
particular state visit http://pglaf.org
While we cannot and do not solicit contributions from states where we
have not met the solicitation requirements, we know of no prohibition
against accepting unsolicited donations from donors in such states who
approach us with offers to donate.
International donations are gratefully accepted, but we cannot make
any statements concerning tax treatment of donations received from
outside the United States. U.S. laws alone swamp our small staff.
Please check the Project Gutenberg Web pages for current donation
methods and addresses. Donations are accepted in a number of other
ways including including checks, online payments and credit card
donations. To donate, please visit: http://pglaf.org/donate
Section 5. General Information About Project Gutenberg-tm electronic
works.
Professor Michael S. Hart is the originator of the Project Gutenberg-tm
concept of a library of electronic works that could be freely shared
with anyone. For thirty years, he produced and distributed Project
Gutenberg-tm eBooks with only a loose network of volunteer support.
Project Gutenberg-tm eBooks are often created from several printed
editions, all of which are confirmed as Public Domain in the U.S.
unless a copyright notice is included. Thus, we do not necessarily
keep eBooks in compliance with any particular paper edition.
Most people start at our Web site which has the main PG search facility:
http://www.gutenberg.net
This Web site includes information about Project Gutenberg-tm,
including how to make donations to the Project Gutenberg Literary
Archive Foundation, how to help produce our new eBooks, and how to
subscribe to our email newsletter to hear about new eBooks.','70c19f9c89544d02a36d857b50a5c97aca77bf03a30c0792d9f5d60f1c549c52','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7e0a2b6804fecb97a542a0c406f8a6a75fe8c2beafbf5af6ac5dfaebc87b30f',2003,'VU','Vanuatu','communications',800,'general assessment: NA
domestic: NA
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Venezuela
general assessment: modern and expanding
domestic: domestic satellite system with 3 earth stations; recent
substantial improvement in telephone service in rural areas;
substantial increase in digitalization of exchanges and trunk lines;
installation of a national interurban fiber-optic network capable of
digital multimedia services
international: 3 submarine coaxial cables; satellite earth stations
- 1 Intelsat (Atlantic Ocean) and 1 PanAmSat; participating with
Colombia, Ecuador, Peru, and Bolivia in the construction of an
international fiber-optic network
Vietnam
general assessment: Vietnam is putting considerable effort
into modernization and expansion of its telecommunication system,
but its performance continues to lag behind that of its more modern
neighbors
domestic: all provincial exchanges are digitalized and connected to
Hanoi, Da Nang, and Ho Chi Minh City by fiber-optic cable or
microwave radio relay networks; since 1991, main lines in use have
been substantially increased and the use of mobile telephones is
growing rapidly
international: satellite earth stations - 2 Intersputnik (Indian
Ocean region)
Virgin Islands
general assessment: NA
domestic: modern, uses fiber-optic cable and microwave radio relay
international: submarine cable and satellite communications;
satellite earth stations - NA
Wake Island
general assessment: satellite communications; 1 DSN
circuit off the Overseas Telephone System (OTS)
domestic: NA
international: NA
mostly mountains of volcanic origin; narrow coastal plains
Venezuela
Andes Mountains and Maracaibo Lowlands in northwest;
central plains (llanos); Guiana Highlands in southeast
Vietnam
low, flat delta in south and north; central highlands;
hilly, mountainous in far north and northwest
Virgin Islands
mostly hilly to rugged and mountainous with little
level land
Wake Island
atoll of three coral islands built up on an underwater
volcano; central lagoon is former crater, islands are part of the rim
2.98 children born/woman (2003 est.)
Venezuela
2.36 children born/woman (2003 est.)
Vietnam
2.24 children born/woman (2003 est.)
Virgin Islands
2.22 children born/woman (2003 est.)
parliamentary republic
Venezuela
federal republic
Vietnam
Communist state
Virgin Islands
NA
NA%
Venezuela
17% (2002 est.)
Vietnam
25% (1995 est.)
Virgin Islands
4.9% (March 1999)
conventional long form: Republic of Vanuatu
conventional short form: Vanuatu
former: New Hebrides
Venezuela
conventional long form: Bolivarian Republic of Venezuela
conventional short form: Venezuela
local long form: Republica Bolivariana de Venezuela
local short form: Venezuela
Vietnam
conventional long form: Socialist Republic of Vietnam
conventional short form: Vietnam
local long form: Cong Hoa Xa Hoi Chu Nghia Viet Nam
local short form: Viet Nam
abbreviation: SRV
Virgin Islands
conventional long form: United States Virgin Islands
conventional short form: Virgin Islands
former: Danish West Indies
Wake Island
conventional long form: none
conventional short form: Wake Island
Oceania, group of islands in the South Pacific Ocean, about
three-quarters of the way from Hawaii to Australia
Venezuela
Northern South America, bordering the Caribbean Sea and
the North Atlantic Ocean, between Colombia and Guyana
Vietnam
Southeastern Asia, bordering the Gulf of Thailand, Gulf of
Tonkin, and South China Sea, alongside China, Laos, and Cambodia
Virgin Islands
Caribbean, islands between the Caribbean Sea and the
North Atlantic Ocean, east of Puerto Rico
Wake Island
Oceania, atoll in the North Pacific Ocean, about
two-thirds of the way from Hawaii to the Northern Mariana Islands
Oceania
Venezuela
South America
Vietnam
Southeast Asia
Virgin Islands
Central America and the Caribbean
Wake Island
Oceania
NA sq km
Venezuela
540 sq km (1998 est.)
Vietnam
30,000 sq km (1998 est.)
Virgin Islands
NA sq km
Wake Island
0 sq km (1998 est.)
total: 12,200 sq km
land: 12,200 sq km
water: 0 sq km
note: includes more than 80 islands
Venezuela
total: 912,050 sq km
land: 882,050 sq km
water: 30,000 sq km
Vietnam
total: 329,560 sq km
land: 325,360 sq km
water: 4,200 sq km
Virgin Islands
total: 352 sq km
land: 349 sq km
water: 3 sq km
Wake Island
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Vanuatu does not have an embassy in the US; it does,
however, have a Permanent Mission to the UN
Venezuela
chief of mission: Ambassador Bernardo ALVAREZ
chancery: 1099 30th Street NW, Washington, DC 20007
telephone: [1] (202) 342-2214
FAX: [1] (202) 342-6820
consulate(s) general: Boston, Chicago, Houston, Miami, New Orleans,
New York, San Francisco, and San Juan (Puerto Rico)
Vietnam
chief of mission: Ambassador Nguyen Tam CHIEN
chancery: 1233 20th Street NW, Suite 400, Washington, DC 20036
telephone: [1] (202) 861-0737
FAX: [1] (202) 861-0917
consulate(s) general: San Francisco
Virgin Islands
none (territory of the US)
5,500 (1998)
Venezuela
2.6 million (however, 3,500,000 have been installed) (1998)
Vietnam
2.6 million (2000)
Virgin Islands
65,000 (1997)
310 (2000)
Venezuela
2 million (1998)
Vietnam
730,155 (2000)
Virgin Islands
2,000 (1992)
1 (2000)
Venezuela
16 (2000)
Vietnam
5 (2000)
Virgin Islands
50 (2000)
3,000 (2000)
Venezuela
1.3 million (2002)
Vietnam
400,000 (2002)
Virgin Islands
12,000 (2000)
.vu
Venezuela
.ve
Vietnam
.vn
Virgin Islands
.vi
NA%
Venezuela
0.5% - note: no country specific models provided (2001
est.)
Vietnam
0.3% (2001 est.)
Virgin Islands
NA%
NA
Venezuela
62,000 (1999 est.)
Vietnam
130,000 (2001 est.)
Virgin Islands
NA
NA
Venezuela
2,000 (2001 est.)
Vietnam
6,600 (2001 est.)
Virgin Islands
NA
VUV
Venezuela
VEB
Vietnam
VND
Virgin Islands
USD
0 bbl/day (2001 est.)
Venezuela
3.08 million bbl/day (2001 est.)
Vietnam
356,700 bbl/day (2001 est.)
Virgin Islands
0 bbl/day (2001 est.)
600 bbl/day (2001 est.)
Venezuela
505,000 bbl/day (2001 est.)
Vietnam
185,000 bbl/day (2001 est.)
Virgin Islands
66,000 bbl/day (2001 est.)
NA (2001)
Venezuela
NA (2001)
Vietnam
NA (2001)
Virgin Islands
NA (2001)
NA (2001)
Venezuela
NA (2001)
Vietnam
NA (2001)
Virgin Islands
NA (2001)
total: 21.9 years
male: 22 years
female: 21.8 years (2002)
Venezuela
total: 24.8 years
male: 24.3 years
female: 25.4 years (2002)
Vietnam
total: 24.5 years
male: 23.6 years
female: 25.5 years (2002)
Virgin Islands
total: 31.2 years
male: 28.6 years
female: 33.7 years (2002)
West Bank
total: 17.9 years
male: 17.7 years
female: 18 years (2002)
United Nations Mission in Ethiopia and Eritrea (UNMEE): established -
31 July 2000
aim - to monitor the cessation of hostilities
members - (44) Algeria, Australia, Bangladesh, Benin, Bosnia and
Herzegovina, Bulgaria, Canada, China, Croatia, Czech Republic, Denmark,
Finland, France, The Gambia, Ghana, Greece, India, Ireland, Italy,
Jordan, Kenya, Malaysia, Namibia, Nepal, Netherlands, Nigeria, Norway,
Paraguay, Peru, Poland, Romania, Russia, Singapore, Slovakia, South
Africa, Spain, Sweden, Switzerland, Tanzania, Tunisia, Ukraine, US,
Uruguay, Zambia
United Nations Mission in Sierra Leone (UNAMSIL): established - 22
October 1999
aim - to cooperate with the Government of Sierra Leone and the other
parties to the Peace Agreement in the implementation of the agreement;
to monitor the military and security situation in Sierra Leone; to
monitor the disarmament and demobilization of combatants and members of
the Civil Defense Forces (CFD); to assist in monitoring respect for
international humanitarian law
members - (31) Bangladesh, Bolivia, Canada, China, Croatia, Czech
Republic, Denmark, Egypt, The Gambia, Germany, Ghana, Guinea,
Indonesia, Jordan, Kenya, Kyrgyzstan, Malaysia, Mali, Nepal, NZ,
Nigeria, Pakistan, Russia, Slovakia, Sweden, Tanzania, Thailand,
Ukraine, UK, Uruguay, Zambia
United Nations Mission of Observers in Prevlaka (UNMOP): established -
1 February 1996
aim - to monitor the demilitarization of the Prevlaka peninsula in
southern Croatia
members - (22) Argentina, Bangladesh, Belgium, Brazil, Czech Republic,
Denmark, Egypt, Finland, Ghana, Indonesia, Ireland, Jordan, Kenya,
Nepal, NZ, Nigeria, Norway, Pakistan, Poland, Russia, Switzerland,','0a34f429f6b1eca5b9d3cc87d84c815874a5d760a01cb8d3a94726afdd68374a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c1abc92241464d4dd39277b902dfcaf93d3653f94b997da7c95cdc37e8508cb',2003,'WF','Wallis and Futuna','communications',801,'general assessment: NA
domestic: NA
international: NA
West Bank
general assessment: NA
domestic: NA
international: NA
note: Israeli company BEZEK and the Palestinian company PALTEL are
responsible for communication services in the West Bank
volcanic origin; low hills
West Bank
mostly rugged dissected upland, some vegetation in west,
but barren in east
NA children born/woman (2003 est.)
West Bank
4.65 children born/woman (2003 est.)
NA
NA%
West Bank
50% (includes Gaza Strip) (2002 est.)
defense is the responsibility of France
conventional long form: Territory of the Wallis
and Futuna Islands
conventional short form: Wallis and Futuna
local long form: Territoire des Iles Wallis et Futuna
local short form: Wallis et Futuna
West Bank
conventional long form: none
conventional short form: West Bank
Oceania, islands in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
West Bank
Middle East, west of Jordan
Oceania
West Bank
Middle East
NA sq km
West Bank
NA sq km
total: 274 sq km
land: 274 sq km
water: 0 sq km
note: includes Ile Uvea (Wallis Island), Ile Futuna (Futuna Island),
Ile Alofi, and 20 islets
West Bank
total: 5,860 sq km
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun Salient, and the northwest quarter
of the Dead Sea, but excludes Mt. Scopus; East Jerusalem and
Jerusalem No Man''s Land are also included only as a means of
depicting the entire area occupied by Israel in 1967
none (overseas territory of France)
1,125 (1994)
West Bank
95,729 (total for West Bank and Gaza Strip) (1997)
0 (1994)
West Bank
NA
1 (2000)
West Bank
8 (1999)
NA
West Bank
60,000 (includes Gaza Strip) (2001)
.wf
NA%
West Bank
NA%
NA
West Bank
NA
NA
West Bank
NA
XPF
West Bank
ILS; JOD','50ec28f73295620245810459c3677124d2f0179f10a5bce5dc4587f11889a330','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9a0059545539ff0bcb2662f9d73f181593922608396adccc6af6e7e9dad7dc0',2003,'EH','Western Sahara','communications',802,'general assessment: sparse and limited system
domestic: NA
international: tied into Morocco''s system by microwave radio relay,
tropospheric scatter, and satellite; satellite earth stations - 2
Intelsat (Atlantic Ocean) linked to Rabat, Morocco
World
general assessment: NA
domestic: NA
international: NA
mostly low, flat desert with large areas of rocky or
sandy surfaces rising to small mountains in south and northeast
World
the greatest ocean depth is the Mariana Trench at 10,924 m in
the Pacific Ocean
NA children born/woman (2003 est.)
World
2.65 children born/woman (2003 est.)
legal status of territory and issue of sovereignty
unresolved; territory contested by Morocco and Polisario Front
(Popular Front for the Liberation of the Saguia el Hamra and Rio de
Oro), which in February 1976 formally proclaimed a
government-in-exile of the Sahrawi Arab Democratic Republic
(SADR),led by President Mohamed ABDELAZIZ; territory partitioned
between Morocco and Mauritania in April 1976, with Morocco acquiring
northern two-thirds; Mauritania, under pressure from Polisario
guerrillas, abandoned all claims to its portion in August 1979;
Morocco moved to occupy that sector shortly thereafter and has since
asserted administrative control; the Polisario''s government-in-exile
was seated as an OAU member in 1984; guerrilla activities continued
sporadically, until a UN-monitored cease-fire was implemented 6
September 1991
NA%
World
30% combined unemployment and underemployment in many
non-industrialized countries; developed countries typically 4%-12%
unemployment
conventional long form: none
conventional short form: Western Sahara
former: Spanish Sahara
Northern Africa, bordering the North Atlantic Ocean,
between Mauritania and Morocco
Africa
World
Physical Map of the World, Political Map of the World,
Standard Time Zones of the World
NA sq km
World
2,714,320 sq km (1998 est.)
total: 266,000 sq km
land: 266,000 sq km
water: 0 sq km
World
total: 510.072 million sq km
land: 148.94 million sq km
water: 361.132 million sq km
note: 70.8% of the world''s surface is water, 29.2% is land
none
about 2,000 (1999 est.)
World
NA
0 (1999)
World
NA
1 (2000)
World
10,350 (2000 est.)
NA
World
604,111,719 (2002 est.)
.eh
NA%
World
NA%
NA
World
NA
NA
World
NA
MAD
0 bbl/day (2001 est.)
World
75.46 million bbl/day (2001 est.)
1,800 bbl/day (2001 est.)
World
76.21 million bbl/day (2001 est.)
NA (2001)
NA (2001)','96386ecb1400129e879beccc0449fc7754f34743fe12c0b35b1a041070ff4659','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fffb6cdb839c5a88b35c4f771716639d9834440adc4c5a199baa5ba53a1ca40',2003,'YE','Yemen','communications',803,'general assessment: since unification in 1990, efforts have
been made to create a national telecommunications network
domestic: the national network consists of microwave radio relay,
cable, tropospheric scatter, and GSM cellular mobile telephone
systems
international: satellite earth stations - 3 Intelsat (2 Indian Ocean
and 1 Atlantic Ocean), 1 Intersputnik (Atlantic Ocean region), and 2
Arabsat; microwave radio relay to Saudi Arabia and Djibouti
narrow coastal plain backed by flat-topped hills and rugged
mountains; dissected upland desert plains in center slope into the
desert interior of the Arabian Peninsula
6.82 children born/woman (2003 est.)
republic
30% (1995 est.)
establishment of a Coast Guard, scheduled for May 2001, has
been delayed
This page was last updated on 18 December, 2003
======================================================================
@2138 Communications - note
conventional long form: Republic of Yemen
conventional short form: Yemen
local long form: Al Jumhuriyah al Yamaniyah
local short form: Al Yaman
Middle East, bordering the Arabian Sea, Gulf of Aden, and Red
Sea, between Oman and Saudi Arabia
Middle East
4,900 sq km (1998 est.)
total: 527,970 sq km
land: 527,970 sq km
water: 0 sq km
note: includes Perim, Socotra, the former Yemen Arab Republic (YAR
or North Yemen), and the former People''s Democratic Republic of
Yemen (PDRY or South Yemen)
chief of mission: Ambassador Abd al-Wahhab Abdallah al-HAJRI
chancery: Suite 705, 2600 Virginia Avenue NW, Washington, DC 20037
telephone: [1] (202) 965-4760
FAX: [1] (202) 337-2017
291,359 (1999)
32,042 (2000)
1 (2000)
17,000 (2002)
.ye
0.1% (2001 est.)
9,900 (2001 est.)
NA
YER
33.4 (1998)
438,500 bbl/day (2001 est.)
74,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 16.4 years
male: 16.4 years
female: 16.4 years (2002)
3.2 billion bbl (37257)
This page was last updated on 18 December, 2003
======================================================================
@2179 Natural gas - proved reserves (cu m)
480 billion cu m (37257)
This page was last updated on 18 December, 2003
======================================================================
@2180 Natural gas - production (cu m)
0 cu m (2001 est.)
This page was last updated on 18 December, 2003
======================================================================
@2181 Natural gas - consumption (cu m)
0 cu m (2001 est.)
This page was last updated on 18 December, 2003
======================================================================
@2182 Natural gas - imports (cu m)
0 cu m (2001 est.)
This page was last updated on 18 December, 2003
======================================================================
@2183 Natural gas - exports (cu m)
0 cu m (2001 est.)
This page was last updated on 18 December, 2003
======================================================================
Rank code: @2001
Rank Country GDP Date of Information
1 World $ 49,000,000,000,000 2002 est.
2 United States $ 10,450,000,000,000 2002 est.
3 China $ 5,989,000,000,000 2002 est.
4 Japan $ 3,651,000,000,000 2002 est.
5 India $ 2,664,000,000,000 2002 est.
6 Germany $ 2,160,000,000,000 2002 est.
7 France $ 1,558,000,000,000 2002 est.
8 United Kingdom $ 1,528,000,000,000 2002 est.
9 Italy $ 1,455,000,000,000 2002 est.
10 Russia $ 1,409,000,000,000 2002 est.
11 Brazil $ 1,376,000,000,000 2002 est.
12 Korea, South $ 941,500,000,000 2002 est.
13 Canada $ 934,100,000,000 2002 est.
14 Mexico $ 924,400,000,000 2002 est.
15 Spain $ 850,700,000,000 2002 est.
16 Indonesia $ 714,200,000,000 2002 est.
17 Australia $ 525,500,000,000 2002 est.
18 Turkey $ 489,700,000,000 2002 est.
19 Iran $ 458,300,000,000 2002 est.
20 Thailand $ 445,800,000,000 2002 est.
21 Netherlands $ 437,800,000,000 2002 est.
22 South Africa $ 427,700,000,000 2002 est.
23 Taiwan $ 406,000,000,000 2002 est.
24 Argentina $ 403,800,000,000 2002 est.
25 Philippines $ 379,700,000,000 2002 est.
26 Poland $ 373,200,000,000 2002 est.
27 Belgium $ 299,700,000,000 2002 est.
28 Pakistan $ 295,300,000,000 2002 est.
29 Egypt $ 289,800,000,000 2002 est.
30 Saudi Arabia $ 268,900,000,000 2002 est.
31 Colombia $ 251,600,000,000 2002 est.
32 Bangladesh $ 238,200,000,000 2002 est.
33 Switzerland $ 233,400,000,000 2002 est.
34 Sweden $ 230,700,000,000 2002 est.
35 Austria $ 227,700,000,000 2002 est.
36 Ukraine $ 218,000,000,000 2002 est.
37 Greece $ 203,300,000,000 2002 est.
38 Hong Kong $ 198,500,000,000 2002 est.
39 Malaysia $ 198,400,000,000 2002 est.
40 Portugal $ 195,200,000,000 2002 est.
41 Vietnam $ 183,800,000,000 2002 est.
42 Algeria $ 173,800,000,000 2002 est.
43 Romania $ 169,300,000,000 2002 est.
44 Czech Republic $ 157,100,000,000 2002 est.
45 Chile $ 156,100,000,000 2002 est.
46 Denmark $ 155,300,000,000 2002 est.
47 Norway $ 149,100,000,000 2002 est.
48 Peru $ 138,800,000,000 2002 est.
49 Hungary $ 134,000,000,000 2002 est.
50 Finland $ 133,800,000,000 2002 est.
51 Venezuela $ 131,700,000,000 2002 est.
52 Morocco $ 121,800,000,000 2002 est.
53 Kazakhstan $ 120,000,000,000 2002 est.
54 Israel $ 117,400,000,000 2002 est.
55 Ireland $ 113,700,000,000 2002 est.
56 Nigeria $ 112,500,000,000 2002 est.
57 Singapore $ 112,400,000,000 2002 est.
58 Belarus $ 90,190,000,000 2002 est.
59 New Zealand $ 78,400,000,000 2002 est.
60 Sri Lanka $ 73,700,000,000 2002 est.
61 Burma $ 73,690,000,000 2002 est.
62 Slovakia $ 67,340,000,000 2002 est.
63 Tunisia $ 67,130,000,000 2002 est.
64 Uzbekistan $ 66,060,000,000 2002 est.
65 Syria $ 63,480,000,000 2002 est.
66 Iraq $ 58,000,000,000 2002 est.
67 United Arab Emirates $ 53,970,000,000 2002 est.
68 Dominican Republic $ 53,780,000,000 2002 est.
69 Guatemala $ 53,200,000,000 2002 est.
70 Sudan $ 52,900,000,000 2002 est.
71 Bulgaria $ 49,230,000,000 2002 est.
72 Ethiopia $ 48,530,000,000 2002 est.
73 Croatia $ 43,120,000,000 2002 est.
74 Puerto Rico $ 43,010,000,000 2002 est.
75 Ecuador $ 42,650,000,000 2002 est.
76 Ghana $ 41,250,000,000 2002 est.
77 Nepal $ 37,320,000,000 2002 est.
78 Slovenia $ 37,060,000,000 2002 est.
79 Kuwait $ 36,850,000,000 2002 est.
80 Congo, Democratic Republic of the $ 34,000,000,000 2002 est.
81 Libya $ 33,360,000,000 2002 est.
82 Kenya $ 32,890,000,000 2002 est.
83 Costa Rica $ 32,000,000,000 2002 est.
84 Turkmenistan $ 31,340,000,000 2002 est.
85 Cuba $ 30,690,000,000 2002 est.
86 Uganda $ 30,490,000,000 2002 est.
87 Lithuania $ 30,080,000,000 2002 est.
88 El Salvador $ 29,410,000,000 2002 est.
89 Azerbaijan $ 28,610,000,000 2002 est.
90 Cameroon $ 26,840,000,000 2002 est.
91 Uruguay $ 26,820,000,000 2002 est.
92 Zimbabwe $ 26,070,000,000 2002 est.
93 Paraguay $ 25,190,000,000 2002 est.
94 Cote d''Ivoire $ 24,030,000,000 2002 est.
95 Serbia and Montenegro $ 23,150,000,000 2002 est.
96 Jordan $ 22,630,000,000 2002 est.
97 Oman $ 22,400,000,000 2002 est.
98 Korea, North $ 22,260,000,000 2002 est.
99 Luxembourg $ 21,940,000,000 2002 est.
100 Bolivia $ 21,150,000,000 2002 est.
101 Latvia $ 20,990,000,000 2002 est.
102 Cambodia $ 20,420,000,000 2002 est.
103 Tanzania $ 20,420,000,000 2002 est.
104 Mozambique $ 19,520,000,000 2002 est.
105 Afghanistan $ 19,000,000,000 2002 est.
106 Guinea $ 18,690,000,000 2002 est.
107 Angola $ 18,360,000,000 2002 est.
108 Panama $ 18,060,000,000 2002 est.
109 Lebanon $ 17,610,000,000 2002 est.
110 Honduras $ 16,290,000,000 2002 est.
111 Georgia $ 16,050,000,000 2002 est.
112 Qatar $ 15,910,000,000 2002 est.
113 Albania $ 15,690,000,000 2002 est.
114 Senegal $ 15,640,000,000 2002 est.
115 Estonia $ 15,520,000,000 2002 est.
116 Yemen $ 15,070,000,000 2002 est.
117 Burkina Faso $ 14,510,000,000 2002 est.
118 Kyrgyzstan $ 13,880,000,000 2002 est.
119 Botswana $ 13,480,000,000 2002 est.
120 Namibia $ 13,150,000,000 2002 est.
121 Madagascar $ 12,590,000,000 2002
122 Mauritius $ 12,150,000,000 2002 est.
123 Armenia $ 12,130,000,000 2002 est.
124 Moldova $ 11,510,000,000 2002 est.
125 Nicaragua $ 11,160,000,000 2002 est.
126 Trinidad and Tobago $ 11,070,000,000 2002 est.
127 Papua New Guinea $ 10,860,000,000 2002 est.
128 Haiti $ 10,600,000,000 2002 est.
129 Macedonia, The Former Yugoslav Republic of $ 10,570,000,000 2002 est.
130 Laos $ 10,400,000,000 2002 est.
131 Jamaica $ 10,080,000,000 2002 est.
132 Bahrain $ 9,910,000,000 2002 est.
133 Mali $ 9,775,000,000 2002 est.
134 Cyprus $ 9,400,000,000 2002 est.
135 Chad $ 9,297,000,000 2002 est.
136 Rwanda $ 8,920,000,000 2002 est.
137 Niger $ 8,713,000,000 2002 est.
138 Macau $ 8,600,000,000 2002 est.
139 Tajikistan $ 8,476,000,000 2002 est.
140 Iceland $ 8,444,000,000 2002 est.
141 Gabon $ 8,354,000,000 2002 est.
142 Zambia $ 8,240,000,000 2002 est.
143 Togo $ 7,594,000,000 2002 est.
144 Benin $ 7,380,000,000 2002 est.
145 Bosnia and Herzegovina $ 7,300,000,000 2002 est.
146 Malta $ 6,818,000,000 2002 est.
147 Malawi $ 6,811,000,000 2002 est.
148 Brunei $ 6,500,000,000 2002 est.
149 Swaziland $ 5,542,000,000 2002 est.
150 Lesotho $ 5,106,000,000 2002 est.
151 Mongolia $ 5,060,000,000 2002 est.
152 Mauritania $ 4,891,000,000 2002 est.
153 Fiji $ 4,822,000,000 2002 est.
154 Bahamas, The $ 4,590,000,000 2002 est.
155 Martinique $ 4,500,000,000 2001 est.
156 Central African Republic $ 4,296,000,000 2002 est.
157 Somalia $ 4,270,000,000 2001 est.
158 Reunion $ 4,174,000,000 1999 est.
159 Barbados $ 4,153,000,000 2002 est.
160 Guadeloupe $ 3,700,000,000 1997 est.
161 Eritrea $ 3,300,000,000 2002 est.
162 Guam $ 3,200,000,000 2000 est.
163 Burundi $ 3,146,000,000 2002 est.
164 Liberia $ 3,116,000,000 2002 est.
165 New Caledonia $ 3,000,000,000 2002 est.
166 Sierra Leone $ 2,826,000,000 2002 est.
167 Bhutan $ 2,700,000,000 2002 est.
168 Guyana $ 2,628,000,000 2002 est.
169 Gambia, The $ 2,582,000,000 2002 est.
170 Congo, Republic of the $ 2,500,000,000 2002 est.
171 Netherlands Antilles $ 2,400,000,000 2002 est.
172 Virgin Islands $ 2,400,000,000 2001 est.
173 French Guiana $ 2,260,000,000 2002 est.
174 Bermuda $ 2,250,000,000 2002 est.
175 Jersey $ 2,200,000,000 1999 est.
176 Aruba $ 1,940,000,000 2002 est.
177 West Bank $ 1,700,000,000 2002 est.
178 Man, Isle of $ 1,600,000,000 2001 est.
179 Suriname $ 1,469,000,000 2002 est.
180 Andorra $ 1,300,000,000 2000 est.
181 Guernsey $ 1,300,000,000 1999 est.
182 French Polynesia $ 1,300,000,000 2001 est.
183 Belize $ 1,280,000,000 2002 est.
184 Cayman Islands $ 1,270,000,000 2002 est.
185 Equatorial Guinea $ 1,270,000,000 2002 est.
186 Maldives $ 1,250,000,000 2002 est.
187 Greenland $ 1,100,000,000 2001 est.
188 Faroe Islands $ 1,000,000,000 2001 est.
189 Samoa $ 1,000,000,000 2002 est.
190 San Marino $ 940,000,000 2001 est.
191 Guinea-Bissau $ 901,400,000 2002 est.
192 Northern Mariana Islands $ 900,000,000 2000 est.
193 Northern Mariana Islands $ 900,000,000 2000 est.
194 Northern Mariana Islands $ 900,000,000 2000 est.
195 Monaco $ 870,000,000 1999 est.
196 Saint Lucia $ 866,000,000 2002 est.
197 Liechtenstein $ 825,000,000 1999 est.
198 Solomon Islands $ 800,000,000 2001 est.
199 Cyprus $ 787,000,000 2002 est.
200 Antigua and Barbuda $ 750,000,000 2002 est.
201 Gaza Strip $ 735,000,000 2002 est.
202 Seychelles $ 626,000,000 2002 est.
203 Djibouti $ 619,000,000 2002 est.
204 Cape Verde $ 600,000,000 2002 est.
205 Vanuatu $ 563,000,000 2002 est.
206 American Samoa $ 500,000,000 2000 est.
207 Gibraltar $ 500,000,000 1997 est.
208 Comoros $ 441,000,000 2002 est.
209 Grenada $ 440,000,000 2002 est.
210 East Timor $ 440,000,000 2001 est.
211 Dominica $ 380,000,000 2002 est.
212 Saint Kitts and Nevis $ 339,000,000 2002 est.
213 Saint Vincent and the Grenadines $ 339,000,000 2002 est.
214 British Virgin Islands $ 320,000,000 2002 est.
215 Micronesia, Federated States of $ 277,000,000 2002 est.
216 Micronesia, Federated States of $ 277,000,000 2002 est.
217 Micronesia, Federated States of $ 277,000,000 2002 est.
218 Tonga $ 236,000,000 2001 est.
219 Turks and Caicos Islands $ 231,000,000 2000 est.
220 Sao Tome and Principe $ 200,000,000 2002 est.
221 Palau $ 174,000,000 2001 est.
222 Palau $ 174,000,000 2001 est.
223 Palau $ 174,000,000 2001 est.
224 Marshall Islands $ 115,000,000 2001 est.
225 Cook Islands $ 105,000,000 2001 est.
226 Anguilla $ 104,000,000 2001 est.
227 Mayotte $ 85,000,000 1998 est.
228 Kiribati $ 79,000,000 2001 est.
229 Falkland Islands (Islas Malvinas) $ 75,000,000 2002 est.
230 Saint Pierre and Miquelon $ 74,000,000 1996 est.
231 Nauru $ 60,000,000 2001 est.
232 Wallis and Futuna $ 30,000,000 2000 est.
233 Montserrat $ 29,000,000 2002 est.
234 Saint Helena $ 18,000,000 1998 est.
235 Tuvalu $ 12,200,000 2000 est.
236 Niue $ 7,600,000 2000 est.
237 Tokelau $ 1,500,000 1993 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2003
Rank Country GDP - real growth rate(%) Date of Information
1 Turkmenistan 21.10 2002 est.
2 Equatorial Guinea 20.00 2002 est.
3 East Timor 18.00 2001 est.
4 Man, Isle of 13.50
5 Armenia 12.90 2002 est.
6 Liechtenstein 11.00 1999 est.
7 Azerbaijan 10.60 2002 est.
8 Faroe Islands 10.00 2001 est.
9 Rwanda 9.70 2002 est.
10 Kazakhstan 9.50 2002 est.
11 Macau 9.50 2002 est.
12 Angola 9.40 2002 est.
13 Tajikistan 9.10 2002 est.
14 China 8.00 2002 est.
15 Turkey 7.80 2002 est.
16 Bhutan 7.70 2002 est.
17 Mozambique 7.70 2002 est.
18 Iran 7.60 2002 est.
19 San Marino 7.50 2001 est.
20 Chad 7.40 2002 est.
21 Albania 7.30 2002 est.
22 Cook Islands 7.10 2001 est.
23 Vietnam 7.00 2002 est.
24 Ireland 6.90 2002 est.
25 Lithuania 6.70 2002 est.
26 Sierra Leone 6.60 2002 est.
27 Moldova 6.50 2002 est.
28 Korea, South 6.30 2002 est.
29 Latvia 6.10 2002 est.
30 Tanzania 6.10 2002 est.
31 Benin 6.00 2002 est.
32 Estonia 6.00 2002 est.
33 Gambia, The 5.70 2001 est.
34 Guernsey 5.70 1999 est.
35 Laos 5.70 2002 est.
36 Uganda 5.50 2002 est.
37 Georgia 5.40 2002 est.
38 Burma 5.30 2002 est.
39 Kyrgyzstan 5.30 2002 est.
40 Peru 5.30 2002 est.
41 Thailand 5.30 2002 est.
42 Croatia 5.20 2002 est.
43 Sudan 5.10 2002 est.
44 Samoa 5.00 2002 est.
45 Jordan 4.90 2002 est.
46 Turks and Caicos Islands 4.90 2000 est.
47 Romania 4.90 2002 est.
48 Bangladesh 4.80 2002 est.
49 Bulgaria 4.80 2002 est.
50 Ukraine 4.80 2002 est.
51 Tunisia 4.80 2002 est.
52 Belarus 4.70 2002 est.
53 Fiji 4.60 2002 est.
54 Burkina Faso 4.60 2002 est.
55 Qatar 4.60 2002 est.
56 Morocco 4.60 2002 est.
57 Burundi 4.50 2002 est.
58 Cambodia 4.50 2002 est.
59 Mali 4.50 2002 est.
60 Ghana 4.50 2002 est.
61 Slovakia 4.40 2002 est.
62 Philippines 4.40 2002 est.
63 Pakistan 4.40 FY01/02 est.
64 India 4.30 2002 est.
65 Russia 4.30 2002 est.
66 Botswana 4.20 2002 est.
67 Uzbekistan 4.20 2002 est.
68 Dominican Republic 4.10 2002 est.
69 Malaysia 4.10 2002 est.
70 Yemen 4.10 2002 est.
71 Cameroon 4.00 2002 est.
72 Greece 4.00 2002 est.
73 Serbia and Montenegro 4.00 2002 est.
74 Sao Tome and Principe 4.00 2002 est.
75 Lesotho 4.00 2002 est.
76 French Polynesia 4.00 2001 est.
77 Cape Verde 4.00 2002 est.
78 Mongolia 3.90 2002 est.
79 Andorra 3.80 2000 est.
80 Belize 3.70 2002 est.
81 Indonesia 3.70 2002 est.
82 Guinea 3.70 2002 est.
83 Australia 3.60 2002 est.
84 Syria 3.60 2002 est.
85 Congo, Democratic Republic of the 3.50 2002 est.
86 Djibouti 3.50 2002 est.
87 Somalia 3.50 2002 est.
88 Taiwan 3.50 2002 est.
89 Ecuador 3.40 2002 est.
90 Algeria 3.30 2002 est.
91 Saint Lucia 3.30 2002 est.
92 Canada 3.30 2002 est.
93 Hungary 3.30 2002 est.
94 Mauritania 3.30 2002 est.
95 New Zealand 3.30 2002 est.
96 Sri Lanka 3.20 2002 est.
97 Egypt 3.20 2002 est.
98 Slovenia 3.20 2002 est.
99 Trinidad and Tobago 3.20 2002 est.
100 Nigeria 3.20 2002 est.
101 Antigua and Barbuda 3.00 2002 est.
102 Tuvalu 3.00 2000 est.
103 Tonga 3.00 2001 est.
104 South Africa 3.00 2002 est.
105 Ethiopia 3.00 2002 est.
106 Brunei 3.00 2002 est.
107 Bahrain 2.90 2002 est.
108 Togo 2.90 2002 est.
109 Niger 2.90 2002 est.
110 Anguilla 2.80 2001 est.
111 Costa Rica 2.80 2002 est.
112 Bolivia 2.80 2002 est.
113 World 2.70 2001 est.
114 Cyprus 2.60 2002 est.
115 Grenada 2.50 2002 est.
116 Reunion 2.50 2002 est.
117 Honduras 2.50 2002 est.
118 Senegal 2.40 2002 est.
119 United States 2.40 2002 est.
120 Bosnia and Herzegovina 2.30 2002 est.
121 Hong Kong 2.30 2002 est.
122 Mauritius 2.30 2002 est.
123 Zambia 2.30 2002 est.
124 Namibia 2.30 2002 est.
125 Maldives 2.30 2002 est.
126 Guatemala 2.20 2002 est.
127 Oman 2.20 2002 est.
128 Singapore 2.20 2002 est.
129 Chile 2.10 2002 est.
130 El Salvador 2.10 2002 est.
131 Comoros 2.00 2002 est.
132 Virgin Islands 2.00 2001 est.
133 Spain 2.00 2002 est.
134 Liberia 2.00 2002 est.
135 Lebanon 2.00 2002 est.
136 Czech Republic 2.00 2002 est.
137 Eritrea 2.00 2002 est.
138 Sweden 1.90 2002 est.
139 Greenland 1.80 2001 est.
140 United Kingdom 1.80 2002 est.
141 United Arab Emirates 1.80 2002 est.
142 Cayman Islands 1.70 2002 est.
143 Cyprus 1.70 2002 est.
144 Malawi 1.70 2002 est.
145 Denmark 1.60 2002 est.
146 Swaziland 1.60 2002 est.
147 Finland 1.60 2002 est.
148 Brazil 1.50 2002 est.
149 Seychelles 1.50 2002 est.
150 Kiribati 1.50 2001 est.
151 Central African Republic 1.50 2002 est.
152 Colombia 1.50 2002 est.
153 Poland 1.40 2002 est.
154 Dominica 1.20 2002 est.
155 Suriname 1.20 2002 est.
156 France 1.20 2002 est.
157 Malta 1.20 2002 est.
158 Libya 1.20 2002 est.
159 Austria 1.10 2002 est.
160 Nicaragua 1.10 2002 est.
161 Kenya 1.10 2002 est.
162 Cuba 1.10 2002 est.
163 Guyana 1.10 2002 est.
164 Micronesia, Federated States of 1.00 2002 est.
165 Saudi Arabia 1.00 2002 est.
166 British Virgin Islands 1.00 2002 est.
167 Marshall Islands 1.00 2001 est.
168 Jamaica 1.00 2002 est.
169 Norway 1.00 2002 est.
170 Palau 1.00 2001 est.
171 Korea, North 1.00 2002 est.
172 Belgium 0.70 2002 est.
173 Panama 0.70 2002 est.
174 Mexico 0.70 2002 est.
175 Macedonia, The Former Yugoslav Republic of 0.70 2002 est.
176 Bermuda 0.50 2002 est.
177 Italy 0.40 2002 est.
178 Luxembourg 0.40 2002 est.
179 Portugal 0.40 2002 est.
180 Gabon 0.20 2002 est.
181 Germany 0.20 2002 est.
182 Netherlands 0.20 2002 est.
183 Japan 0.20 2002 est.
184 Bahamas, The 0.10 2002 est.
185 Switzerland 0.10 2002 est.
186 Congo, Republic of the 0.00 2002 est.
187 Netherlands Antilles 0.00 2002 est.
188 Puerto Rico -0.20 2002 est.
189 Niue -0.30 2000 est.
190 Vanuatu -0.30 2002 est.
191 Saint Vincent and the Grenadines -0.50 2002 est.
192 Iceland -0.60 2002 est.
193 Nepal -0.60 2002 est.
194 Israel -0.80 2002 est.
195 Haiti -0.90 2002 est.
196 Montserrat -1.00 2002 est.
197 Aruba -1.50 2002 est.
198 Cote d''Ivoire -1.60 2002 est.
199 Saint Kitts and Nevis -1.90 2002 est.
200 Kuwait -2.00 2002 est.
201 Paraguay -2.70 2002 est.
202 Barbados -2.80 2002 est.
203 Iraq -3.00 2002 est.
204 Papua New Guinea -3.10 2002 est.
205 Guinea-Bissau -4.30 2002 est.
206 Venezuela -8.90 2002 est.
207 Solomon Islands -10.00 2001 est.
208 Uruguay -10.80 2002 est.
209 Argentina -10.90 2002 est.
210 Madagascar -11.90 2002 est.
211 Zimbabwe -13.00 2002 est.
212 Gaza Strip -15.00 2002 est.
213 West Bank -22.00 2002 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2004
Rank Country GDP - per capita Date of Information
1 Luxembourg $ 48,900 2002 est.
2 United States $ 36,300 2002 est.
3 Bermuda $ 35,200 2002 est.
4 Cayman Islands $ 35,000 2002 est.
5 San Marino $ 34,600 2001 est.
6 Norway $ 33,000 2002 est.
7 Switzerland $ 32,000 2002 est.
8 Iceland $ 30,200 2002 est.
9 Canada $ 29,300 2002 est.
10 Ireland $ 29,300 2002 est.
11 Belgium $ 29,200 2002 est.
12 Denmark $ 28,900 2002 est.
13 Japan $ 28,700 2002 est.
14 Aruba $ 28,000 2002 est.
15 Austria $ 27,900 2002 est.
16 Hong Kong $ 27,200 2002 est.
17 Netherlands $ 27,200 2002 est.
18 Monaco $ 27,000 1999 est.
19 Australia $ 26,900 2002 est.
20 Germany $ 26,200 2002 est.
21 France $ 26,000 2002 est.
22 Sweden $ 26,000 2002 est.
23 Finland $ 25,800 2002 est.
24 United Kingdom $ 25,500 2002 est.
25 Singapore $ 25,200 2002 est.
26 Italy $ 25,100 2002 est.
27 Falkland Islands (Islas Malvinas) $ 25,000 2002 est.
28 Liechtenstein $ 25,000 1999 est.
29 Jersey $ 24,800 1999 est.
30 United Arab Emirates $ 22,100 2002 est.
31 Faroe Islands $ 22,000 2001 est.
32 Spain $ 21,200 2002 est.
33 Guam $ 21,000 2000 est.
34 Man, Isle of $ 21,000 2001 est.
35 New Zealand $ 20,100 2002 est.
36 Qatar $ 20,100 2002 est.
37 Guernsey $ 20,000 1999 est.
38 Greenland $ 20,000 2001 est.
39 Korea, South $ 19,600 2002 est.
40 Israel $ 19,500 2002 est.
41 Portugal $ 19,400 2002 est.
42 Slovenia $ 19,200 2002 est.
43 Greece $ 19,100 2002 est.
44 Andorra $ 19,000 2000 est.
45 Virgin Islands $ 19,000 2001 est.
46 Brunei $ 18,600 2002 est.
47 Macau $ 18,500 2002 est.
48 Taiwan $ 18,000 2002 est.
49 Gibraltar $ 17,500 1997 est.
50 Kuwait $ 17,500 2002 est.
51 Malta $ 17,200 2002 est.
52 British Virgin Islands $ 16,000 2002 est.
53 Bahamas, The $ 15,300 2002 est.
54 Czech Republic $ 15,300 2002 est.
55 Bahrain $ 15,100 2002 est.
56 Barbados $ 15,000 2002 est.
57 Cyprus $ 15,000 2002 est.
58 French Guiana $ 14,400 2000 est.
59 New Caledonia $ 14,000 2002 est.
60 Hungary $ 13,300 2002 est.
61 Northern Mariana Islands $ 12,500 2000 est.
62 Slovakia $ 12,400 2002 est.
63 Netherlands Antilles $ 11,400 2002 est.
64 Saudi Arabia $ 11,400 2002 est.
65 Puerto Rico $ 11,100 2002 est.
66 Antigua and Barbuda $ 11,000 2002 est.
67 Saint Pierre and Miquelon $ 11,000 1996 est.
68 Estonia $ 11,000 2002 est.
69 Martinique $ 10,700 2001 est.
70 Argentina $ 10,500 2002 est.
71 Chile $ 10,100 2002 est.
72 Mauritius $ 10,100 2002 est.
73 South Africa $ 10,000 2002 est.
74 Trinidad and Tobago $ 10,000 2002 est.
75 Croatia $ 9,800 2002 est.
76 Poland $ 9,700 2002 est.
77 Russia $ 9,700 2002 est.
78 Turks and Caicos Islands $ 9,600 2000 est.
79 Guadeloupe $ 9,000 1997 est.
80 Palau $ 9,000 2001 est.
81 Latvia $ 8,900 2002 est.
82 Mexico $ 8,900 2002 est.
83 Malaysia $ 8,800 2002 est.
84 Saint Kitts and Nevis $ 8,800 2002 est.
85 Belarus $ 8,700 2002 est.
86 Anguilla $ 8,600 2001 est.
87 Botswana $ 8,500 2002 est.
88 Lithuania $ 8,400 2002 est.
89 Costa Rica $ 8,300 2002 est.
90 Oman $ 8,300 2002 est.
91 American Samoa $ 8,000 2000 est.
92 Uruguay $ 7,900 2002 est.
93 World $ 7,900 2002 est.
94 Seychelles $ 7,800 2002 est.
95 Brazil $ 7,600 2002 est.
96 Romania $ 7,600 2002 est.
97 Turkey $ 7,300 2002 est.
98 Kazakhstan $ 7,200 2002 est.
99 Thailand $ 7,000 2002 est.
100 Namibia $ 6,900 2002 est.
101 Iran $ 6,800 2002 est.
102 Tunisia $ 6,800 2002 est.
103 Turkmenistan $ 6,700 2002 est.
104 Bulgaria $ 6,500 2002 est.
105 Gabon $ 6,500 2002 est.
106 Dominican Republic $ 6,300 2002 est.
107 Libya $ 6,200 2002 est.
108 Panama $ 6,200 2002 est.
109 Colombia $ 6,100 2002 est.
110 Cyprus $ 6,000 2002 est.
111 Fiji $ 5,600 2002 est.
112 Samoa $ 5,600 2002 est.
113 Reunion $ 5,600 2002 est.
114 Algeria $ 5,400 2002 est.
115 Saint Lucia $ 5,400 2002 est.
116 Venezuela $ 5,400 2002 est.
117 Dominica $ 5,400 2002 est.
118 Macedonia, The Former Yugoslav Republic of $ 5,100 2002 est.
119 Cook Islands $ 5,000 2001 est.
120 Peru $ 5,000 2002 est.
121 Nauru $ 5,000 2001 est.
122 Grenada $ 5,000 2002 est.
123 French Polynesia $ 5,000 2001 est.
124 Belize $ 4,900 2002 est.
125 Lebanon $ 4,800 2002 est.
126 Swaziland $ 4,800 2002 est.
127 China $ 4,700 2002 est.
128 El Salvador $ 4,600 2002 est.
129 Philippines $ 4,600 2002 est.
130 Ukraine $ 4,500 2002 est.
131 Albania $ 4,400 2002 est.
132 Jordan $ 4,300 2002 est.
133 Paraguay $ 4,300 2002 est.
134 Egypt $ 4,000 2002 est.
135 Guatemala $ 3,900 2002 est.
136 Maldives $ 3,900 2002 est.
137 Morocco $ 3,900 2002 est.
138 Guyana $ 3,800 2002 est.
139 Jamaica $ 3,800 2002 est.
140 Azerbaijan $ 3,700 2002 est.
141 Sri Lanka $ 3,700 2002 est.
142 Syria $ 3,700 2002 est.
143 Armenia $ 3,600 2002 est.
144 Niue $ 3,600 2000 est.
145 Montserrat $ 3,400 2002 est.
146 Suriname $ 3,400 2002 est.
147 Ecuador $ 3,200 2002 est.
148 Georgia $ 3,200 2001 est.
149 Indonesia $ 3,100 2002 est.
150 Kyrgyzstan $ 2,900 2002 est.
151 Saint Vincent and the Grenadines $ 2,900 2002 est.
152 Vanuatu $ 2,900 2002 est.
153 Cuba $ 2,700 2002 est.
154 Lesotho $ 2,70','0db2ae2e62d924538947323157d91558c08b13ebf32fd360fa5a1ddb7be33ad2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b258d6c2d6be359d8b8e461f8dc619e42e3bf6cbfee871c6222899a3d522715',2003,'YE','Yemen','communications',804,'0 2002 est.
155 Equatorial Guinea $ 2,700 2002 est.
156 India $ 2,600 2002 est.
157 Uzbekistan $ 2,600 2002 est.
158 Moldova $ 2,600 2002 est.
159 Bolivia $ 2,500 2002 est.
160 Saint Helena $ 2,500 1998 est.
161 Honduras $ 2,500 2002 est.
162 Iraq $ 2,400 2002 est.
163 Vietnam $ 2,300 2002 est.
164 Nicaragua $ 2,200 2002 est.
165 Tonga $ 2,200 2001 est.
166 Serbia and Montenegro $ 2,200 2002 est.
167 Guinea $ 2,100 2002 est.
168 Zimbabwe $ 2,100 2002 est.
169 Papua New Guinea $ 2,100 2002 est.
170 Micronesia, Federated States of $ 2,000 2002 est.
171 Wallis and Futuna $ 2,000 2000 est.
172 Ghana $ 2,000 2002 est.
173 Pakistan $ 2,000 FY01/02 est.
174 Bosnia and Herzegovina $ 1,900 2002 est.
175 Mongolia $ 1,900 2002 est.
176 Bangladesh $ 1,800 2002 est.
177 Laos $ 1,800 2002 est.
178 Gambia, The $ 1,800 2002 est.
179 Angola $ 1,700 2002 est.
180 Mauritania $ 1,700 2002 est.
181 Cameroon $ 1,700 2002 est.
182 Solomon Islands $ 1,700 2001 est.
183 Burma $ 1,700 2002 est.
184 Cambodia $ 1,600 2002 est.
185 Marshall Islands $ 1,600 2001 est.
186 Senegal $ 1,500 2002 est.
187 Cape Verde $ 1,400 2002 est.
188 Cote d''Ivoire $ 1,400 2002 est.
189 Sudan $ 1,400 2002 est.
190 Togo $ 1,400 2002 est.
191 Nepal $ 1,400 2002 est.
192 Haiti $ 1,400 2002 est.
193 Bhutan $ 1,300 2002 est.
194 Tajikistan $ 1,300 2002 est.
195 Djibouti $ 1,300 2002 est.
196 Central African Republic $ 1,200 2002 est.
197 Sao Tome and Principe $ 1,200 2002 est.
198 Uganda $ 1,200 2002 est.
199 Rwanda $ 1,200 2002 est.
200 Benin $ 1,100 2002 est.
201 Kenya $ 1,100 2002 est.
202 Mozambique $ 1,100 2002 est.
203 Burkina Faso $ 1,100 2002 est.
204 Tuvalu $ 1,100 2000 est.
205 Chad $ 1,000 2002 est.
206 Korea, North $ 1,000 2002 est.
207 Tokelau $ 1,000 1993 est.
208 Liberia $ 1,000 2002 est.
209 Congo, Republic of the $ 900 2002 est.
210 Mali $ 900 2002 est.
211 Nigeria $ 900 2002 est.
212 Kiribati $ 800 2001 est.
213 Zambia $ 800 2002 est.
214 Yemen $ 800 2002 est.
215 West Bank $ 800 2002 est.
216 Niger $ 800 2002 est.
217 Madagascar $ 800 2002 est.
218 Afghanistan $ 700 2002 est.
219 Comoros $ 700 2002 est.
220 Eritrea $ 700 2002 est.
221 Ethiopia $ 700 2002 est.
222 Guinea-Bissau $ 700 2002 est.
223 Congo, Democratic Republic of the $ 600 2002 est.
224 Tanzania $ 600 2002 est.
225 Gaza Strip $ 600 2002 est.
226 Mayotte $ 600 1998 est.
227 Malawi $ 600 2002 est.
228 Somalia $ 600 2002 est.
229 Burundi $ 500 2002 est.
230 East Timor $ 500 2001 est.
231 Sierra Leone $ 500 2002 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2034
Rank Country Military expenditures - percent of GDP(%) Date of Information
1 Korea, North 33.90 FY02
2 Mali 15.00 FY02
3 Saudi Arabia 13.00
4 Ethiopia 12.60 FY00
5 Oman 12.20 FY01
6 Eritrea 12.00 FY02
7 Qatar 10.00
8 Israel 8.75 FY02
9 Jordan 8.60 FY01
10 Maldives 8.60 FY02
11 Afghanistan 7.70 FY02
12 Bahrain 6.70 FY01
13 Armenia 6.50 FY01
14 Macedonia, The Former Yugoslav Republic of 6.00
15 Syria 5.90
16 Kuwait 5.50 FY01
17 Angola 5.40 FY02
18 Burundi 5.30 FY02
19 New Caledonia 5.30 FY96
20 Yemen 5.20 FY01
21 Brunei 5.00 FY02
22 Greece 4.91
23 Singapore 4.90
24 Lebanon 4.80
25 Swaziland 4.75 FY00
26 Congo, Democratic Republic of the 4.60
27 Pakistan 4.60 FY02
28 Bosnia and Herzegovina 4.50
29 Turkey 4.50 2002 est.
30 Djibouti 4.40 FY02
31 China 4.30 FY02
32 Sri Lanka 4.20
33 Laos 4.20
34 Algeria 4.10
35 Egypt 4.10 FY99
36 Cuba 4.00
37 Morocco 4.00
38 Libya 3.90
39 Tajikistan 3.90 FY01
40 Cyprus 3.80
41 Mauritania 3.70 FY02
42 Botswana 3.50 FY02
43 Colombia 3.40 FY01
44 Turkmenistan 3.40
45 Ecuador 3.40
46 Guinea 3.30 FY02
47 United States 3.20
48 Zimbabwe 3.20 FY02
49 Chile 3.10
50 Iran 3.10
51 United Arab Emirates 3.10
52 Cambodia 3.00
53 Rwanda 3.00 FY02
54 Comoros 3.00 FY02
55 Australia 2.90 FY02
56 Congo, Republic of the 2.80 FY01
57 Korea, South 2.80 FY02
58 Guinea-Bissau 2.80 FY02
59 Benin 2.70 FY02
60 Taiwan 2.70 FY02
61 Bulgaria 2.70 FY02
62 Azerbaijan 2.60
63 France 2.57 2002
64 Equatorial Guinea 2.50 FY02
65 Vietnam 2.50
66 Sudan 2.50
67 Romania 2.47 2002
68 Namibia 2.40 FY02
69 Croatia 2.39 2002 est.
70 United Kingdom 2.32 2002
71 India 2.30 FY02
72 Fiji 2.20 FY02
73 Mongolia 2.20 FY02
74 Portugal 2.20 FY99/00
75 Norway 2.13 2002
76 Burma 2.10
77 Uganda 2.10 FY02
78 Sweden 2.10 FY01
79 Czech Republic 2.10 FY01
80 Malaysia 2.03
81 Estonia 2.00 2002 est.
82 Gabon 2.00 FY02
83 Uzbekistan 2.00
84 World 2.00
85 Finland 2.00 FY98/99
86 Brazil 1.90 FY99
87 Chad 1.90 FY02
88 Lithuania 1.90 FY01
89 Bhutan 1.90 FY02
90 Slovakia 1.89 2002
91 Belize 1.87
92 Bangladesh 1.80 FY96
93 Bolivia 1.80 FY99
94 Kenya 1.80 FY02
95 Peru 1.80
96 Seychelles 1.80 FY02
97 Togo 1.80 FY02
98 Hungary 1.75 2002 est.
99 Poland 1.71 2002
100 Malta 1.70 2000
101 Slovenia 1.70 FY00
102 South Africa 1.70 FY02
103 Italy 1.64 2002
104 Costa Rica 1.60
105 Cape Verde 1.60 FY02
106 Suriname 1.60
107 Netherlands 1.50 FY00/01 est.
108 Sierra Leone 1.50 FY02
109 Tunisia 1.50
110 Philippines 1.50
111 Albania 1.49 FY02
112 Belgium 1.40 FY01/02
113 Belarus 1.40 FY02
114 Denmark 1.40 FY99/00
115 Burkina Faso 1.40 FY02
116 Ukraine 1.40 FY02
117 Thailand 1.40
118 Trinidad and Tobago 1.40 1999
119 Senegal 1.40 FY02
120 Papua New Guinea 1.40 FY02
121 Paraguay 1.40
122 Kyrgyzstan 1.40 FY01
123 Cote d''Ivoire 1.40 FY02
124 Cameroon 1.40 FY98
125 Germany 1.38 2002
126 Argentina 1.30 FY00
127 Haiti 1.30 FY00
128 Indonesia 1.30
129 Liberia 1.30 FY02
130 Panama 1.30
131 Latvia 1.20 FY01
132 Nicaragua 1.20
133 Madagascar 1.20 FY02
134 Spain 1.15 2002
135 Canada 1.10 FY01/02
136 Central African Republic 1.10 FY02
137 Dominican Republic 1.10
138 Niger 1.10 FY02
139 Nepal 1.10 FY02
140 Uruguay 1.10 2000
141 Japan 1.00 FY02
142 Mexico 1.00
143 Mozambique 1.00
144 New Zealand 1.00 FY02
145 Switzerland 1.00 FY01
146 Nigeria 1.00 FY02
147 Ireland 0.90 FY00/01
148 Venezuela 0.90
149 Zambia 0.90 FY02
150 Somalia 0.90 FY02
151 Kazakhstan 0.90 FY02
152 Austria 0.80 FY01/02
153 Sao Tome and Principe 0.80 FY01
154 Luxembourg 0.80 FY01/02
155 Bahamas, The 0.70 FY99
156 Malawi 0.70 FY02
157 El Salvador 0.70
158 Ghana 0.60 FY02
159 Guatemala 0.60
160 Honduras 0.60
161 Georgia 0.59
162 Moldova 0.40 FY02
163 Gambia, The 0.30 FY02
164 Mauritius 0.20 FY02
165 Tanzania 0.20 FY02
166 Bermuda 0.11
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2038
Rank Country Electricity - production(kWh) Date of Information
1 World 14,850,000,000,000 2001 est.
2 United States 3,719,000,000,000 2001
3 China 1,420,000,000,000 2001
4 Japan 1,037,000,000,000 2001
5 Russia 846,500,000,000 2001
6 Canada 566,300,000,000 2001
7 Germany 544,800,000,000 2001
8 India 533,300,000,000 2001
9 France 520,100,000,000 2001
10 United Kingdom 360,900,000,000 2001
11 Brazil 321,200,000,000 2001
12 Korea, South 290,700,000,000 2001
13 Italy 258,800,000,000 2001
14 Spain 222,500,000,000 2001
15 Mexico 198,600,000,000 2001
16 Australia 198,200,000,000 2001
17 South Africa 195,600,000,000 2001
18 Ukraine 164,700,000,000 2001
19 Sweden 152,900,000,000 2001
20 Taiwan 151,100,000,000 2001
21 Poland 135,000,000,000 2001
22 Iran 124,600,000,000 2001
23 Saudi Arabia 122,400,000,000 2001
24 Norway 120,100,000,000 2001
25 Turkey 116,600,000,000 2001
26 Thailand 97,600,000,000 2001
27 Argentina 97,170,000,000 2001
28 Indonesia 95,780,000,000 2001
29 Netherlands 88,320,000,000 2001
30 Venezuela 87,600,000,000 2001
31 Ecuador 75,230,000,000 2001
32 Egypt 75,230,000,000 2001
33 Belgium 74,280,000,000 2001
34 Finland 71,200,000,000 2001
35 Czech Republic 70,040,000,000 2001
36 Switzerland 68,680,000,000 2001
37 Malaysia 68,340,000,000 2001
38 Pakistan 66,960,000,000 2001
39 Austria 58,750,000,000 2001
40 Kazakhstan 52,430,000,000 2001
41 Romania 50,860,000,000 2001
42 Greece 49,790,000,000 2001
43 Philippines 45,210,000,000 2001
44 Paraguay 44,890,000,000 2001
45 Uzbekistan 44,490,000,000 2001
46 Portugal 44,320,000,000 2001
47 Colombia 42,990,000,000 2001
48 Israel 42,240,000,000 2001
49 Chile 41,660,000,000 2001
50 Bulgaria 41,380,000,000 2001
51 United Arab Emirates 37,740,000,000 2001
52 New Zealand 37,510,000,000 2001
53 Iraq 36,010,000,000 2001
54 Denmark 35,470,000,000 2001
55 Hungary 34,390,000,000 2001
56 Serbia and Montenegro 31,710,000,000 2001
57 Kuwait 31,490,000,000 2001
58 Hong Kong 30,480,000,000 2001
59 Singapore 30,480,000,000 2001
60 Slovakia 30,290,000,000 2001
61 Korea, North 30,010,000,000 2001
62 Vietnam 29,800,000,000 2001
63 Algeria 24,690,000,000 2001
64 Belarus 24,400,000,000 2001
65 Ireland 23,530,000,000 2001
66 Syria 23,260,000,000 2001
67 Puerto Rico 20,900,000,000 2001
68 Peru 20,590,000,000 2001
69 Libya 20,180,000,000 2001
70 Azerbaijan 18,230,000,000 2001
71 Nigeria 15,670,000,000 2001
72 Bangladesh 15,330,000,000 2001
73 Lithuania 14,620,000,000 2001
74 Cuba 14,380,000,000 2001
75 Tajikistan 14,180,000,000 2001
76 Slovenia 13,690,000,000 2001
77 Kyrgyzstan 13,450,000,000 2001
78 Morocco 13,350,000,000 2001
79 Croatia 12,120,000,000 2001
80 Tunisia 10,480,000,000 2001
81 Turkmenistan 10,180,000,000 2001
82 Bosnia and Herzegovina 9,979,000,000 2001
83 Oman 9,274,000,000 2001
84 Qatar 9,264,000,000 2001
85 Dominican Republic 9,186,000,000 2001
86 Ghana 8,801,000,000 2001
87 Uruguay 7,963,000,000 2001
88 Estonia 7,937,000,000 2001
89 Iceland 7,894,000,000 2001
90 Zambia 7,751,000,000 2001
91 Georgia 7,270,000,000 2001
92 Mozambique 7,193,000,000 2001
93 Jordan 7,091,000,000 2001
94 Costa Rica 6,839,000,000 2001
95 Zimbabwe 6,735,000,000 2001
96 Lebanon 6,728,000,000 2001
97 Armenia 6,479,000,000 2001
98 Macedonia, The Former Yugoslav Republic of 6,465,000,000 2001
99 Sri Lanka 6,360,000,000 2001
100 Jamaica 6,272,000,000 2001
101 Bahrain 6,257,000,000 2001
102 Guatemala 6,237,000,000 2001
103 Burma 6,139,000,000 2001
104 Trinidad and Tobago 5,315,000,000 2001
105 Albania 5,289,000,000 2001
106 Congo, Democratic Republic of the 5,243,000,000 2001
107 Cote d''Ivoire 4,605,000,000 2001
108 Latvia 4,365,000,000 2001
109 Panama 4,039,000,000 2001
110 Kenya 4,033,000,000 2001
111 Bolivia 3,901,000,000 2001
112 Honduras 3,778,000,000 2001
113 El Salvador 3,729,000,000 2001
114 Cameroon 3,613,000,000 2001
115 Cyprus 3,401,000,000 2001
116 Moldova 3,394,000,000 2001
117 Yemen 3,010,000,000 2001
118 Tanzania 2,906,000,000 2001
119 Nicaragua 2,549,000,000 2001
120 Brunei 2,497,000,000 2001
121 Sudan 2,389,000,000 2001
122 Mongolia 2,225,000,000 2001
123 Suriname 1,959,000,000 2001
124 Uganda 1,928,000,000 2001
125 Bhutan 1,896,000,000 2001
126 Malta 1,768,000,000 2001
127 Nepal 1,755,000,000 2001
128 Ethiopia 1,713,000,000 2001
129 New Caledonia 1,613,000,000 2001
130 Macau 1,611,000,000 2002
131 Bahamas, The 1,560,000,000 2001
132 Senegal 1,518,000,000 2001
133 Papua New Guinea 1,496,000,000 2001
134 Angola 1,450,000,000 2001
135 Laos 1,317,000,000 2001
136 Mauritius 1,311,000,000 2001
137 Guadeloupe 1,155,000,000 2001
138 Martinique 1,151,000,000 2001
139 Reunion 1,080,000,000 2001
140 Netherlands Antilles 1,061,000,000 2001
141 Virgin Islands 1,030,000,000 2001
142 Guyana 852,000,000 2001
143 Madagascar 830,200,000 2001
144 Guam 830,000,000 2001
145 Gabon 798,400,000 2001
146 Guinea 790,600,000 2001
147 Barbados 780,000,000 2001
148 Malawi 769,200,000 2001
149 Bermuda 643,700,000 2001
150 Haiti 580,000,000 2001
151 Aruba 531,900,000 2001
152 Fiji 520,100,000 2001
153 Mali 480,200,000 2001
154 Liberia 468,800,000 2001
155 Luxembourg 457,000,000 2001
156 French Guiana 455,000,000 2001
157 French Polynesia 428,300,000 2001
158 Botswana 409,800,000 2001
159 Cayman Islands 381,900,000 2001
160 Congo, Republic of the 358,100,000 2001
161 Swaziland 348,300,000 2001
162 Afghanistan 334,800,000 2001
163 Burkina Faso 279,200,000 2001
164 Benin 274,300,000 2001
165 Sierra Leone 250,100,000 2001
166 Somalia 245,100,000 2001
167 Greenland 245,000,000 2001
168 Niger 242,000,000 2001
169 Eritrea 220,500,000 2001
170 Belize 199,500,000 2001
171 Djibouti 180,000,000 2001
172 Faroe Islands 160,400,000 2001
173 Seychelles 160,000,000 2001
174 Mauritania 157,400,000 2001
175 Burundi 155,400,000 2001
176 Grenada 138,000,000 2001
177 American Samoa 130,000,000 2001
178 Saint Lucia 120,200,000 2001
179 Cambodia 119,000,000 2001
180 Maldives 117,000,000 2001
181 Central African Republic 106,000,000 2001
182 Antigua and Barbuda 105,300,000 2001
183 Samoa 105,100,000 2001
184 Togo 101,600,000 2001
185 Saint Kitts and Nevis 100,300,000 2001
186 Gibraltar 100,000,000 2001
187 Rwanda 96,780,000 2001
188 Chad 94,040,000 2001
189 Saint Vincent and the Grenadines 92,480,000 2001
190 Western Sahara 90,000,000 2001
191 Gambia, The 85,330,000 2001
192 Dominica 72,410,000 2001
193 Guinea-Bissau 55,000,000 2001
194 Johnston Atoll 44,200,000 1999
195 Vanuatu 43,460,000 2001
196 Cape Verde 42,030,000 2001
197 Saint Pierre and Miquelon 42,030,000 2001
198 British Virgin Islands 38,100,000 2001
199 Solomon Islands 32,000,000 2001
200 Nauru 30,000,000 2001
201 Cook Islands 27,430,000 2001
202 Tonga 27,270,000 2001
203 Namibia 26,950,000 2001
204 Equatorial Guinea 23,560,000 2001
205 Comoros 21,270,000 2001
206 Sao Tome and Principe 17,000,000 2001
207 Falkland Islands (Islas Malvinas) 16,330,000 2001
208 Kiribati 7,000,000 2001
209 Saint Helena 5,000,000 2001
210 Turks and Caicos Islands 5,000,000 2001
211 Niue 3,000,000 2001
212 Montserrat 2,500,000 2001
213 Lesotho 0 2001
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2042
Rank Country Electricity - consumption(kWh) Date of Information
1 World 13,930,000,000,000 2001 est.
2 United States 3,602,000,000,000 2001
3 China 1,312,000,000,000 2001
4 Japan 964,200,000,000 2001
5 Russia 773,000,000,000 2001
6 Germany 506,800,000,000 2001
7 Canada 504,400,000,000 2001
8 India 497,200,000,000 2001
9 France 415,300,000,000 2001
10 United Kingdom 346,100,000,000 2001
11 Brazil 335,900,000,000 2001
12 Italy 289,100,000,000 2001
13 Korea, South 270,300,000,000 2001
14 Spain 210,400,000,000 2001
15 Mexico 186,700,000,000 2001
16 Australia 184,400,000,000 2001
17 South Africa 181,200,000,000 2001
18 Ukraine 152,400,000,000 2001
19 Taiwan 140,500,000,000 2001
20 Sweden 134,900,000,000 2001
21 Poland 118,800,000,000 2001
22 Iran 115,900,000,000 2001
23 Norway 115,300,000,000 2001
24 Saudi Arabia 113,800,000,000 2001
25 Turkey 112,600,000,000 2001
26 Netherlands 99,420,000,000 2001
27 Argentina 92,120,000,000 2001
28 Thailand 90,910,000,000 2001
29 Indonesia 89,080,000,000 2001
30 Venezuela 81,470,000,000 2001
31 Belgium 78,180,000,000 2001
32 Finland 76,180,000,000 2001
33 Ecuador 69,960,000,000 2001
34 Egypt 69,960,000,000 2001
35 Malaysia 63,480,000,000 2001
36 Pakistan 62,270,000,000 2001
37 Czech Republic 55,600,000,000 2001
38 Austria 54,850,000,000 2001
39 Switzerland 53,430,000,000 2001
40 Greece 48,800,000,000 2001
41 Kazakhstan 48,360,000,000 2001
42 Uzbekistan 47,070,000,000 2001
43 Romania 46,100,000,000 2001
44 Philippines 42,040,000,000 2001
45 Portugal 41,480,000,000 2001
46 Chile 40,130,000,000 2001
47 Colombia 39,810,000,000 2001
48 Israel 37,820,000,000 2001
49 Hong Kong 37,120,000,000 2001
50 Hungary 35,150,000,000 2001
51 United Arab Emirates 35,100,000,000 2001
52 New Zealand 34,880,000,000 2001
53 Iraq 33,490,000,000 2001
54 Bulgaria 32,520,000,000 2001
55 Denmark 32,410,000,000 2001
56 Serbia and Montenegro 32,370,000,000 2001
57 Kuwait 29,290,000,000 2001
58 Singapore 28,350,000,000 2001
59 Korea, North 27,910,000,000 2001
60 Vietnam 27,710,000,000 2001
61 Belarus 26,690,000,000 2001
62 Slovakia 24,410,000,000 2001
63 Algeria 22,900,000,000 2001
64 Ireland 21,630,000,000 2001
65 Syria 21,630,000,000 2001
66 Puerto Rico 19,440,000,000 2001
67 Peru 19,150,000,000 2001
68 Libya 18,770,000,000 2001
69 Azerbaijan 16,650,000,000 2001
70 Morocco 14,610,000,000 2001
71 Nigeria 14,550,000,000 2001
72 Tajikistan 14,520,000,000 2001
73 Croatia 14,270,000,000 2001
74 Bangladesh 14,250,000,000 2001
75 Slovenia 13,830,000,000 2001
76 Cuba 13,380,000,000 2001
77 Kyrgyzstan 10,460,000,000 2001
78 Zimbabwe 9,813,000,000 2001
79 Tunisia 9,748,000,000 2001
80 Ghana 8,835,000,000 2001
81 Lithuania 8,683,000,000 2001
82 Oman 8,625,000,000 2001
83 Qatar 8,616,000,000 2001
84 Dominican Republic 8,543,000,000 2001
85 Turkmenistan 8,509,000,000 2001
86 Bosnia and Herzegovina 8,116,000,000 2001
87 Georgia 7,611,000,000 2001
88 Lebanon 7,440,000,000 2001
89 Iceland 7,341,000,000 2001
90 Jordan 6,860,000,000 2001
91 Estonia 6,192,000,000 2001
92 Uruguay 6,152,000,000 2001
93 Macedonia, The Former Yugoslav Republic of 6,112,000,000 2001
94 Costa Rica 6,109,000,000 2001
95 Luxembourg 6,070,000,000 2001
96 Latvia 6,046,000,000 2001
97 Sri Lanka 5,915,000,000 2001
98 Albania 5,898,000,000 2001
99 Jamaica 5,833,000,000 2001
100 Bahrain 5,819,000,000 2001
101 Armenia 5,784,000,000 2001
102 Burma 5,709,000,000 2001
103 Guatemala 5,559,000,000 2001
104 Zambia 5,458,000,000 2001
105 Trinidad and Tobago 4,943,000,000 2001
106 Kenya 3,981,000,000 2001
107 Congo, Democratic Republic of the 3,839,000,000 2001
108 Honduras 3,822,000,000 2001
109 El Salvador 3,777,000,000 2001
110 Panama 3,681,000,000 2001
111 Bolivia 3,634,000,000 2001
112 Cameroon 3,360,000,000 2001
113 Moldova 3,216,000,000 2001
114 Cyprus 3,163,000,000 2001
115 Cote d''Ivoire 2,983,000,000 2001
116 Yemen 2,800,000,000 2001
117 Tanzania 2,752,000,000 2001
118 Paraguay 2,637,000,000 2001
119 Nicaragua 2,388,000,000 2001
120 Brunei 2,322,000,000 2001
121 Sudan 2,222,000,000 2001
122 Mongolia 2,194,000,000 2001
123 Suriname 1,822,000,000 2001
124 Nepal 1,764,000,000 2001
125 Macau 1,688,000,000 2002
126 Malta 1,644,000,000 2001
127 Uganda 1,620,000,000 2001
128 Ethiopia 1,594,000,000 2001
129 Botswana 1,564,000,000 2001
130 New Caledonia 1,500,000,000 2001
131 Bahamas, The 1,451,000,000 2001
132 Senegal 1,412,000,000 2001
133 Papua New Guinea 1,391,000,000 2001
134 Mozambique 1,390,000,000 2001
135 Angola 1,348,000,000 2001
136 Mauritius 1,219,000,000 2001
137 Guadeloupe 1,074,000,000 2001
138 Martinique 1,070,000,000 2001
139 Reunion 1,005,000,000 2001
140 Netherlands Antilles 986,800,000 2001
141 Swaziland 962,900,000 2001
142 Virgin Islands 957,900,000 2001
143 Laos 824,700,000 2001
144 Guyana 792,400,000 2001
145 Madagascar 772,100,000 2001
146 Guam 771,900,000 2001
147 Gabon 742,500,000 2001
148 Guinea 735,200,000 2001
149 Barbados 725,400,000 2001
150 Malawi 715,300,000 2001
151 Congo, Republic of the 633,000,000 2001
152 Benin 631,100,000 2001
153 Togo 614,500,000 2001
154 Namibia 603,100,000 2001
155 Bermuda 598,600,000 2001
156 Haiti 539,400,000 2001
157 Afghanistan 511,400,000 2001
158 Aruba 494,700,000 2001
159 Fiji 483,700,000 2001
160 Mali 446,600,000 2001
161 Liberia 435,900,000 2001
162 French Guiana 423,200,000 2001
163 French Polynesia 398,300,000 2001
164 Bhutan 379,500,000 2001
165 Cayman Islands 355,200,000 2001
166 Niger 325,100,000 2001
167 Burkina Faso 259,600,000 2001
168 Sierra Leone 232,600,000 2001
169 Greenland 227,900,000 2001
170 Somalia 227,900,000 2001
171 Eritrea 205,100,000 2001
172 Belize 185,500,000 2001
173 Burundi 177,500,000 2001
174 Djibouti 167,400,000 2001
175 Faroe Islands 149,100,000 2001
176 Seychelles 148,800,000 2001
177 Mauritania 146,300,000 2001
178 Rwanda 140,000,000 2001
179 Grenada 128,300,000 2001
180 American Samoa 120,900,000 2001
181 Saint Lucia 111,800,000 2001
182 Cambodia 110,600,000 2001
183 Maldives 108,800,000 2001
184 Central African Republic 98,630,000 2001
185 Antigua and Barbuda 97,890,000 2001
186 Samoa 97,740,000 2001
187 Saint Kitts and Nevis 93,260,000 2001
188 Gibraltar 93,000,000 2001
189 Chad 87,460,000 2001
190 Saint Vincent and the Grenadines 86,000,000 2001
191 Western Sahara 83,700,000 2001
192 Gambia, The 79,360,000 2001
193 Dominica 67,350,000 2001
194 Guinea-Bissau 51,150,000 2001
195 Anguilla 42,600,000
196 Vanuatu 40,420,000 2001
197 Lesotho 40,000,000 2001
198 Cape Verde 39,080,000 2001
199 Saint Pierre and Miquelon 39,080,000 2001
200 British Virgin Islands 35,430,000 2001
201 Solomon Islands 29,760,000 2001
202 Nauru 27,900,000 2001
203 Cook Islands 25,510,000 2001
204 Tonga 25,360,000 2001
205 Equatorial Guinea 21,910,000 2001
206 Comoros 19,780,000 2001
207 Sao Tome and Principe 15,810,000 2001
208 Falkland Islands (Islas Malvinas) 15,190,000 2001
209 Kiribati 6,510,000 2001
210 Saint Helena 4,650,000 2001
211 Turks and Caicos Islands 4,650,000 2001
212 Niue 2,790,000 2001
213 Montserrat 2,325,000 2001
214 Johnston Atoll 2,002,000
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2054
Rank Country Birth rate(births/1,000 population) Date of Information
1 Niger 49.54 2003 est.
2 Mali 47.79 2003 est.
3 Chad 47.06 2003 est.
4 Uganda 46.57 2003 est.
5 Somalia 46.42 2003 est.
6 Angola 45.57 2003 est.
7 Liberia 45.28 2003 est.
8 Congo, Democratic Republic of the 45.12 2003 est.
9 Burkina Faso 44.78 2003 est.
10 Malawi 44.70 2003 est.
11 Sierra Leone 43.89 2003 est.
12 Yemen 43.23 2003 est.
13 Benin 43.15 2003 est.
14 Mayotte 42.86 2003 est.
15 Guinea 42.50 2003 est.
16 Madagascar 42.16 2003 est.
17 Mauritania 42.16 2003 est.
18 Sao Tome and Principe 41.87 2003 est.
19 Gaza Strip 41.23 2003 est.
20 Djibouti 40.78 2003 est.
21 Gambia, The 40.77 2003 est.
22 Afghanistan 40.63 2003 est.
23 Rwanda 40.10 2003 est.
24 Cote d''Ivoire 40.01 2003 est.
25 Ethiopia 39.81 2003 est.
26 Burundi 39.72 2003 est.
27 Zambia 39.53 2003 est.
28 Tanzania 39.50 2003 est.
29 Eritrea 39.44 2003 est.
30 Nigeria 38.75 2003 est.
31 Comoros 38.50 2003 est.
32 Guinea-Bissau 38.41 2003 est.
33 Mozambique 38.20 2003 est.
34 Oman 37.47 2003 est.
35 Saudi Arabia 37.20 2003 est.
36 Equatorial Guinea 36.94 2003 est.
37 Laos 36.93 2003 est.
38 Maldives 36.71 2003 est.
39 Gabon 36.54 2003 est.
40 Sudan 36.48 2003 est.
41 Senegal 36.23 2003 est.
42 Central African Republic 35.93 2003 est.
43 Cameroon 35.49 2003 est.
44 Togo 35.23 2003 est.
45 Guatemala 35.05 2003 est.
46 Bhutan 34.82 2003 est.
47 Marshall Islands 34.18 2003 est.
48 Namibia 34.10 2003 est.
49 West Bank 34.07 2003 est.
50 Haiti 34.06 2003 est.
51 Iraq 33.66 2003 est.
52 Tajikistan 32.78 2003 est.
53 Nepal 32.46 2003 est.
54 Solomon Islands 32.45 2003 est.
55 Honduras 31.67 2003 est.
56 Kiribati 31.24 2003 est.
57 Papua New Guinea 31.07 2003 est.
58 Belize 30.46 2003 est.
59 Zimbabwe 30.34 2003 est.
60 Paraguay 30.14 2003 est.
61 Bangladesh 29.90 2003 est.
62 Pakistan 29.59 2003 est.
63 Syria 29.54 2003 est.
64 Congo, Republic of the 29.46 2003 est.
65 Swaziland 29.37 2003 est.
66 Kenya 28.81 2003 est.
67 Turkmenistan 28.02 2003 est.
68 El Salvador 27.90 2003 est.
69 East Timor 27.75 2003 est.
70 Libya 27.43 2003 est.
71 Cambodia 27.28 2003 est.
72 Lesotho 27.26 2003 est.
73 Cape Verde 26.95 2003 est.
74 Micronesia, Federated States of 26.47 2003 est.
75 Philippines 26.30 2003 est.
76 Nicaragua 26.29 2003 est.
77 Nauru 26.09 2003 est.
78 Uzbekistan 26.09 2003 est.
79 Kyrgyzstan 26.06 2003 est.
80 Ghana 25.84 2003 est.
81 Bolivia 25.53 2003 est.
82 Botswana 25.50 2003 est.
83 Ecuador 24.94 2003 est.
84 Tonga 24.51 2003 est.
85 Egypt 24.36 2003 est.
86 Vanuatu 24.26 2003 est.
87 Dominican Republic 23.94 2003 est.
88 Malaysia 23.70 2003 est.
89 Jordan 23.68 2003 est.
90 Turks and Caicos Islands 23.51 2003 est.
91 India 23.28 2003 est.
92 American Samoa 23.26 2003 est.
93 Morocco 23.26 2003 est.
94 Guam 23.19 2003 est.
95 Fiji 23.06 2003 est.
96 Grenada 22.87 2003 est.
97 Peru 22.81 2003 est.
98 Algeria 21.94 2003 est.
99 Mexico 21.92 2003 est.
100 Kuwait 21.83 2003 est.
101 Colombia 21.59 2003 est.
102 Tuvalu 21.58 2003 est.
103 Indonesia 21.49 2003 est.
104 Mongolia 21.39 2003 est.
105 French Guiana 21.33 2003 est.
106 Saint Lucia 20.93 2003 est.
107 Panama 20.78 2003 est.
108 World 20.43 2003 est.
109 Reunion 20.17 2003 est.
110 Northern Mariana Islands 19.97 2003 est.
111 V','6b7618dfff0728154758329b262b3060fb1059b545b026ecab570ee8d27727ba','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2675aecb4819f751acd5dcf5b100eb38ba5a9707811fd7c8610378fae42cb62',2003,'YE','Yemen','communications',805,'enezuela 19.78 2003 est.
112 Brunei 19.68 2003 est.
113 Lebanon 19.68 2003 est.
114 Vietnam 19.58 2003 est.
115 New Caledonia 19.45 2003 est.
116 Costa Rica 19.40 2003 est.
117 Suriname 19.40 2003 est.
118 Azerbaijan 19.28 2003 est.
119 Burma 19.15 2003 est.
120 Bahrain 19.02 2003 est.
121 Palau 19.02 2003 est.
122 South Africa 18.87 2003 est.
123 Israel 18.67 2003 est.
124 Bahamas, The 18.57 2003 est.
125 United Arab Emirates 18.48 2003 est.
126 Saint Kitts and Nevis 18.45 2003 est.
127 Kazakhstan 18.36 2003 est.
128 Antigua and Barbuda 18.23 2003 est.
129 Albania 18.20 2003 est.
130 Guyana 17.87 2003 est.
131 French Polynesia 17.74 2003 est.
132 Brazil 17.67 2003 est.
133 Korea, North 17.61 2003 est.
134 Turkey 17.59 2003 est.
135 Montserrat 17.57 2003 est.
136 Argentina 17.47 2003 est.
137 Jamaica 17.35 2003 est.
138 Iran 17.23 2003 est.
139 Uruguay 17.19 2003 est.
140 Saint Vincent and the Grenadines 17.16 2003 est.
141 Seychelles 16.89 2003 est.
142 Dominica 16.78 2003 est.
143 Tunisia 16.53 2003 est.
144 Thailand 16.37 2003 est.
145 Guadeloupe 16.16 2003 est.
146 Sri Lanka 16.12 2003 est.
147 Chile 16.10 2003 est.
148 Mauritius 16.10 2003 est.
149 Greenland 16.09 2003 est.
150 Virgin Islands 15.80 2003 est.
151 Netherlands Antilles 15.76 2003 est.
152 Qatar 15.68 2003 est.
153 Samoa 15.41 2003 est.
154 Puerto Rico 15.00 2003 est.
155 British Virgin Islands 15.00 2003 est.
156 Martinique 14.96 2003 est.
157 Anguilla 14.68 2003 est.
158 Ireland 14.63 2003 est.
159 Saint Pierre and Miquelon 14.62 2003 est.
160 Moldova 14.31 2003 est.
161 New Zealand 14.14 2003 est.
162 United States 14.14 2003 est.
163 Iceland 14.13 2003 est.
164 Faroe Islands 13.81 2003 est.
165 Cayman Islands 13.33 2003 est.
166 Macedonia, The Former Yugoslav Republic of 13.20 2003 est.
167 Barbados 13.15 2003 est.
168 China 12.96 2003 est.
169 Saint Helena 12.90 2003 est.
170 Cyprus 12.77 2003 est.
171 Croatia 12.76 2003 est.
172 Malta 12.75 2003 est.
173 Singapore 12.75 2003 est.
174 Trinidad and Tobago 12.74 2003 est.
175 Taiwan 12.74 2003 est.
176 Serbia and Montenegro 12.74 2003 est.
177 Bosnia and Herzegovina 12.65 2003 est.
178 Korea, South 12.60 2003 est.
179 Armenia 12.57 2003 est.
180 Australia 12.55 2003 est.
181 France 12.54 2003 est.
182 Norway 12.17 2003 est.
183 Bermuda 12.13 2003 est.
184 Macau 12.07 2003 est.
185 Luxembourg 11.92 2003 est.
186 Cuba 11.87 2003 est.
187 Aruba 11.86 2003 est.
188 Georgia 11.79 2003 est.
189 Denmark 11.52 2003 est.
190 Portugal 11.45 2003 est.
191 Man, Isle of 11.38 2003 est.
192 Netherlands 11.31 2003 est.
193 Gibraltar 11.09 2003 est.
194 Canada 10.99 2003 est.
195 United Kingdom 10.99 2003 est.
196 Liechtenstein 10.92 2003 est.
197 Romania 10.79 2003 est.
198 Hong Kong 10.71 2003 est.
199 Finland 10.54 2003 est.
200 San Marino 10.49 2003 est.
201 Lithuania 10.48 2003 est.
202 Poland 10.47 2003 est.
203 Belgium 10.45 2003 est.
204 Jersey 10.44 2003 est.
205 Belarus 10.18 2003 est.
206 Slovakia 10.10 2003 est.
207 Russia 10.09 2003 est.
208 Spain 10.08 2003 est.
209 Ukraine 9.89 2003 est.
210 Greece 9.79 2003 est.
211 Sweden 9.71 2003 est.
212 Andorra 9.65 2003 est.
213 Japan 9.61 2003 est.
214 Switzerland 9.59 2003 est.
215 Monaco 9.46 2003 est.
216 Austria 9.43 2003 est.
217 Guernsey 9.43 2003 est.
218 Hungary 9.32 2003 est.
219 Estonia 9.24 2003 est.
220 Slovenia 9.23 2003 est.
221 Italy 9.18 2003 est.
222 Czech Republic 9.01 2003 est.
223 Germany 8.60 2003 est.
224 Latvia 8.55 2003 est.
225 Bulgaria 8.02 2003 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2066
Rank Country Death rate(deaths/1,000 population) Date of Information
1 Botswana 31.00 2003 est.
2 Mozambique 30.04 2003 est.
3 Angola 25.83 2003 est.
4 Lesotho 24.58 2003 est.
5 Zambia 24.30 2003 est.
6 Malawi 22.64 2003 est.
7 Zimbabwe 22.02 2003 est.
8 Rwanda 21.72 2003 est.
9 Niger 21.71 2003 est.
10 Swaziland 21.08 2003 est.
11 Sierra Leone 20.66 2003 est.
12 Ethiopia 20.17 2003 est.
13 Central African Republic 19.73 2003 est.
14 Djibouti 19.45 2003 est.
15 Mali 19.21 2003 est.
16 Namibia 19.17 2003 est.
17 Burkina Faso 18.76 2003 est.
18 South Africa 18.42 2003 est.
19 Cote d''Ivoire 18.41 2003 est.
20 Liberia 17.84 2003 est.
21 Burundi 17.80 2003 est.
22 Somalia 17.64 2003 est.
23 Tanzania 17.38 2003 est.
24 Afghanistan 17.15 2003 est.
25 Uganda 16.95 2003 est.
26 Guinea-Bissau 16.62 2003 est.
27 Ukraine 16.39 2003 est.
28 Chad 16.38 2003 est.
29 Kenya 16.01 2003 est.
30 Guinea 15.70 2003 est.
31 Cameroon 15.30 2003 est.
32 Congo, Democratic Republic of the 14.87 2003 est.
33 Georgia 14.71 2003 est.
34 Latvia 14.70 2003 est.
35 Bulgaria 14.34 2003 est.
36 Congo, Republic of the 14.20 2003 est.
37 Belarus 14.05 2003 est.
38 Russia 13.99 2003 est.
39 Nigeria 13.76 2003 est.
40 Benin 13.65 2003 est.
41 Bhutan 13.47 2003 est.
42 Estonia 13.42 2003 est.
43 Haiti 13.36 2003 est.
44 Eritrea 13.23 2003 est.
45 Mauritania 13.04 2003 est.
46 Hungary 13.00 2003 est.
47 Lithuania 12.89 2003 est.
48 Monaco 12.82 2003 est.
49 Moldova 12.70 2003 est.
50 Equatorial Guinea 12.54 2003 est.
51 Laos 12.39 2003 est.
52 Gambia, The 12.35 2003 est.
53 Romania 12.25 2003 est.
54 Burma 12.17 2003 est.
55 Madagascar 11.88 2003 est.
56 Togo 11.51 2003 est.
57 Man, Isle of 11.49 2003 est.
58 Croatia 11.25 2003 est.
59 Gabon 11.17 2003 est.
60 Senegal 10.88 2003 est.
61 Kazakhstan 10.78 2003 est.
62 Czech Republic 10.74 2003 est.
63 Denmark 10.72 2003 est.
64 Serbia and Montenegro 10.62 2003 est.
65 Sweden 10.58 2003 est.
66 Ghana 10.53 2003 est.
67 Germany 10.34 2003 est.
68 Portugal 10.21 2003 est.
69 United Kingdom 10.21 2003 est.
70 Armenia 10.16 2003 est.
71 Slovenia 10.15 2003 est.
72 Italy 10.12 2003 est.
73 Belgium 10.07 2003 est.
74 Poland 9.96 2003 est.
75 Greece 9.86 2003 est.
76 Guernsey 9.84 2003 est.
77 Nepal 9.84 2003 est.
78 Finland 9.82 2003 est.
79 Norway 9.72 2003 est.
80 Austria 9.69 2003 est.
81 Azerbaijan 9.68 2003 est.
82 Sudan 9.59 2003 est.
83 Spain 9.48 2003 est.
84 Guyana 9.27 2003 est.
85 Cambodia 9.26 2003 est.
86 Slovakia 9.22 2003 est.
87 Jersey 9.17 2003 est.
88 Kyrgyzstan 9.10 2003 est.
89 France 9.05 2003 est.
90 Yemen 9.04 2003 est.
91 Barbados 9.02 2003 est.
92 Uruguay 8.97 2003 est.
93 Gibraltar 8.93 2003 est.
94 Turkmenistan 8.87 2003 est.
95 Comoros 8.86 2003 est.
96 Saint Kitts and Nevis 8.85 2003 est.
97 World 8.83 2003 est.
98 Switzerland 8.82 2003 est.
99 Pakistan 8.79 2003 est.
100 Luxembourg 8.78 2003 est.
101 Trinidad and Tobago 8.71 2003 est.
102 Faroe Islands 8.70 2003 est.
103 Bahamas, The 8.68 2003 est.
104 Netherlands 8.66 2003 est.
105 Bangladesh 8.63 2003 est.
106 Kiribati 8.63 2003 est.
107 Japan 8.55 2003 est.
108 India 8.49 2003 est.
109 Tajikistan 8.46 2003 est.
110 United States 8.44 2003 est.
111 Mayotte 8.34 2003 est.
112 Bosnia and Herzegovina 8.21 2003 est.
113 Vanuatu 8.13 2003 est.
114 Uzbekistan 7.97 2003 est.
115 Ireland 7.94 2003 est.
116 Bolivia 7.91 2003 est.
117 San Marino 7.86 2003 est.
118 Malta 7.80 2003 est.
119 Macedonia, The Former Yugoslav Republic of 7.78 2003 est.
120 Puerto Rico 7.68 2003 est.
121 Greenland 7.66 2003 est.
122 Maldives 7.65 2003 est.
123 Cyprus 7.63 2003 est.
124 Papua New Guinea 7.63 2003 est.
125 Canada 7.61 2003 est.
126 Argentina 7.58 2003 est.
127 New Zealand 7.54 2003 est.
128 Bermuda 7.46 2003 est.
129 Grenada 7.46 2003 est.
130 Cuba 7.38 2003 est.
131 Montserrat 7.34 2003 est.
132 Tuvalu 7.34 2003 est.
133 Australia 7.31 2003 est.
134 Mongolia 7.18 2003 est.
135 Sao Tome and Principe 7.11 2003 est.
136 Nauru 7.08 2003 est.
137 Palau 7.00 2003 est.
138 Dominica 6.99 2003 est.
139 Iceland 6.95 2003 est.
140 Korea, North 6.93 2003 est.
141 Dominican Republic 6.88 2003 est.
142 Cape Verde 6.86 2003 est.
143 Thailand 6.86 2003 est.
144 Liechtenstein 6.85 2003 est.
145 Suriname 6.83 2003 est.
146 Mauritius 6.81 2003 est.
147 Guatemala 6.78 2003 est.
148 China 6.74 2003 est.
149 Saint Pierre and Miquelon 6.74 2003 est.
150 Seychelles 6.49 2003 est.
151 Albania 6.48 2003 est.
152 Sri Lanka 6.46 2003 est.
153 Honduras 6.44 2003 est.
154 Martinique 6.41 2003 est.
155 East Timor 6.41 2003 est.
156 Samoa 6.41 2003 est.
157 Netherlands Antilles 6.40 2003 est.
158 Aruba 6.38 2003 est.
159 Lebanon 6.32 2003 est.
160 Indonesia 6.26 2003 est.
161 Panama 6.25 2003 est.
162 Saint Helena 6.24 2003 est.
163 Israel 6.20 2003 est.
164 Taiwan 6.20 2003 est.
165 Hong Kong 6.19 2003 est.
166 Vietnam 6.19 2003 est.
167 Brazil 6.13 2003 est.
168 Saint Vincent and the Grenadines 6.08 2003 est.
169 Belize 6.05 2003 est.
170 Guadeloupe 6.04 2003 est.
171 Korea, South 6.03 2003 est.
172 El Salvador 6.01 2003 est.
173 Turkey 5.95 2003 est.
174 Iraq 5.84 2003 est.
175 Saudi Arabia 5.79 2003 est.
176 Morocco 5.78 2003 est.
177 Andorra 5.74 2003 est.
178 Fiji 5.70 2003 est.
179 Peru 5.69 2003 est.
180 Virgin Islands 5.68 2003 est.
181 Antigua and Barbuda 5.64 2003 est.
182 Chile 5.63 2003 est.
183 Colombia 5.63 2003 est.
184 New Caledonia 5.63 2003 est.
185 Philippines 5.60 2003 est.
186 Iran 5.54 2003 est.
187 Tonga 5.54 2003 est.
188 Reunion 5.49 2003 est.
189 Anguilla 5.42 2003 est.
190 Jamaica 5.42 2003 est.
191 Egypt 5.35 2003 est.
192 Ecuador 5.29 2003 est.
193 Saint Lucia 5.24 2003 est.
194 Malaysia 5.12 2003 est.
195 Micronesia, Federated States of 5.10 2003 est.
196 Algeria 5.09 2003 est.
197 Syria 5.04 2003 est.
198 Marshall Islands 5.03 2003 est.
199 Tunisia 5.02 2003 est.
200 Mexico 4.97 2003 est.
201 Venezuela 4.90 2003 est.
202 French Guiana 4.80 2003 est.
203 Cayman Islands 4.70 2003 est.
204 Nicaragua 4.69 2003 est.
205 Paraguay 4.64 2003 est.
206 French Polynesia 4.53 2003 est.
207 British Virgin Islands 4.46 2003 est.
208 Qatar 4.43 2003 est.
209 American Samoa 4.38 2003 est.
210 Turks and Caicos Islands 4.34 2003 est.
211 Costa Rica 4.31 2003 est.
212 Singapore 4.31 2003 est.
213 Guam 4.29 2003 est.
214 West Bank 4.16 2003 est.
215 Solomon Islands 4.12 2003 est.
216 Gaza Strip 4.03 2003 est.
217 United Arab Emirates 4.02 2003 est.
218 Bahrain 3.99 2003 est.
219 Oman 3.97 2003 est.
220 Macau 3.85 2003 est.
221 Libya 3.49 2003 est.
222 Brunei 3.39 2003 est.
223 Jordan 2.62 2003 est.
224 Kuwait 2.45 2003 est.
225 Northern Mariana Islands 2.44 2003 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2067
Rank Country Military expenditures - dollar figure Date of Information
1 United States $ 276,700,000,000
2 China $ 55,910,000,000 FY02
3 France $ 46,500,000,000 2000
4 Japan $ 39,520,000,000 FY02
5 Germany $ 38,800,000,000 2002
6 United Kingdom $ 31,700,000,000 2002
7 Italy $ 20,200,000,000 2002
8 Saudi Arabia $ 18,300,000,000
9 Brazil $ 13,408,000,000
10 Korea, South $ 13,094,300,000 FY02
11 India $ 11,520,000,000 FY02
12 Australia $ 11,390,000,000 FY02
13 Iran $ 9,700,000,000
14 Israel $ 8,970,000,000 FY02
15 Spain $ 8,600,000,000 2002
16 Turkey $ 8,100,000,000 2002 est.
17 Canada $ 7,861,000,000 FY01/02
18 Taiwan $ 7,574,000,000 FY02
19 Netherlands $ 6,500,000,000 FY00/01 est.
20 Greece $ 6,120,000,000
21 Korea, North $ 5,217,400,000 FY02
22 Singapore $ 4,470,000,000
23 Sweden $ 4,395,000,000 FY01
24 Argentina $ 4,300,000,000
25 Egypt $ 4,040,000,000 FY99
26 Mexico $ 4,000,000,000
27 Poland $ 3,500,000,000 2002
28 Colombia $ 3,300,000,000
29 Norway $ 3,113,000,000
30 Belgium $ 3,077,000,000 FY01/02
31 Pakistan $ 2,964,000,000 FY02
32 Switzerland $ 2,548,000,000 FY01
33 Chile $ 2,500,000,000
34 Denmark $ 2,470,000,000 FY99/00
35 Oman $ 2,424,000,000 FY01
36 Kuwait $ 1,967,300,000
37 Algeria $ 1,870,000,000
38 Finland $ 1,800,000,000 FY98/99
39 Thailand $ 1,775,000,000
40 South Africa $ 1,746,000,000 FY02
41 Malaysia $ 1,690,000,000
42 United Arab Emirates $ 1,600,000,000
43 Austria $ 1,497,000,000 FY01/02
44 Morocco $ 1,400,000,000
45 Iraq $ 1,300,000,000 FY00
46 Libya $ 1,300,000,000
47 Portugal $ 1,286,000,000 FY99/00
48 Czech Republic $ 1,190,200,000 FY01
49 Hungary $ 1,080,000,000 2002 est.
50 Indonesia $ 1,000,000,000
51 Peru $ 1,000,000,000
52 Philippines $ 995,000,000
53 Romania $ 985,000,000 2002
54 Venezuela $ 934,000,000
55 Syria $ 858,000,000
56 Ethiopia $ 800,000,000 FY00
57 Jordan $ 757,500,000 FY01
58 Qatar $ 723,000,000
59 Ecuador $ 720,000,000
60 Sri Lanka $ 719,000,000
61 Ireland $ 700,000,000 FY00/01
62 Serbia and Montenegro $ 654,000,000 2002
63 Vietnam $ 650,000,000
64 Zimbabwe $ 625,100,000 FY02
65 Ukraine $ 617,900,000 FY02
66 New Zealand $ 605,700,000 FY02
67 Sudan $ 581,000,000
68 Bangladesh $ 559,000,000 FY96
69 Lebanon $ 541,000,000
70 Bahrain $ 526,200,000 FY01
71 Afghanistan $ 525,200,000 FY02
72 Croatia $ 520,000,000 2002 est.
73 Yemen $ 482,500,000 FY01
74 Mali $ 419,700,000 FY02
75 Nigeria $ 417,900,000 FY02
76 Slovakia $ 406,000,000 2002
77 Cyprus $ 384,000,000
78 Slovenia $ 370,000,000 FY00
79 Bulgaria $ 356,000,000 FY02
80 Tunisia $ 356,000,000
81 Brunei $ 329,700,000 FY02
82 Congo, Democratic Republic of the $ 250,000,000
83 Uruguay $ 250,000,000 1999
84 Bosnia and Herzegovina $ 234,300,000
85 Lithuania $ 230,800,000 FY01
86 Angola $ 222,700,000 FY02
87 Kazakhstan $ 221,800,000 FY02
88 Botswana $ 207,300,000 FY02
89 Macedonia, The Former Yugoslav Republic of $ 200,000,000
90 Uzbekistan $ 200,000,000
91 New Caledonia $ 192,300,000 FY96
92 Kenya $ 185,200,000 FY02
93 Dominican Republic $ 180,000,000
94 Belarus $ 176,100,000 FY02
95 Estonia $ 155,000,000 2002 est.
96 Guinea $ 154,000,000 FY02
97 Luxembourg $ 147,800,000 FY01/02
98 Bolivia $ 147,000,000
99 Cote d''Ivoire $ 143,500,000 FY02
100 Armenia $ 135,000,000 FY01
101 Panama $ 128,000,000
102 Paraguay $ 125,000,000
103 Uganda $ 124,700,000 FY02
104 Azerbaijan $ 121,000,000
105 Guatemala $ 120,000,000
106 Cameroon $ 118,600,000 FY00
107 Cambodia $ 112,000,000
108 El Salvador $ 112,000,000
109 Eritrea $ 95,750,000 FY02
110 Trinidad and Tobago $ 90,000,000 1999
111 Turkmenistan $ 90,000,000
112 Latvia $ 87,000,000 FY01
113 Congo, Republic of the $ 84,000,000 FY01
114 Gabon $ 81,900,000 FY02
115 Benin $ 80,800,000 FY02
116 Namibia $ 73,100,000 FY02
117 Costa Rica $ 69,000,000
118 Senegal $ 68,600,000 FY02
119 Malta $ 60,000,000 2000 est.
120 Rwanda $ 59,570,000 FY02
121 Nepal $ 57,220,000 FY02
122 Albania $ 56,500,000 FY02
123 Laos $ 55,000,000
124 Madagascar $ 52,300,000 FY02
125 Haiti $ 50,000,000 FY00
126 Burkina Faso $ 45,830,000 FY02
127 Burundi $ 42,130,000 FY02
128 Chad $ 40,740,000 FY02
129 Papua New Guinea $ 40,210,000 FY02
130 Fiji $ 39,210,000 FY02
131 Burma $ 39,000,000
132 Mauritania $ 37,110,000 FY02
133 Ghana $ 36,010,000 FY02
134 Tajikistan $ 35,400,000 FY01
135 Mozambique $ 35,100,000
136 Honduras $ 35,000,000
137 Maldives $ 34,460,000 FY02
138 Lesotho $ 34,000,000 1999
139 Zambia $ 33,460,000 FY02
140 Equatorial Guinea $ 30,000,000 FY02
141 Jamaica $ 30,000,000
142 Djibouti $ 26,530,000 FY02
143 Nicaragua $ 26,000,000
144 Togo $ 23,720,000 FY02
145 Mongolia $ 23,100,000 FY02
146 Georgia $ 23,000,000
147 Niger $ 20,540,000 FY02
148 Bahamas, The $ 20,000,000 FY95/96
149 Swaziland $ 20,000,000 FY01
150 Tanzania $ 19,680,000 FY02
151 Kyrgyzstan $ 19,200,000 FY01
152 Somalia $ 17,100,000 FY02
153 Central African Republic $ 13,430,000 FY02
154 Malawi $ 13,010,000 FY02
155 Seychelles $ 12,800,000 FY02
156 Sierra Leone $ 10,260,000 FY02
157 Mauritius $ 9,712,000 FY02
158 Bhutan $ 9,300,000 FY02
159 Cape Verde $ 9,300,000 FY02
160 Liberia $ 7,800,000 FY02
161 Belize $ 7,700,000
162 Moldova $ 6,400,000 FY02
163 Comoros $ 6,000,000 FY02
164 Guinea-Bissau $ 5,600,000 FY02
165 East Timor $ 4,400,000 FY03
166 Bermuda $ 4,028,000 January 2002
167 Gambia, The $ 1,200,000 FY02
168 San Marino $ 700,000 FY00/01
169 Sao Tome and Principe $ 400,000 FY01
170 Iceland $ 0
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2078
Rank Country Exports Date of Information
1 World $ 6,600,000,000,000 2002 est.
2 United States $ 687,000,000,000 2002 est.
3 Germany $ 608,000,000,000 2002 est.
4 Japan $ 383,800,000,000 2002 est.
5 China $ 325,600,000,000 2002 est.
6 France $ 307,800,000,000 2002
7 United Kingdom $ 286,300,000,000 2002
8 Canada $ 260,500,000,000 2002 est.
9 Italy $ 259,200,000,000 2002 est.
10 Netherlands $ 243,300,000,000 2002
11 Hong Kong $ 200,300,000,000 2002 est.
12 Korea, South $ 162,600,000,000 2002 est.
13 Belgium $ 162,000,000,000 2002 est.
14 Mexico $ 158,400,000,000 2002 est.
15 Taiwan $ 130,000,000,000 2002 est.
16 Singapore $ 127,000,000,000 2002 est.
17 Spain $ 122,200,000,000 2002 est.
18 Russia $ 104,600,000,000 2002 est.
19 Switzerland $ 100,300,000,000 2002 est.
20 Malaysia $ 95,200,000,000 2002 est.
21 Ireland $ 86,600,000,000 2002 est.
22 Sweden $ 80,600,000,000 2002 est.
23 Saudi Arabia $ 71,000,000,000 2001
24 Austria $ 70,000,000,000 2001
25 Norway $ 68,200,000,000 2002 est.
26 Thailand $ 67,700,000,000 2002 est.
27 Australia $ 66,300,000,000 2002 est.
28 Brazil $ 59,400,000,000 2002 est.
29 Denmark $ 56,300,000,000 2002 est.
30 Indonesia $ 52,300,000,000 2002 est.
31 Puerto Rico $ 46,900,000,000 2001
32 United Arab Emirates $ 44,900,000,000 2002 est.
33 India $ 44,500,000,000 2001
34 Czech Republic $ 40,800,000,000 2002
35 Finland $ 40,100,000,000 2002
36 Philippines $ 35,100,000,000 2002
37 Turkey $ 35,100,000,000 2002
38 Poland $ 32,400,000,000 2002 est.
39 South Africa $ 31,800,000,000 2002 est.
40 Hungary $ 31,400,000,000 2002 est.
41 Venezuela $ 28,600,000,000 2001
42 Israel $ 28,100,000,000 2002 est.
43 Portugal $ 25,900,000,000 2001
44 Argentina $ 25,300,000,000 2002
45 Iran $ 24,800,000,000 2002 est.
46 Algeria $ 19,500,000,000 2002 est.
47 Ukraine $ 18,100,000,000 2002 est.
48 Chile $ 17,800,000,000 2002 est.
49 Nigeria $ 17,300,000,000 2002 est.
50 Vietnam $ 16,500,000,000 2002 est.
51 Kuwait $ 16,000,000,000 2002 est.
52 New Zealand $ 15,000,000,000 2002 est.
53 Romania $ 13,700,000,000 2002 est.
54 Iraq $ 13,000,000,000 2002 est.
55 Colombia $ 12,900,000,000 2002 est.
56 Slovakia $ 12,900,000,000 2002 est.
57 Greece $ 12,600,000,000 2002
58 Libya $ 11,800,000,000 2002 est.
59 Qatar $ 10,900,000,000 2002 est.
60 Oman $ 10,600,000,000 2002 est.
61 Kazakhstan $ 10,300,000,000 2002 est.
62 Slovenia $ 10,300,000,000 2002
63 Luxembourg $ 10,100,000,000 2002
64 Pakistan $ 9,800,000,000 FY02/03 est.
65 Angola $ 8,600,000,000 2002 est.
66 Belarus $ 7,700,000,000 2002
67 Peru $ 7,600,000,000 2002 est.
68 Morocco $ 7,500,000,000 2002 est.
69 Egypt $ 7,000,000,000 2002 est.
70 Tunisia $ 6,800,000,000 2002 est.
71 Bangladesh $ 6,200,000,000 2002
72 Syria $ 6,200,000,000 2002 est.
73 Bahrain $ 5,800,000,000 2002
74 Panama $ 5,800,000,000 2002 est.
75 Lithuania $ 5,400,000,000 2002 est.
76 Bulgaria $ 5,300,000,000 2002 est.
77 Dominican Republic $ 5,300,000,000 2002 est.
78 Costa Rica $ 5,100,000,000 2002
79 Ecuador $ 4,900,000,000 2002 est.
80 Croatia $ 4,900,000,000 2002
81 Sri Lanka $ 4,600,000,000 2002
82 Cote d''Ivoire $ 4,400,000,000 2002 est.
83 Trinidad and Tobago $ 4,200,000,000 2002 est.
84 Estonia $ 3,400,000,000 2002
85 Yemen $ 3,400,000,000 2002 est.
86 Brunei $ 3,000,000,000 2000 est.
87 El Salvador $ 3,000,000,000 2002 est.
88 Turkmenistan $ 2,970,000,000 2002 est.
89 Uzbekistan $ 2,800,000,000 2002 est.
90 Burma $ 2,700,000,000 2002
91 Guatemala $ 2,700,000,000 2002 est.
92 Gabon $ 2,600,000,000 2002 est.
93 Equatorial Guinea $ 2,500,000,000 2002 est.
94 Jordan $ 2,500,000,000 2002 est.
95 Liechtenstein $ 2,470,000,000 1996
96 Botswana $ 2,400,000,000 2002 est.
97 Serbia and Montenegro $ 2,400,000,000 2002
98 Congo, Republic of the $ 2,400,000,000 2002 est.
99 Macau $ 2,360,000,000 2002
100 Iceland $ 2,300,000,000 2002
101 Latvia $ 2,300,000,000 2002
102 Ghana $ 2,200,000,000 2002 est.
103 Kenya $ 2,100,000,000 2002 est.
104 Uruguay $ 2,100,000,000 2002 est.
105 Azerbaijan $ 2,000,000,000 2002
106 Paraguay $ 2,000,000,000 2002 est.
107 Malta $ 2,000,000,000 2001
108 Cameroon $ 1,900,000,000 2002 est.
109 Aruba $ 1,880,000,000 2002 est.
110 Cuba $ 1,800,000,000 2002 est.
111 Sudan $ 1,800,000,000 2002 est.
112 Papua New Guinea $ 1,800,000,000 2002 est.
113 Mauritius $ 1,600,000,000 2002 est.
114 Zimbabwe $ 1,570,000,000 2001 est.
115 Jamaica $ 1,400,000,000 2002 est.
116 Cambodia $ 1,380,000,000 2001 est.
117 Bolivia $ 1,300,000,000 2002 est.
118 Honduras $ 1,300,000,000 2002 est.
119 Namibia $ 1,210,000,000 2002 est.
120 Afghanistan $ 1,200,000,000 2001 est.
121 Congo, Democratic Republic of the $ 1,200,000,000 2002 est.
122 Bosnia and Herzegovina $ 1,150,000,000 2002 est.
123 Senegal $ 1,150,000,000 2002 est.
124 Macedonia, The Former Yugoslav Republic of $ 1,100,000,000 2002 est.
125 Cyprus $ 1,030,000,000 2002 est.
126 Lebanon $ 1,000,000,000 2002 est.
127 Tanzania $ 863,000,000 2001
128 Korea, North $ 842,000,000 2001 est.
129 Guinea $ 835,000,000 2002 est.
130 Swaziland $ 820,000,000 2002 est.
131 Nepal $ 720,000,000 2001 est.
132 Tajikistan $ 710,000,000 2002 est.
133 Zambia $ 709,000,000 2001
134 Madagascar $ 700,000,000 2002
135 Mali $ 680,000,000 2002 est.
136 Mozambique $ 680,000,000 2002 est.
137 Nicaragua $ 637,000,000 2002 est.
138 Gaza Strip $ 603,000,000
139 West Bank $ 603,000,000
140 Moldova $ 590,000,000 2002 est.
141 Bahamas, The $ 560,700,000 2002 est.
142 Netherlands Antilles $ 553,000,000 2002
143 Armenia $ 525,000,000 2001 est.
144 Georgia $ 515,000,000 2002 est.
145 Mongolia $ 501,000,000 2002 est.
146 Guyana $ 500,000,000 2002
147 Kyrgyzstan $ 488,000,000 2002 est.
148 Uganda $ 476,000,000 2002 est.
149 Togo $ 449,000,000 2002
150 Suriname $ 445,000,000 2002
151 Fiji $ 442,000,000 2001
152 Malawi $ 435,000,000 201
153 Ethiopia $ 433,000,000 2001 est.
154 Lesotho $ 422,000,000 2002 est.
155 Faroe Islands $ 418,000,000 2001
156 New Caledonia $ 400,000,000 2000
157 Greenland $ 364,000,000 2001
158 Mauritania $ 355,000,000 2002
159 American Samoa $ 345,000,000 1999
160 Laos $ 345,000,000 2002 est.
161 Albania $ 340,000,000 2002 est.
162 Haiti $ 298,000,000 2002
163 Niger $ 293,000,000 2002 est.
164 Belize $ 290,000,000 2002 est.
165 French Polynesia $ 260,000,000 2000
166 Martinique $ 250,000,000 1997
167 Burkina Faso $ 250,000,000 2002 est.
168 Seychelles $ 235,000,000 2002
169 Barbados $ 227,000,000 2002
170 Reunion $ 214,000,000 1997
171 Benin $ 207,000,000 2002
172 Chad $ 197,000,000 2002 est.
173 Turks and Caicos Islands $ 169,200,000 2000
174 French Guiana $ 155,000,000
175 Bhutan $ 154,000,000 2000 est.
176 Guadeloupe $ 140,000,000 1997
177 Gambia, The $ 138,000,000 2002 est.
178 Central African Republic $ 134,000,000 2002 est.
179 Somalia $ 126,000,000 2001 est.
180 Liberia $ 110,000,000 2002 est.
181 Maldives $ 110,000,000 2001 est.
182 Gibraltar $ 81,100,000 1997
183 Grenada $ 78,000,000 2000 est.
184 Guam $ 75,700,000 1999 est.
185 Guinea-Bissau $ 71,000,000 2002 est.
186 Djibouti $ 70,000,000 2002 est.
187 Saint Lucia $ 68,300,000 2000 est.
188 Rwanda $ 68,000,000 2002 est.
189 Andorra $ 58,000,000 1998
190 Saint Vincent and the Grenadines $ 53,700,000 2000 est.
191 Bermuda $ 51,000,000 2000
192 Dominica $ 50,000,000 2002 est.
193 Solomon Islands $ 47,000,000 2001 est.
194 Saint Kitts and Nevis $ 47,000,000 2001 est.
195 Cyprus $ 46,000,000 2002 est.
196 Antigua and Barbuda $ 40,000,000
197 Sierra Leone $ 35,000,000 2000 est.
198 Cape Verde $ 30,000,000 2002 est.
199 Nauru $ 27,000,000 1995
200 Burundi $ 26,000,000 2002 est.
201 British Virgin Islands $ 25,300,000 2002
202 Micronesia, Federated States of $ 22,000,000 FY 99/00 est.
203 Vanuatu $ 22,000,000 2001
204 Eritrea $ 20,000,000 2001
205 Palau $ 18,000,000 2001 est.
206 Comoros $ 16,300,000 2001 est.
207 Samoa $ 15,500,000 2001
208 Saint Pierre and Miquelon $ 12,000,000 1999
209 Cook Islands $ 9,100,000 2000
210 Marshall Islands $ 9,000,000 2000
211 Tonga $ 8,900,000 2001 est.
212 East Timor $ 8,000,000 2001 est.
213 Falkland Islands (Islas Malvinas) $ 7,600,000 1995
214 Kiribati $ 6,000,000 1998
215 Sao Tome and Principe $ 5,500,000 2002 est','5c1d98d5fd9a1f282c774e4473da192beb626a9a76c1eb40919aa88f97e1c491','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3748895fcf6c3ade661188a26f329cc3ac731bd1d057961849e3c6d81dcd2fc',2003,'YE','Yemen','communications',806,'.
216 Mayotte $ 3,440,000 1997
217 Anguilla $ 2,600,000 1999
218 Norfolk Island $ 1,500,000 FY 91/92
219 Cayman Islands $ 1,200,000 1999
220 Saint Helena $ 704,000 1995
221 Montserrat $ 700,000 2001
222 Tuvalu $ 276,000 1997
223 Wallis and Futuna $ 250,000 1999
224 Niue $ 137,200 1999
225 Tokelau $ 98,000 1983
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2079
Rank Country Debt - external Date of Information
1 World $ 2,000,000,000,000 2002 est.
2 United States $ 862,000,000,000 1995 est.
3 Brazil $ 222,400,000,000 2002
4 Australia $ 176,800,000,000 yearend 2002 est.
5 Argentina $ 155,000,000,000 2001 est.
6 Russia $ 153,500,000,000 yearend 2002
7 Mexico $ 150,000,000,000 2000 est.
8 China $ 149,400,000,000 2002 est.
9 Korea, South $ 135,200,000,000 yearend 2002 est.
10 Indonesia $ 131,000,000,000 2002 est.
11 Iraq $ 120,000,000,000 2002 est.
12 Turkey $ 118,300,000,000 Yearend 2001
13 India $ 100,600,000,000 2001 est.
14 Spain $ 90,000,000,000 1993 est.
15 Sweden $ 66,500,000,000 1994
16 Poland $ 64,000,000,000 2002
17 Greece $ 63,400,000,000 2002 est.
18 Thailand $ 62,500,000,000 2002 est.
19 Philippines $ 60,300,000,000 2002
20 Hong Kong $ 49,500,000,000 2002 est.
21 Malaysia $ 47,500,000,000 2002 est.
22 Israel $ 42,800,000,000 2001 est.
23 Chile $ 40,400,000,000 2002
24 Colombia $ 38,400,000,000 2002 est.
25 Venezuela $ 38,200,000,000 2000
26 New Zealand $ 33,000,000,000 2002 est.
27 Pakistan $ 32,300,000,000 2002 est.
28 Hungary $ 31,500,000,000 2002 est.
29 Egypt $ 30,500,000,000 2002 est.
30 Finland $ 30,000,000,000 December 1993
31 Nigeria $ 29,700,000,000 2002 est.
32 Peru $ 29,200,000,000 2002 est.
33 Belgium $ 28,300,000,000 1999 est.
34 Saudi Arabia $ 25,900,000,000 2003 est.
35 South Africa $ 24,700,000,000 2002 est.
36 Taiwan $ 24,700,000,000 2002
37 Czech Republic $ 23,800,000,000 2002
38 Syria $ 22,000,000,000 2002 est.
39 Denmark $ 21,700,000,000 2000
40 Algeria $ 21,600,000,000 2002 est.
41 United Arab Emirates $ 18,500,000,000 2002 est.
42 Morocco $ 17,700,000,000 2002 est.
43 Bangladesh $ 16,500,000,000 2002
44 Croatia $ 16,500,000,000 yearend 2002 est.
45 Sudan $ 15,800,000,000 2002 est.
46 Qatar $ 15,400,000,000 2002 est.
47 Ecuador $ 14,400,000,000 2002
48 Ukraine $ 14,200,000,000 2002
49 Vietnam $ 14,100,000,000 2001
50 Romania $ 13,700,000,000 2002 est.
51 Tunisia $ 13,600,000,000 2003 est.
52 Portugal $ 13,100,000,000 1997 est.
53 Congo, Democratic Republic of the $ 12,900,000,000 2000 est.
54 Cuba $ 12,300,000,000 2002 est.
55 Austria $ 12,100,000,000 2001 est.
56 Korea, North $ 12,000,000,000 1996 est.
57 Uruguay $ 11,800,000,000 2002 est.
58 Ireland $ 11,000,000,000 1998
59 Kuwait $ 10,400,000,000 2000 est.
60 Bulgaria $ 10,300,000,000 yearend 2002
61 Cote d''Ivoire $ 10,300,000,000 2002 est.
62 Angola $ 9,900,000,000 2002 est.
63 Sri Lanka $ 9,800,000,000 2002
64 Slovakia $ 9,600,000,000 2002 est.
65 Lebanon $ 9,300,000,000 2002 est.
66 Serbia and Montenegro $ 9,200,000,000 2001 est.
67 Iran $ 8,700,000,000 2002 est.
68 Cameroon $ 8,600,000,000 2002 est.
69 Jordan $ 8,200,000,000 2002 est.
70 Singapore $ 8,200,000,000 2002 est.
71 Cyprus $ 8,000,000,000 2002
72 Slovenia $ 7,900,000,000 2001
73 Ghana $ 7,200,000,000 2002 est.
74 Panama $ 7,000,000,000 2002 est.
75 Tanzania $ 6,800,000,000 2002 est.
76 Kazakhstan $ 6,600,000,000 2002 est.
77 Yemen $ 6,200,000,000 2002
78 Burma $ 6,100,000,000 2002 est.
79 Bolivia $ 5,900,000,000 2002 est.
80 Lithuania $ 5,800,000,000 2002 est.
81 Zambia $ 5,800,000,000 2001
82 Nicaragua $ 5,800,000,000 2002 est.
83 Kenya $ 5,700,000,000 2002 est.
84 Oman $ 5,700,000,000 2002 est.
85 El Salvador $ 5,600,000,000 2001 est.
86 Honduras $ 5,400,000,000 2002
87 Ethiopia $ 5,300,000,000 2001 est.
88 Jamaica $ 5,300,000,000 2002 est.
89 Congo, Republic of the $ 5,000,000,000 2000 est.
90 Guatemala $ 4,900,000,000 2002 est.
91 Costa Rica $ 4,800,000,000 2002 est.
92 Dominican Republic $ 4,800,000,000 2002 est.
93 Madagascar $ 4,600,000,000 2002
94 Uzbekistan $ 4,600,000,000 2002 est.
95 Libya $ 4,400,000,000 2001 est.
96 Zimbabwe $ 3,900,000,000 2002 est.
97 Gabon $ 3,800,000,000 2002 est.
98 Bahrain $ 3,700,000,000 2002
99 Guinea $ 3,400,000,000 2000 est.
100 Latvia $ 3,400,000,000 2000 est.
101 Estonia $ 3,300,000,000 2001 est.
102 Mali $ 3,300,000,000 2000
103 Paraguay $ 3,200,000,000 2002 est.
104 Senegal $ 3,100,000,000 2002 est.
105 Malawi $ 2,900,000,000 2002
106 Bosnia and Herzegovina $ 2,800,000,000 2001
107 Uganda $ 2,800,000,000 2002 est.
108 Papua New Guinea $ 2,800,000,000 2002 est.
109 Trinidad and Tobago $ 2,800,000,000 2002 est.
110 Iceland $ 2,600,000,000 1999
111 Somalia $ 2,600,000,000 2000 est.
112 Nepal $ 2,550,000,000 FY 00/01
113 Laos $ 2,530,000,000 1999
114 Mauritania $ 2,500,000,000 2000
115 Mauritius $ 2,400,000,000 2002 est.
116 Turkmenistan $ 2,400,000,000 2001 est.
117 Liberia $ 2,100,000,000 2000 est.
118 Canada $ 1,900,000,000 2000
119 Georgia $ 1,700,000,000 2001
120 Benin $ 1,600,000,000 2000
121 Niger $ 1,600,000,000 1999 est.
122 Kyrgyzstan $ 1,500,000,000 2002 est.
123 Sierra Leone $ 1,500,000,000 2002 est.
124 Azerbaijan $ 1,400,000,000 2002
125 Togo $ 1,400,000,000 2000
126 Netherlands Antilles $ 1,350,000,000 1996
127 Moldova $ 1,300,000,000 2002
128 Burkina Faso $ 1,300,000,000 2000
129 Rwanda $ 1,300,000,000 2000 est.
130 Macedonia, The Former Yugoslav Republic of $ 1,300,000,000 2001 est.
131 French Guiana $ 1,200,000,000 1988
132 Guyana $ 1,200,000,000 2002
133 Haiti $ 1,200,000,000 1999
134 Burundi $ 1,140,000,000 2001
135 Chad $ 1,100,000,000 2000 est.
136 Tajikistan $ 1,000,000,000 2002 est.
137 Mozambique $ 966,000,000 2002 est.
138 Guinea-Bissau $ 941,500,000 2000 est.
139 Mongolia $ 913,000,000 2001 est.
140 Armenia $ 905,000,000 June 2001
141 Central African Republic $ 881,400,000 2000 est.
142 Belarus $ 851,000,000 2001 est.
143 Cambodia $ 829,000,000 1999 est.
144 Albania $ 784,000,000 2000
145 Lesotho $ 735,000,000 2002
146 Barbados $ 692,000,000 2002
147 Namibia $ 517,000,000 2002 est.
148 Gambia, The $ 476,000,000 2001 est.
149 Belize $ 475,000,000 2001 est.
150 Bahamas, The $ 371,600,000 2001
151 Djibouti $ 366,000,000 2002 est.
152 Botswana $ 360,000,000 2002
153 Cape Verde $ 325,000,000 2002
154 Suriname $ 321,000,000 2002 est.
155 Swaziland $ 320,000,000 2002 est.
156 Eritrea $ 311,000,000 2000 est.
157 Aruba $ 285,000,000 1996
158 Maldives $ 281,000,000 2003 est.
159 Macau $ 255,000,000 2000 est.
160 Sao Tome and Principe $ 253,800,000 2000
161 Equatorial Guinea $ 248,000,000 2000 est.
162 Bhutan $ 245,000,000 2000
163 Comoros $ 232,000,000 2000 est.
164 Antigua and Barbuda $ 231,000,000 1999
165 Saint Lucia $ 214,000,000 2000
166 Samoa $ 197,000,000 2000
167 Grenada $ 196,000,000 2000
168 Martinique $ 180,000,000 1994
169 Saint Kitts and Nevis $ 171,000,000 2001
170 Seychelles $ 170,000,000 2002 est.
171 Saint Vincent and the Grenadines $ 167,200,000 2000
172 Dominica $ 161,500,000 2001
173 Bermuda $ 145,000,000 FY 99/00
174 Cook Islands $ 141,000,000 1996 est.
175 Solomon Islands $ 137,000,000 2001 est.
176 Fiji $ 135,900,000 2000
177 Malta $ 130,000,000 1997
178 Gaza Strip $ 108,000,000 1997 est.
179 West Bank $ 108,000,000 1997 est.
180 Marshall Islands $ 86,500,000 FY 99/00 est.
181 New Caledonia $ 79,000,000 1998 est.
182 Cayman Islands $ 70,000,000 1996
183 Vanuatu $ 68,600,000 2000 est.
184 Faroe Islands $ 64,000,000 1999
185 Tonga $ 57,500,000 June 2001
186 Micronesia, Federated States of $ 53,100,000 FY 02/03 est.
187 British Virgin Islands $ 36,100,000 1997
188 Nauru $ 33,300,000
189 Greenland $ 25,000,000 1999
190 Kiribati $ 10,000,000 1999 est.
191 Montserrat $ 8,900,000 1997
192 Anguilla $ 8,800,000 1998
193 Niue $ 418,000 2002 est.
194 Brunei $ 0
195 Norway $ 0
196 Tokelau $ 0
197 Palau $ 0 FY 99/00
198 Liechtenstein $ 0 2001
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2085
Rank Country Highways(km) Date of Information
1 United States 6,334,859 2000
2 India 3,319,644 1999 est.
3 Brazil 1,724,929 2000
4 Canada 1,408,000 2002
5 China 1,402,698 2000
6 Japan 1,161,894 1999
7 France 894,000 2000
8 Australia 811,603 1999 est.
9 Spain 663,795 1999
10 Russia 532,393 2000
11 Italy 479,688 1999
12 Turkey 385,960 1999
13 United Kingdom 371,913 1999
14 Poland 364,656 2000
15 South Africa 362,099 2000
16 Indonesia 342,700 1999 est.
17 Mexico 329,532 1999 est.
18 Pakistan 254,410 1999
19 Germany 230,735 1999
20 Argentina 215,471 1999
21 Sweden 212,402 2000
22 Bangladesh 207,486 1999
23 Philippines 201,994 2000
24 Austria 200,000 2000
25 Romania 198,603 2000
26 Nigeria 194,394 1999 est.
27 Hungary 188,203 1999
28 Ukraine 169,491 2000
29 Iran 167,157 1998
30 Congo, Democratic Republic of the 157,000 1999 est.
31 Saudi Arabia 151,470 1999
32 Belgium 148,216 2000
33 Greece 117,000 1999 est.
34 Netherlands 116,500 1999
35 Colombia 110,000 2000
36 Algeria 104,000 1999
37 Sri Lanka 96,695 1999
38 Venezuela 96,155 1999 est.
39 Vietnam 93,300 1999 est.
40 Ireland 92,500 2000 est.
41 New Zealand 92,053 2000
42 Norway 91,454 2000
43 Tanzania 88,200 1999 est.
44 Korea, South 86,990 1999 est.
45 Libya 83,200 1999 est.
46 Uzbekistan 81,600 1999 est.
47 Kazakhstan 81,331 2000
48 Chile 79,814 2000
49 Finland 77,943 2001
50 Lithuania 75,243 2000
51 Belarus 74,385 2000
52 Latvia 73,202 2000
53 Peru 72,900 1999 est.
54 Denmark 71,591 2000
55 Switzerland 71,011 2000
56 Portugal 68,732 2000
57 Yemen 67,000 1999 est.
58 Zambia 66,781 1999 est.
59 Namibia 66,467 2000
60 Malaysia 65,877 1999
61 Thailand 64,600 1999 est.
62 Egypt 64,000 1999 est.
63 Kenya 63,942 2000
64 Cuba 60,858 1999 est.
65 Morocco 57,707 2000
66 Czech Republic 55,408 2000
67 Bolivia 53,790 2000 est.
68 Angola 51,429 1999
69 Estonia 51,411 2000
70 Cote d''Ivoire 50,400 1999 est.
71 Madagascar 49,827 1999 est.
72 Serbia and Montenegro 49,805 2000
73 Mongolia 49,250 2000
74 Iraq 45,550 2000 est.
75 Syria 43,381 1999
76 Ecuador 43,197 2000
77 Slovakia 42,717 2000
78 Ghana 39,409 1999 est.
79 Bulgaria 37,286 2000
80 Taiwan 35,931 2000
81 Costa Rica 35,892 2000
82 Oman 34,965 2001
83 Cameroon 34,300 1999 est.
84 Chad 33,400 1999 est.
85 Ethiopia 31,571 2000
86 Korea, North 31,200 1999 est.
87 Guinea 30,500 1999 est.
88 Mozambique 30,400 1999 est.
89 Paraguay 29,500 1999 est
90 Malawi 28,400 1999 est.
91 Burma 28,200 1996 est.
92 Croatia 28,123 2000
93 Tajikistan 27,767 2000
94 Uganda 27,000 1999 est.
95 Azerbaijan 24,981 2000
96 Turkmenistan 24,000 1999 est.
97 Central African Republic 23,810 1999 est.
98 Somalia 22,100 1999 est.
99 Bosnia and Herzegovina 21,846 1999 est
100 Laos 21,716 1999 est.
101 Afghanistan 21,000 1999 est.
102 Georgia 20,362 2000
103 Slovenia 20,177 2000
104 Papua New Guinea 19,600 1999 est.
105 Nicaragua 19,032 2000
106 Tunisia 18,997 2000
107 Jamaica 18,700 1999 est.
108 Kyrgyzstan 18,500 1999 est.
109 Zimbabwe 18,338 1999 est.
110 Albania 18,000 2000
111 Israel 16,281 2000
112 Armenia 15,918 2000
113 Mali 15,100 1999 est.
114 Senegal 14,576 2000
115 Burundi 14,480 1999 est.
116 Puerto Rico 14,400 1999 est.
117 Guatemala 14,118 1999
118 Honduras 13,603 1999 est.
119 Cyprus 13,491 2000/1996
120 Nepal 13,223 1999 est.
121 Iceland 12,955 2003
122 Congo, Republic of the 12,800 1999 est.
123 Moldova 12,657 1999
124 Dominican Republic 12,600 1999
125 Burkina Faso 12,506 1999
126 Cambodia 12,323 2000 est
127 Rwanda 12,000 1999 est.
128 Sudan 11,900 1999 est.
129 Panama 11,400 1999
130 Sierra Leone 11,330 1999
131 Liberia 10,600 1999 est.
132 Botswana 10,217 1999
133 Niger 10,100 1999 est.
134 El Salvador 10,029 1999 est.
135 Uruguay 8,983 1999 est.
136 Macedonia, The Former Yugoslav Republic of 8,684 1999 est.
137 Gabon 8,464 2000 est.
138 Trinidad and Tobago 8,320 1999 est.
139 Guyana 7,970 1999 est.
140 Mauritania 7,720 2000
141 Togo 7,520 1999 est.
142 Lebanon 7,300 1999 est.
143 Jordan 7,245 2000
144 Benin 6,787 1999 est.
145 Western Sahara 6,200 1991 est
146 Lesotho 5,940 1999
147 Luxembourg 5,189 2000
148 New Caledonia 4,825 1999
149 West Bank 4,500 1997 est.
150 Suriname 4,492 2000
151 Kuwait 4,450 1999 est.
152 Guinea-Bissau 4,400 1999 est.
153 Haiti 4,160 1999 est.
154 Eritrea 4,010 1999 est.
155 East Timor 3,800 1995
156 Bhutan 3,690 1999 est.
157 Fiji 3,440 1999 est.
158 Bahrain 3,261 2000
159 Swaziland 3,247 1998
160 Singapore 3,066 1999
161 Djibouti 2,890 1999 est.
162 Equatorial Guinea 2,880 1999 est.
163 Belize 2,872 1999 est.
164 Reunion 2,724 1994
165 Gambia, The 2,700 1999
166 Bahamas, The 2,693 1999 est.
167 French Polynesia 2,590 1999
168 Brunei 2,525 2000
169 Guadeloupe 2,467 1998
170 Malta 2,254 2000
171 Martinique 2,105 2000
172 Mauritius 1,926 2000
173 Hong Kong 1,831 1999 est.
174 Barbados 1,793 1999
175 Solomon Islands 1,360 1999 est.
176 Qatar 1,230 1999 est.
177 Saint Lucia 1,210 1999 est.
178 Cape Verde 1,100 1999 est.
179 United Arab Emirates 1,088 1999 est.
180 Vanuatu 1,070 1999 est.
181 Grenada 1,040 1999 est.
182 Saint Vincent and the Grenadines 1,040 1999 est.
183 Guam 885
184 Comoros 880 1999 est
185 Virgin Islands 856 2000
186 Aruba 800 1995
187 Man, Isle of 800 1999
188 Samoa 790 1999 est.
189 Cayman Islands 785 2000
190 Dominica 780 1999 est.
191 French Guiana 722 1996
192 Tonga 680 1999 est.
193 Kiribati 670 1999 est.
194 Netherlands Antilles 600
195 Jersey 577
196 Faroe Islands 463 1999
197 Bermuda 450 2002
198 Falkland Islands (Islas Malvinas) 440 2002
199 Seychelles 373 1997 est.
200 Northern Mariana Islands 362 1991
201 American Samoa 350
202 Cook Islands 320 2000
203 Sao Tome and Principe 320 1999 est.
204 Saint Kitts and Nevis 320 1999 est
205 Macau 271 2000
206 Andorra 269 1994
207 Antigua and Barbuda 250 1999 est.
208 Liechtenstein 250
209 Micronesia, Federated States of 240 1999 est.
210 Christmas Island 240 2000
211 Niue 234 2001
212 Montserrat 227 2003
213 San Marino 220 2001
214 Saint Helena 198 2000
215 British Virgin Islands 177 2000
216 Turks and Caicos Islands 121 2000
217 Wallis and Futuna 120
218 Saint Pierre and Miquelon 114
219 Anguilla 105 1997
220 Mayotte 93
221 Norfolk Island 80 2001
222 Palau 61
223 Monaco 50 1999 est.
224 Nauru 30 1999 est.
225 Gibraltar 29 2002
226 Cocos (Keeling) Islands 15 2003
227 Tuvalu 8 1999 est.
228 Pitcairn Islands 6
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2087
Rank Country Imports Date of Information
1 World $ 6,600,000,000,000 2002 est.
2 United States $ 1,165,000,000,000 2002 est.
3 Germany $ 487,300,000,000 2002 est.
4 United Kingdom $ 330,100,000,000 2002
5 France $ 303,700,000,000 2002 est.
6 China $ 295,300,000,000 2002 est.
7 Japan $ 292,100,000,000 2002 est.
8 Italy $ 238,200,000,000 2002 est.
9 Canada $ 229,000,000,000 2002 est.
10 Hong Kong $ 208,100,000,000 2002 est.
11 Netherlands $ 201,100,000,000 2001 est.
12 Mexico $ 168,400,000,000 2002
13 Spain $ 156,600,000,000 2002 est.
14 Belgium $ 152,000,000,000 2001
15 Korea, South $ 148,400,000,000 2002 est.
16 Singapore $ 113,000,000,000 2002 est.
17 Taiwan $ 113,000,000,000 2002
18 Switzerland $ 94,400,000,000 2002 est.
19 Malaysia $ 76,800,000,000 2002 est.
20 Austria $ 74,000,000,000 2001
21 Sweden $ 68,600,000,000 2002 est.
22 Australia $ 68,000,000,000 2002 est.
23 Russia $ 60,700,000,000 2002 est.
24 Thailand $ 58,100,000,000 2002 est.
25 India $ 53,800,000,000 2001
26 Turkey $ 50,800,000,000 2002 est.
27 Ireland $ 48,600,000,000 2002 est.
28 Denmark $ 47,900,000,000 2002 est.
29 Brazil $ 46,200,000,000 2002
30 Poland $ 43,400,000,000 2002
31 Czech Republic $ 43,200,000,000 2002
32 Saudi Arabia $ 39,500,000,000 2001
33 Portugal $ 39,000,000,000 2001
34 Norway $ 37,300,000,000 2002 est.
35 Hungary $ 33,900,000,000 2002 est.
36 Philippines $ 33,500,000,000 2002
37 Indonesia $ 32,100,000,000 2002 est.
38 Finland $ 31,800,000,000 2002 est.
39 Greece $ 31,400,000,000 2002
40 Israel $ 30,800,000,000 2002 est.
41 United Arab Emirates $ 30,800,000,000 2002 est.
42 Puerto Rico $ 29,100,000,000 2001
43 South Africa $ 26,600,000,000 2002 est.
44 Iran $ 21,800,000,000 2002 est.
45 Venezuela $ 18,800,000,000 2001
46 Ukraine $ 18,000,000,000 2002 est.
47 Vietnam $ 16,800,000,000 2002 est.
48 Romania $ 16,700,000,000 2002 est.
49 Chile $ 15,600,000,000 2002
50 Slovakia $ 15,400,000,000 2001 est.
51 Egypt $ 15,200,000,000 2002 est.
52 Nigeria $ 13,600,000,000 2002 est.
53 Luxembourg $ 13,250,000,000 2002
54 Colombia $ 12,500,000,000 2002 est.
55 New Zealand $ 12,500,000,000 2001 est.
56 Pakistan $ 11,100,000,000 FY02/03 est.
57 Slovenia $ 11,100,000,000 2002
58 Croatia $ 10,700,000,000 2002
59 Algeria $ 10,600,000,000 2002 est.
60 Morocco $ 10,400,000,000 2002 est.
61 Kazakhstan $ 9,600,000,000 2002 est.
62 Argentina $ 9,000,000,000 2002
63 Belarus $ 8,800,000,000 2002
64 Dominican Republic $ 8,700,000,000 2002 est.
65 Tunisia $ 8,700,000,000 2002
66 Bangladesh $ 8,500,000,000 2002
67 Iraq $ 7,800,000,000 2002 est.
68 Kuwait $ 7,300,000,000 2002 est.
69 Peru $ 7,300,000,000 2002 est.
70 Bulgaria $ 6,900,000,000 2002 est.
71 Lithuania $ 6,800,000,000 2002 est.
72 Panama $ 6,700,000,000 2002 est.
73 Costa Rica $ 6,400,000,000 2002
74 Libya $ 6,300,000,000 2002 est.
75 Serbia and Montenegro $ 6,300,000,000 2002
76 Ecuador $ 6,000,000,000 2002 est.
77 Lebanon $ 6,000,000,000 2002
78 Guatemala $ 5,600,000,000 2002 est.
79 Oman $ 5,500,000,000 2002 est.
80 Sri Lanka $ 5,400,000,000 2002
81 El Salvador $ 4,900,000,000 2002
82 Syria $ 4,900,000,000 2002 est.
83 Cuba $ 4,800,000,000 2001 est.
84 Estonia $ 4,400,000,000 2002
85 Jordan $ 4,400,000,000 2002 est.
86 Bahrain $ 4,200,000,000 2002
87 Angola $ 4,100,000,000 2002 est.
88 Cyprus $ 3,900,000,000 2002 est.
89 Latvia $ 3,900,000,000 2002
90 Qatar $ 3,900,000,000 2002 est.
91 Trinidad and Tobago $ 3,800,000,000 2002 est.
92 Jamaica $ 3,100,000,000 2002 est.
93 Kenya $ 3,000,000,000 2002 est.
94 Yemen $ 2,900,000,000 2002 est.
95 Bosnia and Herzegovina $ 2,800,000,000 2002 est.
96 Malta $ 2,800,000,000 2001
97 Ghana $ 2,800,000,000 2002 est.
98 Honduras $ 2,700,000,000 2002 est.
99 Macau $ 2,530,000,000 2002
100 Burma $ 2,500,000,000 2002
101 Uzbekistan $ 2,500,000,000 2002 est.
102 Reunion $ 2,500,000,000 1997
103 Cote d''Ivoire $ 2,500,000,000 2002 est.
104 Paraguay $ 2,400,000,000 2002 est.
105 Turkmenistan $ 2,250,000,000 2002 est.
106 Aruba $ 2,210,000,000 2002 est.
107 Iceland $ 2,100,000,000 2002
108 Martinique $ 2,000,000,000 1997
109 Botswana $ 1,900,000,000 2002 est.
110 Gaza Strip $ 1,900,000,000
111 West Bank $ 1,900,000,000
112 Macedonia, The Former Yugoslav Republic of $ 1,900,000,000 2002 est.
113 Uruguay $ 1,870,000,000 2002 est.
114 Bahamas, The $ 1,860,000,000 2002 est.
115 Azerbaijan $ 1,800,000,000 2002
116 Mauritius $ 1,800,000,000 2002 est.
117 Zimbabwe $ 1,739,000,000 2001 est.
118 Cambodia $ 1,730,000,000 2001 est.
119 Cameroon $ 1,700,000,000 2002 est.
120 Guadeloupe $ 1,700,000,000 1997
121 Nicaragua $ 1,700,000,000 2002 est.
122 Tanzania $ 1,670,000,000 2001
123 Ethiopia $ 1,630,000,000 2001
124 Bolivia $ 1,600,000,000 2002 est.
125 Nepal $ 1,600,000,000 2001 est.
126 Albania $ 1,500,000,000 2002 est.
127 Sudan $ 1,500,000,000 2002 est.
128 Senegal $ 1,460,000,000 2002 est.
129 Netherlands Antilles $ 1,430,000,000 2002
130 Brunei $ 1,400,000,000 2000 est.
131 Namibia $ 1,380,000,000 2002 est.
132 Korea, North $ 1,314,000,000 2001 est.
133 Afghanistan $ 1,300,000,000 2001 est.
134 French Polynesia $ 1,200,000,000 2000
135 Mozambique $ 1,180,000,000 2002 est.
136 Haiti $ 1,140,000,000 2002
137 Uganda $ 1,140,000,000 2002 est.
138 Zambia $ 1,123,000,000 2001
139 Gabon $ 1,100,000,000 2002 est.
140 Papua New Guinea $ 1,100,000,000 2002 est.
141 Andorra $ 1,077,000,000 1998
142 New Caledonia $ 1,000,000,000 2000
143 Armenia $ 991,000,000 2001 est.
144 Barbados $ 987,000,000 2002
145 Madagascar $ 985,000,000 2002
146 Moldova $ 980,000,000 2002 est.
147 Swaziland $ 938,000,000 2002
148 Liechtenstein $ 917,300,000 1996
149 Congo, Democratic Republic of the $ 890,000,000 2002 est.
150 Tajikistan $ 830,000,000 2002 est.
151 Georgia $ 750,000,000 2002 est.
152 Lesotho $ 738,000,000 2002 est.
153 Congo, Republic of the $ 730,000,000 2002 est.
154 Bermuda $ 719,000,000 2000
155 Guinea $ 670,000,000 2002 est.
156 Mongolia $ 659,000,000 2002 est.
157 Fiji $ 642,000,000 2001
158 Mali $ 630,000,000 2002 est.
159 French Guiana $ 625,000,000
160 Kyrgyzstan $ 587,000,000 2002 est.
161 Guyana $ 575,000,000 2002
162 Chad $ 570,000,000 2002 est.
163 Equatorial Guinea $ 562,000,000 2002 est.
164 Togo $ 561,000,000 2002
165 Laos $ 555,000,000 2002 est.
166 Burkina Faso $ 525,000,000 2002 est.
167 Malawi $ 505,000,000 2001
168 Eritrea $ 500,000,000 2001
169 Gibraltar $ 492,000,000 1997
170 Benin $ 479,000,000 2002
171 Faroe Islands $ 469,000,000 1999
172 Cayman Islands $ 457,400,000 1999
173 American Samoa $ 452,000,000 1999
174 Belize $ 430,000,000 2002 est.
175 Greenland $ 403,000,000 2001
176 Maldives $ 395,000,000 2001 est.
177 Seychelles $ 380,000,000 2002
178 Niger $ 368,000,000 2002 est.
179 Mauritania $ 360,000,000 2000
180 Antigua and Barbuda $ 357,000,000 2000 est.
181 Somalia $ 343,000,000 2001 est.
182 Saint Lucia $ 319,400,000 2000 est.
183 Cyprus $ 301,000,000 2002 est.
184 Suriname $ 300,000,000 2002
185 Grenada $ 270,000,000 2000 est.
186 Djibouti $ 255,000,000 2002 est.
187 Rwanda $ 253,000,000 2002 est.
188 East Timor $ 237,000,000 2001 est.
189 Gambia, The $ 225,000,000 2002 est.
190 Cape Verde $ 220,000,000 2002 est.
191 Guam $ 203,000,000 1999 est.
192 Bhutan $ 196,000,000 2000 est.
193 Sierra Leone $ 190,000,000 2002 est.
194 British Virgin Islands $ 187,000,000 2002 est.
195 Saint Vincent and the Grenadines $ 185,600,000 2000 est.
196 Turks and Caicos Islands $ 175,600,000 2000
197 Liberia $ 165,000,000 2002 est.
198 Saint Kitts and Nevis $ 152,000,000 2001 est.
199 Micronesia, Federated States of $ 149,000,000 FY 99/00 est.
200 Mayotte $ 141,300,000 1997
201 Burundi $ 135,000,000 2002 est.
202 Dominica $ 135,000,000 2002 est.
203 Samoa $ 130,100,000 2001
204 Central African Republic $ 102,000,000 2002 est.
205 Palau $ 99,000,000 2001 est.
206 Vanuatu $ 93,000,000 2001
207 Solomon Islands $ 82,000,000 2001 est.
208 Anguilla $ 80,900,000 1999
209 Tonga $ 70,000,000 2001 est.
210 Guinea-Bissau $ 59,000,000 2002 est.
211 Saint Pierre and Miquelon $ 55,000,000 1999
212 Marshall Islands $ 54,000,000 2000
213 Cook Islands $ 50,700,000 2000
214 Kiribati $ 44,000,000 1999
215 Comoros $ 39,800,000 2001 est.
216 Nauru $ 33,000,000 1995
217 Sao Tome and Principe $ 24,800,000 2002 est.
218 Falkland Islands (Islas Malvinas) $ 24,700,000 1995
219 Norfolk Island $ 17,900,000 FY 91/92
220 Montserrat $ 17,000,000 2001
221 Saint Helena $ 14,434,000 1995
222 Tuvalu $ 7,200,000 1998
223 Niue $ 2,380,000 1999
224 Tokelau $ 323,000 1983
225 Wallis and Futuna $ 300,000 1999
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2089
Rank Country Industrial production growth rate(%) Date of Information
1 Equatorial Guinea 30.00 2002 est.
2 Burundi 18.00 2001
3 Cambodia 16.00 2001 est.
4 Lesotho 15.50 1999
5 Armenia 15.00 2002 est.
6 Cote d''Ivoire 15.00 1998 est.
7 Burkina Faso 14.00 2001 est.
8 China 12.60 2002 est.
9 Tajikistan 10.30 2000 est.
10 Vietnam 10.20 2002 est.
11 Kazakhstan 10.00 2002 est.
12 Bhutan 9.30 1996 est.
13 Albania 9.00 2000 est.
14 Moldova 9.00 2002 est.
15 Nepal 8.70 FY 99/00
16 Tonga 8.60 FY 98/99
17 Sudan 8.50 1999 est.
18 Turkey 8.50 2002 est.
19 East Timor 8.50
20 Tanzania 8.40 1999 est.
21 Benin 8.30 2001 est.
22 Senegal 8.10 2002 est.
23 Faroe Islands 8.00 1999 est.
24 Mauritius 8.00 2000 est.
25 Laos 7.50 1999 est.
26 Guyana 7.10 1997 est.
27 Bosnia and Herzegovina 7.00 2002 est.
28 Greece 7.00 2000 est.
29 Rwanda 7.00 2001 est.
30 Ethiopia 6.70 2001 est.
31 Korea, South 6.50 2002 est.
32 Peru 6.50 2002 est.
33 Suriname 6','d31cae2755946a745b514232529aec9e58bc25a994e26495deef4d5a3b59ab76','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad810a17969774287470b1792bc371731de1177912442e237d52071bc4097644',2003,'YE','Yemen','communications',807,'.50 1994 est.
34 Uganda 6.30 2002 est.
35 Antigua and Barbuda 6.00 1997 est.
36 Algeria 6.00 2001 est.
37 Ukraine 6.00 2002 est.
38 Taiwan 6.00 2002
39 San Marino 6.00 1997 est.
40 Romania 6.00 2002
41 Lithuania 6.00 2002 est.
42 Kyrgyzstan 6.00 2000 est.
43 India 6.00 2002 est.
44 Ireland 6.00 2002 est.
45 Azerbaijan 6.00 2002 est.
46 Latvia 5.70 2002 est.
47 Iran 5.50 2001 est.
48 Ecuador 5.10 2001 est.
49 Zambia 5.10 2001 est.
50 Brunei 5.00 2002 est.
51 Chad 5.00 1995
52 Estonia 5.00 2000 est.
53 Malaysia 5.00 2002 est.
54 Finland 5.00 2002 est.
55 Indonesia 4.90 2002 est.
56 Mexico 4.90 2002 est.
57 Belize 4.60 1999
58 Belgium 4.50 2000 est.
59 Slovakia 4.40 2002 est.
60 Maldives 4.40 1996 est.
61 Nicaragua 4.40 2000 est.
62 Australia 4.30 2002 est.
63 Cameroon 4.20 1999 est.
64 Guatemala 4.10 1999
65 Mongolia 4.10 2002 est.
66 Colombia 4.00 2001 est.
67 Honduras 4.00 1999 est.
68 Philippines 4.00 2000 est.
69 Yemen 4.00 2002 est.
70 United Arab Emirates 4.00 2000
71 Oman 4.00 2000 est.
72 Bolivia 3.90 1998
73 Austria 3.80 2001 est.
74 Ghana 3.80 2000 est.
75 Russia 3.70 2002 est.
76 Swaziland 3.70 FY 95/96
77 Czech Republic 3.50 2002
78 Tunisia 3.50 2002 est.
79 Uzbekistan 3.50 2000 est.
80 Mozambique 3.40 2000
81 Guinea 3.20 1994
82 Man, Isle of 3.20 FY 96/97
83 Switzerland 3.20 2001
84 Anguilla 3.10 1997 est.
85 Hungary 3.10 2002 est.
86 Central African Republic 3.00 2002
87 World 3.00 2002 est.
88 Thailand 3.00 2000 est.
89 South Africa 3.00 2002 est.
90 Georgia 3.00 2000
91 Djibouti 3.00 1996 est.
92 El Salvador 3.00 2002 est.
93 New Zealand 3.00 2001 est.
94 Madagascar 3.00 2000 est.
95 Costa Rica 2.90 2002 est.
96 Croatia 2.80 2002 est.
97 Samoa 2.80 2000
98 Guinea-Bissau 2.60 1997 est.
99 Trinidad and Tobago 2.60 2002 est.
100 Belarus 2.50 2002 est.
101 Botswana 2.40 2001 est.
102 Pakistan 2.40 FY01/02 est.
103 Slovenia 2.40 2002
104 Brazil 2.30 2002 est.
105 Canada 2.20 2002 est.
106 Egypt 2.20 2002 est.
107 Bahrain 2.00 2000 est.
108 Bulgaria 2.00 2002 est.
109 Mauritania 2.00 2000 est.
110 Dominican Republic 2.00 2001 est.
111 Bangladesh 1.80 2002 est.
112 Serbia and Montenegro 1.70 2002 est.
113 Gabon 1.60 2002 est.
114 Portugal 1.50 2002 est.
115 Denmark 1.40 2002 est.
116 Norway 1.20 2002 est.
117 Spain 1.20 2002 est.
118 Sri Lanka 1.10 2002
119 Angola 1.00
120 Cook Islands 1.00 2002
121 Jordan 1.00 2002 est.
122 Argentina 1.00 2000 est.
123 Vanuatu 1.00 1997 est.
124 Turkmenistan 1.00 2002 est.
125 Saudi Arabia 1.00 1997 est.
126 Kenya 0.90 2002 est.
127 Sweden 0.90 2002 est.
128 Grenada 0.70 1997 est.
129 Kiribati 0.70 1991 est.
130 Morocco 0.50 1999 est.
131 Panama 0.50 2002 est.
132 Nigeria 0.40 2002 est.
133 Poland 0.30 2001
134 Cuba 0.20 2001 est.
135 Iceland 0.20 2002 est.
136 Congo, Republic of the 0.00 2002 est.
137 Paraguay 0.00 2000 est.
138 Netherlands 0.00 2002 est.
139 Luxembourg 0.00 2002 est.
140 Cyprus -0.30 2002
141 France -0.30 2002
142 United States -0.40 2002 est.
143 New Caledonia -0.60 1996
144 Malawi -0.80 2002 est.
145 Saint Vincent and the Grenadines -0.90 1997 est.
146 Cyprus -1.40 2002
147 Japan -1.40 2002 est.
148 Chile -1.50 2002 est.
149 Israel -1.50 2002 est.
150 Comoros -2.00 1999 est.
151 Jamaica -2.00 2000 est.
152 Germany -2.10 2002 est.
153 Italy -2.80 2002
154 Zimbabwe -3.10 2002 est.
155 Barbados -3.20 2000 est.
156 United Kingdom -3.40 2002 est.
157 Kuwait -5.00 2002 est.
158 Macedonia, The Former Yugoslav Republic of -5.00 2002 est.
159 Venezuela -5.40 2002 est.
160 Saint Lucia -8.90 1997 est.
161 Hong Kong -9.70 2002 est.
162 Singapore -9.80 2002 est.
163 Dominica -10.00 1997 est.
164 Uruguay -12.00 2002 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2091
Rank Country Infant mortality rate(deaths/1,000 live births) Date of Information
1 Mozambique 199.00 2003 est.
2 Angola 193.82 2003 est.
3 Sierra Leone 146.86 2003 est.
4 Afghanistan 142.48 2003 est.
5 Liberia 132.18 2003 est.
6 Niger 123.64 2003 est.
7 Somalia 120.34 2003 est.
8 Mali 119.20 2003 est.
9 Tajikistan 113.43 2003 est.
10 Guinea-Bissau 110.29 2003 est.
11 Djibouti 106.96 2003 est.
12 Malawi 105.15 2003 est.
13 Bhutan 104.68 2003 est.
14 Tanzania 103.68 2003 est.
15 Ethiopia 103.22 2003 est.
16 Rwanda 102.61 2003 est.
17 Burkina Faso 99.78 2003 est.
18 Zambia 99.29 2003 est.
19 Cote d''Ivoire 98.33 2003 est.
20 Congo, Democratic Republic of the 96.56 2003 est.
21 Chad 95.74 2003 est.
22 Congo, Republic of the 95.34 2003 est.
23 Central African Republic 93.30 2003 est.
24 Guinea 93.30 2003 est.
25 Equatorial Guinea 89.02 2003 est.
26 Laos 88.94 2003 est.
27 Uganda 87.90 2003 est.
28 Benin 86.76 2003 est.
29 Lesotho 86.21 2003 est.
30 Azerbaijan 82.41 2003 est.
31 Madagascar 80.21 2003 est.
32 Comoros 79.51 2003 est.
33 Pakistan 76.53 2003 est.
34 Eritrea 76.32 2003 est.
35 Haiti 76.01 2003 est.
36 Cambodia 75.94 2003 est.
37 Kyrgyzstan 75.34 2003 est.
38 Gambia, The 74.93 2003 est.
39 Mauritania 73.80 2003 est.
40 Turkmenistan 73.17 2003 est.
41 Burundi 71.54 2003 est.
42 Uzbekistan 71.51 2003 est.
43 Nigeria 71.35 2003 est.
44 Nepal 70.57 2003 est.
45 Burma 70.35 2003 est.
46 Cameroon 70.12 2003 est.
47 Togo 68.73 2003 est.
48 Namibia 68.44 2003 est.
49 Swaziland 67.44 2003 est.
50 Botswana 67.34 2003 est.
51 Zimbabwe 66.47 2003 est.
52 Bangladesh 66.08 2003 est.
53 Mayotte 65.98 2003 est.
54 Sudan 65.59 2003 est.
55 Yemen 65.02 2003 est.
56 Kenya 63.36 2003 est.
57 South Africa 60.84 2003 est.
58 Maldives 60.13 2003 est.
59 India 59.59 2003 est.
60 Kazakhstan 58.73 2003 est.
61 Vanuatu 58.11 2003 est.
62 Senegal 57.57 2003 est.
63 Mongolia 57.16 2003 est.
64 Bolivia 56.05 2003 est.
65 Iraq 55.16 2003 est.
66 Gabon 55.05 2003 est.
67 Papua New Guinea 54.84 2003 est.
68 Ghana 53.02 2003 est.
69 World 51.38 2003 est.
70 Kiribati 51.26 2003 est.
71 Georgia 51.24 2003 est.
72 Cape Verde 50.50 2003 est.
73 East Timor 50.47 2003 est.
74 Saudi Arabia 47.94 2003 est.
75 Sao Tome and Principe 46.04 2003 est.
76 Morocco 44.87 2003 est.
77 Turkey 44.20 2003 est.
78 Iran 44.17 2003 est.
79 Moldova 41.58 2003 est.
80 Armenia 40.86 2003 est.
81 Indonesia 38.09 2003 est.
82 Guatemala 37.92 2003 est.
83 Algeria 37.74 2003 est.
84 Guyana 37.55 2003 est.
85 Albania 37.28 2003 est.
86 Peru 36.97 2003 est.
87 Egypt 35.26 2003 est.
88 Dominican Republic 34.19 2003 est.
89 Micronesia, Federated States of 32.39
90 Ecuador 31.97 2003 est.
91 Brazil 31.74 2003 est.
92 Syria 31.67 2003 est.
93 Marshall Islands 31.58 2003 est.
94 Nicaragua 31.39 2003 est.
95 Vietnam 30.83 2003 est.
96 Honduras 29.96 2003 est.
97 Samoa 29.73 2003 est.
98 Paraguay 27.71 2003 est.
99 Belize 27.07 2003 est.
100 Tunisia 26.91 2003 est.
101 Libya 26.80 2003 est.
102 El Salvador 26.75 2003 est.
103 Lebanon 26.43 2003 est.
104 Bahamas, The 26.21 2003 est.
105 Korea, North 25.66 2003 est.
106 China 25.26 2003 est.
107 Philippines 24.98 2003 est.
108 Trinidad and Tobago 24.97 2003 est.
109 Suriname 24.74 2003 est.
110 Gaza Strip 24.15 2003 est.
111 Venezuela 23.79 2003 est.
112 Mexico 23.68 2003 est.
113 Solomon Islands 22.88 2003 est.
114 Anguilla 22.80 2003 est.
115 Bosnia and Herzegovina 22.70 2003 est.
116 Colombia 22.47 2003 est.
117 Thailand 21.83 2003 est.
118 Panama 21.44 2003 est.
119 Tuvalu 21.34 2003 est.
120 Oman 21.01 2003 est.
121 Antigua and Barbuda 20.90 2003 est.
122 Ukraine 20.87 2003 est.
123 Saint Helena 20.70 2003 est.
124 West Bank 20.68 2003 est.
125 Qatar 20.03 2003 est.
126 Russia 19.51 2003 est.
127 Malaysia 19.00 2003 est.
128 Jordan 18.86 2003 est.
129 British Virgin Islands 18.80 2003 est.
130 Bahrain 18.59 2003 est.
131 Romania 18.40 2003 est.
132 Serbia and Montenegro 16.90 2003 est.
133 Turks and Caicos Islands 16.87 2003 est.
134 Greenland 16.80 2003 est.
135 Seychelles 16.41 2003 est.
136 Argentina 16.16 2003 est.
137 Mauritius 16.11 2003 est.
138 Palau 15.76 2003 est.
139 Saint Vincent and the Grenadines 15.70 2003 est.
140 United Arab Emirates 15.58 2003 est.
141 Saint Kitts and Nevis 15.39 2003 est.
142 Dominica 15.34 2003 est.
143 Sri Lanka 15.22 2003 est.
144 Grenada 14.63 2003 est.
145 Latvia 14.59 2003 est.
146 Saint Lucia 14.37 2003 est.
147 Lithuania 14.17 2003 est.
148 Belarus 13.87 2003 est.
149 Uruguay 13.80 2003 est.
150 Bulgaria 13.70 2003 est.
151 Brunei 13.50 2003 est.
152 Fiji 13.35 2003 est.
153 Tonga 13.35 2003 est.
154 Jamaica 13.26 2003 est.
155 French Guiana 12.84 2003 est.
156 Barbados 12.72 2003 est.
157 Macedonia, The Former Yugoslav Republic of 12.14 2003 est.
158 Estonia 12.03 2003 est.
159 Netherlands Antilles 10.71 2003 est.
160 Kuwait 10.57 2003 est.
161 Costa Rica 10.56 2003 est.
162 Nauru 10.33 2003 est.
163 American Samoa 9.82 2003 est.
164 Puerto Rico 9.38 2003 est.
165 Guadeloupe 9.07 2003 est.
166 Bermuda 9.05 2003 est.
167 Virgin Islands 9.00 2003 est.
168 Poland 8.95 2003 est.
169 Chile 8.88 2003 est.
170 French Polynesia 8.78 2003 est.
171 Cayman Islands 8.64 2003 est.
172 Hungary 8.58 2003 est.
173 Slovakia 8.55 2003 est.
174 Reunion 8.13 2003 est.
175 New Caledonia 8.06 2003 est.
176 Saint Pierre and Miquelon 7.97 2003 est.
177 Montserrat 7.77 2003 est.
178 Cyprus 7.54 2003 est.
179 Martinique 7.44 2003 est.
180 Israel 7.37 2003 est.
181 Korea, South 7.31 2003 est.
182 Cuba 7.15 2003 est.
183 Croatia 6.92 2003 est.
184 United States 6.75 2003 est.
185 Taiwan 6.65 2003 est.
186 Faroe Islands 6.52 2003 est.
187 Guam 6.46 2003 est.
188 Italy 6.19 2003 est.
189 Man, Isle of 6.17 2003 est.
190 Aruba 6.14 2003 est.
191 Greece 6.12 2003 est.
192 New Zealand 6.07 2003 est.
193 San Marino 5.97 2003 est.
194 Portugal 5.73 2003 est.
195 Hong Kong 5.63 2003 est.
196 Monaco 5.63 2003 est.
197 Malta 5.62 2003 est.
198 Northern Mariana Islands 5.52 2003 est.
199 Jersey 5.43 2003 est.
200 Czech Republic 5.37 2003 est.
201 Ireland 5.34 2003 est.
202 Gibraltar 5.31 2003 est.
203 United Kingdom 5.28 2003 est.
204 Denmark 4.90 2003 est.
205 Canada 4.88 2003 est.
206 Guernsey 4.85 2003 est.
207 Liechtenstein 4.85 2003 est.
208 Australia 4.83 2003 est.
209 Luxembourg 4.65 2003 est.
210 Belgium 4.57 2003 est.
211 Spain 4.54 2003 est.
212 Macau 4.42 2003 est.
213 Slovenia 4.42 2003 est.
214 France 4.37 2003 est.
215 Switzerland 4.36 2003 est.
216 Austria 4.33 2003 est.
217 Netherlands 4.26 2003 est.
218 Germany 4.23 2003 est.
219 Andorra 4.06 2003 est.
220 Norway 3.87 2003 est.
221 Finland 3.73 2003 est.
222 Singapore 3.57 2003 est.
223 Iceland 3.50 2003 est.
224 Sweden 3.42 2003 est.
225 Japan 3.30 2003 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2092
Rank Country Inflation rate (consumer prices)(%) Date of Information
1 Zimbabwe 134.50 2002 est.
2 Angola 106.00 2002 est.
3 Iraq 70.00 2002 est.
4 Burma 53.70 2002 est.
5 Turkey 45.20 2002 est.
6 Belarus 42.80 2002 est.
7 Argentina 41.00 2002, yearend
8 Venezuela 31.20 2002 est.
9 Malawi 27.40 2001 est.
10 Uzbekistan 26.00 2001 est.
11 Cyprus 24.50 2002 est.
12 Romania 22.50 2002 est.
13 Zambia 21.00 2002 est.
14 Serbia and Montenegro 19.00 2002 est.
15 Suriname 17.00 2002 est.
16 Congo, Democratic Republic of the 16.00 2002 est.
17 Iran 15.30 2002 est.
18 Mozambique 15.20 2002 est.
19 Eritrea 15.00 2001
20 Russia 15.00 2002 est.
21 Liberia 15.00 2002 est.
22 Ghana 14.50 2002 est.
23 Nigeria 14.20 2002 est.
24 Uruguay 14.10 2002 est.
25 Ecuador 12.50 2002 est.
26 Yemen 12.20 2002 est.
27 Burundi 12.00 2002 est.
28 Tajikistan 12.00 2001 est.
29 Haiti 11.90 2001 est.
30 Indonesia 11.90 2002 est.
31 Swaziland 11.80 2002 est.
32 Paraguay 10.50 2002 est.
33 Laos 10.00 2002 est.
34 Lesotho 10.00 2002 est.
35 South Africa 9.90 2002 est.
36 Papua New Guinea 9.80 2002 est.
37 Sri Lanka 9.60 2002 est.
38 Sudan 9.20 2002 est.
39 Costa Rica 9.10 2002 est.
40 Sao Tome and Principe 9.00 2002 est.
41 Tonga 8.40 2001 est.
42 Brazil 8.30 2002
43 Botswana 8.10 2002 est.
44 Guatemala 8.10 2002 est.
45 Namibia 8.00 2001
46 Honduras 7.70 2002 est.
47 Madagascar 7.40 2001 est.
48 Slovenia 7.40 2002 est.
49 Cuba 7.10 2002 est.
50 Jamaica 7.00 2002 est.
51 Mauritius 6.40 2002 est.
52 Mexico 6.40 2002 est.
53 Colombia 6.20 2002 est.
54 Albania 6.00 2002 est.
55 Chad 6.00 2002 est.
56 Equatorial Guinea 6.00 2002 est.
57 Guinea 6.00 2002 est.
58 Kazakhstan 6.00 2002 est.
59 Bulgaria 5.90 2002 est.
60 Israel 5.70 2002 est.
61 Gambia, The 5.50 2002 est.
62 Rwanda 5.50 2002 est.
63 Moldova 5.50 2002 est.
64 India 5.40 2002 est.
65 Dominican Republic 5.30 2002 est.
66 Hungary 5.30 2002 est.
67 Georgia 5.20 2002 est.
68 Iceland 5.20 2002 est.
69 Faroe Islands 5.10 1999
70 Puerto Rico 5.00 2002 est.
71 Tuvalu 5.00 2000 est.
72 Turkmenistan 5.00 2002 est.
73 Tanzania 4.80 2002 est.
74 Guyana 4.70 2002 est.
75 Jersey 4.70 1998
76 Ireland 4.60 2002 est.
77 Cameroon 4.50 2002 est.
78 Mali 4.50 2002 est.
79 Andorra 4.30 2000
80 Trinidad and Tobago 4.30 2002 est.
81 Egypt 4.30 2002 est.
82 Congo, Republic of the 4.00 2002 est.
83 Togo 4.00 2002 est.
84 Samoa 4.00 2001 est.
85 Turks and Caicos Islands 4.00 1995
86 Ethiopia 4.00 2003 est.
87 Guinea-Bissau 4.00 2002 est.
88 Guernsey 3.99 2000 est.
89 Martinique 3.90 1990
90 Pakistan 3.90 2002 est.
91 Vietnam 3.90 2002 est.
92 El Salvador 3.80 2001 est.
93 Estonia 3.70 2002 est.
94 Portugal 3.70 2002 est.
95 Nicaragua 3.70 2002 est.
96 Central African Republic 3.60 2001 est.
97 Man, Isle of 3.60 March 2003 est.
98 Morocco 3.60 2002 est.
99 Greece 3.60 2002 est.
100 Falkland Islands (Islas Malvinas) 3.60 1998
101 Bosnia and Herzegovina 3.50 2002 est.
102 Comoros 3.50 2001 est.
103 Burkina Faso 3.50 2001 est.
104 Lebanon 3.50 2002 est.
105 Netherlands 3.40 2002 est.
106 Palau 3.40 2000 est.
107 Benin 3.30 2002 est.
108 Cambodia 3.30 2002 est.
109 Jordan 3.30 2002 est.
110 San Marino 3.30 2001
111 Slovakia 3.30 2002 est.
112 Aruba 3.20 2002 est.
113 Cook Islands 3.20 2000 est.
114 Saint Helena 3.20 1997 est.
115 Vanuatu 3.20 2001 est.
116 Cote d''Ivoire 3.20 2002 est.
117 Bangladesh 3.10 2002 est.
118 Philippines 3.10 2002 est.
119 Algeria 3.00 2002 est.
120 Bhutan 3.00 2002 est.
121 Cape Verde 3.00 2002
122 Hong Kong 3.00 2002 est.
123 Mauritania 3.00 2002 est.
124 Saint Lucia 3.00 2001 est.
125 Spain 3.00 2002 est.
126 Senegal 3.00 2002 est.
127 Niger 3.00 2002 est.
128 Mongolia 3.00 2002 est.
129 Australia 2.80 2002 est.
130 United Arab Emirates 2.80 2002 est.
131 Cyprus 2.80 2002 est.
132 Nepal 2.80 2001 est.
133 Korea, South 2.80 2002 est.
134 Grenada 2.80 2001 est.
135 Cayman Islands 2.80 2002
136 New Zealand 2.70 2002 est.
137 Azerbaijan 2.60 2002 est.
138 Montserrat 2.60 2002 est.
139 Chile 2.50 2002 est.
140 Kiribati 2.50 2001 est.
141 British Virgin Islands 2.50 2002
142 Tunisia 2.50 2002 est.
143 Italy 2.40 2002 est.
144 Malta 2.40 2002 est.
145 Anguilla 2.30
146 Denmark 2.30 2002 est.
147 Gabon 2.30 2002 est.
148 Bermuda 2.30 July 2002
149 Canada 2.20 2002 est.
150 Gaza Strip 2.20 2001 est.
151 Croatia 2.20 2002 est.
152 West Bank 2.20 2001 est.
153 Sweden 2.20 2002 est.
154 Kyrgyzstan 2.10 2002 est.
155 United Kingdom 2.10 2002 est.
156 Saint Pierre and Miquelon 2.10 1991-96 average
157 Bolivia 2.00 2001 est.
158 Virgin Islands 2.00 1992
159 Kuwait 2.00 2002 est.
160 Marshall Islands 2.00 2001 est.
161 Fiji 2.00 2002 est.
162 Djibouti 2.00 2002 est.
163 Latvia 2.00 2002 est.
164 Belize 1.90 2002 est.
165 Qatar 1.90 2002
166 Kenya 1.90 2002 est.
167 Finland 1.90 2002 est.
168 Malaysia 1.90 2002 est.
169 Poland 1.90 2002 est.
170 Austria 1.80 2002 est.
171 Bahamas, The 1.80 2001 est.
172 Solomon Islands 1.80 2001 est.
173 France 1.80 2002 est.
174 Belgium 1.70 2002 est.
175 Saint Kitts and Nevis 1.70 2001 est.
176 Greenland 1.60 1999 est.
177 Luxembourg 1.60 2002 est.
178 United States 1.60 2002
179 French Guiana 1.50 2002 est.
180 Gibraltar 1.50 1998
181 French Polynesia 1.50
182 Germany 1.30 2002 est.
183 Norway 1.30 2001 est.
184 Northern Mariana Islands 1.20 1997 est.
185 Armenia 1.10 2002 est.
186 Macedonia, The Former Yugoslav Republic of 1.10 2002 est.
187 Panama 1.10 2001 est.
188 Dominica 1.00 2001 est.
189 Sierra Leone 1.00 2002 est.
190 Saudi Arabia 1.00 2002 est.
191 Niue 1.00 1995
192 Maldives 1.00 2002 est.
193 Libya 1.00 2001 est.
194 Liechtenstein 1.00 2001
195 Micronesia, Federated States of 1.00 2002 est.
196 Syria 0.90 2002 est.
197 Lithuania 0.80 2002 est.
198 Czech Republic 0.60 2002 est.
199 Thailand 0.60 2002 est.
200 Bahrain 0.50 2002 est.
201 Seychelles 0.50 2002 est.
202 Switzerland 0.50 2002 est.
203 Antigua and Barbuda 0.40 2000 est.
204 Netherlands Antilles 0.40 2002 est.
205 Peru 0.20 2002 est.
206 Uganda 0.10 2002 est.
207 Guam 0.00 1999 est.
208 Taiwan -0.20 2002 est.
209 Singapore -0.40 2002 est.
210 Saint Vincent and the Grenadines -0.40 2001 est.
211 Oman -0.50 2002 est.
212 Barbados -0.60 2002 est.
213 New Caledonia -0.60 2000 est.
214 China -0.80 2002 est.
215 Japan -0.90 2002 est.
216 Ukraine -1.20 2002 est.
217 Brunei -2.00 2002 est.
218 Macau -2.60 2002 est.
219 Nauru -3.60 1993
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2095
Rank Country Labor force Date of Information
1 China 744,000,000 2001 est.
2 India 406,000,000 1999
3 United States 141,800,000 2001
4 Indonesia 99,000,000 1999
5 Brazil 79,000,000 1999 est.
6 Russia 71,800,000 2002 est.
7 Japan 67,700,000 December 2001
8 Nigeria 66,000,000 1999 est.
9 Bangladesh 64,100,000 1998
10 Germany 41,900,000 2001
11 Pakistan 40,400,000 2000
12 Mexico 39,800,000 2000
13 Vietnam 38,200,000 1998 est.
14 Philippines 33,700,000 2002
15 Thailand 33,400,000 2001 est.
16 United Kingdom 29,700,000 2001
17 France 26,600,000 2001 est.
18 Turkey 23,800,000 2001 3rd quarter
19 Burma 23,700,000 1999 est.
20 Italy 23,600,000 2001 est.
21 Ukraine 22,800,000 yearend 1997
22 Korea, South 22,000,000 2001
23 Iran 21,000,000 1998
24 Egypt 20,600,000 2001 est.
25 Colombia 18,300,000 1999 est.
26 Poland 17,600,000 2000 est.
27 Spain 17,100,000 2001
28 South Africa 17,000,000
29 Canada 16,400,000 2001 est.
30 Argentina 15,000,000 1999
31 Congo, Democratic Republic of the 14,510,000 1993 est.
32 Tanzania 13,495,000
33 Uganda 12,000,000 2001 est.
34 Uzbekistan 11,900,000 1998 est.
35 Morocco 11,000,000 1999
36 Sudan 11,000,000 1996 est.
37 Afghanistan 10,000,000 2000 est.
38 Taiwan 10,000,000 2003
39 Nepal 10,000,000 1996 est.
40 Kenya 10,000,000 2001 est.
41 Malaysia 9,900,000 2001 est.
42 Romania 9,900,000 1999 est.
43 Venezuela 9,900,000 1999
44 Korea, North 9,600,000
45 Algeria 9,400,000 2001 est.
46 Australia 9,200,000 37256
47 Mozambique 9,200,000 2000 est.
48 Ghana 9,000,000 2000 est.
49 Kazakhstan 8,400,000 1999
50 Peru 7,500,000 2000 est.
51 Madagascar 7,300,000 2000
52 Netherlands 7,200,000 2000
53 Saudi Arabia 7,000,000
54 Sri Lanka 6,600,000 1998
55 Iraq 6,500,000 2002 est.
56 Cambodia 6,000,000 1998 est.
57 Chile 5,900,000 2000 est.
58 Zimbabwe 5,800,000 2000 est.
59 Czech Republic 5,203,000 1999 est.
60 Syria 5,200,000 2000 est.
61 Portugal 5,100,000 2000
62 Angola 5,000,000 1997 est.
63 Burkina Faso 5,000,000 2002
64 Belarus 4,800,000 2000
65 Rwanda 4,600,000 2000
66 Malawi 4,500,000 2001 est.
67 Belgium 4,440,000 2001
68 Sweden 4,400,000 2000 est.
69 Greece 4,370,000 2002 est.
70 Austria 4,300,000 2001
71 Cuba 4,300,000 2000 est.
72 Zambia 4,290,000 2000
73 Guatemala 4,200,000 1999 est.
74 Hungary 4,200,000 1997
75 Switzerland 4,000,000 2001
76 Mali 3,930,000 2001 est.
77 Bulgaria 3,830,000 2000 est.
78 Azerbaijan 3,700,000 2001
79 Ecuador 3,700,000
80 Somalia 3,700,000
81 Burundi 3,700,000 2000
82 Haiti 3,600,000 1995
83 Hong Kong 3,520,000 2001 est.
84 Tajikistan 3,187,000 2000
85 Guinea 3,000,000 1999
86 Serbia and Montenegro 3,000,000 2001 est.
87 Slovakia 3,000,000 1999
88 Denmark 2,856,000 2000 est.
89 Kyrgyzstan 2,700,000 2000
90 Tunisia 2,690,000 2001 est.
91 Finland 2,600,000 2000 est.
92 Bolivia 2,500,000
93 Israel 2,500,000 2002 est.
94 Laos 2,400,000 1999
95 Norway 2,400,000 2000 est.
96 El Salvador 2,350,000 1999
97 Turkmenistan 2,340,000 1996
98 Honduras 2,300,000 1997 est.
99 Papua New Guinea 2,300,000 1999
100 Singapore 2,190,000 2000
101 Georgia 2,100,000 2001 est.
102 Paraguay 2,000,000 2000 est.
103 New Zealand 1,920,000 2001 est.
104 Costa Rica 1,900,000 1999
105 Ireland 1,800,000 2001
106 Togo 1,740,000 1996
107 Croatia 1,700,000 2001
108 Nicaragua 1,700,000 1999
109 Moldova 1,700,000 1998
110 United Arab Emirates 1,600,000 2000 est.
111 Lebanon 1,500,000 2001 est.
112 Libya 1,500,000 2000 est.
113 Lithuania 1,500,000 2001 est.
114 Armenia 1,400,000 2001
115 Mongolia 1,400,000 2001
116 Sierra Leone 1,369,000 1981 est.
117 Jordan 1,360,000 2002
118 Kuwait 1,300,000 1998 est.
119 Puerto Rico 1,300,000 2000
120 Albania 1,283,000 2000 est.
121 Uruguay 1,200,000 2001
122 Jamaica 1,130,000 1998
123 Latvia 1,100,000 2001 est.
124 Macedonia, The Former Yugoslav Republic of 1,100,000 2000 est.
125 Panama 1,100,000 2000 est.
126 Bosnia and Herzegovina 1,026,000
127 Oman 920,000 2002 est.
128 Slovenia 857,400
129 Lesotho 838,000
130 Mauritania 786,000 2001
131 Namibia 725,000 2000
132 Estonia 608,600 2001 est.
133 Gabon 600,000
134 Trinidad and Tobago 564,000 2000
135 Mauritius 514,000 1995
136 Guinea-Bissau 480,000
137 Guyana 418,000 2001 est.
138 Gambia, The 400,000
139 Swaziland 383,200 2000
140 Reunion 309,900 2000
141 Bahrain 295,000 1998 est.
142 Djibouti 282,000
143 Qatar 280,122 1997 est.
144 Botswana 264,000 2000
145 Luxembourg 262,300 2000
146 Macau 214,000 2002
147 Martinique 165,900 1998
148 Malta 160,000 2002 est.
149 Iceland 159,000 2000
150 Bahamas, The 156,000 1999
151 Comoros 144,500 1996 est.
152 Brunei 143,400 1999 est.
153 Fiji 137,000 1999
154 Barbados 128,500 2001 est.
155 Guadeloupe 125,900 1997
156 Suriname 100,000
157 Belize 90,000
158 Samoa 90,000 2000 est.
159 Netherlands Antilles 89,000
160 Maldives 88,000 2000
161 New Caledonia 79,395
162 French Polynesia 70,000 1996
163 Niger 70,000
164 Saint Vincent and the Grenadines 67,000 1984 est.
165 Guam 60,000 2000 est.
166 French Guiana 58,800 1997
167 Jersey 57,050 1996
168 Virgin Islands 49,000 2002 est.
169 Mayotte 48,800 2000
170 Saint Lucia 43,800
171 Grenada 42,300 1996
172 Aruba 41,501 1997 est.
173 Bermuda 37,472 2000
174 Man, Isle of 36,610 1998
175 Tonga 33,908 1996
176 Andorra 33,000 2001 est.
177 Guernsey 31,322 2000
178 Seychelles 30,900 1996
179 Monaco 30,540 January 1994
180 Antigua and Barbuda 30,000
181 Liechtenstein 29,000 37256
182 Marshall Islands 28,698
183 Solomon Islands 26,842
184 Dominica 25,000
185 Greenland 24,500 1999 est.
186 Faroe Islands 24,250 October 2000
187 Cayman Islands 19,820 1995
188 San Marino 18,500 1999
189 Saint Kitts and Nevis 18,172 June 1995
190 Gibraltar 14,800
191 American Samoa 14,000 1996
192 Western Sahara 12,000
193 Palau 9,845 2000
194 Cook Islands 8,000 1996
195 Kiribati 7,870
196 Tuvalu 7,000 2001 est.
197 Anguilla 6,049 2001
198 Northern Mariana Islands 6,006
199 British Virgin Islands 4,911 1980
200 Turks and Caicos Islands 4,848 1990 est.
201 Montserrat 4,521
202 Saint Helena 3,500 1998 est.
203 Saint Pierre and Miquelon 3,261 1999
204 Falkland Islands (Islas Malvinas) 1,100
205 Pitcairn Islands 12 1997
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2102
Rank Country Life expectancy at birth(years) Date of Information
1 Andorra 83.49 2003 est.
2 Macau 81.87 2003 est.
3 San Marino 81.43 2003 est.
4 Japan 80.93 2003 est.
5 Singapore 80.42 2003 est.
6 Australia 80.13 2003 est.
7 Guernsey 80.04 2003 est.
8 Switzerland 79.99 2003 est.
9 Sweden 79.97 2003 est.
10 Hong Kong 79.93 2003 est.
11 Canada 79.83 2003 est.
12 Iceland 79.80 2003 est.
13 Cayman Islands 79.67 2003 est.
14 Italy 79.40 2003 est.
15 Gibraltar 79.38 2003 est.
16 France 79.28 2003 est.
17 Monaco 79.27 2003 est.
18 Liechtenstein 79.25 2003 est.
19 Spain 79.23 2003 est.
20 Norway 79.09 2003 est.
21 Israel 79.02 2003 est.
22 Jersey 78','39818f10594696cbb328da2e2c099978108fa8a60e3d7deb0e37dc2048f0664c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc0bb049b287fdf47c7eda3a973b84164bb31ec7d2f88d6d02e5abd154dd645c',2003,'YE','Yemen','communications',808,'.93 2003 est.
23 Faroe Islands 78.90 2003 est.
24 Greece 78.89 2003 est.
25 Aruba 78.83 2003 est.
26 Netherlands 78.74 2003 est.
27 Martinique 78.72 2003 est.
28 Virgin Islands 78.59 2003 est.
29 Malta 78.43 2003 est.
30 Germany 78.42 2003 est.
31 Montserrat 78.36 2003 est.
32 New Zealand 78.32 2003 est.
33 Belgium 78.29 2003 est.
34 Guam 78.27 2003 est.
35 Austria 78.17 2003 est.
36 United Kingdom 78.16 2003 est.
37 Saint Pierre and Miquelon 78.11 2003 est.
38 Man, Isle of 77.98 2003 est.
39 Finland 77.92 2003 est.
40 Jordan 77.88 2003 est.
41 Luxembourg 77.66 2003 est.
42 Guadeloupe 77.53 2003 est.
43 Bermuda 77.41 2003 est.
44 Saint Helena 77.38 2003 est.
45 Ireland 77.35 2003 est.
46 Cyprus 77.27 2003 est.
47 Puerto Rico 77.26 2003 est.
48 United States 77.14 2003 est.
49 Denmark 77.10 2003 est.
50 Taiwan 76.87 2003 est.
51 Cuba 76.80 2003 est.
52 Anguilla 76.70 2003 est.
53 French Guiana 76.69 2003 est.
54 Kuwait 76.65 2003 est.
55 Costa Rica 76.43 2003 est.
56 Chile 76.35 2003 est.
57 Portugal 76.35 2003 est.
58 Northern Mariana Islands 76.16 2003 est.
59 Libya 76.07 2003 est.
60 British Virgin Islands 76.06 2003 est.
61 Uruguay 75.87 2003 est.
62 Jamaica 75.85 2003 est.
63 American Samoa 75.75 2003 est.
64 Slovenia 75.51 2003 est.
65 Argentina 75.48 2003 est.
66 French Polynesia 75.45 2003 est.
67 Netherlands Antilles 75.38 2003 est.
68 Korea, South 75.36 2003 est.
69 Czech Republic 75.18 2003 est.
70 United Arab Emirates 74.75 2003 est.
71 Macedonia, The Former Yugoslav Republic of 74.49 2003 est.
72 Slovakia 74.43 2003 est.
73 Paraguay 74.40 2003 est.
74 Tunisia 74.40 2003 est.
75 Croatia 74.37 2003 est.
76 Brunei 74.30 2003 est.
77 Dominica 74.12 2003 est.
78 Turks and Caicos Islands 74.00 2003 est.
79 Serbia and Montenegro 73.97 2003 est.
80 Poland 73.91 2003 est.
81 Venezuela 73.81 2003 est.
82 Bahrain 73.72 2003 est.
83 New Caledonia 73.52 2003 est.
84 Reunion 73.43 2003 est.
85 Qatar 73.14 2003 est.
86 Saint Lucia 73.08 2003 est.
87 Saint Vincent and the Grenadines 73.08 2003 est.
88 West Bank 72.68 2003 est.
89 Sri Lanka 72.62 2003 est.
90 Oman 72.58 2003 est.
91 Albania 72.37 2003 est.
92 Panama 72.32 2003 est.
93 Mexico 72.30 2003 est.
94 Bosnia and Herzegovina 72.29 2003 est.
95 China 72.22 2003 est.
96 Hungary 72.17 2003 est.
97 Solomon Islands 72.10 2003 est.
98 Lebanon 72.07 2003 est.
99 Ecuador 71.89 2003 est.
100 Barbados 71.84 2003 est.
101 Bulgaria 71.80 2003 est.
102 Turkey 71.80 2003 est.
103 Mauritius 71.80 2003 est.
104 Malaysia 71.67 2003 est.
105 Saint Kitts and Nevis 71.57 2003 est.
106 Gaza Strip 71.40 2003 est.
107 Antigua and Barbuda 71.31 2003 est.
108 Seychelles 71.25 2003 est.
109 Thailand 71.24 2003 est.
110 Colombia 71.14 2003 est.
111 Brazil 71.13 2003 est.
112 Peru 70.88 2003 est.
113 Korea, North 70.79 2003 est.
114 El Salvador 70.62 2003 est.
115 Romania 70.62 2003 est.
116 Algeria 70.54 2003 est.
117 Egypt 70.41 2003 est.
118 Estonia 70.31 2003 est.
119 Samoa 70.11 2003 est.
120 Vietnam 70.05 2003 est.
121 Morocco 70.04 2003 est.
122 Cape Verde 69.83 2003 est.
123 Nicaragua 69.68 2003 est.
124 Lithuania 69.60 2003 est.
125 Trinidad and Tobago 69.59 2003 est.
126 Palau 69.50 2003 est.
127 Marshall Islands 69.39 2003 est.
128 Syria 69.39 2003 est.
129 Iran 69.35 2003 est.
130 Latvia 69.31 2003 est.
131 Philippines 69.29 2003 est.
132 Suriname 69.23 2003 est.
133 Micronesia, Federated States of 69.13 2003 est.
134 Greenland 69.00 2003 est.
135 Indonesia 68.94 2003 est.
136 Fiji 68.88 2003 est.
137 Tonga 68.88 2003 est.
138 Saudi Arabia 68.73 2003 est.
139 Belarus 68.43 2003 est.
140 Dominican Republic 67.96 2003 est.
141 Iraq 67.81 2003 est.
142 Russia 67.66 2003 est.
143 Belize 67.36 2003 est.
144 Tuvalu 67.32 2003 est.
145 Armenia 66.68 2003 est.
146 Honduras 66.65 2003 est.
147 Ukraine 66.50 2003 est.
148 Sao Tome and Principe 66.28 2003 est.
149 Bahamas, The 65.71 2003 est.
150 Guatemala 65.23 2003 est.
151 East Timor 65.20 2003 est.
152 Moldova 64.88 2003 est.
153 Bolivia 64.78 2003 est.
154 Georgia 64.76 2003 est.
155 Grenada 64.52 2003 est.
156 Tajikistan 64.37 2003 est.
157 Papua New Guinea 64.19 2003 est.
158 Uzbekistan 64.00 2003 est.
159 World 63.95 2003 est.
160 Mongolia 63.81 2003 est.
161 Kyrgyzstan 63.66 2003 est.
162 India 63.62 2003 est.
163 Kazakhstan 63.48 2003 est.
164 Maldives 63.30 2003 est.
165 Azerbaijan 63.16 2003 est.
166 Guyana 63.09 2003 est.
167 Pakistan 62.20 2003 est.
168 Nauru 61.95 2003 est.
169 Vanuatu 61.71 2003 est.
170 Bangladesh 61.33 2003 est.
171 Turkmenistan 61.19 2003 est.
172 Comoros 61.18 2003 est.
173 Yemen 60.97 2003 est.
174 Kiribati 60.93 2003 est.
175 Mayotte 60.60 2003 est.
176 Nepal 59.00 2003 est.
177 Cambodia 57.92 2003 est.
178 Sudan 57.73 2003 est.
179 Gabon 57.12 2003 est.
180 Ghana 56.53 2003 est.
181 Senegal 56.37 2003 est.
182 Madagascar 56.14 2003 est.
183 Burma 55.79 2003 est.
184 Equatorial Guinea 54.75 2003 est.
185 Gambia, The 54.38 2003 est.
186 Laos 54.30 2003 est.
187 Bhutan 53.58 2003 est.
188 Togo 53.43 2003 est.
189 Eritrea 53.18 2003 est.
190 Mauritania 51.93 2003 est.
191 Haiti 51.61 2003 est.
192 Benin 51.08 2003 est.
193 Nigeria 51.01 2003 est.
194 Congo, Republic of the 50.02 2003 est.
195 Guinea 49.54 2003 est.
196 Congo, Democratic Republic of the 48.93 2003 est.
197 Chad 48.51 2003 est.
198 Liberia 48.15 2003 est.
199 Cameroon 48.05 2003 est.
200 Somalia 47.34 2003 est.
201 Afghanistan 46.97 2003 est.
202 Guinea-Bissau 46.97 2003 est.
203 South Africa 46.56 2003 est.
204 Mali 45.43 2003 est.
205 Kenya 45.22 2003 est.
206 Uganda 44.88 2003 est.
207 Tanzania 44.56 2003 est.
208 Burkina Faso 44.46 2003 est.
209 Burundi 43.20 2003 est.
210 Djibouti 43.13 2003 est.
211 Sierra Leone 42.84 2003 est.
212 Namibia 42.77 2003 est.
213 Cote d''Ivoire 42.65 2003 est.
214 Niger 42.21 2003 est.
215 Central African Republic 41.71 2003 est.
216 Ethiopia 41.24 2003 est.
217 Swaziland 39.47 2003 est.
218 Rwanda 39.33 2003 est.
219 Zimbabwe 39.01 2003 est.
220 Malawi 37.98 2003 est.
221 Angola 36.96 2003 est.
222 Lesotho 36.94 2003 est.
223 Zambia 35.25 2003 est.
224 Botswana 32.26 2003 est.
225 Mozambique 31.30 2003 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2119
Rank Country Population Date of Information
1 World 6,302,309,691 July 2003 est.
2 China 1,286,975,468 July 2003 est.
3 India 1,049,700,118 July 2003 est.
4 United States 290,342,554 July 2003 est.
5 Indonesia 234,893,453 July 2003 est.
6 Brazil 182,032,604 July 2003 est.
7 Pakistan 150,694,740 July 2003 est.
8 Russia 144,526,278 July 2003 est.
9 Bangladesh 138,448,210 July 2003 est.
10 Nigeria 133,881,703 July 2003 est.
11 Japan 127,214,499 July 2003 est.
12 Mexico 104,907,991 July 2003 est.
13 Philippines 84,619,974 July 2003 est.
14 Germany 82,398,326 July 2003 est.
15 Vietnam 81,624,716 July 2003 est.
16 Egypt 74,718,797 July 2003 est.
17 Iran 68,278,826 July 2003 est.
18 Turkey 68,109,469 July 2003 est.
19 Ethiopia 66,557,553 July 2003 est.
20 Thailand 64,265,276 July 2003 est.
21 France 60,180,529 July 2003 est.
22 United Kingdom 60,094,648 July 2003 est.
23 Italy 57,998,353 July 2003 est.
24 Congo, Democratic Republic of the 56,625,039 July 2003 est.
25 Korea, South 48,289,037 July 2003 est.
26 Ukraine 48,055,439 July 2003 est.
27 South Africa 42,768,678 July 2003 est.
28 Burma 42,510,537 July 2003 est.
29 Colombia 41,662,073 July 2003 est.
30 Spain 40,217,413 July 2003 est.
31 Argentina 38,740,807 July 2003 est.
32 Poland 38,622,660 July 2003 est.
33 Sudan 38,114,160 July 2003 est.
34 Tanzania 35,922,454 July 2003 est.
35 Algeria 32,818,500 July 2003 est.
36 Canada 32,207,113 July 2003 est.
37 Morocco 31,689,265 July 2003 est.
38 Kenya 31,639,091 July 2003 est.
39 Afghanistan 28,717,213 July 2003 est.
40 Peru 28,409,897 July 2003 est.
41 Nepal 26,469,569 July 2003 est.
42 Uzbekistan 25,981,647 July 2003 est.
43 Uganda 25,632,794 July 2003 est.
44 Iraq 24,683,313 July 2003 est.
45 Venezuela 24,654,694 July 2003 est.
46 Saudi Arabia 24,293,844 July 2003 est.
47 Malaysia 23,092,940 July 2003 est.
48 Taiwan 22,603,001 July 2003 est.
49 Korea, North 22,466,481 July 2003 est.
50 Romania 22,271,839 July 2003 est.
51 Ghana 20,467,747 July 2003 est.
52 Sri Lanka 19,742,439 July 2003 est.
53 Australia 19,731,984 July 2003 est.
54 Yemen 19,349,881 July 2003 est.
55 Syria 17,585,540 July 2003 est.
56 Mozambique 17,479,266 July 2003 est.
57 Madagascar 16,979,744 July 2003 est.
58 Cote d''Ivoire 16,962,491 July 2003 est.
59 Kazakhstan 16,763,795 July 2003 est.
60 Netherlands 16,150,511 July 2003 est.
61 Cameroon 15,746,179 July 2003 est.
62 Chile 15,665,216 July 2003 est.
63 Guatemala 13,909,384 July 2003 est.
64 Ecuador 13,710,234 July 2003 est.
65 Burkina Faso 13,228,460 July 2003 est.
66 Cambodia 13,124,764 July 2003 est.
67 Zimbabwe 12,576,742 July 2003 est.
68 Malawi 11,651,239 July 2003 est.
69 Mali 11,626,219 July 2003 est.
70 Cuba 11,263,429 July 2003 est.
71 Niger 11,058,590 July 2003 est.
72 Angola 10,766,471 July 2003 est.
73 Greece 10,665,989 July 2003 est.
74 Serbia and Montenegro 10,655,774 July 2003 est.
75 Senegal 10,580,307 July 2003 est.
76 Belarus 10,322,151 July 2003 est.
77 Zambia 10,307,333 July 2003 est.
78 Belgium 10,289,088 July 2003 est.
79 Czech Republic 10,249,216 July 2003 est.
80 Portugal 10,102,022 July 2003 est.
81 Hungary 10,045,407 July 2003 est.
82 Tunisia 9,924,742 July 2003 est.
83 Chad 9,253,493 July 2003 est.
84 Guinea 9,030,220 July 2003 est.
85 Sweden 8,878,085 July 2003 est.
86 Dominican Republic 8,715,602 July 2003 est.
87 Bolivia 8,586,443 July 2003 est.
88 Austria 8,188,207 July 2003 est.
89 Somalia 8,025,190 July 2003 est.
90 Azerbaijan 7,830,764 July 2003 est.
91 Rwanda 7,810,056 July 2003 est.
92 Bulgaria 7,537,929 July 2003 est.
93 Haiti 7,527,817 July 2003 est.
94 Hong Kong 7,394,170 July 2003 est.
95 Switzerland 7,318,638 July 2003 est.
96 Benin 7,041,490 July 2003 est.
97 Tajikistan 6,863,752 July 2003 est.
98 Honduras 6,669,789 July 2003 est.
99 El Salvador 6,470,379 July 2003 est.
100 Israel 6,116,533 July 2003 est.
101 Burundi 6,096,156 July 2003 est.
102 Paraguay 6,036,900 July 2003 est.
103 Laos 5,921,545 July 2003 est.
104 Sierra Leone 5,732,681 July 2003 est.
105 Libya 5,499,074 July 2003 est.
106 Jordan 5,460,265 July 2003 est.
107 Slovakia 5,430,033 July 2003 est.
108 Togo 5,429,299 July 2003 est.
109 Denmark 5,384,384 July 2003 est.
110 Papua New Guinea 5,295,816 July 2003 est.
111 Finland 5,190,785 July 2003 est.
112 Nicaragua 5,128,517 July 2003 est.
113 Georgia 4,934,413 July 2003 est.
114 Kyrgyzstan 4,892,808 July 2003 est.
115 Turkmenistan 4,775,544 July 2003 est.
116 Singapore 4,608,595 July 2003 est.
117 Norway 4,546,123 July 2003 est.
118 Moldova 4,439,502 July 2003 est.
119 Croatia 4,422,248 July 2003 est.
120 Eritrea 4,362,254 July 2003 est.
121 Bosnia and Herzegovina 3,989,018 July 2003 est.
122 New Zealand 3,951,307 July 2003 est.
123 Ireland 3,924,140 July 2003 est.
124 Costa Rica 3,896,092 July 2003 est.
125 Puerto Rico 3,885,877 July 2003 est.
126 Lebanon 3,727,703 July 2003 est.
127 Central African Republic 3,683,538 July 2003 est.
128 Lithuania 3,592,561 July 2003 est.
129 Albania 3,582,205 July 2003 est.
130 Uruguay 3,413,329 July 2003 est.
131 Armenia 3,326,448 July 2003 est.
132 Liberia 3,317,176 July 2003 est.
133 Panama 2,960,784 July 2003 est.
134 Congo, Republic of the 2,954,258 July 2003 est.
135 Mauritania 2,912,584 July 2003 est.
136 Oman 2,807,125 July 2003 est.
137 Mongolia 2,712,315 July 2003 est.
138 Jamaica 2,695,867 July 2003 est.
139 United Arab Emirates 2,484,818 July 2003 est.
140 Latvia 2,348,784 July 2003 est.
141 West Bank 2,237,194 July 2003 est.
142 Kuwait 2,183,161 July 2003 est.
143 Bhutan 2,139,549 July 2003 est.
144 Macedonia, The Former Yugoslav Republic of 2,063,122 July 2003 est.
145 Slovenia 1,935,677 July 2003 est.
146 Namibia 1,927,447 July 2003 est.
147 Lesotho 1,861,959 July 2003 est.
148 Botswana 1,573,267 July 2003 est.
149 Gambia, The 1,501,050 July 2003 est.
150 Estonia 1,408,556 July 2003 est.
151 Guinea-Bissau 1,360,827 July 2003 est.
152 Gabon 1,321,560 July 2003 est.
153 Gaza Strip 1,274,868 July 2003 est.
154 Mauritius 1,210,447 July 2003 est.
155 Swaziland 1,161,219 July 2003 est.
156 Trinidad and Tobago 1,104,209 July 2003 est.
157 East Timor 997,853 July 2003 est.
158 Fiji 868,531 July 2003 est.
159 Qatar 817,052 July 2003 est.
160 Cyprus 771,657 July 2003 est.
161 Reunion 755,171 July 2003 est.
162 Guyana 702,100 July 2003 est.
163 Bahrain 667,238 July 2003 est.
164 Comoros 632,948 July 2003 est.
165 Equatorial Guinea 510,473 July 2003 est.
166 Solomon Islands 509,190 July 2003 est.
167 Macau 469,903 July 2003 est.
168 Djibouti 457,130 July 2003 est.
169 Luxembourg 454,157 July 2003 est.
170 Guadeloupe 440,189 July 2003 est.
171 Suriname 435,449 July 2003 est.
172 Martinique 425,966 July 2003 est.
173 Cape Verde 412,137 July 2003 est.
174 Malta 400,420 July 2003 est.
175 Brunei 358,098 July 2003 est.
176 Maldives 329,684 July 2003 est.
177 Bahamas, The 297,477 July 2003 est.
178 Iceland 280,798 July 2003 est.
179 Barbados 277,264 July 2003 est.
180 Belize 266,440 July 2003 est.
181 French Polynesia 262,125 July 2003 est.
182 Western Sahara 261,794 July 2003 est.
183 Netherlands Antilles 216,226 July 2003 est.
184 New Caledonia 210,798 July 2003 est.
185 Vanuatu 199,414 July 2003 est.
186 French Guiana 186,917 July 2003 est.
187 Mayotte 178,437 July 2003 est.
188 Samoa 178,173 July 2003 est.
189 Sao Tome and Principe 175,883 July 2003 est.
190 Guam 163,941 July 2003 est.
191 Saint Lucia 162,157 July 2003 est.
192 Virgin Islands 124,778 July 2003 est.
193 Saint Vincent and the Grenadines 116,812 July 2003 est.
194 Micronesia, Federated States of 108,143 July 2003 est.
195 Tonga 108,141 July 2003 est.
196 Kiribati 98,549 July 2003 est.
197 Jersey 90,156 July 2003 est.
198 Grenada 89,258 July 2003 est.
199 Seychelles 80,469 July 2003 est.
200 Northern Mariana Islands 80,006 July 2003 est.
201 Man, Isle of 74,261 July 2003 est.
202 Aruba 70,844 July 2003 est.
203 American Samoa 70,260 July 2003 est.
204 Dominica 69,655 July 2003 est.
205 Andorra 69,150 July 2003 est.
206 Antigua and Barbuda 67,897 July 2003 est.
207 Guernsey 64,818 July 2003 est.
208 Bermuda 64,482 July 2003 est.
209 Marshall Islands 56,429 July 2003 est.
210 Greenland 56,385 July 2003 est.
211 Faroe Islands 46,345 July 2003 est.
212 Cayman Islands 41,934 July 2003 est.
213 Saint Kitts and Nevis 38,763 July 2003 est.
214 Liechtenstein 33,145 July 2003 est.
215 Monaco 32,130 July 2003 est.
216 San Marino 28,119 July 2003 est.
217 Gibraltar 27,776 July 2003 est.
218 British Virgin Islands 21,730 July 2003 est.
219 Cook Islands 21,008 July 2003 est.
220 Palau 19,717 July 2003 est.
221 Turks and Caicos Islands 19,350 July 2003 est.
222 Wallis and Futuna 15,734 July 2003 est.
223 Anguilla 12,738 July 2003 est.
224 Nauru 12,570 July 2003 est.
225 Tuvalu 11,305 July 2003 est.
226 Montserrat 8,995 July 2003 est.
227 Saint Helena 7,367 July 2003 est.
228 Saint Pierre and Miquelon 6,976 July 2003 est.
229 Falkland Islands (Islas Malvinas) 2,967 July 2003 est.
230 Svalbard 2,811 July 2003 est.
231 Niue 2,145 July 2003 est.
232 Norfolk Island 1,853 July 2003 est.
233 Tokelau 1,418 July 2003 est.
234 Holy See (Vatican City) 911 July 2003 est.
235 Cocos (Keeling) Islands 630 July 2003 est.
236 Christmas Island 433 July 2003 est.
237 Pitcairn Islands 47 July 2003 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2121
Rank Country Railways(km) Date of Information
1 World 1,122,650
2 United States 194,731 2000
3 Russia 87,157 2002
4 China 71,600 2002
5 India 63,518 2002
6 Canada 49,422 2002
7 Germany 45,514 2002
8 Australia 41,588 2002
9 Argentina 34,463 2002
10 France 32,682 2002
11 Brazil 31,543 2002
12 Poland 23,420 2002
13 Japan 23,168 2002
14 Ukraine 22,473 2002
15 South Africa 22,298 2002
16 Mexico 19,510 2002
17 Italy 19,493 2002
18 United Kingdom 16,893 2002
19 Spain 14,189 2002
20 Kazakhstan 13,601 2002
21 Sweden 11,481 2002
22 Romania 11,385 2002
23 Czech Republic 9,462 2002
24 Turkey 8,607 2002
25 Pakistan 8,163 2002
26 Hungary 7,875 2002
27 Iran 7,201 2002
28 Chile 6,585 2002
29 Indonesia 6,458 2002
30 Austria 6,024 2002
31 Sudan 5,978 2002
32 Finland 5,850 2002
33 Belarus 5,523 2002
34 Korea, North 5,214 2002
35 Egypt 5,105 2002
36 Congo, Democratic Republic of the 4,772 2002
37 Switzerland 4,511 2002
38 Bulgaria 4,294 2002
39 Norway 4,178 2002
40 Thailand 4,071 2002
41 Serbia and Montenegro 4,059 2002
42 Algeria 3,973 2002
43 Burma 3,955 2002
44 Uzbekistan 3,950 2002
45 New Zealand 3,898 2002
46 Tanzania 3,690 2002
47 Slovakia 3,668 2002
48 Nigeria 3,557 2002
49 Bolivia 3,519 2002
50 Belgium 3,471 2002
51 Cuba 3,442 2002
52 Ireland 3,312 2002
53 Colombia 3,304 2002
54 Denmark 3,164 2002
55 Vietnam 3,142 2002
56 Korea, South 3,125 2002
57 Mozambique 3,123 2002
58 Zimbabwe 3,077 2002
59 Portugal 2,850 2002
60 Netherlands 2,808 2002
61 Kenya 2,778 2002
62 Angola 2,761 2002
63 Syria 2,743 2002
64 Bangladesh 2,706 2002
65 Greece 2,571 2002
66 Turkmenistan 2,440 2002
67 Malaysia 2,418 2002
68 Namibia 2,382 2002
69 Latvia 2,347 2002
70 Croatia 2,296 2002
71 Zambia 2,173 2002
72 Tunisia 2,152 2002
73 Azerbaijan 2,122 2002
74 Uruguay 2,073 2002
75 Lithuania 1,998 2002
76 Iraq 1,963 2003
77 Morocco 1,907 2002
78 Peru 1,829 2002
79 Georgia 1,612 2002
80 Sri Lanka 1,508 2002
81 Dominican Republic 1,503 2002
82 Saudi Arabia 1,392 2002
83 Moldova 1,300 2002
84 Uganda 1,241 2002
85 Slovenia 1,201 2002
86 Guinea 1,115 2002
87 Taiwan 1,108 2002
88 Bosnia and Herzegovina 1,021 2002
89 Cameroon 1,008 2002
90 Estonia 968 2002
91 Ecuador 966 2002
92 Ghana 953 2002
93 Costa Rica 950 2002
94 Senegal 906 2002
95 Philippines 897 2002
96 Congo, Republic of the 894 2002
97 Botswana 888 2002
98 Guatemala 886 2002
99 Armenia 852 2002
100 Gabon 814 2002
101 Malawi 797 2002
102 Madagascar 732 2002
103 Mali 729 2002
104 Honduras 699 2002
105 Macedonia, The Former Yugoslav Republic of 699 2002
106 Venezuela 682 2002
107 Ethiopia 681 2002
108 Cote d''Ivoire 660 2002
109 Israel 640 2002
110 Burkina Faso 622 2002
111 Cambodia 602 2002
112 Fiji 597 2002
113 Benin 578 2002
114 Togo 525 2002
115 Jordan 505 2002
116 Liberia 490 2002
117 Tajikistan 482 2002
118 Albania 447 2002
119 Paraguay 441 2002
120 Kyrgyzstan 420 2002
121 Lebanon 401 2002
122 Panama 355 2002
123 Eritrea 306 2002
124 Swaziland 301 2002
125 El Salvador 283 2002
126 Luxembourg 274 2002
127 Jamaica 272 2002
128 Guyana 187 2001 est.
129 Suriname 166 2001
130 Djibouti 100 2002
131 Puerto Rico 96 2002
132 Sierra Leone 84 2001
133 Antigua and Barbuda 77 2001 est.
134 Man, Isle of 60 2002
135 Nepal 59 2002
136 Saint Kitts and Nevis 50 2002
137 Haiti 40 2001 est.
138 Singapore 39
139 Hong Kong 34 2001
140 Afghanistan 25 2001
141 Liechtenstein 19 2002
142 Brunei 13 2001 est.
143 Nicaragua 6 2002
144 Nauru 5 2001
145 Lesotho 3 1995
146 Monaco 2 2002
147 Holy See (Vatican City) 1 2001 est.
148 Equatorial Guinea 0
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2127
Rank Country Total fertility rate(children born/woman) Date of Information
1 Somalia 6.98 2003 est.
2 Niger 6.91 2003 est.
3 Yemen 6.82 2003 est.
4 Uganda 6.72 2003 est.
5 Congo, Democratic Republic of the 6.69 2003 est.
6 Mali 6.66 2003 est.
7 Chad 6.44 2003 est.
8 Angola 6.38 2003 est.
9 Burkina Faso 6.34 2003 est.
10 Liberia 6.23 2003 est.
11 Gaza Strip 6.17 2003 est.
12 Saudi Arabia 6.15 2003 est.
13 Malawi 6.10 2003 est.
14 Mauritania 6.08 2003 est.
15 Mayotte 6.07 2003 est.
16 Benin 6.04 2003 est.
17 Burundi 5.99 2003 est.
18 Oman 5.94 2003 est.
19 Guinea 5.90 2003 est.
20 Sao Tome and Principe 5.88 2003 est.
21 Sierra Leone 5.86 2003 est.
22 Eritrea 5.74 2003 est.
23 Madagascar 5.73 2003 est.
24 Afghanistan 5.64 2003 est.
25 Rwanda 5.60 2003 est.
26 Djibouti 5.56 2003 est.
27 Ethiopia 5.55 2003 est.
28 Gambia, The 5.53 2003 est.
29 Cote d''Ivoire 5.51 2003 est.
30 Nigeria 5.40 2003 est.
31 Maldives 5.26 2003 est.
32 Zambia 5.25 2003 est.
33 Tanzania 5.24 2003 est.
34 Comoros 5.21 2003 est.
35 Sudan 5.10 2003 est.
36 Guinea-Bissau 5.07 2003 est.
37 Togo 4.97 2003 est.
38 Bhutan 4.94 2003 est.
39 Laos 4.94 2003 est.
40 Senegal 4.93 2003 est.
41 Mozambique 4.87 2003 est.
42 Haiti 4.86 2003 est.
43 Gabon 4.83 2003 est.
44 Equatorial Guinea 4.75 2003 est.
45 Namibia 4.71 2003 est.
46 Central African Republic 4.68 2003 est.
47 Guatemala 4.67 2003 est.
48 West Bank 4.65 2003 est.
49 Cameroon 4.63 2003 est.
50 Iraq 4.52 2003 est.
51 Nepal 4.39 2003 est.
52 Solomon Islands 4.34 2003 est.
53 Kiribati 4.28 2003 est.
54 Tajikistan 4.17 2003 est.
55 Papua New Guinea 4.13 2003 est.
56 Marshall Islands 4.12 2003 est.
57 Pakistan 4.10 2003 est.
58 Honduras 4.07 2003 est.
59 Paraguay 4.02 2003 est.
60 Swaziland 3.92 2003 est.
61 Belize 3.86 2003 est.
62 East Timor 3.79 2003 est.
63 Cape Verde 3.77 2003 est.
64 Syria 3.72 2003 est.
65 Zimbabwe 3.66 2003 est.
66 Congo, Republic of the 3.65 2003 est.
67 Guam 3.62 2003 est.
68 Cambodia 3.58 2003 est.
69 Lesotho 3.52 2003 est.
70 Micronesia, Federated States of 3.50 2003 est.
71 Turkmenistan 3.50 2003 est.
72 Libya 3.49 2003 est.
73 Kenya 3.47 2003 est.
74 Nauru 3.40 2003 est.
75 Ghana 3.32 2003 est.
76 American Samoa 3.30 2003 est.
77 Philippines 3.29 2003 est.
78 Botswana 3.27 2003 est.
79 El Salvador 3.25 2003 est.
80 Bolivia 3.23 2003 est.
81 Samoa 3.21 2003 est.
82 Bangladesh 3.17 2003 est.
83 Turks and Caicos Islands 3.15 2003 est.
84 Malaysia 3.13 2003 est.
85 Kyrgyzstan 3.12 2003 est.
86 French Guiana 3.09 2003 est.
87 United Arab Emirates 3.09 2003 est.
88 Kuwait 3.08 2003 est.
89 Tuvalu 3.05 2003 est.
90 Egypt 3.02 2003 est.
91 Qatar 3.02 2003 est.
92 Jordan 3.00 2003 est.
93 Nicaragua 3.00 2003 est.
94 Uzbekistan 3.00 2003 est.
95 Tonga 3.00 2003 est.
96 Ecuador 2.99 2003 est.
97 Vanuatu 2.98 2003 est.
98 Dominican Republic 2.92 2003 est.
99 India 2.91 2003 est.
100 Morocco 2.89 2003 est.
101 Fiji 2.81 2003 est.
102 Peru 2.81 2003 est.
103 Bahrain 2.71 2003 est.
104 World 2.65 2003 est.
105 Colombia 2.61 2003 est.
106 Algeria 2.55 2003 est.
107 Mexico 2.53 2003 est.
108 Panama 2.53 2003 est.
109 Reunion 2.53 2003 est.
110 Indonesia 2.50 2003 est.
111 Israel 2.50 2003 est.
112 Palau 2.47 2003 est.
113 Grenada 2.45 2003 est.
114 Greenland 2.43 2003 est.
115 Suriname 2.40 2003 est.
116 New Caledonia 2.39 2003 est.
117 Costa Rica 2.38 2003 est.
118 Brunei 2.37 2003 est.
119 Saint Kitts and Nevis 2.37 2003 est.
120 Venezuela 2.36 2003 est.
121 Uruguay 2.35 2003 est.
122 Azerbaijan 2.34 2003 est.
123 Saint Lucia 2.29 2003 est.
124 Antigua and Barbuda 2.28 2003 est.
125 Mongolia 2.28 2003 est.
126 Argentina 2.28 2003 est.
127 Bahamas, The 2.25 2003 est.
128 Korea, North 2.25 2003 est.
129 Faroe Islands 2.24 2003 est.
130 South Africa 2.24 2003 est.
131 Vietnam 2.24 2003 est.
132 Albania 2.22 2003 est.
133 Virgin Islands 2.22 2003 est.
134 Kazakhstan 2.16 2003 est.
135 Burma 2.15 2003 est.
136 French Polynesia 2.14 2003 est.
137 Chile 2.09 2003 est.
138 Guyana 2.07 2003 est.
139 Saint Pierre and Miquelon 2.07 2003 est.
140 United States 2.07 2003 est.
141 Netherlands Antilles 2.04 2003 est.
142 Turkey 2.03 2003 est.
143 Puerto Rico 2.02 2003 est.
144 Brazil 2.01 2003 est.
145 Jamaica 2.01 2003 est.
146 Dominica 1.99 2003 est.
147 Iran 1.99 2003 est.
148 Iceland 1.98 2003 est.
149 Lebanon 1.98 2003 est.
150 Mauritius 1.98 2003 est.
151 Saint Vincent and the Grenadines 1.95 2003 est.
152 Croatia 1.93 2003 est.
153 Guadeloupe 1.92 2003 est.
154 Cayman Islands 1.91 2003 est.
155 Malta 1.91 2003 est.
156 Thailand 1.91 2003 est.
157 Bermuda 1.90 2003 est.
158 Tunisia 1.90 2003 est.
159 Sri Lanka 1.90 2003 est.
160 Ireland 1.89 2003 est.
161 Cyprus 1.88 2003 est.
162 France 1.85 2003 est.
163 Montserrat 1.80 2003 est.
164 Norway 1.80','6a9032330ca0969515a16d884d570a232ca71232af3651d153d2e2b5cd670e8e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8491d663892ab139f83b7eb7add5e6c150054e18799818690011b0520768a0c',2003,'YE','Yemen','communications',809,'2003 est.
165 Aruba 1.79 2003 est.
166 New Zealand 1.79 2003 est.
167 Seychelles 1.79 2003 est.
168 Martinique 1.79 2003 est.
169 Trinidad and Tobago 1.78 2003 est.
170 Serbia and Montenegro 1.77 2003 est.
171 Australia 1.76 2003 est.
172 Monaco 1.76 2003 est.
173 Anguilla 1.76 2003 est.
174 Northern Mariana Islands 1.75 2003 est.
175 Macedonia, The Former Yugoslav Republic of 1.75 2003 est.
176 Moldova 1.74 2003 est.
177 Denmark 1.73 2003 est.
178 British Virgin Islands 1.72 2003 est.
179 Bosnia and Herzegovina 1.71 2003 est.
180 China 1.70 2003 est.
181 Luxembourg 1.70 2003 est.
182 Finland 1.70 2003 est.
183 United Kingdom 1.66 2003 est.
184 Barbados 1.65 2003 est.
185 Netherlands 1.65 2003 est.
186 Man, Isle of 1.65 2003 est.
187 Gibraltar 1.65 2003 est.
188 Belgium 1.62 2003 est.
189 Canada 1.61 2003 est.
190 Cuba 1.61 2003 est.
191 Jersey 1.57 2003 est.
192 Taiwan 1.57 2003 est.
193 Armenia 1.56 2003 est.
194 Korea, South 1.56 2003 est.
195 Saint Helena 1.54 2003 est.
196 Sweden 1.54 2003 est.
197 Georgia 1.51 2003 est.
198 Liechtenstein 1.50 2003 est.
199 Portugal 1.49 2003 est.
200 Switzerland 1.48 2003 est.
201 Lithuania 1.43 2003 est.
202 Austria 1.41 2003 est.
203 Japan 1.38 2003 est.
204 Guernsey 1.37 2003 est.
205 Poland 1.37 2003 est.
206 Germany 1.37 2003 est.
207 Romania 1.36 2003 est.
208 Greece 1.35 2003 est.
209 Belarus 1.34 2003 est.
210 Ukraine 1.34 2003 est.
211 Russia 1.33 2003 est.
212 Hong Kong 1.32 2003 est.
213 Macau 1.32 2003 est.
214 San Marino 1.31 2003 est.
215 Andorra 1.27 2003 est.
216 Slovenia 1.27 2003 est.
217 Estonia 1.27 2003 est.
218 Italy 1.26 2003 est.
219 Spain 1.26 2003 est.
220 Hungary 1.25 2003 est.
221 Slovakia 1.25 2003 est.
222 Singapore 1.24 2003 est.
223 Latvia 1.20 2003 est.
224 Czech Republic 1.18 2003 est.
225 Bulgaria 1.13 2003 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2129
Rank Country Unemployment rate(%) Date of Information
1 Kiribati 70.00 1992 est.
2 Zimbabwe 70.00 2002 est.
3 Cocos (Keeling) Islands 60.00 2000 est.
4 Gaza Strip 50.00 2002 est.
5 Zambia 50.00 2000 est.
6 West Bank 50.00 2002 est.
7 East Timor 50.00
8 Senegal 48.00 2001 est.
9 Nepal 47.00 2001 est.
10 Lesotho 45.00 2002
11 Botswana 40.00 2001 est.
12 Bangladesh 40.00 2002 est.
13 Bosnia and Herzegovina 40.00 2002 est.
14 Kenya 40.00 2001 est.
15 Tajikistan 40.00 2002 est.
16 Mayotte 38.00 1999
17 Macedonia, The Former Yugoslav Republic of 37.00 2002 est.
18 South Africa 37.00 2001 est.
19 Reunion 36.00 1999 est.
20 Namibia 35.00 1998
21 Swaziland 34.00 2000 est.
22 Serbia and Montenegro 32.00 2002 est.
23 Algeria 31.00 2002 est.
24 Marshall Islands 30.90 1999 est.
25 Cameroon 30.00 2001 est.
26 Yemen 30.00 1995 est.
27 World 30.00
28 Equatorial Guinea 30.00 1998 est.
29 Libya 30.00 2001
30 Honduras 28.00 2002 est.
31 Nigeria 28.00 1992 est.
32 Guadeloupe 27.80 1998
33 Martinique 27.20 1998
34 Saudi Arabia 25.00 2002
35 Vietnam 25.00 1995 est.
36 Nicaragua 24.00 2002 est.
37 Dominica 23.00 2000 est.
38 French Guiana 22.00 2001
39 Saint Vincent and the Grenadines 22.00 1997 est.
40 Croatia 21.70 2002 est.
41 Argentina 21.50 37377
42 Cape Verde 21.00 2000 est.
43 Mauritania 21.00 1999 est.
44 Mozambique 21.00 1997 est.
45 Gabon 21.00 1997 est.
46 Armenia 20.00 2001 est.
47 Syria 20.00 2002 est.
48 Mongolia 20.00 2000
49 Ghana 20.00 1997 est.
50 Comoros 20.00 1996 est.
51 Uruguay 19.40 2002
52 Morocco 19.00 2002 est.
53 New Caledonia 19.00 1996
54 Sudan 18.70 2002 est.
55 Paraguay 18.20 2002 est.
56 Poland 18.10 2002
57 Bulgaria 18.00 2002 est.
58 Lebanon 18.00 1997 est.
59 Colombia 17.40 2002 est.
60 Slovakia 17.20 2002 est.
61 Albania 17.00 2001 est.
62 Georgia 17.00 2001 est.
63 Venezuela 17.00 2002 est.
64 Suriname 17.00 2000
65 Saint Lucia 16.50 1997 est.
66 Iran 16.30 2003 est.
67 Azerbaijan 16.00 2003 est.
68 Micronesia, Federated States of 16.00 1999 est.
69 Panama 16.00 2002 est.
70 Jordan 16.00 2001 est.
71 Jamaica 15.40 2002 est.
72 Tunisia 15.40 2002 est.
73 Bahrain 15.00 1998 est.
74 Guam 15.00 2000 est.
75 Netherlands Antilles 15.00 1998 est.
76 Mali 14.60 2001 est.
77 Dominican Republic 14.50 2002 est.
78 Saint Helena 14.00 1998 est.
79 Tonga 13.30 1996 est.
80 Cook Islands 13.00 1996
81 Cote d''Ivoire 13.00 1998
82 Grenada 12.50 2000
83 Lithuania 12.50 2001 est.
84 Estonia 12.40 2001
85 Egypt 12.00 2001 est.
86 Puerto Rico 12.00 2002
87 French Polynesia 11.80 1994
88 Spain 11.30 2002 est.
89 Antigua and Barbuda 11.00 2001 est.
90 Slovenia 11.00 2002 est.
91 Trinidad and Tobago 10.80 2002
92 Turkey 10.80 2002 est.
93 Indonesia 10.60 2002 est.
94 Israel 10.40 2002 est.
95 Greece 10.30 2002 est.
96 Philippines 10.20 2002
97 Barbados 10.00 2001 est.
98 Uzbekistan 10.00
99 Turks and Caicos Islands 10.00 1997 est.
100 Greenland 10.00 2000 est.
101 El Salvador 10.00 2001 est.
102 Brunei 10.00 2001 est.
103 Czech Republic 9.80 2002
104 Saint Pierre and Miquelon 9.80 1997
105 Germany 9.80 2002 est.
106 Peru 9.40 2002 est.
107 Chile 9.20 2002
108 Belize 9.10 2002
109 France 9.10 2002 est.
110 Italy 9.10 2002 est.
111 India 8.80 2002
112 Kazakhstan 8.80 2002 est.
113 Mauritius 8.80 2002 est.
114 Finland 8.50 2002 est.
115 Romania 8.30 2002
116 Sri Lanka 8.00 2002
117 Central African Republic 8.00 2001 est.
118 Moldova 8.00 2002 est.
119 Russia 7.90 2002
120 Pakistan 7.80 2002 est.
121 Ecuador 7.70 2001 est.
122 Bolivia 7.60 2000
123 Fiji 7.60 1999
124 Latvia 7.60 2001 est.
125 Canada 7.60 2002 est.
126 Guatemala 7.50 1999 est.
127 Hong Kong 7.50 2002 est.
128 Belgium 7.20 2002 est.
129 Kyrgyzstan 7.20 1999 est.
130 Kuwait 7.00 2002 est.
131 Malta 7.00 2002 est.
132 Bahamas, The 6.90 2001 est.
133 Anguilla 6.70 2001
134 Brazil 6.40 2001 est.
135 Australia 6.30 2002
136 Macau 6.30 2002
137 Costa Rica 6.30 2002 est.
138 American Samoa 6.00 2000
139 Montserrat 6.00 1998 est.
140 Madagascar 5.90 1998
141 Hungary 5.80 2002 est.
142 United States 5.80 2002
143 Laos 5.70 1997 est.
144 Cyprus 5.60 2002 est.
145 Japan 5.40 2002
146 Mali 5.30 2001 est.
147 New Zealand 5.30 2002 est.
148 Taiwan 5.20 2002 est.
149 United Kingdom 5.20 2002 est.
150 Burma 5.10 2001 est.
151 Denmark 5.10 2002
152 Virgin Islands 4.90 March 1999
153 Austria 4.80 2002 est.
154 Portugal 4.70 2002 est.
155 Singapore 4.60 2002 est.
156 Bermuda 4.50 1993
157 Saint Kitts and Nevis 4.50 1997
158 Ireland 4.30 2002 est.
159 Cayman Islands 4.10 1997
160 Cuba 4.10 2001 est.
161 Luxembourg 4.10 2002 est.
162 Sweden 4.00 2002 est.
163 Norway 3.90 2002 est.
164 Malaysia 3.80 2002 est.
165 Ukraine 3.80 2002
166 Cyprus 3.30 2002 est.
167 Korea, South 3.10 2002 est.
168 Monaco 3.10 1998
169 Mexico 3.00 2002
170 Netherlands 3.00 2002 est.
171 British Virgin Islands 3.00 1995
172 Thailand 2.90 2002 est.
173 Cambodia 2.80 1999 est.
174 Iceland 2.80 2002 est.
175 Qatar 2.70 2001
176 San Marino 2.60 2001
177 Palau 2.30 2000 est.
178 Belarus 2.10
179 Gibraltar 2.00 2001 est.
180 Kiribati 2.00 1992 est.
181 Switzerland 1.90 2002 est.
182 Liechtenstein 1.30 37500
183 Faroe Islands 1.00 October 2000
184 Man, Isle of 0.70 March 2003
185 Jersey 0.70 1998 est.
186 Aruba 0.60
187 Guernsey 0.50 1999 est.
188 Andorra 0.00
189 Nauru 0.00
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2147
Rank Country Area(sq km) Date of Information
1 World 510,072,000
2 Pacific Ocean 155,557,000
3 Atlantic Ocean 76,762,000
4 Indian Ocean 68,556,000
5 Southern Ocean 20,327,000
6 Russia 17,075,200
7 Arctic Ocean 14,056,000
8 Antarctica 14,000,000
9 Canada 9,984,670
10 United States 9,629,091
11 China 9,596,960
12 Brazil 8,511,965
13 Australia 7,686,850
14 India 3,287,590
15 Argentina 2,766,890
16 Kazakhstan 2,717,300
17 Sudan 2,505,810
18 Algeria 2,381,740
19 Congo, Democratic Republic of the 2,345,410
20 Greenland 2,166,086
21 Mexico 1,972,550
22 Saudi Arabia 1,960,582
23 Indonesia 1,919,440
24 Libya 1,759,540
25 Iran 1,648,000
26 Mongolia 1,565,000
27 Peru 1,285,220
28 Chad 1,284,000
29 Niger 1,267,000
30 Angola 1,246,700
31 Mali 1,240,000
32 South Africa 1,219,912
33 Colombia 1,138,910
34 Ethiopia 1,127,127
35 Bolivia 1,098,580
36 Mauritania 1,030,700
37 Egypt 1,001,450
38 Tanzania 945,087
39 Nigeria 923,768
40 Venezuela 912,050
41 Namibia 825,418
42 Pakistan 803,940
43 Mozambique 801,590
44 Turkey 780,580
45 Chile 756,950
46 Zambia 752,614
47 Burma 678,500
48 Afghanistan 647,500
49 Somalia 637,657
50 Central African Republic 622,984
51 Ukraine 603,700
52 Botswana 600,370
53 Madagascar 587,040
54 Kenya 582,650
55 France 547,030
56 Yemen 527,970
57 Thailand 514,000
58 Spain 504,782
59 Turkmenistan 488,100
60 Cameroon 475,440
61 Papua New Guinea 462,840
62 Sweden 449,964
63 Uzbekistan 447,400
64 Morocco 446,550
65 Iraq 437,072
66 Paraguay 406,750
67 Zimbabwe 390,580
68 Japan 377,835
69 Germany 357,021
70 Congo, Republic of the 342,000
71 Finland 337,030
72 Malaysia 329,750
73 Vietnam 329,560
74 Norway 324,220
75 Cote d''Ivoire 322,460
76 Poland 312,685
77 Italy 301,230
78 Philippines 300,000
79 Ecuador 283,560
80 Burkina Faso 274,200
81 New Zealand 268,680
82 Gabon 267,667
83 Western Sahara 266,000
84 Guinea 245,857
85 United Kingdom 244,820
86 Ghana 239,460
87 Romania 237,500
88 Laos 236,800
89 Uganda 236,040
90 Guyana 214,970
91 Oman 212,460
92 Belarus 207,600
93 Kyrgyzstan 198,500
94 Senegal 196,190
95 Syria 185,180
96 Cambodia 181,040
97 Uruguay 176,220
98 Tunisia 163,610
99 Suriname 163,270
100 Bangladesh 144,000
101 Tajikistan 143,100
102 Nepal 140,800
103 Greece 131,940
104 Nicaragua 129,494
105 Eritrea 121,320
106 Korea, North 120,540
107 Malawi 118,480
108 Benin 112,620
109 Honduras 112,090
110 Liberia 111,370
111 Bulgaria 110,910
112 Cuba 110,860
113 Guatemala 108,890
114 Iceland 103,000
115 Serbia and Montenegro 102,350
116 Korea, South 98,480
117 Hungary 93,030
118 Portugal 92,391
119 Jordan 92,300
120 French Guiana 91,000
121 Azerbaijan 86,600
122 Austria 83,858
123 United Arab Emirates 82,880
124 Czech Republic 78,866
125 Panama 78,200
126 Sierra Leone 71,740
127 Ireland 70,280
128 Georgia 69,700
129 Sri Lanka 65,610
130 Lithuania 65,200
131 Latvia 64,589
132 Svalbard 62,049
133 Togo 56,785
134 Croatia 56,542
135 Bosnia and Herzegovina 51,129
136 Costa Rica 51,100
137 Slovakia 48,845
138 Dominican Republic 48,730
139 Bhutan 47,000
140 Estonia 45,226
141 Denmark 43,094
142 Netherlands 41,526
143 Switzerland 41,290
144 Guinea-Bissau 36,120
145 Taiwan 35,980
146 Moldova 33,843
147 Belgium 30,510
148 Lesotho 30,355
149 Armenia 29,800
150 Albania 28,748
151 Solomon Islands 28,450
152 Equatorial Guinea 28,051
153 Burundi 27,830
154 Haiti 27,750
155 Rwanda 26,338
156 Macedonia, The Former Yugoslav Republic of 25,333
157 Djibouti 23,000
158 Belize 22,966
159 El Salvador 21,040
160 Israel 20,770
161 Slovenia 20,273
162 New Caledonia 19,060
163 Fiji 18,270
164 Kuwait 17,820
165 Swaziland 17,363
166 East Timor 15,007
167 Bahamas, The 13,940
168 Vanuatu 12,200
169 Falkland Islands (Islas Malvinas) 12,173
170 Qatar 11,437
171 Gambia, The 11,300
172 Jamaica 10,991
173 Lebanon 10,400
174 Cyprus 9,250
175 Puerto Rico 9,104
176 French Southern and Antarctic Lands 7,829
177 West Bank 5,860
178 Brunei 5,770
179 Trinidad and Tobago 5,128
180 French Polynesia 4,167
181 Cape Verde 4,033
182 South Georgia and the South Sandwich Islands 3,903
183 Samoa 2,944
184 Luxembourg 2,586
185 Reunion 2,517
186 Comoros 2,170
187 Mauritius 2,040
188 Guadeloupe 1,780
189 Faroe Islands 1,399
190 Martinique 1,100
191 Hong Kong 1,092
192 Sao Tome and Principe 1,001
193 Netherlands Antilles 960
194 Kiribati 811
195 Dominica 754
196 Tonga 748
197 Micronesia, Federated States of 702
198 Singapore 693
199 Bahrain 665
200 Saint Lucia 616
201 Man, Isle of 572
202 Guam 549
203 Northern Mariana Islands 477
204 Andorra 468
205 Palau 458
206 Seychelles 455
207 Antigua and Barbuda 443
208 Barbados 431
209 Turks and Caicos Islands 430
210 Heard Island and McDonald Islands 412
211 Saint Helena 410
212 Saint Vincent and the Grenadines 389
213 Mayotte 374
214 Jan Mayen 373
215 Gaza Strip 360
216 Virgin Islands 352
217 Grenada 344
218 Malta 316
219 Maldives 300
220 Wallis and Futuna 274
221 Cayman Islands 262
222 Saint Kitts and Nevis 261
223 Niue 260
224 Saint Pierre and Miquelon 242
225 Cook Islands 240
226 American Samoa 199
227 Aruba 193
228 Marshall Islands 181
229 Liechtenstein 160
230 British Virgin Islands 153
231 Christmas Island 135
232 Jersey 116
233 Anguilla 102
234 Montserrat 102
235 Guernsey 78
236 San Marino 61
237 British Indian Ocean Territory 60
238 Bouvet Island 59
239 Bermuda 53
240 Pitcairn Islands 47
241 Norfolk Island 35
242 Europa Island 28
243 Tuvalu 26
244 Macau 25
245 Nauru 21
246 Cocos (Keeling) Islands 14
247 Palmyra Atoll 12
248 Tokelau 10
249 Gibraltar 7
250 Wake Island 7
251 Midway Islands 6
252 Clipperton Island 6
253 Navassa Island 5
254 Ashmore and Cartier Islands 5
255 Glorioso Islands 5
256 Spratly Islands 5
257 Jarvis Island 5
258 Juan de Nova Island 4
259 Coral Sea Islands 3
260 Johnston Atoll 3
261 Monaco 2
262 Howland Island 2
263 Baker Island 1
264 Kingman Reef 1
265 Tromelin Island 1
266 Holy See (Vatican City) 0
267 Bassas da India 0
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2150
Rank Country Telephones - main lines in use Date of Information
1 United States 194,000,000 1997
2 China 135,000,000 2000
3 Japan 60,381,000 1997
4 Germany 50,900,000 March 2001
5 United Kingdom 34,878,000 1997
6 France 34,860,000 yearend 1998
7 Russia 30,000,000 1998
8 India 27,700,000 October 2000
9 Italy 25,000,000 1999
10 Korea, South 24,000,000 2000
11 Canada 20,802,900 1999
12 Turkey 19,500,000 1999
13 Spain 17,336,000 1999
14 Brazil 17,039,000 1997
15 Taiwan 12,490,000 September 2000
16 Mexico 12,332,000 2000
17 Australia 10,050,000 2000
18 Ukraine 9,450,000 April 1999
19 Netherlands 9,132,400 1999
20 Poland 8,070,000 1998
21 Argentina 7,500,000 1998
22 Philippines 6,980,000 2001
23 Iran 6,313,000 1997
24 Sweden 6,017,000 December 1998
25 Thailand 5,600,000 2000
26 Indonesia 5,588,310 1998
27 Colombia 5,433,565 December 1997
28 Greece 5,431,000 1997
29 Portugal 5,300,000 yearend 1998
30 South Africa 5,000,000 2001
31 Switzerland 4,820,000 1998
32 Denmark 4,785,000 1997
33 Belgium 4,769,000 1997
34 Malaysia 4,600,000 2000
35 Austria 4,000,000 2001
36 Egypt 3,971,500 December 1998
37 Saudi Arabia 3,900,000 2002 est.
38 Czech Republic 3,869,000 2000
39 Hong Kong 3,839,000 1999
40 Romania 3,777,000 1997
41 Bulgaria 3,186,731 2001
42 Hungary 3,095,000 1997
43 Pakistan 2,861,000
44 Finland 2,847,900 2001
45 Israel 2,800,000 1999
46 Norway 2,735,000 1998
47 Chile 2,603,000 1998
48 Venezuela 2,600,000 1998
49 Vietnam 2,600,000 2000
50 Belarus 2,313,000 1997
51 Algeria 2,300,000 1998
52 Serbia and Montenegro 2,017,000 1995
53 Uzbekistan 1,980,000 1999
54 Singapore 1,950,000 2000
55 Slovakia 1,934,558 1998
56 Kazakhstan 1,920,000 2001
57 New Zealand 1,920,000 2000
58 Peru 1,800,000 2000
59 Croatia 1,721,139 2000
60 Ireland 1,600,000 2002
61 Morocco 1,391,000 1998
62 Puerto Rico 1,322,000 1997
63 Syria 1,313,000 1997
64 Lithuania 1,142,000 2001
65 Ecuador 1,115,272 1999
66 Korea, North 1,100,000 1997
67 Uruguay 929,141 2001
68 United Arab Emirates 915,223 1998
69 Azerbaijan 865,000 2002
70 Latvia 734,693 2000
71 Slovenia 722,000 1997
72 Dominican Republic 709,000 1997
73 Lebanon 700,000 1999
74 Iraq 675,000
75 Guatemala 665,061 June 2000
76 Tunisia 654,000 1997
77 Moldova 627,000 1997
78 Georgia 620,000 1997
79 Armenia 600,000 2002
80 Rwanda 600,000 2002
81 Estonia 501,691 2000
82 Bangladesh 500,000 2000
83 Libya 500,000 1998
84 Nigeria 500,000 2000 est.
85 Sri Lanka 494,509 1998
86 Cuba 473,031 2000
87 Costa Rica 450,000
88 Kuwait 412,000 1997
89 Macedonia, The Former Yugoslav Republic of 408,000 1997
90 Cyprus 405,000
91 Jordan 403,000 1997
92 Sudan 400,000 2000
93 Panama 396,000 1997
94 El Salvador 380,000 1998
95 Tajikistan 363,000 1997
96 Turkmenistan 363,000 1997
97 Jamaica 353,000 1996
98 Kyrgyzstan 351,000 1997
99 Bolivia 327,600 1996
100 Luxembourg 314,700 1999
101 Kenya 310,000 2001
102 Bosnia and Herzegovina 303,000 1997
103 Yemen 291,359 1999
104 Paraguay 290,475 2001
105 Mauritius 280,900 2000
106 Reunion 268,500 1999
107 Cote d''Ivoire 263,700 2000
108 Trinidad and Tobago 252,000 1999
109 Burma 250,000 2000
110 Ghana 240,000 2001
111 Nepal 236,816 January 2000
112 Senegal 234,916 2001
113 Honduras 234,000 1997
114 Ethiopia 231,900 2000
115 Zimbabwe 212,000 1997
116 Oman 201,000 1997
117 Iceland 196,984 2001
118 Malta 187,000 1997
119 Macau 176,902 November 2001
120 Guadeloupe 171,000 1996
121 Martinique 170,000 1997
122 Bahrain 152,000 1997
123 Qatar 142,000 1997
124 Nicaragua 140,000 1996
125 Botswana 131,000 September 2001
126 Zambia 130,000 2002
127 Tanzania 127,000 1998
128 Albania 120,000 2001
129 Namibia 110,200 2000
130 Barbados 108,000 1997
131 Mongolia 104,100 1999
132 Bahamas, The 96,000 1997
133 Gaza Strip 95,729 1997
134 West Bank 95,729 1997
135 Cameroon 95,000 2001
136 Mozambique 90,000 2001
137 Guam 84,134 1998
138 Cyprus 83,162
139 Fiji 80,901 1999
140 Brunei 79,000 1996
141 Netherlands Antilles 76,000 1995
142 Angola 72,000 1998
143 Guyana 70,000 2000
144 Jersey 65,500 1997
145 Virgin Islands 65,000 1997
146 Suriname 64,000 1997
147 Papua New Guinea 61,152 1999
148 Cape Verde 60,935 2002
149 Haiti 60,000 1997
150 Madagascar 55,000 2000
151 Burkina Faso 53,200 2000
152 Bermuda 52,000 1997
153 French Polynesia 52,000 1997
154 Benin 51,000 2000
155 Man, Isle of 51,000 1999
156 French Guiana 47,000 1997
157 New Caledonia 47,000 1997
158 Malawi 45,000 2000
159 Mali 45,000 2000
160 Guernsey 44,000 1996
161 Gabon 39,000 1998
162 Swaziland 38,500 2001
163 Guinea 37,000 1998
164 Saint Lucia 37,000 1997
165 Aruba 33,000 1997
166 Andorra 32,946 December 1998
167 Gambia, The 31,900 2000
168 Monaco 31,027 1995
169 Belize 31,000 1997
170 Eritrea 30,000 2001
171 Afghanistan 29,000
172 Antigua and Barbuda 28,000 1996
173 Grenada 27,000 1997
174 Mauritania 26,500 2001
175 Greenland 25,617 yearend 1999
176 Laos 25,000 1997
177 Sierra Leone 25,000 2001
178 Togo 25,000 1997
179 Faroe Islands 24,851 1999
180 Lesotho 22,200 2000
181 Congo, Republic of the 22,000 1998
182 Cambodia 21,800 mid-1998
183 Northern Mariana Islands 21,000 1996
184 Maldives 21,000 1999
185 Saint Vincent and the Grenadines 20,500 1998
186 Liechtenstein 20,072 2000
187 Congo, Democratic Republic of the 20,000 2000
188 Niger 20,000 2001
189 Seychelles 19,635 1997
190 Cayman Islands 19,000 1995
191 Dominica 19,000 1996
192 Gibraltar 19,000 1997
193 Burundi 18,000 2002
194 San Marino 18,000 1998
195 Saint Kitts and Nevis 17,000 1997
196 Somalia 15,000 2000
197 American Samoa 13,000 1997
198 Mayotte 12,000 1998
199 Micronesia, Federated States of 11,000 2001
200 Djibouti 10,000 2002
201 British Virgin Islands 10,000 1996
202 Guinea-Bissau 10,000 2001
203 Chad 9,700 1999
204 Central African Republic 9,500 2000
205 Samoa 8,183 1998
206 Solomon Islands 8,000 1997
207 Tonga 8,000 1996
208 Comoros 7,000 2000
209 Liberia 6,700 2000
210 Palau 6,700 2002
211 Bhutan 6,000 1997
212 Equatorial Guinea 6,000 1998
213 Vanuatu 5,500 1998
214 Cook Islands 5,000 1997
215 Anguilla 4,974 2000
216 Sao Tome and Principe 4,600 2000
217 Marshall Islands 4,186 2001
218 Montserrat 4,000 1997
219 Saint Pierre and Miquelon 4,000 1997
220 Kiribati 3,800 1999
221 Turks and Caicos Islands 3,000 1994
222 Nauru 2,000 1996
223 Saint Helena 2,000 1997
224 Wallis and Futuna 1,125 1994
225 Norfolk Island 1,087 1983
226 Tuvalu 1,000 1997
227 Niue 376 1991
228 Cocos (Keeling) Islands 287 1992
229 Pitcairn Islands 1 1997
230 Antarctica 0 2001
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2151
Rank Country Telephones - mobile cellular Date of Information
1 United States 69,209,000 1998
2 China 65,000,000 January 2001
3 Japan 63,880,000 2000
4 Germany 55,300,000 June 2001
5 United Kingdom 43,500,000 yearend 1998
6 Korea, South 28,000,000 September 2000
7 Italy 20,500,000 1999
8 Russia 19,000,000 January 2003
9 Turkey 17,100,000 2001
10 Taiwan 16,000,000 September 2000
11 Poland 13,000,000 2002
12 Philippines 11,350,000 2001
13 France 11,078,000 yearend 1998
14 Canada 8,751,300 1997
15 Australia 8,600,000 2000
16 Spain 8,394,000 1999
17 South Africa 7,060,000 2001
18 Austria 6,000,000 2001
19 Malaysia 5,000,000 2000
20 Brazil 4,400,000 1997
21 Czech Republic 4,346,000 2000
22 Netherlands 4,081,891 April 1999
23 Sweden 3,835,000 October 1998
24 Finland 3,728,600 2001
25 Hong Kong 3,700,000 December 1999
26 Thailand 3,100,000 2002
27 Portugal 3,074,194 1999
28 Argentina 3,000,000 December 1999
29 Ireland 3,000,000 2002
30 India 2,930,000 November 2000
31 Saudi Arabia 2,900,000 2002 est.
32 Singapore 2,740,000 2000
33 Israel 2,500,000 1999
34 New Zealand 2,200,000 2000
35 Norway 2,080,408 1998
36 Mexico 2,020,000 1998
37 Venezuela 2,000,000 1998
38 Switzerland 1,967,000 1999
39 Colombia 1,800,229 December 1998
40 Denmark 1,444,016 1997
41 Croatia 1,300,000 2001
42 Hungary 1,269,000 July 1999
43 Indonesia 1,070,000 1998
44 Bulgaria 1,054,000 2001
45 Slovenia 1,000,000 2000
46 United Arab Emirates 1,000,000 1999
47 Belgium 974,494 1997
48 Chile 944,225 1998
49 Greece 937,700 1997
50 Azerbaijan 800,000 2002
51 Slovakia 736,662 April 1999
52 Vietnam 730,155 2000
53 Estonia 711,000 yearend 2001
54 Guatemala 663,296 September 2000
55 Romania 645,500 1999
56 Lebanon 580,000 1999
57 Kenya 540,000 2001
58 Paraguay 510,000 2001
59 Peru 504,995 1998
60 Lithuania 500,000 2001
61 Cote d''Ivoire 450,000 2000
62 Latvia 401,263 2000
63 Kazakhstan 400,000 2001
64 Ecuador 384,000 1999
65 Egypt 380,000 1999
66 Senegal 373,965 2001
67 Uruguay 350,000 2001
68 Cameroon 300,000 2002
69 Mozambique 287,000 2002
70 Bangladesh 283,000 2000
71 Botswana 270,000 September 2001
72 Iran 265,000 August 1998
73 Albania 250,000 2001
74 Iceland 248,131 2001
75 Ukraine 236,000 1998
76 Sri Lanka 228,604 1999
77 Luxembourg 215,741 2000
78 Kuwait 210,000 1997
79 Nigeria 200,000 2001
80 Reunion 197,000 September 2000
81 Georgia 185,500 2000
82 Mauritius 180,000 2000
83 Puerto Rico 169,265 1996
84 Macau 158,251 November 2001
85 Pakistan 158,000 1998
86 Ghana 150,000 2001
87 Costa Rica 143,000 2000
88 Dominican Republic 130,149 1997
89 Uzbekistan 130,000 2003
90 Gabon 120,000 2000
91 Morocco 116,645 1998
92 Bolivia 116,000 1997
93 Zimbabwe 111,000 2001
94 Mongolia 110,000 2001
95 Zambia 90,000 2002
96 Serbia and Montenegro 87,000 1997
97 Namibia 82,000 2000 est.
98 Rwanda 81,000 2002
99 Cambodia 80,000 2000
100 Cyprus 70,000
101 Cyprus 68,000
102 Madagascar 63,100 2000
103 Oman 59,822 1997
104 Bahrain 58,543 1997
105 Benin 55,500 2000
106 Guam 55,000 1998
107 Jamaica 54,640 1996
108 Armenia 50,000 2002
109 Tunisia 50,000 1998
110 Malawi 49,000 2000
111 Swaziland 45,000 2001
112 Brunei 43,524 1996
113 Qatar 43,476 1997
114 El Salvador 40,163 1997
115 Mali 40,000 2001
116 Mauritania 35,000 2001
117 Algeria 33,500 1999
118 Yemen 32,042 2000
119 Burundi 30,000 2002
120 Sierra Leone 30,000 2001
121 Tanzania 30,000 1999
122 Cape Verde 28,119 2002
123 Angola 25,800 2000
124 Burkina Faso 25,200 2000
125 Lesotho 21,600 2000
126 Guinea 21,567 1998
127 Libya 20,000 1998
128 Sudan 20,000 2000
129 Ethiopia 17,800 2000
130 Malta 17,691 1997
131 Trinidad and Tobago 17,411 1997
132 Panama 17,000 1997
133 Seychelles 16,316 1999
134 Congo, Democratic Republic of the 15,000 2000
135 Martinique 15,000 1997
136 Honduras 14,427 1997
137 Andorra 14,117 December 1998
138 Netherlands Antilles 13,977 1996
139 New Caledonia 13,040 1998
140 Greenland 12,676 yearend 1999
141 Macedonia, The Former Yugoslav Republic of 12,362 1997
142 Guernsey 12,000 1997
143 Jordan 11,500 1995
144 Faroe Islands 10,761 1999
145 Bosnia and Herzegovina 9,000 1997
146 Uganda 9,000 1998
147 Burma 8,492 1997
148 Belarus 8,167 1997
149 Barb','6554638841239e4aa1ae5498edf7957b4576b6c3e4e30fd43de4174b3dd1471c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0c7983d2ee5d799dbc0996e8a814404a88bbafe0b40c7069c517738ee58ed5a',2003,'YE','Yemen','communications',810,'ados 8,013 1997
150 Bermuda 7,980 1996
151 Nicaragua 7,911 1997
152 Sao Tome and Principe 6,942 1997
153 Niger 6,700 2002
154 Bahamas, The 6,152 1997
155 Guyana 6,100 2000
156 Gambia, The 5,624 2000
157 Chad 5,500 2000
158 French Polynesia 5,427 1997
159 Fiji 5,200 1997
160 Djibouti 5,000 2002
161 Laos 4,915 1997
162 Jersey 4,400 1997
163 Turkmenistan 4,300 1998
164 Suriname 4,090 1997
165 Aruba 3,402 1997
166 Congo, Republic of the 3,300 1998
167 Papua New Guinea 3,053 1996
168 Belize 3,023 1997
169 San Marino 3,010 1998
170 Togo 2,995 1997
171 Cuba 2,994 1997
172 American Samoa 2,550 1997
173 Cayman Islands 2,534 1995
174 Tajikistan 2,500 1997
175 Moldova 2,200 1997
176 Virgin Islands 2,000 1992
177 Anguilla 1,629 2000
178 Gibraltar 1,620 1997
179 Saint Lucia 1,600 1997
180 Samoa 1,545 February 1998
181 Antigua and Barbuda 1,300 1996
182 Maldives 1,290 1997
183 Northern Mariana Islands 1,200 1995
184 Palau 1,000 2002
185 Grenada 976 1997
186 Central African Republic 710 1998
187 Solomon Islands 658 1997
188 Marshall Islands 489 2001
189 Dominica 461 1996
190 Nauru 450 1994
191 Vanuatu 310 2000
192 Tonga 302 1996
193 Equatorial Guinea 300 1998
194 Saint Kitts and Nevis 205 1997
195 Montserrat 70 1994
196 Cook Islands 0 1994
197 Liberia 0 1998
198 Niue 0 1991
199 Guinea-Bissau 0 2001
200 Turks and Caicos Islands 0 1994
201 Tuvalu 0 1994
202 Western Sahara 0 1999
203 Wallis and Futuna 0 1994
204 Tokelau 0 2001
205 Saint Helena 0 1997
206 Saint Pierre and Miquelon 0 1994
207 Norfolk Island 0 1983
208 Mayotte 0 2000
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2153
Rank Country Internet users Date of Information
1 World 604,111,719
2 United States 165,750,000 2002
3 Japan 56,000,000 2002
4 China 45,800,000 2002
5 United Kingdom 34,300,000 2002
6 Germany 32,100,000 2002
7 Korea, South 25,600,000 2002
8 Italy 19,250,000 2001
9 Russia 18,000,000 2002
10 France 16,970,000 2002
11 Canada 16,840,000 2002
12 Brazil 13,980,000 2002
13 Taiwan 11,600,000 2001
14 Australia 10,630,000 2002
15 Netherlands 9,730,000 2002
16 Spain 7,890,000 2002
17 India 7,000,000 2002
18 Poland 6,400,000 2001
19 Sweden 6,020,000 2002
20 Malaysia 5,700,000 2002
21 Philippines 4,500,000 2002
22 Indonesia 4,400,000 2002
23 Portugal 4,400,000 2002
24 Hong Kong 4,350,000 2002
25 Argentina 3,880,000 2001
26 Switzerland 3,850,000 2002
27 Belgium 3,760,000 2002
28 Austria 3,700,000 2002
29 Mexico 3,500,000 2002
30 Denmark 3,370,000 2002
31 Chile 3,100,000 2002
32 South Africa 3,068,000 2002
33 Peru 3,000,000 2002
34 Czech Republic 2,690,000 2001
35 Finland 2,690,000 2002
36 Norway 2,680,000 2002
37 Turkey 2,500,000 2002
38 Singapore 2,310,000 2002
39 New Zealand 2,060,000 2002
40 Israel 1,940,000 2001
41 Saudi Arabia 1,453,000 2002
42 Greece 1,400,000 2002
43 Iran 1,326,000 2002 est.
44 Ireland 1,310,000 2002
45 Venezuela 1,300,000 2002
46 Hungary 1,200,000 2001
47 Thailand 1,200,000 2001
48 Pakistan 1,200,000 2000
49 Colombia 1,150,000 2002
50 Romania 1,000,000 2002
51 United Arab Emirates 900,000 2002
52 Ukraine 750,000 2001
53 Slovakia 700,000 2000
54 Egypt 600,000 2002
55 Puerto Rico 600,000 2002
56 Slovenia 600,000 2001
57 Bulgaria 585,000 2001
58 Kenya 500,000 2002
59 Croatia 480,000 2001
60 Estonia 429,700 2002
61 Belarus 422,000 2002
62 Morocco 400,000 2002
63 Vietnam 400,000 2002
64 Serbia and Montenegro 400,000 2001
65 Uruguay 400,000 2002
66 Tunisia 400,000 2002
67 Costa Rica 384,000 2002
68 Lithuania 341,000 2001
69 Ecuador 328,000 2002
70 Latvia 312,000 2001
71 Lebanon 300,000 2001
72 Tanzania 300,000 2002
73 Iceland 220,000 2002
74 Jordan 212,000 2002
75 Ghana 200,000 2002
76 Guatemala 200,000 2002
77 Kuwait 200,000 2002
78 Dominican Republic 186,000 2002
79 Algeria 180,000 2001
80 Mauritius 158,000 2002
81 Bangladesh 150,000 2002
82 Cyprus 150,000 2002
83 Bahrain 140,200 2002
84 Papua New Guinea 135,000 2001
85 Sri Lanka 121,500 2001
86 Cuba 120,000 2002
87 Oman 120,000 2002
88 Trinidad and Tobago 120,000 2002
89 Macau 101,000 2002
90 Jamaica 100,000 2002
91 Nigeria 100,000 2000
92 Zimbabwe 100,000 2002
93 Uzbekistan 100,000 2002
94 Senegal 100,000 2002
95 Macedonia, The Former Yugoslav Republic of 100,000 2001
96 Luxembourg 100,000 2001
97 Kazakhstan 100,000 2002
98 Guyana 95,000 2002
99 Bolivia 78,000 2000
100 Qatar 75,000 2001
101 Cote d''Ivoire 70,000 2002
102 Angola 60,000 2002
103 Gaza Strip 60,000
104 West Bank 60,000
105 Uganda 60,000 2002
106 Syria 60,000 2002
107 Nepal 60,000 2002
108 Malta 59,000 2002
109 Sudan 56,000 2002
110 Kyrgyzstan 51,600 2001
111 Togo 50,000 2002
112 Bosnia and Herzegovina 45,000 2002
113 Panama 45,000 2000
114 Cameroon 45,000 December 2001
115 Namibia 45,000 2002
116 El Salvador 40,000 2000
117 Honduras 40,000 2000
118 Mongolia 40,000 2002
119 Brunei 35,000 2002
120 Madagascar 35,000 2002
121 Malawi 35,000 2002
122 Botswana 33,000 2001
123 Armenia 30,000 2001
124 Haiti 30,000 2002
125 Mali 30,000 2002
126 Azerbaijan 25,000 2002
127 Zambia 25,000 2002
128 Burkina Faso 25,000 2002
129 Georgia 25,000 2002
130 Benin 25,000 2002
131 Bermuda 25,000 2000
132 Andorra 24,500 2001
133 Aruba 24,000 2002
134 New Caledonia 24,000 2001
135 Mozambique 22,500 2000
136 Ethiopia 20,000 2002
137 Nicaragua 20,000 2000
138 Paraguay 20,000 2000
139 Rwanda 20,000 2002
140 Sierra Leone 20,000 2001
141 Libya 20,000 2001
142 Greenland 20,000 2002
143 Belize 18,000 2002
144 Gabon 18,000 2002
145 Yemen 17,000 2002
146 Bahamas, The 16,900 2002
147 French Polynesia 16,000 2002
148 Fiji 15,000 2002
149 Moldova 15,000 2000
150 Guinea 15,000 2002
151 Suriname 14,500 2002
152 Iraq 12,500 2001
153 Albania 12,000 2001
154 Virgin Islands 12,000 2000
155 Niger 12,000 2002
156 Cape Verde 12,000 2002
157 Burma 10,000 2002
158 Reunion 10,000 2000
159 Laos 10,000 2002
160 Eritrea 10,000 2002
161 Cambodia 10,000 2002
162 Seychelles 9,000 2002
163 Sao Tome and Principe 9,000 2002
164 Solomon Islands 8,400 2002
165 Mauritania 7,500 2001
166 Swaziland 7,000 2002
167 Barbados 6,000 2000
168 Burundi 6,000 2002
169 Maldives 6,000 2001
170 Congo, Democratic Republic of the 6,000 2002
171 Grenada 5,200 2002
172 Antigua and Barbuda 5,000 2001
173 Gambia, The 5,000 2001
174 Guam 5,000 2000
175 Martinique 5,000 2000
176 Tajikistan 5,000 2002
177 Lesotho 5,000 2002
178 Chad 4,000 2002
179 Guinea-Bissau 4,000 2002
180 Guadeloupe 4,000 2000
181 Saint Vincent and the Grenadines 3,500 2001
182 Djibouti 3,300 2002
183 Faroe Islands 3,000 2000
184 Vanuatu 3,000 2000
185 Samoa 3,000 2002
186 Saint Lucia 3,000 2000
187 Bhutan 2,500 2002
188 Comoros 2,500 2002
189 Central African Republic 2,000 2002
190 Dominica 2,000 2000
191 Micronesia, Federated States of 2,000 2000
192 Netherlands Antilles 2,000 2000
193 Turkmenistan 2,000 2000
194 Saint Kitts and Nevis 2,000 2000
195 French Guiana 2,000 2000
196 Kiribati 1,000 2000
197 Tonga 1,000 2000
198 Anguilla 919 2000
199 Equatorial Guinea 900 2002
200 Marshall Islands 900 2002
201 Congo, Republic of the 500 2001
202 Liberia 500 2000
203 Somalia 200 2000
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2155
Rank Country HIV/AIDS - adult prevalence rate(%) Date of Information
1 Botswana 38.80 2001 est.
2 Zimbabwe 33.70 2001 est.
3 Swaziland 33.40 2001 est.
4 Lesotho 31.00 2001 est.
5 Namibia 22.50 2001 est.
6 Zambia 21.50 2001 est.
7 South Africa 20.10 2001 est.
8 Kenya 15.00 2001 est.
9 Malawi 15.00 2001 est.
10 Mozambique 13.00 2001 est.
11 Central African Republic 12.90 2001 est.
12 Cameroon 11.80 2001 est.
13 Djibouti 11.75 2001 est.
14 Cote d''Ivoire 9.70 2001 est.
15 Gabon 9.00 2001 est.
16 Liberia 9.00 2001 est.
17 Rwanda 8.90 2001 est.
18 Burundi 8.30 2001 est.
19 Tanzania 7.80 2001 est.
20 Congo, Republic of the 7.20 2001 est.
21 Sierra Leone 7.00 2001 est.
22 Burkina Faso 6.50 2001 est.
23 Ethiopia 6.40 2001 est.
24 Haiti 6.10 2001 est.
25 Togo 6.00 2001 est.
26 Nigeria 5.80 2001 est.
27 Angola 5.50 2001 est.
28 Uganda 5.00 2001 est.
29 Congo, Democratic Republic of the 4.90 2001 est.
30 Niger 4.00 2001 est.
31 Benin 3.60 2001 est.
32 Chad 3.60 2001 est.
33 Bahamas, The 3.50 2001 est.
34 Equatorial Guinea 3.40 2001 est.
35 Ghana 3.00 2001 est.
36 Eritrea 2.80 2001 est.
37 Guinea-Bissau 2.80 2001 est.
38 Cambodia 2.70 2001 est.
39 Guyana 2.70 2001 est.
40 Sudan 2.60 2001 est.
41 Dominican Republic 2.50 2001 est.
42 Trinidad and Tobago 2.50 2001 est.
43 Belize 2.00 2001 est.
44 Burma 1.99 2001 est.
45 Mauritania 1.80 2001 est.
46 Thailand 1.80 2001 est.
47 Mali 1.70 2001 est.
48 Gambia, The 1.60 2001 est.
49 Honduras 1.60 2001 est.
50 Guinea 1.54 2001 est.
51 Panama 1.50 2001 est.
52 Barbados 1.20 2001 est.
53 Jamaica 1.20 2001 est.
54 Suriname 1.20 2001 est.
55 Estonia 1.00 2001 est.
56 Ukraine 1.00 2001 est.
57 Somalia 1.00 2001 est.
58 Guatemala 1.00 2001 est.
59 Russia 0.90 2001 est.
60 India 0.80 2001 est.
61 Argentina 0.70 2001 est.
62 Papua New Guinea 0.70 2001 est.
63 Brazil 0.70 2001 est.
64 Costa Rica 0.60 2001 est.
65 United States 0.60 2001 est.
66 El Salvador 0.60 2001 est.
67 Nepal 0.50 2001 est.
68 Senegal 0.50 2001 est.
69 Switzerland 0.50 2001 est.
70 Venezuela 0.50 2001 est.
71 Spain 0.50 2001 est.
72 Portugal 0.50 2001 est.
73 Colombia 0.40 2001 est.
74 Latvia 0.40 2001 est.
75 Malaysia 0.40 2001 est.
76 Peru 0.40 2001 est.
77 Italy 0.40 2001 est.
78 Bahrain 0.30 2001 est.
79 Vietnam 0.30 2001 est.
80 Uruguay 0.30 2001 est.
81 Mexico 0.30 2001 est.
82 Madagascar 0.30 2001 est.
83 Ecuador 0.30 2001 est.
84 Chile 0.30 2001 est.
85 Canada 0.30 2001 est.
86 France 0.30 2001 est.
87 Cyprus 0.30 2001 est.
88 Belarus 0.30 2001 est.
89 Armenia 0.20 2001 est.
90 Belgium 0.20 2001 est.
91 Serbia and Montenegro 0.20 2001 est.
92 Singapore 0.20 2001 est.
93 Nicaragua 0.20 2001 est.
94 Netherlands 0.20 2001 est.
95 Moldova 0.20 2001 est.
96 Libya 0.20 2001 est.
97 Luxembourg 0.20 2001 est.
98 Iceland 0.20 2001 est.
99 Greece 0.20 2001 est.
100 Denmark 0.20 2001 est.
101 Brunei 0.20 2001 est.
102 Austria 0.20 2001 est.
103 United Arab Emirates 0.18 2001 est.
104 Comoros 0.12 2001 est.
105 Kuwait 0.12 2001 est.
106 Paraguay 0.11 2001 est.
107 Algeria 0.10 2001 est.
108 Australia 0.10 2001 est.
109 Bosnia and Herzegovina 0.10 2001 est.
110 Bhutan 0.10 2001 est.
111 Cuba 0.10 2001 est.
112 Hong Kong 0.10 2001 est.
113 Germany 0.10 2001 est.
114 Georgia 0.10 2001 est.
115 Fiji 0.10 2001 est.
116 Finland 0.10 2001 est.
117 Czech Republic 0.10 2001 est.
118 Ireland 0.10 2001 est.
119 Egypt 0.10 2001 est.
120 China 0.10 2001 est.
121 Tajikistan 0.10 2001 est.
122 Sweden 0.10 2001 est.
123 Slovenia 0.10 2001 est.
124 Philippines 0.10 2001 est.
125 Romania 0.10 2001 est.
126 Poland 0.10 2001 est.
127 Pakistan 0.10 2001 est.
128 New Zealand 0.10 2001 est.
129 Morocco 0.10 2001 est.
130 Yemen 0.10 2001 est.
131 Uzbekistan 0.10 2001 est.
132 United Kingdom 0.10 2001 est.
133 Turkmenistan 0.10 2001 est.
134 Turkey 0.10 2001 est.
135 Macedonia, The Former Yugoslav Republic of 0.10 2001 est.
136 Mongolia 0.10 2001 est.
137 Slovakia 0.10 2001 est.
138 Lithuania 0.10 2001 est.
139 Laos 0.10 2001 est.
140 Kazakhstan 0.10 2001 est.
141 Korea, South 0.10 2001 est.
142 Kyrgyzstan 0.10 2001 est.
143 Norway 0.10 2001 est.
144 Maldives 0.10 2001 est.
145 Oman 0.10 2001 est.
146 Malta 0.10 2001 est.
147 Mauritius 0.10 2001 est.
148 Jordan 0.10 2001 est.
149 Japan 0.10 2001 est.
150 Iraq 0.10 2001 est.
151 Israel 0.10 2001 est.
152 Iran 0.10 2001 est.
153 Indonesia 0.10 2001 est.
154 Hungary 0.10 2001 est.
155 Croatia 0.10 2001 est.
156 Sri Lanka 0.10 2001 est.
157 Bulgaria 0.10 2001 est.
158 Bolivia 0.10 2001 est.
159 Bangladesh 0.10 2001 est.
160 Azerbaijan 0.10 2001 est.
161 Lebanon 0.09 2001 est.
162 Qatar 0.09 2001 est.
163 Tunisia 0.04 2001 est.
164 Cape Verde 0.04
165 Afghanistan 0.01 2001 est.
166 Syria 0.01 2001 est.
167 Saudi Arabia 0.01 2001 est.
168 Svalbard 0.00 2001
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2156
Rank Country HIV/AIDS - people living with HIV/AIDS Date of Information
1 South Africa 5,000,000 2001 est.
2 India 3,970,000 2001 est.
3 Nigeria 3,500,000 2001 est.
4 Kenya 2,500,000 2001 est.
5 Zimbabwe 2,300,000 2001 est.
6 Ethiopia 2,100,000 2001 est.
7 Tanzania 1,500,000 2001 est.
8 Congo, Democratic Republic of the 1,300,000 2001 est.
9 Zambia 1,200,000 2001 est.
10 Mozambique 1,100,000 2001 est.
11 Cameroon 920,000 2001 est.
12 United States 900,000 2001 est.
13 China 850,000 2001 est.
14 Malawi 850,000 2001 est.
15 Cote d''Ivoire 770,000 2001 est.
16 Russia 700,000 2001 est.
17 Thailand 670,000 2001 est.
18 Brazil 610,000 2001 est.
19 Uganda 600,000 2001 est.
20 Burma 530,000 2001 est.
21 Rwanda 500,000 2001 est.
22 Sudan 450,000 2001 est.
23 Burkina Faso 440,000 2001 est.
24 Burundi 390,000 2001 est.
25 Ghana 360,000 2001 est.
26 Lesotho 360,000 2001 est.
27 Angola 350,000 2001 est.
28 Botswana 330,000 2001 est.
29 Central African Republic 250,000 2001 est.
30 Haiti 250,000 2001 est.
31 Ukraine 250,000 2001 est.
32 Namibia 230,000 2001 est.
33 Cambodia 170,000 2001 est.
34 Sierra Leone 170,000 2001 est.
35 Swaziland 170,000 2001 est.
36 Chad 150,000 2001 est.
37 Togo 150,000 2001 est.
38 Mexico 150,000 2001 est.
39 Colombia 140,000 2001 est.
40 Argentina 130,000 2001 est.
41 Vietnam 130,000 2001 est.
42 Spain 130,000 2001 est.
43 Dominican Republic 130,000 2001 est.
44 Liberia 125,000 2001 est.
45 Benin 120,000 2001 est.
46 Indonesia 120,000 2001 est.
47 Congo, Republic of the 110,000 2001 est.
48 Mali 110,000 2001 est.
49 France 100,000 2001 est.
50 Italy 100,000 2001 est.
51 Pakistan 78,000 2001 est.
52 Guatemala 67,000 2001 est.
53 Venezuela 62,000 1999 est.
54 Nepal 58,000 2001 est.
55 Honduras 57,000 2001 est.
56 Canada 55,000 2001 est.
57 Eritrea 55,000 2001 est.
58 Guinea 55,000 1999 est.
59 Peru 53,000 2001 est.
60 Somalia 43,000 2001 est.
61 Malaysia 42,000 2001 est.
62 Germany 41,000 2001 est.
63 Djibouti 37,000 2001 est.
64 United Kingdom 34,000 2001 est.
65 Portugal 27,000 2001 est.
66 Senegal 27,000 2001 est.
67 Panama 25,000 2001 est.
68 El Salvador 24,000 2001 est.
69 Gabon 23,000 1999 est.
70 Madagascar 22,000 2001 est.
71 Chile 20,000 2001 est.
72 Iran 20,000 2001 est.
73 Jamaica 20,000 2001 est.
74 Ecuador 20,000 2001 est.
75 Switzerland 19,000 2001 est.
76 Guyana 18,000 2001 est.
77 Netherlands 17,000 2001 est.
78 Trinidad and Tobago 17,000 2001 est.
79 Guinea-Bissau 17,000 2001 est.
80 Papua New Guinea 17,000 2001 est.
81 Belarus 15,000 2001 est.
82 Bangladesh 13,000 2001 est.
83 Morocco 13,000 2001 est.
84 Australia 12,000 2001 est.
85 Japan 12,000 2001 est.
86 Costa Rica 11,000 2001 est.
87 Serbia and Montenegro 10,000 2001 est.
88 Austria 9,900 2001 est.
89 Yemen 9,900 2001 est.
90 Philippines 9,400 2001 est.
91 Greece 8,800 2001 est.
92 Belgium 8,500 2001 est.
93 Gambia, The 8,400 2001 est.
94 Egypt 8,000 2001 est.
95 Estonia 7,700 2001 est.
96 Puerto Rico 7,397
97 Libya 7,000 2001 est.
98 Mauritania 6,600 1999 est.
99 Romania 6,500 2001 est.
100 Uruguay 6,300 2001 est.
101 Bahamas, The 6,200 2001 est.
102 Kazakhstan 6,000 2001 est.
103 Equatorial Guinea 5,900 2001 est.
104 Nicaragua 5,800 2001 est.
105 Moldova 5,500 2001 est.
106 Latvia 5,000 2001 est.
107 Sri Lanka 4,800 2001 est.
108 Bolivia 4,600 2001 est.
109 Korea, South 4,000 2001 est.
110 Denmark 3,800 2001 est.
111 Suriname 3,700 2001 est.
112 Singapore 3,400 2001 est.
113 Sweden 3,300 2001 est.
114 Cuba 3,200 2001 est.
115 Paraguay 3,000 1999 est.
116 Hungary 2,800 2001 est.
117 Hong Kong 2,600 2001 est.
118 Belize 2,500 2001 est.
119 Armenia 2,400 2001 est.
120 Israel 2,400 1999 est.
121 Ireland 2,400 2001 est.
122 Barbados 1,800 2001 est.
123 Norway 1,800 2001 est.
124 Azerbaijan 1,400 2001 est.
125 Laos 1,400 2001 est.
126 Lithuania 1,300 2001 est.
127 Oman 1,300 2001 est.
128 Finland 1,200 2001 est.
129 New Zealand 1,200 2001 est.
130 Bahrain 1,000
131 Iraq 1,000
132 Jordan 1,000
133 Cyprus 1,000 1999 est.
134 Georgia 900 2001 est.
135 Cape Verde 775
136 Uzbekistan 740 2001 est.
137 Mauritius 700 2001 est.
138 Czech Republic 500 2001 est.
139 Kyrgyzstan 500 2001 est.
140 Bulgaria 346 2001 est.
141 Fiji 300 2001 est.
142 Slovenia 280 2001 est.
143 Iceland 220 2001 est.
144 Croatia 200 2001 est.
145 Tajikistan 200 2001 est.
146 Bhutan 100 1999 est.
147 Turkmenistan 100 1999 est.
148 Maldives 100 2001 est.
149 Brunei 100 2001 est.
150 Slovakia 100 1999 est.
151 Macedonia, The Former Yugoslav Republic of 100 1999 est.
152 Mongolia 100 1999 est.
153 Greenland 100
154 Samoa 12
155 Svalbard 0 2001
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2157
Rank Country HIV/AIDS - deaths Date of Information
1 South Africa 360,000 2001 est.
2 India 310,000 2001 est.
3 Zimbabwe 200,000 2001 est.
4 Kenya 190,000 2001 est.
5 Nigeria 170,000 2001 est.
6 Ethiopia 160,000 2001 est.
7 Tanzania 140,000 2001 est.
8 Congo, Democratic Republic of the 120,000 2001 est.
9 Zambia 120,000 2001 est.
10 Uganda 84,000 2001 est.
11 Malawi 80,000 2001 est.
12 Cote d''Ivoire 75,000 2001 est.
13 Burma 65,000 2001 est.
14 Mozambique 60,000 2001 est.
15 Thailand 55,000 2001 est.
16 Cameroon 53,000 2001 est.
17 Rwanda 49,000 2001 est.
18 Burkina Faso 44,000 2001 est.
19 Burundi 40,000 2001 est.
20 China 30,000 2001 est.
21 Haiti 30,000 2001 est.
22 Ghana 28,000 2001 est.
23 Botswana 26,000 2001 est.
24 Lesotho 25,000 2001 est.
25 Angola 24,000 2001 est.
26 Sudan 23,000 2001 est.
27 Central African Republic 22,000 2001 est.
28 United States 15,000 2001 est.
29 Chad 14,000 2001 est.
30 Namibia 13,000 2001 est.
31 Cambodia 12,000 2001 est.
32 Swaziland 12,000 2001 est.
33 Togo 12,000 2001 est.
34 Congo, Republic of the 11,000 2001 est.
35 Mali 11,000 2001 est.
36 Sierra Leone 11,000 2001 est.
37 Ukraine 11,000 2001 est.
38 Guinea 9,000 2001 est.
39 Russia 9,000 2001 est.
40 Brazil 8,400 2001 est.
41 Benin 8,100 2001 est.
42 Dominican Republic 7,800 2001 est.
43 Vietnam 6,600 2001 est.
44 Niger 6,000 2001 est.
45 Colombia 5,600 2001 est.
46 Guatemala 5,200 2001 est.
47 Liberia 5,000 2001 est.
48 Indonesia 4,600 2001 est.
49 Pakistan 4,500 2001 est.
50 Mexico 4,200 2001 est.
51 Peru 3,900 2001 est.
52 Honduras 3,300 2001 est.
53 Gabon 3,000 2001 est.
54 Malaysia 2,500 2001 est.
55 Senegal 2,500 2001 est.
56 Nepal 2,400 2001 est.
57 Spain 2,300 2001 est.
58 El Salvador 2,100 2001 est.
59 Djibouti 2,000 2001 est.
60 Venezuela 2,000 2001 est.
61 Panama 1,900 2001 est.
62 Argentina 1,800 2001 est.
63 Ecuador 1,700 2001 est.
64 Guyana 1,300 2001 est.
65 Guinea-Bissau 1,200 2001 est.
66 Trinidad and Tobago 1,200 2001 est.
67 Italy 1,100 2001 est.
68 Belarus 1,000 2001 est.
69 Portugal 1,000 2001 est.
70 Jamaica 980 2001 est.
71 Costa Rica 890 2001 est.
72 Papua New Guinea 880 2001 est.
73 Madagascar 870 2001 est.
74 France 800 2001 est.
75 Philippines 720 2001 est.
76 Germany 660 2001 est.
77 Bangladesh 650 2001 est.
78 Bahamas, The 610 2001 est.
79 Mauritania 610 2001 est.
80 Canada 500 2001 est.
81 Uruguay 500 2001 est.
82 United Kingdom 460 2001 est.
83 Japan 430 2001 est.
84 Gambia, The 400 2001 est.
85 Nicaragua 400 2001 est.
86 Equatorial Guinea 370 2001 est.
87 Eritrea 350 2001 est.
88 Romania 350 2001 est.
89 Suriname 330 2001 est.
90 Belize 300 2001 est.
91 Moldova 300 2001 est.
92 Kazakhstan 300 2001 est.
93 Bolivia 290 2001 est.
94 Iran 290 2001 est.
95 Barbados 250 2001 est.
96 Sri Lanka 250 2001 est.
97 Cape Verde 225
98 Chile 220 2001 est.
99 Korea, South 220 2001 est.
100 Paraguay 220 2001 est.
101 Laos 150 2001 est.
102 Singapore 140 2001 est.
103 Cuba 120 2001 est.
104 Netherlands 110 2001 est.
105 Azerbaijan 100 2001 est.
106 Denmark 100 2001 est.
107 Estonia 100 2001 est.
108 Latvia 100 2001 est.
109 Kyrgyzstan 100 2001 est.
110 Israel 100 2001 est.
111 Iceland 100 2001 est.
112 Hungary 100 2001 est.
113 Hong Kong 100 2001 est.
114 Greece 100 2001 est.
115 Georgia 100 2001 est.
116 Finland 100 2001 est.
117 Serbia and Montenegro 100 2001 est.
118 Uzbekistan 100 2001 est.
119 Poland 100 2001 est.
120 New Zealand 100 2001 est.
121 Norway 100 2001 est.
122 Malta 100 2001 est.
123 Mauritius 100 2001 est.
124 Macedonia, The Former Yugoslav Republic of 100 2001 est.
125 Luxembourg 100 2001 est.
126 Slovakia 100 2001 est.
127 Lithuania 100 2001 est.
128 Turkmenistan 100 2001 est.
129 Tajikistan 100 2001 est.
130 Switzerland 100 2001 est.
131 Sweden 100 2001 est.
132 Slovenia 100 2001 est.
133 Ireland 100 2001 est.
134 Belgium 100 2001 est.
135 Austria 100 2001 est.
136 Bulgaria 100 2001 est.
137 Bosnia and Herzegovina 100 2001 est.
138 Australia 100 2001 est.
139 Armenia 100 2001 est.
140 Czech Republic 10 2001 est.
141 Croatia 10 2001 est.
142 Samoa 3
143 Svalbard 0 2001
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2173
Rank Country Oil - production(bbl/day) Date of Information
1 World 75,460,000 2001 est.
2 Saudi Arabia 8,711,000 2001 est.
3 United States 8,054,000 2001 est.
4 Russia 7,286,000 2001 est.
5 Iran 3,804,000 2001 est.
6 Mexico 3,590,000 2001 est.
7 Norway 3,408,000 2001 est.
8 China 3,300,000 2001 est.
9 Venezuela 3,080,000 2001 est.
10 Canada 2,738,000 2001 est.
11 United Arab Emirates 2,566,000 2001 est.
12 United Kingdom 2,541,000 2001 est.
13 Iraq 2,452,000 2001 est.
14 Nigeria 2,256,000 2001 est.
15 Kuwait 2,117,000 2001 est.
16 Brazil 1,561,000 2001 est.
17 Algeria 1,520,000 2001 est.
18 Indonesia 1,451,000 2001 est.
19 Libya 1,429,000 2001 est.
20 Oman 963,800 2001 est.
21 Qatar 864,200 2001 est.
22 Argentina 828,600 2001 est.
23 Egypt 816,900 2001 est.
24 Kazakhstan 798,200 2001 est.
25 Angola 742,400 2001 est.
26 India 732,400 2001 est.
27 Australia 731,000 2001 est.
28 Malaysia 729,200 2001 est.
29 Colombia 614,400 2001 est.
30 Syria 522,700 2001 est.
31 Yemen 438,500 2001 est.
32 Ecuador 421,200 2001 est.
33 Vietnam 356,700 2001 est.
34 Denmark 346,200 2001 est.
35 Azerbaijan 307,200 2001 est.
36 Gabon 301,300 2001 est.
37 Congo, Republic of the 275,000 2001 est.
38 Brunei 217,200 2001 est.
39 Sudan 209,100 2001 est.
40 South Africa 196,200 2001 est.
41 Equatorial Guinea 181,400 2001 est.
42 Thailand 173,800 2001 est.
43 Turkmenistan 162,500 2001 est.
44 Uzbekistan 142,700 2001 est.
45 Romania 127,500 2001 est.
46 Trinidad and Tobago 125,400 2001 est.
47 Peru 95,100 2001 est.
48 Ukraine 86,490 2001 est.
49 Germany 85,860 2001 est.
50 Italy 79,460 2001 est.
51 Cameroon 76,650 2001 est.
52 Tunisia 72,580 2001 est.
53 Papua New Guinea 67,500 2001 est.
54 Pakistan 62,870 2001 est.
55 Cuba 50,000 2001 est.
56 Turkey 48,000 2001 est.
57 Netherlands 46,200 2001 est.
58 Bolivia 44,340 2001 est.
59 Bahrain 43,000 2001 est.
60 New Zealand 42,160 2001 est.
61 Hungary 41,190 2001 est.
62 Belarus 37,000 2001 est.
63 France 34,920 2001 est.
64 Croatia 29,000 2001 est.
65 Congo, Democratic Republic of the 24,000 2001 est.
66 Guatemala 21,080 2001 est.
67 Austria 20,670 2001 est.
68 Japan 17,330 2001 est.
69 Poland 17,180 2001 est.
70 Serbia and Montenegro 15,000 2001 est.
71 Burma 14,170 2001 est.
72 Chile 13,640 2001 est.
73 Cote d''Ivoire 11,000 2001 est.
74 Suriname 10,000 2001 est.
75 Philippines 8,460 2001 est.
76 Czech Republic 7,419 2001 est.
77 Spain 7,099 2001 est.
78 Ghana 7,000 2001 est.
79 Greece 5,992 2001 est.
80 Albania 5,952 2001 est.
81 Estonia 5,100 2001 est.
82 Lithuania 4,594 2001 est.
83 Bangladesh 3,581 2001 est.
84 Georgia 2,000 2001 est.
85 Kyrgyzstan 2,000 2001 est.
86 Barbados 1,271 2001 est.
87 Taiwan 1,100 2001 est.
88 Slovakia 1,000 2001 est.
89 Benin 700 2001 est.
90 Bulgaria 603 2001 est.
91 Morocco 400 2001 est.
92 Tajikistan 250 2001 est.
93 Israel 80 2001 est.
94 Jordan 40 2001 est.
95 Slovenia 20 2001 est.
96 Aruba 0 2001 est.
97 American Samoa 0 2001 est.
98 Armenia 0 2001 est.
99 Bermuda 0 2001 est.
100 Bahamas, The 0 200','2e4b3bec85e78e9188d2bd31b1e1536b68cab6c5b18b257a836499e0bb06fe8f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f844785343c3071809e3882793dc42812522b454bbb2d81a5b3c491c1f5ca85f',2003,'YE','Yemen','communications',811,'1 est.
101 Solomon Islands 0 2001 est.
102 Zimbabwe 0 2001 est.
103 Zambia 0 2001 est.
104 Swaziland 0 2001 est.
105 Samoa 0 2001 est.
106 Western Sahara 0 2001 est.
107 Namibia 0 2001 est.
108 Virgin Islands 0 2001 est.
109 British Virgin Islands 0 2001 est.
110 Saint Vincent and the Grenadines 0 2001 est.
111 Uruguay 0 2001 est.
112 Burkina Faso 0 2001 est.
113 Uganda 0 2001 est.
114 Tanzania 0 2001 est.
115 Sao Tome and Principe 0 2001 est.
116 Togo 0 2001 est.
117 Tonga 0 2001 est.
118 Turks and Caicos Islands 0 2001 est.
119 Switzerland 0 2001 est.
120 Sweden 0 2001 est.
121 Saint Lucia 0 2001 est.
122 Somalia 0 2001 est.
123 Singapore 0 2001 est.
124 Sierra Leone 0 2001 est.
125 Saint Helena 0 2001 est.
126 Senegal 0 2001 est.
127 Seychelles 0 2001 est.
128 Saint Kitts and Nevis 0 2001 est.
129 Saint Pierre and Miquelon 0 2001 est.
130 Rwanda 0 2001 est.
131 Puerto Rico 0 2001 est.
132 Reunion 0 2001 est.
133 Guinea-Bissau 0 2001 est.
134 Latvia 0 2001 est.
135 Lebanon 0 2001 est.
136 Laos 0 2001 est.
137 Korea, South 0 2001 est.
138 Kiribati 0 2001 est.
139 Korea, North 0 2001 est.
140 Kenya 0 2001 est.
141 Jamaica 0 2001 est.
142 Haiti 0 2001 est.
143 Portugal 0 2001 est.
144 Panama 0 2001 est.
145 Paraguay 0 2001 est.
146 Nicaragua 0 2001 est.
147 Netherlands Antilles 0 2001 est.
148 Nauru 0 2001 est.
149 Nepal 0 2001 est.
150 Mozambique 0 2001 est.
151 Maldives 0 2001 est.
152 Malta 0 2001 est.
153 Mauritania 0 2001 est.
154 Mauritius 0 2001 est.
155 Mali 0 2001 est.
156 Macedonia, The Former Yugoslav Republic of 0 2001 est.
157 Malawi 0 2001 est.
158 Montserrat 0 2001 est.
159 Vanuatu 0 2001 est.
160 Niger 0 2001 est.
161 Niue 0 2001 est.
162 New Caledonia 0 2001 est.
163 Mongolia 0 2001 est.
164 Moldova 0 2001 est.
165 Macau 0 2001 est.
166 Martinique 0 2001 est.
167 Madagascar 0 2001 est.
168 Luxembourg 0 2001 est.
169 Lesotho 0 2001 est.
170 Liberia 0 2001 est.
171 Guyana 0 2001 est.
172 Guinea 0 2001 est.
173 Guam 0 2001 est.
174 Guadeloupe 0 2001 est.
175 Greenland 0 2001 est.
176 Grenada 0 2001 est.
177 Gibraltar 0 2001 est.
178 Gambia, The 0 2001 est.
179 Iceland 0 2001 est.
180 Honduras 0 2001 est.
181 Hong Kong 0 2001 est.
182 French Polynesia 0 2001 est.
183 Faroe Islands 0 2001 est.
184 Falkland Islands (Islas Malvinas) 0 2001 est.
185 Fiji 0 2001 est.
186 Finland 0 2001 est.
187 French Guiana 0 2001 est.
188 Ethiopia 0 2001 est.
189 El Salvador 0 2001 est.
190 Eritrea 0 2001 est.
191 Ireland 0 2001 est.
192 Dominican Republic 0 2001 est.
193 Dominica 0 2001 est.
194 Djibouti 0 2001 est.
195 Cyprus 0 2001 est.
196 Cook Islands 0 2001 est.
197 Cape Verde 0 2001 est.
198 Central African Republic 0 2001 est.
199 Costa Rica 0 2001 est.
200 Comoros 0 2001 est.
201 Cayman Islands 0 2001 est.
202 Sri Lanka 0 2001 est.
203 Chad 0 2001 est.
204 Cambodia 0 2001 est.
205 Burundi 0 2001 est.
206 Bhutan 0 2001 est.
207 Bosnia and Herzegovina 0 2001 est.
208 Belize 0 2001 est.
209 Belgium 0 2001 est.
210 Botswana 0 2001 est.
211 Antigua and Barbuda 0 2001 est.
212 Afghanistan 0 2001 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2174
Rank Country Oil - consumption(bbl/day) Date of Information
1 World 76,210,000 2001 est.
2 United States 19,650,000 2001 est.
3 Japan 5,290,000 2001 est.
4 China 4,975,000 2001 est.
5 Germany 2,813,000 2001 est.
6 Russia 2,595,000 2001 est.
7 Brazil 2,199,000 2001 est.
8 Korea, South 2,140,000 2001 est.
9 India 2,130,000 2001 est.
10 France 2,026,000 2001 est.
11 Italy 1,866,000 2001 est.
12 United Kingdom 1,710,000 2001 est.
13 Canada 1,703,000 2001 est.
14 Mexico 1,507,000 2001 est.
15 Spain 1,497,000 2001 est.
16 Saudi Arabia 1,452,000 2001 est.
17 Iran 1,277,000 2001 est.
18 Indonesia 1,045,000 2001 est.
19 Taiwan 988,000 2001 est.
20 Netherlands 895,300 2001 est.
21 Australia 796,500 2001 est.
22 Thailand 785,000 2001 est.
23 Singapore 700,000 2001 est.
24 Turkey 619,500 2001 est.
25 Belgium 595,100 2001 est.
26 Egypt 562,000 2001 est.
27 Venezuela 505,000 2001 est.
28 Argentina 486,000 2001 est.
29 Malaysia 472,000 2001 est.
30 Iraq 460,000 2001 est.
31 South Africa 460,000 2001 est.
32 Poland 424,100 2001 est.
33 Greece 405,700 2001 est.
34 Pakistan 365,000 2001 est.
35 Philippines 343,000 2001 est.
36 Portugal 339,800 2001 est.
37 Sweden 328,600 2001 est.
38 United Arab Emirates 310,000 2001 est.
39 Switzerland 290,400 2001 est.
40 Ukraine 290,000 2001 est.
41 Nigeria 275,000 2001 est.
42 Kuwait 273,000 2001 est.
43 Syria 265,000 2001 est.
44 Austria 262,400 2001 est.
45 Israel 260,000 2001 est.
46 Hong Kong 257,000 2001 est.
47 Colombia 252,000 2001 est.
48 Chile 241,000 2001 est.
49 Belarus 230,000 2001 est.
50 Denmark 218,000 2001 est.
51 Libya 216,000 2001 est.
52 Romania 215,000 2001 est.
53 Finland 211,400 2001 est.
54 Algeria 209,000 2001 est.
55 Kazakhstan 195,000 2001 est.
56 Puerto Rico 190,000 2001 est.
57 Vietnam 185,000 2001 est.
58 Czech Republic 175,700 2001 est.
59 Ireland 174,400 2001 est.
60 Norway 171,100 2001 est.
61 Morocco 167,000 2001 est.
62 Cuba 163,000 2001 est.
63 Peru 161,000 2001 est.
64 Uzbekistan 142,000 2001 est.
65 Hungary 140,700 2001 est.
66 Azerbaijan 140,000 2001 est.
67 New Zealand 132,700 2001 est.
68 Dominican Republic 129,000 2001 est.
69 Ecuador 129,000 2001 est.
70 Lebanon 107,000 2001 est.
71 Jordan 103,000 2001 est.
72 Bulgaria 94,000 2001 est.
73 Croatia 89,000 2001 est.
74 Tunisia 87,000 2001 est.
75 Korea, North 85,000 2001 est.
76 Slovakia 82,000 2001 est.
77 Sri Lanka 75,000 2001 est.
78 Yemen 74,000 2001 est.
79 Lithuania 72,000 2001 est.
80 Netherlands Antilles 72,000 2001 est.
81 Bangladesh 71,000 2001 est.
82 Jamaica 66,000 2001 est.
83 Virgin Islands 66,000 2001 est.
84 Serbia and Montenegro 64,000 2001 est.
85 Turkmenistan 63,000 2001 est.
86 Guatemala 61,000 2001 est.
87 Kenya 57,000 2001 est.
88 Slovenia 53,300 2001 est.
89 Oman 53,000 2001 est.
90 Panama 52,000 2001 est.
91 Luxembourg 50,650 2001 est.
92 Sudan 50,000 2001 est.
93 Bolivia 49,000 2001 est.
94 Cyprus 49,000 2001 est.
95 Latvia 44,000 2001 est.
96 Gibraltar 42,000 2001 est.
97 Uruguay 41,500 2001 est.
98 El Salvador 39,000 2001 est.
99 Burma 38,000 2001 est.
100 Ghana 38,000 2001 est.
101 Costa Rica 37,000 2001 est.
102 Cote d''Ivoire 32,000 2001 est.
103 Georgia 31,500 2001 est.
104 Angola 31,000 2001 est.
105 Senegal 31,000 2001 est.
106 Bahrain 31,000 2001 est.
107 Honduras 29,000 2001 est.
108 Qatar 29,000 2001 est.
109 Paraguay 25,000 2001 est.
110 Nicaragua 24,500 2001 est.
111 Estonia 24,000 2001 est.
112 Mauritania 24,000 2001 est.
113 Moldova 24,000 2001 est.
114 Trinidad and Tobago 24,000 2001 est.
115 Bahamas, The 23,000 2001 est.
116 Ethiopia 23,000 2001 est.
117 Zimbabwe 23,000 2001 est.
118 Albania 22,400 2001 est.
119 Cameroon 22,000 2001 est.
120 Mauritius 21,000 2001 est.
121 Bosnia and Herzegovina 20,000 2001 est.
122 Kyrgyzstan 20,000 2001 est.
123 Malta 20,000 2001 est.
124 Tajikistan 20,000 2001 est.
125 Macedonia, The Former Yugoslav Republic of 20,000 2001 est.
126 Guam 20,000 2001 est.
127 Reunion 18,000 2001 est.
128 Tanzania 17,000 2001 est.
129 Iceland 16,300 2001 est.
130 Botswana 16,000 2001 est.
131 Nepal 16,000 2001 est.
132 Papua New Guinea 15,000 2001 est.
133 Congo, Democratic Republic of the 14,000 2001 est.
134 Martinique 13,500 2001 est.
135 Brunei 13,000 2001 est.
136 Namibia 13,000 2001 est.
137 Guadeloupe 13,000 2001 est.
138 Madagascar 13,000 2001 est.
139 Gabon 13,000 2001 est.
140 Benin 11,500 2001 est.
141 Djibouti 11,300 2001 est.
142 Guyana 11,000 2001 est.
143 Macau 11,000 2001 est.
144 Zambia 11,000 2001 est.
145 Haiti 11,000 2001 est.
146 Barbados 10,900 2001 est.
147 Suriname 10,000 2001 est.
148 Togo 10,000 2001 est.
149 Mongolia 8,750 2001 est.
150 Uganda 8,750 2001 est.
151 New Caledonia 8,750 2001 est.
152 Guinea 8,600 2001 est.
153 Mozambique 8,500 2001 est.
154 Burkina Faso 8,000 2001 est.
155 Aruba 6,500 2001 est.
156 French Guiana 6,500 2001 est.
157 Sierra Leone 6,500 2001 est.
158 Eritrea 6,000 2001 est.
159 Armenia 5,700 2001 est.
160 Fiji 5,700 2001 est.
161 Malawi 5,400 2001 est.
162 Rwanda 5,300 2001 est.
163 Belize 5,000 2001 est.
164 Congo, Republic of the 5,000 2001 est.
165 Niger 5,000 2001 est.
166 French Polynesia 4,750 2001 est.
167 Faroe Islands 4,500 2001 est.
168 Bermuda 4,000 2001 est.
169 Somalia 4,000 2001 est.
170 Mali 4,000 2001 est.
171 Seychelles 4,000 2001 est.
172 American Samoa 3,800 2001 est.
173 Greenland 3,700 2001 est.
174 Antigua and Barbuda 3,600 2001 est.
175 Cambodia 3,600 2001 est.
176 Afghanistan 3,500 2001 est.
177 Swaziland 3,500 2001 est.
178 Maldives 3,200 2001 est.
179 Liberia 3,100 2001 est.
180 Burundi 2,750 2001 est.
181 Laos 2,750 2001 est.
182 Guinea-Bissau 2,500 2001 est.
183 Cayman Islands 2,400 2001 est.
184 Saint Lucia 2,400 2001 est.
185 Central African Republic 2,400 2001 est.
186 Cape Verde 2,000 2001 est.
187 Equatorial Guinea 2,000 2001 est.
188 Gambia, The 1,900 2001 est.
189 Western Sahara 1,800 2001 est.
190 Chad 1,500 2001 est.
191 Lesotho 1,500 2001
192 Solomon Islands 1,250 2001 est.
193 Saint Vincent and the Grenadines 1,250 2001 est.
194 Bhutan 1,020 2001 est.
195 Grenada 1,000 2001 est.
196 Nauru 1,000 2001 est.
197 Samoa 1,000 2001 est.
198 Tonga 1,000 2001 est.
199 Saint Kitts and Nevis 710 2001 est.
200 Comoros 700 2001 est.
201 Sao Tome and Principe 700 2001 est.
202 Dominica 600 2001 est.
203 Vanuatu 600 2001 est.
204 Saint Pierre and Miquelon 600 2001 est.
205 Cook Islands 450 2001 est.
206 British Virgin Islands 420 2001 est.
207 Montserrat 400 2001 est.
208 Falkland Islands (Islas Malvinas) 200 2001 est.
209 Saint Helena 200 2001 est.
210 Kiribati 190 2001 est.
211 Niue 20 2001 est.
212 Turks and Caicos Islands 0 2001 est.
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2175
Rank Country Oil - imports(bbl/day) Date of Information
1 Japan 5,449,000 2001
2 Germany 3,081,000 2001
3 Korea, South 2,965,000 2001
4 Netherlands 2,284,000 2001
5 France 2,281,000 2001
6 Italy 2,158,000 2001
7 Spain 1,582,000 2001
8 United Kingdom 1,418,000 2001
9 Canada 1,145,000 2001
10 Belgium 1,042,000 2001
11 Turkey 616,500 2001
12 Sweden 553,100 2001
13 Australia 530,800 2001
14 Greece 468,300 2001
15 Poland 413,700 2001
16 Mexico 374,700 2001
17 Portugal 357,300 2001
18 Finland 318,300 2001
19 Switzerland 289,500 2001
20 Austria 262,000 2001
21 Denmark 195,000 2001
22 Czech Republic 192,300 2001
23 Ireland 178,600 2001
24 Hungary 136,600 2001
25 New Zealand 119,700 2001
26 Norway 88,870 2001
27 Luxembourg 50,700 2001
28 Iceland 15,470 2001
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2176
Rank Country Oil - exports(bbl/day) Date of Information
1 Norway 3,466,000 2001
2 United Kingdom 2,205,000 2001
3 Canada 2,008,000 2001
4 Mexico 1,881,000 2001
5 Netherlands 1,418,000 2001
6 Korea, South 804,700 2001
7 Australia 523,400 2001
8 Italy 456,600 2001
9 Belgium 450,000 2001
10 France 409,600 2001
11 Germany 404,300 2001
12 Denmark 332,100 2001
13 Sweden 203,700 2001
14 Spain 135,100 2001
15 Finland 101,000 2001
16 Japan 93,360 2001
17 Greece 84,720 2001
18 Poland 53,000 2001
19 Hungary 47,180 2001
20 Turkey 46,110 2001
21 Austria 35,470 2001
22 New Zealand 30,220 2001
23 Portugal 28,830 2001
24 Ireland 27,450 2001
25 Czech Republic 26,670 2001
26 Switzerland 10,420 2001
27 Luxembourg 634 2001
28 Iceland 0 2001
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2178
Rank Country Oil - proved reserves(bbl) Date of Information
1 World 1,025,000,000,000 37257
2 Saudi Arabia 261,700,000,000 37257
3 Iraq 113,800,000,000 37257
4 Kuwait 97,680,000,000 37257
5 Iran 94,390,000,000 37257
6 United Arab Emirates 80,310,000,000 37257
7 Venezuela 63,950,000,000 37257
8 Russia 51,220,000,000 37257
9 Libya 29,750,000,000 37257
10 Nigeria 27,000,000,000 37257
11 China 26,750,000,000 37257
12 Mexico 25,030,000,000 37257
13 United States 22,450,000,000 37257
14 Qatar 14,510,000,000 37257
15 Algeria 13,100,000,000 37257
16 Norway 9,859,000,000 37257
17 Brazil 8,507,000,000 37257
18 Indonesia 7,083,000,000 37257
19 Oman 5,703,000,000 37257
20 Angola 5,691,000,000 37257
21 Canada 5,112,000,000 37257
22 United Kingdom 4,741,000,000 37257
23 India 4,330,000,000 37257
24 Malaysia 3,729,000,000 37257
25 Australia 3,664,000,000 37257
26 Egypt 3,308,000,000 37257
27 Yemen 3,200,000,000 37257
28 Argentina 2,927,000,000 37257
29 Kazakhstan 2,709,000,000 37257
30 Gabon 2,450,000,000 37257
31 Syria 2,400,000,000 37257
32 Ecuador 2,358,000,000 37257
33 Colombia 1,800,000,000 37257
34 Congo, Democratic Republic of the 1,538,000,000 37257
35 Vietnam 1,400,000,000 37257
36 Brunei 1,255,000,000 37257
37 Denmark 1,230,000,000 37257
38 Romania 1,055,000,000 37257
39 Trinidad and Tobago 716,000,000 37257
40 Sudan 631,500,000 37257
41 Peru 614,700,000 37257
42 Azerbaijan 589,000,000 37257
43 Italy 586,600,000 37257
44 Equatorial Guinea 563,500,000 37257
45 Thailand 551,500,000 37257
46 Cuba 532,000,000 37257
47 Bolivia 458,800,000 37257
48 Tunisia 417,000,000 37257
49 Papua New Guinea 345,200,000 37257
50 Germany 327,300,000 37257
51 Pakistan 297,100,000 37257
52 Uzbekistan 297,000,000 37257
53 Turkey 288,400,000 37257
54 Turkmenistan 273,000,000 37257
55 Guatemala 263,000,000 37257
56 Cameroon 200,000,000 37257
57 Ukraine 197,500,000 37257
58 Albania 185,500,000 37257
59 Philippines 164,000,000 37257
60 France 144,300,000 37257
61 Burma 142,500,000 37257
62 Poland 116,400,000 37257
63 Hungary 110,700,000 37257
64 Croatia 93,600,000 37257
65 Congo, Republic of the 93,500,000 37257
66 New Zealand 89,620,000 37257
67 Netherlands 88,060,000 37257
68 Austria 85,690,000 37257
69 Chile 81,050,000 37257
70 Bahrain 62,280,000 37257
71 Cote d''Ivoire 50,000,000 37257
72 Serbia and Montenegro 38,750,000 37257
73 Suriname 37,000,000 37257
74 Japan 29,290,000 37257
75 Bangladesh 28,450,000 37257
76 Czech Republic 17,250,000 37257
77 Spain 10,500,000 37257
78 Ghana 8,255,000 37257
79 Bulgaria 8,100,000 37257
80 South Africa 7,840,000 37257
81 Greece 4,500,000 37257
82 Slovakia 4,500,000 37257
83 Benin 4,105,000 37257
84 Taiwan 2,000,000 37257
85 Israel 1,920,000 37257
86 Barbados 1,254,000 37257
87 Morocco 900,000 37257
88 Jordan 445,000 37257
89 Ethiopia 214,000 37257
90 Afghanistan 0 37257
91 Mozambique 0 37257
92 Tanzania 0 37257
93 Namibia 0 37257
94 Somalia 0 37257
95 Rwanda 0 37257
96 Ireland 0 37257
97 Madagascar 0 37257
This file was last updated on 18 December, 2003
======================================================================
Rank code: @2179
Rank Country Natural gas - proved reserves(cu m) Date of Information
1 World 161,200,000,000,000 37257
2 Russia 47,860,000,000,000 37257
3 Iran 24,800,000,000,000 37257
4 Qatar 17,930,000,000,000 37257
5 Saudi Arabia 6,339,000,000,000 37257
6 United Arab Emirates 5,892,000,000,000 37257
7 United States 5,195,000,000,000 37257
8 Algeria 4,739,000,000,000 37257
9 Venezuela 4,202,000,000,000 37257
10 Nigeria 4,007,000,000,000 37257
11 Iraq 3,149,000,000,000 37257
12 Indonesia 2,549,000,000,000 37257
13 Australia 2,407,000,000,000 37257
14 Malaysia 2,230,000,000,000 37257
15 Norway 1,716,000,000,000 37257
16 Netherlands 1,693,000,000,000 37257
17 Canada 1,691,000,000,000 37257
18 Kuwait 1,548,000,000,000 37257
19 Turkmenistan 1,430,000,000,000 37257
20 Libya 1,321,000,000,000 37257
21 China 1,290,000,000,000 37257
22 Egypt 1,264,000,000,000 37257
23 Mexico 969,200,000,000 37257
24 Uzbekistan 937,300,000,000 37257
25 Kazakhstan 920,300,000,000 37257
26 Oman 846,400,000,000 37257
27 Argentina 768,000,000,000 37257
28 Bolivia 727,200,000,000 37257
29 United Kingdom 714,900,000,000 37257
30 Pakistan 695,600,000,000 37257
31 Trinidad and Tobago 610,600,000,000 37257
32 Ukraine 560,700,000,000 37257
33 India 542,400,000,000 37257
34 Yemen 480,000,000,000 37257
35 Papua New Guinea 385,500,000,000 37257
36 Thailand 368,200,000,000 37257
37 Brunei 315,000,000,000 37257
38 Burma 314,400,000,000 37257
39 Germany 298,300,000,000 37257
40 Peru 245,100,000,000 37257
41 Syria 240,700,000,000 37257
42 Brazil 221,700,000,000 37257
43 Italy 209,700,000,000 37257
44 Vietnam 192,600,000,000 37257
45 Poland 154,400,000,000 37257
46 Bangladesh 150,300,000,000 37257
47 Colombia 132,000,000,000 37257
48 Romania 111,100,000,000 37257
49 Ecuador 106,500,000,000 37257
50 Congo, Democratic Republic of the 104,800,000,000 37257
51 Philippines 104,600,000,000 37257
52 Sudan 99,110,000,000 37257
53 Denmark 81,980,000,000 37257
54 Angola 79,570,000,000 37257
55 Tunisia 77,160,000,000 37257
56 Equatorial Guinea 68,530,000,000 37257
57 Chile 67,780,000,000 37257
58 Gabon 66,470,000,000 37257
59 Mozambique 63,710,000,000 37257
60 Azerbaijan 62,300,000,000 37257
61 New Zealand 58,940,000,000 37257
62 Cameroon 55,220,000,000 37257
63 Hungary 50,450,000,000 37257
64 Afghanistan 49,980,000,000 37257
65 Bahrain 46,000,000,000 37257
66 Cuba 42,620,000,000 37257
67 Taiwan 38,230,000,000 37257
68 Croatia 34,360,000,000 37257
69 Namibia 31,150,000,000 37257
70 Rwanda 28,320,000,000 37257
71 Austria 24,900,000,000 37257
72 Serbia and Montenegro 24,070,000,000 37257
73 Israel 20,810,000,000 37257
74 Japan 20,020,000,000 37257
75 Cote d''Ivoire 14,870,000,000 37257
76 France 12,860,000,000 37257
77 Ethiopia 12,460,000,000 37257
78 Ghana 11,890,000,000 37257
79 Tanzania 11,330,000,000 37257
80 Ireland 9,911,000,000 37257
81 Turkey 8,685,000,000 37257
82 Slovakia 7,504,000,000 37257
83 Bulgaria 3,724,000,000 37257
84 Albania 3,316,000,000 37257
85 Jordan 3,256,000,000 37257
86 Czech Republic 3,057,000,000 37257
87 Somalia 2,832,000,000 37257
88 Guatemala 1,543,000,000 37257
89 Morocco 665,400,000 37257
90 Benin 608,800,000 37257
91 Congo, Republic of the 495,500,000 37257
92 Greece 254,900,000 37257
93 Spain 254,900,000 37257
94 Barbados 70,790,000 37257
95 South Africa 14,160,000 37257
96 Madagascar 0 37257
97 Suriname 0 37257
This file was last updated on 18 December, 2003
======================================================================
Appendix A - Abbreviations
ABEDA: Arab Bank for Economic Development in Africa
ACC: Arab Cooperation Council
ACCT: Agency for the French-Speaking Community
ACP Group: African, Caribbean, and Pacific Group of States
AfDB: African Development Bank
AFESD: Arab Fund for Economic and Social Development
Air Pollution: Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides: Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Nitrogen Oxides or Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants: Protocol to the 1979
Convention on Long-Range Transboundary Air Pollution on Persistent
Organic Pollutants
Air Pollution-Sulphur 85: Protocol to the 1979 Convention on Long-
Range Transboundary Air Pollution on the Reduction of Sulphur Emissions
or Their Transboundary Fluxes by at Least 30%
Air Pollution-Sulphur 94: Protocol to the 1979 Convention on Long-
Range Transboundary Air Pollution on Further Reduction of Sulphur
Emissions
Air Pollution-Volatile Organic Compounds: Protocol to the 1979
Convention on Long-Range Transboundary Air Pollution Concerning the
Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
AL: Arab League
AMF: Arab Monetary Fund
AMU: Arab Maghreb Union
Antarctic-Environmental Protocol: Protocol on Environmental
Protection to the Antarctic Treaty
Antarctic-Marine Living Resources: Convention on the Conservation of
Antarctic Marine Living Resources
Antarctic Seals: Convention for the Conservation of Antarctic Seals
ANZUS: Australia-New Zealand-United States Security Treaty
APEC: Asia-Pacific Economic Cooperation
Arabsat: Arab Satellite Communications Organization
ARF: ASEAN Regional Forum
AsDB: Asian Development Bank
ASEAN: Association of Southeast Asian Nations
Autodin: Automatic Digital Network
bbl/day: barrels per day
BCIE: Central American Bank for Economic Integration
BDEAC: Central African States Development Bank
Benelux: Benelux Economic Union
Biodiversity: Convention on Biological Diversity
BIS: Bank for International Settlements
BSEC: Black Sea Economic Cooperation Zone
C: Commonwealth
CACM: Central American Common Market
CAEU: Council of Arab Economic Unity
CAN: Andean Community of Nations
Caricom: Caribbean Community and Common Market
CB: citizen''s band mobile radio communications
CBSS: Council of the Baltic Sea States
CCC: Customs Cooperation Council
CDB: Caribbean Development Bank
CE: Council of Europe
CEI: Central European Initiative
CEMA: Council for Mutual Economic Assistance; also known as CMEA or
Comecon
CEMAC: Monetary and Economic Community of Central Africa
CEPGL: Economic Community of the Great Lakes Countries
CERN: European Organization for Nuclear Research
c.i.f.: cost, insurance, and freight
CIS: Commonwealth of Independent States
CITES: see Endangered Species
Climate Change: United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol: Kyoto Protocol to the United Nations
Framework Convention on Climate Change
COCOM: Coordinating Committee on Export Controls
COMESA: Common Market for Eastern and Southern Africa
Comsat: Communications Satellite Corporation
CP: Colombo Plan
CY: calendar year
DC: developed country
Desertification: United Nations Convention to Combat Desertification
in Those Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa
DSN: Defense Switched Network
DWT: deadweight ton
EADB: East African Development Bank
EAPC: Euro-Atlantic Partnership Council
EBRD: European Bank for Reconstruction and Development
EC: European Community
ECA: Economic Commission for Africa
ECE: Economic Commission for Europe
ECLAC: Economic Commission for Latin America and the Caribbean
ECO: Economic Cooperation Organization
ECOSOC: Economic and Social Council
ECOWAS: Economic Community of West African States
ECS: European Coal and Steel Community
EEC: European Economic Community
EFTA: European Free Trade Association
EIB: European Investment Bank
EMU: Economic and Monetary Union
Endangered Species: Convention on the International Trade in
Endangered Species of Wild Flora and Fauna (CITES)
Entente: Council of the Entente
Environmental Modification: Convention on the Prohibition of Military
or Any Other Hostile Use of Environmental Modification Techniques
ESA: European Space Agency
ESCAP: Economic and Social Commission for Asia and the Pacific
ESCWA: Economic and Social Commission for Western Asia
est.: estimate
EU: European Union
Euratom: European Atomic Energy Community
Eutelsat: European Telecommunications Satellite Organization
Ex-Im: Export-Import Bank of the United States
FAO: Food and Agriculture Organization
FAX: facsimile
f.o.b.: free on board
FLS: Front Line States
FRG: Federal Republic of Germany (West Germany); used for
information dated before 3 October 1990 or CY91
FSU: former Soviet Union
FY: fiscal year
F.Y.R.O.M.: The Former Yugoslav Republic of Macedonia
FZ: Franc Zone
G-2: Group of 2
G-3: Group of 3
G-5: Group of 5
G-6: Group of 6
G-7: Group of 7
G-8: Group of 8
G-9: Group of 9
G-10: Group of 10
G-11: Group of 11
G-15: Group of 15
G-24: Group of 24
G-77: Group of 77
GATT: General Agreement on Tariffs and Trade; now WTrO
GCC: Gulf Cooperation Council
GDP: gross domestic product
GDR: German Democratic Republic (East Germany); used for information
dated before 3 October 1990 or CY91
GNP: gross national product
GRT: gross register ton
GUUAM: acronym for member states - Georgia, Ukraine, Uzbekistan,
Azerbaijan, Moldova
GWP: gross world product
Habitat: United Nations Center for Human Settlements
Hazardous Wastes: Basel Convention on the Control of Transboundary
Movements of Hazardous Wastes and Their Disposal
HF: high-frequency
IADB','3f356f1532a84050399eb84f912fe3cfeafbfefe860e9315ef7d30d00003632c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35062499bb89eea8891dcdb028d5d2399f9a8bb29f9807289d316c62ea755dd2',2003,'YE','Yemen','communications',812,': Inter-American Development Bank
IAEA: International Atomic Energy Agency
IBEC: International Bank for Economic Cooperation
IBRD: International Bank for Reconstruction and Development (World
Bank)
ICAO: International Civil Aviation Organization
ICC: International Chamber of Commerce
ICCt: International Criminal Court
ICFTU: International Confederation of Free Trade Unions
ICJ: International Court of Justice (World Court)
ICRC: International Committee of the Red Cross
ICRM: International Red Cross and Red Crescent Movement
ICSID: International Center for Secretariat of Investment Disputes
ICTR: International Criminal Tribunal for Rwanda
ICTY: International Criminal Tribunal for the former Yugoslavia
IDA: International Development Association
IDB: Islamic Development Bank
IEA: International Energy Agency
IFAD: International Fund for Agricultural Development
IFC: International Finance Corporation
IFCTU: International Federation of Christian Trade Unions
IFRCS: International Federation of Red Cross and Red Crescent
Societies
IGAD: Inter-Governmental Authority on Development
IGADD: Inter-Governmental Authority on Drought and Development
IHO: International Hydrographic Organization
IIB: International Investment Bank
ILO: International Labor Organization
IMF: International Monetary Fund
IMO: International Maritime Organization
Inmarsat: International Mobile Satellite Organization
InOC: Indian Ocean Commission
INSTRAW: International Research and Training Institute for the
Advancement of Women
Intelsat: International Telecommunications Satellite Organization
Interpol: International Criminal Police Organization
Intersputnik: International Organization of Space Communications
IOC: International Olympic Committee
IOM: International Organization for Migration
ISO: International Organization for Standardization
ITU: International Telecommunication Union
kHz: kilohertz
km: kilometer
kW: kilowatt
kWh: kilowatt-hour
LAES: Latin American Economic System
LAIA: Latin American Integration Association
Law of the Sea: United Nations Convention on the Law of the Sea (LOS)
LDC: less developed country
LLDC: least developed country
London Convention: see Marine Dumping
LOS: see Law of the Sea
m: meter
Marecs: Maritime European Communications Satellite
Marine Dumping: Convention on the Prevention of Marine Pollution by
Dumping Wastes and Other Matter
Marine Life Conservation: Convention on Fishing and Conservation of
Living Resources of the High Seas
MARPOL: see Ship Pollution
Medarabtel: Middle East Telecommunications Project of the
International Telecommunications Union
Mercosur: Southern Cone Common Market
MHz: megahertz
MIGA: Multilateral Investment Geographic Agency
MINURSO: United Nations Mission for the Referendum in Western Sahara
MIPOHUH: United Nations Civilian Police Mission in Haiti
MONUC: United Nations Organization Mission in the Democratic Republic
of the Congo
NA: not available
NAM: Nonaligned Movement
NATO: North Atlantic Treaty Organization
NC: Nordic Council
NEA: Nuclear Energy Agency
NEGL: negligible
NIB: Nordic Investment Bank
NIC: newly industrializing country
NIE: newly industrializing economy
NIS: new independent states
NM: nautical mile
NMT: Nordic Mobile Telephone
NSG: Nuclear Suppliers Group
Nuclear Test Ban: Treaty Banning Nuclear Weapons Tests in the
Atmosphere, in Outer Space, and Under Water
NZ: New Zealand
OAPEC: Organization of Arab Petroleum Exporting Countries
OAS: Organization of American States
OAU: Organization of African Unity
ODA: official development assistance
OECD: Organization for Economic Cooperation and Development
OECS: Organization of Eastern Caribbean States
OIC: Organization of the Islamic Conference
OOF: other official flows
OPANAL: Agency for the Prohibition of Nuclear Weapons in Latin
America and the Caribbean
OPCW: Organization for the Prohibition of Chemical Weapons
OPEC: Organization of Petroleum Exporting Countries
OSCE: Organization for Security and Cooperation in Europe
Ozone Layer Protection: Montreal Protocol on Substances That Deplete
the Ozone Layer
PCA: Permanent Court of Arbitration
PDRY: People''s Democratic Republic of Yemen [Yemen (Aden) or South
Yemen]; used for information dated before 22 May 1990 or CY91
PFP: Partnership for Peace
Ramsar: see Wetlands
RG: Rio Group
SAARC: South Asian Association for Regional Cooperation
SACU: Southern African Customs Union
SADC: Southern African Development Community
SCO: Shanghai Cooperative Organization
SFRY: Socialist Federal Republic of Yugoslavia
SHF: super-high-frequency
Ship Pollution: Protocol of 1978 Relating to the International
Convention for the Prevention of Pollution From Ships, 1973 (MARPOL)
Sparteca: South Pacific Regional Trade and Economic Cooperation
Agreement
SPC: South Pacific Commission
SPF: South Pacific Forum
sq km: square kilometer
sq mi: square mile
TAT: Trans-Atlantic Telephone
Tropical Timber 83: International Tropical Timber Agreement, 1983
Tropical Timber 94: International Tropical Timber Agreement, 1994
UAE: United Arab Emirates
UDEAC: Central African Customs and Economic Union
UHF: ultra-high-frequency
UK: United Kingdom
UN: United Nations
UNAMA: United Nations Assistance Mission in Afghanistan
UNAMSIL: United Nations Mission in Sierra Leone
UNCTAD: United Nations Conference on Trade and Development
UNDCP: United Nations Drug Control Program
UNDOF: United Nations Disengagement Observer Force
UNDP: United Nations Development Program
UNEP: United Nations Environment Program
UNESCO: United Nations Educational, Scientific, and Cultural
Organization
UNFICYP: United Nations Peace-keeping Force in Cyprus
UNFPA: United Nations Population Fund
UNHCR: United Nations High Commissioner for Refugees
UNHCRHR: United Nations High Commissioner for Human Rights
UNICEF: United Nations Children''s Fund
UNICRI: United Nations Interregional Crime and Justice Research
Institute
UNIDIR: United Nations Disarmament Research
UNIDO: United Nations Industrial Development Organization
UNIFIL: United Nations Interim Force in Lebanon
UNIKOM: United Nations Iraq-Kuwait Observation Mission
UNITAR: United Nations Institute for Training and Research
UNMEE: United Nations Mission in Ethiopia and Eritrea
UNMIBH: United Nations Mission in Bosnia and Herzegovina
UNMIK: United Nations Interim Administration Mission in Kosovo
UNMISET: United Nations Mission of Support in East Timor
UNMOGIP: United Nations Military Observer Group in India and Pakistan
UNMOP: United Nations Mission of Observers in Prevlaka
UNMOT: United Nations Mission of Observers in Tajikistan
UNMOVIC: United Nations Monitoring, Verification, and Inspection
Commission
UNOMIG: United Nations Observer Mission in Georgia
UNOMSIL: United Nations Mission of Observers in Sierra Leone
UNOPS: United Nations Office of Project Services
UNPREDEP: United Nations Preventive Deployment Force
UNRISD: United Nations Research Institute for Social Development
UNRWA: United Nations Relief and Works Agency for Palestine Refugees
in the Near East
UNSC: United Nations Security Council
UNSSC: United Nations System Staff College
UNTAET: United Nations Transitional Administration in East Timor
UNTSO: United Nations Truce Supervision Organization
UNU: United Nations University
UPU: Universal Postal Union
US: United States
USSR: Union of Soviet Socialist Republics (Soviet Union); used for
information dated before 25 December 1991
USSR/EE: Union of Soviet Socialist Republics/Eastern Europe
VHF: very-high-frequency
VSAT: very small aperture terminal
WADB: West African Development Bank
WAEMU: West African Economic and Monetary Union
WCL: World Confederation of Labor
Wetlands: Convention on Wetlands of International Importance
Especially As Waterfowl Habitat
WEU: Western European Union
WFC: World Food Council
WFP: World Food Program
WFTU: World Federation of Trade Unions
Whaling: International Convention for the Regulation of Whaling
WHO: World Health Organization
WIPO: World Intellectual Property Organization
WMO: World Meteorological Organization
WP: Warsaw Pact
WTO: see WToO for World Tourism Organization or WTrO for World Trade
Organization
WToO: World Tourism Organization
WTrO: World Trade Organization
YAR: Yemen Arab Republic [Yemen (Sanaa) or North Yemen]; used for
information dated before 22 May 1990 or CY91
ZC: Zangger Committee
This page was last updated on 1 August, 2003
=====================================================================
Appendix B - International Organizations and Groups
advanced developing countries: another term for those less developed
countries (LDCs) with particularly rapid industrial development; see
newly industrializing economies (NIEs)
advanced economies: a term used by the International Monetary FUND
(IMF) for the top group in its hierarchy of advanced economies,
countries in transition, and developing countries; it includes the
following 28 advanced economies: Australia, Austria, Belgium, Canada,
Denmark, Finland, France, Germany, Greece, Hong Kong, Iceland, Ireland,
Israel, Italy, Japan, South Korea, Luxembourg, Netherlands, NZ, Norway,
Portugal, Singapore, Spain, Sweden, Switzerland, Taiwan, UK, US; note -
this group would presumably also cover the following seven smaller
countries of Andorra, Bermuda, Faroe Islands, Holy See, Liechtenstein,
Monaco, and San Marino which are included in the more comprehensive
group of "developed countries"
African, Caribbean, and Pacific Group of States (ACP Group):
established - 6 June 1975
aim - to manage their preferential economic and aid relationship with
the EU
members - (77) Angola, Antigua and Barbuda, The Bahamas, Barbados,
Belize, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde,
Central African Republic, Chad, Comoros, Democratic Republic of the
Congo, Republic of the Congo, Cook Islands, Cote d''Ivoire, Djibouti,
Dominica, Dominican Republic, Equatorial Guinea, Eritrea, Ethiopia,
Fiji, Gabon, The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana,
Haiti, Jamaica, Kenya, Kiribati, Lesotho, Liberia, Madagascar, Malawi,
Mali, Marshall Islands, Mauritania, Mauritius, Federated States of
Micronesia, Mozambique, Namibia, Nauru, Niger, Nigeria, Niue, Palau,
Papua New Guinea, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, Sao Tome and Principe, Senegal,
Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa,
Sudan, Suriname, Swaziland, Tanzania, Togo, Tonga, Trinidad and Tobago,
Tuvalu, Uganda, Vanuatu, Zambia, Zimbabwe
African Development Bank (AfDB): note - also known as Banque Africaine
de Developpement (BAD)
established - 4 August 1963
aim - to promote economic and social development
regional members - (53) Algeria, Angola, Benin, Botswana, Burkina
Faso, Burundi, Cameroon, Cape Verde, Central African Republic, Chad,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote
d''Ivoire, Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon,
The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia,
Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco,
Mozambique, Namibia, Niger, Nigeria, Rwanda, Sao Tome and Principe,
Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan,
Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
nonregional members - (24) Argentina, Austria, Belgium, Brazil, Canada,
China, Denmark, Finland, France, Germany, India, Italy, Japan, South
Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain,
Sweden, Switzerland, UK, US
African Union (AU): note - replaces Organization of African Unity
(OAU)
established - 8 July 2001
aim - to achieve greater unity among African States; to defend states''
integrity and independence; to accelerate political, social, and
economic integration; to encourage international cooperation; to
promote democratic principles and institutions
members - (52) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi,
Cameroon, Cape Verde, Central African Republic, Chad, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The
Gambia, Ghana, Guinea, Kenya, Lesotho, Liberia, Libya, Madagascar,
Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger,
Nigeria, Rwanda, Sahrawi Arab Democratic Republic, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa,
Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
Agency for the French-Speaking Community (ACCT): note - formerly
Agency for Cultural and Technical Cooperation
established - 20 March 1970; name changed 1996
aim - to promote cultural and technical cooperation among French-
speaking countries
members - (51) Albania, Belgium, Benin, Bulgaria, Burkina Faso,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Cote d''Ivoire, Djibouti, Dominica, Egypt, Equatorial Guinea,
France, French Community of Belgium, Gabon, Guinea, Guinea-Bissau,
Haiti, Laos, Lebanon, Luxembourg, Former Yugoslav Republic of
Macedonia, Madagascar, Mali, Mauritania, Mauritius, Moldova, Monaco,
Morocco, New Brunswick (Canada), Niger, Quebec (Canada), Romania,
Rwanda, Saint Lucia, Sao Tome and Principe, Senegal, Seychelles,
Switzerland, Togo, Tunisia, Vanuatu, Vietnam
observers - (4) Czech Republic, Lithuania, Poland, Slovenia
Agency for the Prohibition of Nuclear Weapons in Latin America and the
Caribbean (OPANAL): note - acronym from Organismo para la Proscripcion
de las Armas Nucleares en la America Latina y el Caribe (OPANAL)
established - 14 February 1967 under the Treaty of Tlatelolco;
effective - 25 April 1969 on the 11th ratification of the treaty
aim - to encourage the peaceful uses of atomic energy and prohibit
nuclear weapons
members - (33) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba, Dominica,
Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana,
Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Suriname, Trinidad and Tobago, Uruguay, Venezuela
Andean Community of Nations (CAN): note - formerly known as the Andean
Group (AG), the Andean Parliament, and most recently as the Andean
Common Market (Ancom)
established - 26 May 1969; present name established 1 October 1992;
effective - 16 October 1969
aim - to promote harmonious development through economic integration
members - (5) Bolivia, Colombia, Ecuador, Peru, Venezuela
Arab Bank for Economic Development in Africa (ABEDA): note - also
known as Banque Arabe de Developpement Economique en Afrique (BADEA)
established - 18 February 1974; effective - 16 September 1974
aim - to promote economic development
members - (17 plus the Palestine Liberation Organization) Algeria,
Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya, Mauritania,
Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE,
Palestine Liberation Organization; note - these are all the members of
the Arab League excluding Comoros, Djibouti, Somalia, Yemen
Arab Cooperation Council (ACC): established - 16 February 1989
aim - to promote economic cooperation and integration, possibly leading
to an Arab Common Market
members - (4) Egypt, Iraq, Jordan, Yemen; note - the ACC has remained
inactive since the Gulf crisis
Arab Fund for Economic and Social Development (AFESD): established -
16 May 1968
aim - to promote economic and social development
members - (20 plus the Palestine Liberation Organization) Algeria,
Bahrain, Djibouti, Egypt, Iraq (suspended 1993), Jordan, Kuwait,
Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia
(suspended 1993), Sudan, Syria, Tunisia, UAE, Yemen, Palestine
Liberation Organization
Arab League (AL): note - also known as League of Arab States (LAS)
established - 22 March 1945
aim - to promote economic, social, political, and military cooperation
members - (21 plus the Palestine Liberation Organization) Algeria,
Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan,
Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
Arab Maghreb Union (AMU): established - 17 February 1989
aim - to promote cooperation and integration among the Arab states of
northern Africa
members - (5) Algeria, Libya, Mauritania, Morocco, Tunisia
Arab Monetary Fund (AMF): established - 27 April 1976; effective - 2
February 1977
aim - to promote Arab cooperation, development, and integration in
monetary and economic affairs
members - (21 plus the Palestine Liberation Organization) Algeria,
Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan,
Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
Asia-Pacific Economic Cooperation (APEC): established - 7 November
1989
aim - to promote trade and investment in the Pacific basin
members - (21) Australia, Brunei, Canada, Chile, China, Hong Kong,
Indonesia, Japan, South Korea, Malaysia, Mexico, NZ, Papua New Guinea,
Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers - (3) Association of Southeast Asian Nations, Pacific
Economic Cooperation Council, Pacific Islands Forum
Asian Development Bank (AsDB): established - 19 December 1966
aim - to promote regional economic cooperation
regional members - (44) Afghanistan, Australia, Azerbaijan, Bangladesh,
Bhutan, Burma, Cambodia, China, Cook Islands, East Timor, Fiji, Hong
Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea,
Kyrgyzstan, Laos, Malaysia, Maldives, Marshall Islands, Federated
States of Micronesia, Mongolia, Nauru, Nepal, NZ, Pakistan, Papua New
Guinea, Philippines, Samoa, Singapore, Solomon Islands, Sri Lanka,
Taiwan, Tajikistan, Thailand, Tonga, Turkmenistan, Tuvalu, Uzbekistan,
Vanuatu, Vietnam
nonregional members - (17) Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Italy, Netherlands, Norway, Portugal, Spain, Sweden,
Switzerland, Turkey, UK, US
Association of Southeast Asian Nations (ASEAN): established - 8 August
1967
aim - to encourage regional economic, social, and cultural cooperation
among the non-Communist countries of Southeast Asia
members - (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia,
Philippines, Singapore, Thailand, Vietnam
associate member - (1) Papua New Guinea
dialogue partners - (12) Australia, Canada, China, EU, India, Japan,
Pakistan, South Korea, NZ, Russia, US, UNDP
ASEAN Regional Forum (ARF): established - NA 1994
aim - to foster constructive dialogue and consultation on political and
security issues of common interest and concern
members - (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia,
Philippines, Singapore, Thailand, Vietnam
dialogue partners - (13) Australia, Canada, China, EU, India, Japan,
North Korea, South Korea, Mongolia, NZ, Papua New Guinea, Russia, US
Australia Group: established - NA 1984
aim - to consult on and coordinate export controls related to chemical
and biological weapons
members - (34) Argentina, Australia, Austria, Belgium, Bulgaria,
Canada, Cyprus, Czech Republic, Denmark, European Commission, Finland,
France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, South
Korea, Luxembourg, Netherlands, NZ, Norway, Poland, Portugal, Romania,
Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
Australia-New Zealand-United States Security Treaty (ANZUS):
established - 1 September 1951; effective - 29 April 1952
aim - to implement a trilateral mutual security agreement, although the
US suspended security obligations to NZ on 11 August 1986; Australia
and the US continue to hold annual meetings
members - (3) Australia, NZ, US
Bank for International Settlements (BIS): established - 20 January
1930; effective - 17 March 1930
aim - to promote cooperation among central banks in international
financial settlements
members - (50) Argentina, Australia, Austria, Belgium, Bosnia and
Herzegovina, Brazil, Bulgaria, Canada, China, Croatia, Czech Republic,
Denmark, Estonia, European Central Bank, Finland, France, Germany,
Greece, Hong Kong, Hungary, Iceland, India, Ireland, Italy, Japan,
South Korea, Latvia, Lithuania, The Former Yugoslav Republic of
Macedonia, Malaysia, Mexico, Netherlands, Norway, Poland, Portugal,
Romania, Russia, Saudi Arabia, Serbia and Montenegro, Singapore,
Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Thailand,
Turkey, UK, US
Benelux Economic Union (Benelux): note - acronym from Belgium,
Netherlands, and Luxembourg
established - 3 February 1958; effective - 1 November 1960
aim - to develop closer economic cooperation and integration
members - (3) Belgium, Luxembourg, Netherlands
Big Seven: note - membership is the same as the Group of 7
established - NA 1975
aim - to discuss and coordinate major economic policies
members - (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus
the US
Big Six: note - not to be confused with the Group of 6
established - NA 1967
aim - to foster economic cooperation
members - (6) Canada, France, Germany, Italy, Japan, UK
Black Sea Economic Cooperation Zone (BSEC): established - 25 June 1992
aim - to enhance regional stability through economic cooperation
members - (11) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece,
Moldova, Romania, Russia, Turkey, Ukraine
observers - (9) Austria, Egypt, France, Germany, Israel, Italy, Poland,
Slovakia, Tunisia
Caribbean Community and Common Market (Caricom): established - 4 July
1973; effective - 1 August 1973
aim - to promote economic integration and development, especially among
the less developed countries
members - (15) Antigua and Barbuda, The Bahamas, Barbados, Belize,
Dominica, Grenada, Guyana, Haiti, Jamaica, Montserrat, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname,
countries that have signed, but not yet ratified - (17) Bolivia,
Democratic Republic of the Congo, Ethiopia, Holy See, Iceland, Iran,
Iraq, Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal,
Sierra Leone, Syria, Turkey, Uganda
Convention on Wetlands of International Importance Especially as
Waterfowl Habitat (Ramsar)
note - abbreviated as Wetlands
opened for signature - 2 February 1971
entered into force - 21 December 1975
objective - to stem the progressive encroachment on and loss of
wetlands now and in the future, recognizing the fundamental ecological
functions of wetlands and their economic, cultural, scientific, and
recreational value
parties - (125) Albania, Algeria, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Belarus,
Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Bulgaria, Burkina Faso, Cambodia, Canada, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Czech Republic,
Denmark, Ecuador, Egypt, El Salvador, Estonia, Finland, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-
Bissau, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Latvia,
Lebanon, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Norway, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Romania, Russia, Senegal, Serbia and Montenegro, Sierra Leone,
Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Suriname, Sweden,
Switzerland, Syria, Tajikistan, Thailand, Togo, Trinidad and Tobago,
Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Zambia
Desertification
see United Nations Convention to Combat Desertification in Those
Countries Experiencin','2363c88661ce8aad32284f56b13a9efc54d23a8bee47a8c373099b69bf75b910','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('902dfd81a81f757c6ce85dc65de85d5ae4b25e0b35a18e469b5f4b9533d81023',2003,'YE','Yemen','communications',813,'g Serious Drought and/or Desertification,
Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use
of Environmental Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of
Hazardous Wastes and Their Disposal
International Convention for the Regulation of Whaling
note - abbreviated as Whaling
opened for signature - 2 December 1946
entered into force - 10 November 1948
objective - to protect all species of whales from overhunting; to
establish a system of international regulation for the whale fisheries
to ensure proper conservation and development of whale stocks; and to
safeguard for future generations the great natural resources
represented by whale stocks
parties - (42) Antigua and Barbuda, Argentina, Australia, Austria,
Brazil, Chile, China, Costa Rica, Denmark, Dominica, Finland, France,
Germany, Grenada, Guinea, India, Ireland, Italy, Japan, Kenya, South
Korea, Mexico, Monaco, Morocco, Netherlands, NZ, Norway, Oman, Panama,
Peru, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Senegal, Solomon Islands, South Africa, Spain, Sweden,
Switzerland, UK, US
International Tropical Timber Agreement, 1983
note - abbreviated as Tropical Timber 83
opened for signature - 18 November 1983
entered into force - 1 April 1985; this agreement expired when the
International Tropical Timber Agreement, 1994, went into force
objective - to provide an effective framework for cooperation between
tropical timber producers and consumers and to encourage the
development of national policies aimed at sustainable utilization and
conservation of tropical forests and their genetic resources
parties - (54) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cameroon, Canada, China, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Cote d''Ivoire, Denmark, Ecuador, Egypt, EU,
Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras,
India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia,
Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua New
Guinea, Peru, Philippines, Portugal, Russia, Spain, Sweden,
Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Venezuela
International Tropical Timber Agreement, 1994
note - abbreviated as Tropical Timber 94
opened for signature - 26 January 1994
entered into force - 1 January 1997
objective - to ensure that by the year 2000 exports of tropical timber
originate from sustainably managed sources; to establish a fund to
assist tropical timber producers in obtaining the resources necessary
to reach this objective
parties - (58) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cambodia, Cameroon, Canada, Central African Republic, China, Colombia,
Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Denmark, Ecuador, Egypt, EU, Fiji, Finland, France, Gabon, Germany,
Ghana, Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy,
Japan, South Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands,
NZ, Norway, Panama, Papua New Guinea, Peru, Philippines, Portugal,
Spain, Suriname, Sweden, Switzerland, Thailand, Togo, Trinidad and
Tobago, UK, US, Uruguay, Vanuatu, Venezuela
Kyoto Protocol to the United Nations Framework Convention on Climate
Change
note - abbreviated as Climate Change-Kyoto Protocol
opened for signature - 16 March 1998, but not yet in force
objective - to further reduce greenhouse gas emissions by enhancing the
national programs of developed countries aimed at this goal and by
establishing percentage reduction targets for the developed countries
parties - (49) Antigua and Barbuda, Argentina, Azerbaijan, The Bahamas,
Bangladesh, Barbados, Bolivia, Burundi, Colombia, Cook Islands, Cyprus,
Czech Republic, Denmark, Ecuador, El Salvador, Equatorial Guinea, Fiji,
The Gambia, Georgia, Guatemala, Guinea, Honduras, Jamaica, Jordan,
Kiribati, Lesotho, Malawi, Maldives, Malta, Mauritius, Mexico,
Federated States of Micronesia, Mongolia, Nauru, Nicaragua, Niue,
Palau, Panama, Paraguay, Portugal, Romania, Samoa, Senegal, Trinidad
and Tobago, Turkmenistan, Tuvalu, Uruguay, Uzbekistan, Vanuatu
countries that have signed, but not yet ratified - (57) Australia,
Austria, Belgium, Brazil, Bulgaria, Canada, Chile, China, Costa Rica,
Croatia, Cuba, Egypt, Estonia, EU, Finland, France, Germany, Greece,
Indonesia, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea,
Latvia, Liechtenstein, Lithuania, Luxembourg, Malaysia, Mali, Marshall
Islands, Monaco, Netherlands, NZ, Niger, Norway, Papua New Guinea,
Peru, Philippines, Poland, Russia, Saint Lucia, Saint Vincent and the
Grenadines, Seychelles, Slovakia, Slovenia, Solomon Islands, Spain,
Sweden, Switzerland, Thailand, Ukraine, UK, US, Vietnam, Zambia
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes
and Other Matter (London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the
High Seas
Montreal Protocol on Substances That Deplete the Ozone Layer
note - abbreviated as Ozone Layer Protection
opened for signature - 16 September 1987
entered into force - 1 January 1989
objective - to protect the ozone layer by controlling emissions of
substances that deplete it
parties - (183) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia
and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer
Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL)
note - abbreviated as Ship Pollution
opened for signature - 17 February 1978
entered into force - 2 October 1983
objective - to preserve the marine environment through the complete
elimination of pollution by oil and other harmful substances and the
minimization of accidental discharge of such substances
parties - (119) Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada,
Chile, China, Colombia, Comoros, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, Equatorial Guinea, Estonia, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guyana, Honduras,
Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica,
Japan, Kazakhstan, Kenya, North Korea, South Korea, Latvia, Lebanon,
Liberia, Lithuania, Luxembourg, Malawi, Malaysia, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Monaco, Morocco, Netherlands,
NZ, Nicaragua, Norway, Oman, Pakistan, Panama, Papua New Guinea, Peru,
Philippines, Poland, Portugal, Romania, Russia, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe,
Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Suriname, Sweden,
Switzerland, Syria, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Tuvalu, Ukraine, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam
Protocol on Environmental Protection to the Antarctic Treaty
note - abbreviated as Antarctic-Environmental Protocol
opened for signature - 4 October 1991
entered into force - 14 January 1998
objective - to provide for comprehensive protection of the Antarctic
environment and dependent and associated ecosystems; applies to the
area covered by the Antarctic Treaty
consultative parties - (27) Argentina, Australia, Belgium, Brazil,
Bulgaria, Chile, China, Ecuador, Finland, France, Germany, India,
Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru, Poland,
Russia, South Africa, Spain, Sweden, UK, US, Uruguay
non consultative parties - (16) Austria, Canada, Colombia, Cuba, Czech
Republic, Denmark, Greece, Guatemala, Hungary, North Korea, Papua New
Guinea, Romania, Slovakia, Switzerland, Turkey, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
note - abbreviated as Air Pollution-Nitrogen Oxides
opened for signature - 31 October 1988
entered into force - 14 February 1991
objective - to provide for the control or reduction of nitrogen oxides
and their transboundary fluxes
parties - (28) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Estonia, EU, Finland, France, Germany, Greece,
Hungary, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands,
Norway, Russia, Slovakia, Spain, Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified - (1) Poland
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
note - abbreviated as Air Pollution-Volatile Organic Compounds
opened for signature - 18 November 1991
entered into force - 29 September 1997
objective - to provide for the control and reduction of emissions of
volatile organic compounds in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse
effects
parties - (21) Austria, Belgium, Bulgaria, Czech Republic, Denmark,
Estonia, Finland, France, Germany, Hungary, Italy, Liechtenstein,
Luxembourg, Monaco, Netherlands, Norway, Slovakia, Spain, Sweden,
Switzerland, UK
countries that have signed, but not yet ratified - (6) Canada, EU,
Greece, Portugal, Ukraine, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions
note - abbreviated as Air Pollution-Sulphur 94
opened for signature - 14 June 1994
entered into force - 5 August 1998
objective - to provide for a further reduction in sulfur emissions or
transboundary fluxes
parties - (23) Austria, Belgium, Canada, Croatia, Czech Republic,
Denmark, EU, Finland, France, Germany, Greece, Ireland, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Slovakia, Slovenia,
Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified - (5) Bulgaria,
Hungary, Poland, Russia, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Persistent Organic Pollutants
note - abbreviated as Air Pollution-Persistent Organic Pollutants
opened for signature - 24 June 1998, but not yet in force
objective - to provide for the control and reduction of emissions of
persistent organic pollutants in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse
effects
parties - (8) Bulgaria, Canada, Denmark, Luxembourg, Netherlands,
Norway, Sweden, Switzerland
countries that have signed, but not yet ratified - (28) Armenia,
Austria, Belgium, Croatia, Cyprus, Czech Republic, EU, Finland, France,
Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia,
Liechtenstein, Lithuania, Moldova, Poland, Portugal, Romania, Slovakia,
Slovenia, Spain, Ukraine, UK, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or Their Transboundary
Fluxes by at Least 30%
note - abbreviated as Air Pollution-Sulphur 85
opened for signature - 8 July 1985
entered into force - 2 September 1987
objective - to provide for a 30% reduction in sulfur emissions or
transboundary fluxes by 1993
parties - (22) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Estonia, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia,
Sweden, Switzerland, Ukraine
Ship Pollution
see Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL)
Treaty Banning Nuclear Weapon Tests in the Atmosphere, in Outer Space,
and Under Water
note - abbreviated as Nuclear Test Ban
opened for signature - 5 August 1963
entered into force - 10 October 1963
objective - to obtain an agreement on general and complete disarmament
under strict international control in accordance with the objectives of
the United Nations; to put an end to the armaments race and eliminate
incentives for the production and testing of all kinds of weapons,
including nuclear weapons
parties - (113) Afghanistan, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, The Bahamas, Bangladesh, Belgium, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burma,
Canada, Central African Republic, Chad, China, Colombia, Democratic
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus,
Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El
Salvador, Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece,
Guatemala, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea,
Kuwait, Laos, Lebanon, Liberia, Luxembourg, Madagascar, Malawi,
Malaysia, Malta, Mauritania, Mauritius, Mexico, Morocco, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Panama, Papua New
Guinea, Peru, Philippines, Poland, Romania, Russia, Rwanda, Samoa, San
Marino, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Uganda, UK, US, Venezuela, Zambia
countries that have signed, but not yet ratified - (17) Algeria,
Burkina Faso, Burundi, Cameroon, Chile, Ethiopia, Haiti, Libya, Mali,
Pakistan, Paraguay, Portugal, Somalia, Tanzania, Uruguay, Vietnam,
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law of the Sea (LOS)
note - abbreviated as Law of the Sea
opened for signature - 10 December 1982
entered into force - 16 November 1994
objective - to set up a comprehensive new legal regime for the sea and
oceans; to include rules concerning environmental standards as well as
enforcement provisions dealing with pollution of the marine environment
parties - (137) Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bahrain, Bangladesh, Barbados,
Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burma, Cameroon, Cape Verde, Chile, China,
Comoros, Democratic Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti,
Dominica, Egypt, Equatorial Guinea, EU, Fiji, Finland, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Iceland, India,
Indonesia, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, South
Korea, Kuwait, Laos, Lebanon, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Monaco, Mongolia, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ,
Nicaragua, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Philippines, Poland, Portugal, Romania, Russia, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Sweden, Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Uganda,
Ukraine, UK, Uruguay, Vanuatu, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (33) Afghanistan,
Belarus, Bhutan, Burkina Faso, Burundi, Cambodia, Canada, Central
African Republic, Chad, Colombia, Republic of the Congo, Denmark,
Dominican Republic, El Salvador, Ethiopia, Hungary, Iran, North Korea,
Lesotho, Liberia, Libya, Liechtenstein, Malawi, Morocco, Niger, Niue,
Qatar, Rwanda, Swaziland, Switzerland, Thailand, Tuvalu, UAE
United Nations Convention to Combat Desertification in Those Countries
Experiencing Serious Drought and/or Desertification, Particularly in
Africa
note - abbreviated as Desertification
opened for signature - 14 October 1994
entered into force - 26 December 1996
objective - to combat desertification and mitigate the effects of
drought through national action programs that incorporate long-term
strategies supported by international cooperation and partnership
arrangements
parties - (178) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Luxembourg,
Madagascar, Malawi, Malaysia, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Thailand, Tajikistan, Tanzania, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
United Nations Framework Convention on Climate Change
note - abbreviated as Climate Change
opened for signature - 9 May 1992
entered into force - 21 March 1994
objective - to achieve stabilization of greenhouse gas concentrations
in the atmosphere at a low enough level to prevent dangerous
anthropogenic interference with the climate system
parties - (186) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and
Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkmenistan, Tuvalu,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (2) Afghanistan,','9af0b73d757b001cf590b480495344f91a24e04dd32881dcc69c8c9084f0d244','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74432599c58979023fa682655edce12510bc8a11f4ae3dbc4eca0eaa4200c432',2003,'ZM','Zambia','communications',814,'general assessment: facilities are aging but still among the
best in Sub-Saharan Africa
domestic: high-capacity microwave radio relay connects most larger
towns and cities; several cellular telephone services in operation;
Internet service is widely available; very small aperture terminal
(VSAT) networks are operated by private firms
international: satellite earth stations - 2 Intelsat (1 Indian Ocean
and 1 Atlantic Ocean)
mostly high plateau with some hills and mountains
5.25 children born/woman (2003 est.)
republic
50% (2000 est.)
conventional long form: Republic of Zambia
conventional short form: Zambia
former: Northern Rhodesia
Southern Africa, east of Angola
Africa
460 sq km (1998 est.)
total: 752,614 sq km
land: 740,724 sq km
water: 11,890 sq km
chief of mission: Ambassador Inonge MBIKUSITA-LEWANIKA
chancery: 2419 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 265-9717 through 9719
FAX: [1] (202) 332-0826
130,000 (including approximately 40,000 fixed telephones in
wireless local loop connections) (2002)
90,000 (2002)
5 (2001)
25,000 (2002)
.zm
21.5% (2001 est.)
1.2 million (2001 est.)
120,000 (2001 est.)
ZMK
52.6 (1998)
0 bbl/day (2001 est.)
11,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 16.5 years
male: 16.4 years
female: 16.6 years (2002)','51f7b8a1044e1a6d8ab18a7186ab8ac0fd4f32e6b1743895879c0bfe2853cdd8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ba9a973a0e60a46be00c784f7b3a3da5b4261f465bf3abfb621b3d8d032f5b8',2003,'AF','Afghanistan','communications',815,'mostly rugged mountains; plains in north and southwest
5.64 children born/woman (2003 est.)
transitional
NA%
conventional long form: Transitional Islamic State of
conventional short form: Afghanistan
local long form: Dowlat-e Eslami-ye Afghanestan
local short form: Afghanestan
former: Republic of Afghanistan
Southern Asia, north and west of Pakistan, east of Iran
Asia
23,860 sq km (1998 est.)
total: 647,500 sq km
land: 647,500 sq km
water: 0 sq km
chief of mission: ambassador Seyyed Tayeb JAWAD
chancery: 2341 Wyoming Avenue NW, Washington, DC 20008
telephone: 202-483-6410
FAX: 202-483-6487
consulate(s) general: New York
29,000 (1998)
NA
1 (2000)
NA
.af
0.01% (2001 est.)
NA
NA
AFA
0 bbl/day (2001 est.)
3,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.9 years
male: 19.1 years
female: 18.7 years (2002)
0 bbl (37257)
49.98 billion cu m (37257)
220 million cu m (2001 est.)
220 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','ef1f09d44f3094133a7291281f9cbe395984d7c752df25c76338873d27d26ec6','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90324de58554b232ec69c88a21e49f6949b2a5ffdd3d076984b23660ec9cf180',2003,'AL','Albania','communications',816,'mostly mountains and hills; small plains along coast
2.22 children born/woman (2003 est.)
emerging democracy
17% officially; may be as high as 30% (2001 est.)
conventional long form: Republic of Albania
conventional short form: Albania
local long form: Republika e Shqiperise
local short form: Shqiperia
former: People''s Socialist Republic of Albania
Southeastern Europe, bordering the Adriatic Sea and Ionian
Sea, between Greece and Serbia and Montenegro
Europe
3,400 sq km (1998 est.)
total: 28,748 sq km
land: 27,398 sq km
water: 1,350 sq km
chief of mission: Ambassador Dr. Fatos TARIFA
chancery: 2100 S Street NW, Washington, DC 20008
telephone: [1] (202) 223-4942
FAX: [1] (202) 628-7342
120,000 (2001)
250,000 (2001)
10 (2001)
12,000 (2001)
.al
NA
NA
NA
ALL
5,952 bbl/day (2001 est.)
22,400 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 26.5 years
male: 24.8 years
female: 28.1 years (2002)
185.5 million bbl (37257)
3.316 billion cu m (37257)
30 million cu m (2001 est.)
30 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','17b68b70d0d0f768be9c1596d1fb42557f6daa1bf4c7db837c34f1efedefa45a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc7bebd5fa1f146660f3ed3c8e0b4ec1a26d0cfd362b2dd7e418305abda73ef6',2003,'DZ','Algeria','communications',817,'mostly high plateau and desert; some mountains; narrow,
discontinuous coastal plain
2.55 children born/woman (2003 est.)
republic
31% (2002 est.)
conventional long form: People''s Democratic Republic of
conventional short form: Algeria
local long form: Al Jumhuriyah al Jaza''iriyah ad Dimuqratiyah ash
Sha''biyah
local short form: Al Jaza''ir
Northern Africa, bordering the Mediterranean Sea, between
Morocco and Tunisia
Africa
5,600 sq km (1998 est.)
total: 2,381,740 sq km
land: 2,381,740 sq km
water: 0 sq km
chief of mission: Ambassador Idriss JAZAIRY
chancery: 2137 Wyoming Ave NW, Washington, DC 20008
telephone: [1] (202) 265-2800
FAX: [1] (202) 667-2174
2.3 million (1998)
33,500 (1999)
2 (2000)
180,000 (2001)
.dz
0.1% - note: no country specific models provided (2001 est.)
NA
NA
DZD
35.3 (1995)
1.52 million bbl/day (2001 est.)
209,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 22.5 years
male: 22.3 years
female: 22.6 years (2002)
13.1 billion bbl (37257)
4.739 trillion cu m (37257)
80.3 billion cu m (2001 est.)
22.32 billion cu m (2001 est.)
0 cu m (2001 est.)
57.98 billion cu m (2001 est.)','107046bca5a5b33e1908bee4268299193f6731da7c4fa226e792dcd4bc9a968c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('834f915390770eff049492b4ca0801abbea9be6c6c082b0f9ad49f27d1a8f863',2003,'AS','American Samoa','communications',818,'five volcanic islands with rugged peaks and limited
coastal plains, two coral atolls (Rose Island, Swains Island)
3.3 children born/woman (2003 est.)
NA
6% (2000)
defense is the responsibility of the US
conventional long form: Territory of American Samoa
conventional short form: American Samoa
abbreviation: AS
Oceania, group of islands in the South Pacific Ocean,
about half way between Hawaii and New Zealand
Oceania
NA sq km
total: 199 sq km
land: 199 sq km
water: 0 sq km
note: includes Rose Island and Swains Island
none (territory of the US)
13,000 (1997)
2,550 (1997)
1 (2000)
NA
.as
NA%
NA
NA
USD
0 bbl/day (2001 est.)
3,800 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 21.6 years
male: 21.1 years
female: 22.2 years (2002)','86961f2131367e129e54dd5cf636dc26f03be9ed3e668468601e7e4ccbda8e1e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c1bb4cb720ccb142b569e3ac8f8d165def5ec57a35a6dfe4caf9ef90292f53d',2003,'AD','Andorra','communications',819,'rugged mountains dissected by narrow valleys
1.27 children born/woman (2003 est.)
parliamentary democracy (since March 1993) that retains as
its heads of state a coprincipality; the two princes are the
president of France and bishop of Seo de Urgel, Spain, who are
represented locally by coprinces'' representatives
0%
defense is the responsibility of France and Spain
conventional long form: Principality of Andorra
conventional short form: Andorra
local long form: Principat d''Andorra
local short form: Andorra
Southwestern Europe, between France and Spain
Europe
NA sq km
total: 468 sq km
land: 468 sq km
water: 0 sq km
chief of mission: Ambassador (vacant); Charge d''Affaires
Jelena V. PIA-COMELLA
chancery: 2 United Nations Plaza, 25th Floor, New York, NY 10017
telephone: [1] (212) 750-8064
FAX: [1] (212) 750-6630
32,946 (December 1998)
14,117 (December 1998)
1 (2000)
24,500 (2001)
.ad
NA%
NA
NA
EUR
total: 39.1 years
male: 39.4 years
female: 38.8 years (2002)','7f049d43dcda114382c9e9cec16e443cedb64a312ff3abac41855efc25b485dc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2488933c6bcb30e20985e7d8244f30824074869777680442f7065b55c983ffc2',2003,'AO','Angola','communications',820,'narrow coastal plain rises abruptly to vast interior plateau
6.38 children born/woman (2003 est.)
republic, nominally a multiparty democracy with a strong
presidential system
extensive unemployment and underemployment affecting more
than half the population (2001 est.)
conventional long form: Republic of Angola
conventional short form: Angola
local long form: Republica de Angola
local short form: Angola
former: People''s Republic of Angola
Southern Africa, bordering the South Atlantic Ocean, between
Namibia and Democratic Republic of the Congo
Africa
750 sq km (1998 est.)
total: 1,246,700 sq km
land: 1,246,700 sq km
water: 0 sq km
chief of mission: Ambassador Josefina Perpetua Pitra DIAKIDI
chancery: 2108 16th Street NW, Washington, DC 20009
telephone: [1] (202) 785-1156
FAX: [1] (202) 785-1258
consulate(s) general: Houston and New York
72,000 (1998)
25,800 (2000)
1 (2000)
60,000 (2002)
.ao
5.5% (2001 est.)
350,000 (2001 est.)
24,000 (2001 est.)
AOA
742,400 bbl/day (2001 est.)
31,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.2 years
male: 18.2 years
female: 18.2 years (2002)
5.691 billion bbl (37257)
79.57 billion cu m (37257)
530 million cu m (2001 est.)
530 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','d8f3aa6519994a3a54382abae6ee935ac9a83b773443318078f0ef5b14f94d32','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48d8b040427efc38b8a2f4243c1d8a5b3a1141d14ee0d9b7331d007331cec92c',2003,'AI','Anguilla','communications',821,'flat and low-lying island of coral and limestone
1.76 children born/woman (2003 est.)
NA
6.7% (2001)
defense is the responsibility of the UK
conventional long form: none
conventional short form: Anguilla
Caribbean, islands between the Caribbean Sea and North
Atlantic Ocean, east of Puerto Rico
Central America and the Caribbean
NA sq km
total: 102 sq km
land: 102 sq km
water: 0 sq km
none (overseas territory of the UK)
4,974 (2000)
1,629 (2000)
16 (2000)
919 (2000)
.ai
NA%
NA
NA
XCD
total: 30 years
male: 30 years
female: 29.9 years (2002)','1a2c92b448e830b8f40f70a31515653a2702634b28a3b99d7ad6a72b3fa0a799','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a864684544bc0815ca392e4e8ba820110cd113fe7a4774b0004ae44219c2f28',2003,'AQ','Antarctica','communications',822,'about 98% thick continental ice sheet and 2% barren rock,
with average elevations between 2,000 and 4,000 meters; mountain
ranges up to nearly 5,000 meters; ice-free coastal areas include
parts of southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo Sound; glaciers
form ice shelves along about half of the coastline, and floating ice
shelves constitute 11% of the area of the continent
Antarctic Treaty Summary - the Antarctic Treaty, signed
on 1 December 1959 and entered into force on 23 June 1961,
establishes the legal framework for the management of Antarctica.
The 24th Antarctic Treaty Consultative Meeting was held in Russia in
July 2001. At the end of 2001, there were 45 treaty member nations:
27 consultative and 18 non-consultative. Consultative (voting)
members include the seven nations that claim portions of Antarctica
as national territory (some claims overlap) and 20 nonclaimant
nations. The US and Russia have reserved the right to make claims.
The US does not recognize the claims of others. Antarctica is
administered through meetings of the consultative member nations.
Decisions from these meetings are carried out by these member
nations (within their areas) in accordance with their own national
laws. The year in parentheses indicates when an acceding nation was
voted to full consultative (voting) status, while no date indicates
the country was an original 1959 treaty signatory. Claimant nations
are - Argentina, Australia, Chile, France, New Zealand, Norway, and
the UK. Nonclaimant consultative nations are - Belgium, Brazil
(1983), Bulgaria (1998) China (1985), Ecuador (1990), Finland
(1989), Germany (1981), India (1983), Italy (1987), Japan, South
Korea (1989), Netherlands (1990), Peru (1989), Poland (1977),
Russia, South Africa, Spain (1988), Sweden (1988), Uruguay (1985),
and the US. Non-consultative (nonvoting) members, with year of
accession in parentheses, are - Austria (1987), Canada (1988),
Colombia (1989), Cuba (1984), Czech Republic (1993), Denmark (1965),
Estonia (2001), Greece (1987), Guatemala (1991), Hungary (1984),
North Korea (1987), Papua New Guinea (1981), Romania (1971),
Slovakia (1993), Switzerland (1990), Turkey (1995), Ukraine (1992),
and Venezuela (1999). Article 1 - area to be used for peaceful
purposes only; military activity, such as weapons testing, is
prohibited, but military personnel and equipment may be used for
scientific research or any other peaceful purpose; Article 2 -
freedom of scientific investigation and cooperation shall continue;
Article 3 - free exchange of information and personnel, cooperation
with the UN and other international agencies; Article 4 - does not
recognize, dispute, or establish territorial claims and no new
claims shall be asserted while the treaty is in force; Article 5 -
prohibits nuclear explosions or disposal of radioactive wastes;
Article 6 - includes under the treaty all land and ice shelves south
of 60 degrees 00 minutes south and reserves high seas rights;
Article 7 - treaty-state observers have free access, including
aerial observation, to any area and may inspect all stations,
installations, and equipment; advance notice of all expeditions and
of the introduction of military personnel must be given; Article 8 -
allows for jurisdiction over observers and scientists by their own
states; Article 9 - frequent consultative meetings take place among
member nations; Article 10 - treaty states will discourage
activities by any country in Antarctica that are contrary to the
treaty; Article 11 - disputes to be settled peacefully by the
parties concerned or, ultimately, by the ICJ; Articles 12, 13, 14 -
deal with upholding, interpreting, and amending the treaty among
involved nations. Other agreements - some 200 recommendations
adopted at treaty consultative meetings and ratified by governments
include - Agreed Measures for Fauna and Flora (1964) which were
later incorporated into the Environmental Protocol; Convention for
the Conservation of Antarctic Seals (1972); Convention on the
Conservation of Antarctic Marine Living Resources (1980); a mineral
resources agreement was signed in 1988 but remains unratified; the
Protocol on Environmental Protection to the Antarctic Treaty was
signed 4 October 1991 and entered into force 14 January 1998; this
agreement provides for the protection of the Antarctic environment
through five specific annexes: 1) marine pollution, 2) fauna and
flora, 3) environmental impact assessments, 4) waste management, and
5) protected area management; it prohibits all activities relating
to mineral resources except scientific research.
the Antarctic Treaty prohibits any measures of a military
nature, such as the establishment of military bases and
fortifications, the carrying out of military maneuvers, or the
testing of any type of weapon; it permits the use of military
personnel or equipment for scientific research or for any other
peaceful purposes
conventional long form: none
conventional short form: Antarctica
continent mostly south of the Antarctic Circle
Antarctic Region
0 sq km (1998 est.)
total: 14 million sq km
land: 14 million sq km (280,000 sq km ice-free, 13.72 million sq km
ice-covered) (est.)
note: fifth-largest continent, following Asia, Africa, North
America, and South America, but larger than Australia and the
subcontinent of Europe
0
note: information for US bases only (2001)
NA; Iridium system in use
NA
.aq','bc7fac9144a5baadd8bf7975d3490c0e76ad6b4fc514d1e571ed001ff9a416b2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('724656b1470eeab205f98e4c2e36eac4832ea047a4055db35dc6f4acc9447442',2003,'AG','Antigua and Barbuda','communications',823,'mostly low-lying limestone and coral islands,
with some higher volcanic areas
Arctic Ocean
central surface covered by a perennial drifting polar
icepack that averages about 3 meters in thickness, although pressure
ridges may be three times that size; clockwise drift pattern in the
Beaufort Gyral Stream, but nearly straight-line movement from the
New Siberian Islands (Russia) to Denmark Strait (between Greenland
and Iceland); the icepack is surrounded by open seas during the
summer, but more than doubles in size during the winter and extends
to the encircling landmasses; the ocean floor is about 50%
continental shelf (highest percentage of any ocean) with the
remainder a central basin interrupted by three submarine ridges
(Alpha Cordillera, Nansen Cordillera, and Lomonosov Ridge)
2.28 children born/woman (2003 est.)
constitutional monarchy with UK-style parliament
11% (2001 est.)
conventional long form: none
conventional short form: Antigua and Barbuda
Caribbean, islands between the Caribbean Sea and
the North Atlantic Ocean, east-southeast of Puerto Rico
Arctic Ocean
body of water between Europe, Asia, and North America,
mostly north of the Arctic Circle
Central America and the Caribbean
Arctic Ocean
Arctic Region
NA sq km
total: 443 sq km (Antigua 280 sq km; Barbuda 161
sq km)
land: 443 sq km
water: 0 sq km
note: includes Redonda, 1.6 sq km
Arctic Ocean
total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea, Beaufort Sea, Chukchi Sea,
East Siberian Sea, Greenland Sea, Hudson Bay, Hudson Strait, Kara
Sea, Laptev Sea, Northwest Passage, and other tributary water bodies
chief of mission: Ambassador (vacant)
chancery: 3216 New Mexico Avenue NW, Washington, DC 20016
telephone: [1] (202) 362-5211
FAX: [1] (202) 362-5225
consulate(s) general: Miami
28,000 (1996)
1,300 (1996)
16 (2000)
5,000 (2001)
.ag
NA%
NA
NA
XCD
0 bbl/day (2001 est.)
3,600 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 29.1 years
male: 28.6 years
female: 29.6 years (2002)','a2d99c96bef963ce486f7beea31d99184f4c4de0eb94f9d9bb5f4f0a7a029074','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74939e5544122e816edadff8f5a25b571e058faab451838d5f4da44ebf68c8ff',2003,'AR','Argentina','communications',824,'rich plains of the Pampas in northern half, flat to
rolling plateau of Patagonia in south, rugged Andes along western
border
2.28 children born/woman (2003 est.)
republic
21.5% (37377)
conventional long form: Argentine Republic
conventional short form: Argentina
local long form: Republica Argentina
local short form: Argentina
Southern South America, bordering the South Atlantic
Ocean, between Chile and Uruguay
South America
15,610 sq km (1998 est.)
total: 2,766,890 sq km
land: 2,736,690 sq km
water: 30,200 sq km
chief of mission: Ambassador Jose Octavio BORDON
chancery: 1600 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 238-6400
FAX: [1] (202) 332-3171
consulate(s) general: Atlanta, Chicago, Houston, Los Angeles, Miami,
New York
7.5 million (1998)
3 million (December 1999)
33 (2000)
3.88 million (2001)
.ar
0.7% (2001 est.)
130,000 (2001 est.)
1,800 (2001 est.)
ARS
828,600 bbl/day (2001 est.)
486,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 29 years
male: 28 years
female: 29.9 years (2002)
2.927 billion bbl (37257)
768 billion cu m (37257)
37.15 billion cu m (2001 est.)
31.1 billion cu m (2001 est.)
0 cu m (2001 est.)
6.05 billion cu m (2001 est.)','e25025892eb49ba0c89f6626f40c69bd36786f9eeece0849627b477939949046','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('014079276be8af9ea89dd431254b661e79cabd2e244fd67dd5947b30978b4fd4',2003,'AM','Armenia','communications',825,'Armenian Highland with mountains; little forest land; fast
flowing rivers; good soil in Aras River valley
1.56 children born/woman (2003 est.)
republic
20% (2001 est.)
conventional long form: Republic of Armenia
conventional short form: Armenia
local long form: Hayastani Hanrapetut''yun
local short form: Hayastan
former: Armenian Soviet Socialist Republic; Armenian Republic
Southwestern Asia, east of Turkey
Asia
2,870 sq km (1998 est.)
total: 29,800 sq km
land: 28,400 sq km
water: 1,400 sq km
chief of mission: Ambassador Arman KIRAKOSSIAN
chancery: 2225 R Street NW, Washington, DC 20008
telephone: [1] (202) 319-1976
FAX: [1] (202) 319-2982
consulate(s) general: Los Angeles
600,000 (2002)
50,000 (2002)
9 (2001)
30,000 (2001)
.am
0.2% (2001 est.)
less than 2,400 (2001 est.)
less than 100 (2001 est.)
AMD
44.4 (1996)
0 bbl/day (2001 est.)
5,700 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 32.3 years
male: 30.6 years
female: 34.1 years (2002)
0 cu m (2001 est.)
1.4 billion cu m (2001 est.)
1.4 billion cu m (2001 est.)
0 cu m (2001 est.)','20620588395ad9767143344933f02caa5c74f8c6e76557abd3256b3975b888b7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcaaf1441d8443124b7da155acd96c1c47a5113bfe37b30c1f1ffab381cfdfb4',2003,'AW','Aruba','communications',826,'flat with a few hills; scant vegetation
Ashmore and Cartier Islands
low with sand and coral
Atlantic Ocean
surface usually covered with sea ice in Labrador Sea,
Denmark Strait, and coastal portions of the Baltic Sea from October
to June; clockwise warm-water gyre (broad, circular system of
currents) in the northern Atlantic, counterclockwise warm-water gyre
in the southern Atlantic; the ocean floor is dominated by the
Mid-Atlantic Ridge, a rugged north-south centerline for the entire
Atlantic basin
1.79 children born/woman (2003 est.)
parliamentary democracy
0.6%
defense is the responsibility of the Kingdom of the Netherlands
Ashmore and Cartier Islands
defense is the responsibility of
Australia; periodic visits by the Royal Australian Navy and Royal
Australian Air Force
Baker Island
defense is the responsibility of the US; visited
annually by the US Coast Guard
Bassas da India
defense is the responsibility of France
conventional long form: none
conventional short form: Aruba
Ashmore and Cartier Islands
conventional long form: Territory of
Ashmore and Cartier Islands
conventional short form: Ashmore and Cartier Islands
Caribbean, island in the Caribbean Sea, north of Venezuela
Ashmore and Cartier Islands
Southeastern Asia, islands in the Indian
Ocean, northwest of Australia, south of the Indonesian half of Timor
island
Atlantic Ocean
body of water between Africa, Europe, the Southern
Ocean, and the Western Hemisphere
Central America and the Caribbean
Ashmore and Cartier Islands
Southeast Asia
Atlantic Ocean
Political Map of the World
0.01 sq km (1998 est.)
Ashmore and Cartier Islands
0 sq km (1998 est.)
total: 193 sq km
land: 193 sq km
water: 0 sq km
Ashmore and Cartier Islands
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes Ashmore Reef (West, Middle, and East Islets) and
Cartier Island
Atlantic Ocean
total: 76.762 million sq km
note: includes Baltic Sea, Black Sea, Caribbean Sea, Davis Strait,
Denmark Strait, part of the Drake Passage, Gulf of Mexico, Labrador
Sea, Mediterranean Sea, North Sea, Norwegian Sea, almost all of the
Scotia Sea, and other tributary water bodies
none (represented by the Kingdom of the Netherlands)
Ashmore and Cartier Islands
none (territory of Australia)
33,000 (1997)
3,402 (1997)
NA
24,000 (2002)
.aw
NA%
NA
NA
AWG
0 bbl/day (2001 est.)
6,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 37.1 years
male: 35.3 years
female: 38.5 years (2002)','912c71db5edc6671b8363e0f764999eae6296e6ef6526dd5b2b392c990f78753','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c4448055fd823d9f820921924b3acb7c4c843c0c24e9f50ba739fc1cdb06f88',2003,'AU','Australia','communications',827,'mostly low plateau with deserts; fertile plain in southeast
1.76 children born/woman (2003 est.)
democratic, federal-state system recognizing the British
monarch as sovereign
6.3% (2002)
conventional long form: Commonwealth of Australia
conventional short form: Australia
Oceania, continent between the Indian Ocean and the South
Pacific Ocean
Oceania
24,000 sq km (1998 est.)
total: 7,686,850 sq km
land: 7,617,930 sq km
water: 68,920 sq km
note: includes Lord Howe Island and Macquarie Island
chief of mission: Ambassador Michael J. THAWLEY
chancery: 1601 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 797-3000
FAX: [1] (202) 797-3168
consulate(s) general: Atlanta, Chicago, Honolulu, Los Angeles, New
York, and San Francisco
10.05 million (2000)
8.6 million (2000)
571 (2002)
10.63 million (2002)
.au
0.1% (2001 est.)
12,000 (2001 est.)
less than 100 (2001 est.)
AUD
35.2 (1994)
731,000 bbl/day (2001 est.)
796,500 bbl/day (2001 est.)
530,800 bbl/day (2001)
523,400 bbl/day (2001)
total: 36 years
male: 35.2 years
female: 36.8 years (2002)
3.664 billion bbl (37257)
2.407 trillion cu m (37257)
33.08 billion cu m (2001 est.)
23.33 billion cu m (2001 est.)
0 cu m (2001 est.)
9.744 billion cu m (2001 est.)','61a494876cb73517f5e0485291aa6a01857c55585bfc1ecbc6f68e292458a7c9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bff1878d4184524231f32ed012ac2334b5bfe52af076b32ef03dd51b4716e3ce',2003,'AT','Austria','communications',828,'in the west and south mostly mountains (Alps); along the
eastern and northern margins mostly flat or gently sloping
1.41 children born/woman (2003 est.)
federal republic
4.8% (2002 est.)
conventional long form: Republic of Austria
conventional short form: Austria
local long form: Republik Oesterreich
local short form: Oesterreich
Central Europe, north of Italy and Slovenia
Europe
457 sq km (2000 est.)
total: 83,858 sq km
land: 82,738 sq km
water: 1,120 sq km
chief of mission: Ambassador Eva NOWOTNY
chancery: 3524 International Court NW, Washington, DC 20008-3035
telephone: [1] (202) 895-6700
FAX: [1] (202) 895-6750
consulate(s) general: Chicago, Los Angeles, and New York
4 million (consisting of 3,600,000 analog main lines plus
400,000 Integrated Services Digital Network connections); in
addition, there are 100,000 Asymmetric Digital Services lines (2001)
6 million (2001)
37 (2000)
3.7 million (2002)
.at
0.2% (2001 est.)
9,900 (2001 est.)
less than 100 (2001 est.)
EUR
31 (1995)
20,670 bbl/day (2001 est.)
262,400 bbl/day (2001 est.)
262,000 bbl/day (2001)
35,470 bbl/day (2001)
total: 39.4 years
male: 38.2 years
female: 40.7 years (2002)
85.69 million bbl (37257)
24.9 billion cu m (37257)
1.731 billion cu m (2001 est.)
7.81 billion cu m (2001 est.)
6.033 billion cu m (2001 est.)
403 million cu m (2001 est.)','73ebfcd27dc6b9a1c60c66323b7804fe7d80f514213b6e7c1abf5c1c00b1dfbc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b12ad7635cf465889e89728f6408ee47be8cd663031ec711ffd8e7a09f43dfe6',2003,'AZ','Azerbaijan','communications',829,'large, flat Kur-Araz Ovaligi (Kura-Araks Lowland) (much
of it below sea level) with Great Caucasus Mountains to the north,
Qarabag Yaylasi (Karabakh Upland) in west; Baku lies on Abseron
Yasaqligi (Apsheron Peninsula) that juts into Caspian Sea
Bahamas, The
long, flat coral formations with some low rounded hills
2.34 children born/woman (2003 est.)
Bahamas, The
2.25 children born/woman (2003 est.)
republic
Bahamas, The
constitutional parliamentary democracy
16% (official rate is 1.2%) (2003 est.)
Bahamas, The
6.9% (2001 est.)
conventional long form: Republic of Azerbaijan
conventional short form: Azerbaijan
local long form: Azarbaycan Respublikasi
local short form: none
former: Azerbaijan Soviet Socialist Republic
Bahamas, The
conventional long form: Commonwealth of The Bahamas
conventional short form: The Bahamas
Southwestern Asia, bordering the Caspian Sea, between
Iran and Russia, with a small European portion north of the Caucasus
range
Bahamas, The
Caribbean, chain of islands in the North Atlantic
Ocean, southeast of Florida, northeast of Cuba
Asia
Bahamas, The
Central America and the Caribbean
14,550 sq km (1998 est.)
Bahamas, The
NA sq km
total: 86,600 sq km
land: 86,100 sq km
water: 500 sq km
note: includes the exclave of Naxcivan Autonomous Republic and the
Nagorno-Karabakh region; the region''s autonomy was abolished by
Azerbaijani Supreme Soviet on 26 November 1991
Bahamas, The
total: 13,940 sq km
land: 10,070 sq km
water: 3,870 sq km
chief of mission: Ambassador Hafiz PASHAYEV
chancery: 2741 34th Street NW, Washington, DC 20008
telephone: [1] (202) 337-3500
FAX: [1] (202) 337-5911
Bahamas, The
chief of mission: Ambassador Joshua SEARS
chancery: 2220 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 319-2660
FAX: [1] (202) 319-2668
consulate(s) general: Miami and New York
865,000 (2002)
Bahamas, The
96,000 (1997)
800,000 (2002)
Bahamas, The
6,152 (1997)
2 (2000)
Bahamas, The
19 (2000)
25,000 (2002)
Bahamas, The
16,900 (2002)
.az
Bahamas, The
.bs
less than 0.1% (2001 est.)
Bahamas, The
3.5% (2001 est.)
less than 1,400 (2001 est.)
Bahamas, The
6,200 (2001 est.)
less than 100 (2001 est.)
Bahamas, The
610 (2001 est.)
AZM
Bahamas, The
BSD
36 (1995)
307,200 bbl/day (2001 est.)
Bahamas, The
0 bbl/day (2001 est.)
140,000 bbl/day (2001 est.)
Bahamas, The
23,000 bbl/day (2001 est.)
NA (2001)
Bahamas, The
NA (2001)
NA (2001)
Bahamas, The
NA (2001)
total: 27.1 years
male: 25.7 years
female: 28.6 years (2002)
Bahamas, The
total: 27 years
male: 26.2 years
female: 27.7 years (2002)
589 million bbl (37257)
62.3 billion cu m (37257)
5.72 billion cu m (2001 est.)
6.72 billion cu m (2001 est.)
1 billion cu m (2001 est.)
0 cu m (2001 est.)','37c37b5a06f14f263adde52ce5ca41e9bdad57efe181faedcb6dae0622ecee20','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed56e18ac7d52c021b5825e54583db59b433d5ab04b41db9a41402c062197cd2',2003,'BH','Bahrain','communications',830,'mostly low desert plain rising gently to low central
escarpment
Baker Island
low, nearly level coral island surrounded by a narrow
fringing reef
2.71 children born/woman (2003 est.)
constitutional hereditary monarchy
15% (1998 est.)
conventional long form: Kingdom of Bahrain
conventional short form: Bahrain
local long form: Mamlakat al Bahrayn
local short form: Al Bahrayn
former: Dilmun
Baker Island
conventional long form: none
conventional short form: Baker Island
Middle East, archipelago in the Persian Gulf, east of Saudi
Arabia
Baker Island
Oceania, atoll in the North Pacific Ocean, about half
way between Hawaii and Australia
Middle East
Baker Island
Oceania
50 sq km (1998 est.)
Baker Island
0 sq km (1998 est.)
total: 665 sq km
land: 665 sq km
water: 0 sq km
Baker Island
total: 1.4 sq km
land: 1.4 sq km
water: 0 sq km
chief of mission: Ambassador Khalifa bin Ali bin Rashid AL
KHALIFA
chancery: 3502 International Drive NW, Washington, DC 20008
telephone: [1] (202) 342-0741
FAX: [1] (202) 362-2192
consulate(s) general: New York
152,000 (1997)
58,543 (1997)
1 (2000)
140,200 (2002)
.bh
0.3% (2001 est.)
less than 1,000
NA
BHD
43,000 bbl/day (2001 est.)
31,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 28.7 years
male: 31.6 years
female: 25.1 years (2002)
62.28 million bbl (37257)
46 billion cu m (37257)
8.9 billion cu m (2001 est.)
8.9 billion cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','b12dee1121a92e0091c458bf239772cfbb411578b2dbb6161e30e6bce2e1dd1d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d4bb52f4a3acf48897f997d2705e616f5707831b5417585101bd07548dea81c',2003,'BD','Bangladesh','communications',831,'mostly flat alluvial plain; hilly in southeast
3.17 children born/woman (2003 est.)
parliamentary democracy
40% (includes underemployment) (2002 est.)
conventional long form: People''s Republic of Bangladesh
conventional short form: Bangladesh
former: East Pakistan
Southern Asia, bordering the Bay of Bengal, between Burma
and India
Asia
38,440 sq km (1998 est.)
total: 144,000 sq km
land: 133,910 sq km
water: 10,090 sq km
chief of mission: Ambassador Syed Hasan AHMAD
chancery: 3510 International Drive NW, Washington, DC 20008
telephone: [1] (202) 244-0183
FAX: [1] (202) 244-5366
consulate(s) general: Los Angeles and New York
500,000 (2000)
283,000 (2000)
10 (2000)
150,000 (2002)
.bd
less than 0.1% (2001 est.)
13,000 (2001 est.)
650 (2001 est.)
BDT
33.6 (FY 95/96)
3,581 bbl/day (2001 est.)
71,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 21.2 years
male: 21.2 years
female: 21.1 years (2002)
28.45 million bbl (37257)
150.3 billion cu m (37257)
9.9 billion cu m (2001 est.)
9.9 billion cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','a3507ecc0e1b6d7f66725f6faccd127f0ccdf7d72b297c19115caa909c8deb91','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4484977f16475c1fef3fd51d4f607bb63f166de70f95059770938529d7b3434d',2003,'BB','Barbados','communications',832,'relatively flat; rises gently to central highland region
Bassas da India
volcanic rock
1.65 children born/woman (2003 est.)
parliamentary democracy; independent sovereign state within
the Commonwealth
10% (2001 est.)
conventional long form: none
conventional short form: Barbados
Bassas da India
conventional long form: none
conventional short form: Bassas da India
Caribbean, island in the North Atlantic Ocean, northeast of
Venezuela
Bassas da India
Southern Africa, islands in the southern Mozambique
Channel, about one-half of the way from Madagascar to Mozambique
Central America and the Caribbean
Bassas da India
Africa
10 sq km (1998 est.)
Bassas da India
0 sq km (1998 est.)
total: 431 sq km
land: 431 sq km
water: 0 sq km
Bassas da India
total: 0.2 sq km
land: 0.2 sq km
water: 0 sq km
chief of mission: Ambassador Michael Ian KING
chancery: 2144 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 339-9201
FAX: [1] (202) 332-7467
consulate(s) general: Miami and New York
consulate(s): Los Angeles
108,000 (1997)
8,013 (1997)
19 (2000)
6,000 (2000)
.bb
1.2% - note: no country specific models provided (2001 est.)
1,800 (2001 est.)
250 (2001 est.)
BBD
1,271 bbl/day (2001 est.)
10,900 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 33.3 years
male: 32.2 years
female: 34.4 years (2002)
1.254 million bbl (37257)
70.79 million cu m (37257)
29.17 million cu m (2001 est.)
29.17 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','1d58db441c86bb79406d5d662a69c80ac480382c54b6a48bd27110df24b89cbd','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e90ce7251c7fd470ecb9ba957aa819448a929c61e04e465d52c9d15016e206af',2003,'BY','Belarus','communications',833,'generally flat and contains much marshland
1.34 children born/woman (2003 est.)
republic
2.1% officially registered unemployed (December 2000); large
number of underemployed workers
conventional long form: Republic of Belarus
conventional short form: Belarus
local long form: Respublika Byelarus''
local short form: none
former: Belorussian (Byelorussian) Soviet Socialist Republic
Eastern Europe, east of Poland
Europe
1,150 sq km (1998 est.)
total: 207,600 sq km
land: 207,600 sq km
water: 0 sq km
chief of mission: Ambassador Mikhail KHVOSTOV
chancery: 1619 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 986-1604
FAX: [1] (202) 986-1805
consulate(s) general: New York
2.313 million (1997)
8,167 (1997)
23 (2002)
422,000 (2002)
.by
0.3% (2001 est.)
15,000 (2001 est.)
1,000 (2001 est.)
BYB/BYR
21.7 (1998)
37,000 bbl/day (2001 est.)
230,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 36.7 years
male: 34.1 years
female: 39.3 years (2002)
200 million cu m (2001 est.)
18 billion cu m (2001 est.)
17.8 billion cu m (2001 est.)
0 cu m (2001 est.)','f1bee5287d5244f0ef96acdfbf8e1ab4a68c664b4d5e59451e2bf5d3989ab95d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d053edd99de80be93294078f342e20a3ba5c2a7c293739e60ec4ed01505465fa',2003,'BE','Belgium','communications',834,'flat coastal plains in northwest, central rolling hills,
rugged mountains of Ardennes Forest in southeast
1.62 children born/woman (2003 est.)
federal parliamentary democracy under a constitutional
monarch
7.2% (2002 est.)
conventional long form: Kingdom of Belgium
conventional short form: Belgium
local long form: Royaume de Belgique/Koninkrijk Belgie
local short form: Belgique/Belgie
Western Europe, bordering the North Sea, between France and
the Netherlands
Europe
40 sq km (includes Luxembourg) (1998 est.)
total: 30,510 sq km
land: 30,230 sq km
water: 280 sq km
chief of mission: Ambassador Franciskus VAN DAELE
chancery: 3330 Garfield Street NW, Washington, DC 20008
telephone: [1] (202) 333-6900
FAX: [1] (202) 333-3079
consulate(s) general: Atlanta, Chicago, Los Angeles, and New York
4.769 million (1997)
974,494 (1997)
61 (2000)
3.76 million (2002)
.be
0.2% (2001 est.)
8,500 (2001 est.)
less than 100 (2001 est.)
EUR
28.7 (1996)
Bolivia
58.9 (1997)
0 bbl/day (2001 est.)
595,100 bbl/day (2001 est.)
1.042 million bbl/day (2001)
450,000 bbl/day (2001)
total: 40 years
male: 38.7 years
female: 41.3 years (2002)
0 cu m (2001 est.)
Bolivia
4.05 billion cu m (2001 est.)
15.5 billion cu m (2001 est.)
Bolivia
1.15 billion cu m (2001 est.)
15.4 billion cu m (2001 est.)
Bolivia
0 cu m (2001 est.)
0 cu m (2001 est.)
Bolivia
2.9 billion cu m (2001 est.)','6d7c53b378dbe3e6515cd7a697e196fba143524f9558c4742a6ccc6c908e6e19','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28119ab4b2bed30ec3be67cda0b928b8dbea0ed54623742525ea2e5794be6255',2003,'BZ','Belize','communications',835,'flat, swampy coastal plain; low mountains in south
3.86 children born/woman (2003 est.)
parliamentary democracy
9.1% (2002)
conventional long form: none
conventional short form: Belize
former: British Honduras
Middle America, bordering the Caribbean Sea, between
Guatemala and Mexico
Central America and the Caribbean
30 sq km (1998 est.)
total: 22,966 sq km
land: 22,806 sq km
water: 160 sq km
chief of mission: Ambassador Lisa M. SHOMAN
chancery: 2535 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 332-9636
FAX: [1] (202) 332-6888
consulate(s) general: Los Angeles
31,000 (1997)
3,023 (1997)
2 (2000)
18,000 (2002)
.bz
2% (2001 est.)
2,500 (2001 est.)
300 (2001 est.)
BZD
0 bbl/day (2001 est.)
5,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.9 years
male: 18.8 years
female: 19 years (2002)','4343a1c3874ea9a05ccbdbd1ea5b5cc9caa72dec56de2ea9fc35d1167cfb49e6','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08dfb1a082648469d8dce516964fe39aed489ff79f701cd1727c0ea0963f3d7f',2003,'BJ','Benin','communications',836,'mostly flat to undulating plain; some hills and low mountains
6.04 children born/woman (2003 est.)
republic under multiparty democratic rule; dropped
Marxism-Leninism December 1989; democratic reforms adopted February
1990; transition to multiparty system completed 4 April 1991
NA%
conventional long form: Republic of Benin
conventional short form: Benin
local long form: Republique du Benin
local short form: Benin
former: Dahomey
Western Africa, bordering the Bight of Benin, between Nigeria
and Togo
Africa
120 sq km (1998 est.)
total: 112,620 sq km
land: 110,620 sq km
water: 2,000 sq km
chief of mission: Ambassador Cyrille Segbe OGUIN
chancery: 2124 Kalorama Road NW, Washington, DC 20008
telephone: [1] (202) 232-6656
FAX: [1] (202) 265-1996
51,000 (2000)
55,500 (2000)
4 (2002)
25,000 (2002)
.bj
3.6% (2001 est.)
120,000 (2001 est.)
8,100 (2001 est.)
XOF
700 bbl/day (2001 est.)
11,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 16.4 years
male: 15.9 years
female: 16.9 years (2002)
4.105 million bbl (37257)
Bolivia
458.8 million bbl (37257)
608.8 million cu m (37257)
Bolivia
727.2 billion cu m (37257)','6b0867ae2873a05c6949f7878802a67b2bbc2c3a4cd6e09f881cec53c15ac8b2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea917ba4574fbb98696f01c3166529ff49bb38b2dd77dff55d82396f02964ce6',2003,'BM','Bermuda','communications',837,'low hills separated by fertile depressions
1.9 children born/woman (2003 est.)
parliamentary British overseas territory with internal
self-government
4.5% (1993)
defense is the responsibility of the UK
conventional long form: none
conventional short form: Bermuda
former: Somers Islands
North America, group of islands in the North Atlantic Ocean,
east of North Carolina (US)
North America
NA sq km
total: 53.3 sq km
land: 53.3 sq km
water: 0 sq km
none (overseas territory of the UK)
52,000 (1997)
7,980 (1996)
20 (2000)
25,000 (2000)
.bm
NA%
NA
NA
BMD
0 bbl/day (2001 est.)
4,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 38.7 years
male: 37.8 years
female: 39.6 years (2002)','4478559e803ed51aa4ced9a52fa1b77ee1f855eef6fc453c823760db5aabb5ab','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76346286b8d633dcd81fcc24ed5cc09e40ce8a16b63f6f055d80deddfd46910f',2003,'BT','Bhutan','communications',838,'mostly mountainous with some fertile valleys and savanna
Bolivia
rugged Andes Mountains with a highland plateau (Altiplano),
hills, lowland plains of the Amazon Basin
4.94 children born/woman (2003 est.)
Bolivia
3.23 children born/woman (2003 est.)
monarchy; special treaty relationship with India
Bolivia
republic
NA%
Bolivia
7.6%
note: widespread underemployment (2000)
conventional long form: Kingdom of Bhutan
conventional short form: Bhutan
Bolivia
conventional long form: Republic of Bolivia
conventional short form: Bolivia
local long form: Republica de Bolivia
local short form: Bolivia
Southern Asia, between China and India
Bolivia
Central South America, southwest of Brazil
Asia
Bolivia
South America
400 sq km (1998 est.)
Bolivia
1,280 sq km (1998 est.)
total: 47,000 sq km
land: 47,000 sq km
water: 0 sq km
Bolivia
total: 1,098,580 sq km
land: 1,084,390 sq km
water: 14,190 sq km
none; note - Bhutan has a Permanent Mission to the UN;
address: 2 United Nations Plaza, 27th Floor, New York, NY 10017;
telephone [1] (212) 826-1919; the Bhutanese mission to the UN has
consular jurisdiction in the US
consulate(s) general: New York
Bolivia
chief of mission: Ambassador Jaime APARICIO Otero
chancery: 3014 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 483-4410
FAX: [1] (202) 328-3712
consulate(s) general: Miami, New York, and San Francisco
consulate(s): Washington, DC
6,000 (1997)
Bolivia
327,600 (1996)
NA
Bolivia
116,000 (1997)
NA
Bolivia
9 (2000)
2,500 (2002)
Bolivia
78,000 (2000)
.bt
Bolivia
.bo
less than 0.1% (2001 est.)
Bolivia
0.1% - note: no country specific models provided (2001 est.)
less than 100 (1999 est.)
Bolivia
4,600 (2001 est.)
NA
Bolivia
290 (2001 est.)
BTN; INR
Bolivia
BOB
0 bbl/day (2001 est.)
Bolivia
44,340 bbl/day (2001 est.)
1,020 bbl/day (2001 est.)
Bolivia
49,000 bbl/day (2001 est.)
NA (2001)
Bolivia
NA (2001)
NA (2001)
Bolivia
NA (2001)
total: 20.1 years
male: 19.9 years
female: 20.3 years (2002)
Bolivia
total: 20.8 years
male: 20.1 years
female: 21.5 years (2002)','8627c45db517d7e4fb87077cc7d25cc557273c487016b5f152189a851fba558b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3d7511830798f942778be7ea22fe964f1ae3f0338dab4aed1f4e04bb99b5fbc',2003,'BA','Bosnia and Herzegovina','communications',839,'mountains and valleys
1.71 children born/woman (2003 est.)
emerging federal democratic republic
40% (2002 est.)
The Dayton Agreement, signed in Paris on 14
December 1995, retained Bosnia and Herzegovina''s exterior border and
created a joint multi-ethnic and democratic government. This
national government - based on proportional representation similar
to that which existed in the former socialist regime - is charged
with conducting foreign, economic, and fiscal policy. The Dayton
Agreement also recognized a second tier of government, comprised of
two entities - a joint Bosniak/Croat Federation of Bosnia and
Herzegovina and the Bosnian Serb Republika Srpska (RS) - each
presiding over roughly one-half the territory. The Federation and RS
governments are charged with overseeing internal functions. The
Bosniak/Croat Federation is further divided into 10 cantons. The
Dayton Agreement established the Office of the High Representative
(OHR) to oversee the implementation of the civilian aspects of the
agreement.
conventional long form: none
conventional short form: Bosnia and Herzegovina
local long form: none
local short form: Bosna i Hercegovina
Southeastern Europe, bordering the Adriatic
Sea and Croatia
Europe
20 sq km (1998 est.)
total: 51,129 sq km
land: 51,129 sq km
water: 0 sq km
chief of mission: Ambassador Igor DAVIDOVIC
chancery: 2109 E Street NW, Washington, DC 20037
telephone: [1] (202) 337-1500
FAX: [1] (202) 337-1502
consulate(s) general: New York
303,000 (1997)
9,000 (1997)
3 (2000)
45,000 (2002)
.ba
less than 0.1% (2001 est.)
NA
100 (2001 est.)
BAM
0 bbl/day (2001 est.)
20,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 35.5 years
male: 35.1 years
female: 35.9 years (2002)
0 cu m (2001 est.)
300 million cu m (2001 est.)
300 million cu m (2001 est.)
0 cu m (2001 est.)','fc4da9c19973cf7070ad2a0c3e4036bdd463ba3a33a6443ee0fa1d2ae19f716b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('849a88d0f903698ec577ebe7d2760ea91e4fd9737336a1b6ae8fc2417721296c',2003,'BW','Botswana','communications',840,'predominantly flat to gently rolling tableland; Kalahari
Desert in southwest
3.27 children born/woman (2003 est.)
parliamentary republic
40% (official rate is 21%) (2001 est.)
conventional long form: Republic of Botswana
conventional short form: Botswana
former: Bechuanaland
Southern Africa, north of South Africa
Africa
10 sq km (1998 est.)
total: 600,370 sq km
land: 585,370 sq km
water: 15,000 sq km
chief of mission: Ambassador Lapologang Caesar LEKOA
chancery: 1531-1533 New Hampshire Avenue NW, Washington, DC 20036
telephone: [1] (202) 244-4990
FAX: [1] (202) 244-4164
131,000 (September 2001)
270,000 (September 2001)
11 (2001)
33,000 (2001)
.bw
38.8% (2001 est.)
330,000 (2001 est.)
26,000 (2001 est.)
BWP
0 bbl/day (2001 est.)
16,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 19.1 years
male: 18.4 years
female: 19.8 years (2002)','66e0fb7a2d67c028ea83096497964717dfe6411095cfb99e4e99b83b62f6a25f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c91be6e60a9d2e07a57395cafe426b15824802f8b201be07245fb530bb6189c5',2003,'BV','Bouvet Island','communications',841,'volcanic; coast is mostly inaccessible
defense is the responsibility of Norway
automatic meteorological station
Coral Sea Islands
there are automatic weather stations on many of
the isles and reefs relaying data to the mainland
Europa Island
1 meteorological station
Glorioso Islands
1 meteorological station
Juan de Nova Island
1 meteorological station
Saint Helena
Gough Island has a meteorological station
Tromelin Island
important meteorological station
This page was last updated on 18 December, 2003
======================================================================
@2140 Government - note
conventional long form: none
conventional short form: Bouvet Island
island in the South Atlantic Ocean, southwest of the
Cape of Good Hope (South Africa)
Antarctic Region
0 sq km (1998 est.)
total: 58.5 sq km
land: 58.5 sq km
water: 0 sq km
.bv','32398cab19cfe65896b13eba1bfea203d16e71174423c2fc3e5d042f9054df28','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e351ca25a702dd798bfad5a58dfe62f32a4059fae34a88dfa9e3ebe753f842b',2003,'BR','Brazil','communications',842,'mostly flat to rolling lowlands in north; some plains, hills,
mountains, and narrow coastal belt
2.01 children born/woman (2003 est.)
British Virgin Islands
1.72 children born/woman (2003 est.)
Brunei
2.37 children born/woman (2003 est.)
federative republic
British Virgin Islands
NA
Brunei
constitutional sultanate
6.4% (2001 est.)
British Virgin Islands
3% (1995)
Brunei
10% (2001 est.)
conventional long form: Federative Republic of Brazil
conventional short form: Brazil
local long form: Republica Federativa do Brasil
local short form: Brasil
Eastern South America, bordering the Atlantic Ocean
South America
26,560 sq km (1998 est.)
total: 8,511,965 sq km
land: 8,456,510 sq km
water: 55,455 sq km
note: includes Arquipelago de Fernando de Noronha, Atol das Rocas,
Ilha da Trindade, Ilhas Martin Vaz, and Penedos de Sao Pedro e Sao
Paulo
chief of mission: Ambassador Rubens Antonio BARBOSA; note -
Ambassador-Designate Roberto ABDENUR expected to arrive March 2004
chancery: 3006 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 238-2700
FAX: [1] (202) 238-2827
consulate(s) general: Boston, Chicago, Houston, Los Angeles, Miami,
New York, and San Francisco
17.039 million (1997)
4.4 million (1997)
British Virgin Islands
NA
Brunei
43,524 (1996)
50 (2000)
13.98 million (2002)
British Virgin Islands
NA
Brunei
35,000 (2002)
.br
0.7% (2001 est.)
British Virgin Islands
NA%
Brunei
0.2% (2001 est.)
610,000 (2001 est.)
British Virgin Islands
NA
Brunei
less than 100 (2001 est.)
8,400 (2001 est.)
British Virgin Islands
NA
Brunei
NA
BRL
British Virgin Islands
USD
Brunei
BND
60.7 (1998)
1.561 million bbl/day (2001 est.)
British Virgin Islands
0 bbl/day (2001 est.)
Brunei
217,200 bbl/day (2001 est.)
2.199 million bbl/day (2001 est.)
British Virgin Islands
420 bbl/day (2001 est.)
Brunei
13,000 bbl/day (2001 est.)
NA (2001)
British Virgin Islands
NA (2001)
Brunei
NA (2001)
NA (2001)
British Virgin Islands
NA (2001)
Brunei
NA (2001)
total: 27 years
male: 26.2 years
female: 27.7 years (2002)
British Virgin Islands
total: 30.7 years
male: 31 years
female: 30.4 years (2002)
Brunei
total: 26.4 years
male: 27 years
female: 25.7 years (2002)
8.507 billion bbl (37257)
Brunei
1.255 billion bbl (37257)
221.7 billion cu m (37257)
Brunei
315 billion cu m (37257)
5.95 billion cu m (2001 est.)
Brunei
10.35 billion cu m (2001 est.)
9.59 billion cu m (2001 est.)
Brunei
1.35 billion cu m (2001 est.)
3.64 billion cu m (2001 est.)
Brunei
0 cu m (2001 est.)
0 cu m (2001 est.)
Brunei
9 billion cu m (2001 est.)','0d87a6c40944c81b3c836196118a5313780620d0a360201e4cc8aa07d125c638','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8603dcebd408570b4ea16067b7fdaf854467ce759506c2ba00b724066a76d2c',2003,'IO','British Indian Ocean Territory','communications',843,'flat and low (most areas do not
exceed four meters in elevation)
British Virgin Islands
coral islands relatively flat; volcanic
islands steep, hilly
Brunei
flat coastal plain rises to mountains in east; hilly lowland
in west
defense is the responsibility of the
UK; the US lease on Diego Garcia expires in 2016
British Virgin Islands
defense is the responsibility of the UK
conventional long form: British
Indian Ocean Territory
conventional short form: none
abbreviation: BIOT
British Virgin Islands
conventional long form: none
conventional short form: British Virgin Islands
abbreviation: BVI
Brunei
conventional long form: Negara Brunei Darussalam
conventional short form: Brunei
archipelago in the Indian Ocean,
south of India, about one-half the way from Africa to Indonesia
British Virgin Islands
Caribbean, between the Caribbean Sea and the
North Atlantic Ocean, east of Puerto Rico
Brunei
Southeastern Asia, bordering the South China Sea and Malaysia
Political Map of the World
British Virgin Islands
Central America and the Caribbean
Brunei
Southeast Asia
0 sq km (1998 est.)
British Virgin Islands
NA sq km
Brunei
10 sq km (1998 est.)
total: 60 sq km
land: 60 sq km
water: 0 sq km
note: includes the entire Chagos Archipelago
British Virgin Islands
total: 153 sq km
land: 153 sq km
water: 0 sq km
note: comprised of 16 inhabited and more than 20 uninhabited
islands; includes the island of Anegada
Brunei
total: 5,770 sq km
land: 5,270 sq km
water: 500 sq km
none (overseas territory of the UK)
British Virgin Islands
none (overseas territory of the UK)
Brunei
chief of mission: Ambassador Anak Dato Haji PUTEH
chancery: 3520 International Court NW, Washington, DC 20008
telephone: [1] (202) 237-1838
FAX: [1] (202) 885-0560
NA
British Virgin Islands
10,000 (1996)
Brunei
79,000 (1996)
1 (2000)
British Virgin Islands
16 (2000)
Brunei
2 (2000)
.io
British Virgin Islands
.vg
Brunei
.bn','9a2c026ebd03ef58a6c41bc6586eba8498d811cc870c1800fc11a7046324ded7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47e441238493577c6e6bf9a6ef6a8e20349790b8d5a185690e19ceea993553d0',2003,'BG','Bulgaria','communications',844,'mostly mountains with lowlands in north and southeast
1.13 children born/woman (2003 est.)
parliamentary democracy
18% (2002 est.)
conventional long form: Republic of Bulgaria
conventional short form: Bulgaria
Southeastern Europe, bordering the Black Sea, between
Romania and Turkey
Europe
8,000 sq km (1998 est.)
total: 110,910 sq km
land: 110,550 sq km
water: 360 sq km
chief of mission: Ambassador Elena B. POPTODOROVA
chancery: 1621 22nd Street NW, Washington, DC 20008
telephone: [1] (202) 387-0174
FAX: [1] (202) 234-7973
consulate(s): New York
3,186,731 (2001)
1.054 million (2001)
200 (2001)
585,000 (2001)
.bg
less than 0.1% - note: no country specific models provided
(2001 est.)
346 (2001 est.)
100 (2001 est.)
BGN
26.4 (2001)
603 bbl/day (2001 est.)
94,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 40.5 years
male: 38.4 years
female: 42.4 years (2002)
8.1 million bbl (37257)
Burma
142.5 million bbl (37257)
3.724 billion cu m (37257)
Burma
314.4 billion cu m (37257)
4 million cu m (2001 est.)
Burma
7.35 billion cu m (2001 est.)
5.804 billion cu m (2001 est.)
Burma
2.15 billion cu m (2001 est.)
5.8 billion cu m (2001 est.)
Burma
0 cu m (2001 est.)
0 cu m (2001 est.)
Burma
5.2 billion cu m (2001 est.)','5deeb9bf0e6aa7dd99d044fea42408cbe394bc4421d82e6f21d53269c0edf656','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('329a5afc2a31553186b1161bb30a00e2f001350bb3a475c52e2f745c03aaf0d9',2003,'BF','Burkina Faso','communications',845,'mostly flat to dissected, undulating plains; hills in
west and southeast
Burma
central lowlands ringed by steep, rugged highlands
6.34 children born/woman (2003 est.)
Burma
2.15 children born/woman (2003 est.)
parliamentary republic
Burma
military regime
NA%
Burma
5.1% (2001 est.)
conventional long form: none
conventional short form: Burkina Faso
former: Upper Volta, Republic of Upper Volta
Burma
conventional long form: Union of Burma
conventional short form: Burma
local long form: Pyidaungzu Myanma Naingngandaw (translated by the
US Government as Union of Myanma and by the Burmese as Union of
Myanmar)
local short form: Myanma Naingngandaw
former: Socialist Republic of the Union of Burma
note: since 1989 the military authorities in Burma have promoted the
name Myanmar as a conventional name for their state; this decision
was not approved by any sitting legislature in Burma, and the US
Government did not adopt the name, which is a derivative of the
Burmese short-form name Myanma Naingngandaw
Western Africa, north of Ghana
Burma
Southeastern Asia, bordering the Andaman Sea and the Bay of
Bengal, between Bangladesh and Thailand
Africa
Burma
Southeast Asia
250 sq km (1998 est.)
Burma
15,920 sq km (1998 est.)
total: 274,200 sq km
land: 273,800 sq km
water: 400 sq km
Burma
total: 678,500 sq km
land: 657,740 sq km
water: 20,760 sq km
chief of mission: Ambassador Tertius ZONGO
chancery: 2340 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 332-5577
FAX: [1] (202) 667-1882
Burma
chief of mission: Ambassador LINN MYAING
chancery: 2300 S Street NW, Washington, DC 20008
telephone: [1] (202) 332-9044
FAX: [1] (202) 332-9046
consulate(s) general: New York
53,200 (2000)
Burma
250,000 (2000)
25,200 (2000)
Burma
8,492 (1997)
1 (2002)
Burma
1
note: as of September 2000, Internet connections were legal only for
the government, tourist offices, and a few large businesses (2000)
25,000 (2002)
Burma
10,000 (2002)
.bf
Burma
.mm
6.5% (2001 est.)
Burma
1.99% (2001 est.)
440,000 (2001 est.)
Burma
530,000 (2001 est.)
44,000 (2001 est.)
Burma
65,000 (2001 est.)
XOF
Burma
MMK
48.2 (1994)
0 bbl/day (2001 est.)
Burma
14,170 bbl/day (2001 est.)
8,000 bbl/day (2001 est.)
Burma
38,000 bbl/day (2001 est.)
NA (2001)
Burma
NA (2001)
NA (2001)
Burma
NA (2001)
total: 16.8 years
male: 16.4 years
female: 17.2 years (2002)
Burma
total: 25.3 years
male: 24.8 years
female: 25.9 years (2002)','65036d82c4993fa0d58684c616e741f4a7aa9d9b1451ff0f68f5bc9ed0640ee2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fb2805d570c7ec68b24953b8a1f863b3192693362b491b8ed531cf5994d2fc7',2003,'BI','Burundi','communications',846,'hilly and mountainous, dropping to a plateau in east, some
plains
5.99 children born/woman (2003 est.)
republic
NA%
conventional long form: Republic of Burundi
conventional short form: Burundi
local long form: Republika y''u Burundi
local short form: Burundi
former: Urundi
Central Africa, east of Democratic Republic of the Congo
Africa
740 sq km (1998 est.)
total: 27,830 sq km
land: 25,650 sq km
water: 2,180 sq km
chief of mission: Ambassador Antoine NTAMOBWA
chancery: Suite 212, 2233 Wisconsin Avenue NW, Washington, DC 20007
telephone: [1] (202) 342-2574
FAX: [1] (202) 342-2578
18,000 (2002)
30,000 (2002)
1 (2000)
6,000 (2002)
.bi
8.3% (2001 est.)
390,000 (2001 est.)
40,000 (2001 est.)
BIF
42.5 (1998)
0 bbl/day (2001 est.)
2,750 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 16.3 years
male: 15.9 years
female: 16.7 years (2002)','73309c001858679c92334b7a7ba9d82ad5ecb2dbac4e8c70789e4ef891bfba15','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53f4f333baac785e4aea7c4db93b5c843c3a6bf017b7ebc32445029aefb6e915',2003,'KH','Cambodia','communications',847,'mostly low, flat plains; mountains in southwest and north
3.58 children born/woman (2003 est.)
multiparty democracy under a constitutional monarchy
established in September 1993
2.8% (1999 est.)
conventional long form: Kingdom of Cambodia
conventional short form: Cambodia
local long form: Preahreacheanachakr Kampuchea
local short form: Kampuchea
former: Khmer Republic, Kampuchea Republic
Southeastern Asia, bordering the Gulf of Thailand, between
Thailand, Vietnam, and Laos
Southeast Asia
2,700 sq km (1998 est.)
total: 181,040 sq km
land: 176,520 sq km
water: 4,520 sq km
chief of mission: Ambassador ROLAND ENG
chancery: 4530 16th Street NW, Washington, DC 20011
telephone: [1] (202) 726-7742
FAX: [1] (202) 726-8381
21,800 (mid-1998)
80,000 (2000)
2 (2000)
10,000 (2002)
.kh
2.7% (2001 est.)
170,000 (2001 est.)
12,000 (2001 est.)
KHR
40.4 (1997)
0 bbl/day (2001 est.)
3,600 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 19.2 years
male: 18.4 years
female: 20 years (2002)','b9a42db305d203bcfbe5484df5b5e12696b99511ce06a126afd0b5548eef269d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82d534237b6e689149fed9fb71f5dba99f06826e7e7a1312999d7248c32faf93',2003,'CM','Cameroon','communications',848,'diverse, with coastal plain in southwest, dissected plateau
in center, mountains in west, plains in north
4.63 children born/woman (2003 est.)
unitary republic; multiparty presidential regime
(opposition parties legalized in 1990)
note: preponderance of power remains with the president
30% (2001 est.)
conventional long form: Republic of Cameroon
conventional short form: Cameroon
former: French Cameroon
Western Africa, bordering the Bight of Biafra, between
Equatorial Guinea and Nigeria
Africa
330 sq km (1998 est.)
total: 475,440 sq km
land: 469,440 sq km
water: 6,000 sq km
chief of mission: Ambassador Jerome MENDOUGA
chancery: 2349 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 265-8790
FAX: [1] (202) 387-3826
95,000 (2001)
300,000 (2002)
1 (2002)
45,000
note: Cameroon also had more than 100 cyber-cafes in 2001 (December
2001)
.cm
11.8% (2001 est.)
920,000 (2001 est.)
53,000 (2001 est.)
XAF
47.7 (1996)
76,650 bbl/day (2001 est.)
22,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.4 years
male: 18.2 years
female: 18.5 years (2002)
200 million bbl (37257)
55.22 billion cu m (37257)
0 cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','1441b74756f03c67594f098c13b7051a5e8d1203547b20a3160fb46ef630a6c8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6b1caf518e39adfba1f8f6069cb6b7cfedafbfad68a198fcd86d941a058969d',2003,'CA','Canada','communications',849,'mostly plains with mountains in west and lowlands in southeast
Cape Verde
steep, rugged, rocky, volcanic
1.61 children born/woman (2003 est.)
Cape Verde
3.77 children born/woman (2003 est.)
confederation with parliamentary democracy
Cape Verde
republic
7.6% (2002 est.)
Cape Verde
21% (2000 est.)
conventional long form: none
conventional short form: Canada
Cape Verde
conventional long form: Republic of Cape Verde
conventional short form: Cape Verde
local long form: Republica de Cabo Verde
local short form: Cabo Verde
Northern North America, bordering the North Atlantic Ocean on
the east, North Pacific Ocean on the west, and the Arctic Ocean on
the north, north of the conterminous US
Cape Verde
Western Africa, group of islands in the North Atlantic
Ocean, west of Senegal
North America
Cape Verde
Political Map of the World
7,200 sq km (1998 est.)
Cape Verde
30 sq km (1998 est.)
total: 9,984,670 sq km
land: 9,093,507 sq km
water: 891,163 sq km
Cape Verde
total: 4,033 sq km
land: 4,033 sq km
water: 0 sq km
chief of mission: Ambassador Michael F. KERGIN
chancery: 501 Pennsylvania Avenue NW, Washington, DC 20001
telephone: [1] (202) 682-1740
FAX: [1] (202) 682-7726
consulate(s) general: Atlanta, Boston, Buffalo, Chicago, Dallas,
Detroit, Los Angeles, Minneapolis, New York, and Seattle
consulate(s): Miami, Princeton, San Francisco, and San Jose
Cape Verde
chief of mission: Ambassador Jose BRITO
chancery: 3415 Massachusetts Avenue NW, Washington, DC 20007
telephone: [1] (202) 965-6820
FAX: [1] (202) 965-1207
consulate(s) general: Boston
20,802,900 (1999)
Cape Verde
60,935 (2002)
8,751,300 (1997)
Cape Verde
28,119 (2002)
760 (2000 est.)
Cape Verde
1 (2002)
16.84 million (2002)
Cape Verde
12,000 (2002)
.ca
Cape Verde
.cv
0.3% (2001 est.)
Cape Verde
0.04% (2001 est.)
55,000 (2001 est.)
Cape Verde
775 (2001)
less than 500 (2001 est.)
Cape Verde
225 (as of 2001)
CAD
Cape Verde
CVE
31.5 (1994)
2.738 million bbl/day (2001 est.)
Cape Verde
0 bbl/day (2001 est.)
1.703 million bbl/day (2001 est.)
Cape Verde
2,000 bbl/day (2001 est.)
1.145 million bbl/day (2001)
Cape Verde
NA (2001)
2.008 million bbl/day (2001)
Cape Verde
NA (2001)
total: 37.8 years
male: 36.9 years
female: 38.8 years (2002)
Cape Verde
total: 18.7 years
male: 17.9 years
female: 19.6 years (2002)
5.112 billion bbl (37257)
1.691 trillion cu m (37257)
186.8 billion cu m (2001 est.)
82.25 billion cu m (2001 est.)
4.46 billion cu m (2001 est.)
109 billion cu m (2001 est.)','a158b6c8fa47e96ff546a00be8fb27171a5737bdad416a57133605b104aa7427','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea38fb569c82d537a416452470d39427c383336245b2e87aa5d06c1e8f592c42',2003,'KY','Cayman Islands','communications',850,'low-lying limestone base surrounded by coral reefs
1.91 children born/woman (2003 est.)
British crown colony
4.1% (1997)
defense is the responsibility of the UK
conventional long form: none
conventional short form: Cayman Islands
Caribbean, island group in Caribbean Sea, nearly
one-half of the way from Cuba to Honduras
Central America and the Caribbean
NA sq km
total: 262 sq km
land: 262 sq km
water: 0 sq km
none (overseas territory of the UK)
19,000 (1995)
2,534 (1995)
16 (2000)
NA
.ky
NA%
NA
NA
KYD
0 bbl/day (2001 est.)
2,400 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 36.1 years
male: 35.8 years
female: 36.4 years (2002)','4b948dc77a1b5dfb4f95c3c9201d50bd4c350e8c5f81998c2fcdc2ced8182d2e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a3a65d6005a8e1661fa604023d2f62d2133e9b2b4b763e86e35bdc296b4302e',2003,'CF','Central African Republic','communications',851,'vast, flat to rolling, monotonous plateau;
scattered hills in northeast and southwest
4.68 children born/woman (2003 est.)
republic
8% (23% for Bangui) (2001 est.)
conventional long form: Central African
Republic
conventional short form: none
local long form: Republique Centrafricaine
local short form: none
former: Ubangi-Shari, Central African Empire
abbreviation: CAR
Central Africa, north of Democratic
Republic of the Congo
Africa
NA sq km
total: 622,984 sq km
land: 622,984 sq km
water: 0 sq km
chief of mission: Ambassador Emmanuel
TOUABOY
chancery: 1618 22nd Street NW, Washington, DC 20008
telephone: [1] (202) 483-7800
FAX: [1] (202) 332-9893
9,500 (2000)
710 (1998)
1 (2002)
2,000 (2002)
.cf
12.9% (2001 est.)
250,000 (2001 est.)
22,000 (2001 est.)
XAF
61.3 (1993)
0 bbl/day (2001 est.)
2,400 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 17.9 years
male: 17.6 years
female: 18.3 years (2002)','10a5053d3386019f8490d67915a9753b046dfe066b4c324dbe026a1412dc2209','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('610df5c57c7bcd6182b103bdc8b082d9253ecc622e122154dda1122141f38fe1',2003,'TD','Chad','communications',852,'broad, arid plains in center, desert in north, mountains in
northwest, lowlands in south
6.44 children born/woman (2003 est.)
republic
NA%
conventional long form: Republic of Chad
conventional short form: Chad
local long form: Republique du Tchad
local short form: Tchad
Central Africa, south of Libya
Africa
200 sq km (1998 est.)
total: 1.284 million sq km
land: 1,259,200 sq km
water: 24,800 sq km
chief of mission: Ambassador Hassaballah Abdelhadi Ahmat
SOUBIANE
chancery: 2002 R Street NW, Washington, DC 20009
telephone: [1] (202) 462-4009
FAX: [1] (202) 265-1937
9,700 (1999)
5,500 (2000)
1 (2002)
4,000 (2002)
.td
3.6% 5%-7% (2001 est.)
150,000 (2001 est.)
14,000 (confirmed AIDS cases, actual number far higher but
difficult to estimate) (2001 est.)
XAF
0 bbl/day (2001 est.)
1,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 16 years
male: 15.2 years
female: 16.8 years (2002)','ede5f454e51f37962a28b28388fa91977146b8153b895f6d0f319f31ad1616bb','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98d11b41fb2872ae0f7b6dadaa568374ba32b60d03fb452e06b27ac2a4cfff7e',2003,'CL','Chile','communications',853,'low coastal mountains; fertile central valley; rugged Andes in
east
2.09 children born/woman (2003 est.)
republic
9.2% (2002)
conventional long form: Republic of Chile
conventional short form: Chile
local long form: Republica de Chile
local short form: Chile
Southern South America, bordering the South Pacific Ocean,
between Argentina and Peru
South America
18,000 sq km (1998 est.)
total: 756,950 sq km
land: 748,800 sq km
water: 8,150 sq km
note: includes Easter Island (Isla de Pascua) and Isla Sala y Gomez
chief of mission: Ambassador Andres BIANCHI
chancery: 1732 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 785-1746
FAX: [1] (202) 887-5579
consulate(s) general: Chicago, Houston, Los Angeles, Miami, New
York, Philadelphia, San Francisco, and San Juan (Puerto Rico)
2.603 million (1998)
944,225 (1998)
7 (2000)
3.1 million (2002)
.cl
0.3% (2001 est.)
20,000 (2001 est.)
220 (2001 est.)
CLP
56.7 (1998)
13,640 bbl/day (2001 est.)
241,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 29.5 years
male: 28.6 years
female: 30.4 years (2002)
81.05 million bbl (37257)
67.78 billion cu m (37257)
1.2 billion cu m (2001 est.)
6.47 billion cu m (2001 est.)
5.27 billion cu m (2001 est.)
0 cu m (2001 est.)','084adfce1d48f5c789b62de7c71d4e1aef30b464e7f347ca57f9b1bf0c9e31d3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d50d02ade146ac2a5c565170f010004b49e725f5a091f39f90f37a50585815a',2003,'CN','China','communications',854,'mostly mountains, high plateaus, deserts in west; plains,
deltas, and hills in east
1.7 children born/woman (2003 est.)
Communist state
urban unemployment roughly 10%; substantial unemployment and
underemployment in rural areas (2002 est.)
conventional long form: People''s Republic of China
conventional short form: China
local long form: Zhonghua Renmin Gongheguo
local short form: Zhong Guo
abbreviation: PRC
Eastern Asia, bordering the East China Sea, Korea Bay, Yellow
Sea, and South China Sea, between North Korea and Vietnam
Asia
525,800 sq km (1998 est.)
total: 9,596,960 sq km
land: 9,326,410 sq km
water: 270,550 sq km
chief of mission: Ambassador YANG Jiechi
chancery: 2300 Connecticut Avenue NW, Washington, DC 20008
telephone: [1] (202) 328-2500
FAX: [1] (202) 328-2582
consulate(s) general: Chicago, Houston, Los Angeles, New York, and
San Francisco
135 million (2000)
65 million (January 2001)
3 (2000)
45.8 million (2002)
.cn
less than 0.1% (2001 est.)
850,000 (2001 est.)
30,000 (2001 est.)
CNY
40 (2001)
3.3 million bbl/day (2001 est.)
4.975 million bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 31.5 years
male: 31.2 years
female: 31.7 years (2002)
26.75 billion bbl (37257)
1.29 trillion cu m (37257)
30.3 billion cu m (2001 est.)
30.3 billion cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','1d7892d1209e42aa35e95f9f66e3e8b84d21bcceecb1ea032b1fec4aac7c310e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a3d6da2439fc4877587a8aeb8a968b2e163e4e255afef8e03d3ef996881d8a2',2003,'CX','Christmas Island','communications',855,'steep cliffs along coast rise abruptly to central
plateau
Clipperton Island
coral atoll
NA children born/woman (2003 est.)
NA
NA%
defense is the responsibility of Australia
Clipperton Island
defense is the responsibility of France
conventional long form: Territory of Christmas
Island
conventional short form: Christmas Island
Clipperton Island
conventional long form: none
conventional short form: Clipperton Island
local long form: none
local short form: Ile Clipperton
former: sometimes called Ile de la Passion
Southeastern Asia, island in the Indian Ocean,
south of Indonesia
Clipperton Island
Middle America, atoll in the North Pacific Ocean,
1,120 km southwest of Mexico
Southeast Asia
Clipperton Island
Political Map of the World
NA sq km
Clipperton Island
0 sq km (1998 est.)
total: 135 sq km
land: 135 sq km
water: 0 sq km
Clipperton Island
total: 6 sq km
land: 6 sq km
water: 0 sq km
none (territory of Australia)
NA
NA
2 (2000)
NA
.cx
NA%
NA
NA
AUD','0ded4745c96c914f7cc3bdd62db9633754fadac80047fe5455d9316be358880c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c995b03421ade543922771746b396adb07c07450eddf9139a8fa2aeae93e8373',2003,'CC','Cocos (Keeling) Islands','communications',856,'flat, low-lying coral atolls
NA children born/woman (2003 est.)
NA
60% (2000 est.)
defense is the responsibility of Australia;
the territory does have a five-person police force
conventional long form: Territory of Cocos
(Keeling) Islands
conventional short form: Cocos (Keeling) Islands
Southeastern Asia, group of islands in the
Indian Ocean, southwest of Indonesia, about halfway from Australia
to Sri Lanka
Southeast Asia
NA sq km
total: 14 sq km
land: 14 sq km
water: 0 sq km
note: includes the two main islands of West Island and Home Island
none (territory of Australia)
287 (1992)
NA
2 (2000)
NA
.cc
NA%
NA
NA
AUD','46caa560b589b1bb9c0567b299635bf5cc8c67f8a286a418571b7dc92d806174','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a512c55768ab91133207998128aeb60c6b845b6e4f21ab4797898986591ba470',2003,'CO','Colombia','communications',857,'flat coastal lowlands, central highlands, high Andes
Mountains, eastern lowland plains
2.61 children born/woman (2003 est.)
republic; executive branch dominates government structure
17.4% (2002 est.)
conventional long form: Republic of Colombia
conventional short form: Colombia
local long form: Republica de Colombia
local short form: Colombia
Northern South America, bordering the Caribbean Sea,
between Panama and Venezuela, and bordering the North Pacific Ocean,
between Ecuador and Panama
South America
8,500 sq km (1998 est.)
total: 1,138,910 sq km
land: 1,038,700 sq km
water: 100,210 sq km
note: includes Isla de Malpelo, Roncador Cay, Serrana Bank, and
Serranilla Bank
chief of mission: Ambassador Luis Alberto MORENO Mejia
chancery: 2118 Leroy Place NW, Washington, DC 20008
telephone: [1] (202) 387-8338
FAX: [1] (202) 232-8643
consulate(s) general: Boston, Chicago, Houston, Los Angeles, Miami,
New Orleans, New York, San Francisco, San Juan (Puerto Rico), and
Washington, DC
consulate(s): Atlanta
5,433,565 (December 1997)
1,800,229 (December 1998)
18 (2000)
1.15 million (2002)
.co
0.4% (2001 est.)
140,000 (2001 est.)
5,600 (2001 est.)
COP
57.1 (1996)
614,400 bbl/day (2001 est.)
252,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 25.6 years
male: 24.8 years
female: 26.4 years (2002)
1.8 billion bbl (37257)
Congo, Democratic Republic of the
1.538 billion bbl (37257)
Congo, Republic of the
93.5 million bbl (37257)
Cote d''Ivoire
50 million bbl (37257)
132 billion cu m (37257)
Congo, Democratic Republic of the
104.8 billion cu m (37257)
Congo, Republic of the
495.5 million cu m (37257)
Cote d''Ivoire
14.87 billion cu m (37257)
5.7 billion cu m (2001 est.)
Congo, Republic of the
0 cu m (2001 est.)
Cote d''Ivoire
1.35 billion cu m (2001 est.)
5.7 billion cu m (2001 est.)
Congo, Republic of the
0 cu m (2001 est.)
Cote d''Ivoire
1.35 billion cu m (2001 est.)
0 cu m (2001 est.)
Congo, Republic of the
0 cu m (2001 est.)
Cote d''Ivoire
0 cu m (2001 est.)
0 cu m (2001 est.)
Congo, Republic of the
0 cu m (2001 est.)
Cote d''Ivoire
0 cu m (2001 est.)','578efcde696d5cfb1f838eb9dd5f1ef61de947dc358beeff792f20ad7cc4238a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13689c6defc8ad2456a5f62da4e698270493cc9e9f91d84bb0dd257de10fcf5f',2003,'KM','Comoros','communications',858,'volcanic islands, interiors vary from steep mountains to low
hills
Congo, Democratic Republic of the
vast central basin is a low-lying
plateau; mountains in east
Congo, Republic of the
coastal plain, southern basin, central
plateau, northern basin
5.21 children born/woman (2003 est.)
Congo, Democratic Republic of the
6.69 children born/woman (2003
est.)
Congo, Republic of the
3.65 children born/woman (2003 est.)
independent republic
Congo, Democratic Republic of the
dictatorship; presumably
undergoing a transition to representative government
Congo, Republic of the
republic
20% (1996 est.)
Congo, Democratic Republic of the
NA%
Congo, Republic of the
NA%
conventional long form: Union of the Comoros
conventional short form: Comoros
local long form: Union des Comores
local short form: Comores
Congo, Democratic Republic of the
conventional long form: Democratic
Republic of the Congo
conventional short form: none
local long form: Republique Democratique du Congo
local short form: none
former: Congo Free State, Belgian Congo, Congo/Leopoldville,
Congo/Kinshasa, Zaire
abbreviation: DROC
Congo, Republic of the
conventional long form: Republic of the Congo
conventional short form: Congo (Brazzaville)
local long form: Republique du Congo
local short form: none
former: Middle Congo, Congo/Brazzaville, Congo
Southern Africa, group of islands at the northern mouth of
the Mozambique Channel, about two-thirds of the way between northern
Madagascar and northern Mozambique
Congo, Democratic Republic of the
Central Africa, northeast of Angola
Congo, Republic of the
Western Africa, bordering the South Atlantic
Ocean, between Angola and Gabon
Africa
Congo, Democratic Republic of the
Africa
Congo, Republic of the
Africa
NA sq km
Congo, Democratic Republic of the
110 sq km (1998 est.)
Congo, Republic of the
10 sq km (1998 est.)
total: 2,170 sq km
land: 2,170 sq km
water: 0 sq km
Congo, Democratic Republic of the
total: 2,345,410 sq km
land: 2,267,600 sq km
water: 77,810 sq km
Congo, Republic of the
total: 342,000 sq km
land: 341,500 sq km
water: 500 sq km
chief of mission: Ambassador Mahmoud M. ABOUD (ambassador to
the US and Canada and permanent representative to the UN)
chancery: (temporary) care of the Permanent Mission of the Union of
the Comoros to the United Nations, 420 East 50th Street, New York,
NY 10022
telephone: [1] (212) 972-8010 and 223-2711
FAX: [1] (212) 983-4712 and 715-0699
Congo, Democratic Republic of the
chief of mission: Ambassador Faida
MITIFU
chancery: 1800 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 234-7690, 7691
FAX: [1] (202) 234-2609
Congo, Republic of the
chief of mission: Ambassador Serge MOMBOULI
chancery: 4891 Colorado Avenue NW, Washington, DC 20011
telephone: [1] (202) 726-5500
FAX: [1] (202) 726-1860
7,000 (2000)
Congo, Democratic Republic of the
20,000 (2000)
Congo, Republic of the
22,000 (1998)
NA
Congo, Democratic Republic of the
15,000 (2000)
Congo, Republic of the
3,300 (1998)
1 (2000)
Congo, Democratic Republic of the
1 (2001)
Congo, Republic of the
1 (2000)
2,500 (2002)
Congo, Democratic Republic of the
6,000 (2002)
Congo, Republic of the
500 (2001)
.km
Congo, Democratic Republic of the
.cd
Congo, Republic of the
.cg
0.12% (2001 est.)
Congo, Democratic Republic of the
4.9% (2001 est.)
Congo, Republic of the
7.2% (2001 est.)
NA
Congo, Democratic Republic of the
1.3 million (2001 est.)
Congo, Republic of the
110,000 (2001 est.)
NA
Congo, Democratic Republic of the
120,000 (2001 est.)
Congo, Republic of the
11,000 (2001 est.)
KMF
Congo, Democratic Republic of the
CDF
Congo, Republic of the
XAF
0 bbl/day (2001 est.)
Congo, Democratic Republic of the
24,000 bbl/day (2001 est.)
Congo, Republic of the
275,000 bbl/day (2001 est.)
700 bbl/day (2001 est.)
Congo, Democratic Republic of the
14,000 bbl/day (2001 est.)
Congo, Republic of the
5,000 bbl/day (2001 est.)
NA (2001)
Congo, Democratic Republic of the
NA (2001)
Congo, Republic of the
NA (2001)
NA (2001)
Congo, Democratic Republic of the
NA (2001)
Congo, Republic of the
NA (2001)
total: 18.6 years
male: 18.3 years
female: 18.9 years (2002)
Congo, Democratic Republic of the
total: 15.8 years
male: 15.4 years
female: 16.1 years (2002)
Congo, Republic of the
total: 20.2 years
male: 19.8 years
female: 20.7 years (2002)','9ebb9c6376811743a16538386294b6d7995ae5a045670eb38ca57dfccac54169','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e084745d864910217da2172d4f654f6af05fdba165b3de841da37971f401137',2003,'CK','Cook Islands','communications',859,'low coral atolls in north; volcanic, hilly islands in
south
Coral Sea Islands
sand and coral reefs and islands (or cays)
NA children born/woman (2003 est.)
self-governing parliamentary democracy
13% (1996)
defense is the responsibility of New Zealand, in
consultation with the Cook Islands and at its request
Coral Sea Islands
defense is the responsibility of Australia;
visited regularly by the Royal Australian Navy; Australia has
control over the activities of visitors
conventional long form: none
conventional short form: Cook Islands
former: Harvey Islands
Coral Sea Islands
conventional long form: Coral Sea Islands Territory
conventional short form: Coral Sea Islands
Oceania, group of islands in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Coral Sea Islands
Oceania, islands in the Coral Sea, northeast of
Oceania
Coral Sea Islands
Oceania
NA sq km
Coral Sea Islands
0 sq km (1998 est.)
total: 240 sq km
land: 240 sq km
water: 0 sq km
Coral Sea Islands
total: less than 3 sq km
land: less than 3 sq km
water: 0 sq km
note: includes numerous small islands and reefs scattered over a sea
area of about 780,000 sq km, with the Willis Islets the most
important
none (self-governing in free association with New
Zealand)
Coral Sea Islands
none (territory of Australia)
5,000 (1997)
0 (1994)
3 (2000)
NA
.ck
NA%
NA
NA
NZD
0 bbl/day (2001 est.)
450 bbl/day (2001 est.)
NA (2001)
NA (2001)','c39fc0722a632681da630b070738c6ffc2987f9dcfa03d9f3c9882b8ae5be20c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4639f0946092b912728a969718013864de2bea1971c47707ed4f01b2d1a28172',2003,'CR','Costa Rica','communications',860,'coastal plains separated by rugged mountains including
over 100 volcanic cones, of which several are major volcanoes
Cote d''Ivoire
mostly flat to undulating plains; mountains in
northwest
2.38 children born/woman (2003 est.)
Cote d''Ivoire
5.51 children born/woman (2003 est.)
democratic republic
Cote d''Ivoire
republic; multiparty presidential regime established
1960
6.3% (2002 est.)
Cote d''Ivoire
13% in urban areas (1998)
conventional long form: Republic of Costa Rica
conventional short form: Costa Rica
local long form: Republica de Costa Rica
local short form: Costa Rica
Cote d''Ivoire
conventional long form: Republic of Cote d''Ivoire
conventional short form: Cote d''Ivoire
local long form: Republique de Cote d''Ivoire
local short form: Cote d''Ivoire
former: Ivory Coast
Middle America, bordering both the Caribbean Sea and the
North Pacific Ocean, between Nicaragua and Panama
Cote d''Ivoire
Western Africa, bordering the North Atlantic Ocean,
between Ghana and Liberia
Central America and the Caribbean
Cote d''Ivoire
Africa
1,260 sq km (1998 est.)
Cote d''Ivoire
730 sq km (1998 est.)
total: 51,100 sq km
land: 50,660 sq km
water: 440 sq km
note: includes Isla del Coco
Cote d''Ivoire
total: 322,460 sq km
land: 318,000 sq km
water: 4,460 sq km
chief of mission: Ambassador Jaime DAREMBLUM Rosenstein
chancery: 2114 S Street NW, Washington, DC 20008
telephone: [1] (202) 234-2945
FAX: [1] (202) 265-4795
consulate(s) general: Atlanta, Chicago, Denver, Durham (North
Carolina), Houston, Los Angeles, Miami, New Orleans, New York,
Phoenix, San Antonio, San Francisco, St. Paul, and Tampa
consulate(s): Austin
Cote d''Ivoire
chief of mission: Ambassador Pascal Dago KOKORA
chancery: 3421 Massachusetts Avenue NW, Washington, DC 20007
telephone: [1] (202) 797-0300
FAX: [1] (202) 462-9444
450,000 (1998)
note: 584,000 installed in 1997, but only about 450,000 were in use
in 1998
Cote d''Ivoire
263,700 (2000)
143,000 (2000)
Cote d''Ivoire
450,000 (2000)
3 (of which only one is legal) (2000)
Cote d''Ivoire
5 (2001)
384,000 (2002)
Cote d''Ivoire
70,000 (2002)
.cr
Cote d''Ivoire
.ci
0.6% (2001 est.)
Cote d''Ivoire
9.7% (2001 est.)
11,000 (2001 est.)
Cote d''Ivoire
770,000 (2001 est.)
890 (2001 est.)
Cote d''Ivoire
75,000 (2001 est.)
CRC
Cote d''Ivoire
XOF
45.9 (1997)
Cote d''Ivoire
36.7 (1995)
0 bbl/day (2001 est.)
Cote d''Ivoire
11,000 bbl/day (2001 est.)
37,000 bbl/day (2001 est.)
Cote d''Ivoire
32,000 bbl/day (2001 est.)
NA (2001)
Cote d''Ivoire
NA (2001)
NA (2001)
Cote d''Ivoire
NA (2001)
total: 25.4 years
male: 24.9 years
female: 25.8 years (2002)
Cote d''Ivoire
total: 17 years
male: 17.3 years
female: 16.6 years (2002)','f70c9503a946b24ad9218023c5fd9c4589900d5fe051e48356f25f08e5a7e574','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c3a16912f476d727beb932ddcef3b1f66a66d79c8e5897ab8212c661da63329',2003,'HR','Croatia','communications',861,'geographically diverse; flat plains along Hungarian border,
low mountains and highlands near Adriatic coastline and islands
1.93 children born/woman (2003 est.)
presidential/parliamentary democracy
21.7% (2002 est.)
conventional long form: Republic of Croatia
conventional short form: Croatia
local long form: Republika Hrvatska
local short form: Hrvatska
Southeastern Europe, bordering the Adriatic Sea, between
Bosnia and Herzegovina and Slovenia
Europe
30 sq km (1998 est.)
total: 56,542 sq km
land: 56,414 sq km
water: 128 sq km
chief of mission: Ambassador Ivan GRDESIC
chancery: 2343 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 588-5899
FAX: [1] (202) 588-8936
consulate(s) general: Chicago, Los Angeles, New York
1,721,139 (2000)
1.3 million (2001)
9 (2000)
480,000 (2001)
.hr
less than 0.1% (2001 est.)
200 (2001 est.)
less than 10 (2001 est.)
HRK
29 (1998)
Czech Republic
25.4 (1996)
29,000 bbl/day (2001 est.)
89,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 38.9 years
male: 37.1 years
female: 40.7 years (2002)
93.6 million bbl (37257)
34.36 billion cu m (37257)
1.76 billion cu m (2001 est.)
2.84 billion cu m (2001 est.)
1.08 billion cu m (2001 est.)
0 cu m (2001 est.)','828741eb9609448d11858255fe3facaa3d4f3a2d6559e6462bdd8b047c785232','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38ff77994ef9b8cb6c205ec80a09c8b3d4a33918c1b7cdd829da0bb92c43850d',2003,'CU','Cuba','communications',862,'mostly flat to rolling plains, with rugged hills and mountains
in the southeast
1.61 children born/woman (2003 est.)
Communist state
4.1% (2001 est.)
Moscow, for decades the key military supporter and supplier of
Cuba, cut off almost all military aid by 1993
Europa Island
defense is the responsibility of France
Falkland Islands (Islas Malvinas)
defense is the responsibility of
the UK
conventional long form: Republic of Cuba
conventional short form: Cuba
local long form: Republica de Cuba
local short form: Cuba
Caribbean, island between the Caribbean Sea and the North
Atlantic Ocean, 150 km south of Key West, Florida
Central America and the Caribbean
870 sq km (1998 est.)
total: 110,860 sq km
land: 110,860 sq km
water: 0 sq km
none; note - Cuba has an Interests Section in the Swiss
Embassy, headed by Principal Officer Dagoberto RODRIGUEZ Barrera
(since August 2001); address: Cuban Interests Section, Swiss
Embassy, 2630 16th Street NW, Washington, DC 20009; telephone: [1]
(202) 797-8518
473,031 (2000)
2,994 (1997)
5 (2001)
120,000 (2002)
.cu
less than 0.1% (2001 est.)
3,200 (2001 est.)
120 (2001 est.)
CUP
50,000 bbl/day (2001 est.)
163,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 34.5 years
male: 33.9 years
female: 35.1 years (2002)
532 million bbl (37257)
Czech Republic
17.25 million bbl (37257)
42.62 billion cu m (37257)
Czech Republic
3.057 billion cu m (37257)
600 million cu m (2001 est.)
Czech Republic
160 million cu m (2001 est.)
600 million cu m (2001 est.)
Czech Republic
9.892 billion cu m (2001 est.)
0 cu m (2001 est.)
Czech Republic
9.521 billion cu m (2001 est.)
0 cu m (2001 est.)
Czech Republic
1 million cu m (2001 est.)','08298e82dac2cd98d8a40e52ec4346224d1b50e125caf7c5846b22ac09018c03','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b36ed6f4b34548751729012bef2f510f5199f52a11953dd93574cc37fa5f9da3',2003,'CY','Cyprus','communications',863,'central plain with mountains to north and south; scattered
but significant plains along southern coast
Czech Republic
Bohemia in the west consists of rolling plains,
hills, and plateaus surrounded by low mountains; Moravia in the east
consists of very hilly country
1.88 children born/woman (2003 est.)
Czech Republic
1.18 children born/woman (2003 est.)
republic
note: a disaggregation of the two ethnic communities inhabiting the
island began following the outbreak of communal strife in 1963; this
separation was further solidified after the Turkish intervention in
July 1974 after a Greek junta-based coup attempt gave the Turkish
Cypriots de facto control in the north; Greek Cypriots control the
only internationally recognized government; on 15 November 1983
Turkish Cypriot "President" Rauf DENKTASH declared independence and
the formation of a "Turkish Republic of Northern Cyprus" (TRNC),
recognized only by Turkey; both sides publicly support a settlement
based on a federation (Greek Cypriot position) or confederation
(Turkish Cypriot position)
Czech Republic
parliamentary democracy
Greek Cypriot area: 3.3%; Turkish Cypriot area: 5.6% (2002
est.)
Czech Republic
9.8% (2002)
conventional long form: Republic of Cyprus
conventional short form: Cyprus
note: the Turkish Cypriot area refers to itself as the "Turkish
Republic of Northern Cyprus" (TRNC)
Czech Republic
conventional long form: Czech Republic
conventional short form: Czech Republic
local long form: Ceska Republika
local short form: Ceska Republika
Middle East, island in the Mediterranean Sea, south of Turkey
Czech Republic
Central Europe, southeast of Germany
Middle East
Czech Republic
Europe
400 sq km (1998 est.)
Czech Republic
240 sq km (1998 est.)
total: 9,250 sq km (of which 3,355 sq km are in the Turkish
Cypriot area)
land: 9,240 sq km
water: 10 sq km
Czech Republic
total: 78,866 sq km
land: 77,276 sq km
water: 1,590 sq km
chief of mission: Ambassador Euripides L. EVRIVIADES
chancery: 2211 R Street NW, Washington, DC 20008
telephone: [1] (202) 462-5772
FAX: [1] (202) 483-6710
consulate(s) general: New York
consulate(s): New York
note: representative of the Turkish Cypriot area in the US is Osman
ERTUG; office at 1667 K Street NW, Washington, DC; telephone [1]
(202) 887-6198
Czech Republic
chief of mission: Ambassador Martin PALOUS
chancery: 3900 Spring of Freedom Street NW, Washington, DC 20008
telephone: [1] (202) 274-9100
FAX: [1] (202) 966-8540
consulate(s) general: Los Angeles and New York
Greek Cypriot area: 405,000 (1998);; Turkish Cypriot area:
83,162 (1998)
Czech Republic
3.869 million (2000)
Greek Cypriot area: 68,000 (1998); Turkish Cypriot area:
70,000 (1999)
Czech Republic
4.346 million (2000)
6 (2000)
Czech Republic
more than 300 (2000)
150,000 (2002)
Czech Republic
2.69 million (2001)
.cy
Czech Republic
.cz
0.3% (2001 est.)
Czech Republic
less than 0.1% (2001 est.)
less than 1,000 (1999 est.)
Czech Republic
500 (2001 est.)
NA
Czech Republic
less than 10 (2001 est.)
CYP; TRL
Czech Republic
CZK
0 bbl/day (2001 est.)
Czech Republic
7,419 bbl/day (2001 est.)
49,000 bbl/day (2001 est.)
Czech Republic
175,700 bbl/day (2001 est.)
NA (2001)
Czech Republic
192,300 bbl/day (2001)
NA (2001)
Czech Republic
26,670 bbl/day (2001)
total: 34.2 years
male: 33.1 years
female: 35.2 years (2002)
Czech Republic
total: 38.4 years
male: 36.6 years
female: 40.2 years (2002)','bd6e0d08ed25b199d200975ab5997acd9a209e92a09d9bdd26d2d54744b78e64','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef040a0e692720e3f019c28a6165cd9c1095e16aef08df3056302b22cd1df3d6',2003,'DK','Denmark','communications',864,'low and flat to gently rolling plains
1.73 children born/woman (2003 est.)
constitutional monarchy
5.1% (2002)
conventional long form: Kingdom of Denmark
conventional short form: Denmark
local long form: Kongeriget Danmark
local short form: Danmark
Northern Europe, bordering the Baltic Sea and the North Sea,
on a peninsula north of Germany (Jutland); also includes two major
islands (Sjaelland and Fyn)
Europe
4,760 sq km (1998 est.)
total: 43,094 sq km
land: 42,394 sq km
water: 700 sq km
note: includes the island of Bornholm in the Baltic Sea and the rest
of metropolitan Denmark (the Jutland Peninsula, and the major
islands of Sjaelland and Fyn), but excludes the Faroe Islands and
chief of mission: Ambassador Ulrik Andreas FEDERSPIEL
chancery: 3200 Whitehaven Street NW, Washington, DC 20008
telephone: [1] (202) 234-4300
FAX: [1] (202) 328-1470
consulate(s) general: Chicago, Los Angeles, and New York
4.785 million (1997)
1,444,016 (1997)
13 (2000)
3.37 million (2002)
.dk
0.2% (2001 est.)
3,800 (2001 est.)
less than 100 (2001 est.)
DKK
24.7 (1992)
346,200 bbl/day (2001 est.)
218,000 bbl/day (2001 est.)
195,000 bbl/day (2001)
332,100 bbl/day (2001)
total: 39.1 years
male: 38.1 years
female: 40.1 years (2002)
1.23 billion bbl (37257)
81.98 billion cu m (37257)
8.38 billion cu m (2001 est.)
5.28 billion cu m (2001 est.)
0 cu m (2001 est.)
3.1 billion cu m (2001 est.)','3469c3708df9075c3a64a2457999d387c45a7708cee7fc78b8744af4fd4961bb','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e892d6ddc94e5bc0445d5c0678dd0656e03ac385adeaf695d02719ba080e694',2003,'DJ','Djibouti','communications',865,'coastal plain and plateau separated by central mountains
5.56 children born/woman (2003 est.)
republic
50% (2000 est.)
conventional long form: Republic of Djibouti
conventional short form: Djibouti
former: French Territory of the Afars and Issas, French Somaliland
Eastern Africa, bordering the Gulf of Aden and the Red Sea,
between Eritrea and Somalia
Africa
10 sq km (1998 est.)
total: 23,000 sq km
land: 22,980 sq km
water: 20 sq km
chief of mission: Ambassador ROBLE Olhaye
chancery: Suite 515, 1156 15th Street NW, Washington, DC 20005
telephone: [1] (202) 331-0270
FAX: [1] (202) 331-0302
10,000 (2002)
5,000 (2002)
1 (2000)
3,300 (2002)
.dj
11.75% (2001 est.)
37,000 (2001 est.)
2,000 (2001 est.)
DJF
0 bbl/day (2001 est.)
11,300 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.3 years
male: 18.9 years
female: 17.7 years (2002)','1fc440185237d00adc6f755fbb06f45e6f4b031bf5269c288a8b294e52e27a55','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1530ad9fda50443477884a5a76340eda03db51b835772199d578a3eac5d76dc2',2003,'DM','Dominica','communications',866,'rugged mountains of volcanic origin
1.99 children born/woman (2003 est.)
parliamentary democracy; republic within the Commonwealth
23% (2000 est.)
conventional long form: Commonwealth of Dominica
conventional short form: Dominica
Caribbean, island between the Caribbean Sea and the North
Atlantic Ocean, about one-half of the way from Puerto Rico to
Central America and the Caribbean
NA sq km
total: 754 sq km
land: 754 sq km
water: 0 sq km
chief of mission: Ambassador Swinburne LESTRADE
chancery: 3216 New Mexico Avenue NW, Washington, DC 20016
telephone: [1] (202) 364-6781
FAX: [1] (202) 364-6791
consulate(s) general: New York
19,000 (1996)
461 (1996)
16 (2000)
2,000 (2000)
.dm
NA%
NA
NA
XCD
0 bbl/day (2001 est.)
600 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 28.4 years
male: 28.1 years
female: 28.8 years (2002)','2f5d2252d7f43ce4ad14b1f2c96ebe7a907ff45c9bf1cde735e7b8538cbf7647','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('273402944de9f67720e42945127d1e409856ec157c957846f9bf6b84c6675f94',2003,'DO','Dominican Republic','communications',867,'rugged highlands and mountains with fertile
valleys interspersed
East Timor
mountainous
2.92 children born/woman (2003 est.)
East Timor
3.79 children born/woman (2003 est.)
representative democracy
East Timor
republic
14.5% (2002 est.)
East Timor
50% (including underemployment)
conventional long form: Dominican Republic
conventional short form: none
local long form: Republica Dominicana
local short form: none
East Timor
conventional long form: Democratic Republic of Timor-Leste
conventional short form: East Timor
local long form: Republika Demokratika Timor Lorosa''e [Tetum];
Republica Democratica de Timor-Leste [Portuguese]
local short form: Timor Lorosa''e [Tetum]; Timor-Leste [Portuguese]
former: Portuguese Timor
Caribbean, eastern two-thirds of the island of
Hispaniola, between the Caribbean Sea and the North Atlantic Ocean,
east of Haiti
East Timor
Southeastern Asia, northwest of Australia in the Lesser
Sunda Islands at the eastern end of the Indonesian archipelago; note
- East Timor includes the eastern half of the island of Timor, the
Oecussi (Ambeno) region on the northwest portion of the island of
Timor, and the islands of Pulau Atauro and Pulau Jaco
Central America and the Caribbean
East Timor
Southeast Asia
2,590 sq km (1998 est.)
East Timor
1,065 sq km (est.)
total: 48,730 sq km
land: 48,380 sq km
water: 350 sq km
East Timor
total: 15,007 sq km
land: NA sq km
water: NA sq km
chief of mission: Ambassador Hugo GUILIANI Cury
chancery: 1715 22nd Street NW, Washington, DC 20008
telephone: [1] (202) 332-6280
FAX: [1] (202) 265-8057
consulate(s) general: Boston, Chicago, Jacksonville, Mayaguez
(Puerto Rico), Miami, New Orleans, New York, Philadelphia, San
Francisco, and San Juan (Puerto Rico)
consulate(s): Mobile and Ponce (Puerto Rico)
East Timor
chief of mission: Ambassador Jose Luis GUTERRES
chancery: 3415 Massachusetts Avenue, Washington, DC 20007
telephone: 202 965-1515
FAX: 202 965-1517
consulate(s) general: New York (the ambassador resides in New York)
(2003)
709,000 (1997)
East Timor
NA
130,149 (1997)
East Timor
NA
24 (2000)
East Timor
NA
186,000 (2002)
East Timor
NA
.do
East Timor
.tp
2.5% (2001 est.)
East Timor
NA%
130,000 (2001 est.)
East Timor
NA
7,800 (2001 est.)
East Timor
NA
DOP
East Timor
IDR
47.4 (1998)
East Timor
38 (2002 est.)
0 bbl/day (2001 est.)
129,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 23.5 years
male: 23.3 years
female: 23.7 years (2002)
East Timor
total: 19.7 years
male: 19.8 years
female: 19.6 years (2002)','602c46101483bd38c61ae113fa13648bfe6a00c3f868cc585bd19b90f2c0577d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49acc8f0071dd0e84e5d858a19348bc6f68572868c64795e118d868a60eb6581',2003,'EC','Ecuador','communications',868,'coastal plain (costa), inter-Andean central highlands
(sierra), and flat to rolling eastern jungle (oriente)
2.99 children born/woman (2003 est.)
republic
7.7%; note - widespread underemployment (2001 est.)
conventional long form: Republic of Ecuador
conventional short form: Ecuador
local long form: Republica del Ecuador
local short form: Ecuador
Western South America, bordering the Pacific Ocean at the
Equator, between Colombia and Peru
South America
8,650 sq km (1998 est.)
total: 283,560 sq km
land: 276,840 sq km
water: 6,720 sq km
note: includes Galapagos Islands
chief of mission: Ambassador Raul GANGOTENA Rivadeneira
chancery: 2535 15th Street NW, Washington, DC 20009
telephone: [1] (202) 234-7200
FAX: [1] (202) 667-3482
consulate(s) general: Chicago, Houston, Los Angeles, Miami, New
Orleans, New York, Newark, Philadelphia, and San Francisco
1,115,272 (1999)
384,000 (1999)
31 (2001)
328,000 (2002)
.ec
0.3% (2001 est.)
20,000 (2001 est.)
1,700 (2001 est.)
USD
43.7 (1995)
421,200 bbl/day (2001 est.)
129,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 22.5 years
male: 22 years
female: 23 years (2002)
2.358 billion bbl (37257)
106.5 billion cu m (37257)
160 million cu m (2001 est.)
160 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','0ae275cd3c68d57e635a5633e0c49ad836c85c03b262c6343a2600cac4319890','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('405d2440ee0e48dd54672c3aff2dbdba7a364472cb3ac2032c0b2dc90b8c0fa2',2003,'EG','Egypt','communications',869,'vast desert plateau interrupted by Nile valley and delta
3.02 children born/woman (2003 est.)
republic
12% (2001 est.)
conventional long form: Arab Republic of Egypt
conventional short form: Egypt
local long form: Jumhuriyat Misr al-Arabiyah
local short form: Misr
former: United Arab Republic (with Syria)
Northern Africa, bordering the Mediterranean Sea, between
Libya and the Gaza Strip, and the Red Sea north of Sudan, and
includes the Asian Sinai Peninsula
Africa
33,000 sq km (1998 est.)
total: 1,001,450 sq km
land: 995,450 sq km
water: 6,000 sq km
chief of mission: Ambassador M. Nabil FAHMY
chancery: 3521 International Court NW, Washington, DC 20008
telephone: [1] (202) 895-5400
FAX: [1] (202) 244-4319
consulate(s) general: Chicago, Houston, New York, and San Francisco
3,971,500 (December 1998)
380,000 (1999)
50 (2000)
600,000 (2002)
.eg
less than 0.1% (2001 est.)
8,000 (2001 est.)
NA
EGP
28.9 (1995)
816,900 bbl/day (2001 est.)
562,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 23.1 years
male: 22.8 years
female: 23.5 years (2002)
3.308 billion bbl (37257)
1.264 trillion cu m (37257)
21.2 billion cu m (2001 est.)
21.2 billion cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','df83cd0f27c716cf85d9ffc3969bd9c8b2feb4344226ecf4d0cb498c29ecfde5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba90b9cf208db045fbdda9e628c7d632df7371e0427a12c11a946e6c67624782',2003,'SV','El Salvador','communications',870,'mostly mountains with narrow coastal belt and central
plateau
3.25 children born/woman (2003 est.)
republic
10% - but the economy has much underemployment. (2001
est.)
conventional long form: Republic of El Salvador
conventional short form: El Salvador
local long form: Republica de El Salvador
local short form: El Salvador
Middle America, bordering the North Pacific Ocean,
between Guatemala and Honduras
Central America and the Caribbean
360 sq km (1998 est.)
total: 21,040 sq km
land: 20,720 sq km
water: 320 sq km
chief of mission: Ambassador Rene Antonio LEON Rodriguez
chancery: 2308 California Street NW, Washington, DC 20008
telephone: [1] (202) 265-9671
FAX: [1] (202) 234-3834
consulate(s) general: Boston, Chicago, Dallas, Houston, Los Angeles,
Miami, New York, San Francisco, and Washington, DC
380,000 (1998)
40,163 (1997)
4 (2000)
40,000 (2000)
.sv
0.6% (2001 est.)
24,000 (2001 est.)
2,100 (2001 est.)
USD
52.2 (1998)
0 bbl/day (2001 est.)
39,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 21.1 years
male: 20 years
female: 22.2 years (2002)','08f760935e4b2a961ebbb7bf1b2ba493deb58e63e5799d5259fe4b73887f5199','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cba7981b6991905e0b8b80505b5893441811a23285265d452a2df7c0d34f3dc',2003,'GQ','Equatorial Guinea','communications',871,'coastal plains rise to interior hills; islands are
volcanic
4.75 children born/woman (2003 est.)
republic
30% (1998 est.)
conventional long form: Republic of Equatorial
Western Africa, bordering the Bight of Biafra,
between Cameroon and Gabon
Africa
NA sq km
total: 28,051 sq km
land: 28,051 sq km
water: 0 sq km
chief of mission: Ambassador Teodoro Biyogo NSUE
chancery: 2020 16th Street NW, Washington, DC 20009
telephone: [1] (202) 518-5700
FAX: [1] (202) 518-5252
6,000 (1998)
300 (1998)
1 (2002)
900 (2002)
.gq
3.4% (2001 est.)
5,900 (2001 est.)
370 (2001 est.)
XAF
181,400 bbl/day (2001 est.)
2,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.7 years
male: 18 years
female: 19.3 years (2002)
563.5 million bbl (37257)
68.53 billion cu m (37257)
20 million cu m (2001 est.)
20 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','99aad52ed238cfaff6a6379cb5445aa57508a98a77783a23548ff0edcd92cb19','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05cf79029b1e1fb2601dcca04f58d753df6e703787817eeeab61ebc8cc927d71',2003,'ER','Eritrea','communications',872,'dominated by extension of Ethiopian north-south trending
highlands, descending on the east to a coastal desert plain, on the
northwest to hilly terrain and on the southwest to flat-to-rolling
plains
5.74 children born/woman (2003 est.)
transitional government
note: following a successful referendum on independence for the
Autonomous Region of Eritrea on 23-25 April 1993, a National
Assembly, composed entirely of the People''s Front for Democracy and
Justice or PFDJ, was established as a transitional legislature; a
Constitutional Commission was also established to draft a
constitution; ISAIAS Afworki was elected president by the
transitional legislature; the constitution, ratified in May 1997,
did not enter into effect, pending parliamentary and presidential
elections; parliamentary elections had been scheduled to take place
in December 2001, but were postponed indefinitely; currently the
sole legal party is the People''s Front for Democracy and Justice
(PFDJ)
NA%
conventional long form: State of Eritrea
conventional short form: Eritrea
local long form: Hagere Ertra
local short form: Ertra
former: Eritrea Autonomous Region in Ethiopia
Eastern Africa, bordering the Red Sea, between Djibouti and
Africa
220 sq km (1998 est.)
total: 121,320 sq km
land: 121,320 sq km
water: 0 sq km
chief of mission: Ambassador GIRMA Asmerom
chancery: 1708 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 319-1991
FAX: [1] (202) 319-1304
consulate(s) general: Oakland (California)
30,000 (2001)
NA; note - mobile cellular service was introduced in May 2001
5 (2001)
10,000 (2002)
.er
2.8% (2001 est.)
55,000 (2001 est.)
350 (2001 est.)
ERN
0 bbl/day (2001 est.)
6,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 17.6 years
male: 17.4 years
female: 17.7 years (2002)','d0c98934bb9f30a8aeacfa24483edbb3acfc0ce5d0b423ce1a85af3a188bc33d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e48261eb472b4d5b7016f6f062c9aa1106ae7b7ba62c5a266175f73c3a923324',2003,'EE','Estonia','communications',873,'marshy, lowlands; flat in the north, hilly in the south
1.27 children born/woman (2003 est.)
parliamentary republic
12.4% (2001)
conventional long form: Republic of Estonia
conventional short form: Estonia
local long form: Eesti Vabariik
local short form: Eesti
former: Estonian Soviet Socialist Republic
Eastern Europe, bordering the Baltic Sea and Gulf of
Finland, between Latvia and Russia
Europe
40 sq km (1998 est.)
total: 45,226 sq km
land: 43,211 sq km
water: 2,015 sq km
note: includes 1,520 islands in the Baltic Sea
chief of mission: Ambassador Juri LUIK
chancery: 1730 M Street NW, Suite 503, Washington, DC 20036
telephone: [1] (202) 588-0101
FAX: [1] (202) 588-0108
consulate(s) general: New York
501,691 (2000)
711,000 (yearend 2001)
38 (2001)
429,700 (2002)
.ee
1% (2001 est.)
less than 7,700 (2001 est.)
less than 100 (2001 est.)
EEK
37 (1999)
5,100 bbl/day (2001 est.)
24,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 38.1 years
male: 34.7 years
female: 41.3 years (2002)
0 cu m (2001 est.)
1.27 billion cu m (2001 est.)
1.27 billion cu m (2001 est.)
0 cu m (2001 est.)','224c60a6db4e3a7c9bf2dcbf65e64ca59124f396df191ab28e8a02ba7c2200c8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('160d174e7d5b58a92a35a6a7a3a8f006768e079b190fb7403786a26396a10c14',2003,'FO','Faroe Islands','communications',874,'rugged, rocky, some low peaks; cliffs along most of
coast
2.24 children born/woman (2003 est.)
NA
1% (October 2000)
defense is the responsibility of Denmark
conventional long form: none
conventional short form: Faroe Islands
local long form: none
local short form: Foroyar
Northern Europe, island group between the Norwegian
Sea and the North Atlantic Ocean, about one-half of the way from
Iceland to Norway
Europe
0 sq km (1998 est.)
total: 1,399 sq km
land: 1,399 sq km
water: 0 sq km (some lakes and streams)
none (self-governing overseas administrative division
of Denmark)
24,851 (1999)
10,761 (1999)
2 (2000)
3,000 (2000)
.fo
NA%
NA
NA
DKK
0 bbl/day (2001 est.)
4,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 35.1 years
male: 34.5 years
female: 35.8 years (2002)','45e60190e2996acd0fc74b410e7445d55663a1b36d13141cc8d413a77bf045f8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('354e4229dad472b293b61d00f9315eef69447255e657e9e190417487e8e4b346',2003,'FJ','Fiji','communications',875,'mostly mountains of volcanic origin
2.81 children born/woman (2003 est.)
republic
note: military coup leader Maj. Gen. Sitiveni RABUKA formally
declared Fiji a republic on 6 October 1987
7.6% (1999)
conventional long form: Republic of the Fiji Islands
conventional short form: Fiji
Oceania, island group in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
Oceania
30 sq km (1998 est.)
total: 18,270 sq km
land: 18,270 sq km
water: 0 sq km
chief of mission: Ambassador Anare JALE
chancery: 2233 Wisconsin Avenue NW, Suite 240, Washington, DC 20007
telephone: [1] (202) 337-8320
FAX: [1] (202) 337-1996
80,901 (1999)
5,200 (1997)
2 (2000)
15,000 (2002)
.fj
0.1% (2001 est.)
300 (2001 est.)
NA
FJD
0 bbl/day (2001 est.)
5,700 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 23.7 years
male: 23.3 years
female: 24.2 years (2002)','facc92f18c174bd8880a48515ac1d0f00f53fe15b50080f5d4a70bfe384acd48','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4085705abd988902a48b02abfa767c5e538733de89d0662cd4253f2e766f5a75',2003,'FI','Finland','communications',876,'mostly low, flat to rolling plains interspersed with lakes
and low hills
1.7 children born/woman (2003 est.)
republic
8.5% (2002 est.)
conventional long form: Republic of Finland
conventional short form: Finland
local long form: Suomen Tasavalta
local short form: Suomi
Northern Europe, bordering the Baltic Sea, Gulf of Bothnia,
and Gulf of Finland, between Sweden and Russia
Europe
640 sq km (1998 est.)
total: 337,030 sq km
land: 305,470 sq km
water: 31,560 sq km
chief of mission: Ambassador Jukka Robert VALTASAARI
chancery: 3301 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 298-5800
FAX: [1] (202) 298-6030
consulate(s) general: Los Angeles and New York
2,847,900 (2001)
3,728,600 (2001)
3 (2002)
2.69 million (2002)
.fi
less than 0.1% (2001 est.)
1,200 (2001 est.)
less than 100 (2001 est.)
EUR
25.6 (1991)
0 bbl/day (2001 est.)
211,400 bbl/day (2001 est.)
318,300 bbl/day (2001)
101,000 bbl/day (2001)
total: 40.3 years
male: 38.8 years
female: 41.8 years (2002)
0 cu m (2001 est.)
4.557 billion cu m (2001 est.)
4.567 billion cu m (2001 est.)
0 cu m (2001 est.)','5d920d2f2fd914f65d6fc1f72ff7595005f123c4d4ddd7a4109fd78ea0892208','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13a65dc7d8cde42e2462033e239ecf4eeba521ee71b4554b6a086fff1f3251a0',2003,'FR','France','communications',877,'mostly flat plains or gently rolling hills in north and west;
remainder is mountainous, especially Pyrenees in south, Alps in east
1.85 children born/woman (2003 est.)
republic
9.1% (2002 est.)
conventional long form: French Republic
conventional short form: France
local long form: Republique Francaise
local short form: France
Western Europe, bordering the Bay of Biscay and English
Channel, between Belgium and Spain, southeast of the UK; bordering
the Mediterranean Sea, between Italy and Spain
Johnston Atoll
Oceania, atoll in the North Pacific Ocean 717 NM
(1328 km) southwest of Honolulu, Hawaii, about one-third of the way
from Hawaii to the Marshall Islands
Europe
20,000 sq km (1998 est.)
total: 547,030 sq km
land: 545,630 sq km
water: 1,400 sq km
note: includes only metropolitan France; excludes the overseas
administrative divisions
chief of mission: Ambassador Jean-David LEVITTE
chancery: 4101 Reservoir Road NW, Washington, DC 20007
telephone: [1] (202) 944-6000
FAX: [1] (202) 944-6166
consulate(s) general: Atlanta, Boston, Chicago, Houston, Los
Angeles, Miami, New Orleans, New York, and San Francisco
34.86 million (yearend 1998)
11.078 million (yearend 1998)
62 (2000)
16.97 million (2002)
.fr
0.3% (2001 est.)
100,000 (2001 est.)
800 (2001 est.)
EUR
32.7 (1995)
34,920 bbl/day (2001 est.)
2.026 million bbl/day (2001 est.)
2.281 million bbl/day (2001)
409,600 bbl/day (2001)
total: 38.3 years
male: 36.8 years
female: 39.8 years (2002)
144.3 million bbl (37257)
12.86 billion cu m (37257)
1.898 billion cu m (2001 est.)
42.01 billion cu m (2001 est.)
40.26 billion cu m (2001 est.)
1.725 billion cu m (2001 est.)','9cc93d65991fbfbd852f9f19c9741f8951fb71ab334bee6923154609977f1395','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc59b756f6cb212e1de577d93b04bddd8e7b9fdd266a677d92cd67395bb21098',2003,'GF','French Guiana','communications',878,'low-lying coastal plains rising to hills and small
mountains
3.09 children born/woman (2003 est.)
NA
22% (2001)
defense is the responsibility of France
conventional long form: Department of Guiana
conventional short form: French Guiana
local long form: none
local short form: Guyane
Northern South America, bordering the North Atlantic
Ocean, between Brazil and Suriname
South America
20 sq km (1998 est.)
total: 91,000 sq km
land: 89,150 sq km
water: 1,850 sq km
none (overseas department of France)
47,000 (1997)
NA
2 (2000)
2,000 (2000)
.gf
NA%
NA
NA
EUR; FRF
0 bbl/day (2001 est.)
6,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 28.2 years
male: 29.2 years
female: 27.1 years (2002)','d3c8885e4520bb113678f63c1a712ff0fe893b3707ea9976a653ee2f55d7ec2e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b52fc80a8f58c01463d8e2618f995b11f4e4cce48e20ad35696dc67fb8d6c77c',2003,'PF','French Polynesia','communications',879,'mixture of rugged high islands and low islands with
reefs
French Southern and Antarctic Lands
volcanic
2.14 children born/woman (2003 est.)
NA
11.8% (1994)
defense is the responsibility of France
French Southern and Antarctic Lands
defense is the responsibility of
conventional long form: Territory of French
Polynesia
conventional short form: French Polynesia
local long form: Territoire de la Polynesie Francaise
local short form: Polynesie Francaise
former: French Colony of Oceania
French Southern and Antarctic Lands
conventional long form:
Territory of the French Southern and Antarctic Lands
conventional short form: French Southern and Antarctic Lands
local long form: Territoire des Terres Australes et Antarctiques
Francaises
local short form: Terres Australes et Antarctiques Francaises
Oceania, archipelago in the South Pacific Ocean,
about one-half of the way from South America to Australia
French Southern and Antarctic Lands
southeast of Africa, islands in
the southern Indian Ocean, about equidistant between Africa,
Antarctica, and Australia; note - French Southern and Antarctic
Lands include Ile Amsterdam, Ile Saint-Paul, Iles Crozet, and Iles
Kerguelen in the southern Indian Ocean, along with the
French-claimed sector of Antarctica, "Adelie Land"; the US does not
recognize the French claim to "Adelie Land"
Oceania
French Southern and Antarctic Lands
Antarctic Region
NA sq km
French Southern and Antarctic Lands
0 sq km (1998 est.)
total: 4,167 sq km (118 islands and atolls)
land: 3,660 sq km
water: 507 sq km
French Southern and Antarctic Lands
total: 7,829 sq km
land: 7,829 sq km
water: 0 sq km
note: includes Ile Amsterdam, Ile Saint-Paul, Iles Crozet and Iles
Kerguelen; excludes "Adelie Land" claim of about 500,000 sq km in
Antarctica that is not recognized by the US
none (overseas territory of France)
French Southern and Antarctic Lands
none (overseas territory of
France)
52,000 (1997)
5,427 (1997)
2 (2000)
16,000 (2002)
.pf
French Southern and Antarctic Lands
.tf
NA%
NA
NA
XPF
0 bbl/day (2001 est.)
4,750 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 26.7 years
male: 27.1 years
female: 26.3 years (2002)','3d938b0eba973ab182c74426e805d33df03a9bc9151561c4ab0f03fd68f97db6','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccf2c08bcbc63182f070cd787c8966beab98bcc29dce138863ef47eebb154eac',2003,'GA','Gabon','communications',880,'narrow coastal plain; hilly interior; savanna in east and south
Gambia, The
flood plain of the Gambia River flanked by some low hills
Gaza Strip
flat to rolling, sand- and dune-covered coastal plain
4.83 children born/woman (2003 est.)
Gambia, The
5.53 children born/woman (2003 est.)
Gaza Strip
6.17 children born/woman (2003 est.)
republic; multiparty presidential regime (opposition parties
legalized in 1990)
Gambia, The
republic under multiparty democratic rule
21% (1997 est.)
Gambia, The
NA%
Gaza Strip
50% (includes West Bank) (2002 est.)
conventional long form: Gabonese Republic
conventional short form: Gabon
local long form: Republique Gabonaise
local short form: Gabon
Gambia, The
conventional long form: Republic of The Gambia
conventional short form: The Gambia
Gaza Strip
conventional long form: none
conventional short form: Gaza Strip
local long form: none
local short form: Qita Ghazzah
Western Africa, bordering the Atlantic Ocean at the Equator,
between Republic of the Congo and Equatorial Guinea
Gambia, The
Western Africa, bordering the North Atlantic Ocean and
Africa
Gambia, The
Africa
Gaza Strip
Middle East
150 sq km (1998 est.)
Gambia, The
20 sq km (1998 est.)
Gaza Strip
120 sq km (1998 est.)
total: 267,667 sq km
land: 257,667 sq km
water: 10,000 sq km
Gambia, The
total: 11,300 sq km
land: 10,000 sq km
water: 1,300 sq km
Gaza Strip
total: 360 sq km
land: 360 sq km
water: 0 sq km
chief of mission: Ambassador Jules Marius OGOUEBANDJA
chancery: Suite 200, 2034 20th Street NW, Washington, DC 20009
telephone: [1] (202) 797-1000
FAX: [1] (202) 332-0668
consulate(s): New York
Gambia, The
chief of mission: Ambassador (vacant); Charge D''Affaires
Lena Manga Sagnia SECK
chancery: Suite 905, 1156 15th Street NW, Washington, DC 20005
telephone: [1] (202) 785-1379
FAX: [1] (202) 785-1430
39,000 (1998)
Gambia, The
31,900 (2000)
Gaza Strip
95,729 (total for Gaza Strip and West Bank) (1997)
120,000 (2000)
Gambia, The
5,624 (2000)
Gaza Strip
NA
1 (2001)
Gambia, The
2 (2001)
Gaza Strip
3 (1999)
18,000 (2002)
Gambia, The
5,000 (2001)
Gaza Strip
60,000 (includes West Bank) (2001)
.ga
Gambia, The
.gm
9% (2001 est.)
Gambia, The
1.6% (2001 est.)
Gaza Strip
NA%
23,000 (1999 est.)
Gambia, The
8,400 (2001 est.)
Gaza Strip
NA
3,000 (2001 est.)
Gambia, The
400 (2001 est.)
Gaza Strip
NA
XAF
Gambia, The
GMD
Gaza Strip
ILS
301,300 bbl/day (2001 est.)
Gambia, The
0 bbl/day (2001 est.)
13,000 bbl/day (2001 est.)
Gambia, The
1,900 bbl/day (2001 est.)
NA (2001)
Gambia, The
NA (2001)
NA (2001)
Gambia, The
NA (2001)
total: 18.5 years
male: 18.3 years
female: 18.7 years (2002)
Gambia, The
total: 17.4 years
male: 17.3 years
female: 17.6 years (2002)
Gaza Strip
total: 15.3 years
male: 15.1 years
female: 15.5 years (2002)
2.45 billion bbl (37257)
66.47 billion cu m (37257)
80 million cu m (2001 est.)
80 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','75496a8ff372dd324d91279a3ac44d9f5806477c535f3c162410f7346fb5709e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77120e530f8c3eb9780c646d623787905ba2232c2e7199f956b8276b7568f14a',2003,'GE','Georgia','communications',881,'largely mountainous with Great Caucasus Mountains in the
north and Lesser Caucasus Mountains in the south; Kolkhet''is Dablobi
(Kolkhida Lowland) opens to the Black Sea in the west; Mtkvari River
Basin in the east; good soils in river valley flood plains,
foothills of Kolkhida Lowland
1.51 children born/woman (2003 est.)
republic
17% (2001 est.)
a CIS peacekeeping force of Russian troops is deployed in
the Abkhazia region of Georgia together with a UN military observer
group; a Russian peacekeeping battalion is deployed in South Ossetia
conventional long form: none
conventional short form: Georgia
local long form: none
local short form: Sak''art''velo
former: Georgian Soviet Socialist Republic
Southwestern Asia, bordering the Black Sea, between Turkey
and Russia
Asia
4,700 sq km (1998 est.)
total: 69,700 sq km
land: 69,700 sq km
water: 0 sq km
chief of mission: Ambassador Levan MIKELADZE
chancery: Suite 300, 1615 New Hampshire Avenue NW, Washington, DC
20009
telephone: [1] (202) 387-2390
FAX: [1] (202) 393-6060
620,000 (1997)
185,500 (2000)
6 (2000)
25,000 (2002)
.ge
less than 0.1% (2001 est.)
less than 900 (2001 est.)
less than 100 (2001 est.)
GEL
37.1 (1996)
2,000 bbl/day (2001 est.)
31,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 34.8 years
male: 32.6 years
female: 37 years (2002)
60 million cu m (2001 est.)
1.16 billion cu m (2001 est.)
1.1 billion cu m (2001 est.)
0 cu m (2001 est.)','f83681583fe513434706b89e556c0f1101e9caaf487184f5aefcc56a9352ca05','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b864ca1f849cfee8429a67afe92adb935bfdfd6e11275eb9c74b0302469b722',2003,'DE','Germany','communications',882,'lowlands in north, uplands in center, Bavarian Alps in south
1.37 children born/woman (2003 est.)
federal republic
9.8% (2002 est.)
conventional long form: Federal Republic of Germany
conventional short form: Germany
local long form: Bundesrepublik Deutschland
local short form: Deutschland
former: German Empire, German Republic, German Reich
Central Europe, bordering the Baltic Sea and the North Sea,
between the Netherlands and Poland, south of Denmark
Europe
4,850 sq km (1998 est.)
total: 357,021 sq km
land: 349,223 sq km
water: 7,798 sq km
chief of mission: Ambassador Wolfgang Friedrich ISCHINGER
chancery: 4645 Reservoir Road NW, Washington, DC 20007
telephone: [1] (202) 298-8140
FAX: [1] (202) 298-4249
consulate(s) general: Atlanta, Boston, Chicago, Detroit, Houston,
Los Angeles, Miami, New York, San Francisco
50.9 million (March 2001)
55.3 million (June 2001)
200 (2001)
32.1 million (2002)
.de
0.1% (2001 est.)
41,000 (2001 est.)
660 (2001 est.)
EUR
30 (1994)
85,860 bbl/day (2001 est.)
2.813 million bbl/day (2001 est.)
3.081 million bbl/day (2001)
404,300 bbl/day (2001)
total: 41.3 years
male: 39.9 years
female: 42.8 years (2002)
327.3 million bbl (37257)
298.3 billion cu m (37257)
22.16 billion cu m (2001 est.)
94.34 billion cu m (2001 est.)
78.73 billion cu m (2001 est.)
6.674 billion cu m (2001 est.)','5a8e7d79d65aa014b0556aaf1b00c04560c29ef7977bbe644d5a5a20d42c68b1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a6453894a9f87b51df6591da84bc03e3b84ad5f410458eea80954e98681a7b5',2003,'GH','Ghana','communications',883,'mostly low plains with dissected plateau in south-central area
3.32 children born/woman (2003 est.)
constitutional democracy
20% (1997 est.)
conventional long form: Republic of Ghana
conventional short form: Ghana
former: Gold Coast
Western Africa, bordering the Gulf of Guinea, between Cote
d''Ivoire and Togo
Africa
110 sq km (1998 est.)
total: 239,460 sq km
land: 230,940 sq km
water: 8,520 sq km
chief of mission: Ambassador Alan J. KYEREMATEN
chancery: 3512 International Drive NW, Washington, DC 20008
telephone: [1] (202) 686-4520
FAX: [1] (202) 686-4527
consulate(s) general: New York
240,000 (2001)
150,000 (2001)
12 (2000)
200,000 (2002)
.gh
3% (2001 est.)
360,000 (2001 est.)
28,000 (2001 est.)
GHC
40.7 (1999)
7,000 bbl/day (2001 est.)
38,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 19.8 years
male: 19.5 years
female: 20 years (2002)
8.255 million bbl (37257)
11.89 billion cu m (37257)','b9846d795d186a07013a0402a0daebfd2d76b77dd5d2f48235fc7e986c8f5566','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b79ae7c909d2c4f4293cd0fdb54298437e67b8fb0f1837e885ea935a71f3c777',2003,'GI','Gibraltar','communications',884,'a narrow coastal lowland borders the Rock of Gibraltar
Glorioso Islands
low and flat
1.65 children born/woman (2003 est.)
NA
2% (2001 est.)
defense is the responsibility of the UK
Glorioso Islands
defense is the responsibility of France
conventional long form: none
conventional short form: Gibraltar
Glorioso Islands
conventional long form: none
conventional short form: Glorioso Islands
local long form: none
local short form: Iles Glorieuses
Southwestern Europe, bordering the Strait of Gibraltar,
which links the Mediterranean Sea and the North Atlantic Ocean, on
the southern coast of Spain
Glorioso Islands
Southern Africa, group of islands in the Indian
Ocean, northwest of Madagascar
Europe
Glorioso Islands
Africa
NA sq km
Glorioso Islands
0 sq km (1998 est.)
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Glorioso Islands
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes Ile Glorieuse, Ile du Lys, Verte Rocks, Wreck Rock,
and South Rock
none (overseas territory of the UK)
Glorioso Islands
none (possession of France)
19,000 (1997)
1,620 (1997)
2 (2000)
NA
.gi
NA%
NA
NA
GIP
0 bbl/day (2001 est.)
42,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 38.8 years
male: 38.6 years
female: 39 years (2002)','0ab4d90f0411b9b52dfb9dac38c74a8f83c40e330a0b4017bc81900ebdb694c4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39eb04f1aacd91579d2b68e43f357bd20d276152a5b85b073ddc701ea35e3532',2003,'GR','Greece','communications',885,'mostly mountains with ranges extending into the sea as
peninsulas or chains of islands
1.35 children born/woman (2003 est.)
parliamentary republic; monarchy rejected by referendum 8
December 1974
10.3% (2002 est.)
conventional long form: Hellenic Republic
conventional short form: Greece
local long form: Elliniki Dhimokratia
local short form: Ellas or Ellada
former: Kingdom of Greece
Southern Europe, bordering the Aegean Sea, Ionian Sea, and
the Mediterranean Sea, between Albania and Turkey
Europe
14,220 sq km (1998 est.)
total: 131,940 sq km
land: 130,800 sq km
water: 1,140 sq km
chief of mission: Ambassador Yeoryious SAVVAIDES
chancery: 2221 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 939-1300
FAX: [1] (202) 939-1324
consulate(s) general: Boston, Chicago, Los Angeles, New York, and
San Francisco
consulate(s): Atlanta, Houston, and New Orleans
5.431 million (1997)
937,700 (1997)
27 (2000)
1.4 million (2002)
.gr
0.2% (2001 est.)
8,800 (2001 est.)
less than 100 (2001 est.)
EUR
32.7 (1993)
5,992 bbl/day (2001 est.)
405,700 bbl/day (2001 est.)
468,300 bbl/day (2001)
84,720 bbl/day (2001)
total: 39.8 years
male: 38.6 years
female: 41 years (2002)
4.5 million bbl (37257)
254.9 million cu m (37257)
35 million cu m (2001 est.)
2.021 billion cu m (2001 est.)
2.018 billion cu m (2001 est.)
0 cu m (2001 est.)','bcd5699bb2ca4e3059e09e2d7d5569adcf7b6d44cbbae59f5ca4a102fbf9173e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('082f551b6e2e74c6de690fdbf6f5044e12aa1eb7473df830f8633a7d3bdbba5b',2003,'GL','Greenland','communications',886,'flat to gradually sloping icecap covers all but a narrow,
mountainous, barren, rocky coast
2.43 children born/woman (2003 est.)
parliamentary democracy within a constitutional monarchy
10% (2000 est.)
defense is the responsibility of Denmark
conventional long form: none
conventional short form: Greenland
local long form: none
local short form: Kalaallit Nunaat
Northern North America, island between the Arctic Ocean
and the North Atlantic Ocean, northeast of Canada
Arctic Region
NA sq km
total: 2,166,086 sq km
land: 2,166,086 sq km (410,449 sq km ice-free, 1,755,637 sq km
ice-covered) (2000 est.)
none (self-governing overseas administrative division of
Denmark)
25,617 (yearend 1999)
12,676 (yearend 1999)
1 (2000)
20,000 (2002)
.gl
NA%
100 (1999)
NA
DKK
0 bbl/day (2001 est.)
3,700 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 33.1 years
male: 34.3 years
female: 31.7 years (2002)','c8efcabbd9c916119271b5cfac3f0beda359fbe2e9cdcbd3eecba3528e252262','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f28f899c5d23b05d846ec4482f789f3efbdea8f6c9ee6905092a5e0efe84a74',2003,'GD','Grenada','communications',887,'volcanic in origin with central mountains
2.45 children born/woman (2003 est.)
constitutional monarchy with Westminster-style parliament
12.5% (2000)
conventional long form: none
conventional short form: Grenada
Caribbean, island between the Caribbean Sea and Atlantic
Ocean, north of Trinidad and Tobago
Central America and the Caribbean
NA sq km
total: 344 sq km
land: 344 sq km
water: 0 sq km
chief of mission: Ambassador Denis G. ANTOINE
chancery: 1701 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 265-2561
FAX: [1] (202) 265-2468
consulate(s) general: New York
27,000 (1997)
976 (1997)
14 (2000)
5,200 (2002)
.gd
NA%
NA
NA
XCD
0 bbl/day (2001 est.)
1,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 20.5 years
male: 21 years
female: 20 years (2002)','124e8a8ce82e17a8110b8ffdabb959536d539333df24c3e8e16695ca4473d77c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb6c3410f0802e03f0f7a3757787a72faa41cb76a38cf24aedb098c01089855d',2003,'GP','Guadeloupe','communications',888,'Basse-Terre is volcanic in origin with interior
mountains; Grande-Terre is low limestone formation; most of the
seven other islands are volcanic in origin
1.92 children born/woman (2003 est.)
NA
27.8% (1998)
defense is the responsibility of France
conventional long form: Department of Guadeloupe
conventional short form: Guadeloupe
local long form: Departement de la Guadeloupe
local short form: Guadeloupe
Caribbean, islands between the Caribbean Sea and the
North Atlantic Ocean, southeast of Puerto Rico
Central America and the Caribbean
20 sq km (1998 est.)
total: 1,780 sq km
land: 1,706 sq km
water: 74 sq km
note: Guadeloupe is an archipelago of nine inhabited islands,
including Basse-Terre, Grande-Terre, Marie-Galante, La Desirade,
Iles des Saintes (2), Saint-Barthelemy, Iles de la Petite Terre, and
Saint-Martin (French part of the island of Saint Martin)
none (overseas department of France)
171,000 (1996)
NA
3 (2000)
4,000 (2000)
.gp
NA%
NA
NA
EUR; FRF
0 bbl/day (2001 est.)
13,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 31 years
male: 30.2 years
female: 31.9 years (2002)','ba7be89356a5f03580e409360a257d6e1f8b552ea0af4caa7c6cb3e07b491c75','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('913d568410b1b3974e51ef9708eed2b27fcd8a49fdb7752f0c4ba57cba7b7260',2003,'GU','Guam','communications',889,'volcanic origin, surrounded by coral reefs; relatively flat
coralline limestone plateau (source of most fresh water), with steep
coastal cliffs and narrow coastal plains in north, low hills in
center, mountains in south
3.62 children born/woman (2003 est.)
NA
15% (2000 est.)
defense is the responsibility of the US
conventional long form: Territory of Guam
conventional short form: Guam
local long form: Guahan
Oceania, island in the North Pacific Ocean, about
three-quarters of the way from Hawaii to the Philippines
Oceania
NA sq km
total: 549 sq km
land: 549 sq km
water: 0 sq km
none (territory of the US)
84,134 (1998)
55,000 (1998)
20 (2000)
5,000 (2000)
.gu
NA%
NA
NA
USD
0 bbl/day (2001 est.)
20,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 25.2 years
male: 25.6 years
female: 24.9 years (2002)','1b852e3ac42773a84e3783c82e1132e17be8d5ad0b7dfe0b8511126b97b97133','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e83cd77eee0c5ca3d136267f9134850aff62b5ecf6770ce894a6e13fc4ba627',2003,'GT','Guatemala','communications',890,'mostly mountains with narrow coastal plains and rolling
limestone plateau (Peten)
4.67 children born/woman (2003 est.)
constitutional democratic republic
7.5% (1999 est.)
conventional long form: Republic of Guatemala
conventional short form: Guatemala
local long form: Republica de Guatemala
local short form: Guatemala
Middle America, bordering the North Pacific Ocean, between
El Salvador and Mexico, and bordering the Gulf of Honduras
(Caribbean Sea) between Honduras and Belize
Central America and the Caribbean
1,250 sq km (1998 est.)
total: 108,890 sq km
land: 108,430 sq km
water: 460 sq km
chief of mission: Ambassador Antonio Fernando ARENALES
Forno
chancery: 2220 R Street NW, Washington, DC 20008
telephone: [1] (202) 745-4952
FAX: [1] (202) 745-1908
consulate(s) general: Chicago, Denver, Houston, Los Angeles, Miami,
New York, and San Francisco
665,061 (June 2000)
663,296 (September 2000)
5 (2000)
200,000 (2002)
.gt
1% (2001 est.)
67,000 (2001 est.)
5,200 (2001 est.)
GTQ; USD
55.8 (1998)
21,080 bbl/day (2001 est.)
61,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.3 years
male: 18.1 years
female: 18.5 years (2002)
263 million bbl (37257)
1.543 billion cu m (37257)','200850649754797514762e3b8d8e5698601daf91e6a5db19702647c236840b52','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bf9a8cc1476dea7cc2ea5838880e3d871fd899accb2c9caa433b27e09eb185a',2003,'GG','Guernsey','communications',891,'mostly level with low hills in southwest
1.37 children born/woman (2003 est.)
NA
0.5% (1999 est.)
defense is the responsibility of the UK
conventional long form: Bailiwick of Guernsey
conventional short form: Guernsey
Western Europe, islands in the English Channel, northwest
of France
Europe
NA sq km
total: 78 sq km
land: 78 sq km
water: 0 sq km
note: includes Alderney, Guernsey, Herm, Sark, and some other
smaller islands
none (British crown dependency)
44,000 (1996)
12,000 (1997)
NA
NA
.gg
NA%
NA
NA
GBP
total: 40.2 years
male: 39.3 years
female: 41.1 years (2002)','753c9f39b47816f3f912075865bc3df9460de593f3e9fb1a5ad2bc4476194b9f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d03ca4d1f6709700cc6208a2276417b1e1ad910ef16b304c2eabe5f7a7d91103',2003,'GN','Guinea','communications',892,'generally flat coastal plain, hilly to mountainous interior
5.9 children born/woman (2003 est.)
republic
NA%
conventional short form: Equatorial Guinea
local long form: Republica de Guinea Ecuatorial
local short form: Guinea Ecuatorial
former: Spanish Guinea
conventional long form: Republic of Guinea
conventional short form: Guinea
local long form: Republique de Guinee
local short form: Guinee
former: French Guinea
Western Africa, bordering the North Atlantic Ocean, between
Guinea-Bissau and Sierra Leone
Africa
950 sq km (1998 est.)
total: 245,857 sq km
land: 245,857 sq km
water: 0 sq km
chief of mission: Ambassador Rafiou Alpha Oumar BARRY
chancery: 2112 Leroy Place NW, Washington, DC 20008
telephone: [1] (202) 986-4300
FAX: [1] (202) 478-3010
37,000 (1998)
21,567 (1998)
4 (2001)
15,000 (2002)
.gn
1.54% (2001 est.)
55,000 (1999 est.)
9,000 (2001 est.)
GNF
40.3 (1994)
0 bbl/day (2001 est.)
8,600 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 17.7 years
male: 17.4 years
female: 17.9 years (2002)','3ee81baf5b2d4247ba38949921b781c2889d2d295df58c3fdd7f275214cea6c9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a68cd95782f084f7419a29435e2cf553f1fe34c4236e68541fd14c7b33f9ac9',2003,'GW','Guinea-Bissau','communications',893,'mostly low coastal plain rising to savanna in east
5.07 children born/woman (2003 est.)
republic, multiparty since mid-1991
NA%
conventional long form: Republic of Guinea-Bissau
conventional short form: Guinea-Bissau
local long form: Republica da Guine-Bissau
local short form: Guine-Bissau
former: Portuguese Guinea
Western Africa, bordering the North Atlantic Ocean,
between Guinea and Senegal
Africa
170 sq km (1998 est.)
total: 36,120 sq km
land: 28,000 sq km
water: 8,120 sq km
chief of mission: Ambassador (vacant); Charge
d''Affaires Henrique Adriano DA SILVA
chancery: 1511 K Street NW, Suite 519, Washington, DC 20005
telephone: [1] (202) 347-3950
FAX: [1] (202) 347-3954
10,000 (2001)
0 (2001)
2 (2002)
4,000 (2002)
.gw
2.8% (2001 est.)
17,000 (2001 est.)
1,200 (2001 est.)
XOF; GWP
0 bbl/day (2001 est.)
2,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.8 years
male: 18.2 years
female: 19.4 years (2002)','f7ad0151e17d77eef8ec5492c37bd56e2c560ff4d5ade4eade62acf1c55c46f5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db06e4f213cc090c00844beee9ccf31b4bf95e2c2cc97e30e269201402161b6b',2003,'GY','Guyana','communications',894,'mostly rolling highlands; low coastal plain; savanna in south
2.07 children born/woman (2003 est.)
republic within the Commonwealth
9.1% (understated) (2000)
conventional long form: Co-operative Republic of Guyana
conventional short form: Guyana
former: British Guiana
Northern South America, bordering the North Atlantic Ocean,
between Suriname and Venezuela
South America
1,500 sq km (1998 est.)
total: 214,970 sq km
land: 196,850 sq km
water: 18,120 sq km
chief of mission: Ambassador Dr. Ali Odeen ISHMAEL
chancery: 2490 Tracy Place NW, Washington, DC 20008
telephone: [1] (202) 265-6900
FAX: [1] (202) 232-1297
consulate(s) general: New York
70,000 (2000)
6,100 (2000)
3 (2000)
95,000 (2002)
.gy
2.7% (2001 est.)
18,000 (2001 est.)
1,300 (2001 est.)
GYD
0 bbl/day (2001 est.)
11,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 25.7 years
male: 25.2 years
female: 26.3 years (2002)','9827c9ca83427cf3a93a1cfa44171e3504d93f1a867280025f9c36e311d0dc81','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12725f77eb6538380e7a4a29e27cc7d29281e18e8644d86c35c0927af8c89db6',2003,'HT','Haiti','communications',895,'mostly rough and mountainous
4.86 children born/woman (2003 est.)
elected government
Holy See (Vatican City)
ecclesiastical
widespread unemployment and underemployment; more than
two-thirds of the labor force do not have formal jobs (2002 est.)
conventional long form: Republic of Haiti
conventional short form: Haiti
local long form: Republique d''Haiti
local short form: Haiti
Caribbean, western one-third of the island of Hispaniola,
between the Caribbean Sea and the North Atlantic Ocean, west of the
Central America and the Caribbean
750 sq km (1998 est.)
total: 27,750 sq km
land: 27,560 sq km
water: 190 sq km
chief of mission: Ambassador (vacant); Chief of Mission Harry
Frantz LEO
chancery: 2311 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 332-4090
FAX: [1] (202) 745-7215
consulate(s) general: Boston, Chicago, Miami, New York, and San Juan
(Puerto Rico)
60,000 (1997)
Holy See (Vatican City)
NA
over 180,000 (January 2003)
Holy See (Vatican City)
NA
3 (2000)
Holy See (Vatican City)
NA
30,000 (2002)
Holy See (Vatican City)
NA
.ht
6.1% (2001 est.)
Holy See (Vatican City)
NA%
250,000 (2001 est.)
Holy See (Vatican City)
NA
30,000 (2001 est.)
Holy See (Vatican City)
NA
HTG
Holy See (Vatican City)
EUR
0 bbl/day (2001 est.)
11,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 17.9 years
male: 17.4 years
female: 18.5 years (2002)','9b013fc03b2297b5fa2ae0d2b7777a77854f79b8b5c49e64ed2060e593703650','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5da1d7f5b61230e0958837fe07cf76fb48c680bdd6d0f257cf4f872c13c07445',2003,'HM','Heard Island and McDonald Islands','communications',896,'Heard Island - 80% ice-covered,
bleak and mountainous, dominated by a large massif (Big Ben) and an
active volcano (Mawson Peak); McDonald Islands - small and rocky
Holy See (Vatican City)
low hill
defense is the responsibility of
Australia; Australia conducts fisheries patrols
Holy See (Vatican City)
defense is the responsibility of Italy;
Swiss Papal Guards are posted at entrances to the Vatican City to
provide security and protect the Pope
conventional long form: Territory
of Heard Island and McDonald Islands
conventional short form: Heard Island and McDonald Islands
Holy See (Vatican City)
conventional long form: The Holy See (State
of the Vatican City)
conventional short form: Holy See (Vatican City)
local long form: Santa Sede (Stato della Citta del Vaticano)
local short form: Santa Sede (Citta del Vaticano)
islands in the Indian Ocean, about
two-thirds of the way from Madagascar to Antarctica
Holy See (Vatican City)
Southern Europe, an enclave of Rome (Italy)
Antarctic Region
Holy See (Vatican City)
Europe
0 sq km (1998 est.)
Holy See (Vatican City)
0 sq km (1998 est.)
total: 412 sq km
land: 412 sq km
water: 0 sq km
Holy See (Vatican City)
total: 0.44 sq km
land: 0.44 sq km
water: 0 sq km
none (territory of Australia)
Holy See (Vatican City)
chief of mission: Apostolic Nuncio
Archbishop Gabriel MONTALVO
chancery: 3339 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 333-7121
FAX: [1] (202) 337-4036
.hm
Holy See (Vatican City)
.va','b0fdab55b5e9ba26dfa05d15126bb64ec0b3c21a3fcae4de68c2789e7ef95c49','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75cd11f95b605ee1d4a03fc0d01f5aa6d149fd87245524bb629d25d6c8747142',2003,'HN','Honduras','communications',897,'mostly mountains in interior, narrow coastal plains
4.07 children born/woman (2003 est.)
democratic constitutional republic
28% (2002 est.)
conventional long form: Republic of Honduras
conventional short form: Honduras
local long form: Republica de Honduras
local short form: Honduras
Middle America, bordering the Caribbean Sea, between
Guatemala and Nicaragua and bordering the Gulf of Fonseca (North
Pacific Ocean), between El Salvador and Nicaragua
Central America and the Caribbean
760 sq km (1998 est.)
total: 112,090 sq km
land: 111,890 sq km
water: 200 sq km
chief of mission: Ambassador Mario Miguel CANAHUATI
chancery: Suite 4-M, 3007 Tilden Street NW, Washington, DC 20008
telephone: [1] (202) 966-2604
FAX: [1] (202) 966-9751
consulate(s) general: Chicago, Houston, Los Angeles, Miami, New
Orleans, New York, Phoenix, San Francisco, San Juan (Puerto Rico),
Tampa
honorary consulate(s): Atlanta, Boston, Detroit, Jacksonville
234,000 (1997)
14,427 (1997)
8 (2000)
40,000 (2000)
.hn
1.6% (2001 est.)
57,000 (2001 est.)
3,300 (2001 est.)
HNL
56.3 (1998)
0 bbl/day (2001 est.)
29,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.8 years
male: 18.4 years
female: 19.2 years (2002)','f93d71a67fce76c1e332cff7f747ec4ca270e2df175d419a3630265ef1392a39','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f09b1b11851fb83ebd40fbc7d3913812af267e4787696429d504d549504032b',2003,'HK','Hong Kong','communications',898,'hilly to mountainous with steep slopes; lowlands in north
Howland Island
low-lying, nearly level, sandy, coral island
surrounded by a narrow fringing reef; depressed central area
1.32 children born/woman (2003 est.)
limited democracy
7.5% (2002 est.)
defense is the responsibility of China
Howland Island
defense is the responsibility of the US; visited
annually by the US Coast Guard
conventional long form: Hong Kong Special Administrative
Region
conventional short form: Hong Kong
local long form: Xianggang Tebie Xingzhengqu
local short form: Xianggang
abbreviation: HK
Howland Island
conventional long form: none
conventional short form: Howland Island
Eastern Asia, bordering the South China Sea and China
Howland Island
Oceania, island in the North Pacific Ocean, about
half way between Hawaii and Australia
Southeast Asia
Howland Island
Oceania
20 sq km (1998 est.)
Howland Island
0 sq km (1998 est.)
total: 1,092 sq km
land: 1,042 sq km
water: 50 sq km
Howland Island
total: 1.6 sq km
land: 1.6 sq km
water: 0 sq km
none (special administrative region of China)
3.839 million (1999)
3.7 million (December 1999)
17 (2000)
4.35 million (2002)
.hk
0.1% (2001 est.)
2,600 (2001 est.)
less than 100 (2001 est.)
HKD
0 bbl/day (2001 est.)
257,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 37.5 years
male: 37.1 years
female: 37.7 years (2002)
0 cu m (2001 est.)
680.9 million cu m (2001 est.)
680.9 million cu m (2001 est.)
0 cu m (2001 est.)','a428c6a85f501d3740af91e9818d65f3e42684731e9015e10b7f696494426c4a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99604b6f9d6b22ea1d0ab438b666cf577ab39bf1a3d9a5e9ff1a70e523a3f285',2003,'HU','Hungary','communications',899,'mostly flat to rolling plains; hills and low mountains on
the Slovakian border
1.25 children born/woman (2003 est.)
parliamentary democracy
5.8% (2002 est.)
conventional long form: Republic of Hungary
conventional short form: Hungary
local long form: Magyar Koztarsasag
local short form: Magyarorszag
Central Europe, northwest of Romania
Europe
2,100 sq km (1998 est.)
total: 93,030 sq km
land: 92,340 sq km
water: 690 sq km
chief of mission: Ambassador Andras SIMONYI
chancery: 3910 Shoemaker Street NW, Washington, DC 20008
telephone: [1] (202) 362-6730
FAX: [1] (202) 966-8135
consulate(s) general: Los Angeles and New York
3.095 million (1997)
1.269 million (July 1999)
16 (2000)
1.2 million (2001)
.hu
0.1% (2001 est.)
2,800 (2001 est.)
less than 100 (2001 est.)
HUF
24.4 (1998)
41,190 bbl/day (2001 est.)
140,700 bbl/day (2001 est.)
136,600 bbl/day (2001)
47,180 bbl/day (2001)
total: 38.4 years
male: 35.7 years
female: 41.1 years (2002)
110.7 million bbl (37257)
50.45 billion cu m (37257)
3.231 billion cu m (2001 est.)
13.37 billion cu m (2001 est.)
9.587 billion cu m (2001 est.)
4 million cu m (2001 est.)','d0821539d368a4e1b6a3d7d64b0c1760f4bbebe906fe69805112851d0283e459','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bb5505e1345342575a6a8ad4df3340caeef637cf6f18ddf17b4d3aa6ffc2215',2003,'IS','Iceland','communications',900,'mostly plateau interspersed with mountain peaks, icefields;
coast deeply indented by bays and fiords
1.98 children born/woman (2003 est.)
constitutional republic
2.8% (2002 est.)
defense is provided by the US-manned Icelandic Defense Force
(IDF) headquartered at Keflavik
Jan Mayen
defense is the responsibility of Norway
Jarvis Island
defense is the responsibility of the US; visited
annually by the US Coast Guard
conventional long form: Republic of Iceland
conventional short form: Iceland
local long form: Lydhveldidh Island
local short form: Island
Northern Europe, island between the Greenland Sea and the
North Atlantic Ocean, northwest of the UK
Arctic Region
NA sq km
total: 103,000 sq km
land: 100,250 sq km
water: 2,750 sq km
chief of mission: Ambassador Helgi AGUSTSSON
chancery: Suite 1200, 1156 15th Street NW, Washington, DC 20005-1704
telephone: [1] (202) 265-6653
FAX: [1] (202) 265-6656
consulate(s) general: New York
196,984 (2001)
248,131 (221,231 GSM, 26,900 NMT) (2001)
20 (2001)
220,000 (2002)
.is
0.2% (2001 est.)
220 (2001 est.)
less than 100 (2001 est.)
ISK
0 bbl/day (2001 est.)
16,300 bbl/day (2001 est.)
15,470 bbl/day (2001)
0 bbl/day (2001)
total: 34 years
male: 33.2 years
female: 34.7 years (2002)','87a08d66334bf60ce04a99385376b03a641b3b9d957e57089920ca49f795b580','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a21dfe3b73512360c3bc28e2b03abd79adf3babd516cbf07b6e20fb5c58de6a',2003,'IN','India','communications',901,'upland plain (Deccan Plateau) in south, flat to rolling plain
along the Ganges, deserts in west, Himalayas in north
Indian Ocean
surface dominated by counterclockwise gyre (broad,
circular system of currents) in the southern Indian Ocean; unique
reversal of surface currents in the northern Indian Ocean; low
atmospheric pressure over southwest Asia from hot, rising, summer
air results in the southwest monsoon and southwest-to-northeast
winds and currents, while high pressure over northern Asia from
cold, falling, winter air results in the northeast monsoon and
northeast-to-southwest winds and currents; ocean floor is dominated
by the Mid-Indian Ocean Ridge and subdivided by the Southeast Indian
Ocean Ridge, Southwest Indian Ocean Ridge, and Ninetyeast Ridge
2.91 children born/woman (2003 est.)
federal republic
8.8% (2002)
conventional long form: Republic of India
conventional short form: India
Southern Asia, bordering the Arabian Sea and the Bay of
Bengal, between Burma and Pakistan
Indian Ocean
body of water between Africa, the Southern Ocean, Asia,
and Australia
Asia
Indian Ocean
Political Map of the World
590,000 sq km (1998 est.)
total: 3,287,590 sq km
land: 2,973,190 sq km
water: 314,400 sq km
Indian Ocean
total: 68.556 million sq km
note: includes Andaman Sea, Arabian Sea, Bay of Bengal, Flores Sea,
Great Australian Bight, Gulf of Aden, Gulf of Oman, Java Sea,
Mozambique Channel, Persian Gulf, Red Sea, Savu Sea, Strait of
Malacca, Timor Sea, and other tributary water bodies
chief of mission: Ambassador Lalit MANSINGH
chancery: 2107 Massachusetts Avenue NW, Washington, DC 20008; note -
Embassy located at 2536 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 939-7000
FAX: [1] (202) 483-3972
consulate(s) general: Chicago, Houston, New York, and San Francisco
27.7 million (October 2000)
2.93 million (November 2000)
43 (2000)
7 million (2002)
.in
0.8% (2001 est.)
3.97 million (2001 est.)
310,000 (2001 est.)
INR
37.8 (1997)
732,400 bbl/day (2001 est.)
2.13 million bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 24.1 years
male: 24.1 years
female: 24.2 years (2002)
4.33 billion bbl (37257)
542.4 billion cu m (37257)
22.75 billion cu m (2001 est.)
22.75 billion cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','e0f088d50c09c72ba6807e9f2b1fb4de0df455d2154632014079767d77b6a309','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('865a250ad2be30afce661de259b8ca12f7844736fc004fba54b12a97c62aec82',2003,'ID','Indonesia','communications',902,'mostly coastal lowlands; larger islands have interior
mountains
Iran
rugged, mountainous rim; high, central basin with deserts,
mountains; small, discontinuous plains along both coasts
2.5 children born/woman (2003 est.)
Iran
1.99 children born/woman (2003 est.)
republic
Iran
theocratic republic
10.6% (2002 est.)
Iran
16.3% (2003 est.)
conventional long form: Republic of Indonesia
conventional short form: Indonesia
local long form: Republik Indonesia
local short form: Indonesia
former: Netherlands East Indies; Dutch East Indies
Iran
conventional long form: Islamic Republic of Iran
conventional short form: Iran
local long form: Jomhuri-ye Eslami-ye Iran
local short form: Iran
former: Persia
Southeastern Asia, archipelago between the Indian Ocean
and the Pacific Ocean
Iran
Middle East, bordering the Gulf of Oman, the Persian Gulf, and
the Caspian Sea, between Iraq and Pakistan
Midway Islands
Oceania, atoll in the North Pacific Ocean, about
one-third of the way from Honolulu to Tokyo
Moldova
Eastern Europe, northeast of Romania
Southeast Asia
Iran
Middle East
48,150 sq km (1998 est.)
Iran
75,620 sq km (1998 est.)
total: 1,919,440 sq km
land: 1,826,440 sq km
water: 93,000 sq km
Iran
total: 1.648 million sq km
land: 1.636 million sq km
water: 12,000 sq km
chief of mission: Ambassador SOEMADI Brotodiningrat
chancery: 2020 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 775-5200
FAX: [1] (202) 775-5365
consulate(s) general: Chicago, Houston, Los Angeles, New York, and
San Francisco
Iran
none; note - Iran has an Interests Section in the Pakistani
Embassy; address: Iranian Interests Section, Pakistani Embassy, 2209
Wisconsin Avenue NW, Washington, DC 20007; telephone: [1] (202)
965-4990
5,588,310 (1998)
Iran
6.313 million (1997)
1.07 million (1998)
Iran
265,000 (August 1998)
24 (2000)
Iran
100 (2002)
4.4 million (2002)
Iran
1.326 million (2002 est.)
.id
Iran
.ir
0.1% (2001 est.)
Iran
less than 0.1% (2001 est.)
120,000 (2001 est.)
Iran
20,000 (2001 est.)
4,600 (2001 est.)
Iran
290 (2001 est.)
IDR
Iran
IRR
31.7 (1999)
1.451 million bbl/day (2001 est.)
Iran
3.804 million bbl/day (2001 est.)
1.045 million bbl/day (2001 est.)
Iran
1.277 million bbl/day (2001 est.)
NA (2001)
Iran
NA (2001)
NA (2001)
Iran
NA (2001)
total: 25.8 years
male: 25.4 years
female: 26.2 years (2002)
Iran
total: 22.9 years
male: 22.7 years
female: 23.2 years (2002)
7.083 billion bbl (37257)
Iran
94.39 billion bbl (37257)
2.549 trillion cu m (37257)
Iran
24.8 trillion cu m (37257)
69 billion cu m (2001 est.)
Iran
61.5 billion cu m (2001 est.)
36.2 billion cu m (2001 est.)
Iran
65.59 billion cu m (2001 est.)
0 cu m (2001 est.)
Iran
4.2 billion cu m (2001 est.)
32.8 billion cu m (2001 est.)
Iran
110 million cu m (2001 est.)','14f866f7d9a16b3e1dc5742c49e6f2cdd90c6dad39616dfc0951405ffc2af053','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b276a0deb644d6705b483dab912fbbfe733988e76702f0fcf6a42914259acb37',2003,'IQ','Iraq','communications',903,'mostly broad plains; reedy marshes along Iranian border in
south with large flooded areas; mountains along borders with Iran
and Turkey
4.52 children born/woman (2003 est.)
in transition following April 2003 defeat of SADDAM Husayn
regime by US-led coalition
NA%
conventional long form: Republic of Iraq
conventional short form: Iraq
local long form: Al Jumhuriyah al Iraqiyah
local short form: Al Iraq
Middle East, bordering the Persian Gulf, between Iran and Kuwait
Middle East
35,250 sq km (1998 est.)
total: 437,072 sq km
land: 432,162 sq km
water: 4,910 sq km
in transition following April 2003 defeat of SADDAM Husayn
regime by US-led coalition
675,000 (1997); note - an unknown number of telephone lines
were damaged or destroyed during the March-April war
NA; service available in northern Iraq (2001)
1 (2000)
12,500 (2001)
.iq
less than 0.1% (2001 est.)
less than 1,000
NA
IQD
2.452 million bbl/day (2001 est.); note - production was
disrupted as a result of the March-April 2003 war (2001 est.)
460,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 19 years
male: 18.9 years
female: 19.1 years (2002)
113.8 billion bbl (37257)
3.149 trillion cu m (37257)
2.76 billion cu m (2001 est.)
2.76 billion cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','def2b5360a6c90165c3e994a3e5a13ad02e1cb84e6e4ca3fd13d706239bd8854','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e11be214bcf1b31abb3b1fe316e7891d0b94d099864381ecf574ca03ecc067c',2003,'IE','Ireland','communications',904,'mostly level to rolling interior plain surrounded by rugged
hills and low mountains; sea cliffs on west coast
1.89 children born/woman (2003 est.)
republic
4.3% (2002 est.)
conventional long form: none
conventional short form: Ireland
Western Europe, occupying five-sixths of the island of
Ireland in the North Atlantic Ocean, west of Great Britain
Europe
NA sq km
total: 70,280 sq km
land: 68,890 sq km
water: 1,390 sq km
chief of mission: Ambassador Noel FAHEY; note - FAHEY has
announced that he will leave
chancery: 2234 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 462-3939
FAX: [1] (202) 232-5993
consulate(s) general: Boston, Chicago, New York, and San Francisco
1.6 million (2002)
3 million (2002)
22 (2000)
1.31 million (2002)
.ie
0.1% (2001 est.)
2,400 (2001 est.)
less than 100 (2001 est.)
EUR
35.9 (1987)
0 bbl/day (2001 est.)
174,400 bbl/day (2001 est.)
178,600 bbl/day (2001)
27,450 bbl/day (2001)
total: 33.1 years
male: 32.2 years
female: 34 years (2002)
0 bbl (37257)
9.911 billion cu m (37257)
815 million cu m (2001 est.)
4.199 billion cu m (2001 est.)
3.384 billion cu m (2001 est.)
0 cu m (2001 est.)','99385d1a174461e380f55c9bd62ec2db5aafcfa1ffb96e8abf47686c0223df15','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('676092a22142b5d07f19172a5ac3b805430262d2c5b56202c01af119ddfb4209',2003,'IL','Israel','communications',905,'Negev desert in the south; low coastal plain; central
mountains; Jordan Rift Valley
2.5 children born/woman (2003 est.)
parliamentary democracy
10.4% (2002 est.)
conventional long form: State of Israel
conventional short form: Israel
local long form: Medinat Yisra''el
local short form: Yisra''el
Middle East, bordering the Mediterranean Sea, between Egypt
and Lebanon
Middle East
1,990 sq km (1998 est.)
total: 20,770 sq km
land: 20,330 sq km
water: 440 sq km
chief of mission: Ambassador Daniel AYALON
chancery: 3514 International Drive NW, Washington, DC 20008
telephone: [1] (202) 364-5500
FAX: [1] (202) 364-5607
consulate(s) general: Atlanta, Boston, Chicago, Houston, Los
Angeles, Miami, New York, Philadelphia, and San Francisco
2.8 million (1999)
2.5 million (1999)
21 (2000)
1.94 million (2001)
.il
0.1% (2001 est.)
2,400 (1999 est.)
100 (2001 est.)
ILS
35.5 (2001)
80 bbl/day NA bbl/day (2001 est.)
260,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 28.9 years
male: 28.1 years
female: 29.8 years (2002)
1.92 million bbl (37257)
20.81 billion cu m (37257)
10 million cu m (2001 est.)
10 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','797c1c502b2b0233586b41a2c38677dfa0c1fcd2f9805347b523f4a2ab29c99d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea7f8b3217cc7dd312c5faf895e45a028345a778c738ba141a1eaa5957793297',2003,'IT','Italy','communications',906,'mostly rugged and mountainous; some plains, coastal lowlands
1.26 children born/woman (2003 est.)
republic
9.1% (2002 est.)
conventional long form: Italian Republic
conventional short form: Italy
local long form: Repubblica Italiana
local short form: Italia
former: Kingdom of Italy
Southern Europe, a peninsula extending into the central
Mediterranean Sea, northeast of Tunisia
Europe
26,980 sq km (1998 est.)
total: 301,230 sq km
land: 294,020 sq km
water: 7,210 sq km
note: includes Sardinia and Sicily
chief of mission: Ambassador Sergio VENTO
chancery: 3000 Whitehaven Street NW, Washington, DC 20008
telephone: [1] (202) 612-4400
FAX: [1] (202) 518-2151
consulate(s) general: Boston, Chicago, Houston, Miami, New York, Los
Angeles, Philadelphia, and San Francisco
consulate(s): Detroit
25 million (1999)
20.5 million (1999)
93 (Italy and Holy See) (2000)
19.25 million (2001)
.it
0.4% (2001 est.)
100,000 (2001 est.)
1,100 (2001 est.)
EUR
27.3 (1995)
79,460 bbl/day (2001 est.)
1.866 million bbl/day (2001 est.)
2.158 million bbl/day (2001)
456,600 bbl/day (2001)
total: 41 years
male: 39.4 years
female: 42.6 years (2002)
586.6 million bbl (37257)
209.7 billion cu m (37257)
15.49 billion cu m (2001 est.)
71.18 billion cu m (2001 est.)
54.78 billion cu m (2001 est.)
61 million cu m (2001 est.)','3ffadd6673ea38fc95a855abc1210e526502047338dcd02988112694dcb62c2b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7724b7daae0d849f07cee751348ad133061d8751222244574dc11e8aacb35a0b',2003,'JM','Jamaica','communications',907,'mostly mountains, with narrow, discontinuous coastal plain
Jan Mayen
volcanic island, partly covered by glaciers
2.01 children born/woman (2003 est.)
constitutional parliamentary democracy
15.4% (2002 est.)
conventional long form: none
conventional short form: Jamaica
Jan Mayen
conventional long form: none
conventional short form: Jan Mayen
Caribbean, island in the Caribbean Sea, south of Cuba
Jan Mayen
Northern Europe, island between the Greenland Sea and the
Norwegian Sea, northeast of Iceland
Central America and the Caribbean
Jan Mayen
Arctic Region
250 sq km (1998 est.)
Jan Mayen
0 sq km (1998 est.)
total: 10,991 sq km
land: 10,831 sq km
water: 160 sq km
Jan Mayen
total: 373 sq km
land: 373 sq km
water: 0 sq km
chief of mission: Ambassador Seymour MULLINGS
chancery: 1520 New Hampshire Avenue NW, Washington, DC 20036
telephone: [1] (202) 452-0660
FAX: [1] (202) 452-0081
consulate(s) general: Miami and New York
353,000 (1996)
54,640 (1996)
21 (2000)
Jan Mayen
13 (Jan Mayen and Svalbard) (2000)
100,000 (2002)
.jm
1.2% (2001 est.)
20,000 (2001 est.)
980 (2001 est.)
JMD
37.9 (2000)
0 bbl/day (2001 est.)
66,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 26.5 years
male: 25.8 years
female: 27.2 years (2002)','8acae473630c88f4d8917386854d02240582f9c39bf7182c6056ad3cc57dbd42','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fb12b100771fe240c4c6d5f0cc732fd33af0c19bda8eaf4428ee654e7f22c79',2003,'JP','Japan','communications',908,'mostly rugged and mountainous
Jarvis Island
sandy, coral island surrounded by a narrow fringing
reef
1.38 children born/woman (2003 est.)
constitutional monarchy with a parliamentary government
5.4% (2002)
conventional long form: none
conventional short form: Japan
Jarvis Island
conventional long form: none
conventional short form: Jarvis Island
Eastern Asia, island chain between the North Pacific Ocean and
the Sea of Japan, east of the Korean Peninsula
Jarvis Island
Oceania, island in the South Pacific Ocean, about half
way between Hawaii and the Cook Islands
Asia
Jarvis Island
Oceania
26,790 sq km (1998 est.)
Jarvis Island
0 sq km (1998 est.)
total: 377,835 sq km
land: 374,744 sq km
water: 3,091 sq km
note: includes Bonin Islands (Ogasawara-gunto), Daito-shoto,
Minami-jima, Okino-tori-shima, Ryukyu Islands (Nansei-shoto), and
Volcano Islands (Kazan-retto)
Jarvis Island
total: 4.5 sq km
land: 4.5 sq km
water: 0 sq km
chief of mission: Ambassador Ryozo KATO
chancery: 2520 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 238-6700
FAX: [1] (202) 328-2187
consulate(s) general: Anchorage, Atlanta, Boston, Chicago, Denver,
Detroit, Hagatna (Guam), Honolulu, Houston, Kansas City (Missouri),
Los Angeles, Miami, New Orleans, New York, Portland (Oregon), San
Francisco, and Seattle
consulate(s): Saipan (Northern Mariana Islands)
60.381 million (1997)
63.88 million (2000)
73 (2000)
56 million (2002)
.jp
less than 0.1% (2001 est.)
12,000 (2001 est.)
430 (2001 est.)
JPY
24.9 (1993)
17,330 bbl/day (2001 est.)
5.29 million bbl/day (2001 est.)
5.449 million bbl/day (2001)
93,360 bbl/day (2001)
total: 42 years
male: 40.3 years
female: 43.8 years (2002)
29.29 million bbl (37257)
20.02 billion cu m (37257)
2.519 billion cu m (2001 est.)
80.42 billion cu m (2001 est.)
77.73 billion cu m (2001 est.)
0 cu m (2001 est.)','b7259eb618f4415263c852f6f52d78ab8697ac971b25c1c730b4834aef012ea3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb6d5ceb0cb695eff6b63753d960188c03fd40b01483b2d023c0003eb7e1325d',2003,'JE','Jersey','communications',909,'gently rolling plain with low, rugged hills along north coast
Johnston Atoll
mostly flat
1.57 children born/woman (2003 est.)
NA
0.7% (1998 est.)
defense is the responsibility of the UK
Johnston Atoll
defense is the responsibility of the US
Juan de Nova Island
defense is the responsibility of France
Kingman Reef
defense is the responsibility of the US
conventional long form: Bailiwick of Jersey
conventional short form: Jersey
Johnston Atoll
conventional long form: none
conventional short form: Johnston Atoll
Western Europe, island in the English Channel, northwest of
Europe
Johnston Atoll
Oceania
NA sq km
Johnston Atoll
0 sq km (1998 est.)
total: 116 sq km
land: 116 sq km
water: 0 sq km
Johnston Atoll
total: 2.8 sq km
land: 2.8 sq km
water: 0 sq km
none (British crown dependency)
65,500 (1997)
4,400 (1997)
NA
Johnston Atoll
1 256 KB circuit to US Department of Defense-run
Nonsecure Internet Protocol Router Network (NIPRNET) (2002)
NA
.je
NA%
NA
NA
GBP
total: 39.8 years
male: 39.1 years
female: 40.6 years (2002)','2e2bfc46bdd9c166d26bfa24f4466b154fea838f0ddc69c9a0feba67d278c210','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5635bcf2760f19a60ef00bdd6fc9766f3d3a88a79a73eab13e58a1fb4bf050d8',2003,'JO','Jordan','communications',910,'mostly desert plateau in east, highland area in west; Great
Rift Valley separates East and West Banks of the Jordan River
Juan de Nova Island
low and flat
3 children born/woman (2003 est.)
constitutional monarchy
16% official rate; actual rate is 25%-30% (2001 est.)
conventional long form: Hashemite Kingdom of Jordan
conventional short form: Jordan
local long form: Al Mamlakah al Urduniyah al Hashimiyah
local short form: Al Urdun
former: Transjordan
Juan de Nova Island
conventional long form: none
conventional short form: Juan de Nova Island
local long form: none
local short form: Ile Juan de Nova
Middle East, northwest of Saudi Arabia
Juan de Nova Island
Southern Africa, island in the Mozambique
Channel, about one-third of the way between Madagascar and Mozambique
Middle East
Juan de Nova Island
Africa
750 sq km (1998 est.)
Juan de Nova Island
0 sq km (1998 est.)
total: 92,300 sq km
land: 91,971 sq km
water: 329 sq km
Juan de Nova Island
total: 4.4 sq km
land: 4.4 sq km
water: 0 sq km
chief of mission: Ambassador Karim Tawfiq KAWAR
chancery: 3504 International Drive NW, Washington, DC 20008
telephone: [1] (202) 966-2664
FAX: [1] (202) 966-3110
Juan de Nova Island
none (possession of France)
403,000 (1997)
11,500 (1995)
5 (2000)
212,000 (2002)
.jo
less than 0.1% (2001 est.)
less than 1,000
NA
JOD
36.4 (1997)
40 bbl/day NA bbl/day (2001 est.)
103,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 21.8 years
male: 22.4 years
female: 21.1 years (2002)
445,000 bbl (37257)
3.256 billion cu m (37257)
290 million cu m (2001 est.)
290 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','0ae5288dcdf41dc7894f88fc3934967c57eb9f87b7d379142863c816e73b9d39','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2c2e7725a582f044805fca587fe8eb2c7c95028183745fa21e61fd97f0b5b69',2003,'KZ','Kazakhstan','communications',911,'extends from the Volga to the Altai Mountains and from
the plains in western Siberia to oases and desert in Central Asia
2.16 children born/woman (2003 est.)
republic
8.8% (2002 est.)
conventional long form: Republic of Kazakhstan
conventional short form: Kazakhstan
local long form: Qazaqstan Respublikasy
local short form: none
former: Kazakh Soviet Socialist Republic
Central Asia, northwest of China; a small portion west of
the Ural River in eastern-most Europe
Asia
23,320 sq km (1998 est.)
total: 2,717,300 sq km
land: 2,669,800 sq km
water: 47,500 sq km
chief of mission: Ambassador Kanat B. SAUDABAYEV
chancery: 1401 16th Street NW, Washington, DC 20036
telephone: [1] (202) 232-5488
FAX: [1] (202) 232-5845
consulate(s): New York
1.92 million (2001)
400,000 (2001)
10 (with their own international channels) (2001)
100,000 (2002)
.kz
0.1% (2001 est.)
6,000 (2001 est.)
less than 300 (2001 est.)
KZT
35.4 (1996)
798,200 bbl/day (2001 est.)
195,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 28.2 years
male: 26.6 years
female: 29.7 years (2002)
2.709 billion bbl (37257)
920.3 billion cu m (37257)
10.08 billion cu m (2001 est.)
Korea, South
0 cu m (2001 est.)
14.3 billion cu m (2001 est.)
Korea, South
20.92 billion cu m (2001 est.)
8.3 billion cu m (2001 est.)
Korea, South
21.11 billion cu m (2001 est.)
4.1 billion cu m (2001 est.)
Korea, South
0 cu m (2001 est.)','34a05e698230736fbc986eebbf7408af7b0799f25112a38043484cca9042607b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdc440be705828f1d740365427a529d38ca155aa72c6981d53b22c84a0ccb8ba',2003,'KE','Kenya','communications',912,'low plains rise to central highlands bisected by Great Rift
Valley; fertile plateau in west
Kingman Reef
low and nearly level
3.47 children born/woman (2003 est.)
republic
40% (2001 est.)
conventional long form: Republic of Kenya
conventional short form: Kenya
former: British East Africa
Kingman Reef
conventional long form: none
conventional short form: Kingman Reef
Eastern Africa, bordering the Indian Ocean, between Somalia
and Tanzania
Kingman Reef
Oceania, reef in the North Pacific Ocean, about half
way between Hawaii and American Samoa
Africa
Kingman Reef
Oceania
670 sq km (1998 est.)
Kingman Reef
0 sq km (1998 est.)
total: 582,650 sq km
land: 569,250 sq km
water: 13,400 sq km
Kingman Reef
total: 1 sq km
land: 1 sq km
water: 0 sq km
chief of mission: Ambassador Yusuf Abdulraham NZIBO
chancery: 2249 R Street NW, Washington, DC 20008
telephone: [1] (202) 387-6101
FAX: [1] (202) 462-3829
consulate(s) general: offices in Los Angeles and New York are
closed; mission to the UN remains open
310,000 (2001)
540,000 (2001)
65 (2001)
500,000 (2002)
.ke
15% (2001 est.)
2.5 million (2001 est.)
190,000 (2001 est.)
KES
44.9 (1997)
Korea, South
31.6 (1993)
0 bbl/day (2001 est.)
57,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.4 years
male: 18.2 years
female: 18.5 years (2002)','82b4d29836ad1cd41c2af542046950a92991cd31549ae6b5daebfe7cd95af86d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69411257e00766a9638153cfe60f6d119ddbe11e49ba465d780dac00bd8fd2dd',2003,'KI','Kiribati','communications',913,'mostly low-lying coral atolls surrounded by extensive reefs
Korea, North
mostly hills and mountains separated by deep, narrow
valleys; coastal plains wide in west, discontinuous in east
Korea, South
mostly hills and mountains; wide coastal plains in west
and south
4.28 children born/woman (2003 est.)
Korea, North
2.25 children born/woman (2003 est.)
Korea, South
1.56 children born/woman (2003 est.)
republic
Korea, North
authoritarian socialist; one-man dictatorship
Korea, South
republic
2%; underemployment 70% (1992 est.)
Korea, North
NA%
Korea, South
3.1% (2002 est.)
Kiribati does not have military forces; defense assistance
is provided by Australia and NZ
conventional long form: Republic of Kiribati
conventional short form: Kiribati
note: pronounced keer-ree-bahss
former: Gilbert Islands
Korea, North
conventional long form: Democratic People''s Republic of
Korea
conventional short form: North Korea
local long form: Choson-minjujuui-inmin-konghwaguk
local short form: none
note: the North Koreans generally use the term "Choson" to refer to
their country
abbreviation: DPRK
Korea, South
conventional long form: Republic of Korea
conventional short form: South Korea
local long form: Taehan-min''guk
local short form: none
note: the South Koreans generally use the term "Han''guk" to refer to
their country
abbreviation: ROK
Oceania, group of 33 coral atolls in the Pacific Ocean,
straddling the equator; the capital Tarawa is about one-half of the
way from Hawaii to Australia; note - on 1 January 1995, Kiribati
proclaimed that all of its territory lies in the same time zone as
its Gilbert Islands group (GMT +12) even though the Phoenix Islands
and the Line Islands under its jurisdiction lie on the other side of
the International Date Line
Korea, North
Eastern Asia, northern half of the Korean Peninsula
bordering the Korea Bay and the Sea of Japan, between China and
South Korea
Korea, South
Eastern Asia, southern half of the Korean Peninsula
bordering the Sea of Japan and the Yellow Sea
Oceania
Korea, North
Asia
Korea, South
Asia
NA sq km
Korea, North
14,600 sq km (1998 est.)
Korea, South
11,590 sq km (1998 est.)
total: 811 sq km
land: 811 sq km
water: 0 sq km
note: includes three island groups - Gilbert Islands, Line Islands,
Phoenix Islands
Korea, North
total: 120,540 sq km
land: 120,410 sq km
water: 130 sq km
Korea, South
total: 98,480 sq km
land: 98,190 sq km
water: 290 sq km
Kiribati does not have an embassy in the US; there is an
honorary consulate in Honolulu
Korea, North
none; note - North Korea has a Permanent Mission to the
UN in New York
Korea, South
chief of mission: Ambassador HAN Sung-chu (HAN Sung-joo)
chancery: 2450 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 939-5600
FAX: [1] (202) 387-0205
consulate(s) general: Atlanta, Boston, Chicago, Honolulu, Houston,
Los Angeles, New York, San Francisco, and Seattle
consulate(s): New York, Tamuning (Guam)
3,800 (1999)
Korea, North
1.1 million (1997)
Korea, South
24 million (2000)
NA
Korea, North
NA
Korea, South
28 million (September 2000)
1 (2000)
Korea, North
1 (2000)
Korea, South
11 (2000)
1,000 (2000)
Korea, North
NA
Korea, South
25.6 million (2002)
.ki
Korea, North
.kp
Korea, South
.kr
NA%
Korea, North
NA
Korea, South
less than 0.1% (2001 est.)
NA
Korea, North
NA
Korea, South
4,000 (2001 est.)
NA
Korea, North
NA
Korea, South
220 (2001 est.)
AUD
Korea, North
KPW
Korea, South
KRW
0 bbl/day (2001 est.)
Korea, North
0 bbl/day (2001 est.)
Korea, South
0 bbl/day (2001 est.)
190 bbl/day (2001 est.)
Korea, North
85,000 bbl/day (2001 est.)
Korea, South
2.14 million bbl/day (2001 est.)
NA (2001)
Korea, North
NA (2001)
Korea, South
2.965 million bbl/day (2001)
NA (2001)
Korea, North
NA (2001)
Korea, South
804,700 bbl/day (2001)
total: 19.7 years
male: 19.3 years
female: 20.2 years (2002)
Korea, North
total: 31.1 years
male: 30 years
female: 32.3 years (2002)
Korea, South
total: 33.2 years
male: 32.2 years
female: 34.2 years (2002)','1f7c7eeeb6f45ef3cebb5b08cf48c908c6d7a42005841b9236c2b3a059512ec3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f002dcf3079c59eca200dac4a30d38c86909cbe3d742e55101b962f5de9bc580',2003,'KW','Kuwait','communications',914,'flat to slightly undulating desert plain
3.08 children born/woman (2003 est.)
nominal constitutional monarchy
7% (2002 est.)
conventional long form: State of Kuwait
conventional short form: Kuwait
local long form: Dawlat al Kuwayt
local short form: Al Kuwayt
Middle East, bordering the Persian Gulf, between Iraq and
Middle East
60 sq km (1998 est.)
total: 17,820 sq km
land: 17,820 sq km
water: 0 sq km
chief of mission: Ambassador Sheikh SALIM al-Abdallah Jabir
Al Sabah
chancery: 2940 Tilden Street NW, Washington, DC 20008
telephone: [1] (202) 966-0702
FAX: [1] (202) 966-0517
412,000 (1997)
210,000 (1997)
3 (2000)
200,000 (2002)
.kw
0.12% (2001 est.)
NA
NA
KWD
2.117 million bbl/day (2001 est.)
273,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 25.9 years
male: 28.4 years
female: 21.8 years (2002)
97.68 billion bbl (37257)
1.548 trillion cu m (37257)
9.5 billion cu m (2001 est.)
9.5 billion cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','b49eeb229b68c6264305015f3068b36199837ef72bfd2567d76005c574622f16','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2daa641ebf5cb583c3bfa890723f3a0da706f023fbb38a7fca7f923dc339c3c',2003,'KG','Kyrgyzstan','communications',915,'peaks of Tien Shan and associated valleys and basins
encompass entire nation
Laos
mostly rugged mountains; some plains and plateaus
3.12 children born/woman (2003 est.)
Laos
4.94 children born/woman (2003 est.)
republic
Laos
Communist state
7.2% (1999 est.)
Laos
5.7% (1997 est.)
conventional long form: Kyrgyz Republic
conventional short form: Kyrgyzstan
local long form: Kyrgyz Respublikasy
local short form: none
former: Kirghiz Soviet Socialist Republic
Laos
conventional long form: Lao People''s Democratic Republic
conventional short form: Laos
local long form: Sathalanalat Paxathipatai Paxaxon Lao
local short form: none
Central Asia, west of China
Laos
Southeastern Asia, northeast of Thailand, west of Vietnam
Asia
Laos
Southeast Asia
10,740 sq km (1998 est.)
Laos
1,640 sq km
note: rainy season irrigation - 2,169 sq km; dry season irrigation -
750 sq km (1998 est.)
total: 198,500 sq km
land: 191,300 sq km
water: 7,200 sq km
Laos
total: 236,800 sq km
land: 230,800 sq km
water: 6,000 sq km
chief of mission: Ambassador Bakyt ABDRISAYEV
chancery: 1732 Wisconsin Avenue NW, Washington, DC 20007
telephone: [1] (202) 338-5141
FAX: [1] (202) 338-5139
consulate(s): New York
Laos
chief of mission: Ambassador PHANTHONG Phommahaxay
chancery: 2222 S Street NW, Washington, DC 20008
telephone: [1] (202) 332-6416
FAX: [1] (202) 332-4923
351,000 (1997)
Laos
25,000 (1997)
NA
Laos
4,915 (1997)
NA
Laos
1 (2000)
51,600 (2001)
Laos
10,000 (2002)
.kg
Laos
.la
less than 0.1% (2001 est.)
Laos
less than 0.1% (2001 est.)
over 500 (2001 est.)
Laos
1,400 (2001 est.)
less than 100 (2001 est.)
Laos
less than 150 (2001 est.)
KGS
Laos
LAK
34.6 (1999)
Laos
37 (1997)
2,000 bbl/day (2001 est.)
Laos
0 bbl/day (2001 est.)
20,000 bbl/day (2001 est.)
Laos
2,750 bbl/day (2001 est.)
NA (2001)
Laos
NA (2001)
NA (2001)
Laos
NA (2001)
total: 22.7 years
male: 21.8 years
female: 23.6 years (2002)
Laos
total: 18.5 years
male: 18.1 years
female: 18.9 years (2002)
16 million cu m (2001 est.)
2.016 billion cu m (2001 est.)
2 billion cu m (2001 est.)
0 cu m (2001 est.)','0759337046106e58a63edae3f27e306f2698c8bee4c196c71a0450e86fff5d72','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0699e041d9a3862d53553db973e93524c378b1f1cae2a78bb8b1f22330022ae',2003,'LV','Latvia','communications',916,'low plain
1.2 children born/woman (2003 est.)
parliamentary democracy
7.6% (2001 est.)
conventional long form: Republic of Latvia
conventional short form: Latvia
local long form: Latvijas Republika
local short form: Latvija
former: Latvian Soviet Socialist Republic
Eastern Europe, bordering the Baltic Sea, between Estonia and
Europe
200 sq km
note: land in Latvia is often too wet, and in need of drainage, not
irrigation; approximately 16,000 sq km or 85% of agricultural land
has been improved by drainage (1998 est.)
total: 64,589 sq km
land: 63,589 sq km
water: 1,000 sq km
chief of mission: Ambassador Aivis RONIS
chancery: 4325 17th Street NW, Washington, DC 20011
telephone: [1] (202) 726-8213, 8214
FAX: [1] (202) 726-6785
734,693 (2000)
401,263 (2000)
41 (2001)
312,000 (2001)
.lv
0.4% (2001 est.)
5,000 (2001 est.)
less than 100 (2001 est.)
LVL
32 (1999)
0 bbl/day (2001 est.)
44,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 39 years
male: 35.5 years
female: 42.1 years (2002)
0 cu m (2001 est.)
1.7 billion cu m (2001 est.)
1.7 billion cu m (2001 est.)
0 cu m (2001 est.)','fd727339ddbe5259761d107237c685b65251474bdbe7c76873f28becad1d9c43','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c769ac1f71452abaae124110461905e4e9e6f2b16abbe2fc59f2950cae1a745',2003,'LB','Lebanon','communications',917,'narrow coastal plain; El Beqaa (Bekaa Valley) separates
Lebanon and Anti-Lebanon Mountains
1.98 children born/woman (2003 est.)
republic
18% (1997 est.)
conventional long form: Lebanese Republic
conventional short form: Lebanon
local long form: Al Jumhuriyah al Lubnaniyah
local short form: Lubnan
Middle East, bordering the Mediterranean Sea, between Israel
and Syria
Middle East
1,200 sq km (1998 est.)
total: 10,400 sq km
land: 10,230 sq km
water: 170 sq km
chief of mission: Ambassador Dr. Farid ABBOUD
chancery: 2560 28th Street NW, Washington, DC 20008
telephone: [1] (202) 939-6320
FAX: [1] (202) 939-6324
consulate(s) general: Detroit, New York, and Los Angeles
700,000 (1999)
580,000 (1999)
22 (2000)
300,000 (2001)
.lb
0.09% (2001 est.)
NA
NA
LBP
0 bbl/day (2001 est.)
107,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 26.4 years
male: 25.4 years
female: 27.5 years (2002)','dc13d47188e4883e44b069f944d93d63daa34128f94ff721b6666cdc2c688183','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54051dc31ec2e32c49f74ca52b47c64f8819e00b1c62da49253d59e055048dad',2003,'LS','Lesotho','communications',918,'mostly highland with plateaus, hills, and mountains
3.52 children born/woman (2003 est.)
parliamentary constitutional monarchy
45% (2002)
the Lesotho Government in 1999 began an open debate on the
future structure, size, and role of the armed forces, especially
considering the Lesotho Defense Force''s (LDF) history of intervening
in political affairs
conventional long form: Kingdom of Lesotho
conventional short form: Lesotho
former: Basutoland
Southern Africa, an enclave of South Africa
Africa
10 sq km (1998 est.)
total: 30,355 sq km
land: 30,355 sq km
water: 0 sq km
chief of mission: Ambassador Molelekeng E. RAPOLAKI
chancery: 2511 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 797-5533 through 5536
FAX: [1] (202) 234-6815
22,200 (2000)
21,600 (2000)
1 (2000)
5,000 (2002)
.ls
31% (2001 est.)
360,000 (2001 est.)
25,000 (2001 est.)
LSL; ZAR
56 (1986-87)
0 bbl/day (2001 est.)
1,500 bbl/day (2001)
NA (2001)
NA (2001)
total: 19.8 years
male: 19.3 years
female: 20.4 years (2002)
Convention on the Prevention of Marine Pollution by Dumping Wastes and
Other Matter (London Convention)
note - abbreviated as Marine Dumping
opened for signature - 29 December 1972
entered into force - 30 August 1975
objective - to control pollution of the sea by dumping and to encourage
regional agreements supplementary to the Convention
parties - (78) Afghanistan, Antigua and Barbuda, Argentina, Australia,
Azerbaijan, Barbados, Belarus, Belgium, Brazil, Canada, Cape Verde,
Chile, China, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Denmark, Dominican Republic, Egypt,
Finland, France, Gabon, Germany, Greece, Guatemala, Haiti, Honduras,
Hong Kong (associate member), Hungary, Iceland, Iran, Ireland, Italy,
Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Libya,
Luxembourg, Malta, Mexico, Monaco, Morocco, Nauru, Netherlands, NZ,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Philippines,
Poland, Portugal, Russia, Saint Lucia, Serbia and Montenegro,
Seychelles, Slovenia, Solomon Islands, South Africa, Spain, Suriname,
Sweden, Switzerland, Tonga, Tunisia, Ukraine, UAE, UK, US, Vanuatu
Convention on the Prohibition of Military or Any Other Hostile Use of
Environmental Modification Techniques
note - abbreviated as Environmental Modification
opened for signature - 10 December 1976
entered into force - 5 October 1978
objective - to prohibit the military or other hostile use of
environmental modification techniques in order to further world peace
and trust among nations
parties - (66) Afghanistan, Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, Bangladesh, Belarus, Belgium, Benin, Brazil,
Bulgaria, Canada, Cape Verde, Chile, Costa Rica, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Egypt, Finland, Germany, Ghana, Greece,
Guatemala, Hungary, India, Ireland, Italy, Japan, North Korea, South
Korea, Kuwait, Laos, Malawi, Mauritius, Mongolia, Netherlands, NZ,
Niger, Norway, Pakistan, Papua New Guinea, Poland, Romania, Russia,
Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe,
Slovakia, Solomon Islands, Spain, Sri Lanka, Sweden, Switzerland,
Tajikistan, Tunisia, Ukraine, UK, US, Uruguay, Uzbekistan, Vietnam,','568ed04f01d21a59e656b8f73605811744a5acbffb854886dc8d3a3a016c5a13','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f837b3044e2e29fd6db4d47c939cbd0b827eeab071a2bf9dea2f2b50fce33e1a',2003,'LR','Liberia','communications',919,'mostly flat to rolling coastal plains rising to rolling
plateau and low mountains in northeast
6.23 children born/woman (2003 est.)
republic
NA
conventional long form: Republic of Liberia
conventional short form: Liberia
Western Africa, bordering the North Atlantic Ocean, between
Cote d''Ivoire and Sierra Leone
Africa
30 sq km (1998 est.)
total: 111,370 sq km
land: 96,320 sq km
water: 15,050 sq km
chief of mission: Ambassador (vacant); Charge D''Affaires
Aaron B. KOLLIE
chancery: 5201 16th Street NW, Washington, DC 20011
telephone: [1] (202) 723-0437
FAX: [1] (202) 723-0436
consulate(s) general: New York
6,700 (2000)
0 (1998)
2 (2001)
500 (2000)
.lr
9% (2001 est.)
125,000 (2001 est.)
5,000 (2001 est.)
LRD
0 bbl/day (2001 est.)
3,100 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.1 years
male: 17.7 years
female: 18.4 years (2002)
Wetlands
see Convention on Wetlands of International Importance Especially As
Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling
This page was last updated on 1 August, 2003
=====================================================================
Appendix D - Cross-Reference List of Country Data Codes
FIPS 10-4: Countries, Dependencies, Areas of Special Sovereignty, and
Their Principal Administrative Divisions (FIPS PUB 10-4) is maintained
by the Office of the Geographer and Global Issues (Department of State)
and published by the National Institute of Standards and Technology
(Department of Commerce). FIPS 10-4 codes are intended for general use
throughout the US Government, especially in activities associated with
the mission of the Department of State and national defense programs.
ISO 3166:Codes for the Representation of Names of Countries (ISO 3166)
is prepared by the International Organization for Standardization. ISO
3166 includes two- and three-character alphabetic codes and three-digit
numeric codes that may be needed for activities involving exchange of
data with international organizations that have adopted that standard.
Except for the numeric codes, ISO 3166 codes have been adopted in the
US as FIPS 104-1: American National Standard Codes for the
Representation of Names of Countries, Dependencies, and Areas of
Special Sovereignty for Information Interchange.
Internet: The Internet country code is the two-letter digraph
maintained by the International Organization for Standardization (ISO)
in the ISO 3166 Alpha-2 list and used by the Internet Assigned Numbers
Authority (IANA) to establish country-coded top-level domains (ccTLDs).
Appendix D - Cross-Reference List of Country Data Codes
Entity FIPS 10-4 --- ISO 3166 -- Internet Comment
Afghanistan AF AF AFG 004 .af
Albania AL AL ALB 008 .al
Algeria AG DZ DZA 012 .dz
American Samoa AQ AS ASM 016 .as
Andorra AN AD AND 020 .ad
Angola AO AO AGO 024 .ao
Anguilla AV AI AIA 660 .ai
Antarctica AY AQ ATA 010 .aq
ISO defines as the territory south of 60 degrees south latitude
Antigua and Barbuda AC AG ATG 028 .ag
Argentina AR AR ARG 032 .ar
Armenia AM AM ARM 051 .am
Aruba AA AW ABW 533 .aw
Ashmore and
Cartier Islands AT - - - -
ISO includes with Australia
Australia AS AU AUS 036 .au
ISO includes Ashmore and Cartier Islands, Coral Sea Islands
Austria AU AT AUT 040 .at
Azerbaijan AJ AZ AZE 031 .az
Bahamas, The BF BS BHS 044 .bs
Bahrain BA BH BHR 048 .bh
Baker Island FQ - - - -
ISO includes with the US Minor Outlying Islands
Bangladesh BG BD BGD 050 .bd
Barbados BB BB BRB 052 .bb
Bassas da India BS - - - -
ISO includes with the Miscellaneous (French) Indian Ocean Islands
Belarus BO BY BLR 112 .by
Belgium BE BE BEL 056 .be
Belize BH BZ BLZ 084 .bz
Benin BN BJ BEN 204 .bj
Bermuda BD BM BMU 060 .bm
Bhutan BT BT BTN 064 .bt
Bolivia BL BO BOL 068 .bo
Bosnia and
Herzegovina BK BA BIH 070 .ba
Botswana BC BW BWA 072 .bw
Bouvet Island BV BV BVT 074 .bv
Brazil BR BR BRA 076 .br
British Indian
Ocean Territory IO IO IOT 086 .io
British Virgin
Islands VI VG VGB 092 .vg
Brunei BX BN BRN 096 .bn
Bulgaria BU BG BGR 100 .bg
Burkina Faso UV BF BFA 854 .bf
Burma BM MM MMR 104 .mm
ISO uses the name Myanmar
Burundi BY BI BDI 108 .bi
Cambodia CB KH KHM 116 .kh
Cameroon CM CM CMR 120 .cm
Canada CA CA CAN 124 .ca
Cape Verde CV CV CPV 132 .cv
Cayman Islands CJ KY CYM 136 .ky
Central African
Republic CT CF CAF 140 .cf
Chad CD TD TCD 148 .td
Chile CI CL CHL 152 .cl
China CH CN CHN 156 .cn
see also Taiwan
Christmas Island KT CX CXR 162 .cx
Clipperton Island IP - - - -
ISO includes with French Polynesia
Cocos (Keeling)
Islands CK CC CCK 166 .cc
Colombia CO CO COL 170 .co
Comoros CN KM COM 174 .km
Congo, Democratic
Republic of the CG ZR ZAR 180 .cd
formerly Zaire
Congo,
Republic of the CF CG COG 178 .cg
Cook Islands CW CK COK 184 .ck
Coral Sea Islands CR - - - -
ISO includes with Australia
Costa Rica CS CR CRI 188 .cr
Cote d''Ivoire IV CI CIV 384 .ci
Croatia HR HR HRV 191 .hr
Cuba CU CU CUB 192 .cu
Cyprus CY CY CYP 196 .cy
Czech Republic EZ CZ CZE 203 .cz
Denmark DA DK DNK 208 .dk
Djibouti DJ DJ DJI 262 .dj
Dominica DO DM DMA 212 .dm
Dominican Republic DR DO DOM 214 .do
East Timor TT TP TLS 626 .tp
Ecuador EC EC ECU 218 .ec
Egypt EG EG EGY 818 .eg
El Salvador ES SV SLV 222 .sv
Equatorial Guinea EK GQ GNQ 226 .gq
Eritrea ER ER ERI 232 .er
Estonia EN EE EST 233 .ee
Ethiopia ET ET ETH 231 .et
Europa Island EU - - - -
ISO includes with the Miscellaneous (French) Indian Ocean Islands
Falkland Islands
(Islas Malvinas) FA FK FLK 238 .fk
Faroe Islands FO FO FRO 234 .fo
Fiji FJ FJ FJI 242 .fj
Finland FI FI FIN 246 .fi
France FR FR FRA 250 .fr
France,
Metropolitan - FX FXX 249 .fx
ISO limits to the European part of France, excluding French
Guiana, French Polynesia, French Southern and Antarctic Lands,
Guadeloupe, Martinique, Mayotte, New Caledonia, Reunion, Saint
Pierre and Miquelon, Wallis and Futuna
French Guiana FG GF GUF 254 .gf
French Polynesia FP PF PYF 258 .pf
ISO includes Clipperton Island
French Southern
and Antarctic
Lands FS TF ATF 260 .tf
FIPS 10-4 does not include the French-claimed portion of
Antarctica (Terre Adelie)
Gabon GB GA GAB 266 .ga
Gambia, The GA GM GMB 270 .gm
Gaza Strip GZ - - - -
Georgia GG GE GEO 268 .ge
Germany GM DE DEU 276 .de
Ghana GH GH GHA 288 .gh
Gibraltar GI GI GIB 292 .gi
Glorioso Islands GO - - - -
ISO includes with the Miscellaneous (French) Indian Ocean Islands
Greece GR GR GRC 300 .gr
Greenland GL GL GRL 304 .gl
Grenada GJ GD GRD 308 .gd
Guadeloupe GP GP GLP 312 .gp
Guam GQ GU GUM 316 .gu
Guatemala GT GT GTM 320 .gt
Guernsey GK - - - .gg
ISO includes with the UK
Guinea GV GN GIN 324 .gn
Guinea-Bissau PU GW GNB 624 .gw
Guyana GY GY GUY 328 .gy
Haiti HA HT HTI 332 .ht
Heard Island and
McDonald Islands HM HM HMD 334 .hm
Holy See
(Vatican City) VT VA VAT 336 .va
Honduras HO HN HND 340 .hn
Hong Kong HK HK HKG 344 .hk
Howland Island HQ - - - -
ISO includes with the US Minor Outlying Islands
Hungary HU HU HUN 348 .hu
Iceland IC IS ISL 352 .is
India IN IN IND 356 .in
Indonesia ID ID IDN 360 .id
Iran IR IR IRN 364 .ir
Iraq IZ IQ IRQ 368 .iq
Ireland EI IE IRL 372 .ie
Israel IS IL ISR 376 .il
Italy IT IT ITA 380 .it
Jamaica JM JM JAM 388 .jm
Jan Mayen JN - - - -
ISO includes with Svalbard
Japan JA JP JPN 392 .jp
Jarvis Island DQ - - - -
ISO includes with the US Minor Outlying Islands
Jersey JE - - - .je
ISO includes with the UK
Johnston Atoll JQ - - - -
ISO includes with the US Minor Outlying Islands
Jordan JO JO JOR 400 .jo
Juan de Nova Island JU - - - -
ISO includes with the Miscellaneous (French) Indian Ocean Islands
Kazakhstan KZ KZ KAZ 398 .kz
Kenya KE KE KEN 404 .ke
Kingman Reef KQ - - - -
ISO includes with the US Minor Outlying Islands
Kiribati KR KI KIR 296 .ki
Korea, North KN KP PRK 408 .kp
Korea, South KS KR KOR 410 .kr
Kuwait KU KW KWT 414 .kw
Kyrgyzstan KG KG KGZ 417 .kg
Laos LA LA LAO 418 .la
Latvia LG LV LVA 428 .lv
Lebanon LE LB LBN 422 .lb
Lesotho LT LS LSO 426 .ls
Liberia LI LR LBR 430 .lr
Libya LY LY LBY 434 .ly
Liechtenstein LS LI LIE 438 .li
Lithuania LH LT LTU 440 .lt
Luxembourg LU LU LUX 442 .lu
Macau MC MO MAC 446 .mo
Macedonia, The
Republic of MK MK MKD 807 .mk
Madagascar MA MG MDG 450 .mg
Malawi MI MW MWI 454 .mw
Malaysia MY MY MYS 458 .my
Maldives MV MV MDV 462 .mv
Mali ML ML MLI 466 .ml
Malta MT MT MLT 470 .mt
Man, Isle of IM - - - .im
ISO includes with the UK
Marshall Islands RM MH MHL 584 .mh
Martinique MB MQ MTQ 474 .mq
Mauritania MR MR MRT 478 .mr
Mauritius MP MU MUS 480 .mu
Mayotte MF YT MYT 175 .yt
Mexico MX MX MEX 484 .mx
Micronesia,
Federated
States of FM FM FSM 583 .fm
Midway Islands MQ - - - -
ISO includes with the US Minor Outlying Islands
Miscellaneous
(French) Indian
Ocean Islands - - - - -
ISO includes Bassas da India, Europa Island, Glorioso Islands,
Juan de Nova Island, Tromelin Island
Moldova MD MD MDA 498 .md
Monaco MN MC MCO 492 .mc
Mongolia MG MN MNG 496 .mn
Montserrat MH MS MSR 500 .ms
Morocco MO MA MAR 504 .ma
Mozambique MZ MZ MOZ 508 .mz
Myanmar - - - - -
see Burma
Namibia WA NA NAM 516 .na
Nauru NR NR NRU 520 .nr
Navassa Island BQ - - - -
Nepal NP NP NPL 524 .np
Netherlands NL NL NLD 528 .nl','73fe59550fb20e40873120260fef301c417e197059dc5023b4050d9e5023d447','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72d97ed0cd7a977f0c707ad5b2abb70400c9aeb519c31ade4ad2043555dc201e',2003,'LY','Libya','communications',920,'mostly barren, flat to undulating plains, plateaus, depressions
3.49 children born/woman (2003 est.)
Jamahiriya (a state of the masses) in theory, governed by the
populace through local councils; in fact, a military dictatorship
30% (2001)
conventional long form: Great Socialist People''s Libyan Arab
Jamahiriya
conventional short form: Libya
local long form: Al Jumahiriyah al Arabiyah al Libiyah ash Shabiyah
al Ishtirakiyah al Uzma
local short form: none
Northern Africa, bordering the Mediterranean Sea, between
Egypt and Tunisia
Africa
4,700 sq km (1998 est.)
total: 1,759,540 sq km
land: 1,759,540 sq km
water: 0 sq km
Libya does not have an embassy in the US
500,000 (1998)
20,000 (1998)
1 (2002)
20,000 (2001)
.ly
0.2% (2001 est.)
7,000 (2001 est.)
NA
LYD
1.429 million bbl/day (2001 est.)
216,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 22.1 years
male: 22.2 years
female: 21.9 years (2002)
29.75 billion bbl (37257)
1.321 trillion cu m (37257)
6.18 billion cu m (2001 est.)
5.41 billion cu m (2001 est.)
0 cu m (2001 est.)
770 million cu m (2001 est.)','6d6116507f619ce9809b6f89231346b29c20b839ce93a497665f6ec0ed7fd6bd','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6ab7fa7f87722c13cc9263925b5ebcccc64a77b80971b041ca2052b83f3c86b',2003,'LI','Liechtenstein','communications',921,'mostly mountainous (Alps) with Rhine Valley in western
third
1.5 children born/woman (2003 est.)
hereditary constitutional monarchy on a democratic and
parliamentary basis
1.3% (37500)
defense is the responsibility of Switzerland
Man, Isle of
defense is the responsibility of the UK
conventional long form: Principality of Liechtenstein
conventional short form: Liechtenstein
local long form: Fuerstentum Liechtenstein
local short form: Liechtenstein
Central Europe, between Austria and Switzerland
Europe
NA sq km
total: 160 sq km
land: 160 sq km
water: 0 sq km
chief of mission: Ambassador Claudia FRITSCHE
chancery: 1300 Eye Street NW, Suite 550W, Washington, DC 20005
telephone: [1] (202) 216-0460
FAX: [1] (202) 216-0459
20,072 (2000)
NA
44 (Liechtenstein and Switzerland) (2000)
NA
.li
NA%
NA
NA
CHF
total: 38.3 years
male: 37.9 years
female: 38.8 years (2002)','28294c8ad6097a5789da46f237fe2b9410e957773b742717a55f1f6932045c43','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93a6194ae0c5dd22d7f62161f752788d157c8c4e3e17c51e40164dafab4500e8',2003,'LT','Lithuania','communications',922,'lowland, many scattered small lakes, fertile soil
1.43 children born/woman (2003 est.)
parliamentary democracy
12.5% (2001 est.)
conventional long form: Republic of Lithuania
conventional short form: Lithuania
local long form: Lietuvos Respublika
local short form: Lietuva
former: Lithuanian Soviet Socialist Republic
Eastern Europe, bordering the Baltic Sea, between Latvia
and Russia
Europe
90 sq km (1998 est.)
total: 65,200 sq km
land: NA sq km
water: NA sq km
chief of mission: Ambassador Vygaudas USACKAS
chancery: 2622 16th Street NW, Washington, DC 20009
telephone: [1] (202) 234-5860
FAX: [1] (202) 328-0466
consulate(s) general: Chicago and New York
1.142 million (2001)
500,000 (2001)
32 (2001)
341,000 (2001)
.lt
0.1% (2001 est.)
less than 1,300 (2001 est.)
less than 100 (2001 est.)
LTL
34 (1999)
4,594 bbl/day (2001 est.)
72,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 36.6 years
male: 33.9 years
female: 39.2 years (2002)
0 cu m (2001 est.)
2.76 billion cu m (2001 est.)
2.76 billion cu m (2001 est.)
0 cu m (2001 est.)','7adf9e29244bc31c1e5baabb92c6cffcecab8510adae8e89b94c32b5e13f73f6','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0207511c25ed5e38b94d07995720c60d7652366b84972be38c49e31c62250d65',2003,'LU','Luxembourg','communications',923,'mostly gently rolling uplands with broad, shallow
valleys; uplands to slightly mountainous in the north; steep slope
down to Moselle flood plain in the southeast
Macau
generally flat
Macedonia, The Former Yugoslav Republic of
mountainous territory
covered with deep basins and valleys; three large lakes, each
divided by a frontier line; country bisected by the Vardar River
1.7 children born/woman (2003 est.)
Macau
1.32 children born/woman (2003 est.)
Macedonia, The Former Yugoslav Republic of
1.75 children born/woman
(2003 est.)
constitutional monarchy
Macau
limited democracy
Macedonia, The Former Yugoslav Republic of
parliamentary democracy
4.1% (2002 est.)
Macau
6.3% (2002)
Macedonia, The Former Yugoslav Republic of
37% (2002 est.)
conventional long form: Grand Duchy of Luxembourg
conventional short form: Luxembourg
local long form: Grand Duche de Luxembourg
local short form: Luxembourg
Macau
conventional long form: Macau Special Administrative Region
conventional short form: Macau
local long form: Aomen Tebie Xingzhengqu (Chinese); Regiao
Administrativa Especial de Macau (Portuguese)
local short form: Aomen (Chinese); Macau (Portuguese)
Macedonia, The Former Yugoslav Republic of
conventional long form:
The Former Yugoslav Republic of Macedonia
conventional short form: none
local long form: Republika Makedonija
local short form: Makedonija
abbreviation: F.Y.R.O.M.
Western Europe, between France and Germany
Macau
Eastern Asia, bordering the South China Sea and China
Macedonia, The Former Yugoslav Republic of
Southeastern Europe,
north of Greece
Europe
Macau
Southeast Asia
Macedonia, The Former Yugoslav Republic of
Europe
40 sq km (includes Belgium) (1998 est.)
Macau
NA sq km
Macedonia, The Former Yugoslav Republic of
550 sq km (1998 est.)
total: 2,586 sq km
land: 2,586 sq km
water: 0 sq km
Macau
total: 25.4 sq km
land: 25.4 sq km
water: 0 sq km
Macedonia, The Former Yugoslav Republic of
total: 25,333 sq km
land: 24,856 sq km
water: 477 sq km
chief of mission: Ambassador Arlette CONZEMIUS-PACCOURD
chancery: 2200 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 265-4171
FAX: [1] (202) 328-8270
consulate(s) general: New York and San Francisco
Macau
none (special administrative region of China)
Macedonia, The Former Yugoslav Republic of
chief of mission:
Ambassador Nikola DIMITROV
chancery: Suite 302, 1101 30th Street NW, Washington, DC 20007
telephone: [1] (202) 337-3063
FAX: [1] (202) 337-3093
consulate(s) general: New York
314,700 (1999)
Macau
176,902 (November 2001)
Macedonia, The Former Yugoslav Republic of
408,000 (1997)
215,741 (2000)
Macau
158,251 (November 2001)
Macedonia, The Former Yugoslav Republic of
12,362 (1997)
8 (2000)
Macau
1 (2000)
Macedonia, The Former Yugoslav Republic of
6 (2000)
100,000 (2001)
Macau
101,000 (2002)
Macedonia, The Former Yugoslav Republic of
100,000 (2001)
.lu
Macau
.mo
Macedonia, The Former Yugoslav Republic of
.mk
0.2% (2001 est.)
Macau
NA%
Macedonia, The Former Yugoslav Republic of
less than 0.1% (2001 est.)
NA
Macau
NA
Macedonia, The Former Yugoslav Republic of
less than 100 (1999 est.)
less than 100 (2001 est.)
Macau
NA
Macedonia, The Former Yugoslav Republic of
less than 100 (2001 est.)
EUR
Macau
MOP
Macedonia, The Former Yugoslav Republic of
MKD
0 bbl/day (2001 est.)
Macau
0 bbl/day (2001 est.)
Macedonia, The Former Yugoslav Republic of
0 bbl/day (2001 est.)
50,650 bbl/day (2001 est.)
Macau
11,000 bbl/day (2001 est.)
Macedonia, The Former Yugoslav Republic of
20,000 bbl/day (2001 est.)
50,700 bbl/day (2001)
Macau
NA (2001)
Macedonia, The Former Yugoslav Republic of
NA (2001)
634 bbl/day (2001)
Macau
NA (2001)
Macedonia, The Former Yugoslav Republic of
NA (2001)
total: 38.1 years
male: 37.2 years
female: 38.9 years (2002)
Macau
total: 33.1 years
male: 32.9 years
female: 33.3 years (2002)
Macedonia, The Former Yugoslav Republic of
total: 32.5 years
male: 31.4 years
female: 33.6 years (2002)
0 cu m (2001 est.)
865 million cu m (2001 est.)
867 million cu m (2001 est.)
0 cu m (2001 est.)','6f40bb889f9e26a71af069f4306fb00fa2ad251c44f4f639f8de34cbb9440c81','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f58f9ba5a06cae437bad7994664a0458ca0f814615c1bcec4d25f573c3e88016',2003,'MG','Madagascar','communications',924,'narrow coastal plain, high plateau and mountains in center
5.73 children born/woman (2003 est.)
republic
5.9% (1998)
conventional long form: Republic of Madagascar
conventional short form: Madagascar
local long form: Republique de Madagascar
local short form: Madagascar
former: Malagasy Republic
Southern Africa, island in the Indian Ocean, east of
Africa
10,900 sq km (1998 est.)
total: 587,040 sq km
land: 581,540 sq km
water: 5,500 sq km
chief of mission: Ambassador Rajaonarivony NARISOA
chancery: 2374 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 265-5525, 5526
FAX: [1] (202) 483-7603
consulate(s) general: New York
55,000 (2000)
63,100 (2000)
2 (2000)
35,000 (2002)
.mg
0.3% (2001 est.)
22,000 (2001 est.)
870 (2001 est.)
MGF
38.1 (1999)
0 bbl/day (2001 est.)
13,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 17.4 years
male: 17.2 years
female: 17.6 years (2002)
0 bbl (37257)
0 cu m (37257)','98cb25cd479566e4361b6d2176ee81ab099fe5128169af412c03d97d16566187','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99aed338795e981333aef5cdc0f5bf2f2c59f5e4040aac7c551c266105819755',2003,'MW','Malawi','communications',925,'narrow elongated plateau with rolling plains, rounded hills,
some mountains
6.1 children born/woman (2003 est.)
multiparty democracy
NA%
the executive exerts considerable influence over the
legislature
conventional long form: Republic of Malawi
conventional short form: Malawi
former: British Central African Protectorate, Nyasaland
Protectorate, Nyasaland
Southern Africa, east of Zambia
Africa
280 sq km (1998 est.)
total: 118,480 sq km
land: 94,080 sq km
water: 24,400 sq km
chief of mission: Ambassador Paul Tony Steven KANDIERO
chancery: 2408 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 797-1007
FAX: [1] (202) 265-0976
45,000 (2000)
49,000 (2000)
3 (2002)
35,000 (2002)
.mw
15% (2001 est.)
850,000 (2001 est.)
80,000 (2001 est.)
MWK
0 bbl/day (2001 est.)
5,400 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 16.4 years
male: 16.1 years
female: 16.7 years (2002)','cfacc01fc535afb7584103c60806d2c589f12752fe63d105e24d4ca156a4280c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a3806adc07b51503beb0ff0528516eedab576a49e728b15e77bd3e04add8f9c',2003,'MY','Malaysia','communications',926,'coastal plains rising to hills and mountains
3.13 children born/woman (2003 est.)
constitutional monarchy
note: Malaya (what is now Peninsular Malaysia) formed 31 August
1957; Federation of Malaysia (Malaya, Sabah, Sarawak, and Singapore)
formed 9 July 1963 (Singapore left the federation on 9 August 1965);
nominally headed by the paramount ruler and a bicameral Parliament
consisting of a nonelected upper house and an elected lower house;
Peninsular Malaysian states - hereditary rulers in all but Melaka,
George Town (Penang), Sabah, and Sarawak, where governors are
appointed by the Malaysian Government; powers of state governments
are limited by the federal constitution; under terms of the
federation, Sabah and Sarawak retain certain constitutional
prerogatives (e.g., the right to maintain their own immigration
controls); Sabah - holds 20 seats in House of Representatives, with
foreign affairs, defense, internal security, and other powers
delegated to federal government; Sarawak - holds 28 seats in House
of Representatives, with foreign affairs, defense, internal
security, and other powers delegated to federal government
3.8% (2002 est.)
conventional long form: none
conventional short form: Malaysia
former: Federation of Malaysia
Southeastern Asia, peninsula and northern one-third of the
island of Borneo, bordering Indonesia and the South China Sea, south
of Vietnam
Southeast Asia
3,650 sq km (1998 est.)
total: 329,750 sq km
land: 328,550 sq km
water: 1,200 sq km
chief of mission: Ambassador GHAZZALI bin Sheikh Abdul
Khalid
chancery: 3516 International Court NW, Washington, DC 20008
telephone: [1] (202) 572-9700
FAX: [1] (202) 572-9882
consulate(s) general: Los Angeles and New York
4.6 million (2000)
5 million (2000)
7 (2000)
5.7 million (2002)
.my
0.4% (2001 est.)
42,000 (2001 est.)
2,500 (2001 est.)
MYR
49.2 (1997)
729,200 bbl/day (2001 est.)
472,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 23.6 years
male: 23 years
female: 24.3 years (2002)
3.729 billion bbl (37257)
2.23 trillion cu m (37257)
53.66 billion cu m (2001 est.)
31.25 billion cu m (2001 est.)
0 cu m (2001 est.)
22.41 billion cu m (2001 est.)','84162ed8743839f9ec8286d45a6e514d704fd47ba7a3b49345e0135914a2edba','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44f2fd19c76bd573bd6a5bcb9683df6128faa3d7b714a2308bc40bf0b2380fcc',2003,'MV','Maldives','communications',927,'flat, with white sandy beaches
5.26 children born/woman (2003 est.)
republic
NEGL%
conventional long form: Republic of Maldives
conventional short form: Maldives
local long form: Dhivehi Raajjeyge Jumhooriyyaa
local short form: Dhivehi Raajje
Southern Asia, group of atolls in the Indian Ocean,
south-southwest of India
Asia
NA sq km
total: 300 sq km
land: 300 sq km
water: 0 sq km
Maldives does not have an embassy in the US, but does have
a Permanent Mission to the UN in New York; permanent representative
is Dr. Mohamed LATHEEF
21,000 (1999)
1,290 (1997)
1 (2000)
6,000 (2001)
.mv
0.1% (2001 est.)
less than 100 (2001 est.)
NA
MVR
0 bbl/day (2001 est.)
3,200 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 17.3 years
male: 17.2 years
female: 17.4 years (2002)','dce271251389c2b95f17f9e2c0393de60c9bc3f509879e9dd690bbcbf10d93d8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef56e9dee6e24905e74e1d4faf0d6c0b3ada3215a34a341661a206e79f2f65b1',2003,'ML','Mali','communications',928,'mostly flat to rolling northern plains covered by sand; savanna
in south, rugged hills in northeast
6.66 children born/woman (2003 est.)
republic
14.6% urban areas; 5.3% rural areas (2001 est.)
conventional long form: Republic of Mali
conventional short form: Mali
local long form: Republique de Mali
local short form: Mali
former: French Sudan and Sudanese Republic
Western Africa, southwest of Algeria
Africa
1,380 sq km (1998 est.)
total: 1.24 million sq km
land: 1.22 million sq km
water: 20,000 sq km
chief of mission: Ambassador Abdoulaye DIOP
chancery: 2130 R Street NW, Washington, DC 20008
telephone: [1] (202) 332-2249, 939-8950
FAX: [1] (202) 332-6603
45,000 (2000)
40,000 (2001)
13 (2001)
30,000 (2002)
.ml
1.7% (2001 est.)
110,000 (2001 est.)
11,000 (2001 est.)
XOF
50.5 (1994)
0 bbl/day (2001 est.)
4,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 16.3 years
male: 15.7 years
female: 16.9 years (2002)','ae8ca05174f9355461723ae142ca4da949108f0fbc43fdb47aa2e2dfc4bac21d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22a54e9836c2de2eec88da8b8b8bec868b8b9ed86ecf2758faa7c11779f123ea',2003,'MT','Malta','communications',929,'mostly low, rocky, flat to dissected plains; many coastal
cliffs
Man, Isle of
hills in north and south bisected by central valley
1.91 children born/woman (2003 est.)
Man, Isle of
1.65 children born/woman (2003 est.)
republic
Man, Isle of
parliamentary democracy
7% (2002 est.)
Man, Isle of
0.7% (March 2003)
conventional long form: Republic of Malta
conventional short form: Malta
local long form: Repubblika ta'' Malta
local short form: Malta
Man, Isle of
conventional long form: none
conventional short form: Isle of Man
Southern Europe, islands in the Mediterranean Sea, south of
Sicily (Italy)
Man, Isle of
Western Europe, island in the Irish Sea, between Great
Britain and Ireland
Europe
Man, Isle of
Europe
20 sq km (1998 est.)
Man, Isle of
0 sq km (1998 est.)
total: 316 sq km
land: 316 sq km
water: 0 sq km
Man, Isle of
total: 572 sq km
land: 572 sq km
water: 0 sq km
chief of mission: Ambassador John LOWELL
chancery: 2017 Connecticut Avenue NW, Washington, DC 20008
telephone: [1] (202) 462-3611, 3612
FAX: [1] (202) 387-5470
consulate(s): New York
Man, Isle of
none (British crown dependency)
187,000 (1997)
Man, Isle of
51,000 (1999)
17,691 (1997)
Man, Isle of
NA
6 (2002)
Man, Isle of
NA
59,000 (2002)
Man, Isle of
NA
.mt
Man, Isle of
.im
0.1% (2001 est.)
Man, Isle of
NA%
NA
Man, Isle of
NA
less than 100 (2001 est.)
Man, Isle of
NA
MTL
Man, Isle of
GBP
0 bbl/day (2001 est.)
20,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 37.2 years
male: 35.6 years
female: 38.8 years (2002)
Man, Isle of
total: 39.1 years
male: 37.8 years
female: 40.6 years (2002)','d417c3d0629c57b6d36a5a4e2b7754e3fbb5ef8a6e7a44f6d7b74c6290f4ab6a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e20584b318d149f506463ca8d95ce9bfd97c76d980cbf292cb32f9e18666e6b',2003,'MH','Marshall Islands','communications',930,'low coral limestone and sand islands
4.12 children born/woman (2003 est.)
constitutional government in free association with
the US; the Compact of Free Association entered into force 21
October 1986
30.9% (1999 est.)
defense is the responsibility of the US
conventional long form: Republic of the Marshall
Islands
conventional short form: Marshall Islands
former: Marshall Islands District (Trust Territory of the Pacific
Islands)
Oceania, group of atolls and reefs in the North
Pacific Ocean, about one-half of the way from Hawaii to Australia
Navassa Island
Caribbean, island in the Caribbean Sea, about
one-fourth of the way from Haiti to Jamaica
Oceania
0 sq km
total: 181.3 sq km
land: 181.3 sq km
water: 0 sq km
note: includes the atolls of Bikini, Enewetak, Kwajalein, Majuro,
Rongelap, and Utirik
chief of mission: Ambassador Banny DE BRUM
chancery: 2433 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 234-5414
FAX: [1] (202) 232-3236
consulate(s) general: Honolulu
4,186 (2001)
489 (2001)
1 (2002)
900 (2002)
.mh
NA%
NA
NA
USD
total: 19.3 years
male: 19.3 years
female: 19.2 years (2002)','b911883a8f624ac04e5b25931cf5f04fff3ace86a8b1839fb6feec2e31692d34','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fd17f4beb055549e185de6b85beabbc65c601c2cda0acf5bd432f6486687b63',2003,'MQ','Martinique','communications',931,'mountainous with indented coastline; dormant volcano
1.79 children born/woman (2003 est.)
NA
27.2% (1998)
defense is the responsibility of France
conventional long form: Department of Martinique
conventional short form: Martinique
local long form: Departement de la Martinique
local short form: Martinique
Caribbean, island between the Caribbean Sea and North
Atlantic Ocean, north of Trinidad and Tobago
Central America and the Caribbean
30 sq km (1998 est.)
total: 1,100 sq km
land: 1,060 sq km
water: 40 sq km
none (overseas department of France)
170,000 (1997)
15,000 (1997)
2 (2000)
5,000 (2000)
.mq
NA%
NA
NA
EUR
0 bbl/day (2001 est.)
13,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 32.7 years
male: 32 years
female: 33.3 years (2002)','b718024ba509ed930931dd29bee3443eafdf28ba544a893f2c37343b5f3fcc92','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67a3286de98ef54b9a6cbb2a9f8dd4b91b9083176f464d478411f3ef8155c8ae',2003,'MR','Mauritania','communications',932,'mostly barren, flat plains of the Sahara; some central
hills
6.08 children born/woman (2003 est.)
republic
21% (1999 est.)
conventional long form: Islamic Republic of Mauritania
conventional short form: Mauritania
local long form: Al Jumhuriyah al Islamiyah al Muritaniyah
local short form: Muritaniyah
Northern Africa, bordering the North Atlantic Ocean,
between Senegal and Western Sahara
Africa
490 sq km (1998 est.)
total: 1,030,700 sq km
land: 1,030,400 sq km
water: 300 sq km
chief of mission: Ambassador Mohamedou Ould MICHEL
chancery: 2129 Leroy Place NW, Washington, DC 20008
telephone: [1] (202) 232-5700
FAX: [1] (202) 319-2623
26,500 (2001)
35,000 (2001)
5 (2001)
7,500 (2001)
.mr
1.8% (2001 est.)
6,600 (1999 est.)
610 (2001 est.)
MRO
37.3 (1995)
0 bbl/day (2001 est.)
24,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 16.9 years
male: 16.6 years
female: 17.2 years (2002)','fe0621324bce3667c1f3058abd59c181ed9d3e39dce46d878f958e9452e87ce7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11d0804d26c39b3e06008d7da536a9684d4059cbf6cf03f477a4c1239678817c',2003,'MU','Mauritius','communications',933,'small coastal plain rising to discontinuous mountains
encircling central plateau
1.98 children born/woman (2003 est.)
parliamentary democracy
8.8% (2002 est.)
conventional long form: Republic of Mauritius
conventional short form: Mauritius
Southern Africa, island in the Indian Ocean, east of
Political Map of the World
200 sq km (1998 est.)
total: 2,040 sq km
land: 2,030 sq km
water: 10 sq km
note: includes Agalega Islands, Cargados Carajos Shoals (Saint
Brandon), and Rodrigues
chief of mission: Ambassador Usha JEETAH
chancery: 4301 Connecticut Avenue NW, Suite 441, Washington, DC 20008
telephone: [1] (202) 244-1491, 1492
FAX: [1] (202) 966-0983
280,900 (2000)
180,000 (2000)
2 (2000)
158,000 (2002)
.mu
0.1% (2001 est.)
700 (2001 est.)
less than 100 (2001 est.)
MUR
37 (1987 est.)
0 bbl/day (2001 est.)
21,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 29.8 years
male: 29.1 years
female: 30.8 years (2002)','4979cccfce75b7448261e7e930eac6c82fb757e55f04df36fcf97b5246952917','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48b33b3287ad4009116f26bca3f99f9449501d59bb49b9e5455a62c750edfd21',2003,'YT','Mayotte','communications',934,'generally undulating, with deep ravines and ancient volcanic
peaks
6.07 children born/woman (2003 est.)
NA
38% (1999)
defense is the responsibility of France; small contingent of
French forces stationed on the island
conventional long form: Territorial Collectivity of Mayotte
conventional short form: Mayotte
Southern Africa, island in the Mozambique Channel, about
one-half of the way from northern Madagascar to northern Mozambique
Africa
NA sq km
total: 374 sq km
land: 374 sq km
water: 0 sq km
none (territorial collectivity of France)
12,000 (1998)
0 (2000)
NA
NA
.yt
NA%
NA
NA
EUR
total: 16.9 years
male: 18.1 years
female: 15.7 years (2002)','68438be08d4e668133647e7adf807d499dd6e94c81fbcc39da83e964bb02d408','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e5e609ce7a2f043a4d839524e26708fbd9c31524a94255ab821bdc64de22770',2003,'MX','Mexico','communications',935,'high, rugged mountains; low coastal plains; high plateaus;
desert
2.53 children born/woman (2003 est.)
federal republic
urban - 3% plus considerable underemployment (2002)
conventional long form: United Mexican States
conventional short form: Mexico
local long form: Estados Unidos Mexicanos
local short form: Mexico
Middle America, bordering the Caribbean Sea and the Gulf of
Mexico, between Belize and the US and bordering the North Pacific
Ocean, between Guatemala and the US
North America
65,000 sq km (1998 est.)
total: 1,972,550 sq km
land: 1,923,040 sq km
water: 49,510 sq km
chief of mission: Ambassador Juan Jose BREMER Martino
chancery: 1911 Pennsylvania Avenue NW, Washington, DC 20006
telephone: [1] (202) 728-1600
FAX: [1] (202) 728-1698
consulate(s) general: Atlanta, Austin, Boston, Chicago, Dallas,
Denver, El Paso, Houston, Laredo (Texas), Los Angeles, Miami, New
Orleans, New York, Nogales (Arizona), Phoenix, Sacramento, San
Antonio, San Diego, San Francisco, San Jose, San Juan (Puerto Rico)
consulate(s): Albuquerque, Brownsville (Texas), Calexico
(California), Corpus Christi, Del Rio (Texas), Detroit, Douglas
(Arizona), Eagle Pass (Texas), Fresno (California), Indianapolis
(Indiana), Las Vegas, McAllen (Texas), Midland (Texas), Omaha,
Orlando, Oxnard (California), Philadelphia, Portland (Oregon),
Presidio (Texas), Raleigh, Saint Louis, Salt Lake City, San
Bernardino, Santa Ana (California), Seattle, Tucson, Yuma (Arizona)
12.332 million (2000)
2.02 million (1998)
51 (2000)
3.5 million (2002)
.mx
0.3% (2001 est.)
150,000 (2001 est.)
4,200 (2001 est.)
MXN
53.1 (1998)
Moldova
40.6 (1997)
3.59 million bbl/day (2001 est.)
Moldova
0 bbl/day (2001 est.)
1.507 million bbl/day (2001 est.)
Moldova
24,000 bbl/day (2001 est.)
374,700 bbl/day (2001)
Moldova
NA (2001)
1.881 million bbl/day (2001)
Moldova
NA (2001)
total: 23.8 years
male: 22.9 years
female: 24.6 years (2002)
Moldova
total: 32 years
male: 29.8 years
female: 34.2 years (2002)
25.03 billion bbl (37257)
969.2 billion cu m (37257)
36.87 billion cu m (2001 est.)
Moldova
0 cu m (2001 est.)
38.84 billion cu m (2001 est.)
Moldova
2.05 billion cu m (2001 est.)
2.967 billion cu m (2001 est.)
Moldova
2.05 billion cu m (2001 est.)
254 million cu m (2001 est.)
Moldova
0 cu m (2001 est.)','f89af4905bd77ccb1bf3719d7e62aba8f012fec9ba71a2ff100b32268a49d829','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f794299965cc489d1e86176309f7bb74ba35c8b2a498f994d1c1de5a67270a90',2003,'FM','Micronesia, Federated States of','communications',936,'islands vary geologically from high
mountainous islands to low, coral atolls; volcanic outcroppings on
Pohnpei, Kosrae, and Chuuk
Midway Islands
low, nearly level
Moldova
rolling steppe, gradual slope south to Black Sea
3.5 children born/woman (2003 est.)
Moldova
1.74 children born/woman (2003 est.)
constitutional government in free
association with the US; the Compact of Free Association entered
into force 3 November 1986; economic provisions of the Compact are
being renegotiated
Moldova
republic
16% (1999 est.)
Moldova
8% (roughly 25% of working age Moldovans are employed
abroad) (2002 est.)
Federated States of Micronesia (FSM)
is a sovereign, self-governing state in free association with the
US; FSM is totally dependent on the US for its defense
Midway Islands
defense is the responsibility of the US
conventional long form: Federated
States of Micronesia
conventional short form: none
former: Ponape, Truk, and Yap Districts (Trust Territory of the
Pacific Islands)
abbreviation: FSM
Midway Islands
conventional long form: none
conventional short form: Midway Islands
Moldova
conventional long form: Republic of Moldova
conventional short form: Moldova
local long form: Republica Moldova
local short form: none
former: Soviet Socialist Republic of Moldova; Moldavia
Oceania, island group in the North
Pacific Ocean, about three-quarters of the way from Hawaii to
Oceania
Midway Islands
Oceania
Moldova
Europe
NA sq km
Midway Islands
0 sq km (1998 est.)
Moldova
3,070 sq km (1998 est.)
total: 702 sq km
land: 702 sq km
water: 0 sq km (fresh water only)
note: includes Pohnpei (Ponape), Chuuk (Truk) Islands, Yap Islands,
and Kosrae (Kosaie)
Midway Islands
total: 6.2 sq km
land: 6.2 sq km
water: 0 sq km
note: includes Eastern Island, Sand Island, and Spit Island
Moldova
total: 33,843 sq km
land: 33,371 sq km
water: 472 sq km
chief of mission: Ambassador Jesse
Bibiano MAREHALAU
chancery: 1725 N Street NW, Washington, DC 20036
telephone: [1] (202) 223-4383
FAX: [1] (202) 223-4391
consulate(s) general: Honolulu and Tamuning (Guam)
Moldova
chief of mission: Ambassador Mihail MANOLI
chancery: 2101 S Street NW, Washington, DC 20008
telephone: [1] (202) 667-1130
FAX: [1] (202) 667-1204
11,000 (2001)
Moldova
627,000 (1997)
newly installed in Pohnpei and Yap
Moldova
2,200 (1997)
1 (2000)
Moldova
2 (1999)
2,000 (2000)
Moldova
15,000 (2000)
.fm
Moldova
.md
NA%
Moldova
0.2% (2001 est.)
NA
Moldova
5,500 (2001 est.)
NA
Moldova
less than 300 (2001 est.)
USD
Moldova
MDL','dab1a7395e88966814c4c688ee90a5dadd3e363477639d560a639eebf5a810d6','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43e9f60cc355ba0ef56541405378293a573b1c8a7107eb5735090373ac326195',2003,'MC','Monaco','communications',937,'hilly, rugged, rocky
1.76 children born/woman (2003 est.)
constitutional monarchy
3.1% (1998)
defense is the responsibility of France
conventional long form: Principality of Monaco
conventional short form: Monaco
local long form: Principaute de Monaco
local short form: Monaco
Western Europe, bordering the Mediterranean Sea on the
southern coast of France, near the border with Italy
Europe
NA sq km
total: 1.95 sq km
land: 1.95 sq km
water: 0 sq km
Monaco does not have an embassy in the US
consulate(s) general: New York
31,027 (1995)
NA
2 (2000)
NA
.mc
NA%
NA
NA
EUR
total: 45 years
male: 43 years
female: 47 years (2002)','3748462ef5251b86a219e3ffccf56e73b51ed070a88b60af8f209f7b86decf46','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4d1ba9acd96743deafeb687d15650a37646a732a0b57fcf7bed9c6f2eb5620e',2003,'MN','Mongolia','communications',938,'vast semidesert and desert plains, grassy steppe, mountains
in west and southwest; Gobi Desert in south-central
2.28 children born/woman (2003 est.)
parliamentary
20% (2000)
conventional long form: none
conventional short form: Mongolia
local long form: none
local short form: Mongol Uls
former: Outer Mongolia
Northern Asia, between China and Russia
Asia
840 sq km (1998 est.)
total: 1.565 million sq km
land: 1,555,400 sq km
water: 9,600 sq km
chief of mission: Ambassador Ravdangiyn BOLD
chancery: 2833 M Street NW, Washington, DC 20007
telephone: [1] (202) 333-7117
FAX: [1] (202) 298-9227
consulate(s) general: New York
104,100 (1999)
110,000 (2001)
5 (2001)
40,000 (2002)
.mn
less than 0.1% (2001 est.)
less than 100 (1999 est.)
NA
MNT
33.2 (1995)
0 bbl/day (2001 est.)
8,750 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 23.5 years
male: 23.2 years
female: 23.9 years (2002)','89ef86dd22ed9b8bbcf24ac10650875362e8decc89f467c7f0e889ad59dc6b1c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf2bc62e550637e54e9994abc0294e6747668d33fef7bb177dd06374707697b4',2003,'MS','Montserrat','communications',939,'volcanic island, mostly mountainous, with small coastal
lowland
1.8 children born/woman (2003 est.)
NA
6% (1998 est.)
defense is the responsibility of the UK
conventional long form: none
conventional short form: Montserrat
Caribbean, island in the Caribbean Sea, southeast of
Central America and the Caribbean
NA sq km
total: 102 sq km
land: 102 sq km
water: 0 sq km
none (overseas territory of the UK)
4,000 (1997)
70 (1994)
17 (2000)
NA
.ms
NA%
NA
NA
XCD
0 bbl/day (2001 est.)
400 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 27.8 years
male: 27.7 years
female: 27.9 years (2002)','0690aec6c67f953a938188e967b2676d23e6c5ddcb548bdaf2104bfcff10d034','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad77b1e4b2552f4a5234a1598627aa8c56b1817e18ab002a17d9303ae2f0ccdb',2003,'MA','Morocco','communications',940,'northern coast and interior are mountainous with large areas
of bordering plateaus, intermontane valleys, and rich coastal plains
2.89 children born/woman (2003 est.)
constitutional monarchy
19% (2002 est.)
conventional long form: Kingdom of Morocco
conventional short form: Morocco
local long form: Al Mamlakah al Maghribiyah
local short form: Al Maghrib
Northern Africa, bordering the North Atlantic Ocean and the
Mediterranean Sea, between Algeria and Western Sahara
Africa
12,910 sq km (1998 est.)
total: 446,550 sq km
land: 446,300 sq km
water: 250 sq km
chief of mission: Ambassador Aziz MEKOUAR
chancery: 1601 21st Street NW, Washington, DC 20009
telephone: [1] (202) 462-7979 through 7982
FAX: [1] (202) 265-0161
consulate(s) general: New York
1.391 million (1998)
116,645 (1998)
8 (2000)
400,000 (2002)
.ma
0.1% (2001 est.)
13,000 (2001 est.)
NA
MAD
39.5 (1998-99)
400 bbl/day (2001 est.)
167,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 23 years
male: 22.5 years
female: 23.5 years (2002)
900,000 bbl (37257)
665.4 million cu m (37257)
50 million cu m (2001 est.)
50 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','8911e52e62a62c2a0c950b79ffa84e259642d7886b80c7ab5fded66168eb6eef','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff8e0590378dcb0290f307894905d7f01cfbf2b15850326d77a73aaf9e044001',2003,'MZ','Mozambique','communications',941,'mostly coastal lowlands, uplands in center, high plateaus
in northwest, mountains in west
4.87 children born/woman (2003 est.)
republic
21% (1997 est.)
conventional long form: Republic of Mozambique
conventional short form: Mozambique
local long form: Republica de Mocambique
local short form: Mocambique
former: Portuguese East Africa
Falkland Islands (Islas Malvinas)
Southern South America, islands in
the South Atlantic Ocean, east of southern Argentina
South-eastern Africa, bordering the Mozambique Channel,
between South Africa and Tanzania
Africa
1,070 sq km (1998 est.)
total: 801,590 sq km
land: 784,090 sq km
water: 17,500 sq km
chief of mission: Ambassador Armando PANGUENE
chancery: 1990 M Street NW, Suite 570, Washington, DC 20036
telephone: [1] (202) 293-7146
FAX: [1] (202) 835-0245
90,000 (2001)
287,000 (2002)
11 (2002)
22,500 (2000)
.mz
13% 12.6 to 16.4%, estimates vary (2001 est.)
1.1 million (2001 est.)
60,000 (2001 est.)
MZM
39.6 (1996-97)
0 bbl/day (2001 est.)
8,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 19 years
male: 18.7 years
female: 19.3 years (2002)
0 bbl (37257)
63.71 billion cu m (37257)
60 million cu m (2001 est.)
60 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','53ba1266df2803d90d5f912019938181c60f57adbaa6bc2a324c8c6d347379b1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ef2a7fffa626fc98f898828ec618eb8e47c6a858a0235272d92774370e421f3',2003,'NA','Namibia','communications',942,'mostly high plateau; Namib Desert along coast; Kalahari
Desert in east
4.71 children born/woman (2003 est.)
republic
35% (1998)
conventional long form: Republic of Namibia
conventional short form: Namibia
former: German Southwest Africa, South-West Africa
Southern Africa, bordering the South Atlantic Ocean, between
Angola and South Africa
Africa
70 sq km (1998 est.)
total: 825,418 sq km
land: 825,418 sq km
water: 0 sq km
chief of mission: Ambassador Leonard Nangolo IIPUMBU
chancery: 1605 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 986-0540
FAX: [1] (202) 986-0443
110,200 (2000)
82,000 (2000 est.)
2 (2000)
45,000 (2002)
.na
22.5% (2001 est.)
230,000 (2001 est.)
13,000 (2001 est.)
NAD; ZAR
0 bbl/day (2001 est.)
13,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.3 years
male: 17.9 years
female: 18.6 years (2002)
0 bbl (37257)
31.15 billion cu m (37257)','6a7886b65a4e7b943c296de41629a54046e09e9ea1f69864a7880cec62f934e5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2e7b6c6d96fa80cd48bfdfd957675cedfaa2fd495f08223c3e6b75acb8ee48b',2003,'NR','Nauru','communications',943,'sandy beach rises to fertile ring around raised coral reefs
with phosphate plateau in center
Navassa Island
raised coral and limestone plateau, flat to
undulating; ringed by vertical white cliffs (9 to 15 m high)
3.4 children born/woman (2003 est.)
republic
0%
Nauru maintains no defense forces; under an informal
agreement, defense is the responsibility of Australia
Navassa Island
defense is the responsibility of the US
Netherlands Antilles
defense is the responsibility of the Kingdom of
the Netherlands
conventional long form: Republic of Nauru
conventional short form: Nauru
former: Pleasant Island
Navassa Island
conventional long form: none
conventional short form: Navassa Island
Oceania, island in the South Pacific Ocean, south of the
Oceania
Navassa Island
Central America and the Caribbean
NA sq km
Navassa Island
0 sq km (1998 est.)
total: 21 sq km
land: 21 sq km
water: 0 sq km
Navassa Island
total: 5.2 sq km
land: 5.2 sq km
water: 0 sq km
Nauru does not have an embassy in the US, but does have a UN
office at 800 2nd Avenue, Suite 400 D, New York, New York 10017;
telephone: (212) 937-0074
consulate(s): Hagatna (Guam)
2,000 (1996)
450 (1994)
1 (2000)
NA
.nr
NA%
NA
NA
AUD
0 bbl/day (2001 est.)
1,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 19.6 years
male: 19.3 years
female: 20 years (2002)','c1c5b844378c2db7d99aa3ede0fa8f3a5c92e100dfa8a40279c60b79867aa072','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32c344daa1c21eb79a67110a57920d990546f990db2c2d1ff554ae362042eb8f',2003,'NP','Nepal','communications',944,'Terai or flat river plain of the Ganges in south, central hill
region, rugged Himalayas in north
4.39 children born/woman (2003 est.)
parliamentary democracy and constitutional monarchy
47% (2001 est.)
conventional long form: Kingdom of Nepal
conventional short form: Nepal
Southern Asia, between China and India
Asia
11,350 sq km (1998 est.)
total: 140,800 sq km
land: 136,800 sq km
water: 4,000 sq km
chief of mission: Ambassador-designate Jai Pratap RANA
chancery: 2131 Leroy Place NW, Washington, DC 20008
telephone: [1] (202) 667-4550
FAX: [1] (202) 667-5534
consulate(s) general: New York
236,816 (January 2000)
NA
6 (2000)
60,000 (2002)
.np
0.5% (2001 est.)
58,000 (2001 est.)
2,400 (2001 est.)
NPR
36.7 (FY 95/96)
0 bbl/day (2001 est.)
16,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 19.7 years
male: 19.6 years
female: 19.9 years (2002)','0d1b4fa25e601986a669552f3d3f5c3f7b2b3c73de92e4ba619d171511fb5d81','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21cada2c781073921370ea3ac350049c72c57c065b8cc6a8b83ab00e729c3728',2003,'NL','Netherlands','communications',945,'mostly coastal lowland and reclaimed land (polders);
some hills in southeast
Netherlands Antilles
generally hilly, volcanic interiors
1.65 children born/woman (2003 est.)
Netherlands Antilles
2.04 children born/woman (2003 est.)
constitutional monarchy
Netherlands Antilles
parliamentary
3% (2002 est.)
Netherlands Antilles
15% (1998 est.)
conventional long form: Kingdom of the Netherlands
conventional short form: Netherlands
local long form: Koninkrijk der Nederlanden
local short form: Nederland
Netherlands Antilles
conventional long form: none
conventional short form: Netherlands Antilles
local long form: none
local short form: Nederlandse Antillen
former: Curacao and Dependencies
Western Europe, bordering the North Sea, between Belgium
and Germany
Netherlands Antilles
Caribbean, two island groups in the Caribbean
Sea - one includes Curacao and Bonaire north of Venezuela; the other
is east of the Virgin Islands
Europe
Netherlands Antilles
Central America and the Caribbean
5,650 sq km (1998 est.)
Netherlands Antilles
NA sq km
total: 41,526 sq km
land: 33,883 sq km
water: 7,643 sq km
Netherlands Antilles
total: 960 sq km
land: 960 sq km
water: 0 sq km
note: includes Bonaire, Curacao, Saba, Sint Eustatius, and Sint
Maarten (Dutch part of the island of Saint Martin)
chief of mission: Ambassador Boudewijn J. VAN EENENNAAM
chancery: 4200 Linnean Avenue NW, Washington, DC 20008
telephone: [1] (202) 244-5300
FAX: [1] (202) 362-3430
consulate(s) general: Chicago, Houston, Los Angeles, Miami, New York
consulate(s): Boston
Netherlands Antilles
none (represented by the Kingdom of the
Netherlands)
9,132,400 (1999)
Netherlands Antilles
76,000 (1995)
4,081,891 (April 1999)
Netherlands Antilles
13,977 (1996)
52 (2000)
Netherlands Antilles
6
9.73 million (2002)
Netherlands Antilles
2,000 (2000)
.nl
Netherlands Antilles
.an
0.2% (2001 est.)
Netherlands Antilles
NA%
17,000 (2001 est.)
Netherlands Antilles
NA
110 (2001 est.)
Netherlands Antilles
NA
EUR
Netherlands Antilles
ANG
32.6 (1994)
46,200 bbl/day (2001 est.)
Netherlands Antilles
0 bbl/day (2001 est.)
895,300 bbl/day (2001 est.)
Netherlands Antilles
72,000 bbl/day (2001 est.)
2.284 million bbl/day (2001)
Netherlands Antilles
NA (2001)
1.418 million bbl/day (2001)
Netherlands Antilles
NA (2001)
total: 38.6 years
male: 37.7 years
female: 39.5 years (2002)
Netherlands Antilles
total: 31.8 years
male: 30.3 years
female: 33.2 years (2002)
88.06 million bbl (37257)
1.693 trillion cu m (37257)
77.75 billion cu m (2001 est.)
49.72 billion cu m (2001 est.)
20.78 billion cu m (2001 est.)
49.28 billion cu m (2001 est.)
Antilles NT AN ANT 530 .an
New Caledonia NC NC NCL 540 .nc
New Zealand NZ NZ NZL 554 .nz
Nicaragua NU NI NIC 558 .ni
Niger NG NE NER 562 .ne
Nigeria NI NG NGA 566 .ng
Niue NE NU NIU 570 .nu
Norfolk Island NF NF NFK 574 .nf
Northern Mariana
Islands CQ MP MNP 580 .mp
Norway NO NO NOR 578 .no
Oman MU OM OMN 512 .om
Pakistan PK PK PAK 586 .pk
Palau PS PW PLW 585 .pw
Palmyra Atoll LQ - - - -
ISO includes with the US Minor Outlying Islands
Panama PM PA PAN 591 .pa
Papua New Guinea PP PG PNG 598 .pg
Paracel Islands PF - - - -
Paraguay PA PY PRY 600 .py
Peru PE PE PER 604 .pe
Philippines RP PH PHL 608 .ph
Pitcairn Islands PC PN PCN 612 .pn
Poland PL PL POL 616 .pl
Portugal PO PT PRT 620 .pt
Puerto Rico RQ PR PRI 630 .pr
Qatar QA QA QAT 634 .qa
Reunion RE RE REU 638 .re
Romania RO RO ROM 642 .ro
Russia RS RU RUS 643 .ru
Rwanda RW RW RWA 646 .rw
Saint Helena SH SH SHN 654 .sh
Saint Kitts
and Nevis SC KN KNA 659 .kn
Saint Lucia ST LC LCA 662 .lc
Saint Pierre
and Miquelon SB PM SPM 666 .pm
Saint Vincent and
the Grenadines VC VC VCT 670 .vc
Samoa WS WS WSM 882 .ws
San Marino SM SM SMR 674 .sm
Sao Tome and
Principe TP ST STP 678 .st
Saudi Arabia SA SA SAU 682 .sa
Senegal SG SN SEN 686 .sn
Serbia and
Montenegro YI YU YUG 891 .yu
Seychelles SE SC SYC 690 .sc
Sierra Leone SL SL SLE 694 .sl
Singapore SN SG SGP 702 .sg
Slovakia LO SK SVK 703 .sk
Slovenia SI SI SVN 705 .si
Solomon Islands BP SB SLB 090 .sb
Somalia SO SO SOM 706 .so
South Africa SF ZA ZAF 710 .za
South Georgia and
the Islands SX GS SGS 239 .gs
Spain SP ES ESP 724 .es
Spratly Islands PG - - - -
Sri Lanka CE LK LKA 144 .lk
Sudan SU SD SDN 736 .sd
Suriname NS SR SUR 740 .sr
Svalbard SV SJ SJM 744 .sj
ISO includes Jan Mayen
Swaziland WZ SZ SWZ 748 .sz
Sweden SW SE SWE 752 .se
Switzerland SZ CH CHE 756 .ch
Syria SY SY SYR 760 .sy
Taiwan TW TW TWN 158 .tw
Tajikistan TI TJ TJK 762 .tj
Tanzania TZ TZ TZA 834 .tz
Thailand TH TH THA 764 .th
Togo TO TG TGO 768 .tg
Tokelau TL TK TKL 772 .tk
Tonga TN TO TON 776 .to
Trinidad and Tobago TD TT TTO 780 .tt
Tromelin Island TE - - - -
ISO includes with the Miscellaneous Islands
Tunisia TS TN TUN 788 .tn
Turkey TU TR TUR 792 .tr
Turkmenistan TX TM TKM 795 .tm
Turks and
Caicos Islands TK TC TCA 796 .tc
Tuvalu TV TV TUV 798 .tv
Uganda UG UG UGA 800 .ug
Ukraine UP UA UKR 804 .ua
United Arab
Emirates AE AE ARE 784 .ae
United Kingdom UK GB GBR 826 .uk
ISO includes Guernsey, Isle of Man, Jersey
United States US US USA 840 .us','26737150e4707b849197ed3446260b88caf319de42fb28459f4e7228b5e66309','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2542e95296d89e690517761d0ebd1d1c7cabb30c2fe838fa60668a98e9c6b2c',2003,'NC','New Caledonia','communications',946,'coastal plains with interior mountains
2.39 children born/woman (2003 est.)
NA
19% (1996)
defense is the responsibility of France
conventional long form: Territory of New Caledonia and
Dependencies
conventional short form: New Caledonia
local long form: Territoire des Nouvelle-Caledonie et Dependances
local short form: Nouvelle-Caledonie
Oceania, islands in the South Pacific Ocean, east of
Oceania
160 sq km (1991)
total: 19,060 sq km
land: 18,575 sq km
water: 485 sq km
none (overseas territory of France)
47,000 (1997)
13,040 (1998)
1 (2000)
24,000 (2001)
.nc
NA%
NA
NA
XPF
0 bbl/day (2001 est.)
8,750 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 26.9 years
male: 26.7 years
female: 27.2 years (2002)','46bfb4767bd0e68aab0f237a252b2bc48516feb70c3a839369c8cbf2f2cd15ea','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73596a432057116d63a2babd4e2c509d44fd3f6b2a85419e4734694abb8975da',2003,'NZ','New Zealand','communications',947,'predominately mountainous with some large coastal plains
1.79 children born/woman (2003 est.)
parliamentary democracy
5.3% (2002 est.)
conventional long form: none
conventional short form: New Zealand
abbreviation: NZ
Oceania, islands in the South Pacific Ocean, southeast
of Australia
Oceania
2,850 sq km (1998 est.)
total: 268,680 sq km
land: NA sq km
water: NA sq km
note: includes Antipodes Islands, Auckland Islands, Bounty Islands,
Campbell Island, Chatham Islands, and Kermadec Islands
chief of mission: Ambassador L. John WOOD
chancery: 37 Observatory Circle NW, Washington, DC 20008
telephone: [1] (202) 328-4800
FAX: [1] (202) 667-5227
consulate(s) general: Los Angeles, New York
1.92 million (2000)
2.2 million (2000)
36 (2000)
2.06 million (2002)
.nz
0.1% (2001 est.)
1,200 (2001 est.)
less than 100 (2001 est.)
NZD
42,160 bbl/day (2001 est.)
132,700 bbl/day (2001 est.)
119,700 bbl/day (2001)
30,220 bbl/day (2001)
total: 33.1 years
male: 32.4 years
female: 33.9 years (2002)
89.62 million bbl (37257)
58.94 billion cu m (37257)
6.504 billion cu m (2001 est.)
6.504 billion cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','f4cc23908dd5634b3833950ffcb7153add7ffbf27ec5857b99e26ec77c67b3b8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f53d2c649aec7ba8376cf7dc495e60b88e01771941ca0d24536a240429de9bf7',2003,'NI','Nicaragua','communications',948,'extensive Atlantic coastal plains rising to central
interior mountains; narrow Pacific coastal plain interrupted by
volcanoes
3 children born/woman (2003 est.)
republic
24% plus considerable underemployment (2002 est.)
conventional long form: Republic of Nicaragua
conventional short form: Nicaragua
local long form: Republica de Nicaragua
local short form: Nicaragua
Middle America, bordering both the Caribbean Sea and the
North Pacific Ocean, between Costa Rica and Honduras
Central America and the Caribbean
880 sq km (1998 est.)
total: 129,494 sq km
land: 120,254 sq km
water: 9,240 sq km
chief of mission: Ambassador Salvador STADTHAGEN (since 5
December 2003)
chancery: 1627 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 939-6570
FAX: [1] (202) 939-6542
consulate(s) general: Houston, Los Angeles, Miami, New Orleans, New
York
140,000 (1996)
7,911 (1997)
3 (2000)
20,000 (2000)
.ni
0.2% (2001 est.)
5,800 (2001 est.)
400 (2001 est.)
NIO
60.3 (1998)
0 bbl/day (2001 est.)
24,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 20.4 years
male: 20 years
female: 20.8 years (2002)','5500dd5a0b84645d3848718a681a95f94cd1f4042a2449c0bc9b31460938c361','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f589cd039ba4b3d319cba4985101e8bc2c3d9c97262f7d613b203752be7d8af6',2003,'NE','Niger','communications',949,'predominately desert plains and sand dunes; flat to rolling
plains in south; hills in north
6.91 children born/woman (2003 est.)
republic
NA%
conventional long form: Republic of Niger
conventional short form: Niger
local long form: Republique du Niger
local short form: Niger
Western Africa, southeast of Algeria
Africa
660 sq km (1998 est.)
total: 1.267 million sq km
land: 1,266,700 sq km
water: 300 sq km
chief of mission: Ambassador Joseph DIATTA
chancery: 2204 R Street NW, Washington, DC 20008
telephone: [1] (202) 483-4224 through 4227
FAX: [1] (202)483-3169
20,000 (2001)
6,700 (2002)
1 (2002)
12,000 (2002)
.ne
4% (2001 est.)
NA
6,000 (2001 est.)
XOF
50.5 (1995)
0 bbl/day (2001 est.)
5,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 16.1 years
male: 15.6 years
female: 16.6 years (2002)','da5602f73ce7bf07dea118af4621c5bbef260102b0c66c5f98e622e77d3e55c4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c3edf9539c4f04cc23a6587460b984736e1deef723f5cbc763abc8965b2bc60',2003,'NG','Nigeria','communications',950,'southern lowlands merge into central hills and plateaus;
mountains in southeast, plains in north
5.4 children born/woman (2003 est.)
republic transitioning from military to civilian rule
28% (1992 est.)
conventional long form: Federal Republic of Nigeria
conventional short form: Nigeria
Western Africa, bordering the Gulf of Guinea, between Benin
and Cameroon
Africa
2,330 sq km (1998 est.)
total: 923,768 sq km
land: 910,768 sq km
water: 13,000 sq km
chief of mission: Ambassador Jibril Muhammad AMINU
chancery: 3519 International Court NW, Washington, DC 20008
telephone: [1] (202) 986-8400
FAX: [1] (202) 775-1385
consulate(s) general: Atlanta and New York
500,000 (2000 est.)
200,000 (2001)
11 (2000)
100,000 (2000)
.ng
5.8% (2001 est.)
3.5 million (2001 est.)
170,000 (2001 est.)
NGN
50.6 (1996-97)
2.256 million bbl/day (2001 est.)
275,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18 years
male: 18.1 years
female: 17.9 years (2002)
27 billion bbl (37257)
4.007 trillion cu m (37257)
15.68 billion cu m (2001 est.)
7.85 billion cu m (2001 est.)
0 cu m (2001 est.)
7.83 billion cu m (2001 est.)','d639d34bbe1193117d23928a4650cb31aba84e6593e04b11ed7bb3be9976878c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c647d9c312315f1b49a39c49f19a995ffcddf94124e7cd3cf5ee6639816ccde8',2003,'NU','Niue','communications',951,'steep limestone cliffs along coast, central plateau
NA children born/woman (2003 est.)
self-governing parliamentary democracy
NA%
defense is the responsibility of New Zealand
conventional long form: none
conventional short form: Niue
former: Savage Island
Oceania, island in the South Pacific Ocean, east of Tonga
Oceania
NA sq km
total: 260 sq km
land: 260 sq km
water: 0 sq km
none (self-governing territory in free association with New
Zealand)
376 (1991)
0 (1991)
1 (2000)
NA
.nu
NA%
NA
NA
NZD
0 bbl/day (2001 est.)
20 bbl/day (2001 est.)
NA (2001)
NA (2001)','ec00b0c0e3c5ac4ba270aaaeb3464de469150c029f5292bdfb99f8bacf61f19a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b873839731f2e444b990ea1de8c41f5e628e4dbdd64dd8de1ac846861a113ea4',2003,'NF','Norfolk Island','communications',952,'volcanic formation with mostly rolling plains
NA children born/woman (2003 est.)
NA
NA%
defense is the responsibility of Australia
conventional long form: Territory of Norfolk Island
conventional short form: Norfolk Island
Oceania, island in the South Pacific Ocean, east of
Oceania
NA sq km
total: 34.6 sq km
land: 34.6 sq km
water: 0 sq km
none (territory of Australia)
1,087 (1983)
0 (1983)
2 (2000)
NA
.nf
NA%
NA
NA
AUD','1ee818473bd14783b95479ebece5f6e5e58406210640831744ea173e754cfe3f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3688481b25c10872569e29159e85380cbc928f213fa981f91773d7bc1f3d5ea0',2003,'MP','Northern Mariana Islands','communications',953,'southern islands are limestone with level
terraces and fringing coral reefs; northern islands are volcanic
1.75 children born/woman (2003 est.)
commonwealth; self-governing with locally
elected governor, lieutenant governor, and legislature
NA%
defense is the responsibility of the US
conventional long form: Commonwealth of the
conventional short form: Northern Mariana Islands
former: Mariana Islands District (Trust Territory of the Pacific
Islands)
Oceania, islands in the North Pacific
Ocean, about three-quarters of the way from Hawaii to the Philippines
Oceania
NA sq km
total: 477 sq km
land: 477 sq km
water: 0 sq km
note: includes 14 islands including Saipan, Rota, and Tinian
21,000 (1996)
1,200 (1995)
1 (2001)
NA
.mp
NA%
NA
NA
USD
total: 30.4 years
male: 31 years
female: 30.1 years (2002)','e0e7a74d7de7dd60dc579adeb1bd7dd6a5ace7c7586a966ac9f310e28445c732','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea499cc3b352f029b0061581fa1b2607f2eadcb3b25cb47383477bcc4ab2a4e7',2003,'NO','Norway','communications',954,'glaciated; mostly high plateaus and rugged mountains broken
by fertile valleys; small, scattered plains; coastline deeply
indented by fjords; arctic tundra in north
1.8 children born/woman (2003 est.)
constitutional monarchy
3.9% (2002 est.)
conventional long form: Kingdom of Norway
conventional short form: Norway
local long form: Kongeriket Norge
local short form: Norge
Northern Europe, bordering the North Sea and the North
Atlantic Ocean, west of Sweden
Europe
1,270 sq km (1998 est.)
total: 324,220 sq km
land: 307,860 sq km
water: 16,360 sq km
chief of mission: Ambassador Knut VOLLEBAEK
chancery: 2720 34th Street NW, Washington, DC 20008
telephone: [1] (202) 333-6000
FAX: [1] (202) 337-0870
consulate(s) general: Houston, Miami, Minneapolis, New York, and San
Francisco
2.735 million (1998)
2,080,408 (1998)
13 (2000)
2.68 million (2002)
.no
0.1% (2001 est.)
1,800 (2001 est.)
less than 100 (2001 est.)
NOK
25.8 (1995)
3.408 million bbl/day (2001 est.)
171,100 bbl/day (2001 est.)
88,870 bbl/day (2001)
3.466 million bbl/day (2001)
total: 37.7 years
male: 36.7 years
female: 38.7 years (2002)
9.859 billion bbl (37257)
1.716 trillion cu m (37257)
54.6 billion cu m (2001 est.)
4.1 billion cu m (2001 est.)
0 cu m (2001 est.)
50.5 billion cu m (2001 est.)','1f133226a18abcf6f2f1b9fd3eb40efc1abfb5380728039db7b98cb6d955fad1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a271a4a78fc84c2bb0abc78c76763e6733214ca6829d050ca735bea52cbc2457',2003,'OM','Oman','communications',955,'central desert plain, rugged mountains in north and south
Pacific Ocean
surface currents in the northern Pacific are dominated
by a clockwise, warm-water gyre (broad circular system of currents)
and in the southern Pacific by a counterclockwise, cool-water gyre;
in the northern Pacific, sea ice forms in the Bering Sea and Sea of
Okhotsk in winter; in the southern Pacific, sea ice from Antarctica
reaches its northernmost extent in October; the ocean floor in the
eastern Pacific is dominated by the East Pacific Rise, while the
western Pacific is dissected by deep trenches, including the Mariana
Trench, which is the world''s deepest
5.94 children born/woman (2003 est.)
monarchy
NA%
conventional long form: Sultanate of Oman
conventional short form: Oman
local long form: Saltanat Uman
local short form: Uman
former: Muscat and Oman
Middle East, bordering the Arabian Sea, Gulf of Oman, and
Persian Gulf, between Yemen and UAE
Pacific Ocean
body of water between the Southern Ocean, Asia,
Australia, and the Western Hemisphere
Middle East
Pacific Ocean
Political Map of the World
620 sq km (1998 est.)
total: 212,460 sq km
land: 212,460 sq km
water: 0 sq km
Pacific Ocean
total: 155.557 million sq km
note: includes Bali Sea, Bering Sea, Bering Strait, Coral Sea, East
China Sea, Gulf of Alaska, Gulf of Tonkin, Philippine Sea, Sea of
Japan, Sea of Okhotsk, South China Sea, Tasman Sea, and other
tributary water bodies
chief of mission: Ambassador Muhammad bin Ali bin Thani
AL-KHUSSAIBY
chancery: 2535 Belmont Road, NW, Washington, DC 20008
telephone: [1] (202) 387-1980 through 1981, 1988
FAX: [1] (202) 745-4933
201,000 (1997)
59,822 (1997)
1 (2000)
120,000 (2002)
.om
0.1% (2001 est.)
1,300 (2001 est.)
NA
OMR
963,800 bbl/day (2001 est.)
53,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 19.4 years
male: 22.3 years
female: 16.5 years (2002)
5.703 billion bbl (37257)
846.4 billion cu m (37257)
13.77 billion cu m (2001 est.)
6.34 billion cu m (2001 est.)
0 cu m (2001 est.)
7.43 billion cu m (2001 est.)','4c91f35a84673fc97b273dc785e9b46d2c0f9cccc5b6f45d84f4dedaac7c36b4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('036861e92b99e4fd633f565694c6126e83354ce220fd509cef51507845c4898b',2003,'PK','Pakistan','communications',956,'flat Indus plain in east; mountains in north and northwest;
Balochistan plateau in west
4.1 children born/woman (2003 est.)
federal republic
7.8% plus substantial underemployment (2002 est.)
conventional long form: Islamic Republic of Pakistan
conventional short form: Pakistan
former: West Pakistan
Southern Asia, bordering the Arabian Sea, between India on
the east and Iran and Afghanistan on the west and China in the north
Asia
180,000 sq km (1998 est.)
total: 803,940 sq km
land: 778,720 sq km
water: 25,220 sq km
chief of mission: Ambassador Ashraf Jehangir QAZI
chancery: 2315 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 939-6205
FAX: [1] (202) 387-0484
consulate(s) general: Los Angeles, New York, and Sunnyvale
(California)
2.861 million (March 1999)
158,000 (1998)
30 (2000)
1.2 million (2000)
.pk
0.1% (2001 est.)
78,000 (2001 est.)
4,500 (2001 est.)
PKR
41 (FY98/99)
62,870 bbl/day (2001 est.)
365,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 19.8 years
male: 19.7 years
female: 20 years (2002)
297.1 million bbl (37257)
695.6 billion cu m (37257)
23.4 billion cu m (2001 est.)
23.4 billion cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','35e30b229cffa32db1f676ea82eae4963ce65d5eff63c9222a5a0f9ba38be096','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2449737498ee05322da8239fdea5a43537aef5602ceeab42cccbf1736948e7f3',2003,'PW','Palau','communications',957,'varying geologically from the high, mountainous main island of
Babelthuap to low, coral islands usually fringed by large barrier
reefs
Palmyra Atoll
very low
2.47 children born/woman (2003 est.)
constitutional government in free association with the US; the
Compact of Free Association entered into force 1 October 1994
2.3% (2000 est.)
defense is the responsibility of the US; under a Compact of
Free Association between Palau and the US, the US military is
granted access to the islands for 50 years
Palmyra Atoll
defense is the responsibility of the US
conventional long form: Republic of Palau
conventional short form: Palau
local long form: Beluu er a Belau
local short form: Belau
former: Palau District (Trust Territory of the Pacific Islands)
Palmyra Atoll
conventional long form: none
conventional short form: Palmyra Atoll
Oceania, group of islands in the North Pacific Ocean,
southeast of the Philippines
Palmyra Atoll
Oceania, atoll in the North Pacific Ocean, about half
way between Hawaii and American Samoa
Oceania
Palmyra Atoll
Oceania
NA sq km
Palmyra Atoll
0 sq km (1998 est.)
total: 458 sq km
land: 458 sq km
water: 0 sq km
Palmyra Atoll
total: 11.9 sq km
land: 11.9 sq km
water: 0 sq km
chief of mission: Ambassador Hersey KYOTA
chancery: 1800 K Street NW, Suite 714, Washington, DC 20006
telephone: [1] (202) 452-6814
FAX: [1] (202) 452-6281
consulate(s): Saipan (Northern Mariana Islands)
6,700 (2002)
1,000 (2002)
1 (2002)
.pw
NA%
NA
NA
USD
total: 30.8 years
male: 31.8 years
female: 29.7 years (2002)','057b1990dd85fac6ad16f7bed4b02a6936e8d1fb844bbcec53dcda7bd3a25187','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69863ea96a2ee62ebe3f5ba4ceb6576673c3958183a3251021bf3369c698e6cb',2003,'PA','Panama','communications',958,'interior mostly steep, rugged mountains and dissected, upland
plains; coastal areas largely plains and rolling hills
2.53 children born/woman (2003 est.)
constitutional democracy
16% (2002 est.)
on 10 February 1990, the government of then President ENDARA
abolished Panama''s military and reformed the security apparatus by
creating the Panamanian Public Forces; in October 1994, Panama''s
Legislative Assembly approved a constitutional amendment prohibiting
the creation of a standing military force, but allowing the
temporary establishment of special police units to counter acts of
"external aggression"
Paracel Islands
occupied by China
Pitcairn Islands
defense is the responsibility of the UK
conventional long form: Republic of Panama
conventional short form: Panama
local long form: Republica de Panama
local short form: Panama
Middle America, bordering both the Caribbean Sea and the
North Pacific Ocean, between Colombia and Costa Rica
Central America and the Caribbean
320 sq km (1998 est.)
total: 78,200 sq km
land: 75,990 sq km
water: 2,210 sq km
chief of mission: Ambassador Roberto ALFARO Estripeaut
chancery: 2862 McGill Terrace NW, Washington, DC 20008
telephone: [1] (202) 483-1407
FAX: [1] (202) 483-8416
consulate(s) general: Atlanta, Houston, Miami, New Orleans, New
York, Philadelphia, San Francisco, San Juan (Puerto Rico), Tampa
396,000 (1997)
17,000 (1997)
6 (2000)
45,000 (2000)
.pa
1.5% (2001 est.)
25,000 (2001 est.)
1,900 (2001 est.)
PAB; USD
48.5 (1997)
0 bbl/day (2001 est.)
52,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 25.6 years
male: 25.4 years
female: 25.9 years (2002)','95296998387cc9578c488fd4a8dd39810f9d5f42226ce547f1b376fa833cf994','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c2c35fcfcd19f1f48af7408129401e934fdd478dbae6a98018619daf4ce5670',2003,'PG','Papua New Guinea','communications',959,'mostly mountains with coastal lowlands and rolling
foothills
Paracel Islands
mostly low and flat
4.13 children born/woman (2003 est.)
constitutional monarchy with parliamentary democracy
NA%
conventional long form: Independent State of Papua
New Guinea
conventional short form: Papua New Guinea
former: Territory of Papua and New Guinea
abbreviation: PNG
Paracel Islands
conventional long form: none
conventional short form: Paracel Islands
Oceania, group of islands including the eastern
half of the island of New Guinea between the Coral Sea and the South
Pacific Ocean, east of Indonesia
Paracel Islands
Southeastern Asia, group of small islands and reefs
in the South China Sea, about one-third of the way from central
Vietnam to the northern Philippines
Oceania
Paracel Islands
Southeast Asia
NA sq km
Paracel Islands
0 sq km (1998 est.)
total: 462,840 sq km
land: 452,860 sq km
water: 9,980 sq km
Paracel Islands
total: NA sq km
land: NA sq km
water: 0 sq km
chief of mission: Ambassador Evan Jeremy PAKI
chancery: 1779 Massachusetts Avenue NW, Suite 805, Washington, DC
20036
telephone: [1] (202) 745-3680
FAX: [1] (202) 745-3679
61,152 (1999)
3,053 (1996)
3 (2000)
135,000 (2001)
.pg
0.7% (2001 est.)
17,000 (2001 est.)
880 (2001 est.)
PGK
50.9 (1996)
67,500 bbl/day (2001 est.)
15,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 20.8 years
male: 21 years
female: 20.6 years (2002)
345.2 million bbl (37257)
385.5 billion cu m (37257)
110 million cu m (2001 est.)
110 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','7ecc15cba96452ab39e4ebde3291c13a650303a9b3f4952edace9276baa82fd7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0a3571265b4187f87797d39029d90b667c7cb31562dd7733b169ddd4b0f0a19',2003,'PY','Paraguay','communications',960,'grassy plains and wooded hills east of Rio Paraguay; Gran
Chaco region west of Rio Paraguay mostly low, marshy plain near the
river, and dry forest and thorny scrub elsewhere
4.02 children born/woman (2003 est.)
constitutional republic
18.2% (2002 est.)
conventional long form: Republic of Paraguay
conventional short form: Paraguay
local long form: Republica del Paraguay
local short form: Paraguay
Central South America, northeast of Argentina
South America
670 sq km (1998 est.)
total: 406,750 sq km
land: 397,300 sq km
water: 9,450 sq km
chief of mission: Ambassador Leila Teresa RACHID COWLES
chancery: 2400 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 483-6960 through 6962
FAX: [1] (202) 234-4508
consulate(s) general: Kansas City, Los Angeles, Miami, New Orleans,
New York
290,475 (2001)
510,000 (2001)
4 (2000)
20,000 (2000)
.py
0.11% (2001 est.)
3,000 (1999 est.)
220 (2001 est.)
PYG
57.7 (1998)
0 bbl/day (2001 est.)
25,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 20.9 years
male: 20.7 years
female: 21.2 years (2002)','340fb7e7a79054cc3868c58bdcb8fc930de240d3cc78eaf3914182ac56a60802','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f8e95e4be6897e0c93e74eaf0ccebd5194fda3e44bfcba4bf5465391cec1b10',2003,'PE','Peru','communications',961,'western coastal plain (costa), high and rugged Andes in center
(sierra), eastern lowland jungle of Amazon Basin (selva)
2.81 children born/woman (2003 est.)
constitutional republic
9.4%; widespread underemployment (2002 est.)
conventional long form: Republic of Peru
conventional short form: Peru
local long form: Republica del Peru
local short form: Peru
Western South America, bordering the South Pacific Ocean,
between Chile and Ecuador
South America
11,950 sq km (1998 est.)
total: 1,285,220 sq km
land: 1.28 million sq km
water: 5,220 sq km
chief of mission: Ambassador (vacant)
chancery: 1700 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 833-9860 through 9869
FAX: [1] (202) 659-8124
consulate(s) general: Boston, Chicago, Denver, Houston, Los Angeles,
Miami, New York, Paterson (New Jersey), San Francisco, Washington
(DC)
1.8 million (2000)
504,995 (1998)
10 (2000)
3 million (2002)
.pe
0.4% (2001 est.)
53,000 (2001 est.)
3,900 (2001 est.)
PEN
46.2 (1996)
95,100 bbl/day (2001 est.)
161,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 23.5 years
male: 23.2 years
female: 23.7 years (2002)
614.7 million bbl (37257)
245.1 billion cu m (37257)
370 million cu m (2001 est.)
370 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','f5037f99001e57f85cc6bc76e8ad3aba2f16ea9d6a0c61f0932c07751c5584e3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a90497561a84bdc6253d6328f188edd644833fa986acdcfc521d70612613b271',2003,'PH','Philippines','communications',962,'mostly mountains with narrow to extensive coastal
lowlands
Pitcairn Islands
rugged volcanic formation; rocky coastline with
cliffs
3.29 children born/woman (2003 est.)
Pitcairn Islands
NA children born/woman (2003 est.)
republic
Pitcairn Islands
NA
10.2% (2002)
Pitcairn Islands
NA%
conventional long form: Republic of the Philippines
conventional short form: Philippines
local long form: Republika ng Pilipinas
local short form: Pilipinas
Pitcairn Islands
conventional long form: Pitcairn, Henderson, Ducie,
and Oeno Islands
conventional short form: Pitcairn Islands
Southeastern Asia, archipelago between the Philippine
Sea and the South China Sea, east of Vietnam
Pitcairn Islands
Oceania, islands in the South Pacific Ocean, about
midway between Peru and New Zealand
Southeast Asia
Pitcairn Islands
Oceania
15,500 sq km (1998 est.)
Pitcairn Islands
NA sq km
total: 300,000 sq km
land: 298,170 sq km
water: 1,830 sq km
Pitcairn Islands
total: 47 sq km
land: 47 sq km
water: 0 sq km
chief of mission: Ambassador Albert DEL ROSARIO
chancery: 1600 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 467-9300
FAX: [1] (202) 328-7614
consulate(s) general: Chicago, Honolulu, Los Angeles, New York, San
Francisco, San Jose (Northern Mariana Islands), Tamuning (Guam)
consulate(s): San Diego
Pitcairn Islands
none (overseas territory of the UK)
6.98 million (2001)
Pitcairn Islands
1 (there are 17 telephones on one party line) (1997)
11.35 million (2001)
33 (2000)
Pitcairn Islands
NA
4.5 million (2002)
Pitcairn Islands
NA
.ph
Pitcairn Islands
.pn
less than 0.1% (2001 est.)
Pitcairn Islands
NA%
9,400 (2001 est.)
Pitcairn Islands
NA
720 (2001 est.)
Pitcairn Islands
NA
PHP
Pitcairn Islands
NZD
46.2 (1997)
8,460 bbl/day (2001 est.)
343,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 21.8 years
male: 21.3 years
female: 22.4 years (2002)
164 million bbl (37257)
104.6 billion cu m (37257)
10 million cu m (2001 est.)
10 million cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','471a23bc5222de48b0c15f7e48dbf18950aea070c3053cc8cf9b812af2968ea3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f96422800b0c91c0380200428d604da42dcf7af47352d61949c5b05f0bdc35a',2003,'PL','Poland','communications',963,'mostly flat plain; mountains along southern border
1.37 children born/woman (2003 est.)
republic
18.1% (2002)
conventional long form: Republic of Poland
conventional short form: Poland
local long form: Rzeczpospolita Polska
local short form: Polska
Central Europe, east of Germany
Europe
1,000 sq km (1998 est.)
total: 312,685 sq km
land: 304,465 sq km
water: 8,220 sq km
chief of mission: Ambassador Przemyslaw GRUDZINSKI
chancery: 2640 16th Street NW, Washington, DC 20009
telephone: [1] (202) 234-3800 through 3802
FAX: [1] (202) 328-6270
consulate(s) general: Chicago, Los Angeles, and New York
8.07 million (1998)
13 million (2002)
19 (2000)
6.4 million (2001)
.pl
0.1% - note: no country specific models provided (2001 est.)
NA
100 (2001 est.)
PLN
31.6 (1998)
17,180 bbl/day (2001 est.)
424,100 bbl/day (2001 est.)
413,700 bbl/day (2001)
53,000 bbl/day (2001)
total: 36 years
male: 34.1 years
female: 38 years (2002)
116.4 million bbl (37257)
154.4 billion cu m (37257)
5.471 billion cu m (2001 est.)
13.85 billion cu m (2001 est.)
8.782 billion cu m (2001 est.)
41 million cu m (2001 est.)','5685d51b0973d97a87f833f0aa7ff4810bacfd5300cbed2a71560835547e6b6d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('defd140201f5793ea4b1aecf621a48885a928c62e81f1d80ffff4fc1dcf4fb72',2003,'PT','Portugal','communications',964,'mountainous north of the Tagus River, rolling plains in
south
1.49 children born/woman (2003 est.)
parliamentary democracy
4.7% (2002 est.)
conventional long form: Portuguese Republic
conventional short form: Portugal
local long form: Republica Portuguesa
local short form: Portugal
Southwestern Europe, bordering the North Atlantic Ocean,
west of Spain
Europe
6,320 sq km (1998 est.)
total: 92,391 sq km
land: 91,951 sq km
water: 440 sq km
note: includes Azores and Madeira Islands
chief of mission: Ambassador Pedro Manuel Dos Reis Alves
CATARINO
chancery: 2125 Kalorama Road NW, Washington, DC 20008
telephone: [1] (202) 328-8610
FAX: [1] (202) 462-3726
consulate(s) general: Boston, New York, Newark (New Jersey), and San
Francisco
consulate(s): Los Angeles, New Bedford (Massachusetts), Providence
(Rhode Island)
5.3 million (yearend 1998)
3,074,194 (1999)
16 (2000)
4.4 million (2002)
.pt
0.5% (2001 est.)
27,000 (2001 est.)
1,000 (2001 est.)
EUR
35.6 (1994-95)
0 bbl/day (2001 est.)
339,800 bbl/day (2001 est.)
357,300 bbl/day (2001)
28,830 bbl/day (2001)
total: 37.6 years
male: 35.8 years
female: 39.3 years (2002)
0 cu m (2001 est.)
2.542 billion cu m (2001 est.)
2.553 billion cu m (2001 est.)
0 cu m (2001 est.)','73bd6f3ab0261698548d406ca0d6bde63bbc3f59bf283c942ca43aa064f4b9c3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce517b1e08873ef1bcc39fa582772a27c90b9c7cbc6f6fe8e8042f8ee9e34e0b',2003,'PR','Puerto Rico','communications',965,'mostly mountains, with coastal plain belt in north;
mountains precipitous to sea on west coast; sandy beaches along most
coastal areas
2.02 children born/woman (2003 est.)
commonwealth
12% (2002)
defense is the responsibility of the US
Reunion
defense is the responsibility of France
Saint Helena
defense is the responsibility of the UK
conventional long form: Commonwealth of Puerto Rico
conventional short form: Puerto Rico
Caribbean, island between the Caribbean Sea and the
North Atlantic Ocean, east of the Dominican Republic
Central America and the Caribbean
400 sq km (1998 est.)
total: 9,104 sq km
land: 8,959 sq km
water: 145 sq km
none (commonwealth associated with the US)
1.322 million (1997)
169,265 (1996)
76 (2000)
600,000 (2002)
.pr
NA%
7,397 (1997)
NA
USD
0 bbl/day (2001 est.)
190,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 33.3 years
male: 31.6 years
female: 34.9 years (2002)
0 cu m (2001 est.)
630 million cu m (2001 est.)
630 million cu m (2001 est.)
0 cu m (2001 est.)','1532865623f097bfafa75024078a5d4827ed87d55ab6b8807223b87f950dfc97','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('853bfc294b37acc0e7ac6c15bce25b4b4dc17d6e3f4a80581a94c4b61ec01bc6',2003,'QA','Qatar','communications',966,'mostly flat and barren desert covered with loose sand and
gravel
Reunion
mostly rugged and mountainous; fertile lowlands along coast
3.02 children born/woman (2003 est.)
Reunion
2.53 children born/woman (2003 est.)
traditional monarchy
Reunion
NA
2.7% (2001)
Reunion
36% (1999 est.)
conventional long form: State of Qatar
conventional short form: Qatar
local long form: Dawlat Qatar
local short form: Qatar
note: closest approximation of the native pronunciation falls
between cutter and gutter, but not like guitar
Reunion
conventional long form: Department of Reunion
conventional short form: Reunion
local long form: none
local short form: Ile de la Reunion
former: Bourbon Island
Middle East, peninsula bordering the Persian Gulf and Saudi
Arabia
Reunion
Southern Africa, island in the Indian Ocean, east of
Middle East
Reunion
World
130 sq km (1998 est.)
Reunion
120 sq km (1998 est.)
total: 11,437 sq km
land: 11,437 sq km
water: 0 sq km
Reunion
total: 2,517 sq km
land: 2,507 sq km
water: 10 sq km
chief of mission: Ambassador Badr Umar al-DAFA
chancery: 4200 Wisconsin Avenue NW, Washington, DC 20016
telephone: [1] (202) 274-1600
FAX: [1] (202) 237-0061
consulate(s) general: Houston
Reunion
none (overseas department of France)
142,000 (1997)
Reunion
268,500 (1999)
43,476 (1997)
Reunion
197,000 (September 2000)
1 (2000)
Reunion
1 (2000)
75,000 (2001)
Reunion
10,000 (2000)
.qa
Reunion
.re
0.09% (2001 est.)
Reunion
NA%
NA
Reunion
NA
NA
Reunion
NA
QAR
Reunion
EUR
864,200 bbl/day (2001 est.)
Reunion
0 bbl/day (2001 est.)
29,000 bbl/day (2001 est.)
Reunion
18,000 bbl/day (2001 est.)
NA (2001)
Reunion
NA (2001)
NA (2001)
Reunion
NA (2001)
total: 31.2 years
male: 36.4 years
female: 21.6 years (2002)
Reunion
total: 26.4 years
male: 25.2 years
female: 27.5 years (2002)
14.51 billion bbl (37257)
17.93 trillion cu m (37257)
32.4 billion cu m (2001 est.)
15.86 billion cu m (2001 est.)
0 cu m (2001 est.)
16.54 billion cu m (2001 est.)','2b0f91518a151b02fc9ff76f43c1d5a7238981b1af292c72f1bb0b887153e5b9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9bcffef04795d264afad54a8827e24f16a92394705a0d2f2bb621b91872b7ad',2003,'RO','Romania','communications',967,'central Transylvanian Basin is separated from the Plain of
Moldavia on the east by the Carpathian Mountains and separated from
the Walachian Plain on the south by the Transylvanian Alps
Russia
broad plain with low hills west of Urals; vast coniferous
forest and tundra in Siberia; uplands and mountains along southern
border regions
1.36 children born/woman (2003 est.)
Russia
1.33 children born/woman (2003 est.)
republic
Russia
federation
8.3% (2002)
Russia
7.9% plus considerable underemployment (2002)
conventional long form: none
conventional short form: Romania
local long form: none
local short form: Romania
Russia
conventional long form: Russian Federation
conventional short form: Russia
local long form: Rossiyskaya Federatsiya
local short form: Rossiya
former: Russian Empire, Russian Soviet Federative Socialist Republic
Southeastern Europe, bordering the Black Sea, between
Bulgaria and Ukraine
Russia
Northern Asia (that part west of the Urals is included with
Europe), bordering the Arctic Ocean, between Europe and the North
Pacific Ocean
Europe
Russia
Asia
28,800 sq km (1998 est.)
Russia
46,630 sq km (1998 est.)
total: 237,500 sq km
land: 230,340 sq km
water: 7,160 sq km
Russia
total: 17,075,200 sq km
land: 16,995,800 sq km
water: 79,400 sq km
chief of mission: Ambassador Sorin Dumitru DUCARU
chancery: 1607 23rd Street NW, Washington, DC 20008
telephone: [1] (202) 332-4846, 4848, 4851
FAX: [1] (202) 232-4748
consulate(s) general: Chicago, Los Angeles, and New York
Russia
chief of mission: Ambassador Yuriy Viktorovich USHAKOV
chancery: 2650 Wisconsin Avenue NW, Washington, DC 20007
telephone: [1] (202) 298-5700, 5701, 5704, 5708
FAX: [1] (202) 298-5735
consulate(s) general: New York, San Francisco, and Seattle
3.777 million (1997)
Russia
30 million (1998)
645,500 (1999)
Russia
19 million (January 2003)
38 (2000)
Russia
300 (June 2000)
1 million (2002)
Russia
18 million (2002)
.ro
Russia
.ru; Russia also has responsibility for a legacy domain ".su"
that was allocated to the Soviet Union, its legal status and
ownership are contested by the Russian Government, ICANN, and
several Russian commercial entities
less than 0.1% (2001 est.)
Russia
0.9% (2001 est.)
6,500 (2001 est.)
Russia
700,000 (2001 est.)
350 (2001 est.)
Russia
9,000 (2001 est.)
ROL
Russia
RUR
31.1 (1998)
Russia
39.9 (2001)
127,500 bbl/day (2001 est.)
Russia
7.286 million bbl/day (2001 est.)
215,000 bbl/day (2001 est.)
Russia
2.595 million bbl/day (2001 est.)
NA (2001)
Russia
NA (2001)
NA (2001)
Russia
NA (2001)
total: 35.4 years
male: 34 years
female: 37.1 years (2002)
Russia
total: 37.6 years
male: 34.7 years
female: 40.3 years (2002)
1.055 billion bbl (37257)
Russia
51.22 billion bbl (37257)
111.1 billion cu m (37257)
Russia
47.86 trillion cu m (37257)
14.3 billion cu m (2001 est.)
Russia
580.8 billion cu m (2001 est.)
19.7 billion cu m (2001 est.)
Russia
408.1 billion cu m (2001 est.)
5.4 billion cu m (2001 est.)
Russia
32.7 billion cu m (2001 est.)
0 cu m (2001 est.)
Russia
205.4 billion cu m (2001 est.)','a3632f00fde130691a993b89e7ce8b291681cd2a733a7ca8906598f6d7c14d37','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b263433bf2e819a8d5f9ef7b5a4ec41f786013ba062fc2a7b3bf76345c19f6d',2003,'RW','Rwanda','communications',968,'mostly grassy uplands and hills; relief is mountainous with
altitude declining from west to east
Saint Helena
Saint Helena - rugged, volcanic; small scattered
plateaus and plains
note: the other islands of the group have a volcanic origin
5.6 children born/woman (2003 est.)
Saint Helena
1.54 children born/woman (2003 est.)
republic; presidential, multiparty system
Saint Helena
NA
NA%
Saint Helena
14% (1998 est.)
conventional long form: Rwandese Republic
conventional short form: Rwanda
local long form: Republika y''u Rwanda
local short form: Rwanda
former: Ruanda
Saint Helena
conventional long form: none
conventional short form: Saint Helena
Central Africa, east of Democratic Republic of the Congo
Saint Helena
islands in the South Atlantic Ocean, about midway
between South America and Africa
Africa
Saint Helena
Africa
40 sq km (1998 est.)
Saint Helena
NA sq km
total: 26,338 sq km
land: 24,948 sq km
water: 1,390 sq km
Saint Helena
total: 410 sq km
land: 410 sq km
water: 0 sq km
note: includes Saint Helena Island, Ascension, and the island group
of Tristan da Cunha, which consists of Tristan da Cunha Island,
Gough Island, Inaccessible Island, and the three Nightingale Islands
chief of mission: Ambassador Zac NSENGA
chancery: 1714 New Hampshire Ave. NW, Washington, DC 20009
telephone: [1] (202) 232-2882
FAX: [1] (202) 232-4544
Saint Helena
none (overseas territory of the UK)
600,000 note - 90% in Kigali (2002)
Saint Helena
2,000 (1997)
81,000 (2001)
note: Rwanda has mobile cellular service between Kigali and several
prefecture capitals (2002)
Saint Helena
0 (1997)
2 (2002)
Saint Helena
1 (2000)
20,000 (2002)
Saint Helena
NA
.rw
Saint Helena
.sh
8.9% (2001 est.)
Saint Helena
NA%
500,000 (2001 est.)
Saint Helena
NA
49,000 (2001 est.)
Saint Helena
NA
RWF
Saint Helena
SHP
28.9 (1985)
0 bbl/day (2001 est.)
Saint Helena
0 bbl/day (2001 est.)
5,300 bbl/day (2001 est.)
Saint Helena
200 bbl/day (2001 est.)
NA (2001)
Saint Helena
NA (2001)
NA (2001)
Saint Helena
NA (2001)
total: 18.1 years
male: 17.8 years
female: 18.3 years (2002)
Saint Helena
total: 34.2 years
male: 34.4 years
female: 33.9 years (2002)
0 bbl (37257)
28.32 billion cu m (37257)','5211c41c6ca51370a5fd6275dfedebb46bddf4865ee46f01df8840191b7b3e85','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81aea004990b6849c3436b267bc92697de24d0366219f8fb0d55b9f0d256c02b',2003,'KN','Saint Kitts and Nevis','communications',969,'volcanic with mountainous interiors
2.37 children born/woman (2003 est.)
constitutional monarchy with Westminster-style
parliament
4.5% (1997)
conventional long form: Federation of Saint
Kitts and Nevis
conventional short form: Saint Kitts and Nevis
former: Federation of Saint Christopher and Nevis
Caribbean, islands in the Caribbean Sea, about
one-third of the way from Puerto Rico to Trinidad and Tobago
Central America and the Caribbean
NA sq km
total: 261 sq km (Saint Kitts 168 sq km; Nevis
93 sq km)
land: 261 sq km
water: 0 sq km
chief of mission: Ambassador Dr. Izben
Cordinal WILLIAMS
chancery: 3216 New Mexico Avenue NW, Washington, DC 20016
telephone: [1] (202) 686-2636
FAX: [1] (202) 686-5740
consulate(s) general: New York
17,000 (1997)
205 (1997)
16 (2000)
2,000 (2000)
.kn
NA%
NA
NA
XCD
0 bbl/day (2001 est.)
710 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 27.1 years
male: 26.3 years
female: 27.9 years (2002)','07248c226c021e14b98cda4b28b6478ca6fda1133dcd371305fcaafc4f5ca67b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3cfdd15ee842b2658d0e1cf8e5aa79b1b2ed1064a125254eb07217e833a8a08',2003,'LC','Saint Lucia','communications',970,'volcanic and mountainous with some broad, fertile valleys
2.29 children born/woman (2003 est.)
Westminster-style parliamentary democracy
16.5% (1997 est.)
conventional long form: none
conventional short form: Saint Lucia
Caribbean, island between the Caribbean Sea and North
Atlantic Ocean, north of Trinidad and Tobago
Central America and the Caribbean
30 sq km (1998 est.)
total: 616 sq km
land: 606 sq km
water: 10 sq km
chief of mission: Ambassador Sonia Merlyn JOHNNY
chancery: 3216 New Mexico Avenue NW, Washington, DC 20016
telephone: [1] (202) 364-6792 through 6795
FAX: [1] (202) 364-6723
consulate(s) general: Miami and New York
37,000 (1997)
1,600 (1997)
15 (2000)
3,000 (2000)
.lc
NA%
NA
NA
XCD
0 bbl/day (2001 est.)
2,400 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 24.1 years
male: 23.3 years
female: 24.9 years (2002)','4f78579b18b126a81b15f4eb950d2a6d3301908b04d6f12b5cdedd40361aa5d5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a805722b85bf9f9eeb2daa88485e39e851ece581a8c9095f31f1ed32e03ff5a7',2003,'PM','Saint Pierre and Miquelon','communications',971,'mostly barren rock
2.07 children born/woman (2003 est.)
NA
9.8% (1997)
defense is the responsibility of France
conventional long form: Territorial
Collectivity of Saint Pierre and Miquelon
conventional short form: Saint Pierre and Miquelon
local long form: Departement de Saint-Pierre et Miquelon
local short form: Saint-Pierre et Miquelon
Northern North America, islands in the
North Atlantic Ocean, south of Newfoundland (Canada)
North America
NA sq km
total: 242 sq km
land: 242 sq km
water: 0 sq km
note: includes eight small islands in the Saint Pierre and the
Miquelon groups
none (territorial collectivity of France)
4,000 (1997)
0 (1994)
1 (2000)
NA
.pm
NA%
NA
NA
EUR
0 bbl/day (2001 est.)
600 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 32.9 years
male: 32.7 years
female: 33.1 years (2002)','eee308e7e9fac00edd2131490f3b1fae937fe199b4d8ee55252be595ce8bd6ba','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fb092d7802b970d853c7b611ae94a013ae6dd6b70c9519679e800d6ebcbaba8',2003,'VC','Saint Vincent and the Grenadines','communications',972,'volcanic, mountainous
1.95 children born/woman (2003 est.)
parliamentary democracy;
independent sovereign state within the Commonwealth
22% (1997 est.)
conventional long form: none
conventional short form: Saint Vincent and the Grenadines
Caribbean, islands between the
Caribbean Sea and North Atlantic Ocean, north of Trinidad and Tobago
Central America and the Caribbean
10 sq km (1998 est.)
total: 389 sq km (Saint Vincent 344
sq km)
land: 389 sq km
water: 0 sq km
chief of mission: Ambassador
Ellsworth I. A. JOHN
chancery: 3216 New Mexico Avenue NW, Washington, DC 20016
telephone: [1] (202) 364-6730
FAX: [1] (202) 364-6736
consulate(s) general: New York
20,500 (1998)
NA
15 (2000)
3,500 (2001)
.vc
NA%
NA
NA
XCD
0 bbl/day (2001 est.)
1,250 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 25.3 years
male: 25.1 years
female: 25.5 years (2002)','8a7d99681c9c50a2d2a519729d4483ee7c1625a66323e6701ed64b4f2d48d2d7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba600990a004cd7c2d3b3236de060786f614008a12d9ab646c876ada0d0e2fad',2003,'WS','Samoa','communications',973,'narrow coastal plain with volcanic, rocky, rugged mountains in
interior
3.21 children born/woman (2003 est.)
constitutional monarchy under native chief
NA%; note - substantial underemployment
Samoa has no formal defense structure or regular armed forces;
informal defense ties exist with NZ, which is required to consider
any Samoan request for assistance under the 1962 Treaty of Friendship
conventional long form: Independent State of Samoa
conventional short form: Samoa
former: Western Samoa
Oceania, group of islands in the South Pacific Ocean, about
one-half of the way from Hawaii to New Zealand
Oceania
NA sq km
total: 2,944 sq km
land: 2,934 sq km
water: 10 sq km
chief of mission: Ambassador Feturi ELISAIA
chancery: 800 Second Avenue, Suite 400D, New York, NY 10017
telephone: [1] (212) 599-6196, 6197
FAX: [1] (212) 599-0797
8,183 (1998)
1,545 (February 1998)
2 (2000)
3,000 (2002)
.ws
NA%
12
3
SAT (former WST code is still in wide use)
0 bbl/day (2001 est.)
1,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 23.7 years
male: 26.3 years
female: 20.2 years (2002)','1728785aa5d5224ee73827481eae9d1091f06a74025cd32c6f33fa3b8656e958','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe68ae7d6706811e63f915d2c5edec1a77c85fb2e8a38183ae3416b02dd4293d',2003,'SM','San Marino','communications',974,'rugged mountains
1.31 children born/woman (2003 est.)
independent republic
2.6% (2001)
conventional long form: Republic of San Marino
conventional short form: San Marino
local long form: Repubblica di San Marino
local short form: San Marino
Southern Europe, an enclave in central Italy
Europe
NA sq km
total: 61.2 sq km
land: 61.2 sq km
water: 0 sq km
San Marino does not have an embassy in the US
honorary consulate(s) general: Washington, DC and New York
honorary consulate(s): Detroit and Honolulu
18,000 (1998)
3,010 (1998)
2 (2000)
NA
.sm
NA%
NA
NA
EUR
total: 39.6 years
male: 39.2 years
female: 40 years (2002)','3f12310eb09aa0601a10faf3be7fe8a445cdcab12651f75fd1d7d1b4c13cd4d2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('740cda430abf978c3670088983afbeb37978d8307cfdafee38917b8a8adcf63d',2003,'ST','Sao Tome and Principe','communications',975,'volcanic, mountainous
5.88 children born/woman (2003 est.)
republic
NA%
conventional long form: Democratic Republic of
conventional short form: Sao Tome and Principe
local long form: Republica Democratica de Sao Tome e Principe
local short form: Sao Tome e Principe
Western Africa, islands in the Gulf of Guinea,
straddling the Equator, west of Gabon
Africa
100 sq km (1998 est.)
total: 1,001 sq km
land: 1,001 sq km
water: 0 sq km
Sao Tome and Principe does not have an embassy
in the US, but does have a Permanent Mission to the UN, headed by
First Secretary Domingos Augusto FERREIRA, located at 400 Park
Avenue, 7th Floor, New York, NY 10022, telephone [1] (212) 317-0580
4,600 (2000)
6,942 (1997)
1 (2002)
9,000 (2002)
.st
NA%
NA
NA
STD
0 bbl/day (2001 est.)
700 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 16.1 years
male: 15.5 years
female: 16.7 years (2002)','cd43a420107b0ddff8cf260db2965a7e69e66277c478a809d5c3dfb28bd575a4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f2718a36295c1ca0fdb2f2be19570aba1f9140b1c070f3adbac73de397f6ce3',2003,'SA','Saudi Arabia','communications',976,'mostly uninhabited, sandy desert
6.15 children born/woman (2003 est.)
monarchy
25% (2002)
conventional long form: Kingdom of Saudi Arabia
conventional short form: Saudi Arabia
local long form: Al Mamlakah al Arabiyah as Suudiyah
local short form: Al Arabiyah as Suudiyah
Middle East, bordering the Persian Gulf and the Red
Sea, north of Yemen
Middle East
16,200 sq km (1998 est.)
total: 1,960,582 sq km
land: 1,960,582 sq km
water: 0 sq km
chief of mission: Ambassador BANDAR bin Sultan bin Abd
al-Aziz Al Saud
chancery: 601 New Hampshire Avenue NW, Washington, DC 20037
telephone: [1] (202) 342-3800
consulate(s) general: Houston, Los Angeles, and New York
3.9 million (2002 est.)
2.9 million (2002 est.)
22 (2003)
1.453 million (2002)
.sa
0.01% (2001 est.)
NA
NA
SAR
8.711 million bbl/day (2001 est.)
1.452 million bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.8 years
male: 20.9 years
female: 16.8 years (2002)
261.7 billion bbl (37257)
Serbia and Montenegro
38.75 million bbl (37257)
6.339 trillion cu m (37257)
Serbia and Montenegro
24.07 billion cu m (37257)
53.69 billion cu m (2001 est.)
53.69 billion cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','908df29ca08e63bdbfadc8a7dbcc3132e46e4e32afeb14b7e3a45519f4f880fc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29134584ee12caf93bf849f52310307afe94cb6edbb16a5b46e542bc639e666c',2003,'SN','Senegal','communications',977,'generally low, rolling, plains rising to foothills in
southeast
Serbia and Montenegro
extremely varied; to the north, rich fertile
plains; to the east, limestone ranges and basins; to the southeast,
ancient mountains and hills; to the southwest, extremely high
shoreline with no islands off the coast
4.93 children born/woman (2003 est.)
Serbia and Montenegro
1.77 children born/woman (2003 est.)
republic under multiparty democratic rule
Serbia and Montenegro
republic
48% (urban youth 40%) (2001 est.)
Serbia and Montenegro
32% (2002 est.)
conventional long form: Republic of Senegal
conventional short form: Senegal
local long form: Republique du Senegal
local short form: Senegal
Serbia and Montenegro
conventional long form: Serbia and Montenegro
conventional short form: none
local long form: Srbija i Crna Gora
local short form: none
Gaza Strip
Middle East, bordering the Mediterranean Sea, between
Egypt and Israel
Western Africa, bordering the North Atlantic Ocean, between
Guinea-Bissau and Mauritania
Serbia and Montenegro
Southeastern Europe, bordering the Adriatic
Sea, between Albania and Bosnia and Herzegovina
Africa
Serbia and Montenegro
Europe
710 sq km (1998 est.)
Serbia and Montenegro
570 sq km
total: 196,190 sq km
land: 192,000 sq km
water: 4,190 sq km
Serbia and Montenegro
total: 102,350 sq km
land: 102,136 sq km
water: 214 sq km
chief of mission: Ambassador Amadou Lamine BA
chancery: 2112 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 234-0540
FAX: [1] (202) 332-6315
consulate(s) general: New York
Serbia and Montenegro
chief of mission: Ambassador Ivan VUJACIC
chancery: 2134 Kalorama Road NW, Washington, DC 20008
telephone: [1] (202) 332-0333
FAX: [1] (202) 332-3933
consulate(s) general: Chicago
234,916 (2001)
Serbia and Montenegro
2.017 million (1995)
373,965 (2001)
Serbia and Montenegro
87,000 (1997)
1 (2002)
Serbia and Montenegro
9 (2000)
100,000 (2002)
Serbia and Montenegro
400,000 (2001)
.sn
Serbia and Montenegro
.yu
0.5% (2001 est.)
Serbia and Montenegro
0.2% (2001 est.)
27,000 (2001 est.)
Serbia and Montenegro
10,000 (2001 est.)
2,500 (2001 est.)
Serbia and Montenegro
less than 100 (2001 est.)
XOF
Serbia and Montenegro
YUM
41.3 (1995)
0 bbl/day (2001 est.)
Serbia and Montenegro
15,000 bbl/day (2001 est.)
31,000 bbl/day (2001 est.)
Serbia and Montenegro
64,000 bbl/day (2001 est.)
NA (2001)
Serbia and Montenegro
NA (2001)
NA (2001)
Serbia and Montenegro
NA (2001)
total: 17.8 years
male: 17.2 years
female: 18.4 years (2002)
Serbia and Montenegro
total: 36.2 years
male: 34.3 years
female: 37.9 years (2002)
50 million cu m (2001 est.)
Serbia and Montenegro
602 million cu m (2001 est.)
50 million cu m (2001 est.)
Serbia and Montenegro
602 million cu m (2001 est.)
0 cu m (2001 est.)
Serbia and Montenegro
0 cu m (2001 est.)
0 cu m (2001 est.)
Serbia and Montenegro
0 cu m (2001 est.)','d4f00e5f92e8c60ed7a76293346a15f6c7d190c03624164e08d9b012261aa03f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d89477cbcfc0fb7dadf92e3e9badac5b9db0aad6a5af6ffdc8bbea0f123ef3c8',2003,'SC','Seychelles','communications',978,'Mahe Group is granitic, narrow coastal strip, rocky,
hilly; others are coral, flat, elevated reefs
1.79 children born/woman (2003 est.)
republic
NA%
conventional long form: Republic of Seychelles
conventional short form: Seychelles
Eastern Africa, group of islands in the Indian Ocean,
northeast of Madagascar
Africa
NA sq km
total: 455 sq km
land: 455 sq km
water: 0 sq km
chief of mission: Ambassador Claude Sylvestre MOREL
chancery: 800 Second Avenue, Suite 400C, New York, NY 10017
telephone: [1] (212) 972-1785
FAX: [1] (212) 972-1786
19,635 (1997)
16,316 (1999)
1 (2000)
9,000 (2002)
.sc
NA%
NA
NA
SCR
0 bbl/day (2001 est.)
4,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 26.9 years
male: 25.8 years
female: 27.9 years (2002)
industrial countries: another term for the developed countries; see
developed countries (DCs)
Inter-American Development Bank (IADB): note - also known as Banco
Interamericano de Desarrollo (BID)
established - 8 April 1959; effective - 30 December 1959
aim - to promote economic and social development in Latin America
members - (46) Argentina, Austria, The Bahamas, Barbados, Belgium,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Croatia,
Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France,
Germany, Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica,
Japan, Mexico, Netherlands, Nicaragua, Norway, Panama, Paraguay, Peru,
Portugal, Slovenia, Spain, Suriname, Sweden, Switzerland, Trinidad and
Tobago, UK, US, Uruguay, Venezuela
Inter-Governmental Authority on Development (IGAD): note - formerly
known as Inter-Governmental Authority on Drought and Development
(IGADD)
established - 15-16 January 1986 as the Inter-Governmental Authority on
Drought and Development; revitalized - 21 March 1996 as the Inter-
Governmental Authority on Development
aim - to promote a social, economic, and scientific community among its
members
members - (7) Djibouti, Eritrea, Ethiopia, Kenya, Somalia, Sudan,','989aeecd97fc063523f0a143de52320c18639336f4bb67606b3546d4c05160dd','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7579daf793b49ca6c701d0afc37f417133e7f1d1c19dba528507847fac9d0dce',2003,'SL','Sierra Leone','communications',979,'coastal belt of mangrove swamps, wooded hill country,
upland plateau, mountains in east
5.86 children born/woman (2003 est.)
constitutional democracy
NA%
conventional long form: Republic of Sierra Leone
conventional short form: Sierra Leone
Western Africa, bordering the North Atlantic Ocean,
between Guinea and Liberia
Africa
290 sq km (1998 est.)
total: 71,740 sq km
land: 71,620 sq km
water: 120 sq km
chief of mission: Ambassador Ibrahim M. KAMARA
chancery: 1701 19th Street NW, Washington, DC 20009
telephone: [1] (202) 939-9261 through 9263
FAX: [1] (202) 483-1793
25,000 (2001)
30,000 (2001)
1 (2001)
20,000 (2001)
.sl
7% (2001 est.)
170,000 (2001 est.)
11,000 (2001 est.)
SLL
62.9 (1989)
0 bbl/day (2001 est.)
6,500 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 17.5 years
male: 17.2 years
female: 17.8 years (2002)','07cdc0a1ece7eef477862c893488023a8315f943d93f9ea1be334d14b9f9ff39','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f7d5a9aa4cf472d1ace4cda0f6df1ea71e51b80e5ff9ac6e3545beed375e8a3',2003,'SG','Singapore','communications',980,'lowland; gently undulating central plateau contains water
catchment area and nature preserve
1.24 children born/woman (2003 est.)
parliamentary republic
4.6% (2002 est.)
conventional long form: Republic of Singapore
conventional short form: Singapore
Southeastern Asia, islands between Malaysia and Indonesia
Southeast Asia
NA sq km
total: 692.7 sq km
land: 682.7 sq km
water: 10 sq km
chief of mission: Ambassador CHAN Heng Chee
chancery: 3501 International Place NW, Washington, DC 20008
telephone: [1] (202) 537-3100
FAX: [1] (202) 537-0876
consulate(s) general: San Francisco
consulate(s): New York
1.95 million (2000)
2.74 million (2000)
9 (2000)
2.31 million (2002)
.sg
0.2% (2001 est.)
3,400 (2001 est.)
140 (2001 est.)
SGD
0 bbl/day (2001 est.)
700,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 34.5 years
male: 34.3 years
female: 34.8 years (2002)
0 cu m (2001 est.)
2.5 billion cu m (2001 est.)
2.5 billion cu m (2001 est.)
0 cu m (2001 est.)','68fc36dbc53cac94bffa5cee79677637506fa21738f61afc6b249e93d576b2aa','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18d2a17b2298a3aae4a7243d60f5ebad29bbfd29287e6ba0bd87244482a05bce',2003,'SK','Slovakia','communications',981,'rugged mountains in the central and northern part and
lowlands in the south
1.25 children born/woman (2003 est.)
parliamentary democracy
17.2% (2002 est.)
conventional long form: Slovak Republic
conventional short form: Slovakia
local long form: Slovenska Republika
local short form: Slovensko
Central Europe, south of Poland
Europe
1,740 sq km (1998 est.)
total: 48,845 sq km
land: 48,800 sq km
water: 45 sq km
chief of mission: Ambassador Rastislav KACER
chancery: 3523 International Court NW, Washington, DC 20008
telephone: [1] (202) 237-1054
FAX: [1] (202) 237-6438
1,934,558 (1998)
736,662 (April 1999)
6 (2000)
700,000 (2000)
.sk
less than 0.1% (2001 est.)
less than 100 (1999 est.)
less than 100 (2001 est.)
SKK
26.3 (1996)
1,000 bbl/day (2001 est.)
82,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 35 years
male: 33.3 years
female: 36.7 years (2002)
4.5 million bbl (37257)
7.504 billion cu m (37257)
292 million cu m (2001 est.)
7.932 billion cu m (2001 est.)
7.205 billion cu m (2001 est.)
0 cu m (2001 est.)','63fe00b4d4b1b433517394ccfa877ffb2256e3179ccf867f9c237be0cfcc11e7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15f028929ed4068cf29a6e323044741058ecac2e9944d81f197beb1d704fad75',2003,'SI','Slovenia','communications',982,'a short coastal strip on the Adriatic, an alpine mountain
region adjacent to Italy and Austria, mixed mountains and valleys
with numerous rivers to the east
1.27 children born/woman (2003 est.)
parliamentary democratic republic
11% (2002 est.)
conventional long form: Republic of Slovenia
conventional short form: Slovenia
local long form: Republika Slovenija
local short form: Slovenija
Central Europe, eastern Alps bordering the Adriatic Sea,
between Austria and Croatia
Europe
20 sq km (1998 est.)
total: 20,273 sq km
land: 20,151 sq km
water: 122 sq km
chief of mission: Ambassador Davorin KRACUN
chancery: 1525 New Hampshire Avenue NW, Washington, DC 20036
telephone: [1] (202) 667-5363
FAX: [1] (202) 667-4563
consulate(s) general: New York and Cleveland
722,000 (1997)
1 million (2000)
11 (2000)
600,000 (2001)
.si
less than 0.1% (2001 est.)
280 (2001 est.)
less than 100 (2001 est.)
SIT
28.4 (1998)
20 bbl/day NA bbl/day (2001 est.)
53,300 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 38.6 years
male: 37.1 years
female: 40.2 years (2002)
0 cu m (2001 est.)
1.04 billion cu m (2001 est.)
1.04 billion cu m (2001 est.)
0 cu m (2001 est.)','cc5b4932b7ca9b87981c42bf2b53c6d53a66571c94cfa24c713b11f9a1abfac8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a10a0a99031a6a47ce8ae3e0ae1fece95c114c6b4af7d24dd4937a8dd15f8506',2003,'SB','Solomon Islands','communications',983,'mostly rugged mountains with some low coral atolls
4.34 children born/woman (2003 est.)
parliamentary democracy tending toward anarchy
NA%
conventional long form: none
conventional short form: Solomon Islands
former: British Solomon Islands
Oceania, group of islands in the South Pacific
Ocean, east of Papua New Guinea
Oceania
NA sq km
total: 28,450 sq km
land: 27,540 sq km
water: 910 sq km
chief of mission: Ambassador (vacant); Charge
d''Affaires Colin BECK
chancery: 800 Second Avenue, Suite 400L, New York, NY 10017
telephone: [1] (212) 599-6192, 6193
FAX: [1] (212) 661-8925
8,000 (1997)
658 (1997)
1 (2000)
8,400 (2002)
.sb
NA%
NA
NA
SBD
0 bbl/day (2001 est.)
1,250 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 18.2 years
male: 18.1 years
female: 18.3 years (2002)','0a5ba6d807dd5d408b927c6ed9939dd859ecf279dcf7296dd3453496dde518c8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68e183f4c479bddcd45015d56cc787ebbead5747256e6493721b35d01af29fdd',2003,'SO','Somalia','communications',984,'mostly flat to undulating plateau rising to hills in north
6.98 children born/woman (2003 est.)
no permanent national government; transitional,
parliamentary national government
NA%
although an interim government was created in 2000 other
governing bodies continue to exist and control various cities and
regions of the country, including Somaliland, Puntland, and
traditional clan and faction strongholds
This page was last updated on 18 December, 2003
======================================================================
@2142 Country name
conventional long form: none
conventional short form: Somalia
former: Somali Republic, Somali Democratic Republic
Eastern Africa, bordering the Gulf of Aden and the Indian
Ocean, east of Ethiopia
Africa
2,000 sq km (1998 est.)
total: 637,657 sq km
land: 627,337 sq km
water: 10,320 sq km
Somalia does not have an embassy in the US (ceased
operations on 8 May 1991); note - the TNG and other factions have
representatives in Washington and at the United Nations
15,000 (2000)
NA
3 (one each in Boosaaso, Hargeisa, and Mogadishu) (2000)
200 (2000)
.so
1% (2001 est.)
43,000 (2001 est.)
NA
SOS
0 bbl/day (2001 est.)
4,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 17.6 years
male: 17.6 years
female: 17.6 years (2002)
0 bbl (37257)
2.832 billion cu m (37257)','4c606a4f902bde458ea5ddd908817230d67b5194781d80f67054536ff173f51a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1ba0fd07e0cd10dec9b188d8b5b46d93633e82369d56b8ec1a802198d7e526b',2003,'ZA','South Africa','communications',985,'vast interior plateau rimmed by rugged hills and narrow
coastal plain
2.24 children born/woman (2003 est.)
republic
37% (includes workers no longer looking for employment)
(2001 est.)
with the end of Apartheid and the establishment of
majority rule, former military, black homelands forces, and
ex-opposition forces were integrated into the South African National
Defense Force (SANDF); as of 2003 the integration process was
considered complete
conventional long form: Republic of South Africa
conventional short form: South Africa
former: Union of South Africa
abbreviation: RSA
Southern Africa, at the southern tip of the continent
of Africa
Africa
13,500 sq km (1998 est.)
total: 1,219,912 sq km
land: 1,219,912 sq km
water: 0 sq km
note: includes Prince Edward Islands (Marion Island and Prince
Edward Island)
chief of mission: Ambassador Barbara Joyce Mosima
MASEKELA
chancery: 3051 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 232-4400
FAX: [1] (202) 265-1607
consulate(s) general: Chicago, Los Angeles, and New York
more than 5 million (2001)
7.06 million (2001)
150 (2001)
3.068 million (2002)
.za
20.1% (2001 est.)
5 million (2001 est.)
360,000 (2001 est.)
ZAR
59.3 (1993-94)
196,200 bbl/day (2001 est.)
460,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 24.5 years
male: 24 years
female: 25 years (2002)
7.84 million bbl (37257)
14.16 million cu m (37257)
1.8 billion cu m (2001 est.)
1.8 billion cu m (2001 est.)
0 cu m (2001 est.)
0 cu m (2001 est.)','baafa7338a40f22cb1e0665790c30154b946ae8f7b060fdd3a31288d77a82d38','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e321c01913c842758e8dcd4991c49d48a8c5338f2ba398c3a4e175c9de6f41b',2003,'GS','South Georgia and the South Sandwich Islands','communications',986,'most of the islands,
rising steeply from the sea, are rugged and mountainous; South
Georgia is largely barren and has steep, glacier-covered mountains;
the South Sandwich Islands are of volcanic origin with some active
volcanoes
Southern Ocean
the Southern Ocean is deep, 4,000 to 5,000 meters
over most of its extent with only limited areas of shallow water;
the Antarctic continental shelf is generally narrow and unusually
deep, its edge lying at depths of 400 to 800 meters (the global mean
is 133 meters); the Antarctic icepack grows from an average minimum
of 2.6 million square kilometers in March to about 18.8 million
square kilometers in September, better than a sixfold increase in
area; the Antarctic Circumpolar Current (21,000 km in length) moves
perpetually eastward; it is the world''s largest ocean current,
transporting 130 million cubic meters of water per second - 100
times the flow of all the world''s rivers
defense is the
responsibility of the UK
Spratly Islands
Spratly Islands consist of more than 100 small
islands or reefs, of which about 45 are claimed and occupied by
China, Malaysia, the Philippines, Taiwan, and Vietnam
Svalbard
demilitarized by treaty (9 February 1920)
conventional long form:
conventional short form: none
Southern South America,
islands in the South Atlantic Ocean, east of the tip of South America
Southern Ocean
body of water between 60 degrees south latitude and
Antarctic Region
Southern Ocean
Antarctic Region
0 sq km (1998 est.)
total: 3,903 sq km
land: 3,903 sq km
water: 0 sq km
note: includes Shag Rocks, Black Rock, Clerke Rocks, South Georgia
Island, Bird Island, and the South Sandwich Islands, which consist
of some nine islands
Southern Ocean
total: 20.327 million sq km
note: includes Amundsen Sea, Bellingshausen Sea, part of the Drake
Passage, Ross Sea, a small part of the Scotia Sea, Weddell Sea, and
other tributary water bodies
none (overseas
territory of the UK, also claimed by Argentina)
.gs','c6d4a42d9753d6740a668a64789da18b44bfd2cf7ed46ceb86e7c59674c238b3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc334a5c6a1a7029b286d113b2ab534303358bca6a32b34b4ae0035d018db30c',2003,'ES','Spain','communications',987,'large, flat to dissected plateau surrounded by rugged hills;
Pyrenees in north
Spratly Islands
flat
1.26 children born/woman (2003 est.)
parliamentary monarchy
11.3% (2002 est.)
conventional long form: Kingdom of Spain
conventional short form: Spain
local short form: Espana
Spratly Islands
conventional long form: none
conventional short form: Spratly Islands
Southwestern Europe, bordering the Bay of Biscay,
Mediterranean Sea, North Atlantic Ocean, and Pyrenees Mountains,
southwest of France
Spratly Islands
Southeastern Asia, group of reefs and islands in the
South China Sea, about two-thirds of the way from southern Vietnam
to the southern Philippines
Europe
Spratly Islands
Southeast Asia
36,400 sq km (1998 est.)
Spratly Islands
0 sq km (1998 est.)
total: 504,782 sq km
land: 499,542 sq km
water: 5,240 sq km
note: there are 19 autonomous communities including Balearic Islands
and Canary Islands, and three small Spanish possessions off the
coast of Morocco - Islas Chafarinas, Penon de Alhucemas, and Penon
de Velez de la Gomera
Spratly Islands
total: less than 5 sq km
land: less than 5 sq km
water: 0 sq km
note: includes 100 or so islets, coral reefs, and sea mounts
scattered over an area of nearly 410,000 sq km of the central South
China Sea
chief of mission: Ambassador Francisco Javier RUPEREZ Rubio
chancery: 2375 Pennsylvania Avenue NW, Washington, DC 20037
telephone: [1] (202) 452-0100, 728-2340
FAX: [1] (202) 833-5670
consulate(s) general: Boston, Chicago, Houston, Los Angeles, Miami,
New Orleans, New York, San Francisco, and San Juan (Puerto Rico)
17.336 million (1999)
8.394 million (1999)
56 (2000)
7.89 million (2002)
.es
0.5% (2001 est.)
130,000 (2001 est.)
2,300 (2001 est.)
EUR
32.5 (1990)
7,099 bbl/day (2001 est.)
1.497 million bbl/day (2001 est.)
1.582 million bbl/day (2001)
135,100 bbl/day (2001)
total: 38.7 years
male: 37.4 years
female: 40.1 years (2002)
10.5 million bbl (37257)
254.9 million cu m (37257)
516 million cu m (2001 est.)
17.96 billion cu m (2001 est.)
17.26 billion cu m (2001 est.)
0 cu m (2001 est.)','6924cd8adbf62a48187948a88130a2a11aeb93bade97fe0a5cb194ede2eb09e0','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39b4d1ce2c5ce7a8e20deaa309022b6066594cd26c7f948659a936393703e844',2003,'LK','Sri Lanka','communications',988,'mostly low, flat to rolling plain; mountains in
south-central interior
1.9 children born/woman (2003 est.)
republic
8% (2002)
conventional long form: Democratic Socialist Republic of
conventional short form: Sri Lanka
former: Serendib, Ceylon
Southern Asia, island in the Indian Ocean, south of India
Asia
6,510 sq km (1998 est.)
total: 65,610 sq km
land: 64,740 sq km
water: 870 sq km
chief of mission: Ambassador Devinda R. SUBASINGHE
chancery: 2148 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 483-4025 (through 4028)
FAX: [1] (202) 232-7181
consulate(s) general: Los Angeles
consulate(s): New York
494,509 (1998)
228,604 (1999)
5 (2000)
121,500 (2001)
.lk
less than 0.1% (2001 est.)
4,800 (2001 est.)
250 (2001 est.)
LKR
34.4 (1995)
0 bbl/day (2001 est.)
75,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 28.7 years
male: 27.7 years
female: 29.7 years (2002)','213b2be1ee5aad8a29eb8ae5904c53c6c2449f0158918a9bf2a7a905b622254c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bbcfbeb0fbcb30a9708a5b5e3b06548d76ebb6de935c26ab375e19e7e8ad178',2003,'SD','Sudan','communications',989,'generally flat, featureless plain; mountains in far south,
northeast and west; desert dominates the north
5.1 children born/woman (2003 est.)
authoritarian regime - ruling military junta took power in
1989; government is run by an alliance of the military and the
National Congress Party (NCP), formerly the National Islamic Front
(NIF), which espouses an Islamist platform
18.7% (2002 est.)
conventional long form: Republic of the Sudan
conventional short form: Sudan
local long form: Jumhuriyat as-Sudan
local short form: As-Sudan
former: Anglo-Egyptian Sudan
Northern Africa, bordering the Red Sea, between Egypt and
Africa
19,500 sq km (1998 est.)
total: 2,505,810 sq km
land: 2.376 million sq km
water: 129,810 sq km
chief of mission: Ambassador (vacant); Charge D''Affairs, Ad
Interim Khidir Haroun AHMED (since April 2001)
chancery: 2210 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 338-8565
FAX: [1] (202) 667-2406
400,000 (2000)
20,000 (2000)
2 (2002)
56,000 (2002)
.sd
2.6% (2001 est.)
450,000 (2001 est.)
23,000 (2001 est.)
SDD
209,100 bbl/day (2001 est.)
50,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 17.7 years
male: 17.5 years
female: 17.9 years (2002)
631.5 million bbl (37257)
99.11 billion cu m (37257)','9195148f27271b82b97a65e6da87db27c62ee410294e83eb3703422697f69042','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1905946e4e1fd093982d9c0c885d6b3e2597c5eb8ae4d9e84ae68e2d62b710c',2003,'SR','Suriname','communications',990,'mostly rolling hills; narrow coastal plain with swamps
Svalbard
wild, rugged mountains; much of high land ice covered; west
coast clear of ice about one-half of the year; fjords along west and
north coasts
Swaziland
mostly mountains and hills; some moderately sloping plains
2.4 children born/woman (2003 est.)
Svalbard
NA children born/woman (2003 est.)
Swaziland
3.92 children born/woman (2003 est.)
constitutional democracy
Svalbard
NA
Swaziland
monarchy; independent member of Commonwealth
17% (2000)
Swaziland
34% (2000 est.)
conventional long form: Republic of Suriname
conventional short form: Suriname
local long form: Republiek Suriname
local short form: Suriname
former: Netherlands Guiana, Dutch Guiana
Svalbard
conventional long form: none
conventional short form: Svalbard (sometimes referred to as
Spitzbergen)
Swaziland
conventional long form: Kingdom of Swaziland
conventional short form: Swaziland
Northern South America, bordering the North Atlantic Ocean,
between French Guiana and Guyana
Svalbard
Northern Europe, islands between the Arctic Ocean, Barents
Sea, Greenland Sea, and Norwegian Sea, north of Norway
Swaziland
Southern Africa, between Mozambique and South Africa
South America
Svalbard
Arctic Region
Swaziland
Africa
490 sq km (1998 est.)
Svalbard
NA sq km
Swaziland
690 sq km (1998 est.)
total: 163,270 sq km
land: 161,470 sq km
water: 1,800 sq km
Svalbard
total: 62,049 sq km
land: 62,049 sq km
water: 0 sq km
note: includes Spitsbergen and Bjornoya (Bear Island)
Swaziland
total: 17,363 sq km
land: 17,203 sq km
water: 160 sq km
chief of mission: Ambassador Henry Lothar ILLES
chancery: Suite 460, 4301 Connecticut Avenue NW, Washington, DC 20008
telephone: [1] (202) 244-7488
FAX: [1] (202) 244-5878
consulate(s) general: Miami
Swaziland
chief of mission: Ambassador Mary Madzandza KANYA
chancery: 3400 International Drive NW, Washington, DC 20008
telephone: [1] (202) 362-6683
FAX: [1] (202) 244-8059
64,000 (1997)
Svalbard
NA
Swaziland
38,500 (2001)
4,090 (1997)
Svalbard
NA
Swaziland
45,000 (2001)
2 (2000)
Svalbard
13 (Svalbard and Jan Mayen) (2000)
Swaziland
5 (2002)
14,500 (2002)
Svalbard
NA
Swaziland
7,000 (2002)
.sr
Svalbard
.sj
Swaziland
.sz
1.2% (2001 est.)
Svalbard
0% (2001)
Swaziland
33.4% (2001 est.)
3,700 (2001 est.)
Svalbard
0 (2001)
Swaziland
170,000 (2001 est.)
330 (2001 est.)
Svalbard
0 (2001)
Swaziland
12,000 (2001 est.)
SRG
Svalbard
NOK
Swaziland
SZL
10,000 bbl/day (2001 est.)
Swaziland
0 bbl/day (2001 est.)
10,000 bbl/day (2001 est.)
Swaziland
3,500 bbl/day (2001 est.)
NA (2001)
Swaziland
NA (2001)
NA (2001)
Swaziland
NA (2001)
total: 25.5 years
male: 25.1 years
female: 26 years (2002)
Swaziland
total: 18.5 years
male: 18.2 years
female: 18.8 years (2002)
37 million bbl (37257)
Syria
2.4 billion bbl (37257)
Taiwan
2 million bbl (37257)
Tanzania
0 bbl (37257)
0 cu m (37257)
Syria
240.7 billion cu m (37257)
Taiwan
38.23 billion cu m (37257)
Tanzania
11.33 billion cu m (37257)','d3262ab49f09f60f9c4ba51a901c58aa61e0d4c4a9589f01ef34108dbe30d6a2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9141d3d5215d5a721f37703689234c90d45f233d6f14e31564d2010ff9c760e5',2003,'SE','Sweden','communications',991,'mostly flat or gently rolling lowlands; mountains in west
1.54 children born/woman (2003 est.)
constitutional monarchy
4% (2002 est.)
conventional long form: Kingdom of Sweden
conventional short form: Sweden
local long form: Konungariket Sverige
local short form: Sverige
Northern Europe, bordering the Baltic Sea, Gulf of Bothnia,
Kattegat, and Skagerrak, between Finland and Norway
Europe
1,150 sq km (1998 est.)
total: 449,964 sq km
land: 410,934 sq km
water: 39,030 sq km
chief of mission: Ambassador Jan ELIASSON
chancery: 1501 M Street NW, Washington, DC 20005-1702
telephone: [1] (202) 467-2600
FAX: [1] (202) 467-2699
consulate(s) general: Los Angeles and New York
6.017 million (December 1998)
3.835 million (October 1998)
29 (2000)
6.02 million (2002)
.se
0.1% (2001 est.)
3,300 (2001 est.)
less than 100 (2001 est.)
SEK
25 (1992)
0 bbl/day (2001 est.)
328,600 bbl/day (2001 est.)
553,100 bbl/day (2001)
203,700 bbl/day (2001)
total: 40.1 years
male: 39 years
female: 41.4 years (2002)
0 cu m (2001 est.)
949 million cu m (2001 est.)
968 million cu m (2001 est.)
0 cu m (2001 est.)','8b18ffcfaa9335a17549337f0feee5de9a78405172d25ede92c8cc80e4f898b8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d4b72a2a18c28dd820d05b499500225b87251054c6b5a6e987519455ac36ad7',2003,'CH','Switzerland','communications',992,'mostly mountains (Alps in south, Jura in northwest) with
a central plateau of rolling hills, plains, and large lakes
Syria
primarily semiarid and desert plateau; narrow coastal plain;
mountains in west
Taiwan
eastern two-thirds mostly rugged mountains; flat to gently
rolling plains in west
1.48 children born/woman (2003 est.)
Syria
3.72 children born/woman (2003 est.)
Taiwan
1.57 children born/woman (2003 est.)
federal republic
Syria
republic under military regime since March 1963
Taiwan
multiparty democratic regime headed by popularly-elected
president and unicameral legislature
1.9% (2002 est.)
Syria
20% (2002 est.)
Taiwan
5.2% (2002 est.)
conventional long form: Swiss Confederation
conventional short form: Switzerland
local long form: Schweizerische Eidgenossenschaft (German),
Confederation Suisse (French), Confederazione Svizzera (Italian)
local short form: Schweiz (German), Suisse (French), Svizzera
(Italian)
Syria
conventional long form: Syrian Arab Republic
conventional short form: Syria
local long form: Al Jumhuriyah al Arabiyah as Suriyah
local short form: Suriyah
former: United Arab Republic (with Egypt)
Taiwan
conventional long form: none
conventional short form: Taiwan
local long form: none
local short form: T''ai-wan
former: Formosa
Central Europe, east of France, north of Italy
Syria
Middle East, bordering the Mediterranean Sea, between Lebanon
and Turkey
Taiwan
Eastern Asia, islands bordering the East China Sea,
Philippine Sea, South China Sea, and Taiwan Strait, north of the
Philippines, off the southeastern coast of China
Europe
Syria
Middle East
Taiwan
Southeast Asia
250 sq km (1998 est.)
Syria
12,130 sq km (1998 est.)
Taiwan
NA sq km
total: 41,290 sq km
land: 39,770 sq km
water: 1,520 sq km
Syria
total: 185,180 sq km
land: 184,050 sq km
water: 1,130 sq km
note: includes 1,295 sq km of Israeli-occupied territory
Taiwan
total: 35,980 sq km
land: 32,260 sq km
water: 3,720 sq km
note: includes the Pescadores, Matsu, and Quemoy
chief of mission: Ambassador Christian BLICKENSTORFER
chancery: 2900 Cathedral Avenue NW, Washington, DC 20008
telephone: [1] (202) 745-7900
FAX: [1] (202) 387-2564
consulate(s) general: Atlanta, Chicago, Houston, Los Angeles, New
York, and San Francisco
consulate(s): Boston
Syria
chief of mission: Ambassador (acting) Imad MUSTAFA
chancery: 2215 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 232-6313
FAX: [1] (202) 234-9548
Taiwan
none; unofficial commercial and cultural relations with the
people of the US are maintained through an unofficial
instrumentality, the Taipei Economic and Cultural Representative
Office (TECRO) in the US with headquarters in Taipei and field
offices in Washington and 12 other US cities
4.82 million (1998)
Syria
1.313 million (1997)
Taiwan
12.49 million (September 2000)
1.967 million (1999)
Syria
NA
Taiwan
16 million (September 2000)
44 (Switzerland and Liechtenstein) (2000)
Syria
1 (2000)
Taiwan
8 (2000)
3.85 million (2002)
Syria
60,000 (2002)
Taiwan
11.6 million (2001)
.ch
Syria
.sy
Taiwan
.tw
0.5% (2001 est.)
Syria
0.01% (2001 est.)
Taiwan
NA
19,000 (2001 est.)
Syria
NA
Taiwan
NA
less than 100 (2001 est.)
Syria
NA
Taiwan
NA
CHF
Syria
SYP
Taiwan
TWD
33.1 (1992)
Taiwan
32.6 (2000)
0 bbl/day (2001 est.)
Syria
522,700 bbl/day (2001 est.)
Taiwan
1,100 bbl/day (2001 est.)
290,400 bbl/day (2001 est.)
Syria
265,000 bbl/day (2001 est.)
Taiwan
988,000 bbl/day (2001 est.)
289,500 bbl/day (2001)
Syria
NA (2001)
Taiwan
NA (2001)
10,420 bbl/day (2001)
Syria
NA (2001)
Taiwan
NA (2001)
total: 40.2 years
male: 39.3 years
female: 41.2 years (2002)
Syria
total: 19.7 years
male: 19.6 years
female: 19.9 years (2002)
Taiwan
total: 33.2 years
male: 32.9 years
female: 33.6 years (2002)
0 cu m (2001 est.)
Syria
5.84 billion cu m (2001 est.)
Taiwan
750 million cu m (2001 est.)
3.093 billion cu m (2001 est.)
Syria
5.84 billion cu m (2001 est.)
Taiwan
6.64 billion cu m (2001 est.)
3.093 billion cu m (2001 est.)
Syria
0 cu m (2001 est.)
Taiwan
6.3 billion cu m (2001 est.)
0 cu m (2001 est.)
Syria
0 cu m (2001 est.)
Taiwan
410 million cu m (2001 est.)','df6e34dfc04ed4f7aa2aadb842a6ea5e274f96baf6b8d1995783e8fdb80aad86','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20098a4cc81b379c2c1ba08f08ddd8ef0514eb6303123147aa99d32b26da318f',2003,'TJ','Tajikistan','communications',993,'Pamir and Alay Mountains dominate landscape; western
Fergana Valley in north, Kofarnihon and Vakhsh Valleys in southwest
Tanzania
plains along coast; central plateau; highlands in north,
south
4.17 children born/woman (2003 est.)
Tanzania
5.24 children born/woman (2003 est.)
republic
Tanzania
republic
40% (2002 est.)
Tanzania
NA%
conventional long form: Republic of Tajikistan
conventional short form: Tajikistan
local long form: Jumhurii Tojikiston
local short form: Tojikiston
former: Tajik Soviet Socialist Republic
Tanzania
conventional long form: United Republic of Tanzania
conventional short form: Tanzania
former: United Republic of Tanganyika and Zanzibar
Central Asia, west of China
Tanzania
Eastern Africa, bordering the Indian Ocean, between Kenya
and Mozambique
Asia
Tanzania
Africa
7,200 sq km (1998 est.)
Tanzania
1,550 sq km (1998 est.)
total: 143,100 sq km
land: 142,700 sq km
water: 400 sq km
Tanzania
total: 945,087 sq km
land: 886,037 sq km
water: 59,050 sq km
note: includes the islands of Mafia, Pemba, and Zanzibar
chief of mission: Ambassador Khamrokhon ZARIPOV
chancery: 1725 K Sreet NW, Suite 409, Washington, DC 20006
telephone: [1] (202) 223-6090
FAX: [1] (202) 223-6091
Tanzania
chief of mission: Ambassador Andrew Mhando DARAJA
chancery: 2139 R Street NW, Washington, DC 20008
telephone: [1] (202) 939-6125
FAX: [1] (202) 797-7408
363,000 (1997)
Tanzania
127,000 (1998)
2,500 (1997)
Tanzania
30,000 (1999)
4 (2002)
Tanzania
6 (2000)
5,000 (2002)
Tanzania
300,000 (2002)
.tj
Tanzania
.tz
less than 0.1% (2001 est.)
Tanzania
7.8% (2001 est.)
less than 200 (2001 est.)
Tanzania
1.5 million (2001 est.)
less than 100 (2001 est.)
Tanzania
140,000 (2001 est.)
TJS
Tanzania
TZS
34.7 (1998)
Tanzania
38.2 (1993)
250 bbl/day (2001 est.)
Tanzania
0 bbl/day (2001 est.)
20,000 bbl/day (2001 est.)
Tanzania
17,000 bbl/day (2001 est.)
NA (2001)
Tanzania
NA (2001)
NA (2001)
Tanzania
NA (2001)
total: 19.3 years
male: 19 years
female: 19.6 years (2002)
Tanzania
total: 17.5 years
male: 17.2 years
female: 17.7 years (2002)
50 million cu m (2001 est.)
1.3 billion cu m (2001 est.)
1.25 billion cu m (2001 est.)
0 cu m (2001 est.)','fed9ce67a82ff11ea50dacf5e1544c73fb5671966260c742da436cca199e88f1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47db0653ebc75af8cc023bd9827904f882cd379a38fc0ef62541e172afbe3801',2003,'TH','Thailand','communications',994,'central plain; Khorat Plateau in the east; mountains
elsewhere
1.91 children born/woman (2003 est.)
constitutional monarchy
2.9% (2002 est.)
conventional long form: Kingdom of Thailand
conventional short form: Thailand
former: Siam
Southeastern Asia, bordering the Andaman Sea and the Gulf
of Thailand, southeast of Burma
Southeast Asia
47,490 sq km (1998 est.)
total: 514,000 sq km
land: 511,770 sq km
water: 2,230 sq km
chief of mission: Ambassador SAKTHIP Krairiksh
chancery: 1024 Wisconsin Avenue NW, Washington, DC 20007
telephone: [1] (202) 944-3600
FAX: [1] (202) 944-3611
consulate(s) general: Chicago, Los Angeles, and New York
5.6 million (2000)
3.1 million (2002)
15 (2000)
1.2 million (2001)
.th
1.8% (2001 est.)
670,000 (2001 est.)
55,000 (2001 est.)
THB
41.4 (1998)
173,800 bbl/day (2001 est.)
785,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 30.1 years
male: 29.4 years
female: 30.8 years (2002)
551.5 million bbl (37257)
368.2 billion cu m (37257)
18.73 billion cu m (2001 est.)
23.93 billion cu m (2001 est.)
5.2 billion cu m (2001 est.)
0 cu m (2001 est.)','411fbdabdbb9c377705f2ca2e7bb9d564c44056c475714f97152b1e8ecc0e515','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5c2b14e37bb5252477e5d19df31551b4995e64a1ca0f24a8dd76e9ae0a208b7',2003,'TG','Togo','communications',995,'gently rolling savanna in north; central hills; southern
plateau; low coastal plain with extensive lagoons and marshes
4.97 children born/woman (2003 est.)
republic under transition to multiparty democratic rule
NA%
conventional long form: Togolese Republic
conventional short form: Togo
local long form: Republique Togolaise
local short form: none
former: French Togoland
Western Africa, bordering the Bight of Benin, between Benin and
Africa
70 sq km (1998 est.)
total: 56,785 sq km
land: 54,385 sq km
water: 2,400 sq km
chief of mission: Ambassador Akoussoulelou BODJONA
chancery: 2208 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 234-4212
FAX: [1] (202) 232-3190
25,000 (1997)
2,995 (1997)
3 (2001)
50,000 (2002)
.tg
6% (2001 est.)
150,000 (2001 est.)
12,000 (2001 est.)
XOF
0 bbl/day (2001 est.)
10,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 17.3 years
male: 16.9 years
female: 17.7 years (2002)','5459f5b44b6fe42bfe7050ea9da77e7c0fc7f50ab7f0b53f1354eda76ebee0e0','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a07ba0aa19ef1103708d8ae8a187f44cadfeb061be4c3dc21f4fde52f7b00bd',2003,'TK','Tokelau','communications',996,'low-lying coral atolls enclosing large lagoons
NA children born/woman (2003 est.)
NA
NA%
defense is the responsibility of New Zealand
Tromelin Island
defense is the responsibility of France
conventional long form: none
conventional short form: Tokelau
Oceania, group of three atolls in the South Pacific Ocean,
about one-half of the way from Hawaii to New Zealand
Oceania
NA sq km
total: 10 sq km
land: 10 sq km
water: 0 sq km
none (territory of New Zealand)
NA
0 (2001)
1 (2000)
NA
.tk
NA%
NA
NA
NZD','b93c7934adc74841a012136a0817be07d7823d057d9d9c28b89ba95657d0ecd7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38f5ea383b2520a6b5520feafda0ded00e1a43b730629dd7f3fa319e17dd6fda',2003,'TO','Tonga','communications',997,'most islands have limestone base formed from uplifted coral
formation; others have limestone overlying volcanic base
3 children born/woman (2003 est.)
hereditary constitutional monarchy
13.3% (1996 est.)
conventional long form: Kingdom of Tonga
conventional short form: Tonga
former: Friendly Islands
Oceania, archipelago in the South Pacific Ocean, about
two-thirds of the way from Hawaii to New Zealand
Oceania
NA sq km
total: 748 sq km
land: 718 sq km
water: 30 sq km
chief of mission: Ambassador Sonatane T. T. TUPOU
chancery: 250 East 51st Street, New York, NY 10022
telephone: [1] (917) 369-1136
FAX: [1] (917) 369-1024
consulate(s) general: San Francisco
8,000 (1996)
302 (1996)
2 (2000)
1,000 (2000)
.to
NA%
NA
NA
TOP
0 bbl/day (2001 est.)
1,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 19.8 years
male: 19.3 years
female: 20.3 years (2002)','4c94a976f1a5b9a679ebb38932b4468926a87110f38ae38ddffd91fd6b476845','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fa6699b9f1f331542a77879123a16ca226387ee21da393aa6bf9a9291ebae2e',2003,'TT','Trinidad and Tobago','communications',998,'mostly plains with some hills and low mountains
Tromelin Island
low, flat, and sandy; likely volcanic
1.78 children born/woman (2003 est.)
parliamentary democracy
10.8% (2002)
conventional long form: Republic of Trinidad and
Tobago
conventional short form: Trinidad and Tobago
Tromelin Island
conventional long form: none
conventional short form: Tromelin Island
local long form: none
local short form: Ile Tromelin
Caribbean, islands between the Caribbean Sea and
the North Atlantic Ocean, northeast of Venezuela
Tromelin Island
Southern Africa, island in the Indian Ocean, east of
Central America and the Caribbean
Tromelin Island
Africa
30 sq km (1998 est.)
Tromelin Island
0 sq km (1998 est.)
total: 5,128 sq km
land: 5,128 sq km
water: 0 sq km
Tromelin Island
total: 1 sq km
land: 1 sq km
water: 0 sq km
chief of mission: Ambassador Marina Annette
VALERE (as of February 2003)
chancery: 1708 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 467-6490
FAX: [1] (202) 785-3130
consulate(s) general: Miami and New York
252,000 (1999)
17,411 (1997)
17 (2000)
120,000 (2002)
.tt
2.5% (2001 est.)
17,000 (2001 est.)
1,200 (2001 est.)
TTD
125,400 bbl/day (2001 est.)
24,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 29.9 years
male: 29.5 years
female: 30.4 years (2002)
716 million bbl (37257)
610.6 billion cu m (37257)
15.19 billion cu m (2001 est.)
11.54 billion cu m (2001 est.)
0 cu m (2001 est.)
3.65 billion cu m (2001 est.)
associate members - (4) Anguilla, British Virgin Islands, Cayman
Islands, Turks and Caicos Islands
observers - (8) Aruba, Bermuda, Colombia, Dominican Republic, Mexico,
Netherlands Antilles, Puerto Rico, Venezuela
Caribbean Development Bank (CDB): established - 18 October 1969;
effective - 26 January 1970
aim - to promote economic development and cooperation
regional members - (20) Anguilla, Antigua and Barbuda, The Bahamas,
Barbados, Belize, British Virgin Islands, Cayman Islands, Colombia,
Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Trinidad and
Tobago, Turks and Caicos Islands, Venezuela
nonregional members - (5) Canada, China, Germany, Italy, UK
Central African Customs and Economic Union (UDEAC): see Monetary and
Economic Community of Central Africa (CEMAC)
Central African States Development Bank (BDEAC): note - acronym from
Banque de Developpement des Etats de l''Afrique Centrale
established - 3 December 1975
aim - to provide loans for economic development
members - (11) African Development Bank (AfDB), Cameroon, Central
African States Bank (BEAC), Central African Republic, Chad, Republic of
the Congo, Equatorial Guinea, France, Gabon, Germany, Kuwait
Central American Bank for Economic Integration (BCIE): note - acronym
from Banco Centroamericano de Integracion Economico
established - 13 December 1960 signature of Articles of Agreement; 31
May 1961 began operations
aim - to promote economic integration and development
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members - (4) Argentina, Colombia, Mexico, Taiwan
Central American Common Market (CACM): established - 13 December 1960,
collapsed in 1969, reinstated in 1991
aim - to promote establishment of a Central American Common Market
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua;
note - Panama, although not a member, pursues full regional cooperation
Central European Initiative (CEI): note - evolved from the
Quadrilateral Initiative and the Hexagonal Initiative
established - 11 November 1989 as the Quadrilateral Initiative, 27 July
1991 became the Hexagonal Initiative, NA July 1992 present name adopted
aim - to form an economic and political cooperation group for the
region between the Adriatic and the Baltic Seas
members - (17) Albania, Austria, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Hungary, Italy, The Former Yugoslav
Republic of Macedonia, Moldova, Poland, Romania, Serbia and Montenegro,
Slovakia, Slovenia, Ukraine
centrally planned economies : a term applied mainly to the
traditionally Communist states that looked to the former USSR for
leadership; most are now evolving toward more democratic and market-
oriented systems; also known formerly as the Second World or as the
Communist countries; through the 1980s, this group included Albania,
Bulgaria, Cambodia, China, Cuba, Czechoslovakia, GDR, Hungary, North
Korea, Laos, Mongolia, Poland, Romania, Serbia and Montenegro, USSR,
Vietnam
Colombo Plan (CP): established - NA May 1950 proposal was adopted; 1
July 1951 commenced full operations
aim - to promote economic and social development in Asia and the
Pacific
members - (25) Afghanistan, Australia, Bangladesh, Bhutan, Burma,
Cambodia, Fiji, India, Indonesia, Iran, Japan, South Korea, Laos,
Malaysia, Maldives, Nepal, NZ, Pakistan, Papua New Guinea, Philippines,
Singapore, Sri Lanka, Thailand, US, Vietnam
provisional member - (1) Mongolia
Commonwealth (C): note - also known as Commonwealth of Nations
established - 31 December 1931
aim - to foster multinational cooperation and assistance, as a
voluntary association that evolved from the British Empire
members - (54) Antigua and Barbuda, Australia, The Bahamas, Bangladesh,
Barbados, Belize, Botswana, Brunei, Cameroon, Canada, Cyprus, Dominica,
Fiji, The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya,
Kiribati, Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius,
Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan (suspended), Papua
New Guinea, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Seychelles, Sierra Leone, Singapore, Solomon
Islands, South Africa, Sri Lanka, Swaziland, Tanzania, Tonga, Trinidad
and Tobago, Tuvalu, Uganda, UK, Vanuatu, Zambia, Zimbabwe (suspended)
Commonwealth of Independent States (CIS): established - 8 December
1991; effective - 21 December 1991
aim - to coordinate intercommonwealth relations and to provide a
mechanism for the orderly dissolution of the USSR
members - (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan,
Kyrgyzstan, Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,','7805ee85a8da35d5aa7ff3bc9b5a80d1950019d70f6678955e6602d72859a14a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7855298410e335b9dc9fbb6cdf118e0dfcf65a0ee30649f0ec6f30127a10b14',2003,'TN','Tunisia','communications',999,'mountains in north; hot, dry central plain; semiarid south
merges into the Sahara
Turkey
high central plateau (Anatolia); narrow coastal plain;
several mountain ranges
1.9 children born/woman (2003 est.)
Turkey
2.03 children born/woman (2003 est.)
republic
Turkey
republican parliamentary democracy
15.4% (2002 est.)
Turkey
10.8% (plus underemployment of 6.1%) (2002 est.)
conventional long form: Tunisian Republic
conventional short form: Tunisia
local long form: Al Jumhuriyah at Tunisiyah
local short form: Tunis
Turkey
conventional long form: Republic of Turkey
conventional short form: Turkey
local long form: Turkiye Cumhuriyeti
local short form: Turkiye
Northern Africa, bordering the Mediterranean Sea, between
Algeria and Libya
Turkey
southeastern Europe and southwestern Asia (that portion of
Turkey west of the Bosporus is geographically part of Europe),
bordering the Black Sea, between Bulgaria and Georgia, and bordering
the Aegean Sea and the Mediterranean Sea, between Greece and Syria
Africa
Turkey
Middle East
3,800 sq km (1998 est.)
Turkey
42,000 sq km (1998 est.)
total: 163,610 sq km
land: 155,360 sq km
water: 8,250 sq km
Turkey
total: 780,580 sq km
land: 770,760 sq km
water: 9,820 sq km
chief of mission: Ambassador Hatem ATALLAH
chancery: 1515 Massachusetts Avenue NW, Washington, DC 20005
telephone: [1] (202) 862-1850
FAX: [1] (202) 862-1858
Turkey
chief of mission: Ambassador Dr. Osman Faruk LOGOGLU
chancery: 2525 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 612-6700
FAX: [1] (202) 612-6744
consulate(s) general: Chicago, Houston, Los Angeles, and New York
654,000 (1997)
Turkey
19.5 million (1999)
50,000 (1998)
Turkey
17.1 million (2001)
1 (2000)
Turkey
50 (2001)
400,000 (2002)
Turkey
2.5 million (2002)
.tn
Turkey
.tr
0.04% (2001 est.)
Turkey
less than 0.1% - note: no country specific models provided
(2001 est.)
NA
Turkey
NA
NA
Turkey
NA
TND
Turkey
TRL
41.7 (1995)
Turkey
41.5 (1994)
72,580 bbl/day (2001 est.)
Turkey
48,000 bbl/day (2001 est.)
87,000 bbl/day (2001 est.)
Turkey
619,500 bbl/day (2001 est.)
NA (2001)
Turkey
616,500 bbl/day (2001)
NA (2001)
Turkey
46,110 bbl/day (2001)
total: 26.2 years
male: 25.7 years
female: 26.7 years (2002)
Turkey
total: 26.8 years
male: 26.7 years
female: 27 years (2002)
417 million bbl (37257)
Turkey
288.4 million bbl (37257)
77.16 billion cu m (37257)
Turkey
8.685 billion cu m (37257)
2.25 billion cu m (2001 est.)
Turkey
312 million cu m (2001 est.)
3.83 billion cu m (2001 est.)
Turkey
15.94 billion cu m (2001 est.)
1.58 billion cu m (2001 est.)
Turkey
15.75 billion cu m (2001 est.)
0 cu m (2001 est.)
Turkey
0 cu m (2001 est.)','ff49c094d39f538886f7afddc9a083daf37ae2fb6fd2a872ca58bd3793e112cc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcc3d9cd355d273077b3a4067656518ef866116e19fed1c0bda6ab17f12f39a6',2003,'TM','Turkmenistan','communications',1000,'flat-to-rolling sandy desert with dunes rising to
mountains in the south; low mountains along border with Iran;
borders Caspian Sea in west
3.5 children born/woman (2003 est.)
republic
NA%
conventional long form: none
conventional short form: Turkmenistan
local long form: none
local short form: Turkmenistan
former: Turkmen Soviet Socialist Republic
Central Asia, bordering the Caspian Sea, between Iran
and Kazakhstan
Asia
17,500 sq km (2003 est.)
total: 488,100 sq km
land: 488,100 sq km
water: 0 sq km
chief of mission: Ambassador Mered Bairamovich ORAZOV
chancery: 2207 Massachusetts Avenue NW, Washington, DC 20008
telephone: [1] (202) 588-1500
FAX: [1] (202) 588-0697
363,000 (1997)
4,300 (1998)
1
2,000 (2000)
.tm
less than 0.1% (2001 est.)
less than 100 (1999 est.)
less than 100 (2001 est.)
TMM
40.8 (1998)
162,500 bbl/day (2001 est.)
63,000 bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 21.1 years
male: 20.2 years
female: 22 years (2002)
273 million bbl (37257)
1.43 trillion cu m (37257)
48.2 billion cu m (2001 est.)
9.6 billion cu m (2001 est.)
0 cu m (2001 est.)
38.6 billion cu m (2001 est.)','6899fc87d076817d5cef8503ea3dead7ac1a309fb966845bf781470ced889929','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c3770c30770739c20fb7f7f43d01ebd9d5e7ec1f1064da3dd12c2a55b9ad3d5',2003,'TC','Turks and Caicos Islands','communications',1001,'low, flat limestone; extensive marshes and
mangrove swamps
3.15 children born/woman (2003 est.)
NA
10% (1997 est.)
defense is the responsibility of the UK
conventional long form: none
conventional short form: Turks and Caicos Islands
Caribbean, two island groups in the North
Atlantic Ocean, southeast of The Bahamas, north of Haiti
Central America and the Caribbean
NA sq km
total: 430 sq km
land: 430 sq km
water: 0 sq km
none (overseas territory of the UK)
3,000 (1994)
0 (1994)
14 (2000)
NA
.tc
NA%
NA
NA
USD
0 bbl/day NA (2001 est.)
0 bbl/day NA bbl/day (2001 est.)
NA (2001)
NA (2001)
total: 27 years
male: 27.7 years
female: 26.3 years (2002)','ab9cc15571e0a06635f6bcb63fb3474bafc481926ab2997246818422bcb69d83','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

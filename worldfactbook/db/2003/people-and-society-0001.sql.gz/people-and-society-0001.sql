SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b500efef0b4415d7d3ab387072d760c19c3cff2a3a08f77d78ce6dd476e0743f',2003,'ZW','Zimbabwe','people-and-society',3,'Population
Birth rate
Death rate
Infant mortality rate
Life expectancy at birth - total
Total fertility rate
HIV/AIDS - adult prevalence rate
HIV/AIDS - people living with HIV/AIDS
HIV/AIDS - deaths
Economy Zimbabwe
Economy - overview:
The government of Zimbabwe faces a wide variety of difficult
economic problems as it struggles with an unsustainable fiscal
deficit, an overvalued exchange rate, soaring inflation, and bare
shelves. Its 1998-2002 involvement in the war in the Democratic
Republic of the Congo, for example, drained hundreds of millions of
dollars from the economy. Badly needed support from the IMF has been
suspended because of the country''s failure to meet budgetary goals.
Inflation rose from an annual rate of 32% in 1998 to 59% in 1999, to
60% in 2000, to over 100% by yearend 2001, to 228% in early 2003.
The government''s land reform program, characterized by chaos and
violence, has nearly destroyed the commercial farming sector, the
traditional source of exports and foreign exchange and the provider
of 400,000 jobs.
GDP:
purchasing power parity - $26.07 billion (2002 est.)
GDP - real growth rate:
-13% (2002 est.)
GDP - per capita:
purchasing power parity - $2,100 (2002 est.)
GDP - composition by sector:
agriculture: 18%
industry: 24%
services: 58% (2001)
Population below poverty line:
70% (2002 est.)
Household income or consumption by percentage share:
lowest 10%: 1.97%
highest 10%: 40.42% (1995)
Distribution of family income - Gini index:
50.1 (1995)
Inflation rate (consumer prices):
134.5% (2002 est.)
Labor force:
5.8 million (2000 est.)
Labor force - by occupation:
agriculture 66%, services 24%, industry 10% (1996)
Unemployment rate:
70% (2002 est.)
Budget:
revenues: $2.5 billion
expenditures: $2.6 billion, including capital expenditures of $NA
(2000)
Industries:
mining (coal, gold, copper, nickel, tin, clay, numerous metallic
and nonmetallic ores), steel, wood products, cement, chemicals,
fertilizer, clothing and footwear, foodstuffs, beverages
Industrial production growth rate:
-3.1% (2002 est.)
Electricity - production:
6.735 billion kWh (2001)
Electricity - production by source:
fossil fuel: 47%
hydro: 53%
other: 0% (2001)
nuclear: 0%
Electricity - consumption:
9.813 billion kWh (2001)
Electricity - exports:
0 kWh (2001)
Electricity - imports:
3.55 billion kWh (2001)
Oil - production:
0 bbl/day (2001 est.)
Oil - consumption:
23,000 bbl/day (2001 est.)
Oil - exports:
NA (2001)
Oil - imports:
NA (2001)
Agriculture - products:
corn, cotton, tobacco, wheat, coffee, sugarcane, peanuts; cattle,
sheep, goats, pigs
Exports:
$1.57 billion f.o.b. (2001 est.)
Exports - commodities:
tobacco, gold, ferroalloys, textiles/clothing
Exports - partners:
China 6%, South Africa 5.7%, Germany 5.4%, UK 4.8%, Japan 4.7%,
Netherlands 4.4%, US 4.1% (2002)
Imports:
$1.739 billion f.o.b. (2001 est.)
Imports - commodities:
machinery and transport equipment, other manufactures, chemicals,
fuels
Imports - partners:
South Africa 47.7%, Congo, Democratic Republic of the 5.7%,
Mozambique 5.3% (2002)
Debt - external:
$3.9 billion (2002 est.)
Economic aid - recipient:
$178 million (2000 est.)
Currency:
Zimbabwean dollar (ZWD)
Currency code:
ZWD
Exchange rates:
Zimbabwean dollars per US dollar - 55 (2002), 55.05 (2001), 44.42
(2000), 38.3 (1999), 23.68 (1998)
Fiscal year:
1 January - 31 December
Communications Zimbabwe
Telephones - main lines in use:
212,000 (in addition, there are about 20,000 fixed telephones in
wireless local loop connections) (1997)
Telephones - mobile cellular:
111,000 (2001)
Telephone system:
general assessment: system was once one of the best in Africa, but
now suffers from poor maintenance; more than 100,000 outstanding
requests for connection despite an equally large number of installed
but unused main lines
domestic: consists of microwave radio relay links, open-wire lines,
radiotelephone communication stations, fixed wireless local loop
installations, and a substantial mobile cellular network; Internet
connection is available in Harare and planned for all major towns
and for some of the smaller ones
international: satellite earth stations - 2 Intelsat; two
international digital gateway exchanges (in Harare and Gweru)
Radio broadcast stations:
AM 7, FM 20 (plus 17 repeater stations), shortwave 1 (1998)
Radios:
1.14 million (1997)
Television broadcast stations:
16 (1997)
Televisions:
370,000 (1997)
Internet country code:
.zw
Internet Service Providers (ISPs):
6 (2000)
Internet users:
100,000 (2002)
Transportation Zimbabwe
Railways:
total: 3,077 km
narrow gauge: 3,077 km 1.067-m gauge (313 km electrified)
note: includes the 318 km Bulawayo-Beitbridge Railway Company line
(2002)
Highways:
total: 18,338 km
paved: 8,692 km
unpaved: 9,646 km (1999 est.)
Waterways:
chrome ore is transported from Harare - by way of the Mazoe River -
to the Zambezi River in Mozambique
Pipelines:
refined products 261 km (2003)
Ports and harbors:
Binga, Kariba
Airports:
430 (2002)
Airports - with paved runways:
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2002)
Airports - with unpaved runways:
total: 413
1,524 to 2,437 m: 4
914 to 1,523 m: 197
under 914 m: 212 (2002)
Military Zimbabwe
Military branches:
Zimbabwe National Army, Air Force of Zimbabwe, Zimbabwe Republic
Police (includes Police Support Unit, Paramilitary Police)
Military manpower - availability:
males age 15-49: 3,236,042 (2003 est.)
Military manpower - fit for military service:
males age 15-49: 2,003,572 (2003 est.)
Military expenditures - dollar figure:
$625.1 million (FY02)
Military expenditures - percent of GDP:
3.2% (FY02)
Transnational Issues Zimbabwe
Disputes - international:
dormant dispute remains where Botswana, Namibia, Zambia, and
Zimbabwe boundaries converge
Illicit drugs:
transit point for African cannabis and South Asian heroin, mandrax,
and methamphetamines destined for the South African and European
markets
This page was last updated on 18 December, 2003
======================================================================
@2001 GDP
purchasing power parity - $26.07 billion (2002 est.)
This page was last updated on 18 December, 2003
======================================================================
@2002 Population growth rate (%)
0.83% (2003 est.)
This page was last updated on 18 December, 2003
======================================================================
@2003 GDP - real growth rate (%)
-13% (2002 est.)
This page was last updated on 18 December, 2003
======================================================================
@2004 GDP - per capita
purchasing power parity - $2,100 (2002 est.)
This page was last updated on 18 December, 2003
======================================================================
@2006 Dependency status','71a604986c28894ce60208e6ac3b1c75ed442b2467fffc18cae05653b89caa8a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe9d410ac70e60ccb10dbfdde2896ab40be5368e656845457d6174ee5f24c4d6',2003,'WF','Wallis and Futuna','people-and-society',22,'This category includes the entries dealing with the characteristics of
the people and their society.
People - note
This entry includes miscellaneous demographic information of
significance not included elsewhere.
Personal Names - Capitalization
The Factbook uses all uppercase letters for personal names by which the
subject is usually referred to in various media. An example is
President Vicente FOX Quesada of Mexico. Members of royal families are
usually referred by other than their family name (King and Prime
Minister FAHD bin Abd al-Aziz Al Saud of Saudi Arabia, Queen BEATRIX of
the Netherlands, or King PHUMIPHON Adunyadet of Thailand). Some Asians
are referred to by the first element of their name - also their
surname, such as President NO Muh-hyun of South Korea.
Personal Names - Spelling
The romanization of personal names in the Factbook normally follows the
same transliteration system used by the US Board on Geographic Names
for spelling place names. At times, however, a foreign leader expressly
indicates a preference for, or the media or official documents
regularly use, a romanized spelling that differs from the
transliteration derived from the US Government standard. In such cases,
the Factbook uses the alternative spelling.
Personal Names - Titles
The Factbook capitalizes any valid title (or short form of it)
immediately preceding a person''s name. A title standing alone is
lowercased. Examples: President PUTIN and President BUSH are chiefs of
state. In Russia, the president is chief of state and the premier is
the head of the government, while in the US, the president is both
chief of state and head of government.
Petroleum
See "Oil" entries
Petroleum products
See "Oil" entries
Pipelines
This entry gives the lengths and types of pipelines for transporting
products like natural gas, crude oil, or petroleum products.
Political parties and leaders
This entry includes a listing of significant political organizations
and their leaders.
Political pressure groups and leaders
This entry includes a listing of organizations with leaders involved in
politics, but not standing for legislative election.
Population
This entry gives an estimate from the US Bureau of the Census based on
statistics from population censuses, vital statistics registration
systems, or sample surveys pertaining to the recent past and on
assumptions about future trends. The total population presents one
overall measure of the potential impact of the country on the world and
within its region. Note: starting with the 1993 Factbook, demographic
estimates for some countries (mostly African) have explicitly taken
into account the effects of the growing impact of the HIV/AIDS
epidemic. These countries are currently: The Bahamas, Benin, Botswana,
Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Central
African Republic, Democratic Republic of the Congo, Republic of the
Congo, Cote d''Ivoire, Ethiopia, Gabon, Ghana, Guyana, Haiti, Honduras,
Kenya, Lesotho, Malawi, Mozambique, Namibia, Nigeria, Rwanda, South
Africa, Swaziland, Tanzania, Thailand, Togo, Uganda, Zambia, and
Zimbabwe.
Population below poverty line
National estimates of the percentage of the population lying below the
poverty line are based on surveys of sub-groups, with the results
weighted by the number of people in each group. Definitions of poverty
vary considerably among nations. For example, rich nations generally
employ more generous standards of poverty than poor nations.
Population growth rate
The average annual percent change in the population, resulting from a
surplus (or deficit) of births over deaths and the balance of migrants
entering and leaving a country. The rate may be positive or negative.
The growth rate is a factor in determining how great a burden would be
imposed on a country by the changing needs of its people for
infrastructure (e.g., schools, hospitals, housing, roads), resources
(e.g., food, water, electricity), and jobs. Rapid population growth can
be seen as threatening by neighboring countries.
Ports and harbors
This entry lists the major ports and harbors selected on the basis of
overall importance to each country. This is determined by evaluating a
number of factors (e.g., dollar value of goods handled, gross tonnage,
facilities, military significance).
Radio broadcast stations
This entry includes the total number of AM, FM, and shortwave broadcast
stations.
Railways
This entry states the total route length of the railway network and of
its component parts by gauge: broad, dual, narrow, standard, and other.
Reference maps
This section includes world and regional maps.
Religions
This entry includes a rank ordering of religions by adherents starting
with the largest group and sometimes includes the percent of total
population.
Sex ratio
This entry includes the number of males for each female in five age
groups - at birth, under 15 years, 15-64 years, 65 years and over, and
for the total population. Sex ratio at birth has recently emerged as an
indicator of certain kinds of sex discrimination in some countries. For
instance, high sex ratios at birth in some Asian countries are now
attributed to sex-selective abortion and infanticide due to a strong
preference for sons. This will affect future marriage patterns and
fertility patterns. Eventually it could cause unrest among young adult
males who are unable to find partners.
Suffrage
This entry gives the age at enfranchisement and whether the right to
vote is universal or restricted.
Telephone numbers
All telephone numbers in the Factbook consist of the country code in
brackets, the city or area code (where required) in parentheses, and
the local number. The one component that is not presented is the
international access code, which varies from country to country. For
example, an international direct dial telephone call placed from the US
to Madrid, Spain, would be as follows:
011 [34] (1) 577-xxxx, where
011 is the international access code for station-to-station calls;
01 is for calls other than station-to-station calls,
[34] is the country code for Spain,
(1) is the city code for Madrid,
577 is the local exchange, and
xxxx is the local telephone number.
An international direct dial telephone call placed from another country
to the US would be as follows:
international access code + [1] (202) 939-xxxx, where
[1] is the country code for the US,
(202) is the area code for Washington, DC,
939 is the local exchange, and
xxxx is the local telephone number.
Telephone system
This entry includes a brief characterization of the system with details
on the domestic and international components. The following terms and
abbreviations are used throughout the entry:
Africa ONE - a fiber-optic submarine cable link encircling the
continent of Africa.
Arabsat - Arab Satellite Communications Organization (Riyadh,
Saudi Arabia).
Autodin - Automatic Digital Network (US Department of Defense).
CB - citizen''s band mobile radio communications.
cellular telephone system - the telephones in this system are
radio transceivers, with each instrument having its own private radio
frequency and sufficient radiated power to reach the booster station in
its area (cell), from which the telephone signal is fed to a telephone
exchange.
Central American Microwave System - a trunk microwave radio relay
system that links the countries of Central America and Mexico with each
other.
coaxial cable - a multichannel communication cable consisting of a
central conducting wire, surrounded by and insulated from a cylindrical
conducting shell; a large number of telephone channels can be made
available within the insulated space by the use of a large number of
carrier frequencies.
Comsat - Communications Satellite Corporation (US).
DSN - Defense Switched Network (formerly Automatic Voice Network
or Autovon); basic general-purpose, switched voice network of the
Defense Communications System (US Department of Defense).
Eutelsat - European Telecommunications Satellite Organization
(Paris).
fiber-optic cable - a multichannel communications cable using a
thread of optical glass fibers as a transmission medium in which the
signal (voice, video, etc.) is in the form of a coded pulse of light.
GSM - a global system for mobile (cellular) communications devised
by the Groupe Special Mobile of the pan-European standardization
organization, Conference Europeanne des Posts et Telecommunications
(CEPT) in 1982.
HF - high frequency; any radio frequency in the 3,000- to 30,000-
kHz range.
Inmarsat - International Mobile Satellite Organization (London);
provider of global mobile satellite communications for commercial,
distress, and safety applications at sea, in the air, and on land.
Intelsat - International Telecommunications Satellite Organization
(Washington, DC).
Intersputnik - International Organization of Space Communications
(Moscow); first established in the former Soviet Union and the East
European countries, it is now marketing its services worldwide with
earth stations in North America, Africa, and East Asia.
landline - communication wire or cable of any sort that is
installed on poles or buried in the ground. Marecs - Maritime European
Communications Satellite used in the Inmarsat system on lease from the
European Space Agency.
Marisat - satellites of the Comsat Corporation that participate in
the Inmarsat system.
Medarabtel - the Middle East Telecommunications Project of the
International Telecommunications Union (ITU) providing a modern
telecommunications network, primarily by microwave radio relay, linking
Algeria, Djibouti, Egypt, Jordan, Libya, Morocco, Saudi Arabia,
Somalia, Sudan, Syria, Tunisia, and Yemen; it was initially started in
Morocco in 1970 by the Arab Telecommunications Union (ATU) and was
known at that time as the Middle East Mediterranean Telecommunications
Network.
microwave radio relay - transmission of long distance telephone
calls and television programs by highly directional radio microwaves
that are received and sent on from one booster station to another on an
optical path.
NMT - Nordic Mobile Telephone; an analog cellular telephone system
that was developed jointly by the national telecommunications
authorities of the Nordic countries (Denmark, Finland, Iceland, Norway,
and Sweden).
Orbita - a Russian television service; also the trade name of a
packet-switched digital telephone network.
radiotelephone communications - the two-way transmission and
reception of sounds by broadcast radio on authorized frequencies using
telephone handsets.
PanAmSat - PanAmSat Corporation (Greenwich, CT).
satellite communication system - a communication system consisting
of two or more earth stations and at least one satellite that provide
long distance transmission of voice, data, and television; the system
usually serves as a trunk connection between telephone exchanges; if
the earth stations are in the same country, it is a domestic system.
satellite earth station - a communications facility with a
microwave radio transmitting and receiving antenna and required
receiving and transmitting equipment for communicating with satellites.
satellite link - a radio connection between a satellite and an
earth station permitting communication between them, either one-way
(down link from satellite to earth station - television receive-only
transmission) or two-way (telephone channels).
SHF - super high frequency; any radio frequency in the 3,000- to
30,000-MHz range.
shortwave - radio frequencies (from 1.605 to 30 MHz) that fall
above the commercial broadcast band and are used for communication over
long distances.
Solidaridad - geosynchronous satellites in Mexico''s system of
international telecommunications in the Western Hemisphere.
Statsionar - Russia''s geostationary system for satellite
telecommunications.
submarine cable - a cable designed for service under water.
TAT - Trans-Atlantic Telephone; any of a number of high-capacity
submarine coaxial telephone cables linking Europe with North America.
telefax - facsimile service between subscriber stations via the
public switched telephone network or the international Datel network.
telegraph - a telecommunications system designed for unmodulated
electric impulse transmission.
telex - a communication service involving teletypewriters
connected by wire through automatic exchanges.
tropospheric scatter - a form of microwave radio transmission in
which the troposphere is used to scatter and reflect a fraction of the
incident radio waves back to earth; powerful, highly directional
antennas are used to transmit and receive the microwave signals;
reliable over-the-horizon communications are realized for distances up
to 600 miles in a single hop; additional hops can extend the range of
this system for very long distances.
trunk network - a network of switching centers, connected by
multichannel trunk lines.
UHF - ultra high frequency; any radio frequency in the 300- to
3,000-MHz range.
VHF - very high frequency; any radio frequency in the 30- to 300-
MHz range.
Telephones - main lines in use
This entry gives the total number of main telephone lines in use.
Telephones - mobile cellular
This entry gives the total number of mobile cellular telephones in use.
Television - broadcast stations
This entry gives the total number of separate broadcast stations plus
any repeater stations.
Terminology
Due to the highly structured nature of the Factbook database, some
collective generic terms have to be used. For example, the word Country
in the Country name entry refers to a wide variety of dependencies,
areas of special sovereignty, uninhabited islands, and other entities
in addition to the traditional countries or independent states.
Military is also used as an umbrella term for various civil defense,
security, and defense activities in many entries. The Independence
entry includes the usual colonial independence dates and former ruling
states as well as other significant nationhood dates such as the
traditional founding date or the date of unification, federation,
confederation, establishment, or state succession that are not strictly
independence dates. Dependent areas have the nature of their dependency
status noted in this same entry.
Terrain
This entry contains a brief description of the topography.
Total fertility rate
This entry gives a figure for the average number of children that would
be born per woman if all women lived to the end of their childbearing
years and bore children according to a given fertility rate at each
age. The total fertility rate is a more direct measure of the level of
fertility than the crude birth rate, since it refers to births per
woman. This indicator shows the potential for population growth in the
country. High rates will also place some limits on the labor force
participation rates for women. Large numbers of children born to women
indicate large family sizes that might limit the ability of the
families to feed and educate their children.
purchasing power parity - $30 million (2000 est.)
West Bank
purchasing power parity - $1.7 billion (2002 est.)
NA (2003 est.)
West Bank
3.3% (2003 est.)
NA%
West Bank
-22% (2002 est.)
purchasing power parity - $2,000 (2000 est.)
West Bank
purchasing power parity - $800 (2002 est.)
overseas territory of France
This page was last updated on 18 December, 2003
======================================================================
@2007 Diplomatic representation from the US','8f02bbe6ae8124f65665ea67ed1d9f84ea0e2f39ffcd53df78902a5dd870a46b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de26e760a124c5ac3a781ceba1419487f819aaa57317b4d730b1783e1d33f2bb',2003,'AR','Argentina','people-and-society',206,'Religions:
nominally Roman Catholic 96%, Protestant 2%, other 2%
Languages:
Spanish (official), numerous indigenous dialects
Literacy:
definition: age 15 and over can read and write
total population: 93.4%
male: 93.8%
female: 93.1% (2003 est.)
Government Venezuela
Country name:
conventional long form: Bolivarian Republic of Venezuela
conventional short form: Venezuela
local short form: Venezuela
local long form: Republica Bolivariana de Venezuela
Government type:
federal republic
Capital:
Caracas
Administrative divisions:
23 states (estados, singular - estado), 1 federal district*
(distrito federal), and 1 federal dependency** (dependencia
federal); Amazonas, Anzoategui, Apure, Aragua, Barinas, Bolivar,
Carabobo, Cojedes, Delta Amacuro, Dependencias Federales**, Distrito
Federal*, Falcon, Guarico, Lara, Merida, Miranda, Monagas, Nueva
Esparta, Portuguesa, Sucre, Tachira, Trujillo, Vargas, Yaracuy, Zulia
note: the federal dependency consists of 11 federally controlled
island groups with a total of 72 individual islands
Independence:
5 July 1811 (from Spain)
National holiday:
Independence Day, 5 July (1811)
Constitution:
30 December 1999
Legal system:
based on organic laws as of July 1999; open, adversarial court
system; has not accepted compulsory ICJ jurisdiction
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Hugo CHAVEZ Frias (since 3 February
1999); Vice President Jose Vicente RANGEL (since 28 April 2002);
note - the president is both the chief of state and head of
purchasing power parity - $403.8 billion (2002 est.)
1.05% (2003 est.)
-10.9% (2002 est.)
purchasing power parity - $10,500 (2002 est.)
chief of mission: Ambassador James D. WALSH; note - Lino
GUTIERREZ is designated to replace Ambassador WALSH
embassy: Avenida Colombia 4300, C1425GMN Buenos Aires
mailing address: international mail: use street address; APO
address: Unit 4334, APO AA 34034
telephone: [54] (11) 5777-4533
FAX: [54] (11) 5777-4240','079d71f805fd9065e02cbef0d0af486e8a58852df6a17412517994bd1055e811','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad59a6cdff49ff8b11eab9ff6d2590fb9638fda894c34d289f965ac0697e249d',2003,'AF','Afghanistan','people-and-society',208,'purchasing power parity - $19 billion (2002 est.)
3.38%
note: this rate does not take into consideration the recent war and
its continuing impact (2003 est.)
NA%
purchasing power parity - $700 (2002 est.)
chief of mission: Ambassador Robert Patrick John FINN;
note - embassy in Kabul reopened 16 December 2001, following closure
in January 1989
embassy: Great Masood Road, Kabul
mailing address: 6180 Kabul Place, Dulles, VA 20189-6180
telephone: [93] (2) 290002, 290005, 290154
FAX: 00932290153','ce570097e9f0fcf281cc1a0009206c453619d89c3ca33c6752c3ae739cec66e1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f27bf5552d91129fdab9e67d4f253d071bb77d4ffa50178647b55e58e8bd3b3d',2003,'AL','Albania','people-and-society',209,'purchasing power parity - $15.69 billion (2002 est.)
1.03% (2003 est.)
7.3% (2002 est.)
purchasing power parity - $4,400 (2002 est.)
chief of mission: Ambassador James F. JEFFREY
embassy: Rruga Elbasanit, Labinoti #103, Tirana
mailing address: U. S. Department of State, 9510 Tirana Place,
Washington, DC 20521-9510
telephone: [355] (4) 247285
FAX: [355] (4) 232222','2c32edefaf11e37c07d71cd4d64f907307092eacec2b59be26f75f54ccd6a65a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c639cd9d8b28b630e2041ba24eb6479f9cfb6e83ca9f9ddecfac4882a4181013',2003,'DZ','Algeria','people-and-society',210,'purchasing power parity - $173.8 billion (2002 est.)
1.65% (2003 est.)
3.3% (2002 est.)
purchasing power parity - $5,400 (2002 est.)
chief of mission: Ambassador Richard W. ERDMAN (as of 10
July 2003)
embassy: 4 Chemin Cheikh Bachir El-Ibrahimi, Algiers
mailing address: B. P. Box 549, Alger-Gare, 16000 Algiers
telephone: [213] (21) 691-425/255/186
FAX: [213] (21) 69-39-79','865351642a4e3694abf938610dd0edc0084524218812c75ec36b7eaa3aa45bdb','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f760b7d480ad1b49fc0cdc665d75d24218ab82eb30cb36fd0d98459c70ddf133',2003,'AS','American Samoa','people-and-society',211,'purchasing power parity - $500 million (2000 est.)
2.22% (2003 est.)
NA%
purchasing power parity - $8,000 (2000 est.)
unincorporated and unorganized territory of the US;
administered by the Office of Insular Affairs, US Department of the
Interior
none (territory of the US)','e4d45ea17b038a789843ebe1c32e71329f3cdc3ba575fc72079e9e8f6b6ae1ca','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b590715092c77a1517c10488be1d302a6dfe551dd64109fbd2c70e1e8df67568',2003,'AD','Andorra','people-and-society',212,'purchasing power parity - $1.3 billion (2000 est.)
1.06% (2003 est.)
3.8% (2000 est.)
purchasing power parity - $19,000 (2000 est.)
the US does not have an embassy in Andorra; the US
Ambassador to Spain is accredited to Andorra; US interests in
Andorra are represented by the Consulate General''s office in
Barcelona (Spain); mailing address: Paseo Reina Elisenda, 23, 08034
Barcelona, Spain; telephone: (3493) 280-2227; FAX: (3493) 205-7705','680efdb84a46e54de38bc6c6536bbdd6c7c65281db19d32aadc9305b1cd71442','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('415e4d6f9a1bf99b9d7567359c6bcaabad110b3656f8aa4e7fb9ac2d5ae7a84b',2003,'AO','Angola','people-and-society',213,'purchasing power parity - $18.36 billion (2002 est.)
1.97% (2003 est.)
9.4% (2002 est.)
purchasing power parity - $1,700 (2002 est.)
chief of mission: Ambassador Christopher William DELL
embassy: number 32 Rua Houari Boumedienne (in the Miramar area of
Luanda), Luanda
mailing address: international mail: Caixa Postal 6468, Luanda;
pouch: American Embassy Luanda, Department of State, Washington, DC
20521-2550
telephone: [244] (2) 445-481, 447-028, 446-224
FAX: [244] (2) 446-924','24cb5d2882b6565b27da1f0a08827b9837fc122fa8529ae4754e8e84b6e8b12a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90a6909709ee8fd449a10e6e396332028defb38be1178b838eef90c4acefe5ea',2003,'AI','Anguilla','people-and-society',214,'purchasing power parity - $104 million (2001 est.)
2.21% (2003 est.)
2.8% (2001 est.)
purchasing power parity - $8,600 (2001 est.)
overseas territory of the UK
none (overseas territory of the UK)','9c80baeb1cf6d37a038899b95680eb22f974e20a73e6c416e208e35d576344c0','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b671ef752f2612bf764370f0939bd572eda464db4083231840591d912ef48c3a',2003,'AG','Antigua and Barbuda','people-and-society',215,'purchasing power parity - $750 million (2002
est.)
0.64% (2003 est.)
3% (2002 est.)
purchasing power parity - $11,000 (2002 est.)
the US does not have an embassy in Antigua and
Barbuda (embassy closed 30 June 1994); the US Ambassador to Barbados
is accredited to Antigua and Barbuda','b8f7e6f85edc8c824a413309b87aec05c530f5e9f92a162948a94272bd6aa2ec','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8e811e20611ed47929404f7b92e071b5cbadab5a1d856d39426f05ed270396d',2003,'AM','Armenia','people-and-society',216,'purchasing power parity - $12.13 billion (2002 est.)
-0.07% (2003 est.)
12.9% (2002 est.)
purchasing power parity - $3,600 (2002 est.)
chief of mission: Ambassador John M. ORDWAY
embassy: 18 Baghramyan Ave., Yerevan 375019
mailing address: American Embassy Yerevan, Department of State, 7020
Yerevan Place, Washington, DC 20521-7020
telephone: [374](1) 521-611, 520-791, 542-177, 542-132, 524-661,
527-001, 524-840
FAX: [374](1) 520-800','9fe278181b3b0090d114ab7dead3f4fd8b3e85e94c523eccf78f2a08bfc6649d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d11794f00d37fe6547111ddaf04aeb843742c699cb9b603aa048ebab1d2e8bc',2003,'AW','Aruba','people-and-society',217,'purchasing power parity - $1.94 billion (2002 est.)
0.55% (2003 est.)
-1.5% (2002 est.)
purchasing power parity - $28,000 (2002 est.)
part of the Kingdom of the Netherlands; full autonomy in
internal affairs obtained in 1986 upon separation from the
Netherlands Antilles; Dutch Government responsible for defense and
foreign affairs
Ashmore and Cartier Islands
territory of Australia; administered by
the Australian Department of Transport and Regional Services
Baker Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
Bassas da India
possession of France; administered by a high
commissioner of the Republic, resident in Reunion
the US does not have an embassy in Aruba; the Consul General
to Netherlands Antilles is accredited to Aruba
Ashmore and Cartier Islands
none (territory of Australia)','c6eb28d1f44d039e814e69d063f8d6955058f6cc63455f11a5d2e8e39a88480c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3333b334104365336b410aebb395111f2b4c62740b6b4d00f97e5115ba731c6f',2003,'AU','Australia','people-and-society',218,'purchasing power parity - $525.5 billion (2002 est.)
0.93% (2003 est.)
3.6% (2002 est.)
purchasing power parity - $26,900 (2002 est.)
chief of mission: Ambassador J. Thomas SCHIEFFER
embassy: Moonah Place, Yarralumla, Canberra, Australian Capital
Territory 2600
mailing address: APO AP 96549
telephone: [61] (02) 6214-5600
FAX: [61] (02) 6214-5970
consulate(s) general: Melbourne, Perth, Sydney','acba1627e92039b1edf131f2d8da72e63d87edaa3b78398dccd5cc5a0cb52331','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f38a9f5c4461291669c3d81744facb1011c730b02d361fe32c812d223ab9d221',2003,'AT','Austria','people-and-society',219,'purchasing power parity - $227.7 billion (2002 est.)
0.22% (2003 est.)
1.1% (2002 est.)
purchasing power parity - $27,900 (2002 est.)
chief of mission: Ambassador William Lee LYONS BROWN, Jr.
embassy: Boltzmanngasse 16, A-1090, Vienna
mailing address: use embassy street address
telephone: [43] (1) 31339, 31375, 31335
FAX: [43] (1) 5125835','212d9b4bf2826c58434f106defb1572f98ee750c649e0b6b50087d3f4e64f252','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5baec03024576a46644a9382aabf4d5248062eeb366faba7f49379a64a5adeae',2003,'AZ','Azerbaijan','people-and-society',220,'purchasing power parity - $28.61 billion (2002 est.)
Bahamas, The
purchasing power parity - $4.59 billion (2002 est.)
0.44% (2003 est.)
Bahamas, The
0.77% (2003 est.)
10.6% (2002 est.)
Bahamas, The
0.1% (2002 est.)
purchasing power parity - $3,700 (2002 est.)
Bahamas, The
purchasing power parity - $15,300 (2002 est.)
chief of mission: Ambassador Ross L. WILSON
embassy: 83 Azadliq Prospekt, Baku 370007
mailing address: American Embassy Baku, Department of State, 7050
Baku Place, Washington, DC 20521-7050
telephone: [9] (9412) 98-03-35, 36, 37
FAX: [9] (9412) 90-66-71
Bahamas, The
chief of mission: Ambassador (vacant); Charge d''Affairs
Robert M. WITAJEWSKI
embassy: 42 Queen Street, Nassau
mailing address: local or express mail address: P. O. Box N-8197,
Nassau; Department of State, 3370 Nassau Place, Washington, DC
20521-3370
telephone: [1] (242) 322-1181, 328-2206 (after hours)
FAX: [1] (242) 356-0222','306c65a170c0cf8c83ed99267d5b4baf966922a729be4744982675df5179a5da','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57d21ca663b01fa083324ee8a551f88fab807eadb42a29f912b4cf60651287fa',2003,'BH','Bahrain','people-and-society',221,'purchasing power parity - $9.91 billion (2002 est.)
1.61% (2003 est.)
2.9% (2002 est.)
purchasing power parity - $15,100 (2002 est.)
chief of mission: Ambassador Ronald E. NEUMANN
embassy: Building #979, Road 3119 (next to Al-Ahli Sports Club),
Block 321, Zinj District, Manama
mailing address: American Embassy Manama, PSC 451, FPO AE
09834-5100; international mail: American Embassy, Box 26431, Manama
telephone: [973] 273-300
FAX: [973] 272-594','a880e8e5d874daacc5c77c1e59f2283f928283fbded315fb4945fd6b3d07bf9e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5e8b9509301e263213b2a11121f3849d64b2e6d747edccbcc60b85128a11685',2003,'BD','Bangladesh','people-and-society',222,'purchasing power parity - $238.2 billion (2002 est.)
2.06% (2003 est.)
4.8% (2002 est.)
purchasing power parity - $1,800 (2002 est.)
chief of mission: Ambassador Mary Ann PETERS
embassy: Madani Avenue, Baridhara, Dhaka 1212
mailing address: G. P. O. Box 323, Dhaka 1000
telephone: [880] (2) 8824700 through 8824722
FAX: [880] (2) 8823744','bc5f27b7670cabe6a55afe93362aa37cc1733dc566cf768b8dd515a0f13826a7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b251ec7272b20ec71b88474f89db8a591b6549e73e97dade9e89d9a67ac6cf4f',2003,'BB','Barbados','people-and-society',223,'purchasing power parity - $4.153 billion (2002 est.)
0.38% (2003 est.)
-2.8% (2002 est.)
purchasing power parity - $15,000 (2002 est.)
chief of mission: Ambassador Earl N. PHILLIPS, Jr.
embassy: Canadian Imperial Bank of Commerce Building, Broad Street,
Bridgetown; (courier) ALICO Building-Cheapside, Bridgetown
mailing address: P. O. Box 302, Bridgetown; FPO AA 34055
telephone: [1] (246) 436-4950
FAX: [1] (246) 429-5246, 429-3379','d55955cb50e071b23b2bdcd5f0d392ada9916a8ccba0d3cfe6137d4177aa1cc1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd5dc868c2879835e206f4868eb35ae04fdd45898188bef096ed6278a380fc4d',2003,'BY','Belarus','people-and-society',224,'purchasing power parity - $90.19 billion (2002 est.)
-0.12% (2003 est.)
4.7% (2002 est.)
purchasing power parity - $8,700 (2002 est.)
chief of mission: Ambassador Michael G. KOZAK
embassy: 46 Starovilenskaya St., Minsk 220002
mailing address: PSC 78, Box B Minsk, APO 09723
telephone: [375] (17) 210-12-83
FAX: [375] (17) 234-7853','c5e927a53afea8c85ba4b3a8590dfba2693cedb3acff127b98f50730f63c459c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b915cb72b3c8efed95a600b0cf690deb108d2fde43c5e4dc9b2496699bdb51f4',2003,'BE','Belgium','people-and-society',225,'purchasing power parity - $299.7 billion (2002 est.)
0.14% (2003 est.)
0.7% (2002 est.)
purchasing power parity - $29,200 (2002 est.)
chief of mission: Ambassador Stephen Franklin BRAUER
embassy: Regentlaan 27 Boulevard du Regent, B-1000 Brussels
mailing address: PSC 82, Box 002, APO AE 09710
telephone: [32] (2) 508-2111
FAX: [32] (2) 511-2725','c6e89761dc1e4e359f00864ca0dc775098eb48f74383106ee3f68a932ea16d15','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5769c159998f2f258bb430274b63ae2a5d1ec0b9c29a15bad58eb56e89f959f2',2003,'BZ','Belize','people-and-society',226,'purchasing power parity - $1.28 billion (2002 est.)
2.44% (2003 est.)
3.7% (2002 est.)
purchasing power parity - $4,900 (2002 est.)
chief of mission: Ambassador Russell F. FREEMAN
embassy: 29 Gabourel Lane and Hutson Street, Belize City
mailing address: P. O. Box 286, Unit 7401, APO AA 34025
telephone: [501] 227-7161 through 7163
FAX: [501] 30802','1e79fa6c11b45ba8d712458697b6c6fa76c849cadf27b52d49aba4e5a815af38','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9509bfdd9a9231286cb763c592b230dd549574d04bde7c25ddd39f9f52be569c',2003,'BJ','Benin','people-and-society',227,'purchasing power parity - $7.38 billion (2002 est.)
2.95% (2003 est.)
6% (2002 est.)
purchasing power parity - $1,100 (2002 est.)
chief of mission: Ambassador Wayne NEILL
embassy: Rue Caporal Bernard Anani, Cotonou
mailing address: 01 B. P. 2012, Cotonou
telephone: [229] 30-06-50
FAX: [229] 30-06-70','ffb58ebaabf71d1ee137ca079d630a0d0fb9b485db2ec10a3e5df6b131d55c4b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d2d09e68f464f8398c42df61d4283d34bf3f5264ec786afd53cddac238136c6',2003,'BM','Bermuda','people-and-society',228,'purchasing power parity - $2.25 billion (2002 est.)
0.72% (2003 est.)
0.5% (2002 est.)
purchasing power parity - $35,200 (2002 est.)
overseas territory of the UK
chief of mission: Consul General Denis Patrick COLEMAN, Jr.
consulate(s) general: Crown Hill, 16 Middle Road, Devonshire DVO3
mailing address: P. O. Box HM325, Hamilton HMBX; American Consulate
General Hamilton, Department of State, 5300 Hamilton Place,
Washington, DC 20520-5300
telephone: [1] (441) 295-1342
FAX: [1] (441) 295-1592, [1] (441) 296-9233','52eff829b28dbf5799dbe9de3f5fe050ace0406528151d194b5e514f024d6490','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7bcdae8a62bfdbe4eae77e525ba63e5c931405622bcdb3da0bbf49bdd59b7af',2003,'BT','Bhutan','people-and-society',229,'purchasing power parity - $2.7 billion (2002 est.)
Bolivia
purchasing power parity - $21.15 billion (2002 est.)
2.14% (2003 est.)
Bolivia
1.63% (2003 est.)
7.7% (2002 est.)
Bolivia
2.8% (2002 est.)
purchasing power parity - $1,300 (2002 est.)
Bolivia
purchasing power parity - $2,500 (2002 est.)
the US and Bhutan have no formal diplomatic relations,
although informal contact is maintained between the Bhutanese and US
Embassy in New Delhi (India)
Bolivia
chief of mission: Ambassador David N. GREENLEE
embassy: Avenida Arce 2780, San Jorge, La Paz
mailing address: P. O. Box 425, La Paz; APO AA 34032
telephone: [591] (2) 2430120, 2430251
FAX: [591] (2) 2433900','2ebddd7c9e313a04582349fb15b659fdce39af7f33957d18c0fd48fee835f5c5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7981c6c7b84a807a8c5453f70cf2337a841f9f097bb1ef65338c9f9d35725fb4',2003,'BA','Bosnia and Herzegovina','people-and-society',230,'purchasing power parity - $7.3 billion (2002
est.)
0.48% (2003 est.)
2.3% (2002 est.)
purchasing power parity - $1,900 (2002 est.)
chief of mission: Ambassador Clifford G. BOND
embassy: Alipasina 43, 71000 Sarajevo
mailing address: use street address
telephone: [387] (33) 445-700
FAX: [387] (33) 659-722
branch office(s): Banja Luka, Mostar','9d3236943a3b7d3b5783ca940c75256031bc693aebe917da9de6e5cd2fd290a1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77d19d1de04b2f7d378705d7be20464c7c7dc5f8dd1a210909d65a8937d99a4b',2003,'BW','Botswana','people-and-society',231,'purchasing power parity - $13.48 billion (2002 est.)
-0.55% (2003 est.)
4.2% (2002 est.)
purchasing power parity - $8,500 (2002 est.)
chief of mission: Ambassador Joseph HUGGINS
embassy: address NA, Gaborone
mailing address: Embassy Enclave, P. O. Box 90, Gaborone
telephone: [267] 353982
FAX: [267] 312782','e83ff908d86ba034dd417b5f785077defa817674f790bf966b2f2d0a4c986423','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6aa8ccb179aa23adb138f9fa5edf32d845de1f702d824fef58d91243011bf005',2003,'BR','Brazil','people-and-society',232,'purchasing power parity - $1.376 trillion (2002 est.)
British Virgin Islands
purchasing power parity - $320 million (2002
est.)
Brunei
purchasing power parity - $6.5 billion (2002 est.)
1.15% (2003 est.)
British Virgin Islands
2.1% (2003 est.)
Brunei
2% (2003 est.)
1.5% (2002 est.)
British Virgin Islands
1% (2002 est.)
Brunei
3% (2002 est.)
purchasing power parity - $7,600 (2002 est.)
British Virgin Islands
purchasing power parity - $16,000 (2002 est.)
Brunei
purchasing power parity - $18,600 (2002 est.)
chief of mission: Ambassador Donna J. HRINAK
embassy: Avenida das Nacoes, Quadra 801, Lote 3, Distrito Federal
Cep 70403-900, Brasilia
mailing address: Unit 3500, APO AA 34030
telephone: [55] (61) 312-7000
FAX: [55] (61) 225-9136
consulate(s) general: Rio de Janeiro, Sao Paulo
consulate(s): Recife','d251d549306b15fdab688972f27b267d729b3af472f41edf750d2d7fa0051c66','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56df2fc6f29c124e620ca9a11060399653c7ff24a9e939301fec626ed79423f0',2003,'BG','Bulgaria','people-and-society',233,'purchasing power parity - $49.23 billion (2002 est.)
-1.09% (2003 est.)
4.8% (2002 est.)
purchasing power parity - $6,500 (2002 est.)
chief of mission: Ambassador James William PARDEW
embassy: 1 Suborna Street, Sofia 1000
mailing address: American Embassy Sofia, Department of State, 5740
Sofia Place, Washington, DC 20521-5740
telephone: [359] (2) 937-5100
FAX: [359] (2) 981-89-77','215d79b02e60baf24378b7fd62b611d960bffa61c602a5d1d7e4a1e878864eda','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('757939201dcb81fbadb9ba8556a8d015cd3339c0ed3fff7bc0f49a5ef3518039',2003,'BF','Burkina Faso','people-and-society',234,'purchasing power parity - $14.51 billion (2002 est.)
Burma
purchasing power parity - $73.69 billion (2002 est.)
2.6% (2003 est.)
Burma
0.52% (2003 est.)
4.6% (2002 est.)
Burma
5.3% (2002 est.)
purchasing power parity - $1,100 (2002 est.)
Burma
purchasing power parity - $1,700 (2002 est.)
chief of mission: Ambassador Anthony HOLMES
embassy: 602 Avenue Raoul Follereau, Koulouba, Secteur 4
mailing address: 01 B. P. 35, Ouagadougou 01; pouch mail - U. S.
Department of State, 2440 Ouagadougou Place, Washington, DC
20521-2440
telephone: [226] 306723
FAX: [226] 303890
Burma
chief of mission: Permanent Charge d''Affaires Carmen M.
MARTINEZ
embassy: 581 Merchant Street, Rangoon (GPO 521)
mailing address: Box B, APO AP 96546
telephone: [95] (1) 379 880, 379 881
FAX: [95] (1) 256 018','eb564d5d0a4e7e90a3baa5911da71018b3fb393ecba284c3e8ca44b1ca93fba8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52cb8159ef2a1894adedaf258a126cd82a5de55c27fbb231d4364ceda726c4c4',2003,'BI','Burundi','people-and-society',235,'purchasing power parity - $3.146 billion (2002 est.)
2.18% (2003 est.)
4.5% (2002 est.)
purchasing power parity - $500 (2002 est.)
chief of mission: Ambassador James Howard YELLIN
embassy: Avenue des Etats-Unis, Bujumbura
mailing address: B. P. 1720, Bujumbura
telephone: [257] 223454
FAX: [257] 222926','b8a2045e1a65da8440f28841701a92431451215eea24c5590a96f5db3de5d5ab','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11b4898590e2e75141940ce9f9116d60d789e85f63271c55001e98e5d40a2f67',2003,'KH','Cambodia','people-and-society',236,'purchasing power parity - $20.42 billion (2002 est.)
1.8% (2003 est.)
4.5% (2002 est.)
purchasing power parity - $1,600 (2002 est.)
chief of mission: Ambassador Charles Aaron RAY
embassy: 27 EO Street 240, Phnom Penh
mailing address: Box P, APO AP 96546
telephone: [855] (23) 216-436/438
FAX: [855] (23) 216-437/811','81c0e74cdb87a3bf310a01e76f7674707e2e69160e2ab3c10841136d0e5f07aa','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb6513ce67c26a319b81d8dfafd10102c768babe562c475a3a0783e47b97e794',2003,'CM','Cameroon','people-and-society',237,'purchasing power parity - $26.84 billion (2002 est.)
2.02% (2003 est.)
4% (2002 est.)
purchasing power parity - $1,700 (2002 est.)
chief of mission: Ambassador George McDade STAPLES
embassy: Rue Nachtigal, Yaounde
mailing address: P. O. Box 817, Yaounde; pouch: American Embassy,
Department of State, Washington, DC 20521-2520
telephone: [237] 223-05-12, 222-25-89, 222-17-94, 223-40-14
FAX: [237] 223-07-53
branch office(s): Douala','6188b45a8e212f6c15269e99ed17db3ebc30ac4e3b4d4a495d34cd694420e003','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7356e4fb64f08e67a6893ff8f83458f7430b7c29730ca7b47ed432782d3b724',2003,'CA','Canada','people-and-society',238,'purchasing power parity - $934.1 billion (2002 est.)
Cape Verde
purchasing power parity - $600 million (2002 est.)
0.94% (2003 est.)
Cape Verde
0.79% (2003 est.)
3.3% (2002 est.)
Cape Verde
4% (2002 est.)
purchasing power parity - $29,300 (2002 est.)
Cape Verde
purchasing power parity - $1,400 (2002 est.)
chief of mission: Ambassador Paul CELLUCCI
embassy: 490 Sussex Drive, Ottawa, Ontario K1N 1G8
mailing address: P. O. Box 5000, Ogdensburgh, NY 13669-0430
telephone: [1] (613) 238-5335, 4470
FAX: [1] (613) 688-3097
consulate(s) general: Calgary, Halifax, Montreal, Quebec, Toronto,
and Vancouver
Cape Verde
chief of mission: Ambassador Donald C. JOHNSON
embassy: Rua Abilio m. Macedo 81, Praia
mailing address: C. P. 201, Praia
telephone: [238] 61 56 16, 61 56 17
FAX: [238] 61 13 55','1173ad6064fd55fda52c1e618a9e24266d69b070171ac826e81f941b56c1c94a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2afae120e831377cc71a61ee13aca4000c016cb6324c2e455ddad9ba8b0aa78b',2003,'KY','Cayman Islands','people-and-society',239,'purchasing power parity - $1.27 billion (2002 est.)
2.79% (2003 est.)
1.7% (2002 est.)
purchasing power parity - $35,000 (2002 est.)
overseas territory of the UK
none (overseas territory of the UK)','007bbd56095435317b2d7e6ab15dba6b6dc5b38f11953a061689b6a1ebac82f7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84fee2ad9cfd554b10c806bda0f847eced8b2dfdf291fe5102e235936c2a67ed',2003,'CF','Central African Republic','people-and-society',240,'purchasing power parity - $4.296 billion
(2002 est.)
1.62% (2003 est.)
1.5% (2002 est.)
purchasing power parity - $1,200 (2002 est.)
chief of mission: Ambassador Mattie R.
SHARPLESS
embassy: Avenue David Dacko, Bangui
mailing address: B. P. 924, Bangui
telephone: [236] 61 02 00
FAX: [236] 61 44 94','f7d489aef71d7fa436387ff6d6bd24221d5015bbec90cadb034a1458dbc8ff10','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a065d6867b06ccb7db2d069674e65b3c52f67f29de956897df313d077fa4b84',2003,'TD','Chad','people-and-society',241,'purchasing power parity - $9.297 billion (2002 est.)
3.07% (2003 est.)
7.4% (2002 est.)
purchasing power parity - $1,000 (2002 est.)
chief of mission: Ambassador Christopher E. GOLDTHWAIT
embassy: Avenue Felix Eboue, N''Djamena
mailing address: B. P. 413, N''Djamena
telephone: [235] (51) 70-09
FAX: [235] (51) 56-54','e9478d3198bb3cc62a7d8f8098e4a6d81338c4d253397788636a651c5ef4d65a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fa04b0b6b69564ac63b3d09ac7c4c565c5aff079fb0578e069bcfa9797297ca',2003,'CL','Chile','people-and-society',242,'purchasing power parity - $156.1 billion (2002 est.)
1.05% (2003 est.)
2.1% (2002 est.)
purchasing power parity - $10,100 (2002 est.)
chief of mission: Ambassador William R. BROWNFIELD
embassy: Avenida Andres Bello 2800, Las Condes, Santiago
mailing address: APO AA 34033
telephone: [56] (2) 232-2600
FAX: [56] (2) 330-3710','113beefca41fbe77a22586a825800236d2cb87ce411fd8792bfb8809e7bd28e2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c355d868237800c3d71302abd3e10d5f7130b09350ce745cf21cf0023ed475e2',2003,'CN','China','people-and-society',243,'purchasing power parity - $5.989 trillion (2002 est.)
0.6% (2003 est.)
8% (official data) (2002 est.)
purchasing power parity - $4,700 (2002 est.)
chief of mission: Ambassador Clark T. RANDT, Jr.
embassy: Xiu Shui Bei Jie 3, 100600 Beijing
mailing address: PSC 461, Box 50, FPO AP 96521-0002
telephone: [86] (10) 6532-3831
FAX: [86] (10) 6532-6929
consulate(s) general: Chengdu, Guangzhou, Hong Kong, Shanghai,
Shenyang','52ec0fc542db0b90118d6dc5f234d0fa8e21bc8ce2a4ec5eff8def23b7c09f82','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcbc4f3b790c7e261ecf5eaa4f53eaa2004739d1b77bc77cd8d32ced88deffcb',2003,'CX','Christmas Island','people-and-society',244,'purchasing power parity - $NA
-9% (2003 est.)
NA%
purchasing power parity - $NA
territory of Australia; administered by the
Australian Department of Transport and Regional Services
Clipperton Island
possession of France; administered by France from
French Polynesia by a high commissioner of the Republic
none (territory of Australia)','70c07a2b5cbef1eacb12c2789627a38fc87490dd4eef933c35f7b650daf2b493','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b12ca6bd95f73a2c4932c71f6b374cff3c7f89520d681896ae3c2b576bb8bc12',2003,'CC','Cocos (Keeling) Islands','people-and-society',245,'purchasing power parity - $NA
0% (2003 est.)
NA%
purchasing power parity - $NA
territory of Australia; administered from
Canberra by the Australian Department of Transport and Regional
Services
none (territory of Australia)','5fc44db9cbbc3fb4a8bfb639dc09a7fd12e79802bc152de2445ad5c2feb24a80','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d14bf7d83347476dc1a355e52073a1d8538f9192a5e56182f6be3e0431a914a7',2003,'CO','Colombia','people-and-society',246,'purchasing power parity - $251.6 billion (2002 est.)
1.56% (2003 est.)
1.5% (2002 est.)
purchasing power parity - $6,100 (2002 est.)
chief of mission: Ambassador Anne W. PATTERSON
embassy: Calle 22D-BIS, numbers 47-51, Apartado Aereo 3831
mailing address: Carrera 45 #22D-45, Bogota, D.C., APO AA 34038
telephone: [57] (1) 315-0811
FAX: [57] (1) 315-2197','541e680428d62e004411a9c26e8819cfd4e321e2b531e9f9f052f709b551fe97','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('add7937af7c8af28395fd8b276215c1ebce9d95192745dbcec925bbc6ac06dfc',2003,'KM','Comoros','people-and-society',247,'purchasing power parity - $441 million (2002 est.)
Congo, Democratic Republic of the
purchasing power parity - $34
billion (2002 est.)
Congo, Republic of the
purchasing power parity - $2.5 billion (2002
est.)
2.96% (2003 est.)
Congo, Democratic Republic of the
2.9% (2003 est.)
Congo, Republic of the
1.53% (2003 est.)
2% (2002 est.)
Congo, Democratic Republic of the
3.5% (2002 est.)
Congo, Republic of the
0% (2002 est.)
purchasing power parity - $700 (2002 est.)
Congo, Democratic Republic of the
purchasing power parity - $600
(2002 est.)
Congo, Republic of the
purchasing power parity - $900 (2002 est.)
the US does not have an embassy in Comoros; the ambassador
to Mauritius is accredited to Comoros
Congo, Democratic Republic of the
chief of mission: Ambassador
Aubrey HOOKS
embassy: 310 Avenue des Aviateurs, Kinshasa
mailing address: Unit 31550, APO AE 09828
telephone: [243] (88) 43608
FAX: [243] (88) 43467
Congo, Republic of the
chief of mission: Ambassador Robin R. SANDERS
embassy: NA
mailing address: NA
telephone: [243] (88) 43608
note: the embassy is temporarily collocated with the US Embassy in
the Democratic Republic of the Congo (US Embassy Kinshasa, 310
Avenue des Aviateurs, Kinshasa)','6e150fc4657ab02e86799e6f0acec22af153a351bacfa93ec95e92df8d934135','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bebeef4561c91cd50e7537fe45da776977624519000e4661a9ec33ee84916a2',2003,'CK','Cook Islands','people-and-society',248,'purchasing power parity - $105 million (2001 est.)
NA% (2003 est.)
7.1% (2001 est.)
purchasing power parity - $5,000 (2001 est.)
self-governing in free association with New Zealand;
Cook Islands is fully responsible for internal affairs; New Zealand
retains responsibility for external affairs and defense, in
consultation with the Cook Islands
Coral Sea Islands
territory of Australia; administered from Canberra
by the Department of the Environment, Sport, and Territories
Europa Island
possession of France; administered by a high
commissioner of the Republic, resident in Reunion
Falkland Islands (Islas Malvinas)
overseas territory of the UK; also
claimed by Argentina
none (self-governing in free association with New
Zealand)
Coral Sea Islands
none (territory of Australia)','79d4f51dbe3bd2234586614168c1f63c6943b08ac97d85a699e8e215cafb27df','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34826cabea0a07d60e53519a4439e197b6cd14676f58c7887095d433511652ae',2003,'CR','Costa Rica','people-and-society',249,'purchasing power parity - $32 billion (2002 est.)
Cote d''Ivoire
purchasing power parity - $24.03 billion (2002 est.)
1.56% (2003 est.)
Cote d''Ivoire
2.15% (2003 est.)
2.8% (2002 est.)
Cote d''Ivoire
-1.6% (2002 est.)
purchasing power parity - $8,300 (2002 est.)
Cote d''Ivoire
purchasing power parity - $1,400 (2002 est.)
chief of mission: Ambassador John J. DANILOVICH
embassy: Calle 120 Avenida O, Pavas, San Jose
mailing address: APO AA 34020
telephone: [506] 220-3939
FAX: [506] 220-2305
Cote d''Ivoire
chief of mission: Ambassador Arlene RENDER
embassy: 5 Rue Jesse Owens, Abidjan
mailing address: B. P. 1712, Abidjan 01
telephone: [225] 20 21 09 79
FAX: [225] 20 22 32 59','7ab1ec2aa12d9f3c9720a54170630ce904d98992c17a58e8b7daae6cdbc3c07f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea6e26005763f4ab90e1ef99d56af55a843bddc7ef896648da6f721425355272',2003,'HR','Croatia','people-and-society',250,'purchasing power parity - $43.12 billion (2002 est.)
0.31% (2003 est.)
5.2% (2002 est.)
purchasing power parity - $9,800 (2002 est.)
chief of mission: Ambassador Ralph FRANK
embassy: Thomasa Jeffersona 2, 10010 Zagreb
mailing address: use street address
telephone: [385] (1) 661-2200
FAX: [385] (1) 661-2373','0469d2804a00641d5747d1fe8c8bbe945dfcd30dc06d203ba8e76216df24de43','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9091be404dabb97bf72b822898fc324d06c812b810af836c299137d4a06de256',2003,'CU','Cuba','people-and-society',251,'purchasing power parity - $30.69 billion (2002 est.)
0.34% (2003 est.)
1.1% (2002 est.)
purchasing power parity - $2,700 (2002 est.)
none; note - the US has an Interests Section in the Swiss
Embassy, headed by Principal Officer James C. CASON; address: USINT,
Swiss Embassy, Calzada between L and M Streets, Vedado, Havana;
telephone: [53] (7) 33-3551 through 3559 (operator assistance
required); FAX: [53] (7) 33-3700; protecting power in Cuba is','d26d5fa4c2e4504df3cf79011c2dcba46b4ecfa037fc894ff74bd7d765b8d5e4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07e62a32aa1986d30b3235f67704a464bc7adc2193b9f10345d93c8d0d783549',2003,'CY','Cyprus','people-and-society',252,'Greek Cypriot area: purchasing power parity - $9.4 billion
(2001 est.); Turkish Cypriot area: purchasing power parity - $787
million (2002 est.)
Czech Republic
purchasing power parity - $157.1 billion (2002 est.)
0.56% (2003 est.)
Czech Republic
-0.08% (2003 est.)
Greek Cypriot area: 1.7% (2001 est.); Turkish Cypriot area:
2.6% (2002 est.)
Czech Republic
2% (2002 est.)
Greek Cypriot area: purchasing power parity - $15,000 (2001
est.); Turkish Cypriot area: purchasing power parity - $6,000 (2002
est.)
Czech Republic
purchasing power parity - $15,300 (2002 est.)
chief of mission: Ambassador Michael KLOSSON
embassy: corner of Metochiou and Ploutarchou Streets, Engomi, 2407
Nicosia
mailing address: P. O. Box 24536, 1385 Nikosia
telephone: [357] (22) 776400
FAX: [357] (22) 780944
Czech Republic
chief of mission: Ambassador Craig R. STAPLETON
embassy: Trziste 15, 11801 Prague 1
mailing address: use embassy street address
telephone: [420] (2) 5753-0663
FAX: [420] (2) 5753-0583','98e1dd9e9b92c51331e293a3300a3aea3b6b9aeddc0d9ace8b6c4e46d434d584','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6160d14f130f39d5b0d656d8c4684390c88ef03f7996e78c8a3cbe3d0785be8c',2003,'DK','Denmark','people-and-society',253,'purchasing power parity - $155.3 billion (2002 est.)
0.28% (2003 est.)
1.6% (2002 est.)
purchasing power parity - $28,900 (2002 est.)
chief of mission: Ambassador Stuart A. BERNSTEIN
embassy: Dag Hammarskjolds Alle 24, 2100 Copenhagen
mailing address: PSC 73, APO AE 09716
telephone: [45] 35 55 31 44
FAX: [45] 35 43 02 23','4f87a129f3cdd029932fca2186531a2426a4550e763742104cb529013cd02d48','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a3ea52827843d026126c7cd3c6dcce133fddcdcd8a9345773dad59170c9eb4b',2003,'DJ','Djibouti','people-and-society',254,'purchasing power parity - $619 million (2002 est.)
2.13% (2003 est.)
3.5% (2002 est.)
purchasing power parity - $1,300 (2002 est.)
chief of mission: Ambassador Donald YAMAMOTO
embassy: Plateau du Serpent, Boulevard Marechal Joffre, Djibouti
mailing address: B. P. 185, Djibouti
telephone: [253] 35 39 95
FAX: [253] 35 39 40','bbabeaf967f603ef708d2d820a7d76d4d3f7e3fd0813da7c55af4d7ea1217443','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31fb1a091dbb60eb6b7ee44abfa65ca87b6cbebf896dfcdcfc95fb0ab3306ced',2003,'DM','Dominica','people-and-society',255,'purchasing power parity - $380 million (2002 est.)
-0.63% (2003 est.)
1.2% (2002 est.)
purchasing power parity - $5,400 (2002 est.)
the US does not have an embassy in Dominica; US interests
are served by the embassy in Bridgetown, Barbados','9b22fa05ce28677ed5e8912a749149d1065a517bae27559313dd9d26e207ffd3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e3418c30c0c6ba4906212e803fddfe65334c9379ced553c10ce41cdc8040503',2003,'DO','Dominican Republic','people-and-society',256,'purchasing power parity - $53.78 billion (2002
est.)
East Timor
purchasing power parity - $440 million (2001 est.)
1.36% (2003 est.)
East Timor
2.13% (2003 est.)
4.1% (2002 est.)
East Timor
18% (2001 est.)
purchasing power parity - $6,300 (2002 est.)
East Timor
purchasing power parity - $500 (2001 est.)
chief of mission: Ambassador Hans H. HERTELL
embassy: corner of Calle Cesar Nicolas Penson and Calle Leopoldo
Navarro, Santo Domingo
mailing address: Unit 5500, APO AA 34041-5500
telephone: [1] (809) 221-2171
FAX: [1] (809) 686-7437
East Timor
chief of mission: Ambassador Grover Joseph REES
embassy: Vila 10, Avenida de Portugal, Farol, Dili
mailing address: Department of State, 8250 Dili Place, Washington,
DC 20521-8250
telephone: (670) 332-4684, 331-3205/3160/3472
FAX: (670) 331-3206','fc936d1e93c171ed0679c14551becf4f0878c6e7f5cf470c3abd7a4268fb4552','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('468032323adb3db488386fa0e880f57f89838d43d27e2868537788ccb5f280b7',2003,'EC','Ecuador','people-and-society',257,'purchasing power parity - $42.65 billion (2002 est.)
1.91% (2003 est.)
3.4% (2002 est.)
purchasing power parity - $3,200 (2002 est.)
chief of mission: Ambassador Kristie Anne KENNEY
embassy: Avenida 12 de Octubre y Avenida Patria, Quito
mailing address: APO AA 34039
telephone: [593] (2) 256-2890
FAX: [593] (2) 250-2052
consulate(s) general: Guayaquil','a7161068d48d210c1a739f309d7228d6a1e88b84e55d1219529aca37f07d742f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51c68c3253f37bf759d9684023ba57d7005864d7923439aff6f8bdc82347b035',2003,'EG','Egypt','people-and-society',258,'purchasing power parity - $289.8 billion (2002 est.)
1.88% (2003 est.)
3.2% (2002 est.)
purchasing power parity - $4,000 (2002 est.)
chief of mission: Ambassador C. David WELCH
embassy: 5 Latin America St., Garden City, Cairo
mailing address: Unit 64900, Box 15, APO AE 09839-4900
telephone: [20] (2) 797-3300
FAX: [20] (2) 797-3200','e08016faef56bf137a03fc6c9ce121cbcb5078e138f735c8d077e6cfeef49ead','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8c9789be1c4ff23ffc696e3c76b0ecb557d6adad9ae642e2c9d26ca97799eb6',2003,'SV','El Salvador','people-and-society',259,'purchasing power parity - $29.41 billion (2002 est.)
1.81% (2003 est.)
2.1% (2002 est.)
purchasing power parity - $4,600 (2002 est.)
chief of mission: Ambassador Rose M. LIKINS
embassy: Final Boulevard Santa Elena Sur, Antiguo Cuscatlan, La
Libertad, San Salvador
mailing address: Unit 3116, APO AA 34023
telephone: [503] 278-4444
FAX: [503] 278-6011','288aa459dc4654c3885abb0a05d356d50bf55e8e32a1aba7436138e3507612b9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9215609cc1136b9b9e78594e22a9e08eb1001c4bc648c4a10dc2fafc0daa8bf',2003,'GQ','Equatorial Guinea','people-and-society',260,'purchasing power parity - $1.27 billion (2002 est.)
2.44% (2003 est.)
20% (2002 est.)
purchasing power parity - $2,700 (2002 est.)
the US does not have an embassy in Equatorial
Guinea (embassy closed September 1995); the US ambassador to
Cameroon is accredited to Equatorial Guinea; the US State Department
is considering opening a Consulate Agency in Malabo','16dcad79256910239f450064f433d9e05695631f8e756f849ef9fd2ca1c82618','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bac3a9a68eaf3a99bbe1b366dfcb56fec80e07d02ace9ab2262d929d6667db0',2003,'ER','Eritrea','people-and-society',261,'purchasing power parity - $3.3 billion (2002 est.)
1.28% (2003 est.)
2% (2002 est.)
purchasing power parity - $700 (2002 est.)
chief of mission: Ambassador Donald J. McCONNELL
embassy: Franklin D. Roosevelt Street, Asmara
mailing address: P. O. Box 211, Asmara
telephone: [291] (1) 120004
FAX: [291] (1) 127584','725a3a64244fb75f6164ce9f882365170f2caad755f0e18241dfcb17f183f446','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a8ac663cb427bb5cfa4b63ec383cd739ad856b9a4e4a5c4b0e24d0b6df3fc73',2003,'EE','Estonia','people-and-society',262,'purchasing power parity - $15.52 billion (2002 est.)
-0.49% (2003 est.)
6% (2002 est.)
purchasing power parity - $11,000 (2002 est.)
chief of mission: Ambassador Joseph M. DeTHOMAS
embassy: Kentmanni 20, 15099 Tallinn
mailing address: use embassy street address
telephone: [372] 668-8100
FAX: [372] 668-8134','b56e68a6300f85c570687b3b3090748d45f127899fb534e2a0d5974449e90886','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaab2bd6d9834ff7706a6506ca3888cd2404f50930be3e9036d61d1cad387331',2003,'ET','Ethiopia','people-and-society',263,'purchasing power parity - $48.53 billion (2002 est.)
Falkland Islands (Islas Malvinas)
purchasing power parity - $75
million (2002 est.)
1.96% (2003 est.)
Falkland Islands (Islas Malvinas)
2.44% (2003 est.)
3% (2002 est.)
Falkland Islands (Islas Malvinas)
NA%
purchasing power parity - $700 (2002 est.)
Falkland Islands (Islas Malvinas)
purchasing power parity - $25,000
(2002 est.)
chief of mission: Ambassador Aurelia A. BRAZEAL
embassy: Entoto Street, Addis Ababa
mailing address: P. O. Box 1014, Addis Ababa
telephone: [251] (1) 550666
FAX: [251] (1) 551328
Falkland Islands (Islas Malvinas)
none (overseas territory of the
UK; also claimed by Argentina)','f5118974b2d4c3fb99c73dc15ff3928573d4dfea2042456c652ea95f17e1501d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afaabe5b779c5dad0e0c995ca21f2caefe007441b8f4f7869e89dae84ffbae42',2003,'FO','Faroe Islands','people-and-society',264,'purchasing power parity - $1 billion (2001 est.)
0.7% (2003 est.)
10% (2001 est.)
purchasing power parity - $22,000 (2001 est.)
part of the Kingdom of Denmark; self-governing
overseas administrative division of Denmark since 1948
none (self-governing overseas administrative division
of Denmark)','36d518d1142d0a98c63060fc0d7ba73d52acc3fd821d2a0baa569695f27af631','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('455f6bded167e698b4426c143ad7bfe1207f9f42e2aba8e2a00abb74c32722e6',2003,'FJ','Fiji','people-and-society',265,'purchasing power parity - $4.822 billion (2002 est.)
1.41% (2003 est.)
4.6% (2002 est.)
purchasing power parity - $5,600 (2002 est.)
chief of mission: Ambassador David L. LYON
embassy: 31 Loftus Street, Suva
mailing address: P. O. Box 218, Suva
telephone: [679] 331-4466
FAX: [679] 330-0081','e1968ed50f46fdc4272a372a8894f93f84657b5bfab7c05ce691fdc3a5e7e133','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61fe8b2266b158695e08b5ba5fc7e0bb5ca0217e1f358cded8bccf137e9a0937',2003,'FI','Finland','people-and-society',266,'purchasing power parity - $133.8 billion (2002 est.)
0.14% (2003 est.)
1.6% (2002 est.)
purchasing power parity - $25,800 (2002 est.)
chief of mission: Ambassador Bonnie McELVEEN-HUNTER
embassy: Itainen Puistotie 14A, FIN-00140, Helsinki
mailing address: APO AE 09723
telephone: [358] (9) 616250
FAX: [358] (9) 174681','a13de7c158690f5bff8d01471b24fe3d6674b3005dbe84e434c9d0a3b06a5342','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5598dd2048b4d39e39f8cc7935abe56a413aab26b550e5219c4b0d74f9d0101',2003,'FR','France','people-and-society',267,'purchasing power parity - $1.558 trillion (2002 est.)
0.42% (2003 est.)
1.2% (2002 est.)
purchasing power parity - $26,000 (2002 est.)
chief of mission: Ambassador Howard H. LEACH
embassy: 2 Avenue Gabriel, 75382 Paris Cedex 08
mailing address: PSC 116, APO AE 09777
telephone: [33] (1) 43-12-22-22
FAX: [33] (1) 42 66 97 83
consulate(s) general: Marseille, Strasbourg','0cef8d653e3f7eb5521874f5cdbfb3523ba544e2758bdfce96b8a1430fb7ae6d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62ecf09b55b903ac17c0134899a28b7e62dfcf15ab03f8ab77dd9f79e453d893',2003,'GF','French Guiana','people-and-society',268,'purchasing power parity - $2.26 billion (2002 est.)
2.4% (2003 est.)
NA%
purchasing power parity - $14,400 (2000 est.)
overseas department of France
none (overseas department of France)','42cceb35eadadc3bf0c6388ab64ee06716da95509a80704d84a15414a91d6680','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4fe6253b22ce4bf3d069032e3cb5b20528395b74890be37e631d0f0502ca076',2003,'PF','French Polynesia','people-and-society',269,'purchasing power parity - $1.3 billion (2001 est.)
1.62% (2003 est.)
4% (2001 est.)
purchasing power parity - $5,000 (2001 est.)
overseas territory of France since 1946
French Southern and Antarctic Lands
overseas territory of France
since 1955; administered from Paris by Administrateur Superieur
Francois GARDE (since 24 May 2000), assisted by Secretary General
Jean-Yves HERMOSO (since NA)
none (overseas territory of France)
French Southern and Antarctic Lands
none (overseas territory of
France)','77aa294668b3798409debc604d2827b29950253f0a6114e7ac4cc0615aa60529','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8faaca33597ba8d5670ba5b7c6ef229502bde2d76d6bd01f5d65989ec5ecd4b',2003,'GA','Gabon','people-and-society',270,'purchasing power parity - $8.354 billion (2002 est.)
Gambia, The
purchasing power parity - $2.582 billion (2002 est.)
Gaza Strip
purchasing power parity - $735 million (2002 est.)
2.54% (2003 est.)
Gambia, The
3.03% (2003 est.)
Gaza Strip
3.89% (2003 est.)
0.2% (2002 est.)
Gambia, The
5.7% (2001 est.)
Gaza Strip
-15% (2002 est.)
purchasing power parity - $6,500 (2002 est.)
Gambia, The
purchasing power parity - $1,800 (2002 est.)
Gaza Strip
purchasing power parity - $600 (2002 est.)
chief of mission: Ambassador Kenneth P. MOOREFIELD
embassy: Boulevard de la Mer, Libreville
mailing address: Centre Ville, B. P. 4000, Libreville
telephone: [241] 76 20 03 through 76 20 04, after hours - 74 34 92
FAX: [241] 74 55 07
Gambia, The
chief of mission: Ambassador Jackson McDONALD
embassy: Kairaba Avenue, Fajara, Banjul
mailing address: P. M. B. No. 19, Banjul
telephone: [220] 392856, 392858, 391971
FAX: [220] 392475','30be5489429bdc74eecceac4bf3b7501c2e18ccc1bad60c4aaaad5af56612c0e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db117c97934aebf50c1106f660fc8d109f6303ecb1964abf7ce57050a845cbb4',2003,'GE','Georgia','people-and-society',271,'purchasing power parity - $16.05 billion (2002 est.)
-0.52% (2003 est.)
5.4% (2002 est.)
purchasing power parity - $3,200 (2001 est.)
chief of mission: Ambassador Richard M. MILES
embassy: #25 Atoneli Street, T''bilisi 380026
mailing address: 7060 Tbilisi Place, Washington, DC 20521-7060
telephone: [995] (32) 989-967/68
FAX: [995] (32) 933-759','e777c4155f73101d2faf3730228c2e38af2a3155a7d9fc7042d95b0ee5b75e04','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e50636ff974c14d905c4154a0b044a11e0ba12364410b7ade410c31d7b9887d1',2003,'DE','Germany','people-and-society',272,'purchasing power parity - $2.16 trillion (2002 est.)
0.04% (2003 est.)
0.2% (2002 est.)
purchasing power parity - $26,200 (2002 est.)
chief of mission: Ambassador Daniel R. COATS
embassy: Neustaedtische Kirchstrasse 4-5, 10117 Berlin; note - a new
embassy will be built near the Brandenburg Gate in Berlin
mailing address: PSC 120, Box 1000, APO AE 09265
telephone: [49] (30) 238-5174
FAX: [49] (30) 238-6290
consulate(s) general: Duesseldorf, Frankfurt am Main, Hamburg,
Leipzig, Munich','3f1fe6d782b3dd0935482bedc9e41f14e4da6d4f01ad7cf65bf7e1aa9c8430b7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c4c3f054be037ceb7abfdbc95c6150d63ef9d0926f1b6354a639daae326df2b',2003,'GH','Ghana','people-and-society',273,'purchasing power parity - $41.25 billion (2002 est.)
1.45% (2003 est.)
4.5% (2002 est.)
purchasing power parity - $2,000 (2002 est.)
chief of mission: Ambassador Mary Carlin YATES
embassy: 6th and 10th Lanes, 798/1 Osu, Accra
mailing address: P. O. Box 194, Accra
telephone: [233] (21) 775-347, 775-348
FAX: [233] (21) 701-813','cd2c19bf9b5582253bbcb96a5b1faa1b8a2d9cb3c5aa8b916bc5589498586660','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6be5479ff0949859c3d58e1d6b0703311bb0adb3f3470c83578b4286a24845e6',2003,'GI','Gibraltar','people-and-society',274,'purchasing power parity - $500 million (1997 est.)
0.22% (2003 est.)
NA%
purchasing power parity - $17,500 (1997 est.)
overseas territory of the UK
Glorioso Islands
possession of France; administered by a high
commissioner of the Republic, resident in Reunion
none (overseas territory of the UK)
Glorioso Islands
none (possession of France)','cee79a4029e9860a54458d8fe2a4702d0fab15804afeba7a22cf96495f7f4dd8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cccd5c92230e530a6a25aef610b38efd42815bd3cf906210c3c36fd46a056c1',2003,'GR','Greece','people-and-society',275,'purchasing power parity - $203.3 billion (2002 est.)
0.19% (2003 est.)
4% (2002 est.)
purchasing power parity - $19,100 (2002 est.)
chief of mission: Ambassador Thomas J. MILLER
embassy: 91 Vasilissis Sophias Avenue, 101 60 Athens
mailing address: PSC 108, APO AE 09842-0108
telephone: [30] (210) 721-2951
FAX: [30] (210) 645-6282
consulate(s) general: Thessaloniki','01dce2f943a58e056fd9466b71cc85b9ccc7e6d31a6a1fd7f153f6494a0e8e05','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00885a808ae6968f2515f54eb16b982bfd0ef51986c60fcf4776960f0d517c1c',2003,'GL','Greenland','people-and-society',276,'purchasing power parity - $1.1 billion (2001 est.)
0.01% (2003 est.)
1.8% (2001 est.)
purchasing power parity - $20,000 (2001 est.)
part of the Kingdom of Denmark; self-governing overseas
administrative division of Denmark since 1979
none (self-governing overseas administrative division of
Denmark)','e5d378555eec07d7d50b2f41a8b9b45b9337a0bd4ed2247a02c462c133cde65d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f9974aa27ff99d7884003a18ac9e33090d103b81b3f750cd98ab3ebbb142d76',2003,'GD','Grenada','people-and-society',277,'purchasing power parity - $440 million (2002 est.)
0.08% (2003 est.)
2.5% (2002 est.)
purchasing power parity - $5,000 (2002 est.)
chief of mission: the ambassador to Barbados is accredited
to Grenada
embassy: Point Salines, Saint George''s
mailing address: P. O. Box 54, Saint George''s, Grenada, West Indies
telephone: [1] (473) 444-1173 through 1176
FAX: [1] (473) 444-4820','16be7ac09fb39ea7bb84c08f2320f1597a552dc5a27b27e8c2606ff5b2ce6b06','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af5e9b8c7f75f6a4e624fad57e786a2501613570e963f6a85c3cab9a40673259',2003,'GP','Guadeloupe','people-and-society',278,'purchasing power parity - $3.7 billion (1997 est.)
1% (2003 est.)
NA%
purchasing power parity - $9,000 (1997 est.)
overseas department of France
none (overseas department of France)','e07fd87e9bf19963364fc8a6b555828be9d5260af6dce41935f4e5933d58cb4b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2faa781e7ddbc93498662d212dcd020c7e1ea39bcc6d9e8eb2425bd24a8ba586',2003,'GU','Guam','people-and-society',279,'purchasing power parity - $3.2 billion (2000 est.)
1.89% (2003 est.)
NA%
purchasing power parity - $21,000 (2000 est.)
organized, unincorporated territory of the US with policy
relations between Guam and the US under the jurisdiction of the
Office of Insular Affairs, US Department of the Interior
none (territory of the US)','9cbeff5b8f784b8d109261882a41f6061ec14cbb46bbfecb39d0258b0620bd89','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('032cc35ba676782e335bc8360d6d427b5770fbf0778cb8dbc1d46bd2b04cd867',2003,'GT','Guatemala','people-and-society',280,'purchasing power parity - $53.2 billion (2002 est.)
2.66% (2003 est.)
2.2% (2002 est.)
purchasing power parity - $3,900 (2002 est.)
chief of mission: Ambassador John Randle HAMILTON
embassy: 7-01 Avenida Reforma, Zone 10, Guatemala City
mailing address: APO AA 34024
telephone: [502] 331-1541/55
FAX: [502] 334-8477','fdb6761acc172a73496f66ca0b2a97efbea3873e4b0a11e934e9beb2cba2176f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbc1b2f3b8afa2e3a70dfcdada7dffbf88cd1dbc47a871d0e79d3a80bc1c20ec',2003,'GG','Guernsey','people-and-society',281,'purchasing power parity - $1.3 billion (1999 est.)
0.34% (2003 est.)
5.7% (1999 est.)
purchasing power parity - $20,000 (1999 est.)
British crown dependency
none (British crown dependency)','22bcedbb2f2b63d52e2f9ed5fddedcf35db43a1e2e0932b1af0f60336c353c8a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1caf9ff1160350093f00e7b3ecabcccd0bbc27f0a113f338eb9af91918122d93',2003,'GN','Guinea','people-and-society',282,'purchasing power parity - $18.69 billion (2002 est.)
2.37% (2003 est.)
3.7% (2002 est.)
purchasing power parity - $2,100 (2002 est.)
chief of mission: Ambassador Barrie R. WALKLEY
embassy: Rue Ka 038, Conakry
mailing address: B. P. 603, Conakry
telephone: [224] 41 15 20, 41 15 21, 41 15 23
FAX: [224] 41 15 22','0d65efe17607cfecdcfeb86d8ac06724b10bb68ce6a13ab36181f72e491542c5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40fe7fe69f25456a30b5aa4fe32deeae6a80e97fd42249d77728e1e57563d98b',2003,'GW','Guinea-Bissau','people-and-society',283,'purchasing power parity - $901.4 million (2002 est.)
2.02% (2003 est.)
-4.3% (2002 est.)
purchasing power parity - $700 (2002 est.)
the US Embassy suspended operations on 14 June 1998 in
the midst of violent conflict between forces loyal to then President
VIEIRA and military-led junta; for the time being, US embassy Dakar
is responsible for covering Guinea-Bissau: telephone - [221]
823-4296; FAX - [221] 822-5903','880edc3db7c5eb6bb340e5252836ee774bb357ef95ca2b24f9641bd3997f5ce3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bedae69700e8f93b9cd089c0a95c0d10d8d0f3a69fcbb284a1c5ccc8e2f519f',2003,'GY','Guyana','people-and-society',284,'purchasing power parity - $2.628 billion (2002 est.)
0.44% (2003 est.)
1.1% (2002 est.)
purchasing power parity - $3,800 (2002 est.)
chief of mission: Ambassador Ronald D. GODARD
embassy: 100 Young and Duke Streets, Kingston, Georgetown
mailing address: P. O. Box 10507, Georgetown
telephone: [592] 225-4900 through 4909
FAX: [592] 225-8497','543222ead012922bb23cb59a2094ae8128ec0083da9f4d08f442cdc5794730bb','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c9403ec2db3c91227f28efaee1a184fbe66c76c1c1c16c787f45b5c77ed4ad6',2003,'HT','Haiti','people-and-society',285,'purchasing power parity - $10.6 billion (2002 est.)
1.67% (2003 est.)
Holy See (Vatican City)
0.01% (2003 est.)
-0.9% (2002 est.)
purchasing power parity - $1,400 (2002 est.)
chief of mission: Ambassador James B. Foley
embassy: 5 Harry S Truman Boulevard, Port-au-Prince
mailing address: P. O. Box 1761, Port-au-Prince
telephone: [509] 222-0354, 222-0368, 222-0200, 222-0612
FAX: [509] 223-1641','9ddabaa0f757056dfcf5c4d7f0b93218ec6aef9c3bcddb18901807d44f66abd3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13c361b40b59d1130da47e49ed1518f22548e86361bd76ef254bd24d26f099ba',2003,'HN','Honduras','people-and-society',286,'purchasing power parity - $16.29 billion (2002 est.)
2.32% (2003 est.)
2.5% (2002 est.)
purchasing power parity - $2,500 (2002 est.)
chief of mission: Ambassador Larry Leon PALMER
embassy: Avenida La Paz, Apartado Postal No. 3453, Tegucigalpa
mailing address: American Embassy, APO AA 34022, Tegucigalpa
telephone: [504] 238-5114, 236-9320
FAX: [504] 236-9037','47eab228e2ace3007362cf0c0e3acb756c3873e9a01bced91580112514d63a1a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c64375f1e0f61f5e409476cb7e89660e5e0ade1f4c5183f7733ae3192100a8ab',2003,'HK','Hong Kong','people-and-society',287,'purchasing power parity - $198.5 billion (2002 est.)
1.22% (2003 est.)
2.3% (2002 est.)
purchasing power parity - $27,200 (2002 est.)
special administrative region of China
Howland Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
Jan Mayen
territory of Norway; since August 1994, administered from
Oslo through the county governor (fylkesmann) of Nordland; however,
authority has been delegated to a station commander of the Norwegian
Defense Communication Service
Jarvis Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
chief of mission: Consul General James KEITH
consulate(s) general: 26 Garden Road, Hong Kong
mailing address: PSC 461, Box 1, FPO AP 96521-0006
telephone: [852] 2523-9011
FAX: [852] 2524-0860','6da5ff34487a10cd8926436350423ecbf5d54d5da34e0c13bbb7ea5ed1d3f977','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d25017c63140ecd15becb6a2fb528b23787af3221794dc7f1878fac9a7485f6',2003,'HU','Hungary','people-and-society',288,'purchasing power parity - $134 billion (2002 est.)
-0.29% (2003 est.)
3.3% (2002 est.)
purchasing power parity - $13,300 (2002 est.)
chief of mission: Ambassador Nancy Goodman BRINKER
embassy: 1054 Szabadsag ter 12, Budapest
mailing address: pouch: American Embassy Budapest, 5270 Budapest
Place, Department of State, Washington, DC 20521-5270
telephone: [36] (1) 475-4400
FAX: [36] (1) 475-4764','a026ca7545aa298c5af1b5b606a1f162dbfb727472cde7397d1ea9d4c20cc74e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c736ba85ba71a7244c3a46cae93e726f211d46adca241b103340f866cd0d91e',2003,'IS','Iceland','people-and-society',289,'purchasing power parity - $8.444 billion (2002 est.)
0.49% (2003 est.)
-0.6% (2002 est.)
purchasing power parity - $30,200 (2002 est.)
chief of mission: Ambassador James I. GADSDEN
embassy: Laufasvegur 21, 101 Reykjavik
mailing address: US Embassy, PSC 1003, Box 40, FPO AE 09728-0340
telephone: [354] 5629100
FAX: [354] 5629118','2a484547f9786bfbf4eeb3c21bdac60c2f61f935b94b3ed8e4b9e3882c3c1054','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4b180654d9a55b5b391be08d195b880b9b96e5044f7439235e8b42dd07bac5f',2003,'IN','India','people-and-society',290,'purchasing power parity - $2.664 trillion (2002 est.)
1.47% (2003 est.)
4.3% (2002 est.)
purchasing power parity - $2,600 (2002 est.)
chief of mission: Ambassador Robert D. BLACKWILL
embassy: Shantipath, Chanakyapuri, New Delhi 110021
mailing address: use embassy street address
telephone: [91] (11) 419-8000
FAX: [91] (11) 419-0017
consulate(s) general: Chennai (Madras), Kolkata (Calcutta), Mumbai
(Bombay)','16b89b7112bb579eb5e5dda5eab19c7691ae20823fe82423ea1b4daff5782d17','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cfe29dd63e17a5e9f0c65acaad5584b8d72dede2b5608da5653156a8ab52b68',2003,'ID','Indonesia','people-and-society',291,'purchasing power parity - $714.2 billion (2002 est.)
Iran
purchasing power parity - $458.3 billion (2002 est.)
1.52% (2003 est.)
Iran
1.08% (2003 est.)
3.7% (2002 est.)
Iran
7.6% (2002 est.)
purchasing power parity - $3,100 (2002 est.)
Iran
purchasing power parity - $6,800 (2002 est.)
chief of mission: Ambassador Ralph L. BOYCE
embassy: Jalan 1 Medan Merdeka Selatan 3-5, Jakarta 10110
mailing address: Unit 8129, Box 1, FPO AP 96520
telephone: [62] (21) 3435-9000
FAX: [62] (21) 385-7189
consulate(s) general: Surabaya
Iran
none; note - protecting power in Iran is Switzerland','648f9a4308d49286214ec9206711b8c51a286f9c9cb3ff37d408cd77c1d97988','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31e9a4458fc47b95c40d50ba7ae3b6fa06482160942839fc43e3e369ecab8d5c',2003,'IQ','Iraq','people-and-society',292,'purchasing power parity - $58 billion (2002 est.)
2.78% (2003 est.)
-3% (2002 est.)
purchasing power parity - $2,400 (2002 est.)
in transition following April 2003 defeat of SADDAM Husayn
regime by US-led coalition','1a4f9fcbfa913d866c241fc90333a64fa4072ce9edf5799504860889ef08d6dd','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('584c2f4bc108c2f3d201b2b2d89bbe453b7d25f64255d95a3250c6db1c1d039b',2003,'IE','Ireland','people-and-society',293,'purchasing power parity - $113.7 billion (2002 est.)
1.03% (2003 est.)
6.9% (2002 est.)
purchasing power parity - $29,300 (2002 est.)
chief of mission: Ambassador Richard J. EGAN
embassy: 42 Elgin Road, Ballsbridge, Dublin 4
mailing address: use embassy street address
telephone: [353] (1) 668-8777
FAX: [353] (1) 668-9946','206df5c3274089709b3b9153d0004d81bee068ccb5de5429a33d5203edf34683','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08c40e98f8079b2d90f528054655f6128ed45dd4af3660dfed3d4bec9d43980b',2003,'IL','Israel','people-and-society',294,'purchasing power parity - $117.4 billion (2002 est.)
1.39% (2003 est.)
-0.8% (2002 est.)
purchasing power parity - $19,500 (2002 est.)
chief of mission: Ambassador Daniel C. KURTZER
embassy: 71 Hayarkon Street, Tel Aviv
mailing address: PSC 98, Box 29, APO AE 09830
telephone: [972] (3) 519-7457/7369/7454/7458/7453
FAX: [972] (3) 517-4390
consulate(s) general: Jerusalem; note - an independent US mission,
established in 1928, whose members are not accredited to a foreign','b87a0c2d67b0712204c8f2894305d7623eda25d50b06105719a6e51804e6f05a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e67d82e1fdfeb1d067e88f0645a20d2e573c022710c2260b6612b01899de8582',2003,'IT','Italy','people-and-society',295,'purchasing power parity - $1.455 trillion (2002 est.)
0.11% (2003 est.)
0.4% (2002 est.)
purchasing power parity - $25,100 (2002 est.)','eb0ee3e4f080df3e0ef8a560ab214a1a651cc2ce2de86292879a0a31acbada0e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e6c3dfdd8aad1fe96c1ba078d7ddd2fecd994d4054d0eabaab1553a7dd03a9e',2003,'JM','Jamaica','people-and-society',296,'purchasing power parity - $10.08 billion (2002 est.)
0.61% (2003 est.)
1% (2002 est.)
purchasing power parity - $3,800 (2002 est.)','f9abf12fa6ea34b219552853816c4de629d81a8abdef6a0e7f547706d4f5b493','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad3646fae8c67df6682f9287f0743fbbf5227b037373cc50393f7b603c84b521',2003,'JP','Japan','people-and-society',297,'purchasing power parity - $3.651 trillion (2002 est.)
0.11% (2003 est.)
0.2% (2002 est.)
purchasing power parity - $28,700 (2002 est.)','cde5624c661bce80aaa1270a593bdb1316a1937c6ad80b2a0d6a8b8199e12a28','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1832dadd71ea4acae4af1a9ee5c143c5d6759cf110388227cebaa8b1281c81a4',2003,'JE','Jersey','people-and-society',298,'purchasing power parity - $2.2 billion (1999 est.)
0.4% (2003 est.)
NA%
purchasing power parity - $24,800 (1999 est.)
British crown dependency
Johnston Atoll
unincorporated territory of the US; administered from
Honolulu, HI, by Pacific Air Forces, Hickam Air Force Base, and the
Fish and Wildlife Service of the US Department of the Interior as
part of the National Wildlife Refuge system
Juan de Nova Island
possession of France; administered by a high
commissioner of the Republic, resident in Reunion
Kingman Reef
unincorporated territory of the US; administered from
Washington, DC, by the US Fish and Wildlife Service of the
Department of the Interior
note: on 1 September 2000, the Department of the Interior accepted
restoration of its administrative jurisdiction over Kingman Reef
from the Department of the Navy; Executive Order 3223 signed 18
January 2001 established Kingman Reef National Wildlife Refuge to be
administered by the Director, US Fish and Wildlife Service; this
refuge is managed to protect the terrestrial and aquatic wildlife of
Kingman Reef out to the 12-nautical-mile territorial sea limit
Macau
special administrative region of China
Man, Isle of
British crown dependency','129e84a487d226df45d5f1c3759c44bb084e28783bdfed09a4642aba1df464ff','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f136ddbff084c0f97d9bd523b7b60bbe65a035d5d4eea751be789787fe303c2',2003,'JO','Jordan','people-and-society',299,'purchasing power parity - $22.63 billion (2002 est.)
2.78% (2003 est.)
4.9% (2002 est.)
purchasing power parity - $4,300 (2002 est.)','debaa8dbdaab8253d21ed8cef22fa9acda6f8c69088ad12f73b3d21d344b209e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb9a80864a8ebe83fe7bd5ce53490f9e77f6acc8516e72d70c7e4f41d6b7f1bc',2003,'KZ','Kazakhstan','people-and-society',300,'purchasing power parity - $120 billion (2002 est.)
0.17% (2003 est.)
9.5% (2002 est.)
purchasing power parity - $7,200 (2002 est.)','73df1523a5eb0f1ea1cb6612c54ff97ba492e3a92b920409203f2f76eb42c979','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9196c1ee4f055a4d957fe8264fc8291eedbda489b6ea5078749800cc31ba4363',2003,'KE','Kenya','people-and-society',301,'purchasing power parity - $32.89 billion (2002 est.)
1.27% (2003 est.)
1.1% (2002 est.)
purchasing power parity - $1,100 (2002 est.)','9e30cf7102f84b1ad77d2e701dbf23e7072243a8bdc34901e3613532cde3f0a5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1d5a06a057d2949f11705abe8f9743d14fd91c8cc2bbcffe32bf58bbf6208ae',2003,'KI','Kiribati','people-and-society',302,'purchasing power parity - $79 million - supplemented by a
nearly equal amount from external sources (2001 est.)
Korea, North
purchasing power parity - $22.26 billion (2002 est.)
Korea, South
purchasing power parity - $941.5 billion (2002 est.)
2.26% (2003 est.)
Korea, North
1.07% (2003 est.)
Korea, South
0.66% (2003 est.)
1.5% (2001 est.)
Korea, North
1% (2002 est.)
Korea, South
6.3% (2002 est.)
purchasing power parity - $800 (2001 est.)
Korea, North
purchasing power parity - $1,000 (2002 est.)
Korea, South
purchasing power parity - $19,600 (2002 est.)','df34949499bd116958b385e15badf151149df13b7e82990d63a4e129c6e80248','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cf51004abc5edb60de0f38e7f291bcc7a5eb6a74ad3604fa50eec31be79a2b5',2003,'KW','Kuwait','people-and-society',303,'purchasing power parity - $36.85 billion (2002 est.)
3.34%
note: this rate reflects a return to pre-Gulf crisis immigration of
expatriates (2003 est.)
-2% (2002 est.)
purchasing power parity - $17,500 (2002 est.)','b8ebc8c9d8bf7c3832e3b698572f9742dbdee5a242ba53e5449a64223d1dd2b1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('145a8e9e34916968abed4d176cc3f9dbc62501b79251889b5b3cc49aeb797032',2003,'KG','Kyrgyzstan','people-and-society',304,'purchasing power parity - $13.88 billion (2002 est.)
Laos
purchasing power parity - $10.4 billion (2002 est.)
1.46% (2003 est.)
Laos
2.45% (2003 est.)
5.3% (2002 est.)
Laos
5.7% (2002 est.)
purchasing power parity - $2,900 (2002 est.)
Laos
purchasing power parity - $1,800 (2002 est.)','9f742b3848bea9576d0004b60dc4d11dc3dd8a499b809e498da6e1c0fca0ddff','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a50919d85b5d71a2b8e41b9b552313772ff1c7205a26a7e713d7724df3b4898',2003,'LV','Latvia','people-and-society',305,'purchasing power parity - $20.99 billion (2002 est.)
-0.73% (2003 est.)
6.1% (2002 est.)
purchasing power parity - $8,900 (2002 est.)','b430286d9f764d36600a2d5a4f8ac9c9228e5cf57371da73a85b7b08ffa2b267','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('494379ecd401b7a1e88de40be03ef76343620d916b0f81d9e680114ebabebd72',2003,'LB','Lebanon','people-and-society',306,'purchasing power parity - $17.61 billion (2002 est.)
1.34% (2003 est.)
2% (2002 est.)
purchasing power parity - $4,800 (2002 est.)','c92d2b500586161a17a05f2d04c1adb771a7d49d9a7041f4b155fd833befe545','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03065a7f0d6a2269401ff04c88e36aaaf92ba560718201c6810d777123fc0a99',2003,'LS','Lesotho','people-and-society',307,'purchasing power parity - $5.106 billion (2002 est.)
0.19% (2003 est.)
4% (2002 est.)
purchasing power parity - $2,700 (2002 est.)','72667ca024a8ad2bc02ae780f00f9a2850523724d05dda181ec1430728a87219','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('805942874c177f7a5ed1859af173e6ff0cb81838e9a75673fe9f91bad90dac76',2003,'LR','Liberia','people-and-society',308,'purchasing power parity - $3.116 billion (2002 est.)
1.67% (2003 est.)
2% (2002 est.)
purchasing power parity - $1,000 (2002 est.)','058ede3d2dabe6938623536df6fe6218ac8a42d5fd68a073bb5da2409a2452e1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('649d80ac72ad0965271fe84c8096b7b7350ae2f04a5d4352bfec0a27b53247ae',2003,'LY','Libya','people-and-society',309,'purchasing power parity - $33.36 billion (2002 est.)
2.39% (2003 est.)
1.2% (2002 est.)
purchasing power parity - $6,200 (2002 est.)','97aa713628e1d594969bd1a3ef6219f02a37830833003861111004f526322898','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b150d9c2cccd70ec6dd40665b6f3d88c2836d3fa7f3d000a9c3076d3351f7e6',2003,'LI','Liechtenstein','people-and-society',310,'purchasing power parity - $825 million (1999 est.)
0.9% (2003 est.)
11% (1999 est.)
purchasing power parity - $25,000 (1999 est.)','84aa7501c6c17e90a54cf7de954c71f6760ebdb2266eae999230a7d5f26525ae','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4b18b92a93a98f18c5926d53cefc0ce11f3a0af861de0709f49eb60e9642653',2003,'LT','Lithuania','people-and-society',311,'purchasing power parity - $30.08 billion (2002 est.)
-0.23% (2003 est.)
6.7% (2002 est.)
purchasing power parity - $8,400 (2002 est.)','4da8b98e33391809fc36f917b7f677989e10d65181bf2d64064c5afebf32b49f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76a23efb51402fffe1438ac8c94b096e0ee697ac73e88c5aca7867071553f2a0',2003,'LU','Luxembourg','people-and-society',312,'purchasing power parity - $21.94 billion (2002 est.)
Macau
purchasing power parity - $8.6 billion (2002 est.)
Macedonia, The Former Yugoslav Republic of
purchasing power parity -
$10.57 billion (2002 est.)
1.23% (2003 est.)
Macau
1.72% (2003 est.)
Macedonia, The Former Yugoslav Republic of
0.4% (2003 est.)
0.4% (2002 est.)
Macau
9.5% (2002 est.)
Macedonia, The Former Yugoslav Republic of
0.7% (2002 est.)
purchasing power parity - $48,900 (2002 est.)
Macau
purchasing power parity - $18,500 (2002 est.)
Macedonia, The Former Yugoslav Republic of
purchasing power parity -
$5,100 (2002 est.)','8f33687b53205312d779aca048ed18384a1c76ecad5be201b92c9d7dca8a4761','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91e6884b67bf27f5eada154bbbe98321d65bdc4a4e14d258864ecddf8172cbaf',2003,'MG','Madagascar','people-and-society',313,'purchasing power parity - $12.59 billion (2002)
3.03% (2003 est.)
-11.9% (2002 est.)
purchasing power parity - $800 (2002 est.)','d7027289466e21b7b6632fdfc7f7a43eaf9248be499ab9e81eb33224007740ac','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11202952d6bb81314545592e2d50c8d62c6241563e3e28cefdc61448247abd7b',2003,'MW','Malawi','people-and-society',314,'purchasing power parity - $6.811 billion (2002 est.)
2.21% (2003 est.)
1.7% (2002 est.)
purchasing power parity - $600 (2002 est.)','d566db36baa5f621789e6caaad9da06d282033cf20cdbd98003894d344aacfa7','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ab76ff1f7f2614f2e2a62450ea136632ae5254d18bbc09651c5724497833183',2003,'MY','Malaysia','people-and-society',315,'purchasing power parity - $198.4 billion (2002 est.)
1.86% (2003 est.)
4.1% (2002 est.)
purchasing power parity - $8,800 (2002 est.)','41fdd35db74bda97d3ce7ef606b54c47d87e656468bfd63c3e602c5cb978d635','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64f6a1e32bf0cee99a2d9a96098950d293ba348a8bae714f9d3147c6c3b035b8',2003,'MV','Maldives','people-and-society',316,'purchasing power parity - $1.25 billion (2002 est.)
2.91% (2003 est.)
2.3% (2002 est.)
purchasing power parity - $3,900 (2002 est.)','5722d5b323a76024e17e179fe80bc8ca3848852fdc14c4db679f627459f13a4b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d92f031fc5b9008c06ba9467635574144224d69fc47d6d6f93a28f034dc7df4',2003,'ML','Mali','people-and-society',317,'purchasing power parity - $9.775 billion (2002 est.)
2.82% (2003 est.)
4.5% (2002 est.)
purchasing power parity - $900 (2002 est.)','fecf25cc446d46a92888ccf8892a4abba11e525285bb0df6cc8cdcbe7fca62c9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('825568602704f5f40991c39667349a2f9c8ffa0e438c5faf65e0e2e789843a47',2003,'MT','Malta','people-and-society',318,'purchasing power parity - $6.818 billion (2002 est.)
Man, Isle of
purchasing power parity - $1.6 billion (2001 est.)
0.73% (2003 est.)
Man, Isle of
0.53% (2003 est.)
1.2% (2002 est.)
Man, Isle of
13.5%
purchasing power parity - $17,200 (2002 est.)
Man, Isle of
purchasing power parity - $21,000 (2001 est.)','378044f823e4df4239bc747e3ae442f0a0121602612ab2ed9f3847c1cc23afed','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17684d37699540085197f2cb48971660f24dccfce6698d5f8704e1febcd2f6ec',2003,'MH','Marshall Islands','people-and-society',319,'purchasing power parity - $115 million (2001 est.)
2.3% (2003 est.)
1% (2001 est.)
purchasing power parity - $1,600 (2001 est.)','b3e3e7eda6fe77121adfb291f298083bd3e1f3a380f4e25f36894a99fa4e8a5b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('706624b73b03ad8cd9560140a80fb8617cb0897454c61498aeb4ca3b09a2744b',2003,'MQ','Martinique','people-and-society',320,'purchasing power parity - $4.5 billion (2001 est.)
0.85% (2003 est.)
NA%
purchasing power parity - $10,700 (2001 est.)
overseas department of France','21cb1de841df10f378f69ffd1ca952c1a4d71d58700430470af709388c55c54f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1ba1838209cc020364e171712e3c0fe359f2ed401123138ad65125fad9a0785',2003,'MR','Mauritania','people-and-society',321,'purchasing power parity - $4.891 billion (2002 est.)
2.91% (2003 est.)
3.3% (2002 est.)
purchasing power parity - $1,700 (2002 est.)','ee50ebaa71fe3998150ccea3326f0cb6a9189087b715db4e37540d4337aeefdb','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e24e8fe3a1fa89e023213b6aed1cfe082f6e1b8e4242bdb69828ea704e39af50',2003,'MU','Mauritius','people-and-society',322,'purchasing power parity - $12.15 billion (2002 est.)
0.84% (2003 est.)
2.3% (2002 est.)
purchasing power parity - $10,100 (2002 est.)','1c069bc283f82adc7ccabd0a253190d1c8e1f7390744d27c34ea06d73794d1e6','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46eaa814786e98b21491ca230c23c4c059688d8f136e1301a52ac9d9cc9d828e',2003,'YT','Mayotte','people-and-society',323,'purchasing power parity - $85 million (1998 est.)
4.25% (2003 est.)
NA%
purchasing power parity - $600 (1998 est.)
territorial collectivity of France
Midway Islands
unincorporated territory of the US; formerly
administered from Washington, DC, by the US Navy, under Naval
Facilities Engineering Command, Pacific Division; this facility has
been operationally closed since 10 September 1993; on 31 October
1996, through a presidential executive order, the jurisdiction and
control of the atoll was transferred to the Fish and Wildlife
Service of the US Department of the Interior as part of the National
Wildlife Refuge system','7e8de86c3833ae3ec10a7cdd5a648bf127ac6eba4aae823947272743f4ce6b18','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70795d0191f789d1823c05acc470aaae2dfc7175fe580e8b475549cac3b4acbd',2003,'MX','Mexico','people-and-society',324,'purchasing power parity - $924.4 billion (2002 est.)
1.43% (2003 est.)
0.7% (2002 est.)
purchasing power parity - $8,900 (2002 est.)','360fa30fd1022f848d68b6c8469eb065e6b02a16c8b9d1eb3c71923c1f2f2cac','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8215beec59be9b23beb275b8b1db9c68981abb09ed1efe92575215fe2c7ea421',2003,'FM','Micronesia, Federated States of','people-and-society',325,'purchasing power parity - $277
million
note: $277 million $277 million GDP is supplemented by grant aid,
averaging perhaps $100 million annually (2002 est.)
Moldova
purchasing power parity - $11.51 billion (2002 est.)
0.04% (2003 est.)
Moldova
0.13% (2003 est.)
1% (2002 est.)
Moldova
6.5% (2002 est.)
purchasing power parity - $2,000
(2002 est.)
Moldova
purchasing power parity - $2,600 (2002 est.)','f96088795ce036773bfc6185138cf18c3c77a3d21a58dc1e3309c39815fe4f22','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f89954a967c3f80e32814a3e1a7d5d709da5f0dc8e8fc103db893733d4637361',2003,'MC','Monaco','people-and-society',326,'purchasing power parity - $870 million (1999 est.)
0.44% (2003 est.)
NA%
purchasing power parity - $27,000 (1999 est.)','3d8bc6c267e8d40f3087926fcc486a3c3950be56817ce9f55f1954c7668e8b79','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7537623d2306b27a63b76120950d23d96361d71d76be6a580650f7b7e7b848d6',2003,'MN','Mongolia','people-and-society',327,'purchasing power parity - $5.06 billion (2002 est.)
1.42% (2003 est.)
3.9% (2002 est.)
purchasing power parity - $1,900 (2002 est.)','45c9fe39fc49d3f03331f962906aaa314caf73b99b15a7643630b736485ddb78','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c607e32c58fe340823a462d57676cb28c8190370aaa687dd31ce2276acf84f39',2003,'MS','Montserrat','people-and-society',328,'purchasing power parity - $29 million (2002 est.)
4.5% (2003 est.)
-1% (2002 est.)
purchasing power parity - $3,400 (2002 est.)
overseas territory of the UK
Navassa Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service, US Department of
the Interior; in September 1996, the Coast Guard ceased operations
and maintenance of Navassa Island Light, a 46-meter-tall lighthouse
on the southern side of the island; there has also been a private
claim advanced against the island
Netherlands Antilles
part of the Kingdom of the Netherlands; full
autonomy in internal affairs granted in 1954; Dutch Government
responsible for defense and foreign affairs','69df0459896694d789118caa0b9740454f5ac0016c72f09a592f56536f9be6a2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c32bb1a48b4bbdedbd621947c7a0c2240d0db8292aee3478e8538e564ad526d',2003,'MA','Morocco','people-and-society',329,'purchasing power parity - $121.8 billion (2002 est.)
1.64% (2003 est.)
4.6% (2002 est.)
purchasing power parity - $3,900 (2002 est.)','51e088d96ef60067ab0f3b367681bc092e9049bd51f56cee9bfbd61341c2da6e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb76316475ec33829a48678b2ce0fc0db09992bae0182a95f702f39a834b89bd',2003,'MZ','Mozambique','people-and-society',330,'purchasing power parity - $19.52 billion (2002 est.)
0.82% (2003 est.)
7.7% (2002 est.)
purchasing power parity - $1,100 (2002 est.)','f0e14be495f35293b520b4c4198a9d6ecec3e6190137c8e698a434bfbd1a2444','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ef18be9fe8617e806006065ef0c251481f846f0171d37277e1a2e841b96c58a',2003,'NA','Namibia','people-and-society',331,'purchasing power parity - $13.15 billion (2002 est.)
1.49% (2003 est.)
2.3% (2002 est.)
purchasing power parity - $6,900 (2002 est.)','9d4f71ffc42247bd8229530c7347c077d9ae83baf83dc091cfa5c2f856e852cd','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1befcbb79c0aa00b386ab7a3c6b94c7c97384aeb33eb1deb62f2665e97052c90',2003,'NR','Nauru','people-and-society',332,'purchasing power parity - $60 million (2001 est.)
1.9% (2003 est.)
NA%
purchasing power parity - $5,000 (2001 est.)','ca933014db3c1f5679025d0c72100612717f384b9fd2e231ea4ab227ffe10b91','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('244fda0e84ed4c3baefea6a806efde53e53aa4bc636205cdc8fc70b3ff750619',2003,'NP','Nepal','people-and-society',333,'purchasing power parity - $37.32 billion (2002 est.)
2.26% (2003 est.)
-0.6% (2002 est.)
purchasing power parity - $1,400 (2002 est.)','479decadc53b4be670bdbb5ff43cf96384cc11e177b8c98676498d85a841a288','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2a64d215f1fcf32caf43af499dfa35bde03476106f358779378f2c76c69feae',2003,'NL','Netherlands','people-and-society',334,'purchasing power parity - $437.8 billion (2002 est.)
Netherlands Antilles
purchasing power parity - $2.4 billion (2002
est.)
0.5% (2003 est.)
Netherlands Antilles
0.9% (2003 est.)
0.2% (2002 est.)
Netherlands Antilles
0% (2002 est.)
purchasing power parity - $27,200 (2002 est.)
Netherlands Antilles
purchasing power parity - $11,400 (2002 est.)','58d7e7e239cf11de85ce2c73fae4caf53a34ba441697359cd4f7bfe94e74d246','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f852646da312599a058987ad3d9a28b1e43c72f8e2363589086c5f07aa33160d',2003,'NC','New Caledonia','people-and-society',335,'purchasing power parity - $3 billion (2002 est.)
1.38% (2003 est.)
NA
purchasing power parity - $14,000 (2002 est.)
overseas territory of France since 1956','a74b3f46022e249325d4ca4ff7a8e282e1d1618400e4b74f132b8c21190ba453','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('864a19b742b681383616f65257d157577bc1be9a63f1cea03a1018b16ad08401',2003,'NZ','New Zealand','people-and-society',336,'purchasing power parity - $78.4 billion (2002 est.)
1.09% (2003 est.)
3.3% (2002 est.)
purchasing power parity - $20,100 (2002 est.)','834cc86602223fe8c577f68620ed9aab9350f89429a0abebe182f1c731c4db8d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e88f72451672f7fb436b22f3aeb533c62906f5ab900d098424f7841bd42ab94',2003,'NI','Nicaragua','people-and-society',337,'purchasing power parity - $11.16 billion (2002 est.)
2.03% (2003 est.)
1.1% (2002 est.)
purchasing power parity - $2,200 (2002 est.)','47a1d6f4436687307bfb0910591ec8121a5636ecf025f708bef7615efac6e7ec','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c02567a6b28d16527910cb0d6def1b061dc0e76bf43b018406ee337b554126bb',2003,'NE','Niger','people-and-society',338,'purchasing power parity - $8.713 billion (2002 est.)
2.71% (2003 est.)
2.9% (2002 est.)
purchasing power parity - $800 (2002 est.)','45165995b8dbc93239333b69076798162d0ed4a700ea21be3fdc89c7c923329e','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('560b57fa9756eacafb4ed30b49149773ba3bcb3ef94d257537afe602bd641177',2003,'NG','Nigeria','people-and-society',339,'purchasing power parity - $112.5 billion (2002 est.)
2.53% (2003 est.)
3.2% (2002 est.)
purchasing power parity - $900 (2002 est.)','97f57f58bdb606f3f77a44a9b6041cd352d1f95dca1f22d412fa0e975c030f25','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bad5bdee0f552a7730554b8ea149f743384604d92f8950986c54d0fe8f22861',2003,'NU','Niue','people-and-society',340,'purchasing power parity - $7.6 million (2000 est.)
0.01% (2003 est.)
-0.3% (2000 est.)
purchasing power parity - $3,600 (2000 est.)
self-governing in free association with New Zealand since 1974;
Niue fully responsible for internal affairs; New Zealand retains
responsibility for external affairs and defense; however, these
responsibilities confer no rights of control and are only exercised
at the request of the Government of Niue','867e8d42e846f7feef08b593cd96676f4e7c14d81f5ee1ee653e57959e9a3596','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('770dcbc53b9cd63608d1cc6817b34571cdbecea57c60c87f9a17ec0d0767a34c',2003,'NF','Norfolk Island','people-and-society',341,'purchasing power parity - $NA
0.01% (2003 est.)
NA%
purchasing power parity - $NA
territory of Australia; Canberra administers
Commonwealth responsibilities on Norfolk Island through the
Department of Environment, Sport, and Territories','13a44d687eba7d5d76077139bbf1c7687b2c10f4bcccae9072bdd0dca80d18ad','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b769066664073ab5eaf9934a8c14f521b2d27c8497d8be0a08137ab10e9c817a',2003,'MP','Northern Mariana Islands','people-and-society',342,'purchasing power parity - $900 million
note: $900 million $900 million GDP estimate includes US subsidy
(2000 est.)
3.37% (2003 est.)
NA%
purchasing power parity - $12,500 (2000
est.)
commonwealth in political union with the
US; federal funds to the Commonwealth administered by the US
Department of the Interior, Office of Insular Affairs
Palmyra Atoll
incorporated territory of the US; privately owned, but
administered from Washington, DC, by the Fish and Wildlife Service
of the US Department of the Interior; the Office of Insular Affairs
of the US Department of the Interior continues to administer nine
excluded areas comprising certain tidal and submerged lands within
the 12 NM territorial sea or within the lagoon
Pitcairn Islands
overseas territory of the UK','6e76aa8c4f432e06ff0dacefc46cdc1097e3ccb514f00343bd75f0e745bce4ba','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce0a9f018e4ea0425e7b61c636e71890cc3357f1a3d2cde8da4dfe8ffe1b5307',2003,'NO','Norway','people-and-society',343,'purchasing power parity - $149.1 billion (2002 est.)
0.46% (2003 est.)
1% (2002 est.)
purchasing power parity - $33,000 (2002 est.)','18f36b080c1a98f3d63f41f0f68a3ce8ace87bd01878d1725d68a03a0f489f15','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c301378a1bbecf091934bc6acb19c7383180ca1aa2002646410f67a54cfa8678',2003,'OM','Oman','people-and-society',344,'purchasing power parity - $22.4 billion (2002 est.)
3.38% (2003 est.)
2.2% (2002 est.)
purchasing power parity - $8,300 (2002 est.)','5f7b3df77dede3ca134fae2050e5376955e9ba147ec2eb6a41fc78c5648c1a66','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe13e91cf5f0260fcdda9bbfce95c09dd2f78f3c61c691c6583e0e9c401b2453',2003,'PK','Pakistan','people-and-society',345,'purchasing power parity - $295.3 billion (2002 est.)
2.01% (2003 est.)
4.4% (FY01/02 est.)
purchasing power parity - $2,000 (FY01/02 est.)','107d34bddb90468573eb9421ac0d631ce7b01b73d4868f8ff32f035e5789f26f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdf36b23c7be31d6ffe7759601b69e05cea43815a98215f89fa1cc94f40f77be',2003,'PW','Palau','people-and-society',346,'purchasing power parity - $174 million
note: $174 million $174 million GDP estimate includes US subsidy
(2001 est.)
1.54% (2003 est.)
1% (2001 est.)
purchasing power parity - $9,000 (2001 est.)','3d3f32ec294870e38d060e632aeefb857e555231b4c9bfb2d2d57896ecc284c4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f154e0a8650dbd3c460452655d4dade0d43c2f9c00d0505e96be50cd4859351a',2003,'PA','Panama','people-and-society',347,'purchasing power parity - $18.06 billion (2002 est.)
1.36% (2003 est.)
0.7% (2002 est.)
purchasing power parity - $6,200 (2002 est.)','48746beb19c6a46118402dbb4288913d2f0662a336cc6174faccec23b1460681','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('824fd2fd489d6560ddd3dcc478facca87dec43192da133b6c966a196b7996fae',2003,'PG','Papua New Guinea','people-and-society',348,'purchasing power parity - $10.86 billion (2002 est.)
2.34% (2003 est.)
-3.1% (2002 est.)
purchasing power parity - $2,100 (2002 est.)','b8b8b42936b84692c7fc2d9ba51e4b5804a3aa0803f97d76c6820a0be7713984','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfe921a36973caeda44da451f26b4c78b3eefb43709e47a0c1d0e264b3e37069',2003,'PY','Paraguay','people-and-society',349,'purchasing power parity - $25.19 billion (2002 est.)
2.54% (2003 est.)
-2.7% (2002 est.)
purchasing power parity - $4,300 (2002 est.)','e6cc5c44d3d014c02fdf693fc22ef42311cdeaadd932e8fbfb81c53bd3c5c336','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55570cf092d37460574e0aa5d3ee0617691c59e597f588bc7b1bfebaca093fc1',2003,'PE','Peru','people-and-society',350,'purchasing power parity - $138.8 billion (2002 est.)
1.61% (2003 est.)
5.3% (2002 est.)
purchasing power parity - $5,000 (2002 est.)','c442b8f6692e16630992c44958747c30ba529f2439c6b68f485325a22b483a86','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ac442c0e823870bde323abd6cc3e829aa87c4d00fe924e743100b08a2fd773c',2003,'PH','Philippines','people-and-society',351,'purchasing power parity - $379.7 billion (2002 est.)
Pitcairn Islands
purchasing power parity - $NA
1.92% (2003 est.)
Pitcairn Islands
NA%
4.4% (2002 est.)
Pitcairn Islands
NA%
purchasing power parity - $4,600 (2002 est.)
Pitcairn Islands
purchasing power parity - $NA','cd30fc308a2213da93005a6c66de62eea3caef128303590d136270b0232596da','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5ca4a07d2c6108fa61446476420fb4553d2207807b2eac861a4ba560f69d8a1',2003,'PL','Poland','people-and-society',352,'purchasing power parity - $373.2 billion (2002 est.)
0% (2003 est.)
1.4% (2002 est.)
purchasing power parity - $9,700 (2002 est.)','50d72b67a074742f4d51b5b6430c50bf47e75b65c7cfef243f717d6c6698f544','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f87b46010f26da60257dcbec3497450aa0b90c344c211cd7e159e3dccd329d10',2003,'PT','Portugal','people-and-society',353,'purchasing power parity - $195.2 billion (2002 est.)
0.17% (2003 est.)
0.4% (2002 est.)
purchasing power parity - $19,400 (2002 est.)','97591ecb32c12cbe8dd97aa2b50067c780aabba603177107ab73016e1c191536','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('884c8cae401038a2c6321b45598c65794b555fec548caf0d6016c068fae8378d',2003,'PR','Puerto Rico','people-and-society',354,'purchasing power parity - $43.01 billion (2002 est.)
0.58% (2003 est.)
-0.2% (2002 est.)
purchasing power parity - $11,100 (2002 est.)
commonwealth associated with the US
Reunion
overseas department of France
Saint Helena
overseas territory of the UK','0a42575340c047b003e0f000a43b2959f46fcf17fdc9a88b03677e2a648fbba2','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b93d372662ec7a7aef19aa64a39ae099a329c66a9cea237da6ae03de14c002a',2003,'QA','Qatar','people-and-society',355,'purchasing power parity - $15.91 billion (2002 est.)
Reunion
purchasing power parity - $4.174 billion (1999 est.)
2.87% (2003 est.)
Reunion
1.47% (2003 est.)
4.6% (2002 est.)
Reunion
2.5% (2002 est.)
purchasing power parity - $20,100 (2002 est.)
Reunion
purchasing power parity - $5,600 (2002 est.)','8de687d552b63bd49a92a8bb6173e0deb7b2b43917eec9bf80b89e9b794e09f1','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2786a0389052cf6057a4b27fbc0a88d6f099416e34af24ddaa883805ed5aaa3',2003,'RO','Romania','people-and-society',356,'purchasing power parity - $169.3 billion (2002 est.)
Russia
purchasing power parity - $1.409 trillion (2002 est.)
-0.21% (2003 est.)
Russia
-0.3% (2003 est.)
4.9% (2002 est.)
Russia
4.3% (2002 est.)
purchasing power parity - $7,600 (2002 est.)
Russia
purchasing power parity - $9,700 (2002 est.)','0c55707750174fcbbd865a383ed6c26d0fe3b75d7639d9229a2431fa0ea2095d','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b24f5e98643ed57120f28524986be4ef1b3f9c567920b4d03c6e6f3c35af493',2003,'RW','Rwanda','people-and-society',357,'purchasing power parity - $8.92 billion (2002 est.)
Saint Helena
purchasing power parity - $18 million (1998 est.)
1.84% (2003 est.)
Saint Helena
0.67% (2003 est.)
9.7% (2002 est.)
Saint Helena
NA%
purchasing power parity - $1,200 (2002 est.)
Saint Helena
purchasing power parity - $2,500 (1998 est.)','9f3b19836c85a00e79dba685c6e436de2730fc1a8380102410d4614fb23f7018','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1cc5714c4a34df3c7474b91a83ff7f81449fce5c4c108aa42cddc9035883738',2003,'KN','Saint Kitts and Nevis','people-and-society',358,'purchasing power parity - $339 million (2002
est.)
0.13% (2003 est.)
-1.9% (2002 est.)
purchasing power parity - $8,800 (2002 est.)','71552ecca2a9ca85bffb0bb05e4d5ee13ebc50ad7e3526423e06560dbb8fc4ab','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5daa02a8c995daf96d3bedc45dd5d5f2b1190d0c26b2a0cce8dd05e86c45e93a',2003,'LC','Saint Lucia','people-and-society',359,'purchasing power parity - $866 million (2002 est.)
1.25% (2003 est.)
3.3% (2002 est.)
purchasing power parity - $5,400 (2002 est.)','43bca2b365ea7dea36dccad99b3135b11ab459f9b7b7195abfa571f6e304ad45','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fb749ca103a8ecef484891617de918204ecab45e4cfda235a555a20d2dd62b1',2003,'PM','Saint Pierre and Miquelon','people-and-society',360,'purchasing power parity - $74 million -
supplemented by annual payments from France of about $60 million
(1996 est.)
0.3% (2003 est.)
NA%
purchasing power parity - $11,000 (1996
est.)
self-governing territorial collectivity of','3001b3a63ea136f4b9c7438066cb57aceb74e552430e7dd18241871334870939','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5be8ea14c203bb8ed367b2c57d4d39a4329ea53537092dfbd2468633afaa6083',2003,'VC','Saint Vincent and the Grenadines','people-and-society',361,'purchasing power parity - $339
million (2002 est.)
0.34% (2003 est.)
-0.5% (2002 est.)
purchasing power parity - $2,900
(2002 est.)','d0862343ef31b00a9fa07f83800ece09215f264c4194d5fa0afb5da5712bb079','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be8349d0a2c49671a55f958da82d646299427c32d8a9a60ac3dc995b2702d357',2003,'WS','Samoa','people-and-society',362,'purchasing power parity - $1 billion (2002 est.)
-0.27% (2003 est.)
5% (2002 est.)
purchasing power parity - $5,600 (2002 est.)','c87e056a168667d32e1efeb62bba007366fe48af2c8c3345d79564c7d381b3a3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9b992dc509db1a9931a9af5e7e07f634c3a03f166c7c812e7d721ce0b9c00b6',2003,'SM','San Marino','people-and-society',363,'purchasing power parity - $940 million (2001 est.)
1.38% (2003 est.)
7.5% (2001 est.)
purchasing power parity - $34,600 (2001 est.)','24c04452919e5c27268b246e55db856d85a1993a2aade91a9581a3bdf386c93c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b3dc6fbb95c1cfabd0271a9847d43d06816acba851fa93d6dbecc9fbe458b7a',2003,'ST','Sao Tome and Principe','people-and-society',364,'purchasing power parity - $200 million (2002
est.)
3.18% (2003 est.)
4% (2002 est.)
purchasing power parity - $1,200 (2002 est.)','7d4c7aa07e935100fe260b037f820a5c7bb23f98d9441f2c521c650ce566f3f9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1db7b0e87ebc241b0b51a2d430f42fc8c2ca3553edf12e92a607a3546dbcd7e5',2003,'SA','Saudi Arabia','people-and-society',365,'purchasing power parity - $268.9 billion (2002 est.)
3.27% (2003 est.)
1% (2002 est.)
purchasing power parity - $11,400 (2002 est.)','6139913b9a9333420adf832a6263e854095f955c599954f1f050c374182aa4f4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d5de08deacd3077b2287dfbc6ab3165683344ebfc47aa1357b67d5669330ed6',2003,'SN','Senegal','people-and-society',366,'purchasing power parity - $15.64 billion (2002 est.)
Serbia and Montenegro
purchasing power parity - $23.15 billion (2002
est.)
2.56% (2003 est.)
Serbia and Montenegro
0.07% (2003 est.)
2.4% (2002 est.)
Serbia and Montenegro
4% (2002 est.)
purchasing power parity - $1,500 (2002 est.)
Serbia and Montenegro
purchasing power parity - $2,200 (2002 est.)','0860f3e4d7d86611f8750c8bb37d09b55c674be80dcfbbf0ae29eba69291c786','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24309304b2f1496011a2fb0f1932da93a83909375723bff64f7231cfe2d0ce67',2003,'SC','Seychelles','people-and-society',367,'purchasing power parity - $626 million (2002 est.)
0.46% (2003 est.)
1.5% (2002 est.)
purchasing power parity - $7,800 (2002 est.)','c70e44bde8c51fcc56fb5f0a38a83db90ecf42d6db093c7e7cbfde5b777e75dc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c4383ba130b5cd65ccc9b3e113d2a6f5077c9001555b46c78011141c62f870d',2003,'SL','Sierra Leone','people-and-society',368,'purchasing power parity - $2.826 billion (2002 est.)
2.94% (2003 est.)
6.6% (2002 est.)
purchasing power parity - $500 (2002 est.)','60ad57ce3df40c24b704ea51a4f3f0a0ed11c12599b7cd4938e1c8bd3a0f6708','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f74290d680ec0fa5550b0eece9e6127ca6b3783a194d8aed017917de758c6845',2003,'SG','Singapore','people-and-society',369,'purchasing power parity - $112.4 billion (2002 est.)
3.42% (2003 est.)
2.2% (2002 est.)
purchasing power parity - $25,200 (2002 est.)','22144528c55e1b58dfc929507efefb35b01684aae8b52a90e9a375daec60d3b3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfd779e2b90c17b0c2c73f559d81af9327593114e5c004f5e359b9e644a0ac41',2003,'SK','Slovakia','people-and-society',370,'purchasing power parity - $67.34 billion (2002 est.)
0.14% (2003 est.)
4.4% (2002 est.)
purchasing power parity - $12,400 (2002 est.)','3de63bc8f655669a67c38919bc92eff6303188f1450f901d5c74f6c7ff8b63ef','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9ea1d05157b6ca6a03ce5b4e01c5592707c59b5b64b4e185a58a077f9b95dff',2003,'SI','Slovenia','people-and-society',371,'purchasing power parity - $37.06 billion (2002 est.)
0.14% (2003 est.)
3.2% (2002 est.)
purchasing power parity - $19,200 (2002 est.)','d95997db089e76fa32665f5177b036138db2c9edfc349264461e8a877f930700','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6163f5189219fd0bc3331f6208e71541bd604c1fc14aef9e237da53c8920d5af',2003,'SB','Solomon Islands','people-and-society',372,'purchasing power parity - $800 million (2001 est.)
2.83% (2003 est.)
-10% (2001 est.)
purchasing power parity - $1,700 (2001 est.)','eb7b4f78978414534b6e72bbd0e0954dff6d889a8c5b4f00431df46a84a2b4e8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ee9a26182b9b15dddfc62c47ba5d8beb698711d97037b90e104ddb8439a0762',2003,'SO','Somalia','people-and-society',373,'purchasing power parity - $4.27 billion (2001 est.)
3.43% (2003 est.)
3.5% (2002 est.)
purchasing power parity - $600 (2002 est.)','1cdba3b6abceb0bdf9daae0f37f48637cbff986bea8b994320696509f5f1d527','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0dfdb40939b198ad8142c678b3f4d62eb68c523d8b50ab4d5ac41530092bb473',2003,'ZA','South Africa','people-and-society',374,'purchasing power parity - $427.7 billion (2002 est.)
0.01% (2003 est.)
3% (2002 est.)
purchasing power parity - $10,000 (2002 est.)','bd59112a8b8896041a835343e406c274c4ac0b05d41100c7b05ac7d50c63aca5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ffc6da89a0881ca0d3042cbfe91de7e0ceffc611bbd58c040aab8ed93c312de',2003,'ES','Spain','people-and-society',375,'purchasing power parity - $850.7 billion (2002 est.)
0.16% (2003 est.)
2% (2002 est.)
purchasing power parity - $21,200 (2002 est.)','aaab3489e62ed0057667dc4f64802fd96b35c68f86bd0a1d4433408e8826a9f3','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f248b2c3c9fac4953980d2411252bc52bf2d06f067f18d52ce7902d937e37ff5',2003,'LK','Sri Lanka','people-and-society',376,'purchasing power parity - $73.7 billion (2002 est.)
0.83% (2003 est.)
3.2% (2002 est.)
purchasing power parity - $3,700 (2002 est.)','e78dc8a3a9d2f1c03eec85820dc5f77957ddab3c574dc64816c4eb5be49b3f86','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e55eddc0b925e8c163e7c3ae8d700cbc7e30241d5b4991a821336f407dd843e',2003,'SD','Sudan','people-and-society',377,'purchasing power parity - $52.9 billion (2002 est.)
2.71% (2003 est.)
5.1% (2002 est.)
purchasing power parity - $1,400 (2002 est.)','7436cdc3faac2703a2986a6a6f665415a83a05e10a3f16ad3e56d49e1f6a8f49','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2e24a34f0f322874df9c0b57d274746afefd10fda73ffeb07ac703a3c462353',2003,'SR','Suriname','people-and-society',378,'purchasing power parity - $1.469 billion (2002 est.)
Svalbard
purchasing power parity - $NA
Swaziland
purchasing power parity - $5.542 billion (2002 est.)
0.37% (2003 est.)
Svalbard
-0.02% (2003 est.)
Swaziland
0.83% (2003 est.)
1.2% (2002 est.)
Svalbard
NA%
Swaziland
1.6% (2002 est.)
purchasing power parity - $3,400 (2002 est.)
Svalbard
purchasing power parity - $NA
Swaziland
purchasing power parity - $4,800 (2002 est.)','40a39c64304147747249bdfcf4311df3cdb3accb7988c00c4c3470d0b09a8710','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50b44a79b08b83041977476174a85883a21f23fb9f81ce257b80e7fe914b9370',2003,'SE','Sweden','people-and-society',379,'purchasing power parity - $230.7 billion (2002 est.)
0.01% (2003 est.)
1.9% (2002 est.)
purchasing power parity - $26,000 (2002 est.)','52998a16dd890768ef739eae2a6b2295deddb6be056e7918659f15db2c31679b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da731d034009aa0108c320fce5a99569a6c0731ced9627dd82d8b07e64f7bcac',2003,'CH','Switzerland','people-and-society',380,'purchasing power parity - $233.4 billion (2002 est.)
Syria
purchasing power parity - $63.48 billion (2002 est.)
Taiwan
purchasing power parity - $406 billion (2002 est.)
0.21% (2003 est.)
Syria
2.45% (2003 est.)
Taiwan
0.65% (2003 est.)
0.1% (2002 est.)
Syria
3.6% (2002 est.)
Taiwan
3.5% (2002 est.)
purchasing power parity - $32,000 (2002 est.)
Syria
purchasing power parity - $3,700 (2002 est.)
Taiwan
purchasing power parity - $18,000 (2002 est.)','01ecc63b1c0a7f7e3a6a9f8d9e655096c88d8fc1365f32ff389e38fac66e8256','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1686329e28ae19b2e7e273835aa2257f8635b5f1ca7b7a64dc5565469a5d943b',2003,'TJ','Tajikistan','people-and-society',381,'purchasing power parity - $8.476 billion (2002 est.)
Tanzania
purchasing power parity - $20.42 billion (2002 est.)
2.13% (2003 est.)
Tanzania
1.72% (2003 est.)
9.1% (2002 est.)
Tanzania
6.1% (2002 est.)
purchasing power parity - $1,300 (2002 est.)
Tanzania
purchasing power parity - $600 (2002 est.)','fd00e2ad18b98bf58a2d319df43966a5e1d1a5e2e4f1ea73750ce39b84f1ccfb','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71cf669ea4307f439df423e5391645f79d3a1b784568794b436b69ec3726a226',2003,'TH','Thailand','people-and-society',382,'purchasing power parity - $445.8 billion (2002 est.)
0.95% (2003 est.)
5.3% (2002 est.)
purchasing power parity - $7,000 (2002 est.)','370fc8a29aade087e2865138fbc8282f664d2d891ad1d20b8ae52b83f1807bbc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f083b1c2fd43f90302fce4d707c8f7f488b45875cfe6eb3dd2040f873b8866fe',2003,'TG','Togo','people-and-society',383,'purchasing power parity - $7.594 billion (2002 est.)
2.37% (2003 est.)
2.9% (2002 est.)
purchasing power parity - $1,400 (2002 est.)','d2d17a877e4c6c1a50854d89b17a8f3292dfaf82f15cbbc62be494f41b0855c5','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('005d6915551f548d3496232275b531c315ecd06997ee890a1d29548aa22e61aa',2003,'TK','Tokelau','people-and-society',384,'purchasing power parity - $1.5 million (1993 est.)
0.01% (2003 est.)
NA%
purchasing power parity - $1,000 (1993 est.)
self-administering territory of New Zealand; note -
Tokelauans are drafting a constitution and developing institutions
and patterns of self-government as Tokelau moves toward free
association with New Zealand
Tromelin Island
possession of France; administered by a high
commissioner of the Republic, resident in Reunion','05127f3abc5ca987f27df8c2a9d3422208152d3d39c6dbc51050800f952e6a66','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('119936b1431a9886e01c150a330a14f7f4fde1d4788d8cac7f0308c8a62da9d5',2003,'TO','Tonga','people-and-society',385,'purchasing power parity - $236 million (2001 est.)
1.9% (2003 est.)
3% (2001 est.)
purchasing power parity - $2,200 (2001 est.)','bada41178b22f8497e99396d64fac5db051453cb84987f2e66e6c9b3c6b69aac','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce9bc824fc71aa3e24e5d94cb467c1db7524c78a88f99963e73d71fc6c3db260',2003,'TT','Trinidad and Tobago','people-and-society',386,'purchasing power parity - $11.07 billion (2002
est.)
-0.68% (2003 est.)
3.2% (2002 est.)
purchasing power parity - $10,000 (2002 est.)','793c0cb7233aba9d31a9151dda3696d765c4e4cc5afdb445f841889a430e2821','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5900d9b1ff0322abd5dccea3e2cdf7e920c58b12b440a79447f300b4b0e69ba7',2003,'TN','Tunisia','people-and-society',387,'purchasing power parity - $67.13 billion (2002 est.)
Turkey
purchasing power parity - $489.7 billion (2002 est.)
1.09% (2003 est.)
Turkey
1.16% (2003 est.)
4.8% (2002 est.)
Turkey
7.8% (2002 est.)
purchasing power parity - $6,800 (2002 est.)
Turkey
purchasing power parity - $7,300 (2002 est.)','b0b74d273944f93be6e2c1f87575ae945355e2141443d30381a975e772a0bafb','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4858f9912199c8b43bde4bb7e2db17ef7e599d80360d3c1a7f62f11e8461785',2003,'TM','Turkmenistan','people-and-society',388,'purchasing power parity - $31.34 billion (2002 est.)
1.82% (2003 est.)
21.1% (2002 est.)
purchasing power parity - $6,700 (2002 est.)','935d0446adbf41e0ba6926bae9d083d6e57214c2c77fb9f90e3e8385491ae8e0','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04466f37246a8f0120d1a5d74d0705f4f79556dba1521df23008b0cac8ff1109',2003,'TC','Turks and Caicos Islands','people-and-society',389,'purchasing power parity - $231 million
(2000 est.)
3.14% (2003 est.)
4.9% (2000 est.)
purchasing power parity - $9,600 (2000 est.)
overseas territory of the UK
Virgin Islands
organized, unincorporated territory of the US with
policy relations between the Virgin Islands and the US under the
jurisdiction of the Office of Insular Affairs, US Department of the
Interior
Wake Island
unincorporated territory of the US; administered from
Washington, DC, by the Department of the Interior; activities on the
island are managed by the US Air Force','cfce85e510c3722628671516f493d7e47ff9fa4e27ba1f0b16300a441f87c6f4','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9315616a84ecc41e049ac61ab9cdcc547415ad990829b371753964897c388639',2003,'TV','Tuvalu','people-and-society',390,'purchasing power parity - $12.2 million (2000 est.)
1.42% (2003 est.)
3% (2000 est.)
purchasing power parity - $1,100 (2000 est.)','da86998295cfa9ad056b968183004ce0cc7a638f91f3ee8625d07149763e45af','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a27e4ff1153b01b5465a7d82170df95a81294fe84b63782a87df62f6b8e68e30',2003,'UG','Uganda','people-and-society',391,'purchasing power parity - $30.49 billion (2002 est.)
2.96% (2003 est.)
5.5% (2002 est.)
purchasing power parity - $1,200 (2002 est.)','b7651157cc881a7f2472cdc24bf66a2f1a26bdaaa80c9826002d222ce3d96e6f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfe8f7daed15bb9a5b17c378518bee30c0e56331024b443975dd068095938083',2003,'UA','Ukraine','people-and-society',392,'purchasing power parity - $218 billion (2002 est.)
-0.69% (2003 est.)
4.8% (2002 est.)
purchasing power parity - $4,500 (2002 est.)','9579a569a005141b3c4b10290a4130f7afe9a9c64a883631cc605d0220cae1a8','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fabae3154022f09dbe8fce3e69b860b0526a5bcd6dd4753d01e53cd067afa06',2003,'AE','United Arab Emirates','people-and-society',393,'purchasing power parity - $53.97 billion (2002
est.)
1.57% (2003 est.)
1.8% (2002 est.)
purchasing power parity - $22,100 (2002 est.)','8ba3d71b027a9f82566c91409f1713ee24fad2639e389ec65e4bfdfa2acc949f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c387371e1682daba25ea4dcfcef2c00a2850ebb0832bdbea76e32ee3d84bf127',2003,'GB','United Kingdom','people-and-society',394,'purchasing power parity - $1.528 trillion (2002 est.)
0.3% (2003 est.)
1.8% (2002 est.)
purchasing power parity - $25,500 (2002 est.)','eb2c739be399990471289292d7e352b29ec7b0ebf0fa38bf26fc90ec030ceb2a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3fe46311e665e4a7fe32f7577c11d084134a8010c3e482ef631dd3ea9a8d743',2003,'US','United States','people-and-society',395,'purchasing power parity - $10.45 trillion (2002 est.)
0.92% (2003 est.)
2.4% (2002 est.)
purchasing power parity - $36,300 (2002 est.)','9258d810132ce06f312450ac3b117c0c9cd46b65854718110ce4a4a599691a88','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9950bf7be0a3d989fb527516b164d21753583fb2e143744ecefce1e4ac46b272',2003,'UY','Uruguay','people-and-society',396,'purchasing power parity - $26.82 billion (2002 est.)
0.79% (2003 est.)
-10.8% (2002 est.)
purchasing power parity - $7,900 (2002 est.)','bf8466e7268e0a9da6a8104267cbddd50d753d1c2778c4adc47d146e37e8912b','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc33d72ca335d8ef8bef352a8043cb366c0962b18e789f079446ffe581b048a4',2003,'UZ','Uzbekistan','people-and-society',397,'purchasing power parity - $66.06 billion (2002 est.)
1.63% (2003 est.)
4.2% (2002 est.)
purchasing power parity - $2,600 (2002 est.)','70167ea035cf3c3ceab55ac9b1dd0d6e92b73518ddb7f4b33589691c69f364ee','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43ff306f8c805cc44491b82e7a93baf32a3fe14ca89c95a1692ff90f4546f61e',2003,'VU','Vanuatu','people-and-society',398,'purchasing power parity - $563 million (2002 est.)
Venezuela
purchasing power parity - $131.7 billion (2002 est.)
Vietnam
purchasing power parity - $183.8 billion (2002 est.)
Virgin Islands
purchasing power parity - $2.4 billion (2001 est.)
1.61% (2003 est.)
Venezuela
1.48% (2003 est.)
Vietnam
1.29% (2003 est.)
Virgin Islands
1.02% (2003 est.)
-0.3% (2002 est.)
Venezuela
-8.9% (2002 est.)
Vietnam
7% (2002 est.)
Virgin Islands
2% (2001 est.)
purchasing power parity - $2,900 (2002 est.)
Venezuela
purchasing power parity - $5,400 (2002 est.)
Vietnam
purchasing power parity - $2,300 (2002 est.)
Virgin Islands
purchasing power parity - $19,000 (2001 est.)','fb4b90423ef746f687c748660e1a483a4ca54cf1bd11e9f6678b0450b790c4e9','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a4763450ee10c95a2512b3f74d5a7de5769c5848690c4b1e71b78ea2df72335',2003,'EH','Western Sahara','people-and-society',399,'purchasing power parity - $NA
World
GWP (gross world product) - purchasing power parity - $49
trillion (2002 est.)
NA% (2003 est.)
World
1.17% (2003 est.)
NA%
World
2.7% (2001 est.)
purchasing power parity - $NA
World
purchasing power parity - $7,900 (2002 est.)','4a30077ac616337e79d0a9ef87e6c5d939d2297856ae8e60f09add40f050de2f','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b071d6b83fc9d4b83ccf7b972f8622271486bd3bf32277a21e40ef7f4345952d',2003,'YE','Yemen','people-and-society',400,'purchasing power parity - $15.07 billion (2002 est.)
3.42% (2003 est.)
4.1% (2002 est.)
purchasing power parity - $800 (2002 est.)','d3447125c4a8746e94d63bb86e0aa847494c88b70581046dfc3fc9964359337a','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85d473f87839bf437805ea5c2f5965e99cf529303b232c8c819e5e432666ecd2',2003,'ZM','Zambia','people-and-society',401,'purchasing power parity - $8.24 billion (2002 est.)
1.52% (2003 est.)
2.3% (2002 est.)
purchasing power parity - $800 (2002 est.)','c002d3e609a40666041cca688765fc1e26fd60219803b5f02a53c128bc04a331','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9324165047a611eacb3d3368d482aab3eb51b686c0c19f03e5a272645095aa0',2003,'BV','Bouvet Island','people-and-society',402,'territory of Norway; administered by the Polar
Department of the Ministry of Justice and Police from Oslo','a602d22c9c2afea39d62ac445c6985ef01fa76486b333f2b4b13ad104c4d49dd','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6d160d89a3ba1be31fa2b17c0565f5538b7089289a1e0ec984d7f02610c21b5',2003,'IO','British Indian Ocean Territory','people-and-society',403,'overseas territory of the UK;
administered by a commissioner, resident in the Foreign and
Commonwealth Office in London
British Virgin Islands
overseas territory of the UK; internal
self-governing
none (overseas territory of the UK)
British Virgin Islands
none (overseas territory of the UK)
Brunei
chief of mission: Ambassador Gene B. CHRISTY
embassy: Third Floor, Teck Guan Plaza, Jalan Sultan, Bandar Seri
Begawan
mailing address: PSC 470 (BSB), FPO AP 96507
telephone: [673] (2) 229670
FAX: [673] (2) 225293','5a94b1d60d16e8e19e9b30595fc5aa14501ea8bdaa80b6fb397b937e62b7554c','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('277f81697bfc77888159493221c1d7ca872030418aae6f0aa22b51ce317b1b3d',2003,'HM','Heard Island and McDonald Islands','people-and-society',404,'territory of Australia;
administered from Canberra by the Australian Antarctic Division of
the Department of the Environment and Heritage
none (territory of Australia)
Holy See (Vatican City)
chief of mission: Ambassador R. James "Jim"
NICHOLSON
embassy: Villa Domiziana, Via delle Terme Deciane 26, 00153 Rome
mailing address: PSC 59, Box 66, APO AE 09624
telephone: [39] (06) 4674-3428
FAX: [39] (06) 5758346','d6956161160611609e4fa736b18e6eaba4aec6b436818ba1557ade6a7167f163','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac93c5465d6909a78698447891ec9756cef04196737b5d72ad87428bbc0bcfdf',2003,'GS','South Georgia and the South Sandwich Islands','people-and-society',405,'overseas territory of
the UK, also claimed by Argentina; administered from the Falkland
Islands by a commissioner, who is concurrently governor of the
Falkland Islands, representing Queen ELIZABETH II; Grytviken,
formerly a whaling station on South Georgia, is a scientific base
Svalbard
territory of Norway; administered by the Polar Department
of the Ministry of Justice, through a governor (sysselmann) residing
in Longyearbyen, Spitsbergen; by treaty (9 February 1920)
sovereignty was awarded to Norway','7e971d51ab96a582acbf1aa2eb6d17adb08c5a590ed34379f74ebe4d95de64bc','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

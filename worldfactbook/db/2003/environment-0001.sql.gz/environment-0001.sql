SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e648e8b3acfce2f2315f3deb2673ecdc72a77c2f9204951df7f4f539f60de500',2003,'UA','Ukraine','environment',163,'Geography - note:
vegetation scanty
People Saint Pierre and Miquelon
Population:
6,976 (July 2003 est.)
Age structure:
0-14 years: 25% (male 891; female 851)
15-64 years: 64.7% (male 2,306; female 2,210)
65 years and over: 10.3% (male 310; female 408) (2003 est.)
Median age:
total: 32.9 years
male: 32.7 years
female: 33.1 years (2002)
Population growth rate:
0.3% (2003 est.)
Birth rate:
14.62 births/1,000 population (2003 est.)
Death rate:
6.74 deaths/1,000 population (2003 est.)
Net migration rate:
-4.87 migrant(s)/1,000 population (2003 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 1.01 male(s)/female (2003 est.)
Infant mortality rate:
total: 7.97 deaths/1,000 live births
female: 6.73 deaths/1,000 live births (2003 est.)
male: 9.15 deaths/1,000 live births
Life expectancy at birth:
total population: 78.11 years
male: 75.82 years
female: 80.51 years (2003 est.)
Total fertility rate:
2.07 children born/woman (2003 est.)
HIV/AIDS - adult prevalence rate:
NA%
HIV/AIDS - people living with HIV/AIDS:
NA
HIV/AIDS - deaths:
NA
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups:
Basques and Bretons (French fishermen)
Religions:
Roman Catholic 99%
Languages:
French (official)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)
Government Saint Pierre and Miquelon
Country name:
conventional long form: Territorial Collectivity of Saint Pierre
and Miquelon
conventional short form: Saint Pierre and Miquelon
local short form: Saint-Pierre et Miquelon
local long form: Departement de Saint-Pierre et Miquelon
Dependency status:
self-governing territorial collectivity of France
Government type:
NA
Capital:
Saint-Pierre
Administrative divisions:
none (territorial collectivity of France); note - there are no
first-order administrative divisions as defined by the US
Government, but there are two communes - Saint Pierre, Miquelon at
the second order
Independence:
none (territorial collectivity of France; has been under French
control since 1763)
National holiday:
Bastille Day, 14 July (1789)
Constitution:
28 September 1958 (French Constitution)
Legal system:
French law with special adaptations for local conditions, such as
housing and taxation
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Jacques CHIRAC of France (since 17 May
1995), represented by Prefect Claude VALLEIX (since 9 October 2002)
elections: French president elected by popular vote for a five-year
term; election last held, first round - 21 April 2002, second round
- 5 May 2002 (next to be held NA 2007); prefect appointed by the
French president on the advice of the French Ministry of Interior;
president of the General Council is elected by the members of the
council
head of government: President of the General Council Marc
PLANTAGENEST (since NA)
cabinet: NA
Legislative branch:
unicameral General Council or Conseil General (19 seats - 15 from
Saint Pierre and 4 from Miquelon; members are elected by popular
vote to serve six-year terms)
elections: elections last held 19 and 26 March 2000 (next to be held
NA April 2006)
election results: percent of vote by party - NA%; seats by party -
PS 12, PRG 2, UDF-RPR 5
note: Saint Pierre and Miquelon elect 1 seat to the French Senate;
elections last held NA September 1995 (next to be held NA September
2004); results - percent of vote by party - NA%; seats by party -
RPR 1; Saint Pierre and Miquelon also elects 1 seat to the French
National Assembly; elections last held, first round - 9 June 2002,
second round - 16 June 2002 (next to be held NA 2007); results -
percent of vote by party - NA%; seats by party - UDF 1
Judicial branch:
Superior Tribunal of Appeals or Tribunal Superieur d''Appel
Political parties and leaders:
PRG [leader NA]; Rassemblement pour la Republique or RPR (now UMP)
[leader NA]; Socialist Party or PS [leader NA]; Union pour la
Democratie Francaise or UDF [leader NA]
Political pressure groups and leaders:
NA
International organization participation:
FZ, WFTU
Diplomatic representation in the US:
none (territorial collectivity of France)
Diplomatic representation from the US:
none (territorial collectivity of France)
Flag description:
a yellow sailing ship facing the hoist side rides on a dark blue
background with a black wave line under the ship; on the hoist side,
a vertical band is divided into three parts: the top part (called
ikkurina) is red with a green diagonal cross extending to the
corners overlaid by a white cross dividing the rectangle into four
sections; the middle part has a white background with an ermine
pattern; the third part has a red background with two stylized
yellow lions outlined in black, one above the other; these three
heraldic arms represent settlement by colonists from the Basque
Country (top), Brittany, and Normandy; the flag of France is used
for official occasions
Economy Saint Pierre and Miquelon
Economy - overview:
The inhabitants have traditionally earned their livelihood by
fishing and by servicing fishing fleets operating off the coast of
Newfoundland. The economy has been declining, however, because of
disputes with Canada over fishing quotas and a steady decline in the
number of ships stopping at Saint Pierre. In 1992, an arbitration
panel awarded the islands an exclusive economic zone of 12,348 sq km
to settle a longstanding territorial dispute with Canada, although
it represents only 25% of what France had sought. The islands are
heavily subsidized by France to the great betterment of living
standards. The government hopes an expansion of tourism will boost
economic prospects. Recent test drilling for oil may pave the way
for development of the energy sector.
GDP:
purchasing power parity - $74 million - supplemented by annual
payments from France of about $60 million (1996 est.)
GDP - real growth rate:
NA%
GDP - per capita:
purchasing power parity - $11,000 (1996 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line:
NA%
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices):
2.1% (1991-96 average)
Labor force:
3,261 (1999)
Labor force - by occupation:
fishing 18%, industry (mainly fish-processing) 41%, services 41%
(1996 est.)
Unemployment rate:
9.8% (1997)
Budget:
revenues: $70 million
expenditures: $60 million, including capital expenditures of $24
million (1996 est.)
Industries:
fish processing and supply base for fishing fleets; tourism
Industrial production growth rate:
NA%
Electricity - production:
42.03 million kWh (2001)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
other: 0% (2001)
nuclear: 0%
Electricity - consumption:
39.08 million kWh (2001)
Electricity - exports:
0 kWh (2001)
Electricity - imports:
0 kWh (2001)
Oil - production:
0 bbl/day (2001 est.)
Oil - consumption:
600 bbl/day (2001 est.)
Oil - exports:
NA (2001)
Oil - imports:
NA (2001)
Agriculture - products:
vegetables; poultry, cattle, sheep, pigs; fish
Exports:
$12 million f.o.b. (1999)
Exports - commodities:
fish and fish products, soybeans, animal feed, mollusks and
crustaceans, fox and mink pelts
Exports - partners:
US 33.3%, Zambia 30.3%, Ecuador 16.2%, France 5.1%, Canada 4%,
Spain 4% (2002)
Imports:
$55 million f.o.b. (1999)
Imports - commodities:
meat, clothing, fuel, electrical equipment, machinery, building
materials
Imports - partners:
Zambia 61.5%, France 21.8%, Canada 13% (2002)
Debt - external:
$NA
Economic aid - recipient:
approximately $60 million in annual grants from France
Currency:
euro (EUR)
Currency code:
EUR
Exchange rates:
euros per US dollar - 1.06 1.0626 (2001), 1.08540 (2000), 0.93863
(1999)
Fiscal year:
calendar year
Communications Saint Pierre and Miquelon
Telephones - main lines in use:
4,000 (1997)
Telephones - mobile cellular:
0 (1994)
Telephone system:
general assessment: adequate
domestic: NA
international: radiotelephone communication with most countries in
the world; 1 earth station in French domestic satellite system
Radio broadcast stations:
AM 1, FM 4, shortwave 0 (1998)
Radios:
4,000 (1997)
Television broadcast stations:
0 (there are, however, two repeaters which rebroadcast programs
from France, Canada, and the US) (1997)
Televisions:
4,000 (1997)
Internet country code:
.pm
Internet Service Providers (ISPs):
1 (2000)
Internet users:
NA
Transportation Saint Pierre and Miquelon
Railways:
0 km
Highways:
total: 114 km
paved: 69 km
unpaved: 45 km
Waterways:
none
Ports and harbors:
Saint Pierre
Merchant marine:
none (2002 est.)
Airports:
2 (2002)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2002)
Military Saint Pierre and Miquelon
Military - note:
defense is the responsibility of France
Transnational Issues Saint Pierre and Miquelon
Disputes - international:
none
This page was last updated on 18 December, 2003
======================================================================
@Saint Vincent and the Grenadines
Introduction Saint Vincent and the Grenadines','0db084a4d8773a7fb4e301d8525626af260a17d672e4851a23c2340ff7aa5b21','internet-archive','theciaworldfactb27558gut','txt','317c17cf58445e168af075edbca0f50d049429d243084380a7a870ea9ba847f0','https://archive.org/download/theciaworldfactb27558gut/27558.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
